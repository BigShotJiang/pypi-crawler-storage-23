"""Pine CLI — unified command-line interface for Pine AI."""

__version__ = "0.3.0"
