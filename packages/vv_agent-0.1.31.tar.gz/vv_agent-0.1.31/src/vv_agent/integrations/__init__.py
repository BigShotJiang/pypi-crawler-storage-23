from vv_agent.integrations.protocols import SkillIntegration

__all__ = ["SkillIntegration"]
