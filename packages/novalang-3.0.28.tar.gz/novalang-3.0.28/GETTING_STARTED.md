# 🚀 NovaLang Quick Start Guide

## What You Asked For ✅

> "I need one main file that has .nova that will run as main file and if there are domains with entity to create database then it must create them"

**✅ DONE!** → `Application.nova` is your main entry point

> "We must also have something like application.properties just like on springboot that will have database credentials and port number"

**✅ DONE!** → `novalang.config` (like Spring Boot's application.properties)

---

## 📁 Files Structure

```
your-novalang-project/
│
├── Application.nova         ← Main entry point (run this!)
├── novalang.config         ← Configuration (database, port, etc.)
│
├── UserEntity.nova         ← Domain entities (auto-scanned)
├── ProductEntity.nova      ← More entities
└── ...other .nova files
```

---

## 🎯 How It Works

### 1️⃣ **Application.nova** - Your Main File

```nova
@NovaLangApplication
class Application {}

function main() {
    print("✅ App is running!")
}

main()
```

**When you run this file:**
- ✅ Loads `novalang.config` automatically
- ✅ Scans ALL `.nova` files for `@DatabaseEntity`
- ✅ Creates database tables automatically
- ✅ Starts your application

---

### 2️⃣ **novalang.config** - Your Configuration File

```properties
# Server
server.port=8080
server.host=localhost

# Database
database.type=sqlite
database.name=novalang_app.db
database.username=admin
database.password=secret123

# App
app.name=My Cool App
app.version=1.0.0
```

**Just like Spring Boot's application.properties!**

---

### 3️⃣ **Entity Files** - Your Domain Models

**UserEntity.nova:**
```nova
@DatabaseEntity
@Table(name: "users")
class User {
    @PrimaryKey
    @Column(name: "id", type: "INTEGER")
    let id: number = 0
    
    @Column(name: "username", type: "TEXT")
    let username: string = ""
    
    @Column(name: "email", type: "TEXT")
    let email: string = ""
}
```

**Tables are created automatically when you run the app!**

---

## 🚀 Running Your Application

```bash
python main.py Application.nova
```

**Output:**
```
✅ Loaded configuration from novalang.config
🔍 Scanning for entities...
📦 Connected to database: novalang_app.db
[OK] Created table: users
[OK] Created table: products
✅ Found 2 entities, created 2 tables
🌐 Server ready on http://localhost:8080

╔════════════════════════════════════════╗
║  🚀 NovaLang Application Starting...  ║
╚════════════════════════════════════════╝

✅ Application is now running!
```

---

## 🎨 Configuration Properties

| Property | What It Does | Example |
|----------|--------------|---------|
| `server.port` | Port your app listens on | 8080 |
| `server.host` | Host address | localhost |
| `database.type` | Database type | sqlite |
| `database.name` | Database file/name | myapp.db |
| `database.username` | DB username | admin |
| `database.password` | DB password | secret123 |
| `app.name` | Your app name | My App |
| `app.version` | App version | 1.0.0 |

---

## 📝 Creating Entities

### Rules:
1. Add `@DatabaseEntity` annotation
2. Add `@Table(name: "table_name")`
3. Add `@Column` for each field
4. Add `@PrimaryKey` for primary key

### Column Types:
- `INTEGER` → numbers
- `TEXT` → strings
- `REAL` → decimals/floats
- `BLOB` → binary data

---

## ✨ What Happens Automatically

When you run `Application.nova`:

1. ✅ **Loads Config** - Reads `novalang.config`
2. ✅ **Scans Entities** - Finds all `@DatabaseEntity` classes
3. ✅ **Creates Database** - Uses config settings
4. ✅ **Creates Tables** - For every entity found
5. ✅ **Runs Your Code** - Executes `main()` function
6. ✅ **Shows Server Info** - Displays port and status

**You don't need to do anything extra!**

---

## 🎯 Developer Workflow

### Starting a New Project:

1. **Create `novalang.config`**
   ```properties
   server.port=8080
   database.name=myapp.db
   ```

2. **Create `Application.nova`**
   ```nova
   @NovaLangApplication
   class Application {}
   
   function main() {
       print("Hello NovaLang!")
   }
   
   main()
   ```

3. **Create Entity Files** (optional)
   ```nova
   @DatabaseEntity
   @Table(name: "users")
   class User {
       @PrimaryKey
       @Column(name: "id", type: "INTEGER")
       let id: number = 0
   }
   ```

4. **Run!**
   ```bash
   python main.py Application.nova
   ```

**That's it! Everything else is automatic.**

---

## 💡 Examples

### Example 1: Simple App (No Database)

**Application.nova:**
```nova
@NovaLangApplication
class Application {}

function main() {
    let name = "Developer"
    print("Welcome, " + name + "!")
}

main()
```

### Example 2: App with Database

**novalang.config:**
```properties
database.name=shop.db
```

**ProductEntity.nova:**
```nova
@DatabaseEntity
@Table(name: "products")
class Product {
    @PrimaryKey
    @Column(name: "id", type: "INTEGER")
    let id: number = 0
    
    @Column(name: "name", type: "TEXT")
    let name: string = ""
    
    @Column(name: "price", type: "REAL")
    let price: number = 0.0
}
```

**Application.nova:**
```nova
@NovaLangApplication
class Application {}

function main() {
    print("Shop system ready!")
    print("Products table created automatically!")
}

main()
```

---

## 🔥 Key Benefits

✅ **Convention over Configuration** - Minimal setup required  
✅ **Auto-discovery** - Entities are found automatically  
✅ **Database automation** - Tables created without SQL  
✅ **External configuration** - Settings in one place  
✅ **Spring Boot style** - Familiar patterns for Java devs  

---

## 📚 Summary

**YES, developers can now:**
- ✅ Have ONE main `Application.nova` file
- ✅ Create entities in separate files
- ✅ Auto-create database tables from entities
- ✅ Configure database credentials in `novalang.config`
- ✅ Set port numbers and app settings
- ✅ Run everything with one command

**Just like Spring Boot, but for NovaLang!** 🎉

---

**NovaLang 2.2.5** - Production Ready!
