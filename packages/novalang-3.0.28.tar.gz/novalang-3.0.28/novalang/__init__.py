"""
NovaLang - A Modern Programming Language with Spring Boot-Style Framework

A modern programming language with Spring Boot-style application framework,
automatic database table creation, and external configuration support.

Features:
- Spring Boot-style architecture (@NovaLangApplication, @DatabaseEntity)
- Automatic entity scanning and database table creation
- External configuration (novalang.config like application.properties)
- Support for SQLite and MySQL
- Code execution with variables, functions, and control flow
- Simple, TypeScript-like syntax

Usage:
    # Run a NovaLang application
    python -m novalang Application.nova
    
    # Or use the nova command
    nova Application.nova

Author: Martin Maboya
Email: martinmaboya@gmail.com
GitHub: https://github.com/martinmaboya/novalang
"""

__version__ = "3.0.27"
__author__ = "Martin Maboya"
__email__ = "martinmaboya@gmail.com"
__description__ = "NovaLang - Spring Boot-Style Programming Language"

# Core modules
from . import lexer
from . import parser
from . import interpreter
from . import runtime
from . import config_reader

# Main entry points
try:
    from .main import main
except ImportError:
    main = None

# Export commonly used classes
__all__ = [
    'lexer',
    'parser', 
    'interpreter',
    'runtime',
    'config_reader',
    'main',
    '__version__'
]
__all__ = [
    "lexer",
    "parser", 
    "interpreter",
    "main",
    "nova_main",
    "__version__",
    "__author__",
    "__email__",
    "__description__"
]

def get_version():
    """Return the current version of NovaLang."""
    return __version__

def get_info():
    """Return information about NovaLang."""
    return {
        "name": "NovaLang",
        "version": __version__,
        "author": __author__,
        "email": __email__,
        "description": __description__,
        "homepage": "https://github.com/martinmaboya/novalang",
        "documentation": "https://martinmaboya.github.io/novalang"
    }
