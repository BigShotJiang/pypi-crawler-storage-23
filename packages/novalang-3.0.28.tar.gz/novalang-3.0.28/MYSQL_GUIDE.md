# 🗄️ Using NovaLang with MySQL & MySQL Workbench

## ✅ Yes! NovaLang Now Supports MySQL

NovaLang can work with **both SQLite and MySQL**. Here's how to use MySQL Workbench with NovaLang.

---

## 📋 Prerequisites

### 1. Install MySQL Server
Download from: https://dev.mysql.com/downloads/mysql/

### 2. Install MySQL Workbench
Download from: https://dev.mysql.com/downloads/workbench/

### 3. Install Python MySQL Connector
```bash
pip install mysql-connector-python
```

---

## ⚙️ Configuration Setup

### Step 1: Create Database in MySQL Workbench

Open MySQL Workbench and run:
```sql
CREATE DATABASE novalang_db;
```

### Step 2: Configure NovaLang

Edit your `novalang.config`:

```properties
# Server Configuration
server.port=8080
server.host=localhost

# MySQL Database Configuration
database.type=mysql
database.name=novalang_db
database.host=localhost
database.port=3306
database.username=root
database.password=yourpassword

# Application Settings
app.name=NovaLang Application
app.version=1.0.0
```

---

## 🚀 How It Works

### 1. Create Your Entities

**UserEntity.nova:**
```nova
@DatabaseEntity
@Table(name: "users")
class User {
    @PrimaryKey
    @Column(name: "id", type: "INTEGER")
    let id: number = 0
    
    @Column(name: "username", type: "TEXT")
    let username: string = ""
    
    @Column(name: "email", type: "TEXT")
    let email: string = ""
    
    @Column(name: "created_at", type: "TEXT")
    let created_at: string = ""
}
```

### 2. Create Application

**Application.nova:**
```nova
@NovaLangApplication
class Application {}

function main() {
    print("NovaLang with MySQL is running!")
}

main()
```

### 3. Run Your Application

```bash
python main.py Application.nova
```

**Output:**
```
✅ Loaded configuration from novalang.config
📋 Loading configuration from novalang.config
🔍 Scanning for entities...
📦 Connected to MySQL database: novalang_db@localhost
[OK] Created table: users
✅ Found 1 entities, created 1 tables

╔════════════════════════════════════════╗
║  🚀 NovaLang Application Starting...  ║
╚════════════════════════════════════════╝

NovaLang with MySQL is running!
```

### 4. View in MySQL Workbench

Open MySQL Workbench and run:
```sql
USE novalang_db;
SHOW TABLES;
DESCRIBE users;
```

You'll see your tables created automatically! 🎉

---

## 🔄 Switching Between SQLite and MySQL

### For SQLite (Default):
```properties
database.type=sqlite
database.name=novalang_app.db
```

### For MySQL:
```properties
database.type=mysql
database.name=novalang_db
database.host=localhost
database.port=3306
database.username=root
database.password=yourpassword
```

Just change `database.type` and restart your app!

---

## 📊 Column Type Mapping

| NovaLang Type | SQLite Type | MySQL Type |
|---------------|-------------|------------|
| `INTEGER` | INTEGER | INT |
| `TEXT` | TEXT | VARCHAR(255) |
| `REAL` | REAL | DECIMAL |
| `BLOB` | BLOB | BLOB |

*Note: Currently uses same type names for both databases. Future versions will have database-specific mappings.*

---

## 💡 MySQL Workbench Workflow

### 1. Design Phase
- Create database in MySQL Workbench
- Plan your schema (optional - NovaLang will create tables)

### 2. Development Phase
- Write `.nova` entity files
- Configure `novalang.config` with MySQL settings
- Run `python main.py Application.nova`
- Tables created automatically!

### 3. Testing Phase
- Use MySQL Workbench to:
  - View table structure
  - Insert test data
  - Run queries
  - Monitor performance

### 4. Production Phase
- Update `novalang.config` with production MySQL credentials
- Deploy your NovaLang application
- Manage database with MySQL Workbench

---

## 🔧 Configuration Examples

### Local Development
```properties
database.type=mysql
database.name=novalang_dev
database.host=localhost
database.port=3306
database.username=developer
database.password=dev123
```

### Production (Example)
```properties
database.type=mysql
database.name=novalang_prod
database.host=db.mycompany.com
database.port=3306
database.username=produser
database.password=secure_password_here
```

### Docker MySQL
```properties
database.type=mysql
database.name=novalang_app
database.host=mysql-container
database.port=3306
database.username=root
database.password=rootpassword
```

---

## ⚠️ Important Notes

### 1. Create Database First
NovaLang creates **tables** automatically, but you must create the **database** first:
```sql
CREATE DATABASE novalang_db;
```

### 2. Install MySQL Connector
```bash
pip install mysql-connector-python
```

### 3. Fallback Behavior
If MySQL connection fails, NovaLang automatically falls back to SQLite:
```
⚠️  MySQL connection failed: Access denied for user...
   Falling back to SQLite
📦 Connected to SQLite database: novalang_fallback.db
```

---

## 🎯 Quick Start with MySQL

```bash
# 1. Install MySQL connector
pip install mysql-connector-python

# 2. Create database in MySQL
mysql -u root -p
CREATE DATABASE novalang_db;
exit;

# 3. Copy MySQL config template
cp novalang.config.mysql novalang.config

# 4. Edit credentials in novalang.config
# (Update username and password)

# 5. Run your application
python main.py Application.nova

# 6. View tables in MySQL Workbench
# Connect to localhost:3306
# Open database: novalang_db
# See your auto-created tables!
```

---

## ✅ Supported Databases

| Database | Status | Install Command |
|----------|--------|----------------|
| SQLite | ✅ Built-in | None needed |
| MySQL | ✅ Supported | `pip install mysql-connector-python` |
| PostgreSQL | 🚧 Coming Soon | - |
| SQL Server | 🚧 Coming Soon | - |

---

## 📚 Summary

**Yes, NovaLang supports MySQL Workbench!**

✅ **What Works:**
- MySQL database connections
- Auto table creation from entities
- Configuration via `novalang.config`
- MySQL Workbench integration
- Easy switching between SQLite/MySQL

✅ **How to Use:**
1. Install `mysql-connector-python`
2. Create database in MySQL
3. Configure `novalang.config`
4. Run your NovaLang app
5. View tables in MySQL Workbench

**NovaLang handles all the table creation automatically!** 🎉

---

**Questions?** Check [GETTING_STARTED.md](GETTING_STARTED.md) for more details.
