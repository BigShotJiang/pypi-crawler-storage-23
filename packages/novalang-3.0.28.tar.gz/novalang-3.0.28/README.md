# NovaLang 🚀 - Programming Language with Spring Boot-Style API Templates

[![PyPI version](https://badge.fury.io/py/novalang.svg)](https://badge.fury.io/py/novalang)
[![Python Support](https://img.shields.io/pypi/pyversions/novalang.svg)](https://pypi.org/project/novalang/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://img.shields.io/pypi/dm/novalang.svg)](https://pypi.org/project/novalang/)

**NovaLang** is an experimental programming language with Spring Boot-style syntax and annotations. It focuses on rapid backend API development with familiar Java/Spring Boot patterns.

## 🎉 **NEW in v2.2.5: Clean API Templates**

- ✅ **Clean API Templates**: Minimal Spring Boot-style server foundation
- ✅ **Spring Boot-Style Annotations**: @Service, @RestController, @Entity support  
- ✅ **Simple Project Structure**: ApplicationConfig + HealthController base
- ✅ **IntelliJ Support**: IDE recognition for .nova files
- ✅ **CLI Tool**: Project generation and basic tooling

## 🌟 Current Features

### ✅ **What Actually Works**
- **Project Templates**: Generate Spring Boot-style API projects
- **CLI Tool**: Create, build, and run NovaLang projects
- **Annotation System**: Database and REST annotations (@Entity, @Table, @Column, @RestController)
- **SQL Schema Generation**: Auto-generate CREATE TABLE statements from annotations
- **Lexer**: Tokenize NovaLang source code
- **Basic Interpreter**: Execute simple NovaLang programs

### 🚧 **In Development**
- **Full Parser**: Complete AST generation (partial implementation)
- **Type System**: Static type checking and inference
- **Runtime**: Variable scoping, function execution, class instantiation
- **Database Connectivity**: Actual connection to databases (currently only generates SQL)
- **Multi-target Compilation**: Compile to Java, TypeScript, Python

### 📋 **Development Tools**
- **CLI Tool**: Project lifecycle management (`nova create`, `nova run`)
- **Lexer**: Full tokenization with 400+ token types
- **Annotation Processor**: Parse and process database/REST annotations
- **Template System**: Generate clean API project structures

## 🚀 Quick Start

### Installation

```bash
# Install NovaLang
pip install novalang
```

### Create Your First API Project

```bash
# Create a new API project with clean Spring Boot-style template
nova create my-backend --template api

# Navigate to project
cd my-backend

# Run the application
cd ..
python interpreter.py my-backend/src/main.nova
```

### Example NovaLang Code

```nova
// Clean Spring Boot-style API
@Configuration
class ApplicationConfig {
    function getDatabaseConfig() {
        return {
            host: "localhost",
            port: 3306,
            database: "my_db"
        }
    }
}

@RestController
class HealthController {
    @GetMapping("/health")
    function health() {
        return {
            status: "UP",
            timestamp: new Date()
        }
    }
}

// Database Entity Example
@DatabaseEntity
@Table(name: "users")
class User {
    @PrimaryKey
    @AutoIncrement
    @Column(name: "id", type: "BIGINT")
    let id: number = 0
    
    @Column(name: "name", type: "VARCHAR", length: 50)
    let name: string = ""
}
@Document(collection: "products")
class Product {
    @Id
    private id: String
    
    @Field("name")
    @Indexed
    private name: String
    
    @Field("tags")
    private tags: List<String>
}
```

### Graph Databases
```nova
@Neo4j
@Node("Person")
class Person {
    @Id
    private id: String
    
    @Property("name")
    private name: String
    
    @Relationship(type: "KNOWS", direction: "OUTGOING")
    private friends: List<Person>
}
```

### Time Series Databases
```nova
@InfluxDB
@Measurement("sensor_data")
class SensorReading {
    @Time
    private timestamp: Instant
    
    @Tag("sensor_id")
    private sensorId: String
    
    @Field("temperature")
    private temperature: Double
}
```

### Vector Databases (AI/ML)
```nova
```

### What Gets Generated

When you create an API project, NovaLang generates:
- **ApplicationConfig**: Configuration management class
- **HealthController**: Basic health check endpoints  
- **Main Application**: Spring Boot-style entry point
- **Project Structure**: src/, tests/, dist/ folders

**Note**: NovaLang currently generates SQL schemas but does **not** automatically create or connect to databases. You need to manually set up your database and execute the generated SQL.

## 🏗️ Architecture

NovaLang current architecture:

```
NovaLang
├── Lexer: Tokenization with 400+ token types
├── Parser: AST generation (partial implementation)  
├── Interpreter: Execute basic .nova programs
├── Annotation Processor: Parse @Entity, @Table, @Column annotations
├── SQL Generator: Create TABLE statements from annotations
└── CLI: Project creation and template generation
```

## 📊 How It Works

### 1. Write NovaLang Code with Annotations

```nova
@DatabaseEntity
@Table(name: "products")
class Product {
    @PrimaryKey
    @Column(name: "id", type: "BIGINT")
    let id: number = 0
    
    @Column(name: "name", type: "VARCHAR", length: 100)
    let name: string = ""
}
```

### 2. Run Through Interpreter

```bash
python interpreter.py your_file.nova
```

### 3. Get Generated SQL

```sql
CREATE TABLE products (
    id BIGINT PRIMARY KEY,
    name VARCHAR(100)
);
```

### 4. Manually Create Database

You must manually:
- Install database (MySQL, PostgreSQL, etc.)
- Create the database
- Execute the generated SQL statements
- **Parallel Processing**: Concurrent database operations
- **Memory Optimization**: Zero-copy operations where possible

## 🧪 Testing

```nova
@Test
class UserServiceTest {
    @Mock
    private userRepository: UserRepository
    
    @InjectMocks  
    private userService: UserService
    
    @Test
    public testCreateUser() {
        // Given
        let user = User(email: "test@example.com")
        
        // When
        let result = userService.createUser(user)
        
        // Then
        assert result.isSuccess()
        assert result.get().id != null
    }
}
```

## 📚 Documentation

- **[Language Reference](docs/language-reference.md)**: Complete language syntax
- **[Database Guide](docs/database-guide.md)**: Database integration examples  
- **[API Documentation](docs/api-reference.md)**: Complete API reference
- **[Examples](examples/)**: Real-world examples and tutorials

## 🤝 Contributing

Contributions welcome! NovaLang is an experimental project under active development. 

### Development Roadmap
- [ ] Complete parser implementation
- [ ] Full type system with type checking
- [ ] Actual database connectivity (currently only generates SQL)
- [ ] Multi-target compilation (Java, TypeScript, Python)
- [ ] Runtime with proper scoping and execution
- [ ] Comprehensive test suite
- [ ] REPL/interactive mode
- [ ] Package manager
- [ ] Standard library

## 📄 License

NovaLang is released under the [MIT License](LICENSE).

## 🎯 Project Status

NovaLang is an **experimental programming language** in early development:

- ✅ **Working**: Project templates, SQL generation, basic interpreter, CLI tool
- 🚧 **In Progress**: Full parser, type system, runtime execution
- 📋 **Planned**: Database connectivity, multi-target compilation, standard library

**Current Use Case**: Rapid API project scaffolding with Spring Boot-style patterns

---

**Made with ❤️ by [Martin Maboya](https://github.com/martinmaboya)**

**NovaLang - Experimental Spring Boot-Style Programming Language** 🚀
