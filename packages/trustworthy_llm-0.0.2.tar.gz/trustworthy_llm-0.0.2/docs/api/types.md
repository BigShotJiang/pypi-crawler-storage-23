::: tlm.inference.InferenceResult
    options:
      heading_level: 2

::: tlm.types.base.Eval
    options:
      heading_level: 2

::: tlm.config.presets.QualityPreset
    options:
      heading_level: 2

::: tlm.config.presets.ReasoningEffort
    options:
      heading_level: 2

::: tlm.types.base.SimilarityMeasure
    options:
      heading_level: 2
