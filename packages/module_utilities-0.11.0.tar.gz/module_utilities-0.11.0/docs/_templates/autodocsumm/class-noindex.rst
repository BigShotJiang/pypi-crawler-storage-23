{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}



.. autoclass:: {{ objname }}
   :autosummary:
   :autosummary-nomembers:
   :noindex:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __iadd__, __sub__, __isub__, __mul__, __imul__
