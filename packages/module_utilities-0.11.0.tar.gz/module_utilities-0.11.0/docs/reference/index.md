# API Reference

```{eval-rst}
.. currentmodule:: module_utilities

.. autosummary::
   :toctree: generated/
   :template: autodocsumm/module.rst

   cached
   docfiller
   docinherit
   attributedict
   typing

```
