This directory will hold the changelog entries managed by scriv
