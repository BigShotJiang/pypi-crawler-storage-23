# Project specific config files/metadata

This directory is the home for data related to the project that doesn't have a
clear home elsewhere (or at the root level).
