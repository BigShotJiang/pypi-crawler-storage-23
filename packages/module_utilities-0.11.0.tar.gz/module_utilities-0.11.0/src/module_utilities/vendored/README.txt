Vendored docscrape.py from https://github.com/numpy/numpydoc/blob/main/numpydoc/docscrape.py
