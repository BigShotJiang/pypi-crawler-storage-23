"""
Provider and HttpMethod enums for type-safe SDK usage.

Static enum of supported OAuth providers. Strings are also accepted
by the SDK for forward compatibility with new providers.

When adding a new provider to the backend, add it here too.
See .claude/commands/add-oauth.md for the full procedure.
"""

from enum import Enum


class Provider(str, Enum):
    """
    Supported OAuth provider identifiers.

    Use these for type safety and IDE autocomplete. The SDK also accepts
    plain strings for providers not yet in this enum.

    Provider enums can be used for filtering connections:
        ```python
        from alter_sdk import AlterVault, Provider

        vault = AlterVault(api_key="alter_key_...")
        connections = await vault.list_connections(provider_id=Provider.GOOGLE)
        ```
    """

    GOOGLE = "google"
    GITHUB = "github"
    SLACK = "slack"
    SENTRY = "sentry"

    def __str__(self) -> str:
        """Return the provider ID string value."""
        return self.value


class HttpMethod(str, Enum):
    """
    HTTP methods for type-safe method selection.

    Use these for IDE autocomplete and type safety. Plain strings
    are also accepted for forward compatibility.

    Example:
        ```python
        from alter_sdk import AlterVault, HttpMethod

        vault = AlterVault(api_key="alter_key_...")

        resp = await vault.request(
            "CONNECTION_ID", HttpMethod.GET,
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
        )
        ```
    """

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"

    def __str__(self) -> str:
        """Return the HTTP method string value."""
        return self.value
