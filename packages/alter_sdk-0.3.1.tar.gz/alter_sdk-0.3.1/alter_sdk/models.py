"""
Pydantic models for Alter SDK.

These models provide type-safe data structures with validation.
"""

from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ActorType(StrEnum):
    """Actor types for tracking SDK callers."""

    BACKEND_SERVICE = "backend_service"
    AI_AGENT = "ai_agent"
    MCP_SERVER = "mcp_server"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Module-private token storage for TokenResponse.
#
# NOTE: TokenResponse is a PUBLIC API model for type safety and
# serialization. It is NOT used in the active token flow — the live
# __get_token() path in client.py returns a raw (auth_header, connection_id)
# tuple, so access tokens never exist as a named attribute or object field
# in the production path.
#
# This _token_store mechanism exists to protect TokenResponse instances
# that ARE constructed (e.g., by consumers using the model directly).
# It prevents .access_token from being readable as an attribute.
#
# Key: id(instance)  Value: access token string
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_token_store: dict[int, str] = {}


def _extract_access_token(token: "TokenResponse") -> str:
    """
    Retrieve the access token for internal SDK use.

    This is NOT part of the public API. Returns the raw access token
    from module-private storage. Only usable from within the SDK package.
    """
    value = _token_store.get(id(token))
    if value is None:
        raise RuntimeError(
            "Token data unavailable — TokenResponse may have been garbage collected",
        )
    return value


class TokenResponse(BaseModel):
    """
    OAuth token response from Alter Vault.

    This represents an access token retrieved from the backend.

    Security:
        - frozen=True prevents mutation after creation
        - access_token is NOT stored as a readable attribute — it lives in
          module-private _token_store and is only accessible via _extract_access_token()
        - toJSON/model_dump exclude access token from serialization

    Note: The active token flow in client.py does NOT construct TokenResponse.
    __get_token() returns a raw (auth_header, connection_id) tuple instead.
    This model is retained as a public API type for consumers.
    """

    model_config = ConfigDict(frozen=True)

    token_type: str = Field(default="Bearer", description="Token type (usually Bearer)")
    expires_in: int | None = Field(None, description="Seconds until token expires")
    expires_at: datetime | None = Field(None, description="Absolute expiration time")
    scopes: list[str] = Field(default_factory=list, description="OAuth scopes granted")
    connection_id: UUID = Field(
        ...,
        description="Connection ID that provided this token",
    )

    def __init__(self, *, access_token: str, **kwargs: Any) -> None:
        """
        Create a TokenResponse.

        SECURITY: access_token is accepted as a constructor parameter but NOT
        stored as a Pydantic field. It is moved to module-private _token_store
        immediately and is only retrievable via _extract_access_token().
        """
        super().__init__(**kwargs)
        _token_store[id(self)] = access_token

    def __del__(self) -> None:
        """Clean up module-private token storage on garbage collection."""
        _token_store.pop(id(self), None)

    @field_validator("expires_at", mode="before")
    @classmethod
    def parse_expires_at(cls, v: Any) -> datetime | None:
        """Parse expires_at from ISO string if needed."""
        if v is None:
            return None
        if isinstance(v, datetime):
            return v
        if isinstance(v, str):
            # Parse ISO format
            dt = datetime.fromisoformat(v.replace("Z", "+00:00"))
            # Ensure timezone aware
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt
        return v  # type: ignore[return-value]

    def is_expired(self, buffer_seconds: int = 0) -> bool:
        """
        Check if token is expired.

        Args:
            buffer_seconds: Consider token expired N seconds before actual expiry.
                           Useful for preventing race conditions.

        Returns:
            True if token is expired or will expire within buffer_seconds.
        """
        if self.expires_at is None:
            # No expiration time means token doesn't expire
            return False

        now = datetime.now(UTC)
        # Make expires_at timezone-aware if needed
        expires_at = self.expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=UTC)

        # Check if expired with buffer
        return expires_at <= now + timedelta(seconds=buffer_seconds)

    def needs_refresh(self, buffer_seconds: int = 300) -> bool:
        """
        Check if token should be refreshed soon.

        Args:
            buffer_seconds: Consider token needing refresh N seconds before expiry.
                           Default 5 minutes (300 seconds).

        Returns:
            True if token will expire within buffer_seconds.
        """
        return self.is_expired(buffer_seconds=buffer_seconds)


class ConnectionInfo(BaseModel):
    """
    OAuth connection info from Alter Vault.

    Represents a connected OAuth service (e.g., Google, GitHub).
    Returned by list_connections(). Contains metadata only — no tokens.
    """

    model_config = ConfigDict(frozen=True)

    id: str
    provider_id: str
    scopes: list[str] = Field(default_factory=list)
    account_identifier: str | None = None
    account_display_name: str | None = None
    status: str
    expires_at: str | None = None
    created_at: str
    last_used_at: str | None = None


class ConnectSession(BaseModel):
    """
    Connect session for initiating OAuth flows.

    Returned by create_connect_session(). Contains a URL the user
    opens in their browser to authorize access.
    """

    model_config = ConfigDict(frozen=True)

    session_token: str
    connect_url: str
    expires_in: int
    expires_at: str


class ConnectionListResult(BaseModel):
    """
    Paginated list of connections.

    Returned by list_connections(). Contains connection array plus pagination metadata.
    """

    model_config = ConfigDict(frozen=True)

    connections: list[ConnectionInfo]
    total: int
    limit: int
    offset: int
    has_more: bool


class APICallAuditLog(BaseModel):
    """
    Audit log entry for an API call to a provider.

    This is sent to the backend audit endpoint.
    """

    connection_id: UUID
    provider_id: str
    method: str  # GET, POST, PUT, DELETE, etc.
    url: str
    request_headers: dict[str, str] | None = None
    request_body: Any | None = None
    response_status: int
    response_headers: dict[str, str] | None = None
    response_body: Any | None = None
    latency_ms: int
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        exclude=True,
    )
    reason: str | None = None
    run_id: str | None = None
    thread_id: str | None = None
    tool_call_id: str | None = None

    def sanitize(self) -> dict[str, Any]:
        """
        Sanitize sensitive data before sending.

        Removes Authorization headers, cookies, etc.
        """
        sensitive_headers = {
            "authorization",
            "cookie",
            "set-cookie",
            "x-api-key",
            "x-auth-token",
        }

        # Use mode='json' to ensure UUIDs and datetimes are serialized
        sanitized = self.model_dump(mode="json")

        # Sanitize request headers
        if sanitized.get("request_headers"):
            sanitized["request_headers"] = {
                k: v
                for k, v in sanitized["request_headers"].items()
                if k.lower() not in sensitive_headers
            }

        # Sanitize response headers
        if sanitized.get("response_headers"):
            sanitized["response_headers"] = {
                k: v
                for k, v in sanitized["response_headers"].items()
                if k.lower() not in sensitive_headers
            }

        return sanitized
