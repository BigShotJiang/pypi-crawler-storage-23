"""
Main Alter Vault SDK client.

Provides the AlterVault class for OAuth token management with
zero token exposure — tokens are retrieved and injected automatically,
never returned to the caller.
"""

import asyncio
import contextlib
import hashlib
import hmac as hmac_mod
import json as json_mod
import logging
import os
import re
import sys
import time
from pathlib import Path
from typing import Any
from urllib.parse import quote
from uuid import UUID, uuid4

import httpx

from alter_sdk.exceptions import (
    AlterSDKError,
    ConnectionNotFoundError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    TimeoutError,
    TokenExpiredError,
    TokenRetrievalError,
)
from alter_sdk.models import (
    ActorType,
    APICallAuditLog,
    ConnectionInfo,
    ConnectionListResult,
    ConnectSession,
)
from alter_sdk.providers.enums import HttpMethod

logger = logging.getLogger(__name__)

# SDK version — single source of truth is alter_sdk.__version__
# Imported lazily to avoid circular import; set in _sdk_user_agent().
_SDK_USER_AGENT: str | None = None


def _sdk_user_agent() -> str:
    """Return the SDK User-Agent string, cached after first call."""
    global _SDK_USER_AGENT  # noqa: PLW0603
    if _SDK_USER_AGENT is None:
        from alter_sdk import __version__

        _SDK_USER_AGENT = f"alter-sdk-python/{__version__}"
    return _SDK_USER_AGENT


# HTTP status codes as constants
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_BAD_GATEWAY = 502
HTTP_INTERNAL_SERVER_ERROR = 500
HTTP_SERVICE_UNAVAILABLE = 503

# Request/Response size limits
MAX_BODY_SIZE_BYTES = 10000  # 10KB max for audit log bodies
HTTP_CLIENT_ERROR_START = 400  # HTTP status codes >= 400 are errors

# Actor header validation
MAX_ACTOR_STRING_LENGTH = 255  # Max length for actor string parameters
MAX_TRACKING_ID_LENGTH = 255  # Max length for tracking IDs (thread_id, tool_call_id)
_SAFE_HEADER_PATTERN = re.compile(r"^[\x20-\x7E]+$")  # Printable ASCII only

# URL scheme validation
_ALLOWED_URL_SCHEMES = ("https://", "http://")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SECURITY LAYER 4: Module-private mutable state storage.
#
# HTTP clients, cached actor ID, closed flag, and audit tasks are stored
# in this module-level dict instead of on AlterVault instances. This
# prevents rogue agents from using object.__setattr__() to tamper with
# HTTP clients or other critical mutable state.
#
# Key: id(instance)  Value: dict with alter_client, provider_client, etc.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_THIS_FILE = str(Path(__file__).resolve())
# NOTE: _instance_state is importable by any code that does
# `from alter_sdk.client import _instance_state`. Full mitigation
# (closure-based API key injection) is too invasive for this pass.
# The __getattribute__ guard + leading-underscore convention is the
# accepted bar; the primary secrets (HTTP clients) are keyed by
# id(instance) which is ephemeral.
_instance_state: dict[int, dict[str, Any]] = {}


class AlterVault:
    """
    Main SDK class for Alter Vault OAuth token management.

    This class handles:
    - Executing API requests to any OAuth provider with automatic token injection
    - Audit logging of API calls
    - Actor tracking for AI agents and MCP servers

    Tokens are retrieved and injected automatically — never exposed to callers.

    Example:
        ```python
        from alter_sdk import AlterVault, Provider, HttpMethod

        vault = AlterVault(api_key="alter_key_...")

        # Make API request (token injected automatically)
        response = await vault.request(
            "connection-uuid-here", HttpMethod.GET,
            "https://www.googleapis.com/calendar/v3/calendars/primary/events",
        )
        events = response.json()

        # Clean up
        await vault.close()
        ```
    """

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 1: Prevent subclassing
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __init_subclass__(cls, **kwargs: Any) -> None:
        raise TypeError(
            "AlterVault cannot be subclassed. This restriction prevents security bypasses.",
        )

    # Only immutable configuration on the instance.
    # HTTP clients and mutable state live in _instance_state (module-private).
    __slots__ = (
        "base_url",
        "_actor_type",
        "_actor_identifier",
        "_actor_name",
        "_actor_version",
        "_client_type",
        "_framework",
        "_initialized",
    )

    def __init__(
        self,
        api_key: str,
        timeout: float = 30.0,
        # Actor tracking (required - identifies the SDK caller)
        actor_type: ActorType | str = ...,  # type: ignore[assignment]
        actor_identifier: str = ...,  # type: ignore[assignment]
        actor_name: str | None = None,
        actor_version: str | None = None,
        client_type: str | None = None,
        framework: str | None = None,
    ) -> None:
        """
        Initialize Alter Vault client.

        Args:
            api_key: Alter Vault API key (starts with "alter_key_")
            timeout: HTTP request timeout in seconds
            actor_type: Actor type (use ActorType enum: AI_AGENT, MCP_SERVER, BACKEND_SERVICE)
            actor_identifier: Unique identifier for the actor (e.g., "email-assistant-v2")
            actor_name: Human-readable name for the actor (defaults to actor_identifier)
            actor_version: Actor version string (e.g., "1.0.0")
            client_type: MCP client type (e.g., "cursor", "claude-desktop")
            framework: AI framework (e.g., "langchain", "langgraph", "crewai")

        Raises:
            AlterSDKError: If api_key is invalid or actor_type/actor_identifier missing
        """
        # Validate inputs
        self._validate_init_params(api_key, actor_type, actor_identifier)
        # Validate actor string lengths and characters
        for _name, _val in [
            ("actor_identifier", actor_identifier),
            ("actor_name", actor_name),
            ("actor_version", actor_version),
            ("client_type", client_type),
            ("framework", framework),
        ]:
            self._validate_actor_string(_val, _name)

        # SECURITY LAYER 3: API key string is NOT stored as instance attribute.
        # It is used to build HTTP client headers and stored as bytes in
        # module-private _instance_state for HMAC signing (not on self).
        self.base_url = os.environ.get(
            "ALTER_BASE_URL",
            "https://backend.alterai.dev",
        ).rstrip("/")

        # Actor tracking configuration (immutable on instance)
        # Normalize actor_type to string for header use (handles both ActorType enum and str)
        self._actor_type = str(actor_type)
        self._actor_identifier = actor_identifier
        self._actor_name = actor_name
        self._actor_version = actor_version
        self._client_type = client_type
        self._framework = framework

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # HTTP CLIENT ARCHITECTURE - TWO SEPARATE CLIENTS FOR SECURITY
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        #
        # We maintain TWO separate HTTP clients to prevent credential leakage:
        #
        # alter_client  → Alter backend (has x-api-key + actor headers)
        # provider_client → External APIs (NO secrets, Bearer token per-request)
        #
        # SECURITY LAYER 4: Clients stored in module-private _instance_state,
        # NOT on the instance. This prevents object.__setattr__() attacks.

        # Shared connection pool settings for performance
        try:
            import h2  # type: ignore  # noqa: F401

            _http2_enabled = True
        except Exception:
            _http2_enabled = False

        _shared_limits = httpx.Limits(
            max_keepalive_connections=20,
            max_connections=100,
            keepalive_expiry=30.0,
        )

        user_agent = _sdk_user_agent()

        # CLIENT 1: Alter Backend Client
        # Auth: x-api-key + X-Alter-* actor headers
        # Target: Alter Vault backend only
        # SECURITY LAYER 3: api_key used here then discarded (not stored on self)
        alter_headers = self.__build_alter_client_headers(api_key)

        alter_client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=alter_headers,
            timeout=timeout,
            limits=_shared_limits,
            http2=_http2_enabled,
        )

        # CLIENT 2: Provider API Client
        # Auth: OAuth Bearer token (added per-request)
        # Target: External APIs (Google, Stripe, GitHub, etc.)
        # SECURITY: NO x-api-key header!
        try:
            provider_client = httpx.AsyncClient(
                headers={
                    "User-Agent": user_agent,
                },
                timeout=timeout,
                limits=_shared_limits,
                http2=_http2_enabled,
            )
        except Exception:
            # Best-effort cleanup if provider client creation fails.
            # If an event loop is running, schedule async cleanup.
            # Otherwise, __del__ will handle cleanup when GC runs.
            with contextlib.suppress(Exception):
                loop = asyncio.get_running_loop()
                _task = loop.create_task(alter_client.aclose())  # noqa: RUF006
            raise

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # SECURITY LAYER 4: Store HTTP clients and mutable state in module-private
        # dict, NOT on instance. This prevents rogue agents from using
        # object.__setattr__() to replace HTTP clients or tamper with state.
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        _instance_state[id(self)] = {
            "alter_client": alter_client,
            "provider_client": provider_client,
            "cached_actor_id": None,
            "closed": False,
            "audit_tasks": set(),
            # HMAC signing: derive a purpose-specific signing key from the API key
            # using AWS SigV4 pattern: HMAC-SHA256(api_key, "alter-signing-v1").
            # This provides cryptographic separation between authentication and signing.
            "hmac_key": hmac_mod.new(
                api_key.encode("utf-8"),
                b"alter-signing-v1",
                hashlib.sha256,
            ).digest(),
        }

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # SECURITY LAYER 2: Freeze instance — must be LAST in __init__
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        self._initialized = True

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 5: Attribute access guard for name-mangled methods.
    #
    # Python name-mangling transforms self.__method() to
    # self._AlterVault__method() at compile time. External code can bypass
    # this by calling vault._AlterVault__method() directly.
    #
    # This __getattribute__ guard intercepts such accesses and only allows
    # them from within this module (same file). External callers get
    # AttributeError.
    #
    # Bypass vectors (accepted risk):
    # - object.__getattribute__(vault, name) still works
    # - Python's compile(code, _THIS_FILE, "exec") can forge co_filename
    # Both require deliberate effort and raise the bar significantly.
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __getattribute__(self, name: str) -> Any:
        if name.startswith("_AlterVault__"):
            frame = sys._getframe(1)  # noqa: SLF001
            caller_file = str(Path(frame.f_code.co_filename).resolve())
            if caller_file != _THIS_FILE:
                raise AttributeError(
                    f"Access to internal attribute '{name}' is restricted. "
                    "Use request() for API calls.",
                )
        return super().__getattribute__(name)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SECURITY LAYER 2: Prevent attribute mutation after init
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_initialized", False):
            raise AttributeError(
                f"AlterVault instances are immutable: cannot set '{name}'",
            )
        super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        raise AttributeError(
            f"AlterVault instances are immutable: cannot delete '{name}'",
        )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Module-private state accessor (name-mangled + __getattribute__ guarded)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    @property
    def __state(self) -> dict[str, Any]:
        """Access module-private mutable state for this instance."""
        state = _instance_state.get(id(self))
        if state is None:
            raise AlterSDKError(
                "SDK instance has been closed or corrupted. Create a new AlterVault instance.",
            )
        return state

    def __del__(self) -> None:
        """Clean up module-private state and HTTP clients on garbage collection."""
        state = _instance_state.pop(id(self), None)
        if state and not state.get("closed"):
            # Best-effort: schedule async client cleanup if an event loop is running.
            # If no loop is running (e.g., at interpreter shutdown), clients are
            # abandoned — their underlying connections will be closed by the OS.
            with contextlib.suppress(Exception):
                loop = asyncio.get_running_loop()
                _t1 = loop.create_task(state["alter_client"].aclose())  # noqa: RUF006
                _t2 = loop.create_task(state["provider_client"].aclose())  # noqa: RUF006

    @staticmethod
    def _validate_actor_string(
        value: str | None,
        name: str,
        max_length: int = MAX_ACTOR_STRING_LENGTH,
    ) -> None:
        """Validate an actor string parameter for length and safe characters."""
        if value is None:
            return
        if len(value) > max_length:
            raise AlterSDKError(
                f"{name} exceeds max length ({max_length}): {len(value)}",
            )
        if not _SAFE_HEADER_PATTERN.match(value):
            raise AlterSDKError(
                f"{name} contains invalid characters (only printable ASCII allowed)",
            )

    @staticmethod
    def _validate_init_params(
        api_key: str,
        actor_type: ActorType | str,
        actor_identifier: str,
    ) -> None:
        """Validate constructor parameters. Raises AlterSDKError on invalid input."""
        if not api_key:
            raise AlterSDKError("api_key is required")
        if not api_key.startswith("alter_key_"):
            raise AlterSDKError("api_key must start with 'alter_key_'")

        # actor_type is required
        if actor_type is ... or not actor_type:
            raise AlterSDKError(
                "actor_type is required (use ActorType.AI_AGENT, "
                "ActorType.MCP_SERVER, or ActorType.BACKEND_SERVICE)",
            )
        # Validate against ActorType enum values
        valid_values = {member.value for member in ActorType}
        actor_type_str = str(actor_type)
        if actor_type_str not in valid_values:
            raise AlterSDKError(
                f"actor_type must be one of {sorted(valid_values)}, got '{actor_type_str}'",
            )

        # actor_identifier is required
        if actor_identifier is ... or not actor_identifier:  # type: ignore[comparison-overlap]
            raise AlterSDKError("actor_identifier is required")

    def __build_alter_client_headers(self, api_key: str) -> dict[str, str]:
        """
        Build default headers for the Alter backend HTTP client.

        Includes x-api-key for authentication and X-Alter-* headers for
        actor tracking (if configured). These headers are only sent to
        the Alter backend, never to external providers.

        SECURITY: api_key is passed as parameter, NOT read from self.
        """
        headers: dict[str, str] = {
            "x-api-key": api_key,
            "User-Agent": _sdk_user_agent(),
        }

        # Actor tracking headers
        _actor_headers = {
            "X-Alter-Actor-Type": str(self._actor_type),
            "X-Alter-Actor-Identifier": self._actor_identifier,
            "X-Alter-Actor-Name": self._actor_name,
            "X-Alter-Actor-Version": self._actor_version,
            "X-Alter-Client-Type": self._client_type,
            "X-Alter-Framework": self._framework,
        }
        headers.update({k: v for k, v in _actor_headers.items() if v})

        return headers

    def __compute_hmac_headers(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
    ) -> dict[str, str]:
        """
        Compute HMAC-SHA256 signature headers for an Alter backend request.

        String-to-sign format: METHOD\\nPATH_WITH_SORTED_QUERY\\nTIMESTAMP\\nCONTENT_HASH

        The path should include sorted query parameters if present (e.g. "/sdk/endpoint?a=1&b=2").
        Currently all SDK→backend calls are POSTs without query params, so the path is clean.

        Returns dict with X-Alter-Timestamp, X-Alter-Content-SHA256,
        and X-Alter-Signature headers.
        """
        state = self.__state
        hmac_key: bytes = state["hmac_key"]

        timestamp = str(int(time.time()))
        content_hash = hashlib.sha256(body or b"").hexdigest()
        string_to_sign = f"{method.upper()}\n{path}\n{timestamp}\n{content_hash}"

        signature = hmac_mod.new(
            hmac_key,
            string_to_sign.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

        return {
            "X-Alter-Timestamp": timestamp,
            "X-Alter-Content-SHA256": content_hash,
            "X-Alter-Signature": signature,
        }

    def __get_actor_request_headers(
        self,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> dict[str, str]:
        """
        Build per-request actor headers for instance tracking.

        These headers supplement the static actor headers set on alter_client.
        They include the cached actor_id (for fast path) and instance-specific
        tracking fields (run_id, thread_id, tool_call_id) which change per request.
        """
        headers: dict[str, str] = {}

        # Include cached actor_id for fast path (skip DB registration)
        state = self.__state
        cached_actor_id = state["cached_actor_id"]
        if cached_actor_id:
            headers["X-Alter-Actor-ID"] = cached_actor_id

        # Instance tracking fields (per-request, not per-actor)
        if run_id:
            try:
                UUID(run_id)
                headers["X-Alter-Run-ID"] = run_id
            except ValueError:
                logger.warning("Invalid run_id (must be UUID), skipping: %s", run_id)
        if thread_id:
            if len(thread_id) <= MAX_TRACKING_ID_LENGTH and _SAFE_HEADER_PATTERN.match(thread_id):
                headers["X-Alter-Thread-ID"] = thread_id
            else:
                logger.warning("Invalid thread_id (too long or invalid chars), skipping")
        if tool_call_id:
            if len(tool_call_id) <= MAX_TRACKING_ID_LENGTH and _SAFE_HEADER_PATTERN.match(
                tool_call_id,
            ):
                headers["X-Alter-Tool-Call-ID"] = tool_call_id
            else:
                logger.warning("Invalid tool_call_id (too long or invalid chars), skipping")

        return headers

    def __cache_actor_id_from_response(self, response: httpx.Response) -> None:
        """
        Cache actor_id from response header for subsequent requests.

        The backend returns X-Alter-Actor-ID after registering the actor.
        SDK caches this to include in future requests, allowing the backend
        to skip database lookups (fast path).
        """
        actor_id = response.headers.get("X-Alter-Actor-ID")
        state = self.__state
        if actor_id and not state["cached_actor_id"]:
            try:
                UUID(actor_id)
            except ValueError:
                logger.warning(
                    "Invalid actor_id in response header (not a UUID), ignoring: %s",
                    actor_id,
                )
                return
            state["cached_actor_id"] = actor_id
            logger.debug("Cached actor_id from backend: %s", actor_id)
        elif actor_id and state["cached_actor_id"] and actor_id != state["cached_actor_id"]:
            logger.warning(
                "Backend returned different actor_id (%s) than cached (%s), ignoring",
                actor_id,
                state["cached_actor_id"],
            )

    @staticmethod
    def _safe_parse_json(response: httpx.Response) -> dict[str, Any]:
        """Parse JSON from response, returning empty dict on failure."""
        try:
            return response.json()  # type: ignore[no-any-return]
        except Exception:
            return {"message": response.text[:500] if response.text else "Unknown error"}

    def _raise_policy_violation(self, error_data: dict[str, Any]) -> None:
        """Raise PolicyViolationError from error data."""
        raise PolicyViolationError(
            message=error_data.get("message", "Access denied by policy"),
            policy_error=error_data.get("error"),
            details=error_data.get("details", {}),
        )

    def _raise_connection_not_found(self, error_data: dict[str, Any]) -> None:
        """Raise ConnectionNotFoundError from error data."""
        raise ConnectionNotFoundError(
            message=error_data.get(
                "message",
                "OAuth connection not found for the given connection_id",
            ),
            details=error_data,
        )

    def _raise_token_expired(self, error_data: dict[str, Any]) -> None:
        """Raise TokenExpiredError from error data."""
        raise TokenExpiredError(
            message=error_data.get(
                "message",
                "Token expired and refresh failed",
            ),
            connection_id=error_data.get("connection_id"),
            details=error_data,
        )

    def _handle_error_response(self, response: httpx.Response) -> None:
        """
        Handle HTTP error responses from backend.

        Raises appropriate exceptions based on status code.
        Uses _safe_parse_json to avoid crashes on non-JSON responses.
        """
        if response.status_code == HTTP_FORBIDDEN:
            error_data = self._safe_parse_json(response)
            self._raise_policy_violation(error_data)

        if response.status_code == HTTP_NOT_FOUND:
            error_data = self._safe_parse_json(response)
            self._raise_connection_not_found(error_data)

        if response.status_code in (HTTP_BAD_REQUEST, HTTP_BAD_GATEWAY):
            error_data = self._safe_parse_json(response)
            if "token_expired" in str(error_data).lower():
                self._raise_token_expired(error_data)
            raise TokenRetrievalError(
                message=error_data.get("message", f"Backend error {response.status_code}"),
                details=error_data,
            )

        if response.status_code == HTTP_UNAUTHORIZED:
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get("message", "Unauthorized — check your API key"),
                details=error_data,
            )

        if response.status_code in (HTTP_INTERNAL_SERVER_ERROR, HTTP_SERVICE_UNAVAILABLE):
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get(
                    "message",
                    f"Backend unavailable (HTTP {response.status_code})",
                ),
                details=error_data,
            )

        # Catch-all for any other error status codes
        if response.status_code >= HTTP_CLIENT_ERROR_START:
            error_data = self._safe_parse_json(response)
            raise TokenRetrievalError(
                message=error_data.get(
                    "message",
                    f"Unexpected backend error (HTTP {response.status_code})",
                ),
                details=error_data,
            )

    # INTERNAL — name-mangled, protected by __getattribute__ guard.
    # Returns (header_name, header_value, connection_id, provider_id) tuple;
    # token exists only as a transient local variable, never as a named attribute.
    async def __get_token(
        self,
        connection_id: str,
        reason: str | None = None,
        request_metadata: dict[str, str] | None = None,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> tuple[str, str, UUID, str]:
        actor_headers = self.__get_actor_request_headers(
            run_id=run_id,
            thread_id=thread_id,
            tool_call_id=tool_call_id,
        )

        state = self.__state
        alter_client = state["alter_client"]

        sdk_path = "/sdk/token"
        request_body = {
            "connection_id": connection_id,
            "reason": reason,
            "request": request_metadata,
        }
        # Serialize once with compact separators to ensure the bytes we sign
        # match exactly what httpx sends (httpx uses compact separators internally).
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            ConnectionNotFoundError,
            TokenExpiredError,
            TokenRetrievalError,
        ):
            raise

        except Exception as e:
            raise TokenRetrievalError(
                message=f"Failed to retrieve token: {e}",
                details={"connection_id": connection_id, "error": str(e)},
            ) from e
        else:
            token_data = response.json()
            # SECURITY: Extract only what's needed. Token exists only as local variable.
            # No TokenResponse object is created — no .access_token attribute to discover.
            access_token = token_data["access_token"]
            resp_connection_id = UUID(str(token_data["connection_id"]))
            resp_provider_id = token_data.get("provider_id", "")

            # Dynamic injection metadata — supports API keys, bot tokens, etc.
            injection_header = token_data.get("injection_header", "Authorization")
            injection_format = token_data.get("injection_format", "Bearer {token}")

            # Validate backend-supplied header name (defense-in-depth against CRLF)
            # Must start with a letter, then alphanumeric + hyphens (matches Node SDK)
            if not injection_header or not re.match(r"^[A-Za-z][A-Za-z0-9-]*$", injection_header):
                raise TokenRetrievalError(
                    message="Backend returned an invalid injection_header",
                    details={"connection_id": str(connection_id)},
                )

            # Validate injection_format for CRLF (defense-in-depth)
            if any(c in injection_format for c in ("\r", "\n", "\x00")):
                raise TokenRetrievalError(
                    message="Backend returned invalid injection_format "
                    "(contains control characters)",
                    details={"connection_id": str(connection_id)},
                )

            # Replace only first occurrence to prevent double token leakage
            header_value = injection_format.replace("{token}", access_token, 1)

            logger.debug("Retrieved token for connection %s", connection_id)
            return injection_header, header_value, resp_connection_id, resp_provider_id

    async def __log_api_call(
        self,
        connection_id: UUID,
        provider_id: str,
        method: str,
        url: str,
        request_headers: dict[str, str] | None = None,
        request_body: Any | None = None,
        response_status: int = 0,
        response_headers: dict[str, str] | None = None,
        response_body: Any | None = None,
        latency_ms: int = 0,
        reason: str | None = None,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        """
        Log an API call to the backend audit endpoint (INTERNAL).

        This method NEVER raises exceptions to avoid crashing the application
        if audit logging fails.
        """
        try:
            audit_log = APICallAuditLog(
                connection_id=connection_id,
                provider_id=provider_id,
                method=method,
                url=url,
                request_headers=request_headers,
                request_body=request_body,
                response_status=response_status,
                response_headers=response_headers,
                response_body=response_body,
                latency_ms=latency_ms,
                reason=reason,
                run_id=run_id,
                thread_id=thread_id,
                tool_call_id=tool_call_id,
            )

            sanitized = audit_log.sanitize()

            actor_headers = self.__get_actor_request_headers(run_id=run_id)
            sdk_path = "/sdk/oauth/audit/api-call"
            body_bytes = json_mod.dumps(sanitized, separators=(",", ":")).encode("utf-8")
            hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
            merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

            state = self.__state
            alter_client = state["alter_client"]
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            response.raise_for_status()

            logger.debug("Logged API call to %s", url)

        except Exception as e:
            # NEVER raise - log warning and continue
            logger.warning("Failed to log API call (non-fatal): %s", e)

    @staticmethod
    def _safe_response_body(response: httpx.Response, max_bytes: int = MAX_BODY_SIZE_BYTES) -> str:
        """Extract response body for audit logging without decoding large/binary payloads."""
        content_length = len(response.content)
        if content_length == 0:
            return ""
        # Skip decode for large responses (e.g. binary file downloads)
        if content_length > max_bytes:
            return f"<response too large: {content_length} bytes>"
        try:
            text = response.text
        except Exception:
            return f"<binary response: {content_length} bytes>"
        if len(text) > max_bytes:
            return text[:max_bytes] + "..."
        return text

    def __schedule_audit_log(
        self,
        **kwargs: Any,
    ) -> None:
        """Schedule audit logging as a background task (true fire-and-forget)."""
        try:
            task = asyncio.create_task(self.__log_api_call(**kwargs))
            state = self.__state
            state["audit_tasks"].add(task)
            task.add_done_callback(state["audit_tasks"].discard)
        except Exception:
            # Audit logging is non-fatal — never crash the SDK for telemetry failures.
            pass

    async def request(
        self,
        connection_id: str,
        method: HttpMethod | str,
        url: str,
        *,
        json: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        query_params: dict[str, Any] | None = None,
        path_params: dict[str, str] | None = None,
        reason: str | None = None,
        run_id: str | None = None,
        thread_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> httpx.Response:
        """
        Execute an HTTP request to a provider API with automatic token injection.

        This is the single entry point for all provider API calls. The SDK:
        1. Fetches an OAuth token from Alter backend (never exposed)
        2. Injects the token as a Bearer header
        3. Calls the provider API
        4. Logs the call for audit (fire-and-forget, always enabled)
        5. Returns the raw response
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        if run_id is None:
            run_id = str(uuid4())

        method_str = method.value if isinstance(method, HttpMethod) else str(method).upper()

        # Validate URL scheme to prevent SSRF (token sent to arbitrary destinations)
        url_lower = url.lower()
        if not any(url_lower.startswith(scheme) for scheme in _ALLOWED_URL_SCHEMES):
            raise AlterSDKError(
                f"URL must start with https:// or http://, got: {url[:50]}",
            )

        # Apply path_params to URL template (URL-encode values for safety)
        if path_params:
            encoded_params = {k: quote(str(v), safe="") for k, v in path_params.items()}
            try:
                url = url.format(**encoded_params)
            except (KeyError, ValueError) as e:
                raise AlterSDKError(
                    f"Invalid URL template or missing path_params: {e}. "
                    f"URL: {url}, path_params: {path_params}",
                ) from e

        # Get token internally — returns (header_name, header_value, connection_id, provider_id).
        # Token is NEVER exposed as a named attribute or object field.
        header_name, header_value, resp_connection_id, resp_provider_id = await self.__get_token(
            connection_id=connection_id,
            reason=reason,
            request_metadata={"method": method_str, "url": url},
            run_id=run_id,
            thread_id=thread_id,
            tool_call_id=tool_call_id,
        )

        # Warn if extra_headers contains the injection header (will be overwritten)
        header_name_lower = header_name.lower()
        if extra_headers and any(k.lower() == header_name_lower for k in extra_headers):
            logger.warning(
                "extra_headers contains '%s' which will be overwritten "
                "with the auto-injected credential",
                header_name,
            )

        # Build headers with dynamic credential injection
        request_headers = extra_headers.copy() if extra_headers else {}
        request_headers[header_name] = header_value
        request_headers.setdefault("User-Agent", _sdk_user_agent())

        # Execute request using provider client (NO x-api-key!)
        provider_client = state["provider_client"]
        start_time = time.time()
        try:
            response = await provider_client.request(
                method=method_str,
                url=url,
                json=json,
                headers=request_headers,
                params=query_params,
            )

            latency_ms = int((time.time() - start_time) * 1000)

            # Strip injected credential header before passing to audit log
            audit_headers = {
                k: v for k, v in request_headers.items() if k.lower() != header_name.lower()
            }

            # Schedule audit log as fire-and-forget background task
            self.__schedule_audit_log(
                connection_id=resp_connection_id,
                provider_id=resp_provider_id,
                method=method_str,
                url=url,
                request_headers=audit_headers,
                request_body=json,
                response_status=response.status_code,
                response_headers=dict(response.headers),
                response_body=self._safe_response_body(response),
                latency_ms=latency_ms,
                reason=reason,
                run_id=run_id,
                thread_id=thread_id,
                tool_call_id=tool_call_id,
            )

            # Check for HTTP errors
            if response.status_code >= HTTP_CLIENT_ERROR_START:
                raise ProviderAPIError(  # noqa: TRY301
                    message=f"Provider API returned error {response.status_code}",
                    status_code=response.status_code,
                    response_body=self._safe_response_body(response),
                    details={
                        "connection_id": connection_id,
                        "method": method_str,
                        "url": url,
                    },
                )

            return response  # noqa: TRY300

        except ProviderAPIError:
            raise
        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Provider API request timed out: {e}",
                details={
                    "connection_id": connection_id,
                    "method": method_str,
                    "url": url,
                    "error": str(e),
                },
            ) from e
        except httpx.HTTPError as e:
            raise NetworkError(
                message=f"Failed to call provider API: {e}",
                details={
                    "connection_id": connection_id,
                    "method": method_str,
                    "url": url,
                    "error": str(e),
                },
            ) from e

    async def list_connections(
        self,
        *,
        provider_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> ConnectionListResult:
        """
        List OAuth connections for this app.

        Returns paginated connection metadata (no tokens).
        Useful for discovering which services a user has connected.

        Args:
            provider_id: Filter by provider (e.g., "google"). None for all.
            limit: Maximum number of connections to return (default 100).
            offset: Offset for pagination (default 0).

        Returns:
            ConnectionListResult with connections list and pagination metadata.

        Raises:
            AlterSDKError: If SDK instance is closed.
            PolicyViolationError: If access is denied by policy.
            NetworkError: If connection to backend fails.
            TimeoutError: If request to backend times out.
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/oauth/connections/list"
        request_body = {
            "provider_id": provider_id,
            "limit": limit,
            "offset": offset,
        }
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            ConnectionNotFoundError,
            TokenExpiredError,
            TokenRetrievalError,
            AlterSDKError,
        ):
            raise

        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to list connections: {e}",
            ) from e
        else:
            data = response.json()
            connections = [ConnectionInfo(**c) for c in data["connections"]]
            return ConnectionListResult(
                connections=connections,
                total=data["total"],
                limit=data["limit"],
                offset=data["offset"],
                has_more=data["has_more"],
            )

    async def create_connect_session(
        self,
        *,
        end_user: dict[str, Any],
        allowed_providers: list[str] | None = None,
        return_url: str | None = None,
        allowed_origin: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ConnectSession:
        """
        Create a Connect session for initiating OAuth flows.

        Returns a URL the user can open in their browser to authorize access.

        Args:
            end_user: End user info (must contain "id" key with non-empty value).
            allowed_providers: Restrict to specific providers (e.g., ["google"]).
            return_url: URL to redirect after OAuth completion.
            allowed_origin: Allowed origin for postMessage communication.
            metadata: Request metadata for audit (e.g., ip_address, user_agent).

        Returns:
            ConnectSession with connect_url, session_token, and expiry info.

        Raises:
            AlterSDKError: If SDK instance is closed or end_user.id is missing.
            NetworkError: If connection to backend fails.
            TimeoutError: If request to backend times out.
        """
        state = self.__state
        if state["closed"]:
            raise AlterSDKError(
                message="SDK instance has been closed. "
                "Create a new AlterVault instance to make requests.",
            )

        if not end_user.get("id"):
            raise AlterSDKError(message="end_user['id'] is required")

        alter_client = state["alter_client"]
        actor_headers = self.__get_actor_request_headers()

        sdk_path = "/sdk/oauth/connect/session"
        request_body = {
            "end_user": end_user,
            "allowed_providers": allowed_providers,
            "return_url": return_url,
            "allowed_origin": allowed_origin,
            "metadata": metadata,
        }
        body_bytes = json_mod.dumps(request_body, separators=(",", ":")).encode("utf-8")
        hmac_headers = self.__compute_hmac_headers("POST", sdk_path, body_bytes)
        merged_headers = {**actor_headers, **hmac_headers, "Content-Type": "application/json"}

        try:
            response = await alter_client.post(
                sdk_path,
                content=body_bytes,
                headers=merged_headers,
            )

            self.__cache_actor_id_from_response(response)
            self._handle_error_response(response)

        except httpx.ConnectError as e:
            raise NetworkError(
                message=f"Failed to connect to Alter Vault backend: {e}",
                details={"base_url": self.base_url},
            ) from e

        except httpx.TimeoutException as e:
            raise TimeoutError(
                message=f"Request to Alter Vault backend timed out: {e}",
                details={"base_url": self.base_url},
            ) from e

        except (
            PolicyViolationError,
            ConnectionNotFoundError,
            TokenExpiredError,
            TokenRetrievalError,
            AlterSDKError,
        ):
            raise

        except Exception as e:
            raise AlterSDKError(
                message=f"Failed to create connect session: {e}",
            ) from e
        else:
            data = response.json()
            return ConnectSession(**data)

    async def close(self) -> None:
        """Close HTTP clients and release resources."""
        state = _instance_state.get(id(self))
        if state is None or state["closed"]:
            return
        state["closed"] = True

        # Wait for any pending audit tasks before closing clients
        if state["audit_tasks"]:
            await asyncio.gather(*state["audit_tasks"], return_exceptions=True)
        try:
            await state["alter_client"].aclose()
        finally:
            await state["provider_client"].aclose()

    async def __aenter__(self) -> "AlterVault":
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit."""
        await self.close()
