The files in this directory are used in both the apio parent process
and the scons child process.
