Scripts for fetching and examining oss-cad-suite-packges.
