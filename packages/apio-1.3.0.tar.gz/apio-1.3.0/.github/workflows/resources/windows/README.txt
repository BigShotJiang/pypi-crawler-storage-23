Apio is installed and is ready for use.  

To test it, open a new Command window and try a few
of the commands below. For more information see
https://fpgawars.github.io/apio/quick-start

    apio -h
    apio info system
    apio boards
    apio fpgas
    apio examples list
    apio examples fetch -h


