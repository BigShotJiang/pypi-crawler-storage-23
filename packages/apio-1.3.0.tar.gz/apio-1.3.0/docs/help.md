# Getting help

## Apio Project Home

The Apio project is hosted on a public GitHub repository at <https://github.com/FPGAwars/apio>.

## Asking Questions

You can ask the Apio team and other users in the Apio discussion forum at <https://github.com/FPGAwars/apio/discussions>.

## Bug Reports

Bug reports should be submitted in the main Apio repository at <https://github.com/FPGAwars/apio/issues>, even if they are related to other Apio repositories such as the package repositories.
