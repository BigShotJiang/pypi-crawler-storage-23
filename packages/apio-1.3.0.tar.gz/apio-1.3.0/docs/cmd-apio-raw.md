# Apio raw

---

## apio raw

The `apio raw` command bypasses Apio's usual workflow to run tools directly. It is intended for advanced users familiar with those tools.

> Before execution, Apio temporarily modifies environment variables like `$PATH`
> to make its packages accessible. Use the option `--verbose` to view these changes.

<h3>Examples</h3>

```
apio raw    -- yosys --version      # Show Yosys version
apio raw -v -- yosys --version      # Verbose output
apio raw    -- yosys                # Start Yosys in interactive mode
apio raw    -- icepll -i 12 -o 30   # Calculate ICE PLL parameters
apio raw    -- which yosys          # Locate yosys in the path
apio raw    -- bash                 # Open a shell with Apio's env.
apio raw    -- zadig                # Run Zadig (on Windows).
apio raw -v                         # Show Apio environment settings
apio raw -h                         # Show help message
```

> If a command is specified, it must be prefixed with the `--` marker to
> distinguish it from the apio command args.

<h3>Options</h3>

```
-v, --verbose  Show detailed output
-h, --help     Show help message and exit
```
