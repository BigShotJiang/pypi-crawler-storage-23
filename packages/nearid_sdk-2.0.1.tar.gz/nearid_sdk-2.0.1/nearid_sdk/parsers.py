from __future__ import annotations

from typing import Any, Dict, List, Optional

from .types import (
    AttendanceEntry,
    AttendanceResponse,
    BillingDecision,
    BillingSummary,
    Incident,
    IncidentList,
    Invoice,
    InvoiceLine,
    Link,
    LinkList,
    LinkResponse,
    LinkV2Response,
    Org,
    OrgList,
    OrgConfig,
    OrgSettings,
    OrgUser,
    PresenceEvent,
    PresenceEventList,
    PresenceSession,
    PresenceSessionList,
    Receiver,
    ReceiverHealth,
    ReceiverList,
    ReceiverStatus,
    RealtimeMetrics,
    SafetyStatus,
    SafetySummary,
    SessionConfig,
    SessionList,
    SessionSummary,
    SessionSummaryResponse,
)


def _dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def to_receiver(data: Any) -> Receiver:
    d = _dict(data)
    return Receiver(
        receiver_id=d.get("receiver_id") or d.get("id"),
        org_id=d.get("org_id"),
        display_name=d.get("display_name"),
        location_label=d.get("location_label"),
        latitude=d.get("latitude"),
        longitude=d.get("longitude"),
        auth_mode=d.get("auth_mode"),
        firmware_version=d.get("firmware_version"),
        status=d.get("status"),
        last_seen_at=d.get("last_seen_at"),
        created_at=d.get("created_at"),
        updated_at=d.get("updated_at"),
        raw=d,
    )


def to_receiver_list(payload: Any) -> ReceiverList:
    d = _dict(payload)
    items = [to_receiver(item) for item in _list(d.get("items"))]
    return ReceiverList(items=items, next_cursor=d.get("nextCursor"), raw=d)


def to_receiver_status(payload: Any) -> ReceiverStatus:
    d = _dict(payload)
    return ReceiverStatus(
        receiver_id=d.get("receiver_id") or d.get("id"),
        status=d.get("status"),
        last_seen_at=d.get("last_seen_at"),
        incidents=_list(d.get("incidents")),
        raw=d,
    )


def to_receiver_health(payload: Any) -> ReceiverHealth:
    d = _dict(payload)
    return ReceiverHealth(
        receiver_id=d.get("receiver_id") or d.get("id"),
        status=d.get("status"),
        last_seen_at=d.get("last_seen_at"),
        metrics=_dict(d.get("metrics")),
        raw=d,
    )


def to_presence_event(payload: Any) -> PresenceEvent:
    d = _dict(payload)
    return PresenceEvent(
        id=d.get("id"),
        org_id=d.get("org_id"),
        receiver_id=d.get("receiver_id"),
        user_ref=d.get("user_ref"),
        verification_status=d.get("verification_status"),
        session_id=d.get("session_id"),
        device_id_hash=d.get("device_id_hash"),
        server_timestamp=d.get("server_timestamp"),
        auth_result=d.get("auth_result"),
        reason=d.get("reason"),
        raw=d,
    )


def to_presence_event_list(payload: Any) -> PresenceEventList:
    d = _dict(payload)
    events = [to_presence_event(evt) for evt in _list(d.get("events"))]
    return PresenceEventList(events=events, page=d.get("page"), next_page=d.get("nextPage"), raw=d)


def to_presence_session(payload: Any) -> PresenceSession:
    d = _dict(payload)
    return PresenceSession(
        id=d.get("id"),
        org_id=d.get("org_id"),
        receiver_id=d.get("receiver_id"),
        user_ref=d.get("user_ref"),
        device_id_hash=d.get("device_id_hash"),
        started_at=d.get("started_at") or d.get("start_time"),
        ended_at=d.get("ended_at") or d.get("end_time"),
        session_id=d.get("session_id"),
        session_type=d.get("session_type"),
        raw=d,
    )


def to_presence_session_list(payload: Any) -> PresenceSessionList:
    d = _dict(payload)
    sessions = [to_presence_session(s) for s in _list(d.get("sessions"))]
    return PresenceSessionList(sessions=sessions, page=d.get("page"), next_page=d.get("nextPage"), raw=d)


def to_link(payload: Any) -> Link:
    d = _dict(payload)
    return Link(
        id=d.get("id"),
        org_id=d.get("org_id"),
        user_ref=d.get("user_ref"),
        device_id=d.get("device_id"),
        status=d.get("status"),
        raw=d,
    )


def to_link_response(payload: Any) -> LinkResponse:
    d = _dict(payload)
    link_data = d.get("link") if isinstance(d.get("link"), dict) else None
    link = to_link(link_data) if link_data else None
    return LinkResponse(status=d.get("status"), link=link, raw=d)


def to_link_v2_response(payload: Any) -> LinkV2Response:
    d = _dict(payload)
    return LinkV2Response(
        status=d.get("status"),
        link_id=d.get("link_id"),
        user_ref=d.get("user_ref"),
        device_id=d.get("device_id"),
        revoked_at=d.get("revoked_at"),
        raw=d,
    )


def to_link_list(payload: Any) -> LinkList:
    d = _dict(payload)
    links = [to_link(item) for item in _list(d.get("links"))]
    return LinkList(status=d.get("status"), links=links, raw=d)


def to_org(payload: Any) -> Org:
    d = _dict(payload)
    return Org(
        id=d.get("id"),
        name=d.get("name"),
        slug=d.get("slug"),
        status=d.get("status"),
        created_at=d.get("created_at"),
        updated_at=d.get("updated_at"),
        plan=d.get("plan"),
        enabled_modules=d.get("enabled_modules"),
        raw=d,
    )


def to_org_list(payload: Any) -> OrgList:
    if isinstance(payload, list):
        items = [to_org(item) for item in payload]
        return OrgList(items=items, raw=payload)
    d = _dict(payload)
    items = [to_org(item) for item in _list(d.get("items"))]
    return OrgList(items=items, raw=_list(payload))


def to_org_settings(payload: Any) -> OrgSettings:
    d = _dict(payload)
    return OrgSettings(
        timezone=d.get("timezone"),
        region=d.get("region"),
        country=d.get("country"),
        raw=d,
    )


def to_org_config(payload: Any) -> OrgConfig:
    return OrgConfig(raw=_dict(payload))


def to_realtime_metrics(payload: Any) -> RealtimeMetrics:
    d = _dict(payload)
    return RealtimeMetrics(
        active_receivers=d.get("active_receivers"),
        receivers_window_minutes=d.get("receivers_window_minutes"),
        active_sessions=d.get("active_sessions"),
        present_users=d.get("present_users"),
        incidents_open=d.get("incidents_open"),
        raw=d,
    )


def to_org_users(payload: Any) -> List[OrgUser]:
    return [OrgUser(id=_dict(u).get("id"), email=_dict(u).get("email"), name=_dict(u).get("name"), role=_dict(u).get("role"), status=_dict(u).get("status"), raw=_dict(u)) for u in _list(payload)]


def to_session_config(payload: Any) -> SessionConfig:
    d = _dict(payload)
    return SessionConfig(
        session_id=d.get("id") or d.get("session_id"),
        name=d.get("name") or d.get("display_name"),
        start_time=d.get("startTime"),
        end_time=d.get("endTime"),
        location_id=d.get("locationId"),
        group_id=d.get("groupId"),
        session_type=d.get("sessionType"),
        finalized_at=d.get("finalizedAt"),
        report_url=d.get("reportUrl"),
        raw=d,
    )


def to_session_list(payload: Any) -> SessionList:
    d = _dict(payload)
    items = [to_session_config(item) for item in _list(d.get("items"))]
    return SessionList(
        items=items,
        page=d.get("page"),
        page_size=d.get("pageSize"),
        total_pages=d.get("totalPages"),
        total_count=d.get("totalCount"),
        raw=d,
    )


def to_session_summary(payload: Any) -> SessionSummary:
    d = _dict(payload)
    return SessionSummary(
        session_id=d.get("session_id"),
        session_name=d.get("session_name"),
        present_count=d.get("presentCount"),
        late_count=d.get("lateCount"),
        absent_count=d.get("absentCount"),
        total_count=d.get("totalCount"),
        raw=d,
    )


def to_session_summary_response(payload: Any) -> SessionSummaryResponse:
    d = _dict(payload)
    summaries = [to_session_summary(item) for item in _list(d.get("sessions"))]
    return SessionSummaryResponse(sessions=summaries, rules=_dict(d.get("rules")), raw=d)


def to_attendance_response(payload: Any) -> AttendanceResponse:
    d = _dict(payload)
    entries = [
        AttendanceEntry(
            session_id=_dict(item).get("session_id") or _dict(item).get("id"),
            session_name=_dict(item).get("name"),
            user_ref=_dict(item).get("user_ref"),
            status=_dict(item).get("status"),
            first_seen_at=_dict(item).get("first_seen_at"),
            last_seen_at=_dict(item).get("last_seen_at"),
            raw=_dict(item),
        )
        for item in _list(d.get("sessions"))
    ]
    return AttendanceResponse(
        sessions=entries,
        rules=_dict(d.get("rules")),
        page=d.get("page"),
        next_page=d.get("nextPage"),
        raw=d,
    )


def to_billing_decision(payload: Any) -> BillingDecision:
    d = _dict(payload)
    return BillingDecision(
        id=d.get("id"),
        session_id=d.get("session_id"),
        session_type=d.get("session_type"),
        verified_count=d.get("verified_count"),
        base_price_cents=d.get("base_price_cents"),
        overage_count=d.get("overage_count"),
        overage_price_cents=d.get("overage_price_cents"),
        quiz_count=d.get("quiz_count"),
        quiz_fee_cents=d.get("quiz_fee_cents"),
        final_price_cents=d.get("final_price_cents"),
        finalized_at=d.get("finalized_at"),
        invoice_id=d.get("invoice_id"),
        raw=d,
    )


def to_invoice_line(payload: Any) -> InvoiceLine:
    d = _dict(payload)
    return InvoiceLine(
        id=d.get("id"),
        kind=d.get("kind"),
        reference_id=d.get("reference_id"),
        description=d.get("description"),
        quantity=d.get("quantity"),
        unit_price_cents=d.get("unit_price_cents"),
        total_cents=d.get("total_cents"),
        raw=d,
    )


def to_invoice(payload: Any) -> Invoice:
    d = _dict(payload)
    lines = [to_invoice_line(line) for line in _list(d.get("lines"))]
    return Invoice(
        id=d.get("id"),
        status=d.get("status"),
        period_start=d.get("period_start"),
        period_end=d.get("period_end"),
        total_cents=d.get("total_cents"),
        currency=d.get("currency"),
        created_at=d.get("created_at"),
        lines=lines,
        raw=d,
    )


def to_billing_summary(payload: Any) -> BillingSummary:
    d = _dict(payload)
    decisions = [to_billing_decision(item) for item in _list(d.get("decisions"))]
    invoices = [to_invoice(item) for item in _list(d.get("invoices"))]
    return BillingSummary(
        plan=d.get("plan"),
        seat_count=d.get("seat_count"),
        seat_price_cents=d.get("seat_price_cents"),
        seat_total_cents=d.get("seat_total_cents"),
        decision_count=d.get("decision_count"),
        decision_total_cents=d.get("decision_total_cents"),
        unbilled_decision_count=d.get("unbilled_decision_count"),
        total_cents=d.get("total_cents"),
        period_start=d.get("period_start"),
        period_end=d.get("period_end"),
        decisions=decisions,
        invoices=invoices,
        raw=d,
    )


def to_incident(payload: Any) -> Incident:
    d = _dict(payload)
    return Incident(
        id=d.get("id"),
        type=d.get("type"),
        severity=d.get("severity"),
        status=d.get("status"),
        started_at=d.get("started_at"),
        resolved_at=d.get("resolved_at"),
        location_id=d.get("location_id"),
        workzone_id=d.get("workzone_id"),
        created_by=d.get("created_by"),
        notes=d.get("notes"),
        timestamp=d.get("timestamp"),
        title=d.get("title"),
        description=d.get("description"),
        use_case=d.get("use_case"),
        raw=d,
    )


def to_incident_list(payload: Any) -> IncidentList:
    d = _dict(payload)
    items = [to_incident(item) for item in _list(d.get("items") or d.get("incidents"))]
    return IncidentList(
        items=items,
        page=d.get("page"),
        page_size=d.get("pageSize"),
        total_pages=d.get("totalPages"),
        total_count=d.get("totalCount"),
        raw=d,
    )


def to_safety_status(payload: Any) -> SafetyStatus:
    d = _dict(payload)
    incidents = [to_incident(item) for item in _list(d.get("active_incidents"))]
    return SafetyStatus(active_incidents=incidents, raw=d)


def to_safety_summary(payload: Any) -> SafetySummary:
    d = _dict(payload)
    return SafetySummary(totals=_dict(d.get("totals")), raw=d)
