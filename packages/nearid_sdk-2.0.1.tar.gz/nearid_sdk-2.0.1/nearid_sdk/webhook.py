from __future__ import annotations

import hashlib
import hmac
from typing import Union


def verify_webhook_signature(
    secret: Union[str, bytes],
    timestamp: Union[str, int],
    raw_body: bytes,
    signature_hex: str,
) -> bool:
    """
    Verify a NearID webhook signature using HMAC-SHA256.

    Spec (v2, Section 10.3):

      X-HNNP-Signature = hex(HMAC-SHA256(webhook_secret, timestamp || raw_body))
    """
    key = secret.encode("utf-8") if isinstance(secret, str) else bytes(secret)
    ts_str = str(timestamp)

    msg = ts_str.encode("utf-8") + raw_body
    expected = hmac.new(key, msg, hashlib.sha256).hexdigest()

    try:
        return hmac.compare_digest(expected, signature_hex)
    except Exception:
        return False


def verify_nearid_webhook(
    raw_body: bytes,
    signature: str,
    timestamp: Union[str, int],
    webhook_secret: Union[str, bytes],
) -> bool:
    """
    Helper that forwards to verify_webhook_signature.
    """
    return verify_webhook_signature(
        secret=webhook_secret,
        timestamp=timestamp,
        raw_body=raw_body,
        signature_hex=signature,
    )
