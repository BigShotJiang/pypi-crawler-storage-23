from nearid_sdk import verify_webhook_signature


def test_verify_webhook_signature_valid():
    secret = "webhook_secret"
    timestamp = "1700000000"
    raw_body = b'{"hello":"world"}'

    import hmac
    import hashlib

    expected = hmac.new(
        secret.encode("utf-8"),
        timestamp.encode("utf-8") + raw_body,
        hashlib.sha256,
    ).hexdigest()

    assert verify_webhook_signature(secret, timestamp, raw_body, expected) is True


def test_verify_webhook_signature_invalid():
    assert verify_webhook_signature("secret", "1", b"{}", "deadbeef") is False
