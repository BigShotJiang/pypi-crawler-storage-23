from __future__ import annotations

from typing import Any, Dict, List, Tuple

import requests

from nearid_sdk import NearIDClient


class DummyResponse:
    def __init__(self, status_code: int = 200, json_body: Any = None, text: str | None = None, content: bytes = b""):
        self.status_code = status_code
        self._json = json_body
        self.text = text if text is not None else ""
        self.content = content

    def json(self) -> Any:
        return self._json


def test_client_endpoints(monkeypatch):
    calls: List[Dict[str, Any]] = []

    def fake_request(method, url, headers=None, params=None, json=None, timeout=None):
        calls.append(
            {
                "method": method,
                "url": url,
                "headers": headers,
                "params": params,
                "json": json,
            }
        )
        if "/v1/presence/events" in url:
            page = params.get("page", 1) if isinstance(params, dict) else 1
            events = [{"id": "evt1"}] if page == 1 else [{"id": "evt2"}]
            next_page = 2 if page == 1 else None
            return DummyResponse(status_code=200, json_body={"events": events, "nextPage": next_page, "page": page}, text='{"ok": true}')
        if "/v2/orgs/" in url and "/receivers" in url:
            cursor = params.get("cursor") if isinstance(params, dict) else None
            items = [{"receiver_id": "rcv1"}] if not cursor else [{"receiver_id": "rcv2"}]
            next_cursor = "cursor2" if not cursor else None
            return DummyResponse(status_code=200, json_body={"items": items, "nextCursor": next_cursor}, text='{"ok": true}')
        if url.endswith("/pdf"):
            return DummyResponse(status_code=200, content=b"%PDF", text="")
        return DummyResponse(status_code=200, json_body={"ok": True}, text='{"ok": true}')

    monkeypatch.setattr(requests, "request", fake_request)

    client = NearIDClient(api_key="key", org_id="org_1", base_url="https://api.example")

    client.list_receivers()
    client.create_receiver(receiver_id="rcv1", auth_mode="token")
    client.update_receiver(receiver_id="rcv1", status="active")
    client.list_events(user_ref="user_1")
    client.list_sessions(receiver_id="rcv1")
    client.list_links()
    client.create_link(user_ref="user_1")
    client.link_presence_session(presence_session_id="ps1", user_ref="user_1")
    client.activate_link("link1")
    client.revoke_link("link2")
    client.unlink("link3")

    client.list_orgs()
    client.get_org("org_1")
    client.get_org_settings("org_1")
    client.update_org_settings("org_1", {"timezone": "UTC"})
    client.get_org_config("org_1")
    client.update_org_config("org_1", {"modules": ["attendance"]})
    client.get_org_metrics_realtime("org_1")
    client.list_org_users("org_1")

    client.list_receivers_admin()
    client.get_receiver("rcv1")
    client.update_receiver_admin("rcv1", {"status": "active"})
    client.get_receiver_status("rcv1")
    client.get_receiver_health("rcv1")

    client.list_org_sessions()
    client.get_org_sessions_summary()
    client.create_org_session({"name": "Session 1"})
    client.update_org_session("s1", {"name": "Updated"})
    client.delete_org_session("s1")
    client.finalize_org_session("s1")

    client.get_presence_live()
    client.get_presence_logs()
    client.get_presence_events()
    client.list_locations()
    client.list_groups()
    client.create_group({"name": "Group 1"})
    client.update_group("g1", {"name": "Group 1b"})
    client.delete_group("g1")
    client.get_attendance()
    client.export_attendance_csv()

    client.get_billing_summary()
    client.list_invoices()
    client.get_invoice_pdf("inv1")

    client.list_incidents()
    client.get_incident("inc1")
    client.get_incident_rollcall("inc1")
    client.get_safety_status()
    client.get_safety_summary()

    events = [evt.id for evt in client.iterate_events(org_id="org_1")]
    assert events == ["evt1", "evt2"]

    receivers = [rcv.receiver_id for rcv in client.iterate_receivers(org_id="org_1")]
    assert receivers == ["rcv1", "rcv2"]

    assert any(call["url"].endswith("/v2/orgs/org_1/receivers") for call in calls)
    assert any(call["url"].endswith("/v1/presence/events") for call in calls)
    assert any(call["url"].endswith("/api/sessions/s1/finalize") for call in calls)
    assert any(call["url"].endswith("/api/org/invoices/inv1/pdf") for call in calls)

    # ensure auth header sent
    for call in calls:
        assert call["headers"]["Authorization"].startswith("Bearer ")
