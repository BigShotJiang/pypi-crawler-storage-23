* Pierrick Brun <pierrick.brun@akretion.com>
* Sebastien Beau <sebastien.beau@akretion.com>
* Kevin Khao <kevin.khao@akretion.com>

* `Ooops404 <https://www.ooops404.com>`__:

  * Ilyas <irazor147@gmail.com>
