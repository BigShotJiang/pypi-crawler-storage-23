"""This file has an intentional syntax error for testing."""

def broken(
