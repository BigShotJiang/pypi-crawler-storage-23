### README.md

```markdown
# ProzemiRune 🌀

[![PyPI version](https://badge.fury.io/py/prozemi-rune.svg)](https://badge.fury.io/py/prozemi-rune)
[![Python Version](https://img.shields.io/pypi/pyversions/prozemi-rune.svg)](https://pypi.org/project/prozemi-rune/)

ビジュアルプログラミングアプリ「プログラミングゼミ（プロゼミ）」のAPIをPythonから操作するための非公式クライアントライブラリです。
作品の自動バックアップ、データ分析、機械学習（PyTorch等）のためのデータ収集を支援します。

## ✨ 特徴

- **トークン自動発行**: `sign_up` メソッドで新規アカウントとトークンを即座に生成。
- **認証回避**: 独自ヘッダー（X-Cookiez）をシミュレートし、正規アプリとして通信。
- **作品収集**: 「みんなの作品」からプロジェクト一覧を取得し、`.prozemiproj` ファイルをダウンロード可能。
- **軽量**: `requests` のみに依存しており、導入が簡単。

## 🚀 インストール

```bash
pip install prozemi-rune
```

## 🛠 使い方

### 1. 新規アカウント作成とトークン取得
実行するたびに新しいユーザーとしてログインし、通信用のトークンを取得します。

```python
from prozemi_rune import ProzemiRune

# 初期化
rune = ProzemiRune()

# 新規登録 (トークン自動発行)
user_info = rune.sign_up(nickname="PythonBot")
print(f"User: {rune.username}")
print(f"Token: {rune.report_token}")
```

### 2. 「みんなの作品」の一覧取得とダウンロード
公開されている作品のメタデータを取得し、プロジェクトファイルをダウンロードします。

```python
# 最新の作品15件を取得
works = rune.get_public_works(page=1)

for work in works:
    print(f"Found: {work['name']} by {work['author']}")
    
    # プロジェクトファイルをダウンロード (.prozemiproj)
    rune.download_project(work['url'], f"./data/{work['id']}.prozemiproj")
```

### 3. 既存アカウントでのログイン
一度作成した `username` を保存しておけば、次回から同じアカウントでログインできます。

```python
rune = ProzemiRune(username="YourUsername")
rune.sign_in()
```

## ⚠️ 免責事項
このプロジェクトは公式（DeNA）とは一切関係のない非公式なものです。
サーバーに過度な負荷をかけるスクレイピングや、利用規約に反する行為（スパム投稿等）には使用しないでください。本ライブラリの使用によるアカウントの停止等について、開発者は責任を負いません。

---
