import requests
import time
import random
import string
import urllib3
import json
import os

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ProzemiRune:
    def __init__(self, username=None, nickname="PythonUser", cache_file="session.json"):
        self.base_url = "https://api.programmingzemi.com/api/v1"
        self.cache_file = cache_file
        self.session = requests.Session()
        self.session.verify = False
        
        # 固定ヘッダー（画像から解析したもの）
        self.session.headers.update({
            "User-Agent": "ProgrammingZemi/1.14.12",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-api-token": "5Y_tqKp-Fz_cfDxt7PeW",
            "x-app-token": "wjzZKz5Xf19UDHCyGsG8",
        })

        # キャッシュから認証情報を読み込む、なければ新規作成
        self.load_session(username, nickname)

    def load_session(self, username, nickname):
        if os.path.exists(self.cache_file):
            with open(self.cache_file, 'r') as f:
                data = json.load(f)
                self.username = data.get("username")
                self.nickname = data.get("nickname")
                self.report_token = data.get("report_token")
        else:
            self.username = username or self._generate_id()
            self.nickname = nickname
            self.report_token = None

    def _generate_id(self, length=8):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def save_session(self):
        with open(self.cache_file, 'w') as f:
            json.dump({
                "username": self.username,
                "nickname": self.nickname,
                "report_token": self.report_token
            }, f)

    def sign_in(self):
        """トークンの自動発行・更新"""
        url = f"{self.base_url}/users/sign_in"
        payload = {
            "last_noticed": str(int(time.time())),
            "nickname": self.nickname,
            "username": self.username
        }
        
        response = self.session.post(url, json=payload)
        if response.status_code == 201:
            self.report_token = response.json().get("report_token")
            self.save_session()
            print(f"[Log] Token updated: {self.report_token}")
            return True
        return False

    def request_with_retry(self, method, endpoint, **kwargs):
        """トークン切れを検知して自動リトライするラッパー"""
        url = f"{self.base_url}/{endpoint}"
        
        # トークンがなければまず取得
        if not self.report_token:
            self.sign_in()

        # リクエスト実行（report_tokenをパラメータやボディに追加する必要があるか要調査）
        # 仮にクエリパラメータに必要なら: kwargs.setdefault('params', {})['report_token'] = self.report_token
        
        response = self.session.request(method, url, **kwargs)

        # もしトークン切れ（401等）なら再ログインして1回だけリトライ
        if response.status_code == 401:
            print("[Log] Token expired. Retrying...")
            if self.sign_in():
                return self.session.request(method, url, **kwargs)
        
        return response

    # --- APIの実装例 ---
    def get_user_info(self):
        # sign_in 自体がユーザー情報を兼ねているのでそれを呼ぶ例
        return self.sign_in()

    def create_log(self, log_data):
        # 画像にあった /api/v1/logs/create を叩く例
        return self.request_with_retry("POST", "logs/create", json=log_data)