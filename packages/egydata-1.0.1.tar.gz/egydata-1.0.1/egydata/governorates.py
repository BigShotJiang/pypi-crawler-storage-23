governorates = [
  {"id": 1, "code": "CAI", "name": "القاهرة", "nameEn": "Cairo"},
  {"id": 2, "code": "ALX", "name": "الإسكندرية", "nameEn": "Alexandria"},
  {"id": 3, "code": "GIZ", "name": "الجيزة", "nameEn": "Giza"},
  {"id": 4, "code": "PTS", "name": "بورسعيد", "nameEn": "Port Said"},
  {"id": 5, "code": "SUZ", "name": "السويس", "nameEn": "Suez"},
  {"id": 6, "code": "DKH", "name": "الدقهلية", "nameEn": "Dakahlia"},
  {"id": 7, "code": "SHR", "name": "الشرقية", "nameEn": "Sharqia"},
  {"id": 8, "code": "QLB", "name": "القليوبية", "nameEn": "Qalyubia"},
  {"id": 9, "code": "KFS", "name": "كفر الشيخ", "nameEn": "Kafr El Sheikh"},
  {"id": 10, "code": "GHR", "name": "الغربية", "nameEn": "Gharbia"},
  {"id": 11, "code": "MNF", "name": "المنوفية", "nameEn": "Monufia"},
  {"id": 12, "code": "BHR", "name": "البحيرة", "nameEn": "Beheira"},
  {"id": 13, "code": "ISM", "name": "الإسماعيلية", "nameEn": "Ismailia"},
  {"id": 14, "code": "DMT", "name": "دمياط", "nameEn": "Damietta"},
  {"id": 15, "code": "FYM", "name": "الفيوم", "nameEn": "Faiyum"},
  {"id": 16, "code": "BNS", "name": "بني سويف", "nameEn": "Beni Suef"},
  {"id": 17, "code": "MNY", "name": "المنيا", "nameEn": "Minya"},
  {"id": 18, "code": "AST", "name": "أسيوط", "nameEn": "Asyut"},
  {"id": 19, "code": "SHG", "name": "سوهاج", "nameEn": "Sohag"},
  {"id": 20, "code": "QNA", "name": "قنا", "nameEn": "Qena"},
  {"id": 21, "code": "LXR", "name": "الأقصر", "nameEn": "Luxor"},
  {"id": 22, "code": "ASN", "name": "أسوان", "nameEn": "Aswan"},
  {"id": 23, "code": "RED", "name": "البحر الأحمر", "nameEn": "Red Sea"},
  {"id": 24, "code": "WAD", "name": "الوادي الجديد", "nameEn": "New Valley"},
 {"id": 25, "code": "MTR", "name": "مطروح", "nameEn": "Matruh"},
  {"id": 26, "code": "SIN", "name": "شمال سيناء", "nameEn": "North Sinai"},
  {"id": 27, "code": "SIS", "name": "جنوب سيناء", "nameEn": "South Sinai"},
]

_code_map = {g["code"]: g for g in governorates}
_id_map = {g["id"]: g for g in governorates}

def get_all(): return governorates.copy()

def get_by_code(code):
  if not isinstance(code, str): return None
  return _code_map.get(code.upper())

def get_by_id(id):
  try: num_id = int(id)
  except (ValueError, TypeError): return None
  return _id_map.get(num_id)

def search(query):
  if not isinstance(query, str) or not query.strip(): return []
  q = query.strip().lower()
  result = []
  for g in governorates:
    if (q in g["name"] or q in g["nameEn"].lower() or q in g["code"].lower()): result.append(g)
  return result
