"""Provide Betty's serialization and deserialization API."""
