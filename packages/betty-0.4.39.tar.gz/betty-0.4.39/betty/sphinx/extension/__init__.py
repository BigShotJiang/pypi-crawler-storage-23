"""
Provide `Sphinx <https://www.sphinx-doc.org>`_ extensions.
"""
