"""Abstract parsers."""
