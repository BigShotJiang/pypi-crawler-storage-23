#!/usr/bin/env python
# -*- coding: utf-8 -*-
# vim: nu:ai:ts=4:sw=4

#
#  Copyright (C) 2026 Joseph Areeda <joseph.areeda@ligo.org>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
""""""

__author__ = 'joseph areeda'
__email__ = 'joseph.areeda@ligo.org'

import pytest

from ja_webutils.Page import Page
from ja_webutils.PageItem import PageItemNavBar, PageItemLink, PageItemNavBarDropdown


class TestNavBar:

    def test_min(self):
        navbar = PageItemNavBar()
        html = navbar.get_html()
        assert len(html) > 0

    def test_nav_links(self):
        navbar = PageItemNavBar()
        navbar.add_item(PageItemLink('/home', 'Home'))
        navbar.add_item(PageItemLink('/about', 'About'))
        html = navbar.get_html()
        assert len(html) > 0

        page = Page()
        page.add(navbar)
        html = page.get_html()

        with open('/tmp/navbar-test.html', 'w') as out:
            out.write(html)

    def test_nav_dropdown(self):
        navbar = PageItemNavBar()
        navbar.add_item(PageItemLink('/home', 'Home'))
        navbar.add_item(PageItemLink('/about', 'About'))
        navbar.add_item(PageItemLink('/contact', 'Contact'))
        navbar.add_item(PageItemNavBarDropdown(label='My Dropdown', content=[
            PageItemLink('/help', 'Help'),
            PageItemLink('/about', 'About')
        ]))
        html = navbar.get_html()
        assert len(html) > 0

        page = Page()
        page.add(navbar)
        html = page.get_html()

        with open('/tmp/navbar-test2.html', 'w') as out:
            out.write(html)