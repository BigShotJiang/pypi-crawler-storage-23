require("./wuttafarm-buefy.scss");
