
========
Features
========

Here is the list of features currently supported:

* login via farmOS / OAuth2 workflows
   * Authorization Code workflow is supported
   * (technically, Password Grant workflow is also supported, for now)

* view some farmOS data directly
   * limited data is fetched via farmOS API for several views
   * performance isn't bad, but data is not very "complete"
   * more data could be fetched, but not sure this is the best way..?

* import some data from farmOS
   * limited data is imported from farmOS API into native app tables
   * this data is exposed in views, similar to direct farmOS views (above)

* export some data back to farmOS
   * limited data is exported back via farmOS API, from native tables
   * supported tables are auto-synced when a record is created/updated
      * AnimalType
      * AnimalAsset
      * GroupAsset
      * LandAsset
      * StructureAsset


How I Use This App
------------------

My production farmOS instance is deployed via Podman container, which
I prefer over Docker.  (Not that I know much about any of that
really.)  It has a PostgreSQL database which runs in a separate
container.

My production WuttaFarm instance is installed directly on the same
host machine, in a Python virtual environment.  PostgreSQL is also
installed on the host machine; the app uses that for DB.

I ran the initial "special" import to establish the user accounts;
then I ran the "full" import (farmOS → WuttaFarm).  See also
:doc:`/narr/install`.

I configured a cron job to run the full import every night, but in
dry-run mode with warnings.  This means I will get an email if
WuttaFarm is ever out of sync with farmOS.

With all that in place, I can use WuttaFarm as my "daily driver" to
add/edit assets (and soon, logs).  Changes I make are immediately
synced to farmOS, so as long as the overnight check does not send me
an email, I know everything is good.


Roadmap
-------

Here are some things I still have planned so far:

* finish support for auto-sync, in current asset models
   * must make "asset parents" editable

* add more asset models?
   * i may only add those i need for now, but others can add more

* flesh out the log model support
   * add more tables, fields to schema
   * add/improve import and export
   * basically this should be as good as the asset model support
   * although again i may only add those i need for now

* add custom "quick forms" for assets and logs
   * again i probably will just add a few (e.g. egg collection)
   * but this could be an interesting path to go down, we'll see

* add custom "CSV/file importers"
   * the framework has some pretty neat tools around this, so..
   * ..even if i don't need CSV import i'd like to show what's possible

Notably **off the table** for now are:

* anything involving maps
* file/image attachments

I will just import "thumbnail" and "large" image URLs from farmOS for
each asset for now.  Will have to think more on the image/attachment
stuff before I'll know if/how to add support in WuttaFarm.

Maps will wait mostly because I have never done anything involving
those (or GIS etc. - if that's even the right term).  And anyway the
main "use" for this app is probably around data entry, so it may never
"need" maps support.


Screenshots
-----------


Login Screen
~~~~~~~~~~~~

.. image:: https://wuttaproject.org/images/wuttafarm/screenshot001.png


List All Assets
~~~~~~~~~~~~~~~

.. image:: https://wuttaproject.org/images/wuttafarm/screenshot002.png


View Animal Asset
~~~~~~~~~~~~~~~~~

.. image:: https://wuttaproject.org/images/wuttafarm/screenshot003.png


Edit Animal Asset
~~~~~~~~~~~~~~~~~

.. image:: https://wuttaproject.org/images/wuttafarm/screenshot004.png
