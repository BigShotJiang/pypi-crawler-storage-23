
``wuttafarm.cli``
=================

.. automodule:: wuttafarm.cli
   :members:
