
``wuttafarm.cli.base``
======================

.. automodule:: wuttafarm.cli.base
   :members:
