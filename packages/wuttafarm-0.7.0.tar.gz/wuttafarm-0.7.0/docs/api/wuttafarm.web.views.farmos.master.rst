
``wuttafarm.web.views.farmos.master``
=====================================

.. automodule:: wuttafarm.web.views.farmos.master
   :members:
