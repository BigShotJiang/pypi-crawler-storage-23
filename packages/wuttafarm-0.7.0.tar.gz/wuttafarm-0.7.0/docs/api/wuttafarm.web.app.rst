
``wuttafarm.web.app``
=====================

.. automodule:: wuttafarm.web.app
   :members:
