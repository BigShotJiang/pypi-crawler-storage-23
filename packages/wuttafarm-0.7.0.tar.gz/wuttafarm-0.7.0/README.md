
# WuttaFarm

This is a Python web app (built with
[WuttaWeb](https://wuttaproject.org)), to integrate with and extend
[farmOS](https://farmos.org).

It is just an experiment so far; the ideas I hope to play with
include:

- display farmOS data directly, via real-time API fetch
- add "mirror" schema and sync data from farmOS to app DB (and display it)
- possibly add more schema / extra features
- possibly sync data back to farmOS

See full docs at https://docs.wuttaproject.org/wuttafarm/
