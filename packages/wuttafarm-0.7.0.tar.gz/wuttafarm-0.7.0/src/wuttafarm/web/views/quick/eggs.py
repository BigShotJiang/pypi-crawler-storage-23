# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Quick Form for "Eggs"
"""

import json

import colander
from deform.widget import SelectWidget

from farmOS.subrequests import Action, Subrequest, SubrequestsBlueprint, Format

from wuttaweb.forms.schema import WuttaDateTime
from wuttaweb.forms.widgets import WuttaDateTimeWidget

from wuttafarm.web.views.quick import QuickFormView
from wuttafarm.web.util import get_farmos_client_for_user


class EggsQuickForm(QuickFormView):
    """
    Use this form to record an egg harvest. A harvest log will be
    created with standard details filled in.
    """

    form_title = "Eggs"
    route_slug = "eggs"
    url_slug = "eggs"

    _layer_assets = None

    def make_quick_form(self):
        f = self.make_form(
            fields=[
                "timestamp",
                "count",
                "asset",
                "notes",
            ],
            labels={
                "timestamp": "Date",
                "count": "Quantity",
                "asset": "Layer Asset",
            },
        )

        # timestamp
        f.set_node("timestamp", WuttaDateTime())
        f.set_widget("timestamp", WuttaDateTimeWidget(self.request))
        f.set_default("timestamp", self.app.make_utc())

        # count
        f.set_node("count", colander.Integer())

        # asset
        assets = self.get_layer_assets()
        values = [(a["uuid"], a["name"]) for a in assets]
        f.set_widget("asset", SelectWidget(values=values))
        if len(assets) == 1:
            f.set_default("asset", assets[0]["uuid"])

        # notes
        f.set_widget("notes", "notes")
        f.set_required("notes", False)

        return f

    def get_layer_assets(self):
        if self._layer_assets is not None:
            return self._layer_assets

        assets = []
        params = {
            "filter[produces_eggs]": 1,
            "sort": "name",
        }

        def normalize(asset):
            return {
                "uuid": asset["id"],
                "name": asset["attributes"]["name"],
                "type": asset["type"],
            }

        result = self.farmos_client.asset.get("animal", params=params)
        assets.extend([normalize(a) for a in result["data"]])

        result = self.farmos_client.asset.get("group", params=params)
        assets.extend([normalize(a) for a in result["data"]])

        assets.sort(key=lambda a: a["name"])
        self._layer_assets = assets
        return assets

    def save_quick_form(self, form):

        response = self.save_to_farmos(form)
        log = json.loads(response["create-log#body{0}"]["body"])

        if self.app.is_farmos_mirror():
            quantity = json.loads(response["create-quantity"]["body"])
            client = get_farmos_client_for_user(self.request)
            self.app.auto_sync_from_farmos(
                quantity["data"], "StandardQuantity", client=client
            )
            self.app.auto_sync_from_farmos(log["data"], "HarvestLog", client=client)

        return log

    def save_to_farmos(self, form):
        data = form.validated

        assets = self.get_layer_assets()
        assets = {a["uuid"]: a for a in assets}
        asset = assets[data["asset"]]

        # TODO: make this configurable?
        unit_name = "egg(s)"

        unit = {"data": {"type": "taxonomy_term--unit"}}
        new_unit = None

        result = self.farmos_client.resource.get(
            "taxonomy_term",
            "unit",
            params={
                "filter[name]": unit_name,
            },
        )
        if result["data"]:
            unit["data"]["id"] = result["data"][0]["id"]
        else:
            payload = dict(unit)
            payload["data"]["attributes"] = {"name": unit_name}
            new_unit = Subrequest(
                action=Action.create,
                requestId="create-unit",
                endpoint="api/taxonomy_term/unit",
                body=payload,
            )
            unit["data"]["id"] = "{{create-unit.body@$.data.id}}"

        quantity = {
            "data": {
                "type": "quantity--standard",
                "attributes": {
                    "measure": "count",
                    "value": {
                        "numerator": data["count"],
                        "denominator": 1,
                    },
                },
                "relationships": {
                    "units": unit,
                },
            },
        }

        kw = {}
        if new_unit:
            kw["waitFor"] = ["create-unit"]
        new_quantity = Subrequest(
            action=Action.create,
            requestId="create-quantity",
            endpoint="api/quantity/standard",
            body=quantity,
            **kw,
        )

        notes = None
        if data["notes"]:
            notes = {"value": data["notes"]}

        log = {
            "data": {
                "type": "log--harvest",
                "attributes": {
                    "name": f"Collected {data['count']} {unit_name}",
                    "timestamp": self.app.localtime(data["timestamp"]).timestamp(),
                    "notes": notes,
                    "quick": ["eggs"],
                },
                "relationships": {
                    "asset": {
                        "data": [
                            {
                                "id": asset["uuid"],
                                "type": asset["type"],
                            },
                        ],
                    },
                    "quantity": {
                        "data": [
                            {
                                "id": "{{create-quantity.body@$.data.id}}",
                                "type": "quantity--standard",
                            },
                        ],
                    },
                },
            },
        }

        new_log = Subrequest(
            action=Action.create,
            requestId="create-log",
            waitFor=["create-quantity"],
            endpoint="api/log/harvest",
            body=log,
        )

        blueprints = [new_quantity, new_log]
        if new_unit:
            blueprints.insert(0, new_unit)
        blueprint = SubrequestsBlueprint.parse_obj(blueprints)
        response = self.farmos_client.subrequests.send(blueprint, format=Format.json)
        return response

    def redirect_after_save(self, result):
        return self.redirect(
            self.request.route_url(
                "farmos_logs_harvest.view", uuid=result["data"]["id"]
            )
        )


def includeme(config):
    EggsQuickForm.defaults(config)
