# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS Activity Logs
"""

from wuttafarm.web.views.farmos.logs import LogMasterView


class ActivityLogView(LogMasterView):
    """
    View for farmOS activity logs
    """

    model_name = "farmos_activity_log"
    model_title = "farmOS Activity Log"
    model_title_plural = "farmOS Activity Logs"

    route_prefix = "farmos_logs_activity"
    url_prefix = "/farmOS/logs/activity"

    farmos_log_type = "activity"
    farmos_refurl_path = "/logs/activity"


def defaults(config, **kwargs):
    base = globals()

    ActivityLogView = kwargs.get("ActivityLogView", base["ActivityLogView"])
    ActivityLogView.defaults(config)


def includeme(config):
    defaults(config)
