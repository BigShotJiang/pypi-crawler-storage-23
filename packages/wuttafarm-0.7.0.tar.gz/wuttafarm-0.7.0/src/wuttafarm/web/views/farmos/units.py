# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS units
"""

from wuttafarm.web.views.farmos.master import TaxonomyMasterView


class UnitView(TaxonomyMasterView):
    """
    Master view for Units in farmOS.
    """

    model_name = "farmos_unit"
    model_title = "farmOS Unit"
    model_title_plural = "farmOS Units"

    route_prefix = "farmos_units"
    url_prefix = "/farmOS/units"

    farmos_taxonomy_type = "unit"
    farmos_refurl_path = "/admin/structure/taxonomy/manage/unit/overview"

    def get_xref_buttons(self, unit):
        buttons = super().get_xref_buttons(unit)
        model = self.app.model
        session = self.Session()

        if wf_unit := (
            session.query(model.Unit)
            .filter(model.Unit.farmos_uuid == unit["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url("units.view", uuid=wf_unit.uuid),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    UnitView = kwargs.get("UnitView", base["UnitView"])
    UnitView.defaults(config)


def includeme(config):
    defaults(config)
