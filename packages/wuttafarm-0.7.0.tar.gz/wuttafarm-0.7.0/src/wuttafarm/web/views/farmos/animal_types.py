# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS animal types
"""

from wuttafarm.web.views.farmos.master import TaxonomyMasterView


class AnimalTypeView(TaxonomyMasterView):
    """
    Master view for Animal Types in farmOS.
    """

    model_name = "farmos_animal_type"
    model_title = "farmOS Animal Type"
    model_title_plural = "farmOS Animal Types"

    route_prefix = "farmos_animal_types"
    url_prefix = "/farmOS/animal-types"

    farmos_taxonomy_type = "animal_type"
    farmos_refurl_path = "/admin/structure/taxonomy/manage/animal_type/overview"

    def get_xref_buttons(self, animal_type):
        buttons = super().get_xref_buttons(animal_type)
        model = self.app.model
        session = self.Session()

        if wf_animal_type := (
            session.query(model.AnimalType)
            .filter(model.AnimalType.farmos_uuid == animal_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url(
                        "animal_types.view", uuid=wf_animal_type.uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    AnimalTypeView = kwargs.get("AnimalTypeView", base["AnimalTypeView"])
    AnimalTypeView.defaults(config)


def includeme(config):
    defaults(config)
