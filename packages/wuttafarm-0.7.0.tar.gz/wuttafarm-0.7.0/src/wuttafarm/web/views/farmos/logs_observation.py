# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS Observation Logs
"""

from wuttafarm.web.views.farmos.logs import LogMasterView


class ObservationLogView(LogMasterView):
    """
    View for farmOS observation logs
    """

    model_name = "farmos_observation_log"
    model_title = "farmOS Observation Log"
    model_title_plural = "farmOS Observation Logs"

    route_prefix = "farmos_logs_observation"
    url_prefix = "/farmOS/logs/observation"

    farmos_log_type = "observation"
    farmos_refurl_path = "/logs/observation"

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "name",
        "assets",
        "locations",
        "groups",
        "is_group_assignment",
        "owners",
    ]


def defaults(config, **kwargs):
    base = globals()

    ObservationLogView = kwargs.get("ObservationLogView", base["ObservationLogView"])
    ObservationLogView.defaults(config)


def includeme(config):
    defaults(config)
