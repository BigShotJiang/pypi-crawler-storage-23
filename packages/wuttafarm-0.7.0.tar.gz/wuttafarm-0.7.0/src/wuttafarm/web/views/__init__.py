# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm Views
"""

from wuttaweb.views import essential

from .master import WuttaFarmMasterView


def includeme(config):
    wutta_config = config.registry.settings.get("wutta_config")
    app = wutta_config.get_app()
    enum = app.enum
    mode = app.get_farmos_integration_mode()

    # wuttaweb core
    essential.defaults(
        config,
        **{
            "wuttaweb.views.auth": "wuttafarm.web.views.auth",
            "wuttaweb.views.common": "wuttafarm.web.views.common",
            "wuttaweb.views.settings": "wuttafarm.web.views.settings",
            "wuttaweb.views.users": "wuttafarm.web.views.users",
        }
    )

    # native table views
    if mode != enum.FARMOS_INTEGRATION_MODE_WRAPPER:
        config.include("wuttafarm.web.views.units")
        config.include("wuttafarm.web.views.quantities")
        config.include("wuttafarm.web.views.asset_types")
        config.include("wuttafarm.web.views.assets")
        config.include("wuttafarm.web.views.land")
        config.include("wuttafarm.web.views.structures")
        config.include("wuttafarm.web.views.animals")
        config.include("wuttafarm.web.views.groups")
        config.include("wuttafarm.web.views.plants")
        config.include("wuttafarm.web.views.logs")
        config.include("wuttafarm.web.views.logs_activity")
        config.include("wuttafarm.web.views.logs_harvest")
        config.include("wuttafarm.web.views.logs_medical")
        config.include("wuttafarm.web.views.logs_observation")

    # quick form views
    # (nb. these work with all integration modes)
    config.include("wuttafarm.web.views.quick")

    # views for farmOS
    if mode != enum.FARMOS_INTEGRATION_MODE_NONE:
        config.include("wuttafarm.web.views.farmos")
