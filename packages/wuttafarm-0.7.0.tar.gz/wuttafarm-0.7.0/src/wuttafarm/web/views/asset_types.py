# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Asset Types
"""

from wuttafarm.db.model import AssetType
from wuttafarm.web.views import WuttaFarmMasterView


class AssetTypeView(WuttaFarmMasterView):
    """
    Master view for Asset Types
    """

    model_class = AssetType
    route_prefix = "asset_types"
    url_prefix = "/asset-types"

    grid_columns = [
        "name",
        "drupal_id",
        "description",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "description",
        "drupal_id",
        "farmos_uuid",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")

    def get_xref_buttons(self, asset_type):
        buttons = super().get_xref_buttons(asset_type)

        if asset_type.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_asset_types.view", uuid=asset_type.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons

    @classmethod
    def defaults(cls, config):
        """ """
        wutta_config = config.registry.settings.get("wutta_config")
        app = wutta_config.get_app()

        if app.is_farmos_mirror():
            cls.creatable = False
            cls.editable = False
            cls.deletable = False

        cls._defaults(config)


def defaults(config, **kwargs):
    base = globals()

    AssetTypeView = kwargs.get("AssetTypeView", base["AssetTypeView"])
    AssetTypeView.defaults(config)


def includeme(config):
    defaults(config)
