# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Observation Logs
"""

from wuttafarm.web.views.logs import LogMasterView
from wuttafarm.db.model import ObservationLog


class ObservationLogView(LogMasterView):
    """
    Master view for Observation Logs
    """

    model_class = ObservationLog
    route_prefix = "logs_observation"
    url_prefix = "/logs/observation"

    farmos_bundle = "observation"
    farmos_refurl_path = "/logs/observation"

    grid_columns = [
        "status",
        "drupal_id",
        "timestamp",
        "message",
        "assets",
        "locations",
        "groups",
        "is_group_assignment",
        "owners",
    ]


def defaults(config, **kwargs):
    base = globals()

    ObservationLogView = kwargs.get("ObservationLogView", base["ObservationLogView"])
    ObservationLogView.defaults(config)


def includeme(config):
    defaults(config)
