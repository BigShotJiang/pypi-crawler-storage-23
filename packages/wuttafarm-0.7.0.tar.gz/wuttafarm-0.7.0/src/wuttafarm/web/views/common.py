# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Common views
"""

from wuttaweb.views import common as base


class CommonView(base.CommonView):
    """
    Common views
    """

    def setup_enhance_admin_user(self, user):
        """ """
        model = self.app.model
        session = self.app.get_session(user)
        auth = self.app.get_auth_handler()

        # initialize built-in roles
        farm_manager = auth.get_role_farm_manager(session)
        farm_manager.notes = "this is meant to mirror the corresponding role in farmOS"
        farm_worker = auth.get_role_farm_worker(session)
        farm_worker.notes = "this is meant to mirror the corresponding role in farmOS"
        farm_viewer = auth.get_role_farm_viewer(session)
        farm_viewer.notes = "this is meant to mirror the corresponding role in farmOS"

        # create system user to represent farmOS
        auth.make_user(session, username="farmos", prevent_edit=True)

        site_admin = session.query(model.Role).filter_by(name="Site Admin").first()
        if site_admin:
            site_admin_perms = [
                "animal_types.create",
                "animal_types.edit",
                "animal_types.list",
                "animal_types.view",
                "animal_types.versions",
                "animal_assets.create",
                "animal_assets.edit",
                "animal_assets.list",
                "animal_assets.view",
                "animal_assets.versions",
                "assets.list",
                "asset_types.list",
                "asset_types.view",
                "asset_types.versions",
                "farmos_animal_assets.list",
                "farmos_animal_assets.view",
                "farmos_animal_types.list",
                "farmos_animal_types.view",
                "farmos_asset_types.list",
                "farmos_asset_types.view",
                "farmos_group_assets.list",
                "farmos_group_assets.view",
                "farmos_land_assets.list",
                "farmos_land_assets.view",
                "farmos_land_types.list",
                "farmos_land_types.view",
                "farmos_log_types.list",
                "farmos_log_types.view",
                "farmos_logs_activity.list",
                "farmos_logs_activity.view",
                "farmos_logs_harvest.list",
                "farmos_logs_harvest.view",
                "farmos_logs_medical.list",
                "farmos_logs_medical.view",
                "farmos_logs_observation.list",
                "farmos_logs_observation.view",
                "farmos_plant_assets.list",
                "farmos_plant_assets.view",
                "farmos_plant_types.list",
                "farmos_plant_types.view",
                "farmos_quantities_standard.list",
                "farmos_quantities_standard.view",
                "farmos_quantity_types.list",
                "farmos_quantity_types.view",
                "farmos_structure_assets.list",
                "farmos_structure_assets.view",
                "farmos_structure_types.list",
                "farmos_structure_types.view",
                "farmos_units.list",
                "farmos_units.view",
                "farmos_users.list",
                "farmos_users.view",
                "group_assets.create",
                "group_assets.edit",
                "group_assets.list",
                "group_assets.view",
                "group_assets.versions",
                "land_assets.create",
                "land_assets.edit",
                "land_assets.list",
                "land_assets.view",
                "land_assets.versions",
                "land_types.list",
                "land_types.view",
                "land_types.versions",
                "log_types.list",
                "log_types.view",
                "log_types.versions",
                "logs_activity.list",
                "logs_activity.view",
                "logs_activity.versions",
                "logs_harvest.list",
                "logs_harvest.view",
                "logs_harvest.versions",
                "logs_medical.list",
                "logs_medical.view",
                "logs_medical.versions",
                "logs_observation.list",
                "logs_observation.view",
                "logs_observation.versions",
                "quick.eggs",
                "structure_types.list",
                "structure_types.view",
                "structure_types.versions",
                "structure_assets.create",
                "structure_assets.edit",
                "structure_assets.list",
                "structure_assets.view",
                "structure_assets.versions",
                "units.create",
                "units.edit",
                "units.list",
                "units.view",
                "units.versions",
            ]
            for perm in site_admin_perms:
                auth.grant_permission(site_admin, perm)


def defaults(config, **kwargs):
    local = globals()
    CommonView = kwargs.get("CommonView", local["CommonView"])
    base.defaults(config, **{"CommonView": CommonView})


def includeme(config):
    defaults(config)
