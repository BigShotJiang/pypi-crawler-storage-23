# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Custom views for Settings
"""

from webhelpers2.html import tags

from wuttaweb.views import settings as base

from wuttafarm.web.util import use_farmos_style_grid_links


class AppInfoView(base.AppInfoView):
    """
    Custom appinfo view
    """

    def get_appinfo_dict(self):
        info = super().get_appinfo_dict()
        enum = self.app.enum

        mode = self.config.get(
            f"{self.app.appname}.farmos_integration_mode", default="wrapper"
        )

        info["farmos_integration"] = {
            "label": "farmOS Integration",
            "value": enum.FARMOS_INTEGRATION_MODE.get(mode, mode),
        }

        url = self.app.get_farmos_url()
        info["farmos_url"] = {
            "label": "farmOS URL",
            "value": tags.link_to(url, url, target="_blank"),
        }

        return info

    def configure_get_simple_settings(self):  # pylint: disable=empty-docstring
        farmos = self.app.get_farmos_handler()
        simple_settings = super().configure_get_simple_settings()
        simple_settings.extend(
            [
                {
                    "name": "farmos.url.base",
                },
                {
                    "name": "farmos.oauth2.client_id",
                    "default": farmos.get_oauth2_client_id(),
                },
                {
                    "name": "farmos.oauth2.scope",
                    "default": farmos.get_oauth2_scope(),
                },
                {
                    "name": f"{self.app.appname}.farmos_integration_mode",
                    "default": self.app.get_farmos_integration_mode(),
                },
                {
                    "name": f"{self.app.appname}.farmos_style_grid_links",
                    "type": bool,
                    "default": use_farmos_style_grid_links(self.config),
                },
            ]
        )
        return simple_settings


def defaults(config, **kwargs):
    local = globals()
    AppInfoView = kwargs.get("AppInfoView", local["AppInfoView"])
    base.defaults(config, **{"AppInfoView": AppInfoView})


def includeme(config):
    defaults(config)
