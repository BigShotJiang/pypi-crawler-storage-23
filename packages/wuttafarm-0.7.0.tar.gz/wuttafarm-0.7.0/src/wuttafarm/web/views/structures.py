# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Structures
"""

from wuttafarm.web.views.assets import AssetTypeMasterView, AssetMasterView
from wuttafarm.db.model import StructureType, StructureAsset
from wuttafarm.web.forms.schema import StructureTypeRef
from wuttafarm.web.forms.widgets import ImageWidget


class StructureTypeView(AssetTypeMasterView):
    """
    Master view for Structure Types
    """

    model_class = StructureType
    route_prefix = "structure_types"
    url_prefix = "/structure-types"

    grid_columns = [
        "name",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "drupal_id",
        "farmos_uuid",
    ]

    has_rows = True
    row_model_class = StructureAsset
    rows_viewable = True

    row_grid_columns = [
        "asset_name",
        "is_location",
        "is_fixed",
        "archived",
    ]

    rows_sort_defaults = "asset_name"

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")

    def get_xref_buttons(self, structure_type):
        buttons = super().get_xref_buttons(structure_type)

        if structure_type.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_structure_types.view", uuid=structure_type.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons

    def get_row_grid_data(self, structure_type):
        model = self.app.model
        session = self.Session()
        return (
            session.query(model.StructureAsset)
            .join(model.Asset)
            .filter(model.StructureAsset.structure_type == structure_type)
        )

    def configure_row_grid(self, grid):
        g = grid
        super().configure_row_grid(g)
        model = self.app.model

        # asset_name
        g.set_link("asset_name")
        g.set_sorter("asset_name", model.Asset.asset_name)
        g.set_filter("asset_name", model.Asset.asset_name)

        # is_location
        g.set_renderer("is_location", "boolean")
        g.set_sorter("is_location", model.Asset.is_location)
        g.set_filter("is_location", model.Asset.is_location)

        # is_fixed
        g.set_renderer("is_fixed", "boolean")
        g.set_sorter("is_fixed", model.Asset.is_fixed)
        g.set_filter("is_fixed", model.Asset.is_fixed)

        # archived
        g.set_renderer("archived", "boolean")
        g.set_sorter("archived", model.Asset.archived)
        g.set_filter("archived", model.Asset.archived)

    def get_row_action_url_view(self, structure, i):
        return self.request.route_url("structure_assets.view", uuid=structure.uuid)

    @classmethod
    def defaults(cls, config):
        """ """
        wutta_config = config.registry.settings.get("wutta_config")
        app = wutta_config.get_app()

        if app.is_farmos_mirror():
            cls.creatable = False
            cls.editable = False
            cls.deletable = False

        cls._defaults(config)


class StructureAssetView(AssetMasterView):
    """
    Master view for Structures
    """

    model_class = StructureAsset
    route_prefix = "structure_assets"
    url_prefix = "/asset/structures"

    farmos_bundle = "structure"
    farmos_refurl_path = "/assets/structure"

    grid_columns = [
        "thumbnail",
        "drupal_id",
        "asset_name",
        "structure_type",
        "parents",
        "owners",
        "archived",
    ]

    form_fields = [
        "asset_name",
        "parents",
        "notes",
        "asset_type",
        "structure_type",
        "is_location",
        "is_fixed",
        "archived",
        "drupal_id",
        "farmos_uuid",
        "thumbnail_url",
        "image_url",
        "thumbnail",
        "image",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)
        model = self.app.model

        # structure_type
        g.set_joiner("structure_type", lambda q: q.join(model.StructureType))
        g.set_sorter("structure_type", model.StructureType.name)
        g.set_filter(
            "structure_type", model.StructureType.name, label="Structure Type Name"
        )

    def configure_form(self, form):
        f = form
        super().configure_form(f)
        structure = form.model_instance

        # structure_type
        f.set_node("structure_type", StructureTypeRef(self.request))


def defaults(config, **kwargs):
    base = globals()

    StructureTypeView = kwargs.get("StructureTypeView", base["StructureTypeView"])
    StructureTypeView.defaults(config)

    StructureAssetView = kwargs.get("StructureAssetView", base["StructureAssetView"])
    StructureAssetView.defaults(config)


def includeme(config):
    defaults(config)
