# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm Menu
"""

from wuttaweb import menus as base


class WuttaFarmMenuHandler(base.MenuHandler):
    """
    WuttaFarm menu handler
    """

    def make_menus(self, request, **kwargs):
        enum = self.app.enum
        mode = self.app.get_farmos_integration_mode()

        quick_menu = self.make_quick_menu(request)
        admin_menu = self.make_admin_menu(request, include_people=True)

        if mode == enum.FARMOS_INTEGRATION_MODE_WRAPPER:
            return [
                quick_menu,
                self.make_farmos_asset_menu(request),
                self.make_farmos_log_menu(request),
                self.make_farmos_other_menu(request),
                admin_menu,
            ]

        elif mode == enum.FARMOS_INTEGRATION_MODE_MIRROR:
            return [
                quick_menu,
                self.make_asset_menu(request),
                self.make_log_menu(request),
                self.make_farmos_full_menu(request),
                admin_menu,
            ]

        else:  # FARMOS_INTEGRATION_MODE_NONE
            return [
                quick_menu,
                self.make_asset_menu(request),
                self.make_log_menu(request),
                admin_menu,
            ]

    def make_quick_menu(self, request):
        return {
            "title": "Quick",
            "type": "menu",
            "items": [
                {
                    "title": "Eggs",
                    "route": "quick.eggs",
                    "perm": "quick.eggs",
                },
            ],
        }

    def make_asset_menu(self, request):
        return {
            "title": "Assets",
            "type": "menu",
            "items": [
                {
                    "title": "All Assets",
                    "route": "assets",
                    "perm": "assets.list",
                },
                {
                    "title": "Animal",
                    "route": "animal_assets",
                    "perm": "animal_assets.list",
                },
                {
                    "title": "Group",
                    "route": "group_assets",
                    "perm": "group_assets.list",
                },
                {
                    "title": "Land",
                    "route": "land_assets",
                    "perm": "land_assets.list",
                },
                {
                    "title": "Plant",
                    "route": "plant_assets",
                    "perm": "plant_assets.list",
                },
                {
                    "title": "Structure",
                    "route": "structure_assets",
                    "perm": "structure_assets.list",
                },
                {"type": "sep"},
                {
                    "title": "Animal Types",
                    "route": "animal_types",
                    "perm": "animal_types.list",
                },
                {
                    "title": "Land Types",
                    "route": "land_types",
                    "perm": "land_types.list",
                },
                {
                    "title": "Plant Types",
                    "route": "plant_types",
                    "perm": "plant_types.list",
                },
                {
                    "title": "Structure Types",
                    "route": "structure_types",
                    "perm": "structure_types.list",
                },
                {
                    "title": "Asset Types",
                    "route": "asset_types",
                    "perm": "asset_types.list",
                },
            ],
        }

    def make_log_menu(self, request):
        return {
            "title": "Logs",
            "type": "menu",
            "items": [
                {
                    "title": "All Logs",
                    "route": "log",
                    "perm": "log.list",
                },
                {
                    "title": "Activity",
                    "route": "logs_activity",
                    "perm": "logs_activity.list",
                },
                {
                    "title": "Harvest",
                    "route": "logs_harvest",
                    "perm": "logs_harvest.list",
                },
                {
                    "title": "Medical",
                    "route": "logs_medical",
                    "perm": "logs_medical.list",
                },
                {
                    "title": "Observation",
                    "route": "logs_observation",
                    "perm": "logs_observation.list",
                },
                {"type": "sep"},
                {
                    "title": "All Quantities",
                    "route": "quantities",
                    "perm": "quantities.list",
                },
                {
                    "title": "Standard Quantities",
                    "route": "quantities_standard",
                    "perm": "quantities_standard.list",
                },
                {"type": "sep"},
                {
                    "title": "Log Types",
                    "route": "log_types",
                    "perm": "log_types.list",
                },
                {
                    "title": "Measures",
                    "route": "measures",
                    "perm": "measures.list",
                },
                {
                    "title": "Quantity Types",
                    "route": "quantity_types",
                    "perm": "quantity_types.list",
                },
                {
                    "title": "Units",
                    "route": "units",
                    "perm": "units.list",
                },
            ],
        }

    def make_farmos_full_menu(self, request):
        config = request.wutta_config
        app = config.get_app()
        return {
            "title": "farmOS",
            "type": "menu",
            "items": [
                {
                    "title": "Go to farmOS",
                    "url": app.get_farmos_url(),
                    "target": "_blank",
                },
                {"type": "sep"},
                {
                    "title": "Animal Assets",
                    "route": "farmos_animal_assets",
                    "perm": "farmos_animal_assets.list",
                },
                {
                    "title": "Group Assets",
                    "route": "farmos_group_assets",
                    "perm": "farmos_group_assets.list",
                },
                {
                    "title": "Land Assets",
                    "route": "farmos_land_assets",
                    "perm": "farmos_land_assets.list",
                },
                {
                    "title": "Plant Assets",
                    "route": "farmos_plant_assets",
                    "perm": "farmos_plant_assets.list",
                },
                {
                    "title": "Structure Assets",
                    "route": "farmos_structure_assets",
                    "perm": "farmos_structure_assets.list",
                },
                {"type": "sep"},
                {
                    "title": "Activity Logs",
                    "route": "farmos_logs_activity",
                    "perm": "farmos_logs_activity.list",
                },
                {
                    "title": "Harvest Logs",
                    "route": "farmos_logs_harvest",
                    "perm": "farmos_logs_harvest.list",
                },
                {
                    "title": "Medical Logs",
                    "route": "farmos_logs_medical",
                    "perm": "farmos_logs_medical.list",
                },
                {
                    "title": "Observation Logs",
                    "route": "farmos_logs_observation",
                    "perm": "farmos_logs_observation.list",
                },
                {"type": "sep"},
                {
                    "title": "Animal Types",
                    "route": "farmos_animal_types",
                    "perm": "farmos_animal_types.list",
                },
                {
                    "title": "Land Types",
                    "route": "farmos_land_types",
                    "perm": "farmos_land_types.list",
                },
                {
                    "title": "Plant Types",
                    "route": "farmos_plant_types",
                    "perm": "farmos_plant_types.list",
                },
                {
                    "title": "Structure Types",
                    "route": "farmos_structure_types",
                    "perm": "farmos_structure_types.list",
                },
                {"type": "sep"},
                {
                    "title": "Asset Types",
                    "route": "farmos_asset_types",
                    "perm": "farmos_asset_types.list",
                },
                {
                    "title": "Log Types",
                    "route": "farmos_log_types",
                    "perm": "farmos_log_types.list",
                },
                {
                    "title": "Quantity Types",
                    "route": "farmos_quantity_types",
                    "perm": "farmos_quantity_types.list",
                },
                {
                    "title": "Standard Quantities",
                    "route": "farmos_quantities_standard",
                    "perm": "farmos_quantities_standard.list",
                },
                {
                    "title": "Units",
                    "route": "farmos_units",
                    "perm": "farmos_units.list",
                },
                {"type": "sep"},
                {
                    "title": "Users",
                    "route": "farmos_users",
                    "perm": "farmos_users.list",
                },
            ],
        }

    def make_farmos_asset_menu(self, request):
        config = request.wutta_config
        app = config.get_app()
        return {
            "title": "Assets",
            "type": "menu",
            "items": [
                {
                    "title": "Animal",
                    "route": "farmos_animal_assets",
                    "perm": "farmos_animal_assets.list",
                },
                {
                    "title": "Group",
                    "route": "farmos_group_assets",
                    "perm": "farmos_group_assets.list",
                },
                {
                    "title": "Land",
                    "route": "farmos_land_assets",
                    "perm": "farmos_land_assets.list",
                },
                {
                    "title": "Plant",
                    "route": "farmos_plant_assets",
                    "perm": "farmos_plant_assets.list",
                },
                {
                    "title": "Structure",
                    "route": "farmos_structure_assets",
                    "perm": "farmos_structure_assets.list",
                },
                {"type": "sep"},
                {
                    "title": "Animal Types",
                    "route": "farmos_animal_types",
                    "perm": "farmos_animal_types.list",
                },
                {
                    "title": "Land Types",
                    "route": "farmos_land_types",
                    "perm": "farmos_land_types.list",
                },
                {
                    "title": "Plant Types",
                    "route": "farmos_plant_types",
                    "perm": "farmos_plant_types.list",
                },
                {
                    "title": "Structure Types",
                    "route": "farmos_structure_types",
                    "perm": "farmos_structure_types.list",
                },
                {"type": "sep"},
                {
                    "title": "Asset Types",
                    "route": "farmos_asset_types",
                    "perm": "farmos_asset_types.list",
                },
            ],
        }

    def make_farmos_log_menu(self, request):
        config = request.wutta_config
        app = config.get_app()
        return {
            "title": "Logs",
            "type": "menu",
            "items": [
                {
                    "title": "Activity",
                    "route": "farmos_logs_activity",
                    "perm": "farmos_logs_activity.list",
                },
                {
                    "title": "Harvest",
                    "route": "farmos_logs_harvest",
                    "perm": "farmos_logs_harvest.list",
                },
                {
                    "title": "Medical",
                    "route": "farmos_logs_medical",
                    "perm": "farmos_logs_medical.list",
                },
                {
                    "title": "Observation",
                    "route": "farmos_logs_observation",
                    "perm": "farmos_logs_observation.list",
                },
                {"type": "sep"},
                {
                    "title": "Log Types",
                    "route": "farmos_log_types",
                    "perm": "farmos_log_types.list",
                },
                {
                    "title": "Quantity Types",
                    "route": "farmos_quantity_types",
                    "perm": "farmos_quantity_types.list",
                },
                {
                    "title": "Standard Quantities",
                    "route": "farmos_quantities_standard",
                    "perm": "farmos_quantities_standard.list",
                },
                {
                    "title": "Units",
                    "route": "farmos_units",
                    "perm": "farmos_units.list",
                },
            ],
        }

    def make_farmos_other_menu(self, request):
        config = request.wutta_config
        app = config.get_app()
        return {
            "title": "farmOS",
            "type": "menu",
            "items": [
                {
                    "title": "Go to farmOS",
                    "url": app.get_farmos_url(),
                    "target": "_blank",
                },
                {"type": "sep"},
                {
                    "title": "Users",
                    "route": "farmos_users",
                    "perm": "farmos_users.list",
                },
            ],
        }
