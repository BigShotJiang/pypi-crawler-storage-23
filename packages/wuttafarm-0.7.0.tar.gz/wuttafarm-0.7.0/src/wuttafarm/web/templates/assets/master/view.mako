## -*- coding: utf-8; -*-
<%inherit file="/master/view.mako" />

<%def name="page_content()">

  % if instance.archived:
      <b-notification type="is-warning">
         This asset is archived.
         Archived assets should only be edited if they need corrections.
      </b-notification>
  % endif

  ${parent.page_content()}
</%def>
