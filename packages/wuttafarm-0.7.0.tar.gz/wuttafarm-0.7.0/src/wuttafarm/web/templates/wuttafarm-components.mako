
<%def name="make_wuttafarm_components()">
  ${self.make_animal_type_picker_component()}
  ${self.make_plant_types_picker_component()}
</%def>

<%def name="make_animal_type_picker_component()">
  <script type="text/x-template" id="animal-type-picker-template">
    <div>
      <div style="display: flex; gap: 0.5rem;">

        <b-select :name="name"
                  :value="internalValue"
                  @input="val => $emit('input', val)"
                  style="flex-grow: 1;">
          <option v-for="atype in internalAnimalTypes"
                  :value="atype[0]">
            {{ atype[1] }}
          </option>
        </b-select>

        <b-button v-if="canCreate"
                  type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>
      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New Animal Type</p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const AnimalTypePicker = {
        template: '#animal-type-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: String,
            animalTypes: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                internalAnimalTypes: this.animalTypes,
                internalValue: this.value,
                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        methods: {

            createInit(name) {
                this.createName = name || null
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                const url = "${url('animal_types.ajax_create')}"
                const params = {name: this.createName}
                this.wuttaPOST(url, params, response => {
                    this.internalAnimalTypes.push([response.data.uuid, response.data.name])
                    this.$nextTick(() => {
                        this.internalValue = response.data.uuid
                        this.createSaving = false
                        this.createShowDialog = false
                    })
                }, response => {
                    this.createSaving = false
                })
            },
        },
    }
    Vue.component('animal-type-picker', AnimalTypePicker)
    <% request.register_component('animal-type-picker', 'AnimalTypePicker') %>
  </script>
</%def>

<%def name="make_plant_types_picker_component()">
  <script type="text/x-template" id="plant-types-picker-template">
    <div>
      <input type="hidden" :name="name" :value="value" />

      <div style="display: flex; gap: 0.5rem; align-items: center;">

        <span>Add:</span>

        <b-autocomplete v-model="addName"
                        ref="addName"
                        :data="addNameData"
                        field="name"
                        open-on-focus
                        keep-first
                        @select="addNameSelected"
                        clear-on-select
                        style="flex-grow: 1;">
          <template #empty>No results found</template>
        </b-autocomplete>

        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="plus"
                  @click="createInit()">
          New
        </b-button>

      </div>

      <${b}-table :data="plantTypeData">

        <${b}-table-column field="name" v-slot="props">
          <span>{{ props.row.name }}</span>
        </${b}-table-column>

        <${b}-table-column v-slot="props">
            <a href="#"
               class="has-text-danger"
               @click.prevent="removePlantType(props.row)">
              <i class="fas fa-trash" /> &nbsp; Remove
            </a>
        </${b}-table-column>

      </${b}-table>

      <${b}-modal v-if="canCreate"
                  has-modal-card
                  % if request.use_oruga:
                  v-model:active="createShowDialog"
                  % else:
                  :active.sync="createShowDialog"
                  % endif
                  >
        <div class="modal-card">

          <header class="modal-card-head">
            <p class="modal-card-title">New Plant Type</p>
          </header>

          <section class="modal-card-body">
            <b-field label="Name" horizontal>
              <b-input v-model="createName"
                       ref="createName"
                       expanded
                       @keydown.native="createNameKeydown" />
            </b-field>
          </section>

          <footer class="modal-card-foot">
            <b-button type="is-primary"
                      @click="createSave()"
                      :disabled="createSaving || !createName"
                      icon-pack="fas"
                      icon-left="save">
              {{ createSaving ? "Working, please wait..." : "Save" }}
            </b-button>
            <b-button @click="createShowDialog = false">
              Cancel
            </b-button>
          </footer>
        </div>
      </${b}-modal>
    </div>
  </script>
  <script>
    const PlantTypesPicker = {
        template: '#plant-types-picker-template',
        mixins: [WuttaRequestMixin],
        props: {
            name: String,
            value: Array,
            plantTypes: Array,
            canCreate: Boolean,
        },
        data() {
            return {
                internalPlantTypes: this.plantTypes.map((pt) => {
                    return {uuid: pt[0], name: pt[1]}
                }),

                addShowDialog: false,
                addName: '',

                createShowDialog: false,
                createName: null,
                createSaving: false,
            }
        },
        computed: {
            plantTypeData() {
                const data = []

                if (this.value) {
                    for (let ptype of this.internalPlantTypes) {
                        // ptype = {uuid: ptype[0], name: ptype[1]}
                        if (this.value.includes(ptype.uuid)) {
                            data.push(ptype)
                        }
                    }
                }

                return data
            },
            addNameData() {
                if (!this.addName) {
                    return this.internalPlantTypes
                }

                return this.internalPlantTypes.filter((ptype) => {
                    return ptype.name.toLowerCase().indexOf(this.addName.toLowerCase()) >= 0
                })
            },
        },
        methods: {

            addNameSelected(option) {
                const value = Array.from(this.value || [])

                if (!value.includes(option.uuid)) {
                    value.push(option.uuid)
                    this.$emit('input', value)
                }

                this.addName = null
            },

            createInit() {
                this.createName = this.addName
                this.createShowDialog = true
                this.$nextTick(() => {
                    this.$refs.createName.focus()
                })
            },

            createNameKeydown(event) {
                // nb. must prevent main form submit on ENTER
                // (since ultimately this lives within an outer form)
                // but also we can submit the modal pseudo-form
                if (event.which == 13) {
                    event.preventDefault()
                    this.createSave()
                }
            },

            createSave() {
                this.createSaving = true
                const url = "${url('plant_types.ajax_create')}"
                const params = {name: this.createName}
                this.wuttaPOST(url, params, response => {
                    this.internalPlantTypes.push(response.data)
                    const value = Array.from(this.value || [])
                    value.push(response.data.uuid)
                    this.$emit('input', value)
                    this.addName = null
                    this.createSaving = false
                    this.createShowDialog = false
                }, response => {
                    this.createSaving = false
                })
            },

            removePlantType(ptype) {
                let value = Array.from(this.value)
                const i = value.indexOf(ptype.uuid)
                value.splice(i, 1)
                this.$emit('input', value)
            },
        },
    }
    Vue.component('plant-types-picker', PlantTypesPicker)
    <% request.register_component('plant-types-picker', 'PlantTypesPicker') %>
  </script>
</%def>
