## -*- coding: utf-8; -*-
<%inherit file="/master/view.mako" />

<%def name="tool_panels()">
  ${parent.tool_panels()}
  ${self.tool_panel_tools()}
</%def>

<%def name="tool_panel_tools()">
  % if raw_json:

      <wutta-tool-panel heading="Tools">
        <b-button type="is-primary"
                  icon-pack="fas"
                  icon-left="code"
                  @click="viewJsonShowDialog = true">
          See raw JSON data
        </b-button>
      </wutta-tool-panel>

      <${b}-modal :width="1200"
                  % if request.use_oruga:
                  v-model:active="viewJsonShowDialog"
                  % else:
                  :active.sync="viewJsonShowDialog"
                  % endif
                  >
        <div class="card">
          <div class="card-content">
            ${rendered_json|n}
          </div>
        </div>
      </${b}-modal>

  % endif
</%def>

<%def name="modify_vue_vars()">
  ${parent.modify_vue_vars()}
  % if raw_json:
      <script>
        ThisPageData.viewJsonShowDialog = false
      </script>
  % endif
</%def>
