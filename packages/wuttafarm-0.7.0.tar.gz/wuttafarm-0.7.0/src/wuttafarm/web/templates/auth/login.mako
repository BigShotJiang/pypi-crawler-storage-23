## -*- coding: utf-8; -*-
<%inherit file="wuttaweb:templates/auth/login.mako" />
<%namespace name="base_meta" file="/base_meta.mako" />

<%def name="page_content()">
  <div class="wutta-page-content">
    <div class="wutta-logo">${base_meta.full_logo(image_url or None)}</div>
    <div style="display: flex; gap: 1rem; align-items: center;">

        <div class="card">
          <div class="card-content">
            ${form.render_vue_tag()}
          </div>
        </div>

        <div class="has-text-italic">
          - OR -
        </div>

        <div class="card">
          <div class="card-content">
            <wutta-button type="is-primary"
                          tag="a"
                          href="${url('farmos_oauth_login')}"
                          icon-left="user"
                          label="Login via farmOS / OAuth2"
                          once />
          </div>
        </div>

    </div>
  </div>
</%def>
