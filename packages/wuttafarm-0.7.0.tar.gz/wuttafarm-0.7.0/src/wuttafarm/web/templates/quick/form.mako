<%inherit file="/form.mako" />

<%def name="title()">${index_title} &raquo; ${form_title}</%def>

<%def name="content_title()">${form_title}</%def>

<%def name="render_form_tag()">

  <p class="block">
    ${help_text}
  </p>

  ${parent.render_form_tag()}
</%def>
