## -*- coding: utf-8; -*-
<%inherit file="wuttaweb:templates/appinfo/configure.mako" />

<%def name="form_content()">
  ${parent.form_content()}

  <h3 class="block is-size-3">farmOS</h3>
  <div class="block" style="padding-left: 2rem; width: 50%;">

    <b-field label="farmOS URL">
      <b-input name="farmos.url.base"
               v-model="simpleSettings['farmos.url.base']"
               @input="settingsNeedSaved = true">
      </b-input>
    </b-field>

    <b-field grouped>

      <b-field label="OAuth2 Client ID">
        <b-input name="farmos.oauth2.client_id"
                 v-model="simpleSettings['farmos.oauth2.client_id']"
                 @input="settingsNeedSaved = true">
        </b-input>
      </b-field>

      <b-field label="OAuth2 Scope">
        <b-input name="farmos.oauth2.scope"
                 v-model="simpleSettings['farmos.oauth2.scope']"
                 @input="settingsNeedSaved = true">
        </b-input>
      </b-field>

    </b-field>

    <b-field label="OAuth2 Redirect URI">
      <wutta-copyable-text text="${url('farmos_oauth_callback')}" />
    </b-field>

    <b-field label="farmOS Integration Mode">
      <div style="display: flex; gap: 0.5rem; align-items: center;">
        <b-select name="${app.appname}.farmos_integration_mode"
                  v-model="simpleSettings['${app.appname}.farmos_integration_mode']"
                  @input="settingsNeedSaved = true">
          % for value, label in enum.FARMOS_INTEGRATION_MODE.items():
              <option value="${value}">${label}</option>
          % endfor
        </b-select>
        <${b}-tooltip position="${'right' if request.use_oruga else 'is-right'}">
          <b-icon pack="fas" icon="info-circle" type="is-warning" />
          <template #content>
            <p class="block">
              <span class="has-text-weight-bold">RESTART IS REQUIRED</span>
              if you change the integration mode.
            </p>
          </template>
        </${b}-tooltip>
      </div>
    </b-field>

    <b-checkbox name="${app.appname}.farmos_style_grid_links"
                v-model="simpleSettings['${app.appname}.farmos_style_grid_links']"
                native-value="true"
                @input="settingsNeedSaved = true">
      Use farmOS-style grid links
    </b-checkbox>
    <${b}-tooltip position="${'right' if request.use_oruga else 'is-right'}">
      <b-icon pack="fas" icon="info-circle" />
      <template #content>
        <p class="block">
          If set, certain column values in a grid may link
          to <span class="has-text-weight-bold">related</span>
          records.
        </p>
        <p class="block">
          If not set, column values will only link to view the
          <span class="has-text-weight-bold">current</span> record.
        </p>
      </template>
    </${b}-tooltip>

  </div>
</%def>
