"""add generic log base

Revision ID: dd6351e69233
Revises: b8cd4a8f981f
Create Date: 2026-02-18 12:09:05.200134

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "dd6351e69233"
down_revision: Union[str, None] = "b8cd4a8f981f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log
    op.create_table(
        "log",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_type", sa.String(length=100), nullable=False),
        sa.Column("message", sa.String(length=255), nullable=False),
        sa.Column("timestamp", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["log_type"], ["log_type.drupal_id"], name=op.f("fk_log_log_type_log_type")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_log_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_log_farmos_uuid")),
    )
    op.create_table(
        "log_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_type", sa.String(length=100), autoincrement=False, nullable=True
        ),
        sa.Column("message", sa.String(length=255), autoincrement=False, nullable=True),
        sa.Column("timestamp", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column("status", sa.String(length=20), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint("uuid", "transaction_id", name=op.f("pk_log_version")),
    )
    op.create_index(
        op.f("ix_log_version_end_transaction_id"),
        "log_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_version_operation_type"),
        "log_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_version_pk_transaction_id",
        "log_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_version_pk_validity",
        "log_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_version_transaction_id"),
        "log_version",
        ["transaction_id"],
        unique=False,
    )

    # log_activity
    op.drop_column("log_activity_version", "status")
    op.drop_column("log_activity_version", "farmos_uuid")
    op.drop_column("log_activity_version", "timestamp")
    op.drop_column("log_activity_version", "message")
    op.drop_column("log_activity_version", "drupal_id")
    op.drop_column("log_activity_version", "notes")
    op.drop_constraint(
        op.f("uq_log_activity_drupal_id"), "log_activity", type_="unique"
    )
    op.drop_constraint(
        op.f("uq_log_activity_farmos_uuid"), "log_activity", type_="unique"
    )
    op.create_foreign_key(
        op.f("fk_log_activity_uuid_log"), "log_activity", "log", ["uuid"], ["uuid"]
    )
    op.drop_column("log_activity", "status")
    op.drop_column("log_activity", "farmos_uuid")
    op.drop_column("log_activity", "timestamp")
    op.drop_column("log_activity", "message")
    op.drop_column("log_activity", "drupal_id")
    op.drop_column("log_activity", "notes")


def downgrade() -> None:

    # log_activity
    op.add_column(
        "log_activity",
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity",
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity",
        sa.Column(
            "message", sa.VARCHAR(length=255), autoincrement=False, nullable=False
        ),
    )
    op.add_column(
        "log_activity",
        sa.Column(
            "timestamp", postgresql.TIMESTAMP(), autoincrement=False, nullable=False
        ),
    )
    op.add_column(
        "log_activity",
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity",
        sa.Column("status", sa.VARCHAR(length=20), autoincrement=False, nullable=False),
    )
    op.drop_constraint(
        op.f("fk_log_activity_uuid_log"), "log_activity", type_="foreignkey"
    )
    op.create_unique_constraint(
        op.f("uq_log_activity_farmos_uuid"),
        "log_activity",
        ["farmos_uuid"],
        postgresql_nulls_not_distinct=False,
    )
    op.create_unique_constraint(
        op.f("uq_log_activity_drupal_id"),
        "log_activity",
        ["drupal_id"],
        postgresql_nulls_not_distinct=False,
    )
    op.add_column(
        "log_activity_version",
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity_version",
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity_version",
        sa.Column(
            "message", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
    )
    op.add_column(
        "log_activity_version",
        sa.Column(
            "timestamp", postgresql.TIMESTAMP(), autoincrement=False, nullable=True
        ),
    )
    op.add_column(
        "log_activity_version",
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
    )
    op.add_column(
        "log_activity_version",
        sa.Column("status", sa.VARCHAR(length=20), autoincrement=False, nullable=True),
    )

    # log
    op.drop_index(op.f("ix_log_version_transaction_id"), table_name="log_version")
    op.drop_index("ix_log_version_pk_validity", table_name="log_version")
    op.drop_index("ix_log_version_pk_transaction_id", table_name="log_version")
    op.drop_index(op.f("ix_log_version_operation_type"), table_name="log_version")
    op.drop_index(op.f("ix_log_version_end_transaction_id"), table_name="log_version")
    op.drop_table("log_version")
    op.drop_table("log")
