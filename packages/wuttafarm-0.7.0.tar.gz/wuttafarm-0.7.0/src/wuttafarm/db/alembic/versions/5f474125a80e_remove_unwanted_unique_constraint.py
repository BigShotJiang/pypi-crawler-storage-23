"""remove unwanted unique constraint

Revision ID: 5f474125a80e
Revises: 0771322957bd
Create Date: 2026-03-04 12:03:16.034291

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "5f474125a80e"
down_revision: Union[str, None] = "0771322957bd"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_land
    op.drop_constraint(
        op.f("uq_asset_land_land_type_uuid"), "asset_land", type_="unique"
    )


def downgrade() -> None:

    # asset_land
    op.create_unique_constraint(
        op.f("uq_asset_land_land_type_uuid"),
        "asset_land",
        ["land_type_uuid"],
        postgresql_nulls_not_distinct=False,
    )
