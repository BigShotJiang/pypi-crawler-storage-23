"""add Asset.owners

Revision ID: 12de43facb95
Revises: 85d4851e8292
Create Date: 2026-03-02 19:03:35.511398

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "12de43facb95"
down_revision: Union[str, None] = "85d4851e8292"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_owner
    op.create_table(
        "asset_owner",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("user_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["asset_uuid"], ["asset.uuid"], name=op.f("fk_asset_owner_asset_uuid_asset")
        ),
        sa.ForeignKeyConstraint(
            ["user_uuid"], ["user.uuid"], name=op.f("fk_asset_owner_user_uuid_user")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_owner")),
    )
    op.create_table(
        "asset_owner_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "user_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_owner_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_owner_version_end_transaction_id"),
        "asset_owner_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_owner_version_operation_type"),
        "asset_owner_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_owner_version_pk_transaction_id",
        "asset_owner_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_owner_version_pk_validity",
        "asset_owner_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_owner_version_transaction_id"),
        "asset_owner_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # asset_owner
    op.drop_index(
        op.f("ix_asset_owner_version_transaction_id"), table_name="asset_owner_version"
    )
    op.drop_index(
        "ix_asset_owner_version_pk_validity", table_name="asset_owner_version"
    )
    op.drop_index(
        "ix_asset_owner_version_pk_transaction_id", table_name="asset_owner_version"
    )
    op.drop_index(
        op.f("ix_asset_owner_version_operation_type"), table_name="asset_owner_version"
    )
    op.drop_index(
        op.f("ix_asset_owner_version_end_transaction_id"),
        table_name="asset_owner_version",
    )
    op.drop_table("asset_owner_version")
    op.drop_table("asset_owner")
