"""add LogOwner

Revision ID: 47d0ebd84554
Revises: 45c7718d2ed2
Create Date: 2026-02-28 19:18:49.122090

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "47d0ebd84554"
down_revision: Union[str, None] = "45c7718d2ed2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_owner
    op.create_table(
        "log_owner",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("user_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["log_uuid"], ["log.uuid"], name=op.f("fk_log_owner_log_uuid_log")
        ),
        sa.ForeignKeyConstraint(
            ["user_uuid"], ["user.uuid"], name=op.f("fk_log_owner_user_uuid_user")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_owner")),
    )
    op.create_table(
        "log_owner_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "user_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_owner_version")
        ),
    )
    op.create_index(
        op.f("ix_log_owner_version_end_transaction_id"),
        "log_owner_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_owner_version_operation_type"),
        "log_owner_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_owner_version_pk_transaction_id",
        "log_owner_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_owner_version_pk_validity",
        "log_owner_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_owner_version_transaction_id"),
        "log_owner_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_owner
    op.drop_index(
        op.f("ix_log_owner_version_transaction_id"), table_name="log_owner_version"
    )
    op.drop_index("ix_log_owner_version_pk_validity", table_name="log_owner_version")
    op.drop_index(
        "ix_log_owner_version_pk_transaction_id", table_name="log_owner_version"
    )
    op.drop_index(
        op.f("ix_log_owner_version_operation_type"), table_name="log_owner_version"
    )
    op.drop_index(
        op.f("ix_log_owner_version_end_transaction_id"), table_name="log_owner_version"
    )
    op.drop_table("log_owner_version")
    op.drop_table("log_owner")
