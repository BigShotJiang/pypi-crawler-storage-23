"""add Log.quick

Revision ID: 85d4851e8292
Revises: d459db991404
Create Date: 2026-03-02 18:42:56.070281

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "85d4851e8292"
down_revision: Union[str, None] = "d459db991404"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log
    op.add_column("log", sa.Column("quick", sa.String(length=20), nullable=True))
    op.add_column(
        "log_version",
        sa.Column("quick", sa.String(length=20), autoincrement=False, nullable=True),
    )


def downgrade() -> None:

    # log
    op.drop_column("log_version", "quick")
    op.drop_column("log", "quick")
