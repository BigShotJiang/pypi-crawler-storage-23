"""add Land Assets

Revision ID: e416b96467fc
Revises: e0d9f72575d6
Create Date: 2026-02-13 09:39:31.327442

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "e416b96467fc"
down_revision: Union[str, None] = "e0d9f72575d6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # land_asset
    op.create_table(
        "land_asset",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("land_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("is_location", sa.Boolean(), nullable=False),
        sa.Column("is_fixed", sa.Boolean(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["land_type_uuid"],
            ["land_type.uuid"],
            name=op.f("fk_land_asset_land_type_uuid_land_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_land_asset")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_land_asset_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_land_asset_farmos_uuid")),
        sa.UniqueConstraint(
            "land_type_uuid", name=op.f("uq_land_asset_land_type_uuid")
        ),
        sa.UniqueConstraint("name", name=op.f("uq_land_asset_name")),
    )
    op.create_table(
        "land_asset_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "land_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("is_location", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column("active", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_land_asset_version")
        ),
    )
    op.create_index(
        op.f("ix_land_asset_version_end_transaction_id"),
        "land_asset_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_operation_type"),
        "land_asset_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_land_asset_version_pk_transaction_id",
        "land_asset_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_land_asset_version_pk_validity",
        "land_asset_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_version_transaction_id"),
        "land_asset_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # land_asset
    op.drop_index(
        op.f("ix_land_asset_version_transaction_id"), table_name="land_asset_version"
    )
    op.drop_index("ix_land_asset_version_pk_validity", table_name="land_asset_version")
    op.drop_index(
        "ix_land_asset_version_pk_transaction_id", table_name="land_asset_version"
    )
    op.drop_index(
        op.f("ix_land_asset_version_operation_type"), table_name="land_asset_version"
    )
    op.drop_index(
        op.f("ix_land_asset_version_end_transaction_id"),
        table_name="land_asset_version",
    )
    op.drop_table("land_asset_version")
    op.drop_table("land_asset")
