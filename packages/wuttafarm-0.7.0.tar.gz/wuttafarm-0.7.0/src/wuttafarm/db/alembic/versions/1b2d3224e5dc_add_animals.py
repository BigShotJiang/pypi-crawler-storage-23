"""add Animals

Revision ID: 1b2d3224e5dc
Revises: 4dbba8aeb1e5
Create Date: 2026-02-13 11:55:19.564221

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "1b2d3224e5dc"
down_revision: Union[str, None] = "4dbba8aeb1e5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal
    op.create_table(
        "animal",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("animal_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("birthdate", sa.DateTime(), nullable=True),
        sa.Column("sex", sa.String(length=1), nullable=True),
        sa.Column("is_sterile", sa.Boolean(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("image_url", sa.String(length=255), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(
            ["animal_type_uuid"],
            ["animal_type.uuid"],
            name=op.f("fk_animal_animal_type_uuid_animal_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_animal")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_animal_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_animal_farmos_uuid")),
    )
    op.create_table(
        "animal_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "animal_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("birthdate", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column("sex", sa.String(length=1), autoincrement=False, nullable=True),
        sa.Column("is_sterile", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("active", sa.Boolean(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_animal_version")
        ),
    )
    op.create_index(
        op.f("ix_animal_version_end_transaction_id"),
        "animal_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_operation_type"),
        "animal_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_animal_version_pk_transaction_id",
        "animal_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_animal_version_pk_validity",
        "animal_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_animal_version_transaction_id"),
        "animal_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # animal
    op.drop_index(op.f("ix_animal_version_transaction_id"), table_name="animal_version")
    op.drop_index("ix_animal_version_pk_validity", table_name="animal_version")
    op.drop_index("ix_animal_version_pk_transaction_id", table_name="animal_version")
    op.drop_index(op.f("ix_animal_version_operation_type"), table_name="animal_version")
    op.drop_index(
        op.f("ix_animal_version_end_transaction_id"), table_name="animal_version"
    )
    op.drop_table("animal_version")
    op.drop_table("animal")
