"""add Activity Logs

Revision ID: 3e2ef02bf264
Revises: 92b813360b99
Create Date: 2026-02-13 14:36:47.191922

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "3e2ef02bf264"
down_revision: Union[str, None] = "92b813360b99"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_activity
    op.create_table(
        "log_activity",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("message", sa.String(length=255), nullable=False),
        sa.Column("timestamp", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_activity")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_log_activity_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_log_activity_farmos_uuid")),
    )
    op.create_table(
        "log_activity_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("message", sa.String(length=255), autoincrement=False, nullable=True),
        sa.Column("timestamp", sa.DateTime(), autoincrement=False, nullable=True),
        sa.Column("status", sa.String(length=20), autoincrement=False, nullable=True),
        sa.Column("notes", sa.Text(), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column("drupal_id", sa.Integer(), autoincrement=False, nullable=True),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_activity_version")
        ),
    )
    op.create_index(
        op.f("ix_log_activity_version_end_transaction_id"),
        "log_activity_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_activity_version_operation_type"),
        "log_activity_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_activity_version_pk_transaction_id",
        "log_activity_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_activity_version_pk_validity",
        "log_activity_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_activity_version_transaction_id"),
        "log_activity_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_activity
    op.drop_index(
        op.f("ix_log_activity_version_transaction_id"),
        table_name="log_activity_version",
    )
    op.drop_index(
        "ix_log_activity_version_pk_validity", table_name="log_activity_version"
    )
    op.drop_index(
        "ix_log_activity_version_pk_transaction_id", table_name="log_activity_version"
    )
    op.drop_index(
        op.f("ix_log_activity_version_operation_type"),
        table_name="log_activity_version",
    )
    op.drop_index(
        op.f("ix_log_activity_version_end_transaction_id"),
        table_name="log_activity_version",
    )
    op.drop_table("log_activity_version")
    op.drop_table("log_activity")
