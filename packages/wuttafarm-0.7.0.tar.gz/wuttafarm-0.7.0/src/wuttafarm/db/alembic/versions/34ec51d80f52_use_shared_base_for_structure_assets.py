"""use shared base for Structure Assets

Revision ID: 34ec51d80f52
Revises: d882682c82f9
Create Date: 2026-02-15 13:19:18.814523

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "34ec51d80f52"
down_revision: Union[str, None] = "d882682c82f9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # asset_structure
    op.create_table(
        "asset_structure",
        sa.Column("structure_type_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["structure_type_uuid"],
            ["structure_type.uuid"],
            name=op.f("fk_asset_structure_structure_type_uuid_structure_type"),
        ),
        sa.ForeignKeyConstraint(
            ["uuid"], ["asset.uuid"], name=op.f("fk_asset_structure_uuid_asset")
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_asset_structure")),
    )
    op.create_table(
        "asset_structure_version",
        sa.Column(
            "structure_type_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_asset_structure_version")
        ),
    )
    op.create_index(
        op.f("ix_asset_structure_version_end_transaction_id"),
        "asset_structure_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_structure_version_operation_type"),
        "asset_structure_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_asset_structure_version_pk_transaction_id",
        "asset_structure_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_asset_structure_version_pk_validity",
        "asset_structure_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_asset_structure_version_transaction_id"),
        "asset_structure_version",
        ["transaction_id"],
        unique=False,
    )

    # structure
    op.drop_index(
        op.f("ix_structure_version_end_transaction_id"), table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_operation_type"), table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_pk_transaction_id"), table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_pk_validity"), table_name="structure_version"
    )
    op.drop_index(
        op.f("ix_structure_version_transaction_id"), table_name="structure_version"
    )
    op.drop_table("structure_version")
    op.drop_table("structure")


def downgrade() -> None:

    # structure
    op.create_table(
        "structure",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=False),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column(
            "structure_type_uuid", sa.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("is_location", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("is_fixed", sa.BOOLEAN(), autoincrement=False, nullable=False),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column(
            "thumbnail_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.ForeignKeyConstraint(
            ["structure_type_uuid"],
            ["structure_type.uuid"],
            name=op.f("fk_structure_structure_type_uuid_structure_type"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_structure")),
        sa.UniqueConstraint(
            "drupal_id",
            name=op.f("uq_structure_drupal_id"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "farmos_uuid",
            name=op.f("uq_structure_farmos_uuid"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
        sa.UniqueConstraint(
            "name",
            name=op.f("uq_structure_name"),
            postgresql_include=[],
            postgresql_nulls_not_distinct=False,
        ),
    )
    op.create_table(
        "structure_version",
        sa.Column("uuid", sa.UUID(), autoincrement=False, nullable=False),
        sa.Column("name", sa.VARCHAR(length=100), autoincrement=False, nullable=True),
        sa.Column("archived", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("structure_type_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("is_location", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("is_fixed", sa.BOOLEAN(), autoincrement=False, nullable=True),
        sa.Column("notes", sa.TEXT(), autoincrement=False, nullable=True),
        sa.Column(
            "image_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.Column("farmos_uuid", sa.UUID(), autoincrement=False, nullable=True),
        sa.Column("drupal_id", sa.INTEGER(), autoincrement=False, nullable=True),
        sa.Column("transaction_id", sa.BIGINT(), autoincrement=False, nullable=False),
        sa.Column(
            "end_transaction_id", sa.BIGINT(), autoincrement=False, nullable=True
        ),
        sa.Column("operation_type", sa.SMALLINT(), autoincrement=False, nullable=False),
        sa.Column(
            "thumbnail_url", sa.VARCHAR(length=255), autoincrement=False, nullable=True
        ),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_structure_version")
        ),
    )
    op.create_index(
        op.f("ix_structure_version_transaction_id"),
        "structure_version",
        ["transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_pk_validity"),
        "structure_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_pk_transaction_id"),
        "structure_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_operation_type"),
        "structure_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_version_end_transaction_id"),
        "structure_version",
        ["end_transaction_id"],
        unique=False,
    )

    # asset_structure
    op.drop_index(
        op.f("ix_asset_structure_version_transaction_id"),
        table_name="asset_structure_version",
    )
    op.drop_index(
        "ix_asset_structure_version_pk_validity", table_name="asset_structure_version"
    )
    op.drop_index(
        "ix_asset_structure_version_pk_transaction_id",
        table_name="asset_structure_version",
    )
    op.drop_index(
        op.f("ix_asset_structure_version_operation_type"),
        table_name="asset_structure_version",
    )
    op.drop_index(
        op.f("ix_asset_structure_version_end_transaction_id"),
        table_name="asset_structure_version",
    )
    op.drop_table("asset_structure_version")
    op.drop_table("asset_structure")
