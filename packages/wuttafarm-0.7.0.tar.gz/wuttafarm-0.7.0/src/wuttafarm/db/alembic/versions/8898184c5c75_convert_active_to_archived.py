"""convert active to archived

Revision ID: 8898184c5c75
Revises: 3e2ef02bf264
Create Date: 2026-02-14 18:41:23.042951

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "8898184c5c75"
down_revision: Union[str, None] = "3e2ef02bf264"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal
    op.alter_column("animal", "active", new_column_name="archived")
    animal = sa.sql.table(
        "animal",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(animal.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            animal.update()
            .where(animal.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )
    op.alter_column("animal_version", "active", new_column_name="archived")
    animal_version = sa.sql.table(
        "animal_version",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(animal_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            animal_version.update()
            .where(animal_version.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )

    # group
    op.alter_column("group", "active", new_column_name="archived")
    group = sa.sql.table(
        "group",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(group.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            group.update()
            .where(group.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )
    op.alter_column("group_version", "active", new_column_name="archived")
    group_version = sa.sql.table(
        "group_version",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(group_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            group_version.update()
            .where(group_version.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )

    # land_asset
    op.alter_column("land_asset", "active", new_column_name="archived")
    land_asset = sa.sql.table(
        "land_asset",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(land_asset.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            land_asset.update()
            .where(land_asset.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )
    op.alter_column("land_asset_version", "active", new_column_name="archived")
    land_asset_version = sa.sql.table(
        "land_asset_version",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(land_asset_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            land_asset_version.update()
            .where(land_asset_version.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )

    # structure
    op.alter_column("structure", "active", new_column_name="archived")
    structure = sa.sql.table(
        "structure",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(structure.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            structure.update()
            .where(structure.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )
    op.alter_column("structure_version", "active", new_column_name="archived")
    structure_version = sa.sql.table(
        "structure_version",
        sa.sql.column("uuid"),
        sa.sql.column("archived"),
    )
    cursor = op.get_bind().execute(structure_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            structure_version.update()
            .where(structure_version.c.uuid == row.uuid)
            .values({"archived": not row.archived})
        )


def downgrade() -> None:

    # structure
    op.alter_column("structure", "archived", new_column_name="active")
    structure = sa.sql.table(
        "structure",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(structure.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            structure.update()
            .where(structure.c.uuid == row.uuid)
            .values({"active": not row.active})
        )
    op.alter_column("structure_version", "archived", new_column_name="active")
    structure_version = sa.sql.table(
        "structure_version",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(structure_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            structure_version.update()
            .where(structure_version.c.uuid == row.uuid)
            .values({"active": not row.active})
        )

    # land_asset
    op.alter_column("land_asset", "archived", new_column_name="active")
    land_asset = sa.sql.table(
        "land_asset",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(land_asset.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            land_asset.update()
            .where(land_asset.c.uuid == row.uuid)
            .values({"active": not row.active})
        )
    op.alter_column("land_asset_version", "archived", new_column_name="active")
    land_asset_version = sa.sql.table(
        "land_asset_version",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(land_asset_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            land_asset_version.update()
            .where(land_asset_version.c.uuid == row.uuid)
            .values({"active": not row.active})
        )

    # group
    op.alter_column("group", "archived", new_column_name="active")
    group = sa.sql.table(
        "group",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(group.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            group.update()
            .where(group.c.uuid == row.uuid)
            .values({"active": not row.active})
        )
    op.alter_column("group_version", "archived", new_column_name="active")
    group_version = sa.sql.table(
        "group_version",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(group_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            group_version.update()
            .where(group_version.c.uuid == row.uuid)
            .values({"active": not row.active})
        )

    # animal
    op.alter_column("animal", "archived", new_column_name="active")
    animal = sa.sql.table(
        "animal",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(animal.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            animal.update()
            .where(animal.c.uuid == row.uuid)
            .values({"active": not row.active})
        )
    op.alter_column("animal_version", "archived", new_column_name="active")
    animal_version = sa.sql.table(
        "animal_version",
        sa.sql.column("uuid"),
        sa.sql.column("active"),
    )
    cursor = op.get_bind().execute(animal_version.select())
    for row in cursor.fetchall():
        op.get_bind().execute(
            animal_version.update()
            .where(animal_version.c.uuid == row.uuid)
            .values({"active": not row.active})
        )
