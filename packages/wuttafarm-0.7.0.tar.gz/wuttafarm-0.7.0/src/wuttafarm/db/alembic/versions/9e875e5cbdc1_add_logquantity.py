"""add LogQuantity

Revision ID: 9e875e5cbdc1
Revises: 74d32b4ec210
Create Date: 2026-02-28 21:55:31.876087

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "9e875e5cbdc1"
down_revision: Union[str, None] = "74d32b4ec210"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # log_quantity
    op.create_table(
        "log_quantity",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("log_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("quantity_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["log_uuid"], ["log.uuid"], name=op.f("fk_log_quantity_log_uuid_log")
        ),
        sa.ForeignKeyConstraint(
            ["quantity_uuid"],
            ["quantity.uuid"],
            name=op.f("fk_log_quantity_quantity_uuid_quantity"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_log_quantity")),
    )
    op.create_table(
        "log_quantity_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "log_uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=True
        ),
        sa.Column(
            "quantity_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_log_quantity_version")
        ),
    )
    op.create_index(
        op.f("ix_log_quantity_version_end_transaction_id"),
        "log_quantity_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_quantity_version_operation_type"),
        "log_quantity_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_log_quantity_version_pk_transaction_id",
        "log_quantity_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_log_quantity_version_pk_validity",
        "log_quantity_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_log_quantity_version_transaction_id"),
        "log_quantity_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # log_quantity
    op.drop_index(
        op.f("ix_log_quantity_version_transaction_id"),
        table_name="log_quantity_version",
    )
    op.drop_index(
        "ix_log_quantity_version_pk_validity", table_name="log_quantity_version"
    )
    op.drop_index(
        "ix_log_quantity_version_pk_transaction_id", table_name="log_quantity_version"
    )
    op.drop_index(
        op.f("ix_log_quantity_version_operation_type"),
        table_name="log_quantity_version",
    )
    op.drop_index(
        op.f("ix_log_quantity_version_end_transaction_id"),
        table_name="log_quantity_version",
    )
    op.drop_table("log_quantity_version")
    op.drop_table("log_quantity")
