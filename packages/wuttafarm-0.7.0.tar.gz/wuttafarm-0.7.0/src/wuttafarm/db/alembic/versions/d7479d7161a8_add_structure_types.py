"""add Structure Types

Revision ID: d7479d7161a8
Revises: 9f2243df9566
Create Date: 2026-02-10 19:24:20.249826

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "d7479d7161a8"
down_revision: Union[str, None] = "9f2243df9566"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # structure_type
    op.create_table(
        "structure_type",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("name", sa.String(length=100), nullable=False),
        sa.Column("farmos_uuid", wuttjamaican.db.util.UUID(), nullable=True),
        sa.Column("drupal_id", sa.String(length=50), nullable=True),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_structure_type")),
        sa.UniqueConstraint("drupal_id", name=op.f("uq_structure_type_drupal_id")),
        sa.UniqueConstraint("farmos_uuid", name=op.f("uq_structure_type_farmos_uuid")),
        sa.UniqueConstraint("name", name=op.f("uq_structure_type_name")),
    )
    op.create_table(
        "structure_type_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column("name", sa.String(length=100), autoincrement=False, nullable=True),
        sa.Column(
            "farmos_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "drupal_id", sa.String(length=50), autoincrement=False, nullable=True
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_structure_type_version")
        ),
    )
    op.create_index(
        op.f("ix_structure_type_version_end_transaction_id"),
        "structure_type_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_type_version_operation_type"),
        "structure_type_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_structure_type_version_pk_transaction_id",
        "structure_type_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_structure_type_version_pk_validity",
        "structure_type_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_structure_type_version_transaction_id"),
        "structure_type_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # structure_type
    op.drop_index(
        op.f("ix_structure_type_version_transaction_id"),
        table_name="structure_type_version",
    )
    op.drop_index(
        "ix_structure_type_version_pk_validity", table_name="structure_type_version"
    )
    op.drop_index(
        "ix_structure_type_version_pk_transaction_id",
        table_name="structure_type_version",
    )
    op.drop_index(
        op.f("ix_structure_type_version_operation_type"),
        table_name="structure_type_version",
    )
    op.drop_index(
        op.f("ix_structure_type_version_end_transaction_id"),
        table_name="structure_type_version",
    )
    op.drop_table("structure_type_version")
    op.drop_table("structure_type")
