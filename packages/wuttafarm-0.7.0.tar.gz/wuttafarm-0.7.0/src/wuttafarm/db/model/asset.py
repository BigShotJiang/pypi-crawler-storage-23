# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Asset Types
"""

import sqlalchemy as sa
from sqlalchemy import orm
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.ext.associationproxy import association_proxy

from wuttjamaican.db import model


class AssetType(model.Base):
    """
    Represents an "asset type" from farmOS
    """

    __tablename__ = "asset_type"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Asset Type",
        "model_title_plural": "Asset Types",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the asset type.
        """,
    )

    description = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Description for the asset type.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the asset type within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.String(length=50),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the asset type.
        """,
    )

    def __str__(self):
        return self.name or ""


class Asset(model.Base):
    """
    Represents an asset (of any kind) from farmOS.
    """

    __tablename__ = "asset"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Asset",
        "model_title_plural": "All Assets",
    }

    uuid = model.uuid_column()

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the asset within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the asset.
        """,
    )

    asset_type = sa.Column(
        sa.String(length=100), sa.ForeignKey("asset_type.drupal_id"), nullable=False
    )

    asset_name = sa.Column(
        sa.String(length=100),
        nullable=False,
        doc="""
        Name of the asset.
        """,
    )

    is_location = sa.Column(
        sa.Boolean(),
        nullable=False,
        default=False,
        doc="""
        Whether the asset should be considered a location.
        """,
    )

    is_fixed = sa.Column(
        sa.Boolean(),
        nullable=False,
        default=False,
        doc="""
        Whether the asset's location is fixed.
        """,
    )

    notes = sa.Column(
        sa.Text(),
        nullable=True,
        doc="""
        Notes for the asset.
        """,
    )

    thumbnail_url = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional thumbnail URL for the asset.
        """,
    )

    image_url = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional image URL for the asset.
        """,
    )

    archived = sa.Column(
        sa.Boolean(),
        nullable=False,
        default=False,
        doc="""
        Whether the asset is archived.
        """,
    )

    _parents = orm.relationship(
        "AssetParent",
        foreign_keys="AssetParent.asset_uuid",
        back_populates="asset",
        cascade="all, delete-orphan",
        cascade_backrefs=False,
    )

    parents = association_proxy(
        "_parents",
        "parent",
        creator=lambda parent: AssetParent(parent=parent),
    )

    _owners = orm.relationship(
        "AssetOwner",
        cascade="all, delete-orphan",
        cascade_backrefs=False,
        back_populates="asset",
    )

    owners = association_proxy(
        "_owners",
        "user",
        creator=lambda user: AssetOwner(user=user),
    )

    def __str__(self):
        return self.asset_name or ""


class AssetMixin:

    uuid = model.uuid_fk_column("asset.uuid", nullable=False, primary_key=True)

    @declared_attr
    def asset(cls):
        return orm.relationship(
            Asset,
            single_parent=True,
            cascade="all, delete-orphan",
            cascade_backrefs=False,
        )

    def __str__(self):
        return self.asset_name or ""


def add_asset_proxies(subclass):
    Asset.make_proxy(subclass, "asset", "farmos_uuid")
    Asset.make_proxy(subclass, "asset", "drupal_id")
    Asset.make_proxy(subclass, "asset", "asset_type")
    Asset.make_proxy(subclass, "asset", "asset_name")
    Asset.make_proxy(subclass, "asset", "is_location")
    Asset.make_proxy(subclass, "asset", "is_fixed")
    Asset.make_proxy(subclass, "asset", "notes")
    Asset.make_proxy(subclass, "asset", "thumbnail_url")
    Asset.make_proxy(subclass, "asset", "image_url")
    Asset.make_proxy(subclass, "asset", "archived")
    Asset.make_proxy(subclass, "asset", "parents")
    Asset.make_proxy(subclass, "asset", "owners")


class EggMixin:

    produces_eggs = sa.Column(
        sa.Boolean(),
        nullable=True,
        doc="""
        Whether the group asset produces eggs (i.e. it should be
        available in the egg harvest form).
        """,
    )


class AssetParent(model.Base):
    """
    Represents an "asset's parent relationship" from farmOS.
    """

    __tablename__ = "asset_parent"
    __versioned__ = {}

    uuid = model.uuid_column()

    asset_uuid = model.uuid_fk_column("asset.uuid", nullable=False)

    asset = orm.relationship(
        Asset,
        foreign_keys=asset_uuid,
    )

    parent_uuid = model.uuid_fk_column("asset.uuid", nullable=False)

    parent = orm.relationship(
        Asset,
        foreign_keys=parent_uuid,
    )


class AssetOwner(model.Base):
    """
    Represents a "asset's owner relationship" from farmOS.
    """

    __tablename__ = "asset_owner"
    __versioned__ = {}

    uuid = model.uuid_column()

    asset_uuid = model.uuid_fk_column("asset.uuid", nullable=False)
    asset = orm.relationship(
        Asset,
        foreign_keys=asset_uuid,
        back_populates="_owners",
    )

    user_uuid = model.uuid_fk_column("user.uuid", nullable=False)
    user = orm.relationship(
        model.User,
        foreign_keys=user_uuid,
    )
