"""
UI模块初始化
"""

from .forms import UIManager

__all__ = ["UIManager"]
