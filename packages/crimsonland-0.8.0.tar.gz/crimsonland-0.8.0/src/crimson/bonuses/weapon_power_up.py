from __future__ import annotations

from ..math_parity import f32
from .apply_context import BonusApplyCtx


def apply_weapon_power_up(ctx: BonusApplyCtx) -> None:
    old = float(ctx.state.bonuses.weapon_power_up)
    if old <= 0.0:
        ctx.register_global("weapon_power_up")
    ctx.state.bonuses.weapon_power_up = float(
        f32(float(old) + float(ctx.amount) * float(ctx.economist_multiplier)),
    )
    ctx.player.weapon_reset_latch = 0
    ctx.player.weapon.shot_cooldown = 0.0
    ctx.player.weapon.reload_active = False
    ctx.player.weapon.reload_timer = 0.0
    ctx.player.weapon.reload_timer_max = 0.0
    ctx.player.weapon.ammo = float(ctx.player.weapon.clip_size)
