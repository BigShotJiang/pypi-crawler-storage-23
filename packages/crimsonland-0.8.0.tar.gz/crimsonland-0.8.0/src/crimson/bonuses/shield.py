from __future__ import annotations

from ..math_parity import f32
from .apply_context import BonusApplyCtx


def apply_shield(ctx: BonusApplyCtx) -> None:
    should_register = float(ctx.player.shield_timer) <= 0.0
    if len(ctx.players) > 1:
        should_register = float(ctx.players[0].shield_timer) <= 0.0 and float(ctx.players[1].shield_timer) <= 0.0
    if should_register:
        ctx.register_player("shield_timer")
    ctx.player.shield_timer = float(
        f32(float(ctx.player.shield_timer) + float(ctx.amount) * float(ctx.economist_multiplier)),
    )
