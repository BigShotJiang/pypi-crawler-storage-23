from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Protocol

import msgspec

from grim.geom import Vec2

from ..sim.state_types import GameplayState, PlayerState
from .hud import _TimerRef
from .ids import BONUS_BY_ID, BonusId
from .payload import BonusDurationPayload, bonus_payload_from_bonus

if TYPE_CHECKING:
    from ..creatures.runtime import CreatureState


class HasPos(Protocol):
    pos: Vec2


class BonusApplyCtx(msgspec.Struct):
    state: GameplayState
    player: PlayerState
    bonus_id: BonusId
    amount: int
    origin: HasPos | None
    creatures: Sequence[CreatureState]
    players: list[PlayerState]
    detail_preset: int
    economist_multiplier: float
    label: str
    icon_id: int
    defer_freeze_corpse_fx: bool = False
    freeze_corpse_indices: set[int] | None = None

    def register_global(self, timer_key: str) -> None:
        self.state.bonus_hud.register(
            self.bonus_id,
            label=self.label,
            icon_id=self.icon_id,
            timer_ref=_TimerRef("global", str(timer_key)),
        )

    def register_player(self, timer_key: str) -> None:
        if len(self.players) > 1:
            self.state.bonus_hud.register(
                self.bonus_id,
                label=self.label,
                icon_id=self.icon_id,
                timer_ref=_TimerRef("player", str(timer_key), player_index=0),
                timer_ref_alt=_TimerRef("player", str(timer_key), player_index=1),
            )
        else:
            self.state.bonus_hud.register(
                self.bonus_id,
                label=self.label,
                icon_id=self.icon_id,
                timer_ref=_TimerRef("player", str(timer_key), player_index=int(self.player.index)),
            )

    def origin_pos(self) -> HasPos:
        return self.origin or self.player


BonusApplyHandler = Callable[[BonusApplyCtx], None]


def bonus_apply_seconds(ctx: BonusApplyCtx) -> float:
    meta = BONUS_BY_ID.get(ctx.bonus_id)
    if meta is not None and meta.apply_seconds is not None:
        return float(meta.apply_seconds)
    payload = bonus_payload_from_bonus(
        bonus_id=ctx.bonus_id,
        amount=int(ctx.amount),
    )
    if isinstance(payload, BonusDurationPayload):
        return float(payload.seconds)
    return float(ctx.amount)
