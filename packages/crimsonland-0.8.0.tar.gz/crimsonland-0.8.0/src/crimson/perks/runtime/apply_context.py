from __future__ import annotations

from collections.abc import Callable, Sequence

import msgspec

from ...sim.state_types import GameplayState, PlayerState
from ..ids import PerkId
from ..state import CreatureForPerks, PerkSelectionState


class PerkApplyCtx(msgspec.Struct):
    state: GameplayState
    players: list[PlayerState]
    owner: PlayerState
    perk_id: PerkId
    perk_state: PerkSelectionState | None
    dt: float | None
    creatures: Sequence[CreatureForPerks] | None

    def frame_dt(self) -> float:
        return float(self.dt) if self.dt is not None else 0.0


PerkApplyHandler = Callable[[PerkApplyCtx], None]
