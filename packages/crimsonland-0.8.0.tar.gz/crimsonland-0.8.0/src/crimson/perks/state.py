from __future__ import annotations

from typing import Protocol

import msgspec

from grim.geom import Vec2

from ..creatures.spawn import CreatureFlags
from .ids import PerkId


class CreatureForPerks(Protocol):
    active: bool
    pos: Vec2
    hp: float
    flags: CreatureFlags
    lifecycle_stage: float
    collision_timer: float
    reward_value: float
    size: float


class PerkEffectIntervals(msgspec.Struct):
    """Global thresholds used by perk timers in `player_update`.

    These are global (not per-player) in crimsonland.exe: `flt_473310`,
    `flt_473314`, and `flt_473318`.
    """

    man_bomb: float = 4.0
    fire_cough: float = 2.0
    hot_tempered: float = 2.0


class PerkSelectionState(msgspec.Struct):
    pending_count: int = 0
    choices: list[PerkId] = msgspec.field(default_factory=list)
    choices_dirty: bool = True
    capture_player_perk_counts_known: bool = True
