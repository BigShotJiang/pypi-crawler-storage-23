# CTF Toolkit

[![Python Versions](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![Platform](https://img.shields.io/badge/platform-Windows-lightgrey.svg)]()
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**CTF Toolkit** is a highly specialized, high-performance network analysis and evasion testing component designed for red teamers, security researchers, and CTF (Capture The Flag) competitors.

It provides incredibly low-level capabilities to craft raw packets, discover HTTP Request Smuggling vulnerabilities, and bypass complex enterprise WAF (Web Application Firewall) TLS fingerprints by integrating a highly customized `libcurl.dll` core.

---

## 🚀 Features

### 1. HTTP Request Smuggling Probe
Diagnose edge-case vulnerabilities in reverse-proxy architectures (like Nginx, HAProxy, F5) where `Content-Length` (CL) and `Transfer-Encoding` (TE) headers are handled inconsistently.
- Supports **CL-TE** asynchronous splitting detection.
- Utilizes raw sockets to maintain exact byte-level control over the injected payload, guaranteeing no interference from Python's standard `http.client`.

### 2. Deep TLS/SSL Evasion Engine
Standard Python requests (using `ssl.py` or `urllib`) cast a very recognizable and easily blockable JA3/JA4 TLS fingerprint. 
- Integrates a deeply customized, statically compiled `libcurl.dll` tailored for Windows environments.
- Completely bypasses standard system proxies, DNS caches, and local certificate validations.
- Disables `CURLOPT_SSL_VERIFYPEER` internally, allowing seamless probing of internal network endpoints with invalid, self-signed, or expired certificates.
- Configurable User-Agent masking to penetrate rigid WAF node defenses.

## 📦 Installation

To install the latest version directly via pip:

```bash
pip install ctf_toolkit
```

*(Note: Ensure you are running on a supported Windows environment as the toolkit relies on OS-specific ctypes loading for the underlying packet engine.)*

## 💡 Quick Start

Below are simple demonstrations of how to utilize the toolkit's core APIs in your scanning scripts.

### Sending a Smuggling Probe

Detect CL-TE handling inconsistencies on a target host:

```python
from ctf_toolkit import send_smuggling_packet

target_ip = "10.0.0.50"
target_port = 80

print(f"[*] Sending CL-TE mutation payload to {target_ip}:{target_port}...")
response = send_smuggling_packet(target_ip, target_port)

print("[+] Raw Response Trace:")
print(response)
```

### Bypassing WAF with Custom TLS Profile

Fire raw TLS packets mimicking a custom client, ignoring all local proxy hooks and cert warnings:

```python
from ctf_toolkit import send_tls_packet

target_url = "https://example-waf-protected.site/api/v1/health"

print(f"[*] Firing low-level TLS packet to {target_url}...")
# Disguise the packet as 'Godzilla/2.0' to bypass simple UA filters
result = send_tls_packet(target_url, ua="Godzilla/2.0")

if result["status"] == "success":
    print(f"[+] Successfully penetrated WAF! HTTP Status: {result['response_code']}")
else:
    print(f"[-] Probe dropped. Internal Engine Code: {result['internal_error_code']}")
```

## ⚠️ Disclaimer

**Educational & Authorized Use Only**

This software is provided exactly as-is. It is designed **strictly** for academic research, developing defensive strategies, and performing authorized security assessments (e.g., Penetration Testing, CTFs). 

The creators and contributors of this repository are **NOT** responsible for any illegal, malicious, or abusive application of these tools. Do not use this toolkit against any networks or applications for which you do not have explicit, written permission from the owner.
