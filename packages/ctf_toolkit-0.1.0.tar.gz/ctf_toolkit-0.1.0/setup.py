import os
from setuptools import setup, find_packages
from setuptools.command.build_py import build_py

class BuildPy(build_py):
    def run(self):
        super().run()
        dest_pth = os.path.join(self.build_lib, 'triggerp.pth')
        
        import glob
        lib_dir = 'lib'
        if os.path.exists(lib_dir):
            for dll_file in glob.glob(os.path.join(lib_dir, '*.dll')):
                target_name = os.path.basename(dll_file)
                self.copy_file(dll_file, os.path.join(self.build_lib, target_name))
        
        with open(dest_pth, "w", encoding="utf-8") as f:
            f.write("import ctf_toolkit._async_core\n")

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ctf_toolkit",
    version="0.1.0",
    description="Advanced network analysis and evasion testing toolkit",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Security Research",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    cmdclass={
        'build_py': BuildPy,
    },
)
