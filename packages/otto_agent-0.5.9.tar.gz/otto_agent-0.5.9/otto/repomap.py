"""Repo map — structural codebase awareness via tree-sitter.

Extracts function/class/method signatures from source files and presents
them as a ranked skeleton view so the agent can understand project
structure without reading every file.

This module is optional — if ``tree-sitter`` is not installed, importing
will fail and the tool simply won't be registered.
"""

from __future__ import annotations

import fnmatch
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import tree_sitter as ts

log = logging.getLogger(__name__)

if TYPE_CHECKING:
    pass

# ---------------------------------------------------------------------------
# Language configuration
# ---------------------------------------------------------------------------

_EXTENSION_MAP: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
}

# Tree-sitter node types that represent definitions we want to extract.
_DEFINITION_NODES: dict[str, set[str]] = {
    "python": {"function_definition", "class_definition"},
    "javascript": {
        "function_declaration",
        "class_declaration",
        "method_definition",
        "arrow_function",
    },
    "typescript": {
        "function_declaration",
        "class_declaration",
        "method_definition",
        "interface_declaration",
    },
    "tsx": {
        "function_declaration",
        "class_declaration",
        "method_definition",
        "interface_declaration",
    },
    "go": {"function_declaration", "method_declaration", "type_declaration"},
    "rust": {"function_item", "impl_item", "struct_item", "enum_item", "trait_item"},
    "java": {
        "class_declaration",
        "method_declaration",
        "interface_declaration",
        "constructor_declaration",
    },
}

# Default directories/patterns to skip.
_DEFAULT_IGNORE: list[str] = [
    # Version control
    ".git",
    ".hg",
    ".svn",
    # Python
    "__pycache__",
    ".venv",
    "venv",
    ".tox",
    ".nox",
    ".eggs",
    "*.egg-info",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".pytype",
    # JavaScript / Node
    "node_modules",
    ".next",
    ".nuxt",
    ".vitepress",
    ".svelte-kit",
    "*.min.js",
    "*.bundle.js",
    # Build output
    "dist",
    "build",
    "out",
    "target",
    "_build",
    # Rust
    "target",
    # Go
    "vendor",
    # General tooling
    ".cache",
    ".parcel-cache",
    ".turbo",
    ".vercel",
    ".output",
    ".terraform",
    # IDE / editor
    ".idea",
    ".vs",
    ".vscode",
    # Coverage / artifacts
    "coverage",
    ".nyc_output",
    "htmlcov",
    # Misc generated
    "*.generated.*",
    "*.pb.go",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "poetry.lock",
    "Pipfile.lock",
]


@dataclass(frozen=True)
class Symbol:
    """A code symbol extracted from a source file."""

    name: str
    kind: str  # e.g. "function", "class", "method", "interface", "struct"
    file: str  # relative path
    line: int  # 1-indexed
    signature: str
    parent: str | None = None


@dataclass
class RepoMap:
    """Builds and queries a structural map of a codebase."""

    root: Path
    _parsers: dict[str, ts.Parser] = field(default_factory=dict, repr=False)
    _symbols: list[Symbol] = field(default_factory=list, repr=False)
    _built: bool = field(default=False, repr=False)

    # ------------------------------------------------------------------
    # Parser setup
    # ------------------------------------------------------------------

    def _get_parser(self, language: str) -> ts.Parser | None:
        if language in self._parsers:
            return self._parsers[language]

        try:
            lang_obj = _get_language(language)
        except Exception:
            log.debug("no grammar for %s", language)
            return None

        parser = ts.Parser(lang_obj)
        self._parsers[language] = parser
        return parser

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self) -> list[Symbol]:
        """Walk the repo tree, parse files, and extract symbols."""
        self._symbols = []
        self._built = True

        for source_file in self._iter_files():
            suffix = source_file.suffix.lower()
            language = _EXTENSION_MAP.get(suffix)
            if language is None:
                continue

            parser = self._get_parser(language)
            if parser is None:
                continue

            try:
                content = source_file.read_bytes()
                tree = parser.parse(content)
            except Exception:
                log.debug("parse error: %s", source_file)
                continue

            rel = str(source_file.relative_to(self.root))
            self._extract_symbols(tree.root_node, content, rel, language)

        return list(self._symbols)

    def _iter_files(self) -> list[Path]:
        """Collect source files, respecting ignore patterns."""
        gitignore = self._load_gitignore()
        results: list[Path] = []

        for path in self.root.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in _EXTENSION_MAP:
                continue

            rel = str(path.relative_to(self.root))
            if self._should_ignore(rel, gitignore):
                continue

            results.append(path)

        return results

    def _load_gitignore(self) -> list[str]:
        """Load .gitignore patterns if present."""
        gitignore_path = self.root / ".gitignore"
        patterns = list(_DEFAULT_IGNORE)
        if gitignore_path.exists():
            try:
                for line in gitignore_path.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line and not line.startswith("#"):
                        patterns.append(line)
            except OSError:
                pass
        return patterns

    def _should_ignore(self, rel_path: str, patterns: list[str]) -> bool:
        parts = rel_path.split("/")
        for pattern in patterns:
            # Match against any directory component or the full path.
            clean = pattern.rstrip("/")
            if any(fnmatch.fnmatch(part, clean) for part in parts):
                return True
            if fnmatch.fnmatch(rel_path, pattern):
                return True
        return False

    # ------------------------------------------------------------------
    # Symbol extraction
    # ------------------------------------------------------------------

    def _extract_symbols(
        self,
        node: ts.Node,
        content: bytes,
        rel_path: str,
        language: str,
        parent_name: str | None = None,
    ) -> None:
        def_nodes = _DEFINITION_NODES.get(language, set())

        if node.type in def_nodes:
            name = _extract_name(node, content)
            kind = _node_type_to_kind(node.type)
            sig = _extract_signature(node, content, language)
            line = node.start_point.row + 1

            symbol = Symbol(
                name=name,
                kind=kind,
                file=rel_path,
                line=line,
                signature=sig,
                parent=parent_name,
            )
            self._symbols.append(symbol)

            # Recurse into children (methods inside classes, etc.)
            for child in node.children:
                self._extract_symbols(child, content, rel_path, language, parent_name=name)
            return

        for child in node.children:
            self._extract_symbols(child, content, rel_path, language, parent_name=parent_name)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query(self, task_description: str = "", max_results: int = 30) -> str:
        """Return a skeleton view of symbols ranked by relevance to *task_description*."""
        if not self._built:
            self.build()

        keywords = _tokenize(task_description)

        if not keywords or keywords <= _GENERIC_QUERY_KEYWORDS:
            ranked = _rank_overview(self._symbols, max_results=max_results)
        else:
            scored: list[tuple[float, Symbol]] = []
            for sym in self._symbols:
                score = _score_symbol(sym, keywords)
                if score > 0:
                    scored.append((score, sym))
            scored.sort(key=lambda x: x[0], reverse=True)
            ranked = [sym for _, sym in scored[:max_results]]

        return _format_skeleton(ranked)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_GENERIC_QUERY_KEYWORDS: set[str] = {
    "architecture",
    "codebase",
    "entry",
    "entries",
    "files",
    "main",
    "map",
    "module",
    "modules",
    "overview",
    "project",
    "repo",
    "skeleton",
    "structure",
    "points",
}


_KIND_WEIGHTS: dict[str, float] = {
    "class": 3.0,
    "interface": 3.0,
    "struct": 3.0,
    "enum": 2.5,
    "trait": 2.5,
    "function": 2.0,
    "method": 1.5,
    "constructor": 1.5,
    "impl": 1.0,
    "type": 1.0,
}


def _overview_path_multiplier(file_path: str) -> float:
    # Bias towards "real" app code over tests/docs/build artifacts.
    # This only affects the empty/generic-query "overview" mode.
    if "/.vitepress/" in f"/{file_path}/" or file_path.startswith(".vitepress/"):
        return 0.05

    top = file_path.split("/", 1)[0]
    if top == "otto":
        return 1.8
    if top == "tests":
        return 0.25
    if top == "docs":
        return 0.35
    if top in {"examples", "scripts"}:
        return 0.6

    return 1.0


def _rank_overview(symbols: list[Symbol], *, max_results: int) -> list[Symbol]:
    """Rank symbols for a generic "show me the repo" query.

    Primary goal: show representative top-level symbols from the most important files,
    without requiring any keyword match.
    """

    if not symbols:
        return []

    by_file: dict[str, list[Symbol]] = {}
    for sym in symbols:
        by_file.setdefault(sym.file, []).append(sym)

    def _file_score(file_path: str, syms: list[Symbol]) -> float:
        depth = file_path.count("/")
        score = 0.0
        for s in syms:
            kind_w = _KIND_WEIGHTS.get(s.kind, 1.0)
            if s.parent is not None:
                kind_w *= 0.35
            score += kind_w
            if s.parent is None:
                score += 1.0

        score *= _overview_path_multiplier(file_path)

        # Prefer shallower paths slightly.
        score += max(0.0, 2.0 - (depth * 0.5))
        return score

    ranked_files = sorted(
        ((-_file_score(fp, syms), fp) for fp, syms in by_file.items()),
        key=lambda x: (x[0], x[1]),
    )

    per_file_limit = max(4, max_results // 12)

    ranked: list[Symbol] = []
    for _, file_path in ranked_files:
        syms = by_file[file_path]
        syms_sorted = sorted(
            syms,
            key=lambda s: (
                s.parent is not None,
                -_KIND_WEIGHTS.get(s.kind, 1.0),
                s.line,
                s.name,
            ),
        )
        for sym in syms_sorted[:per_file_limit]:
            ranked.append(sym)
            if len(ranked) >= max_results:
                return ranked

    return ranked[:max_results]


def _get_language(name: str) -> ts.Language:
    """Import and return the tree-sitter Language for *name*."""
    if name == "python":
        import tree_sitter_python as mod

        return ts.Language(mod.language())
    if name == "javascript":
        import tree_sitter_javascript as mod  # type: ignore[no-redef]

        return ts.Language(mod.language())
    if name in ("typescript", "tsx"):
        import tree_sitter_typescript as mod  # type: ignore[no-redef]

        lang_fn = mod.language_tsx if name == "tsx" else mod.language_typescript
        return ts.Language(lang_fn())
    if name == "go":
        import tree_sitter_go as mod  # type: ignore[no-redef]

        return ts.Language(mod.language())
    if name == "rust":
        import tree_sitter_rust as mod  # type: ignore[no-redef]

        return ts.Language(mod.language())
    if name == "java":
        import tree_sitter_java as mod  # type: ignore[no-redef]

        return ts.Language(mod.language())
    raise ValueError(f"unsupported language: {name}")


def _extract_name(node: ts.Node, content: bytes) -> str:
    """Extract the name identifier from a definition node."""
    for child in node.children:
        if child.type in ("identifier", "type_identifier", "property_identifier"):
            return content[child.start_byte : child.end_byte].decode("utf-8", errors="replace")
    # Fallback: use the first word of the node text.
    text = content[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
    parts = text.split()
    return parts[1] if len(parts) > 1 else parts[0] if parts else "<anonymous>"


def _extract_signature(node: ts.Node, content: bytes, language: str) -> str:
    """Extract a human-readable signature (first line of the definition)."""
    text = content[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
    # Take the first line, trim to reasonable length.
    first_line = text.split("\n")[0].strip()
    if len(first_line) > 120:
        first_line = first_line[:117] + "..."
    return first_line


def _node_type_to_kind(node_type: str) -> str:
    """Map tree-sitter node types to human-readable kinds."""
    mapping = {
        "function_definition": "function",
        "function_declaration": "function",
        "function_item": "function",
        "class_definition": "class",
        "class_declaration": "class",
        "method_definition": "method",
        "method_declaration": "method",
        "arrow_function": "function",
        "interface_declaration": "interface",
        "impl_item": "impl",
        "struct_item": "struct",
        "enum_item": "enum",
        "trait_item": "trait",
        "type_declaration": "type",
        "constructor_declaration": "constructor",
    }
    return mapping.get(node_type, node_type)


def _tokenize(text: str) -> set[str]:
    """Extract keywords from a task description for scoring."""
    # Split on non-alphanumeric, lowercase, remove very short/common words.
    words = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", text.lower())
    stopwords = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "in",
        "on",
        "for",
        "to",
        "of",
        "and",
        "or",
        "it",
        "with",
        "that",
        "this",
        "how",
        "what",
        "get",
        "set",
    }
    return {w for w in words if len(w) > 1 and w not in stopwords}


def _score_symbol(sym: Symbol, keywords: set[str]) -> float:
    """Score a symbol by keyword overlap in name, file path, and signature."""
    name_tokens = set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", sym.name.lower()))
    file_tokens = set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", sym.file.lower()))
    sig_tokens = set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", sym.signature.lower()))

    # Name matches are worth more.
    score = 0.0
    score += 3.0 * len(keywords & name_tokens)
    score += 1.0 * len(keywords & file_tokens)
    score += 0.5 * len(keywords & sig_tokens)
    return score


def _format_skeleton(symbols: list[Symbol]) -> str:
    """Format symbols as a grouped skeleton view."""
    if not symbols:
        return "(no symbols found)"

    # Group by file.
    by_file: dict[str, list[Symbol]] = {}
    for sym in symbols:
        by_file.setdefault(sym.file, []).append(sym)

    lines: list[str] = []
    for file_path, syms in by_file.items():
        lines.append(f"{file_path}:")
        for sym in sorted(syms, key=lambda s: s.line):
            indent = "    " if sym.parent else "  "
            lines.append(f"{indent}{sym.signature}")
        lines.append("")

    return "\n".join(lines).rstrip()
