"""Otto — AI agent platform."""

__version__ = "0.4.6"
