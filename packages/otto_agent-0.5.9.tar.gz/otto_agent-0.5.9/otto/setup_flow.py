from __future__ import annotations

import getpass
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

from otto.config import (
    OTTO_HOME,
    AgentConfig,
    BotAuthConfig,
    BotConfig,
    BotSkillsConfig,
    ChannelConfig,
    Config,
    UserConfig,
    WorkspaceConfig,
    ensure_dirs,
    save_config,
)

ENV_FILE = OTTO_HOME / ".env"

PROVIDERS = {
    "1": ("anthropic", "ANTHROPIC_API_KEY", "anthropic/claude-sonnet-4-5-20250514"),
    "2": ("openrouter", "OPENROUTER_API_KEY", "openrouter/anthropic/claude-sonnet-4-5-20250514"),
    "3": ("cerebras", "CEREBRAS_API_KEY", "cerebras/llama-4-scout-17b-16e-instruct"),
}


def _write(text: str) -> None:
    sys.stdout.write(text)
    sys.stdout.flush()


def _prompt(label: str = "> ") -> str:
    try:
        return input(label)
    except EOFError:
        return ""


def _get_os_username() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return ""


def _validate_api_key(provider: str, api_key: str) -> bool:
    """Validate an API key with a cheap test call. Returns True if the key works."""
    try:
        if provider == "anthropic":
            url = "https://api.anthropic.com/v1/messages"
            data = json.dumps(
                {
                    "model": "claude-sonnet-4-5-20250514",
                    "max_tokens": 1,
                    "messages": [{"role": "user", "content": "hi"}],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
        elif provider == "openrouter":
            url = "https://openrouter.ai/api/v1/chat/completions"
            data = json.dumps(
                {
                    "model": "anthropic/claude-sonnet-4-5-20250514",
                    "max_tokens": 1,
                    "messages": [{"role": "user", "content": "hi"}],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "content-type": "application/json",
                },
            )
        elif provider == "cerebras":
            url = "https://api.cerebras.ai/v1/chat/completions"
            data = json.dumps(
                {
                    "model": "llama-4-scout-17b-16e-instruct",
                    "max_tokens": 1,
                    "messages": [{"role": "user", "content": "hi"}],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=data,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "content-type": "application/json",
                },
            )
        else:
            return True

        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as exc:
        # 401/403 means bad key; other errors (like 429) may mean key is valid
        if exc.code in (401, 403):
            return False
        # For rate limits or server errors, assume key is valid
        return exc.code >= 429
    except Exception:
        return False


def _write_env_file(secrets: dict[str, str]) -> None:
    ensure_dirs()
    env_lines = [f"{key}={value}" for key, value in secrets.items() if value]
    ENV_FILE.write_text("\n".join(env_lines) + "\n", encoding="utf-8")
    ENV_FILE.chmod(0o600)


def _validate_telegram_token(token: str) -> bool:
    """Check a Telegram bot token via getMe. Returns True if valid."""
    try:
        url = f"https://api.telegram.org/bot{token}/getMe"
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            return data.get("ok", False)
    except Exception:
        return False


async def _parse_yes_no(user_input: str, api_key: str, provider: str, model: str) -> bool | None:
    """Use a cheap LLM call to parse freeform yes/no. Returns True/False/None."""
    import asyncio

    stripped = user_input.strip().lower()
    # Fast path for obvious answers
    if stripped in ("yes", "y", "yeah", "yep", "sure", "ok", "yea"):
        return True
    if stripped in ("no", "n", "nah", "nope", "not now", "skip"):
        return False

    try:
        if provider == "anthropic":
            url = "https://api.anthropic.com/v1/messages"
            payload = json.dumps(
                {
                    "model": model.split("/", 1)[-1] if "/" in model else model,
                    "max_tokens": 10,
                    "system": (
                        "The user was asked a yes/no question. "
                        'Extract their intent. Reply with exactly "yes" or "no" or "unclear".'
                    ),
                    "messages": [{"role": "user", "content": user_input}],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=payload,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
        elif provider == "openrouter":
            url = "https://openrouter.ai/api/v1/chat/completions"
            payload = json.dumps(
                {
                    "model": model.split("/", 1)[-1] if "/" in model else model,
                    "max_tokens": 10,
                    "messages": [
                        {
                            "role": "system",
                            "content": (
                                "The user was asked a yes/no question. "
                                'Extract their intent. Reply with exactly "yes" or "no" or "unclear".'
                            ),
                        },
                        {"role": "user", "content": user_input},
                    ],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=payload,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "content-type": "application/json",
                },
            )
        elif provider == "cerebras":
            url = "https://api.cerebras.ai/v1/chat/completions"
            payload = json.dumps(
                {
                    "model": model.split("/", 1)[-1] if "/" in model else model,
                    "max_tokens": 10,
                    "messages": [
                        {
                            "role": "system",
                            "content": (
                                "The user was asked a yes/no question. "
                                'Extract their intent. Reply with exactly "yes" or "no" or "unclear".'
                            ),
                        },
                        {"role": "user", "content": user_input},
                    ],
                }
            ).encode()
            req = urllib.request.Request(
                url,
                data=payload,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "content-type": "application/json",
                },
            )
        else:
            return None

        loop = asyncio.get_event_loop()
        resp_data = await asyncio.wait_for(
            loop.run_in_executor(None, lambda: _do_http_request(req)),
            timeout=5.0,
        )
        if resp_data is None:
            return None

        # Parse response based on provider format
        if provider == "anthropic":
            content_blocks = resp_data.get("content", [])
            text = content_blocks[0].get("text", "").strip().lower() if content_blocks else ""
        else:
            choices = resp_data.get("choices", [])
            text = (
                choices[0].get("message", {}).get("content", "").strip().lower() if choices else ""
            )

        if "yes" in text:
            return True
        if "no" in text:
            return False
        return None
    except Exception:
        return None


def _do_http_request(req: urllib.request.Request) -> dict | None:
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def _build_config(
    *,
    provider: str,
    model: str,
    owner_name: str,
    telegram_token: str | None = None,
    telegram_user_id: int | None = None,
) -> Config:
    """Build a Config object in new [[bots]] schema."""
    users = [
        UserConfig(
            name=owner_name,
            telegram_id=telegram_user_id,
        )
    ]

    channels: list[ChannelConfig] = []
    if telegram_token:
        channels.append(ChannelConfig(type="telegram", token="${TELEGRAM_BOT_TOKEN}"))
    channels.append(ChannelConfig(type="cli", enabled=True))

    bots = [
        BotConfig(
            name="otto",
            model=f"{provider}/{model}" if "/" not in model else model,
            auth=BotAuthConfig(
                owner=owner_name,
                allowed_users=[owner_name],
                bootstrap="disabled",
            ),
            workspace=WorkspaceConfig(
                root=Path("~/.otto/workspace"),
                mode="default",
                sandbox="none",
            ),
            skills=BotSkillsConfig(include_shared=True),
            channels=channels,
        )
    ]

    full_model = f"{provider}/{model}" if "/" not in model else model

    return Config(
        agent=AgentConfig(model=full_model),
        log_level="info",
        env_file=".env",
        users=users,
        bots=bots,
    )


async def run_setup() -> Config | None:
    """Run the conversational first-run setup. Returns Config on success, None if cancelled."""
    secrets: dict[str, str] = {}
    api_key_saved = False

    try:
        # ── Phase 1: Pre-API-key (pure scripted) ──

        _write(
            "\nHey! I'm Otto. Looks like this is your first time running me.\n"
            "Let's get you set up — it only takes a minute.\n\n"
        )

        # Provider selection
        _write(
            "What LLM provider do you want to use?\n"
            "  1. Anthropic (Claude)\n"
            "  2. OpenRouter (multi-model)\n"
            "  3. Cerebras (fast inference)\n"
        )

        provider_name = ""
        env_var_name = ""
        default_model = ""

        while True:
            choice = _prompt("> ").strip()
            if choice in PROVIDERS:
                provider_name, env_var_name, default_model = PROVIDERS[choice]
                break
            _write("Please enter 1, 2, or 3.\n")

        # API key
        _write(f"\nPaste your {provider_name.title()} API key:\n")

        api_key = ""
        while True:
            api_key = _prompt("> ").strip()
            if not api_key:
                _write("API key cannot be empty. Try again.\n")
                continue
            _write("Validating... ")
            if _validate_api_key(provider_name, api_key):
                _write("\u2713 Key works!\n\n")
                break
            _write("That key didn't work. Try again?\n")

        # Save .env immediately after key validation
        secrets[env_var_name] = api_key
        _write_env_file(secrets)
        api_key_saved = True
        # Also set in current process so config loading works
        os.environ[env_var_name] = api_key

        # Model selection
        _write(f"Which model? (default: {default_model})\n")
        model_input = _prompt("> ").strip()
        model = model_input if model_input else default_model

        # ── Phase 2: Post-API-key (hybrid scripted) ──

        # Telegram setup
        _write("\nWant to connect a Telegram bot? You can always add one later.\n")
        telegram_token = None
        telegram_user_id = None

        wants_telegram = None
        while wants_telegram is None:
            tg_input = _prompt("> ").strip()
            if not tg_input:
                wants_telegram = False
                break
            wants_telegram = await _parse_yes_no(tg_input, api_key, provider_name, model)
            if wants_telegram is None:
                _write("Sorry, was that a yes or no?\n")

        if wants_telegram:
            # Telegram token
            _write("\nPaste your Telegram bot token from @BotFather:\n")
            while True:
                telegram_token = _prompt("> ").strip()
                if not telegram_token:
                    _write("Token cannot be empty. Try again.\n")
                    continue
                _write("Validating... ")
                if _validate_telegram_token(telegram_token):
                    _write("\u2713 Token works!\n\n")
                    break
                _write("That token didn't work. Try again?\n")

            secrets["TELEGRAM_BOT_TOKEN"] = telegram_token
            _write_env_file(secrets)
            os.environ["TELEGRAM_BOT_TOKEN"] = telegram_token

            # Telegram user ID
            _write("What's your Telegram user ID? Send /start to @userinfobot to find it.\n")
            while True:
                uid_input = _prompt("> ").strip()
                try:
                    telegram_user_id = int(uid_input)
                    break
                except ValueError:
                    _write("That doesn't look like a number. Try again.\n")

        # Owner name
        default_name = _get_os_username()
        default_suffix = f" (default: {default_name})" if default_name else ""
        _write(f"\nWhat should I call you?{default_suffix}\n")
        name_input = _prompt("> ").strip()
        owner_name = name_input if name_input else (default_name or "user")

        # Build and write config
        config = _build_config(
            provider=provider_name,
            model=model,
            owner_name=owner_name,
            telegram_token=telegram_token,
            telegram_user_id=telegram_user_id,
        )

        ensure_dirs()
        from otto.config import CONFIG_FILE

        save_config(config, CONFIG_FILE)
        CONFIG_FILE.chmod(0o644)

        _write("\nYou're all set. What can I help you with?\n\n")

        # Reload the config so env refs are resolved
        from otto.config import load_config

        return load_config(CONFIG_FILE)

    except (KeyboardInterrupt, EOFError):
        _write("\n")
        if api_key_saved:
            _write("Setup interrupted. Your API key was saved to ~/.otto/.env\n")
        return None
