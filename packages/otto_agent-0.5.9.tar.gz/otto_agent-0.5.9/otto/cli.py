from __future__ import annotations

import asyncio
import os
import signal
from contextlib import suppress
from pathlib import Path
from typing import override

import clypi
from clypi import Command, Spinner

from otto.config import (
    CONFIG_FILE,
    OTTO_HOME,
    AgentConfig,
    Config,
    ConfigError,
    TelegramBotConfig,
    TelegramConfig,
    WorkspaceConfig,
    ensure_dirs,
    load_config,
    save_config,
)

ENV_FILE = OTTO_HOME / ".env"
DEFAULT_MODEL = "anthropic/claude-sonnet-4-5-20250514"

PROVIDER_ENV_VARS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
    "ollama": None,
}
VALID_AUTH_PROVIDERS = ("anthropic", "google", "openai", "copilot")
VALID_WORKSPACE_MODES = ("default", "strict")
VALID_WORKSPACE_SANDBOXES = ("none", "bubblewrap")


# === Setup Helpers ===


def _provider_from_model(model: str) -> str:
    """Extract provider from 'provider/model-name' string."""
    if "/" not in model:
        raise SystemExit(f"  Model must be in 'provider/name' format, got: {model}")
    return model.split("/", 1)[0].strip().lower()


def _provider_env_var(provider: str) -> str | None:
    known = PROVIDER_ENV_VARS.get(provider)
    if known is not None or provider in PROVIDER_ENV_VARS:
        return known
    return f"{provider.upper()}_API_KEY"


def _require_env_var(var_name: str) -> str:
    """Return env var value or hard-fail with actionable message."""
    value = os.environ.get(var_name, "").strip()
    if value:
        print(f"  {var_name} ✓")
        return value
    print(f"\n  Missing required environment variable: {var_name}")
    print("  Set it before running setup:")
    print(f"    export {var_name}='your-key-here'\n")
    raise SystemExit(1)


def _prompt_owner_id() -> int | None:
    owner_id_raw = clypi.prompt("Telegram owner user id (optional)", default="").strip()
    if not owner_id_raw:
        return None

    try:
        return int(owner_id_raw)
    except ValueError:
        print("Invalid Telegram owner id. Leaving owner_id unset for bootstrap mode.")
        return None


def _prompt_workspace_root() -> str:
    root = clypi.prompt("Workspace root", default="~").strip()
    return root or "~"


def _prompt_workspace_mode() -> str:
    while True:
        value = clypi.prompt(
            "Workspace mode (default|strict)", default=VALID_WORKSPACE_MODES[0]
        ).strip()
        mode = value.lower() or VALID_WORKSPACE_MODES[0]
        if mode in VALID_WORKSPACE_MODES:
            return mode
        print("Invalid workspace mode. Use 'default' or 'strict'.")


def _prompt_workspace_sandbox() -> str:
    while True:
        value = clypi.prompt(
            "Workspace sandbox (none|bubblewrap)", default=VALID_WORKSPACE_SANDBOXES[0]
        ).strip()
        sandbox = value.lower() or VALID_WORKSPACE_SANDBOXES[0]
        if sandbox in VALID_WORKSPACE_SANDBOXES:
            return sandbox
        print("Invalid workspace sandbox. Use 'none' or 'bubblewrap'.")


def _write_env_file(secrets: dict[str, str]) -> None:
    env_lines = [f"{key}={value}" for key, value in secrets.items() if value]
    ENV_FILE.write_text("\n".join(env_lines) + "\n", encoding="utf-8")
    ENV_FILE.chmod(0o600)


def _write_config_file(
    model: str,
    owner_id: int | None,
    *,
    workspace_root: str,
    workspace_mode: str,
    workspace_sandbox: str,
) -> None:
    owner_id_value = owner_id if owner_id is not None else 0
    workspace_root_path = Path(workspace_root)
    config = Config(
        telegram=TelegramConfig(
            token="${TELEGRAM_BOT_TOKEN}",
            owner_id=owner_id_value,
            allowed_users=[],
            bootstrap="first_user",
            bots=[TelegramBotConfig(alias="default", token="${TELEGRAM_BOT_TOKEN}")],
        ),
        agent=AgentConfig(model=model),
        log_level="info",
        workdir=workspace_root_path,
        env_file=".env",
        workspace=WorkspaceConfig(
            root=workspace_root_path,
            mode=workspace_mode,
            sandbox=workspace_sandbox,
        ),
    )
    save_config(config, CONFIG_FILE)
    CONFIG_FILE.chmod(0o644)


def _write_setup_files(
    *,
    model: str,
    owner_id: int | None,
    workspace_root: str,
    workspace_mode: str,
    workspace_sandbox: str,
    secrets: dict[str, str],
) -> None:
    ensure_dirs()
    _write_env_file(secrets)
    _write_config_file(
        model,
        owner_id,
        workspace_root=workspace_root,
        workspace_mode=workspace_mode,
        workspace_sandbox=workspace_sandbox,
    )


def _run_sync_daemon_command(name: str) -> bool:
    try:
        import otto.daemon as daemon_module
    except Exception:
        return False

    daemon_fn = getattr(daemon_module, name, None)
    if daemon_fn is None:
        return False

    daemon_fn()
    return True


def _default_web_config() -> Config:
    return Config(
        telegram=TelegramConfig(
            token="",
            owner_id=None,
            allowed_users=[],
            bootstrap="first_user",
            bots=[],
        ),
        agent=AgentConfig(model=DEFAULT_MODEL),
        log_level="info",
        workdir=Path("~").expanduser(),
        env_file=None,
        workspace=WorkspaceConfig(root=Path("~").expanduser()),
    )


def _mask_secret(secret: str) -> str:
    if len(secret) <= 8:
        return "***"
    return f"{secret[:4]}...{secret[-4:]}"


def _masked_credential_detail(creds: dict[str, object]) -> str:
    for key in ("access", "key", "refresh"):
        value = creds.get(key)
        if isinstance(value, str) and value:
            return f"{key}={_mask_secret(value)}"
    return "no token fields"


# === Commands ===


class Setup(Command):
    """Set up Otto in under 3 minutes."""

    @override
    async def run(self) -> None:
        if CONFIG_FILE.exists():
            overwrite = clypi.confirm("Config exists. Overwrite?", default=False)
            if not overwrite:
                print("Setup cancelled.")
                return

        model = clypi.prompt("Default model", default=DEFAULT_MODEL).strip()
        provider = _provider_from_model(model)
        env_var = _provider_env_var(provider)

        print("Checking environment...")
        telegram_token = _require_env_var("TELEGRAM_BOT_TOKEN")
        secrets: dict[str, str] = {"TELEGRAM_BOT_TOKEN": telegram_token}
        if env_var:
            secrets[env_var] = _require_env_var(env_var)

        owner_id = _prompt_owner_id()
        workspace_root = _prompt_workspace_root()
        workspace_mode = _prompt_workspace_mode()
        workspace_sandbox = _prompt_workspace_sandbox()

        async with Spinner("Writing Otto configuration"):
            await asyncio.to_thread(
                _write_setup_files,
                model=model,
                owner_id=owner_id,
                workspace_root=workspace_root,
                workspace_mode=workspace_mode,
                workspace_sandbox=workspace_sandbox,
                secrets=secrets,
            )

        bot_name = _bot_username(telegram_token)
        _print_summary(
            model=model,
            provider=provider,
            owner_id=owner_id,
            workspace_root=Path(workspace_root).expanduser(),
            workspace_mode=workspace_mode,
            workspace_sandbox=workspace_sandbox,
            bot_name=bot_name,
        )

        start_now = clypi.confirm("Start Otto now?", default=True)
        if start_now:
            _spawn_background()


# === Setup Display ===


def _bot_username(token: str) -> str | None:
    """Fetch bot username from Telegram API. Returns None on failure."""
    try:
        import json
        import urllib.request

        url = f"https://api.telegram.org/bot{token}/getMe"
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("result", {}).get("username")
    except Exception:
        return None


def _print_summary(
    *,
    model: str,
    provider: str,
    owner_id: int | None,
    workspace_root: Path,
    workspace_mode: str,
    workspace_sandbox: str,
    bot_name: str | None,
) -> None:
    w = 52
    bar = "─" * w
    print(f"\n  ┌{bar}┐")
    print(f"  │{'Otto setup complete!':^{w}}│")
    print(f"  ├{bar}┤")
    print(f"  │  {'Model:':<14}{model:<{w - 16}}│")
    print(f"  │  {'Provider:':<14}{provider:<{w - 16}}│")
    print(f"  │  {'Config:':<14}{str(CONFIG_FILE):<{w - 16}}│")
    print(f"  │  {'Env file:':<14}{str(ENV_FILE):<{w - 16}}│")
    print(f"  │  {'Logs:':<14}{str(OTTO_HOME / 'logs'):<{w - 16}}│")
    print(f"  │  {'Workspace:':<14}{str(workspace_root):<{w - 16}}│")
    print(f"  │  {'Mode:':<14}{workspace_mode:<{w - 16}}│")
    print(f"  │  {'Sandbox:':<14}{workspace_sandbox:<{w - 16}}│")
    print(f"  │  {'Bot entry:':<14}{'telegram.bots[0].alias=default':<{w - 16}}│")
    print(f"  │  {'Token env:':<14}{'${TELEGRAM_BOT_TOKEN}':<{w - 16}}│")
    if owner_id:
        print(f"  │  {'Owner ID:':<14}{str(owner_id):<{w - 16}}│")
    else:
        print(f"  │  {'Bootstrap:':<14}{'first user claims ownership':<{w - 16}}│")
    print(f"  ├{bar}┤")
    print(f"  │{'Quick start':^{w}}│")
    print(f"  ├{bar}┤")
    if bot_name:
        print(f"  │  1. Open @{bot_name} in Telegram{' ' * (w - 22 - len(bot_name))}│")
    else:
        print(f"  │  {'1. Open your bot in Telegram':<{w - 2}}│")
    print(f"  │  {'2. Send /start to activate the bot':<{w - 2}}│")
    print(f"  │  {'3. Send any message to chat with Otto':<{w - 2}}│")
    print(f"  ├{bar}┤")
    print(f"  │  {'otto start':<16}{'Start Otto in the background':<{w - 18}}│")
    print(f"  │  {'otto stop':<16}{'Stop Otto':<{w - 18}}│")
    print(f"  │  {'otto status':<16}{'Check if Otto is running':<{w - 18}}│")
    print(f"  │  {'otto config':<16}{'Show current configuration':<{w - 18}}│")
    print(f"  └{bar}┘\n")


# === Daemon Control ===


def _spawn_background(bot_alias: str | None = None) -> None:
    """Launch 'otto run' as a detached background process."""
    import subprocess
    import sys
    import time

    from otto.daemon import _pid_file, is_running

    if is_running(bot_alias):
        target = f"Otto ({bot_alias})" if bot_alias else "Otto"
        print(f"{target} is already running. Use 'otto status' or 'otto stop'.")
        return

    log_dir = OTTO_HOME / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    crash_log = log_dir / (f"otto-{bot_alias}-crash.log" if bot_alias else "otto-crash.log")
    pid_file = _pid_file(bot_alias)

    # Remove stale PID file so we can detect fresh startup
    pid_file.unlink(missing_ok=True)

    crash_fh = open(crash_log, "w")  # noqa: SIM115
    args = [sys.executable, "-m", "otto.cli", "run"]
    if bot_alias:
        args.append(bot_alias)

    proc = subprocess.Popen(
        args,
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        stderr=crash_fh,
    )

    # Wait for PID file (written after bot starts polling) or process death
    for _ in range(10):
        time.sleep(1)
        if pid_file.exists():
            crash_fh.close()
            crash_log.unlink(missing_ok=True)
            target = f"Otto ({bot_alias})" if bot_alias else "Otto"
            log_file = log_dir / (f"otto.{bot_alias}.log" if bot_alias else "otto.log")
            print(f"{target} started (PID {proc.pid}). Logs: {log_file}")
            print("Use 'otto status' to check, 'otto stop' to stop.")
            return
        if proc.poll() is not None:
            break

    crash_fh.close()
    crash_output = crash_log.read_text(encoding="utf-8").strip()
    print("Otto failed to start.")
    if crash_output:
        print(crash_output)
    else:
        log_file = log_dir / (f"otto.{bot_alias}.log" if bot_alias else "otto.log")
        print(f"Check logs: {log_file}")


class Start(Command):
    """Start Otto in the background."""

    bot: clypi.Positional[str] = clypi.arg(default="", help="Bot alias to start")

    @override
    async def run(self) -> None:
        _spawn_background(self.bot or None)


class Run(Command):
    """Run Otto services in the foreground (used internally)."""

    bot: clypi.Positional[str] = clypi.arg(default="", help="Bot alias to run")

    @override
    async def run(self) -> None:
        from otto.daemon import start_services

        config = load_config()
        try:
            await start_services(config, bot_alias=self.bot or None)
        except RuntimeError as exc:
            message = str(exc)
            if "already running" in message.lower():
                print(message)
                return
            raise


class Stop(Command):
    """Stop Otto services."""

    bot: clypi.Positional[str] = clypi.arg(default="", help="Bot alias to stop")

    @override
    async def run(self) -> None:
        from otto.daemon import stop_daemon

        stop_daemon(self.bot or None)


# === Status Display ===


def _print_status_box(config: Config) -> None:
    """Print a status box with config and service state."""
    from otto.daemon import _pid_file, is_running

    provider = config.agent.model.split("/", 1)[0] if "/" in config.agent.model else "unknown"

    # Main bot status
    main_running = is_running("main") or is_running(None)
    main_pid = ""
    if main_running:
        pf = _pid_file("main")
        if not pf.exists():
            pf = _pid_file(None)
        if pf.exists():
            with suppress(Exception):
                main_pid = pf.read_text(encoding="utf-8").strip()

    status_icon = "● running" if main_running else "○ stopped"

    w = 52
    bar = "─" * w
    print(f"\n  ┌{bar}┐")
    print(f"  │{'Otto':^{w}}│")
    print(f"  ├{bar}┤")
    if main_running:
        print(f"  │  {'Status:':<14}{status_icon + ' (PID ' + main_pid + ')':<{w - 16}}│")
    else:
        print(f"  │  {'Status:':<14}{status_icon:<{w - 16}}│")

    # Other bots
    bot_aliases = [bot.alias for bot in config.telegram.bots]
    if bot_aliases:
        print(f"  ├{bar}┤")
        print(f"  │  {'Bots:':<{w - 4}}│")

        # Show main bot first
        main_running = is_running("main") or is_running(None)
        main_icon = "●" if main_running else "○"
        main_pid_text = ""
        if main_running:
            pf = _pid_file("main")
            if not pf.exists():
                pf = _pid_file(None)
            if pf.exists():
                with suppress(Exception):
                    main_pid_text = f" (PID {pf.read_text(encoding='utf-8').strip()})"
        print(f"  │    {main_icon} {'main':<10}{main_pid_text:<{w - 19}}│")

        for alias in bot_aliases:
            if alias in ("main", "default"):
                continue
            running = is_running(alias)
            icon = "●" if running else "○"
            pid = ""
            if running:
                with suppress(Exception):
                    pid = f" (PID {_pid_file(alias).read_text(encoding='utf-8').strip()})"
            print(f"  │    {icon} {alias:<10}{pid:<{w - 19}}│")

    print(f"  ├{bar}┤")
    print(f"  │  {'Model:':<14}{config.agent.model:<{w - 16}}│")
    print(f"  │  {'Provider:':<14}{provider:<{w - 16}}│")
    print(f"  │  {'Log level:':<14}{config.log_level:<{w - 16}}│")
    print(f"  │  {'Config:':<14}{str(CONFIG_FILE):<{w - 16}}│")
    print(f"  │  {'Logs:':<14}{str(OTTO_HOME / 'logs' / 'otto.log'):<{w - 16}}│")
    oid = config.telegram.owner_id
    if oid and oid != 0:
        print(f"  │  {'Owner ID:':<14}{str(oid):<{w - 16}}│")
    else:
        print(f"  │  {'Bootstrap:':<14}{config.telegram.bootstrap:<{w - 16}}│")

    if not main_running:
        print(f"  ├{bar}┤")
        print(f"  │  {'Run: otto start':<{w - 2}}│")
    else:
        print(f"  ├{bar}┤")
        print(f"  │  {'otto stop':<16}{'Stop Otto':<{w - 18}}│")
        print(f"  │  {'otto config':<16}{'Show raw configuration':<{w - 18}}│")
    print(f"  └{bar}┘\n")


class Status(Command):
    """Show Otto service status and configuration."""

    @override
    async def run(self) -> None:
        try:
            config = load_config()
        except ConfigError as exc:
            print(f"Failed to load config: {exc}")
            return

        _print_status_box(config)


class ConfigCmd(Command):
    """Show raw configuration values."""

    @override
    async def run(self) -> None:
        try:
            config = load_config()
        except ConfigError as exc:
            print(f"Failed to load config: {exc}")
            return

        print("Current configuration:")
        print(f"  env_file = {config.env_file}")
        print(f"  log_level = {config.log_level}")
        print(f"  workdir = {config.workdir}")
        print(f"  workspace.root = {config.workspace.root}")
        print(f"  workspace.mode = {config.workspace.mode}")
        print(f"  workspace.sandbox = {config.workspace.sandbox}")
        print(f"  agent.model = {config.agent.model}")
        print(f"  telegram.token = {config.telegram.token}")
        print(f"  telegram.owner_id = {config.telegram.owner_id}")
        print(f"  telegram.allowed_users = {config.telegram.allowed_users}")
        print(f"  telegram.bootstrap = {config.telegram.bootstrap}")
        for index, bot in enumerate(config.telegram.bots):
            print(f"  telegram.bots[{index}].alias = {bot.alias}")


class Logs(Command):
    """Stream Otto logs in human-readable format."""

    follow: bool = clypi.arg(default=False, short="-f", help="Follow log output")
    lines: int = clypi.arg(default=50, short="-n", help="Number of recent lines to show")
    level: str = clypi.arg(default="", short="-l", help="Minimum level (debug/info/warning/error)")

    @override
    async def run(self) -> None:
        from otto.logs_view import render_logs

        log_file = OTTO_HOME / "logs" / "otto.log"
        if not log_file.exists():
            print("No log file found. Is Otto running?")
            print(f"  Expected: {log_file}")
            return

        await render_logs(
            log_file,
            follow=self.follow,
            tail=self.lines,
            level_filter=self.level.upper() if self.level else None,
        )


class Web(Command):
    """Run Otto web UI in the foreground."""

    @override
    async def run(self) -> None:
        # Keep CLI startup fast by importing web dependencies only when needed.
        from otto.web import ConfigServer

        config = load_config() if CONFIG_FILE.exists() else _default_web_config()
        host = "127.0.0.1"
        port = config.web.port
        server = ConfigServer(config=config, host=host, port=port)
        await server.start()
        print(f"Otto web UI: http://{host}:{port}")

        stop_event = asyncio.Event()
        loop = asyncio.get_running_loop()
        registered_async_signals: list[signal.Signals] = []
        previous_sync_handlers: dict[signal.Signals, object] = {}

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, stop_event.set)
                registered_async_signals.append(sig)
            except (NotImplementedError, RuntimeError):
                previous_handler = signal.getsignal(sig)

                def _sync_handler(signum, frame) -> None:  # pragma: no cover
                    _ = signum, frame
                    stop_event.set()

                try:
                    signal.signal(sig, _sync_handler)
                    previous_sync_handlers[sig] = previous_handler
                except ValueError:  # pragma: no cover
                    continue

        try:
            await stop_event.wait()
        except KeyboardInterrupt:  # pragma: no cover
            pass
        finally:
            stop_event.set()
            with suppress(Exception):
                await server.stop()
            for sig in registered_async_signals:
                with suppress(Exception):
                    loop.remove_signal_handler(sig)
            for sig, previous_handler in previous_sync_handlers.items():
                with suppress(Exception):
                    signal.signal(sig, previous_handler)


class AuthLogin(Command):
    """Authenticate with an LLM provider via OAuth."""

    provider: clypi.Positional[str] = clypi.arg(
        help="Provider: anthropic, google, openai, or copilot"
    )

    @classmethod
    def prog(cls) -> str:
        return "login"

    @override
    async def run(self) -> None:
        import importlib
        import inspect
        import webbrowser

        from otto.auth import AuthStorage

        provider = self.provider.strip().lower()
        if provider not in VALID_AUTH_PROVIDERS:
            print(f"Unknown provider '{provider}'. Choose from: {', '.join(VALID_AUTH_PROVIDERS)}")
            raise SystemExit(1)

        try:
            auth_module = importlib.import_module(f"otto.auth.{provider}")
        except ImportError:
            print(f"OAuth login flow for '{provider}' is not available in this build.")
            raise SystemExit(1) from None

        login_fn = getattr(auth_module, "login", None)
        if not callable(login_fn):
            print(f"Provider '{provider}' does not expose a login() function.")
            raise SystemExit(1)

        storage = AuthStorage()

        def _on_auth_url(url: str, extra: str = "") -> None:
            if extra:
                print(extra)
            print(f"Open this URL in your browser: {url}")
            with suppress(Exception):
                webbrowser.open(url)

        def _on_progress(message: str) -> None:
            if message:
                print(message)

        async def _on_prompt_code() -> str:
            return clypi.prompt("Paste the authorization code").strip()

        async def _on_prompt(data: dict) -> object:
            prompt = str(data.get("message", "Enter value"))
            allow_empty = bool(data.get("allowEmpty", False))
            if allow_empty:
                return clypi.prompt(prompt, default="", show_default=False)
            return clypi.prompt(prompt)

        callbacks: dict[str, object] = {
            "on_auth_url": _on_auth_url,
            "on_prompt_code": _on_prompt_code,
            "on_progress": _on_progress,
            "on_prompt": _on_prompt,
        }

        try:
            signature = inspect.signature(login_fn)
            supports_kwargs = any(
                parameter.kind is inspect.Parameter.VAR_KEYWORD
                for parameter in signature.parameters.values()
            )
            if supports_kwargs:
                login_kwargs = callbacks
            else:
                login_kwargs = {
                    name: callback
                    for name, callback in callbacks.items()
                    if name in signature.parameters
                }

            credentials_result = login_fn(**login_kwargs)
            credentials = (
                await credentials_result
                if inspect.isawaitable(credentials_result)
                else credentials_result
            )
        except Exception as exc:
            print(f"Authentication failed for {provider}: {exc}")
            raise SystemExit(1) from exc

        if not isinstance(credentials, dict):
            print(f"Authentication failed for {provider}: invalid credentials payload")
            raise SystemExit(1)

        storage.save_credentials(provider, credentials)
        print(f"Authenticated with {provider}.")


class AuthLogout(Command):
    """Remove stored credentials for a provider."""

    provider: clypi.Positional[str] = clypi.arg(help="Provider to log out from")

    @classmethod
    def prog(cls) -> str:
        return "logout"

    @override
    async def run(self) -> None:
        from otto.auth import AuthStorage

        provider = self.provider.strip().lower()
        if provider not in VALID_AUTH_PROVIDERS:
            print(f"Unknown provider '{provider}'. Choose from: {', '.join(VALID_AUTH_PROVIDERS)}")
            raise SystemExit(1)

        storage = AuthStorage()
        existed = storage.get_credentials(provider) is not None
        storage.delete_credentials(provider)
        if existed:
            print(f"Logged out of {provider}.")
        else:
            print(f"No stored credentials for {provider}.")


class AuthStatus(Command):
    """Show stored provider credentials."""

    @classmethod
    def prog(cls) -> str:
        return "status"

    @override
    async def run(self) -> None:
        import json

        from otto.auth import AUTH_FILE, AuthStorage

        storage = AuthStorage()
        if not AUTH_FILE.exists():
            print("No stored credentials.")
            return

        try:
            payload = json.loads(AUTH_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            print("No stored credentials.")
            return

        credentials_map = payload.get("credentials")
        if not isinstance(credentials_map, dict) or not credentials_map:
            print("No stored credentials.")
            return

        print("Stored credentials:")
        for provider in sorted(credentials_map):
            credentials = storage.get_credentials(provider)
            if not isinstance(credentials, dict):
                continue

            cred_type = str(credentials.get("type", "unknown"))
            print(f"  {provider}: {cred_type} ({_masked_credential_detail(credentials)})")


class Auth(Command):
    """Authentication and credential management."""

    subcommand: AuthLogin | AuthLogout | AuthStatus | None = None


# === Entry Point ===


async def _standalone_cli(config: Config, resume_id: str | None = None) -> None:
    """Run a CLI chat session without starting the daemon.

    Used when the daemon is already running (e.g. via ``otto start``).
    Constructs minimal per-bot resources and runs the CLI channel.
    """
    from otto.chat import Chat
    from otto.cli_chat import CLIChatChannel
    from otto.config import BotAuthConfig, BotConfig, ChannelConfig
    from otto.gateway import Gateway, Policy
    from otto.log import setup as log_setup
    from otto.memory import Memory
    from otto.sessions import SessionStore
    from otto.tools import create_tools

    log_file = OTTO_HOME / "logs" / "otto.log"
    log_setup(level=config.log_level, log_file=log_file, console=False)

    # Resolve which bot to use.
    if getattr(config, "bots", None) and config.bots:
        target = next(
            (b for b in config.bots if any(c.type == "cli" for c in b.channels)),
            config.bots[0],
        )
    else:
        target = BotConfig(
            name="default",
            model=config.agent.model,
            auth=BotAuthConfig(owner="cli", allowed_users=[]),
            workspace=config.workspace,
        )

    bot_home = OTTO_HOME / "bots" / target.name
    bot_home.mkdir(parents=True, exist_ok=True)

    memory = Memory(bot_home / "data" / "memory.db")
    session_store = SessionStore(bot_home / "sessions")
    gateway = Gateway(Policy(blocked_paths=[], max_calls_per_session=0, allowed_servers=None))
    gateway.add_tools(create_tools(memory=memory))

    chat = Chat(config, gateway, session_store, memory, bot_name=target.name)
    channel = CLIChatChannel(chat, target, ChannelConfig(type="cli"), resume_id=resume_id)

    try:
        await channel.start()
    finally:
        memory.close()


class ChatCmd(Command):
    """Start an interactive CLI chat session."""

    resume: str = clypi.arg(default="", help="Resume archived session by timestamp")

    @classmethod
    def prog(cls) -> str:
        return "chat"

    @override
    async def run(self) -> None:
        if not CONFIG_FILE.exists():
            from otto.setup_flow import run_setup

            config = await run_setup()
            if config is None:
                return  # user cancelled
        else:
            config = load_config(CONFIG_FILE)
        resume_id = self.resume or None

        from otto.daemon import start_services

        try:
            await start_services(config, cli_bot="auto", cli_resume_id=resume_id)
        except RuntimeError as exc:
            if "already running" not in str(exc):
                raise
            # Daemon is running — start a standalone CLI session.
            await _standalone_cli(config, resume_id=resume_id)


class Otto(Command):
    """Otto — AI agent platform."""

    subcommand: (
        ChatCmd | Setup | Start | Run | Stop | Status | ConfigCmd | Logs | Web | Auth | None
    ) = None


def main() -> None:
    cmd = Otto.parse()
    try:
        cmd.start()
    except KeyboardInterrupt:
        # Keep Ctrl+C exits quiet for interactive commands (e.g. `otto chat`).
        # asyncio.run() raises KeyboardInterrupt from the event loop boundary,
        # which would otherwise print a full traceback.
        print("exiting...")
        return


if __name__ == "__main__":
    main()
