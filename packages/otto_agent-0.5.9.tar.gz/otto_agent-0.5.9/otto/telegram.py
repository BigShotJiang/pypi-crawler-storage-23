from __future__ import annotations

import asyncio
import base64
import contextlib
import io
import os
import tempfile
import time
from typing import Any

from telegram import BotCommand
from telegram.constants import ChatAction

from otto.chat import (
    Chat,
    Renderer,
    _persist_model,
    build_help_category_view,
    build_help_main_view,
    build_provider_picker,
    get_provider_model_buttons,
)
from otto.config import (
    BotAuthConfig,
    BotConfig,
    ChannelConfig,
    Config,
    TelegramConfig,
    UserConfig,
    resolve_user,
    save_config,
)
from otto.log import get_logger

log = get_logger("otto.telegram")


BOT_COMMANDS = [
    BotCommand("help", "Commands & reference"),
    BotCommand("status", "System status"),
    BotCommand("model", "Show/switch AI model"),
    BotCommand("new", "New session"),
    BotCommand("clear", "Clear session history"),
    BotCommand("tools", "List available tools"),
    BotCommand("stop", "Cancel current response"),
]


TELEGRAM_MAX_MESSAGE_LEN = 4096
_CHUNK_SEND_DELAY_SECONDS = 0.1
_ERROR_TAIL_CHARS = 2000
_ERROR_TRUNCATED_PREFIX = "... (truncated)\n"
_BUSY_CHAT_MESSAGE = "Still working on your previous message. Send /stop to cancel it."


def _find_split_index(text: str, max_len: int) -> int:
    if max_len <= 0:
        return 1
    window = text[:max_len]
    if not window:
        return 1

    for separator in ("\n\n", "\n"):
        split_index = window.rfind(separator)
        if split_index > 0:
            return split_index + len(separator)

    for separator in (" ", "\t"):
        split_index = window.rfind(separator)
        if split_index > 0:
            return split_index + 1

    return max_len


def _split_text_for_telegram(text: str, max_len: int = TELEGRAM_MAX_MESSAGE_LEN) -> list[str]:
    if not text:
        return []
    chunk_len = max(1, max_len)
    if len(text) <= chunk_len:
        return [text]

    chunks: list[str] = []
    remaining = text
    while remaining:
        if len(remaining) <= chunk_len:
            chunks.append(remaining)
            break
        split_index = _find_split_index(remaining, chunk_len)
        chunks.append(remaining[:split_index])
        remaining = remaining[split_index:]
    return chunks


async def _send_chunked(message: Any, text: str, **kwargs: Any) -> list[Any]:
    """Send text via reply_* methods, splitting content at Telegram's message limit."""
    method_name = kwargs.pop("_send_method", "reply_text")
    send = getattr(message, method_name)
    chunks = _split_text_for_telegram(text, TELEGRAM_MAX_MESSAGE_LEN)
    sent_messages: list[Any] = []
    for index, chunk in enumerate(chunks):
        sent_messages.append(await send(chunk, **kwargs))
        if index + 1 < len(chunks):
            await asyncio.sleep(_CHUNK_SEND_DELAY_SECONDS)
    return sent_messages


def _truncate_error(error: str) -> str:
    if len(error) <= _ERROR_TAIL_CHARS:
        return error
    return f"{_ERROR_TRUNCATED_PREFIX}{error[-_ERROR_TAIL_CHARS:]}"


def _md_to_telegram_html(text: str) -> str:
    """Convert limited markdown (bold, italic, code) to Telegram HTML."""
    import re

    # Code blocks first (```...```)
    text = re.sub(r"```(\w*)\n(.*?)```", r"<pre>\2</pre>", text, flags=re.DOTALL)
    # Inline code (`...`)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    # Bold (**...**)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    # Italic (*...*)
    text = re.sub(r"\*(.+?)\*", r"<i>\1</i>", text)
    return text


class TelegramRenderer:
    """Renders chat events as Telegram messages.

    Tool status: single-line message edited in-place showing current tool.
    Response text: sent as one message after agent completes (no streaming).
    """

    output_format = "telegram_html"

    def __init__(self, bot: Any, chat_id: int, max_len: int = TELEGRAM_MAX_MESSAGE_LEN):
        self._bot = bot
        self._chat_id = chat_id
        self._max_len = max_len
        self._buffer: list[str] = []
        self._tools_used: list[str] = []
        self._tool_names_used: list[str] = []
        self._tool_message_id: int | None = None
        self._last_tool_flush: float = 0.0

    def on_text(self, chunk: str) -> None:
        self._buffer.append(chunk)

    def on_tool_start(self, name: str, args: dict) -> None:
        self._tool_names_used.append(name)
        self._tools_used.append(self._format_tool_label(name, args))
        self._buffer.clear()  # discard intermediate thinking text

    def on_tool_end(self, name: str, result: str) -> None:
        _ = name, result

    async def send_text(self, text: str) -> None:
        await self._send(_md_to_telegram_html(text))

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = [
            [InlineKeyboardButton(label, callback_data=data) for label, data in row]
            for row in buttons
        ]
        markup = InlineKeyboardMarkup(keyboard)
        html_text = _md_to_telegram_html(text)
        try:
            await self._bot.send_message(
                chat_id=self._chat_id,
                text=html_text,
                parse_mode="HTML",
                reply_markup=markup,
            )
        except Exception:
            await self._bot.send_message(
                chat_id=self._chat_id,
                text=html_text,
                reply_markup=markup,
            )

    async def send_file(self, path: str, caption: str | None = None) -> None:
        from pathlib import Path as _Path

        file_path = _Path(path)
        try:
            with file_path.open("rb") as f:
                await self._bot.send_document(
                    chat_id=self._chat_id,
                    document=f,
                    filename=file_path.name,
                    caption=caption,
                )
        except Exception as exc:
            await self._send(f"Failed to send file: {exc}")

    async def show_error(self, error: str) -> None:
        await self._send(f"Error: {_truncate_error(error)}")

    async def flush(self) -> None:
        """Finalize tool status, then send complete response as one message."""
        await self._finalize_tools()
        text = "".join(self._buffer)
        self._buffer.clear()
        if not text:
            return
        await self._send(text)

    async def tick(self) -> None:
        """Update tool status message (called periodically while agent runs)."""
        await self._update_tool_message()

    async def _send(self, text: str) -> Any:
        chunks = self._split_text(text, self._max_len)
        if not chunks:
            return None

        sent_message: Any = None
        for index, chunk in enumerate(chunks):
            try:
                sent_message = await self._bot.send_message(
                    chat_id=self._chat_id,
                    text=chunk,
                    parse_mode="HTML",
                )
            except Exception as exc:
                if _is_retry_after(exc):
                    return None
                sent_message = await self._bot.send_message(
                    chat_id=self._chat_id,
                    text=chunk,
                )
            if index + 1 < len(chunks):
                await asyncio.sleep(_CHUNK_SEND_DELAY_SECONDS)
        return sent_message

    async def _update_tool_message(self) -> None:
        if not self._tools_used:
            return
        now = time.monotonic()
        if self._last_tool_flush and (now - self._last_tool_flush) < 2.0:
            return
        self._last_tool_flush = now

        current_tool = self._tools_used[-1]
        text = f"🔧 {current_tool}..."
        if self._tool_message_id is None:
            message = await self._send(text)
            self._tool_message_id = getattr(message, "message_id", None)
            return
        await self._safe_edit_tool_message(text)

    async def _finalize_tools(self) -> None:
        if not self._tools_used:
            return
        count = len(self._tools_used)
        summary = self._group_tool_summary(self._tool_names_used)
        text = f"✓ {count} tool{'s' if count != 1 else ''}: {summary}"
        if self._tool_message_id is None:
            message = await self._send(text)
            self._tool_message_id = getattr(message, "message_id", None)
        else:
            await self._safe_edit_tool_message(text)
        self._tools_used.clear()  # prevent tick from overwriting finalize
        self._tool_names_used.clear()

    @staticmethod
    def _split_text(text: str, max_len: int) -> list[str]:
        return _split_text_for_telegram(text, max_len)

    @staticmethod
    def _format_tool_label(name: str, args: dict) -> str:
        label_max = 60
        clean = name.removeprefix("mcp__")

        extractors: dict[str, str] = {
            "bash": "command",
            "read_file": "path",
            "edit_file": "path",
            "write_file": "path",
            "web_search": "query",
            "memory_search": "query",
            "memory_store": "key",
            "fetch": "url",
            "browse": "url",
            "view_image": "path",
        }

        short_names: dict[str, str] = {
            "read_file": "read",
            "write_file": "write",
            "edit_file": "edit",
            "web_search": "search",
            "memory_search": "mem search",
            "memory_store": "mem store",
            "view_image": "image",
        }

        arg_key = extractors.get(clean)
        if arg_key:
            value = args.get(arg_key, "")
            if value:
                label = short_names.get(clean, clean)
                full = f"{label}: {value}"
                if len(full) > label_max:
                    return full[: label_max - 1] + "…"
                return full

        return clean.replace("_", " ").title()

    @staticmethod
    def _group_tool_summary(names: list[str]) -> str:
        short: dict[str, str] = {
            "read_file": "read",
            "write_file": "write",
            "edit_file": "edit",
            "web_search": "search",
            "memory_search": "mem search",
            "memory_store": "mem store",
            "view_image": "image",
        }
        counts: dict[str, int] = {}
        order: list[str] = []
        for raw in names:
            clean = raw.removeprefix("mcp__")
            label = short.get(clean, clean.replace("_", " "))
            if label not in counts:
                counts[label] = 0
                order.append(label)
            counts[label] += 1
        parts = []
        for label in order:
            c = counts[label]
            parts.append(f"{label} ×{c}")
        return ", ".join(parts)

    async def _safe_edit_tool_message(self, text: str) -> None:
        if self._tool_message_id is None:
            return
        try:
            await self._bot.edit_message_text(
                chat_id=self._chat_id,
                message_id=self._tool_message_id,
                text=text,
                parse_mode="HTML",
            )
        except Exception as exc:
            if _is_retry_after(exc):
                return
            try:
                await self._bot.edit_message_text(
                    chat_id=self._chat_id,
                    message_id=self._tool_message_id,
                    text=text,
                )
            except Exception:
                pass


def _is_retry_after(exc: BaseException) -> bool:
    return "RetryAfter" in type(exc).__name__ or "Flood control" in str(exc)


class TelegramBot:
    def __init__(
        self,
        chat: Chat,
        config: Config,
        bot_config: BotConfig | None = None,
        channel_config: ChannelConfig | None = None,
        # Legacy compat — kept so existing callers that pass positional
        # TelegramConfig still work until daemon.py is fully migrated.
        telegram_config: TelegramConfig | None = None,
        alias: str | None = None,
    ):
        self._chat = chat
        self._config = config

        # New-schema path: BotConfig + ChannelConfig provided directly.
        if bot_config is not None:
            self._bot_config: BotConfig | None = bot_config
            self._channel_config: ChannelConfig | None = channel_config
            self._telegram_config: TelegramConfig | None = None
            self._token = channel_config.token if channel_config else ""
            self._alias = bot_config.name
        else:
            # Legacy path: TelegramConfig bridge.
            self._bot_config = None
            self._channel_config = None
            self._telegram_config = telegram_config or config.telegram
            self._token = self._telegram_config.token if self._telegram_config else ""
            self._alias = alias

        self._app: Any | None = None
        self._running_tasks: dict[str, asyncio.Task] = {}  # chat_id -> agent task
        self._active_chats: set[str] = set()
        self._active_chats_lock = asyncio.Lock()
        self._log = log.bind(bot=self.alias)

    def _apply_bot_default_model(self, chat_id: str) -> None:
        """Set the per-bot model default for a chat if no override exists yet."""
        bot_model: str | None = None
        if self._bot_config is not None:
            bot_model = self._bot_config.model
        elif self._telegram_config is not None:
            for bot_cfg in self._telegram_config.bots:
                if bot_cfg.alias == self.alias:
                    bot_model = bot_cfg.model
                    break
        if not bot_model:
            return
        context_key = self._chat._context_key(chat_id, bot_id=self.alias)
        if context_key not in self._chat._model_overrides:
            self._chat._model_overrides[context_key] = bot_model

    @property
    def alias(self) -> str:
        return self._alias or "default"

    async def start(self) -> None:
        """Build application, register handlers, and start polling."""
        from telegram.ext import (
            Application,
            CallbackQueryHandler,
            CommandHandler,
            MessageHandler,
            filters,
        )

        self._log.info("starting bot")
        self._app = Application.builder().token(self._token).build()

        # Run text handlers in background so /stop can be processed while a response is active.
        self._app.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self._on_message, block=False)
        )
        self._app.add_handler(MessageHandler(filters.PHOTO, self._on_photo, block=False))
        self._app.add_handler(
            MessageHandler(filters.VOICE | filters.AUDIO, self._on_voice, block=False)
        )
        self._app.add_handler(MessageHandler(filters.Document.ALL, self._on_document, block=False))
        self._app.add_handler(CommandHandler("start", self._on_start))
        self._app.add_handler(MessageHandler(filters.COMMAND, self._on_command))
        self._app.add_handler(CallbackQueryHandler(self._on_callback))

        await self._app.initialize()
        try:
            await self._app.bot.set_my_commands(BOT_COMMANDS)
        except Exception:
            pass
        await self._app.start()

        if self._app.updater is not None:
            await self._app.updater.start_polling(drop_pending_updates=True)

    async def stop(self) -> None:
        """Gracefully stop polling and shutdown the app."""
        if self._app is None:
            return

        self._log.info("stopping bot")
        if self._app.updater is not None:
            await self._app.updater.stop()
        await self._app.stop()
        await self._app.shutdown()

    async def _run_with_renderer(
        self,
        chat_id_int: int,
        chat_id_str: str,
        context: Any,
        handler_coro,
    ) -> None:
        """Shared lifecycle: claim slot, typing indicator, tick loop, run handler, cleanup."""
        if not await self._claim_chat_slot(chat_id_str):
            return False

        renderer = TelegramRenderer(context.bot, chat_id_int)
        stop_event = asyncio.Event()
        typing_task = asyncio.create_task(self._keep_typing(chat_id_int, stop_event))
        tick_task = asyncio.create_task(self._tick_loop(renderer, stop_event))

        agent_task = asyncio.create_task(handler_coro(renderer))
        self._running_tasks[chat_id_str] = agent_task
        try:
            await agent_task
        except asyncio.CancelledError:
            await renderer.send_text("Stopped.")
        except Exception as exc:
            await renderer.show_error(str(exc))
        finally:
            self._running_tasks.pop(chat_id_str, None)
            stop_event.set()
            await typing_task
            tick_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await tick_task
            await self._release_chat_slot(chat_id_str)

    def _authorize_or_bootstrap(self, user: Any, *, event: str) -> bool:
        """Authorize user or bootstrap ownership once when allowed."""
        if self._is_authorized(user.id):
            return True
        if not self._try_bootstrap(user):
            self._log.warning(f"unauthorized {event}", user_id=user.id)
            return False
        self._log.info("user bootstrapped as owner", user_id=user.id)
        return True

    async def _run_handler_with_busy_notice(
        self,
        message: Any,
        chat_id_int: int,
        chat_id_str: str,
        context: Any,
        handler_coro,
    ) -> None:
        """Mirror _on_message slot behavior for all message handlers."""
        if not await self._claim_chat_slot(chat_id_str):
            await _send_chunked(message, _BUSY_CHAT_MESSAGE)
            return
        # _run_with_renderer handles lifecycle; release so it can claim again.
        await self._release_chat_slot(chat_id_str)
        await self._run_with_renderer(chat_id_int, chat_id_str, context, handler_coro)

    async def _on_message(self, update: Any, context: Any) -> None:
        """Handle non-command text messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None or message.text is None:
            return

        if not self._authorize_or_bootstrap(user, event="message"):
            return

        bound = self._log.bind(chat_id=chat.id, user_id=user.id)
        bound.info("message received", text=message.text[:80])

        chat_id_str = self._resolve_chat_id_str(user, chat.id)
        self._apply_bot_default_model(chat_id_str)

        async def _handler(renderer):
            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=message.text,
                renderer=renderer,
                bot_id=self.alias,
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)
        bound.info("message handled")

    async def _on_photo(self, update: Any, context: Any) -> None:
        """Handle photo messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return
        if not message.photo:
            return

        if not self._authorize_or_bootstrap(user, event="photo"):
            return

        chat_id_str = self._resolve_chat_id_str(user, chat.id)
        self._apply_bot_default_model(chat_id_str)

        caption = message.caption or ""

        async def _handler(renderer):
            photo = message.photo[-1]  # highest resolution
            file = await photo.get_file()
            data = await file.download_as_bytearray()
            b64 = base64.b64encode(bytes(data)).decode("ascii")
            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=caption,
                renderer=renderer,
                bot_id=self.alias,
                attachments=[{"type": "image", "data": b64, "mime": "image/jpeg"}],
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _on_voice(self, update: Any, context: Any) -> None:
        """Handle voice and audio messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return

        voice = message.voice or message.audio
        if voice is None:
            return

        if not self._authorize_or_bootstrap(user, event="voice"):
            return

        chat_id_str = self._resolve_chat_id_str(user, chat.id)
        self._apply_bot_default_model(chat_id_str)

        async def _handler(renderer):
            file = await voice.get_file()
            data = await file.download_as_bytearray()

            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".ogg") as tmp:
                    tmp.write(bytes(data))
                    tmp_path = tmp.name

                try:
                    from otto.transcribe import transcribe
                except ImportError:
                    await renderer.send_text(
                        "Voice transcription requires faster-whisper. "
                        "Install with: pip install 'otto-agent[voice]' then restart Otto."
                    )
                    return

                text = await transcribe(tmp_path)
                await self._chat.handle_message(
                    chat_id=chat_id_str,
                    text=text,
                    renderer=renderer,
                    bot_id=self.alias,
                )
            finally:
                if tmp_path:
                    with contextlib.suppress(OSError):
                        os.unlink(tmp_path)

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _on_document(self, update: Any, context: Any) -> None:
        """Handle document messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return

        doc = message.document
        if doc is None:
            return

        if not self._authorize_or_bootstrap(user, event="document"):
            return

        chat_id_str = self._resolve_chat_id_str(user, chat.id)
        self._apply_bot_default_model(chat_id_str)

        caption = message.caption or ""

        text_extensions = {
            ".txt",
            ".py",
            ".json",
            ".md",
            ".csv",
            ".log",
            ".xml",
            ".yaml",
            ".toml",
            ".sh",
            ".js",
            ".ts",
            ".html",
            ".css",
            ".sql",
            ".rs",
            ".go",
            ".c",
            ".h",
            ".cpp",
            ".java",
            ".rb",
            ".php",
            ".r",
            ".swift",
            ".kt",
        }

        async def _handler(renderer):
            file = await doc.get_file()
            data = await file.download_as_bytearray()
            filename = doc.file_name or "document"

            ext = os.path.splitext(filename)[1].lower()
            if ext in text_extensions:
                extracted = bytes(data).decode("utf-8", errors="replace")
            elif ext == ".pdf":
                try:
                    import pdfplumber

                    pages_text = []
                    with pdfplumber.open(io.BytesIO(bytes(data))) as pdf:
                        for page in pdf.pages:
                            page_text = page.extract_text()
                            if page_text:
                                pages_text.append(page_text)
                    extracted = "\n".join(pages_text)
                except ImportError:
                    extracted = (
                        "PDF processing requires pdfplumber. "
                        f"User sent file: {filename} ({len(data)} bytes)"
                    )
            else:
                extracted = f"User sent file: {filename} ({len(data)} bytes)"

            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=caption,
                renderer=renderer,
                bot_id=self.alias,
                attachments=[{"type": "text", "filename": filename, "content": extracted}],
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _keep_typing(self, chat_id: int, stop: asyncio.Event) -> None:
        """Send periodic typing indicators while work is in progress."""
        while not stop.is_set():
            try:
                if self._app is None:
                    break
                await self._app.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
                await asyncio.wait_for(stop.wait(), timeout=4.0)
            except TimeoutError:
                continue
            except (asyncio.CancelledError, Exception):
                break

    @staticmethod
    async def _tick_loop(renderer: TelegramRenderer, stop: asyncio.Event) -> None:
        """Call renderer.tick() periodically to update tool status."""
        while not stop.is_set():
            try:
                await renderer.tick()
                await asyncio.wait_for(stop.wait(), timeout=1.0)
            except TimeoutError:
                continue
            except (asyncio.CancelledError, Exception):
                break

    async def _on_command(self, update: Any, context: Any) -> None:
        """Handle slash commands via Chat."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None or message.text is None:
            return

        if not self._is_authorized(user.id):
            return

        parts = message.text.split(None, 1)
        command = parts[0].lstrip("/").split("@", 1)[0]
        args = parts[1] if len(parts) > 1 else ""
        chat_id_str = self._resolve_chat_id_str(user, chat.id)
        self._apply_bot_default_model(chat_id_str)

        # /stop cancels any running agent task for this chat (silent if nothing running)
        if command == "stop":
            task = self._running_tasks.get(chat_id_str)
            if task and not task.done():
                task.cancel()
            return

        renderer = TelegramRenderer(context.bot, chat.id)
        await self._chat.handle_command(
            chat_id=chat_id_str,
            command=command,
            args=args,
            renderer=renderer,
            bot_id=self.alias,
        )

    async def _on_callback(self, update: Any, context: Any) -> None:
        """Handle inline keyboard button presses."""
        query = getattr(update, "callback_query", None)
        if query is None:
            return

        user = getattr(update, "effective_user", None)
        if user is None or not self._is_authorized(user.id):
            await query.answer("Access denied.", show_alert=True)
            return

        data = getattr(query, "data", "") or ""
        if ":" not in data:
            await query.answer()
            return

        prefix, action = data.split(":", 1)
        await query.answer()

        if query.message is None:
            return
        chat_id = self._resolve_chat_id_str(user, query.message.chat_id)
        telegram_chat_id = query.message.chat_id

        if prefix == "status":
            await self._handle_status_callback(query, chat_id, telegram_chat_id, action, context)
        elif prefix == "model":
            await self._handle_model_callback(query, chat_id, action)
        elif prefix == "help":
            await self._handle_help_callback(query, chat_id, telegram_chat_id, action, context)

    async def _handle_status_callback(
        self,
        query: Any,
        chat_id: str,
        telegram_chat_id: int,
        action: str,
        context: Any,
    ) -> None:
        """Handle status button callbacks."""
        if action == "model":
            context_key = self._chat._context_key(chat_id, bot_id=self.alias)
            model = self._chat._model_overrides.get(context_key, self._config.agent.model)
            await self._edit_callback_message(query, f"Current model: {model}")
        elif action == "new":
            renderer: Renderer = TelegramRenderer(context.bot, telegram_chat_id)
            await self._chat.handle_command(
                chat_id=chat_id,
                command="new",
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )
            await self._edit_callback_message(query, "New session started.")
        elif action == "refresh":
            renderer = TelegramRenderer(context.bot, telegram_chat_id)
            await self._chat.handle_command(
                chat_id=chat_id,
                command="status",
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )

    async def _handle_model_callback(self, query: Any, chat_id: str, action: str) -> None:
        """Handle model picker button callbacks."""
        if action == "cancel":
            await self._edit_callback_message(query, "Model unchanged.")
        elif action == "custom":
            await self._edit_callback_message(
                query, "Send the model string as a message.\nExample: <code>openai/gpt-4o</code>"
            )
        elif action == "back":
            text, buttons = build_provider_picker(
                self._config, auth_storage=self._chat._auth_storage
            )
            # Replace default current model with per-chat override
            context_key = self._chat._context_key(chat_id, bot_id=self.alias)
            current = self._chat._model_overrides.get(context_key, self._config.agent.model)
            text = f"**Current Model**\n{current}\n\nSelect a provider:"
            await self._edit_callback_message(query, text, buttons=buttons)
        elif action.startswith("provider:"):
            provider_key = action.split(":", 1)[1]
            text, buttons = get_provider_model_buttons(self._config, provider_key)
            await self._edit_callback_message(query, text, buttons=buttons)
        else:
            context_key = self._chat._context_key(chat_id, bot_id=self.alias)
            self._chat._model_overrides[context_key] = action
            _persist_model(self._config, action, bot_id=self.alias)
            await self._edit_callback_message(query, f"Model set: <b>{action}</b>")

    async def _handle_help_callback(
        self,
        query: Any,
        chat_id: str,
        telegram_chat_id: int,
        action: str,
        context: Any,
    ) -> None:
        """Handle /help menu category navigation and quick launch actions."""
        if action == "back":
            text, buttons = build_help_main_view()
            await self._edit_callback_message(query, text, buttons=buttons)
            return

        if action.startswith("run:"):
            command = action.split(":", 1)[1].strip().lstrip("/")
            if not command:
                await self._edit_callback_message(query, "Unknown command.")
                return
            renderer: Renderer = TelegramRenderer(context.bot, telegram_chat_id)
            await self._chat.handle_command(
                chat_id=chat_id,
                command=command,
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )
            return

        category_view = build_help_category_view(action)
        if category_view is None:
            await self._edit_callback_message(query, "Unknown help category.")
            return

        text, buttons = category_view
        await self._edit_callback_message(query, text, buttons=buttons)

    def _resolve_chat_id_str(self, user: Any, fallback_chat_id: int) -> str:
        users = getattr(self._bot_config, "users", None)
        if not isinstance(users, list):
            users = self._config.users
        user_config = resolve_user(users, telegram_id=getattr(user, "id", None))
        if user_config is not None:
            return user_config.name
        return str(fallback_chat_id)

    @staticmethod
    def _build_inline_markup(buttons: list[list[tuple[str, str]]]) -> Any:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = [
            [InlineKeyboardButton(label, callback_data=data) for label, data in row]
            for row in buttons
        ]
        return InlineKeyboardMarkup(keyboard)

    async def _edit_callback_message(
        self,
        query: Any,
        text: str,
        *,
        buttons: list[list[tuple[str, str]]] | None = None,
    ) -> None:
        """Edit a callback query message with fallback."""
        markup = self._build_inline_markup(buttons) if buttons else None
        html_text = _md_to_telegram_html(text)
        try:
            await query.edit_message_text(text=html_text, parse_mode="HTML", reply_markup=markup)
        except Exception:
            try:
                await query.edit_message_text(text=html_text, reply_markup=markup)
            except Exception:
                pass

    async def _on_start(self, update: Any, context: Any) -> None:
        """Handle /start with bootstrap-ready messaging."""
        _ = context
        user = getattr(update, "effective_user", None)
        message = getattr(update, "message", None)
        if user is None or message is None:
            return

        if self._try_bootstrap(user):
            await _send_chunked(message, "Welcome! You are now the owner of this Otto instance.")
            return

        if self._is_authorized(user.id):
            await _send_chunked(message, "Otto is ready.")

    def _is_authorized(self, user_id: int) -> bool:
        if self._bot_config is not None:
            # New schema: resolve telegram_id -> user name, check against bot auth.
            user = resolve_user(self._config.users, telegram_id=user_id)
            if user is None:
                return False
            if user.name == self._bot_config.auth.owner:
                return True
            return user.name in self._bot_config.auth.allowed_users

        # Legacy path.
        if self._telegram_config.owner_id and user_id == self._telegram_config.owner_id:
            return True
        return user_id in self._telegram_config.allowed_users

    def _try_bootstrap(self, user: Any) -> bool:
        """If bootstrap=first_user and no owner set, claim ownership."""
        user_id = getattr(user, "id", None)
        if user_id is None:
            return False

        if self._bot_config is not None:
            return self._try_bootstrap_new(user, user_id)
        return self._try_bootstrap_legacy(user, user_id)

    def _try_bootstrap_new(self, user: Any, user_id: int) -> bool:
        """Bootstrap path for new [[bots]] schema."""
        if self._bot_config.auth.bootstrap != "first_user":
            return False
        if self._bot_config.auth.owner and self._bot_config.auth.owner.strip():
            return False

        # Derive a user name from the telegram user.
        username = getattr(user, "username", None)
        user_name = username if username else f"user_{user_id}"

        # Create a new UserConfig and add to config.users (if not already there).
        existing = resolve_user(self._config.users, telegram_id=user_id)
        if existing is None:
            new_user = UserConfig(name=user_name, telegram_id=user_id)
            updated_users = [*self._config.users, new_user]
            object.__setattr__(self._config, "users", updated_users)
        else:
            user_name = existing.name

        # Update bot auth: set owner and add to allowed_users.
        old_auth = self._bot_config.auth
        new_allowed = (
            [user_name, *old_auth.allowed_users]
            if user_name not in old_auth.allowed_users
            else list(old_auth.allowed_users)
        )
        new_auth = BotAuthConfig(
            owner=user_name,
            allowed_users=new_allowed,
            bootstrap="disabled",
        )
        # Replace the frozen BotConfig with updated auth.
        new_bot_config = BotConfig(
            name=self._bot_config.name,
            model=self._bot_config.model,
            auth=new_auth,
            workspace=self._bot_config.workspace,
            skills=self._bot_config.skills,
            channels=self._bot_config.channels,
        )
        self._bot_config = new_bot_config

        # Update the config.bots list in place.
        updated_bots = [
            new_bot_config if b.name == self._bot_config.name else b for b in self._config.bots
        ]
        object.__setattr__(self._config, "bots", updated_bots)

        try:
            save_config(self._config)
            self._log.info("bootstrap persisted", owner=user_name, telegram_id=user_id)
        except Exception as exc:
            self._log.error("failed to persist bootstrap", error=str(exc))
        return True

    def _try_bootstrap_legacy(self, user: Any, user_id: int) -> bool:
        """Bootstrap path for legacy [telegram] schema."""
        tc = self._telegram_config
        if tc is None:
            return False
        if tc.bootstrap != "first_user":
            return False
        # owner_id 0 means unset
        if tc.owner_id and tc.owner_id != 0:
            return False
        # Claim ownership and persist to disk
        new_tc = TelegramConfig(
            token=tc.token,
            owner_id=user_id,
            allowed_users=[user_id, *tc.allowed_users],
            bootstrap="disabled",
            bots=tc.bots,
        )
        self._telegram_config = new_tc

        # If this is the main bot, update the root config
        if tc is self._config.telegram:
            object.__setattr__(self._config, "telegram", new_tc)

        # Update _raw_values so save_config writes the new values (not stale snapshot)
        raw = getattr(self._config, "_raw_values", None)
        if isinstance(raw, dict) and "telegram" in raw:
            if tc is self._config.telegram:
                raw["telegram"]["owner_id"] = user_id
                raw["telegram"]["allowed_users"] = [user_id, *tc.allowed_users]
                raw["telegram"]["bootstrap"] = "disabled"
        try:
            save_config(self._config)
            self._log.info("bootstrap persisted", owner_id=user_id)
        except Exception as exc:
            self._log.error("failed to persist bootstrap", error=str(exc))
        return True

    async def _claim_chat_slot(self, chat_id: str) -> bool:
        """Reserve a chat for one active text message run at a time."""
        async with self._active_chats_lock:
            if chat_id in self._active_chats:
                return False
            self._active_chats.add(chat_id)
            return True

    async def _release_chat_slot(self, chat_id: str) -> None:
        """Release a previously reserved chat slot."""
        async with self._active_chats_lock:
            self._active_chats.discard(chat_id)


__all__ = ["TelegramBot", "TelegramRenderer"]
