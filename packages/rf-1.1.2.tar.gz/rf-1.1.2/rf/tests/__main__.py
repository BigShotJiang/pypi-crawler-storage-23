from rf.tests import run

run()
