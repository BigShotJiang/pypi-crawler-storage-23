"""
Briefcase VCS integration for multi-provider version control and data versioning.

This module provides unified client interfaces for 7 different VCS providers:
- DVC (Data Version Control)
- Nessie (Apache Iceberg metadata service)
- Pachyderm (container-native data versioning)
- ArtiVC (Git-like VCS for artifacts)
- DuckLake (DuckDB + lakeFS)
- Iceberg (Apache Iceberg table format)
- Git LFS (Git Large File Storage)

Each provider is available as an optional integration with automatic import
handling for missing dependencies.

Usage:
    from briefcase.integrations.vcs import DvcClient, NessieClient

    # Using DVC
    dvc_client = DvcClient(
        repository="my-repo",
        branch="main",
        briefcase_client=client
    )
    data = dvc_client.read_object("data/training.csv")

    # Using Nessie
    nessie_client = NessieClient(
        repository="my-iceberg-catalog",
        branch="main",
        endpoint="https://nessie.example.com"
    )
    with nessie_client:
        nessie_client.create_version("Updated training data")

    # Multiple providers in sequence
    for provider_client in [dvc_client, nessie_client]:
        provider_client.write_object("results/output.csv", data)
"""

from briefcase.integrations.vcs.base import VcsClientBase

# Import each provider with graceful fallback for missing dependencies
_dvc_client = None
_nessie_client = None
_pachyderm_client = None
_artivc_client = None
_ducklake_client = None
_iceberg_client = None
_gitlfs_client = None

try:
    from briefcase.integrations.vcs.dvc import DvcClient
    _dvc_client = DvcClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.nessie import NessieClient
    _nessie_client = NessieClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.pachyderm import PachydermClient
    _pachyderm_client = PachydermClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.artivc import ArtiVCClient
    _artivc_client = ArtiVCClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.ducklake import DuckLakeClient
    _ducklake_client = DuckLakeClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.iceberg import IcebergClient
    _iceberg_client = IcebergClient
except ImportError:
    pass

try:
    from briefcase.integrations.vcs.gitlfs import GitLFSClient
    _gitlfs_client = GitLFSClient
except ImportError:
    pass

__all__ = [
    "VcsClientBase",
]

# Conditionally export available clients
if _dvc_client:
    __all__.append("DvcClient")
    DvcClient = _dvc_client

if _nessie_client:
    __all__.append("NessieClient")
    NessieClient = _nessie_client

if _pachyderm_client:
    __all__.append("PachydermClient")
    PachydermClient = _pachyderm_client

if _artivc_client:
    __all__.append("ArtiVCClient")
    ArtiVCClient = _artivc_client

if _ducklake_client:
    __all__.append("DuckLakeClient")
    DuckLakeClient = _ducklake_client

if _iceberg_client:
    __all__.append("IcebergClient")
    IcebergClient = _iceberg_client

if _gitlfs_client:
    __all__.append("GitLFSClient")
    GitLFSClient = _gitlfs_client
