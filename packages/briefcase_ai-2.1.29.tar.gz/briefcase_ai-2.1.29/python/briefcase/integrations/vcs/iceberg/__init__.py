"""Iceberg integration for Briefcase."""

from briefcase.integrations.vcs.iceberg.client import IcebergClient

__all__ = ["IcebergClient"]
