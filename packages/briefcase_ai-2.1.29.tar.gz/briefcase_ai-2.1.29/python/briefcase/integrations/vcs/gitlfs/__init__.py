"""Git LFS integration for Briefcase."""

from briefcase.integrations.vcs.gitlfs.client import GitLFSClient

__all__ = ["GitLFSClient"]
