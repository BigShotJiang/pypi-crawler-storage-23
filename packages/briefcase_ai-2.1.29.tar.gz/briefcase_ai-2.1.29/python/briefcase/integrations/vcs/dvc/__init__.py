"""DVC (Data Version Control) integration for Briefcase."""

from briefcase.integrations.vcs.dvc.client import DvcClient

__all__ = ["DvcClient"]
