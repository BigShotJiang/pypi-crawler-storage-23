"""DuckLake integration for Briefcase."""

from briefcase.integrations.vcs.ducklake.client import DuckLakeClient

__all__ = ["DuckLakeClient"]
