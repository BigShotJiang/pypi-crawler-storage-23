"""
Framework integration callback handlers for automatic decision capture.

Provides drop-in callbacks for popular AI frameworks:
  - LangChain: BriefcaseLangChainHandler
  - LlamaIndex: BriefcaseLlamaIndexHandler
"""

from briefcase.integrations.frameworks.langchain_handler import (
    BriefcaseLangChainHandler,
)
from briefcase.integrations.frameworks.llamaindex_handler import (
    BriefcaseLlamaIndexHandler,
)

__all__ = [
    "BriefcaseLangChainHandler",
    "BriefcaseLlamaIndexHandler",
]
