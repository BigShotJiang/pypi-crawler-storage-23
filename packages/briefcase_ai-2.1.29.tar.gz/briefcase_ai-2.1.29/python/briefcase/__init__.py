"""
Briefcase SDK - OpenTelemetry instrumentation for AI applications.

This module provides comprehensive observability, versioning, and compliance
features for AI applications including lakeFS integration, multi-agent
correlation, RAG versioning, and external data tracking.

Phase 1 Features:
- lakeFS commit SHA capture for knowledge base versioning
- Multi-agent workflow correlation with automatic trace propagation
- Compliance report generation (SOC2, HIPAA, GDPR)

Phase 2 Features:
- RAG component versioning (documents, embeddings, indices)
- External data source versioning and snapshot management
- Vector database integrations (Pinecone, Weaviate, Chroma)

Phase 3 Features:
- Prompt-knowledge validation engine (3-layer architecture)
- Reference extraction and resolution against lakeFS
- Semantic validation with LLM-based content checking
- Multiple validation modes (strict, tolerant, warn-only)

Usage:
    from briefcase.integrations.lakefs import lakefs_context, lakefs_versioned
    from briefcase.correlation import briefcase_workflow
    from briefcase.compliance.reports import SOC2ReportGenerator
    from briefcase.rag import VersionedEmbeddingPipeline
    from briefcase.external_data import ExternalDataTracker
    from briefcase.validation import PromptValidationEngine

Example:
    # lakeFS versioning
    with lakefs_context(client, "acme-healthcare", "main") as lakefs:
        policy = lakefs.read_object("policies/policy.pdf")

    # Multi-agent correlation
    with briefcase_workflow("prior_auth", client) as workflow:
        result1 = agent1.process(data)
        result2 = agent2.process(result1)

    # Compliance reporting
    generator = SOC2ReportGenerator(client)
    report = generator.evaluate("acme", "main", start_date, end_date)

Version: 2.1.29
"""

__version__ = "2.1.29"

# Import key components
from briefcase import semantic_conventions
from briefcase import integrations
from briefcase import correlation
from briefcase import compliance
from briefcase import rag
from briefcase import external_data
from briefcase import validation

__all__ = [
    "semantic_conventions",
    "integrations",
    "correlation",
    "compliance",
    "rag",
    "external_data",
    "validation",
    "__version__",
]
