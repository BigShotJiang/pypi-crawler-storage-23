"""
Semantic conventions for Briefcase SDK.

This module provides standardized attribute names for telemetry data
to ensure consistency across all integrations and features.
"""

from briefcase.semantic_conventions import lakefs
from briefcase.semantic_conventions import workflow
from briefcase.semantic_conventions import rag
from briefcase.semantic_conventions import external_data

__all__ = ["lakefs", "workflow", "rag", "external_data"]
