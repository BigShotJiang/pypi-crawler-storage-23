"""
Correlation utilities for multi-agent workflows.
"""

from briefcase.correlation.workflow import briefcase_workflow, BriefcaseWorkflowContext, get_current_workflow
from briefcase.correlation.propagation import TraceContextCarrier, inject_trace_context, extract_trace_context

__all__ = [
    "briefcase_workflow",
    "BriefcaseWorkflowContext",
    "get_current_workflow",
    "TraceContextCarrier",
    "inject_trace_context",
    "extract_trace_context",
]
