"""Briefcase AI package bootstrap.

Primary API comes from the Rust extension module ``briefcase_ai._core``.
Compatibility shims for legacy imports are also exported.
"""

from ._core import *  # noqa: F401,F403
from ._core import __author__, __version__

from ._compat import (
    briefcase_workflow,
    lakefs_context,
    lakefs_versioned,
    versioned,
    versioned_context,
)

try:
    from ._core import __all__ as _core_all
except ImportError:
    _core_all = [name for name in globals() if not name.startswith("_")]

__all__ = list(
    dict.fromkeys(
        list(_core_all)
        + [
            "versioned",
            "lakefs_versioned",
            "versioned_context",
            "lakefs_context",
            "briefcase_workflow",
            "__version__",
            "__author__",
        ]
    )
)
