"""Compatibility bridge for ``briefcase_ai.rag``."""

from briefcase_ai._compat import _bridge_module

_bridge_module(
    __name__,
    "briefcase.rag",
    submodules=("embedding_pipeline", "retrieval", "vector_stores"),
)
