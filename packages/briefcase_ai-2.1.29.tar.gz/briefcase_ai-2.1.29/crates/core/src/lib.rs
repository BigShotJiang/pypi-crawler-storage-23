//! # Briefcase AI Core Library
//!
//! High-performance AI observability, replay, and decision tracking for Rust applications.
//!
//! ## Features
//!
//! - **AI Decision Tracking**: Capture inputs, outputs, and context for every AI decision
//! - **Deterministic Replay**: Reproduce AI decisions exactly with full context preservation
//! - **Comprehensive Observability**: Monitor model performance, drift, and behavior
//! - **Enterprise Security**: Built-in data sanitization and privacy controls
//! - **Flexible Storage**: SQLite, cloud storage, and custom backends
//! - **Cost Management**: Track and optimize AI model usage costs
//! - **Cross-Platform**: Works on Linux, macOS, Windows, and WebAssembly
//!
//! ## Quick Start
//!
//! ```rust
//! use briefcase_core::*;
//! use briefcase_core::storage::StorageBackend;
//! use serde_json::json;
//!
//! # #[tokio::main]
//! # async fn main() -> Result<(), Box<dyn std::error::Error>> {
//! // Create a decision snapshot
//! let decision = DecisionSnapshot::new("ai_function")
//!     .add_input(Input::new("user_query", json!("Hello world"), "string"))
//!     .add_output(Output::new("response", json!("Hello back!"), "string").with_confidence(0.95))
//!     .with_execution_time(120.5);
//!
//! // Save to storage (requires storage feature)
//! #[cfg(feature = "sqlite-storage")]
//! {
//!     let storage = storage::SqliteBackend::in_memory()?;
//!     let decision_id = storage.save_decision(&decision).await?;
//!     println!("Saved decision: {}", decision_id);
//! }
//! # Ok(())
//! # }
//! ```
//!
//! ## Feature Flags
//!
//! - `async` - Enable async/await support (enabled by default)
//! - `sqlite-storage` - Enable SQLite storage backend (enabled by default)
//! - `lakefs-storage` - Enable LakeFS storage backend (enabled by default)
//! - `networking` - Enable HTTP client for remote storage (enabled by default)
//! - `compression` - Enable data compression (enabled by default)
//! - `parallel` - Enable parallel processing with Rayon
//! - `sync-only` - Sync-only APIs for WebAssembly compatibility
//! - `vcs-storage` - Enable VCS provider abstraction layer
//! - `vcs-dvc` - DVC (Data Version Control) backend
//! - `vcs-nessie` - Project Nessie backend
//! - `vcs-pachyderm` - Pachyderm backend
//! - `vcs-artivc` - ArtiVC backend
//! - `vcs-ducklake` - DuckLake backend
//! - `vcs-iceberg` - Apache Iceberg backend
//! - `vcs-gitlfs` - Git + Git-LFS backend
//! - `vcs-all` - Enable all VCS backends

/// Cost calculation and management functionality
pub mod cost;

/// Drift detection and model performance monitoring
pub mod drift;

/// Core data models and structures
pub mod models;

/// Decision replay and validation
pub mod replay;

/// Data sanitization and privacy controls
pub mod sanitization;

// Storage module only available with storage features
#[cfg(any(
    feature = "sqlite-storage",
    feature = "lakefs-storage",
    feature = "vcs-storage"
))]
/// Storage backends for persisting decisions and snapshots
pub mod storage;

// Control plane abstraction for auth/authz backends (remote, local, etc.)
#[cfg(feature = "async")]
/// Control plane trait and implementations for client lookup
pub mod control;

// Client authentication module (requires networking for server validation)
#[cfg(feature = "networking")]
/// Unified client for authenticated access to the Briefcase AI platform
pub mod client;

// Re-export all public types for convenience
pub use cost::*;
pub use drift::*;
pub use models::*;
pub use replay::*;
pub use sanitization::*;

use thiserror::Error;

#[derive(Error, Debug)]
pub enum BriefcaseError {
    #[cfg(any(
        feature = "sqlite-storage",
        feature = "lakefs-storage",
        feature = "vcs-storage"
    ))]
    #[error("Storage error: {0}")]
    Storage(#[from] storage::StorageError),

    #[error("Replay error: {0}")]
    Replay(#[from] replay::ReplayError),

    #[error("Cost calculation error: {0}")]
    Cost(#[from] cost::CostError),

    #[error("Sanitization error: {0}")]
    Sanitization(#[from] sanitization::SanitizationError),

    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    #[error("Invalid input: {0}")]
    InvalidInput(String),

    #[cfg(feature = "networking")]
    #[error("Client error: {0}")]
    Client(#[from] client::ClientError),
}
