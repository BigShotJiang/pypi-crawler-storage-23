use super::super::StorageError;
use super::provider::{VcsProvider, VcsProviderConfig};
use async_trait::async_trait;
use std::collections::HashMap;
use std::path::PathBuf;
use std::process::Command;

#[derive(Clone, Debug)]
pub struct DvcConfig {
    pub repo_path: PathBuf,
    pub remote_name: String,
}

pub struct DvcProvider {
    config: DvcConfig,
    vcs_config: VcsProviderConfig,
}

impl DvcProvider {
    pub fn new(config: VcsProviderConfig) -> Result<Self, StorageError> {
        let repo_path = config
            .extra
            .get("repo_path")
            .map(|p| PathBuf::from(p))
            .unwrap_or_else(|| PathBuf::from("./briefcase_dvc"));

        let remote_name = config
            .extra
            .get("remote_name")
            .cloned()
            .unwrap_or_else(|| "origin".to_string());

        let dvc_config = DvcConfig {
            repo_path,
            remote_name,
        };

        let provider = DvcProvider {
            config: dvc_config,
            vcs_config: config,
        };

        Ok(provider)
    }

    fn is_git_repo(&self) -> bool {
        self.config.repo_path.join(".git").exists()
    }

    fn git_command(&self, args: &[&str]) -> Result<String, StorageError> {
        let output = Command::new("git")
            .current_dir(&self.config.repo_path)
            .args(args)
            .output()
            .map_err(|e| StorageError::ConnectionError(format!("Git command failed: {}", e)))?;

        if !output.status.success() {
            return Err(StorageError::ConnectionError(format!(
                "Git error: {}",
                String::from_utf8_lossy(&output.stderr)
            )));
        }

        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    }

    fn get_object_path(&self, path: &str) -> PathBuf {
        self.config.repo_path.join(path)
    }
}

#[async_trait]
impl VcsProvider for DvcProvider {
    async fn write_object(&self, path: &str, data: &[u8]) -> Result<(), StorageError> {
        let object_path = self.get_object_path(path);

        if let Some(parent) = object_path.parent() {
            tokio::task::spawn_blocking({
                let parent = parent.to_path_buf();
                move || std::fs::create_dir_all(parent)
            })
            .await
            .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
            .map_err(|e| StorageError::IoError(format!("Failed to create directories: {}", e)))?;
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            let data = data.to_vec();
            move || std::fs::write(path, data)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to write object: {}", e)))?;

        Ok(())
    }

    async fn read_object(&self, path: &str) -> Result<Vec<u8>, StorageError> {
        let object_path = self.get_object_path(path);

        if !object_path.exists() {
            return Err(StorageError::NotFound(format!(
                "Object not found: {}",
                path
            )));
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            move || std::fs::read(path)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to read object: {}", e)))
    }

    async fn list_objects(&self, prefix: &str) -> Result<Vec<String>, StorageError> {
        let base_path = self.get_object_path(prefix);

        let results = tokio::task::spawn_blocking({
            let base_path = base_path.clone();
            move || {
                let mut objects = Vec::new();
                if base_path.exists() {
                    if let Ok(entries) = std::fs::read_dir(&base_path) {
                        for entry in entries.flatten() {
                            if let Ok(metadata) = entry.metadata() {
                                if metadata.is_file() {
                                    if let Some(name) = entry.file_name().into_string().ok() {
                                        objects.push(format!("{}/{}", prefix, name));
                                    }
                                }
                            }
                        }
                    }
                }
                objects
            }
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?;

        Ok(results)
    }

    async fn delete_object(&self, path: &str) -> Result<bool, StorageError> {
        let object_path = self.get_object_path(path);

        if !object_path.exists() {
            return Ok(false);
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            move || std::fs::remove_file(path)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to delete object: {}", e)))?;

        Ok(true)
    }

    async fn create_version(&self, message: &str) -> Result<String, StorageError> {
        // Add all changes
        self.git_command(&["add", "-A"])?;

        // Commit with message
        self.git_command(&["commit", "-m", message])?;

        // Get current commit hash
        self.git_command(&["rev-parse", "HEAD"])
    }

    async fn health_check(&self) -> Result<bool, StorageError> {
        tokio::task::spawn_blocking({
            let repo_path = self.config.repo_path.clone();
            move || repo_path.join(".git").exists()
        })
        .await
        .map_err(|e| StorageError::ConnectionError(format!("Health check spawn failed: {}", e)))
    }

    fn provider_name(&self) -> &'static str {
        "dvc"
    }

    fn config_summary(&self) -> String {
        format!(
            "DVC(repo={}, remote={})",
            self.config.repo_path.display(),
            self.config.remote_name
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dvc_config_parsing() {
        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), "/tmp/my_repo".to_string());
        extra.insert("remote_name".to_string(), "myremote".to_string());

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        assert_eq!(provider.config.repo_path, PathBuf::from("/tmp/my_repo"));
        assert_eq!(provider.config.remote_name, "myremote");
    }

    #[test]
    fn test_dvc_defaults() {
        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        assert_eq!(provider.config.repo_path, PathBuf::from("./briefcase_dvc"));
        assert_eq!(provider.config.remote_name, "origin");
    }

    #[test]
    fn test_provider_name() {
        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        assert_eq!(provider.provider_name(), "dvc");
    }

    #[test]
    fn test_config_summary() {
        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), "/tmp/dvc_repo".to_string());

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let summary = provider.config_summary();
        assert!(summary.contains("dvc") || summary.contains("DVC"));
    }

    #[tokio::test]
    async fn test_write_and_read_object() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path.clone());

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let test_data = b"test content for dvc";
        let test_path = "test_file.txt";

        provider.write_object(test_path, test_data).await.unwrap();
        let read_data = provider.read_object(test_path).await.unwrap();

        assert_eq!(read_data, test_data);
    }

    #[tokio::test]
    async fn test_read_nonexistent_returns_not_found() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();

        let result = provider.read_object("nonexistent.txt").await;
        assert!(matches!(result, Err(StorageError::NotFound(_))));
    }

    #[tokio::test]
    async fn test_list_objects_with_prefix() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path.clone());

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();

        // Write multiple files
        provider
            .write_object("data/file1.txt", b"content1")
            .await
            .unwrap();
        provider
            .write_object("data/file2.txt", b"content2")
            .await
            .unwrap();
        provider
            .write_object("other/file3.txt", b"content3")
            .await
            .unwrap();

        // List objects with prefix
        let objects = provider.list_objects("data").await.unwrap();
        assert_eq!(objects.len(), 2);
        assert!(objects.iter().any(|o| o.contains("file1.txt")));
        assert!(objects.iter().any(|o| o.contains("file2.txt")));
    }

    #[tokio::test]
    async fn test_delete_object_returns_true() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let test_path = "delete_test.txt";

        provider
            .write_object(test_path, b"to delete")
            .await
            .unwrap();
        let result = provider.delete_object(test_path).await.unwrap();

        assert_eq!(result, true);
        let read_result = provider.read_object(test_path).await;
        assert!(matches!(read_result, Err(StorageError::NotFound(_))));
    }

    #[tokio::test]
    async fn test_delete_nonexistent_returns_false() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let result = provider.delete_object("nonexistent.txt").await.unwrap();

        assert_eq!(result, false);
    }

    #[tokio::test]
    async fn test_write_creates_parent_directories() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path.clone());

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let nested_path = "snapshots/deep/path/file.json";

        provider
            .write_object(nested_path, b"nested content")
            .await
            .unwrap();

        let read_data = provider.read_object(nested_path).await.unwrap();
        assert_eq!(read_data, b"nested content");
    }

    #[tokio::test]
    async fn test_health_check_existing_repo() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        // Create a .git directory to simulate a valid repo
        std::fs::create_dir(PathBuf::from(&tmp_path).join(".git")).unwrap();

        let mut extra = HashMap::new();
        extra.insert("repo_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "dvc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = DvcProvider::new(vcs_config).unwrap();
        let health = provider.health_check().await.unwrap();

        assert_eq!(health, true);
    }
}
