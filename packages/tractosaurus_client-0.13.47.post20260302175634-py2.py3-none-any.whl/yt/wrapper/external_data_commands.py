from .auth_commands import get_current_user
from .common import require, set_param
from .cypress_commands import (create, exists, set_attribute, get_attribute,
                               set, get, remove, list, search)
from .driver import make_request
from .external_source_specs import ExternalSourceSpec
from .errors import YtError
from .ypath import TablePath
from .transaction import Transaction
from .client_impl import YtClient
from .lock_commands import lock
from .retries import run_with_retries

import os
import re


################################################################################


def _get_reusable_media_path(offshore_access_registry_path):
    return f"{offshore_access_registry_path}/reusable_media"


def _get_reusable_medium_node_path(offshore_access_registry_path, medium_name):
    return f"{_get_reusable_media_path(offshore_access_registry_path)}/{medium_name}"


def _get_attached_tables_path(offshore_access_registry_path, medium_name):
    return f"{_get_reusable_media_path(offshore_access_registry_path)}/{medium_name}/attached_tables"


def _encode_attached_table_path(table_path):
    return table_path.replace("/", r"\\")


def _decode_attached_table_path(table_path):
    return table_path.replace("\\", "/")


def _get_access_ids_path(offshore_access_registry_path):
    return f"{offshore_access_registry_path}/access_ids"


def _get_access_id_node_path(offshore_access_registry_path, access_id):
    return f"{_get_access_ids_path(offshore_access_registry_path)}/{access_id}"


def _get_null_offshore_medium_config():
    return {
        "bucket": "none",
        "url": "none",
        "region": "none",
        "access_key_id": "none",
        "secret_access_key": "none",
    }


def _set_account_space_limit_for_medium(media_pool_path, medium, client):
    # Deduce the account name using the media pool file's attributes. Maybe in some
    # cases it will not be the one expected by the user, if it happens, we can add
    # a parameter to the function specifying it.
    MAX_INT64 = 9223372036854775807

    account = get_attribute(media_pool_path, "account", client=client)
    limit_path = f"//sys/accounts/{account}/@resource_limits/disk_space_per_medium/{medium}"
    if not exists(limit_path, client=client) or get(limit_path, client=client) != MAX_INT64:
        print("Updating the space limit of the account {} in medium {} to infinity".format(account, medium))
        set(limit_path, MAX_INT64, client=client)


################################################################################


def attach_table(
    destination_table,  # type: str | TablePath
    source_uris=None,  # type: list[str] | None
    source_spec=None,  # type: ExternalSourceSpec | Dict
    attach_mode="parallel",  # type: str
    source_order="none",  # type: str
    allow_incompatible_source_schemas=False,  # type: bool
    medium=None,  # type: str | None
    source_format=None,  # type: str | None
    client=None,  # type: YtClient | None
):
    """
    Attaches external sources, e.g. S3 URLs, to table.

    :param destination_table: output table. Specify `TablePath` attributes for append mode or something like `<append=%true>//path/to/table`.
        If the table does not exist, it will be created.
    :type table: str or :class:`TablePath <yt.wrapper.ypath.TablePath>`
    :param source_uris: URIs, e.g. s3://bucket/key.
    :param source_spec: exclusive with `source_uris`. type can be `files` or `prefix`.
    :param attach_mode: Controls how source URIs produced from the specified source spec are processed.
        In sequential mode, sources are attached to the table one by one in the order specified by `source_order`.
        In parallel mode (default), multiple sources can be attached concurrently, so there are no ordering guarantees.
        NB: It makes no sense to use sequential mode if the ordering of source URIs is not guaranteed either by
        the source spec itself (e.g. it is an explicit list of source URIs) or by the source order option below.
    :param source_order: Controls the order in which source URIs are fed into the attach process.
        In *sequential* attach mode, this guarantees that data from sources will appear in the table in the specified order.
        By default sources are processed in the order they are produced from the source spec, which may be unspecified.
    :param allow_incompatible_source_schemas: set this flag to 'true' to allow attaching sources even if their common schema
        cannot be inferred or is incompatible with the existing table's schema.
    :param medium: name of the medium where the output table will be created if it doesn't exist.
    :param source_format: format of source files. If not specified, it is deduced from file extension.
    """

    params = {"path": TablePath(destination_table, client=client)}
    if source_uris is not None and source_spec is not None:
        raise YtError('Parameters source_uris and source_spec are mutually exclusive')
    set_param(params, "source_uris", source_uris)
    if source_spec:
        set_param(params, "source_spec", source_spec.to_param() if isinstance(source_spec, ExternalSourceSpec) else source_spec)
    set_param(params, "attach_mode", attach_mode)
    set_param(params, "source_order", source_order)
    set_param(params, "allow_incompatible_source_schemas", allow_incompatible_source_schemas)
    set_param(params, "medium", medium)
    set_param(params, "source_format", source_format)

    # Attaching external sources may take a long time.
    # Set timeout to 1 year.
    timeout = 365 * 24 * 60 * 60 * 1000

    with Transaction(attributes={"title": "Python wrapper: attach_table"}, client=client):
        return make_request("attach_table", params, client=client, use_heavy_proxy=True, timeout=timeout)


################################################################################


def attach_table_with_access_id(
    access_id,  # type: str
    offshore_access_registry,  # type: str
    destination_table,  # type: str | TablePath
    metadata_bucket=None,  # type: str | None
    source_spec=None,  # type: ExternalSourceSpec | Dict
    attach_mode="parallel",  # type: str
    source_order="none",  # type: str
    allow_incompatible_source_schemas=False,  # type: bool
    source_format=None,  # type: str | None
    client=None,  # type: YtClient | None
):
    """
    Attaches external sources, e.g. S3 URLs, to table. The main difference between this function
    and the other attach_table is that this implementation will find or create a suitable medium
    for the attached table automatically.

    For that purpose it uses the access ID which is a key to the offshore credentials stored
    somewhere in the system. Prior to calling this function the access ID must be created via
    create_access_id function.

    :param access_id: key of the offshore credentials; create it first via create_access_id function.
    :param offshore_access_registry: path to a node storing information about the reusable media
        and access IDs. It's important to use the same path when calling this family of functions.
    :param destination_table: table to which the data will be attached; it must not exist when
        calling this function.
    :param metadata_bucket: optional; when specified, this bucket will be used to store the
        generated metadata about the attached table. This allows certain operations to work
        more optimally (mostly the sorted operations) or work at all (interpreting composite
        columns as JSON-s).
        NB: Due to the current limitations of the system, there can only be one metadata bucket
        per access ID, and it will be the one which is set during the first call to this function
        for a given access ID. Thus, it's recommended to either always pass the same value or
        never pass it at all to avoid any confusion.

    See other paramets' descriptions in the docs to the other attach_table.
    """

    # Check some preconditions.
    require(exists(offshore_access_registry, client=client),
            lambda: YtError(f"Offshore access registry {offshore_access_registry} does not exist"))

    access_id_node = _get_access_id_node_path(offshore_access_registry, access_id)
    require(exists(access_id_node, client=client),
            lambda: YtError(f"Access ID {access_id} does not exist; use create_access_id to create one"))

    require(not exists(destination_table, client=client),
            lambda: YtError(f"Destination table {destination_table} must not exist"))

    created_medium_name = ""
    updated_medium_name = ""

    try:
        with Transaction(attributes={"title": "Python wrapper: attach_table_with_access_id"}, client=client):
            # Take an exclusive lock over the access ID node; with this we make sure noone removes it
            # while we're attaching the table.
            lock(access_id_node, mode="exclusive", waitable=True, wait_for=60 * 1000, client=client)

            # If we have already attached a table using this access ID, we would have a medium
            # associated with those credentials which we will use again.
            selected_medium = get_attribute(access_id_node, "medium", client=client)
            if selected_medium == "":
                # Otherwise, we need to select a medium from the pool or create a new one.
                print(f"Provided access ID is not linked to any medium; trying to find a free medium")

                s3_creds = get_attribute(access_id_node, "s3_creds", client=client)
                reusable_medium_config = {
                    "type": "s3_medium",
                    "url": s3_creds["url"],
                    "region": s3_creds["region"],
                    "access_key_id": s3_creds["access_key_id"],
                    "secret_access_key": s3_creds["secret_access_key"],
                }
                if metadata_bucket is not None:
                    reusable_medium_config["bucket"] = metadata_bucket

                # Take a shared lock over the media directory; this will allow us to create or acquire
                # a medium and not block other media.
                reusable_media_path = _get_reusable_media_path(offshore_access_registry)
                lock(reusable_media_path, mode="shared", waitable=True, wait_for=60 * 1000, client=client)

                # Try to select a free medium from the pool.
                for reusable_medium_name in list(reusable_media_path, client=client):
                    reusable_medium_node = _get_reusable_medium_node_path(offshore_access_registry, reusable_medium_name)
                    if get_attribute(reusable_medium_node, "access_id", client=client) == "":
                        selected_medium = reusable_medium_name
                        break

                if selected_medium == "":
                    # There were no free media available; create a new one.
                    print(f"Haven't found a free medium; creating a new one")

                    all_media = list("//sys/media", client=client)

                    current_user = get_current_user(client=client)
                    if current_user is not None:
                        current_user = current_user["user"]
                    else:
                        current_user = "generic"

                    REUSABLE_MEDIUM_PREFIX = "reusable_offshore_medium_"
                    selected_medium = REUSABLE_MEDIUM_PREFIX + "{}_{}".format(
                        current_user, os.urandom(5).hex())
                    while selected_medium in all_media:
                        selected_medium = REUSABLE_MEDIUM_PREFIX + "{}_{}".format(
                            current_user, os.urandom(5).hex())

                    print("Creating a new reusable medium {}".format(selected_medium))
                    created_medium_name = selected_medium
                    create("s3_medium", attributes={
                        "name": selected_medium,
                        "config": _get_null_offshore_medium_config(),
                        "acl": [{
                            "action": "allow",
                            "subjects": [ "owner" ],
                            "permissions": [ "use" ],
                        }],
                    }, client=client)

                    # Also don't forget to create an entry for this medium in the registry.
                    create("map_node",
                           _get_reusable_medium_node_path(offshore_access_registry, selected_medium),
                           client=client)

                # Finally, update the medium's configuration and links in the registry.
                updated_medium_name = selected_medium
                set_attribute(f"//sys/media/{selected_medium}", "config", value=reusable_medium_config, client=client)
                _set_account_space_limit_for_medium(offshore_access_registry, selected_medium, client=client)

                set_attribute(_get_reusable_medium_node_path(offshore_access_registry, selected_medium),
                              "access_id",
                              value=access_id,
                              client=client)
                set_attribute(access_id_node, "medium", value=selected_medium, client=client)

            print(f"Attaching table {destination_table} to medium {selected_medium} with access id {access_id}")

            # Remember the table we attach so we can easily remove it when releasing the access id.
            attached_tables_path = _get_attached_tables_path(offshore_access_registry, selected_medium)
            create("map_node",
                   f"{attached_tables_path}/{_encode_attached_table_path(destination_table)}",
                   recursive=True,
                   force=True,
                   client=client)

            # Finally, run the attach table; we perform this operation with retries as information about the
            # new media of changed configurations may not reach all components immediately, so there are
            # some transient errors we want to handle.
            def attach_table_with_error_checks():
                attach_table(destination_table, source_spec=source_spec, attach_mode=attach_mode,
                            source_order=source_order, allow_incompatible_source_schemas=allow_incompatible_source_schemas,
                            medium=selected_medium, source_format=source_format, client=client)

            def handle_transient_error(exception):
                # The exception.contains_text(..) emits a deprecation warning which is annoying.
                TRANSIENT_ERRORS = ["not found in medium directory", "Invalid URL"]
                for trans_error in TRANSIENT_ERRORS:
                    if exception.find_matching_error(predicate=lambda error: trans_error in error.message) is not None:
                        return
                raise

            return run_with_retries(
                attach_table_with_error_checks,
                retry_count=10,
                backoff=6,
                except_action=handle_transient_error)
    except Exception:
        # We need to perform some cleanup here. Almost everything happening under the transaction upwards
        # will be rollbacked except for the actions related to creating a medium or changing of its config.
        # Thus, we need to carefully fix inconsistencies which may happen because of this.
        if created_medium_name != "" and exists(f"//sys/media/{created_medium_name}", client=client):
            create("map_node",
                   _get_reusable_medium_node_path(offshore_access_registry, created_medium_name),
                   attributes={
                       "access_id": "",
                   },
                   client=client)
        if updated_medium_name != "":
            set_attribute("//sys/media/{}".format(updated_medium_name), attribute="config", value={
                "bucket": "none",
                "url": "none",
                "region": "none",
                "access_key_id": "none",
                "secret_access_key": "none",
            }, client=client)

        raise


################################################################################


def create_access_id(
    credentials,  # type: ExternalCredsSpec
    offshore_access_registry,  # type: str
    client=None,  # type: YtClient | None
):
    """
    Create a new access ID. This object stores offshore credentials (for now, only S3) and is used
    when attaching tables with attach_table_with_access_id.

    :param credentials: S3 credentials.
    :param offshore_access_registry: path to a node storing information about the reusable media
        and access IDs. It's important to use the same path when calling this family of functions.

    :returns: access ID key as a string.
    """
    if not exists(offshore_access_registry, client=client):
        with Transaction(attributes={"title": "Python wrapper: create offshore access registry"}, client=client):
            create("map_node", offshore_access_registry, client=client)
            create("map_node", _get_access_ids_path(offshore_access_registry), client=client)
            create("map_node", _get_reusable_media_path(offshore_access_registry), client=client)

    access_ids_node = _get_access_ids_path(offshore_access_registry)
    with Transaction(attributes={"title": "Python wrapper: create_access_id"}, client=client):
        # Shared lock here allows us to safely create a new node for the new access ID while also allowing
        # other operations to run.
        lock(access_ids_node, mode="shared", waitable=True, wait_for=60 * 1000, client=client)

        current_user = get_current_user(client=client)
        if current_user is not None:
            current_user = current_user["user"]
        else:
            current_user = "generic"

        new_access_id_key = f"id_{current_user}_{os.urandom(5).hex()}"
        new_access_id_path = _get_access_id_node_path(offshore_access_registry, new_access_id_key)
        while exists(new_access_id_path, client=client):
            new_access_id_key = f"id_{current_user}_{os.urandom(5).hex()}"
            new_access_id_path = _get_access_id_node_path(offshore_access_registry, new_access_id_key)
        print(f"Creating a new access id entry {new_access_id_path}")

        create("map_node", new_access_id_path, client=client)
        set_attribute(new_access_id_path, "s3_creds", value={
            "url": credentials.url,
            "region": credentials.region,
            "access_key_id": credentials.access_key_id,
            "secret_access_key": credentials.secret_access_key,
        }, client=client)
        set_attribute(new_access_id_path, "medium", value="", client=client)

    return new_access_id_key


def release_access_id(
    access_id,  # type: str
    offshore_access_registry,  # type: str
    client=None,  # type: YtClient | None
):
    """
    Release an access ID. This function must be called when the access ID is no longer required
    in order to release the internal resources. It also removes tables which were attached
    using the specified access ID. After a successfull call to this function the access ID can
    no longer be used.

    :param access_id: key of the access ID to be removed.
    :param offshore_access_registry: path to a node storing information about the reusable media
        and access IDs. It's important to use the same path when calling this family of functions.
    """
    access_id_node = _get_access_id_node_path(offshore_access_registry, access_id)
    require(exists(access_id_node, client=client),
            lambda: YtError(f"Access ID '{access_id}' does not exist"))

    with Transaction(attributes={"title": "Python wrapper: release_access_id"}, client=client):
        # Exclusive lock here to make sure noone uses this access ID for attach operations
        # while we're removing it.
        lock(access_id_node, mode="exclusive", waitable=True, wait_for=60 * 1000, client=client)
        print(f"Starting to release access ID {access_id}")

        linked_medium = get_attribute(access_id_node, "medium", client=client)
        if linked_medium != "":
            attached_tables_path = _get_attached_tables_path(offshore_access_registry, linked_medium)
            for attached_table in list(attached_tables_path, client=client):
                attached_table_path = _decode_attached_table_path(attached_table)
                print(f"Removing table {attached_table_path}")
                remove(attached_table_path, force=True, client=client)
            remove(attached_tables_path, recursive=True, client=client)

            print(f"Releasing medium {linked_medium}")

            linked_medium_node = _get_reusable_medium_node_path(offshore_access_registry, linked_medium)
            require(exists(linked_medium_node, client=client),
                    lambda: YtError("Critical error: medium is specified in access ID attribute, but not in reusable_media"))

            set_attribute(linked_medium_node, "access_id", value="", client=client)
            set_attribute(f"//sys/media/{linked_medium}",
                          attribute="config",
                          value=_get_null_offshore_medium_config(),
                          client=client)

        remove(access_id_node, client=client)


def repair_access_ids(
    offshore_access_registry,  # type: str
    username=None,  # type: str | None
    dry=True,  # type: bool
    client=None,  # type: YtClient | None
):
    """
    Attempt to detect and repair different cases how the access IDs and reusable media model
    can be broken. This function can do dangerous things, especially if the arguments are not
    specified correctly, so be careful about using it in non-dry mode.

    :param offshore_access_registry: registry to be analyzed.
    :param username: user for whom the media were created in attach_table_with_access_id; most
        probably it's your usual user, deduced from the client, but if not, this option can
        override this behaviour.
    :param dry: if set to True, the function will only print what it's going to do.
    """
    if username is None:
        current_user = get_current_user(client=client)
        if current_user is not None:
            username = current_user["user"]
        else:
            print("Cannot repair access IDs: either provide a username or make sure it can be " \
                  "deduced from the client")
            return

    # Enumerate all reusable media belonging to that user.
    def match_username(path):
        return re.match(f".*{username}.*", path) is not None
    existing_media_paths = search("//sys/media", path_filter=match_username, client=client)
    existing_media_names = [path.split("/")[-1] for path in existing_media_paths]

    # First case: medium exists, but is not registered in the access registry.
    reusable_media_registy = _get_reusable_media_path(offshore_access_registry)
    with Transaction(attributes={"title": "Python wrapper: registering orphaned reusable media"}, client=client):
        media_names_in_registry = list(reusable_media_registy, client=client)
        for existing_medium_name in existing_media_names:
            if existing_medium_name not in media_names_in_registry:
                print(f"Medium {existing_medium_name} exists but not registered in registry {offshore_access_registry}")

                medium_node_path = _get_reusable_medium_node_path(offshore_access_registry, existing_medium_name)
                if not dry:
                    create("map_node",
                           medium_node_path,
                           attributes={
                               "access_id": "",
                           },
                           client=client)
                    create("map_node",
                           _get_attached_tables_path(offshore_access_registry, existing_medium_name),
                           client=client)
                    print(f"Created folder {medium_node_path}")
                else:
                    print(f"Would create folder {medium_node_path}")

    # TODO: Second case: config of the medium is not equal to the config of the linked access ID => CRITICAL.

    # TODO: Third case: config of the medium is not none even though it's not linked to any access ID.

    # TODO: Fourth case: access_id[medium] != medium[access_id] => something strange, but check for it.
