# src/openevalkit/config.py

from dataclasses import dataclass
from typing import Optional


@dataclass
class EvalConfig:
    """
    Configuration for evaluation runs.
    
    Examples:
        >>> # Default config
        >>> config = EvalConfig()
        
        >>> # High concurrency with caching
        >>> config = EvalConfig(
        ...     concurrency=20,
        ...     cache_enabled=True,
        ...     cache_max_size_mb=1000
        ... )
        
        >>> # Reproducible evaluation
        >>> config = EvalConfig(
        ...     seed=42,
        ...     concurrency=1,
        ...     cache_enabled=False
        ... )
    """
    
    # Execution
    concurrency: int = 10
    timeout: Optional[float] = None
    
    # Reproducibility
    seed: Optional[int] = None
    
    # Caching
    cache_enabled: bool = True
    cache_dir: Optional[str] = None  # None = default (~/.cache/openevalkit)
    cache_max_size_mb: int = 500
    cache_max_age_days: int = 30
    
    # Error handling
    fail_fast: bool = False
    
    # Output
    verbose: bool = False
    progress_bar: bool = True