# src/openevalkit/judgment.py

"""Judgment class for LLM judge results."""

from typing import Dict, Any, Optional
from dataclasses import dataclass, field
import time


@dataclass
class Judgment:
    """
    Result from judging a single run.
    
    Provides per-criterion scores, explanations, and confidence
    for full traceability.
    
    Examples:
        >>> judgment = Judgment(
        ...     score=0.85,
        ...     criteria_scores={"helpfulness": 0.9, "clarity": 0.8},
        ...     criteria_explanations={
        ...         "helpfulness": "Provides actionable advice",
        ...         "clarity": "Clear but minor grammar issues"
        ...     },
        ...     criteria_confidence={"helpfulness": 0.95, "clarity": 0.85},
        ...     explanation="Overall helpful and clear response",
        ...     confidence=0.90
        ... )
    """
    # Overall score (computed by framework from criteria_scores)
    score: float
    
    # Per-criterion scores (from LLM)
    criteria_scores: Dict[str, float]
    
    # Per-criterion explanations (from LLM)
    criteria_explanations: Dict[str, str]
    
    # Overall explanation/summary (from LLM)
    explanation: str
    
    # Per-criterion confidence (from LLM)
    criteria_confidences: Optional[Dict[str, float]] = None
    
    # Overall confidence (computed by framework from criteria_confidence)
    confidence: Optional[float] = None
    
    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # When judgment was made
    timestamp: float = field(default_factory=time.time)