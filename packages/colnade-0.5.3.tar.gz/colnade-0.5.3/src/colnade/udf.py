"""@udf decorator for typed batch UDFs."""
