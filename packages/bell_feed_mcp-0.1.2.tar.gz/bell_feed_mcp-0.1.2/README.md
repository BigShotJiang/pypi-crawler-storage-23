# bell-feed-mcp

MCP server for [Bell Feed](https://degendar.com) — AI-curated crypto Twitter intelligence from bell notification accounts.

## What it does

Provides 4 tools to Claude Code for querying real-time crypto Twitter data:

- **`get_latest_summaries(count)`** — Latest AI-generated summaries of crypto Twitter activity
- **`get_trending_tokens(hours)`** — Token mention frequency rankings over the past N hours
- **`get_daily_tldr()`** — Today's TL;DR summary
- **`search_summaries(query)`** — Search summaries by keyword, token, or signal

Data is sourced from [data.degendar.com](https://data.degendar.com/summaries.json) (public, updated hourly).

## Install

```bash
claude mcp add bell-feed -- uvx bell-feed-mcp
```

That's it. Restart Claude Code and the tools are available.

## Usage

Just ask Claude naturally:

- "What's happening in crypto today?"
- "Which tokens are trending?"
- "Any news about SOL?"
- "Give me today's TL;DR"

Claude will automatically call the appropriate tool.

## RSS Feed

Prefer RSS? Subscribe directly:

```
https://data.degendar.com/feed.xml
```

Works with any RSS reader (Feedly, Inoreader, etc.).

## Data

All data is fetched from public URLs with 5-minute in-memory caching. No API keys required. No data is sent to any third party.

| Endpoint | Content |
|----------|---------|
| `summaries.json` | Hourly AI summaries with tokens, signals, tweet counts |
| `daily_tldr.json` | Daily TL;DR digest |
| `feed.xml` | RSS 2.0 feed with `bell:` namespace extensions |
