// Extends and overrides API
import './views/HierarchyWidget';
