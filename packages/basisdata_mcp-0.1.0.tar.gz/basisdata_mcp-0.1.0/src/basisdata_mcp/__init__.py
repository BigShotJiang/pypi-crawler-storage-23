"""BasisData MCP Server -- Financial data for AI agents."""
