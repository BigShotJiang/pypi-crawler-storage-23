Adds the possibility to attach emails from a certain IMAP folder to objects,
ie partners. Matching is done via several algorithms, ie email address, email
address's domain or the original Odoo algorithm.

This gives a simple possibility to archive emails in Odoo without a mail
client integration.
