"""Validation result dataclass."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class ValidationResult:
    """Result of attribute validation.

    Attributes:
        is_valid: Whether validation passed
        missing_fields: List of missing required attributes
        errors: List of error messages (including missing fields and invalid values)
    """

    is_valid: bool
    missing_fields: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate consistency of ValidationResult state."""
        # SECURITY: Ensure is_valid=True implies no errors (prevent contradictory state)
        if self.is_valid and (self.missing_fields or self.errors):
            raise ValueError(
                "ValidationResult with is_valid=True cannot have missing_fields or errors. "
                f"Got missing_fields={self.missing_fields}, errors={self.errors}"
            )

    def __str__(self) -> str:
        if self.is_valid:
            return "Validation passed"
        return f"Validation failed: {', '.join(self.errors)}"
