"""Integration helpers for MCA SDK.

This module provides helper classes and functions for integrating
different types of models (vendor, GenAI, etc.) with the MCA SDK.
"""

from .bridge import VendorBridge
from .state import StateManager, SQLiteStateManager, InMemoryStateManager
from .genai import (
    create_genai_client,
    estimate_openai_cost,
    track_llm_completion,
    track_llm_embedding,
    calculate_token_rate,
)
from .decorators import (
    instrument_model,
    instrument_async_model,
    track_batch_prediction,
)

# Optional LiteLLM integration (requires litellm package)
try:
    from .litellm_callback import MCALiteLLMCallback

    _LITELLM_AVAILABLE = True
except ImportError:
    _LITELLM_AVAILABLE = False
    MCALiteLLMCallback = None  # type: ignore

__all__ = [
    "VendorBridge",
    "StateManager",
    "SQLiteStateManager",
    "InMemoryStateManager",
    "create_genai_client",
    "estimate_openai_cost",
    "track_llm_completion",
    "track_llm_embedding",
    "calculate_token_rate",
    "instrument_model",
    "instrument_async_model",
    "track_batch_prediction",
    "MCALiteLLMCallback",
]
