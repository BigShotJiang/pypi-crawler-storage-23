"""Instrumentation decorators for MCA SDK.

This module provides decorators for automatic model instrumentation,
making it easy to add telemetry to prediction functions.
"""

import functools
import time
from typing import Callable, Optional, Any

from ..core.client import MCAClient


def _get_metric_prefix(client) -> str:
    """Get metric prefix from client, defaulting to 'model' for non-SDK objects."""
    prefix = getattr(client, '_metric_prefix', 'model')
    return prefix if isinstance(prefix, str) else 'model'


def instrument_model(
    client: MCAClient,
    metric_name: Optional[str] = None,
    capture_input: bool = False,
    capture_output: bool = False,
):
    """Decorator for automatic model instrumentation.

    Wraps a prediction function to automatically record metrics including
    latency, call counts, and optionally input/output data.

    Args:
        client: MCAClient instance for recording telemetry
        metric_name: Custom metric name prefix (default: function name)
        capture_input: Whether to capture input data (default: False for security)
        capture_output: Whether to capture output data (default: False for security)

    Returns:
        Decorated function with automatic instrumentation

    Examples:
        Basic usage (no data capture):
        >>> client = MCAClient(...)
        >>> @instrument_model(client)
        ... def predict(input_data):
        ...     return model.predict(input_data)

        With custom metric name:
        >>> @instrument_model(client, metric_name="readmission_prediction")
        ... def predict_readmission(patient_data):
        ...     return model.predict(patient_data)

        Capturing input/output (HIPAA: ensure PHI sanitized):
        >>> @instrument_model(client, capture_input=True, capture_output=True)
        ... def predict(input_data):
        ...     return model.predict(input_data)
    """

    def decorator(func: Callable) -> Callable:
        # Use function name if metric_name not provided
        name = metric_name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            import uuid

            start_time = time.time()

            # FIXED (Round 11 Issue #3): Generate prediction_id for correlation
            prediction_id = str(uuid.uuid4())

            # Create trace span
            # FIXED (Round 12 Issue #2): Use dynamic span name for differentiation
            with client.trace(f"{name}.predict") as span:
                # FIXED (Round 11 Issue #3): Add prediction_id to span
                span.set_attribute("prediction.id", prediction_id)

                try:
                    # Call the original function
                    result = func(*args, **kwargs)

                    # FIXED (Round 14 Issue #5): Detect generators/streaming responses
                    import inspect

                    if inspect.isgenerator(result) or inspect.isasyncgen(result):
                        # Wrap generator to measure full latency
                        def generator_wrapper():
                            try:
                                for item in result:
                                    yield item
                            finally:
                                # Measure latency when generator exhausted
                                latency = time.time() - start_time
                                span.set_attribute("status.code", "OK")
                                span.set_attribute("prediction.latency_ms", latency * 1000)
                                client.record_prediction(
                                    input_data=None,  # Don't capture for generators
                                    output=None,
                                    latency=latency,
                                    function=name,
                                    prediction_id=prediction_id,
                                )

                        return generator_wrapper()

                    # Calculate latency for non-generator results
                    latency = time.time() - start_time

                    # FIXED (Round 14 Issue #8): Safer kwarg capture - don't blindly capture sensitive data
                    input_data = None
                    output_data = None

                    if capture_input:
                        if args and kwargs:
                            # Serialize both safely
                            from ..utils.serialization import serialize_for_telemetry

                            input_data = {
                                "args": serialize_for_telemetry(args),
                                "kwargs": serialize_for_telemetry(kwargs),
                            }
                        elif args:
                            input_data = args[0] if len(args) == 1 else args
                        elif kwargs:
                            # FIXED (Round 14 Issue #8): Serialize kwargs safely instead of blind capture
                            from ..utils.serialization import serialize_for_telemetry

                            input_data = serialize_for_telemetry(kwargs)

                    if capture_output:
                        output_data = result

                    # Set span attributes using function-name prefix convention
                    span.set_attribute(f"{name}.latency_seconds", latency)
                    span.set_attribute(f"{name}.status", "success")

                    # Pass input/output (default to {} when not capturing)
                    client.record_prediction(
                        input_data=input_data if input_data is not None else {},
                        output=output_data if output_data is not None else {},
                        latency=latency,
                        function=name,
                        prediction_id=prediction_id,
                    )

                    return result

                except Exception as e:
                    # Calculate latency even on error
                    latency = time.time() - start_time

                    # Set error span attributes using function-name prefix
                    span.set_attribute(f"{name}.status", "error")
                    span.set_attribute(f"{name}.error", str(e))

                    # Record error metric
                    prefix = _get_metric_prefix(client)
                    client.record_metric(
                        f"{prefix}.errors_total", 1, error_type=type(e).__name__
                    )

                    # Re-raise the exception
                    raise

        return wrapper

    return decorator


def instrument_async_model(
    client: MCAClient,
    metric_name: Optional[str] = None,
    capture_input: bool = False,
    capture_output: bool = False,
):
    """Decorator for automatic async model instrumentation.

    Wraps an async prediction function to automatically record metrics.

    Args:
        client: MCAClient instance for recording telemetry
        metric_name: Custom metric name prefix (default: function name)
        capture_input: Whether to capture input data (default: False for security)
        capture_output: Whether to capture output data (default: False for security)

    Returns:
        Decorated async function with automatic instrumentation

    Example:
        >>> @instrument_async_model(client)
        ... async def predict_async(input_data):
        ...     result = await model.predict_async(input_data)
        ...     return result
    """

    def decorator(func: Callable) -> Callable:
        # Use function name if metric_name not provided
        name = metric_name or func.__name__

        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            import uuid

            start_time = time.time()

            # FIXED (Round 11 Issue #3): Generate prediction_id for correlation
            prediction_id = str(uuid.uuid4())

            # Create trace span
            # FIXED (Round 12 Issue #2): Use dynamic span name for differentiation
            with client.trace(f"{name}.predict") as span:
                # FIXED (Round 11 Issue #3): Add prediction_id to span
                span.set_attribute("prediction.id", prediction_id)

                try:
                    # Call the original async function
                    result = await func(*args, **kwargs)

                    # FIXED (Round 14 Issue #5): Detect async generators/streaming responses
                    import inspect

                    if inspect.isasyncgen(result):
                        # Wrap async generator to measure full latency
                        async def async_generator_wrapper():
                            try:
                                async for item in result:
                                    yield item
                            finally:
                                # Measure latency when generator exhausted
                                latency = time.time() - start_time
                                span.set_attribute("status.code", "OK")
                                span.set_attribute("prediction.latency_ms", latency * 1000)
                                client.record_prediction(
                                    input_data=None,  # Don't capture for generators
                                    output=None,
                                    latency=latency,
                                    function=name,
                                    prediction_id=prediction_id,
                                )

                        return async_generator_wrapper()

                    # Calculate latency for non-generator results
                    latency = time.time() - start_time

                    # FIXED (Round 14 Issue #8): Safer kwarg capture - don't blindly capture sensitive data
                    input_data = None
                    output_data = None

                    if capture_input:
                        if args and kwargs:
                            # Serialize both safely
                            from ..utils.serialization import serialize_for_telemetry

                            input_data = {
                                "args": serialize_for_telemetry(args),
                                "kwargs": serialize_for_telemetry(kwargs),
                            }
                        elif args:
                            input_data = args[0] if len(args) == 1 else args
                        elif kwargs:
                            # FIXED (Round 14 Issue #8): Serialize kwargs safely instead of blind capture
                            from ..utils.serialization import serialize_for_telemetry

                            input_data = serialize_for_telemetry(kwargs)

                    if capture_output:
                        output_data = result

                    # Set span attributes using function-name prefix convention
                    span.set_attribute(f"{name}.latency_seconds", latency)
                    span.set_attribute(f"{name}.status", "success")

                    # Pass input/output (default to {} when not capturing)
                    client.record_prediction(
                        input_data=input_data if input_data is not None else {},
                        output=output_data if output_data is not None else {},
                        latency=latency,
                        function=name,
                        prediction_id=prediction_id,
                    )

                    return result

                except Exception as e:
                    # Calculate latency even on error
                    latency = time.time() - start_time

                    # Set error span attributes using function-name prefix
                    span.set_attribute(f"{name}.status", "error")
                    span.set_attribute(f"{name}.error", str(e))

                    # Record error metric
                    prefix = _get_metric_prefix(client)
                    client.record_metric(
                        f"{prefix}.errors_total", 1, error_type=type(e).__name__
                    )

                    # Re-raise the exception
                    raise

        return wrapper

    return decorator


def track_batch_prediction(client: MCAClient, batch_size_metric: Optional[str] = None):
    """Decorator for tracking batch prediction metrics.

    Automatically tracks batch size and per-item latency for batch
    prediction functions.

    Args:
        client: MCAClient instance
        batch_size_metric: Custom metric name for batch size (default: "{prefix}.batch_size_count")

    Returns:
        Decorated function with batch tracking

    Example:
        >>> @track_batch_prediction(client)
        ... def predict_batch(inputs):
        ...     return [model.predict(x) for x in inputs]
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Start timing
            start_time = time.time()

            # Get batch from first argument
            batch = args[0] if args else []
            batch_size = len(batch) if hasattr(batch, "__len__") else 0

            # Resolve metric prefix (safe fallback for mock clients)
            prefix = _get_metric_prefix(client)

            # Batch size metric name (custom or default)
            size_metric = batch_size_metric if batch_size_metric else f"{prefix}.batch_size_count"

            try:
                # Call the original function
                result = func(*args, **kwargs)

                # Calculate metrics
                total_latency = time.time() - start_time
                per_item_latency = total_latency / batch_size if batch_size > 0 else 0

                # Record batch size
                client.record_metric(size_metric, batch_size)

                # Record total latency with batch size attribute
                client.record_metric(
                    f"{prefix}.batch_latency_seconds",
                    total_latency,
                    batch_size=str(batch_size),
                )

                # Record per-item latency with batch size attribute
                client.record_metric(
                    f"{prefix}.per_item_latency_seconds",
                    per_item_latency,
                    batch_size=str(batch_size),
                )

                return result

            except Exception as e:
                # Record batch error metric with context
                client.record_metric(
                    f"{prefix}.batch_errors_total",
                    1,
                    error_type=type(e).__name__,
                    batch_size=str(batch_size),
                )
                raise

        return wrapper

    return decorator
