"""Security utilities for MCA SDK.

Provides secure secret management, credential handling, and certificate management.
"""

# Conditional import for secret_manager (Story 3-9, not yet implemented)
# This allows other security modules like encryption to work independently
try:
    from .secret_manager import (
        SecretManagerClient,
        SecretManagerError,
        SecretNotFoundError,
        SecretPermissionError,
        SecretAuthenticationError,
        SecretInvalidURLError,
        SecretNetworkError,
        SecretDecodingError,
    )

    _SECRET_MANAGER_AVAILABLE = True
except ImportError:
    _SECRET_MANAGER_AVAILABLE = False
    # Define stub classes to prevent import errors
    SecretManagerClient = None  # type: ignore
    SecretManagerError = Exception  # type: ignore
    SecretNotFoundError = Exception  # type: ignore
    SecretPermissionError = Exception  # type: ignore
    SecretAuthenticationError = Exception  # type: ignore
    SecretInvalidURLError = Exception  # type: ignore
    SecretNetworkError = Exception  # type: ignore
    SecretDecodingError = Exception  # type: ignore

# Certificate management (Story 3-10)
from .certificates import CertificateManager

__all__ = [
    "SecretManagerClient",
    "SecretManagerError",
    "SecretNotFoundError",
    "SecretPermissionError",
    "SecretAuthenticationError",
    "SecretInvalidURLError",
    "SecretNetworkError",
    "SecretDecodingError",
    "_SECRET_MANAGER_AVAILABLE",
    "CertificateManager",
]
