"""Test utilities for secret management.

WARNING: This module contains dangerous test-only utilities.
NEVER import or use these utilities in production code.

These utilities are isolated here to prevent accidental misuse.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .secret_manager import SecretManagerClient

# Import module-level singleton references
from . import secret_manager


def reset_secret_manager_for_testing() -> None:
    """Reset SecretManagerClient singleton instance for testing.

    **DANGER:** This is a TEST-ONLY utility that tears down the singleton
    SecretManagerClient. Calling this in production will break the entire
    application's secret management system.

    This function is isolated in a separate module to prevent accidental
    production usage. Only import this module in test code.

    Usage:
        >>> # In test file only:
        >>> from mca_sdk.security._testing import reset_secret_manager_for_testing
        >>> def test_something():
        ...     reset_secret_manager_for_testing()
        ...     # Test code here
    """
    with secret_manager._singleton_lock:
        if secret_manager._singleton_client is not None:
            secret_manager._singleton_client.close()
            secret_manager._singleton_client = None


def get_secret_manager_singleton() -> "SecretManagerClient | None":
    """Get the current singleton instance (for testing/inspection only).

    Returns:
        Current singleton instance or None if not initialized
    """
    return secret_manager._singleton_client
