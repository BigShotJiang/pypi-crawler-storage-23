<?php

/**
 * The front page template file
 */

get_header(); ?>


<?php get_footer();
