<footer id="contact" class="site-footer col-12" role="contentinfo">

    <div class="footer-wrapper col-12">

        <div class="wrap flex">

            <div class="col-12 footer-row row-footer-last d-flex-nw">

                <div class="copy-span d-flex-nw notranslate">
                    <?php _e('© 2026. design&code', 'docktheme') ?>
                    <div class="dcl-dark"></div>
                </div>
            </div>

        </div>

    </div>
</footer>
<?php wp_footer(); ?>
</body>

</html>