"""Export des sessions depuis SQLite vers JSONL."""

import json
from pathlib import Path

from db import get_connection, export_all, get_projects_summary

DEFAULT_OUTPUT = Path("conversations.jsonl")


def export_jsonl(
    output_path: Path = DEFAULT_OUTPUT,
    db_path: Path | None = None,
    project: str | None = None,      # filtrer par projet (optionnel)
    model: str | None = None,        # filtrer par modèle (optionnel)
    min_exchanges: int = 1,          # ignorer les sessions trop courtes
) -> dict:
    """
    Exporte toutes les sessions (ou un sous-ensemble filtré) en JSONL.
    Une ligne = une session complète.
    """
    conn     = get_connection(db_path) if db_path else get_connection()
    sessions = export_all(conn)
    conn.close()

    # Filtres optionnels
    if project:
        sessions = [s for s in sessions if s["project"] == project]
    if model:
        sessions = [s for s in sessions if s.get("model") == model]
    if min_exchanges > 1:
        sessions = [s for s in sessions if s["stats"]["exchanges"] >= min_exchanges]

    written = 0
    with open(output_path, "w", encoding="utf-8") as f:
        for session in sessions:
            f.write(json.dumps(session, ensure_ascii=False) + "\n")
            written += 1

    size = output_path.stat().st_size

    return {
        "sessions": written,
        "output":   str(output_path.resolve()),
        "size_bytes": size,
    }


def print_summary(db_path: Path | None = None) -> None:
    """Affiche un résumé par projet."""
    conn     = get_connection(db_path) if db_path else get_connection()
    projects = get_projects_summary(conn)
    conn.close()

    if not projects:
        print("Base vide.")
        return

    print(f"{'Projet':<40} {'Sessions':>8} {'Input tok':>12} {'Output tok':>12} {'Outils':>8}")
    print("-" * 84)
    for p in projects:
        print(
            f"{p['project']:<40} "
            f"{p['sessions']:>8} "
            f"{(p['input_tokens'] or 0):>12,} "
            f"{(p['output_tokens'] or 0):>12,} "
            f"{(p['tool_calls'] or 0):>8}"
        )


# ---------------------------------------------------------------------------
# CLI minimal
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    output = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_OUTPUT

    print("Résumé de la base :")
    print_summary()
    print()

    result = export_jsonl(output)
    print(f"Export terminé :")
    print(f"  Sessions exportées : {result['sessions']}")
    print(f"  Fichier            : {result['output']}")
    print(f"  Taille             : {result['size_bytes'] / 1024:.1f} KB")
