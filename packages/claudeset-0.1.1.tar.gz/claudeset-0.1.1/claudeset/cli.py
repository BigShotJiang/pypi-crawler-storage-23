"""CLI claudeset — Export your Claude Code conversations to HuggingFace."""

import argparse
import sys
from pathlib import Path


def cmd_collect(args) -> None:
    from .collector import collect
    result = collect()
    print("Collecte terminée :")
    print(f"  Nouvelles sessions     : {result['new']}")
    print(f"  Mises à jour           : {result['updated']}")
    print(f"  Ignorées (inchangées)  : {result['skipped']}")
    print(f"  Échecs de parsing      : {result['failed']}")
    print(f"  Total en base          : {result['total_in_db']}")
    print(f"  Projets scannés        : {result['projects']}")


def cmd_export(args) -> None:
    from .exporter import export_jsonl, print_summary
    output = args.output or Path("conversations.jsonl")
    if args.summary:
        print_summary()
        return
    result = export_jsonl(
        output_path=output,
        project=args.project or None,
        model=args.model or None,
        min_exchanges=args.min_exchanges,
    )
    print(f"Export terminé :")
    print(f"  Sessions : {result['sessions']}")
    print(f"  Fichier  : {result['output']}")
    print(f"  Taille   : {result['size_bytes'] / 1024:.1f} KB")


def cmd_push(args) -> None:
    from .db import get_connection
    from .pusher import push_personal, push_community, COMMUNITY_REPO

    conn = get_connection()

    custom = [s.strip() for s in args.redact.split(",")] if args.redact else None

    if args.target == "personal":
        if not args.repo:
            print("Erreur : spécifiez le repo avec --repo username/dataset-name", file=sys.stderr)
            sys.exit(1)
        result = push_personal(conn, args.repo)

    elif args.target == "community":
        repo = args.repo or COMMUNITY_REPO
        result = push_community(conn, repo_id=repo, custom_strings=custom)

    conn.close()
    print(f"\nRésultat : {result}")


def cmd_status(args) -> None:
    from .db import get_connection, get_projects_summary, count_sessions
    conn = get_connection()
    total = count_sessions(conn)
    projects = get_projects_summary(conn)
    conn.close()

    print(f"Sessions en base : {total}")
    print()
    if not projects:
        print("Base vide.")
        return
    print(f"{'Projet':<40} {'Sessions':>8} {'Input tok':>12} {'Outils':>8}")
    print("-" * 72)
    for p in projects:
        print(
            f"{p['project']:<40} "
            f"{p['sessions']:>8} "
            f"{(p['input_tokens'] or 0):>12,} "
            f"{(p['tool_calls'] or 0):>8}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="claudeset",
        description="Export your Claude Code conversations to HuggingFace as training data.",
    )
    parser.add_argument("--version", action="version", version="claudeset 0.1.1")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── collect ────────────────────────────────────────────────────────────
    sub.add_parser(
        "collect",
        help="Scan Claude Code projects and sync new/updated sessions to local DB.",
    )

    # ── export ────────────────────────────────────────────────────────────
    exp = sub.add_parser(
        "export",
        help="Export sessions from local DB to a JSONL file.",
    )
    exp.add_argument("-o", "--output", type=Path, default=None,
                     help="Output file (default: conversations.jsonl)")
    exp.add_argument("--project", type=str, default=None,
                     help="Filter by project name")
    exp.add_argument("--model", type=str, default=None,
                     help="Filter by model name")
    exp.add_argument("--min-exchanges", type=int, default=1,
                     help="Minimum number of exchanges per session (default: 1)")
    exp.add_argument("--summary", action="store_true",
                     help="Show DB summary instead of exporting")

    # ── push ───────────────────────────────────────────────────────────────
    push = sub.add_parser(
        "push",
        help="Push new sessions to HuggingFace (personal or community repo).",
    )
    push.add_argument(
        "target",
        choices=["personal", "community"],
        help="'personal' = your own HF repo | 'community' = claude-code-community/conversations",
    )
    push.add_argument(
        "--repo", "-r",
        type=str, default=None,
        help="HF repo ID (required for personal, optional override for community)",
    )
    push.add_argument(
        "--redact",
        type=str, default=None,
        help="Comma-separated custom strings to redact before community push",
    )

    # ── status ─────────────────────────────────────────────────────────────
    sub.add_parser(
        "status",
        help="Show a summary of collected sessions by project.",
    )

    # ── dispatch ───────────────────────────────────────────────────────────
    args = parser.parse_args()

    if args.command == "collect":
        cmd_collect(args)
    elif args.command == "export":
        cmd_export(args)
    elif args.command == "push":
        cmd_push(args)
    elif args.command == "status":
        cmd_status(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
