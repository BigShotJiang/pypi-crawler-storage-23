"""SQLite storage pour les sessions collectées."""

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path.home() / ".clawback" / "sessions.db"


# ---------------------------------------------------------------------------
# Connexion
# ---------------------------------------------------------------------------

def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")   # lecture concurrente
    conn.execute("PRAGMA foreign_keys=ON")
    _init_schema(conn)
    return conn


# ---------------------------------------------------------------------------
# Schéma
# ---------------------------------------------------------------------------

def _init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id                   TEXT    PRIMARY KEY,
            project              TEXT    NOT NULL,
            model                TEXT,
            git_branch           TEXT,
            claude_version       TEXT,
            start_time           TEXT,
            end_time             TEXT,
            turns                TEXT    NOT NULL,   -- JSON sérialisé
            stats                TEXT    NOT NULL,   -- JSON sérialisé
            source_file          TEXT    NOT NULL,   -- chemin absolu du .jsonl source
            source_size          INTEGER NOT NULL,   -- taille en octets au moment de la collecte
            collected_at         TEXT    NOT NULL,   -- ISO8601 UTC
            pushed_personal_at   TEXT,               -- NULL = jamais poussé vers repo perso
            pushed_community_at  TEXT                -- NULL = jamais poussé vers repo communautaire
        );

        CREATE INDEX IF NOT EXISTS idx_sessions_project    ON sessions(project);
        CREATE INDEX IF NOT EXISTS idx_sessions_model      ON sessions(model);
        CREATE INDEX IF NOT EXISTS idx_sessions_start_time ON sessions(start_time);
    """)
    # Migration pour les bases existantes (colonnes ajoutées en v2)
    for col in ("pushed_personal_at", "pushed_community_at"):
        try:
            conn.execute(f"ALTER TABLE sessions ADD COLUMN {col} TEXT")
        except Exception:
            pass  # colonne déjà présente
    conn.commit()


# ---------------------------------------------------------------------------
# Opérations
# ---------------------------------------------------------------------------

def upsert_session(
    conn: sqlite3.Connection,
    session: dict,
    source_file: str,
    source_size: int,
) -> None:
    """Insère ou remplace une session (clé = id)."""
    conn.execute(
        """
        INSERT OR REPLACE INTO sessions
            (id, project, model, git_branch, claude_version,
             start_time, end_time, turns, stats,
             source_file, source_size, collected_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            session["id"],
            session["project"],
            session.get("model"),
            session.get("git_branch"),
            session.get("claude_version"),
            session.get("start_time"),
            session.get("end_time"),
            json.dumps(session["turns"],  ensure_ascii=False),
            json.dumps(session["stats"],  ensure_ascii=False),
            source_file,
            source_size,
            datetime.now(tz=timezone.utc).isoformat(),
        ),
    )
    conn.commit()


def get_known_sessions(conn: sqlite3.Connection) -> dict[str, int]:
    """Retourne {session_id: source_size} pour toutes les sessions stockées."""
    rows = conn.execute("SELECT id, source_size FROM sessions").fetchall()
    return {row["id"]: row["source_size"] for row in rows}


def export_all(conn: sqlite3.Connection) -> list[dict]:
    """Retourne toutes les sessions sous forme de dicts, triées par start_time."""
    rows = conn.execute(
        "SELECT * FROM sessions ORDER BY start_time"
    ).fetchall()

    sessions = []
    for row in rows:
        s = dict(row)
        s["turns"] = json.loads(s["turns"])
        s["stats"] = json.loads(s["stats"])
        # Champs internes non destinés à l'export
        del s["source_file"]
        del s["source_size"]
        del s["collected_at"]
        sessions.append(s)

    return sessions


def get_unpushed_sessions(conn: sqlite3.Connection, target: str) -> list[dict]:
    """
    Retourne les sessions pas encore poussées vers `target` ('personal' ou 'community').
    Exclut les champs internes (source_file, source_size, collected_at, pushed_*).
    """
    col = f"pushed_{target}_at"
    rows = conn.execute(
        f"SELECT * FROM sessions WHERE {col} IS NULL ORDER BY start_time"
    ).fetchall()

    sessions = []
    for row in rows:
        s = dict(row)
        s["turns"] = json.loads(s["turns"])
        s["stats"] = json.loads(s["stats"])
        for field in ("source_file", "source_size", "collected_at",
                      "pushed_personal_at", "pushed_community_at"):
            s.pop(field, None)
        sessions.append(s)
    return sessions


def mark_pushed(conn: sqlite3.Connection, session_ids: list[str], target: str) -> None:
    """Marque les sessions comme poussées vers `target`."""
    col = f"pushed_{target}_at"
    now = datetime.now(tz=timezone.utc).isoformat()
    conn.executemany(
        f"UPDATE sessions SET {col} = ? WHERE id = ?",
        [(now, sid) for sid in session_ids],
    )
    conn.commit()


def count_sessions(conn: sqlite3.Connection) -> int:
    return conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]


def get_projects_summary(conn: sqlite3.Connection) -> list[dict]:
    """Résumé par projet : nombre de sessions et tokens."""
    rows = conn.execute("""
        SELECT
            project,
            COUNT(*)                                        AS sessions,
            SUM(json_extract(stats, '$.input_tokens'))      AS input_tokens,
            SUM(json_extract(stats, '$.output_tokens'))     AS output_tokens,
            SUM(json_extract(stats, '$.tool_calls'))        AS tool_calls
        FROM sessions
        GROUP BY project
        ORDER BY sessions DESC
    """).fetchall()
    return [dict(r) for r in rows]
