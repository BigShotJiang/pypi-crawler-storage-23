"""Parse Claude Code session JSONL files into structured conversation turns."""

import json
from pathlib import Path
from typing import Any

CLAUDE_DIR = Path.home() / ".claude"
PROJECTS_DIR = CLAUDE_DIR / "projects"

MAX_OUTPUT_LENGTH = 10_000   # chars par tool output avant troncature
MAX_INPUT_LENGTH  = 2_000    # chars par tool input


# ---------------------------------------------------------------------------
# Découverte des projets
# ---------------------------------------------------------------------------

def discover_projects() -> list[dict]:
    """Retourne tous les projets avec leurs fichiers de session."""
    if not PROJECTS_DIR.exists():
        return []

    projects = []
    for project_dir in sorted(PROJECTS_DIR.iterdir()):
        if not project_dir.is_dir():
            continue
        sessions = list(project_dir.glob("*.jsonl"))
        if not sessions:
            continue
        projects.append({
            "dir_name":         project_dir.name,
            "display_name":     _build_project_name(project_dir.name),
            "session_files":    sessions,
            "session_count":    len(sessions),
            "total_size_bytes": sum(f.stat().st_size for f in sessions),
        })
    return projects


# ---------------------------------------------------------------------------
# Parsing d'une session
# ---------------------------------------------------------------------------

def parse_session_file(filepath: Path) -> dict | None:
    """Parse un fichier .jsonl de session en une conversation structurée."""
    entries = _read_entries(filepath)
    if not entries:
        return None

    tool_results = _extract_tool_results(entries)
    meta         = _extract_metadata(entries, filepath)
    turns        = _build_turns(entries, tool_results)

    if not turns:
        return None

    # Retirer les usages individuels des turns de l'objet final
    stats = _compute_stats(turns)
    for turn in turns:
        if turn["type"] == "exchange":
            turn.pop("_usage", None)

    return {
        "id":             meta["session_id"],
        "project":        None,   # rempli par le collector
        "model":          meta["model"],
        "git_branch":     meta["git_branch"],
        "claude_version": meta["claude_version"],
        "start_time":     meta["start_time"],
        "end_time":       meta["end_time"],
        "turns":          turns,
        "stats":          stats,
    }


# ---------------------------------------------------------------------------
# Lecture brute
# ---------------------------------------------------------------------------

def _read_entries(filepath: Path) -> list[dict]:
    entries = []
    try:
        with open(filepath, errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    except OSError:
        return []
    return entries


# ---------------------------------------------------------------------------
# Extraction des résultats d'outils
# ---------------------------------------------------------------------------

def _extract_tool_results(entries: list[dict]) -> dict[str, dict]:
    """
    Construit un index : tool_use_id → données du résultat.

    Les tool results arrivent dans des entrées `type: user` avec
    sourceToolAssistantUUID présent. toolUseResult contient les données
    complètes (stdout, stderr, interrupted). block.content est ce qui
    a été envoyé à l'API (peut être tronqué).
    """
    results: dict[str, dict] = {}

    for entry in entries:
        if entry.get("type") != "user":
            continue
        if not entry.get("sourceToolAssistantUUID"):
            continue

        content = entry.get("message", {}).get("content", [])
        if not isinstance(content, list):
            continue

        raw = entry.get("toolUseResult", {})
        # toolUseResult est parfois une string (message d'erreur) au lieu d'un dict
        if isinstance(raw, str):
            raw = {"stdout": raw}
        elif not isinstance(raw, dict):
            raw = {}

        for block in content:
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue
            tool_use_id = block.get("tool_use_id", "")
            if not tool_use_id:
                continue

            results[tool_use_id] = {
                "content":     block.get("content", ""),
                "is_error":    block.get("is_error", False),
                "stdout":      raw.get("stdout", ""),
                "stderr":      raw.get("stderr", ""),
                "interrupted": raw.get("interrupted", False),
                "is_image":    raw.get("isImage", False),
            }

    return results


# ---------------------------------------------------------------------------
# Extraction des métadonnées de session
# ---------------------------------------------------------------------------

def _extract_metadata(entries: list[dict], filepath: Path) -> dict:
    meta = {
        "session_id":     filepath.stem,
        "model":          None,
        "git_branch":     None,
        "claude_version": None,
        "start_time":     None,
        "end_time":       None,
    }

    for entry in entries:
        # Métadonnées système (cwd, version, branch) sur la première entrée qui les a
        if meta["claude_version"] is None and entry.get("cwd"):
            meta["git_branch"]     = entry.get("gitBranch")
            meta["claude_version"] = entry.get("version")
            if entry.get("sessionId"):
                meta["session_id"] = entry["sessionId"]

        if entry.get("type") == "assistant":
            if meta["model"] is None:
                meta["model"] = entry.get("message", {}).get("model")
            ts = entry.get("timestamp")
            if ts:
                if meta["start_time"] is None:
                    meta["start_time"] = ts
                meta["end_time"] = ts

    return meta


# ---------------------------------------------------------------------------
# Construction des turns
# ---------------------------------------------------------------------------

def _build_turns(entries: list[dict], tool_results: dict[str, dict]) -> list[dict]:
    """
    Regroupe les entrées brutes en turns cohérents.

    Un exchange = 1 message humain + toutes les réponses assistant
    qui suivent (y compris les boucles tool_use → tool_result).

    Un compact = une entrée type:summary (compression de contexte).

    Logique de détection :
    - type:user  SANS sourceToolAssistantUUID  → nouveau message humain
    - type:user  AVEC sourceToolAssistantUUID  → résultat d'outil (ignoré ici,
                                                 déjà indexé dans tool_results)
    - type:assistant                           → accumulé dans l'exchange courant
    - type:summary                             → turn compact
    - autres (progress, file-history-snapshot, system, queue-operation) → ignorés
    """
    turns: list[dict] = []
    current: dict | None = None   # exchange en cours d'accumulation

    SKIP_TYPES = {"file-history-snapshot", "progress", "queue-operation", "system"}

    for entry in entries:
        etype = entry.get("type")

        if etype in SKIP_TYPES:
            continue

        # ── Compact (compression de contexte) ──────────────────────────────
        if etype == "summary":
            if current is not None:
                turns.append(_finalize_exchange(current))
                current = None
            turns.append({
                "index":   len(turns),
                "type":    "compact",
                "summary": entry.get("summary", ""),
            })

        # ── Message humain ──────────────────────────────────────────────────
        elif etype == "user" and not entry.get("sourceToolAssistantUUID"):
            text = _extract_user_text(entry)
            if not text:
                continue

            if current is not None:
                turns.append(_finalize_exchange(current))

            current = {
                "index":     len(turns),
                "type":      "exchange",
                "timestamp": entry.get("timestamp"),
                "user":      text,
                "assistant": {
                    "thinking":   [],
                    "text":       [],
                    "tool_calls": [],
                },
                "_usage": {
                    "input_tokens":            0,
                    "output_tokens":           0,
                    "cache_read_input_tokens": 0,
                },
            }

        # ── Réponse assistant ───────────────────────────────────────────────
        elif etype == "assistant" and current is not None:
            _accumulate_assistant(current, entry, tool_results)

    # Dernier exchange non terminé
    if current is not None:
        turns.append(_finalize_exchange(current))

    return turns


def _extract_user_text(entry: dict) -> str | None:
    content = entry.get("message", {}).get("content", "")
    if isinstance(content, str):
        return content.strip() or None
    if isinstance(content, list):
        parts = [
            b.get("text", "")
            for b in content
            if isinstance(b, dict) and b.get("type") == "text"
        ]
        return "\n".join(parts).strip() or None
    return None


def _accumulate_assistant(current: dict, entry: dict, tool_results: dict) -> None:
    msg            = entry.get("message", {})
    content_blocks = msg.get("content", [])
    if not isinstance(content_blocks, list):
        return

    # Usage tokens
    usage = msg.get("usage", {})
    current["_usage"]["input_tokens"]            += usage.get("input_tokens", 0)
    current["_usage"]["output_tokens"]           += usage.get("output_tokens", 0)
    current["_usage"]["cache_read_input_tokens"] += (
        usage.get("cache_read_input_tokens", 0)
        + usage.get("cache_creation_input_tokens", 0)
    )

    for block in content_blocks:
        if not isinstance(block, dict):
            continue
        btype = block.get("type")

        if btype == "thinking":
            t = block.get("thinking", "").strip()
            if t:
                current["assistant"]["thinking"].append(t)

        elif btype == "text":
            t = block.get("text", "").strip()
            if t:
                current["assistant"]["text"].append(t)

        elif btype == "tool_use":
            tool_id   = block.get("id", "")
            tool_name = block.get("name", "")
            tool_input = block.get("input", {})
            result    = tool_results.get(tool_id, {})
            current["assistant"]["tool_calls"].append(
                _build_tool_call(tool_name, tool_input, result)
            )


def _finalize_exchange(current: dict) -> dict:
    """Transforme les listes accumulées en strings et nettoie la structure."""
    asst = current["assistant"]

    thinking   = "\n\n".join(asst["thinking"]).strip()
    text       = "\n\n".join(asst["text"]).strip()
    tool_calls = asst["tool_calls"]

    clean_asst: dict[str, Any] = {}
    if thinking:
        clean_asst["thinking"]   = thinking
    if text:
        clean_asst["text"]       = text
    if tool_calls:
        clean_asst["tool_calls"] = tool_calls

    return {
        "index":     current["index"],
        "type":      "exchange",
        "timestamp": current["timestamp"],
        "user":      current["user"],
        "assistant": clean_asst,
        "usage":     current["_usage"],
    }


# ---------------------------------------------------------------------------
# Construction d'un tool call
# ---------------------------------------------------------------------------

def _build_tool_call(tool_name: str, input_data: Any, result: dict) -> dict:
    name_lower = tool_name.lower() if tool_name else ""

    call: dict[str, Any] = {
        "tool":     tool_name,
        "input":    _format_input(name_lower, input_data),
        "is_error": result.get("is_error", False),
    }

    if name_lower == "bash":
        stdout = result.get("stdout", "")
        stderr = result.get("stderr", "")
        call["stdout"] = _truncate(stdout)
        if stderr:
            call["stderr"] = _truncate(stderr)
        if result.get("interrupted"):
            call["interrupted"] = True
    else:
        output = result.get("stdout", "") or result.get("content", "")
        if result.get("is_image"):
            call["is_image"] = True
        elif output:
            call["output"] = _truncate(output)

    return call


def _format_input(name: str, data: Any) -> Any:
    if not isinstance(data, dict):
        return str(data)[:MAX_INPUT_LENGTH]

    if name == "read":
        return data.get("file_path", "")

    if name == "write":
        content = data.get("content", "")
        return {
            "file_path":      data.get("file_path", ""),
            "content_length": len(content),
            "content_preview": content[:300],
        }

    if name == "edit":
        return {
            "file_path":  data.get("file_path", ""),
            "old_string": data.get("old_string", "")[:500],
            "new_string": data.get("new_string", "")[:500],
        }

    if name == "bash":
        return data.get("command", "")

    if name in ("grep",):
        return {
            "pattern": data.get("pattern", ""),
            "path":    data.get("path", ""),
        }

    if name in ("glob",):
        return {
            "pattern": data.get("pattern", ""),
            "path":    data.get("path", ""),
        }

    if name == "task":
        prompt = data.get("prompt", "")
        return _truncate(prompt, MAX_INPUT_LENGTH)

    if name in ("webfetch", "websearch"):
        return data.get("url", "") or data.get("query", "")

    # Générique
    serialized = json.dumps(data, ensure_ascii=False)
    return serialized[:MAX_INPUT_LENGTH]


def _truncate(text: str, limit: int = MAX_OUTPUT_LENGTH) -> str:
    if len(text) <= limit:
        return text
    half = limit // 2
    omitted = len(text) - limit
    return text[:half] + f"\n... [{omitted} chars tronqués] ...\n" + text[-half:]


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

def _compute_stats(turns: list[dict]) -> dict:
    exchanges  = sum(1 for t in turns if t["type"] == "exchange")
    compacts   = sum(1 for t in turns if t["type"] == "compact")
    tool_calls = sum(
        len(t.get("assistant", {}).get("tool_calls", []))
        for t in turns if t["type"] == "exchange"
    )
    input_tok  = sum(t.get("usage", {}).get("input_tokens", 0)            for t in turns if t["type"] == "exchange")
    output_tok = sum(t.get("usage", {}).get("output_tokens", 0)           for t in turns if t["type"] == "exchange")
    cache_tok  = sum(t.get("usage", {}).get("cache_read_input_tokens", 0) for t in turns if t["type"] == "exchange")

    return {
        "exchanges":        exchanges,
        "compacts":         compacts,
        "tool_calls":       tool_calls,
        "input_tokens":     input_tok,
        "output_tokens":    output_tok,
        "cache_read_tokens": cache_tok,
    }


# ---------------------------------------------------------------------------
# Nom de projet lisible
# ---------------------------------------------------------------------------

def _build_project_name(dir_name: str) -> str:
    path  = dir_name.replace("-", "/").lstrip("/")
    parts = path.split("/")

    if len(parts) >= 2 and parts[0] in ("Users", "home"):
        meaningful = parts[2:] if len(parts) > 2 else []
    else:
        meaningful = parts

    if meaningful:
        segments     = dir_name.lstrip("-").split("-")
        prefix_parts = len(parts) - len(meaningful)
        return "-".join(segments[prefix_parts:]) or dir_name

    return dir_name.strip("-") or "unknown"
