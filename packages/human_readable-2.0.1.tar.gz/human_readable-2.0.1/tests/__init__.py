"""Test suite for the human readable package."""
