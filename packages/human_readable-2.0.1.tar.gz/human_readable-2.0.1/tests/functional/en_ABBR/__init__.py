"""Abbreviated English functional tests."""
