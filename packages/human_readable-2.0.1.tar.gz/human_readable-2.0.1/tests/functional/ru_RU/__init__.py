"""Russian functional tests."""
