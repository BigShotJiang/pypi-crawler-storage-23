"""French functional tests."""
