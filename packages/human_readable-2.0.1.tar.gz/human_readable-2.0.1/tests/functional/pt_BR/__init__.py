"""Brazilian Portuguese functional tests."""
