"""
DJ Control Room panel configuration.

This module defines the panel that will be discovered and registered
by DJ Control Room via entry points.
"""


class DjErrorPanelPanel:
    """
    Panel configuration for Dj Error Panel.
    
    This class is discovered by DJ Control Room via the entry point
    defined in pyproject.toml under [project.entry-points."dj_control_room.panels"]
    """
    
    # Unique identifier for this panel (should match the app_name in urls.py)
    id = "dj_error_panel"
    
    # Display name shown in the DJ Control Room dashboard
    name = "Dj Error Panel"
    
    # Brief description shown on the panel card
    description = "Monitor errors and stacktraces right fromn the django admin"
    
    # Icon to display (options: database, layers, link, chart, radio, cog, etc.)
    icon = "cog"
    
    def get_url_name(self):
        """
        Return the URL name for the panel's main view.
        
        This should match the name of your main URL pattern in urls.py.
        Typically this is "index".
        
        Returns:
            str: The URL name (e.g., "index")
        """
        return "index"
