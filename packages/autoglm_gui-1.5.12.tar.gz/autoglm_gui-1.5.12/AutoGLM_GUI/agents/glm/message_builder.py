"""Re-export MessageBuilder from canonical location for backward compatibility."""

from AutoGLM_GUI.model import MessageBuilder

__all__ = ["MessageBuilder"]
