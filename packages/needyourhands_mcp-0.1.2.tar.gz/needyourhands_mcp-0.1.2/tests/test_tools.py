"""
Tests for MCP tool Pydantic model validation.
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from needyourhands_mcp.tools import (
    AvailabilitySlot,
    BookHumanInput,
    BookHumanOutput,
    GetAvailabilityInput,
    GetAvailabilityOutput,
    GetTaskStatusInput,
    GetTaskStatusOutput,
    ProofItem,
    RateHumanInput,
    RateHumanOutput,
    SearchHumansInput,
    SearchHumansOutput,
    SubmitTaskInput,
    SubmitTaskOutput,
    TimelineEvent,
    WorkerSummary,
)


# ---------------------------------------------------------------------------
# WorkerSummary
# ---------------------------------------------------------------------------


class TestWorkerSummary:
    def test_valid_worker(self):
        w = WorkerSummary(
            id="u1",
            name="Alice Dupont",
            rating=4.5,
            skills=["delivery", "photography"],
            city="Paris",
            hourly_rate_min=15.0,
            distance_km=3.2,
            availability="available",
        )
        assert w.id == "u1"
        assert w.rating == 4.5
        assert len(w.skills) == 2

    def test_minimal_worker(self):
        w = WorkerSummary(id="u2", name="Bob", rating=0.0)
        assert w.city == ""
        assert w.hourly_rate_min is None
        assert w.distance_km is None
        assert w.availability == "unknown"

    def test_invalid_rating_too_high(self):
        with pytest.raises(ValidationError):
            WorkerSummary(id="u3", name="Charlie", rating=6.0)

    def test_invalid_rating_negative(self):
        with pytest.raises(ValidationError):
            WorkerSummary(id="u4", name="Diana", rating=-1.0)


# ---------------------------------------------------------------------------
# SearchHumansInput
# ---------------------------------------------------------------------------


class TestSearchHumansInput:
    def test_valid_input(self):
        inp = SearchHumansInput(
            skills=["delivery"],
            location="Paris",
            radius_km=50,
            budget_max_eur=200.0,
            urgency="urgent",
        )
        assert inp.skills == ["delivery"]
        assert inp.radius_km == 50

    def test_defaults(self):
        inp = SearchHumansInput(skills=["photography"], location="Lyon")
        assert inp.radius_km == 25
        assert inp.budget_max_eur == 100.0
        assert inp.urgency == "normal"

    def test_empty_skills_rejected(self):
        with pytest.raises(ValidationError):
            SearchHumansInput(skills=[], location="Paris")

    def test_empty_location_rejected(self):
        with pytest.raises(ValidationError):
            SearchHumansInput(skills=["delivery"], location="")

    def test_invalid_urgency(self):
        with pytest.raises(ValidationError):
            SearchHumansInput(skills=["delivery"], location="Paris", urgency="super_urgent")

    def test_radius_too_large(self):
        with pytest.raises(ValidationError):
            SearchHumansInput(skills=["delivery"], location="Paris", radius_km=1000)

    def test_negative_budget(self):
        with pytest.raises(ValidationError):
            SearchHumansInput(skills=["delivery"], location="Paris", budget_max_eur=-10)


class TestSearchHumansOutput:
    def test_valid_output(self):
        out = SearchHumansOutput(
            workers=[
                WorkerSummary(id="u1", name="Alice", rating=4.0),
                WorkerSummary(id="u2", name="Bob", rating=3.5),
            ],
            total=2,
        )
        assert out.total == 2
        assert len(out.workers) == 2

    def test_empty_output(self):
        out = SearchHumansOutput()
        assert out.workers == []
        assert out.total == 0


# ---------------------------------------------------------------------------
# BookHumanInput
# ---------------------------------------------------------------------------


class TestBookHumanInput:
    def test_valid_input(self):
        inp = BookHumanInput(
            human_id="u1",
            task_title="Pick up package",
            task_description="Collect a package from 12 rue de Rivoli and deliver to office.",
            location="Paris 1er",
            deadline="2026-03-15T18:00:00Z",
            budget_eur=35.0,
        )
        assert inp.human_id == "u1"
        assert inp.budget_eur == 35.0

    def test_empty_human_id_rejected(self):
        with pytest.raises(ValidationError):
            BookHumanInput(
                human_id="",
                task_title="Test",
                task_description="Test description",
                location="Paris",
                deadline="2026-03-15T18:00:00Z",
                budget_eur=20.0,
            )

    def test_zero_budget_rejected(self):
        with pytest.raises(ValidationError):
            BookHumanInput(
                human_id="u1",
                task_title="Test",
                task_description="Test description",
                location="Paris",
                deadline="2026-03-15T18:00:00Z",
                budget_eur=0.0,
            )


class TestBookHumanOutput:
    def test_valid_output(self):
        out = BookHumanOutput(
            mission_id="m1",
            status="assigned",
            estimated_start="2026-03-15T09:00:00Z",
            worker_name="Alice Dupont",
        )
        assert out.mission_id == "m1"
        assert out.status == "assigned"

    def test_minimal_output(self):
        out = BookHumanOutput(mission_id="m2", status="pending")
        assert out.estimated_start is None
        assert out.worker_name == ""


# ---------------------------------------------------------------------------
# GetAvailabilityInput
# ---------------------------------------------------------------------------


class TestGetAvailabilityInput:
    def test_valid_input(self):
        inp = GetAvailabilityInput(
            human_id="u1",
            date="2026-03-15",
            time_range="09:00-18:00",
        )
        assert inp.human_id == "u1"
        assert inp.time_range == "09:00-18:00"

    def test_no_time_range(self):
        inp = GetAvailabilityInput(human_id="u1", date="2026-03-15")
        assert inp.time_range is None

    def test_empty_human_id_rejected(self):
        with pytest.raises(ValidationError):
            GetAvailabilityInput(human_id="", date="2026-03-15")


class TestGetAvailabilityOutput:
    def test_available(self):
        out = GetAvailabilityOutput(
            available=True,
            slots=[
                AvailabilitySlot(start="09:00", end="12:00", available=True),
                AvailabilitySlot(start="14:00", end="18:00", available=True),
            ],
            next_available=None,
        )
        assert out.available is True
        assert len(out.slots) == 2

    def test_unavailable(self):
        out = GetAvailabilityOutput(
            available=False,
            slots=[],
            next_available="2026-03-16",
        )
        assert out.available is False
        assert out.next_available == "2026-03-16"

    def test_defaults(self):
        out = GetAvailabilityOutput()
        assert out.available is False
        assert out.slots == []
        assert out.next_available is None


# ---------------------------------------------------------------------------
# SubmitTaskInput
# ---------------------------------------------------------------------------


class TestSubmitTaskInput:
    def test_valid_input(self):
        inp = SubmitTaskInput(
            title="Photograph a storefront",
            description="Take 10 high-quality photos of the facade at 5 rue du Commerce.",
            required_skills=["photography"],
            location="Paris 15e",
            budget_eur=50.0,
            deadline="2026-03-20T12:00:00Z",
        )
        assert inp.title == "Photograph a storefront"
        assert inp.required_skills == ["photography"]

    def test_empty_skills_rejected(self):
        with pytest.raises(ValidationError):
            SubmitTaskInput(
                title="Test",
                description="Test",
                required_skills=[],
                location="Paris",
                budget_eur=50.0,
                deadline="2026-03-20T12:00:00Z",
            )

    def test_zero_budget_rejected(self):
        with pytest.raises(ValidationError):
            SubmitTaskInput(
                title="Test",
                description="Test",
                required_skills=["delivery"],
                location="Paris",
                budget_eur=0,
                deadline="2026-03-20T12:00:00Z",
            )


class TestSubmitTaskOutput:
    def test_valid_output(self):
        out = SubmitTaskOutput(
            task_id="t1",
            matching_humans_count=12,
            status="open",
        )
        assert out.task_id == "t1"
        assert out.matching_humans_count == 12

    def test_defaults(self):
        out = SubmitTaskOutput(task_id="t2")
        assert out.matching_humans_count == 0
        assert out.status == "open"


# ---------------------------------------------------------------------------
# GetTaskStatusInput / Output
# ---------------------------------------------------------------------------


class TestGetTaskStatusInput:
    def test_valid_input(self):
        inp = GetTaskStatusInput(mission_id="m1")
        assert inp.mission_id == "m1"

    def test_empty_mission_id_rejected(self):
        with pytest.raises(ValidationError):
            GetTaskStatusInput(mission_id="")


class TestGetTaskStatusOutput:
    def test_full_output(self):
        out = GetTaskStatusOutput(
            status="in_progress",
            proofs=[
                ProofItem(
                    type="photo",
                    url="https://storage.example.com/proof1.jpg",
                    timestamp="2026-03-15T10:30:00Z",
                    verified=True,
                )
            ],
            worker_name="Alice Dupont",
            eta="2026-03-15T12:00:00Z",
            timeline=[
                TimelineEvent(
                    timestamp="2026-03-15T09:00:00Z",
                    event="mission_created",
                    details="Mission created by AI agent",
                ),
                TimelineEvent(
                    timestamp="2026-03-15T09:05:00Z",
                    event="worker_assigned",
                    details="Alice Dupont accepted the mission",
                ),
            ],
        )
        assert out.status == "in_progress"
        assert len(out.proofs) == 1
        assert out.proofs[0].verified is True
        assert len(out.timeline) == 2

    def test_minimal_output(self):
        out = GetTaskStatusOutput(status="open")
        assert out.proofs == []
        assert out.worker_name == ""
        assert out.eta is None
        assert out.timeline == []


# ---------------------------------------------------------------------------
# RateHumanInput / Output
# ---------------------------------------------------------------------------


class TestRateHumanInput:
    def test_valid_input(self):
        inp = RateHumanInput(
            mission_id="m1",
            rating=5,
            comment="Excellent work, very professional!",
        )
        assert inp.rating == 5
        assert inp.comment == "Excellent work, very professional!"

    def test_no_comment(self):
        inp = RateHumanInput(mission_id="m1", rating=3)
        assert inp.comment == ""

    def test_rating_too_low(self):
        with pytest.raises(ValidationError):
            RateHumanInput(mission_id="m1", rating=0)

    def test_rating_too_high(self):
        with pytest.raises(ValidationError):
            RateHumanInput(mission_id="m1", rating=6)

    def test_empty_mission_id_rejected(self):
        with pytest.raises(ValidationError):
            RateHumanInput(mission_id="", rating=4)


class TestRateHumanOutput:
    def test_success(self):
        out = RateHumanOutput(success=True, new_average_rating=4.3)
        assert out.success is True
        assert out.new_average_rating == 4.3

    def test_failure(self):
        out = RateHumanOutput(success=False)
        assert out.success is False
        assert out.new_average_rating is None

    def test_defaults(self):
        out = RateHumanOutput()
        assert out.success is False
        assert out.new_average_rating is None


# ---------------------------------------------------------------------------
# VerifyProofInput / Output
# ---------------------------------------------------------------------------


class TestCancelMissionInput:
    def test_valid_input(self):
        from needyourhands_mcp.tools import CancelMissionInput
        inp = CancelMissionInput(
            mission_id="m1",
            reason="Worker ne repond plus",
        )
        assert inp.mission_id == "m1"
        assert inp.reason == "Worker ne repond plus"

    def test_empty_mission_id_rejected(self):
        from needyourhands_mcp.tools import CancelMissionInput
        with pytest.raises(ValidationError):
            CancelMissionInput(mission_id="", reason="test")

    def test_empty_reason_rejected(self):
        from needyourhands_mcp.tools import CancelMissionInput
        with pytest.raises(ValidationError):
            CancelMissionInput(mission_id="m1", reason="")


class TestCancelMissionOutput:
    def test_full_output(self):
        from needyourhands_mcp.tools import CancelMissionOutput
        out = CancelMissionOutput(
            mission_id="m1",
            new_status="cancelled",
            reason="Worker ne repond plus",
            payment_action="canceled",
            payment_status="canceled",
            cancelled_at="2026-02-17T15:30:00+00:00",
        )
        assert out.new_status == "cancelled"
        assert out.payment_action == "canceled"


class TestVerifyProofInput:
    def test_valid_approve(self):
        from needyourhands_mcp.tools import VerifyProofInput
        inp = VerifyProofInput(
            mission_id="m1",
            proof_index=0,
            approved=True,
        )
        assert inp.approved is True
        assert inp.rejection_reason == ""

    def test_valid_reject(self):
        from needyourhands_mcp.tools import VerifyProofInput
        inp = VerifyProofInput(
            mission_id="m1",
            proof_index=0,
            approved=False,
            rejection_reason="Photo floue",
        )
        assert inp.approved is False
        assert inp.rejection_reason == "Photo floue"

    def test_empty_mission_id_rejected(self):
        from needyourhands_mcp.tools import VerifyProofInput
        with pytest.raises(ValidationError):
            VerifyProofInput(mission_id="", proof_index=0, approved=True)

    def test_negative_index_rejected(self):
        from needyourhands_mcp.tools import VerifyProofInput
        with pytest.raises(ValidationError):
            VerifyProofInput(mission_id="m1", proof_index=-1, approved=True)


class TestVerifyProofOutput:
    def test_full_output(self):
        from needyourhands_mcp.tools import VerifyProofOutput
        out = VerifyProofOutput(
            mission_id="m1",
            proof_index=0,
            approved=True,
            new_mission_status="completed",
            all_proofs_verified=True,
            total_proofs=1,
            verified_count=1,
        )
        assert out.all_proofs_verified is True
        assert out.new_mission_status == "completed"

    def test_defaults(self):
        from needyourhands_mcp.tools import VerifyProofOutput
        out = VerifyProofOutput(mission_id="m1", proof_index=0, approved=False)
        assert out.all_proofs_verified is False
        assert out.verified_count == 0
