"""Tests for CLI and config."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from attocode.cli import main
from attocode.config import (
    AttoConfig,
    find_project_root,
    get_user_config_dir,
    load_config,
    load_json_config,
    load_rules,
    load_yaml_config,
)


class TestAttoConfig:
    def test_defaults(self) -> None:
        c = AttoConfig()
        assert c.provider == "anthropic"
        assert c.model == "claude-sonnet-4-20250514"
        assert c.max_iterations == 100
        assert c.compaction_warning_threshold == pytest.approx(0.7)
        assert c.compaction_threshold == pytest.approx(0.8)
        assert c.debug is False
        assert c.swarm is False

    def test_slots(self) -> None:
        c = AttoConfig()
        with pytest.raises(AttributeError):
            c.nonexistent = "value"


class TestFindProjectRoot:
    def test_finds_git_dir(self, tmp_path: Path) -> None:
        (tmp_path / ".git").mkdir()
        sub = tmp_path / "sub" / "deep"
        sub.mkdir(parents=True)
        result = find_project_root(sub)
        assert result == tmp_path

    def test_finds_attocode_dir(self, tmp_path: Path) -> None:
        (tmp_path / ".attocode").mkdir()
        result = find_project_root(tmp_path)
        assert result == tmp_path

    def test_returns_none_for_root(self, tmp_path: Path) -> None:
        # tmp_path usually doesn't have .git or .attocode
        isolated = tmp_path / "isolated"
        isolated.mkdir()
        result = find_project_root(isolated)
        # May or may not be None depending on system, but should not crash
        assert result is None or isinstance(result, Path)


class TestLoadJsonConfig:
    def test_load_existing(self, tmp_path: Path) -> None:
        f = tmp_path / "config.json"
        f.write_text(json.dumps({"model": "gpt-4o"}))
        result = load_json_config(f)
        assert result["model"] == "gpt-4o"

    def test_load_missing(self, tmp_path: Path) -> None:
        result = load_json_config(tmp_path / "missing.json")
        assert result == {}

    def test_load_invalid_json(self, tmp_path: Path) -> None:
        f = tmp_path / "bad.json"
        f.write_text("not json{{{")
        result = load_json_config(f)
        assert result == {}


class TestLoadYamlConfig:
    def test_load_existing(self, tmp_path: Path) -> None:
        f = tmp_path / "config.yaml"
        f.write_text("model: gpt-4o\ntemperature: 0.5\n")
        result = load_yaml_config(f)
        assert result["model"] == "gpt-4o"
        assert result["temperature"] == 0.5

    def test_load_missing(self, tmp_path: Path) -> None:
        result = load_yaml_config(tmp_path / "missing.yaml")
        assert result == {}

    def test_load_non_dict(self, tmp_path: Path) -> None:
        f = tmp_path / "list.yaml"
        f.write_text("- item1\n- item2\n")
        result = load_yaml_config(f)
        assert result == {}


class TestLoadRules:
    def test_load_existing(self, tmp_path: Path) -> None:
        f = tmp_path / "rules.md"
        f.write_text("# Rules\n- Be nice\n")
        result = load_rules(f)
        assert "Be nice" in result

    def test_load_missing(self, tmp_path: Path) -> None:
        result = load_rules(tmp_path / "missing.md")
        assert result == ""


class TestLoadConfig:
    def test_defaults(self) -> None:
        config = load_config()
        assert config.provider in ("anthropic", "openrouter", "openai", "zai")
        assert config.max_iterations == 100

    def test_cli_args_override(self) -> None:
        config = load_config(
            cli_args={
                "model": "gpt-4o",
                "debug": True,
                "compaction_threshold": 0.91,
            }
        )
        assert config.model == "gpt-4o"
        assert config.debug is True
        assert config.compaction_threshold == pytest.approx(0.91)

    def test_project_compaction_block(self, tmp_path: Path) -> None:
        project_root = tmp_path / "repo"
        workdir = project_root / "subdir"
        (project_root / ".attocode").mkdir(parents=True)
        workdir.mkdir(parents=True)
        (project_root / ".attocode" / "config.json").write_text(
            json.dumps({
                "compaction": {
                    "warningThreshold": 0.61,
                    "compactionThreshold": 0.77,
                },
            }),
            encoding="utf-8",
        )

        config = load_config(working_dir=str(workdir))
        assert config.compaction_warning_threshold == pytest.approx(0.61)
        assert config.compaction_threshold == pytest.approx(0.77)

    def test_working_dir(self, tmp_path: Path) -> None:
        config = load_config(working_dir=str(tmp_path))
        assert config.working_directory == str(tmp_path)


class TestCLI:
    def test_version(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "attocode " in result.output

    def test_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Attocode" in result.output
        assert "--model" in result.output
        assert "--provider" in result.output

    def test_swarm_passthrough_dispatch(self, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        called: dict[str, Any] = {}

        def _fake(parts: tuple[str, ...], *, debug: bool = False) -> None:
            called["parts"] = parts
            called["debug"] = debug

        monkeypatch.setattr("attocode.cli._dispatch_swarm_command", _fake)
        runner = CliRunner()
        result = runner.invoke(main, ["swarm", "doctor", ".attocode/swarm.hybrid.yaml"])
        assert result.exit_code == 0
        assert called["parts"] == ("doctor", ".attocode/swarm.hybrid.yaml")
        assert called["debug"] is False

    def test_single_turn_exits_1_on_failure(self, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        """When agent.run() returns success=False, the process should exit 1."""

        def _fake_single_turn(config: Any, prompt: str) -> None:
            # Simulate what _run_single_turn does when result.success is False
            sys.exit(1)

        monkeypatch.setattr("attocode.cli._run_single_turn", _fake_single_turn)

        runner = CliRunner()
        result = runner.invoke(main, ["--non-interactive", "fail please"])
        assert result.exit_code == 1

    def test_single_turn_exits_0_on_success(self, monkeypatch) -> None:  # type: ignore[no-untyped-def]
        """When agent.run() returns success=True, the process should exit 0."""

        def _fake_single_turn(config: Any, prompt: str) -> None:
            # Simulate what _run_single_turn does when result.success is True
            pass

        monkeypatch.setattr("attocode.cli._run_single_turn", _fake_single_turn)

        runner = CliRunner()
        result = runner.invoke(main, ["--non-interactive", "succeed please"])
        assert result.exit_code == 0
