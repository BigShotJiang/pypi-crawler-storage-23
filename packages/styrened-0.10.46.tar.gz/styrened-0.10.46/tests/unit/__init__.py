"""Unit tests for styrened components.

Unit tests verify isolated components without RNS/LXMF dependencies.
These tests are fast and run without network stack.
"""
