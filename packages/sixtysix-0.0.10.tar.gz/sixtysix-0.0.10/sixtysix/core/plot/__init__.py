"""
Plot Module - Chart visualization components and serialization

Components:
    Line, Scatter, Bar, HBar, HLine, Fill, Segment, Marker, SignalPlot, Label

Serialization:
    extract_plot_data - Convert components to JSON format
"""

from .components import (
    SeriesLike,
    ColorLike,
    PlotComponent,
    LineDash,
    ScatterShape,
    PositionMode,
    TextAlign,
    TextBaseline,
    Line,
    Scatter,
    Bar,
    HBar,
    HLine,
    Fill,
    Segment,
    Marker,
    SignalPlot,
    Label,
    Panel,
    PlotResult,
)
from .serialization import extract_plot_data, extract_plot_data_with_panels, _to_list

__all__ = [
    # Type aliases
    'SeriesLike',
    'ColorLike',
    'PlotComponent',
    # Literal types
    'LineDash',
    'ScatterShape',
    'PositionMode',
    'TextAlign',
    'TextBaseline',
    # Components
    'Line',
    'Scatter',
    'Bar',
    'HBar',
    'HLine',
    'Fill',
    'Segment',
    'Marker',
    'SignalPlot',
    'Label',
    # Panel system
    'Panel',
    'PlotResult',
    # Serialization
    'extract_plot_data',
    'extract_plot_data_with_panels',
    '_to_list',
]
