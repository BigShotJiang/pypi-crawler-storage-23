"""VFS drivers for hexDAG."""

from hexdag.drivers.vfs.local import LocalVFS

__all__ = ["LocalVFS"]
