"""Local adapter implementations — re-exports from drivers/."""

from hexdag.drivers.observer_manager import LocalObserverManager

__all__ = [
    "LocalObserverManager",
]
