"""pgvector adapter for PostgreSQL with vector similarity search."""

from hexdag.stdlib.adapters.database.pgvector.pgvector_adapter import PgVectorAdapter

__all__ = ["PgVectorAdapter"]
