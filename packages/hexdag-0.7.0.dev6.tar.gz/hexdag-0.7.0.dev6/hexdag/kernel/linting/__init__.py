"""Pipeline linting framework for hexDAG."""
