"""FastAPI server for hexdag studio."""
