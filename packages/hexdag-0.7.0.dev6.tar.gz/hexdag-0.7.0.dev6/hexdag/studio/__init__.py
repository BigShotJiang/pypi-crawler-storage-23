"""hexdag studio - Local-first visual editor for hexdag pipelines.

Usage:
    hexdag studio ./pipelines/

Opens a browser-based editor that reads/writes YAML files directly.
No cloud, no accounts - just local files that work with git.
"""

__version__ = "0.1.0"
