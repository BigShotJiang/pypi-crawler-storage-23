# Nomox LLM Semantic Model

Internal python package for describing semantics model used across Nomox.

## Installation

To use the package from anywhere run:

```bash
pip install git+https://github.com/MiraZzle/nomox-semantics-package.git
```

Or add to `requirements.txt`:

```bash
git+https://github.com/MiraZzle/nomox-semantics-package.git
```

To pin a specific version, use a specific tag:

```bash
git+https://github.com/MiraZzle/nomox-semantics-package.git@v0.2.0
```

## Usage

Usage examples can be found at [Usage docs](./docs/usage.md).
