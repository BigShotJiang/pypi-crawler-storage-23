## Architecture

The semantic model is organized into three layers:

### Level 1: Source-Scoped Semantics

Produced by the Level 1 Indexer Agent. Contains:

- **DataSource**: Top-level container for a data source (Trino catalog.schema)
- **Table**: Tables and views with semantic roles and temporal information
- **Column**: Columns with semantic types, profiling, and sample values
- **InternalRelationship**: Foreign key relationships within a source

### Level 2: Cross-Source Semantics

Produced by the Level 2 Aggregator Agent. Contains:

- **SemanticEntity**: Canonical business concepts (Customer, Order, Product)
- **EntityManifestation**: Where entities appear across sources
- **UnifiedAttribute**: Logical attributes sourced from multiple places
- **EntityRelationship**: Relationships between entities with join paths
- **IdentityResolution**: How to match entities across sources

### Shared Components

- **GlossaryTerm**: Business terminology definitions
- **ConfidenceScore**: Confidence scoring for all elements
- **ExpertOverride**: Human corrections and enhancements
- **IndexingState**: Tracking of indexing jobs and status
