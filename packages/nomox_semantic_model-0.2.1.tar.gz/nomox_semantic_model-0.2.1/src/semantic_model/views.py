"""
Scoped views of the semantic model.

Each view bundles a primary domain object with the relevant cross-cutting
data from all 3 layers, ready to be consumed by the API or any other client.

  ModelView    — the complete SemanticModel
  SourceView   — a DataSource + related Level 2 + Shared data
  TableView    — a Table + related Level 2 + Shared data
  ColumnView   — a Column + related Level 2 + Shared data
"""

from pydantic import Field

from semantic_model.base import SemanticBaseModel
from semantic_model.model import SemanticModel
from semantic_model.sources import DataSource
from semantic_model.tables import Table
from semantic_model.columns import Column
from semantic_model.relationships import InternalRelationship
from semantic_model.entities import SemanticEntity
from semantic_model.entity_relationships import EntityRelationship
from semantic_model.glossary import GlossaryTerm
from semantic_model.overrides import ExpertOverride


class ModelView(SemanticBaseModel):
    """The full semantic model — all sources, entities, glossary and overrides."""

    model: SemanticModel


class SourceView(SemanticBaseModel):
    """Everything semantically relevant to a single data source."""

    # Level 1
    source: DataSource

    # Level 2 — entities with at least one manifestation in this source
    entities: list[SemanticEntity] = Field(default_factory=list)
    entity_relationships: list[EntityRelationship] = Field(default_factory=list)

    # Shared
    glossary: list[GlossaryTerm] = Field(default_factory=list)
    overrides: list[ExpertOverride] = Field(default_factory=list)


class TableView(SemanticBaseModel):
    """Everything semantically relevant to a single table."""

    # Level 1
    table: Table
    internal_relationships: list[InternalRelationship] = Field(default_factory=list)

    # Level 2 — entities whose manifestations point to this table
    entities: list[SemanticEntity] = Field(default_factory=list)
    entity_relationships: list[EntityRelationship] = Field(default_factory=list)

    # Shared
    glossary: list[GlossaryTerm] = Field(default_factory=list)
    overrides: list[ExpertOverride] = Field(default_factory=list)


class ColumnView(SemanticBaseModel):
    """Everything semantically relevant to a single column."""

    # Level 1
    column: Column

    # Level 2 — entities whose unified attributes source from this column
    entities: list[SemanticEntity] = Field(default_factory=list)

    # Shared
    glossary: list[GlossaryTerm] = Field(default_factory=list)
    overrides: list[ExpertOverride] = Field(default_factory=list)
