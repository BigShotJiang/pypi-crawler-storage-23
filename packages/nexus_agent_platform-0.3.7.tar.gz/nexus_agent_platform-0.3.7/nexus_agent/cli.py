import click
from rich.console import Console

from nexus_agent import __version__

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="nexus-agent")
def main():
    """Nexus Agent — AI Agent Platform with MCP Integration"""
    pass


@main.command()
@click.option("--host", default="0.0.0.0", help="바인딩 호스트")
@click.option("--port", default=8000, type=int, help="포트 번호")
@click.option("--dev", is_flag=True, help="개발 모드 (CORS 허용, 리로드)")
def start(host: str, port: int, dev: bool):
    """서버 시작 (프론트엔드 + API)"""
    import os
    import uvicorn

    if dev:
        os.environ["NEXUS_DEV"] = "1"

    console.print(f"[bold green]Nexus Agent v{__version__}[/] starting on http://{host}:{port}")
    if dev:
        console.print("[dim]개발 모드: CORS 허용, 리로드 활성화[/]")

    uvicorn.run(
        "nexus_agent.server:app",
        host=host,
        port=port,
        reload=dev,
    )


@main.command()
def init():
    """~/.nexus-agent/ 초기 설정 파일 생성"""
    from nexus_agent.config import init_data_dir

    data_dir = init_data_dir()
    console.print(f"[green]✓[/] 데이터 디렉토리: {data_dir}")
    console.print("[dim]  .env, mcp.json, settings.json, skills.json, pages.json 생성 완료[/]")
    console.print(f"\n[bold]다음 단계:[/] {data_dir / '.env'} 에 GOOGLE_API_KEY를 설정하세요.")


@main.command()
def config():
    """현재 설정 경로 및 상태 표시"""
    from nexus_agent.config import get_data_dir

    data_dir = get_data_dir()
    console.print(f"[bold]데이터 디렉토리:[/] {data_dir}")

    for name in ["settings.json", "mcp.json", "skills.json", "pages.json", ".env"]:
        path = data_dir / name
        status = "[green]✓[/]" if path.exists() else "[red]✗[/]"
        console.print(f"  {status} {name}")


@main.command()
def update():
    """최신 버전으로 업데이트"""
    import subprocess

    console.print("[bold]nexus-agent 업데이트 중...[/]")
    try:
        subprocess.run(["uv", "tool", "upgrade", "nexus-agent-platform"], check=True)
        console.print("[green]✓ 업데이트 완료[/]")
    except FileNotFoundError:
        try:
            subprocess.run(["pipx", "upgrade", "nexus-agent-platform"], check=True)
            console.print("[green]✓ 업데이트 완료[/]")
        except FileNotFoundError:
            console.print("[red]uv 또는 pipx를 찾을 수 없습니다.[/]")
