# Datatrail CLI Reference

This page provides documentation for the Datatrail CLI.

::: mkdocs-click
    :module: dtcli.cli
    :command: cli
    :prog_name: datatrail
    :depth: 1
    :style: table
