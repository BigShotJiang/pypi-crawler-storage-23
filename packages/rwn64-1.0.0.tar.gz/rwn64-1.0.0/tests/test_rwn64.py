import sys,os,time
sys.path.insert(0,os.path.join(os.path.dirname(__file__),".."))
import rwn64

_G="\x1b[32m✔\x1b[0m"; _R="\x1b[31m✘\x1b[0m"
_H="\x1b[1m\x1b[38;5;252m"; _D="\x1b[38;5;245m"; _E="\x1b[0m"
_p=_f=0

def _head(t): print(f"\n{_H}{t}{_E}")
def _assert(c,m="assertion failed"):
    if not c: raise AssertionError(m)

def test(label,fn):
    global _p,_f
    try:    fn(); print(f"  {_G}  {label}"); _p+=1
    except Exception as e: print(f"  {_R}  {label}\n     {_D}{e}{_E}"); _f+=1

_head("encrypt / decrypt")
test("returns rwn64:v1: token",          lambda:_assert(rwn64.encrypt("hi","pw").startswith("rwn64:v1:")))
test("roundtrip plaintext",              lambda:_assert(rwn64.decrypt(rwn64.encrypt("secret","pw"),"pw")=="secret"))
test("unique tokens per call",           lambda:_assert(rwn64.encrypt("x","pw")!=rwn64.encrypt("x","pw")))
test("unicode roundtrip",                lambda:_assert(rwn64.decrypt(rwn64.encrypt("日本語 ñ @#$","pw"),"pw")=="日本語 ñ @#$"))
test("10 KB roundtrip",                  lambda:_assert(rwn64.decrypt(rwn64.encrypt("x"*10240,"pw"),"pw")=="x"*10240))

_head("wrong password / tampered")
def _t6():
    tok=rwn64.encrypt("secret","correct")
    try: rwn64.decrypt(tok,"wrong"); raise AssertionError("should raise")
    except ValueError: pass
test("wrong password raises",_t6)

def _t7():
    tok=rwn64.encrypt("secret","pw")
    try: rwn64.decrypt(tok[:-6]+"AAAAAA","pw"); raise AssertionError("should raise")
    except Exception: pass
test("tampered token raises",_t7)

def _t8():
    try: rwn64.decrypt("notatoken","pw"); raise AssertionError("should raise")
    except Exception: pass
test("invalid format raises",_t8)

_head("verify")
test("valid token → True",   lambda:_assert(rwn64.verify(rwn64.encrypt("x","pw"),"pw") is True))
test("wrong password → False",lambda:_assert(rwn64.verify(rwn64.encrypt("x","pw"),"bad") is False))
test("garbage → False",       lambda:_assert(rwn64.verify("garbage","pw") is False))

_head("expiry")
test("no expiry decrypts",    lambda:_assert(rwn64.decrypt(rwn64.encrypt("x","pw"),"pw")=="x"))
test("future expiry decrypts",lambda:_assert(rwn64.decrypt(rwn64.encrypt("x","pw",expires_ms=int(time.time()*1000)+60000),"pw")=="x"))
test("expires= string (1h)",  lambda:_assert(rwn64.decrypt(rwn64.encrypt("x","pw",expires="1h"),"pw")=="x"))

def _t13():
    tok=rwn64.encrypt("x","pw",expires_ms=int(time.time()*1000)+100)
    time.sleep(0.2)
    try: rwn64.decrypt(tok,"pw"); raise AssertionError("should raise")
    except ValueError as e: _assert("expired" in str(e).lower())
test("expired token raises",_t13)

_head("fingerprint")
test("deterministic",         lambda:_assert(rwn64.fingerprint("hi","s")==rwn64.fingerprint("hi","s")))
test("different input differs",lambda:_assert(rwn64.fingerprint("a","s")!=rwn64.fingerprint("b","s")))
test("16 hex chars",          lambda:_assert(len(rwn64.fingerprint("x","s"))==16))

_head("generate")
test("non-empty string",      lambda:_assert(isinstance(rwn64.generate(),str) and len(rwn64.generate())>0))
test("unique values",         lambda:_assert(rwn64.generate()!=rwn64.generate()))

_head("inspect")
def _t_ins():
    m=rwn64.inspect(rwn64.encrypt("x","pw"))
    _assert(m["version"]=="v1")
    _assert(m["algo"]=="AES-256-GCM")
    _assert(m["prefix"]=="rwn64:v1:")
test("inspect metadata",_t_ins)

_head("node interoperability")
_TOK ="rwn64:v1:IaQVjP7tITZRERd-MWZBpxGMdo432gsidiGNlK9vZFSt-Vqhs2ioZt4dFykhmciisVa9a07VY0M"
_PASS="minhasenha"
_TXT ="old v1 text"
test("decrypt Node.js token", lambda:_assert(rwn64.decrypt(_TOK,_PASS)==_TXT))
test("Python token is valid", lambda:_assert(rwn64.decrypt(rwn64.encrypt(_TXT,_PASS),_PASS)==_TXT))

total=_p+_f
print(f"\n{_D}{'─'*48}{_E}\n")
print(f"  total   {total}")
print(f"  \x1b[32mpassed  {_p}\x1b[0m")
if _f: print(f"  \x1b[31mfailed  {_f}\x1b[0m")
print()
if not _f: print(f"  \x1b[32m\x1b[1mall tests passed\x1b[0m\n")
else:      print(f"  \x1b[31m\x1b[1m{_f} test(s) failed\x1b[0m\n"); sys.exit(1)
