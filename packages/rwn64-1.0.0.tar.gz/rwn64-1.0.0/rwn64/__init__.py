from __future__ import annotations
from ._crypto import encrypt as _enc,decrypt as _dec
from ._util   import fingerprint as _fp,generate as _gen,parse_expiry,inspect as _ins

__version__  = "1.0.0"
__all__      = ["encrypt","decrypt","verify","fingerprint","generate","inspect","parse_expiry"]
TOKEN_PREFIX = "rwn64:v1:"

def encrypt(text:str,password:str,*,expires:str|None=None,expires_ms:int|None=None)->str:
    if not password: raise TypeError("password must be non-empty")
    exp=parse_expiry(expires) if expires else expires_ms
    return _enc(text,password,expires_ms=exp)

def decrypt(token:str,password:str)->str:
    if not token:    raise TypeError("token must be non-empty")
    if not password: raise TypeError("password must be non-empty")
    return _dec(token,password)[0]

def verify(token:str,password:str)->bool:
    try: _dec(token,password); return True
    except: return False

def fingerprint(text:str,secret:str)->str: return _fp(text,secret)
def generate(nbytes:int=24)->str:          return _gen(nbytes)
def inspect(token:str)->dict:              return _ins(token)
