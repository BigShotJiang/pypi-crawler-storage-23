from __future__ import annotations
import ctypes as _c, hashlib as _h, os as _o, struct as _s, time as _t, base64 as _b64

_lib   = _c.CDLL("libcrypto.so.3")
_ci    = _c.c_int
_cv    = _c.c_void_p
_cc    = _c.c_char_p

_lib.EVP_CIPHER_CTX_new.restype       = _cv
_lib.EVP_aes_256_gcm.restype          = _cv
_lib.EVP_EncryptInit_ex.argtypes      = [_cv,_cv,_cv,_cc,_cc];  _lib.EVP_EncryptInit_ex.restype  = _ci
_lib.EVP_DecryptInit_ex.argtypes      = [_cv,_cv,_cv,_cc,_cc];  _lib.EVP_DecryptInit_ex.restype  = _ci
_lib.EVP_CIPHER_CTX_ctrl.argtypes     = [_cv,_ci,_ci,_cv];      _lib.EVP_CIPHER_CTX_ctrl.restype = _ci
_lib.EVP_EncryptUpdate.argtypes       = [_cv,_cc,_c.POINTER(_ci),_cc,_ci]; _lib.EVP_EncryptUpdate.restype  = _ci
_lib.EVP_DecryptUpdate.argtypes       = [_cv,_cc,_c.POINTER(_ci),_cc,_ci]; _lib.EVP_DecryptUpdate.restype  = _ci
_lib.EVP_EncryptFinal_ex.argtypes     = [_cv,_cc,_c.POINTER(_ci)]; _lib.EVP_EncryptFinal_ex.restype = _ci
_lib.EVP_DecryptFinal_ex.argtypes     = [_cv,_cc,_c.POINTER(_ci)]; _lib.EVP_DecryptFinal_ex.restype = _ci
_lib.EVP_CIPHER_CTX_free.argtypes     = [_cv]

_GCM_SIVLEN = 0x9
_GCM_GTAG   = 0x10
_GCM_STAG   = 0x11
_SL,_NL,_TL,_KL = 16,12,16,32
_N,_R,_P         = 16384,8,1
_PX1             = b"rwn64:v1:"

def _kdf(pw:bytes,salt:bytes)->bytes:
    return _h.scrypt(pw,salt=salt,n=_N,r=_R,p=_P,dklen=_KL)

def _enc(key:bytes,nonce:bytes,pt:bytes)->tuple[bytes,bytes]:
    x=_lib.EVP_CIPHER_CTX_new()
    _lib.EVP_EncryptInit_ex(x,_lib.EVP_aes_256_gcm(),None,None,None)
    _lib.EVP_CIPHER_CTX_ctrl(x,_GCM_SIVLEN,len(nonce),None)
    _lib.EVP_EncryptInit_ex(x,None,None,key,nonce)
    buf=_c.create_string_buffer(len(pt)+16); l=_ci(0)
    _lib.EVP_EncryptUpdate(x,buf,_c.byref(l),pt,len(pt))
    ct=buf.raw[:l.value]
    _lib.EVP_EncryptFinal_ex(x,buf,_c.byref(l))
    tag=_c.create_string_buffer(16)
    _lib.EVP_CIPHER_CTX_ctrl(x,_GCM_GTAG,16,tag)
    _lib.EVP_CIPHER_CTX_free(x)
    return ct,tag.raw

def _dec(key:bytes,nonce:bytes,ct:bytes,tag:bytes)->bytes:
    x=_lib.EVP_CIPHER_CTX_new()
    _lib.EVP_DecryptInit_ex(x,_lib.EVP_aes_256_gcm(),None,None,None)
    _lib.EVP_CIPHER_CTX_ctrl(x,_GCM_SIVLEN,len(nonce),None)
    _lib.EVP_DecryptInit_ex(x,None,None,key,nonce)
    buf=_c.create_string_buffer(len(ct)+16); l=_ci(0)
    _lib.EVP_DecryptUpdate(x,buf,_c.byref(l),ct,len(ct))
    pt=buf.raw[:l.value]
    _lib.EVP_CIPHER_CTX_ctrl(x,_GCM_STAG,16,_c.c_char_p(tag))
    fin=_c.create_string_buffer(16)
    ok=_lib.EVP_DecryptFinal_ex(x,fin,_c.byref(l))
    _lib.EVP_CIPHER_CTX_free(x)
    if ok<=0: raise ValueError("wrong password or corrupted token")
    return pt

def _b64e(b:bytes)->bytes: return _b64.urlsafe_b64encode(b).rstrip(b"=")
def _b64d(b:bytes)->bytes:
    p=4-len(b)%4
    return _b64.urlsafe_b64decode(b+(b"="*p if p!=4 else b""))

def _eexp(ms:int)->bytes:
    return _s.pack(">II",ms>>32,ms&0xFFFFFFFF)

def _dexp(b:bytes)->int:
    hi,lo=_s.unpack(">II",b); return(hi<<32)|lo

def encrypt(plaintext:str,password:str,*,expires_ms:int|None=None)->str:
    salt=_o.urandom(_SL); nonce=_o.urandom(_NL)
    key=_kdf(password.encode(),salt)
    hx=expires_ms is not None
    inner=(b"\x01"+_eexp(expires_ms) if hx else b"\x00")+plaintext.encode()
    ct,tag=_enc(key,nonce,inner)
    return(_PX1+_b64e(salt+nonce+tag+ct)).decode()

def decrypt(token:str,password:str)->tuple[str,int|None]:
    tb=token.encode()
    if not tb.startswith(_PX1): raise ValueError("invalid token format")
    raw=_b64d(tb[len(_PX1):])
    if len(raw)<_SL+_NL+_TL+2: raise ValueError("token is too short or malformed")
    salt=raw[:_SL]; nonce=raw[_SL:_SL+_NL]; tag=raw[_SL+_NL:_SL+_NL+_TL]; ct=raw[_SL+_NL+_TL:]
    key=_kdf(password.encode(),salt)
    inner=_dec(key,nonce,ct,tag)
    if inner[0]==1:
        exp=_dexp(inner[1:9])
        if int(_t.time()*1000)>exp: raise ValueError(f"token expired at {exp}")
        return inner[9:].decode(),exp
    return inner[1:].decode(),None
