Contributors
============

- Philip Bauer, bauer@starzel.de

- Maurits van Rees, m.van.rees@zestsoftware.nl

- Fred van Dijk, f.van.dijk@zestsoftware.nl

- Leonardo J. Caballero G., leonardocaballero@gmail.com
