"""Tests for update_pipeline function."""

import pytest

from agentic_devtools.cli.azure_devops.pipeline_commands import update_pipeline  # noqa: F401


@pytest.mark.skip(reason="TODO: implement tests for update_pipeline")
def test_update_pipeline() -> None:
    raise NotImplementedError
