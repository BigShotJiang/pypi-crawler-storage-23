# Work on Jira Issue - Retrieve Step

You are retrieving details for Jira issue **{{issue_key}}**.

The issue details have been fetched and saved. Review the information below:

## Issue Summary

{{issue_summary}}

## Issue Type

{{issue_type}}

## Labels

{{issue_labels}}

## Description

{{issue_description}}

## Comments

{{issue_comments}}

---

**Workflow Status**: Retrieve complete. Advancing to planning step...
