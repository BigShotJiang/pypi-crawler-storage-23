"""Syke — Personal context daemon."""

__version__ = "0.3.4"
