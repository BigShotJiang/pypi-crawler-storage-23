# 🚀 Sloki Agent — Agentic Code Editor

A professional, multi-agent AI system for rule-driven, surgical code editing with autonomous execution support.

## ✨ Features

- **Multi-Agent Pipeline**: Intent → RuleGuard → Planning → Editing → Validation → Walkthrough
- **Surgical Precision**: Only modifies code within `// === EDITABLE ===` blocks
- **Rule Enforcement**: RuleGuard agent blocks modifications to protected files
- **Autonomous Mode**: `--auto` flag for headless, zero-interaction execution from `.md` files
- **Human-in-the-Loop**: Interactive mode with plan approval and code review
- **Comprehensive Setup UI**: Built-in `/config` and `/guide` wizards for seamless API key and local LLM configuration
- **Post-Edit Validation**: Automatic compilation check after code changes
- **Multi-Provider LLM**: Supports LMStudio (local), Gemini, OpenAI, Anthropic
- **Workflow System**: Structured `.md` workflows for repeatable task execution
- **Skills System**: Domain-specific skill definitions with strict boundaries

## 📁 Repository Structure

```text
sloki_agent/
├── src/sloki_agent/     # Main package source
│   ├── agents/          # Specialized AI agents
│   ├── core/            # System backbone
│   ├── .agents/         # Agent infrastructure (skills/workflows)
│   ├── code_editor/     # Surgical block parser
│   ├── rules/           # Rule engine
│   ├── validators/      # Post-edit validators
│   ├── prompts/         # LLM templates
│   ├── brain/           # Session persistence
│   └── cli.py           # Entry point
├── dist/                # PyPI distribution files
├── docs/                # Extended Documentation
├── pyproject.toml       # Build configuration
└── MANIFEST.in          # Package data manifest
```

## ✂️ Surgical Editing Strategy

Sloki employs a "Zero-Touch" surgical strategy to ensure code integrity:

1.  **Manual Instrumentation**: Use `// === EDITABLE_START: name ===` markers to define safe zones.
2.  **Autonomous Instrumentation**: If markers are missing, Sloki's **Smart Marker** engine analyzes the code, identifies the safest modification block, and automatically inserts markers for you.
3.  **RuleGuard Protection**: Edits outside of these surgical zones are autonomously blocked by the safety engine (configured in `project_rules.json`).

## 🚀 Getting Started

### Windows & macOS

```bash
pip install sloki-agent
sloki-agent
```

### Linux (Ubuntu, Debian, Kali)

Modern Linux distros block global pip installs. Use **pipx** instead:

```bash
# 1. Install pipx if missing
sudo apt update && sudo apt install pipx

# 2. Add pipx to your path
pipx ensurepath

# 3. Install Sloki globally
pipx install sloki-agent

# 4. Restart your terminal, then:
sloki-agent
```

### Autonomous Mode (No Human Intervention)

```bash
sloki-agent --auto --input requirements.md
sloki-agent --auto --input requirements.md --provider gemini
```

### Provider Selection

```bash
sloki-agent --provider lmstudio   # Local (default)
sloki-agent --provider gemini     # Google Gemini
sloki-agent --provider openai     # OpenAI GPT
sloki-agent --provider anthropic  # Anthropic Claude
```

## 📚 Documentation

- [Architecture Overview](docs/architecture.md)
- [Usage Guide](docs/usage_guide.md)
- [Rule Engine](docs/rules_engine.md)
- [Agent Details](docs/agent_details.md)
- [RAG Strategy](docs/rag_integration.md)
- [Development Guide](docs/development.md)

## 🔧 Configuration

1. Set API keys in `~/.sloki/.env` (copy from `.env.example`) or configure them via the CLI.
2. Run `sloki-agent` for the first-time setup wizard (handles API Keys, Auto Mode, and Project Discovery).
3. Type `/guide` in the CLI for instructions on setting up LM Studio locally.
4. Or use `--auto` mode with a pre-configured `~/.sloki/brain/project_config.md`.
