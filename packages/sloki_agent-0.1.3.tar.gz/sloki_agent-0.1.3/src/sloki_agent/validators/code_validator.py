"""
Code Validator — Post-edit validation via compilation and syntax checks.
Ensures generated code actually compiles before being accepted.
"""
import subprocess
import os
import re
import shutil


class CompilationValidator:
    """Validates generated code by attempting compilation."""

    def __init__(self, project_root, build_command=None):
        self.project_root = project_root
        self.build_command = build_command or self._detect_build_command()

    def _detect_build_command(self):
        """Auto-detect the build system, verifying tools actually exist."""
        if not self.project_root:
            return None

        # Check for Makefile + make/mingw32-make
        if os.path.exists(os.path.join(self.project_root, "Makefile")):
            if shutil.which("make"):
                return "make"
            if shutil.which("mingw32-make"):
                return "mingw32-make"
            # Makefile exists but no make tool — try to parse it for gcc command
            gcc_cmd = self._parse_makefile_for_gcc()
            if gcc_cmd:
                return gcc_cmd

        # Check for CMakeLists.txt
        if os.path.exists(os.path.join(self.project_root, "CMakeLists.txt")):
            if shutil.which("cmake"):
                return "cmake --build ."

        # Fallback: build a gcc command directly if gcc exists
        if shutil.which("gcc"):
            return self._build_gcc_command()

        # No build tools available
        return None

    def _parse_makefile_for_gcc(self):
        """Try to extract the gcc compile command from a Makefile."""
        makefile = os.path.join(self.project_root, "Makefile")
        try:
            with open(makefile, 'r', encoding='utf-8') as f:
                content = f.read()

            # Look for SRC = ... line
            src_match = re.search(r'^SRC\s*=\s*(.+)$', content, re.MULTILINE)
            cflags_match = re.search(r'^CFLAGS\s*=\s*(.+)$', content, re.MULTILINE)

            if src_match and shutil.which("gcc"):
                sources = src_match.group(1).strip()
                cflags = cflags_match.group(1).strip() if cflags_match else ""
                return f"gcc {cflags} {sources} -o __sloki_test_build.exe"
        except Exception:
            pass
        return None

    def _build_gcc_command(self):
        """Build a gcc command from discovered .c files."""
        c_files = []
        for root, _, files in os.walk(self.project_root):
            for f in files:
                if f.endswith('.c'):
                    c_files.append(os.path.join(root, f))

        if c_files:
            include_dirs = set()
            for root, dirs, _ in os.walk(self.project_root):
                if 'include' in dirs:
                    include_dirs.add(os.path.join(root, 'include'))
            includes = " ".join(f'-I"{d}"' for d in include_dirs)
            files_str = " ".join(f'"{f}"' for f in c_files)
            return f"gcc {includes} {files_str} -o __sloki_test_build.exe -Wall"
        return None

    def validate(self):
        """
        Run the build command and return (success: bool, message: str).
        If no build command is available, performs a syntax-only check.
        """
        if not self.build_command:
            return self._syntax_check()

        try:
            result = subprocess.run(
                self.build_command,
                shell=True,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=30
            )

            # Clean up test build artifact
            test_exe = os.path.join(self.project_root, "__sloki_test_build.exe")
            if os.path.exists(test_exe):
                os.remove(test_exe)

            if result.returncode == 0:
                return True, "Compilation successful"
            else:
                errors = self._extract_errors(result.stderr)
                return False, f"Compilation failed:\n{errors}"

        except subprocess.TimeoutExpired:
            return False, "Compilation timed out (30s)"
        except FileNotFoundError:
            return self._syntax_check()
        except Exception as e:
            return False, f"Build error: {e}"

    def _syntax_check(self):
        """Fallback: basic syntax validation when no compiler is available."""
        if not self.project_root:
            return True, "No project root — skipping validation"

        issues = []
        for root, _, files in os.walk(self.project_root):
            for f in files:
                if f.endswith('.c') or f.endswith('.h'):
                    path = os.path.join(root, f)
                    try:
                        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                            content = fh.read()

                        # Check brace balance
                        opens = content.count('{')
                        closes = content.count('}')
                        if opens != closes:
                            issues.append(
                                f"{f}: Unbalanced braces ({{ {opens} vs }} {closes})"
                            )

                        # Check semicolon after statements (very basic)
                        lines = content.split('\n')
                        for i, line in enumerate(lines, 1):
                            stripped = line.strip()
                            if (stripped and
                                not stripped.startswith('//') and
                                not stripped.startswith('#') and
                                not stripped.startswith('/*') and
                                not stripped.endswith('{') and
                                not stripped.endswith('}') and
                                not stripped.endswith('\\') and
                                not stripped.endswith(';') and
                                not stripped.endswith(',') and
                                not stripped.endswith('*/') and
                                '(' in stripped and ')' in stripped and
                                '{' not in stripped):
                                # Possible missing semicolon
                                pass  # Too many false positives, skip for now

                    except Exception:
                        pass

        if issues:
            return False, "Syntax issues found:\n" + "\n".join(issues)
        return True, "Basic syntax check passed (no compiler found)"

    def _extract_errors(self, stderr):
        """Extract meaningful error lines from compiler output."""
        if not stderr:
            return "Unknown error"
        lines = stderr.strip().split('\n')
        errors = [l for l in lines if 'error' in l.lower() or 'warning' in l.lower()]
        return "\n".join(errors[:10]) if errors else stderr[:500]


class BaseValidator:
    """Base class for code and requirement validation."""
    def validate(self, content):
        return True, "Valid"


class RuleValidator(BaseValidator):
    """Validates content against project rules.json."""
    def __init__(self, rule_engine):
        self.rule_engine = rule_engine

    def validate(self, intent):
        action = intent.get("action")
        params = intent.get("params", {})

        if not self.rule_engine.is_action_allowed(action):
            return False, f"Action '{action}' is not allowed by rules."

        valid, msg = self.rule_engine.validate_params(params)
        if not valid:
            return False, msg

        return True, "Rules satisfied"
