"""
Context Engine — File-aware context retrieval for LLM prompts.
Replaces the placeholder VectorRetriever with real project-aware retrieval.

This is NOT a full vector-embedding RAG system. It uses surgical context
retrieval: reading editable blocks, scanning protected files for type info,
and building a structured context window for the LLM.
"""
import os
import re
from sloki_agent.code_editor.block_parser import BlockParser


class ContextEngine:
    """
    Builds structured context from the project for LLM prompts.
    Retrieves: editable blocks, type definitions, function signatures,
    and relevant file summaries.
    """

    def __init__(self, project_root, editable_files=None, protected_files=None):
        self.project_root = project_root
        self.editable_files = editable_files or []
        self.protected_files = protected_files or []
        self._cache = {}

    def get_context(self, query="", max_tokens=4000):
        """
        Build a context string for the LLM based on the current project state.
        Includes: editable blocks, type definitions, and file structure.
        """
        sections = []

        # 1. Editable blocks (primary context)
        editable_ctx = self._get_editable_context()
        if editable_ctx:
            sections.append(editable_ctx)

        # 2. Type definitions and function signatures from headers
        type_ctx = self._get_type_context()
        if type_ctx:
            sections.append(type_ctx)

        # 3. File structure overview
        structure_ctx = self._get_structure_context()
        if structure_ctx:
            sections.append(structure_ctx)

        context = "\n\n".join(sections)

        # Trim to approximate token budget (rough: 1 token ≈ 4 chars)
        max_chars = max_tokens * 4
        if len(context) > max_chars:
            context = context[:max_chars] + "\n... [context truncated]"

        return context

    def _get_editable_context(self):
        """Extract all editable blocks from target files."""
        blocks = []
        for filepath in self.editable_files:
            if not os.path.exists(filepath):
                continue

            parser = BlockParser(filepath)
            block_names = parser.list_blocks()
            rel_path = os.path.relpath(filepath, self.project_root)

            if block_names:
                for name in block_names:
                    content = parser.extract_block(name)
                    if content:
                        blocks.append(
                            f"### EDITABLE BLOCK: {name} ({rel_path})\n"
                            f"```c\n{content}\n```"
                        )
            else:
                # No blocks — include full file
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    blocks.append(
                        f"### EDITABLE FILE: {rel_path}\n"
                        f"```c\n{content}\n```"
                    )
                except Exception:
                    pass

        if blocks:
            return "## CURRENT EDITABLE CODE\n\n" + "\n\n".join(blocks)
        return ""

    def _get_type_context(self):
        """Extract type definitions, structs, and function prototypes from headers."""
        type_info = []

        for filepath in self.protected_files:
            if not os.path.exists(filepath):
                continue

            rel_path = os.path.relpath(filepath, self.project_root)
            if not filepath.endswith(('.h', '.hpp')):
                continue

            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                # Extract structs
                structs = re.findall(
                    r'(typedef\s+struct\s*\w*\s*\{[^}]*\}\s*\w+;)',
                    content, re.DOTALL
                )
                # Extract function prototypes
                protos = re.findall(
                    r'^[a-zA-Z_]\w*\s+\w+\s*\([^)]*\)\s*;',
                    content, re.MULTILINE
                )
                # Extract defines
                defines = re.findall(
                    r'^#define\s+\w+.*$',
                    content, re.MULTILINE
                )

                if structs or protos or defines:
                    section = f"### TYPES FROM: {rel_path}\n```c\n"
                    if structs:
                        section += "\n".join(structs) + "\n\n"
                    if protos:
                        section += "// Function prototypes\n"
                        section += "\n".join(protos) + "\n\n"
                    if defines:
                        section += "// Defines\n"
                        section += "\n".join(defines[:10]) + "\n"
                    section += "```"
                    type_info.append(section)

            except Exception:
                pass

        if type_info:
            return "## TYPE DEFINITIONS (read-only reference)\n\n" + "\n\n".join(type_info)
        return ""

    def _get_structure_context(self):
        """Build a file tree overview of the project."""
        if not self.project_root or not os.path.exists(self.project_root):
            return ""

        tree_lines = ["## PROJECT STRUCTURE\n```"]
        skip_dirs = {'.git', '__pycache__', 'brain', '.gemini', 'node_modules', '.venv', 'venv'}
        code_extensions = {'.c', '.h', '.cpp', '.hpp', '.py', '.js', '.ts', '.rs', '.go', '.java'}

        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            depth = root.replace(self.project_root, '').count(os.sep)
            if depth > 3:
                continue

            indent = '  ' * depth
            folder = os.path.basename(root)
            tree_lines.append(f"{indent}{folder}/")

            for f in sorted(files):
                ext = os.path.splitext(f)[1]
                if ext in code_extensions:
                    tree_lines.append(f"{indent}  {f}")

        tree_lines.append("```")
        return "\n".join(tree_lines)

    def get_relevant_context(self, query, max_tokens=2000):
        """
        Get context specifically relevant to a query.
        Uses keyword matching to prioritize relevant sections.
        """
        full_context = self.get_context(max_tokens=max_tokens * 2)

        # Simple keyword relevance scoring
        query_words = set(query.lower().split())
        sections = full_context.split('\n## ')

        scored = []
        for section in sections:
            score = sum(1 for word in query_words if word in section.lower())
            scored.append((score, section))

        scored.sort(key=lambda x: x[0], reverse=True)

        result = "\n## ".join(s for _, s in scored)
        max_chars = max_tokens * 4
        if len(result) > max_chars:
            result = result[:max_chars] + "\n... [truncated]"

        return result
