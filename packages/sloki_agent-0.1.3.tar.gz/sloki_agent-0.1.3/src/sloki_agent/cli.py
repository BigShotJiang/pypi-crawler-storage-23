import os
import sys
import re
import argparse
from dotenv import load_dotenv

# Load API keys from global .env
env_path = os.path.join(os.path.expanduser("~"), ".sloki", ".env")
load_dotenv(env_path)

# Force UTF-8 for Windows terminals
if sys.platform == "win32":
    os.system('chcp 65001 > nul')
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        sys.stdin.reconfigure(encoding='utf-8', errors='replace')
    else:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8', errors='replace')

from sloki_agent.core.agent_manager import AgentManager
from sloki_agent.core.utils.style import SlokiStyle


def setup_project():
    """First-time setup wizard for project configuration."""
    SlokiStyle.banner()

    brain_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "brain")
    if not os.path.exists(brain_dir):
        os.makedirs(brain_dir)

    rules_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rules", "rules.json")

    return rules_path


def main():
    """Main entry point with support for interactive and autonomous modes."""
    parser = argparse.ArgumentParser(
        description="Sloki Agent — Agentic RAG Code Editor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                          Interactive mode
  python main.py --auto --input req.md    Autonomous mode from .md file
  python main.py --auto --input req.md --provider gemini
        """
    )
    parser.add_argument(
        '--auto', action='store_true',
        help='Run autonomously without human approval prompts'
    )
    parser.add_argument(
        '--input', type=str, metavar='FILE',
        help='Path to requirements .md file (used with --auto)'
    )
    parser.add_argument(
        '--provider', type=str, choices=['lmstudio', 'gemini', 'openai', 'anthropic'],
        help='Override LLM provider'
    )
    args = parser.parse_args()

    if args.provider:
        os.environ["PREFERRED_PROVIDER"] = args.provider

    try:
        rules_path = setup_project()
        manager = AgentManager(rules_path, auto_mode=args.auto)
        
        # ── Trigger unified config wizard on first boot ──
        config_path = os.path.join(manager.brain_dir, "project_config.md")
        if not os.path.exists(config_path) or not manager.config.project_root:
            SlokiStyle.safe_print(
                f"\n{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Welcome to Sloki. Let's set up your workbench..."
            )
            # Default root if absolutely nothing is set
            if not manager.config.project_root:
                manager.config.project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            manager.cmd_handler._run_config_wizard(auto_mode=args.auto)
            if not args.auto:
                manager.cmd_handler._show_guide()

        # ── Autonomous / Headless Mode ──
        if args.auto:
            if not args.input:
                print(f"{SlokiStyle.RED}[Error] --auto requires --input <path.md>{SlokiStyle.RESET}")
                sys.exit(1)

            if not os.path.exists(args.input):
                print(f"{SlokiStyle.RED}[Error] File not found: {args.input}{SlokiStyle.RESET}")
                sys.exit(1)

            SlokiStyle.header("AUTONOMOUS EXECUTION")
            SlokiStyle.safe_print(f"{SlokiStyle.GOLD}[System]{SlokiStyle.RESET} Loading: {args.input}")

            with open(args.input, 'r', encoding='utf-8') as f:
                requirements = f.read()

            success, result = manager.run_command(requirements)
            status = "SUCCESS" if success else "FAILED"
            color = SlokiStyle.GREEN if success else SlokiStyle.RED
            SlokiStyle.safe_print(f"\n{color}[{status}] {result}{SlokiStyle.RESET}")
            sys.exit(0 if success else 1)

        # ── Interactive Mode ──
        SlokiStyle.header("SLOKI COMMAND INTERFACE")
        SlokiStyle.safe_print(
            f"{SlokiStyle.DIM}Type /help for commands or start typing your request.{SlokiStyle.RESET}"
        )

        while True:
            active_files = [os.path.basename(f) for f in manager.editable_files]
            display_name = active_files[0] if active_files else "No Target"
            if len(active_files) > 1:
                display_name += f" (+{len(active_files)-1})"

            agent_tag = (
                f"[{manager.active_agent_name.capitalize()}]"
                if manager.active_agent_name != "assistant" else ""
            )
            prompt_str = (
                f"{SlokiStyle.BOLD}{SlokiStyle.CYAN}"
                f"Sloki{agent_tag} @ {display_name} > {SlokiStyle.RESET}"
            )

            try:
                user_input = input(f"\n{prompt_str}").strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{SlokiStyle.GOLD}Goodbye!{SlokiStyle.RESET}")
                break

            if not user_input:
                continue

            success, result = manager.run_command(user_input)
            if result == "EXIT_SIGNAL":
                print(f"{SlokiStyle.GOLD}Goodbye!{SlokiStyle.RESET}")
                break

    except KeyboardInterrupt:
        print(f"\n{SlokiStyle.GOLD}Session Terminated.{SlokiStyle.RESET}")
    except Exception as e:
        SlokiStyle.safe_print(f"{SlokiStyle.RED}[FATAL ERROR] {e}{SlokiStyle.RESET}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
