import re

class WalkthroughAgent:
    def __init__(self, llm_client):
        self.llm_client = llm_client

    def generate_report(self, plan, final_code):
        prompt = f"""
        ### System:
        You are a Verification Agent. Compare the initial plan with the final implemented C code and generate a professional walkthrough.
        
        ### Initial Plan:
        {plan}
        
        ### Final Implementation:
        {final_code}
        
        ### Task:
        1. Provide reasoning inside <thought> tags.
        2. Generate a structured summary of changes, what was verified, and the final state.
        
        ### Rules:
        - Return ONLY professional MARKDOWN.
        - DO NOT use XML-style tags like <summary>, <report>, etc., in your final response.
        - Use bolding and lists for readability.
        """
        response, thought = self.llm_client.generate(prompt)
        # Final cleanup for any leaked tags
        clean_response = re.sub(r'</?(summary|report|walkthrough)>', '', response, flags=re.IGNORECASE).strip()
        return clean_response
