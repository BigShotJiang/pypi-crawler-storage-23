import os
from sloki_agent.core.utils.style import SlokiStyle

class PersonaAgent:
    def __init__(self, llm_client, persona_name):
        self.llm_client = llm_client
        self.persona_name = persona_name
        self.prompt_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts", "agents")
        os.makedirs(self.prompt_dir, exist_ok=True)

    def chat(self, user_input, context=""):
        prompt_path = os.path.join(self.prompt_dir, f"{self.persona_name}.txt")
        
        if not os.path.exists(prompt_path):
            SlokiStyle.safe_print(f"{SlokiStyle.RED}[Error] Prompt file for agent '{self.persona_name}' not found.{SlokiStyle.RESET}")
            return f"Error: Agent '{self.persona_name}' is missing its configuration file."

        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                system_instructions = f.read()
            
            # Construct dynamic prompt
            # We use a similar structure to the assistant but with the custom persona instructions
            full_prompt = f"### System: {self.persona_name} Persona\n\n{system_instructions}\n\n"
            full_prompt += f"CONTEXT:\n{context}\n\nUser: {user_input}"
            
            response, _ = self.llm_client.generate(full_prompt, stream_output=True)
            return response
        except Exception as e:
            return f"Error loading agent '{self.persona_name}': {str(e)}"
