"""
RuleGuard Agent — Validates intent against project rules before code generation.
Acts as a security gate that blocks unauthorized actions and protected file access.
"""


class RuleGuardAgent:
    """
    Validates user intent against the project's rule engine before
    any code generation occurs. Blocks protected file access and
    unauthorized actions.
    """

    def __init__(self, rule_engine):
        self.rule_engine = rule_engine

    def validate(self, intent):
        """
        Validate the intent against project rules.
        Returns (valid: bool, message: str).
        """
        action = intent.get("action")
        params = intent.get("params", {})

        # Check if the action (or its normalized form) is allowed
        if not self._is_action_allowed(action, intent):
            return False, f"Action '{action}' is not allowed by rules."

        # Validate target file isn't protected
        details = params.get("details", {})
        target_file = details.get("filename", "")
        if target_file and self.rule_engine.is_file_protected(target_file):
            return False, f"Target file '{target_file}' is protected."

        # Validate safety parameters (time_slice, etc.)
        valid, msg = self.rule_engine.validate_params(params)
        if not valid:
            return False, msg

        return True, "Rules satisfied"

    def _is_action_allowed(self, action, intent):
        """
        Check if an action is allowed, considering normalization.
        The pipeline normalizes domain actions (add_task → edit_code),
        so we check both the current action AND the original action.
        """
        # Direct check
        if self.rule_engine.is_action_allowed(action):
            return True

        # Check the original action before normalization
        original_action = intent.get("original_action")
        if original_action and self.rule_engine.is_action_allowed(original_action):
            return True

        # Check params for domain-specific action hints
        params = intent.get("params", {})
        edit_type = params.get("edit_type", "")
        if edit_type and self.rule_engine.is_action_allowed(edit_type):
            return True

        # Meta-actions that should always be allowed
        always_allowed = ["chat", "edit_rules"]
        if action in always_allowed:
            return True

        return False
