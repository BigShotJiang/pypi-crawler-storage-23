import json
import re

class IntentAgent:
    def __init__(self, llm_client):
        self.llm_client = llm_client

    def parse(self, user_input, current_code=""):
        prompt = f"""
        ### System:
        You are a Routing Agent for Sloki, a code editing assistant.
        Classify the user's intent based on their request.
        
        ### Current Code:
        {current_code}
        
        ### Request:
        "{user_input}"
        
        ### Task:
        Return ONLY a JSON object:
        {{
          "action": "chat" | "edit_code" | "edit_rules" | "create_file" | "delete_file" | "rename_file" | "git_action" | "build_project" | "run_tests" | "search_code" | "analyze_codebase",
          "params": {{
            "summary": "Brief description of the action",
            "edit_type": "add" | "modify" | "delete" | "refactor" | "create",
            "details": {{
              "filename": "Target file name if specified in the request or context (e.g. 'test.c')",
              "old_name": "Old filename for renames",
              "new_name": "New filename for renames",
              "git_command": "The specific git command (e.g. 'add', 'commit', 'remote')",
              "git_args": ["list", "of", "arguments"],
              "query": "Search query or pattern for search_code",
              "other_keys": "any other necessary details"
            }},
            "project_operations": ["Brief log of the change, e.g. 'Added OfficeTask'"],
            "preference": {{ "key": "value" }}
          }}
        }}
        
        Rules:
        - "chat": Conversation or question only.
        - "edit_code": Use for ANY code change request (add/delete/modify task, edit function, etc.).
        - "create_file": For entire new files.
        - "delete_file": For physical deletion of files from disk.
        - "rename_file": For renaming or moving files on disk.
        - "git_action": For ANY git operation (init, add, commit, branch, remote, etc.).
        - "build_project": For compiling or building the project.
        - "run_tests": For executing the project test suite.
        - "search_code": For searching patterns, strings, or definitions in the codebase.
        - "analyze_codebase": For performing a high-level architectural or security analysis.
        - "edit_rules": For rules.json changes.
        - "project_operations": Use this ONLY when an action is being performed. Write it in the past tense (e.g. "Modified min_time_slice", "Deleted video task").
        - "preference": Use for long-term user settings (e.g. "Always use 5s time").
        - **IMPORTANT**: DO NOT generate "style_notes" or speculative context. Stick to objective extraction.
        
        Examples:
        - "create a file at C:\\Users\\manth\\Desktop\\test.c" -> {{"action": "create_file", "params": {{"summary": "Create test.c", "details": {{"filename": "C:\\Users\\manth\\Desktop\\test.c"}}}}}}
        - "rename makefile to nofile" -> {{"action": "rename_file", "params": {{"summary": "Rename makefile to nofile", "details": {{"old_name": "makefile", "new_name": "nofile"}}}}}}
        - "git add src/main.c" -> {{"action": "git_action", "params": {{"summary": "Stage main.c", "details": {{"git_command": "add", "git_args": ["src/main.c"]}}}}}}
        - "create branch 'feature-x'" -> {{"action": "git_action", "params": {{"summary": "Create branch", "details": {{"git_command": "branch", "git_args": ["feature-x"]}}}}}}
        - "add remote origin https://github.com/user/repo" -> {{"action": "git_action", "params": {{"summary": "Add remote", "details": {{"git_command": "remote", "git_args": ["add", "origin", "https://github.com/user/repo"]}}}}}}
        - "commit changes with message 'Initial commit'" -> {{"action": "git_action", "params": {{"summary": "Commit changes", "details": {{"git_command": "commit", "git_args": ["-m", "Initial commit"]}}}}}}
        - "add office task with 5.0s time" -> {{"action": "edit_code", "params": {{"summary": "Add office task", "project_operations": ["Added OfficeTask (5.0s)"], "details": {{"task_name": "OfficeTask", "time": 5.0}}}}}}
        - "run the tests" -> {{"action": "run_tests", "params": {{"summary": "Running project tests", "project_operations": ["Triggered test suite"]}}}}
        - "build the project" -> {{"action": "build_project", "params": {{"summary": "Building project", "project_operations": ["Triggered project build"]}}}}
        - "search for TASK_SYSTEM in src/" -> {{"action": "search_code", "params": {{"summary": "Searching for TASK_SYSTEM", "details": {{"query": "TASK_SYSTEM"}}}}}}
        - "analyze the codebase structure" -> {{"action": "analyze_codebase", "params": {{"summary": "Analyzing project architecture"}}}}
        - "delete test.c" -> {{"action": "delete_file", "params": {{"summary": "Delete test.c", "project_operations": ["Deleted test.c"], "details": {{"filename": "test.c"}}}}}}
        - "Change min_time_slice to 0.5" -> {{"action": "edit_rules", "params": {{"summary": "Update min_time_slice", "project_operations": ["Modified min_time_slice to 0.5"]}}}}
        """
        response, thought = self.llm_client.generate(prompt)
        
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group(0))
                # Backward compatibility: map old action names
                action = parsed.get('action', 'chat')
                if action in ['add_task', 'remove_task', 'update_task']:
                    parsed['action'] = 'edit_code'
                    if action == 'add_task':
                        parsed.setdefault('params', {})['edit_type'] = 'add'
                    elif action == 'remove_task':
                        parsed.setdefault('params', {})['edit_type'] = 'delete'
                    elif action == 'update_task':
                        parsed.setdefault('params', {})['edit_type'] = 'modify'
                return parsed
            return {"action": "chat", "params": {"summary": response}}
        except Exception:
            return {"action": "chat", "params": {"summary": "I'm ready to help you with your code. What would you like to do?"}}
