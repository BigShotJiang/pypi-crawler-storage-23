import os

class AssistantAgent:
    def __init__(self, llm_client):
        self.llm_client = llm_client

    def chat(self, user_input, context=""):
        prompt_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts", "assistant.txt")
        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                prompt_template = f.read()
            prompt = prompt_template.format(context=context, user_input=user_input)
        except:
            prompt = f"### System: Assistant...\nUser: {user_input}"
        # We call generate with stream_output=True to allow the response to flow in real-time
        response, thought = self.llm_client.generate(prompt, stream_output=True)
        return response
