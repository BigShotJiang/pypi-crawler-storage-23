import re
import os

class EditAgent:
    # Map file extensions to language identifiers
    LANG_MAP = {
        '.c': 'c', '.h': 'c',
        '.py': 'python',
        '.js': 'javascript', '.ts': 'typescript',
        '.rs': 'rust', '.go': 'go',
        '.java': 'java', '.cpp': 'cpp', '.hpp': 'cpp',
    }

    def __init__(self, llm_client):
        self.llm_client = llm_client

    def _detect_language(self, filename):
        """Detect programming language from file extension."""
        ext = os.path.splitext(filename)[1].lower()
        return self.LANG_MAP.get(ext, 'code')

    def generate_edit(self, intent, current_block, context="", is_full_file=False, suggest_markers=False):
        action = intent.get('action')
        params = intent.get('params', {})
        target_file = intent.get('target_file', 'unknown')
        lang = self._detect_language(target_file)
        
        mode_hint = "full source file" if is_full_file else "specific code block"
        
        feedback_text = ""
        if 'feedback' in intent:
            feedback_text = f"### CORRECTION FROM PREVIOUS ATTEMPT:\n{intent['feedback']}"

        marker_rule = ""
        if suggest_markers:
            marker_rule = (
                "6. SMART SURGICAL EDIT: This file has no editable markers. You MUST identify the section "
                "relevant to this change and wrap it with `// === EDITABLE_START: <name> ===` and "
                "`// === EDITABLE_END: <name> ===`. Choose a short, descriptive name for the block."
            )

        if not current_block.strip():
            # Special case for creating entirely new files
            mode_hint = "new file"
            current_sec = "### Current Code:\n(New File - Empty)\n"
            rules_sec = (
                "1. This is a NEW FILE. Write the complete initial implementation based on the request.\n"
                "2. Include necessary imports/headers appropriate for the language.\n"
                "3. Provide a meaningful initial structure even if the request is vague.\n"
                "4. Return the COMPLETE new file content."
            )
        else:
            current_sec = f"### Current {mode_hint.capitalize()}:\n```{lang}\n{current_block}\n```\n"
            rules_sec = (
                "1. PRESERVE ALL EXISTING CODE: Copy every existing line first. Then make ONLY the requested change.\n"
                "2. DO NOT delete or remove any existing code unless the user explicitly asks for deletion.\n"
                "3. If adding new code, place it in the correct location following the existing patterns.\n"
                "4. If modifying, change ONLY the specific values mentioned. Keep everything else identical.\n"
                f"5. Return the COMPLETE updated {mode_hint} — not just the changed lines.\n"
                f"{marker_rule}"
            )

        prompt = f"""### System:
You are an expert software developer. You must write the {mode_hint} precisely according to the user request.

{current_sec}
### User Request:
{params.get('summary', action)}
Details: {params.get('details', params)}
{feedback_text}

### CRITICAL RULES:
{rules_sec}

### Output:
Return the full updated code inside ```{lang} fences. Nothing else.
```{lang}
(complete source code here)
```"""

        response, thought = self.llm_client.generate(prompt)
        
        # 1. Strip thought tags
        code = re.sub(r'<thought>.*?</thought>', '', response, flags=re.DOTALL)
        
        # 2. Extract between markdown fences (any language)
        code_match = re.search(r'```\w*\n?(.*?)```', code, re.DOTALL | re.IGNORECASE)
        if code_match:
            code = code_match.group(1).strip()
        
        # 3. Strip conversational preamble lines
        lines = code.split('\n')
        code = '\n'.join([line for line in lines if not any(
            x in line.lower() for x in ["okay", "i understand", "the user", "here is", "here's the"]
        )])
        
        return code.strip()
