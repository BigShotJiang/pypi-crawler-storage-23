import os
import re

class PlanningAgent:
    def __init__(self, llm_client):
        self.llm_client = llm_client

    def create_plan(self, requirements_text):
        prompt = f"""
        ### System:
        You are a Senior Software Engineer planning code changes.
        
        ### Background:
        {requirements_text}
        
        ### Instructions:
        1. Analyze the user's request carefully.
        2. Create a clear plan describing what code changes are needed.
        3. List specific tasks as a checklist.
        4. If a new file needs to be created, include a task like "- [ ] Create new file: <filename>".
        5. NO CODE BLOCKS in the plan. Use plain English only.
        
        ### Output Format:
        [PLAN]
        (Describe what changes will be made and why)
        [TASKS]
        - [ ] First specific change
        - [ ] Second specific change
        
        ### Plan:
        """
        response, thought = self.llm_client.generate(prompt)
            
        return response
