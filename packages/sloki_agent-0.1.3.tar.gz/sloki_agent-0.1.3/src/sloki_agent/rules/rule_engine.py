import json
import os
import re

class RuleEngine:
    def __init__(self, rules_path):
        self.rules_path = rules_path
        self.rules = {}
        self._load_rules()

    def _load_rules(self):
        # 1. Try split files first
        rules_dir = os.path.dirname(self.rules_path)
        project_p = os.path.normpath(os.path.join(rules_dir, "project_rules.json"))
        agentic_p = os.path.normpath(os.path.join(rules_dir, "agentic_rules.json"))

        if os.path.exists(project_p) and os.path.exists(agentic_p):
            try:
                with open(project_p, 'r') as f:
                    self.rules.update(json.load(f))
                with open(agentic_p, 'r') as f:
                    self.rules.update(json.load(f))
                return
            except Exception:
                pass # Fallback to original path

        # 2. Existing markdown/json logic
        if not os.path.exists(self.rules_path):
            return

        if self.rules_path.endswith('.md'):
            self.rules = self.parse_markdown_rules(self.rules_path)
        else:
            with open(self.rules_path, 'r') as f:
                self.rules = json.load(f)

    def parse_markdown_rules(self, md_path):
        """Parse a Markdown file into a rules dictionary."""
        rules = {}
        try:
            if not os.path.exists(md_path):
                return rules

            with open(md_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            current_category = None
            for line in lines:
                line = line.strip()
                if not line: continue

                if line.startswith('##'):
                    cat_name = line.replace('##', '', 1).strip()
                    current_category = cat_name.lower().replace(' ', '_')
                    if current_category not in rules:
                        if "safety" in current_category or "config" in current_category:
                            rules[current_category] = {}
                        else:
                            rules[current_category] = []
                    continue

                if current_category:
                    if line.startswith('- ') or line.startswith('* '):
                        val = line[2:].strip()
                        if isinstance(rules[current_category], list):
                            rules[current_category].append(val)
                        elif isinstance(rules[current_category], dict) and ':' in val:
                            parts = val.split(':', 1)
                            k, v = parts[0], parts[1]
                            rules[current_category][k.strip()] = self._type_cast(v.strip())
            return rules
        except Exception:
            return {}

    def _type_cast(self, val):
        """Helper to cast strings to float/int if possible."""
        try:
            if '.' in val: return float(val)
            return int(val)
        except:
            return val

    def sync_from_markdown(self, md_path):
        """Reload rules from a Markdown file and save to JSON if applicable."""
        new_rules = self.parse_markdown_rules(md_path)
        if new_rules:
            self.rules = new_rules
            if not self.rules_path.endswith('.md'):
                self.save_rules()
            return True, "Rules synchronized from Markdown"
        return False, "Failed to parse Markdown rules"

    def is_file_protected(self, file_path):
        normalized_path = os.path.normpath(file_path)
        for protected in self.rules.get("protected_files", []):
            if normalized_path.endswith(os.path.normpath(protected)):
                return True
        return False

    def is_action_allowed(self, action):
        return action in self.rules.get("allowed_actions", [])

    def add_rule(self, category, value):
        """Add a rule to a list or dictionary category."""
        if category not in self.rules:
            # Default to list if unknown category
            self.rules[category] = []
        
        if isinstance(self.rules[category], list):
            if value not in self.rules[category]:
                self.rules[category].append(value)
                return True, f"Added '{value}' to {category}"
        
        elif isinstance(self.rules[category], dict):
            k, v = None, None
            if isinstance(value, dict):
                # Direct dict update
                self.rules[category].update(value)
                return True, f"Updated {category} with {len(value)} items"
            elif ':' in str(value):
                parts = str(value).split(':', 1)
                k, v = parts[0].strip(), self._type_cast(parts[1].strip())
            
            if k:
                self.rules[category][k] = v
                return True, f"Updated {category}.{k} to {v}"
        
        return False, f"Could not add to {category} (unsupported format for {type(self.rules[category]).__name__})"

    def delete_rule(self, category, value):
        if category in self.rules and isinstance(self.rules[category], list):
            if value in self.rules[category]:
                self.rules[category].remove(value)
                return True, f"Removed '{value}' from {category}"
        elif category in self.rules and isinstance(self.rules[category], dict):
            if value in self.rules[category]:
                del self.rules[category][value]
                return True, f"Removed '{value}' from {category}"
        
        return False, f"Rule '{value}' not found in {category}"

    def save_rules(self):
        try:
            rules_dir = os.path.dirname(self.rules_path)
            project_p = os.path.join(rules_dir, "project_rules.json")
            agentic_p = os.path.join(rules_dir, "agentic_rules.json")

            if os.path.exists(project_p) and os.path.exists(agentic_p):
                # Save split files
                project_data = {k: v for k, v in self.rules.items() if k != "allowed_actions"}
                agentic_data = {"allowed_actions": self.rules.get("allowed_actions", [])}

                with open(project_p, 'w', encoding='utf-8') as f:
                    json.dump(project_data, f, indent=2)
                with open(agentic_p, 'w', encoding='utf-8') as f:
                    json.dump(agentic_data, f, indent=2)
                return True

            # Legacy save
            with open(self.rules_path, 'w', encoding='utf-8') as f:
                json.dump(self.rules, f, indent=2)
            return True
        except Exception as e:
            return False, str(e)

    def validate_params(self, params):
        time_slice = params.get("time_slice")
        if time_slice is not None:
            min_slice = self.rules.get("safety_rules", {}).get("min_time_slice", 0)
            if float(time_slice) < min_slice:
                return False, f"Time slice {time_slice} is below minimum {min_slice}"
        return True, "Valid"
