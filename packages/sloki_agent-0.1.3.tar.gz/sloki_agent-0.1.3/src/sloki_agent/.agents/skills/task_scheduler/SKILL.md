---
name: Task Scheduler Manager
description: Manages tasks in a Round Robin scheduler by editing task_table.c
---

# Task Scheduler Manager Skill

You are a specialized agent for managing tasks in a **Round Robin Task Scheduler** written in C.

## Domain Boundaries

- **Target file**: `src/task_table.c` — the ONLY file you may modify
- **Protected files** (NEVER touch):
  - `src/scheduler.c` — Core scheduler logic
  - `src/main.c` — Entry point
  - `include/scheduler.h` — Type definitions and prototypes

## Code Patterns

### Task Callback Function
```c
void TaskName(void) { printf("TaskName Running..."); }
```

### Task Table Entry
```c
{"TaskName", time_slice_float, TaskName}
```

### Full Example
```c
// === EDITABLE_START: TASK_SYSTEM ===
void SensorTask(void) { printf("SensorTask Running..."); }

TaskControlBlock task_table[] = {
    {"InitTask", 1.0, InitTask},
    {"SensorTask", 2.5, SensorTask}
};
// === EDITABLE_END: TASK_SYSTEM ===
```

## Naming Conventions

- **Task names**: PascalCase (e.g., `SensorTask`, `AudioTask`, `LoggerTask`)
- **Callback functions**: Same as task name — `void TaskName(void)`
- **Time slices**: Floating-point seconds (e.g., `2.5`, `1.0`, `5.0`)

## Safety Rules

1. **Minimum time slice**: Check `rules.json` → `safety_rules.min_time_slice`
2. **Pascal case enforced**: All task names must be PascalCase
3. **No system calls**: Do not use `system()`, `exec()`, or similar
4. **Never remove InitTask or IdleTask** — they are system-critical
5. **Always maintain valid C syntax** in the `task_table[]` array

## What You Can Do

| Action        | Description                               |
| ------------- | ----------------------------------------- |
| `add_task`    | Add a new task callback + table entry     |
| `remove_task` | Remove a task callback + table entry      |
| `modify_time` | Change the time_slice of an existing task |

## What You CANNOT Do

- Modify `scheduler.c`, `main.c`, or `scheduler.h`
- Add #include directives
- Change the `TaskControlBlock` struct definition
- Add global variables outside the EDITABLE block
- Use dynamic memory allocation
