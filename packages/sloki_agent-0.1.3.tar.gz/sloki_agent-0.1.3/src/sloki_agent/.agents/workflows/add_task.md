---
description: Add a new task to the Round Robin scheduler task table
---

## Prerequisites
- Target file: `src/task_table.c` (must contain `// === EDITABLE ===` blocks)
- Protected files: `scheduler.c`, `main.c`, `scheduler.h` — DO NOT MODIFY

## Workflow Steps

1. **Parse Requirement**: Extract `task_name`, `callback_function`, and `time_slice` from the input
2. **Validate Task Name**: Must follow PascalCase convention (e.g., `SensorTask`, `AudioTask`)
3. **Validate Time Slice**: Must be >= `min_time_slice` from `rules.json`
4. **Check Uniqueness**: Verify `task_name` does not already exist in `task_table[]`
5. **Generate Callback**: Create function `void TaskName(void) { printf("TaskName Running..."); }`
6. **Add Table Entry**: Append `{"TaskName", time_slice, TaskName}` to the `task_table[]` array
7. **Compile & Verify**: Run `make` and check for compilation errors
8. **Generate Report**: Create a walkthrough summarizing the changes made

## Constraints
- ONLY modify code within `// === EDITABLE_START: TASK_SYSTEM ===` markers
- DO NOT modify `scheduler.c`, `main.c`, or `scheduler.h`
- ALL new task functions must match the existing pattern exactly
- The `task_table[]` array must remain syntactically valid C
