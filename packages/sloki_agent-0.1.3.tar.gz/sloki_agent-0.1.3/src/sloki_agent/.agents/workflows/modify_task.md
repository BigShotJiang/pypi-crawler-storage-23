---
description: Modify an existing task's properties in the Round Robin scheduler
---

## Prerequisites
- Target file: `src/task_table.c` (must contain `// === EDITABLE ===` blocks)
- Protected files: `scheduler.c`, `main.c`, `scheduler.h` — DO NOT MODIFY

## Workflow Steps

1. **Parse Requirement**: Extract `task_name` and properties to modify (e.g., `time_slice`, callback logic)
2. **Locate Task**: Find the task in both the callback function definition and the `task_table[]` array
3. **Validate Changes**: Ensure new `time_slice` >= `min_time_slice` from `rules.json`
4. **Apply Changes**: Modify ONLY the specified properties — preserve all other code
5. **Compile & Verify**: Run `make` and check for compilation errors
6. **Generate Report**: Create a walkthrough summarizing the modifications

## Constraints
- ONLY modify code within `// === EDITABLE_START: TASK_SYSTEM ===` markers
- DO NOT delete any existing tasks unless explicitly requested
- Preserve ALL unchanged code exactly as-is
- The `task_table[]` array must remain syntactically valid C
