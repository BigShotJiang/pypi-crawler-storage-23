---
description: Remove an existing task from the Round Robin scheduler task table
---

## Prerequisites
- Target file: `src/task_table.c` (must contain `// === EDITABLE ===` blocks)
- Protected files: `scheduler.c`, `main.c`, `scheduler.h` — DO NOT MODIFY

## Workflow Steps

1. **Parse Requirement**: Extract the `task_name` to remove
2. **Locate Task**: Find the task callback function AND its entry in `task_table[]`
3. **Validate**: Ensure the task exists. Do NOT remove `InitTask` or `IdleTask` (system-critical)
4. **Remove Callback**: Delete the `void TaskName(void) { ... }` function definition
5. **Remove Table Entry**: Delete the `{"TaskName", time_slice, TaskName}` line from `task_table[]`
6. **Fix Trailing Comma**: Ensure the last entry in `task_table[]` has no trailing comma
7. **Compile & Verify**: Run `make` and check for compilation errors
8. **Generate Report**: Create a walkthrough summarizing what was removed

## Constraints
- ONLY modify code within `// === EDITABLE_START: TASK_SYSTEM ===` markers
- DO NOT remove `InitTask` or `IdleTask` — they are system-critical
- DO NOT modify `scheduler.c`, `main.c`, or `scheduler.h`
- The `task_table[]` array must remain syntactically valid C after removal
