# Logger Domain Guardrails

## Protected Files

- sloki_agent/main.py

## Allowed Actions

- chat
- edit_code

## Safety Rules

- max_file_size: 50000
- allow_stdout_logging: true
