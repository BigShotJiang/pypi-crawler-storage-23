"""
Sloki Logger — Structured logging for the Sloki Agent system.
Replaces ad-hoc print() statements with a centralized logger.
Supports file logging, level filtering, and formatted output.
"""
import os
import logging
from datetime import datetime


class SlokiLogger:
    """
    Centralized logger for the Sloki Agent system.
    Writes to both console and file with structured formatting.
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, log_dir=None, level=logging.INFO):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True

        self.logger = logging.getLogger('sloki')
        self.logger.setLevel(logging.DEBUG)
        self.logger.handlers = []

        # Console handler (INFO and above)
        console = logging.StreamHandler()
        console.setLevel(level)
        console_fmt = logging.Formatter(
            '%(message)s'  # Clean output for console
        )
        console.setFormatter(console_fmt)
        self.logger.addHandler(console)

        # File handler (DEBUG and above)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(
                log_dir,
                f"sloki_{datetime.now().strftime('%Y%m%d')}.log"
            )
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.DEBUG)
            file_fmt = logging.Formatter(
                '%(asctime)s | %(levelname)-8s | %(module)-15s | %(message)s',
                datefmt='%H:%M:%S'
            )
            file_handler.setFormatter(file_fmt)
            self.logger.addHandler(file_handler)

    # ── Convenience methods ──

    def info(self, msg, *args):
        self.logger.info(msg, *args)

    def debug(self, msg, *args):
        self.logger.debug(msg, *args)

    def warning(self, msg, *args):
        self.logger.warning(msg, *args)

    def error(self, msg, *args):
        self.logger.error(msg, *args)

    def critical(self, msg, *args):
        self.logger.critical(msg, *args)

    # ── Agent-specific logging ──

    def agent_action(self, agent_name, action, details=""):
        """Log an agent performing an action."""
        self.logger.info(f"[{agent_name}] {action}" + (f" | {details}" if details else ""))

    def pipeline_phase(self, phase_name, status="started"):
        """Log pipeline phase transitions."""
        self.logger.info(f"[Pipeline] {phase_name} — {status}")

    def rule_check(self, action, allowed, reason=""):
        """Log a rule validation check."""
        status = "ALLOWED" if allowed else "BLOCKED"
        self.logger.info(
            f"[RuleGuard] {action} → {status}" + (f" | {reason}" if reason else "")
        )

    def validation_result(self, validator_name, passed, message=""):
        """Log a validation result."""
        status = "PASSED" if passed else "FAILED"
        self.logger.info(
            f"[Validation] {validator_name} → {status}" + (f" | {message}" if message else "")
        )

    def file_op(self, operation, filepath, details=""):
        """Log a file operation."""
        self.logger.debug(
            f"[File] {operation}: {os.path.basename(filepath)}" +
            (f" | {details}" if details else "")
        )


def get_logger(log_dir=None):
    """Get or create the singleton Sloki logger."""
    return SlokiLogger(log_dir=log_dir)
