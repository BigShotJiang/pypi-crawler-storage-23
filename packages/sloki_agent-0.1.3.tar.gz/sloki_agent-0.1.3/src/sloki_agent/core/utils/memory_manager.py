import os
import json
from datetime import datetime

class MemoryManager:
    def __init__(self, memory_path):
        self.memory_path = memory_path
        self._memory = {
            "chat_history": [],
            "preferences": {},
            "last_interaction": None,
            "style_notes": [],
            "project_operations": []  # Track specific actions like "Added task X"
        }
        self.load()

    def load(self):
        """Load memory from JSON file if it exists."""
        if os.path.exists(self.memory_path):
            try:
                with open(self.memory_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Merge data to handle schema updates
                    for key in self._memory:
                        if key in data:
                            self._memory[key] = data[key]
            except Exception as e:
                print(f"[WARN] Failed to load memory: {e}")

    def save(self):
        """Save current memory state to JSON."""
        try:
            with open(self.memory_path, 'w', encoding='utf-8') as f:
                json.dump(self._memory, f, indent=4)
        except Exception as e:
            print(f"[WARN] Failed to save memory: {e}")

    def add_chat(self, role, content):
        """Add a chat interaction to history (limit to last 15)."""
        timestamp = datetime.now().isoformat()
        self._memory["chat_history"].append({
            "role": role,
            "content": content,
            "timestamp": timestamp
        })
        # Keep last 15 for a better session context
        if len(self._memory["chat_history"]) > 15:
            self._memory["chat_history"] = self._memory["chat_history"][-15:]
        
        self._memory["last_interaction"] = timestamp
        self.save()

    def add_operation(self, operation):
        """Record a significant project operation (e.g. 'Modified scheduler.c')."""
        timestamp = datetime.now().isoformat()
        entry = f"{timestamp.split('T')[1][:5]} | {operation}"
        self._memory["project_operations"].append(entry)
        
        # Keep last 10 operations
        if len(self._memory["project_operations"]) > 10:
            self._memory["project_operations"] = self._memory["project_operations"][-10:]
        self.save()

    def set_preference(self, key, value):
        """Set a persistent user preference."""
        self._memory["preferences"][key] = value
        self.save()

    def add_style_note(self, note):
        """Add a persistent style/architectural note with deduplication."""
        from difflib import SequenceMatcher
        
        # Normalize note
        note = note.strip()
        if not note: return

        # Check for similarity with existing notes
        for existing in self._memory["style_notes"]:
            similarity = SequenceMatcher(None, note.lower(), existing.lower()).ratio()
            if similarity > 0.8: # Skip if >80% similar
                return

        self._memory["style_notes"].append(note)
        # Cap style notes to the last 15
        if len(self._memory["style_notes"]) > 15:
            self._memory["style_notes"] = self._memory["style_notes"][-15:]
        self.save()

    def get_context_summary(self):
        """Generate a summary string for LLM context injection."""
        summary = "### PERSISTENT SESSION CONTEXT\n"
        
        if self._memory["preferences"]:
            summary += "\nUser Preferences:\n"
            for k, v in self._memory["preferences"].items():
                summary += f"- {k}: {v}\n"
        
        if self._memory["style_notes"]:
            summary += "\nCoding Style & Architectural Notes:\n"
            for note in self._memory["style_notes"]:
                summary += f"- {note}\n"

        if self._memory["chat_history"]:
            summary += "\nRecent Conversation History:\n"
            for chat in self._memory["chat_history"][-2:]: # Show last 2 only
                role = "User" if chat["role"] == "user" else "AI"
                summary += f"[{role}]: {chat['content'][:100]}...\n"
        
        return summary

    def clear_history(self):
        """Wipe only the chat history while preserving preferences and style."""
        self._memory["chat_history"] = []
        self._memory["last_interaction"] = datetime.now().isoformat()
        self.save()

    def wipe_all(self):
        """Complete reset of all memory data."""
        self._memory = {
            "chat_history": [],
            "preferences": {},
            "last_interaction": None,
            "style_notes": []
        }
        if os.path.exists(self.memory_path):
            try:
                os.remove(self.memory_path)
            except Exception as e:
                print(f"[WARN] Failed to delete memory file: {e}")
        self.save()

    def get_memory_data(self):
        """Return the raw memory dictionary."""
        return self._memory

    def get_filtered_history(self, limit=5):
        """Return significant chat interactions, skipping short confirmations."""
        filtered = []
        skip_content = ["y", "n", "yes", "no", "continue", "ok", "confirm", "approve"]
        
        for chat in reversed(self._memory["chat_history"]):
            content = chat["content"].strip().lower()
            if content in skip_content or len(content) < 2:
                continue
            filtered.append(chat)
            if len(filtered) >= limit:
                break
        
        return list(reversed(filtered))
