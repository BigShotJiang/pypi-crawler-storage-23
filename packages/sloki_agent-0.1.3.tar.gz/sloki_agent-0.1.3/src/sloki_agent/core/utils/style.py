import sys
import shutil

class SlokiStyle:
    CYAN = "\033[36m"
    GOLD = "\033[33m"
    YELLOW = GOLD # Alias to prevent attribute errors
    GREEN = "\033[32m"
    RED = "\033[31m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    BOLD = "\033[1m"
    DIM = "\033[90m"
    RESET = "\033[0m"
    
    @staticmethod
    def get_width():
        # Get terminal width, fallback to 80 if detection fails
        width = shutil.get_terminal_size((80, 20)).columns
        return min(width, 120) # Cap at 120 for readability

    @staticmethod
    def header(text):
        width = SlokiStyle.get_width()
        SlokiStyle.safe_print(f"\n{SlokiStyle.CYAN}{'━' * width}{SlokiStyle.RESET}")
        SlokiStyle.safe_print(f"{SlokiStyle.BOLD}{SlokiStyle.CYAN}{text.center(width)}{SlokiStyle.RESET}")
        SlokiStyle.safe_print(f"{SlokiStyle.CYAN}{'━' * width}{SlokiStyle.RESET}")

    @staticmethod
    def banner():
        width = SlokiStyle.get_width()
        logo_lines = [
            "   ██████╗██╗      ██████╗ ██╗  ██╗██╗    █████╗  ██████╗ ███████╗███╗   ██╗████████╗",
            "  ██╔════╝██║     ██╔═══██╗██║ ██╔╝██║   ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝",
            "  ╚█████╗ ██║     ██║   ██║█████╔╝ ██║   ███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║   ",
            "   ╚═══██╗██║     ██║   ██║██╔═██╗ ██║   ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   ",
            "  ██████╔╝███████╗╚██████╔╝██║  ██╗██║   ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║   ",
            "  ╚═════╝ ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   "
        ]
        
        SlokiStyle.safe_print(f"\n{SlokiStyle.CYAN}{SlokiStyle.BOLD}")
        for line in logo_lines:
            SlokiStyle.safe_print(line.center(width))
        SlokiStyle.safe_print(f"{SlokiStyle.RESET}")
        
        subtitle = ">>> Professional Agentic RAG System <<<"
        print(f"{SlokiStyle.DIM}{subtitle.center(width)}{SlokiStyle.RESET}\n")

    @staticmethod
    def safe_print(text, end="\n", flush=False):
        try:
            sys.stdout.write(str(text) + end)
            if flush:
                sys.stdout.flush()
        except UnicodeEncodeError:
            encoding = sys.stdout.encoding or 'utf-8'
            safe_text = str(text).encode(encoding, errors='replace').decode(encoding)
            sys.stdout.write(safe_text + end)
            if flush:
                sys.stdout.flush()
        except Exception:
            # Absolute fallback
            try:
                print(str(text).encode('ascii', errors='replace').decode('ascii'), end=end, flush=flush)
            except:
                pass

    @staticmethod
    def label(key, value, color=CYAN):
        SlokiStyle.safe_print(f"{SlokiStyle.BOLD}{color}{key.ljust(15)}:{SlokiStyle.RESET} {value}")

    @staticmethod
    def grid(items, title=None):
        if title:
            SlokiStyle.header(title)
        for key, value in items.items():
            SlokiStyle.label(key, value)
        width = SlokiStyle.get_width()
        print(f"{SlokiStyle.CYAN}{'━' * width}{SlokiStyle.RESET}")
