import os
from .clients.lmstudio_client import LMStudioClient

class LLMClient:
    def __init__(self, api_key=None, lmstudio_url=None):
        # API Keys from env or direct input
        self.gemini_key = api_key or os.environ.get("GOOGLE_API_KEY")
        self.openai_key = os.environ.get("OPENAI_API_KEY")
        self.anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
        
        self.lmstudio_url = lmstudio_url or os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1")
        self.lmstudio = LMStudioClient(self.lmstudio_url)
        
        # Default model
        self.lmstudio_model = "qwen2.5-coder-7b-instruct"
        
        # Lazy Clients
        self._gemini = None
        self._openai = None
        self._anthropic = None

        self.preferred_provider = os.environ.get("PREFERRED_PROVIDER", "lmstudio").lower()
        self.preferred_model = os.environ.get("PREFERRED_MODEL", self.lmstudio_model if self.preferred_provider == "lmstudio" else None)

    @property
    def gemini(self):
        if not self._gemini and self.gemini_key:
            from .clients.gemini_client import GeminiClient
            self._gemini = GeminiClient(self.gemini_key)
        return self._gemini

    @property
    def openai(self):
        if not self._openai and self.openai_key:
            from .clients.openai_client import OpenAIClient
            self._openai = OpenAIClient(self.openai_key)
        return self._openai

    @property
    def anthropic(self):
        if not self._anthropic and self.anthropic_key:
            from .clients.anthropic_client import AnthropicClient
            self._anthropic = AnthropicClient(self.anthropic_key)
        return self._anthropic

    def list_lmstudio_models(self):
        return self.lmstudio.list_models()

    def generate(self, prompt, model=None, use_local=False, stream_output=False, **kwargs):
        provider = self.preferred_provider if not use_local else "lmstudio"
        target_model = model or self.preferred_model
        
        try:
            if provider == "openai" and self.openai:
                return self.openai.generate(prompt, target_model or os.environ.get("OPENAI_MODEL", "gpt-4o"), stream_output=stream_output, **kwargs)
            elif provider == "anthropic" and self.anthropic:
                return self.anthropic.generate(prompt, target_model or os.environ.get("ANTHROPIC_MODEL", "claude-3-5-sonnet-20240620"), stream_output=stream_output, **kwargs)
            elif provider == "gemini" and self.gemini:
                return self.gemini.generate(prompt, target_model or "gemini-2.0-flash", stream_output=stream_output, **kwargs)
            elif provider == "lmstudio":
                return self.lmstudio.generate(prompt, target_model or self.lmstudio_model, stream_output=stream_output, **kwargs)
        except Exception as e:
            print(f"[WARN] {provider} failed: {e}. Falling back to LM Studio.")

        return self.lmstudio.generate(prompt, model=target_model or self.lmstudio_model, stream_output=stream_output, **kwargs)
