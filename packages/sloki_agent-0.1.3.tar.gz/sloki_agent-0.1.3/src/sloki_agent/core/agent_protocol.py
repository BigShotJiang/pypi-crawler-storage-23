"""
Agent Protocol — Structured message types for Master ↔ Mini-Agent communication.
Defines request/result dataclasses for clean, serializable inter-agent messaging.
"""
import json
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, List


@dataclass
class AgentRequest:
    """A structured request from the MasterAgent to a MiniAgent."""
    domain: str                          # e.g. "task_scheduler"
    action: str                          # e.g. "add_task"
    requirement: str                     # Raw user input / requirement text
    constraints: Dict = field(default_factory=dict)  # rules_path, workflow, skills
    context: str = ""                    # Memory context, project context, etc.
    auto_mode: bool = False              # Skip human approval

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, data: str) -> "AgentRequest":
        return cls(**json.loads(data))

    @classmethod
    def from_dict(cls, d: dict) -> "AgentRequest":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class AgentResult:
    """A structured result from a MiniAgent back to the MasterAgent."""
    success: bool
    domain: str
    action: str = ""
    diff: str = ""                       # Generated code diff
    validation: str = ""                 # Compilation/syntax check result
    walkthrough: str = ""                # Summary report
    error: str = ""                      # Error message if failed
    files_modified: List[str] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, data: str) -> "AgentResult":
        return cls(**json.loads(data))

    @classmethod
    def from_dict(cls, d: dict) -> "AgentResult":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class DomainConfig:
    """Configuration for a single domain / mini-agent."""
    domain: str
    description: str = ""
    target_files: List[str] = field(default_factory=list)
    protected_files: List[str] = field(default_factory=list)
    editable_blocks: List[str] = field(default_factory=list)
    rules_path: str = ""
    workflows_dir: str = ""
    skills_dir: str = ""

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, data: str) -> "DomainConfig":
        return cls(**json.loads(data))

    @classmethod
    def from_dict(cls, d: dict) -> "DomainConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @classmethod
    def from_file(cls, path: str) -> "DomainConfig":
        with open(path, 'r', encoding='utf-8') as f:
            return cls.from_dict(json.load(f))
