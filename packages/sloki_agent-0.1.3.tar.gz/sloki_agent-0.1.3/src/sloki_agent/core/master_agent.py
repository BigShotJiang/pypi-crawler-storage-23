"""
MasterAgent — Central dispatcher that orchestrates multiple MiniAgents.
Routes user requests to the correct domain-specific agent.
"""
import os
import json
from .mini_agent import MiniAgent
from .agent_protocol import DomainConfig, AgentResult
from .utils.logger import get_logger
from sloki_agent.agents.intent_agent import IntentAgent


class MasterAgent:
    """
    Orchestrates multiple MiniAgents.
    Classifies intent to determine the correct domain, then dispatches the request.
    """

    def __init__(self, domains_dir, llm_client, rule_engine, memory_manager, brain_dir, project_root, auto_mode=False):
        self.domains_dir = domains_dir
        self.llm_client = llm_client
        self.rule_engine = rule_engine
        self.memory_manager = memory_manager
        self.brain_dir = brain_dir
        self.project_root = project_root
        self.auto_mode = auto_mode
        self.log = get_logger()
        
        self.intent_agent = IntentAgent(llm_client)
        self.mini_agents = {}
        
        self._load_mini_agents()

    def _load_mini_agents(self):
        """Scan the domains directory and initialize MiniAgents."""
        if not os.path.exists(self.domains_dir):
            self.log.warning(f"Domains directory not found: {self.domains_dir}")
            return

        for domain_name in os.listdir(self.domains_dir):
            domain_path = os.path.join(self.domains_dir, domain_name)
            if not os.path.isdir(domain_path):
                continue

            config_path = os.path.join(domain_path, "config.json")
            if not os.path.exists(config_path):
                continue

            try:
                config = DomainConfig.from_file(config_path)
                # Resolve relative paths in config to absolute paths
                self._resolve_config_paths(config, domain_path)
                
                agent = MiniAgent(
                    config=config,
                    llm_client=self.llm_client,
                    memory_manager=self.memory_manager,
                    brain_dir=self.brain_dir,
                    project_root=self.project_root,
                    auto_mode=self.auto_mode
                )
                self.mini_agents[config.domain] = agent
                self.log.info(f"Loaded MiniAgent for domain: {config.domain}")
            except Exception as e:
                self.log.error(f"Failed to load MiniAgent for {domain_name}: {e}")

    def _resolve_config_paths(self, config, domain_path):
        """Make paths in DomainConfig absolute relative to the domain directory."""
        if config.rules_path and not os.path.isabs(config.rules_path):
            config.rules_path = os.path.abspath(os.path.join(domain_path, config.rules_path))
        if config.workflows_dir and not os.path.isabs(config.workflows_dir):
            config.workflows_dir = os.path.abspath(os.path.join(domain_path, config.workflows_dir))
        if config.skills_dir and not os.path.isabs(config.skills_dir):
            config.skills_dir = os.path.abspath(os.path.join(domain_path, config.skills_dir))

    def _classify_specialist(self, user_input) -> str:
        """Use LLM to classify user input into a specialized task expert."""
        if not self.mini_agents:
            return "general"

        specialist_list = "\n".join([
            f"- {d}: Specialist for {agent.config.description}"
            for d, agent in self.mini_agents.items()
        ])

        prompt = f"""
CLASSIFY THE SPECIALIST needed for the following task.
AVAILABLE EXPERTS:
{specialist_list}
- general: Any request that doesn't fit the specific experts above.

USER REQUEST: "{user_input}"

Respond with ONLY the specialist name.
"""
        response, thought = self.llm_client.generate(prompt)
        response = response.strip().lower()
        
        for d in self.mini_agents.keys():
            if d in response:
                return d
        
        return "general"

    def _decompose_request(self, user_input) -> list:
        """Use LLM to split a complex request into sub-tasks for specific specialists."""
        if not self.mini_agents:
            return [{"domain": "general", "task": user_input}]

        specialists = "\n".join([f"- {d}: {a.config.description}" for d, a in self.mini_agents.items()])
        
        prompt = f"""
ROLE: You are the Sloki Master Orchestrator.
TASK: DECOMPOSE the user request into specialized sub-tasks.
STRATEGY: Assign each sub-task to the most relevant task specialist.

AVAILABLE EXPERTS:
{specialists}
- general: For tasks that don't fit any specialized expert above.

USER REQUEST: "{user_input}"

Return a JSON list (NOT markdown) of objects:
[
  {{"domain": "specialist_name", "task": "specific instruction", "reasoning": "why this expert?"}}
]
"""
        response, thought = self.llm_client.generate(prompt)
        from .config_manager import _extract_json_block
        tasks = _extract_json_block(response)
        
        if not tasks or not isinstance(tasks, list):
            domain = self._classify_specialist(user_input)
            return [{"domain": domain, "task": user_input}]
            
        return tasks

    def dispatch(self, user_input) -> AgentResult:
        """Route the user request to appropriate MiniAgent(s), supporting decomposition."""
        is_complex = any(x in user_input.lower() for x in [" and ", " then ", ". ", " also "])
        
        if not is_complex:
            domain = self._classify_specialist(user_input)
            return self._execute_subtask(domain, user_input)

        sub_tasks = self._decompose_request(user_input)
        self.log.info(f"Decomposed request into {len(sub_tasks)} sub-tasks")
        
        results = []
        for st in sub_tasks:
            domain = st.get("domain", "general")
            task_str = st.get("task", user_input)
            res = self._execute_subtask(domain, task_str)
            results.append(res)

        all_success = all(r.success for r in results)
        agg_walkthrough = "\n\n---\n\n".join([f"### Specialist: {r.domain}\n{r.walkthrough}" for r in results if r.walkthrough])
        agg_errors = "\n".join([f"[{r.domain}] {r.error}" for r in results if r.error])
        agg_files = []
        for r in results: agg_files.extend(r.files_modified)

        return AgentResult(
            success=all_success,
            domain="multi-agent",
            walkthrough=agg_walkthrough,
            error=agg_errors if not all_success else "",
            files_modified=list(set(agg_files))
        )

    def _execute_subtask(self, domain, task_str) -> AgentResult:
        """Internal helper to execute a single task string on a specialist agent."""
        if domain == "general" or domain not in self.mini_agents:
            self.log.info(f"Dispatching to default assistant")
            return AgentResult(
                success=False,
                domain="general",
                error="General assistant fallback."
            )

        self.log.info(f"Executing task on {domain} Specialist")
        return self.mini_agents[domain].execute(task_str)

    def configure_from_md(self, name, md_path):
        """Synthesize specialist configuration from a Markdown requirement file."""
        if name not in self.mini_agents:
            return False, f"Specialist '{name}' not found."
        
        if not os.path.exists(md_path):
            return False, f"Requirement file '{md_path}' not found."

        try:
            with open(md_path, 'r', encoding='utf-8') as f:
                md_content = f.read()
            return self._apply_ai_synthesis(name, md_content, os.path.basename(md_path))
        except Exception as e:
            return False, f"Configuration synthesis failed: {e}"

    def _apply_ai_synthesis(self, name, content, source_label):
        """Internal helper to run AI synthesis and update config.json."""
        try:
            # 1. Get file summaries for context
            project_root = os.path.dirname(self.domains_dir)
            file_summaries = []
            for root, dirs, files in os.walk(project_root):
                if ".git" in dirs: dirs.remove(".git")
                if "brain" in dirs: dirs.remove("brain")
                for f_name in files[:40]: # Context limit
                    rel = os.path.relpath(os.path.join(root, f_name), project_root)
                    file_summaries.append(rel)

            # 2. Load prompt
            prompt_path = os.path.join(os.path.dirname(__file__), "..", "prompts", "agent_config_synthesis.txt")
            if not os.path.exists(prompt_path):
                return False, "Synthesis prompt template missing."
            
            with open(prompt_path, 'r', encoding='utf-8') as f:
                prompt_template = f.read()
            
            prompt = prompt_template.format(
                md_content=content,
                files_json=json.dumps(file_summaries, indent=2)
            )

            # 3. Generate & Extract
            response, thought = self.llm_client.generate(prompt)
            from .config_manager import _extract_json_block
            data = _extract_json_block(response)
            if not data and thought:
                data = _extract_json_block(thought)

            if not data:
                return False, "AI failed to synthesize valid configuration."

            # 4. Update config.json
            domain_path = os.path.join(self.domains_dir, name)
            config_path = os.path.join(domain_path, "config.json")
            
            with open(config_path, 'r', encoding='utf-8') as f:
                current_config = json.load(f)
            
            # Prioritize AI-generated fields for a professional look
            current_config.update(data)
            current_config["domain"] = name # Secure the name
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(current_config, f, indent=4)

            # 5. SYNC GLOBAL RULES
            if self.rule_engine:
                added_something = False
                
                # Apply suggested actions
                actions = data.get("suggested_agentic_actions", [])
                for action in actions:
                    added, _ = self.rule_engine.add_rule("allowed_actions", action)
                    if added: added_something = True
                
                # Apply safety rules
                safety = data.get("suggested_safety_rules", {})
                if safety:
                    self.rule_engine.add_rule("safety_rules", safety)
                    added_something = True
                
                if added_something:
                    self.rule_engine.save_rules()
                    self.log.info(f"Synchronized global rules for specialist: {name}")

            # 6. Reload
            self._load_mini_agents()
            return True, f"Specialist '{name}' successfully configured from {source_label}."

        except Exception as e:
            return False, f"Synthesis failed: {e}"

    def create_specialist(self, name, description):
        """Create a new task-specialized MiniAgent and synthesize its config."""
        domain_path = os.path.join(self.domains_dir, name)
        if os.path.exists(domain_path):
            return False, f"Specialist '{name}' already exists."

        try:
            os.makedirs(domain_path, exist_ok=True)
            config = {
                "domain": name,
                "description": description,
                "target_files": [],
                "protected_files": [],
                "rules_path": "../../rules/rules.json",
                "workflows_dir": "workflows",
                "skills_dir": "skills"
            }
            with open(os.path.join(domain_path, "config.json"), 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)

            os.makedirs(os.path.join(domain_path, "workflows"), exist_ok=True)
            os.makedirs(os.path.join(domain_path, "skills"), exist_ok=True)

            self._load_mini_agents()  

            # AUTOMATIC SYNTHESIS from plain text description
            if description and len(description) > 10:
                self.log.info(f"Triggering automatic AI synthesis for {name}")
                success, msg = self._apply_ai_synthesis(name, description, "provided description")
                if success:
                    return True, f"Specialist '{name}' created and AI-configured."
                else:
                    return True, f"Specialist '{name}' created (AI-configuration failed: {msg})"

            return True, f"Specialist '{name}' created."
        except Exception as e:
            return False, f"Failed to create specialist: {e}"

    def delete_specialist(self, name):
        """Delete a task specialist and its configuration."""
        if name not in self.mini_agents:
            return False, f"Specialist '{name}' not found."

        domain_path = os.path.join(self.domains_dir, name)
        if os.path.exists(domain_path):
            try:
                import shutil
                shutil.rmtree(domain_path)
                self.mini_agents.pop(name)
                return True, f"Specialist '{name}' deleted."
            except Exception as e:
                return False, f"Failed to delete specialist: {e}"
        return False, "Specialist data missing from filesystem."
