"""
MiniAgent — Isolated execution unit for a specific domain.
Encapsulates its own rules, workflows, skills, and pipeline.
"""
import os
from .pipeline import Pipeline
from .agent_protocol import AgentRequest, AgentResult, DomainConfig
from sloki_agent.rules.rule_engine import RuleEngine
from .utils.logger import get_logger


class MiniAgent:
    """
    Isolated agent for a specific domain (e.g., task_scheduler).
    Manages its own lifecycle and executes requests within its domain boundaries.
    """

    def __init__(self, config: DomainConfig, llm_client, memory_manager, brain_dir, project_root, auto_mode=False):
        self.config = config
        self.domain = config.domain
        self.llm_client = llm_client
        self.memory_manager = memory_manager
        self.brain_dir = brain_dir
        self.project_root = project_root
        self.auto_mode = auto_mode
        self.log = get_logger()

        # ── Domain-Specific Services ──
        # Load rules for this domain
        if config.rules_path and os.path.exists(config.rules_path):
            self.rule_engine = RuleEngine(config.rules_path)
        else:
            # Fallback to shared rules or empty
            self.rule_engine = RuleEngine(os.path.join(os.path.dirname(os.path.dirname(__file__)), "rules", "rules.json"))

        # Create specialized CommandHandler for this MiniAgent
        from .command_handler import CommandHandler
        self.cmd_handler = CommandHandler(
            config_manager=None, # MiniAgent handles its own file targets
            llm_client=llm_client,
            rule_engine=self.rule_engine,
            memory_manager=memory_manager,
            brain_dir=brain_dir
        )
        self.cmd_handler.active_agent_name = self.domain
        self.cmd_handler.agent_registry[self.domain] = self.config.description

        # Create a specialized Pipeline for this MiniAgent
        # Note: We pass None to config_manager because MiniAgent uses its own DomainConfig
        self.pipeline = Pipeline(
            llm_client=llm_client,
            rule_engine=self.rule_engine,
            config_manager=self._create_mock_config_manager(),
            memory_manager=memory_manager,
            command_handler=self.cmd_handler,
            brain_dir=os.path.join(brain_dir, f"domain_{self.domain}"),
            auto_mode=auto_mode
        )
        os.makedirs(self.pipeline.brain_dir, exist_ok=True)

    def _create_mock_config_manager(self):
        """Create a mock ConfigManager that returns the MiniAgent's target files."""
        # SELF-HEALING SCOPE: If the domain is a file manager, allow broad access
        description = self.config.description.lower()
        is_file_specialist = any(kw in description for kw in [
            "manage files", "modify files", "create files", "file manager", "file specialist", 
            "file i/o", "file operations", "file system"
        ])
        
        target_files = self.config.target_files
        if is_file_specialist or not target_files:
            target_files = ["**/*"] # Allow broad file management

        class MockConfig:
            def __init__(self, dc, root, targets):
                self.project_root = root
                self.editable_files = targets
                self.protected_files = dc.protected_files
        return MockConfig(self.config, self.project_root, target_files)

    def execute(self, user_input) -> AgentResult:
        """Execute a request through the MiniAgent's pipeline."""
        self.log.agent_action(self.domain, "executing", user_input[:50] + "...")
        
        # Prepare the request
        # In a real system, we might wrap user_input in AgentRequest
        # For now, we reuse the existing Pipeline.execute logic
        success, message = self.pipeline.execute(user_input)
        
        # Construct the result
        result = AgentResult(
            success=success,
            domain=self.domain,
            walkthrough=message if success else "",
            error=message if not success else "",
            files_modified=self.config.target_files if success else []
        )
        
        return result
