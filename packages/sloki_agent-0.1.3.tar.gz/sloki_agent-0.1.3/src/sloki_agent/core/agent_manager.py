"""
Agent Manager — Thin coordinator that delegates to specialized modules.

Architecture:
    ConfigManager  → project discovery, config persistence
    CommandHandler → slash commands, agent personas
    Pipeline       → intent → rule guard → planning → editing → validation → walkthrough

This module was refactored from a 1164-line monolith into a clean coordinator.
"""
import os
from .llm_client import LLMClient
from .config_manager import ConfigManager
from .command_handler import CommandHandler
from .pipeline import Pipeline
from .master_agent import MasterAgent
from .utils.style import SlokiStyle
from .utils.memory_manager import MemoryManager
from sloki_agent.rules.rule_engine import RuleEngine


class AgentManager:
    """
    Central coordinator for the Sloki agentic system.
    Delegates all work to ConfigManager, CommandHandler, and Pipeline.
    """

    def __init__(self, rules_path, auto_mode=False):
        self.auto_mode = auto_mode

        # ── Core services ──
        self.llm_client = LLMClient()
        self.rule_engine = RuleEngine(rules_path)

        # ── Brain directory ──
        self.brain_dir = os.path.join(os.path.expanduser("~"), ".sloki", "brain")
        os.makedirs(self.brain_dir, exist_ok=True)

        # ── Memory ──
        memory_path = os.path.join(self.brain_dir, "session_memory.json")
        self.memory_manager = MemoryManager(memory_path)

        # ── Delegates ──
        self.config = ConfigManager(self.brain_dir, self.llm_client)
        self.cmd_handler = CommandHandler(
            config_manager=self.config,
            llm_client=self.llm_client,
            rule_engine=self.rule_engine,
            memory_manager=self.memory_manager,
            brain_dir=self.brain_dir,
        )
        self.pipeline = Pipeline(
            llm_client=self.llm_client,
            rule_engine=self.rule_engine,
            config_manager=self.config,
            memory_manager=self.memory_manager,
            command_handler=self.cmd_handler,
            brain_dir=self.brain_dir,
            auto_mode=self.auto_mode,
        )

        # ── Master Agent (Phase 3) ──
        domains_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".agents", "domains")
        self.master_agent = MasterAgent(
            domains_dir=domains_dir,
            llm_client=self.llm_client,
            rule_engine=self.rule_engine, # Pass rule engine
            memory_manager=self.memory_manager,
            brain_dir=self.brain_dir,
            project_root=self.config.project_root,
            auto_mode=self.auto_mode
        )
        self.cmd_handler.register_master_agent(self.master_agent)

    # ──────────────────────────────────────────────
    #  PUBLIC API
    # ──────────────────────────────────────────────

    @property
    def editable_files(self):
        return self.config.editable_files

    @property
    def active_agent_name(self):
        return self.cmd_handler.active_agent_name

    def run_command(self, user_input):
        """
        Main entry point for all user input.
        Routes to CommandHandler for slash commands, or Pipeline for natural language.
        """
        # Dynamically sync auto_mode down to all execution pipelines
        is_auto = self.auto_mode or getattr(self.config, 'auto_mode', False)
        self.pipeline.auto_mode = is_auto
        if self.master_agent:
            self.master_agent.auto_mode = is_auto
            for agent in self.master_agent.mini_agents.values():
                agent.auto_mode = is_auto
                agent.pipeline.auto_mode = is_auto

        handled, success, result = self.cmd_handler.try_handle(user_input, is_auto)
        if handled:
            return success, result

        # Slash commands should skip MasterAgent classification
        if user_input.strip().startswith('/'):
            return self.pipeline.execute(user_input)

        # Try Master Agent (Phase 3) dispatch
        if self.master_agent and self.master_agent.mini_agents:
            active = self.active_agent_name
            if active in self.master_agent.mini_agents:
                # Direct route to active domain agent
                agent_result = self.master_agent.mini_agents[active].execute(user_input)
            else:
                # Full classification / decomposition
                agent_result = self.master_agent.dispatch(user_input)

            if agent_result.success:
                return True, agent_result.walkthrough
            elif agent_result.domain != "general":
                # It tried a domain and failed
                return False, agent_result.error

        # Not a slash command or domain match → run through the default agentic pipeline
        return self.pipeline.execute(user_input)
