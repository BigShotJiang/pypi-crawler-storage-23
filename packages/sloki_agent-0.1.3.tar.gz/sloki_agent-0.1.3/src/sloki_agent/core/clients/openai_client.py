import openai
from .base_client import BaseLLMClient
from ..utils.style import SlokiStyle

class OpenAIClient(BaseLLMClient):
    def __init__(self, api_key):
        super().__init__()
        self.client = openai.OpenAI(api_key=api_key)

    def generate(self, prompt, model="gpt-4o", stream_output=False):
        print(f"[OpenAI] Generating with {model}...")
        response_stream = self.client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            stream=True
        )
        
        full_text = ""
        # We handle thinking header in _process_stream_token now
        for chunk in response_stream:
            token = chunk.choices[0].delta.content or ""
            full_text += token
            self._process_stream_token(token, full_text, stream_output=stream_output)
            
        return self._extract_thought(full_text)
