from .base_client import BaseLLMClient
from ..utils.style import SlokiStyle
import requests
import json

class LMStudioClient(BaseLLMClient):
    def __init__(self, base_url):
        super().__init__()
        self.base_url = base_url

    def get_active_model(self):
        try:
            # Prevent double /v1 if already in base_url
            base = self.base_url.rstrip('/')
            if base.endswith('/v1'):
                url = f"{base}/models"
            else:
                url = f"{base}/v1/models"
                
            response = requests.get(url, timeout=1)
            if response.status_code == 200:
                models = response.json().get("data", [])
                if models:
                    return models[0].get("id", "qwen2.5-coder-7b-instruct")
        except Exception:
            pass
        return "qwen2.5-coder-7b-instruct"

    def list_models(self):
        try:
            base = self.base_url.rstrip('/')
            if base.endswith('/v1'):
                url = f"{base}/models"
            else:
                url = f"{base}/v1/models"
            
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                data = response.json().get("data", [])
                return [m.get("id") for m in data if m.get("id")]
        except Exception:
            pass
        return []

    def generate(self, prompt, model="qwen2.5-coder-7b-instruct", stream_output=False, silent_reasoning=False):
        # Prevent double /v1 if already in base_url
        base = self.base_url.rstrip('/')
        if base.endswith('/v1'):
            url = f"{base}/chat/completions"
        else:
            url = f"{base}/v1/chat/completions"
            
        headers = {"Content-Type": "application/json"}
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.3,
            "stream": True # Always stream for process_token to work
        }

        try:
            response = requests.post(url, headers=headers, json=payload, stream=True, timeout=30)
            if response.status_code != 200:
                return f"[Error] LM Studio returned {response.status_code}", ""

            full_text = ""
            for line in response.iter_lines():
                if line:
                    decoded = line.decode('utf-8').replace('data: ', '')
                    if decoded == '[DONE]': break
                    try:
                        chunk = json.loads(decoded)
                        token = chunk['choices'][0]['delta'].get('content', '')
                        full_text += token
                        # Handle streaming UI via base class
                        self._process_stream_token(token, full_text, stream_output=stream_output, silent_reasoning=silent_reasoning)
                    except: continue
            
            # Clean extraction for return
            clean_text, thought = self._extract_thought(full_text)
            return clean_text, thought

        except Exception as e:
            return f"[ERROR] LM Studio stream failed: {e}", ""
