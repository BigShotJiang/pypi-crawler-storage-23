from google import genai
from .base_client import BaseLLMClient
from ..utils.style import SlokiStyle

class GeminiClient(BaseLLMClient):
    def __init__(self, api_key):
        super().__init__()
        self.client = genai.Client(api_key=api_key)

    def generate(self, prompt, model="gemini-2.0-flash", stream_output=False):
        m_name = model if model.startswith("models/") else f"models/{model}"
        response_stream = self.client.models.generate_content_stream(model=m_name, contents=prompt)
        
        full_text = ""
        for chunk in response_stream:
            text = chunk.text
            full_text += text
            self._process_stream_token(text, full_text, stream_output=stream_output)
            
        return self._extract_thought(full_text)
