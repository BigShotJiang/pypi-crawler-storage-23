import json
import requests
from .base_client import BaseLLMClient
from ..utils.style import SlokiStyle

class OllamaClient(BaseLLMClient):
    def __init__(self, url):
        super().__init__()
        self.url = url
        self._print_buffer = ""

    def generate(self, prompt, model="qwen3:4b"):
        print(f"[Ollama] Generating with {model}...")
        full_text = ""
        self._in_thought = False
        self._print_buffer = ""
        
        try:
            payload = {
                "model": model,
                "prompt": prompt,
                "stream": True,
                "options": {"temperature": 0.1}
            }
            response = requests.post(self.url, json=payload, stream=True, timeout=120)
            response.raise_for_status()

            print(f"{SlokiStyle.DIM}Sloki is thinking: {SlokiStyle.RESET}", end="", flush=True)
            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line)
                    token = chunk.get("response", "")
                    full_text += token
                    
                    # Custom Ollama tag handling for partial tokens
                    if not self._in_thought and any(tag in full_text.lower()[-20:] for tag in ["<thought>", "<think>"]):
                        self._in_thought = True
                        continue
                    
                    if self._in_thought:
                        if any(tag in full_text.lower()[-20:] for tag in ["</thought>", "</think>"]):
                            self._in_thought = False
                            print(SlokiStyle.RESET + "\n" + SlokiStyle.CYAN + "━" * 40 + SlokiStyle.RESET)
                            self._print_buffer = ""
                            continue
                            
                        combined = self._print_buffer + token
                        is_potential_tag = False
                        for tag in ["</thought>", "</think>"]:
                             if tag.startswith(combined.lower()):
                                 is_potential_tag = True
                                 break
                        
                        if is_potential_tag:
                            self._print_buffer = combined
                        else:
                            print(combined, end="", flush=True)
                            self._print_buffer = ""
                    
                    if chunk.get("done"):
                        break
            
            return self._extract_thought(full_text)

        except Exception as e:
            print(f"\n[ERROR] Ollama stream failed: {e}")
            return "", ""
