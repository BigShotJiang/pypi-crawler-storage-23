import anthropic
from .base_client import BaseLLMClient
from ..utils.style import SlokiStyle

class AnthropicClient(BaseLLMClient):
    def __init__(self, api_key):
        super().__init__()
        self.client = anthropic.Anthropic(api_key=api_key)

    def generate(self, prompt, model="claude-3-5-sonnet-20240620", stream_output=False):
        print(f"[Anthropic] Generating with {model}...")
        full_text = ""
        with self.client.messages.stream(
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}],
            model=model,
        ) as stream:
            for text in stream.text_stream:
                full_text += text
                self._process_stream_token(text, full_text, stream_output=stream_output)
                
        return self._extract_thought(full_text)
