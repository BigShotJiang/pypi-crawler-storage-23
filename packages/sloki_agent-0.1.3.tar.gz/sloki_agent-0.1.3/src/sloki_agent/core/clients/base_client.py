import re
from ..utils.style import SlokiStyle

class BaseLLMClient:
    def __init__(self):
        self._state = "SCANNING" # States: SCANNING, REASONING, RESPONDING
        self._sliding_buffer = ""
        self._token_count = 0

    def generate(self, prompt, model, stream_output=False, silent_reasoning=False):
        raise NotImplementedError("Subclasses must implement generate")

    def _process_stream_token(self, token, full_text, stream_output=False, silent_reasoning=False):
        self._token_count += 1
        self._sliding_buffer = (self._sliding_buffer + token)[-30:] # Small window
        low_buf = self._sliding_buffer.lower()

        # --- STATE: SCANNING ---
        if self._state == "SCANNING":
            if any(tag in low_buf for tag in ["<thought>", "<think>"]):
                self._state = "REASONING"
                if not silent_reasoning:
                    print(f"\n{SlokiStyle.GOLD}[ REASONING ]{SlokiStyle.RESET}")
                return True
            
            # SILENCE ALL PREAMBLE CHATTER until we see a tag
            if self._token_count > 150: # Increased threshold for complex models
                self._state = "RESPONDING"
                # Fall through to Respond state
            else:
                return True 

        # --- STATE: REASONING ---
        if self._state == "REASONING":
            # Detect end of reasoning: be VERY sensitive to closing tags
            if any(tag in low_buf for tag in ["</thought>", "</think>", "</ thought", "</ think"]):
                self._state = "RESPONDING"
                print(f" {SlokiStyle.DIM}✓{SlokiStyle.RESET}\n")
                return True
            
            # Buffer closing tags and fragments aggressively
            forbidden_start = ["<", "/", "<t", "</t", "</th"]
            if any(low_buf.endswith(fs) for fs in forbidden_start):
                return True

            # Stream reasoning in DIM
            print(f"{SlokiStyle.DIM}{token}{SlokiStyle.RESET}", end="", flush=True)
            return True

        # --- STATE: RESPONDING ---
        if self._state == "RESPONDING" and stream_output:
            # Final safety: skip tokens that look like the residue of a closing tag
            low_token = token.lower().strip()
            if low_token in ["<thought>", "<think>", "</thought>", "</think>", ">", "thought>", "think>"]: 
                return True
            
            # If we just entered RESPONDING, we check if the token is part of a tag fragment
            if len(self._sliding_buffer) < 5 and any(c in token for c in ["<", ">", "/"]):
                return True

            print(token, end="", flush=True)
            return True
                
        return False

    def _extract_thought(self, full_text):
        # Improved regex to handle unclosed tags or variations
        thought_match = re.search(r'<(think|thought)>(.*?)(?:</\1>|$)', full_text, re.DOTALL | re.IGNORECASE)
        thought = thought_match.group(2).strip() if thought_match else ""
        
        # Clean the text but also remove any trailing common artifact words if the tag was cut off
        clean_text = re.sub(r'<(think|thought)>.*?(?:</\1>|$)', '', full_text, flags=re.DOTALL | re.IGNORECASE).strip()
        
        # Final safety cleanup for common leakages and trailing punctuation/tags
        clean_text = re.sub(r'(?i)\b(thought|thinking)\b\s*$', '', clean_text).strip()
        clean_text = re.sub(r'</?(?:think|thought)>?\s*$', '', clean_text, flags=re.IGNORECASE).strip()
        
        return clean_text, thought
