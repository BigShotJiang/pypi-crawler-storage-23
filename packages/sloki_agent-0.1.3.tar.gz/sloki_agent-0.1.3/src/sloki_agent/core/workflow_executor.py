"""
Workflow Executor — Reads workflow .md files and drives the pipeline.
Provides structured, repeatable execution of defined workflows.
"""
import os
import re
import yaml
from sloki_agent.core.utils.style import SlokiStyle


class WorkflowExecutor:
    """
    Reads workflow definitions from .md files and provides structured
    execution guidance for the pipeline.
    """

    def __init__(self, workflows_dir):
        self.workflows_dir = workflows_dir
        self.workflows = {}
        self._load_workflows()

    def _load_workflows(self):
        """Scan workflows directory and load all .md workflow files."""
        if not os.path.exists(self.workflows_dir):
            return

        for filename in os.listdir(self.workflows_dir):
            if not filename.endswith('.md'):
                continue

            filepath = os.path.join(self.workflows_dir, filename)
            try:
                workflow = self._parse_workflow(filepath)
                if workflow:
                    name = os.path.splitext(filename)[0]
                    self.workflows[name] = workflow
            except Exception as e:
                SlokiStyle.safe_print(
                    f"{SlokiStyle.RED}[Workflow] Error loading {filename}: {e}{SlokiStyle.RESET}"
                )

    def _parse_workflow(self, filepath):
        """Parse a workflow .md file with YAML frontmatter + markdown body."""
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        # Extract YAML frontmatter
        metadata = {}
        body = content
        frontmatter_match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)', content, re.DOTALL)
        if frontmatter_match:
            try:
                metadata = yaml.safe_load(frontmatter_match.group(1)) or {}
            except Exception:
                metadata = {}
            body = frontmatter_match.group(2)

        # Extract steps (numbered list items)
        steps = []
        step_pattern = re.compile(r'^\d+\.\s+\*\*(.+?)\*\*[:\s]*(.*?)$', re.MULTILINE)
        for match in step_pattern.finditer(body):
            steps.append({
                'name': match.group(1).strip(),
                'description': match.group(2).strip()
            })

        # Extract constraints
        constraints = []
        constraint_section = re.search(r'## Constraints\s*\n(.*?)(?=\n## |\Z)', body, re.DOTALL)
        if constraint_section:
            for line in constraint_section.group(1).strip().split('\n'):
                line = line.strip()
                if line.startswith('-'):
                    constraints.append(line[1:].strip())

        return {
            'description': metadata.get('description', ''),
            'filepath': filepath,
            'steps': steps,
            'constraints': constraints,
            'raw_body': body
        }

    def list_workflows(self):
        """Return a dict of workflow_name: description."""
        return {
            name: wf['description']
            for name, wf in self.workflows.items()
        }

    def get_workflow(self, name):
        """Get a workflow definition by name."""
        return self.workflows.get(name)

    def match_workflow(self, user_input):
        """
        Match a user request to the most appropriate workflow.
        Returns (workflow_name, workflow) or (None, None).
        """
        input_lower = user_input.lower()

        # Keyword-based matching
        keyword_map = {
            'add_task': ['add', 'new', 'create'],
            'modify_task': ['modify', 'change', 'update', 'set'],
            'remove_task': ['remove', 'delete', 'drop'],
        }

        for wf_name, keywords in keyword_map.items():
            if wf_name in self.workflows:
                if any(kw in input_lower for kw in keywords):
                    # Verify it's about a task
                    if 'task' in input_lower:
                        return wf_name, self.workflows[wf_name]

        return None, None

    def build_prompt_context(self, workflow_name):
        """
        Build a structured context string from a workflow for injection
        into the LLM prompt. Includes steps and constraints.
        """
        wf = self.workflows.get(workflow_name)
        if not wf:
            return ""

        lines = [
            f"## ACTIVE WORKFLOW: {workflow_name}",
            f"**Description**: {wf['description']}",
            "",
            "### Steps to Follow:",
        ]

        for i, step in enumerate(wf['steps'], 1):
            lines.append(f"{i}. **{step['name']}**: {step['description']}")

        if wf['constraints']:
            lines.append("")
            lines.append("### Constraints (MUST obey):")
            for c in wf['constraints']:
                lines.append(f"- {c}")

        return "\n".join(lines)

    def validate_step(self, step_name, context):
        """
        Check if a workflow step's preconditions are met.
        Returns (valid: bool, message: str).
        """
        step_name_lower = step_name.lower()

        if 'validate task name' in step_name_lower:
            task_name = context.get('task_name', '')
            if task_name and not task_name[0].isupper():
                return False, f"Task name '{task_name}' must be PascalCase"
            return True, "Task name valid"

        if 'validate time slice' in step_name_lower:
            time_slice = context.get('time_slice', 0)
            min_time = context.get('min_time_slice', 0)
            if float(time_slice) < float(min_time):
                return False, f"Time slice {time_slice} below minimum {min_time}"
            return True, "Time slice valid"

        if 'check uniqueness' in step_name_lower:
            task_name = context.get('task_name', '')
            existing = context.get('existing_tasks', [])
            if task_name in existing:
                return False, f"Task '{task_name}' already exists"
            return True, "Task name is unique"

        return True, "Step validated"
