"""
Configuration Manager — Handles project discovery, config persistence, and file role management.
Extracted from the monolithic AgentManager to provide clean separation of concerns.
"""
import os
import re
import json
from .utils.style import SlokiStyle
from sloki_agent.code_editor.block_parser import BlockParser


class ConfigManager:
    """Manages project configuration: root path, editable/protected files, and provider settings."""

    def __init__(self, brain_dir, llm_client=None):
        self.brain_dir = brain_dir
        self.llm_client = llm_client
        self.project_root = ""
        self.editable_files = []      # List of absolute paths
        self.protected_files = []     # List of absolute paths
        self.block_parser = None
        self.auto_mode = False
        self._load_config()

    # ──────────────────────────────────────────────
    #  PERSISTENCE
    # ──────────────────────────────────────────────

    def _load_config(self):
        config_path = os.path.join(self.brain_dir, "project_config.md")
        if not os.path.exists(config_path):
            return

        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                content = f.read()

            root_match = re.search(r'\*\*Project Root\*\*: (.*)', content)
            if root_match:
                self.project_root = root_match.group(1).strip()

            edit_match = re.search(r'\*\*Editable Files\*\*: (.*)', content)
            if edit_match:
                files = [f.strip() for f in edit_match.group(1).split(',')]
                self.editable_files = [
                    os.path.join(self.project_root, f)
                    for f in files if f and f != "None"
                ]

            prot_match = re.search(r'\*\*Protected Files\*\*: (.*)', content)
            if prot_match:
                files = [f.strip() for f in prot_match.group(1).split(',')]
                self.protected_files = [
                    os.path.join(self.project_root, f)
                    for f in files if f and f != "None"
                ]

            auto_match = re.search(r'\*\*Autonomous Mode\*\*: (True|False)', content)
            if auto_match:
                self.auto_mode = (auto_match.group(1) == 'True')

            if self.editable_files:
                self.block_parser = BlockParser(self.editable_files[0])

        except Exception as e:
            SlokiStyle.safe_print(
                f"{SlokiStyle.RED}[Error] Failed to load config: {e}{SlokiStyle.RESET}"
            )

    def save_config(self):
        config_path = os.path.join(self.brain_dir, "project_config.md")
        editable_rel = [os.path.relpath(f, self.project_root) for f in self.editable_files]
        protected_rel = [os.path.relpath(f, self.project_root) for f in self.protected_files]

        provider = self.llm_client.preferred_provider if self.llm_client else "lmstudio"
        model = (self.llm_client.preferred_model or "qwen2.5-coder-7b-instruct") if self.llm_client else "qwen2.5-coder-7b-instruct"

        config_md = f"""# AI Project Configuration

- **Project Root**: {self.project_root}
- **Editable Files**: {", ".join(editable_rel) or "None"}
- **Protected Files**: {", ".join(protected_rel) or "None"}
- **Preferred Provider**: {provider}
- **Preferred Model**: {model}
- **Autonomous Mode**: {self.auto_mode}
"""
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(config_md)

    # ──────────────────────────────────────────────
    #  PROJECT ANALYSIS (AI-driven)
    # ──────────────────────────────────────────────

    def analyze_project(self, project_root):
        """Scan project directory and use LLM to classify files as editable/protected."""
        SlokiStyle.safe_print(
            f"{SlokiStyle.GOLD}[AI Discovery]{SlokiStyle.RESET} Scanning: "
            f"{SlokiStyle.DIM}{project_root}{SlokiStyle.RESET}"
        )

        file_summaries = {}
        extensions = (
            '.c', '.h', '.cpp', '.hpp', '.py', '.js', '.ts',
            '.rs', '.go', '.java', '.cs', '.sh', '.md'
        )
        skip_dirs = ['.git', '__pycache__', 'brain', '.gemini', 'rag_agent', '.agent', '.agents']

        for root, _, filenames in os.walk(project_root):
            for f in filenames:
                rel_path = os.path.relpath(os.path.join(root, f), project_root)
                if any(x in rel_path for x in skip_dirs):
                    continue

                if f.endswith(extensions):
                    try:
                        abs_path = os.path.join(root, f)
                        with open(abs_path, 'r', errors='ignore') as file_ref:
                            sample = file_ref.read(500)
                            file_summaries[rel_path] = f"Code Sample:\n{sample}..."
                    except Exception:
                        file_summaries[rel_path] = "Found folder/config"
                else:
                    file_summaries[rel_path] = "Non-code file"

        if not self.llm_client:
            return [], [], file_summaries

        prompt_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "prompts", "discovery.txt"
        )
        try:
            with open(prompt_path, 'r', encoding='utf-8') as f:
                prompt_template = f.read()
            prompt = prompt_template.format(files_json=json.dumps(file_summaries, indent=2))
        except Exception:
            prompt = f"### System: Analyze files...\n{json.dumps(file_summaries, indent=2)}"

        response, thought = self.llm_client.generate(prompt)

        # Removed redundant print of thought; BaseLLMClient already streams it.

        data = _extract_json_block(response)
        if not data and thought:
            # Fallback: Maybe JSON is trapped in thought due to unclosed tags
            data = _extract_json_block(thought)

        if data:
            editable = data.get("editable", [])
            protected = data.get("protected", [])
            return editable, protected, file_summaries

        # Diagnostic info for support
        SlokiStyle.safe_print(f"{SlokiStyle.RED}[Warn] AI Discovery failed to produce valid JSON suggestions.{SlokiStyle.RESET}")
        if response:
            SlokiStyle.safe_print(f"{SlokiStyle.DIM}Raw snippet: {response[:100]}...{SlokiStyle.RESET}")
        
        return [], [], file_summaries

    def apply_roles(self, editable_rel, protected_rel):
        """Apply editable/protected file roles from relative paths."""
        self.editable_files = [os.path.join(self.project_root, f) for f in editable_rel]
        self.protected_files = [os.path.join(self.project_root, f) for f in protected_rel]
        if self.editable_files:
            self.block_parser = BlockParser(self.editable_files[0])
        self.save_config()

    def clear(self):
        """Reset all file assignments."""
        self.editable_files = []
        self.protected_files = []
        self.block_parser = None


# ──────────────────────────────────────────────
#  MODULE-LEVEL UTILITIES
# ──────────────────────────────────────────────

def _extract_json_block(text):
    """Robustly extract a JSON object from LLM output text."""
    if not text:
        return None

    # Try to strip any thought tags if they wrap the JSON or are present
    # Using a non-greedy regex that just removes the tags but keeps content if no closing tag
    clean_text = re.sub(r'<(think|thought)>', '', text, flags=re.IGNORECASE)
    clean_text = re.sub(r'</(think|thought)>', '', clean_text, flags=re.IGNORECASE).strip()
    
    # 1. Try code-fenced JSON
    json_block_match = re.search(r'```json\s*(.*?)\s*```', clean_text, re.DOTALL | re.IGNORECASE)
    if not json_block_match:
        json_block_match = re.search(r'```\s*(\{.*?\})\s*```', clean_text, re.DOTALL)

    if json_block_match:
        try:
            return json.loads(json_block_match.group(1))
        except Exception:
            pass

    # 2. Iterative search for {} blocks
    # We find the first '{', find the last '}', and try to parse.
    # If it fails, we try to move the start forward until we find a valid start of the JSON we want.
    first_idx = clean_text.find('{')
    while first_idx != -1:
        last_idx = clean_text.rfind('}')
        while last_idx != -1 and last_idx > first_idx:
            candidate = clean_text[first_idx:last_idx + 1]
            try:
                # Basic check to avoid parsing small fragments like "{ files_json }"
                # Relaxed to support both project_config ("editable") and specialist synthesis ("domain"/"target")
                if any(k in candidate for k in ["editable", "protected", "domain", "target_files"]):
                    return json.loads(candidate)
            except Exception:
                pass
            last_idx = clean_text.rfind('}', 0, last_idx)
        first_idx = clean_text.find('{', first_idx + 1)
        
    return None
