import re
import os

class BlockParser:
    def __init__(self, file_path):
        self.file_path = file_path

    def list_blocks(self):
        """Discover all editable blocks in the file."""
        if not os.path.exists(self.file_path):
            return []
        with open(self.file_path, "r", encoding="utf-8") as f:
            content = f.read()
        return re.findall(r'// === EDITABLE_START: (\w+) ===', content)

    def extract_block(self, block_name):
        """Extract the content between EDITABLE_START and EDITABLE_END markers."""
        pattern = rf"// === EDITABLE_START: {block_name} ===(.*?)// === EDITABLE_END: {block_name} ==="
        if not os.path.exists(self.file_path):
            return ""
        with open(self.file_path, "r", encoding="utf-8") as f:
            content = f.read()
        match = re.search(pattern, content, re.DOTALL)
        return match.group(1).strip() if match else ""

    def replace_block(self, block_name, new_content):
        """Replace the content of an editable block."""
        pattern = rf"(// === EDITABLE_START: {block_name} ===).*?(// === EDITABLE_END: {block_name} ===)"
        replacement = rf"\1\n{new_content}\n\2"
        with open(self.file_path, "r", encoding="utf-8") as f:
            content = f.read()
        
        updated = re.sub(pattern, replacement, content, flags=re.DOTALL)
        with open(self.file_path, "w", encoding="utf-8") as f:
            f.write(updated)
        return True

    def has_blocks(self):
        """Check if the file has any editable blocks."""
        return len(self.list_blocks()) > 0
