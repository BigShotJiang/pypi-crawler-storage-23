"""Verification test for Phase 4: Orchestration & MD Rules."""
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.master_agent import MasterAgent
from rules.rule_engine import RuleEngine
from core.llm_client import LLMClient
from core.utils.memory_manager import MemoryManager

def test_md_rule_parsing():
    print("Testing RuleEngine Markdown parsing...")
    md_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".agents", "domains", "logger_manager", "rules.md")
    
    # Force creation of rules.md if it doesn't exist (it should from previous steps)
    if not os.path.exists(md_path):
        print(f"  [ERROR] rules.md not found at {md_path}")
        return False

    re = RuleEngine(md_path)
    print(f"  Parsed Rules: {re.rules}")
    
    assert "protected_files" in re.rules, "Missing protected_files"
    assert "sloki_agent/main.py" in re.rules["protected_files"], "main.py not protected"
    assert re.is_file_protected("sloki_agent/main.py"), "is_file_protected failed"
    assert re.is_action_allowed("edit_code"), "edit_code should be allowed"
    
    # Check safety rules (dict)
    assert "safety_rules" in re.rules, "Missing safety_rules"
    assert re.rules["safety_rules"]["max_file_size"] == 50000, "max_file_size incorrect"
    
    print("  MD Rule Parsing: OK")
    return True

def test_task_decomposition():
    print("Testing MasterAgent task decomposition...")
    llm = LLMClient()
    brain_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "brain")
    memory = MemoryManager(os.path.join(brain_dir, "session_memory_test.json"))
    domains_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".agents", "domains")
    
    master = MasterAgent(domains_dir, llm, memory, brain_dir, auto_mode=True)
    
    complex_request = "Add a video task with 5s time and then update the logger to support file output"
    print(f"  Decomposing: '{complex_request}'")
    
    tasks = master._decompose_request(complex_request)
    print(f"  Resulting tasks: {tasks}")
    
    assert len(tasks) >= 2, f"Should have at least 2 tasks, got {len(tasks)}"
    domains = [t["domain"] for t in tasks]
    assert "task_scheduler" in domains, "task_scheduler domain missed"
    assert "logger_manager" in domains, "logger_manager domain missed"
    
    print("  Task Decomposition: OK")
    return True

if __name__ == "__main__":
    tests = [
        test_md_rule_parsing,
        test_task_decomposition,
    ]
    
    passed = 0
    failed = 0
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)} tests")
    if failed == 0:
        print("PHASE 4 VERIFICATION TESTS PASSED")
    else:
        print("PHASE 4 TESTS FAILED")
        sys.exit(1)
