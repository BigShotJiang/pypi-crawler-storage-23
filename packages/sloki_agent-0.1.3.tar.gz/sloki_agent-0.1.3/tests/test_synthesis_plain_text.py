
import sys
import os
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_synthesis():
    print("Testing AI Synthesis from Plain Text Description...")
    
    rules_path = os.path.join("rules", "rules.json")
    mgr = AgentManager(rules_path)
    
    # 1. Cleanup if exists
    if os.path.exists(os.path.join(mgr.master_agent.domains_dir, "file_manager_test")):
        mgr.run_command("/agent delete file_manager_test")

    # 2. Simulate the user's file_manager creation
    name = "file_manager_test"
    purpose = "it manages files like delete, create, modify and also gets the required detail from specific section of the file. it has access to all the files except the protected pc files."
    
    print(f"  Testing: /agent create {name} {purpose}")
    # Note: mgr.run_command handles the full string
    success, res = mgr.run_command(f"/agent create {name} {purpose}")
    print(f"  Result: {res}")

    if name in mgr.master_agent.mini_agents:
        agent = mgr.master_agent.mini_agents[name]
        
        # Load the actual config.json to see if rules/skills were added
        config_path = os.path.join(mgr.master_agent.domains_dir, name, "config.json")
        with open(config_path, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        print("\n  Synthesized Config Check:")
        print(f"    Description: {config_data.get('description')}")
        print(f"    Target Files: {config_data.get('target_files')}")
        
        # We check for presence of synthesized fields (target_files should ideally be populated by AI)
        if config_data.get('target_files') != []:
             print("  ✓ Configuration synthesized successfully.")
        else:
             print("  ✗ FAILED: Configuration lists are empty. AI may not have run or returned default.")
    else:
        print(f"  ✗ FAILED: Specialist '{name}' was not created.")

if __name__ == "__main__":
    test_synthesis()
