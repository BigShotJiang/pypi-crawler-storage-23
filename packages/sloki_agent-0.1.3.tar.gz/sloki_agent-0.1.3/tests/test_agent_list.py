"""Verification test for /agent list integration."""
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_agent_list_integration():
    print("Testing /agent list integration...")
    rules_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "rules.json")
    
    # Initialize AgentManager (this will load domains)
    manager = AgentManager(rules_path, auto_mode=True)
    
    # Simulate /agent list command
    print("\nExecuting '/agent list' simulation:")
    print("="*30)
    # Redirect stdout to capture the output would be complex, 
    # but we can check the internal registry linkage.
    
    assert manager.cmd_handler.master_agent is not None, "MasterAgent not linked to CommandHandler"
    assert manager.master_agent.mini_agents, "No mini-agents loaded"
    
    print(f"  Linked MasterAgent: OK")
    print(f"  Loaded Domains: {list(manager.master_agent.mini_agents.keys())}")
    
    # Trigger the handler directly
    success, result = manager.run_command("/agent list")
    print(f"\nResult: {result}")
    
    print("\n  /agent list Integration: OK")
    return True

if __name__ == "__main__":
    try:
        if test_agent_list_integration():
            print("\nVERIFICATION PASSED")
        else:
            print("\nVERIFICATION FAILED")
            sys.exit(1)
    except Exception as e:
        print(f"\nCRASHED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
