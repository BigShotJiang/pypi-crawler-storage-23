"""Verification test for /rules command enhancements."""
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_rules_command_enhancements():
    print("Testing /rules command enhancements...")
    
    # Use a temporary rules file to avoid overwriting project rules
    original_rules = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "rules.json")
    temp_rules = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "test_rules_temp.json")
    
    import shutil
    shutil.copy2(original_rules, temp_rules)
    
    manager = AgentManager(temp_rules, auto_mode=True)
    
    try:
        # 1. Test Help Message (Invalid command triggers help)
        print("\nTriggering /rules help:")
        success, result = manager.run_command("/rules")
        print(f"Result Type: {type(result)}")
        print(f"Result Value: {repr(result)}")
        
        if "Rules usage help displayed" not in result:
            print(f"FAILED: Expected 'Rules usage help displayed' in {repr(result)}")
        
        assert "Rules usage help displayed" in result
        
        # 2. Test Sync Command
        print("\nTesting /rules sync:")
        test_dir = os.path.dirname(os.path.abspath(__file__))
        test_md = os.path.join(test_dir, "test_rules.md")
        print(f"  Target MD Path: {test_md}")
        
        with open(test_md, 'w', encoding='utf-8') as f:
            f.write("# Test Rules\n\n## Protected Files\n- include/test_sync.h\n\n## Safety Rules\n- min_time_slice: 10.5\n")
        
        if os.path.exists(test_md):
            print(f"  File created successfully. Size: {os.path.getsize(test_md)} bytes")
        else:
            print(f"  ERROR: File was NOT created at {test_md}")
        
        success, result = manager.run_command(f"/rules sync {test_md}")
        print(f"Result: {result}")
        assert "synchronized" in result.lower()
        
        # Verify in RuleEngine
        assert "include/test_sync.h" in manager.rule_engine.rules["protected_files"]
        assert manager.rule_engine.rules["safety_rules"]["min_time_slice"] == 10.5
        
    finally:
        if os.path.exists(temp_rules):
            os.remove(temp_rules)
        if os.path.exists(test_md):
            os.remove(test_md)

if __name__ == "__main__":
    try:
        test_rules_command_enhancements()
        print("\nVERIFICATION PASSED")
    except Exception as e:
        print(f"\nVERIFICATION FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
