
import sys
import os
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_simplified_agents():
    print("Testing Simplified Master/Mini-Agent Architecture...")
    
    rules_path = os.path.join("rules", "rules.json")
    mgr = AgentManager(rules_path)
    
    # 1. Test Master Protection
    print("  Testing: Blocked deletion of 'assistant'")
    success, res = mgr.run_command("/agent delete assistant")
    if "blocked" in str(res).lower() or "cannot" in str(res).lower():
        print("  ✓ Protected successfully.")
    else:
        print(f"  ✗ FAILED: Deletion not blocked: {res}")

    # 2. Test Unified Creation (Specialist)
    print("  Testing: '/agent create specialist_one Experts in file system'")
    # We simulate input by passing a description
    mgr.run_command("/agent create specialist_one Experts in file system")
    
    if "specialist_one" in mgr.master_agent.mini_agents:
        print("  ✓ Specialist 'specialist_one' created successfully.")
    else:
        print("  ✗ FAILED: Specialist not found.")

    # 3. Test Unified Deletion
    print("  Testing: '/agent delete specialist_one'")
    mgr.run_command("/agent delete specialist_one")
    if "specialist_one" not in mgr.master_agent.mini_agents:
        print("  ✓ Specialist deleted successfully.")
    else:
        print("  ✗ FAILED: Specialist still exists.")

    print("\nALL SIMPLIFIED ARCHITECTURE TESTS PASSED")

if __name__ == "__main__":
    test_simplified_agents()
