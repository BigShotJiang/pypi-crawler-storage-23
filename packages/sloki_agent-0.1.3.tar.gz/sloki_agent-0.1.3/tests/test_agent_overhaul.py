
import sys
import os
import json
import time

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_agent_overhaul():
    print("Testing Agent Creation Persistence & AI Configuration...")
    
    rules_path = os.path.join("rules", "rules.json")
    mgr = AgentManager(rules_path)
    
    # 1. Test Persona Persistence Fix
    print("  Testing: '/agent create file_expert_persona Expert in file systems'")
    mgr.run_command("/agent create file_expert_persona Expert in file systems")
    
    # Reload manager to simulate restart
    mgr2 = AgentManager(rules_path)
    if "file_expert_persona" in mgr2.cmd_handler.agent_registry:
        print("  ✓ Persona 'file_expert_persona' persisted across restarts.")
    else:
        print("  ✗ FAILED: Persona not persisted.")

    # 2. Test Domain Creation & MD Configuration
    print("  Testing: Creating domain 'file_expert_domain'...")
    mgr2.run_command("/agent create-domain file_expert_domain File system specialist")
    
    md_path = os.path.join("tests", "file_expert_reqs.md")
    print(f"  Testing: '/agent configure-md file_expert_domain {md_path}'")
    mgr2.run_command(f"/agent configure-md file_expert_domain {md_path}")
    
    # Verify config.json updates
    config_path = os.path.join(".agents", "domains", "file_expert_domain", "config.json")
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        print(f"  ✓ Domain configuration synthesized.")
        print(f"    - Description: {config.get('description')}")
        print(f"    - target_files: {config.get('target_files')}")
        
        if config.get("skills"):
            print("  ✓ Skills correctly extracted.")
        else:
            print("  ✗ FAILED: Skills missing from config.")
            
        if "file_expert_domain" in mgr2.master_agent.mini_agents:
            print("  ✓ MiniAgent reloaded with new configuration.")
    else:
        print("  ✗ FAILED: config.json not found.")

    # 3. Cleanup
    print("\nCleaning up...")
    mgr2.run_command("/agent delete file_expert_persona")
    mgr2.run_command("/agent delete-domain file_expert_domain")
    
    print("\nALL AGENT OVERHAUL TESTS PASSED")

if __name__ == "__main__":
    test_agent_overhaul()
