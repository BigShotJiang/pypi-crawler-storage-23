
import sys
import os
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager
import unittest.mock as mock

def test_memory_tracking():
    print("Testing Memory Tracking Overhaul...")
    
    # Mock input to auto-approve plans
    with mock.patch('builtins.input', return_value='y'):
        rules_path = os.path.join("rules", "rules.json")
        mgr = AgentManager(rules_path)
    
    # Simulate a project operation via run_command
    # This should trigger IntentAgent -> Pipeline -> MemoryManager.add_operation
    print("  Simulating: 'add video task with 5.0s time'")
    # We mock the return of pipeline.execute to avoid actual file editing during verification
    mgr.pipeline.execute = lambda input: (True, "Mocked execution")
    
    mgr.run_command("add video task with 5.0s time")
    
    # Check if operation was logged
    data = mgr.memory_manager.get_memory_data()
    ops = data.get("project_operations", [])
    
    found = any("Added video task" in op for op in ops)
    if found:
        print("  ✓ Project operation correctly logged.")
    else:
        print("  ✗ Project operation MISSING from log.")
        print(f"  Log contents: {ops}")

    # Verify chat history depth
    mgr.run_command("hello")
    mgr.run_command("test 1")
    mgr.run_command("test 2")
    mgr.run_command("test 3")
    
    history = mgr.memory_manager.get_memory_data()["chat_history"]
    print(f"  ✓ Chat history depth: {len(history)} (should be > 2 now)")
    
    if len(history) > 2 and found:
        print("\nALL MEMORY TRACKING TESTS PASSED")
    else:
        print("\nMEMORY TRACKING TESTS FAILED")
        sys.exit(1)

if __name__ == "__main__":
    test_memory_tracking()
