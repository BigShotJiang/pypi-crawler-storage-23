
import sys
import os
import unittest.mock as mock

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_command_routing():
    print("Testing Command Routing Logic...")
    
    rules_path = os.path.join("rules", "rules.json")
    mgr = AgentManager(rules_path)
    
    # Mock Master Agent dispatch to check if it's called
    mgr.master_agent.dispatch = mock.Mock()
    
    # Mock Pipeline execute to avoid real execution
    mgr.pipeline.execute = mock.Mock(return_value=(True, "Pipeline executed"))
    
    print("  Testing: '/load requirements.md'")
    mgr.run_command("/load requirements.md")
    
    # Verify MasterAgent was skipped
    if mgr.master_agent.dispatch.called:
        print("  ✗ FAILED: MasterAgent was called for a slash command.")
    else:
        print("  ✓ SUCCESS: MasterAgent was bypassed.")

    # Verify Pipeline was called
    if mgr.pipeline.execute.called:
        print("  ✓ SUCCESS: Pipeline.execute was called.")
    else:
        print("  ✗ FAILED: Pipeline.execute was not called.")

    # Verify regular text still goes to MasterAgent
    mgr.master_agent.dispatch = mock.Mock()
    mgr.master_agent.dispatch.return_value = mock.Mock(success=True, walkthrough="Agent walkthrough")
    
    print("  Testing: 'add a task'")
    mgr.run_command("add a task")
    
    if mgr.master_agent.dispatch.called:
        print("  ✓ SUCCESS: MasterAgent was called for natural language.")
    else:
        print("  ✗ FAILED: MasterAgent was skipped for natural language.")

    if mgr.master_agent.dispatch.called and mgr.pipeline.execute.called:
        print("\nALL ROUTING TESTS PASSED")

if __name__ == "__main__":
    test_command_routing()
