
import sys
import os
import shutil

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager

def test_domain_management():
    print("Testing Domain Management & Switching...")
    
    rules_path = os.path.join("rules", "rules.json")
    mgr = AgentManager(rules_path)
    
    # 1. Test Switching to existing mini-agent
    print("  Testing: '/agent switch task_scheduler'")
    mgr.run_command("/agent switch task_scheduler")
    if mgr.active_agent_name == "task_scheduler":
        print("  ✓ Switched to task_scheduler.")
    else:
        print(f"  ✗ FAILED: Active agent is {mgr.active_agent_name}")

    # 2. Test Create-Domain
    print("  Testing: '/agent create-domain temp_agent Temporary test agent'")
    mgr.run_command("/agent create-domain temp_agent Temporary test agent")
    
    domain_path = os.path.join(".agents", "domains", "temp_agent")
    if os.path.exists(os.path.join(domain_path, "config.json")):
        print("  ✓ Domain 'temp_agent' created on filesystem.")
    else:
        print("  ✗ FAILED: Domain folder or config missing.")
        
    if "temp_agent" in mgr.master_agent.mini_agents:
        print("  ✓ MiniAgent 'temp_agent' loaded into MasterAgent.")
    else:
        print("  ✗ FAILED: MiniAgent not loaded.")

    # 3. Test Switch to new domain
    print("  Testing: '/agent switch temp_agent'")
    mgr.run_command("/agent switch temp_agent")
    if mgr.active_agent_name == "temp_agent":
        print("  ✓ Switched to temp_agent.")
    else:
        print(f"  ✗ FAILED: Could not switch to new domain.")

    # 4. Test Delete-Domain
    print("  Testing: '/agent delete-domain temp_agent'")
    mgr.run_command("/agent delete-domain temp_agent")
    
    if not os.path.exists(domain_path):
        print("  ✓ Domain folder deleted.")
    else:
        print("  ✗ FAILED: Domain folder still exists.")
        
    if "temp_agent" not in mgr.master_agent.mini_agents:
        print("  ✓ MiniAgent removed from MasterAgent.")
    else:
        print("  ✗ FAILED: MiniAgent still in memory.")

    print("\nALL DOMAIN MANAGEMENT TESTS PASSED")

if __name__ == "__main__":
    test_domain_management()
