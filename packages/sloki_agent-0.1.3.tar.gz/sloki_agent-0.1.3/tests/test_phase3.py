"""Verification test for Phase 3: Master-Agent Architecture."""
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.agent_manager import AgentManager
from core.master_agent import MasterAgent
from core.mini_agent import MiniAgent
from core.agent_protocol import AgentRequest, AgentResult, DomainConfig

def test_master_agent_init():
    print("Testing MasterAgent initialization...")
    from core.llm_client import LLMClient
    from core.utils.memory_manager import MemoryManager
    
    llm = LLMClient()
    brain_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "brain")
    memory = MemoryManager(os.path.join(brain_dir, "session_memory_test.json"))
    domains_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".agents", "domains")
    
    master = MasterAgent(domains_dir, llm, memory, brain_dir, auto_mode=True)
    
    print(f"  Loaded domains: {list(master.mini_agents.keys())}")
    assert "task_scheduler" in master.mini_agents, "task_scheduler domain not loaded"
    print("  MasterAgent Init: OK")
    return True

def test_master_agent_dispatch():
    print("Testing MasterAgent dispatch classification...")
    from core.llm_client import LLMClient
    from core.utils.memory_manager import MemoryManager
    
    llm = LLMClient()
    brain_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "brain")
    memory = MemoryManager(os.path.join(brain_dir, "session_memory_test.json"))
    domains_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".agents", "domains")
    
    master = MasterAgent(domains_dir, llm, memory, brain_dir, auto_mode=True)
    
    # This should trigger _classify_domain
    # We mock the LLM check by just ensuring it doesn't crash on tuple return
    print("  Dispatching 'add video task'...")
    try:
        domain = master._classify_domain("add video task")
        print(f"  Classified as: {domain}")
        assert isinstance(domain, str), "Domain should be a string"
    except AttributeError as e:
        print(f"  CRASH DETECTED: {e}")
        raise e
    
    print("  MasterAgent Dispatch: OK")
    return True

def test_agent_manager_integration():
    print("Testing AgentManager with MasterAgent integration...")
    rules_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rules", "rules.json")
    manager = AgentManager(rules_path, auto_mode=True)
    
    assert hasattr(manager, "master_agent"), "AgentManager missing master_agent"
    assert "task_scheduler" in manager.master_agent.mini_agents, "task_scheduler missing from AgentManager.master_agent"
    
    print("  AgentManager Integration: OK")
    return True

if __name__ == "__main__":
    tests = [
        test_master_agent_init,
        test_master_agent_dispatch,
        test_agent_manager_integration,
    ]
    
    passed = 0
    failed = 0
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)} tests")
    if failed == 0:
        print("PHASE 3 VERIFICATION TESTS PASSED")
    else:
        print("PHASE 3 TESTS FAILED")
        sys.exit(1)
