"""Verification test for the refactored Sloki Agent system."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_all_imports():
    print("Testing module imports...")
    from core.agent_manager import AgentManager
    from core.config_manager import ConfigManager, _extract_json_block
    from core.command_handler import CommandHandler
    from core.pipeline import Pipeline
    from core.llm_client import LLMClient
    from agents.intent_agent import IntentAgent
    from agents.edit_agent import EditAgent
    from agents.planning_agent import PlanningAgent
    from agents.walkthrough_agent import WalkthroughAgent
    from agents.assistant_agent import AssistantAgent
    from agents.persona_agent import PersonaAgent
    from agents.rule_guard_agent import RuleGuardAgent
    from rules.rule_engine import RuleEngine
    from code_editor.block_parser import BlockParser
    from validators.code_validator import CompilationValidator, RuleValidator
    print("  All 15 module imports: OK")
    return True

def test_json_extraction():
    print("Testing JSON extraction...")
    from core.config_manager import _extract_json_block
    result = _extract_json_block('{"test": true}')
    assert result == {'test': True}, f'Failed: {result}'
    result2 = _extract_json_block('```json\n{"key": "val"}\n```')
    assert result2 == {'key': 'val'}, f'Failed: {result2}'
    print("  JSON extraction: OK")
    return True

def test_block_parser():
    print("Testing BlockParser...")
    from code_editor.block_parser import BlockParser
    task_file = os.path.join(os.path.dirname(__file__), '..', 'c_project', 'src', 'task_table.c')
    bp = BlockParser(task_file)
    blocks = bp.list_blocks()
    assert 'TASK_SYSTEM' in blocks, f'TASK_SYSTEM not found, got: {blocks}'
    content = bp.extract_block('TASK_SYSTEM')
    assert 'InitTask' in content, 'InitTask not found in block'
    print(f"  BlockParser found blocks: {blocks}")
    print("  BlockParser: OK")
    return True

def test_rule_engine():
    print("Testing RuleEngine...")
    from rules.rule_engine import RuleEngine
    rules_path = os.path.join(os.path.dirname(__file__), 'rules', 'rules.json')
    re = RuleEngine(rules_path)
    assert re.is_file_protected('src\\main.c'), 'main.c should be protected'
    assert re.is_action_allowed('add_task'), 'add_task should be allowed'
    print("  RuleEngine: OK")
    return True

def test_rule_guard():
    print("Testing RuleGuardAgent...")
    from rules.rule_engine import RuleEngine
    from agents.rule_guard_agent import RuleGuardAgent
    rules_path = os.path.join(os.path.dirname(__file__), 'rules', 'rules.json')
    re = RuleEngine(rules_path)
    rg = RuleGuardAgent(re)
    valid, msg = rg.validate({'action': 'add_task', 'params': {}})
    print(f"  RuleGuard: valid={valid}, msg={msg}")
    print("  RuleGuardAgent: OK")
    return True

def test_compilation_validator():
    print("Testing CompilationValidator...")
    from validators.code_validator import CompilationValidator
    proj = os.path.join(os.path.dirname(__file__), '..', 'c_project')
    v = CompilationValidator(proj)
    print(f"  Build command auto-detected: {v.build_command}")
    print("  CompilationValidator: OK")
    return True

def test_agent_manager_init():
    print("Testing AgentManager initialization...")
    from core.agent_manager import AgentManager
    rules_path = os.path.join(os.path.dirname(__file__), 'rules', 'rules.json')
    manager = AgentManager(rules_path, auto_mode=True)
    assert hasattr(manager, 'config'), 'Missing config'
    assert hasattr(manager, 'cmd_handler'), 'Missing cmd_handler'
    assert hasattr(manager, 'pipeline'), 'Missing pipeline'
    assert manager.auto_mode == True, 'auto_mode not set'
    print(f"  Editable files: {manager.editable_files}")
    print(f"  Active agent: {manager.active_agent_name}")
    print("  AgentManager: OK")
    return True

if __name__ == "__main__":
    tests = [
        test_all_imports,
        test_json_extraction,
        test_block_parser,
        test_rule_engine,
        test_rule_guard,
        test_compilation_validator,
        test_agent_manager_init,
    ]
    
    passed = 0
    failed = 0
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)} tests")
    if failed == 0:
        print("ALL VERIFICATION TESTS PASSED")
    else:
        print("SOME TESTS FAILED")
        sys.exit(1)
