"""Tests for convenience functions and additional coverage"""

import pytest
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport

from rcommerz_logger import (
    initialize,
    get_instance,
    create_fastapi_middleware,
    LoggerConfig,
    Logger,
)


class TestConvenienceFunctions:
    """Test package-level convenience functions"""

    def test_initialize_convenience_function(self):
        """Should initialize logger using convenience function"""
        config = LoggerConfig(
            service_name="test-convenience",
            service_version="1.0.0",
            env="test",
            level="info",
        )

        logger = initialize(config)
        assert logger is not None
        assert isinstance(logger, Logger)

    def test_get_instance_convenience_function(self):
        """Should get logger instance using convenience function"""
        # First initialize
        config = LoggerConfig(
            service_name="test-get", service_version="1.0.0", env="test"
        )
        initialize(config)

        # Then get instance
        logger = get_instance()
        assert logger is not None
        assert isinstance(logger, Logger)


class TestMiddlewareConvenience:
    """Test create_fastapi_middleware convenience function"""

    @pytest.mark.asyncio
    async def test_create_fastapi_middleware_function(self, capsys):
        """Should add middleware using convenience function"""
        app = FastAPI()

        # Initialize logger
        Logger.initialize(
            LoggerConfig(
                service_name="test-middleware-convenience",
                service_version="1.0.0",
                env="test",
            )
        )

        # Use convenience function to add middleware
        create_fastapi_middleware(
            app, exclude_paths=["/health"], include_headers=False, include_body=False
        )

        @app.get("/test")
        async def test_endpoint():
            return {"status": "ok"}

        @app.get("/health")
        async def health_endpoint():
            return {"status": "healthy"}

        # Test that middleware is working
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/test")
            assert response.status_code == 200

            # Test excluded path
            response2 = await client.get("/health")
            assert response2.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Should log /test but not /health
        assert "/test" in output
        assert "/health" not in output

    @pytest.mark.asyncio
    async def test_create_fastapi_middleware_with_all_options(self, capsys):
        """Should handle all middleware options"""
        app = FastAPI()

        Logger.initialize(
            LoggerConfig(
                service_name="test-all-options", service_version="1.0.0", env="test"
            )
        )

        # Use all options
        create_fastapi_middleware(
            app,
            exclude_paths=["/metrics", "/health"],
            include_headers=True,
            include_body=True,
        )

        @app.get("/api/data")
        async def data_endpoint():
            return {"data": "test"}

        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/api/data", headers={"X-Custom": "header"})
            assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Verify middleware logged the request
        assert "/api/data" in output


class TestTraceContext:
    """Test trace context extraction coverage"""

    def test_trace_context_without_otel(self, capsys):
        """Should handle logging without active OpenTelemetry span"""
        Logger.initialize(
            LoggerConfig(
                service_name="test-no-trace", service_version="1.0.0", env="test"
            )
        )

        logger = Logger.get_instance()

        # Log without active span - this covers the empty return path
        logger.info("Test message without trace", {"key": "value"})

        captured = capsys.readouterr()
        output = captured.out

        assert "Test message without trace" in output
        assert "key" in output


class TestErrorHandlingCoverage:
    """Additional tests for error handling paths"""

    def test_logger_with_minimal_config(self, capsys):
        """Should work with minimal configuration"""
        config = LoggerConfig(
            service_name="minimal-test", service_version="1.0.0", env="test"
        )

        logger = Logger.initialize(config)
        logger.info("Minimal config test")

        captured = capsys.readouterr()
        output = captured.out

        assert "Minimal config test" in output
        assert "minimal-test" in output

    def test_logger_preserves_config(self):
        """Should preserve configuration after initialization"""
        config = LoggerConfig(
            service_name="preserve-test",
            service_version="2.0.0",
            env="staging",
            level="debug",
        )

        logger = Logger.initialize(config)
        stored_config = logger.config

        assert stored_config.service_name == "preserve-test"
        assert stored_config.service_version == "2.0.0"
        assert stored_config.env == "staging"
        assert stored_config.level == "debug"
