"""FastAPI middleware for automatic HTTP request/response logging"""

import time
from typing import Callable, List, Optional
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from fastapi import FastAPI

from .logger import Logger


class LoggerMiddleware(BaseHTTPMiddleware):
    """FastAPI middleware for automatic HTTP logging"""

    def __init__(
        self,
        app,
        exclude_paths: Optional[List[str]] = None,
        include_headers: bool = False,
        include_body: bool = False,
    ):
        super().__init__(app)
        self.exclude_paths = exclude_paths or []
        self.include_headers = include_headers
        self.include_body = include_body
        self.logger = Logger.get_instance()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request and log details"""
        # Skip excluded paths
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)

        start_time = time.time()

        # Process request
        try:
            response = await call_next(request)
        except Exception as exc:
            # Log unhandled exceptions
            duration_ms = (time.time() - start_time) * 1000
            self.logger.error(
                f"Unhandled exception: {str(exc)}",
                {
                    "method": request.method,
                    "path": request.url.path,
                    "duration_ms": round(duration_ms, 2),
                    "error": exc,
                },
            )
            raise

        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000

        # Build log context
        log_context = {
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": round(duration_ms, 2),
            "client_ip": request.client.host if request.client else None,
            "user_agent": request.headers.get("user-agent"),
        }

        # Add query params if present
        if request.query_params:
            log_context["query"] = dict(request.query_params)

        # Add headers if requested
        if self.include_headers:
            log_context["headers"] = dict(request.headers)

        # Add user context if available (set by auth middleware)
        if hasattr(request.state, "user_id"):
            log_context["user_id"] = request.state.user_id

        # Log message
        message = f"{request.method} {request.url.path} {response.status_code}"

        # Log based on status code
        if response.status_code >= 500:
            self.logger.error(message, log_context)
        elif response.status_code >= 400:
            self.logger.warn(message, log_context)
        else:
            self.logger.http(message, log_context)

        return response


def create_fastapi_middleware(
    app: FastAPI,
    exclude_paths: Optional[List[str]] = None,
    include_headers: bool = False,
    include_body: bool = False,
) -> None:
    """
    Add logger middleware to FastAPI application

    Args:
        app: FastAPI application instance
        exclude_paths: List of paths to exclude from logging (e.g., ["/health", "/metrics"])
        include_headers: Whether to include request headers in logs
        include_body: Whether to include request body in logs (use carefully)

    Example:
        ```python
        from fastapi import FastAPI
        from rcommerz_logger import Logger, create_fastapi_middleware

        app = FastAPI()

        Logger.initialize(LoggerConfig(
            service_name="api-service",
            service_version="1.0.0",
            env="production"
        ))

        create_fastapi_middleware(
            app,
            exclude_paths=["/health", "/metrics"],
            include_headers=False
        )
        ```
    """
    app.add_middleware(
        LoggerMiddleware,
        exclude_paths=exclude_paths,
        include_headers=include_headers,
        include_body=include_body,
    )
