"""
RCOMMERZ Logger - Production-ready structured logging for Python microservices
"""

from .logger import Logger
from .middleware import create_fastapi_middleware, LoggerMiddleware
from .types import LoggerConfig, LogContext, LogLevel, LogType

__version__ = "1.0.0"


# Convenience functions
def initialize(config: LoggerConfig) -> Logger:
    """Initialize the logger singleton"""
    return Logger.initialize(config)


def get_instance() -> Logger:
    """Get the logger singleton instance"""
    return Logger.get_instance()


__all__ = [
    "Logger",
    "LoggerConfig",
    "LogContext",
    "LogLevel",
    "LogType",
    "initialize",
    "get_instance",
    "create_fastapi_middleware",
    "LoggerMiddleware",
]
