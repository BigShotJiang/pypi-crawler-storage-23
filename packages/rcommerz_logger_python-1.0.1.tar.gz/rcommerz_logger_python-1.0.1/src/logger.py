"""Structured logger implementation using structlog"""

import sys
import socket
import logging
import structlog
from typing import Any, Dict, Optional
from opentelemetry import trace

from .types import LoggerConfig, LogContext, LogType


class Logger:
    """Singleton structured logger with OpenTelemetry support"""

    _instance: Optional["Logger"] = None
    _initialized: bool = False

    def __init__(self, config: LoggerConfig):
        """Private constructor - use initialize() instead"""
        if Logger._initialized:
            return

        self.config = config
        self.hostname = socket.gethostname()

        # Configure structlog
        structlog.configure(
            processors=[
                structlog.contextvars.merge_contextvars,
                structlog.processors.add_log_level,
                structlog.processors.StackInfoRenderer(),
                structlog.dev.set_exc_info,
                structlog.processors.TimeStamper(fmt="iso", utc=True, key="@timestamp"),
                self._add_base_fields,  # type: ignore[list-item]
                structlog.processors.JSONRenderer(),
            ],
            wrapper_class=structlog.make_filtering_bound_logger(self._get_log_level()),
            context_class=dict,
            logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
            cache_logger_on_first_use=True,
        )

        self._logger = structlog.get_logger()
        Logger._initialized = True

    @classmethod
    def initialize(cls, config: LoggerConfig) -> "Logger":
        """Initialize the singleton logger instance"""
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance

    @classmethod
    def get_instance(cls) -> "Logger":
        """Get the singleton logger instance"""
        if cls._instance is None:
            raise RuntimeError(
                "Logger not initialized. Call Logger.initialize() first."
            )
        return cls._instance

    def _get_log_level(self) -> int:
        """Convert string log level to structlog level"""
        levels = {
            "DEBUG": logging.DEBUG,
            "INFO": logging.INFO,
            "WARN": logging.WARNING,
            "ERROR": logging.ERROR,
        }
        return levels.get(self.config.level.upper(), logging.INFO)

    def _add_base_fields(
        self, logger, method_name: str, event_dict: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Add base fields to every log entry"""
        # Rename level key
        if "level" in event_dict:
            event_dict["log.level"] = event_dict.pop("level").upper()

        # Add base service fields
        event_dict["service.name"] = self.config.service_name
        event_dict["service.version"] = self.config.service_version
        event_dict["env"] = self.config.env
        event_dict["host.name"] = self.hostname

        # Rename event to message
        if "event" in event_dict:
            event_dict["message"] = event_dict.pop("event")

        return event_dict

    def _get_trace_context(self) -> Dict[str, str]:
        """Extract OpenTelemetry trace context"""
        try:
            span = trace.get_current_span()
            if span and span.is_recording():
                span_context = span.get_span_context()
                return {
                    "trace_id": format(span_context.trace_id, "032x"),
                    "span_id": format(span_context.span_id, "016x"),
                }
        except Exception:
            pass
        return {}

    def _build_log_context(
        self, log_type: LogType, context: Optional[LogContext] = None
    ) -> Dict[str, Any]:
        """Build complete log context with trace info"""
        log_context = {
            "log_type": log_type,
            **self._get_trace_context(),
        }

        if context:
            log_context.update(context)

        return log_context

    def info(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log informational message"""
        log_context = self._build_log_context("normal", context)
        self._logger.info(message, **log_context)

    def error(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log error message"""
        if context is None:
            context = {}

        # Handle exception objects
        if "error" in context and isinstance(context["error"], Exception):
            exc = context["error"]
            context["error_message"] = str(exc)
            context["error_type"] = type(exc).__name__
            # structlog will handle exc_info automatically
            del context["error"]

        log_context = self._build_log_context("error", context)
        self._logger.error(message, **log_context)

    def warn(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log warning message"""
        log_context = self._build_log_context("normal", context)
        self._logger.warning(message, **log_context)

    def debug(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log debug message"""
        log_context = self._build_log_context("debug", context)
        self._logger.debug(message, **log_context)

    def security(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log security-related event"""
        log_context = self._build_log_context("security", context)
        self._logger.warning(message, **log_context)

    def audit(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log audit trail event"""
        log_context = self._build_log_context("audit", context)
        self._logger.info(message, **log_context)

    def http(self, message: str, context: Optional[LogContext] = None) -> None:
        """Log HTTP-specific event"""
        log_context = self._build_log_context("http", context)
        self._logger.info(message, **log_context)
