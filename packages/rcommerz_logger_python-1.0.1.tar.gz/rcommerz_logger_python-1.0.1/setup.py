from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rcommerz-logger-python",
    version="1.0.0",
    author="RCOMMERZ",
    author_email="dev@rcommerz.com",
    description="Production-ready structured logging for Python/FastAPI microservices with OpenTelemetry support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rcommerz/logger-python",
    packages=["rcommerz_logger"],
    package_dir={"rcommerz_logger": "src"},
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
        "Topic :: System :: Logging",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "structlog>=23.2.0",
        "python-json-logger>=2.0.7",
        "opentelemetry-api>=1.22.0",
    ],
    extras_require={
        "fastapi": ["fastapi>=0.109.0", "starlette>=0.35.0"],
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.1.0",
            "httpx>=0.25.0",
            "black>=23.0.0",
            "mypy>=1.7.0",
        ],
    },
    keywords="logging structured-logging fastapi microservices opentelemetry observability json-logging",
    project_urls={
        "Bug Reports": "https://github.com/rcommerz/logger-python/issues",
        "Source": "https://github.com/rcommerz/logger-python",
        "Documentation": "https://github.com/rcommerz/logger-python#readme",
    },
)
