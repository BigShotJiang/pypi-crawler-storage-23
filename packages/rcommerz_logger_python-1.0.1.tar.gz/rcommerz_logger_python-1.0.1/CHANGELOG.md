# Changelog

All notable changes to rcommerz-logger-python will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.1] - 2026-02-22

### Added

- Complete GitHub Actions CI/CD pipeline for automated testing and publishing
- Automated workflows: test, publish, release-drafter, and dependabot
- Local test runner script (`run_tests_locally.sh`) for pre-push validation
- Issue and PR templates for better contribution workflow
- Comprehensive CI/CD documentation (3 guides)

### Fixed

- Code formatting with Black (100% compliance)
- flake8 linting issues (removed unused imports)
- mypy type checking compatibility
- Security vulnerabilities (upgraded pip to 26.0.1)

### Changed

- Enforced 100% test coverage requirement in CI pipeline
- Enhanced code quality checks with automated linting and type checking
- Improved development workflow with automated dependency updates

## [1.0.0] - 2026-02-22

### Added

- Initial production release of rcommerz-logger-python
- Core Logger class with singleton pattern
- Structured JSON logging with consistent field names
- Support for multiple log types: info, error, warn, debug, security, audit, http
- FastAPI middleware for automatic HTTP request/response logging
- OpenTelemetry integration for automatic trace_id and span_id extraction
- LoggerConfig for flexible configuration (service_name, version, env, level)
- Exception handling and detailed error logging
- Performance optimizations with structlog backend
- Comprehensive test suite with 69 tests and 100% code coverage
- Full type hints support for better IDE integration
- LGTM stack compatibility (Loki, Grafana, Tempo, Prometheus)
- Container-friendly with stdout logging
- Python 3.9+ support

### Documentation

- Comprehensive README with examples
- API reference documentation
- FastAPI integration guide
- OpenTelemetry setup guide
- Best practices and anti-patterns
- Testing guide
- Contributing guidelines
- Publishing guide for maintainers

### Testing

- Unit tests for Logger class (26 tests)
- Middleware integration tests (12 tests)
- End-to-end integration tests (12 tests)
- Edge case tests (7 tests)
- OpenTelemetry integration tests (5 tests)
- Convenience function tests (7 tests)
- 100% code coverage achieved

### Dependencies

- structlog >= 23.2.0 (structured logging)
- python-json-logger >= 2.0.7 (JSON formatting)
- opentelemetry-api >= 1.22.0 (trace context)
- Optional: fastapi >= 0.109.0 (web framework)
- Optional: starlette >= 0.35.0 (ASGI framework)

[1.0.0]: https://github.com/rcommerz/logger-python/releases/tag/v1.0.0
