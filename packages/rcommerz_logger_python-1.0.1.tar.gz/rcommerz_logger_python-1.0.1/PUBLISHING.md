# Publishing Guide for rcommerz-logger-python

This guide is for maintainers who need to publish new versions of the package to PyPI.

## Prerequisites

### 1. Install Build Tools

```bash
pip install --upgrade pip setuptools wheel build twine
```

### 2. PyPI Account Setup

1. Create accounts on:
   - **PyPI** (production): <https://pypi.org/account/register/>
   - **TestPyPI** (testing): <https://test.pypi.org/account/register/>

2. Generate API tokens:
   - PyPI: <https://pypi.org/manage/account/token/>
   - TestPyPI: <https://test.pypi.org/manage/account/token/>

3. Create `~/.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJDYOUR_ACTUAL_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-AgENdGVzdC5weXBpLm9yZyYOUR_ACTUAL_TOKEN_HERE
```

**Security Note**: Set proper file permissions:

```bash
chmod 600 ~/.pypirc
```

## Publishing Workflow

### Step 1: Prepare Release

#### Update Version Number

Update version in **three places**:

1. **setup.py** - Line 8:

   ```python
   version="1.1.0",
   ```

2. **pyproject.toml** - Line 6:

   ```toml
   version = "1.1.0"
   ```

3. **src/**init**.py** - Line 9:

   ```python
   __version__ = "1.1.0"
   ```

#### Update Changelog

Edit `README.md` and add new version section:

```markdown
## Changelog

### [1.1.0] - 2026-03-15

#### Added
- New feature X
- Support for Y

#### Fixed
- Bug in Z

#### Changed
- Improved performance of A

### [1.0.0] - 2026-02-22
...
```

### Step 2: Run Quality Checks

```bash
# Ensure you're in the package directory
cd /path/to/packages/logger-python

# Activate virtual environment
source .venv/bin/activate

# Run full test suite
pytest -v

# Check test coverage (must be 100%)
pytest --cov=rcommerz_logger --cov-report=term-missing --cov-report=html

# Verify 100% coverage
open htmlcov/index.html

# Format code
black src/ tests/

# Type checking
mypy src/

# Check for any linting issues
flake8 src/ tests/ || true
```

### Step 3: Clean Build Artifacts

```bash
# Remove old build artifacts
rm -rf dist/
rm -rf build/
rm -rf *.egg-info
rm -rf src/*.egg-info
```

### Step 4: Build Package

```bash
# Build source distribution and wheel
python -m build

# Verify build created files
ls -lh dist/

# You should see two files:
# - rcommerz_logger_python-1.1.0.tar.gz      (source distribution)
# - rcommerz_logger_python-1.1.0-py3-none-any.whl  (wheel)
```

### Step 5: Check Package

```bash
# Validate package
twine check dist/*

# Expected output:
# Checking dist/rcommerz_logger_python-1.1.0-py3-none-any.whl: PASSED
# Checking dist/rcommerz_logger_python-1.1.0.tar.gz: PASSED
```

### Step 6: Test on TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation in a clean environment
python -m venv test_env
source test_env/bin/activate
pip install --index-url https://test.pypi.org/simple/ \
    --extra-index-url https://pypi.org/simple/ \
    rcommerz-logger-python

# Test the package
python -c "from rcommerz_logger import Logger; print('✓ Import successful')"
python -c "from rcommerz_logger import LoggerConfig; print('✓ Config import successful')"

# Cleanup test environment
deactivate
rm -rf test_env/
```

### Step 7: Upload to PyPI (Production)

```bash
# Upload to production PyPI
twine upload dist/*

# You'll see output like:
# Uploading distributions to https://upload.pypi.org/legacy/
# Uploading rcommerz_logger_python-1.1.0-py3-none-any.whl
# 100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 15.2/15.2 kB • 00:00 • ?
# Uploading rcommerz_logger_python-1.1.0.tar.gz
# 100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 18.1/18.1 kB • 00:00 • ?
# View at: https://pypi.org/project/rcommerz-logger-python/1.1.0/
```

### Step 8: Verify Installation

```bash
# Test installation in a fresh environment
python -m venv verify_env
source verify_env/bin/activate

# Install from PyPI
pip install rcommerz-logger-python

# Verify version
python -c "import rcommerz_logger; print(rcommerz_logger.__version__)"

# Quick functionality test
python << 'EOF'
from rcommerz_logger import Logger, LoggerConfig

Logger.initialize(LoggerConfig(
    service_name="test",
    service_version="1.0.0",
    env="dev"
))

logger = Logger.get_instance()
logger.info("Test successful")
print("✓ Package works correctly!")
EOF

# Cleanup
deactivate
rm -rf verify_env/
```

### Step 9: Create Git Tag and GitHub Release

```bash
# Commit version changes
git add setup.py pyproject.toml src/__init__.py README.md
git commit -m "Release version 1.1.0"

# Create and push tag
git tag -a v1.1.0 -m "Release version 1.1.0"
git push origin main
git push origin v1.1.0

# Create GitHub release manually at:
# https://github.com/rcommerz/logger-python/releases/new
# - Tag: v1.1.0
# - Title: v1.1.0
# - Description: Copy from CHANGELOG
# - Attach: dist/rcommerz_logger_python-1.1.0.tar.gz
```

## Version Numbering (SemVer)

Follow [Semantic Versioning](https://semver.org/):

- **MAJOR.MINOR.PATCH** (e.g., 2.1.3)

### When to Increment

| Change Type | Version | Example |
|------------|---------|---------|
| Bug fixes, small improvements | PATCH | 1.0.0 → 1.0.1 |
| New features (backward-compatible) | MINOR | 1.0.1 → 1.1.0 |
| Breaking changes | MAJOR | 1.1.0 → 2.0.0 |

### Examples

```
1.0.0 → 1.0.1  # Fixed log timestamp formatting bug
1.0.1 → 1.1.0  # Added new log_batch() method
1.1.0 → 2.0.0  # Changed LoggerConfig API (breaking change)
```

## Troubleshooting

### Issue: "File already exists"

If you see this error when uploading:

```
HTTPError: 400 Bad Request ... File already exists
```

**Solution**: You cannot replace an existing version. Increment version number and rebuild.

### Issue: "Invalid distribution"

```bash
# Check package contents
tar -tzf dist/rcommerz_logger_python-1.1.0.tar.gz

# Should include:
# - PKG-INFO
# - setup.py
# - README.md
# - src/__init__.py, logger.py, middleware.py, types.py
```

### Issue: "Module not found after install"

Ensure `package_dir` in `setup.py` is correct:

```python
package_dir={"rcommerz_logger": "src"},
```

### Issue: "Authentication failed"

1. Regenerate API token on PyPI
2. Update `~/.pypirc`
3. Verify file permissions: `chmod 600 ~/.pypirc`

### Issue: Tests fail before publishing

**DO NOT PUBLISH** until all tests pass:

```bash
pytest tests/ -v
# Must show: 69 passed
```

## Post-Release Checklist

- ✅ Package visible on PyPI: <https://pypi.org/project/rcommerz-logger-python/>
- ✅ Installation works: `pip install rcommerz-logger-python`
- ✅ Import works: `from rcommerz_logger import Logger`
- ✅ Version correct: `python -c "import rcommerz_logger; print(rcommerz_logger.__version__)"`
- ✅ Git tag created and pushed
- ✅ GitHub release created
- ✅ CHANGELOG updated
- ✅ Documentation updated
- ✅ Team notified

## Rollback (Emergency)

If critical bug found after publishing:

```bash
# You CANNOT delete PyPI versions, but you can:

# 1. Mark version as yanked (discourages installation)
# This requires PyPI web interface - no CLI support

# 2. Publish fixed version immediately
# Increment PATCH version:
# 1.1.0 (broken) → 1.1.1 (fixed)

# 3. Update documentation to warn about broken version
```

## Support

For questions about publishing:

- Email: <dev@rcommerz.com>
- Internal docs: [Link to internal wiki]
- PyPI documentation: <https://packaging.python.org/>

## Security

**NEVER** commit:

- PyPI API tokens
- `~/.pypirc` file
- Private keys

**Always**:

- Use API tokens (not passwords)
- Keep tokens in `~/.pypirc` with `chmod 600`
- Rotate tokens periodically
- Use separate tokens for TestPyPI and PyPI
