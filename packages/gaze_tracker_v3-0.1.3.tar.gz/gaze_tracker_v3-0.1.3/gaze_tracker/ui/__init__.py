"""UI subpackage for gaze tracker."""
