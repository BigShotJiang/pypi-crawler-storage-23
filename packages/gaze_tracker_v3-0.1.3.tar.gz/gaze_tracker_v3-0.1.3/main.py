from gaze_tracker import run_app


if __name__ == "__main__":
    run_app()
