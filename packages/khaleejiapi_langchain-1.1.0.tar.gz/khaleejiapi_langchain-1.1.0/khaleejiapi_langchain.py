"""
KhaleejiAPI LangChain Tool Definitions

Provides LangChain-compatible tools for all KhaleejiAPI endpoints.
Compatible with LangChain, CrewAI, AutoGen, and any framework
that supports LangChain's StructuredTool interface.
"""

from __future__ import annotations

import json
from typing import Any, Optional

import requests
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

BASE_URL = "https://khaleejiapi.dev/api/v1"


def _api_call(endpoint: str, api_key: str, params: dict[str, Any] | None = None, method: str = "GET", json_body: dict[str, Any] | None = None) -> dict[str, Any]:
    """Make an authenticated API call to KhaleejiAPI."""
    headers = {"x-api-key": api_key, "Content-Type": "application/json"}
    url = f"{BASE_URL}/{endpoint}"

    if method == "GET":
        resp = requests.get(url, headers=headers, params=params, timeout=30)
    else:
        resp = requests.post(url, headers=headers, json=json_body, timeout=30)

    resp.raise_for_status()
    return resp.json()


# ──────────────────────────────────────────────
# Input schemas (Pydantic models)
# ──────────────────────────────────────────────

class EmailValidateInput(BaseModel):
    email: str = Field(description="The email address to validate")

class PhoneValidateInput(BaseModel):
    phone: str = Field(description="Phone number to validate (with country code, e.g. +971501234567)")

class IPLookupInput(BaseModel):
    ip: str = Field(description="IP address to look up (IPv4 or IPv6)")

class ExchangeRatesInput(BaseModel):
    base: str = Field(description="Base currency code (e.g. AED, USD, EUR)")
    target: str = Field(default="", description="Optional target currency code. If omitted, returns all rates.")

class WeatherInput(BaseModel):
    city: str = Field(description="City name (e.g. Dubai, Riyadh, Doha)")

class TranslateInput(BaseModel):
    text: str = Field(description="Text to translate")
    source: str = Field(default="auto", description="Source language code (e.g. en, ar). Use 'auto' for detection.")
    target: str = Field(description="Target language code (e.g. ar, en, fr)")

class PrayerTimesInput(BaseModel):
    city: str = Field(description="City name (e.g. Dubai, Mecca, Istanbul)")
    date: str = Field(default="", description="Date in YYYY-MM-DD format. Defaults to today.")

class HijriConvertInput(BaseModel):
    date: str = Field(description="Date in YYYY-MM-DD format to convert")
    direction: str = Field(default="to_hijri", description="Conversion direction: 'to_hijri' or 'to_gregorian'")

class ZakatCalculateInput(BaseModel):
    assets: str = Field(description="JSON string of assets, e.g. '{\"cash\": 50000, \"gold_grams\": 100}'")
    currency: str = Field(default="AED", description="Currency code for values (e.g. AED, SAR, USD)")

class VATCalculateInput(BaseModel):
    amount: float = Field(description="Amount to calculate VAT on")
    country: str = Field(default="AE", description="Country code (AE, SA, BH, OM, KW, QA)")

class HolidaysInput(BaseModel):
    country: str = Field(default="AE", description="Country code (AE, SA, BH, OM, KW, QA)")
    year: int = Field(default=0, description="Year (defaults to current year if 0)")

class FraudCheckInput(BaseModel):
    ip: str = Field(default="", description="IP address to check")
    email: str = Field(default="", description="Email address to check")
    phone: str = Field(default="", description="Phone number to check")

class IBANValidateInput(BaseModel):
    iban: str = Field(description="IBAN number to validate")

class VATValidateInput(BaseModel):
    vat_number: str = Field(description="VAT/TRN number to validate")
    country: str = Field(default="AE", description="Country code (AE, SA, BH, OM, KW, QA)")

class TimezoneInput(BaseModel):
    location: str = Field(description="Location name or coordinates (e.g. 'Dubai' or '25.2048,55.2708')")

class GeocodingInput(BaseModel):
    query: str = Field(description="Address to geocode or coordinates to reverse-geocode")

class BusinessDaysInput(BaseModel):
    start_date: str = Field(description="Start date in YYYY-MM-DD format")
    end_date: str = Field(description="End date in YYYY-MM-DD format")
    country: str = Field(default="AE", description="Country code for holiday awareness")

class ArabicTextInput(BaseModel):
    text: str = Field(description="Arabic text to process")
    operation: str = Field(default="analyze", description="Operation: analyze, transliterate, remove_diacritics, sentiment")

class EmiratesIdInput(BaseModel):
    id: str = Field(description="15-digit UAE Emirates ID number to validate")

class SaudiIdInput(BaseModel):
    id: str = Field(description="10-digit Saudi National ID or Iqama number")

class SaudiIdBatchInput(BaseModel):
    ids: str = Field(description="JSON array of Saudi IDs to validate (max 100), e.g. '[\"1234567890\", \"2345678901\"]'")

class SukukInput(BaseModel):
    country: str = Field(default="", description="Filter by issuer country code (e.g. AE, SA)")
    type: str = Field(default="", description="Filter by sukuk type (e.g. Ijara, Mudarabah, Wakalah)")
    status: str = Field(default="", description="Filter by status (e.g. Active, Matured)")

class TakafulInput(BaseModel):
    type: str = Field(description="Insurance type: health, motor, property, travel, life, business")
    country: str = Field(default="AE", description="GCC country code (AE, SA, BH, OM, KW, QA)")
    age: int = Field(default=0, description="Policyholder age (for health/life types)")
    coverage_amount: float = Field(default=0, description="Desired coverage amount")
    model: str = Field(default="wakalah", description="Takaful model: wakalah or mudarabah")

class ShortenUrlInput(BaseModel):
    url: str = Field(description="URL to shorten")
    custom_alias: str = Field(default="", description="Optional custom short code")


# ──────────────────────────────────────────────
# Tool factory functions
# ──────────────────────────────────────────────

def _make_email_validate(api_key: str) -> StructuredTool:
    def run(email: str) -> str:
        result = _api_call("email/validate", api_key, params={"email": email})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_email_validate", description="Validate an email address — checks syntax, domain, MX records, and disposable providers. Returns deliverability status.", args_schema=EmailValidateInput)

def _make_phone_validate(api_key: str) -> StructuredTool:
    def run(phone: str) -> str:
        result = _api_call("phone/validate", api_key, params={"phone": phone})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_phone_validate", description="Validate an international phone number — detects carrier, line type, and country. Supports all GCC and international formats.", args_schema=PhoneValidateInput)

def _make_ip_lookup(api_key: str) -> StructuredTool:
    def run(ip: str) -> str:
        result = _api_call("ip/lookup", api_key, params={"ip": ip})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_ip_lookup", description="Look up geolocation data for an IP address — returns country, city, ISP, coordinates, and threat intelligence.", args_schema=IPLookupInput)

def _make_exchange_rates(api_key: str) -> StructuredTool:
    def run(base: str, target: str = "") -> str:
        params: dict[str, str] = {"base": base}
        if target:
            params["target"] = target
        result = _api_call("exchange/rates", api_key, params=params)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_exchange_rates", description="Get real-time currency exchange rates. Supports 50+ currencies including AED, SAR, KWD, BHD, OMR, QAR.", args_schema=ExchangeRatesInput)

def _make_weather(api_key: str) -> StructuredTool:
    def run(city: str) -> str:
        result = _api_call("weather", api_key, params={"city": city})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_weather", description="Get current weather and 7-day forecast for a city. Covers all MENA cities with temperature, humidity, wind, and conditions.", args_schema=WeatherInput)

def _make_translate(api_key: str) -> StructuredTool:
    def run(text: str, source: str = "auto", target: str = "en") -> str:
        result = _api_call("translate", api_key, method="POST", json_body={"text": text, "source": source, "target": target})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_translate", description="Translate text between 22+ languages using AI. Supports Arabic, English, French, Urdu, Hindi, and more with transliteration.", args_schema=TranslateInput)

def _make_prayer_times(api_key: str) -> StructuredTool:
    def run(city: str, date: str = "") -> str:
        params: dict[str, str] = {"city": city}
        if date:
            params["date"] = date
        result = _api_call("prayer-times", api_key, params=params)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_prayer_times", description="Get Islamic prayer times (Fajr, Dhuhr, Asr, Maghrib, Isha) for any city using astronomical calculation.", args_schema=PrayerTimesInput)

def _make_hijri_convert(api_key: str) -> StructuredTool:
    def run(date: str, direction: str = "to_hijri") -> str:
        result = _api_call("hijri/convert", api_key, params={"date": date, "direction": direction})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_hijri_convert", description="Convert dates between Gregorian and Hijri (Islamic) calendars with full month names and day details.", args_schema=HijriConvertInput)

def _make_zakat_calculate(api_key: str) -> StructuredTool:
    def run(assets: str, currency: str = "AED") -> str:
        try:
            assets_dict = json.loads(assets)
        except json.JSONDecodeError:
            return json.dumps({"error": "Invalid JSON for assets parameter"})
        result = _api_call("zakat/calculate", api_key, method="POST", json_body={"assets": assets_dict, "currency": currency})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_zakat_calculate", description="Calculate zakat obligations on cash, gold, silver, stocks, and other assets. Uses live gold/silver prices for nisab threshold.", args_schema=ZakatCalculateInput)

def _make_vat_calculate(api_key: str) -> StructuredTool:
    def run(amount: float, country: str = "AE") -> str:
        result = _api_call("vat/calculate", api_key, params={"amount": str(amount), "country": country})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_vat_calculate", description="Calculate VAT for GCC countries. Supports UAE (5%), Saudi Arabia (15%), Bahrain (10%), Oman (5%), and more.", args_schema=VATCalculateInput)

def _make_holidays(api_key: str) -> StructuredTool:
    def run(country: str = "AE", year: int = 0) -> str:
        params: dict[str, str] = {"country": country}
        if year > 0:
            params["year"] = str(year)
        result = _api_call("holidays", api_key, params=params)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_holidays", description="Get public holidays for GCC countries with Islamic calendar support. Returns dates, names, and observance details.", args_schema=HolidaysInput)

def _make_fraud_check(api_key: str) -> StructuredTool:
    def run(ip: str = "", email: str = "", phone: str = "") -> str:
        params: dict[str, str] = {}
        if ip:
            params["ip"] = ip
        if email:
            params["email"] = email
        if phone:
            params["phone"] = phone
        result = _api_call("fraud/check", api_key, params=params)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_fraud_check", description="Detect fraud signals for IP addresses, emails, or phone numbers. Returns risk scores, VPN/proxy detection, and threat indicators.", args_schema=FraudCheckInput)

def _make_iban_validate(api_key: str) -> StructuredTool:
    def run(iban: str) -> str:
        result = _api_call("iban/validate", api_key, params={"iban": iban})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_iban_validate", description="Validate IBAN numbers with bank and branch information. Focused on MENA region banks.", args_schema=IBANValidateInput)

def _make_vat_validate(api_key: str) -> StructuredTool:
    def run(vat_number: str, country: str = "AE") -> str:
        result = _api_call("vat/validate", api_key, params={"vat_number": vat_number, "country": country})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_vat_validate", description="Validate VAT/TRN numbers for UAE and GCC countries. Returns registration status and company details.", args_schema=VATValidateInput)

def _make_timezone(api_key: str) -> StructuredTool:
    def run(location: str) -> str:
        result = _api_call("timezone", api_key, params={"location": location})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_timezone", description="Get timezone data for a location — current time, UTC offset, DST status, and abbreviation.", args_schema=TimezoneInput)

def _make_geocoding(api_key: str) -> StructuredTool:
    def run(query: str) -> str:
        result = _api_call("geocode", api_key, params={"query": query})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_geocoding", description="Geocode addresses to coordinates or reverse-geocode coordinates to addresses. Focused on UAE and MENA locations.", args_schema=GeocodingInput)

def _make_business_days(api_key: str) -> StructuredTool:
    def run(start_date: str, end_date: str, country: str = "AE") -> str:
        result = _api_call("business-days", api_key, params={"start_date": start_date, "end_date": end_date, "country": country})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_business_days", description="Calculate business days between two dates for GCC countries, accounting for weekends (Fri-Sat) and public holidays.", args_schema=BusinessDaysInput)

def _make_arabic_text(api_key: str) -> StructuredTool:
    def run(text: str, operation: str = "analyze") -> str:
        result = _api_call("arabic/process", api_key, method="POST", json_body={"text": text, "operation": operation})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_arabic_text", description="Process Arabic text — remove diacritics, transliterate to Latin, analyze sentiment, or detect language features.", args_schema=ArabicTextInput)

def _make_emirates_id_validate(api_key: str) -> StructuredTool:
    def run(id: str) -> str:
        result = _api_call("validation/emirates-id", api_key, params={"id": id})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_emirates_id_validate", description="Validate and parse a UAE Emirates ID number using Luhn algorithm. Returns validity, nationality type, and age.", args_schema=EmiratesIdInput)

def _make_saudi_id_validate(api_key: str) -> StructuredTool:
    def run(id: str) -> str:
        result = _api_call("validation/saudi-id", api_key, params={"id": id})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_saudi_id_validate", description="Validate a Saudi National ID or Iqama number (10 digits) using Luhn algorithm. Returns validity and metadata.", args_schema=SaudiIdInput)

def _make_saudi_id_batch(api_key: str) -> StructuredTool:
    def run(ids: str) -> str:
        try:
            ids_list = json.loads(ids)
        except json.JSONDecodeError:
            return json.dumps({"error": "Invalid JSON for ids parameter. Provide a JSON array of strings."})
        result = _api_call("validation/saudi-id", api_key, method="POST", json_body={"ids": ids_list})
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_saudi_id_batch", description="Validate up to 100 Saudi National IDs or Iqama numbers in a single batch request.", args_schema=SaudiIdBatchInput)

def _make_sukuk_list(api_key: str) -> StructuredTool:
    def run(country: str = "", type: str = "", status: str = "") -> str:
        params: dict[str, str] = {}
        if country:
            params["country"] = country
        if type:
            params["type"] = type
        if status:
            params["status"] = status
        result = _api_call("sukuk/list", api_key, params=params)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_sukuk_list", description="Get GCC sukuk (Islamic bonds) reference data. 12 sukuk from UAE, Saudi Arabia, and other GCC countries with filtering.", args_schema=SukukInput)

def _make_takaful_calculate(api_key: str) -> StructuredTool:
    def run(type: str, country: str = "AE", age: int = 0, coverage_amount: float = 0, model: str = "wakalah") -> str:
        body: dict[str, Any] = {"type": type, "country": country, "model": model}
        if age > 0:
            body["age"] = age
        if coverage_amount > 0:
            body["coverage_amount"] = coverage_amount
        result = _api_call("takaful/calculate", api_key, method="POST", json_body=body)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_takaful_calculate", description="Calculate Islamic insurance (Takaful) premium estimates. Supports 6 types across GCC with Wakalah/Mudarabah models.", args_schema=TakafulInput)

def _make_shorten_url(api_key: str) -> StructuredTool:
    def run(url: str, custom_alias: str = "") -> str:
        body: dict[str, Any] = {"url": url}
        if custom_alias:
            body["customCode"] = custom_alias
        result = _api_call("url/shorten", api_key, method="POST", json_body=body)
        return json.dumps(result, indent=2)
    return StructuredTool.from_function(run, name="khaleeji_shorten_url", description="Shorten a URL with optional custom alias. Returns the short URL with click analytics.", args_schema=ShortenUrlInput)


# ──────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────

def get_all_tools(api_key: str) -> list[StructuredTool]:
    """Return all KhaleejiAPI tools configured with the given API key.

    Compatible with LangChain agents, CrewAI, AutoGen, and any framework
    that accepts LangChain StructuredTool instances.

    Args:
        api_key: Your KhaleejiAPI API key (starts with kapi_).

    Returns:
        List of StructuredTool instances ready for agent use.
    """
    return [
        _make_email_validate(api_key),
        _make_phone_validate(api_key),
        _make_ip_lookup(api_key),
        _make_exchange_rates(api_key),
        _make_weather(api_key),
        _make_translate(api_key),
        _make_prayer_times(api_key),
        _make_hijri_convert(api_key),
        _make_zakat_calculate(api_key),
        _make_vat_calculate(api_key),
        _make_holidays(api_key),
        _make_fraud_check(api_key),
        _make_iban_validate(api_key),
        _make_vat_validate(api_key),
        _make_timezone(api_key),
        _make_geocoding(api_key),
        _make_business_days(api_key),
        _make_arabic_text(api_key),
        _make_emirates_id_validate(api_key),
        _make_saudi_id_validate(api_key),
        _make_saudi_id_batch(api_key),
        _make_sukuk_list(api_key),
        _make_takaful_calculate(api_key),
        _make_shorten_url(api_key),
    ]


def get_tools_by_category(api_key: str, category: str) -> list[StructuredTool]:
    """Return KhaleejiAPI tools filtered by category.

    Categories: validation, geolocation, finance, utilities, islamic-finance, identity
    """
    category_map: dict[str, list[str]] = {
        "validation": ["khaleeji_email_validate", "khaleeji_phone_validate", "khaleeji_iban_validate", "khaleeji_vat_validate", "khaleeji_emirates_id_validate", "khaleeji_saudi_id_validate", "khaleeji_saudi_id_batch"],
        "geolocation": ["khaleeji_ip_lookup", "khaleeji_timezone", "khaleeji_geocoding"],
        "finance": ["khaleeji_exchange_rates", "khaleeji_vat_calculate", "khaleeji_holidays", "khaleeji_business_days"],
        "utilities": ["khaleeji_weather", "khaleeji_translate", "khaleeji_arabic_text", "khaleeji_shorten_url"],
        "islamic-finance": ["khaleeji_prayer_times", "khaleeji_hijri_convert", "khaleeji_zakat_calculate", "khaleeji_sukuk_list", "khaleeji_takaful_calculate"],
        "identity": ["khaleeji_fraud_check"],
    }

    allowed = set(category_map.get(category, []))
    all_tools = get_all_tools(api_key)
    return [t for t in all_tools if t.name in allowed]
