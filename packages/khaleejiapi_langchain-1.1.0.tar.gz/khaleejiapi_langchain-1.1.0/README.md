# KhaleejiAPI LangChain Tools

AI agent tool definitions for integrating KhaleejiAPI with LangChain, CrewAI, and other agent frameworks.

## Installation

```bash
pip install khaleejiapi langchain-core
```

## Quick Start

```python
from langchain_core.tools import StructuredTool
from khaleejiapi_langchain import get_all_tools

# Get all KhaleejiAPI tools for your agent
tools = get_all_tools(api_key="your_api_key")

# Use with LangChain agent
from langchain.agents import create_tool_calling_agent
agent = create_tool_calling_agent(llm, tools, prompt)
```

## Available Tools

| Tool | Description |
|------|-------------|
| `khaleeji_email_validate` | Validate email addresses with syntax, domain, MX checks |
| `khaleeji_phone_validate` | Validate international phone numbers |
| `khaleeji_ip_lookup` | Get geolocation data from IP addresses |
| `khaleeji_exchange_rates` | Get real-time currency exchange rates |
| `khaleeji_weather` | Get weather data for MENA cities |
| `khaleeji_translate` | AI-powered translation (22+ languages) |
| `khaleeji_prayer_times` | Get prayer times for any city |
| `khaleeji_hijri_convert` | Convert between Gregorian and Hijri calendars |
| `khaleeji_zakat_calculate` | Calculate zakat obligations |
| `khaleeji_vat_calculate` | Calculate UAE/GCC VAT |
| `khaleeji_holidays` | Get public holidays for GCC countries |
| `khaleeji_fraud_check` | Detect suspicious IPs, emails, phones |

## Usage with CrewAI

```python
from crewai import Agent
from khaleejiapi_langchain import get_all_tools

tools = get_all_tools(api_key="your_api_key")

researcher = Agent(
    role="Middle East Market Researcher",
    goal="Analyze business conditions in the GCC region",
    tools=tools,
)
```
