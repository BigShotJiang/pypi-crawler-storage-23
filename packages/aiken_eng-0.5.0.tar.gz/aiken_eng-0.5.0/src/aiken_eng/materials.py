# TODO: Materials module

def tsts_curve():
    return "tsts_curve() is not yet implemented."

# TODO: make a properties look up function