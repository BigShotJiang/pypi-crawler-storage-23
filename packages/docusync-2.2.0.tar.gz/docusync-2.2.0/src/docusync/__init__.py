"""DocuSync - Documentation synchronization tool for Docusaurus sites."""

__version__ = "2.2.0"
