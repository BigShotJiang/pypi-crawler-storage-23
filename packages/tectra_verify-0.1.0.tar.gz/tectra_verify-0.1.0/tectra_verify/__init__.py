"""tectra-verify: Open-source image provenance verification library."""

from tectra_verify.verify import verify_image
from tectra_verify.watermark import extract_watermark
from tectra_verify.hashing import compute_hashes
from tectra_verify.merkle import verify_merkle_proof

__all__ = [
    "verify_image",
    "extract_watermark",
    "compute_hashes",
    "verify_merkle_proof",
]
