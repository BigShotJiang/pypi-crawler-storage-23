# tectra-verify

Open-source image provenance verification library. Part of the [Tectra](https://tectra.vision) content authenticity platform.

`tectra-verify` lets you verify whether an image was registered on the Tectra provenance network. It computes perceptual and cryptographic hashes locally, extracts embedded watermarks, and checks the result against the Tectra verification API.

This package contains **verification and extraction logic only** — no signing, key management, or watermark embedding.

## Install

```bash
pip install tectra-verify
```

To enable watermark extraction (optional):

```bash
pip install tectra-verify[watermark]
```

## CLI Usage

```bash
tectra-verify check image.jpg
tectra-verify check photo.png --api-url https://custom-api.example.com
```

## Python Usage

```python
from tectra_verify import verify_image

result = verify_image("image.jpg")
print(result)
```

Lower-level utilities are also available:

```python
from tectra_verify import extract_watermark, compute_hashes, verify_merkle_proof
```

## Links

- **Full documentation**: [tectra.vision/docs](https://tectra.vision/docs)
- **Protocol specification**: [tectra.vision/protocol](https://tectra.vision/protocol)
- **Source**: [github.com/tectra-vision/tectra-verify](https://github.com/tectra-vision/tectra-verify)

## License

MIT — see [LICENSE](LICENSE).
