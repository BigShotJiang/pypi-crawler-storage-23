"""
Generate ids utility
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

def generate_ids(geojson: dict, from_property: str | None = None) -> dict:
  """
  Generates feature IDs for a GeoJSON FeatureCollection.

  If `from_property` is provided, the feature's 'id' is taken from that property.
  If `from_property` is None, a sequential index is used as the 'id'.

  :param geojson: GeoJSON dictionary containing a FeatureCollection.
  :param from_property: Optional name of the property to use as the feature 'id'.
  :return: The GeoJSON dictionary with 'id' fields updated.
  :raises ValueError: If `from_property` is provided but not found in a feature's properties.
  """

  new_geojson = { **geojson, "features": [] }
  for i, feature in enumerate(geojson["features"]):

    new_feature = _utility(feature, from_property, i)

    new_geojson["features"].append(new_feature)

  return new_geojson


def _utility(feature: dict, from_property: str | None, index: int) -> dict:
  """
  Sets the 'id' of a single GeoJSON feature based on a property or index.

  :param feature: A single GeoJSON Feature dictionary.
  :param from_property: Name of the property to use as 'id', or None to use index.
  :param index: Index of the feature, used if `from_property` is None.
  :return: The updated feature dictionary with 'id' set.
  """

  new_feature = feature.copy()
  new_feature.pop("id", None)

  if from_property is None:
    new_feature = {"id": index, **new_feature}
    return new_feature

  if from_property in new_feature.get('properties', {}):
    new_feature = {"id": new_feature['properties'][from_property], **new_feature}
  else:
    raise ValueError(f'fieldname: [{from_property}] not found in properties for feature {index}')

  return new_feature
