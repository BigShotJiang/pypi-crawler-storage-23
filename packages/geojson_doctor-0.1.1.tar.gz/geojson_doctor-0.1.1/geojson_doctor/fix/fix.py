"""
Fix function
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

from geojson_doctor.helpers.helpers import get_id
from geojson_doctor.fix.fix_functions import FIXERS


def fix(geojson: dict, fixers: list | None = None):
  """
  Apply a sequence of registered geometry fixers to all features in a GeoJSON.

  Iterates over each feature in the GeoJSON `features` list, extracts
  the geometry, and applies the fixers in the order specified by `fixers`.
  If `fixers` is not provided, all fixers are applied.

  Available fixers (keys in `FIXERS`):
      - fix_validity: Validates and repairs invalid geometries.
      - fix_orientation: Ensures correct exterior/interior ring orientation.
      - fix_redundant_vertices: Removes redundant vertices (e.g., duplicate and collinear points)

  'id' field is used for logging. If 'id' id missing from the GeoJSON, logging will 
  display the index of the GeoJSON entry.

  :param geojson: A GeoJSON dictionary containing a 'features' list of geometries.
  :param fixers: List of fixer names (strings) to apply in order.
                   If None, all fixers are applied.
  :return: The GeoJSON dictionary with all fixed geometries 
  """

  if fixers is None:
    fixers = list(FIXERS.keys())

  for item in fixers:
    if item not in FIXERS:
      raise FileNotFoundError(f'fixer {item} not available, must be one of {list(FIXERS.keys())}')

  new_geojson = { **geojson, "features": [] }
  for i, feature in enumerate(geojson["features"]):
    geom = feature["geometry"]
    name = get_id(feature, i)

    for fixer in fixers:
      if geom:
        geom = FIXERS[fixer](geom, name)

    if geom:
      new_feature = { **feature, "geometry": geom }
      new_geojson["features"].append(new_feature)

  return new_geojson
