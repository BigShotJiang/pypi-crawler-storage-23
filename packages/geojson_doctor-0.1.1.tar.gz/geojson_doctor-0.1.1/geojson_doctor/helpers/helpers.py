"""
Helper functions helper
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

from shapely import MultiPolygon, Polygon
from shapely.geometry.base import BaseGeometry


def check_polygon_multipolygon(shapely_object: BaseGeometry, geojson_name: str, function_name) -> Polygon | MultiPolygon:
  """
  Ensure the geometry is a Polygon or MultiPolygon.

  :param geometry: A Shapely geometry object.
  :return: Geometry, typed as Polygon or MultiPolygon.
  """
  if not isinstance(shapely_object, (Polygon, MultiPolygon)):
    raise TypeError(f"{geojson_name} has unsupported geometry type: {shapely_object.geom_type}. "
                    f"Only Polygon or MultiPolygon are supported for function: [{function_name}].")

  return shapely_object


def get_id(feature: dict, index: int):
  """
  Determine a name or identifier for a GeoJSON feature for logging purposes.

  :param feature: A GeoJSON feature dictionary containing at least a 'properties' key.
  :param index: Index of the feature in the GeoJSON features list, used as a fallback identifier.
  :return: A string identifier for the feature, either in the form "ID:{value}" or "INDEX:{index}".
  """
  if 'id' in feature:
    return f"ID:{feature['id']}"

  return f"INDEX:{index}"
