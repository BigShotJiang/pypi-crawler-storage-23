"""
multipolygon to polygon tranformer
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

import logging
from shapely import Polygon
from shapely.geometry import mapping, shape

from geojson_doctor.helpers.helpers import get_id, check_polygon_multipolygon


def multipolygon_to_polygon(geojson: dict, method: str = 'leave_multi'):
  """
  Convert single-polygon MultiPolygons in a GeoJSON to simple Polygons.

  Iterates over all features in the GeoJSON and normalizes their geometries:
  - If a feature is a Polygon, it is left unchanged.
  - If a feature is a MultiPolygon with exactly one polygon, it is converted to a Polygon.
  - If a feature is a MultiPolygon with multiple polygons, behavior depends on `method`:
      - 'leave_multi' (default): keeps the MultiPolygon unchanged.
      - 'keep_first': keeps only the first polygon and converts it to a Polygon.
      - 'remove': removes the feature (geometry becomes None) and logs a warning.

  'id' field is used for logging. 'id' field missing logging will display index.

  :param geojson: GeoJSON dictionary
  :param method: Strategy for handling MultiPolygons with multiple polygons. 
  :return: GeoJSON dictionary containing only single-polygons.
  """

  available_methods = ['leave_multi', 'keep_first', 'remove']

  if method not in available_methods:
    raise ValueError(f'{method} not found, must be: ')

  new_geojson = { **geojson, "features": [] }
  for i, feature in enumerate(geojson["features"]):
    geom = feature["geometry"]
    name = get_id(feature, i)

    geom = _transformer(geom, name, method)

    if geom:
      new_feature = { **feature, "geometry": geom }
      new_geojson["features"].append(new_feature)

  return new_geojson


def _transformer(geom: dict, name: str, method: str) -> dict | None:
  """
  Normalize a geometry by converting single-polygon MultiPolygons to Polygons.
  Other polygons handled based on the method given.

  :param geom: The input geometry, expected to be a Polygon or MultiPolygon.
  :param name: Name of the feature (e.g., building) for logging purposes.
  :param method: Strategy for handling MultiPolygons with multiple polygons. 
  :return: A GeoJSON dictionary representing a Polygon.
  """

  shapely_object = shape(geom)
  shapely_object = check_polygon_multipolygon(shapely_object, name, "multipolygon_to_polygon")

  if isinstance(shapely_object, Polygon):
    return mapping(shapely_object)

  if len(shapely_object.geoms) > 1:
    if method == 'leave_multi':
      return mapping(shapely_object)

    if method == 'keep_first':
      logging.warning('%s is a MultiPolygon with more than one polygon, keeping only the first polygon', name)
      return mapping(Polygon(shapely_object.geoms[0]))

    if method == 'remove':
      logging.error('%s is a MultiPolygon with more than one polygon, removing', name)
      return None

  return mapping(Polygon(shapely_object.geoms[0]))
