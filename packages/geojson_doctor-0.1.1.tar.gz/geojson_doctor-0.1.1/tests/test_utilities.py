"""
Test utility functions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2026 Concordia CERC group
Project Coder Connor Brackley connor.brackley@concordia.ca
"""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from geojson_doctor.utilities.generate_ids import generate_ids


@pytest.fixture(scope="session")
def geojson():
  """
  Load GeoJSON test data
  """
  path = Path(__file__).parent / "data" / "multipolygon.geojson"
  with path.open() as f:
    return json.load(f)


def test_generate_ids(geojson):  # pylint: disable=redefined-outer-name
  """
  Test generate_ids creates ids from property

  :param geojson: GeoJSON test fixture
  """

  geojson = generate_ids(geojson, from_property='custom_id')

  assert 'id' in geojson['features'][0]
  assert geojson['features'][0]['id'] == 'A1'


def test_utilities_input_mutation(geojson):  # pylint: disable=redefined-outer-name
  """
  Test to ensure input data is not mutated by utility functions

  :param geojson: GeoJSON test fixture
  """
  copy_geojson = deepcopy(geojson)
  generate_ids(geojson)
  assert copy_geojson == geojson, 'Function generate_ids modified input data'
