"""Monitor package for home automation."""

__version__ = "0.1.0"
