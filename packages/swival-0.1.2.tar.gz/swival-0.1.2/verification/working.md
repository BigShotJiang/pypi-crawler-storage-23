The following shell command:

<command>
curl http://127.0.0.1:5000
</command>

returns a response that includes "HELLO WORLD!"
