Your goal is to write a program in Python that implements a simple
HTTP server, that listens to port 5000 and always returns the
following rsponse: "HELLO WORLD!".
