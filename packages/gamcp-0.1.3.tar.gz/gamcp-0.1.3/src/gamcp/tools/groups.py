from typing import Optional

from gamcp.gam_runner import execute_gam

def register(mcp):

    @mcp.tool()
    def create_collaborative_inbox_group(
        group_email: str,
        group_name: str,
        initial_member_emails: list[str],
        who_can_post: str = "ALL_MEMBERS_CAN_POST",
        confirmed: bool = False
    ) -> str:
        """
        Creates a new Google Group configured as a Collaborative Inbox.
        
        Args:
            group_email: The email address for the new group.
            group_name: The display name for the new group.
            initial_member_emails: List of email addresses to add as members.
            who_can_post: Posting permission setting. Defaults to "ALL_MEMBERS_CAN_POST".
            confirmed: Must be True to execute. If False, returns a preview.
            
        GAM pattern:
            1. gam create group <group_email> name <group_name>
            2. gam update group <group_email> setting isArchived false whoCanPostMessage <who_can_post> enableCollaborativeInbox true
            3. for each member: gam update group <group_email> add member <member_email>
        """
        cmd1 = ["create", "group", group_email, "name", group_name]
        cmd2 = [
            "update", "group", group_email, "setting", 
            "isArchived", "false", 
            "whoCanPostMessage", who_can_post, 
            "enableCollaborativeInbox", "true"
        ]
        cmds3 = [["update", "group", group_email, "add", "member", m] for m in initial_member_emails]
        
        if not confirmed:
            preview = f"PREVIEW (not executed - run with confirmed=True):\\n"
            preview += f"1. gam {' '.join(cmd1)}\\n"
            preview += f"2. gam {' '.join(cmd2)}\\n"
            for c in cmds3:
                preview += f"3. gam {' '.join(c)}\\n"
            return preview
            
        results = []
        results.append("Step 1 (Create Group):\\n" + execute_gam(cmd1))
        results.append("Step 2 (Configure Setting):\\n" + execute_gam(cmd2))
        
        for email, cmd in zip(initial_member_emails, cmds3):
            results.append(f"Step 3 (Add {email}):\\n" + execute_gam(cmd))
            
        return "\\n\\n".join(results)

    @mcp.tool()
    def get_group_permissions_to_sheet(
        group_emails: list[str],
        output_sheet_id: str,
        output_sheet_name: str
    ) -> str:
        """
        Retrieves group members and their roles, outputting to a Google Sheet.
        Uses multiprocess redirect to quickly gather many groups.
        
        Args:
            group_emails: List of group email addresses to query.
            output_sheet_id: ID of the Google Sheet for output.
            output_sheet_name: Tab name for the output sheet.
            
        GAM pattern:
            gam redirect csv - multiprocess todrive tdfileid <id> tdsheet <name> tdupdatesheet 
            print group-members group <email1> <email2> ...
        """
        args = [
            "redirect", "csv", "-", "multiprocess", 
            "todrive", "tdfileid", output_sheet_id, 
            "tdsheet", f'"{output_sheet_name}"', "tdupdatesheet",
            "print", "group-members", "group"
        ]
        args.extend(group_emails)
        
        result = execute_gam(args)
        return f"Results written to Google Sheet ID: {output_sheet_id} (Sheet Name: {output_sheet_name})\\n\\n{result}"
