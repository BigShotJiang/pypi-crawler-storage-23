from gamcp.gam_runner import execute_gam

def register(mcp):

    @mcp.tool()
    def create_gws_user(
        first_name: str,
        last_name: str,
        primary_email: str,
        org_unit_path: str,
        password: str,
        change_password_at_next_login: bool = True,
        confirmed: bool = False
    ) -> str:
        """
        Creates a new Google Workspace user.
        
        Args:
            first_name: The first name of the user.
            last_name: The last name of the user.
            primary_email: The primary email address for the new user.
            org_unit_path: The organizational unit path (e.g., '/Staff/Engineering').
            password: The initial password for the user.
            change_password_at_next_login: Whether to force password change on first login.
            confirmed: Must be True to execute. If False, returns a preview.
            
        GAM pattern:
            gam create user <primary_email> firstname <first_name> lastname <last_name>
                org <org_unit_path> password <password> changepassword <true/false>
        """
        change_pw = "true" if change_password_at_next_login else "false"
        args = [
            "create", "user", primary_email,
            "firstname", first_name,
            "lastname", last_name,
            "org", org_unit_path,
            "password", password,
            "changepassword", change_pw
        ]
        
        if not confirmed:
            prfx_args = [
                "create", "user", primary_email,
                "firstname", first_name,
                "lastname", last_name,
                "org", org_unit_path
            ]
            return f"PREVIEW (not executed - run with confirmed=True):\\nCommand: gam {' '.join(prfx_args)} password **** changepassword {change_pw}"
            
        return execute_gam(args)

    @mcp.tool()
    def identify_workspace_entity(
        identifier: str
    ) -> str:
        """
        Identifies a Workspace entity (user, group, alias, etc.) by its email or ID.
        
        Args:
            identifier: The email address or resource identifier to query.
            
        GAM pattern:
            gam whatis <identifier>
        """
        args = ["whatis", identifier]
        return execute_gam(args)
