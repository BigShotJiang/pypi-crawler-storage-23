from __future__ import annotations

from .app import app


def main() -> None:
    app()
