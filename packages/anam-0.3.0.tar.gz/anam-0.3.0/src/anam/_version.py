"""Version information for anam-ai SDK."""

__version__ = "0.3.0"
