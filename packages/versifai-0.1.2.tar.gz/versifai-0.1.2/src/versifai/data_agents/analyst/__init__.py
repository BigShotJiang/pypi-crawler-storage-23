"""Data analyst agent for acceptance testing."""
