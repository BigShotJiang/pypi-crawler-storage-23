"""Internal shared utilities."""
