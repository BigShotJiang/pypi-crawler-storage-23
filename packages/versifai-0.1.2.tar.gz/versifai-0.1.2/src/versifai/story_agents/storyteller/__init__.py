"""Storyteller agent and configuration."""
