"""Storytelling tools: citations, evidence evaluation, narrative writing."""
