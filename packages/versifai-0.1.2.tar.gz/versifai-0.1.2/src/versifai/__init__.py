"""Versifai — Agentic AI framework for data engineering, science, and storytelling."""

__version__ = "0.1.2"
