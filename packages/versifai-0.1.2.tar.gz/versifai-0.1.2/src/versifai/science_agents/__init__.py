"""Data science and research agents."""

from versifai.science_agents.scientist.agent import DataScientistAgent
from versifai.science_agents.scientist.config import ResearchConfig

__all__ = [
    "DataScientistAgent",
    "ResearchConfig",
]
