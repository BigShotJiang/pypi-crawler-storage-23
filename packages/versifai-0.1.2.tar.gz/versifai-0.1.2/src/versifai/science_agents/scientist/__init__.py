"""Data scientist agent and configuration."""
