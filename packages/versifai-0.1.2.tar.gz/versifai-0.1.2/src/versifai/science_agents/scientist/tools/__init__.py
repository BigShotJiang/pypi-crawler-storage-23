"""Science agent tools: statistical analysis, modeling, literature review."""
