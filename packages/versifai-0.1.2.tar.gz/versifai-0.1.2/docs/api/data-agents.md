# Data Agents

The `versifai.data_agents` package provides agents for data engineering and quality validation.

## DataEngineerAgent

::: versifai.data_agents.engineer.agent.DataEngineerAgent

## DataAnalystAgent

::: versifai.data_agents.analyst.agent.DataAnalystAgent

## Configuration

::: versifai.data_agents.engineer.config.ProjectConfig

::: versifai.data_agents.engineer.config.JoinKeyConfig

::: versifai.data_agents.engineer.config.AlternativeKeyConfig

::: versifai.data_agents.engineer.config.MetadataColumnConfig

::: versifai.data_agents.engineer.config.DataSourceHint

::: versifai.data_agents.engineer.config.SourceProcessingHint

::: versifai.data_agents.engineer.config.SourceFileHint

## Data Models

::: versifai.data_agents.models.source.FileInfo

::: versifai.data_agents.models.source.FileGroup

::: versifai.data_agents.models.source.DataSource

::: versifai.data_agents.models.schema.ColumnDefinition

::: versifai.data_agents.models.schema.TargetSchema

::: versifai.data_agents.models.state.SourceStatus

::: versifai.data_agents.models.state.SourceState

::: versifai.data_agents.models.state.AgentState
