# Core Framework

The `versifai.core` package provides the shared agentic infrastructure: the ReAct loop engine, LLM client, memory management, tool system, and configuration.

## Agent Base

::: versifai.core.agent.BaseAgent

## LLM Client

::: versifai.core.llm.LLMClient

::: versifai.core.llm.LLMResponse

## Memory

::: versifai.core.memory.AgentMemory

## Display

::: versifai.core.display.AgentDisplay

## Configuration

::: versifai.core.config.CatalogConfig

::: versifai.core.config.AgentSettings

## Tool System

::: versifai.core.tools.base.BaseTool

::: versifai.core.tools.base.ToolResult

::: versifai.core.tools.registry.ToolRegistry

## Run Management

::: versifai.core.run_manager.RunState

::: versifai.core.run_manager.AgentDependency

::: versifai.core.run_manager.generate_run_id

::: versifai.core.run_manager.init_run_directory

::: versifai.core.run_manager.resolve_dependency

::: versifai.core.run_manager.resolve_run_path

::: versifai.core.run_manager.list_runs
