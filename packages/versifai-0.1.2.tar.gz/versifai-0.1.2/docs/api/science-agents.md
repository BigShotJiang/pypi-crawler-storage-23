# Science Agents

The `versifai.science_agents` package provides agents for autonomous research analysis.

## DataScientistAgent

::: versifai.science_agents.scientist.agent.DataScientistAgent

## Configuration

::: versifai.science_agents.scientist.config.ResearchConfig

::: versifai.science_agents.scientist.config.AnalysisTheme

::: versifai.science_agents.scientist.config.SilverDatasetSpec

::: versifai.science_agents.scientist.config.ResearchReference

::: versifai.science_agents.scientist.config.ResearchQuestion
