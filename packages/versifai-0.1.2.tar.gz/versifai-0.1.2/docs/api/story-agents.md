# Story Agents

The `versifai.story_agents` package provides agents for transforming research into narrative reports.

## StoryTellerAgent

::: versifai.story_agents.storyteller.agent.StoryTellerAgent

## Configuration

::: versifai.story_agents.storyteller.config.StorytellerConfig

::: versifai.story_agents.storyteller.config.NarrativeSection

::: versifai.story_agents.storyteller.config.EvidenceThreshold

::: versifai.story_agents.storyteller.config.StyleGuide

::: versifai.story_agents.storyteller.config.OutputFormat
