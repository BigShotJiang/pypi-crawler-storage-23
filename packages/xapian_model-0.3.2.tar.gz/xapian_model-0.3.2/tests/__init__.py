"""Test suite for the xapian_model package."""

from __future__ import annotations
