"""
Base Algorithm Class for New Algorithms
========================================

Provides common functionality for all MHA algorithms including:
- Random solution generation
- Boundary handling
- Levy flight integration support

Author: MHA Flow Development Team
License: MIT
"""

import numpy as np
from typing import Tuple


class BaseAlgorithm:
    """Base class for all metaheuristic algorithms with Levy flight support"""
    
    def __init__(self, population_size: int = 30, max_iterations: int = 100):
        self.population_size = population_size
        self.max_iterations = max_iterations
        self._levy_engine = None
    
    def create_random_solution(self, bounds: Tuple[float, float], dimensions: int) -> np.ndarray:
        """Create random solution within bounds"""
        return np.random.uniform(bounds[0], bounds[1], dimensions)
    
    def clip_solution(self, solution: np.ndarray, bounds: Tuple[float, float]) -> np.ndarray:
        """Clip solution to bounds"""
        return np.clip(solution, bounds[0], bounds[1])
    
    def apply_levy_flight(self, position: np.ndarray, best: np.ndarray, 
                         bounds: Tuple[float, float], iteration: int) -> np.ndarray:
        """Apply Levy flight if available"""
        try:
            from ..levy_flight_engine import integrate_levy_flight
            return integrate_levy_flight(
                self, position, best, bounds, iteration, self.max_iterations
            )
        except:
            return position
