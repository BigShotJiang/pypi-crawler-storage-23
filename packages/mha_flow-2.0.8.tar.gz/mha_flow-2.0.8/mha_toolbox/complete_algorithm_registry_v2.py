"""
Complete Algorithm Registry
============================

Comprehensive registry of all 100+ metaheuristic algorithms available in MHA Flow.

This file maintains metadata for all algorithms including:
- Algorithm names and aliases
- Categories and types
- Parameters and their descriptions
- References and citations
- Performance characteristics

Author: MHA Flow Development Team
License: MIT
"""

from typing import Dict, List, Any


class AlgorithmRegistry:
    """Central registry for all MHA algorithms"""
    
    def __init__(self):
        self.algorithms = self._initialize_registry()
    
    def _initialize_registry(self) -> Dict[str, Dict[str, Any]]:
        """Initialize complete algorithm registry"""
        
        registry = {}
        
        # ====================BIO-INSPIRED ALGORITHMS ====================
        
        # Swarm Intelligence
        registry.update({
# AUTO-GENERATED - DO NOT EDIT MANUALLY
# Generated from mha_toolbox/algorithms/*.py files


    'ABC': {
        'name': 'Artificial Bee Colony',
        'aliases': ['abc'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2005,
        'author': 'Karaboga',
        'file': 'abc.py',
        'levy_flight_support': True,
        'description': 'Artificial Bee Colony optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ACO': {
        'name': 'Ant Colony Optimization',
        'aliases': ['aco'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 1992,
        'author': 'Dorigo',
        'file': 'aco.py',
        'levy_flight_support': True,
        'description': 'Ant Colony Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'AEO': {
        'name': 'Artificial Ecosystem Optimization',
        'aliases': ['aeo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2019,
        'author': 'Zhao et al.',
        'file': 'aeo.py',
        'levy_flight_support': True,
        'description': 'Artificial Ecosystem Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'AFSA': {
        'name': 'Artificial Fish Swarm Algorithm',
        'aliases': ['afsa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2002,
        'author': 'Li et al.',
        'file': 'afsa.py',
        'levy_flight_support': True,
        'description': 'Artificial Fish Swarm Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ALO': {
        'name': 'Ant Lion Optimizer',
        'aliases': ['alo'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2015,
        'author': 'Mirjalili',
        'file': 'alo.py',
        'levy_flight_support': True,
        'description': 'Ant Lion Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ALO_NEW': {
        'name': 'Alo New',
        'aliases': ['alo_new'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'alo_new.py',
        'levy_flight_support': True,
        'description': 'Alo New optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ANTS': {
        'name': 'Ants',
        'aliases': ['ants'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'ants.py',
        'levy_flight_support': True,
        'description': 'Ants optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'AO': {
        'name': 'Aquila Optimizer',
        'aliases': ['ao'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Abualigah et al.',
        'file': 'ao.py',
        'levy_flight_support': True,
        'description': 'Aquila Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'AOA': {
        'name': 'Arithmetic Optimization Algorithm',
        'aliases': ['aoa'],
        'category': 'Mathematics-based',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Abualigah et al.',
        'file': 'aoa.py',
        'levy_flight_support': True,
        'description': 'Arithmetic Optimization Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'AS_ANT': {
        'name': 'As Ant',
        'aliases': ['as_ant'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'as_ant.py',
        'levy_flight_support': True,
        'description': 'As Ant optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ASO': {
        'name': 'Atom Search Optimization',
        'aliases': ['aso'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2019,
        'author': 'Zhao et al.',
        'file': 'aso.py',
        'levy_flight_support': True,
        'description': 'Atom Search Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BA': {
        'name': 'Bat Algorithm',
        'aliases': ['ba'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2010,
        'author': 'Yang',
        'file': 'ba.py',
        'levy_flight_support': True,
        'description': 'Bat Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BAT': {
        'name': 'Bat Algorithm',
        'aliases': ['bat'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2010,
        'author': 'Yang',
        'file': 'bat.py',
        'levy_flight_support': True,
        'description': 'Bat Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BBBC': {
        'name': 'Bbbc',
        'aliases': ['bbbc'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'bbbc.py',
        'levy_flight_support': True,
        'description': 'Bbbc optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BBO': {
        'name': 'Biogeography-Based Optimization',
        'aliases': ['bbo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2008,
        'author': 'Simon',
        'file': 'bbo.py',
        'levy_flight_support': True,
        'description': 'Biogeography-Based Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BFO': {
        'name': 'Bfo',
        'aliases': ['bfo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'bfo.py',
        'levy_flight_support': True,
        'description': 'Bfo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BH': {
        'name': 'Bh',
        'aliases': ['bh'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'bh.py',
        'levy_flight_support': True,
        'description': 'Bh optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'BOA': {
        'name': 'Boa',
        'aliases': ['boa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'boa.py',
        'levy_flight_support': True,
        'description': 'Boa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CA': {
        'name': 'Ca',
        'aliases': ['ca'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'ca.py',
        'levy_flight_support': True,
        'description': 'Ca optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CEM': {
        'name': 'Cem',
        'aliases': ['cem'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'cem.py',
        'levy_flight_support': True,
        'description': 'Cem optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CFO': {
        'name': 'Central Force Optimization',
        'aliases': ['cfo'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2008,
        'author': 'Formato',
        'file': 'cfo.py',
        'levy_flight_support': True,
        'description': 'Central Force Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CGO': {
        'name': 'Cgo',
        'aliases': ['cgo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'cgo.py',
        'levy_flight_support': True,
        'description': 'Cgo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CHIO': {
        'name': 'Coronavirus Herd Immunity Optimization',
        'aliases': ['chio'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Al-Betar et al.',
        'file': 'chio.py',
        'levy_flight_support': True,
        'description': 'Coronavirus Herd Immunity Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CHOA': {
        'name': 'Choa',
        'aliases': ['choa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'choa.py',
        'levy_flight_support': True,
        'description': 'Choa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'COA': {
        'name': 'Coyote Optimization Algorithm',
        'aliases': ['coa'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2018,
        'author': 'Pierezan & Coelho',
        'file': 'coa.py',
        'levy_flight_support': True,
        'description': 'Coyote Optimization Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CRO': {
        'name': 'Coral Reefs Optimization',
        'aliases': ['cro'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2014,
        'author': 'Salcedo-Sanz et al.',
        'file': 'cro.py',
        'levy_flight_support': True,
        'description': 'Coral Reefs Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CSA': {
        'name': 'Crow Search Algorithm',
        'aliases': ['csa'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Askarzadeh',
        'file': 'csa.py',
        'levy_flight_support': True,
        'description': 'Crow Search Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CSS': {
        'name': 'Css',
        'aliases': ['css'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'css.py',
        'levy_flight_support': True,
        'description': 'Css optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'CUCKOO': {
        'name': 'Cuckoo',
        'aliases': ['cuckoo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'cuckoo.py',
        'levy_flight_support': True,
        'description': 'Cuckoo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'DA': {
        'name': 'Da',
        'aliases': ['da'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'da.py',
        'levy_flight_support': True,
        'description': 'Da optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'DE': {
        'name': 'Differential Evolution',
        'aliases': ['de'],
        'category': 'Evolutionary',
        'type': 'Metaheuristic',
        'year': 1997,
        'author': 'Storn & Price',
        'file': 'de.py',
        'levy_flight_support': True,
        'description': 'Differential Evolution optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'DMOA': {
        'name': 'Dmoa',
        'aliases': ['dmoa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'dmoa.py',
        'levy_flight_support': True,
        'description': 'Dmoa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'EHO': {
        'name': 'Eho',
        'aliases': ['eho'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'eho.py',
        'levy_flight_support': True,
        'description': 'Eho optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'EO': {
        'name': 'Equilibrium Optimizer',
        'aliases': ['eo'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Faramarzi et al.',
        'file': 'eo.py',
        'levy_flight_support': True,
        'description': 'Equilibrium Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'EPO': {
        'name': 'Epo',
        'aliases': ['epo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'epo.py',
        'levy_flight_support': True,
        'description': 'Epo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'EXTENDED_ALGORITHMS': {
        'name': 'Extended Algorithms',
        'aliases': ['extended_algorithms'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'extended_algorithms.py',
        'levy_flight_support': True,
        'description': 'Extended Algorithms optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FA': {
        'name': 'Firefly Algorithm',
        'aliases': ['fa'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2008,
        'author': 'Yang',
        'file': 'fa.py',
        'levy_flight_support': True,
        'description': 'Firefly Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FBI': {
        'name': 'Fbi',
        'aliases': ['fbi'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'fbi.py',
        'levy_flight_support': True,
        'description': 'Fbi optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FIREFLY': {
        'name': 'Firefly',
        'aliases': ['firefly'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'firefly.py',
        'levy_flight_support': True,
        'description': 'Firefly optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FOA': {
        'name': 'Foa',
        'aliases': ['foa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'foa.py',
        'levy_flight_support': True,
        'description': 'Foa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FPA': {
        'name': 'Flower Pollination Algorithm',
        'aliases': ['fpa'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2012,
        'author': 'Yang',
        'file': 'fpa.py',
        'levy_flight_support': True,
        'description': 'Flower Pollination Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'FWA': {
        'name': 'Fwa',
        'aliases': ['fwa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'fwa.py',
        'levy_flight_support': True,
        'description': 'Fwa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GA': {
        'name': 'Genetic Algorithm',
        'aliases': ['ga'],
        'category': 'Evolutionary',
        'type': 'Metaheuristic',
        'year': 1975,
        'author': 'Holland',
        'file': 'ga.py',
        'levy_flight_support': True,
        'description': 'Genetic Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GAO': {
        'name': 'Gao',
        'aliases': ['gao'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'gao.py',
        'levy_flight_support': True,
        'description': 'Gao optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GBMO': {
        'name': 'Gbmo',
        'aliases': ['gbmo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'gbmo.py',
        'levy_flight_support': True,
        'description': 'Gbmo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GBO': {
        'name': 'Gradient-Based Optimizer',
        'aliases': ['gbo'],
        'category': 'Mathematics-based',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Ahmadianfar et al.',
        'file': 'gbo.py',
        'levy_flight_support': True,
        'description': 'Gradient-Based Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GCO': {
        'name': 'Gco',
        'aliases': ['gco'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'gco.py',
        'levy_flight_support': True,
        'description': 'Gco optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GOA': {
        'name': 'Grasshopper Optimization Algorithm',
        'aliases': ['goa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2017,
        'author': 'Saremi et al.',
        'file': 'goa.py',
        'levy_flight_support': True,
        'description': 'Grasshopper Optimization Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GSA': {
        'name': 'Gravitational Search Algorithm',
        'aliases': ['gsa'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2009,
        'author': 'Rashedi et al.',
        'file': 'gsa.py',
        'levy_flight_support': True,
        'description': 'Gravitational Search Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GSK': {
        'name': 'Gsk',
        'aliases': ['gsk'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'gsk.py',
        'levy_flight_support': True,
        'description': 'Gsk optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GSO': {
        'name': 'Glowworm Swarm Optimization',
        'aliases': ['gso'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2005,
        'author': 'Krishnanand & Ghose',
        'file': 'gso.py',
        'levy_flight_support': True,
        'description': 'Glowworm Swarm Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GTO': {
        'name': 'Gorilla Troops Optimizer',
        'aliases': ['gto'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Abdollahzadeh et al.',
        'file': 'gto.py',
        'levy_flight_support': True,
        'description': 'Gorilla Troops Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'GWO': {
        'name': 'Grey Wolf Optimizer',
        'aliases': ['gwo'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2014,
        'author': 'Mirjalili et al.',
        'file': 'gwo.py',
        'levy_flight_support': True,
        'description': 'Grey Wolf Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HBA': {
        'name': 'Honey Badger Algorithm',
        'aliases': ['hba'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Hashim et al.',
        'file': 'hba.py',
        'levy_flight_support': True,
        'description': 'Honey Badger Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HC': {
        'name': 'Hc',
        'aliases': ['hc'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'hc.py',
        'levy_flight_support': True,
        'description': 'Hc optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HGS': {
        'name': 'Hunger Games Search',
        'aliases': ['hgs'],
        'category': 'Human-inspired',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Yang et al.',
        'file': 'hgs.py',
        'levy_flight_support': True,
        'description': 'Hunger Games Search optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HGSO': {
        'name': 'Hgso',
        'aliases': ['hgso'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'hgso.py',
        'levy_flight_support': True,
        'description': 'Hgso optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HHO': {
        'name': 'Harris Hawks Optimization',
        'aliases': ['hho'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2019,
        'author': 'Heidari et al.',
        'file': 'hho.py',
        'levy_flight_support': True,
        'description': 'Harris Hawks Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HS': {
        'name': 'Harmony Search',
        'aliases': ['hs'],
        'category': 'Music-inspired',
        'type': 'Metaheuristic',
        'year': 2001,
        'author': 'Geem et al.',
        'file': 'hs.py',
        'levy_flight_support': True,
        'description': 'Harmony Search optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'HYBRID_ADVANCED': {
        'name': 'Hybrid Advanced',
        'aliases': ['hybrid_advanced'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'hybrid_advanced.py',
        'levy_flight_support': True,
        'description': 'Hybrid Advanced optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'ICA': {
        'name': 'Imperialist Competitive Algorithm',
        'aliases': ['ica'],
        'category': 'Socio-inspired',
        'type': 'Metaheuristic',
        'year': 2007,
        'author': 'Atashpaz & Lucas',
        'file': 'ica.py',
        'levy_flight_support': True,
        'description': 'Imperialist Competitive Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'INNOV': {
        'name': 'Innov',
        'aliases': ['innov'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'innov.py',
        'levy_flight_support': True,
        'description': 'Innov optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'IWO': {
        'name': 'Invasive Weed Optimization',
        'aliases': ['iwo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2006,
        'author': 'Mehrabian & Lucas',
        'file': 'iwo.py',
        'levy_flight_support': True,
        'description': 'Invasive Weed Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'JS': {
        'name': 'Jellyfish Search',
        'aliases': ['js'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Chou & Truong',
        'file': 'js.py',
        'levy_flight_support': True,
        'description': 'Jellyfish Search optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'KH': {
        'name': 'Kh',
        'aliases': ['kh'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'kh.py',
        'levy_flight_support': True,
        'description': 'Kh optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'KOA': {
        'name': 'Koa',
        'aliases': ['koa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'koa.py',
        'levy_flight_support': True,
        'description': 'Koa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'LCA': {
        'name': 'Lca',
        'aliases': ['lca'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'lca.py',
        'levy_flight_support': True,
        'description': 'Lca optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'LCBO': {
        'name': 'Lcbo',
        'aliases': ['lcbo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'lcbo.py',
        'levy_flight_support': True,
        'description': 'Lcbo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'LEVY_FLIGHT_UNIVERSAL': {
        'name': 'Levy Flight Universal',
        'aliases': ['levy_flight_universal'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'levy_flight_universal.py',
        'levy_flight_support': True,
        'description': 'Levy Flight Universal optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'LSA': {
        'name': 'Lsa',
        'aliases': ['lsa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'lsa.py',
        'levy_flight_support': True,
        'description': 'Lsa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MBO': {
        'name': 'Monarch Butterfly Optimization',
        'aliases': ['mbo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2015,
        'author': 'Wang et al.',
        'file': 'mbo.py',
        'levy_flight_support': True,
        'description': 'Monarch Butterfly Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MFO': {
        'name': 'Moth Flame Optimization',
        'aliases': ['mfo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2015,
        'author': 'Mirjalili',
        'file': 'mfo.py',
        'levy_flight_support': True,
        'description': 'Moth Flame Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MPA': {
        'name': 'Marine Predators Algorithm',
        'aliases': ['mpa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Faramarzi et al.',
        'file': 'mpa.py',
        'levy_flight_support': True,
        'description': 'Marine Predators Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MRFO': {
        'name': 'Mrfo',
        'aliases': ['mrfo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'mrfo.py',
        'levy_flight_support': True,
        'description': 'Mrfo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MSA': {
        'name': 'Msa',
        'aliases': ['msa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'msa.py',
        'levy_flight_support': True,
        'description': 'Msa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'MVO': {
        'name': 'Multi-Verse Optimizer',
        'aliases': ['mvo'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Mirjalili et al.',
        'file': 'mvo.py',
        'levy_flight_support': True,
        'description': 'Multi-Verse Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'NMR': {
        'name': 'Nmr',
        'aliases': ['nmr'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'nmr.py',
        'levy_flight_support': True,
        'description': 'Nmr optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'NRO': {
        'name': 'Nro',
        'aliases': ['nro'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'nro.py',
        'levy_flight_support': True,
        'description': 'Nro optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'PFA': {
        'name': 'Pfa',
        'aliases': ['pfa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'pfa.py',
        'levy_flight_support': True,
        'description': 'Pfa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'PM': {
        'name': 'Pm',
        'aliases': ['pm'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'pm.py',
        'levy_flight_support': True,
        'description': 'Pm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'PSO': {
        'name': 'Particle Swarm Optimization',
        'aliases': ['pso'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 1995,
        'author': 'Kennedy & Eberhart',
        'file': 'pso.py',
        'levy_flight_support': True,
        'description': 'Particle Swarm Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'QSA': {
        'name': 'Qsa',
        'aliases': ['qsa'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'qsa.py',
        'levy_flight_support': True,
        'description': 'Qsa optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'RSA': {
        'name': 'Reptile Search Algorithm',
        'aliases': ['rsa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2022,
        'author': 'Abualigah et al.',
        'file': 'rsa.py',
        'levy_flight_support': True,
        'description': 'Reptile Search Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'RUN': {
        'name': 'Run',
        'aliases': ['run'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'run.py',
        'levy_flight_support': True,
        'description': 'Run optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SA': {
        'name': 'Simulated Annealing',
        'aliases': ['sa'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 1983,
        'author': 'Kirkpatrick et al.',
        'file': 'sa.py',
        'levy_flight_support': True,
        'description': 'Simulated Annealing optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SAR': {
        'name': 'Sar',
        'aliases': ['sar'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'sar.py',
        'levy_flight_support': True,
        'description': 'Sar optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SCA': {
        'name': 'Sine Cosine Algorithm',
        'aliases': ['sca'],
        'category': 'Mathematics-based',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Mirjalili',
        'file': 'sca.py',
        'levy_flight_support': True,
        'description': 'Sine Cosine Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SCSO': {
        'name': 'Scso',
        'aliases': ['scso'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'scso.py',
        'levy_flight_support': True,
        'description': 'Scso optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SFLA': {
        'name': 'Sfla',
        'aliases': ['sfla'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'sfla.py',
        'levy_flight_support': True,
        'description': 'Sfla optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SFO': {
        'name': 'Sailfish Optimizer',
        'aliases': ['sfo'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2019,
        'author': 'Shadravan et al.',
        'file': 'sfo.py',
        'levy_flight_support': True,
        'description': 'Sailfish Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SHO': {
        'name': 'Spotted Hyena Optimizer',
        'aliases': ['sho'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2017,
        'author': 'Dhiman & Kumar',
        'file': 'sho.py',
        'levy_flight_support': True,
        'description': 'Spotted Hyena Optimizer optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SLO': {
        'name': 'Slo',
        'aliases': ['slo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'slo.py',
        'levy_flight_support': True,
        'description': 'Slo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SMA': {
        'name': 'Slime Mould Algorithm',
        'aliases': ['sma'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Li et al.',
        'file': 'sma.py',
        'levy_flight_support': True,
        'description': 'Slime Mould Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SOA_SEAGULL': {
        'name': 'Soa Seagull',
        'aliases': ['soa_seagull'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'soa_seagull.py',
        'levy_flight_support': True,
        'description': 'Soa Seagull optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SOS': {
        'name': 'Sos',
        'aliases': ['sos'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'sos.py',
        'levy_flight_support': True,
        'description': 'Sos optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SPBO': {
        'name': 'Spbo',
        'aliases': ['spbo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'spbo.py',
        'levy_flight_support': True,
        'description': 'Spbo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SPIDER': {
        'name': 'Spider',
        'aliases': ['spider'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'spider.py',
        'levy_flight_support': True,
        'description': 'Spider optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SSA': {
        'name': 'Salp Swarm Algorithm',
        'aliases': ['ssa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2017,
        'author': 'Mirjalili et al.',
        'file': 'ssa.py',
        'levy_flight_support': True,
        'description': 'Salp Swarm Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SSA_SQUIRREL': {
        'name': 'Ssa Squirrel',
        'aliases': ['ssa_squirrel'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'ssa_squirrel.py',
        'levy_flight_support': True,
        'description': 'Ssa Squirrel optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'SSD': {
        'name': 'Ssd',
        'aliases': ['ssd'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'ssd.py',
        'levy_flight_support': True,
        'description': 'Ssd optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'THRO': {
        'name': 'Thro',
        'aliases': ['thro'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'thro.py',
        'levy_flight_support': True,
        'description': 'Thro optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'TLBO': {
        'name': 'Tlbo',
        'aliases': ['tlbo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'tlbo.py',
        'levy_flight_support': True,
        'description': 'Tlbo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'TS': {
        'name': 'Ts',
        'aliases': ['ts'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'ts.py',
        'levy_flight_support': True,
        'description': 'Ts optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'TSO': {
        'name': 'Tuna Swarm Optimization',
        'aliases': ['tso'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2021,
        'author': 'Xie et al.',
        'file': 'tso.py',
        'levy_flight_support': True,
        'description': 'Tuna Swarm Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'TWO': {
        'name': 'Tug of War Optimization',
        'aliases': ['two'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Kaveh & Zolghadr',
        'file': 'two.py',
        'levy_flight_support': True,
        'description': 'Tug of War Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'VCS': {
        'name': 'Virus Colony Search',
        'aliases': ['vcs'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Li et al.',
        'file': 'vcs.py',
        'levy_flight_support': True,
        'description': 'Virus Colony Search optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'VNS': {
        'name': 'Vns',
        'aliases': ['vns'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'vns.py',
        'levy_flight_support': True,
        'description': 'Vns optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'WCA': {
        'name': 'Wca',
        'aliases': ['wca'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'wca.py',
        'levy_flight_support': True,
        'description': 'Wca optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'WDO': {
        'name': 'Wind Driven Optimization',
        'aliases': ['wdo'],
        'category': 'Physics-based',
        'type': 'Metaheuristic',
        'year': 2013,
        'author': 'Bayraktar et al.',
        'file': 'wdo.py',
        'levy_flight_support': True,
        'description': 'Wind Driven Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'WHO': {
        'name': 'Wildebeest Herd Optimization',
        'aliases': ['who'],
        'category': 'Bio-inspired',
        'type': 'Metaheuristic',
        'year': 2019,
        'author': 'Amali & Dinakaran',
        'file': 'who.py',
        'levy_flight_support': True,
        'description': 'Wildebeest Herd Optimization optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'WOA': {
        'name': 'Whale Optimization Algorithm',
        'aliases': ['woa'],
        'category': 'Swarm Intelligence',
        'type': 'Metaheuristic',
        'year': 2016,
        'author': 'Mirjalili & Lewis',
        'file': 'woa.py',
        'levy_flight_support': True,
        'description': 'Whale Optimization Algorithm optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    'WWO': {
        'name': 'Wwo',
        'aliases': ['wwo'],
        'category': 'Other',
        'type': 'Metaheuristic',
        'year': 2020,
        'author': 'Various',
        'file': 'wwo.py',
        'levy_flight_support': True,
        'description': 'Wwo optimization algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'optimization']
    },

    # ==================== HYBRID ALGORITHMS ====================
    
    'ABC_DE': {
        'name': 'ABC-DE Hybrid',
        'aliases': ['abc_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/abc_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Artificial Bee Colony and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'ABC_GWO': {
        'name': 'ABC-GWO Hybrid',
        'aliases': ['abc_gwo'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/abc_gwo_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Artificial Bee Colony and Grey Wolf Optimizer',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'ACO_PSO': {
        'name': 'ACO-PSO Hybrid',
        'aliases': ['aco_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/aco_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Ant Colony Optimization and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'combinatorial', 'hybrid_problems']
    },
    'ADAPTIVE_MS': {
        'name': 'Adaptive Multi-Strategy',
        'aliases': ['adaptive_ms', 'ams'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Adaptive Research',
        'file': 'hybrid/adaptive_multi_strategy.py',
        'levy_flight_support': True,
        'description': 'Adaptive combination of multiple strategies',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['adaptive', 'dynamic', 'complex_problems']
    },
    'ALO_PSO': {
        'name': 'ALO-PSO Hybrid',
        'aliases': ['alo_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/alo_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Ant Lion Optimizer and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'AO_WOA': {
        'name': 'AO-WOA Hybrid',
        'aliases': ['ao_woa'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2019,
        'author': 'Hybrid Research',
        'file': 'hybrid/ao_woa_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Aquila Optimizer and Whale Optimization',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'CS_GA': {
        'name': 'CS-GA Hybrid',
        'aliases': ['cs_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/cs_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Cuckoo Search and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'exploration']
    },
    'DA_GA': {
        'name': 'DA-GA Hybrid',
        'aliases': ['da_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/da_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Dragonfly Algorithm and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'DE_PSO': {
        'name': 'DE-PSO Hybrid',
        'aliases': ['de_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/de_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Differential Evolution and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'FA_DE': {
        'name': 'FA-DE Hybrid',
        'aliases': ['fa_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/fa_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Firefly Algorithm and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'FA_GA': {
        'name': 'FA-GA Hybrid',
        'aliases': ['fa_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/fa_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Firefly Algorithm and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'exploration']
    },
    'FPA_GA': {
        'name': 'FPA-GA Hybrid',
        'aliases': ['fpa_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/fpa_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Flower Pollination Algorithm and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'exploration']
    },
    'GA_SA': {
        'name': 'GA-SA Hybrid',
        'aliases': ['ga_sa'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2016,
        'author': 'Hybrid Research',
        'file': 'hybrid/ga_sa_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Genetic Algorithm and Simulated Annealing',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'exploitation', 'local_search']
    },
    'GWO_DE': {
        'name': 'GWO-DE Hybrid',
        'aliases': ['gwo_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/gwo_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Grey Wolf Optimizer and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'GWO_MFO': {
        'name': 'GWO-MFO Hybrid',
        'aliases': ['gwo_mfo'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/gwo_mfo_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Grey Wolf Optimizer and Moth Flame Optimization',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'GWO_PSO': {
        'name': 'GWO-PSO Hybrid',
        'aliases': ['gwo_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/gwo_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Grey Wolf Optimizer and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'GWO_WOA': {
        'name': 'GWO-WOA Hybrid',
        'aliases': ['gwo_woa'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2019,
        'author': 'Hybrid Research',
        'file': 'hybrid/gwo_woa_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Grey Wolf Optimizer and Whale Optimization',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'HBA_GWO': {
        'name': 'HBA-GWO Hybrid',
        'aliases': ['hba_gwo'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Hybrid Research',
        'file': 'hybrid/hba_gwo_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Honey Badger Algorithm and Grey Wolf Optimizer',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'HS_DE': {
        'name': 'HS-DE Hybrid',
        'aliases': ['hs_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/hs_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Harmony Search and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'exploitation']
    },
    'JS_PSO': {
        'name': 'JS-PSO Hybrid',
        'aliases': ['js_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/js_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Jellyfish Search and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'KH_PSO': {
        'name': 'KH-PSO Hybrid',
        'aliases': ['kh_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/kh_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Krill Herd and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'MFO_DE': {
        'name': 'MFO-DE Hybrid',
        'aliases': ['mfo_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/mfo_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Moth Flame Optimization and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'MPA_DE': {
        'name': 'MPA-DE Hybrid',
        'aliases': ['mpa_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Hybrid Research',
        'file': 'hybrid/mpa_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Marine Predators Algorithm and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'PSO_GA': {
        'name': 'PSO-GA Hybrid',
        'aliases': ['pso_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/pso_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Particle Swarm and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'PSO_MFO': {
        'name': 'PSO-MFO Hybrid',
        'aliases': ['pso_mfo'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2018,
        'author': 'Hybrid Research',
        'file': 'hybrid/pso_mfo_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Particle Swarm and Moth Flame Optimization',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'PSO_SCA': {
        'name': 'PSO-SCA Hybrid',
        'aliases': ['pso_sca'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2019,
        'author': 'Hybrid Research',
        'file': 'hybrid/pso_sca_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Particle Swarm and Sine Cosine Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'exploration']
    },
    'SA_PSO': {
        'name': 'SA-PSO Hybrid',
        'aliases': ['sa_pso'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/sa_pso_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Simulated Annealing and Particle Swarm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'exploitation', 'local_search']
    },
    'SMA_DE': {
        'name': 'SMA-DE Hybrid',
        'aliases': ['sma_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Hybrid Research',
        'file': 'hybrid/sma_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Slime Mould Algorithm and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'SMA_GA': {
        'name': 'SMA-GA Hybrid',
        'aliases': ['sma_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Hybrid Research',
        'file': 'hybrid/sma_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Slime Mould Algorithm and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'SSA_DE': {
        'name': 'SSA-DE Hybrid',
        'aliases': ['ssa_de'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2019,
        'author': 'Hybrid Research',
        'file': 'hybrid/ssa_de_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Salp Swarm Algorithm and Differential Evolution',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    'TS_GA': {
        'name': 'TS-GA Hybrid',
        'aliases': ['ts_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2017,
        'author': 'Hybrid Research',
        'file': 'hybrid/ts_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Tabu Search and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'combinatorial', 'local_search']
    },
    'WOA_GA': {
        'name': 'WOA-GA Hybrid',
        'aliases': ['woa_ga'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2019,
        'author': 'Hybrid Research',
        'file': 'hybrid/woa_ga_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Whale Optimization and Genetic Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'balanced']
    },
    'WOA_SMA': {
        'name': 'WOA-SMA Hybrid',
        'aliases': ['woa_sma'],
        'category': 'Hybrid',
        'type': 'Hybrid',
        'year': 2020,
        'author': 'Hybrid Research',
        'file': 'hybrid/woa_sma_hybrid.py',
        'levy_flight_support': True,
        'description': 'Hybrid of Whale Optimization and Slime Mould Algorithm',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'high_performance']
    },
    
    # ==================== GENETIC & EVOLUTIONARY ALGORITHMS ====================
    
    'GA': {
        'name': 'Genetic Algorithm',
        'aliases': ['ga', 'genetic'],
        'category': 'Evolutionary',
        'type': 'Genetic',
        'year': 1975,
        'author': 'Holland',
        'file': 'genetic_algorithm.py',
        'levy_flight_support': False,
        'description': 'Standard Genetic Algorithm with mutation and crossover operators. Mutation introduces random changes for exploration, while crossover combines features of good solutions for exploitation.',
        'parameters': ['population_size', 'max_iterations', 'mutation_rate', 'crossover_rate', 'elite_ratio'],
        'best_for': ['continuous', 'discrete', 'multimodal', 'robust_optimization'],
        'operators': {
            'mutation': ['uniform', 'gaussian', 'polynomial', 'boundary'],
            'crossover': ['single_point', 'two_point', 'uniform', 'arithmetic', 'simulated_binary'],
            'selection': 'tournament'
        },
        'features': ['adaptive_operators', 'elitism', 'diversity_maintenance']
    },
    
    'EPD_GA': {
        'name': 'EPD-GA (Evolutionary Population Dynamics GA)',
        'aliases': ['epdga', 'epd_ga', 'epd-ga'],
        'category': 'Hybrid',
        'type': 'Evolutionary-Hybrid',
        'year': 2025,
        'author': 'MHA Flow',
        'file': 'epd_ga.py',
        'levy_flight_support': False,
        'description': 'Hybrid algorithm combining Genetic Operators with Evolutionary Population Dynamics. Uses mutation for exploration, crossover for exploitation, and EPD for self-organized criticality to reposition worst solutions near best ones.',
        'parameters': ['population_size', 'max_iterations', 'mutation_rate', 'crossover_rate', 'epd_frequency', 'epd_removal_ratio', 'elite_ratio'],
        'best_for': ['continuous', 'multimodal', 'complex_landscapes', 'balanced_search'],
        'operators': {
            'mutation': ['uniform', 'gaussian', 'polynomial', 'boundary'],
            'crossover': ['single_point', 'two_point', 'uniform', 'arithmetic', 'simulated_binary'],
            'selection': 'tournament',
            'population_dynamics': 'Adaptive EPD with self-organized criticality'
        },
        'features': ['adaptive_operators', 'self_organized_criticality', 'elite_preservation', 'dynamic_repositioning']
    },
    
    'EPD_GA_Explorative': {
        'name': 'EPD-GA Explorative',
        'aliases': ['epdga_exp', 'epd_ga_exp'],
        'category': 'Hybrid',
        'type': 'Evolutionary-Hybrid',
        'year': 2025,
        'author': 'MHA Flow',
        'file': 'epd_ga.py',
        'levy_flight_support': False,
        'description': 'Exploration-focused variant of EPD-GA with higher mutation rate and less frequent EPD application.',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'wide_search', 'avoiding_local_optima'],
        'features': ['high_exploration', 'uniform_mutation', 'diversity_focused']
    },
    
    'EPD_GA_Exploitative': {
        'name': 'EPD-GA Exploitative',
        'aliases': ['epdga_expl', 'epd_ga_expl'],
        'category': 'Hybrid',
        'type': 'Evolutionary-Hybrid',
        'year': 2025,
        'author': 'MHA Flow',
        'file': 'epd_ga.py',
        'levy_flight_support': False,
        'description': 'Exploitation-focused variant of EPD-GA with lower mutation rate, higher crossover, and frequent EPD application.',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'unimodal', 'fine_tuning', 'local_refinement'],
        'features': ['high_exploitation', 'frequent_epd', 'convergence_focused']
    },
    
    'EPD_GA_Balanced': {
        'name': 'EPD-GA Balanced',
        'aliases': ['epdga_bal', 'epd_ga_bal'],
        'category': 'Hybrid',
        'type': 'Evolutionary-Hybrid',
        'year': 2025,
        'author': 'MHA Flow',
        'file': 'epd_ga.py',
        'levy_flight_support': False,
        'description': 'Balanced variant of EPD-GA with moderate mutation, crossover, and EPD frequency for general-purpose optimization.',
        'parameters': ['population_size', 'max_iterations'],
        'best_for': ['continuous', 'multimodal', 'general_purpose', 'robust_performance'],
        'features': ['balanced_search', 'adaptive_behavior', 'versatile']
    },
                })
        
        # Add more algorithms from the existing files
        # (This is a subset - the full registry would include all 100+ algorithms)
        
        return registry
    
    def get_algorithm(self, name: str) -> Dict[str, Any]:
        """Get algorithm information by name or alias"""
        # Try direct name match
        if name.upper() in self.algorithms:
            return self.algorithms[name.upper()]
        
        # Try alias match
        for algo_name, algo_info in self.algorithms.items():
            if name.lower() in [alias.lower() for alias in algo_info['aliases']]:
                return algo_info
        
        return None
    
    def list_algorithms(self, category: str = None, levy_support: bool = None) -> List[Dict]:
        """List algorithms with optional filtering"""
        result = []
        
        for name, info in self.algorithms.items():
            if category and info['category'] != category:
                continue
            if levy_support is not None and info['levy_flight_support'] != levy_support:
                continue
            
            result.append({
                'code': name,
                **info
            })
        
        return result
    
    def get_categories(self) -> List[str]:
        """Get list of all algorithm categories"""
        categories = set()
        for info in self.algorithms.values():
            categories.add(info['category'])
        return sorted(list(categories))
    
    def get_statistics(self) -> Dict[str, int]:
        """Get registry statistics"""
        stats = {
            'total': len(self.algorithms),
            'levy_flight_supported': sum(1 for a in self.algorithms.values() if a.get('levy_flight_support', False)),
            'with_levy': sum(1 for a in self.algorithms.values() if a.get('levy_flight_support', False)),
            'bio_inspired': sum(1 for a in self.algorithms.values() if a.get('type') == 'Bio-inspired'),
            'physics_based': sum(1 for a in self.algorithms.values() if a.get('type') == 'Physical'),
            'hybrid': sum(1 for a in self.algorithms.values() if a.get('type') == 'Hybrid'),
        }
        
        # Count by category
        category_counts = {}
        type_counts = {}
        complexity_counts = {}
        
        for algo in self.algorithms.values():
            # Category
            cat = algo.get('category', 'Unknown')
            category_counts[cat] = category_counts.get(cat, 0) + 1
            
            # Type
            typ = algo.get('type', 'Unknown')
            type_counts[typ] = type_counts.get(typ, 0) + 1
            
            # Complexity
            comp = algo.get('complexity', 'medium')
            complexity_counts[comp] = complexity_counts.get(comp, 0) + 1
        
        stats['by_category'] = category_counts
        stats['by_type'] = type_counts
        stats['by_complexity'] = complexity_counts
        
        return stats
    
    def get_total_count(self) -> int:
        """Get total number of algorithms in registry"""
        return len(self.algorithms)
    
    def get_algorithms_by_category(self, category: str) -> List[str]:
        """Get list of algorithm names by category"""
        return [name for name, info in self.algorithms.items() 
                if info.get('category') == category]


# Global registry instance
ALGORITHM_REGISTRY = AlgorithmRegistry()


def get_all_algorithms() -> List[str]:
    """Get list of all algorithm codes"""
    return list(ALGORITHM_REGISTRY.algorithms.keys())


def get_algorithm_info(name: str) -> Dict:
    """Get information about a specific algorithm"""
    return ALGORITHM_REGISTRY.get_algorithm(name)


def search_algorithms(keyword: str) -> List[Dict]:
    """Search algorithms by keyword"""
    results = []
    keyword_lower = keyword.lower()
    
    for name, info in ALGORITHM_REGISTRY.algorithms.items():
        # Search in name, aliases, and description
        search_text = f"{name} {' '.join(info['aliases'])} {info['name']} {info['description']}".lower()
        if keyword_lower in search_text:
            results.append({
                'code': name,
                **info
            })
    
    return results


if __name__ == "__main__":
    print("=" * 70)
    print("MHA Flow - Complete Algorithm Registry")
    print("=" * 70)
    
    stats = ALGORITHM_REGISTRY.get_statistics()
    print(f"\n📊 Registry Statistics:")
    print(f"   Total Algorithms: {stats['total']}")
    print(f"   With Levy Flight Support: {stats['with_levy']}")
    print(f"   Bio-inspired: {stats['bio_inspired']}")
    print(f"   Physics-based: {stats['physics_based']}")
    print(f"   Hybrid: {stats['hybrid']}")
    
    print(f"\n📁 Categories:")
    for category in ALGORITHM_REGISTRY.get_categories():
        count = sum(1 for a in ALGORITHM_REGISTRY.algorithms.values() if a['category'] == category)
        print(f"   - {category}: {count} algorithms")
    
    print(f"\n🔍 Sample Algorithms:")
    samples = ['PSO', 'GWO', 'JS', 'HBA', 'RSA', 'GTO', 'JS_PSO', 'AO_WOA']
    for code in samples:
        info = get_algorithm_info(code)
        if info:
            levy = "✓" if info['levy_flight_support'] else "✗"
            print(f"   {code:10} - {info['name']:40} [Levy: {levy}]")
    
    print("\n" + "=" * 70)
