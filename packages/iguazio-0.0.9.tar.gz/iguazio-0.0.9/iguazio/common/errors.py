# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


class SerializationError(Exception):
    pass


class RetryUntilSuccessfulInProgressErrorMessage(Exception):
    def __init__(self, message, *, variables=None):
        super().__init__(message)
        self.variables = variables if variables else {}
        self.message = message


class RetryUntilSuccessfulFatalError(Exception):
    def __init__(self, message, *, caused_by_exc=None):
        super().__init__(message)
        self.message = message

        # the exception that caused the fatal error
        self.caused_by_exc = caused_by_exc


class RetryTimeoutError(Exception):
    """Raised when retry_until_successful exceeds the given timeout."""
