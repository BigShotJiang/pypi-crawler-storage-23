# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import unittest

import iguazio.schemas


class TestPolicySchemas(unittest.TestCase):
    def test_project_role_from_str(self):
        for role_str, expected_role in [
            ("admin", iguazio.schemas.ProjectRole.ADMIN),
            ("editor", iguazio.schemas.ProjectRole.EDITOR),
            ("viewer", iguazio.schemas.ProjectRole.VIEWER),
            ("owner", iguazio.schemas.ProjectRole.OWNER),
            ("no-access", None),
        ]:
            role = iguazio.schemas.ProjectRole.from_str(role_str)
            assert role == expected_role

    def test_project_role_for_policy_name(self):
        for policy_name, expected_role in [
            ("igz-project-admin", iguazio.schemas.ProjectRole.ADMIN),
            ("igz-project-editor", iguazio.schemas.ProjectRole.EDITOR),
            ("igz-project-viewer", iguazio.schemas.ProjectRole.VIEWER),
            ("igz-project-owner", iguazio.schemas.ProjectRole.OWNER),
            ("no-access", None),
        ]:
            role = iguazio.schemas.ProjectRole.role_for_policy_name(policy_name)
            assert role == expected_role
