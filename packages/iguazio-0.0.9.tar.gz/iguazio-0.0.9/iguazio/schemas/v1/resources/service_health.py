# Copyright 2026 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import datetime
import enum
import typing

import iguazio.schemas.base.igz_schema as igz_schema
import iguazio.schemas.v1.common.base as base


class ServiceState(enum.Enum):
    """
    Represents the health state of a monitored service.

    Attributes:
        unspecified: Default value.
        unknown: Service state is not yet determined.
        ready: Service is healthy and operational.
        unhealthy: Service is unhealthy or unavailable.
    """

    unspecified = "unspecified"
    unknown = "unknown"
    ready = "ready"
    unhealthy = "unhealthy"


@igz_schema.igz_dataclass
class ServiceHealthSpec(base.BaseSpec):
    """
    Specification for a monitored service health entry.

    Args:
        name (str): Logical service name (e.g., "kfp", "mlrun").
        group (str): Service group: "infra", "core", or "app".
        resource (str, optional): K8s workload resource name.
        resource_kind (str, optional): K8s workload kind (Deployment, StatefulSet, DaemonSet).
    """

    name: str = ""
    group: str = ""
    resource: typing.Optional[str] = None
    resource_kind: typing.Optional[str] = None


@igz_schema.igz_dataclass
class ServiceHealthStatus(base.BaseStatus):
    """
    Health status for a monitored service.

    Args:
        state (ServiceState): Current health state of the service.
        last_checked (datetime, optional): Timestamp of the last health check.
        error_description (str, optional): Error details when the service is unhealthy.
    """

    state: ServiceState = ServiceState.unspecified
    last_checked: typing.Optional[datetime.datetime] = None
    error_description: typing.Optional[str] = None


@igz_schema.igz_dataclass
class ServiceHealth(igz_schema.IGZSchema):
    """
    Represents the health of a single monitored service.

    Args:
        spec (ServiceHealthSpec): Service definition fields (name, group, resource).
        status (ServiceHealthStatus): Health state fields (state, last_checked, error_description).
    """

    spec: ServiceHealthSpec = dataclasses.field(default_factory=ServiceHealthSpec)
    status: ServiceHealthStatus = dataclasses.field(default_factory=ServiceHealthStatus)


@igz_schema.igz_dataclass
class ServiceHealthList(igz_schema.IGZSchema):
    """
    A list of monitored service health entries.

    Args:
        items (list[ServiceHealth]): List of ServiceHealth objects.
        status (ServiceHealthStatus): Overall response status.
    """

    items: typing.List[ServiceHealth] = dataclasses.field(default_factory=list)
    status: ServiceHealthStatus = dataclasses.field(default_factory=ServiceHealthStatus)
