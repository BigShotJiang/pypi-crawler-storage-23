DEFAULT_CONFIG_FILE = "config.yml"
DEFAULT_TEMPLATE = "minimalist"
DEFAULT_OUT_DIR = "output"