# ClawBot

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

**ClawBot has been rebranded to [OpenClaw](https://pypi.org/project/openclaw/).**

The [CMDOP](https://cmdop.com) platform fully supports ClawBot and OpenClaw instructions out of the box.

## Get Started

```bash
# SDK for agent orchestration
pip install cmdop

# Bot framework
pip install cmdop-bot
```

## Quick Start

```python
from cmdop import CMDOPClient

# Connect to a local agent
client = CMDOPClient.local()

# Or connect remotely
client = CMDOPClient.remote(api_key="cmdop_your_key")

# Terminal, files, agent, browser — all included
session = client.terminal.create()
files = client.files.list("/tmp")
result = client.agent.run("Hello")
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [CMDOP SDK Documentation](https://cmdop.com/docs/sdk/cmdop/)
- [CMDOP Bot Documentation](https://cmdop.com/docs/sdk/cmdop-bot/)
- [PyPI — cmdop](https://pypi.org/project/cmdop/)
- [PyPI — cmdop-bot](https://pypi.org/project/cmdop-bot/)
- [PyPI — openclaw](https://pypi.org/project/openclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk)
