"""
ClawBot is now OpenClaw.

The CMDOP platform fully supports ClawBot/OpenClaw instructions.
Install the SDK: pip install cmdop
Install the Bot: pip install cmdop-bot

Learn more: https://cmdop.com
"""

__version__ = "0.0.1"

from cmdop import *  # noqa: F401,F403
