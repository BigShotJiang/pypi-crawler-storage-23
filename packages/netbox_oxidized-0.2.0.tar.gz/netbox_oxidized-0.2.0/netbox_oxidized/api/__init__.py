"""API module for NetBox Oxidized plugin."""
