"""API URL configuration for NetBox Oxidized plugin."""

from django.urls import path

urlpatterns = []
