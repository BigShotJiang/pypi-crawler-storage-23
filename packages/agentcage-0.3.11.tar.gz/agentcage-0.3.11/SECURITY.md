# Security Policy

## Threat Model

See [docs/security.md](docs/security.md) for the full threat model, defense layers, and known limitations.

## Reporting a Vulnerability

If you discover a security vulnerability in agentcage, please report it responsibly:

1. **Do not** open a public GitHub issue for security vulnerabilities.
2. Email **security@agentcage.ai** with a description of the vulnerability, steps to reproduce, and any relevant details.
3. You will receive an acknowledgment within 48 hours.
4. We will work with you to understand the issue and coordinate a fix before public disclosure.

## Scope

agentcage is a defense-in-depth tool that reduces exfiltration risk but does not claim to be a complete security boundary. See [Known Limitations](docs/security.md#known-limitations) for what is explicitly out of scope.
