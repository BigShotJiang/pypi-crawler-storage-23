## [0.13.1](https://github.com/l4rm4nd/PyADRecon/compare/v0.13.0...v0.13.1) (2026-02-22)


### Bug Fixes

* detect delegation findings ([90aea4e](https://github.com/l4rm4nd/PyADRecon/commit/90aea4ef264f2f6e124bb1a8fe4c123f1ea63192))

## [0.13.0](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.14...v0.13.0) (2026-02-22)


### Features

* paginated dashboard ([1ec081f](https://github.com/l4rm4nd/PyADRecon/commit/1ec081f906436060cede2ebed94854708e2a954c))

## [0.12.14](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.13...v0.12.14) (2026-02-22)


### Bug Fixes

* rename finding ([453536a](https://github.com/l4rm4nd/PyADRecon/commit/453536a5bf760db7ae28a759c5e11a77ee1adb1e))

## [0.12.13](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.12...v0.12.13) (2026-02-22)


### Bug Fixes

* rework protected users in dashboard ([b07d6e6](https://github.com/l4rm4nd/PyADRecon/commit/b07d6e6e88c3ad7503a41e2fbfd83231ee9016be))

## [0.12.12](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.11...v0.12.12) (2026-02-21)


### Bug Fixes

* add --generate-dashboard-from support ([e4905ce](https://github.com/l4rm4nd/PyADRecon/commit/e4905ce55616ea13e480f9c3c299542f07c3d312))

