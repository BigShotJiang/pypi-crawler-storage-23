# mystrotamer-tohtml

A professional CLI tool to convert **Markdown** files into a clean, modern, and print-friendly **HTML document** — with built-in Dark/Light mode, RTL support, and code copy buttons.

---

## ✨ Features

- 🖨️ **Print-friendly layout** (optimized for PDFs and paper)
- 🌙 **Dark / Light mode** with **System preference**
- 🌍 **Automatic RTL support** for Arabic, Persian, Hebrew, and Urdu
- 📋 **Copy buttons** on all code blocks
- 🎨 Clean typography for headings, tables, and blockquotes
- ⚙️ Single self-contained HTML output (no external assets)

---

## 📦 Installation

### From PyPI (recommended)
```bash
pip install mystrotamer-tohtml
```

### Local / Development
```bash
pip install -e .
```

---

## 🚀 Usage

### Basic conversion
```bash
tohtml README.md
```

Generates:
```
README.html
```

---

### Specify output file
```bash
tohtml README.md -o output.html
```

---

### Arabic / RTL documents
```bash
tohtml README.md --lang ar
```

RTL is applied automatically based on the language.

---

### Disable GUI file picker
(useful on servers or minimal Linux)
```bash
tohtml --no-gui README.md
```

---

## ⚙️ Command-line Options

| Option | Description |
|------|------------|
| `-o, --output` | Output HTML file path |
| `--title` | Custom document title |
| `--lang` | HTML language (`ar`, `en`, `fa`, `he`, …) |
| `--footer-left` | Custom footer (left) |
| `--footer-right` | Custom footer (right) |
| `--no-gui` | Disable file picker dialog |

---

## 🖥️ Notes

- When opening the generated HTML via `file://`, some browsers may restrict `localStorage`.
- For best results, serve the file locally:

```bash
python -m http.server 8000
```

Then open:
```
http://localhost:8000/yourfile.html
```

---

## 📄 License

MIT License © Tamer Hamad Faour

---

## 👤 Author

**Tamer Hamad Faour**  
GitHub: https://github.com/TamerOnLine
