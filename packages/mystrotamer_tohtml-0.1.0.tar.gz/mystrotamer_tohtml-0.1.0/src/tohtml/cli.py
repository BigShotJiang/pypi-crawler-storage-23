from __future__ import annotations

import argparse
from datetime import date
from html import escape
from pathlib import Path

try:
    from markdown_it import MarkdownIt
except ModuleNotFoundError as exc:  # pragma: no cover
    raise SystemExit(
        "Missing dependency 'markdown-it-py'. Install with: pip install markdown-it-py"
    ) from exc


def build_md() -> MarkdownIt:
    md = MarkdownIt("commonmark", {"html": False, "linkify": True})
    md.enable(["table", "strikethrough"])
    return md


CSS = """
:root{
  --paper:#ffffff;
  --ink:#111827;
  --muted:#6b7280;
  --border:#e5e7eb;
  --shadow:0 10px 30px rgba(0,0,0,.08);
  --link:#1d4ed8;
  --quote:#f9fafb;
}

*{box-sizing:border-box}

body{
  margin:0;
  font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Arial;
  color:var(--ink);
  background:#f3f4f6;
  line-height:1.6;
}

a{
  color:var(--link);
  text-decoration:none;
}

a:hover{
  text-decoration:underline;
}

.topbar{
  position:sticky;
  top:0;
  z-index:10;
  backdrop-filter:blur(10px);
  background:rgba(243,244,246,.75);
  border-bottom:1px solid var(--border);
}

.topbar-inner{
  max-width:900px;
  margin:0 auto;
  padding:12px 18px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
}

.brand{
  display:flex;
  flex-direction:column;
  gap:2px;
}

.brand .title{font-weight:700}
.brand .subtitle{font-size:12px;color:var(--muted)}

.btn{
  appearance:none;
  border:1px solid var(--border);
  background:#ffffff;
  color:var(--ink);
  border-radius:10px;
  padding:10px 14px;
  font-weight:600;
  cursor:pointer;
}

.actions{
  display:flex;
  gap:8px;
}

.page{
  max-width:900px;
  margin:22px auto 40px;
  padding:0 18px;
}

.paper{
  background:var(--paper);
  border:1px solid var(--border);
  border-radius:16px;
  box-shadow:var(--shadow);
  padding:42px 48px;
}

.paper h1,
.paper h2,
.paper h3{
  line-height:1.25;
  margin:1.4em 0 .65em;
}

.paper h1{
  font-size:2rem;
  padding-bottom:.35em;
  border-bottom:1px solid var(--border);
}

.paper h2{
  font-size:1.55rem;
  padding-bottom:.25em;
  border-bottom:1px solid var(--border);
}

.paper h3{font-size:1.2rem}

.paper p,
.paper ul,
.paper ol{margin:.85em 0}

.paper blockquote{
  margin:1em 0;
  padding:.8em 1em;
  border-inline-start:4px solid var(--border);
  background:var(--quote);
  color:var(--muted);
  border-radius:10px;
}

.paper table{
  width:100%;
  border-collapse:collapse;
  margin:1em 0;
  overflow-x:auto;
  display:block;
}

.paper th,
.paper td{
  border:1px solid var(--border);
  padding:.55em .7em;
  text-align:start;
}

.paper th{
  background:#f9fafb;
  font-weight:700;
}

pre{
  background:linear-gradient(180deg,#f8fafc 0%,#f9fafb 100%);
  border:1px solid var(--border);
  padding:2.5rem 1rem 1rem;
  border-radius:12px;
  overflow:auto;
  position:relative;
}

pre::before{
  content:"";
  position:absolute;
  top:0;
  left:0;
  right:0;
  height:2.1rem;
  border-bottom:1px solid var(--border);
  background:rgba(255,255,255,.65);
}

code{
  font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
}

pre > code{
  display:block;
  direction:ltr;
  text-align:left;
  line-height:1.7;
  font-size:.95rem;
}

:not(pre) > code{
  background:#f3f4f6;
  border:1px solid var(--border);
  border-radius:6px;
  padding:.12em .38em;
}

.copy-btn{
  position:absolute;
  top:7px;
  inset-inline-end:10px;
  font-size:12px;
  font-weight:600;
  letter-spacing:.01em;
  line-height:1;
  padding:7px 10px;
  border:1px solid var(--border);
  background:#ffffff;
  color:var(--ink);
  border-radius:9px;
  cursor:pointer;
  transition:all .15s ease;
}

.copy-btn:hover{
  transform:translateY(-1px);
  border-color:#cbd5e1;
}

.copy-btn:active{
  transform:translateY(0);
}

.footer{
  margin-top:26px;
  padding-top:14px;
  border-top:1px solid var(--border);
  color:var(--muted);
  font-size:12px;
  display:flex;
  justify-content:space-between;
  flex-wrap:wrap;
}

/* 🌙 Dark Mode */
body.dark{
  --paper:#111827;
  --ink:#f9fafb;
  --muted:#9ca3af;
  --border:#374151;
  --shadow:0 10px 30px rgba(0,0,0,.6);
  --link:#93c5fd;
  --quote:#0f172a;
  background:#030712;
}

body.dark .topbar{
  background:rgba(3,7,18,.85);
}

body.dark pre{
  background:linear-gradient(180deg,#020617 0%,#030a18 100%);
}

body.dark pre::before{
  background:rgba(2,6,23,.7);
}

body.dark :not(pre) > code{
  background:#0b1220;
}

body.dark .copy-btn{
  background:#111827;
  border-color:#4b5563;
  color:#f3f4f6;
}

body.dark .btn{
  background:#020617;
  color:#f9fafb;
}

body.dark .paper th{
  background:#0b1220;
}

body[dir="rtl"]{
  direction:rtl;
  line-height:1.85;
}

body[dir="rtl"] .topbar-inner{
  flex-direction:row-reverse;
}

body[dir="rtl"] .actions{
  direction:ltr;
}

/* 🖨️ Print */
@media print{
  body{background:#ffffff}
  .topbar,.copy-btn{display:none !important}
  .page{margin:0;padding:0}
  .paper{border:none;box-shadow:none;border-radius:0;padding:0}
  pre,code{
    white-space:pre-wrap;
    word-break:break-word;
    overflow-wrap:anywhere;
  }
  a::after{
    content:" (" attr(href) ")";
    color:#6b7280;
    font-size:.92em;
  }
}
"""


HTML_TEMPLATE = """<!doctype html>
<html lang="{lang}" dir="{dir}">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>{title}</title>
  <style>{css}</style>
</head>
<body>
  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand">
        <div class="title">{title}</div>
        <div class="subtitle">HTML version with print & dark mode</div>
      </div>
      <div class="actions">
        <button class="btn" id="themeBtn" onclick="toggleTheme()" aria-label="Toggle dark mode">🌙 Dark</button>
        <button class="btn" onclick="resetTheme()" aria-label="Reset theme to system preference">System</button>
        <button class="btn" onclick="window.print()" aria-label="Print document">Print</button>
      </div>
    </div>
  </div>

  <main class="page">
    <article class="paper">
      {content}
      <div class="footer">
        <span>{footer_left}</span>
        <span>{footer_right}</span>
      </div>
    </article>
  </main>

<script>
function applyTheme(theme){
  const btn = document.getElementById("themeBtn");
  const isDark = theme === "dark";
  document.body.classList.toggle("dark", isDark);
  btn.textContent = isDark ? "☀️ Light" : "🌙 Dark";
  btn.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
}

function toggleTheme(){
  const nextTheme = document.body.classList.contains("dark") ? "light" : "dark";
  applyTheme(nextTheme);
  localStorage.setItem("theme", nextTheme);
}

function resetTheme(){
  localStorage.removeItem("theme");
  const systemPrefersDark = window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches;
  applyTheme(systemPrefersDark ? "dark" : "light");
}

function addCopyButtons(){
  document.querySelectorAll("pre").forEach(function(pre){
    if(pre.querySelector(".copy-btn")) return;
    const code = pre.querySelector("code");
    if(!code) return;
    const btn = document.createElement("button");
    btn.className = "copy-btn";
    btn.type = "button";
    btn.textContent = "Copy";
    btn.addEventListener("click", async function(){
      try{
        await navigator.clipboard.writeText(code.innerText);
        btn.textContent = "Copied";
        setTimeout(function(){ btn.textContent = "Copy"; }, 1000);
      }catch(_err){
        btn.textContent = "Failed";
        setTimeout(function(){ btn.textContent = "Copy"; }, 1200);
      }
    });
    pre.appendChild(btn);
  });
}

document.addEventListener("DOMContentLoaded", function(){
  addCopyButtons();
  const storedTheme = localStorage.getItem("theme");
  if(storedTheme === "dark" || storedTheme === "light"){
    applyTheme(storedTheme);
    return;
  }
  const systemPrefersDark = window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: dark)").matches;
  applyTheme(systemPrefersDark ? "dark" : "light");
});
</script>

</body>
</html>
"""


def pick_file_gui() -> Path:
    """Open a native file picker and return the selected Markdown path."""
    try:
        from tkinter import Tk
        from tkinter.filedialog import askopenfilename
    except Exception as exc:  # pragma: no cover
        raise SystemExit(
            "GUI file picker is unavailable (tkinter missing). "
            "Pass the input file path explicitly or use --no-gui."
        ) from exc

    root = Tk()
    root.withdraw()
    file_path = askopenfilename(
        title="Select Markdown file",
        filetypes=[("Markdown files", "*.md"), ("All files", "*.*")],
    )
    root.destroy()
    if not file_path:
        raise SystemExit("No input file selected")
    return Path(file_path).resolve()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Convert Markdown to a styled HTML document with print + dark/light toggle."
    )
    parser.add_argument("input_md", nargs="?", help="Path to input .md file")
    parser.add_argument("-o", "--output", default=None, help="Output .html path")
    parser.add_argument("--title", default=None, help="Document title")
    parser.add_argument("--lang", default="ar", help="HTML lang attribute (default: ar)")
    parser.add_argument("--footer-left", default=None)
    parser.add_argument("--footer-right", default=None)
    parser.add_argument("--no-gui", action="store_true", help="Disable GUI file picker")
    args = parser.parse_args(argv)

    if args.input_md:
        md_path = Path(args.input_md).resolve()
        if not md_path.exists():
            raise SystemExit(f"Input not found: {md_path}")
    else:
        if args.no_gui:
            raise SystemExit("No input file provided. Pass a Markdown path.")
        md_path = pick_file_gui()

    out_path = Path(args.output).resolve() if args.output else md_path.with_suffix(".html")
    text_dir = "rtl" if args.lang.lower().startswith(("ar", "he", "fa", "ur")) else "ltr"

    md = build_md()
    content_html = md.render(md_path.read_text(encoding="utf-8"))

    title = args.title or md_path.stem
    footer_left = args.footer_left or md_path.stem
    footer_right = args.footer_right or date.today().isoformat()

    html = (
        HTML_TEMPLATE.replace("{lang}", args.lang)
        .replace("{dir}", text_dir)
        .replace("{title}", escape(title))
        .replace("{css}", CSS)
        .replace("{content}", content_html)
        .replace("{footer_left}", escape(footer_left))
        .replace("{footer_right}", escape(footer_right))
    )

    out_path.write_text(html, encoding="utf-8")
    print(f"HTML created: {out_path}")


if __name__ == "__main__":  # pragma: no cover
    main()
