"""SmartBlocks Network SDK — canonical client for the SBN infrastructure.

Usage::

    from sbn import SbnClient

    client = SbnClient(base_url="https://api.smartblocks.network")
    client.authenticate_api_key("sbn_live_abc123")

    # SnapChore
    block = client.snapchore.capture({"event": "signup", "user": "u-42"})
    ok    = client.snapchore.verify(block["snapchore_hash"], {"event": "signup", "user": "u-42"})

    # Gateway (slots / receipts / attestations)
    slot    = client.gateway.create_slot(worker_id="w-1", task_type="classify")
    receipt = client.gateway.fetch_receipt(slot.receipt_id)

    # Console (projects, API keys, usage)
    keys  = client.console.list_api_keys()
    usage = client.console.get_usage()

    # GEC (frontier registry, compute, health)
    result = client.gec.compute(y=85.0, x=100.0, frontier_id="core-ops")

    # Governance (proposal lifecycle)
    proposals = client.governance.list_proposals()

    # Control plane (tenants, rate plans, validators)
    plans = client.control_plane.list_rate_plans()
"""

from __future__ import annotations

__version__ = "0.3.0"

# Re-export top-level conveniences
from sbn.client import SbnClient
from sbn.auth import SigningKey, MintedToken
from sbn._http import SbnError, SbnTransportError, RetryConfig
from sbn.gateway import (
    GatewayClient,
    SlotCreateRequest,
    SlotHandle,
    SlotClosure,
    SlotSummary,
    Receipt,
)
from sbn.snapchore import SnapChoreClient
from sbn.console import ConsoleClient, ApiKeyRecord, ApiKeyLimits, ProjectUsage
from sbn.control_plane import (
    ControlPlaneClient,
    RatePlan,
    TenantSummary,
    TenantDetail,
    Validator,
)
from sbn.lattice import LatticeClient
from sbn.reality import RealityClient
from sbn.blocks import BlocksClient
from sbn.gec import GecClient
from sbn.governance import GovernanceClient

__all__ = [
    "SbnClient",
    # Auth
    "SigningKey",
    "MintedToken",
    # HTTP / errors
    "SbnError",
    "SbnTransportError",
    "RetryConfig",
    # Gateway
    "GatewayClient",
    "SlotCreateRequest",
    "SlotHandle",
    "SlotClosure",
    "SlotSummary",
    "Receipt",
    # SnapChore
    "SnapChoreClient",
    # Console
    "ConsoleClient",
    "ApiKeyRecord",
    "ApiKeyLimits",
    "ProjectUsage",
    # Control plane
    "ControlPlaneClient",
    "RatePlan",
    "TenantSummary",
    "TenantDetail",
    "Validator",
    # Lattice
    "LatticeClient",
    # Reality Check
    "RealityClient",
    # Blocks
    "BlocksClient",
    # GEC
    "GecClient",
    # Governance
    "GovernanceClient",
]
