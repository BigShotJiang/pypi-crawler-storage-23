"""Blocks sub-client — SmartBlock creation."""

from __future__ import annotations

from typing import Any, Mapping

from sbn._http import HttpTransport


class BlocksClient:
    """Create and query SmartBlocks."""

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    def create(
        self,
        *,
        payload: Mapping[str, Any],
        domain: str = "default",
        metadata: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a SmartBlock.

        Returns ``{"data": {"id": "uuid", "hash": "sha256:...", ...}}``.
        """
        body: dict[str, Any] = {
            "payload": dict(payload),
            "domain": domain,
            "metadata": dict(metadata) if metadata else {"source": "sbn-sdk"},
        }
        return self._t.post("/api/blocks", json=body).json()

    def get(self, block_id: str) -> dict[str, Any]:
        """Retrieve a SmartBlock by ID."""
        return self._t.get(f"/api/blocks/{block_id}").json()

    def list(
        self,
        *,
        domain: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if domain:
            params["domain"] = domain
        data = self._t.get("/api/blocks", params=params).json()
        return data.get("data", {}).get("blocks", data.get("blocks", []))
