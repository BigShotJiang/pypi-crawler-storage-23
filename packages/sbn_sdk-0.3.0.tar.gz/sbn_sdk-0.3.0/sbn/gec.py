"""GEC sub-client — frontier registry, on-demand GEC compute, and health queries."""

from __future__ import annotations

from typing import Any, Mapping

from sbn._http import HttpTransport

PREFIX = "/api/gec"


class GecClient:
    """On-demand GEC computation, frontier registry, and health queries.

    Provides SDK access to the SBN Generalized Efficiency Coefficient (GEC)
    compute engine, frontier registry lookups, and live frontier health
    aggregation.

    Example::

        client = SbnClient(base_url="https://api.smartblocks.network")
        client.authenticate_api_key("sbn_live_...")

        # List all frontiers from the registry
        frontiers = client.gec.list_frontiers()

        # Compute GEC₀ with optional CSK health dimensions
        result = client.gec.compute(
            y=85.0,
            x=100.0,
            frontier_id="core-ops",
            csk={"S": 0.9, "H": 0.85, "D": 0.7, "R": 0.8, "E": 0.75},
        )
        print(result["gec0"], result["metallic_label"])
    """

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    # ── Frontier Registry ──────────────────────────────────────────────

    def list_frontiers(
        self,
        *,
        if_none_match: str | None = None,
    ) -> dict[str, Any]:
        """Return the frontier registry with ETag support.

        Supports conditional GET via ``if_none_match`` — pass a previously
        received ETag to get a 304 if the registry hasn't changed.

        Returns ``{"domains": {...}}`` with all registered frontiers.
        """
        headers: dict[str, str] = {}
        if if_none_match:
            headers["If-None-Match"] = if_none_match
        resp = self._t.get(f"{PREFIX}/frontiers", headers=headers)
        if resp.status_code == 304:
            return {"not_modified": True}
        return resp.json()

    def get_frontier_bundle(self) -> dict[str, Any]:
        """Get the raw signed frontier bundle for integrity verification.

        Returns ``{"bundle": {...}, "snapchore_hash": "...", "version": "...",
        "loaded_at": "..."}``.
        """
        return self._t.get(f"{PREFIX}/frontiers/bundle").json()

    # ── Compute ────────────────────────────────────────────────────────

    def compute(
        self,
        y: float,
        x: float,
        *,
        frontier_id: str | None = None,
        c_max: float | None = None,
        var_y: float = 0.0,
        var_x: float = 0.0,
        var_cmax: float = 0.0,
        n: int | None = None,
        cov_yx: float | None = None,
        alpha: float = 0.05,
        csk: Mapping[str, float] | None = None,
    ) -> dict[str, Any]:
        """Compute GEC₀, confidence interval, CSK health, and metallic class.

        Parameters
        ----------
        y : float
            Validated output (yield).
        x : float
            Resource input.
        frontier_id : str, optional
            Frontier domain ID for ``c_max`` lookup from the registry.
        c_max : float, optional
            Explicit ``c_max`` — overrides ``frontier_id`` lookup.
        var_y, var_x, var_cmax : float
            Estimator variances for CI computation.
        n : int, optional
            Sample size (passed through for CI metadata).
        cov_yx : float, optional
            Covariance between y and x estimators.
        alpha : float
            Significance level for confidence interval (default 0.05).
        csk : dict, optional
            CSK health vector ``{"S": ..., "H": ..., "D": ..., "R": ...,
            "E": ...}`` for metallic classification.

        Returns
        -------
        dict
            ``{"gec0": ..., "ci": {...}, "csk": {...}, "lambda_score": ...,
            "metallic_label": "...", "attractor": {...}, "frontier": {...}}``.
        """
        body: dict[str, Any] = {"y": y, "x": x}
        if frontier_id is not None:
            body["frontier_id"] = frontier_id
        if c_max is not None:
            body["c_max"] = c_max
        if var_y != 0.0:
            body["var_y"] = var_y
        if var_x != 0.0:
            body["var_x"] = var_x
        if var_cmax != 0.0:
            body["var_cmax"] = var_cmax
        if n is not None:
            body["n"] = n
        if cov_yx is not None:
            body["cov_yx"] = cov_yx
        if alpha != 0.05:
            body["alpha"] = alpha
        if csk is not None:
            body["csk"] = dict(csk)
        return self._t.post(f"{PREFIX}/compute", json=body).json()

    # ── Health ─────────────────────────────────────────────────────────

    def get_frontier_health(
        self,
        frontier_id: str,
        *,
        days: int = 30,
    ) -> dict[str, Any]:
        """Compute live GEC health from recent efficiency events for a frontier.

        Parameters
        ----------
        frontier_id : str
            The frontier to query.
        days : int
            Lookback window (1–90, default 30).

        Returns
        -------
        dict
            ``{"frontier_id": ..., "current_gec0": ..., "avg_gec": ...,
            "trend": ..., "metallic_label": ..., "ci": {...},
            "csk_health": {...}, "attractor": {...}, "n": ..., "days": ...,
            "frontier_c_max": ..., "updated_at": ...}``.
        """
        params: dict[str, str] = {}
        if days != 30:
            params["days"] = str(days)
        return self._t.get(
            f"{PREFIX}/frontiers/{frontier_id}/health", params=params
        ).json()
