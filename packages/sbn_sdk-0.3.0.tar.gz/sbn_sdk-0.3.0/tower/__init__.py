"""Tower Agent Profile SDK — typed client for Tower Agent API.

Provides profile-scoped clients for products (Dominion, Grid, Stillpoint)
to integrate with Tower Agent without importing tower-agent internals.

Usage::

    from tower import TowerClient

    client = TowerClient(base_url="http://localhost:8001", api_key="sk-tower-...")
    agent = client.create_agent(
        employee_id="emp-42",
        project_id="proj-001",
        profile="dominion",
    )
    client.dominion.ingest_batch(agent["agent_id"], batch_summary={...})
    suggestions = client.suggestions(agent["agent_id"])
    client.feedback(agent["agent_id"], "sug-001", feedback_type="accept")
"""

from tower.client import TowerClient
from tower.types import (
    AgentState,
    FeedbackType,
    MemoryType,
    ProfileTier,
    ScoreType,
    SuggestionStatus,
    SuggestionType,
)

__all__ = [
    "TowerClient",
    "AgentState",
    "FeedbackType",
    "MemoryType",
    "ProfileTier",
    "ScoreType",
    "SuggestionStatus",
    "SuggestionType",
]

__version__ = "0.1.0"
