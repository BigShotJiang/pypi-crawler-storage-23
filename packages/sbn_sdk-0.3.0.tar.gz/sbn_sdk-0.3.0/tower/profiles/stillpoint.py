"""Stillpoint profile client — treasury-scoped Tower Agent operations.

Extends BaseProfileClient with Stillpoint-specific context ingestion:
- Treasury health snapshots (FRHI, compression, buffers)
- Reflex events
- Yield updates (decay detection)
- GEC/CSK hints
- Treasury brief
"""

from __future__ import annotations

from typing import Any, Dict, List

from tower.profiles._base import BaseProfileClient


class StillpointProfileClient(BaseProfileClient):
    """Client for Stillpoint (treasury) agent profiles.

    Usage::

        client.stillpoint.ingest_health(agent_id, snapshot={
            "frhi": 1.35, "health_band": "green",
            "compression_score": 0.88, "total_aum": 2_500_000,
        })
        client.stillpoint.ingest_yield(
            agent_id, asset="sol_staking", yield_pct=4.2, prev_yield_pct=4.7,
        )
        brief = client.stillpoint.treasury_brief(agent_id)
    """

    def __init__(self, transport: Any) -> None:
        super().__init__(transport, profile="stillpoint")

    # ── Context Ingestion ─────────────────────────────────────────────

    def ingest_health(
        self,
        agent_id: str,
        snapshot: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Ingest a Stillpoint treasury health snapshot.

        Call after every health tick. The agent uses this to detect
        trends and generate proactive treasury suggestions.

        Expected snapshot shape::

            {
                "frhi": float,
                "health_band": str,
                "compression_score": float,
                "convergence_score": float,
                "total_aum": float,
                "total_yield": float,
                "buffer_short": float,
                "buffer_mid": float,
                "buffer_long": float,
                "gec0_score": float,
                "csk_vector": {"S": float, "H": float, "D": float, "R": float, "E": float},
            }
        """
        resp = self._t.post(
            f"/api/agents/{agent_id}/context/health_snapshot",
            json={"type": "treasury_snapshot", "data": snapshot},
        )
        return resp.json().get("data", resp.json())

    def ingest_reflex(
        self,
        agent_id: str,
        reflex: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Ingest a Stillpoint reflex event.

        Expected shape::

            {
                "reflex_type": str,
                "source": str,
                "trigger_frhi": float,
                "action_taken": str,
            }
        """
        resp = self._t.post(
            f"/api/agents/{agent_id}/context/reflex",
            json={"type": "reflex_event", "data": reflex},
        )
        return resp.json().get("data", resp.json())

    def ingest_yield(
        self,
        agent_id: str,
        *,
        asset: str,
        yield_pct: float,
        prev_yield_pct: float,
    ) -> Dict[str, Any]:
        """Ingest a yield change for decay detection.

        The agent will alert if yield drops more than the configured
        ``yield_decay_alert_pct`` threshold.
        """
        resp = self._t.post(
            f"/api/agents/{agent_id}/context/yield_update",
            json={
                "type": "yield_update",
                "asset": asset,
                "yield_pct": yield_pct,
                "prev_yield_pct": prev_yield_pct,
            },
        )
        return resp.json().get("data", resp.json())

    def ingest_gec_hints(
        self,
        agent_id: str,
        hints: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Ingest NUMA/GEC intervention hints for treasury frontier."""
        resp = self._t.post(
            f"/api/agents/{agent_id}/context/gec_hints",
            json={"type": "gec_hints", "hints": hints},
        )
        return resp.json().get("data", resp.json())

    # ── Intelligence Queries ──────────────────────────────────────────

    def treasury_brief(self, agent_id: str) -> Dict[str, Any]:
        """Get an operator-facing treasury brief.

        Returns FRHI, health band, AUM, compression score, GEC₀,
        recent reflex count, and agent analysis.
        """
        resp = self._t.get(f"/api/agents/{agent_id}/brief")
        return resp.json().get("data", resp.json())
