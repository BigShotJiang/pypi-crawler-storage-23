"""Agent infrastructure for veripak v2."""
