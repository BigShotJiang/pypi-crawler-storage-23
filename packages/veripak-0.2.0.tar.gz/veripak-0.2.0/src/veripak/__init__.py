"""veripak — open-source package auditing CLI."""

from .version import __version__
