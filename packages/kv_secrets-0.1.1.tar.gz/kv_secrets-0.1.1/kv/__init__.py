"""kv — encrypted secrets management for developers."""
__version__ = "0.1.1"
