"""MCP server for kv encrypted secrets management.

Implements Model Context Protocol (MCP) over stdio transport.
AI coding agents can manage secrets without plaintext on disk.
"""
