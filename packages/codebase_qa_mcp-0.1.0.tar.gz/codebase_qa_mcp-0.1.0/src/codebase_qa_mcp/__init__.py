"""Codebase Q&A MCP Server — ask questions about any codebase using RAG."""

__version__ = "0.1.0"
