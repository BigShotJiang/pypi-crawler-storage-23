"""Query engine: search ChromaDB for relevant code chunks."""

from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from . import config
from .indexer import _get_chroma_client, _get_collection_name, _get_embedding_function, _read_state


def query_codebase(
    repo_path: str,
    question: str,
    top_k: int = config.TOP_K,
    file_filter: str | None = None,
) -> list[dict]:
    """Search the indexed codebase for chunks relevant to a question."""
    collection_name = _get_collection_name(repo_path)
    client = _get_chroma_client()
    embed_fn = _get_embedding_function()

    try:
        collection = client.get_collection(
            name=collection_name,
            embedding_function=embed_fn,
        )
    except ValueError:
        return []

    where_filter = None
    if file_filter:
        where_filter = {"file_path": {"$contains": file_filter}}

    results = collection.query(
        query_texts=[question],
        n_results=min(top_k, collection.count()),
        where=where_filter,
    )

    if not results["documents"] or not results["documents"][0]:
        return []

    chunks = []
    for i, doc in enumerate(results["documents"][0]):
        chunks.append({
            "content": doc,
            "file_path": results["metadatas"][0][i].get("file_path", "unknown"),
            "chunk_index": results["metadatas"][0][i].get("chunk_index", 0),
            "language": results["metadatas"][0][i].get("language", "text"),
            "distance": results["distances"][0][i] if results["distances"] else None,
        })

    return chunks


def list_indexed_files(repo_path: str) -> list[str]:
    """Get all unique file paths in the index for a repo."""
    collection_name = _get_collection_name(repo_path)
    client = _get_chroma_client()
    embed_fn = _get_embedding_function()

    try:
        collection = client.get_collection(
            name=collection_name,
            embedding_function=embed_fn,
        )
    except ValueError:
        return []

    all_items = collection.get(include=["metadatas"])
    file_paths = set()
    for meta in all_items["metadatas"]:
        if "file_path" in meta:
            file_paths.add(meta["file_path"])

    return sorted(file_paths)


def get_index_stats(repo_path: str) -> dict:
    """Get statistics about the index for a repo."""
    collection_name = _get_collection_name(repo_path)
    client = _get_chroma_client()
    embed_fn = _get_embedding_function()

    state = _read_state(collection_name)

    try:
        collection = client.get_collection(
            name=collection_name,
            embedding_function=embed_fn,
        )
    except ValueError:
        return {
            "collection": collection_name,
            "status": "not_indexed",
        }

    all_items = collection.get(include=["metadatas"])
    file_paths = set()
    for meta in all_items["metadatas"]:
        if "file_path" in meta:
            file_paths.add(meta["file_path"])

    return {
        "collection": collection_name,
        "repo_path": state.get("repo_path", repo_path),
        "total_chunks": collection.count(),
        "total_files": len(file_paths),
        "last_indexed_commit": state.get("last_commit_sha"),
    }


def list_projects() -> list[dict]:
    """List all indexed projects."""
    client = _get_chroma_client()
    collections = client.list_collections()

    projects = []
    for col in collections:
        state = _read_state(col.name)
        projects.append({
            "collection": col.name,
            "repo_path": state.get("repo_path", "unknown"),
            "last_commit": state.get("last_commit_sha"),
        })

    return projects
