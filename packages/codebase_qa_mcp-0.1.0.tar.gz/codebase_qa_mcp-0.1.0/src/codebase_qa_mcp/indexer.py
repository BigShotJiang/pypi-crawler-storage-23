"""Codebase ingestion: load files, chunk, embed, store in ChromaDB."""

import json
import os
import re
import subprocess
from pathlib import Path

import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
from langchain_text_splitters import Language, RecursiveCharacterTextSplitter

from . import config

# Map file extensions to language names
EXTENSION_TO_LANGUAGE = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".jsx": "javascript", ".java": "java",
    ".go": "go", ".rs": "rust", ".c": "c", ".cpp": "cpp",
    ".h": "c", ".hpp": "cpp", ".html": "html", ".css": "css",
    ".scss": "css", ".sql": "sql", ".sh": "bash", ".bash": "bash",
    ".zsh": "bash", ".md": "markdown", ".txt": "text", ".rst": "text",
    ".yaml": "yaml", ".yml": "yaml", ".json": "json", ".toml": "toml",
    ".dockerfile": "dockerfile",
}

# Map our language names to LangChain Language enums for code-aware splitting
_LANGUAGE_TO_LANGCHAIN = {
    "python": Language.PYTHON,
    "javascript": Language.JS,
    "typescript": Language.TS,
    "java": Language.JAVA,
    "go": Language.GO,
    "rust": Language.RUST,
    "c": Language.C,
    "cpp": Language.CPP,
    "html": Language.HTML,
    "markdown": Language.MARKDOWN,
}


def _get_collection_name(repo_path: str) -> str:
    """Derive a ChromaDB collection name from a repo path."""
    name = Path(repo_path).resolve().name
    # ChromaDB collection names: 3-63 chars, alphanumeric/underscores/hyphens
    name = re.sub(r"[^a-zA-Z0-9_-]", "-", name).strip("-")
    if len(name) < 3:
        name = name + "-repo"
    return name[:63]


def _get_chroma_client() -> chromadb.ClientAPI:
    """Return a persistent ChromaDB client."""
    db_path = config.CHROMA_DB_PATH
    os.makedirs(db_path, exist_ok=True)
    return chromadb.PersistentClient(path=db_path)


def _get_embedding_function() -> SentenceTransformerEmbeddingFunction:
    """Return the embedding function used for all collections."""
    return SentenceTransformerEmbeddingFunction(model_name=config.EMBEDDING_MODEL)


def _get_state_file(collection_name: str) -> Path:
    """Path to the index state file for a collection."""
    return Path(config.CHROMA_DB_PATH) / f".state_{collection_name}.json"


def _read_state(collection_name: str) -> dict:
    """Read the persisted index state (last commit SHA, repo path)."""
    state_file = _get_state_file(collection_name)
    if state_file.exists():
        return json.loads(state_file.read_text())
    return {}


def _write_state(collection_name: str, state: dict) -> None:
    """Persist index state."""
    state_file = _get_state_file(collection_name)
    state_file.write_text(json.dumps(state, indent=2))


def _get_head_sha(repo_path: str) -> str | None:
    """Get the current HEAD commit SHA of a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path, capture_output=True, text=True, check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _should_skip_dir(dir_name: str) -> bool:
    """Check if a directory should be skipped."""
    return dir_name in config.IGNORED_DIRS or dir_name.endswith(".egg-info")


def load_files(repo_path: str) -> list[dict]:
    """Walk a directory and load all supported files."""
    repo = Path(repo_path).resolve()
    files = []

    for root, dirs, filenames in os.walk(repo):
        # Prune ignored directories in-place
        dirs[:] = [d for d in dirs if not _should_skip_dir(d)]

        for filename in filenames:
            filepath = Path(root) / filename
            ext = filepath.suffix.lower()

            if ext not in config.SUPPORTED_EXTENSIONS:
                continue

            try:
                content = filepath.read_text(encoding="utf-8", errors="ignore")
            except (OSError, PermissionError):
                continue

            if not content.strip():
                continue

            rel_path = str(filepath.relative_to(repo))
            files.append({
                "path": rel_path,
                "content": content,
                "language": EXTENSION_TO_LANGUAGE.get(ext, "text"),
            })

    return files


def chunk_file(file_dict: dict) -> list[dict]:
    """Split a file's content into chunks with metadata.

    Uses language-aware splitting when possible (splits on function/class
    boundaries) and falls back to generic recursive splitting for unsupported
    languages.
    """
    lang_enum = _LANGUAGE_TO_LANGCHAIN.get(file_dict["language"])

    if lang_enum is not None:
        splitter = RecursiveCharacterTextSplitter.from_language(
            language=lang_enum,
            chunk_size=config.CHUNK_SIZE,
            chunk_overlap=config.CHUNK_OVERLAP,
        )
    else:
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=config.CHUNK_SIZE,
            chunk_overlap=config.CHUNK_OVERLAP,
            length_function=len,
        )

    texts = splitter.split_text(file_dict["content"])

    return [
        {
            "text": text,
            "metadata": {
                "file_path": file_dict["path"],
                "chunk_index": i,
                "language": file_dict["language"],
            },
        }
        for i, text in enumerate(texts)
    ]


def index_repository(repo_path: str) -> dict:
    """Full-index a codebase into ChromaDB. Replaces any existing index."""
    repo_path = str(Path(repo_path).resolve())
    collection_name = _get_collection_name(repo_path)
    client = _get_chroma_client()
    embed_fn = _get_embedding_function()

    # Delete existing collection if it exists, then create fresh
    try:
        client.delete_collection(collection_name)
    except (ValueError, Exception):
        pass  # Collection doesn't exist yet, that's fine
    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=embed_fn,
    )

    # Load and chunk all files
    files = load_files(repo_path)
    all_chunks = []
    for f in files:
        all_chunks.extend(chunk_file(f))

    if not all_chunks:
        return {
            "collection": collection_name,
            "repo_path": repo_path,
            "files_indexed": 0,
            "chunks_created": 0,
        }

    # Add chunks to ChromaDB in batches (ChromaDB limit is ~41666 per add)
    batch_size = 5000
    for i in range(0, len(all_chunks), batch_size):
        batch = all_chunks[i:i + batch_size]
        collection.add(
            ids=[f"{c['metadata']['file_path']}::{c['metadata']['chunk_index']}" for c in batch],
            documents=[c["text"] for c in batch],
            metadatas=[c["metadata"] for c in batch],
        )

    # Save state
    head_sha = _get_head_sha(repo_path)
    _write_state(collection_name, {
        "repo_path": repo_path,
        "last_commit_sha": head_sha,
        "collection_name": collection_name,
    })

    return {
        "collection": collection_name,
        "repo_path": repo_path,
        "files_indexed": len(files),
        "chunks_created": len(all_chunks),
        "commit_sha": head_sha,
    }


def get_changed_files(repo_path: str, last_sha: str) -> dict:
    """Get files changed between last indexed commit and HEAD."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-status", f"{last_sha}..HEAD"],
            cwd=repo_path, capture_output=True, text=True, check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {"added": [], "modified": [], "deleted": []}

    changes = {"added": [], "modified": [], "deleted": []}
    for line in result.stdout.strip().splitlines():
        if not line:
            continue
        parts = line.split("\t", 1)
        if len(parts) != 2:
            continue
        status, filepath = parts[0], parts[1]

        if status.startswith("A"):
            changes["added"].append(filepath)
        elif status.startswith("M"):
            changes["modified"].append(filepath)
        elif status.startswith("D"):
            changes["deleted"].append(filepath)
        elif status.startswith("R"):
            # Renamed: old\tnew
            rename_parts = filepath.split("\t")
            changes["deleted"].append(rename_parts[0])
            if len(rename_parts) > 1:
                changes["added"].append(rename_parts[1])

    return changes


def update_index(repo_path: str) -> dict:
    """Incrementally update the index using git diff."""
    repo_path = str(Path(repo_path).resolve())
    collection_name = _get_collection_name(repo_path)
    state = _read_state(collection_name)

    if not state or not state.get("last_commit_sha"):
        # No previous index — do a full index
        return index_repository(repo_path)

    last_sha = state["last_commit_sha"]
    head_sha = _get_head_sha(repo_path)

    if head_sha == last_sha:
        return {
            "collection": collection_name,
            "status": "already_up_to_date",
            "commit_sha": head_sha,
        }

    changes = get_changed_files(repo_path, last_sha)
    files_to_remove = changes["deleted"] + changes["modified"]
    files_to_add = changes["added"] + changes["modified"]

    client = _get_chroma_client()
    embed_fn = _get_embedding_function()
    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=embed_fn,
    )

    chunks_removed = 0
    chunks_added = 0

    # Remove chunks for deleted/modified files
    for filepath in files_to_remove:
        existing = collection.get(where={"file_path": filepath})
        if existing["ids"]:
            collection.delete(ids=existing["ids"])
            chunks_removed += len(existing["ids"])

    # Add chunks for added/modified files
    repo = Path(repo_path).resolve()
    for filepath in files_to_add:
        full_path = repo / filepath
        if not full_path.exists():
            continue

        ext = full_path.suffix.lower()
        if ext not in config.SUPPORTED_EXTENSIONS:
            continue

        try:
            content = full_path.read_text(encoding="utf-8", errors="ignore")
        except (OSError, PermissionError):
            continue

        if not content.strip():
            continue

        file_dict = {
            "path": filepath,
            "content": content,
            "language": EXTENSION_TO_LANGUAGE.get(ext, "text"),
        }
        chunks = chunk_file(file_dict)

        if chunks:
            collection.add(
                ids=[f"{c['metadata']['file_path']}::{c['metadata']['chunk_index']}" for c in chunks],
                documents=[c["text"] for c in chunks],
                metadatas=[c["metadata"] for c in chunks],
            )
            chunks_added += len(chunks)

    # Update state
    _write_state(collection_name, {
        "repo_path": repo_path,
        "last_commit_sha": head_sha,
        "collection_name": collection_name,
    })

    return {
        "collection": collection_name,
        "files_updated": len(changes["modified"]),
        "files_added": len(changes["added"]),
        "files_deleted": len(changes["deleted"]),
        "chunks_removed": chunks_removed,
        "chunks_added": chunks_added,
        "commit_sha": head_sha,
    }
