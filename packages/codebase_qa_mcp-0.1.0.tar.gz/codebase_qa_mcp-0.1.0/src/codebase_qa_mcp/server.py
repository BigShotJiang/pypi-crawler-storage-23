"""MCP server exposing codebase Q&A tools."""

from mcp.server.fastmcp import FastMCP

from . import indexer, retriever

mcp = FastMCP("Codebase Q&A")

# Track the active project so queries know which collection to search
_active_repo_path: str | None = None


@mcp.tool()
def index_repository(repo_path: str) -> dict:
    """Full-index a git repository into the vector store.

    Reads all supported source files, splits them into chunks,
    generates embeddings, and stores them in ChromaDB.
    This replaces any existing index for the same repo.
    Sets this repo as the active project for queries.

    Args:
        repo_path: Absolute path to the git repository to index.
    """
    global _active_repo_path
    _active_repo_path = repo_path
    return indexer.index_repository(repo_path)


@mcp.tool()
def update_index(repo_path: str) -> dict:
    """Incrementally update the index using git diff.

    Only re-indexes files that changed since the last index.
    Much faster than a full re-index for large repos.
    Falls back to full index if no previous index exists.

    Args:
        repo_path: Absolute path to the git repository.
    """
    global _active_repo_path
    _active_repo_path = repo_path
    return indexer.update_index(repo_path)


@mcp.tool()
def query_codebase(
    question: str, top_k: int = 5, file_filter: str | None = None
) -> list[dict]:
    """Search the indexed codebase for code chunks relevant to a question.

    Returns the most relevant source code chunks with file paths,
    ordered by similarity. Use this to find code related to a topic,
    understand how something is implemented, or locate specific functionality.

    Args:
        question: Natural language question about the codebase.
        top_k: Number of results to return (default 5).
        file_filter: Optional substring to filter by file path (e.g. "auth" to only search auth-related files).
    """
    if not _active_repo_path:
        return [
            {
                "error": "No active project. Call index_repository or switch_project first."
            }
        ]
    return retriever.query_codebase(_active_repo_path, question, top_k, file_filter)


@mcp.tool()
def switch_project(repo_path: str) -> dict:
    """Switch the active project without re-indexing.

    Use this when you want to query a previously indexed repo.
    The repo must have been indexed before with index_repository.

    Args:
        repo_path: Absolute path to a previously indexed repository.
    """
    global _active_repo_path
    stats = retriever.get_index_stats(repo_path)
    if stats.get("status") == "not_indexed":
        return {
            "error": f"Repository not indexed. Run index_repository('{repo_path}') first."
        }
    _active_repo_path = repo_path
    return {"active_project": repo_path, **stats}


@mcp.tool()
def list_indexed_files() -> list[str]:
    """List all file paths currently indexed in the active project.

    Useful for understanding what's in the index and verifying
    that the right files were captured.
    """
    if not _active_repo_path:
        return ["No active project. Call index_repository or switch_project first."]
    return retriever.list_indexed_files(_active_repo_path)


@mcp.tool()
def get_index_stats() -> dict:
    """Get statistics about the active project's index.

    Returns total chunks, total files, last indexed commit, etc.
    """
    if not _active_repo_path:
        return {
            "error": "No active project. Call index_repository or switch_project first."
        }
    return retriever.get_index_stats(_active_repo_path)


@mcp.tool()
def list_projects() -> list[dict]:
    """List all previously indexed projects.

    Shows all repos that have been indexed, with their paths
    and last indexed commit. Use switch_project to activate one.
    """
    return retriever.list_projects()


def main():
    """Entry point for the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
