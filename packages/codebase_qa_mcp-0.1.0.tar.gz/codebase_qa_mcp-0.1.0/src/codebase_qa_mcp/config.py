"""Configuration constants for the Codebase Q&A MCP server."""

import os
from pathlib import Path

# Chunking
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50

# Embedding model (runs locally, no API key needed)
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# Retrieval
TOP_K = 5

# File types to index
SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx",
    ".md", ".txt", ".rst",
    ".java", ".go", ".rs", ".c", ".cpp", ".h", ".hpp",
    ".yaml", ".yml", ".json", ".toml",
    ".sh", ".bash", ".zsh",
    ".html", ".css", ".scss",
    ".sql",
    ".dockerfile",
}

# Directories to skip during indexing
IGNORED_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv",
    "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
    ".next", ".nuxt", "target", "vendor", ".eggs", "*.egg-info",
}

# ChromaDB storage (user-level, not inside any repo)
CHROMA_DB_PATH = os.environ.get(
    "CODEBASE_QA_CHROMA_PATH",
    str(Path.home() / ".local" / "share" / "codebase-qa-mcp" / "chroma_db"),
)
