"""Entry point for python -m slurmgrid."""

from .cli import main

main()
