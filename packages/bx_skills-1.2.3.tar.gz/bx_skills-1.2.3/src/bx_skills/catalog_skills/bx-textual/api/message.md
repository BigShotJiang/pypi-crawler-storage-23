*API reference: `textual.message`*
