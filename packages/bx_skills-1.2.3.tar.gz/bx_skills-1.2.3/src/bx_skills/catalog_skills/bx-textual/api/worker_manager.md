*API reference: `textual.worker_manager`*
