*API reference: `textual.highlight`*
