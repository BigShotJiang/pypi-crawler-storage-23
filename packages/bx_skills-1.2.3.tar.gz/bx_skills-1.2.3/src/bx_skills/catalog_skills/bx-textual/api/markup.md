*API reference: `textual.markup`*

## See also

- [Guide: Content](../guide/content.md) - In-depth guide to content and markup rendering
