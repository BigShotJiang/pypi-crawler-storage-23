*API reference: `textual.containers`*

## See also

- [How-To: Work with Containers](../how-to/work-with-containers.md) - Practical guide to using layout containers
