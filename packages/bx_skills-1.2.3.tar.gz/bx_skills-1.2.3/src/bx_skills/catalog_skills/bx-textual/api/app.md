*API reference: `textual.app`*

## See also

- [Guide: App Basics](../guide/app.md) - In-depth guide to the App class
