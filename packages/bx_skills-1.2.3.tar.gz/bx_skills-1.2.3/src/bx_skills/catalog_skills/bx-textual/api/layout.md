*API reference: `textual.layout`*

## See also

- [Guide: Layout](../guide/layout.md) - In-depth guide to layout in Textual
