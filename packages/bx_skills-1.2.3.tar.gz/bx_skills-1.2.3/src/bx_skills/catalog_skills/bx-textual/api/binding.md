*API reference: `textual.binding`*

## See also

- [Guide: Input](../guide/input.md) - In-depth guide to key bindings and input handling
