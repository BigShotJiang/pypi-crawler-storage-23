*API reference: `textual.work`*

## See also

- [Guide: Workers](../guide/workers.md) - In-depth guide to the work decorator and workers
