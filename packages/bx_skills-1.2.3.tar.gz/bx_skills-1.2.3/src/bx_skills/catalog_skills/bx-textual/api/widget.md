*API reference: `textual.widget`*

## See also

- [Guide: Widgets](../guide/widgets.md) - In-depth guide to building and using widgets
