*API reference: `textual.reactive`*

## See also

- [Guide: Reactivity](../guide/reactivity.md) - In-depth guide to reactive attributes
