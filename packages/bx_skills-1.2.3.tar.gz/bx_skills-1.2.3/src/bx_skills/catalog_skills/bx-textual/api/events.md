*API reference: `textual.events`*

## See also

- [Guide: Events](../guide/events.md) - In-depth guide to handling events
