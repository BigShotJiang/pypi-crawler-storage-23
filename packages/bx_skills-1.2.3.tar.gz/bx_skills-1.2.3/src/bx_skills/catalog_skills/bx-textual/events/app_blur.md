*API reference: `textual.events.AppBlur`*


## See also

- [AppFocus](app_focus.md) - Sent when the application gains focus
- [Blur](blur.md) - Sent when an individual widget loses focus
- [Events guide](../guide/events.md) - Introduction to Textual's event system
