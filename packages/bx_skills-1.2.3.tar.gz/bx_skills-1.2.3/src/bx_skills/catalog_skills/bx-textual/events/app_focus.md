*API reference: `textual.events.AppFocus`*


## See also

- [AppBlur](app_blur.md) - Sent when the application loses focus
- [Focus](focus.md) - Sent when an individual widget gains focus
- [Events guide](../guide/events.md) - Introduction to Textual's event system
