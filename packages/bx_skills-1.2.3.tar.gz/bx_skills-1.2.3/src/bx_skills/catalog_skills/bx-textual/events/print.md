*API reference: `textual.events.Print`*


## See also

- [Events guide](../guide/events.md) - Introduction to Textual's event system
