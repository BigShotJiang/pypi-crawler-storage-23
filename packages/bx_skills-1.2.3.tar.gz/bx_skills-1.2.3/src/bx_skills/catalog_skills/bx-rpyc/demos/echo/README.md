# Simple Echo Server
The client will open a connection once and send a message. The server is a `OneShotServer`. So, the server will close once the client is done.
