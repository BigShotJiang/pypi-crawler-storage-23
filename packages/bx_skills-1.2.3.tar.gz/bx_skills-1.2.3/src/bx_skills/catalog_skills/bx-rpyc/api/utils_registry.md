# Registry

> Auto-generated API documentation for `rpyc.utils.registry`. See source code.
