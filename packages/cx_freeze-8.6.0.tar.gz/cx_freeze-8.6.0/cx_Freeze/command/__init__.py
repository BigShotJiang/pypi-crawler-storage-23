"""Creates or extends setuptools commands."""
