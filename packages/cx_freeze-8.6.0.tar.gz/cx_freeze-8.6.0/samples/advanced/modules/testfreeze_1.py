print("Test freeze module #1")
