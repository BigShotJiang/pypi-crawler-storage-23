Release notes
=============

.. toctree::
   :maxdepth: 2
   :hidden:

   releasenotes-8x.rst
   releasenotes-7x.rst
   releasenotes-6x.rst
   releasenotes-5x.rst

- :doc:`releasenotes-8x`
- :doc:`releasenotes-7x`
- :doc:`releasenotes-6x`
- :doc:`releasenotes-5x`
