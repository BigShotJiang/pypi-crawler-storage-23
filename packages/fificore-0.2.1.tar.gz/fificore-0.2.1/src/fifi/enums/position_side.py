from enum import Enum


class PositionSide(Enum):
    LONG = "long"
    SHORT = "short"
