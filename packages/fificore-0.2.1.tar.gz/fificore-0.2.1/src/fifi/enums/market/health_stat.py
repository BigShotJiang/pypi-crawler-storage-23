from enum import Enum


class HealthStat(Enum):
    IS_UPDATED = 0
    TIME = 1
