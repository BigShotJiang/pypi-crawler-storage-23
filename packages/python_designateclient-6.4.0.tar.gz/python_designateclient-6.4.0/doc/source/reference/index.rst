========================================
python-designateclient Package Reference
========================================

.. toctree::
   :maxdepth: 4

   api/modules
