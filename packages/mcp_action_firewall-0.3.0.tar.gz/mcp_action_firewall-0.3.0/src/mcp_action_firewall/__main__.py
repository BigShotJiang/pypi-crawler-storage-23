"""Allow running with ``python -m mcp_action_firewall``."""

from mcp_action_firewall.server import main

main()
