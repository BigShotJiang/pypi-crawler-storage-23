"""MCP Action Firewall — a transparent MCP proxy that blocks dangerous tool calls."""

__version__ = "0.3.0"
