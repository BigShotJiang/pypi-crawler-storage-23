from setuptools import setup, find_packages
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()
setup(
    name="ltlbp",
    version="1.0.0",
    description="Logarithmic Transformation of Local Binary Pattern (LT-LBP)",
    author="P.Pankaja Lakshmi",
    license="MIT License",
    packages=find_packages(),
    install_requires=["numpy"],
    python_requires=">=3.7",
    long_description=long_description,
    long_description_content_type="text/markdown",
)
