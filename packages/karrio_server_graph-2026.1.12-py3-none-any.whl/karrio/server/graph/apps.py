from django.apps import AppConfig


class GraphConfig(AppConfig):
    name = 'karrio.server.graph'
