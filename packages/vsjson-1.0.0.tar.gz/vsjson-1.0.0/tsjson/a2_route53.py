"""
Route53 备份辅助方法 V2
基于 a_route53.py，修复 b_a_route53.md 审查发现的所有问题：

修复清单:
  1. [高] recordID 加入 identifier 维度，保证文件内唯一性闭合
  2. [中] Alias 记录跳过时打印日志，明确标识非全量备份
  3. [低] sem 参数添加说明，消除歧义
  4. [补] 分页使用 IsTruncated 判断 + StartRecordIdentifier 支持，避免 Geo/权重路由记录遗漏
"""
import logging
import re
import uuid

from libs.route53 import Route53Client, get_record_host, get_domain_record
from utils import DomainException


async def route53_domain_map_for_backup(client: Route53Client, sem) -> dict:
    """
    获取 Route53 账号下所有域名 → {domain_name: zone_id} 映射。
    与 AliDNSClient.domain_map_for_backup 接口对齐。

    参数 sem: Semaphore，仅用于与其他厂商 Target 接口签名对齐，函数内部未使用。
    """
    domain_list = await client.hoster_domain_list(page_size=100)
    return {d['domains'].lower(): d['domainsID'] for d in domain_list}


async def route53_record_list_for_backup(client: Route53Client, domain_name, h_domain_id=None, **kwargs) -> list:
    """
    获取某个 Hosted Zone 的全部解析记录（排除 SOA/NS），返回格式与 AliDNSClient.record_list_for_backup 对齐：
    [{'recordID': ..., 'record': ..., 'type': ..., 'value': ..., 'TTL': ..., 'geo': ..., 'identifier': ...}, ...]

    修复点:
      1. recordID 包含 identifier，保证 5 维唯一: zone_id+host+type+geo+identifier
      2. Alias 记录跳过时记录日志
      3. 分页使用 IsTruncated + StartRecordIdentifier，支持 Geo/权重路由
    """
    zone_id = h_domain_id or kwargs.get('zone_id')
    if not zone_id:
        raise DomainException(code=-1, message="缺少 zone_id 参数")

    record_list = []
    # [修复4] 分页参数初始化
    start_name = None
    start_type = None
    start_identifier = None

    while True:
        # [修复4] 构建分页请求参数，包含 StartRecordIdentifier
        req_kwargs = {
            'HostedZoneId': zone_id,
            'MaxItems': '300',
        }
        if start_name:
            req_kwargs['StartRecordName'] = start_name
            req_kwargs['StartRecordType'] = start_type
            # Geo/权重路由场景下同一 Name+Type 可能有多个 SetIdentifier
            if start_identifier:
                req_kwargs['StartRecordIdentifier'] = start_identifier

        data = await client.route53.list_resource_record_sets(**req_kwargs)

        for r in data.get('ResourceRecordSets', []):
            r_type = r.get('Type')
            if r_type in ('SOA', 'NS'):
                continue

            # [修复2] Alias 记录跳过并记录日志
            if not r.get('ResourceRecords'):
                alias_target = r.get('AliasTarget', {}).get('DNSName', '未知')
                host = get_record_host(r.get('Name'), domain_name)
                logging.info(
                    f"[route53_backup] 跳过 Alias 记录: "
                    f"zone={zone_id}, host={host}, type={r_type}, alias_target={alias_target}"
                )
                continue

            geo = r.get('GeoLocation')
            geo_code = ''
            if geo:
                geo_code = geo.get('CountryCode') or geo.get('ContinentCode') or ''

            host = get_record_host(r.get('Name'), domain_name)
            identifier = r.get('SetIdentifier', '')
            ispview_code = geo_code or 'simple'

            # [修复1] recordID 5 维唯一: zone_id+host+type+geo+identifier
            record_id = f"{zone_id}+{host}+{r_type}+{ispview_code}+{identifier}"

            value = ','.join([i.get('Value') for i in r.get('ResourceRecords')])

            item = {
                'recordID': record_id,
                'record': host,
                'type': r_type,
                'value': value,
                'TTL': r.get('TTL', 60),
                'geo': geo_code,
                'identifier': identifier,
            }
            record_list.append(item)

        # [修复4] 使用 IsTruncated 判断是否还有下一页
        if not data.get('IsTruncated', False):
            break

        start_name = data.get('NextRecordName', '')
        start_type = data.get('NextRecordType', '')
        start_identifier = data.get('NextRecordIdentifier', '')

    return record_list


async def route53_delete_record_for_backup(client: Route53Client, zone_id, record_host, domain_name,
                                            typ, value, ttl, geo_code='', identifier=''):
    """
    删除 Route53 上的单条解析记录。Route53 删除需要精确匹配所有字段。
    """
    full_name = get_domain_record(record_host, domain_name)
    req_kwargs = {
        'action': 'DELETE',
        'zone_id': zone_id,
        'record': full_name,
        'typ': typ,
        'value': value,
        'ttl': int(ttl),
    }
    if geo_code:
        if len(geo_code) == 2 and geo_code in client.country_codes:
            req_kwargs['country_code'] = geo_code
            req_kwargs['identifier'] = identifier
        elif geo_code in client.continent_codes:
            req_kwargs['continent_code'] = geo_code
            req_kwargs['identifier'] = identifier

    await client.create_update_delete_request(**req_kwargs)


async def route53_add_record_for_backup(client: Route53Client, zone_id, record_host, domain_name,
                                         typ, value, ttl, geo_code='', identifier=''):
    """
    通过 UPSERT 添加/更新 Route53 解析记录（幂等操作）。
    """
    full_name = get_domain_record(record_host, domain_name)
    req_kwargs = {
        'action': 'UPSERT',
        'zone_id': zone_id,
        'record': full_name,
        'typ': typ,
        'value': value,
        'ttl': int(ttl),
    }
    if geo_code:
        if len(geo_code) == 2 and geo_code in client.country_codes:
            req_kwargs['country_code'] = geo_code
            req_kwargs['identifier'] = identifier
        elif geo_code in client.continent_codes:
            req_kwargs['continent_code'] = geo_code
            req_kwargs['identifier'] = identifier

    await client.create_update_delete_request(**req_kwargs)


async def route53_add_domain_for_backup(client: Route53Client, domain_name):
    """
    在 Route53 上创建 Hosted Zone（如果已存在则用 UUID 绕过 CallerReference 冲突）。
    返回 zone_id。
    """
    try:
        response = await client.route53.create_hosted_zone(
            Name=domain_name, CallerReference=domain_name)
    except Exception as e:
        error = str(e)
        if re.search("already been created with the specified caller reference", error):
            response = await client.route53.create_hosted_zone(
                Name=domain_name, CallerReference=str(uuid.uuid4()))
        else:
            raise DomainException(code=-1, message=error)
    zone_id = response['HostedZone']['Id'].split('/')[-1]
    return zone_id
