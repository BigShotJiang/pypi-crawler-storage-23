"""
DNS 备份 V3.3 — 最终版
基于 a3_backup_view3.py (V3.2) 修复剩余 2 个低风险问题:
  - request.json 空值保护
  - 错误查询分页排序稳定性

累计修复清单 (V2 → V3.3):
  V3:   新增 aws_to_aws + Target 适配层 + 锁 6h + 重试修复 + _acme 字段修复
  V3.1: Geo/Identifier 全链路 + 状态判定 + 锁泄漏 + 域名大小写 + 续租机制 + 指数退避
  V3.2: ISPViewID→geo_code 6 元素 + bytes/str 续租 + gather 安全 + typ 白名单
  V3.3: request.json 空值保护 + 分页排序
"""
import asyncio
import copy
import logging
from asyncio import Semaphore
from datetime import datetime
from json import dumps, loads

from sanic.response import json
from sanic.views import HTTPMethodView

from base_util import format_timestamp
from libs import get_hoster_client
from libs.a_route53 import (
    route53_domain_map_for_backup,
    route53_record_list_for_backup,
    route53_delete_record_for_backup,
    route53_add_record_for_backup,
    route53_add_domain_for_backup,
)
from models import Hoster, Record
from models.domain import ISPView
from utils import Session, DomainException, chunker, RedisLock
from settings import es_settings
from utils.es import es_index

TASK_KEY = "dns_backup_v3"
EXPIRES = 864000  # 10 天

# 可重试错误集合
RETRYABLE_ERRORS = [
    "LastOperationNotFinished",
    "Throttling",
    "PriorRequestNotComplete",
    "TooManyRequests",
    "ServiceUnavailable",
]


# ========== 备份类型配置 ==========

VENDOR_TYPE_MAP = {
    "aws_to_aliyun": ("route53", "aliyun"),
    "aws_to_aws": ("route53", "route53"),
}

# 并发配置: (semaphore_size, http_session_limit, gather_batch_size)
CONCURRENCY_CONFIG = {
    "aws_to_aliyun": (16, 2, 5000),
    "aws_to_aws": (10, 2, 3000),
}

DEFAULT_CONCURRENCY = (16, 2, 5000)


# ========== Redis 进度管理 ==========

async def set_task(redis, typ, task_data):
    await redis.setex(f"{TASK_KEY}_{typ}", EXPIRES, dumps(task_data))


async def get_task(redis, typ):
    data = await redis.get(f"{TASK_KEY}_{typ}")
    return loads(data) if data else None


async def update_progress(redis, typ, **kwargs):
    task = await get_task(redis, typ)
    if task:
        task.update(**kwargs)
        await set_task(redis, typ, task)


async def incr_done(redis, typ):
    await redis.incr(f"{TASK_KEY}_{typ}_done")


async def incr_fail(redis, typ):
    """独立错误计数器"""
    await redis.incr(f"{TASK_KEY}_{typ}_fail")


async def error_record(redis, domain, typ, msg):
    await redis.setex(f"{TASK_KEY}_error_{typ}_{domain}", EXPIRES, msg)
    await incr_fail(redis, typ)


async def clear_error_records(redis, typ, count=1000):
    keys = [k async for k in redis.scan_iter(match=f"{TASK_KEY}_error_{typ}_*", count=count)]
    if keys:
        for batch in chunker(keys, count):
            await redis.delete(*batch)


async def task_info(redis, typ):
    """获取任务进度信息"""
    task = await get_task(redis, typ)
    if not task:
        return dict(
            from_account="", to_account="", start_time="", end_time="",
            domain_count_all=0, domain_done=0, status="暂无任务运行",
            state="", left_count=0, left_time=0, typ=typ, error_count=0
        )

    done_count = int(await redis.get(f"{TASK_KEY}_{typ}_done") or 0)
    total = task.get('domain_count_all', 0)
    left_count = max(total - done_count, 0)
    left_time = 0

    if left_count > 0 and task.get('status') == '运行中' and done_count > 0:
        now_ts = datetime.now().timestamp()
        start_ts = datetime.strptime(task['start_time'], '%Y-%m-%d %H:%M:%S').timestamp()
        elapsed = now_ts - start_ts
        if elapsed > 0:
            left_time = int(elapsed * left_count / done_count)

    error_count = int(await redis.get(f"{TASK_KEY}_{typ}_fail") or 0)

    task.update(
        domain_done=done_count,
        left_count=left_count,
        left_time=left_time,
        typ=typ,
        error_count=error_count
    )
    return task


# ========== ISPViewID → geo_code 映射 ==========

async def build_geo_map(records):
    """批量查询 ISPView 表，构建 {ISPViewID: geo_code} 映射
    Record.ISPViewID 存的是 ISPView 表的主键 id，
    ISPView.code 存的是 Route53 的国家/大洲代码 (如 'CN', 'US', 'AS', 'simple')。
    """
    isp_ids = {r[6] for r in records if r[6]}
    if not isp_ids:
        return {}
    isps = await ISPView.filter(id__in=isp_ids, vendor="route53").values("id", "code")
    geo_map = {i["id"]: i["code"] for i in isps}
    # 'simple' 对应无 Geo 路由，在备份中用空字符串表示
    return {k: ('' if v == 'simple' else v) for k, v in geo_map.items()}


# ========== 记录转换函数 ==========

def a_split(records):
    """AWS→阿里云: 拆分多值 A 记录, CNAME 加尾点, TTL 强制 600, 丢弃 geo/identifier"""
    new_records = []
    ttl = 600
    for r in records:
        # r = [host, typ, value, ttl, geo_code, identifier] (6 元素)
        host, typ = r[0], r[1].upper()
        value = r[2]
        if typ != "A":
            if typ == "CNAME":
                value = value.lstrip('"').rstrip('".') + "."
            # 阿里云不支持 Geo 路由，输出 4 元组
            new_records.append([host, typ, value, ttl])
        else:
            for v in value.split(","):
                new_records.append([host, typ, v.strip(), ttl])
    return new_records


def a_keep(records):
    """AWS→AWS: 保持原始格式, 保留 geo+identifier (6 元素)"""
    new_records = []
    for r in records:
        # r = [host, typ, value, ttl, geo_code, identifier] (6 元素)
        r[1] = r[1].upper()
        if r[1] == "CNAME":
            r[2] = r[2].rstrip('.') + '.'
        if r[1] == "TXT":
            v = r[2].strip('"\'')
            r[2] = f'"{v}"'
        new_records.append(r)
    return new_records


def process_record(records, typ):
    """根据备份类型对记录进行预处理"""
    if typ == "aws_to_aliyun":
        records = a_split(records)   # 输出 4 元素
    elif typ == "aws_to_aws":
        records = a_keep(records)    # 输出 6 元素
    return sorted(records)


# ========== 目标端适配层 ==========

class AliyunTarget:
    """阿里云目标端操作 — record 为 4 元素 [host, typ, value, ttl]"""

    def __init__(self, client):
        self.client = client

    async def get_domain_map(self, sem):
        return await self.client.domain_map_for_backup(sem)

    async def get_record_list(self, domain_name, h_domain_id):
        return await self.client.record_list_for_backup(
            domain_name=domain_name, h_domain_id=h_domain_id)

    async def add_domain(self, domain_name):
        return await self.client.add_domain(domain_name)

    async def add_record(self, domain_name, h_domain_id, record):
        """record: [host, typ, value, ttl]"""
        return await self.client.add_record(
            domain=domain_name, domain_name=domain_name,
            domain_id=h_domain_id, raw=True,
            record=record[0], typ=record[1], value=record[2], ttl=record[3])

    async def delete_record(self, record_id, **kwargs):
        return await self.client.delete_record_for_backup(record_id)

    def build_record_key(self, r):
        """比对 key: (record, type, value, ttl) — 阿里云无 geo"""
        value = r["value"] if r["type"].upper() != "CNAME" else r["value"].rstrip('.') + '.'
        return (r["record"], r["type"].upper(), value, r['TTL'])

    def get_record_id(self, r):
        return r["recordID"]


class Route53Target:
    """Route53 目标端操作 — record 为 6 元素 [host, typ, value, ttl, geo, identifier]"""

    def __init__(self, client):
        self.client = client

    async def get_domain_map(self, sem):
        return await route53_domain_map_for_backup(self.client, sem)

    async def get_record_list(self, domain_name, h_domain_id):
        return await route53_record_list_for_backup(
            self.client, domain_name=domain_name, h_domain_id=h_domain_id)

    async def add_domain(self, domain_name):
        return await route53_add_domain_for_backup(self.client, domain_name)

    async def add_record(self, domain_name, h_domain_id, record):
        """record: [host, typ, value, ttl, geo_code, identifier] — 传入 geo+identifier"""
        geo_code = record[4] if len(record) > 4 else ''
        identifier = record[5] if len(record) > 5 else ''
        await route53_add_record_for_backup(
            self.client, zone_id=h_domain_id, record_host=record[0],
            domain_name=domain_name, typ=record[1], value=record[2], ttl=record[3],
            geo_code=geo_code, identifier=identifier)
        ispview = geo_code or 'simple'
        return f"{h_domain_id}+{record[0]}+{record[1]}+{ispview}+{identifier}"

    async def delete_record(self, record_id, **kwargs):
        """Route53 删除需要精确匹配所有字段"""
        await route53_delete_record_for_backup(
            self.client,
            kwargs.get('zone_id'), kwargs.get('record_host'),
            kwargs.get('domain_name'), kwargs.get('typ'),
            kwargs.get('value'), kwargs.get('ttl'),
            kwargs.get('geo', ''), kwargs.get('identifier', ''))

    def build_record_key(self, r):
        """比对 key: (record, type, value, ttl, geo, identifier) — 6 维"""
        return (r["record"], r["type"].upper(), r["value"], r['TTL'],
                r.get('geo', ''), r.get('identifier', ''))

    def get_record_id(self, r):
        """record_id 加入 identifier 维度，避免同 host/type/geo 冲突"""
        rid = r["recordID"]
        identifier = r.get('identifier', '')
        if identifier and not rid.endswith(f"+{identifier}"):
            rid = f"{rid}+{identifier}"
        return rid


def get_target(to_vendor_name, client):
    """根据目标厂商名称返回对应的 Target 适配器"""
    if to_vendor_name == "aliyun":
        return AliyunTarget(client)
    elif to_vendor_name == "route53":
        return Route53Target(client)
    else:
        raise DomainException(code=-1, message=f"不支持的目标厂商: {to_vendor_name}")


# ========== 核心备份逻辑 ==========

async def add_single_record(target, domain_name, h_domain_id, record):
    """添加单条解析，可重试错误 + 指数退避"""
    for attempt in range(3):
        try:
            return await target.add_record(domain_name, h_domain_id, record)
        except DomainException as e:
            err_str = str(e)
            if any(code in err_str for code in RETRYABLE_ERRORS) and attempt < 2:
                await asyncio.sleep(1 * (2 ** attempt))  # 1s, 2s
                continue
            return e
        except Exception as e:
            return e


async def add_records_batch(target, redis, domain_name, h_domain_id, records, typ):
    """批量添加解析记录，返回错误消息（None 表示全部成功）"""
    error_msgs = []
    for batch in chunker(records, 500):
        tasks = [add_single_record(target, domain_name, h_domain_id, r) for r in batch]
        results = await asyncio.gather(*tasks)
        for i, res in enumerate(results):
            if isinstance(res, Exception):
                r = batch[i]
                error_msgs.append(f"record={r[0]},typ={r[1]},value={r[2]},ttl={r[3]},失败:{res}")

    if error_msgs:
        msg = "\r\n".join(error_msgs)
        logging.info(f'{typ}:{domain_name}:{msg}')
        await error_record(redis, domain_name, typ, msg)
        return msg
    return None


async def add_new_domain(target, domain_name, records, redis, typ, r_cache_key, did_cache_key):
    """在目标端创建新域名并写入全部解析"""
    try:
        h_domain_id = await target.add_domain(domain_name)
    except DomainException as e:
        e_str = str(e).lower()
        if any(kw in e_str for kw in ('duplicate', 'exist', '存在')):
            try:
                domain_map = await target.get_domain_map(Semaphore(1))
                h_domain_id = domain_map.get(domain_name.lower())
                if not h_domain_id:
                    return await error_record(redis, domain_name, typ, f"域名已存在但无法获取ID:{e}")
            except Exception:
                return await error_record(redis, domain_name, typ, f"添加域名失败:{e}")
        else:
            return await error_record(redis, domain_name, typ, f"添加域名失败:{e}")
    except Exception as e:
        # 捕获所有异常（ConnectionError, TimeoutError 等）
        return await error_record(redis, domain_name, typ, f"添加域名异常:{e}")

    await redis.hset(did_cache_key, domain_name, h_domain_id)
    res = await add_records_batch(target, redis, domain_name, h_domain_id, records, typ)
    if not res:
        await redis.hset(r_cache_key, domain_name, dumps(records))


async def update_domain(target, h_domain_id, domain_name, records, redis, typ,
                        r_cache_key, did_cache_key):
    """增量同步：对比目标端现有解析，删除多余、新增缺失"""
    try:
        to_records = await target.get_record_list(domain_name, h_domain_id)
    except Exception as e:
        return await error_record(redis, domain_name, typ, f"获取目标解析失败:{e}")

    # 构建目标端解析 map: {record_id: (record_key_tuple, raw_record)}
    to_records_map = {}
    for r in to_records:
        r_typ = r["type"].upper()
        if r_typ == "CAA" or r.get("record", "").startswith("_acme-challenge"):
            continue
        key = target.build_record_key(r)
        to_records_map[target.get_record_id(r)] = (key, r)

    # 构建源端解析 set
    records_copy = copy.deepcopy(records)
    source_set = {tuple(r): None for r in records}

    # 删除目标端多余解析
    for rid, (key, raw_r) in to_records_map.items():
        if key not in source_set:
            try:
                await target.delete_record(rid,
                    zone_id=h_domain_id, record_host=raw_r.get('record'),
                    domain_name=domain_name, typ=raw_r.get('type'),
                    value=raw_r.get('value'), ttl=raw_r.get('TTL'),
                    geo=raw_r.get('geo', ''), identifier=raw_r.get('identifier', ''))
            except Exception as e:
                logging.info(f"{typ}:{domain_name}删除解析{key}失败:{e}")
                return await error_record(redis, domain_name, typ, f"删除解析失败:{e}")
        else:
            del source_set[key]

    if not source_set:
        await redis.hset(r_cache_key, domain_name, dumps(records_copy))
        return

    logging.info(f"{typ}:{domain_name}:{len(source_set)}条解析需要更新")
    res = await add_records_batch(target, redis, domain_name, h_domain_id,
                                   list(source_set.keys()), typ)
    if not res:
        await redis.hset(r_cache_key, domain_name, dumps(records_copy))


async def process_domain_task(semaphore, target, h_domain_id, domain_name, records,
                               redis, typ, r_cache_key, did_cache_key, is_update):
    """单个域名的处理协程 — try/except 捕获所有异常，finally 保证 incr_done"""
    try:
        async with semaphore:
            if is_update:
                await update_domain(target, h_domain_id, domain_name, records,
                                    redis, typ, r_cache_key, did_cache_key)
            else:
                await add_new_domain(target, domain_name, records,
                                     redis, typ, r_cache_key, did_cache_key)
    except Exception as e:
        logging.exception(f"[V3.3] {typ}:{domain_name} 未捕获异常: {e}")
        try:
            await error_record(redis, domain_name, typ, f"未预期异常: {e}")
        except Exception:
            pass
    finally:
        await incr_done(redis, typ)


async def backup_dns(from_hoster: Hoster, to_hoster: Hoster, typ: str, redis, is_test):
    """主备份流程"""
    to_vendor_name = VENDOR_TYPE_MAP[typ][1]

    # 1. 从 Record 表查询源数据
    params = dict(domain__hoster__id=from_hoster.id, state=0)
    exclude = dict(typ="CAA")
    values = ["domain__name", 'record', 'typ', 'value', 'ttl', 'identifier', 'ISPViewID']
    if is_test:
        params["domain__name__in"] = is_test

    logging.info(f"[V3.3] 开始备份: {typ}, 参数: {params}")

    records = await Record.filter(**params).exclude(**exclude).distinct().values_list(*values)
    if not records:
        return await update_progress(redis, typ, domain_count_all=0, status="成功", state="没有需要更新的数据",
                                     end_time=format_timestamp())

    # 构建 ISPViewID → geo_code 映射（仅 aws_to_aws 需要）
    geo_map = {}
    if typ == "aws_to_aws":
        geo_map = await build_geo_map(records)
        logging.info(f"[V3.3] geo_map 构建完成: {len(geo_map)} 条映射")

    # 按域名分组，域名统一 lower + rstrip('.')
    domain_record_map = {}
    for r in records:
        domain_name = r[0].lower().rstrip('.')
        # r = (domain_name, record, typ, value, ttl, identifier, ISPViewID)
        identifier = r[5] or ''
        isp_view_id = r[6] or 0

        # 构建完整 6 元素: [record, typ, value, ttl, geo_code, identifier]
        geo_code = geo_map.get(isp_view_id, '') if typ == 'aws_to_aws' else ''
        domain_record_map.setdefault(domain_name, []).append(
            list(r[1:5]) + [geo_code, identifier]
        )

    # 2. 并发配置
    sem_size, limit, batch_size = CONCURRENCY_CONFIG.get(typ, DEFAULT_CONCURRENCY)
    semaphore = Semaphore(sem_size)

    # 3. 缓存 key
    did_cache_key = f"{TASK_KEY}_{from_hoster.id}to{to_hoster.id}_domain_id"
    r_cache_key = f"{TASK_KEY}_{from_hoster.id}to{to_hoster.id}_records"
    has_id_cache = await redis.exists(did_cache_key)

    async with Session(limit=limit) as session:
        await update_progress(redis, typ,
                              domain_count_all=len(domain_record_map),
                              state="拉取目标端域名列表")

        client = get_hoster_client(to_hoster, session)
        target = get_target(to_vendor_name, client)

        # 4. 获取目标端域名映射（优先用缓存）
        if not has_id_cache:
            try:
                domain_map = await target.get_domain_map(semaphore)
            except Exception as e:
                return await update_progress(redis, typ, status="失败",
                                             state=f"拉取目标端数据失败: {e}",
                                             end_time=format_timestamp())
            if domain_map:
                await redis.hset(did_cache_key, mapping=domain_map)
        else:
            domain_map = await redis.hgetall(did_cache_key)

        records_cache = await redis.hgetall(r_cache_key)
        await update_progress(redis, typ, state="开始同步解析")

        # 5. 构建任务列表
        tasks = []
        for domain_name, raw_records in domain_record_map.items():
            processed = process_record(raw_records, typ)

            # 检查缓存，如果解析没有变化则跳过
            if domain_name in domain_map:
                cached_str = records_cache.get(domain_name)
                if cached_str:
                    try:
                        if loads(cached_str) == processed:
                            await incr_done(redis, typ)
                            continue
                    except Exception:
                        pass

                h_domain_id = domain_map[domain_name]
                task = process_domain_task(
                    semaphore, target, h_domain_id, domain_name, processed,
                    redis, typ, r_cache_key, did_cache_key, is_update=True)
            else:
                task = process_domain_task(
                    semaphore, target, None, domain_name, processed,
                    redis, typ, r_cache_key, did_cache_key, is_update=False)

            tasks.append(task)

        await redis.setex(f"{TASK_KEY}_{typ}_tasks", EXPIRES, len(tasks))

        # 6. 分批并发执行，return_exceptions=True 防止单任务异常中断整批
        if tasks:
            for batch in chunker(tasks, batch_size):
                results = await asyncio.gather(*batch, return_exceptions=True)
                for r in results:
                    if isinstance(r, Exception):
                        logging.error(f"[V3.3] gather 捕获异常: {r}")

    # 根据错误计数判定最终状态
    fail_count = int(await redis.get(f"{TASK_KEY}_{typ}_fail") or 0)
    done_count = int(await redis.get(f"{TASK_KEY}_{typ}_done") or 0)
    if fail_count == 0:
        final_status = "成功"
    elif fail_count >= done_count:
        final_status = "失败"
    else:
        final_status = "部分成功"

    await update_progress(redis, typ, status=final_status, state="完成",
                          end_time=format_timestamp(), error_count=fail_count)
    await es_index(es_settings.get('XOPS-INDEX'), {
        'operator': "定时任务",
        'from_hoster': from_hoster.account,
        'to_hoster': to_hoster.account,
        'action': 'dns备份v3',
        'status': final_status,
    })


# ========== 锁续租 ==========

async def lock_heartbeat(redis, lock, identifier, interval=300):
    """后台续租协程 — 使用 app.redis (异步, decode_responses=True)
    避免 lock.conn (同步 redis.Redis, 无 decode_responses) 的 bytes/str 比较问题
    """
    lock_key = lock.name
    lock_timeout = lock.lock_timeout
    while True:
        await asyncio.sleep(interval)
        try:
            current = await redis.get(lock_key)
            if current and current == identifier:
                await redis.expire(lock_key, lock_timeout)
            else:
                break
        except Exception:
            break


# ========== HTTP 视图 ==========

class DNSBackUpV3View(HTTPMethodView):
    """DNS 备份 V3.3 — 任务启动和查询"""

    async def get(self, request):
        """查询所有备份类型的任务状态"""
        redis = request.app.redis
        data = []
        for typ in VENDOR_TYPE_MAP:
            info = await task_info(redis, typ)
            data.append(info)
        return json(dict(code=0, data=data))

    async def post(self, request):
        """创建备份任务"""
        # [V3.3] 空 body 或非 JSON 时 request.json 为 None，用 or {} 防御
        data = request.json or {}
        typ = data.get("type")
        from_account = data.get("from_account")
        to_account = data.get("to_account")
        is_test = data.get("is_test")

        if not all((from_account, to_account)):
            return json(dict(code=-1, msg='账户信息不全'))

        if typ not in VENDOR_TYPE_MAP:
            types_str = ', '.join(VENDOR_TYPE_MAP.keys())
            return json(dict(code=-1, msg=f'type 错误，支持: {types_str}'))

        from_vendor, to_vendor = VENDOR_TYPE_MAP[typ]

        from_hoster = await Hoster.get_or_none(account=from_account, vendor=from_vendor)
        to_hoster = await Hoster.get_or_none(account=to_account, vendor=to_vendor)

        if not from_hoster or not to_hoster:
            return json(dict(code=-1, msg='源账号或目标账号不存在'))

        # 按 typ 分锁: 不同备份类型可并行，同类型互斥
        lock = RedisLock(f"{TASK_KEY}_{typ}", acquire_timeout=4, lock_timeout=21600)
        identifier = await lock.acquire()
        if not identifier:
            return json(dict(code=-1, msg='有相同类型的备份任务正在运行'))

        redis = request.app.redis

        # 初始化阶段 try/except 保护，异常时立即释放锁
        try:
            task_data = {
                'from_account': from_account,
                'to_account': to_account,
                'start_time': format_timestamp(),
                'end_time': '',
                'domain_count_all': 0,
                'status': '运行中',
                'state': '数据获取中',
            }
            await set_task(redis, typ, task_data)
            await redis.setex(f"{TASK_KEY}_{typ}_done", EXPIRES, 0)
            await redis.setex(f"{TASK_KEY}_{typ}_tasks", EXPIRES, -1)
            await redis.setex(f"{TASK_KEY}_{typ}_fail", EXPIRES, 0)
            await clear_error_records(redis, typ)
        except Exception as e:
            await lock.release(identifier)
            logging.exception(f"[V3.3] 任务初始化失败: {typ}")
            return json(dict(code=-1, msg=f'任务初始化失败: {e}'))

        # 启动异步备份任务
        async def run_backup():
            hb_task = asyncio.ensure_future(lock_heartbeat(redis, lock, identifier))
            try:
                await backup_dns(from_hoster, to_hoster, typ, redis, is_test)
            except Exception as e:
                logging.exception(f"[V3.3] 备份任务异常: {typ}")
                await update_progress(redis, typ, status="失败",
                                      state=f"任务异常: {e}",
                                      end_time=format_timestamp())
            finally:
                hb_task.cancel()
                await lock.release(identifier)

        asyncio.ensure_future(run_backup())

        return json(dict(code=0, msg='备份任务已创建'))


class DNSBackUpV3QueryView(HTTPMethodView):
    """DNS 备份 V3.3 — 错误查询"""

    async def get(self, request):
        params = request.ctx.query
        redis = request.app.redis
        typ = params.get('typ')
        is_all = params.get('all')
        page = int(params.pop('page', 1))
        limit = int(params.pop('limit', 10))
        domain = params.get('domain')

        if not typ:
            return json(dict(code=-1, msg='typ 参数不能为空'))

        if typ not in VENDOR_TYPE_MAP:
            return json(dict(code=-1, msg=f'typ 错误，支持: {", ".join(VENDOR_TYPE_MAP.keys())}'))

        end = page * limit
        start = end - limit
        count, data = 0, []

        if not domain:
            # [V3.3] sorted 保证分页结果稳定，SCAN 返回顺序不固定
            keys = sorted([k async for k in redis.scan_iter(
                match=f"{TASK_KEY}_error_{typ}_*", count=1000)])
            if keys:
                values = await redis.mget(keys)
                count = len(values)
                prefix_len = len(f"{TASK_KEY}_error_{typ}_")
                for i, key in enumerate(keys):
                    d = key[prefix_len:]
                    data.append({"domain": d, "value": values[i]})
                if not is_all:
                    data = data[start:end]
        else:
            value = await redis.get(f"{TASK_KEY}_error_{typ}_{domain}")
            if value:
                data = [{"domain": domain, "value": value}]
                count = 1

        return json(dict(code=0, data=data, count=count))
