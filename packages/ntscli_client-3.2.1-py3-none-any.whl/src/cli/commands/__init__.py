#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""CLI commands package."""

from src.cli.commands.calibration import run_eleven_calibration_plan, run_eyepatch_calibration_plan
from src.cli.commands.device import get_host_devices, release_device_reservation, set_device_ui, status
from src.cli.commands.plan import cancel, get_plan_from_device, get_run_plan_summary, run_plan
from src.cli.commands.utility import get_nts_cli_dockerfile

__all__ = [
    # Plan commands
    "get_plan_from_device",
    "run_plan",
    "get_run_plan_summary",
    "cancel",
    # Device commands
    "status",
    "release_device_reservation",
    "get_host_devices",
    "set_device_ui",
    # Calibration commands
    "run_eyepatch_calibration_plan",
    "run_eleven_calibration_plan",
    # Utility commands
    "get_nts_cli_dockerfile",
]
