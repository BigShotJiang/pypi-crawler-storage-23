#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Test result related CLI commands."""

from typing import List, Optional, TextIO

import click

from src.cli.options import common_auth_options, common_output_option
from src.cli.validators import handle_exceptions, validate_user_authentication
from src.command_impls.get_test_result_impl import GetTestResultCommandImpl
from src.decorators.command_event import capture_command_event


def parse_run_ids(ctx, param, value: tuple) -> List[str]:
    """Parse space-separated and/or comma-separated runIDs into a flat list."""
    if not value:
        return []
    result = []
    for item in value:
        result.extend(run_id.strip() for run_id in item.split(",") if run_id.strip())
    return result


@click.command(
    name="get-test-result",
    short_help="Get test results by runIDs",
    help="""Get test results for one or more runIDs.

RUN_IDS can be space-separated and/or comma-separated.

\b
Examples:
    nts get-test-result runid1 runid2 runid3
    nts get-test-result runid1,runid2,runid3
""",
)
@click.argument("run_ids", nargs=-1, callback=parse_run_ids)
@click.option(
    "--include-attachments",
    "include_attachments",
    is_flag=True,
    help="Include attachment URLs in the test result details",
)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def get_test_result(
    run_ids: List[str],
    include_attachments: bool,
    out_file: TextIO,
    net_key: Optional[str],
    use_netflix_access: bool,
):
    """
    Get test results for one or more runIDs.

    RUN_IDS can be space-separated and/or comma-separated.

    Examples:
        nts get-test-result runid1 runid2 runid3

        nts get-test-result runid1,runid2,runid3
    """
    if not run_ids:
        raise click.UsageError("At least one runID is required")
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    GetTestResultCommandImpl(net_key, use_netflix_access).run(out_file=out_file, run_ids=run_ids, include_attachments=include_attachments)
