#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Device related CLI commands: get-device-status, release-device-reservation, get-host-devices, set-device-ui."""

import json
from typing import Optional, TextIO

import click

from src.cli.constants import REQUIRES_RAE_OR_ESN_STR
from src.cli.options import common_auth_options, common_output_option, esn_option, rae_option
from src.cli.validators import handle_exceptions, validate_user_authentication
from src.clients.hardware_manager_client import HardwareManagerClient
from src.command_impls.release_device_impl import ReleaseDeviceCommandImpl
from src.command_impls.status_impl import StatusCommandImpl
from src.decorators.command_event import capture_command_event


@click.command(name="get-device-status", short_help="Get device status")
@rae_option(required=False)
@esn_option(required=False)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def status(rae: Optional[str], esn: Optional[str], out_file: TextIO, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to get device metadata.
    This includes information about the state of any test plans being run for the device.
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    if not any([rae, esn]):
        raise click.UsageError(REQUIRES_RAE_OR_ESN_STR)
    StatusCommandImpl(net_key, use_netflix_access).run(out_file=out_file, rae=rae, esn=esn)


@click.command(
    name="release-device-reservation",
    short_help="[TEMPORARY] Self-serve workaround to release stuck reservations without contacting platform teams",
)
@esn_option(required=True)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def release_device_reservation(esn: str, out_file: TextIO, net_key: Optional[str], use_netflix_access: bool):
    """
    Manually release a device reservation that is stuck.

    ⚠️  TEMPORARY WORKAROUND - This command provides a self-serve solution for releasing
    device reservations that become stuck. This is not intended for regular use and exists
    only until the underlying platform issue is resolved.

    This command reduces turnaround time by eliminating the need to communicate internally
    with platform teams to manually unblock devices before you can continue testing.
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    ReleaseDeviceCommandImpl(net_key, use_netflix_access).run(out_file=out_file, esn=esn)


@click.command(name="get-host-devices", short_help="Get the available devices for a host")
@rae_option(required=True)
@common_auth_options
@capture_command_event
@handle_exceptions
def get_host_devices(rae: str, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to get devices behind a host
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    hwm_client = HardwareManagerClient(net_key, use_netflix_access)
    devices = hwm_client.get_devices_for_host(rae)
    print(json.dumps(devices, indent=4))


@click.command(name="set-device-ui", short_help="set the UI mode for a device")
@rae_option(required=True)
@click.option(
    "--ip",
    type=str,
    help="IP address of the device to set the UI mode for",
    envvar="IP",
    required=True,
)
@click.option(
    "--env",
    help="UI environment to set for the device, such as 'test' or 'prod'",
    type=click.Choice(["test", "prod"]),
    envvar="DEVICE_ENV",
    required=True,
)
@common_auth_options
@capture_command_event
@handle_exceptions
def set_device_ui(rae: str, ip: str, env: str, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to set the device UI mode for a device behind a host.
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    hwm_client = HardwareManagerClient(net_key, use_netflix_access)
    devices = hwm_client.set_device_ui(rae, ip, env)
    print(json.dumps(devices, indent=4))
