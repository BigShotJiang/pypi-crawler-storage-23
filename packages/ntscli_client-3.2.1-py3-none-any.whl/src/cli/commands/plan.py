#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Test plan related CLI commands: get-plan, run-plan, get-run-plan-summary, cancel-running-plan."""

import json
from typing import Optional, TextIO

import click

from src.cli.constants import (
    BATCH_ID_HELP_STR,
    DYNAMIC_FILTER_ID_HELP_STR,
    OVERRIDE_HELP_STR,
    PLAN_FILE_HELP_STR,
    PLAN_FILE_PARSE_FAILURE_STR,
    PLAN_FILE_SIZE_FAILURE_STR,
    PLAN_TYPE_HELP_STR,
    PLAYLIST_ID_HELP_STR,
    REQUIRES_DYNAMIC_FILTER_ID_STR,
    REQUIRES_PLAYLIST_ID_STR,
    RUN_WAIT_HELP_STR,
    SDK_OR_APK_HELP_STR,
    TESTCASE_AUTOMATION_FILTER_HELP_STR,
    TESTCASE_CATEGORY_EXCLUDE_HELP_STR,
    TESTCASE_CATEGORY_FILTER_HELP_STR,
    TESTCASE_NAME_EXCLUDE_HELP_STR,
    TESTCASE_NAME_FILTER_HELP_STR,
    TESTCASE_STATE_FILTER_HELP_STR,
    TESTCASE_TAG_EXCLUDE_HELP_STR,
    TESTCASE_TAG_FILTER_HELP_STR,
)
from src.cli.options import common_auth_options, common_output_option, esn_option
from src.cli.validators import (
    handle_exceptions,
    validate_automation_filter,
    validate_state_filter,
    validate_user_authentication,
)
from src.clients.device_test_client import TestPlanFilters
from src.command_impls.cancel_impl import CancelCommandImpl
from src.command_impls.get_plan_impl import GetPlanCommandImpl, PlanType
from src.command_impls.get_run_plan_summary_impl import GetRunPlanSummaryCommandImpl
from src.command_impls.run_impl import RunCommandImpl
from src.decorators.command_event import capture_command_event
from src.log import logger


@click.command(name="get-plan", short_help="Get a test plan")
@esn_option(required=True)
@click.option(
    "--plan-type",
    "plan_type",
    type=click.Choice([pt.value for pt in PlanType]),
    required=True,
    help=PLAN_TYPE_HELP_STR,
)
@click.option(
    "--testcase-automation-filter",
    "testcase_automation_filter",
    type=str,
    callback=validate_automation_filter,
    help=TESTCASE_AUTOMATION_FILTER_HELP_STR,
)
@click.option(
    "--testcase-state-filter",
    "testcase_state_filter",
    type=str,
    callback=validate_state_filter,
    help=TESTCASE_STATE_FILTER_HELP_STR,
)
@click.option(
    "--testcase-name-filter",
    "testcase_name_filter",
    type=str,
    help=TESTCASE_NAME_FILTER_HELP_STR,
)
@click.option(
    "--testcase-tag-filter",
    "testcase_tag_filter",
    type=str,
    help=TESTCASE_TAG_FILTER_HELP_STR,
)
@click.option(
    "--testcase-category-filter",
    "testcase_category_filter",
    type=str,
    help=TESTCASE_CATEGORY_FILTER_HELP_STR,
)
@click.option(
    "--testcase-name-exclude",
    "testcase_name_exclude",
    type=str,
    help=TESTCASE_NAME_EXCLUDE_HELP_STR,
)
@click.option(
    "--testcase-tag-exclude",
    "testcase_tag_exclude",
    type=str,
    help=TESTCASE_TAG_EXCLUDE_HELP_STR,
)
@click.option(
    "--testcase-category-exclude",
    "testcase_category_exclude",
    type=str,
    help=TESTCASE_CATEGORY_EXCLUDE_HELP_STR,
)
@click.option("--playlist-id", "playlist_id", type=str, help=PLAYLIST_ID_HELP_STR)
@click.option(
    "--dynamic-filter-id",
    "dynamic_filter_id",
    type=str,
    help=DYNAMIC_FILTER_ID_HELP_STR,
)
@click.option("--sdk-or-apk", "sdk_or_apk", type=str, help=SDK_OR_APK_HELP_STR)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def get_plan_from_device(
    esn: str,
    plan_type: str,
    testcase_automation_filter: Optional[str],
    testcase_state_filter: Optional[str],
    testcase_name_filter: Optional[str],
    testcase_tag_filter: Optional[str],
    testcase_category_filter: Optional[str],
    testcase_name_exclude: Optional[str],
    testcase_tag_exclude: Optional[str],
    testcase_category_exclude: Optional[str],
    playlist_id: Optional[str],
    dynamic_filter_id: Optional[str],
    sdk_or_apk: Optional[str],
    out_file: TextIO,
    net_key: Optional[str],
    use_netflix_access: bool,
):
    """
    Command to get test plans of various types for a device
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)

    # Convert string to enum
    plan_type_enum = PlanType(plan_type)

    match plan_type_enum:
        case PlanType.PLAYLIST:
            if playlist_id is None:
                raise click.UsageError(REQUIRES_PLAYLIST_ID_STR)
        case PlanType.DYNAMIC_FILTER:
            if dynamic_filter_id is None:
                raise click.UsageError(REQUIRES_DYNAMIC_FILTER_ID_STR)

    # Construct filters object for test plan filtering
    filters = TestPlanFilters(
        automation=testcase_automation_filter,
        state=testcase_state_filter,
        name=testcase_name_filter,
        tag=testcase_tag_filter,
        category=testcase_category_filter,
        name_exclude=testcase_name_exclude,
        tag_exclude=testcase_tag_exclude,
        category_exclude=testcase_category_exclude,
    )

    # Warn if filters are provided for plan types that don't support them
    if plan_type_enum != PlanType.FULL and filters != TestPlanFilters():
        click.echo(
            f"Warning: Filter options are only supported for FULL plan type and will be ignored for {plan_type_enum.value}.",
            err=True,
        )

    GetPlanCommandImpl(net_key, use_netflix_access).run(
        out_file=out_file,
        esn=esn,
        plan_type=plan_type_enum,
        filters=filters,
        playlist_id=playlist_id,
        dynamic_filter_id=dynamic_filter_id,
        sdk_or_apk=sdk_or_apk,
    )


@click.command(name="run-plan", short_help="Run a test plan")
@click.option(
    "--plan-file",
    "plan_file",
    type=click.File("r", encoding="utf-8"),
    required=True,
    help=PLAN_FILE_HELP_STR,
)
@click.option("--override", multiple=True, help=OVERRIDE_HELP_STR)
@click.option("--wait", type=bool, is_flag=True, help=RUN_WAIT_HELP_STR)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def run_plan(plan_file: TextIO, override: tuple, wait: bool, out_file: TextIO, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to run an input test plan file
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    for item in override:
        if "=" not in item:
            raise click.UsageError(f"Invalid override format '{item}'. Expected key=value format. Example: --override foo=bar")
    overrides = dict(item.split("=", 1) for item in override)
    try:
        plan = json.load(plan_file)
    except Exception as e:
        logger.error(f"Failed to parse plan file: {e}")
        raise click.UsageError(PLAN_FILE_PARSE_FAILURE_STR)
    if "esn" not in plan:
        raise click.UsageError("Plan file must contain 'esn' field")
    if not isinstance(plan.get("test_case_guids"), list):
        raise click.UsageError("Plan file 'test_case_guids' must be a non-null list")
    if len(plan["test_case_guids"]) == 0:
        raise click.UsageError("Plan file 'test_case_guids' must contain at least one test case")
    if len(plan["test_case_guids"]) > 2000:
        raise click.UsageError(PLAN_FILE_SIZE_FAILURE_STR)

    # Merge CLI overrides with existing plan test_overrides (CLI takes precedence)
    existing_overrides = plan.get("test_overrides", {})
    existing_overrides.update(overrides)
    plan["test_overrides"] = existing_overrides

    RunCommandImpl(net_key, use_netflix_access).run(out_file=out_file, plan=plan, wait=wait)


@click.command(name="get-run-plan-summary", short_help="Get a summary for a test plan you have run")
@click.option(
    "--batch-id",
    "batch_id",
    type=str,
    required=True,
    help=BATCH_ID_HELP_STR,
    envvar="BATCH_ID",
)
@click.option(
    "--include-attachments",
    "include_attachments",
    type=bool,
    is_flag=True,
    help="Include attachment URLs in the test result details",
)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def get_run_plan_summary(
    batch_id: str,
    include_attachments: bool,
    out_file: TextIO,
    net_key: Optional[str],
    use_netflix_access: bool,
):
    """
    Command to get a summary for a test plan you have run
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    GetRunPlanSummaryCommandImpl(net_key, use_netflix_access).run(
        out_file=out_file, batch_id=batch_id, include_attachments=include_attachments
    )


@click.command(name="cancel-running-plan", short_help="Cancel a running test plan")
@click.option("--batch-id", "batch_id", type=str, required=True, help=BATCH_ID_HELP_STR)
@esn_option(required=True)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def cancel(batch_id: str, esn: str, out_file: TextIO, net_key: Optional[str], use_netflix_access: bool):
    """
    Cancel any test runs for a device.
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    CancelCommandImpl(net_key, use_netflix_access).run(out_file=out_file, batch_id=batch_id, esn=esn)
