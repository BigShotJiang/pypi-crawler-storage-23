#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Utility CLI commands: get-nts-cli-dockerfile."""

from typing import Optional

import click

from src.cli.options import common_auth_options, common_output_option
from src.cli.validators import handle_exceptions, validate_user_authentication
from src.decorators.command_event import capture_command_event


@click.command(
    name="get-nts-cli-dockerfile",
    short_help="Generates a Dockerfile for creating a Docker image with the NTS CLI client.",
)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def get_nts_cli_dockerfile(out_file, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to get a NTS CLI Dockerfile
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    dockerfile_content = """\
FROM python:3.10-slim-bullseye

RUN apt-get update && \\
    apt-get upgrade -y && \\
    apt-get install -y bash && \\
    rm -rf /var/lib/apt/lists/*

RUN pip3 install 'ntscli-client>=3.0.0,<4.0.0'

WORKDIR /ntscli

CMD ["/bin/sh"]
"""
    out_file.write(dockerfile_content)
