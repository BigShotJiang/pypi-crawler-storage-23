#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Calibration CLI commands: run-eyepatch-calibration-plan, run-eleven-calibration-plan."""

from typing import Optional, TextIO

import click

from src.cli.constants import SET_TOP_BOX, SMART_TV
from src.cli.options import common_auth_options, common_output_option, esn_option
from src.cli.validators import handle_exceptions, validate_user_authentication
from src.command_impls.run_eleven_calibration_impl import RunElevenCalibrationCommandImpl
from src.command_impls.run_eyepatch_calibration_impl import RunEyepatchCalibrationCommandImpl
from src.decorators.command_event import capture_command_event


@click.command(
    name="run-eyepatch-calibration-plan",
    short_help="Get the eyepatch calibration plan for a device and run it",
)
@esn_option(required=True)
@click.option(
    "--form-factor",
    "form_factor",
    required=False,
    type=click.Choice([SET_TOP_BOX, SMART_TV]),
    help="[DEPRECATED] This option is no longer used and will be removed in future versions.",
)
@click.option(
    "--smart-tv-topology",
    "smart_tv_topology",
    type=click.Choice(["TV", "TV->AVR"]),
    help="[DEPRECATED] This option is no longer used and will be removed in future versions.",
)
@click.option(
    "--stb-topology",
    "stb_topology",
    type=click.Choice(["STB->TV", "STB->AVR->TV"]),
    help="[DEPRECATED] This option is no longer used and will be removed in future versions.",
)
@click.option(
    "--audio-source",
    "audio_source",
    required=True,
    type=click.Choice(["line-in", "contact-mic", "magnetic-mic", "spdif", "arc", "earc"]),
    help="Audio transport to capture & analyze audio",
)
@click.option(
    "--audio-mode",
    "audio_mode",
    required=False,
    type=click.Choice(["PASSTHROUGH", "ATMOS", "DDP51", "PCM", "DOLBYMAT"]),
    help="[DEPRECATED] This option is no longer used and will be removed in future versions.",
)
@click.option(
    "--eyepatch-serial",
    "eyepatch_serial",
    type=str,
    help="The serial number of the eyepatch to be used.",
)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def run_eyepatch_calibration_plan(
    esn: str,
    form_factor: Optional[str],
    smart_tv_topology: Optional[str],
    stb_topology: Optional[str],
    audio_source: str,
    audio_mode: Optional[str],
    eyepatch_serial: Optional[str],
    out_file: TextIO,
    net_key: Optional[str],
    use_netflix_access: bool,
):
    """
    Command to get the eyepatch calibration test plan for a device and run it
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    if form_factor is not None:
        click.echo("Warning: --form-factor is deprecated and will be ignored.", err=True)
    if smart_tv_topology is not None:
        click.echo("Warning: --smart-tv-topology is deprecated and will be ignored.", err=True)
    if stb_topology is not None:
        click.echo("Warning: --stb-topology is deprecated and will be ignored.", err=True)
    if audio_mode is not None:
        click.echo("Warning: --audio-mode is deprecated and will be ignored.", err=True)

    RunEyepatchCalibrationCommandImpl(net_key, use_netflix_access).run(
        out_file=out_file, esn=esn, audio_source=audio_source, eyepatch_serial=eyepatch_serial
    )


@click.command(
    name="run-eleven-calibration-plan",
    short_help="Get the eleven calibration plan for a device and run it",
)
@esn_option(required=True)
@common_output_option
@common_auth_options
@capture_command_event
@handle_exceptions
def run_eleven_calibration_plan(esn: str, out_file: TextIO, net_key: Optional[str], use_netflix_access: bool):
    """
    Command to get the eleven calibration test plan for a device and run it
    """
    validate_user_authentication(net_key=net_key, use_netflix_access=use_netflix_access)
    RunElevenCalibrationCommandImpl(net_key, use_netflix_access).run(out_file=out_file, esn=esn)
