#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Reusable Click option decorators for common CLI options."""

import sys
from functools import wraps

import click

from src.cli.constants import (
    ESN_HELP_STR,
    NET_KEY_HELP_STR,
    OUT_FILE_HELP_STR,
    RAE_HELP_STR,
    USE_NETFLIX_ACCESS_HELP_STR,
)


def common_auth_options(func):
    """Add common authentication options (--net-key, --use-netflix-access)."""

    @click.option("--net-key", "net_key", type=str, help=NET_KEY_HELP_STR, envvar="NET_KEY")
    @click.option(
        "--use-netflix-access",
        "use_netflix_access",
        type=bool,
        is_flag=True,
        help=USE_NETFLIX_ACCESS_HELP_STR,
        envvar="USE_NETFLIX_ACCESS",
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def common_output_option(func):
    """Add common output file option (-o)."""

    @click.option(
        "-o",
        "out_file",
        type=click.File("w", encoding="utf-8"),
        help=OUT_FILE_HELP_STR,
        default=sys.stdout,
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def esn_option(required: bool = False):
    """Create ESN option decorator with configurable required flag."""

    def decorator(func):
        @click.option("--esn", "esn", type=str, required=required, help=ESN_HELP_STR, envvar="ESN")
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator


def rae_option(required: bool = False):
    """Create RAE option decorator with configurable required flag."""

    def decorator(func):
        @click.option("--rae", type=str, required=required, help=RAE_HELP_STR, envvar="RAE")
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        return wrapper

    return decorator
