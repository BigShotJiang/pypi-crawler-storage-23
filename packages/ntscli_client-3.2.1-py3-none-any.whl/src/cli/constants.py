#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""CLI constants, help strings, and error messages."""

# CLI parameter help strings
RAE_HELP_STR = "The Netflix RAE device serial to connect to, such as r3010203. Defaults to environment variable 'RAE'."
ESN_HELP_STR = "The ESN of the target device. Defaults to environment variable 'ESN'"
BATCH_ID_HELP_STR = "UUID of a currently running test batch"
PLAN_TYPE_HELP_STR = "Type of plan to target, defaults to FULL"
PLAYLIST_ID_HELP_STR = "UUID of a playlist from https://nts.prod.netflixpartners.com/#playlist"
DYNAMIC_FILTER_ID_HELP_STR = "UUID of a dynamic filter from https://nts.prod.netflixpartners.com/#testing"
SDK_OR_APK_HELP_STR = "SDK or APK version to load all tests from a dynamic filter, ignoring device capabilities"
OUT_FILE_HELP_STR = "Saves output to the specified file"
RUN_WAIT_HELP_STR = "Waits until tests have finished executing, ensuring the command output reflects the final result"
PLAN_FILE_HELP_STR = "Test plan output file that will be used as input for executing tests"
NET_KEY_HELP_STR = "Netflix Edge Token used to provide authenticated external partners access. Defaults to environment variable 'NET_KEY'"
USE_NETFLIX_ACCESS_HELP_STR = (
    "Flag to enable Netflix identity service for authenticated access. Defaults to environment variable 'USE_NETFLIX_ACCESS'"
)
VERBOSITY_HELP_STR = "[INTERNAL ONLY] Either CRITICAL, ERROR, WARNING, INFO or DEBUG"
OVERRIDE_HELP_STR = "Apply test plan override values as key=value pairs. Example: --override foo=bar --override baz=qux"
TESTCASE_AUTOMATION_FILTER_HELP_STR = (
    "[FULL plan type only] Include test cases matching these automation values (comma-separated). "
    "Allowed values: AUTOMATED, MANUAL, PERIPHERAL. Defaults to AUTOMATED,PERIPHERAL"
)
TESTCASE_STATE_FILTER_HELP_STR = (
    "[FULL plan type only] Include test cases matching these state values (comma-separated). "
    "Allowed values: ENABLED, MAINTENANCE. Defaults to ENABLED"
)
TESTCASE_NAME_FILTER_HELP_STR = "[FULL plan type only] Include tests whose names contain this substring (e.g., SYNC, PLAY)"
TESTCASE_TAG_FILTER_HELP_STR = "[FULL plan type only] Include test cases matching these tag values (comma-separated)"
TESTCASE_CATEGORY_FILTER_HELP_STR = "[FULL plan type only] Include test cases matching these category values (comma-separated)"
TESTCASE_NAME_EXCLUDE_HELP_STR = "[FULL plan type only] Exclude tests whose names contain this substring (e.g., FLAKY, SKIP)"
TESTCASE_TAG_EXCLUDE_HELP_STR = "[FULL plan type only] Exclude test cases matching these tag values (comma-separated)"
TESTCASE_CATEGORY_EXCLUDE_HELP_STR = "[FULL plan type only] Exclude test cases matching these category values (comma-separated)"

# CLI choice options
SET_TOP_BOX = "set-top-box"
SMART_TV = "smart-tv"
ALLOWED_TESTCASE_AUTOMATIONS = {"AUTOMATED", "MANUAL", "PERIPHERAL"}
ALLOWED_TESTCASE_STATES = {"ENABLED", "MAINTENANCE"}

# CLI command precondition strings (error messages)
PLAN_FILE_PARSE_FAILURE_STR = "Unable to parse plan file as valid JSON"
PLAN_FILE_SIZE_FAILURE_STR = "The max test_case_guid size in your test plan file to execute is 2000"
REQUIRES_NET_KEY_OR_NETFLIX_ACCESS_STR = "At least one of --net-key or --use-netflix-access is required to authenticate requests"
REQUIRES_RAE_OR_ESN_STR = "At least one of --rae or --esn must be specified."
REQUIRES_PLAYLIST_ID_STR = "Must specify --playlist-id"
REQUIRES_DYNAMIC_FILTER_ID_STR = "Must specify --dynamic-filter-id"
REQUIRES_SMART_TV_TOPOLOGY_STR = f"Must specify --smart-tv-topology if --form-factor is {SMART_TV}"
REQUIRES_STB_TOPOLOGY_STR = f"Must specify --stb-topology if --form-factor is {SET_TOP_BOX}"
