#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""CLI validation functions and decorators."""

import functools
import sys

import click

from src.cli.constants import (
    ALLOWED_TESTCASE_AUTOMATIONS,
    ALLOWED_TESTCASE_STATES,
    REQUIRES_NET_KEY_OR_NETFLIX_ACCESS_STR,
)
from src.exceptions import (
    DeviceAlreadyReservedException,
    DeviceIsUnavailableException,
    ForbiddenException,
    MissingMetatronException,
    UnauthorizedException,
    UnclaimedDeviceException,
)


def validate_user_authentication(net_key: str, use_netflix_access: bool) -> None:
    """Validate that at least one authentication method is provided."""
    if net_key is None and not use_netflix_access:
        raise click.UsageError(REQUIRES_NET_KEY_OR_NETFLIX_ACCESS_STR)


def validate_automation_filter(ctx, param, value):
    """Click callback to validate automation filter values."""
    if value is None:
        return None
    choices = [v.strip().upper() for v in value.split(",") if v.strip()]
    invalid = [v for v in choices if v not in ALLOWED_TESTCASE_AUTOMATIONS]
    if invalid:
        raise click.BadParameter(f"Invalid values: {', '.join(invalid)}. Allowed values are: {', '.join(ALLOWED_TESTCASE_AUTOMATIONS)}")
    return value


def validate_state_filter(ctx, param, value):
    """Click callback to validate state filter values."""
    if value is None:
        return None
    choices = [v.strip().upper() for v in value.split(",") if v.strip()]
    invalid = [v for v in choices if v not in ALLOWED_TESTCASE_STATES]
    if invalid:
        raise click.BadParameter(f"Invalid values: {', '.join(invalid)}. Allowed values are: {', '.join(ALLOWED_TESTCASE_STATES)}")
    return value


def handle_exceptions(func):
    """Decorator to handle exceptions for Click commands."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (
            MissingMetatronException,
            UnauthorizedException,
            ForbiddenException,
            UnclaimedDeviceException,
            DeviceAlreadyReservedException,
            DeviceIsUnavailableException,
        ) as e:
            raise click.ClickException(str(e))
        except Exception as e:
            click.echo(f"An error occurred: {e}", err=True)
            sys.exit(1)

    return wrapper
