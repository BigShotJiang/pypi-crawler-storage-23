#!/usr/bin/env python3
#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""
NTS CLI - Command Line Interface for Netflix Test Services.

This module provides the main CLI entry point and registers all commands.
"""

import logging

import click
import click_log

from src import __version__
from src.cli.commands.calibration import run_eleven_calibration_plan, run_eyepatch_calibration_plan
from src.cli.commands.device import get_host_devices, release_device_reservation, set_device_ui, status
from src.cli.commands.plan import cancel, get_plan_from_device, get_run_plan_summary, run_plan
from src.cli.commands.result import get_test_result
from src.cli.commands.utility import get_nts_cli_dockerfile
from src.cli.constants import VERBOSITY_HELP_STR
from src.log import logger

click_log.basic_config(logger)


@click.group(name="default")
@click.version_option(__version__.__version__, message="%(prog)s, build %(version)s", prog_name="NTS-CLI")
@click_log.simple_verbosity_option(logger, help=VERBOSITY_HELP_STR)
def default():
    """
    NTS CLI

    Each command has its own --help option to show its usage.
    """
    try:
        from metatron.http import MetatronAdapter  # noqa: F401
    except ImportError:
        # Disable logs for users without internal extras installed
        logger.setLevel(logging.CRITICAL)
    pass


# Register plan commands
default.add_command(get_plan_from_device)
default.add_command(run_plan)
default.add_command(get_run_plan_summary)

# Register device commands
default.add_command(status)
default.add_command(release_device_reservation)
default.add_command(get_host_devices)
default.add_command(set_device_ui)

# Register calibration commands
default.add_command(run_eyepatch_calibration_plan)
default.add_command(run_eleven_calibration_plan)

# Register utility commands
default.add_command(cancel)
default.add_command(get_nts_cli_dockerfile)

# Register result commands
default.add_command(get_test_result)


if __name__ == "__main__":
    default()
