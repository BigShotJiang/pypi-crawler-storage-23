#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Event models for CLI command usage tracking."""

import json
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class EventStatus(Enum):
    """Status of a CLI command execution."""

    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    CANCELLED = "CANCELLED"


@dataclass
class NTSActionEvent:
    """
    Represents a CLI command usage event.

    Maps to NPPNrdp_CreateActionEventRequest GraphQL input type.
    """

    source: str  # "nts-cli"
    action: str  # Command name, e.g., "get-plan", "run-plan"
    status: EventStatus  # SUCCESS, FAILURE, CANCELLED
    version: Optional[str]  # CLI version from __version__
    params: Optional[dict]  # Sanitized command args (serialized to JSON in to_gql_input)
    traceids: List[str]  # Trace IDs from x-netflix-traceid headers
    note: Optional[str]  # Additional context (e.g., error message)

    def to_gql_input(self) -> dict:
        """Convert to GraphQL mutation input format."""
        return {
            "source": self.source,
            "action": self.action,
            "status": self.status.value,
            "version": self.version,
            "params": json.dumps(self.params, default=str) if self.params else None,
            "traceids": self.traceids,
            "note": self.note,
        }
