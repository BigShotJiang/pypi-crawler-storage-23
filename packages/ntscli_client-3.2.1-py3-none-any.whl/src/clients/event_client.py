#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Client for sending CLI command usage events via GraphQL mutation."""

from src.clients.base_client import BaseClient, Endpoint
from src.log import logger
from src.models.event import NTSActionEvent


class EventClient(BaseClient):
    """Client for sending command usage events to the backend."""

    target_app_name = "wall_e"
    external_endpoint = Endpoint(url="https://third-party-gateway.dta.netflix.net")
    internal_endpoint = Endpoint(url="https://third-party-gateway-mtls.dta.netflix.net")

    def send_event(self, event: NTSActionEvent) -> None:
        """
        Send command event via GraphQL mutation.

        This method never throws exceptions - event telemetry should not
        affect CLI functionality. Failures are logged and a warning is shown.

        Args:
            event: The NTSActionEvent to send
        """
        mutation = """
        mutation CreateActionEvent($request: NPPNrdp_CreateActionEventRequest!) {
            nppnrdp_createActionEvent(request: $request) {
                success
            }
        }
        """
        try:
            with self._create_client() as client:
                resp = client.post(
                    f"{self._get_url_with_port()}/nppntsdgs/graphql",
                    json={"query": mutation, "variables": {"request": event.to_gql_input()}},
                    headers=self._get_headers(),
                    timeout=5.0,  # Fast timeout - don't block CLI
                )
                if resp.status_code != 200 or resp.json().get("errors"):
                    logger.error(f"Event send failed: [{resp.status_code}], errors: {resp.json().get('errors')}")
                else:
                    logger.debug(f"Event sent successfully: {event.action}")
        except Exception as e:
            logger.error(f"Event send error details: {e}")
