import os
import time

import httpx

from src.clients.base_client import BaseClient
from src.exceptions import MissingMetatronException
from src.log import logger

E2E_TOKEN_TTL_SECONDS = int(os.environ.get("E2E_TOKEN_TTL_SECONDS", "300"))


class E2ETokenClient(BaseClient):
    """Fetches and caches Metatron e2e tokens for authenticated requests."""

    url = "https://public.nflxe2etokens.prod.netflix.net"

    # Shared cache across all instances, keyed by app_name.
    # Entries are (timestamp, token_data) tuples with a TTL to handle
    # long-running commands (e.g. run-plan --wait over multiple days).
    _token_cache: dict[str, tuple[float, dict]] = {}

    def __init__(self):
        try:
            from metatron.tls import MetatronSslContext

            self.sslcontext = MetatronSslContext(appName="nflxe2etokens")
        except ImportError:
            raise MissingMetatronException()

    def get_e2e_token(self, app_name: str):
        cached = self._token_cache.get(app_name)
        if cached is not None:
            cached_at, token_data = cached
            if (time.monotonic() - cached_at) < E2E_TOKEN_TTL_SECONDS:
                logger.debug(f"Using cached e2e token for app: {app_name}")
                return token_data
            logger.debug(f"Cached e2e token expired for app: {app_name}")

        logger.debug(f"Fetching e2e token for app: {app_name}")
        with self._create_client(retries=1) as client:
            url = f"{E2ETokenClient.url}/REST/v1/tokens/mint/metatron?targetApp={app_name}"
            resp = client.get(url)
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                logger.error(f"Failed to fetch e2e token: {e}")
                raise e
            token_data = resp.json()
            self._token_cache[app_name] = (time.monotonic(), token_data)
            return token_data
