from typing import Literal

import httpx

from src.clients.base_client import BaseClient, Endpoint
from src.log import logger


class HardwareManagerClient(BaseClient):
    target_app_name = "wall_e"
    external_endpoint = Endpoint(url="https://hardwaremanager.netflixpartners.com")
    internal_endpoint = Endpoint(url="https://hardwaremanager.netflixpartners.com", port=7004)

    def __init__(self, net_key=None, use_netflix_access=False):
        super().__init__(net_key=net_key, use_netflix_access=use_netflix_access)

    def _call_host_command(self, host: str, command: str, params=None):
        url = f"{self._get_url_with_port()}/api/host/{host}/command/{command}"
        with self._create_client() as client:
            resp = client.post(url, headers=self._get_headers(), json=params)
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                logger.debug(f"Failed to call host command {command} for host {host}: {e}")
                raise Exception(f"Failed to call host command {command} for host {host}: {e}")
            return resp.json()

    def get_devices_for_host(self, host: str):
        return self._call_host_command(host, "host.devices.list")

    def get_host_peripherals(self, host: str):
        return self._call_host_command(host, "peripheral.list")

    def set_device_ui(self, host: str, ip: str, env: Literal["test", "prod"]):
        res = self._call_host_command(host, f"device.deviceui?ip={ip}", {"ui": env})
        return {
            "deviceUI": res.get("deviceUI", ""),
        }
