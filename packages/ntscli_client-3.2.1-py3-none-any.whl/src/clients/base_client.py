from dataclasses import dataclass

import httpx

from src import __version__
from src.context.trace_context import push_trace_id
from src.exceptions import MissingMetatronException
from src.log import logger


def _capture_trace_id_from_response(response: httpx.Response) -> None:
    """
    httpx event hook to capture trace IDs from responses.

    This hook is called after each HTTP response is received,
    extracting the x-netflix-traceid header for telemetry purposes.
    """
    trace_id = response.headers.get("x-netflix-traceid")
    if trace_id:
        push_trace_id(trace_id)


# Default timeout configuration for HTTP requests
DEFAULT_TIMEOUT = httpx.Timeout(
    connect=10.0,  # Time to establish connection
    read=60.0,  # Time to receive response (some APIs are slow)
    write=30.0,  # Time to send request
    pool=10.0,  # Time to acquire a connection from the pool
)


@dataclass
class Endpoint:
    """Configuration for an API endpoint"""

    url: str
    port: int = 443


class BaseClient:
    """Base class for HTTP clients with common functionality"""

    # Subclasses should override these
    target_app_name: str = None

    # Endpoint configuration - subclasses define these
    external_endpoint: Endpoint = None  # Used with net_key (external partners)
    internal_endpoint: Endpoint = None  # Used with Metatron (Netflix internal)

    def __init__(self, net_key: str = None, use_netflix_access: bool = False):
        """
        Initialize client with authentication.

        Args:
            net_key: Bearer token for external authentication
            use_netflix_access: Use Netflix Metatron mTLS authentication
        """
        self.sslcontext = None

        if net_key is not None:
            self._setup_external_auth(net_key)
        elif use_netflix_access:
            self._setup_metatron_auth()
        else:
            raise Exception("User is not authenticated")

    def _setup_external_auth(self, net_key: str):
        """Configure external authentication with bearer token"""
        endpoint = self.external_endpoint
        self.url = endpoint.url
        self.port = endpoint.port
        self.auth_header = "Authorization"
        self.auth_value = f"Bearer {net_key}"

    def _setup_metatron_auth(self):
        """Configure Metatron mTLS authentication"""
        from src.clients.e2e_token_client import E2ETokenClient

        try:
            from metatron.tls import MetatronSslContext

            # Use internal endpoint, fallback to external if not defined
            endpoint = self.internal_endpoint or self.external_endpoint
            self.url = endpoint.url
            self.port = endpoint.port
            self.auth_header = "X-Forwarded-Authentication"
            self._e2e_token_client = E2ETokenClient()
            self._e2e_token_client.get_e2e_token(self.target_app_name)  # warm the TTL cache
            self.sslcontext = MetatronSslContext(appName=self.target_app_name)
        except ImportError:
            raise MissingMetatronException()

    def _create_client(self, retries: int = 0) -> httpx.Client:
        """Create and return an httpx client with proper SSL context, timeout, and event hooks"""
        verify = self.sslcontext if self.sslcontext else True
        return httpx.Client(
            timeout=DEFAULT_TIMEOUT,
            transport=httpx.HTTPTransport(verify=verify, retries=retries),
            event_hooks={"response": [_capture_trace_id_from_response]},
        )

    def _get_url_with_port(self) -> str:
        """Get the full URL with port"""
        return f"{self.url}:{self.port}"

    def _get_auth_value(self) -> str:
        """Get the current auth token, refreshing from cache if using Metatron."""
        if hasattr(self, "_e2e_token_client"):
            return self._e2e_token_client.get_e2e_token(self.target_app_name)["token"]
        return self.auth_value

    def _get_headers(self) -> dict:
        """Get common HTTP headers. Subclasses can override to add more."""
        return {
            self.auth_header: self._get_auth_value(),
            "Content-Type": "application/json",
            "Accept-Encoding": "identity",
            "x-netflix.client.appid": "nts-cli",
            "User-Agent": f"nts-cli/{__version__.__version__}",
        }

    def _log_resp(self, resp: httpx.Response):
        """Log HTTP response details for debugging"""
        logger.debug(f"Request: {resp.request.method} {resp.request.url}")
        logger.debug(f"Response: {resp.status_code} {resp.reason_phrase}")
        logger.debug(f"Response headers: {dict(resp.headers)}")
