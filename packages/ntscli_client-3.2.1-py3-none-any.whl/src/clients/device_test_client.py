import json
import os
import time
import urllib.parse
from dataclasses import dataclass
from typing import List, Optional

import httpx

from src.clients.base_client import BaseClient, Endpoint
from src.exceptions import (
    DeviceAlreadyReservedException,
    DeviceIsUnavailableException,
    ForbiddenException,
    UnauthorizedException,
    UnclaimedDeviceException,
)
from src.log import logger


@dataclass
class TestPlanFilters:
    """Encapsulates all test plan filtering options for the FULL plan type"""

    # Inclusion filters
    automation: Optional[str] = None
    state: Optional[str] = None
    name: Optional[str] = None
    tag: Optional[str] = None
    category: Optional[str] = None

    # Exclusion filters
    name_exclude: Optional[str] = None
    tag_exclude: Optional[str] = None
    category_exclude: Optional[str] = None


class DeviceTestClient(BaseClient):
    target_app_name = "wall_e"
    external_endpoint = Endpoint(url="https://third-party-gateway.dta.netflix.net")
    internal_endpoint = Endpoint(url="https://third-party-gateway-mtls.dta.netflix.net")

    def __init__(self, net_key=None, use_netflix_access=False):
        super().__init__(net_key=net_key, use_netflix_access=use_netflix_access)

    def get_test_plan(self, esn: str, filters: Optional[TestPlanFilters] = None):
        """
        Get a test plan for a device with optional filtering

        Args:
            esn: Device ESN
            filters: Optional TestPlanFilters object containing inclusion/exclusion criteria

        Returns:
            Test plan JSON response
        """
        filters = filters or TestPlanFilters()

        # Base query params
        params = {"format": "marathonlite"}

        # Add inclusion filters if provided
        if filters.automation:
            params["testcaseAutomationFilter"] = filters.automation
        if filters.state:
            params["testcaseStateFilter"] = filters.state
        if filters.name:
            params["testcaseNameFilter"] = filters.name
        if filters.tag:
            params["testcaseTagFilter"] = filters.tag
        if filters.category:
            params["testcaseCategoryFilter"] = filters.category

        # Add exclusion filters if provided
        if filters.name_exclude:
            params["testcaseNameExclude"] = filters.name_exclude
        if filters.tag_exclude:
            params["testcaseTagExclude"] = filters.tag_exclude
        if filters.category_exclude:
            params["testcaseCategoryExclude"] = filters.category_exclude

        # Build the full URL with query string
        base_url = f"{self._get_url_with_port()}/test-plan/esn/{esn}"
        query_string = urllib.parse.urlencode(params)
        full_url = f"{base_url}?{query_string}"

        with self._create_client() as client:
            resp = client.get(full_url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get test plan", e)
            return resp.json()

    def get_playlist_test_plan(self, playlist_id: str, esn: str):
        url = f"{self._get_url_with_port()}/playlist/id/{playlist_id}/esn/{esn}?format=marathonlite"
        with self._create_client() as client:
            resp = client.get(url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get playlist test plan", e)
            return resp.json()

    def get_dynamic_filter_test_plan(self, dynamic_filter_id: str, esn: str, sdk_or_apk: str):
        sdk_or_apk_query_param = f"&singleNamespaceFilter={sdk_or_apk}" if sdk_or_apk else ""
        url = f"{self._get_url_with_port()}/dynamic-filter/id/{dynamic_filter_id}/esn/{esn}?format=marathonlite{sdk_or_apk_query_param}"
        with self._create_client() as client:
            resp = client.get(url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get dynamic filter test plan", e)
            return resp.json()

    def get_status(self, rae: str, esn: str):
        query_params = f"rae={rae}" if rae is not None else f"esn={esn}"
        with self._create_client() as client:
            resp = client.get(
                f"{self._get_url_with_port()}/device-status?{query_params}",
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get status", e)

        # Curate list of device attributes we expose to clients
        curated_fields = ["esn", "rae", "host", "status", "batchId"]
        curated_devices = []
        for device in resp.json():
            if esn and device["esn"] != esn:
                continue  # Skip if not matching ESN

            # hydrate device with batchId
            device["batchId"] = None if device.get("status") == "idle" else self.__get_latest_running_batch_id(device["esn"])

            # Reduce to curated fields
            curated_device = {field: device.get(field) for field in curated_fields}
            curated_devices.append(curated_device)

        return curated_devices

    def __get_latest_running_batch_id(self, esn: str):
        batches = self.__get_all_batch_summaries(esn)
        if not batches:
            return None
        latest_batch = batches[0]
        # Return batchId if 'ended' key is missing (implying still running)
        return latest_batch["batchId"] if "ended" not in latest_batch else None

    def __get_all_batch_summaries(self, esn: str):
        with self._create_client() as client:
            resp = client.get(
                f"{self._get_url_with_port()}/batch/summary/all?esn={esn}",
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception(f"Failed to get all batch summaries for esn: {esn}", e)
            return resp.json()

    def get_registry_device_details(self, esn: str):
        with self._create_client() as client:
            resp = client.get(
                f"{self._get_url_with_port()}/device-registry?esn={esn}",
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception(f"Failed to get registry device details for esn: {esn}", e)
            return resp.json()

    def release_device_reservation(self, esn: str, user: str):
        params = {"esn": esn, "user": user}
        query_string = urllib.parse.urlencode(params)
        full_url = f"{self._get_url_with_port()}/device-registry/reservation?{query_string}"
        with self._create_client() as client:
            resp = client.delete(full_url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception(f"Failed to release device reservation for esn: {esn}, user: {user}", e)

    def get_eleven_calibration_plan(self, esn: str):
        url = f"{self._get_url_with_port()}/eleven/calibration/esn/{esn}?format=marathonlite"
        with self._create_client() as client:
            resp = client.get(url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get eleven calibration plan", e)
            return resp.json()

    def get_eyepatch_calibration_plan(self, esn: str, audio_source: str, eyepatch_serial: str):
        url = f"{self._get_url_with_port()}/eyepatch/calibration/esn/{esn}?format=marathonlite"
        with self._create_client() as client:
            resp = client.get(url, headers=self._get_headers())
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to get eyepatch calibration plan", e)
            plan = resp.json()
            plan["test_overrides"] = self.__get_eyepatch_calibration_plan_overrides(audio_source, eyepatch_serial)
            return plan

    def run_test_plan(self, plan, wait):
        overrides = {"test_log_level": "warning"}
        plan_overrides = plan.get("test_overrides", {})

        overrides.update(plan_overrides)
        # TODO: determine whether we should make these user configurable parameters
        plan["target_profiles"] = [{"esn": plan["esn"]}]
        plan["test_overrides"] = overrides
        plan["stress_count"] = 0
        plan["retry_count"] = 0

        with self._create_client() as client:
            resp = client.post(
                f"{self._get_url_with_port()}/testruns/launch/nts/batch",
                json=plan,
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to run test plan", e)

            batch_id = resp.json()["batch_id"]

        return self.get_run_plan_summary(batch_id, wait, True)

    def cancel_test_plan_run(self, batch_id: str, esn: str):
        json_data = {"esn": esn}
        with self._create_client() as client:
            resp = client.post(
                f"{self._get_url_with_port()}/testruns/cancel/batch/{batch_id}",
                json=json_data,
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to cancel test plan run", e)
            return {"batchId": batch_id, "details": resp.json()["details"]}

    def get_run_plan_summary(self, batch_id: str, wait: bool = False, include_attachments: bool = False):
        poll_interval = 20  # seconds
        inprogress_file = f"inprogress_test_plan_result_{batch_id}.json"

        try:
            while True:
                summary = self._get_run_plan_summary(batch_id, include_attachments)

                if not wait or summary["executionFinished"]:
                    return summary

                # Write inprogress result to file
                with open(inprogress_file, "w") as f:
                    json.dump(summary, f, indent=4)
                time.sleep(poll_interval)
        finally:
            if os.path.exists(inprogress_file):
                os.remove(inprogress_file)

    def list_execution_details(self, run_ids: List[str], include_attachments: bool = False) -> dict:
        """
        Fetch execution details for multiple runIDs in one batch request.

        Args:
            run_ids: List of runID strings
            include_attachments: Whether to include attachment data in response

        Returns:
            Dict mapping runID -> execution details
        """
        if not run_ids:
            return {}

        payload = {
            "markerSetIds": run_ids,  # API contract uses markerSetIds
            "includeAttachments": include_attachments,
        }

        with self._create_client() as client:
            resp = client.post(
                f"{self._get_url_with_port()}/results/exec-details/list",
                json=payload,
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                self._raise_cli_exception("Failed to list execution details", e)

            result = {}
            for item in resp.json().get("data", []):
                run_id = item.get("markerSetId")  # API response uses markerSetId
                if run_id:
                    result[run_id] = item
            return result

    def get_test_results_by_run_ids(self, run_ids: List[str], include_attachments: bool = False) -> List[dict]:
        """
        Fetch execution details for runIDs and format as CLI results.

        Args:
            run_ids: List of runID strings
            include_attachments: Whether to include attachment URLs

        Returns:
            List of formatted test result dicts
        """
        if not run_ids:
            return []

        # Fetch execution details in batches of 100
        page_size = 100
        exec_details_map = {}
        for i in range(0, len(run_ids), page_size):
            batch_run_ids = run_ids[i : i + page_size]
            batch_result = self.list_execution_details(batch_run_ids, include_attachments)
            exec_details_map.update(batch_result)

        return self.__format_exec_details_to_cli_results(exec_details_map, run_ids, include_attachments)

    # Returns the overall batch run summary
    def _get_run_plan_summary(self, batch_id: str, include_attachments: bool):
        with self._create_client() as client:
            resp = client.get(
                f"{self._get_url_with_port()}/batch/results/batchId/{batch_id}",
                headers=self._get_headers(),
            )
            self._log_resp(resp)
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                if resp.status_code == 404:
                    logger.warning(
                        f"No results found for batchId {batch_id}. "
                        "This could mean the results are not yet available or the batch ID does not exist."
                    )
                    return {"batchId": batch_id, "executionFinished": False}
                else:
                    self._raise_cli_exception(f"Failed to get test plan run summary for batchId {batch_id}", e)
            return self.__extract_cli_summary(resp.json(), include_attachments)

    # Raises appropriate NTS-CLI exception for HTTP error status code received from 3PG
    def _raise_cli_exception(self, error_message: str, http_error: httpx.HTTPStatusError):
        status_code = getattr(http_error.response, "status_code", None)
        response_text = getattr(http_error.response, "text", "")

        logger.error(f"{error_message} : {http_error}")

        unclaimed_device_msg = "Device must be claimed"
        reserved_device_msg = "Device has already been reserved"
        device_is_unavailable_msg = "Device is unavailable"

        if reserved_device_msg in response_text:
            raise DeviceAlreadyReservedException(error_message)
        elif unclaimed_device_msg in response_text:
            raise UnclaimedDeviceException(error_message)
        elif device_is_unavailable_msg in response_text:
            raise DeviceIsUnavailableException(error_message)
        elif status_code == 401:
            raise UnauthorizedException(error_message)
        elif status_code == 403:
            raise ForbiddenException(error_message)
        else:
            raise Exception(error_message)

    # Returns a collection of test results for an executed batch
    def _get_run_plan_results(self, batch_id: str, include_attachments: bool):
        next_token = None
        page_size = 100
        results = []
        total_items = None

        with self._create_client() as client:
            while True:
                payload = {"batchId": batch_id, "pageSize": page_size}
                if next_token is not None:
                    payload["nextToken"] = next_token

                resp = client.post(
                    f"{self._get_url_with_port()}/results/summary/all",
                    headers=self._get_headers(),
                    json=payload,
                )
                self._log_resp(resp)
                try:
                    resp.raise_for_status()
                except httpx.HTTPStatusError as e:
                    self._raise_cli_exception(f"Failed to get test plan run results for batchId {batch_id}", e)
                resp_json = resp.json()
                if total_items is None:
                    total_items = resp_json.get("totalItems")
                results.extend(resp_json.get("data", []))
                next_token = resp_json.get("nextToken", None)
                if not next_token:
                    break

        # Safety check
        if total_items is not None and len(results) != total_items:
            logger.warning(f"Expected {total_items} items, but got {len(results)}.")

        # Extract runIDs from API response (API uses markerSetId field)
        run_ids = [item["markerSetId"] for item in results]
        return self.get_test_results_by_run_ids(run_ids, include_attachments)

    def __get_eyepatch_calibration_plan_overrides(self, audio_source, eyepatch_serial):
        overrides = {
            "promptChoice_audioSource": "positive",
            "promptInput_audioSource": audio_source.lower(),
            "skipPrompt": "true",
        }

        # Optional overrides
        if eyepatch_serial is not None:
            overrides["promptChoice_epchoice"] = "positive"
            overrides["promptInput_epchoice"] = eyepatch_serial

        return overrides

    def __extract_cli_summary(self, results, include_attachments: bool):
        summary = results["summary"]
        batch_id = summary.get("batchId")
        finished = summary.get("pending") == 0 and summary.get("running") == 0
        test_results = self._get_run_plan_results(batch_id, include_attachments)

        return {
            "batchId": batch_id,
            "passed": summary.get("passed"),
            "failed": summary.get("failed"),
            "timedout": summary.get("timedout"),
            "canceled": summary.get("canceled"),
            "invalid": summary.get("invalid"),
            "running": summary.get("running"),
            "review": summary.get("review"),
            "pending": summary.get("pending"),
            "total": summary.get("total"),
            "executionFinished": finished,
            "testResultDetails": test_results,
        }

    def __format_exec_details_to_cli_results(self, exec_details_map: dict, run_ids: List[str], include_attachments: bool) -> List[dict]:
        """Convert exec_details_map to CLI result format."""
        cli_results = []
        for run_id in run_ids:
            exec_detail = exec_details_map.get(run_id, {})
            if not exec_detail:
                logger.debug(f"exec_detail not found for run_id: {run_id}")
                continue

            test_case = exec_detail.get("test_case", {})
            test_attrs = exec_detail.get("test_attributes", {})

            result_url = f"https://nts.prod.netflixpartners.com/#testhistory?{urllib.parse.urlencode({'markerSetId': run_id})}"

            failure_message = []
            if exec_detail.get("result") != "passed" and exec_detail.get("failure_message"):
                failure_message.append(exec_detail.get("failure_message"))

            result_dict = {
                "runId": run_id,
                "name": test_case.get("name"),
                "result": exec_detail.get("result"),
                "resultUrl": result_url,
                "failures": failure_message,
                "tags": test_attrs.get("test_case_tags", []),
                "category": test_case.get("category"),
                "steps": exec_detail.get("report", []),
            }

            # Only include attachmentsUrl when requested
            if include_attachments:
                attachments = exec_detail.get("attachments", [])
                attachments_url = None
                for attachment in attachments:
                    if attachment.get("key", "").endswith("_ntscli.zip"):
                        attachments_url = attachment.get("url")
                        break
                result_dict["attachmentsUrl"] = attachments_url

            cli_results.append(result_dict)

        return cli_results
