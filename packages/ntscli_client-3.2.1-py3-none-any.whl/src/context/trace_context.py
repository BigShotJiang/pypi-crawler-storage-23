#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Thread-safe context manager for collecting trace IDs across HTTP requests."""

import threading
from contextlib import contextmanager
from typing import List

# Thread-local storage for trace IDs
_trace_context = threading.local()


@contextmanager
def trace_id_context():
    """
    Context manager that collects trace IDs from HTTP responses.

    Usage:
        with trace_id_context():
            # Make HTTP requests - trace IDs are collected automatically
            client.get(...)
            client.post(...)
            # Retrieve all collected trace IDs
            trace_ids = get_trace_ids()
    """
    _trace_context.trace_ids = []
    try:
        yield
    finally:
        pass  # trace_ids remain accessible until get_trace_ids() is called


def push_trace_id(trace_id: str) -> None:
    """
    Called by httpx response hook to store a trace ID.

    Args:
        trace_id: The trace ID from x-netflix-traceid response header
    """
    if hasattr(_trace_context, "trace_ids") and trace_id:
        _trace_context.trace_ids.append(trace_id)


_MAX_TRACE_IDS = 40
_KEEP_PER_SIDE = _MAX_TRACE_IDS // 2


def get_trace_ids() -> List[str]:
    """
    Retrieve collected trace IDs, capped to avoid oversized payloads.

    When --wait polling generates many requests, the list can grow large.
    If it exceeds the cap, the first and last entries are kept so we
    retain the initial request context and the most recent responses.

    Returns:
        List of trace IDs collected during the current context
    """
    trace_ids = getattr(_trace_context, "trace_ids", [])
    if len(trace_ids) <= _MAX_TRACE_IDS:
        return trace_ids
    return trace_ids[:_KEEP_PER_SIDE] + trace_ids[-_KEEP_PER_SIDE:]
