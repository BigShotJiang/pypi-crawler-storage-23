#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Decorator for capturing CLI command usage events."""

import functools
import platform
import re
import sys
import time

import click

from src import __version__
from src.context.trace_context import get_trace_ids, trace_id_context
from src.log import logger
from src.models.event import EventStatus, NTSActionEvent

# Args to exclude from event params
# - net_key: sensitive credential
# - out_file: file handle, not serializable
EXCLUDED_ARGS = {"net_key", "out_file"}

OS_INFO = f"{platform.system()} {platform.release()} ({platform.machine()})"


def _sanitize_command(argv: list) -> str:
    """
    Build sanitized command string from argument list.

    Handles both --net-key=VALUE and --net-key VALUE formats.

    Args:
        argv: The raw sys.argv list

    Returns:
        Sanitized command string with sensitive values replaced
    """
    command = " ".join(argv)
    command = re.sub(r"--net-key[=\s]+\S+", "--net-key=[REDACTED]", command)
    return command


def _send_event(event: NTSActionEvent, kwargs: dict) -> None:
    """
    Send the event to the backend.

    This function handles authentication for the EventClient.
    It tries to use the same authentication method as the command.

    Args:
        event: The event to send
        kwargs: The command kwargs (for extracting auth info)
    """
    try:
        from src.clients.event_client import EventClient

        net_key = kwargs.get("net_key")
        use_netflix_access = kwargs.get("use_netflix_access", False)

        # Create event client with same auth as command
        if net_key:
            client = EventClient(net_key=net_key)
        elif use_netflix_access:
            client = EventClient(use_netflix_access=True)
        else:
            # No auth available, skip event sending
            logger.warning("Cannot send event: no authentication available")
            return

        client.send_event(event)
    except Exception as e:
        # Never let event sending crash the CLI
        logger.error(f"Event send failed: {e}")


def capture_command_event(func):
    """
    Decorator that captures CLI command usage events.

    This decorator wraps Click commands to capture:
    - Command name (from Click context)
    - Command arguments (sanitized)
    - Execution timing
    - Success/failure status
    - Trace IDs from HTTP responses

    Usage:
        @capture_command_event
        @handle_exceptions
        def my_command(...):
            ...
    """

    @functools.wraps(func)
    @click.pass_context
    def wrapper(ctx: click.Context, *args, **kwargs):
        start_time = time.time()
        status = EventStatus.SUCCESS
        error_note = ""

        # Get the actual CLI command name from Click context
        # e.g., "get-plan" instead of "get_plan_from_device"
        command_name = ctx.info_name

        # Enter trace ID collection context
        with trace_id_context():
            try:
                # Invoke the original function via Click's context
                result = ctx.invoke(func, *args, **kwargs)
            except KeyboardInterrupt:
                status = EventStatus.CANCELLED
                error_note = "Command cancelled by user (Ctrl+C)"
                raise
            except SystemExit as e:
                # handle_exceptions calls sys.exit(1) for unexpected errors.
                # SystemExit inherits from BaseException, not Exception,
                # so we must catch it explicitly to capture FAILURE status.
                if e.code != 0:
                    status = EventStatus.FAILURE
                    # Python chains exceptions: when sys.exit() is raised
                    # inside an except block, __context__ holds the original.
                    original = e.__context__
                    if original:
                        error_note = f"{type(original).__name__}: {str(original)}"
                    else:
                        error_note = f"Command exited with code {e.code}"
                raise
            except Exception as e:
                status = EventStatus.FAILURE
                error_note = f"{type(e).__name__}: {str(e)}"
                raise
            finally:
                # Build and send event
                duration_ms = int((time.time() - start_time) * 1000)

                # Sanitize args (remove sensitive/non-serializable values)
                sanitized_args = {k: v for k, v in kwargs.items() if k not in EXCLUDED_ARGS}

                # Build params dict with raw command and sanitized args
                # Sanitize raw command to remove --net-key value if present
                raw_command = _sanitize_command(sys.argv)
                note = "; ".join(filter(None, [f"os: {OS_INFO}", error_note]))

                event = NTSActionEvent(
                    source="nts-cli",
                    action=command_name,
                    status=status,
                    version=__version__.__version__,
                    params={
                        "raw_command": raw_command,
                        "args": sanitized_args,
                        "duration_ms": duration_ms,
                    },
                    traceids=get_trace_ids(),
                    note=note,
                )

                # Send event - shows warning on failure but doesn't crash
                _send_event(event, kwargs)

        return result

    return wrapper
