#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#

from src.decorators.command_event import capture_command_event

__all__ = ["capture_command_event"]
