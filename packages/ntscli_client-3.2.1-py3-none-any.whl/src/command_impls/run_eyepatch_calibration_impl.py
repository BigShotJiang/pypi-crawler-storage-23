#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Run eyepatch calibration command implementation."""

import sys
from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.clients.hardware_manager_client import HardwareManagerClient
from src.command_impls.base_impl import BaseCommandImpl


class RunEyepatchCalibrationCommandImpl(BaseCommandImpl):
    """Implementation for running eyepatch calibration."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.device_test_client = DeviceTestClient(net_key, use_netflix_access)
        self.hardware_manager_client = HardwareManagerClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        esn: str,
        audio_source: str,
        eyepatch_serial: Optional[str] = None,
    ) -> dict:
        """
        Get the eyepatch calibration plan and run it.

        Args:
            out_file: Optional file handle for JSON output
            esn: Device ESN
            audio_source: Audio transport to capture & analyze audio
            eyepatch_serial: Optional eyepatch serial number

        Returns:
            Run summary dict
        """

        def execute() -> dict:
            # Get device details to retrieve host hardware serial
            device_details = self.device_test_client.get_registry_device_details(esn)
            host = device_details.get("hardware_serial")
            # Get peripherals connected to the host
            peripherals = self.hardware_manager_client.get_host_peripherals(host)

            # Check if any peripheral is an old Eyepatch
            has_old_eyepatch = any(peripheral.get("hw_config", {}).get("type", "").lower() == "eyepatch" for peripheral in peripherals)

            if has_old_eyepatch:
                print(
                    "\nWarning: the EyePatch sensor being used currently is marked for deprecation on Jan 31, 2026.\n\n"
                    "Calibration will be able to complete for these legacy hexagonal sensors until this time.\n\n"
                    "To procure a new sensor (EyePatch Ultra) please navigate to the following ordering site:\n"
                    "https://docs.netflixpartners.com/docs/nrdp/cert/setting-up-nts/eyepatch-ultra/order-form/\n\n"
                    "If there are questions or concerns, please reach out to your Netflix Partner Engineering "
                    "contact for more information.\n",
                    file=sys.stderr,
                )

            plan = self.device_test_client.get_eyepatch_calibration_plan(esn, audio_source, eyepatch_serial)
            return self.device_test_client.run_test_plan(plan, wait=True)

        return self._run_with_lifecycle(execute, out_file)
