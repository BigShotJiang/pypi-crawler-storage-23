#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Run eleven calibration command implementation."""

from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class RunElevenCalibrationCommandImpl(BaseCommandImpl):
    """Implementation for running eleven calibration."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        esn: str,
    ) -> dict:
        """
        Get the eleven calibration plan and run it.

        Args:
            out_file: Optional file handle for JSON output
            esn: Device ESN

        Returns:
            Run summary dict
        """

        def execute() -> dict:
            plan = self.client.get_eleven_calibration_plan(esn)
            return self.client.run_test_plan(plan, wait=True)

        return self._run_with_lifecycle(execute, out_file)
