#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Get device status command implementation."""

from typing import List, Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class StatusCommandImpl(BaseCommandImpl):
    """Implementation for getting device status."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        rae: Optional[str] = None,
        esn: Optional[str] = None,
    ) -> List[dict]:
        """
        Get device status.

        Args:
            out_file: Optional file handle for JSON output
            rae: RAE device serial (optional)
            esn: Device ESN (optional)

        Returns:
            List of device status dicts
        """
        return self._run_with_lifecycle(
            lambda: self.client.get_status(rae, esn),
            out_file,
        )
