#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Cancel running test plan command implementation."""

from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class CancelCommandImpl(BaseCommandImpl):
    """Implementation for canceling a running test plan."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        batch_id: str,
        esn: str,
    ) -> dict:
        """
        Cancel a running test plan.

        Args:
            out_file: Optional file handle for JSON output
            batch_id: UUID of the running test batch
            esn: Device ESN

        Returns:
            Cancel result with batch ID and details
        """
        return self._run_with_lifecycle(
            lambda: self.client.cancel_test_plan_run(batch_id, esn),
            out_file,
        )
