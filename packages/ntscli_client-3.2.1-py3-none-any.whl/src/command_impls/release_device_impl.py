#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Release device reservation command implementation."""

from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class ReleaseDeviceCommandImpl(BaseCommandImpl):
    """Implementation for releasing a device reservation."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        esn: str,
    ) -> dict:
        """
        Release a device reservation.

        Args:
            out_file: Optional file handle for JSON output
            esn: Device ESN

        Returns:
            Result dict with message
        """

        def execute() -> dict:
            registry_device_details = self.client.get_registry_device_details(esn)
            user = registry_device_details["user"]
            message = "device is not reserved"

            if user is not None:
                self.client.release_device_reservation(esn, user)
                message = "manually released device reservation"

            return {"message": message}

        return self._run_with_lifecycle(execute, out_file)
