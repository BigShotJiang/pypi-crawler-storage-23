#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Run test plan command implementation."""

from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class RunCommandImpl(BaseCommandImpl):
    """Implementation for running a test plan."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        plan: dict,
        wait: bool = False,
    ) -> dict:
        """
        Run a test plan.

        Args:
            out_file: Optional file handle for JSON output
            plan: Test plan dict
            wait: Whether to wait for completion

        Returns:
            Run summary dict
        """
        return self._run_with_lifecycle(
            lambda: self.client.run_test_plan(plan, wait),
            out_file,
        )
