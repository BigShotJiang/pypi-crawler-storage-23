#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Get test result command implementation."""

from typing import List, Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class GetTestResultCommandImpl(BaseCommandImpl):
    """Implementation for getting test results by runIDs."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        run_ids: List[str],
        include_attachments: bool = False,
    ) -> dict:
        """
        Get test results for one or more runIDs.

        Args:
            out_file: Optional file handle for JSON output
            run_ids: List of runID strings
            include_attachments: Whether to include attachment URLs

        Returns:
            Test result details dict
        """
        return self._run_with_lifecycle(
            lambda: self._get_results(run_ids, include_attachments),
            out_file,
        )

    def _get_results(self, run_ids: List[str], include_attachments: bool) -> dict:
        """Fetch and format test results for the given runIDs."""
        results = self.client.get_test_results_by_run_ids(run_ids, include_attachments)
        return {"testResultDetails": results}
