#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Get test plan command implementation."""

from enum import Enum
from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient, TestPlanFilters
from src.command_impls.base_impl import BaseCommandImpl


class PlanType(Enum):
    """Type of test plan to retrieve."""

    FULL = "FULL"
    PLAYLIST = "PLAYLIST"
    DYNAMIC_FILTER = "DYNAMIC_FILTER"


class GetPlanCommandImpl(BaseCommandImpl):
    """Implementation for getting a test plan."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        esn: str,
        plan_type: PlanType,
        filters: Optional[TestPlanFilters] = None,
        playlist_id: Optional[str] = None,
        dynamic_filter_id: Optional[str] = None,
        sdk_or_apk: Optional[str] = None,
    ) -> dict:
        """
        Get a test plan for a device.

        Args:
            out_file: Optional file handle for JSON output
            esn: Device ESN
            plan_type: Type of plan (FULL, PLAYLIST, DYNAMIC_FILTER)
            filters: Optional filters for FULL plan type
            playlist_id: Playlist ID for PLAYLIST plan type
            dynamic_filter_id: Dynamic filter ID for DYNAMIC_FILTER plan type
            sdk_or_apk: SDK or APK version for dynamic filter

        Returns:
            Test plan dict
        """

        def execute() -> dict:
            match plan_type:
                case PlanType.FULL:
                    plan = self.client.get_test_plan(esn, filters)
                case PlanType.PLAYLIST:
                    plan = self.client.get_playlist_test_plan(playlist_id, esn)
                case PlanType.DYNAMIC_FILTER:
                    plan = self.client.get_dynamic_filter_test_plan(dynamic_filter_id, esn, sdk_or_apk)

            # Ensure test_overrides scaffold always exists for users to conveniently modify
            plan["test_overrides"] = plan.get("test_overrides", {})
            return plan

        return self._run_with_lifecycle(execute, out_file)
