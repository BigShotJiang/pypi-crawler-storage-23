#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Base class for command implementations with lifecycle hooks."""

import json
from abc import ABC
from typing import Any, Callable, Optional, TextIO, TypeVar

from src.log import logger

# Default JSON output indentation
JSON_INDENT = 4

# Type variable for generic return type
T = TypeVar("T")


class BaseCommandImpl(ABC):
    """
    Base class for command implementations with lifecycle hooks.

    Subclasses define their own run() method with proper type hints,
    and call _run_with_lifecycle() to wrap execution with before/after hooks.

    Implementation Patterns:

        Pattern 1: Lambda (for simple single-expression logic)
        -------------------------------------------------------
        Use when your command logic is a single method call.

            class SimpleCommandImpl(BaseCommandImpl):
                def __init__(self, net_key: str, use_netflix_access: bool):
                    self.client = SomeClient(net_key, use_netflix_access)

                def run(
                    self,
                    out_file: Optional[TextIO] = None,
                    *,
                    esn: str,
                    batch_id: str,
                ) -> dict:
                    return self._run_with_lifecycle(
                        lambda: self.client.do_something(esn, batch_id),
                        out_file,
                    )

        Pattern 2: Inner function (for complex multi-statement logic)
        --------------------------------------------------------------
        Use when your command has conditionals, loops, match/case,
        or multiple statements. Python lambdas only support single expressions.

            class ComplexCommandImpl(BaseCommandImpl):
                def __init__(self, net_key: str, use_netflix_access: bool):
                    self.client = SomeClient(net_key, use_netflix_access)

                def run(
                    self,
                    out_file: Optional[TextIO] = None,
                    *,
                    esn: str,
                    plan_type: str,
                ) -> dict:
                    def execute() -> dict:
                        match plan_type:
                            case "FULL":
                                result = self.client.get_full_plan(esn)
                            case "PARTIAL":
                                result = self.client.get_partial_plan(esn)
                            case _:
                                raise ValueError(f"Unknown type: {plan_type}")
                        result["extra_field"] = "value"
                        return result

                    return self._run_with_lifecycle(execute, out_file)

    CLI Usage:
        MyCommandImpl(net_key, use_netflix_access).run(out_file=out_file, esn="X", batch_id="Y")

    Notes:
        - Use `*` after out_file to enforce keyword-only arguments for clarity
        - Define proper type hints on run() for IDE support and documentation
        - The lifecycle hooks (before_execute, after_execute) are called automatically
    """

    def before_execute(self) -> None:
        """
        Called before command execution. Override for pre-execution checks.

        Use cases:
        - Rate limiting: Query backend, block if too many requests
        - Validation: Additional input validation
        - Setup: Initialize resources

        Raise an exception to block command execution.
        """
        # TODO: Future - add rate limiting check here
        pass  # Default: no-op

    def after_execute(
        self,
        result: Optional[Any] = None,
        error: Optional[Exception] = None,
    ) -> None:
        """
        Called after command execution, regardless of success or failure.

        Use cases:
        - Cleanup: Release resources
        - Logging: Additional logging based on result
        - Metrics: Record execution metrics

        Args:
            result: The return value from execution (if successful)
            error: The exception raised during execution (if failed)
        """
        # TODO: Future - add custom post-execution logic here
        pass  # Default: no-op

    def get_additional_event_data(self) -> Optional[dict]:
        """
        Override to provide extra data for event logging.

        Return dict will be serialized and added to event 'note' field.
        """
        return None

    def write_output(self, result: Any, out_file: TextIO) -> None:
        """
        Write the result to the output file as formatted JSON.

        Args:
            result: The data to write (typically a dict or list)
            out_file: File handle to write to (e.g., sys.stdout or a file)

        Raises:
            TypeError/ValueError: If result cannot be serialized to JSON
            OSError: If writing to file fails
        """
        try:
            json.dump(result, out_file, indent=JSON_INDENT)
        except (TypeError, ValueError) as e:
            logger.error(f"Failed to serialize result to JSON: {e}")
            raise
        except OSError as e:
            logger.error(f"Failed to write output: {e}")
            raise

    def _run_with_lifecycle(
        self,
        execute_fn: Callable[[], T],
        out_file: Optional[TextIO] = None,
    ) -> T:
        """
        Execute a function wrapped with lifecycle hooks.

        This is the core template method that orchestrates:
        before_execute() → execute_fn() → write_output() → after_execute()

        Subclasses call this from their typed run() method.

        Args:
            execute_fn: Callable containing the main command logic
            out_file: Optional file handle for JSON output

        Returns:
            The result from execute_fn()
        """
        self.before_execute()
        result = None
        error = None
        try:
            result = execute_fn()
            if out_file is not None:
                self.write_output(result, out_file)
            return result
        except Exception as e:
            error = e
            logger.debug(f"Command execution failed: {e}")
            raise
        finally:
            self.after_execute(result=result, error=error)
