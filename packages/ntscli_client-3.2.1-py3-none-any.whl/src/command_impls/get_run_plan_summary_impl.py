#  Copyright (c) 2026 Netflix.
#  All rights reserved.
#
"""Get run plan summary command implementation."""

from typing import Optional, TextIO

from src.clients.device_test_client import DeviceTestClient
from src.command_impls.base_impl import BaseCommandImpl


class GetRunPlanSummaryCommandImpl(BaseCommandImpl):
    """Implementation for getting a run plan summary."""

    def __init__(self, net_key: str, use_netflix_access: bool):
        self.client = DeviceTestClient(net_key, use_netflix_access)

    def run(
        self,
        out_file: Optional[TextIO] = None,
        *,
        batch_id: str,
        include_attachments: bool = False,
    ) -> dict:
        """
        Get a summary for a test plan run.

        Args:
            out_file: Optional file handle for JSON output
            batch_id: UUID of the test batch
            include_attachments: Whether to include attachment URLs

        Returns:
            Run plan summary dict
        """
        return self._run_with_lifecycle(
            lambda: self.client.get_run_plan_summary(batch_id, wait=False, include_attachments=include_attachments),
            out_file,
        )
