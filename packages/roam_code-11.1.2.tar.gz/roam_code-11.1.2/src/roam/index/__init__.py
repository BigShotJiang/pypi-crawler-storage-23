"""Indexing pipeline: discovery, parsing, symbol extraction, and orchestration."""

from roam.index.indexer import Indexer

__all__ = ["Indexer"]
