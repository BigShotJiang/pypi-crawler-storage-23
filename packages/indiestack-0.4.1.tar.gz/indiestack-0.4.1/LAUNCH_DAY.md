# IndieStack Launch Day Prep — March 2, 2026

---

## Product Hunt Relaunch

### Strategy

Relaunch — update the existing PH listing with new copy. Previous upvotes and comments stay. Use PH's relaunch feature so we keep our history and show momentum since the first launch.

**Critical messaging shift:** IndieStack is NOT a marketplace where makers sell tools. Direct selling is paused. IndieStack is an **Intergenerational Knowledge Transfer hub for AI agents** — the knowledge layer where agents learn what tools exist so they stop rebuilding solved problems. "Tools" means everything — from full SaaS products to tiny utilities someone built because the existing options were paywalled or broken.

### Tagline (60 char max)

**Primary:** `Someone already built that — tool knowledge for AI agents` (57 chars)
**Backup:** `The tool knowledge layer AI agents are missing` (47 chars)

### Description (260 char max)

```
Someone already built that. IndieStack is where AI agents learn what tools exist — from full products to tiny utilities — so they stop rebuilding solved problems. Saves thousands of tokens per task.
```

### Topics

1. Developer Tools
2. Artificial Intelligence
3. Open Source
4. Productivity
5. Software Engineering

### Maker Comment (Patrick)

> Patrick here — we launched IndieStack on PH back in February as a small directory of 100 indie tools. The vision has evolved.
>
> **The observation:** AI agents are amnesiac. Every session starts from zero. They have no persistent knowledge of what tools already exist. So they rebuild auth systems, billing integrations, file converters — burning thousands of tokens on problems someone already solved. Not because the solutions don't exist, but because agents have no way to know about them.
>
> **What IndieStack actually is:** Not a SaaS marketplace. It's the knowledge layer where agents learn what's already been built. We index everything — full products, self-hosted alternatives, scripts, utilities. If someone solved the problem, it belongs here.
>
> **Why "everything"?** A developer needed to convert .txt to .FASTA format. The online converters were paywalled and limited to 1GB. They built their own in an afternoon. That solution should live somewhere agents can find it — so the next developer doesn't waste 40,000 tokens rebuilding it. That's the kind of knowledge transfer we're talking about. Not just polished SaaS. Every solved problem.
>
> **Agent memory:** The MCP server learns what you build with. Search for auth tools a few times, it starts recommending auth-adjacent tools you haven't seen. It tracks category interests and inferred tech stack only — never raw queries. You can view, clear, or pause your profile at `/developer`. Over 2,000 agent lookups so far and the personalization is already surfacing tools people wouldn't have found otherwise.
>
> **The tech:** Python/FastAPI/SQLite, single Fly.io machine, zero JS frameworks, fully open source. Pure Python string templates — no React, no Next.js, no build step.
>
> **What we shipped:** Agent Memory, Personalized Recommendations, Stack Builder API, Prompt Cache Index, Agent Citation Tracking, Developer Profiles, API Keys, 11 MCP tools. All in about 10 weeks.
>
> **The ask:** If you've built something useful — doesn't matter how small — list it. Install the MCP server (`pip install indiestack-mcp`). Give us feedback. We read everything.
>
> — Patrick & Ed

### Ed's Comment

> Ed here, Patrick's co-founder.
>
> Over the past few weeks I've personally contacted 200+ makers — cold emails, Reddit DMs, Twitter replies. 66 have claimed their tools so far. But the vision is bigger than any one maker's listing. It's about capturing every solved problem so AI agents stop reinventing wheels.
>
> Every conversation I've had with a maker reinforces the same thing: people are building incredible stuff that nobody knows about. Not because it's bad — because there's no knowledge layer that connects what's been built to who needs it. Especially not for agents.
>
> We're two CS students in Cardiff who realized AI agents are brilliant at writing code but terrible at knowing what already exists. That gap wastes millions of tokens every day across every coding assistant. We're trying to close it.
>
> Building something that could genuinely change how developers work — and how agents serve them — still doesn't feel entirely real. But here we are. If you've built something, list it. If it solved your problem, it'll solve someone else's.
>
> — Ed

### Screenshots (to capture tonight)

1. **Landing page hero (dark mode)** — Full-width hero with tagline, search bar, and key stats (480 tools, 220+ makers). Dark background with teal accents.
2. **MCP walkthrough section with personalization card** — The "How it works" section showing MCP server integration and the agent memory personalization feature card.
3. **Explore page with Maker checkmark badges visible** — Grid of tools showing green Maker checkmark badges on claimed tools and category filters.
4. **Tool detail page (verified + ejectable badges, reviews)** — A single tool page showing Verified badge, Ejectable badge, star reviews, and changelog.
5. **Terminal — Claude Code using MCP server** — Screenshot of a terminal session where Claude Code queries IndieStack via MCP and gets personalized tool recommendations.

### Q&A

**Q: "How is this different from GitHub/npm?"**
A: GitHub stores code. npm stores packages. IndieStack stores tool knowledge — pricing, what it replaces, maintenance status, categories, reviews. It's structured for agents to make recommendations, not just search. When your agent asks "what auth tools exist for Python?", IndieStack returns structured comparisons with pricing, trust signals, and alternatives — not a list of repositories.

**Q: "What's new since last launch?"**
A: 480 tools (was 134), agent memory with personalized recommendations, 11 MCP tools (was 3), developer profiles, API keys, 220+ makers (66 claimed), Stack Builder API, Prompt Cache Index, Citation Tracking, and the full agent infrastructure. We shipped 22+ feature rounds in 10 weeks.

**Q: "How does agent memory work?"**
A: When you search through the MCP server, IndieStack builds a lightweight profile from your search patterns — category interests (e.g., "auth," "payments") and inferred tech stack (e.g., Python, React). It never stores your raw queries. Over time, recommendations get better. You can view your full profile, clear it, or pause tracking entirely at `/developer`. Full transparency, full control.

**Q: "Is this just a directory?"**
A: No. Directories are for humans with browsers. IndieStack has 11 MCP tools, a Stack Builder API that recommends full tool stacks for a project, a Prompt Cache Index for agent-optimized tool summaries, Citation Tracking so we know when agents actually recommend tools, and personalized recommendations that learn your preferences. AI agents don't browse websites — they need structured, searchable, programmable data.

**Q: "What counts as a 'tool'?"**
A: Anything that solves a problem developers face. Full SaaS products, self-hosted alternatives, scripts, utilities, file converters. If someone already built it, it belongs here. A txt-to-FASTA converter built because the online ones were paywalled? That's a tool. A deployment script that saves 20 minutes per release? That's a tool. The bar isn't polish — it's usefulness.

**Q: "Can I list my small utility?"**
A: Yes. IndieStack isn't just for polished products. If you built a txt-to-FASTA converter, a CSV parser, a deployment script — list it. That's knowledge that saves the next developer time and saves their agent thousands of tokens. Every solved problem matters.

**Q: "How do you make money?"**
A: Focus is on growth right now. Boost (featured placement) is available for makers who want extra visibility. Marketplace infrastructure exists for when we're ready to turn it on. Right now, the priority is building the most complete knowledge layer possible.

**Q: "What about security/privacy?"**
A: Fully open source — you can read every line of code. Transparent indie scoring (no black box algorithms). We never sell data. Developer profiles have full privacy controls: view everything we store, clear your profile with one click, or pause tracking entirely. Agent memory stores category interests and tech stack only, never raw search queries.

**Q: "Can I self-host this?"**
A: The codebase is open source. The MCP server is on PyPI (`pip install indiestack-mcp`). We also index self-hosted tools in the catalog alongside SaaS — look for the Ejectable badge, which marks tools you can run on your own infrastructure.

---

## Reddit Post Drafts

### r/SideProject

**Title:** We're building the knowledge base AI agents are missing — 480 tools and counting

We're Patrick and Ed, two CS students at Cardiff University. About 10 weeks ago we launched a small directory of indie dev tools. It had maybe 100 tools and a basic search page. Today we're relaunching it as something fundamentally different: a knowledge transfer hub where AI agents learn what tools already exist.

The observation that changed everything: AI agents are amnesiac. Every session starts from zero. They have no persistent knowledge of what's been built. We watched Claude spend 40,000 tokens rebuilding a file converter that some developer already built in an afternoon — because the agent had no way to know it existed.

That's not a code quality problem. It's a knowledge problem.

IndieStack is the knowledge layer. We index everything — full SaaS products, self-hosted tools, tiny utilities, scripts. If someone solved the problem, it belongs in the catalog. A developer built a txt-to-FASTA converter because the online ones were paywalled. That solution should live somewhere agents can find it so the next developer doesn't waste tokens rebuilding it.

We built an MCP server that connects to Claude Code, Cursor, and Windsurf. Install it (`pip install indiestack-mcp`) and your agent can search 480 tools, get personalized recommendations that learn your tech stack, and build full project stacks — all without leaving your terminal.

The agent memory is what I'm most proud of. It builds a lightweight profile from your search patterns — category interests and inferred tech stack, never raw queries. Over time, recommendations get genuinely useful. Full transparency: view, clear, or pause at `/developer`.

Tech stack: Python/FastAPI/SQLite on a single Fly.io machine. Zero JS frameworks. The whole thing runs on about $5/mo. We wanted to prove you can build something real without a massive infrastructure bill.

480 tools, 220+ makers, 66 claimed, 21 categories, 11 MCP tools, 2,000+ agent lookups.

Check it out: https://indiestack.fly.dev

If you've built something useful — no matter how small — list it. That's knowledge the ecosystem needs.

### r/SaaS

**Title:** AI agents keep rebuilding solved problems — we're fixing that with a tool knowledge layer

Here's an inefficiency nobody's talking about: every time an AI coding agent starts a new session, it has zero knowledge of what tools already exist. So it rebuilds. Auth systems, billing integrations, file converters, email pipelines — all from scratch, burning thousands of tokens on problems someone already solved.

We built IndieStack to fix that. It's a knowledge layer where AI agents learn what tools exist before writing code from scratch. Not a marketplace (direct selling is paused). Not a review site. A structured, agent-readable catalog of 480 tools — from full SaaS products to tiny utilities — that agents query programmatically via MCP.

The token savings are real. When a developer asks Claude Code to "add auth to my app," it can now search IndieStack, find existing solutions, compare pricing and features, and recommend one — instead of writing 400 lines of custom auth code. That's a massive efficiency gain for every developer using AI coding assistants.

Over 2,000 agent lookups so far and growing fast. The agent memory feature means recommendations improve over time — it learns your tech stack and category interests (never raw queries) and surfaces increasingly relevant tools.

We're two CS students at Cardiff University. The whole platform runs on Python/FastAPI/SQLite on a single Fly.io machine. Infrastructure bill: under $10/mo. We're focused on growth and building the most complete knowledge layer possible before worrying about revenue.

The catalog isn't just polished SaaS products. We index everything — scripts, utilities, self-hosted alternatives. If someone built a CSV parser because the existing options were terrible, that belongs here. Every solved problem that agents can reference is a problem that doesn't get rebuilt from scratch.

220+ makers listed. 66 claimed. 11 MCP tools. If you've built something, list it: https://indiestack.fly.dev

### r/webdev

**Title:** Built an MCP server that gives AI coding assistants memory of what tools exist — your agent has amnesia and it's costing you tokens

Your AI coding assistant has amnesia. Every session starts from zero. It doesn't remember that you searched for auth tools last week, doesn't know that someone already built the exact file converter you need, and will happily spend 40,000 tokens rebuilding something that already exists.

We built an MCP server that fixes this.

```bash
pip install indiestack-mcp
```

It connects Claude Code, Cursor, and Windsurf to a catalog of 480 tools — from full products to tiny utilities. But the interesting part is the agent memory.

The server exposes 11 tools including:
- `search_tools` — full-text search across 480 tools with structured metadata
- `get_recommendations` — personalized recs based on your developer profile
- `stack_builder` — suggest a full tool stack for a project description
- `get_tool_details` — deep info on any tool (pricing, badges, reviews, what it replaces)

The personalization builds a lightweight profile from your search patterns — category interests and inferred tech stack. Search for auth tools a few times and it starts surfacing auth-adjacent tools you haven't seen. Never stores raw queries. View, clear, or pause at `/developer`.

Under the hood: FTS5 with a `replaces` fallback — if you search "Heroku alternative" and FTS returns nothing, it checks the `replaces` column to find indie alternatives. Zero-result pages show a "market gap" CTA that tracks demand. Agent memory uses recency-weighted category scoring with a discovery pick to avoid filter bubbles.

Tech decisions:
- Pure Python string templates. No Jinja2, no React, no build step.
- FastAPI + SQLite with FTS5 for search.
- Single Fly.io machine. $5/mo infrastructure.
- Zero JavaScript frameworks. Every page is server-rendered HTML with minimal inline JS.
- Fully open source.

2,000+ agent lookups so far. The knowledge layer is filling up — but we need more tools, especially small utilities. If you built something useful, list it: https://indiestack.fly.dev

### r/selfhosted

**Title:** Your AI coding assistant should know about self-hosted options — we built the knowledge layer for that

When someone asks Claude Code to "add analytics," it suggests Google Analytics or writes custom tracking code. It doesn't mention Plausible, Umami, or any of the excellent self-hosted alternatives. Not because they're worse — because the agent has no knowledge layer to draw from.

We built IndieStack — a catalog of 480 indie developer tools that AI agents can query via MCP. A significant chunk are self-hostable, tagged with an "Ejectable" badge so both humans and agents can filter for tools you can run on your own infrastructure.

```bash
pip install indiestack-mcp
```

Install the MCP server and your AI coding assistant can search the catalog with awareness of self-hosted options. Ask it for "self-hosted auth tools" and it knows what's available — with pricing (or lack thereof), features, maintenance status, and what enterprise tools they replace.

We're not trying to replace Awesome-Selfhosted or any of the great lists this community maintains. Those lists are for humans. We're building the knowledge layer for agents. When your agent can recommend Plausible instead of writing 300 lines of custom analytics, everyone wins.

The catalog spans 21 categories. Self-hosted, open source, and SaaS all live side by side with clear badges. The agent memory even learns your preferences — if you consistently look for self-hosted options, it starts prioritizing them in recommendations.

We'd love suggestions for self-hosted tools we're missing. If you've built something or use something that should be in the catalog, submit it: https://indiestack.fly.dev/submit

Browse: https://indiestack.fly.dev/explore

### r/vibecoding

**Title:** Your AI just spent 40k tokens rebuilding something that already exists

You know that feeling when Claude writes 500 lines of auth code... and you find out later there's a $9/mo tool that does it better? Or when it builds you an entire file converter from scratch when some developer already built and open-sourced that exact converter?

Your AI assistant has amnesia. Every session starts fresh. It has zero memory of what tools exist in the world.

We fixed that.

```bash
pip install indiestack-mcp
```

IndieStack is a knowledge layer of 480 tools — from full products to tiny utilities someone built in an afternoon. Install the MCP server and your agent checks what already exists before writing code from scratch. Auth, billing, email, file converters, deployment scripts — whatever you need, it searches first.

The best part: it learns what you build with. Use it for a while and it picks up your tech stack and the kinds of tools you reach for. Recommendations get better over time. You can see exactly what it knows about you and clear it anytime at `/developer`.

And "tools" doesn't just mean polished SaaS products. Someone built a txt-to-FASTA converter because the online ones were paywalled. That's in there. A CSV parser that handles edge cases better than the alternatives? In there. If someone already solved the problem, your agent should know about it before burning tokens reinventing the wheel.

480 tools, 21 categories, all indie-built. No enterprise bloatware.

Check it out: https://indiestack.fly.dev

Built by two CS students with Python and SQLite. No JS frameworks were harmed.

### r/indiehackers

**Title:** List anything you've built — even tiny utilities. AI agents need to know it exists.

If you've built something useful, it doesn't matter how small or unpolished it is. It needs to be in a knowledge layer that AI agents can access.

Here's why: every time a developer asks Claude Code or Cursor to build something, the agent starts from scratch. It doesn't know your auth library exists. It doesn't know someone already built that CSV parser. It doesn't know about the file converter you shipped last weekend. So it rebuilds all of it, burning thousands of tokens on solved problems.

IndieStack is the knowledge layer that fixes this. We have 480 tools indexed — and we want everything. Not just polished SaaS products. Utilities, scripts, converters, self-hosted tools, CLI tools, browser extensions. If you built it because you needed it, other developers need it too.

A real example: a developer needed to convert .txt files to .FASTA format. The online converters were paywalled and limited to 1GB. They built their own in an afternoon. That solution should live somewhere agents can find it — so the next developer doesn't waste 40,000 tokens rebuilding it.

That's the kind of thing we want listed. That's knowledge transfer.

When you list your tool, it becomes discoverable by AI coding assistants via our MCP server (`pip install indiestack-mcp`). Over 2,000 agent lookups so far. 11 MCP tools including personalized recommendations, stack building, and citation tracking. The agent memory learns developer preferences over time — more searches, better recommendations.

220+ makers listed so far. 66 have claimed their tools. 21 categories. Maker checkmark badge on claimed tools.

No listing fee. No gatekeeping. The bar isn't polish — it's usefulness.

If you've built something, list it: https://indiestack.fly.dev/submit

The ecosystem needs your solved problems more than it needs another from-scratch rebuild.

---

## Early Maker Email (6 AM Blast)

**Target:** All claimed makers (66 total)
**Subject:** "Your tool goes in front of Product Hunt today — make sure it's ready"
**Template:** `launch_morning_maker_html(maker_name, tool_name)` in `email.py`
**CTA:** "Review Your Listing" -> `/dashboard`

**Note:** The Stripe Connect nudge angle is paused. Direct selling is paused. If/when marketplace selling resumes, a separate Stripe nudge campaign can be sent. This email is purely about listing readiness before the PH traffic spike.

**Email body outline:**

> Hey {maker_name},
>
> IndieStack is relaunching on Product Hunt in 6 hours. Thousands of developers and AI agents are going to discover your tool today.
>
> {tool_name} is listed and ready — but is it showing its best? Take 2 minutes to check:
>
> - Is the description clear and accurate?
> - Are the tags and categories right?
> - Got a changelog entry? Recent updates show the tool is actively maintained.
> - Is the "replaces" field set? This is how agents recommend you as an alternative to bigger tools.
>
> [Review Your Listing ->] /dashboard
>
> Today's going to be our biggest traffic day — from both humans and AI agents. Make sure {tool_name} makes a strong impression.
>
> — Patrick

---

## Day-Of Timeline

| Time (GMT) | Who | Action |
|------------|-----|--------|
| 6:00 AM | Patrick | Send maker email blast (listing readiness) |
| 8:00 AM | Patrick | PH goes live (midnight PST). Post maker comment immediately. |
| 8:05 AM | Patrick | Share PH link in follow-up maker email ("We're live!") |
| 9:00 AM | Ed | Reddit posts go live (all 6 subs) |
| 9:00 AM | Ed | Instagram/TikTok influencer posts scheduled |
| 10:00 AM | Ed | Discord/IH maker-facing blasts + co-founder PH comment |
| 10:00 AM | Patrick | Weekly digest email to all subscribers with PH link |
| 12:00 PM | Both | Reply to every PH comment, monitor Reddit |
| 3:00 PM | Ed | Second Reddit push if momentum building |
| 6:00 PM | Patrick | PH update comment with day stats |
| 9:00 PM | Both | Final comment sweep, thank everyone |

---

## Verification Checklist

- [ ] `python3 smoke_test.py` — 38/38
- [ ] PH description reflects knowledge transfer angle (no "marketplace" or "sell your tools" language)
- [ ] PH tagline is 57 chars or under
- [ ] PH description is 260 chars or under
- [ ] Reddit drafts reviewed — zero marketplace/selling references
- [ ] Maker email template tested (listing readiness, not Stripe)
- [ ] No "keep 95%" or commission language in any PH copy
- [ ] Landing page messaging aligned with knowledge transfer positioning
- [ ] PH post queued and ready to submit
- [ ] All Reddit drafts reviewed and ready
- [ ] Send script tested locally
- [ ] MCP server latest version on PyPI
- [ ] Screenshots captured and uploaded to PH
- [ ] Ed has all Reddit posts drafted in separate tabs
