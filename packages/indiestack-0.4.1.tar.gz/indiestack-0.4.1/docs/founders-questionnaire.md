# IndieStack Founders Questionnaire

Fill this out however you like — bullet points, rambling, voice notes transcribed, whatever. I'll write it up properly for the About page.

## About you both

- Full names and what you want to be called on the site
- One-line role each (e.g., "builds the product" / "handles growth")
- Where are you based?
- Photo of each of you? (even casual/cropped is fine — can be a URL or file path)
- Any relevant background? (previous projects, jobs, what makes you qualified to curate indie tools)

## The origin story

- How did IndieStack start? What were you doing when the idea came up?
- What problem were you personally frustrated by?
- Was there a specific moment where you said "we should build this"?

## The mission (in your own words)

- Why indie tools specifically? Why not just "all SaaS"?
- What do you want IndieStack to be in 1 year?
- What's one thing about the indie tool space that annoys you?

## For Ed specifically

- What's your Reddit/social strategy in a sentence?
- What's been the most surprising response from a maker you've reached out to?

## Fun / human stuff

- What tools do you both actually use day-to-day? (indie or not)
- Anything personal you're happy to share — hobbies, uni, how you know each other
- Any funny story from building IndieStack?

---

*When you're done, send this back and I'll turn it into a proper About page with your story, photos, and personality.*
