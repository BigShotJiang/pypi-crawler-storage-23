# Patrick's Questionnaire Responses (Feb 2026)

## About
- **Name:** Patrick Amey-Jones ("Pat" / "Oat" / "Oatcake" — typo from years ago)
- **Role:** Builds IndieStack
- **Location:** Cardiff
- **Photo:** Pending — remind him
- **Background:** BSc Zoology final year at Cardiff Uni. Does data analytics in RStudio/Python for course. Always coded on the side. IndieStack is the project he's put his heart into. "Claude has given me superpowers."

## Origin Story
- Repeatedly failed to get SaaS side hustles seen — too hard to break through
- Wanted to build something for people in his situation — a place to build a reputation
- Students struggling with AI uprising — wanted an indie place for vibecoding wave to break out
- Started from a conversation with Ed while both separately tried to launch SaaS products (Pat was working on GovLink and Logic Gate, Ed doing his own thing)

## Mission
- Give people opportunity to build reputation away from mainstream places
- An indie community where everyone has a fair chance to thrive
- In 1 year: central hub of all things vibecoded and manually coded — "analogous to humans sharing knowledge over generations but we are building the same systems for agents to save power/tokens and make names for ourselves"
- Annoyance: posting on Reddit over and over, gated entry on HN (karma farming). Wants open community, not closed.

## Fun Stuff
- Uses Claude Code daily + whatever it pulls from IndieStack
- Final year zoology student at Cardiff — doesn't know what he wants to do after
- Knows getting a job in zoology will be hard — building IndieStack to build CV, make money, break out
- Gets 5-6 hours of sleep average balancing uni + IndieStack. "The second mouse gets the cheese."
