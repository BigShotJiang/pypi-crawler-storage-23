import os

BASE_URL = os.environ.get("BASE_URL", "https://indiestack.fly.dev")
