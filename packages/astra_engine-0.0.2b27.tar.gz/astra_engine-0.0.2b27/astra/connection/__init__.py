# -----------------------------------------------------------
# Astra - WhatsApp Client Framework
# Licensed under the Apache License 2.0.
# -----------------------------------------------------------

"""
Astra Connection: Manages the bridge to the Chromium engine.
"""

from .browser_manager import BrowserController

__all__ = ["BrowserController"]
