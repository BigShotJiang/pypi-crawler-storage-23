# -----------------------------------------------------------
# Astra - WhatsApp Client Framework
# Licensed under the Apache License 2.0.
# -----------------------------------------------------------

"""
Astra Client: The main developer interface for WhatsApp automation.
"""

from .client import Client

__all__ = ["Client"]
