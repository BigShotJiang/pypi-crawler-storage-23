"""Version information for sagellm-core."""

__version__ = "0.5.2.9"
