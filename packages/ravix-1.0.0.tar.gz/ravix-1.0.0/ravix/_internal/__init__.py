"""
Internal helpers.

This submodule contains private helper functions used internally by Ravix.
These are not part of the public API and may change without notice.
"""
