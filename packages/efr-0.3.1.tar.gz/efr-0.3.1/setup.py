#!/usr/bin/env python
# coding:utf-8
import os
import sys
import ctypes
import tempfile
from setuptools import find_packages, setup
from setuptools.command.install import install

setup(
    name='efr',
    version='0.3.1',
    description='...',
    author_email='2229066748@qq.com',
    maintainer="Eagle'sBaby",
    maintainer_email='2229066748@qq.com',
    packages=find_packages(),
    license='Apache Licence 2.0',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: Microsoft :: Windows',
    ],
    keywords=['event'],
    python_requires='>=3.10',
    install_requires=[
        "loguru",
    ],
    package_data={
        '': ['*.md'],
    },
    include_package_data=True,
    # entry_points={
    #     'console_scripts': [
    #         'f3 = files3:cmd_show',
    #         'f3open = files3:cmd_open',
    #         'f3assoc = files3:cmd_assoc',
    #         'f3unassoc = files3:cmd_unassoc',
    #     ],
    # },
    # cmdclass={
    #     'install': PostInstallCommand,
    # },
)
