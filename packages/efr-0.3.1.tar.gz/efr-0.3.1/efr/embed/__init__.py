"""
efr.embed - Embedded event system with optional framework integration.

This module provides an embedded event system that can operate in:
- Standalone non-threaded mode (default)
- Integrated mode with EventFramework

The system supports dynamic attachment/detachment from frameworks,
allowing seamless switching between modes.

嵌入式事件系统模块，支持可选的框架集成。

本模块提供一个嵌入式事件系统，可以运行在：
- 独立非线程模式（默认）
- 与EventFramework集成模式

系统支持动态附加/分离框架，允许在模式之间无缝切换。

Example:
    >>> from efr.embed import EventSystem, PrioritizedEventSystem

    >>> # Standalone mode (non-threaded)
    >>> events = EventSystem()
    >>> events.listenFor("user_login", on_login, "auth_service")
    >>> events.pushEvent("user_login", {"user": "alice"})

    >>> # With framework at initialization
    >>> from efr.core import EventFramework
    >>> efr = EventFramework()
    >>> events = EventSystem(framework=efr)

    >>> # Delayed framework attachment
    >>> events = EventSystem()
    >>> events.eframework = efr

    >>> # Framework detachment (switch back to standalone)
    >>> del events.eframework

    >>> # With priority
    >>> events = PrioritizedEventSystem()
    >>> events.listenFor("critical", handle_critical, priority=10)
"""

from efr.embed.api import EventListener, EventSystem, PrioritizedEventSystem

__all__ = [
    "EventListener",
    "EventSystem",
    "PrioritizedEventSystem",
]
