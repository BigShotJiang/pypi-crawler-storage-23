"""
Embed API Module - Embedded event system with optional framework integration.

嵌入式API模块 - 可选框架集成的嵌入式事件系统。

This module provides:
- Non-threaded event system (same as reference implementation)
- Optional EventFramework integration
- Dynamic framework attachment/detachment
- Seamless mode switching between standalone and framework modes

特性：
- 非线程模式的事件系统（与参考实现一致）
- 可选的EventFramework集成
- 动态框架附加/分离
- 独立模式和框架模式之间的无缝切换
"""

from __future__ import annotations

import weakref
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, FrozenSet, Generic, List, Optional, Set, TypeVar, Union

# Import efr core components for framework integration
from efr.core.event import Event, EventState
from efr.core.estation import EventStation
from efr.core.eframework import EventFramework

# Type variable for callback typing
T = TypeVar('T')

# Type alias for callbacks
EventCallback = Callable[[Any], Any]


@dataclass(frozen=True, slots=True)
class EventListener:
    """
    Immutable representation of an event listener.
    
    Uses slots for memory efficiency and frozen for immutability.
    
    不可变的事件监听器表示。
    使用slots提高内存效率，frozen保证不可变性。
    """
    callback: EventCallback
    sources: FrozenSet[str] = field(default_factory=frozenset)
    
    def __hash__(self) -> int:
        return hash((id(self.callback), self.sources))
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, EventListener):
            return NotImplemented
        return (self.callback == other.callback and 
                self.sources == other.sources)


class EventSystem:
    """
    Embedded event system with optional framework integration.
    
    嵌入式事件系统，支持可选的框架集成。
    
    Features:
    - Non-threaded standalone mode (default)
    - Optional EventFramework integration
    - Dynamic framework attachment/detachment
    - Source/target filtering
    - Method chaining support
    
    特性：
    - 非线程独立模式（默认）
    - 可选的EventFramework集成
    - 动态框架附加/分离
    - 源/目标过滤
    - 方法链支持
    
    Example:
        >>> # Standalone mode (non-threaded)
        >>> events = EventSystem()
        >>> events.listenFor('damage', on_damage, 'combat')
        >>> events.pushEvent('damage', {'amount': 10})

        >>> # With framework at initialization
        >>> efr = EventFramework()
        >>> events = EventSystem(eframework=efr)

        >>> # Delayed framework attachment
        >>> events = EventSystem()
        >>> events.eframework = efr

        >>> # Framework detachment
        >>> del events.eframework
    """
    
    def __init__(
        self,
        eframework: Optional[EventFramework] = None,
        auto_worker: bool = True
    ) -> None:
        """
        Initialize the embedded event system.

        Args:
            eframework: Optional EventFramework instance for integration.
                      If None, operates in standalone non-threaded mode.
            auto_worker: If True, automatically assign a worker to stations
                      when attached to a framework. Default is True.

        初始化嵌入式事件系统。

        参数：
            eframework: 可选的EventFramework实例用于集成。
                      如果为None，则以独立非线程模式运行。
            auto_worker: 如果为True，附加到框架时自动为站点分配工作线程。
                      默认为True。
        """
        # Event name -> set of listeners mapping
        self._listeners: Dict[str, Set[EventListener]] = defaultdict(set)

        # Weak references for automatic cleanup (optional)
        self._weak_refs: Dict[str, weakref.WeakSet] = defaultdict(weakref.WeakSet)

        # Framework integration
        self._eframework: Optional[EventFramework] = None
        self._stations: Dict[str, EventStation] = {}
        self._event_map: Dict[str, List[Event]] = defaultdict(list)

        # Auto worker configuration
        self._auto_worker: bool = auto_worker

        # Set framework if provided
        if eframework is not None:
            self.eframework = eframework

    @property
    def eframework(self) -> Optional[EventFramework]:
        """
        Get or set the associated EventFramework.

        Getter: Returns the associated EventFramework or None if in standalone mode.
        Setter: Attach or switch to a new EventFramework.
        Deleter: Detach from the current framework (switch to standalone mode).

        Example:
            >>> # Getter
            >>> efr = events.eframework
            >>> # Setter
            >>> events.eframework = EventFramework()
            >>> # Deleter
            >>> del events.eframework
        """
        return self._eframework

    @eframework.setter
    def eframework(self, eframework: Optional[EventFramework]) -> None:
        """Attach or switch to a new EventFramework."""
        # Handle None => equivalent to del
        if eframework is None:
            del self.eframework
            return

        # Skip if setting the same framework
        if self._eframework is eframework:
            return

        # Detach from current framework if any (this also releases auto-worker)
        if self._eframework is not None:
            del self.eframework

        self._eframework = eframework

        # Create stations for all existing events
        # (auto-worker will be created per station in _create_station if needed)
        for event_name in self._listeners.keys():
            self._create_station(event_name)

    @eframework.deleter
    def eframework(self) -> None:
        """Detach from the current EventFramework and switch to standalone mode."""
        if self._eframework is not None:
            # Unregister all stations (this also unassigns workers)
            for station in list(self._stations.values()):
                self._eframework.logoff(station)

            # Auto-created workers will be released automatically when stations are logged off
            self._stations.clear()
            self._event_map.clear()
            self._eframework = None

    def _create_station(self, event_name: str) -> Optional[EventStation]:
        """
        Create and register an EventStation for the given event name.

        Args:
            event_name: The name of the event

        Returns:
            The created EventStation or None if no framework
        """
        if self._eframework is None:
            return None

        if event_name in self._stations:
            return self._stations[event_name]

        def responder(event: Event) -> Any:
            """Responder that delivers events to listeners."""
            # Store the framework event for later retrieval
            self._event_map[event_name].append(event)
            # Deliver to listeners
            self._deliver_to_listeners(event_name, event.task)
            return None

        station = EventStation(
            key=event_name,
            respond_fn=responder
        )

        self._stations[event_name] = station

        # Auto-assign worker if enabled (using new login(worker=True) feature)
        if self._auto_worker:
            self._eframework.login(station, True)
        else:
            self._eframework.login(station)

        return station

    def _remove_station(self, event_name: str) -> None:
        """
        Remove and unregister an EventStation for the given event name.

        Args:
            event_name: The name of the event
        """
        if event_name in self._stations:
            station = self._stations[event_name]
            if self._eframework is not None:
                self._eframework.logoff(station)
            del self._stations[event_name]
            if event_name in self._event_map:
                del self._event_map[event_name]

    def _deliver_to_listeners(self, event_name: str, data: Any) -> int:
        """
        Deliver an event to all matching listeners.
        
        Args:
            event_name: The event name
            data: The event data
            
        Returns:
            Number of listeners that received the event
        """
        if event_name not in self._listeners:
            return 0
        
        listeners = self._listeners[event_name]
        delivered = 0
        
        for listener in listeners:
            # Check source filtering
            if listener.sources:
                event_sources = self._extract_sources(data)
                if event_sources and not listener.sources.intersection(event_sources):
                    continue
            
            # Deliver the event
            try:
                listener.callback(data)
                delivered += 1
            except Exception as e:
                self._handle_delivery_error(event_name, listener, e)
        
        return delivered
    
    def listenFor(
        self, 
        event: str, 
        callback: EventCallback, 
        *sources: str
    ) -> EventSystem:
        """
        Register a listener for an event.
        
        Args:
            event: The event name to listen for
            callback: The function to call when event is received
            *sources: Optional source filters. Only events from these
                     sources will trigger the callback.
        
        Returns:
            self for method chaining
        
        Example:
            >>> events.listenFor('player_joined', on_join, 'network', 'lobby')
        """
        listener = EventListener(
            callback=callback,
            sources=frozenset(sources) if sources else frozenset()
        )
        self._listeners[event].add(listener)
        
        # Create station if framework is attached
        if self._eframework is not None and event not in self._stations:
            self._create_station(event)

        return self

    def listen(
        self,
        event: str,
        *sources: str
    ) -> Callable[[EventCallback], EventCallback]:
        """
        Decorator to register a listener for an event.
        
        装饰器语法糖，用于注册事件监听器。
        
        Args:
            event: Event name to listen for
            *sources: Optional source filters
        
        Returns:
            Decorator function that registers the callback and returns it unchanged
        
        Example:
            >>> @events.listen("user_login")
            ... def on_login(data):
            ...     print(f"User logged in: {data}")
            >>> @events.listen("security_alert", "auth_service")
            ... def on_security(data):
            ...     print(f"Security alert: {data}")
        """
        def decorator(callback: EventCallback) -> EventCallback:
            self.listenFor(event, callback, *sources)
            return callback
        return decorator
    
    def pushEvent(
        self, 
        event: str, 
        data: Any = None, 
        *targets: str
    ) -> int:
        """
        Push an event to all matching listeners.
        
        Args:
            event: The event name to push
            data: Optional data to pass to listeners
            *targets: Optional target filters. Only listeners whose callback name
                     matches one of these targets will receive the event.
        
        Returns:
            Number of listeners that received the event
        
        Delivery rules:
        1. If targets are specified, only listeners whose callback name
           contains any target string receive the event
        2. If sources are specified on the listener, only events from
           matching sources trigger the callback

        Example:
            >>> events.pushEvent('damage', {'amount': 10}, 'player', 'enemy')
        """
        # If framework is attached, push through framework only
        if self._eframework is not None:
            # Create an Event and push to framework
            framework_event = Event(
                task=data,
                dest=event,
                source=self._extract_sources(data)
            )
            self._eframework.push(framework_event)
            # Return 1 to indicate event was queued (actual delivery count unknown)
            return 1

        # Standalone mode: direct delivery
        return self._push_direct(event, data, *targets)
    
    def _push_direct(
        self, 
        event: str, 
        data: Any = None, 
        *targets: str
    ) -> int:
        """
        Push an event directly to listeners (non-threaded mode).
        
        Args:
            event: The event name to push
            data: Optional data to pass to listeners
            *targets: Optional target filters
        
        Returns:
            Number of listeners that received the event
        """
        if event not in self._listeners:
            return 0
        
        listeners = self._listeners[event]
        delivered = 0
        
        for listener in listeners:
            # Check target filtering (by callback name)
            if targets:
                callback_name = getattr(listener.callback, '__name__', '')
                if not any(t in callback_name for t in targets):
                    continue
            
            # Check source filtering
            if listener.sources:
                event_sources = self._extract_sources(data)
                if event_sources and not listener.sources.intersection(event_sources):
                    continue
            
            # Deliver the event
            try:
                listener.callback(data)
                delivered += 1
            except Exception as e:
                self._handle_delivery_error(event, listener, e)
        
        return delivered
    
    def cancelListen(
        self, 
        event: str, 
        callback: Optional[EventCallback] = None
    ) -> bool:
        """
        Cancel listening to an event.
        
        Args:
            event: The event name to stop listening for
            callback: Optional specific callback to remove. If None,
                     all listeners for the event are removed.
        
        Returns:
            True if any listeners were removed, False otherwise
        
        Example:
            >>> events.cancelListen('damage')  # Remove all damage listeners
            >>> events.cancelListen('damage', specific_callback)  # Remove specific
        """
        if event not in self._listeners:
            return False
        
        if callback is None:
            # Remove all listeners for this event
            removed = len(self._listeners[event]) > 0
            del self._listeners[event]
            
            # Remove station if framework is attached
            if event in self._stations:
                self._remove_station(event)
            
            return removed
        
        # Find and remove specific callback
        to_remove = None
        for listener in self._listeners[event]:
            if listener.callback == callback:
                to_remove = listener
                break
        
        if to_remove:
            self._listeners[event].discard(to_remove)
            if not self._listeners[event]:
                del self._listeners[event]
                
                # Remove station if framework is attached
                if event in self._stations:
                    self._remove_station(event)
            
            return True
        
        return False
    
    def hasListeners(self, event: str) -> bool:
        """Check if there are any listeners for an event."""
        return event in self._listeners and len(self._listeners[event]) > 0
    
    def getListenerCount(self, event: str) -> int:
        """Get the number of listeners for an event."""
        return len(self._listeners.get(event, set()))
    
    def getEvents(self) -> List[str]:
        """Get a list of all events with listeners."""
        return list(self._listeners.keys())
    
    def clear(self) -> None:
        """Remove all listeners and detach from framework."""
        # Remove all stations if framework is attached
        if self._eframework is not None:
            for event in list(self._stations.keys()):
                self._remove_station(event)

        self._listeners.clear()
        self._weak_refs.clear()
        self._event_map.clear()

    def stop(self) -> None:
        """
        Stop the event system and detach from framework.

        This is a convenience method that detaches from the framework.
        In standalone mode, this has no effect beyond clearing.
        """
        del self.eframework
        self.clear()
    
    def _extract_sources(self, data: Any) -> Optional[Set[str]]:
        """
        Extract source information from event data.
        
        Supports:
        - dict with 'source' or 'sources' key
        - object with .source or .sources attribute
        - string (treated as single source)
        """
        if data is None:
            return None
        
        # Handle dict
        if isinstance(data, dict):
            if 'source' in data:
                return {data['source']}
            if 'sources' in data:
                sources = data['sources']
                if isinstance(sources, (list, tuple, set)):
                    return set(sources)
                return {sources}
        
        # Handle object with attributes
        if hasattr(data, 'source'):
            return {data.source}
        if hasattr(data, 'sources'):
            sources = data.sources
            if isinstance(sources, (list, tuple, set)):
                return set(sources)
            return {sources}
        
        # Handle string
        if isinstance(data, str):
            return {data}
        
        return None
    
    def _handle_delivery_error(
        self, 
        event: str, 
        listener: EventListener, 
        error: Exception
    ) -> None:
        """Handle errors during event delivery. Override for custom error handling."""
        # Default: silently ignore or could log
        pass
    
    def __repr__(self) -> str:
        total_listeners = sum(len(v) for v in self._listeners.values())
        framework_status = "attached" if self._eframework else "standalone"
        return f"EventSystem(events={len(self._listeners)}, listeners={total_listeners}, mode={framework_status})"
    
    def __len__(self) -> int:
        """Return total number of listeners across all events."""
        return sum(len(v) for v in self._listeners.values())


@dataclass(order=True)
class _PrioritizedListener:
    """Internal prioritized listener wrapper."""
    priority: int
    listener: EventListener = field(compare=False)


class PrioritizedEventSystem(EventSystem):
    """
    Extended EventSystem with priority-based event delivery.
    
    基于优先级的嵌入式事件系统。
    
    Listeners can be registered with a priority level (higher = earlier).
    
    Example:
        >>> events = PrioritizedEventSystem()
        >>> events.listenFor("event", handler1, priority=5)
        >>> events.listenFor("event", handler2, priority=10)  # Delivered first
    """
    
    def __init__(
        self,
        eframework: Optional[EventFramework] = None,
        auto_worker: bool = True
    ) -> None:
        """
        Initialize the prioritized event system.

        Args:
            eframework: Optional EventFramework instance for integration.
            auto_worker: If True, automatically assign a worker to stations
                      when attached to a framework. Default is True.
        """
        super().__init__(eframework, auto_worker=auto_worker)
        # Override with priority-aware storage
        self._prioritized: Dict[str, List[_PrioritizedListener]] = defaultdict(list)
    
    def listenFor(
        self, 
        event: str, 
        callback: EventCallback, 
        *sources: str,
        priority: int = 0
    ) -> PrioritizedEventSystem:
        """
        Register a listener with optional priority.
        
        Args:
            event: The event name to listen for
            callback: The function to call when event is received
            *sources: Optional source filters
            priority: Priority level (higher = earlier delivery)
        
        Returns:
            self for method chaining
        """
        listener = EventListener(
            callback=callback,
            sources=frozenset(sources) if sources else frozenset()
        )
        
        pl = _PrioritizedListener(priority=priority, listener=listener)
        self._prioritized[event].append(pl)
        # Keep sorted by priority (descending)
        self._prioritized[event].sort(key=lambda x: x.priority, reverse=True)
        
        # Also add to base listeners for compatibility
        self._listeners[event].add(listener)
        
        # Create station if framework is attached
        if self._eframework is not None and event not in self._stations:
            self._create_station(event)

        return self

    def listen(
        self,
        event: str,
        *sources: str,
        priority: int = 0
    ) -> Callable[[EventCallback], EventCallback]:
        """
        Decorator to register a listener with optional priority.
        
        装饰器语法糖，用于注册带优先级的事件监听器。
        
        Args:
            event: Event name to listen for
            *sources: Optional source filters
            priority: Priority level (higher = earlier delivery)
        
        Returns:
            Decorator function that registers the callback and returns it unchanged
        
        Example:
            >>> @events.listen("critical_event", priority=10)
            ... def handle_critical(data):
            ...     print(f"Critical: {data}")
        """
        def decorator(callback: EventCallback) -> EventCallback:
            self.listenFor(event, callback, *sources, priority=priority)
            return callback
        return decorator
    
    def pushEvent(
        self, 
        event: str, 
        data: Any = None, 
        *targets: str
    ) -> int:
        """
        Push event with priority-ordered delivery.
        
        Args:
            event: Event name to push
            data: Data to pass to listeners
            *targets: Optional target filters
        
        Returns:
            Number of listeners that received the event
        """
        # If framework is attached, push through framework
        if self._eframework is not None:
            framework_event = Event(
                task=data,
                dest=event,
                source=self._extract_sources(data)
            )
            self._eframework.push(framework_event)

            # Also deliver directly with priority
            return self._push_direct_prioritized(event, data, *targets)

        # Standalone mode: direct delivery with priority
        return self._push_direct_prioritized(event, data, *targets)
    
    def _push_direct_prioritized(
        self, 
        event: str, 
        data: Any = None, 
        *targets: str
    ) -> int:
        """
        Push an event directly to listeners with priority ordering.
        
        Args:
            event: The event name to push
            data: Optional data to pass to listeners
            *targets: Optional target filters
        
        Returns:
            Number of listeners that received the event
        """
        if event not in self._prioritized:
            return 0
        
        delivered = 0
        
        for pl in self._prioritized[event]:
            listener = pl.listener
            
            # Check target filtering
            if targets:
                callback_name = getattr(listener.callback, '__name__', '')
                if not any(t in callback_name for t in targets):
                    continue
            
            # Check source filtering
            if listener.sources:
                event_sources = self._extract_sources(data)
                if event_sources and not listener.sources.intersection(event_sources):
                    continue
            
            # Deliver
            try:
                listener.callback(data)
                delivered += 1
            except Exception as e:
                self._handle_delivery_error(event, listener, e)
        
        return delivered
    
    def cancelListen(
        self, 
        event: str, 
        callback: Optional[EventCallback] = None
    ) -> bool:
        """
        Cancel listening with priority-aware removal.
        
        Args:
            event: Event name to stop listening for
            callback: Specific callback to remove (None = all)
        
        Returns:
            True if any listeners were removed
        """
        if event not in self._prioritized:
            return False
        
        if callback is None:
            # Remove all
            removed = len(self._prioritized[event]) > 0
            del self._prioritized[event]
            if event in self._listeners:
                del self._listeners[event]
            
            # Remove station if framework is attached
            if event in self._stations:
                self._remove_station(event)
            
            return removed
        
        # Remove specific callback
        original_len = len(self._prioritized[event])
        self._prioritized[event] = [
            pl for pl in self._prioritized[event] 
            if pl.listener.callback != callback
        ]
        
        if len(self._prioritized[event]) < original_len:
            # Also remove from base listeners
            for listener in list(self._listeners.get(event, set())):
                if listener.callback == callback:
                    self._listeners[event].discard(listener)
                    break
            
            if not self._prioritized[event]:
                del self._prioritized[event]
                if event in self._listeners:
                    del self._listeners[event]
                
                # Remove station if framework is attached
                if event in self._stations:
                    self._remove_station(event)
            
            return True
        
        return False
    
    def clear(self) -> None:
        """Remove all listeners and clear prioritized storage."""
        self._prioritized.clear()
        super().clear()
    
    def __repr__(self) -> str:
        total = sum(len(v) for v in self._prioritized.values())
        framework_status = "attached" if self._eframework else "standalone"
        return f"PrioritizedEventSystem(events={len(self._prioritized)}, listeners={total}, mode={framework_status})"


# =============================================================================
# Convenience Exports
# =============================================================================

__all__ = [
    'EventSystem',
    'PrioritizedEventSystem',
    'EventListener',
]
