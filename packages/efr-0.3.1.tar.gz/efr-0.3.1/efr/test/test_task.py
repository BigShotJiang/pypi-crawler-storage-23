"""
Test Task Module - Tests for Task class.

测试任务模块 - Task类的测试。
"""

import unittest
from efr.utils.task import Task, ONCE, CIRCLE


class TestTask(unittest.TestCase):
    """Test cases for Task class."""
    
    def test_task_creation(self) -> None:
        """Test basic task creation."""
        task = Task()
        self.assertEqual(task.left, ONCE)
        self.assertFalse(task.is_done())  # ONCE means ready to execute once
    
    def test_task_with_params(self) -> None:
        """Test task creation with parameters."""
        def target(a, b, c=None):
            return a + b + (c or 0)
        
        task = Task(target=target, args=(1, 2), kwargs={"c": 3}, times=3)
        self.assertEqual(task.left, 3)
    
    def test_task_execution(self) -> None:
        """Test task execution."""
        results = []
        
        def target(x):
            results.append(x)
            return x * 2
        
        task = Task(target=target, args=(5,), times=2)
        
        result1 = task()
        self.assertEqual(result1, 10)
        self.assertEqual(task.left, 1)
        
        result2 = task()
        self.assertEqual(result2, 10)
        self.assertEqual(task.left, 0)
        
        # Should not execute when done
        result3 = task()
        self.assertIsNone(result3)
    
    def test_circular_task(self) -> None:
        """Test circular (infinite) task."""
        results = []
        
        def target():
            results.append(1)
        
        task = Task(target=target, times=CIRCLE)
        
        self.assertTrue(task.is_circular())
        self.assertFalse(task.is_done())
        
        # Execute multiple times
        for _ in range(10):
            task()
        
        self.assertEqual(len(results), 10)
        self.assertFalse(task.is_done())  # Still not done
    
    def test_task_reset(self) -> None:
        """Test task reset."""
        def target(): pass
        
        task = Task(target=target, times=3)
        task()
        task()
        self.assertEqual(task.left, 1)
        
        task.reset()
        self.assertEqual(task.left, 3)
    
    def test_task_str(self) -> None:
        """Test string representation."""
        def my_function(): pass
        
        task = Task(target=my_function, times=5)
        str_repr = str(task)
        
        self.assertIn("Task", str_repr)
        self.assertIn("my_function", str_repr)


if __name__ == '__main__':
    unittest.main()
