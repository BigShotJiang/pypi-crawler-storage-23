"""
Test README examples - Ensure all code examples in README work correctly.

测试README示例 - 确保README中的所有代码示例都能正常运行。
"""

import time
import sys
from efr import (
    EventFramework, Event, EventStation,
    EventSystem, PrioritizedEventSystem
)


def test_example1_event_system():
    """Test README Example 1: EventSystem (Simple event system)"""
    print("\n[Test] Example 1: EventSystem...")
    events = EventSystem()
    results = []

    # Consumer: listen for tasks
    @events.listen("task_queue")
    def consumer(data):
        task_id = data["task_id"]
        results.append(task_id)
        return {"result": "success", "task_id": task_id}

    # Producer: push tasks
    for i in range(5):
        events.pushEvent("task_queue", {"task_id": i, "payload": f"data_{i}"})

    events.stop()

    assert len(results) == 5, f"Expected 5 results, got {len(results)}"
    assert set(results) == {0, 1, 2, 3, 4}, f"Unexpected results: {results}"
    print("[PASS] Example 1: EventSystem")


def test_example2_event_framework():
    """Test README Example 2: EventFramework (Multi-threaded)"""
    print("\n[Test] Example 2: EventFramework...")
    efr = EventFramework(name="test_producer_consumer")
    results = []

    # Consumer: define handler
    def consumer(event):
        task = event.task
        results.append(task['id'])
        return {"status": "done", "id": task["id"]}

    # Create station and bind worker
    station = EventStation(key="task_queue", respond_fn=consumer)
    worker = efr.add_worker("consumer_worker")
    efr.login(station, worker)

    # Start framework
    efr.start()

    # Producer: push tasks
    for i in range(5):
        event = Event(task={"id": i}, dest="task_queue")
        efr.push(event)

    # Wait for processing
    time.sleep(0.5)
    efr.quit()

    assert len(results) == 5, f"Expected 5 results, got {len(results)}"
    assert set(results) == {0, 1, 2, 3, 4}, f"Unexpected results: {results}"
    print("[PASS] Example 2: EventFramework")


def test_example3_hybrid():
    """Test README Example 3: Embed consumer + Estation producer (auto_worker)"""
    print("\n[Test] Example 3: Hybrid (Embed consumer + Estation producer)...")
    efr = EventFramework(name="test_hybrid")
    results = []

    # Consumer: listen via EventSystem (auto_worker=True automatically assigns worker)
    events = EventSystem(eframework=efr)

    @events.listen("job_queue")
    def consumer(data):
        job_id = data["job_id"]
        results.append(job_id)
        return {"job_id": job_id, "status": "completed"}

    # Producer: push via EventStation/Event
    def producer():
        for i in range(5):
            event = Event(
                task={"job_id": i, "data": f"payload_{i}"},
                dest="job_queue",
                priority=5
            )
            efr.push(event)
            time.sleep(0.05)

    # Start and run
    efr.start()
    producer()
    time.sleep(0.5)
    events.stop()
    efr.quit()

    assert len(results) == 5, f"Expected 5 results, got {len(results)}"
    assert set(results) == {0, 1, 2, 3, 4}, f"Unexpected results: {results}"
    print("[PASS] Example 3: Hybrid")


def test_advanced_prioritized():
    """Test advanced feature: Prioritized Event System"""
    print("\n[Test] Advanced: Prioritized Event System...")
    events = PrioritizedEventSystem()
    results = []

    # Low priority consumer
    @events.listen("task_queue", priority=1)
    def normal_consumer(data):
        results.append(("normal", data['task_id']))

    # High priority consumer
    @events.listen("task_queue", priority=10)
    def urgent_consumer(data):
        results.append(("urgent", data['task_id']))

    # Push task
    events.pushEvent("task_queue", {"task_id": 1})

    # Both consumers should receive the event
    assert len(results) == 2, f"Expected 2 results, got {len(results)}"
    # Urgent should be first due to priority
    assert results[0][0] == "urgent", f"Expected urgent first, got {results}"
    assert results[1][0] == "normal", f"Expected normal second, got {results}"

    events.stop()
    print("[PASS] Advanced: Prioritized Event System")


def test_advanced_source_filtering():
    """Test advanced feature: Source Filtering"""
    print("\n[Test] Advanced: Source Filtering...")
    events = EventSystem()
    results = []

    # Only listen to "payment_service" source
    @events.listen("task_queue", "payment_service")
    def payment_consumer(data):
        results.append(data.get("amount"))

    # Push with matching source
    events.pushEvent("task_queue", {
        "source": "payment_service",
        "amount": 100
    })

    # Push without matching source (should not be received)
    events.pushEvent("task_queue", {
        "source": "other_service",
        "amount": 200
    })

    assert len(results) == 1, f"Expected 1 result, got {len(results)}"
    assert results[0] == 100, f"Expected 100, got {results[0]}"

    events.stop()
    print("[PASS] Advanced: Source Filtering")


def test_advanced_dynamic_attachment():
    """Test advanced feature: Dynamic Framework Attachment"""
    print("\n[Test] Advanced: Dynamic Framework Attachment...")
    # Standalone mode
    events = EventSystem()
    results = []

    @events.listen("task_queue")
    def consumer(data):
        results.append(data['task_id'])

    # Test standalone mode
    events.pushEvent("task_queue", {"task_id": 1})
    assert len(results) == 1, f"Expected 1 result, got {len(results)}"

    # Attach to framework
    efr = EventFramework()
    events.eframework = efr
    efr.start()

    # Now events go through framework
    events.pushEvent("task_queue", {"task_id": 2})
    time.sleep(0.2)
    assert len(results) == 2, f"Expected 2 results, got {len(results)}"

    # Detach back to standalone
    del events.eframework

    # Push again in standalone mode
    events.pushEvent("task_queue", {"task_id": 3})
    assert len(results) == 3, f"Expected 3 results, got {len(results)}"

    efr.quit()
    events.stop()
    print("[PASS] Advanced: Dynamic Framework Attachment")


def run_all_tests():
    """Run all README example tests"""
    tests = [
        ("Example 1: EventSystem", test_example1_event_system),
        ("Example 2: EventFramework", test_example2_event_framework),
        ("Example 3: Hybrid", test_example3_hybrid),
        ("Advanced: Prioritized", test_advanced_prioritized),
        ("Advanced: Source Filtering", test_advanced_source_filtering),
        ("Advanced: Dynamic Attachment", test_advanced_dynamic_attachment),
    ]

    passed = 0
    failed = 0

    print("=" * 60)
    print("Running README Examples Tests")
    print("=" * 60)

    for name, test_func in tests:
        try:
            test_func()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"[FAIL] {name}: {e}")

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
