"""
Test Embed API Module - Tests for EventSystem and PrioritizedEventSystem.

测试嵌入式API模块 - EventSystem和PrioritizedEventSystem的测试。
"""

import unittest
import time
import sys
import os

# Add the output directory to the path
sys.path.insert(0, '/mnt/okcomputer/output')

from efr.embed import EventSystem, PrioritizedEventSystem, EventListener
from efr.core import EventFramework


class TestEventSystemStandalone(unittest.TestCase):
    """Test cases for EventSystem in standalone (non-threaded) mode."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.events = EventSystem()
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.events.stop()
    
    def test_standalone_mode_by_default(self) -> None:
        """Test that EventSystem starts in standalone mode by default."""
        self.assertIsNone(self.events.eframework)
        self.assertFalse(self.events.eframework)
    
    def test_listen_and_push(self) -> None:
        """Test basic listen and push."""
        results = []
        
        def callback(data):
            results.append(data)
        
        self.events.listenFor("test_event", callback)
        count = self.events.pushEvent("test_event", "hello")
        
        self.assertEqual(count, 1)
        self.assertEqual(results, ["hello"])
    
    def test_multiple_listeners(self) -> None:
        """Test multiple listeners for same event."""
        results1 = []
        results2 = []
        
        self.events.listenFor("event", lambda d: results1.append(d))
        self.events.listenFor("event", lambda d: results2.append(d))
        
        count = self.events.pushEvent("event", "data")
        
        self.assertEqual(count, 2)
        self.assertEqual(results1, ["data"])
        self.assertEqual(results2, ["data"])
    
    def test_source_filtering(self) -> None:
        """Test source filtering."""
        results = []
        
        def callback(data):
            results.append(data)
        
        # Listen only for events from "source1"
        self.events.listenFor("event", callback, "source1")
        
        # Push with matching source
        count1 = self.events.pushEvent("event", {"source": "source1", "data": 1})
        self.assertEqual(count1, 1)
        
        # Push with non-matching source
        count2 = self.events.pushEvent("event", {"source": "source2", "data": 2})
        self.assertEqual(count2, 0)
    
    def test_target_filtering(self) -> None:
        """Test target filtering."""
        results = []
        
        def player_handler(data):
            results.append(("player", data))
        
        def enemy_handler(data):
            results.append(("enemy", data))
        
        self.events.listenFor("damage", player_handler)
        self.events.listenFor("damage", enemy_handler)
        
        # Push to player target only
        count = self.events.pushEvent("damage", 10, "player")
        self.assertEqual(count, 1)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0], ("player", 10))
    
    def test_cancel_listen(self) -> None:
        """Test canceling listeners."""
        results = []
        
        def callback(data):
            results.append(data)
        
        self.events.listenFor("event", callback)
        self.events.pushEvent("event", "first")
        self.assertEqual(len(results), 1)
        
        # Cancel specific callback
        self.events.cancelListen("event", callback)
        self.events.pushEvent("event", "second")
        self.assertEqual(len(results), 1)  # No change
    
    def test_cancel_all(self) -> None:
        """Test canceling all listeners for an event."""
        self.events.listenFor("event", lambda d: None)
        self.events.listenFor("event", lambda d: None)
        
        self.assertEqual(self.events.getListenerCount("event"), 2)
        
        self.events.cancelListen("event")
        
        self.assertEqual(self.events.getListenerCount("event"), 0)
    
    def test_has_listeners(self) -> None:
        """Test hasListeners method."""
        self.assertFalse(self.events.hasListeners("event"))
        
        self.events.listenFor("event", lambda d: None)
        self.assertTrue(self.events.hasListeners("event"))
    
    def test_get_events(self) -> None:
        """Test getEvents method."""
        self.events.listenFor("event1", lambda d: None)
        self.events.listenFor("event2", lambda d: None)
        
        events = self.events.getEvents()
        self.assertIn("event1", events)
        self.assertIn("event2", events)
    
    def test_clear(self) -> None:
        """Test clear method."""
        self.events.listenFor("event1", lambda d: None)
        self.events.listenFor("event2", lambda d: None)
        
        self.assertEqual(len(self.events), 2)
        
        self.events.clear()
        
        self.assertEqual(len(self.events), 0)
        self.assertFalse(self.events.hasListeners("event1"))
    
    def test_method_chaining(self) -> None:
        """Test method chaining."""
        result = (self.events
            .listenFor("event1", lambda d: None)
            .listenFor("event2", lambda d: None))

        self.assertIs(result, self.events)
    
    def test_listen_decorator(self) -> None:
        """Test @events.listen() decorator."""
        results = []

        @self.events.listen("test_event")
        def on_test(data):
            results.append(data)

        count = self.events.pushEvent("test_event", "decorator_test")

        self.assertEqual(count, 1)
        self.assertEqual(results, ["decorator_test"])

    def test_listen_decorator_with_source(self) -> None:
        """Test @events.listen() decorator with source filtering."""
        results = []

        @self.events.listen("alert", "security")
        def on_security_alert(data):
            results.append(data)

        # Should receive - matching source
        count1 = self.events.pushEvent("alert", {"source": "security", "msg": "breach"})
        self.assertEqual(count1, 1)

        # Should not receive - non-matching source
        count2 = self.events.pushEvent("alert", {"source": "system", "msg": "info"})
        self.assertEqual(count2, 0)

        self.assertEqual(len(results), 1)
    
    def test_repr(self) -> None:
        """Test __repr__ method."""
        self.events.listenFor("event1", lambda d: None)
        self.events.listenFor("event2", lambda d: None)
        
        repr_str = repr(self.events)
        self.assertIn("EventSystem", repr_str)
        self.assertIn("standalone", repr_str)
        self.assertIn("listeners=2", repr_str)


class TestEventSystemWithFramework(unittest.TestCase):
    """Test cases for EventSystem with EventFramework integration."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.efr = EventFramework(name="test_framework", log_immediate=False)
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.efr.quit()
    
    def test_init_with_framework(self) -> None:
        """Test initialization with framework."""
        events = EventSystem(eframework=self.efr)

        self.assertIs(events.eframework, self.efr)
        self.assertTrue(events.eframework)

    def test_set_framework(self) -> None:
        """Test delayed framework attachment via property setter."""
        events = EventSystem()

        # Start in standalone mode
        self.assertIsNone(events.eframework)

        # Attach framework
        events.eframework = self.efr

        self.assertIs(events.eframework, self.efr)
        self.assertTrue(events.eframework)

    def test_set_framework_creates_stations(self) -> None:
        """Test that setting framework creates stations for existing listeners."""
        events = EventSystem()
        events.listenFor("event1", lambda d: None)
        events.listenFor("event2", lambda d: None)

        events.eframework = self.efr

        # Check that stations were created
        self.assertIn("event1", events._stations)
        self.assertIn("event2", events._stations)
    
    def test_detach_framework(self) -> None:
        """Test framework detachment via property deleter."""
        events = EventSystem(eframework=self.efr)
        events.listenFor("event", lambda d: None)

        # Detach framework
        del events.eframework

        self.assertIsNone(events.eframework)
        self.assertFalse(events.eframework)

        # Stations should be cleared
        self.assertEqual(len(events._stations), 0)
    
    def test_switch_framework(self) -> None:
        """Test switching between frameworks."""
        efr2 = EventFramework(name="test_framework_2", log_immediate=False)

        events = EventSystem(eframework=self.efr)
        events.listenFor("event", lambda d: None)

        # Switch to new framework
        events.eframework = efr2

        self.assertIs(events.eframework, efr2)

        efr2.quit()
    
    def test_framework_integration_push(self) -> None:
        """Test pushing events with framework integration."""
        import time
        events = EventSystem(eframework=self.efr)

        results = []
        events.listenFor("test_event", lambda d: results.append(d))

        # Start framework to process events
        self.efr.start()

        # Push event (queued to framework)
        count = events.pushEvent("test_event", "hello")

        # Event is queued, count is 1
        self.assertEqual(count, 1)

        # Wait for async processing
        time.sleep(0.2)
        self.assertEqual(results, ["hello"])

        self.efr.quit()
    
    def test_repr_with_framework(self) -> None:
        """Test __repr__ with framework attached."""
        events = EventSystem(eframework=self.efr)

        repr_str = repr(events)
        self.assertIn("attached", repr_str)


class TestPrioritizedEventSystem(unittest.TestCase):
    """Test cases for PrioritizedEventSystem class."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.events = PrioritizedEventSystem()
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.events.stop()
    
    def test_priority_ordering(self) -> None:
        """Test priority-based delivery order."""
        results = []
        
        def high_priority(d): results.append("high")
        def low_priority(d): results.append("low")
        
        # Register low priority first
        self.events.listenFor("event", low_priority, priority=1)
        # Then high priority
        self.events.listenFor("event", high_priority, priority=10)
        
        self.events.pushEvent("event", None)
        
        # High priority should be delivered first
        self.assertEqual(results, ["high", "low"])
    
    def test_same_priority(self) -> None:
        """Test same priority delivery."""
        results = []

        self.events.listenFor("event", lambda d: results.append(1), priority=5)
        self.events.listenFor("event", lambda d: results.append(2), priority=5)

        self.events.pushEvent("event", None)

        # Both should be delivered
        self.assertEqual(len(results), 2)

    def test_listen_decorator_with_priority(self) -> None:
        """Test @events.listen() decorator with priority."""
        results = []

        @self.events.listen("event", priority=1)
        def low_priority(d):
            results.append("low")

        @self.events.listen("event", priority=10)
        def high_priority(d):
            results.append("high")

        self.events.pushEvent("event", None)

        # High priority should be delivered first
        self.assertEqual(results, ["high", "low"])

    def test_listen_decorator_with_priority_and_source(self) -> None:
        """Test @events.listen() decorator with both priority and source."""
        results = []

        @self.events.listen("alert", "security", priority=5)
        def on_security(d):
            results.append("security")

        @self.events.listen("alert", "firewall", priority=10)
        def on_firewall(d):
            results.append("firewall")

        # Firewall has higher priority
        self.events.pushEvent("alert", {"source": "firewall"})
        self.assertEqual(results, ["firewall"])

        results.clear()

        # Both should fire, firewall first due to priority
        self.events.pushEvent("alert", {"source": "security"})
        self.assertEqual(results, ["security"])
    
    def test_prioritized_with_framework(self) -> None:
        """Test PrioritizedEventSystem with framework."""
        efr = EventFramework(name="test_prioritized", log_immediate=False)
        
        events = PrioritizedEventSystem(eframework=efr)
        
        results = []
        events.listenFor("event", lambda d: results.append("low"), priority=1)
        events.listenFor("event", lambda d: results.append("high"), priority=10)
        
        events.pushEvent("event", None)
        
        self.assertEqual(results, ["high", "low"])
        
        efr.quit()


class TestEventListener(unittest.TestCase):
    """Test cases for EventListener class."""
    
    def test_listener_creation(self) -> None:
        """Test EventListener creation."""
        def callback(data):
            pass
        
        listener = EventListener(callback=callback, sources=frozenset(["source1"]))
        
        self.assertEqual(listener.callback, callback)
        self.assertEqual(listener.sources, frozenset(["source1"]))
    
    def test_listener_hash(self) -> None:
        """Test EventListener hashing."""
        def callback(data):
            pass
        
        listener1 = EventListener(callback=callback)
        listener2 = EventListener(callback=callback)
        
        # Same callback should have same hash
        self.assertEqual(hash(listener1), hash(listener2))
    
    def test_listener_equality(self) -> None:
        """Test EventListener equality."""
        def callback1(data):
            pass
        
        def callback2(data):
            pass
        
        listener1 = EventListener(callback=callback1)
        listener2 = EventListener(callback=callback1)
        listener3 = EventListener(callback=callback2)
        
        self.assertEqual(listener1, listener2)
        self.assertNotEqual(listener1, listener3)


if __name__ == '__main__':
    unittest.main()
