"""
Test EventQueue Module - Tests for EventQueue class.

测试事件队列模块 - EventQueue类的测试。
"""

import unittest
import threading
import time
from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue


class TestEventQueue(unittest.TestCase):
    """Test cases for EventQueue class."""
    
    def test_queue_creation(self) -> None:
        """Test basic queue creation."""
        queue = EventQueue()
        self.assertEqual(queue.capacity, 0)  # Unlimited
        self.assertEqual(queue.qsize(), 0)
        self.assertTrue(queue.empty())
        self.assertFalse(queue.full())
    
    def test_queue_with_capacity(self) -> None:
        """Test queue with capacity limit."""
        queue = EventQueue(capacity=2)
        self.assertEqual(queue.capacity, 2)
        
        # Fill queue
        event1 = Event()
        event2 = Event()
        event3 = Event()
        
        self.assertIsNotNone(queue.push(event1))
        self.assertIsNotNone(queue.push(event2))
        self.assertTrue(queue.full())
        
        # Should fail (queue full)
        result = queue.push(event3, timeout=0.01)
        self.assertIsNone(result)
    
    def test_push_and_get(self) -> None:
        """Test push and get operations."""
        queue = EventQueue()
        event = Event(task="test")
        
        # Push event
        result = queue.push(event)
        self.assertIsNotNone(result)
        self.assertEqual(result.state, EventState.JUNIOR)
        self.assertEqual(queue.qsize(), 1)
        
        # Get event
        retrieved = queue.get(timeout=0.1)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.task, "test")
        self.assertEqual(queue.qsize(), 0)
    
    def test_release_multiple(self) -> None:
        """Test releasing multiple events."""
        queue = EventQueue()
        
        # Add events
        for i in range(5):
            queue.push(Event(task=f"event_{i}"))
        
        self.assertEqual(queue.qsize(), 5)
        
        # Release 3 events
        events = queue.release(num=3)
        self.assertEqual(len(events), 3)
        self.assertEqual(queue.qsize(), 2)
        
        # Release all remaining
        events = queue.release()
        self.assertEqual(len(events), 2)
        self.assertEqual(queue.qsize(), 0)
    
    def test_empty_queue_get(self) -> None:
        """Test get from empty queue."""
        queue = EventQueue()
        result = queue.get(timeout=0.01)
        self.assertIsNone(result)
    
    def test_thread_safety(self) -> None:
        """Test thread-safe operations."""
        queue = EventQueue()
        events_pushed = []
        events_popped = []
        
        def pusher():
            for i in range(50):
                event = Event(task=f"task_{i}")
                if queue.push(event):
                    events_pushed.append(i)
                time.sleep(0.001)
        
        def popper():
            for _ in range(50):
                event = queue.get(timeout=0.1)
                if event:
                    events_popped.append(event.task)
                time.sleep(0.001)
        
        threads = [
            threading.Thread(target=pusher),
            threading.Thread(target=popper),
            threading.Thread(target=pusher),
            threading.Thread(target=popper)
        ]
        
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # All pushed events should be popped
        self.assertEqual(len(events_pushed), len(events_popped))
    
    def test_queue_len(self) -> None:
        """Test __len__ method."""
        queue = EventQueue()
        self.assertEqual(len(queue), 0)
        
        queue.push(Event())
        self.assertEqual(len(queue), 1)
        
        queue.push(Event())
        self.assertEqual(len(queue), 2)


if __name__ == '__main__':
    unittest.main()
