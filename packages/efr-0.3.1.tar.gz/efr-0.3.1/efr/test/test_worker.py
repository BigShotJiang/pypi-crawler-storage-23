"""
Test Worker Module - Tests for Worker class.

测试工作线程模块 - Worker类的测试。
"""

import unittest
import time
from efr.utils.worker import Worker
from efr.utils.task import Task, ONCE, CIRCLE


class TestWorker(unittest.TestCase):
    """Test cases for Worker class."""
    
    def test_worker_creation(self) -> None:
        """Test basic worker creation."""
        worker = Worker(name="test_worker")
        self.assertEqual(worker.name, "test_worker")
        self.assertTrue(worker.daemon)
        self.assertTrue(worker.alive)
        self.assertEqual(worker.task_count(), 0)
    
    def test_add_task(self) -> None:
        """Test adding tasks to worker."""
        worker = Worker()
        task = Task(target=lambda: None, times=ONCE)
        
        result = worker.add_task(task)
        self.assertTrue(result)
        self.assertEqual(worker.task_count(), 1)
    
    def test_remove_task(self) -> None:
        """Test removing tasks from worker."""
        worker = Worker()
        task = Task(target=lambda: None, times=ONCE)
        
        worker.add_task(task)
        self.assertEqual(worker.task_count(), 1)
        
        result = worker.remove_task(task)
        self.assertTrue(result)
        self.assertEqual(worker.task_count(), 0)
    
    def test_task_execution(self) -> None:
        """Test task execution."""
        results = []
        
        def work():
            results.append(1)
        
        worker = Worker(mindt=0.01)
        task = Task(target=work, times=ONCE)
        
        worker.add_task(task)
        worker.start()
        
        time.sleep(0.1)
        worker.stop()
        worker.join()
        
        self.assertEqual(len(results), 1)
    
    def test_circular_task(self) -> None:
        """Test circular (infinite) task."""
        results = []
        
        def work():
            results.append(1)
            if len(results) >= 5:
                worker.stop()
        
        worker = Worker(mindt=0.01, always=True)
        task = Task(target=work, times=CIRCLE)
        
        worker.add_task(task)
        worker.start()
        worker.join(timeout=1.0)
        
        self.assertGreaterEqual(len(results), 5)
    
    def test_auto_stop(self) -> None:
        """Test auto-stop when tasks empty and always=False."""
        results = []
        
        def work():
            results.append(1)
        
        worker = Worker(mindt=0.01, always=False)
        task = Task(target=work, times=ONCE)
        
        worker.add_task(task)
        worker.start()
        worker.join(timeout=1.0)
        
        self.assertEqual(len(results), 1)
        self.assertFalse(worker.is_alive())
    
    def test_stop(self) -> None:
        """Test stopping worker."""
        worker = Worker()
        worker.start()
        self.assertTrue(worker.is_alive())
        
        worker.stop()
        worker.join(timeout=1.0)
        self.assertFalse(worker.is_alive())
    
    def test_multiple_tasks(self) -> None:
        """Test multiple tasks execution."""
        results = []

        def work1(): results.append("work1")
        def work2(): results.append("work2")

        worker = Worker(mindt=0.01)
        worker.add_task(Task(target=work1, times=ONCE))
        worker.add_task(Task(target=work2, times=ONCE))

        worker.start()
        time.sleep(0.1)
        worker.stop()
        worker.join()

        self.assertIn("work1", results)
        self.assertIn("work2", results)

    # ========== Cost Mechanism Tests ==========

    def test_auto_task_count_property(self) -> None:
        """Test auto_task_count property."""
        worker = Worker(auto_managed=True, auto_task_count=5)
        self.assertEqual(worker.auto_task_count, 5)

        # Change it
        worker.auto_task_count = 8
        self.assertEqual(worker.auto_task_count, 8)

    def test_auto_task_count_bounds(self) -> None:
        """Test auto_task_count bounds (1-10)."""
        worker = Worker(auto_managed=True)

        # Below minimum
        worker.auto_task_count = 0
        self.assertEqual(worker.auto_task_count, 1)

        worker.auto_task_count = -5
        self.assertEqual(worker.auto_task_count, 1)

        # Above maximum
        worker.auto_task_count = 20
        self.assertEqual(worker.auto_task_count, 10)

    def test_add_task_with_cost(self) -> None:
        """Test add_task with cost parameter."""
        worker = Worker(auto_managed=True)
        task = Task(target=lambda: None, times=ONCE)

        # Add task with cost
        worker.add_task(task, cost=5)

        # Only tracked in auto_managed mode
        self.assertEqual(worker.total_cost(), 5)

    def test_add_task_cost_non_auto_mode(self) -> None:
        """Test that cost is not tracked in non-auto mode."""
        worker = Worker(auto_managed=False)  # Non-auto mode
        task = Task(target=lambda: None, times=ONCE)

        worker.add_task(task, cost=5)

        # Cost not tracked in non-auto mode
        self.assertEqual(worker.total_cost(), 0)

    def test_total_cost_calculation(self) -> None:
        """Test total_cost calculation."""
        worker = Worker(auto_managed=True)

        task1 = Task(target=lambda: None, times=ONCE)
        task2 = Task(target=lambda: None, times=ONCE)
        task3 = Task(target=lambda: None, times=ONCE)

        worker.add_task(task1, cost=2)
        self.assertEqual(worker.total_cost(), 2)

        worker.add_task(task2, cost=3)
        self.assertEqual(worker.total_cost(), 5)

        worker.add_task(task3, cost=1)
        self.assertEqual(worker.total_cost(), 6)

    def test_remove_task_clears_cost(self) -> None:
        """Test that removing task clears its cost."""
        worker = Worker(auto_managed=True)
        task = Task(target=lambda: None, times=ONCE)

        worker.add_task(task, cost=5)
        self.assertEqual(worker.total_cost(), 5)

        worker.remove_task(task)
        self.assertEqual(worker.total_cost(), 0)

    def test_default_cost_is_one(self) -> None:
        """Test default cost is 1."""
        worker = Worker(auto_managed=True)
        task = Task(target=lambda: None, times=ONCE)

        worker.add_task(task)  # No cost specified
        self.assertEqual(worker.total_cost(), 1)


if __name__ == '__main__':
    unittest.main()
