"""
Test auto worker functionality - Ensure automatic worker allocation and release works correctly.

测试自动工作线程功能 - 确保自动分配和释放工作线程正常工作。
"""

import time
import sys
from efr import EventFramework, EventStation, EventSystem
from efr.utils.worker import Worker


def test_login_with_true_creates_auto_worker():
    """Test that login(station, True) creates an auto-managed worker."""
    print("\n[Test] login(station, True) creates auto worker...")
    efr = EventFramework(name="test_auto_worker")

    def handler(event):
        return {"status": "ok"}

    station = EventStation(key="test_station", respond_fn=handler)

    # Login with worker=True should create auto worker
    result = efr.login(station, True)
    assert result, "Login should succeed"

    # Check that an auto-managed worker was created
    auto_worker = efr._auto_workers.get("test_station")
    assert auto_worker is not None, "Auto worker should be created"
    assert auto_worker.auto_managed, "Worker should be auto-managed"
    assert station._worker is auto_worker, "Station should be assigned to auto worker"

    efr.quit()
    print("[PASS] login(station, True) creates auto worker")


def test_auto_worker_released_on_logoff():
    """Test that auto worker is released when station is logged off."""
    print("\n[Test] Auto worker released on logoff...")
    efr = EventFramework(name="test_auto_release")

    def handler(event):
        return {"status": "ok"}

    station = EventStation(key="test_station", respond_fn=handler)

    # Login with auto worker
    efr.login(station, True)
    auto_worker = efr._auto_workers.get("test_station")
    initial_worker_count = len(efr._workers)

    # Logoff should release the auto worker
    efr.logoff(station)

    # Auto worker should be removed from framework
    assert len(efr._workers) == initial_worker_count - 1, "Auto worker should be removed"
    assert "test_station" not in efr._auto_workers, "Auto worker mapping should be cleared"

    efr.quit()
    print("[PASS] Auto worker released on logoff")


def test_auto_worker_not_released_if_has_other_tasks():
    """Test that auto worker is not released if it has other tasks."""
    print("\n[Test] Auto worker not released if has other tasks...")
    efr = EventFramework(name="test_auto_shared")

    def handler1(event):
        return {"status": "ok"}

    def handler2(event):
        return {"status": "ok"}

    station1 = EventStation(key="station1", respond_fn=handler1)
    station2 = EventStation(key="station2", respond_fn=handler2)

    # Create one auto worker and manually assign to both stations
    efr.login(station1, True)
    auto_worker = efr._auto_workers.get("station1")

    # Manually assign same worker to second station (simulating shared worker scenario)
    efr.login(station2)
    efr.assign(station2, auto_worker)

    initial_worker_count = len(efr._workers)

    # Logoff first station - worker should NOT be released (still has station2)
    efr.logoff(station1)

    # Worker should still exist
    assert len(efr._workers) == initial_worker_count, "Worker should not be released (has other tasks)"

    # Logoff second station - now worker should be released
    efr.logoff(station2)
    assert len(efr._workers) == initial_worker_count - 1, "Worker should be released now"

    efr.quit()
    print("[PASS] Auto worker not released if has other tasks")


def test_assign_no_op_if_has_worker():
    """Test that assign does nothing if station already has a worker."""
    print("\n[Test] assign no-op if station already has worker...")
    efr = EventFramework(name="test_assign_noop")

    def handler(event):
        return {"status": "ok"}

    station = EventStation(key="test_station", respond_fn=handler)

    # Login with auto worker
    efr.login(station, True)
    auto_worker = efr._auto_workers.get("test_station")
    initial_worker_count = len(efr._workers)

    # Create a new manual worker
    manual_worker = efr.add_worker("manual_worker")

    # Try to reassign station to manual worker - should do nothing
    result = efr.assign(station, manual_worker)

    # Assign should fail (station already has worker)
    assert not result, "Assign should fail when station already has worker"

    # Original auto worker should still be assigned
    assert station._worker is auto_worker, "Station should still have original auto worker"
    assert len(efr._workers) == initial_worker_count + 1, "No workers should be released"

    # Must explicitly unassign first, then assign
    efr.assign(station, None)  # Unassign
    result = efr.assign(station, manual_worker)  # Now assign
    assert result, "Assign should succeed after unassignment"
    assert station._worker is manual_worker, "Station should now have manual worker"

    # Auto worker should be released now (no other tasks)
    assert auto_worker not in efr._workers, "Auto worker should be removed"

    efr.quit()
    print("[PASS] assign no-op if station already has worker")


def test_manual_worker_not_released():
    """Test that manually created workers are never auto-released."""
    print("\n[Test] Manual worker not auto-released...")
    efr = EventFramework(name="test_manual_preserve")

    def handler(event):
        return {"status": "ok"}

    station = EventStation(key="test_station", respond_fn=handler)

    # Create manual worker and assign
    manual_worker = efr.add_worker("manual_worker")
    efr.login(station, manual_worker)

    initial_worker_count = len(efr._workers)

    # Logoff station
    efr.logoff(station)

    # Manual worker should still exist
    assert len(efr._workers) == initial_worker_count, "Manual worker should not be auto-released"

    efr.quit()
    print("[PASS] Manual worker not auto-released")


def test_eventsystem_auto_worker():
    """Test EventSystem with auto_worker=True uses per-station auto workers."""
    print("\n[Test] EventSystem auto_worker=True creates per-station workers...")
    efr = EventFramework(name="test_embed_auto")

    # EventSystem with auto_worker=True
    events = EventSystem(eframework=efr, auto_worker=True)

    @events.listen("event1")
    def handler1(data):
        return {"result": data}

    @events.listen("event2")
    def handler2(data):
        return {"result": data}

    efr.start()

    # Should have 2 auto workers (one per station)
    auto_worker_count = sum(1 for w in efr._workers if w.auto_managed)
    assert auto_worker_count == 2, f"Should have 2 auto workers, got {auto_worker_count}"

    # Push events and verify they are processed
    results = []

    @events.listen("test_event")
    def collect(data):
        results.append(data)

    events.pushEvent("test_event", "hello")
    time.sleep(0.3)

    # Now should have 3 auto workers
    auto_worker_count = sum(1 for w in efr._workers if w.auto_managed)
    assert auto_worker_count == 3, f"Should have 3 auto workers, got {auto_worker_count}"

    events.stop()
    efr.quit()
    print("[PASS] EventSystem auto_worker=True creates per-station workers")


def test_eventsystem_cancel_listen_releases_worker():
    """Test that canceling a listener releases the auto worker."""
    print("\n[Test] cancelListen releases auto worker...")
    efr = EventFramework(name="test_cancel_release")

    events = EventSystem(eframework=efr, auto_worker=True)

    @events.listen("temp_event")
    def handler(data):
        return {"result": data}

    efr.start()

    # Should have 1 auto worker
    auto_worker_count = sum(1 for w in efr._workers if w.auto_managed)
    assert auto_worker_count == 1, f"Should have 1 auto worker, got {auto_worker_count}"

    # Cancel listen
    events.cancelListen("temp_event")
    time.sleep(0.1)

    # Auto worker should be released
    auto_worker_count = sum(1 for w in efr._workers if w.auto_managed)
    assert auto_worker_count == 0, f"Auto worker should be released, got {auto_worker_count}"

    events.stop()
    efr.quit()
    print("[PASS] cancelListen releases auto worker")


def test_auto_task_count_limits():
    """Test auto_task_count is limited to [1, 10]."""
    print("\n[Test] auto_task_count limits...")

    # Default is 1
    efr = EventFramework(name="test_count_default")
    assert efr.auto_task_count == 1, "Default should be 1"
    efr.quit()

    # Setting within range
    efr = EventFramework(name="test_count_5", auto_task_count=5)
    assert efr.auto_task_count == 5, "Should be 5"
    efr.quit()

    # Setting below range clamps to 1
    efr = EventFramework(name="test_count_low", auto_task_count=0)
    assert efr.auto_task_count == 1, "Should clamp to 1"
    efr.quit()

    # Setting above range clamps to 10
    efr = EventFramework(name="test_count_high", auto_task_count=20)
    assert efr.auto_task_count == 10, "Should clamp to 10"
    efr.quit()

    # Dynamic setting
    efr = EventFramework(name="test_count_dynamic")
    efr.auto_task_count = 3
    assert efr.auto_task_count == 3, "Should be 3"
    efr.auto_task_count = -5
    assert efr.auto_task_count == 1, "Should clamp to 1"
    efr.auto_task_count = 100
    assert efr.auto_task_count == 10, "Should clamp to 10"
    efr.quit()

    print("[PASS] auto_task_count limits")


def test_auto_worker_pool_reuse():
    """Test that auto workers are reused when they have capacity."""
    print("\n[Test] auto worker pool reuse...")
    efr = EventFramework(name="test_pool", auto_task_count=3)

    def handler1(event):
        return {"status": "ok"}

    def handler2(event):
        return {"status": "ok"}

    def handler3(event):
        return {"status": "ok"}

    station1 = EventStation(key="station1", respond_fn=handler1)
    station2 = EventStation(key="station2", respond_fn=handler2)
    station3 = EventStation(key="station3", respond_fn=handler3)

    # Login all stations with auto worker
    efr.login(station1, True)
    efr.login(station2, True)
    efr.login(station3, True)

    # With auto_task_count=3 (cost limit=3) and default station cost=1,
    # all 3 stations (3*1=3) should share 1 worker
    auto_workers = [w for w in efr._workers if w.auto_managed]
    assert len(auto_workers) == 1, f"Should have 1 auto worker, got {len(auto_workers)}"

    # Check that all stations are assigned to the same worker
    assert station1._worker is auto_workers[0], "station1 should use auto worker"
    assert station2._worker is auto_workers[0], "station2 should use same auto worker"
    assert station3._worker is auto_workers[0], "station3 should use same auto worker"

    efr.quit()
    print("[PASS] auto worker pool reuse")


def test_auto_worker_creates_new_when_full():
    """Test that new auto worker is created when existing ones are full."""
    print("\n[Test] auto worker creates new when full...")
    efr = EventFramework(name="test_full", auto_task_count=2)

    def handler(event):
        return {"status": "ok"}

    station1 = EventStation(key="station1", respond_fn=handler)
    station2 = EventStation(key="station2", respond_fn=handler)
    station3 = EventStation(key="station3", respond_fn=handler)

    # Login 3 stations with auto_task_count=2 (cost limit=2) and default cost=1
    efr.login(station1, True)
    efr.login(station2, True)
    efr.login(station3, True)

    # Should have 2 auto workers (first has 2 cost, second has 1 cost)
    auto_workers = [w for w in efr._workers if w.auto_managed]
    assert len(auto_workers) == 2, f"Should have 2 auto workers, got {len(auto_workers)}"

    efr.quit()
    print("[PASS] auto worker creates new when full")


def test_assign_with_default_true():
    """Test that assign defaults to True for auto worker allocation."""
    print("\n[Test] assign with default True...")
    efr = EventFramework(name="test_assign_default")

    def handler(event):
        return {"status": "ok"}

    station = EventStation(key="test_station", respond_fn=handler)

    # Login without worker
    efr.login(station)
    assert station._worker is None, "Station should have no worker"

    # Assign with default (True) should auto-allocate
    result = efr.assign(station)
    assert result, "Assign should succeed"
    assert station._worker is not None, "Station should have auto worker"
    assert station._worker.auto_managed, "Should be auto-managed worker"

    # Assign again should fail (already has worker)
    result = efr.assign(station)
    assert not result, "Assign should fail when station already has worker"

    efr.quit()
    print("[PASS] assign with default True")


def test_worker_auto_managed_property():
    """Test Worker auto_managed property."""
    print("\n[Test] Worker auto_managed property...")

    # Default worker is not auto-managed
    worker1 = Worker(name="normal")
    assert not worker1.auto_managed, "Default worker should not be auto-managed"

    # Worker with auto_managed=True
    worker2 = Worker(name="auto", auto_managed=True)
    assert worker2.auto_managed, "Worker should be auto-managed"

    print("[PASS] Worker auto_managed property")


def run_all_tests():
    """Run all auto worker tests."""
    tests = [
        ("Worker auto_managed property", test_worker_auto_managed_property),
        ("auto_task_count limits", test_auto_task_count_limits),
        ("auto worker pool reuse", test_auto_worker_pool_reuse),
        ("auto worker creates new when full", test_auto_worker_creates_new_when_full),
        ("assign with default True", test_assign_with_default_true),
        ("login(station, True) creates auto worker", test_login_with_true_creates_auto_worker),
        ("Auto worker released on logoff", test_auto_worker_released_on_logoff),
        ("Auto worker not released if has other tasks", test_auto_worker_not_released_if_has_other_tasks),
        ("assign no-op if station already has worker", test_assign_no_op_if_has_worker),
        ("Manual worker not auto-released", test_manual_worker_not_released),
        ("EventSystem auto_worker=True creates per-station workers", test_eventsystem_auto_worker),
        ("cancelListen releases auto worker", test_eventsystem_cancel_listen_releases_worker),
    ]

    passed = 0
    failed = 0

    print("=" * 60)
    print("Running Auto Worker Tests")
    print("=" * 60)

    for name, test_func in tests:
        try:
            test_func()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"[FAIL] {name}: {e}")
            import traceback
            traceback.print_exc()

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
