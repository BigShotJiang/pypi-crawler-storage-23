"""
Test EventFramework Module - Tests for EventFramework class.

测试事件框架模块 - EventFramework类的测试。
"""

import unittest
import time
import os
import tempfile
from efr.core.event import Event, EventState
from efr.core.estation import EventStation
from efr.core.eframework import EventFramework
from efr.utils.worker import Worker


class TestEventFramework(unittest.TestCase):
    """Test cases for EventFramework class."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.framework = EventFramework(name="test_framework")
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.framework.quit()
    
    def test_framework_creation(self) -> None:
        """Test basic framework creation."""
        self.assertIn("test_framework", self.framework.name)
        self.assertEqual(len(self.framework._workers), 1)  # Default worker
        self.assertEqual(len(self.framework.stations), 0)
    
    def test_start_stop(self) -> None:
        """Test framework start and stop."""
        self.framework.start()
        self.assertTrue(self.framework._start_flag)
        
        self.framework.quit()
        self.assertFalse(self.framework._start_flag)
    
    def test_add_remove_worker(self) -> None:
        """Test adding and removing workers."""
        worker = self.framework.add_worker("test_worker")
        self.assertIsNotNone(worker)
        self.assertEqual(len(self.framework._workers), 2)
        
        result = self.framework.remove_worker(worker)
        self.assertTrue(result)
        self.assertEqual(len(self.framework._workers), 1)
    
    def test_login_logoff_station(self) -> None:
        """Test station login and logoff."""
        station = EventStation(key="test_station")
        
        # Login
        result = self.framework.login(station)
        self.assertTrue(result)
        self.assertEqual(len(self.framework.stations), 1)
        
        # Logoff
        result = self.framework.logoff(station)
        self.assertTrue(result)
        self.assertEqual(len(self.framework.stations), 0)
    
    def test_push_event(self) -> None:
        """Test pushing events to framework."""
        event = Event(task="test_task", dest="test_dest")
        result = self.framework.push(event)
        
        self.assertIsNotNone(result)
        self.assertEqual(result.state, EventState.JUNIOR)
    
    def test_config(self) -> None:
        """Test framework configuration."""
        self.framework.config(step=10, timeout=5.0)
        
        self.assertEqual(self.framework._ealloter.step, 10)
        self.assertEqual(self.framework._ealloter.timeout, 5.0)
    
    def test_assign_worker(self) -> None:
        """Test assigning worker to station."""
        station = EventStation(key="test")
        worker = self.framework.add_worker("assigned_worker")

        # Login without worker assignment
        self.framework.login(station, worker=None)
        result = self.framework.assign(station, worker)

        self.assertTrue(result)
        self.assertEqual(station._worker, worker)
    
    def test_parallel_execution(self) -> None:
        """Test parallel task execution."""
        results = []
        
        def task():
            results.append(1)
        
        worker = EventFramework.parallel(task, count=1)
        time.sleep(0.2)
        
        self.assertEqual(len(results), 1)
        worker.stop()
    
    def test_logging(self) -> None:
        """Test logging functionality."""
        log_path = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.log') as f:
                log_path = f.name

            framework = EventFramework(name="log_test", log_path=log_path)
            framework._log("Test message")
            framework.quit()

            # Check log file
            with open(log_path, 'r') as f:
                content = f.read()
                self.assertIn("Test message", content)
        finally:
            if log_path and os.path.exists(log_path):
                try:
                    os.unlink(log_path)
                except PermissionError:
                    pass  # Windows may hold file handle

    # ========== Cost Mechanism Tests ==========

    def test_auto_worker_with_station_cost(self) -> None:
        """Test auto-worker uses station cost."""
        framework = EventFramework(name="cost_test", auto_task_count=10)
        station = EventStation(key="test", respond_fn=lambda e: None, cost=5)

        # Login with auto worker (should use station.cost=5)
        framework.login(station, worker=True)

        # Verify station was assigned
        self.assertIsNotNone(station._worker)

        # Check worker has the cost recorded
        self.assertEqual(station._worker.total_cost(), 5)

    def test_auto_worker_with_custom_int_cost(self) -> None:
        """Test auto-worker with custom int cost."""
        framework = EventFramework(name="cost_test2", auto_task_count=10)
        station = EventStation(key="test", respond_fn=lambda e: None, cost=3)

        # Login with int=7 (should override station.cost=3)
        framework.login(station, worker=7)

        # Verify station was assigned
        self.assertIsNotNone(station._worker)

        # Check worker uses the int cost (7) not station cost (3)
        self.assertEqual(station._worker.total_cost(), 7)

    def test_auto_worker_cost_capacity_check(self) -> None:
        """Test auto-worker capacity check based on total_cost."""
        framework = EventFramework(name="capacity_test", auto_task_count=5)

        station1 = EventStation(key="station1", respond_fn=lambda e: None, cost=3)
        station2 = EventStation(key="station2", respond_fn=lambda e: None, cost=3)

        # First station should be assigned to new worker
        framework.login(station1, worker=True)
        worker1 = station1._worker
        self.assertEqual(worker1.total_cost(), 3)

        # Second station: check if worker.total_cost (3) < auto_task_count (5)
        # 3 < 5 is True, so should be assigned to same worker
        # Note: cost is checked BEFORE adding, not after
        framework.login(station2, worker=True)
        worker2 = station2._worker

        # Should be same worker (checked before adding: 3 < 5)
        self.assertIs(worker1, worker2)
        # Total cost is now 6 (3+3), exceeding auto_task_count of 5
        self.assertEqual(worker1.total_cost(), 6)

    def test_auto_task_count_sync_to_workers(self) -> None:
        """Test auto_task_count syncs to all auto-managed workers."""
        framework = EventFramework(name="sync_test", auto_task_count=5)

        station = EventStation(key="test", respond_fn=lambda e: None)
        framework.login(station, worker=True)

        auto_worker = list(framework._auto_worker_pool)[0]
        self.assertEqual(auto_worker.auto_task_count, 5)

        # Change framework auto_task_count
        framework.auto_task_count = 8

        # Should sync to worker
        self.assertEqual(auto_worker.auto_task_count, 8)

    def test_auto_worker_cost_bounds(self) -> None:
        """Test int cost is bounded to >= 1."""
        framework = EventFramework(name="bounds_test", auto_task_count=10)
        station = EventStation(key="test", respond_fn=lambda e: None)

        # Login with negative int (should become 1)
        framework.login(station, worker=-5)

        self.assertEqual(station._worker.total_cost(), 1)


if __name__ == '__main__':
    unittest.main()
