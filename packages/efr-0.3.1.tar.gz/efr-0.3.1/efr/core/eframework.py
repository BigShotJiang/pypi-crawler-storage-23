"""
Event Framework Module - Main framework integrating all components.

事件框架模块 - 整合所有组件的主框架。
"""

from __future__ import annotations

import time
from math import inf
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union

from loguru import logger

from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.ealloter import EventAlloter
from efr.utils.task import Task, ONCE, CIRCLE
from efr.utils.worker import Worker


T = TypeVar('T')
R = TypeVar('R')


class _ParamNone:
    """Sentinel class for distinguishing None from unset parameter."""
    pass


PARAM_NONE = _ParamNone()


class EventFramework:
    """
    Main event-driven framework integrating all components.
    
    主事件驱动框架，整合所有组件。
    
    The framework provides:
    - Event queue management
    - Station registration and management
    - Worker thread pool
    - Event distribution and processing
    - Logging support
    
    Example:
        >>> efr = EventFramework(name="my_app")
        >>> station = EventStation(key="processor", respond_fn=process_event)
        >>> efr.login(station)
        >>> efr.push(Event(task="data", dest="processor"))
        >>> efr.start()
        >>> time.sleep(10)
        >>> efr.quit()
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        capacity: Optional[int] = None,
        step: Optional[int] = None,
        timeout: Optional[float] = None,
        timedt: float = 0.1,
        log_path: Optional[str] = None,
        log_level: str = "INFO",
        log_immediate: bool = True,
        log_format: Optional[str] = None,
        auto_task_count: int = 1
    ) -> None:
        """
        Initialize the event framework.

        Args:
            name: Framework name (None = auto-generated)
            capacity: Event queue capacity (None = unlimited)
            step: Events to process per update (None = unlimited)
            timeout: Event retrieval timeout (None = infinite)
            timedt: Worker loop interval in seconds
            log_path: Log file path (None = no logging)
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_immediate: Write logs immediately vs batch
            log_format: Log message format (None = use default)
            auto_task_count: Max cost per auto worker (1-10)
        """
        from efr.utils.id_generator import NewRandomID
        
        self.name: str = name or f"efr_{NewRandomID(8)}"
        self.timedt: float = timedt
        self.log_path: Optional[str] = log_path
        self.log_level: str = log_level.upper()
        self.log_immediate: bool = log_immediate
        
        self._start_flag: bool = False
        self._worker_id: int = 0
        self._quit_logs: List[Any] = []
        
        # Initialize logger
        self._logger = logger.bind(framework=self.name)
        self._init_logger(log_format)
        
        # Create components
        self._equeue: EventQueue = EventQueue(capacity=capacity or 0)
        self._ealloter: EventAlloter = EventAlloter(self._equeue, step, timeout)
        
        # Link components to framework
        self._equeue.efr = self
        self._ealloter.efr = self
        
        # Workers
        self._workers: List[Worker] = []
        self._auto_workers: Dict[str, Worker] = {}  # station_key -> auto_worker mapping
        self._auto_worker_pool: List[Worker] = []  # pool of auto workers for reuse
        self._auto_task_count: int = max(1, min(10, auto_task_count))  # clamp to [1, 10]
        self._default_worker: Worker = self.add_worker('default_worker')
        self._default_worker.add_task(Task(self.update, times=CIRCLE))
    
    def _init_logger(self, log_format: Optional[str] = None) -> None:
        """Initialize logging configuration with loguru."""
        # Remove existing handlers for this framework
        self._logger = logger.bind(framework=self.name)
        
        if self.log_path:
            # Clear log file
            open(self.log_path, 'w').close()
            
            # Add file handler with loguru
            fmt = log_format or "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
            logger.add(
                self.log_path,
                level=self.log_level,
                format=fmt,
                filter=lambda record: record["extra"].get("framework") == self.name,
                enqueue=True
            )
    
    def _log(self, item: Any, level: str = "INFO") -> None:
        """Log an item immediately or queue for batch logging."""
        if self.log_path or self.log_immediate:
            if isinstance(item, Exception):
                self._logger.exception(item)
            elif isinstance(item, Warning):
                self._logger.warning(str(item))
            else:
                self._logger.log(level, str(item))
        else:
            self._quit_logs.append((item, level))
    
    def _output_logs(self) -> None:
        """Output all queued logs."""
        for log, level in self._quit_logs:
            if isinstance(log, Exception):
                self._logger.exception(log)
            elif isinstance(log, Warning):
                self._logger.warning(str(log))
            else:
                self._logger.log(level, str(log))
        self._quit_logs.clear()
    
    def _new_worker(self, name: Optional[str] = None, timedt: Optional[float] = None) -> Worker:
        """Create a new worker instance."""
        self._worker_id += 1
        worker_name = name or f"worker_{self._worker_id - 1}_of_{self.name}"
        worker = Worker(name=worker_name, mindt=timedt or self.timedt)
        if self._start_flag:
            worker.start()
        return worker
    
    @property
    def stations(self) -> List[EventStation]:
        """Get all registered stations."""
        return self._ealloter.stations

    @property
    def auto_task_count(self) -> int:
        """Get or set max cost per auto worker (1-10)."""
        return self._auto_task_count

    @auto_task_count.setter
    def auto_task_count(self, value: int) -> None:
        """Set max cost per auto worker, clamped to [1, 10].

        Also synchronizes the value to all auto-managed workers.
        """
        self._auto_task_count = max(1, min(10, value))
        # Sync to all auto-managed workers
        for worker in self._auto_worker_pool:
            if worker.auto_managed:
                worker.auto_task_count = self._auto_task_count
    
    def start(self) -> None:
        """Start the event framework and all workers."""
        self._log(f"{self.name} starting...")
        self._start_flag = True
        for worker in self._workers:
            if not worker.is_alive():
                worker.start()
        self._log(f"{self.name} started")
    
    def quit(self) -> None:
        """Stop the event framework and all workers."""
        self._log(f"{self.name} quitting...")
        self._start_flag = False
        for worker in self._workers:
            worker.stop()
        self._output_logs()
        self._log(f"{self.name} quit")
    
    def login(self, station: EventStation, worker: Union[Worker, bool, int] = True) -> bool:
        """
        Register a station with the framework.

        Args:
            station: The station to register
            worker: Worker to assign for processing. Can be:
                   - Worker instance: use that worker
                   - True: auto-create and assign a worker, use station.cost
                   - int (>=1): auto-create and assign, use this int as cost
                   - None: don't assign any worker

        Returns:
            True if registered successfully
        """
        result = self._ealloter.login(station)
        if result and worker is not None:
            if worker is True:
                # Auto mode: use station's cost
                auto_worker = self._find_or_create_auto_worker(station, station.cost)
                if auto_worker:
                    self._auto_workers[station.key] = auto_worker
                    # Pass cost as int to assign
                    self.assign(station, station.cost)
            elif isinstance(worker, int):
                # Auto mode with custom cost: validate int >= 1
                cost = max(1, worker)
                auto_worker = self._find_or_create_auto_worker(station, cost)
                if auto_worker:
                    self._auto_workers[station.key] = auto_worker
                    # Pass cost as int to assign
                    self.assign(station, cost)
            else:
                # Use provided worker instance
                self.assign(station, worker)
        return result

    def _find_or_create_auto_worker(self, station: EventStation, cost: int = 1) -> Optional[Worker]:
        """Find an existing auto worker with capacity or create a new one.

        Args:
            station: The station to assign
            cost: The cost value to use for capacity checking (not station.cost)

        Returns:
            An auto-managed worker with available capacity, or a new one
        """
        # Look for existing auto worker with capacity (using total_cost)
        for worker in self._auto_worker_pool:
            if worker.auto_managed and worker.total_cost() < worker.auto_task_count:
                return worker

        # Create new auto worker
        worker_name = f"auto_{len(self._auto_worker_pool)}_of_{self.name}"
        auto_worker = self.add_worker(worker_name, timedt=self.timedt)
        auto_worker.auto_managed = True
        auto_worker.auto_task_count = self._auto_task_count
        self._auto_worker_pool.append(auto_worker)
        return auto_worker

    def logoff(self, station: EventStation) -> bool:
        """
        Unregister a station from the framework.

        Args:
            station: The station to unregister

        Returns:
            True if unregistered
        """
        # Check if station has an auto-managed worker before unassigning
        old_worker = station._worker
        is_auto_managed = old_worker and old_worker.auto_managed

        result = self._ealloter.logoff(station)
        if result:
            self.assign(station, None)
            # Remove from auto_workers mapping
            if station.key in self._auto_workers:
                del self._auto_workers[station.key]
            # Check if auto-worker should be released
            if is_auto_managed and old_worker:
                self._maybe_release_auto_worker(old_worker)
        return result

    def _maybe_release_auto_worker(self, worker: Worker) -> None:
        """
        Release an auto-managed worker if it has no tasks.

        Args:
            worker: The worker to check and potentially release
        """
        if not worker.auto_managed:
            return
        if not worker.has_tasks():
            self.remove_worker(worker)

    def push(self, event: Event[T, R], timeout: Optional[float] = None) -> Optional[Event[T, R]]:
        """
        Push an event into the framework.
        
        Args:
            event: The event to push
            timeout: Maximum time to wait if queue is full
            
        Returns:
            The event if successful, None if failed
        """
        return self._equeue.push(event, timeout)
    
    def config(
        self,
        step: Union[int, _ParamNone] = PARAM_NONE,
        timeout: Union[float, _ParamNone] = PARAM_NONE,
        log_path: Union[str, _ParamNone] = PARAM_NONE,
        log_immediate: Union[bool, _ParamNone] = PARAM_NONE,
        log_format: Union[str, _ParamNone] = PARAM_NONE,
        log_level: Union[str, _ParamNone] = PARAM_NONE
    ) -> None:
        """
        Configure framework parameters.
        
        Args:
            step: Events to process per update
            timeout: Event retrieval timeout
            log_path: Log file path
            log_immediate: Write logs immediately
            log_format: Log message format
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        """
        if not isinstance(step, _ParamNone):
            self._ealloter.step = step
        if not isinstance(timeout, _ParamNone):
            self._ealloter.timeout = timeout
        if not isinstance(log_path, _ParamNone):
            self.log_path = log_path
            self._init_logger()
        if not isinstance(log_immediate, _ParamNone):
            if not self.log_immediate and log_immediate:
                self._output_logs()
            self.log_immediate = log_immediate
        if not isinstance(log_format, _ParamNone):
            self.log_format = log_format
            self._init_logger()
        if not isinstance(log_level, _ParamNone):
            self.log_level = log_level.upper()
            self._init_logger()
    
    def assign(
        self,
        station: EventStation,
        worker: Union[Worker, bool, int, None] = True
    ) -> bool:
        """
        Assign a worker to a station.

        Args:
            station: The station to assign to
            worker: The worker to assign. Can be:
                   - Worker instance: use that worker
                   - True: auto-create and assign a worker, use station.cost (default)
                   - int (>=1): auto-create and assign, use this int as cost
                   - None: unassign current worker

        Returns:
            True if assignment successful, False if station already has a worker
        """
        if worker is None:
            # Unassign worker - always allow unassignment
            old_worker = station._worker
            is_auto_managed = old_worker and old_worker.auto_managed
            if old_worker:
                old_worker.remove_task(station._task)
                station._worker = None
                station._task = None
                # Check if auto-worker should be released
                if is_auto_managed:
                    self._maybe_release_auto_worker(old_worker)
            return True

        # If station already has a worker, don't do anything (for assignment only)
        if station._worker is not None:
            return False

        # Determine cost and get/create worker
        cost = station.cost
        actual_worker: Optional[Worker] = None

        if worker is True:
            # Auto mode: use station's cost
            actual_worker = self._find_or_create_auto_worker(station, cost)
            if actual_worker is None:
                return False
            self._auto_workers[station.key] = actual_worker
        elif isinstance(worker, int):
            # Auto mode with custom cost: validate int >= 1
            cost = max(1, worker)
            actual_worker = self._find_or_create_auto_worker(station, cost)
            if actual_worker is None:
                return False
            self._auto_workers[station.key] = actual_worker
        else:
            # Use provided worker instance
            actual_worker = worker

        # Assign worker
        if station not in self._ealloter.stations:
            self.login(station)
        station._worker = actual_worker
        station._task = Task(station.update, times=CIRCLE)
        # Pass cost to add_task (only used in auto mode)
        return actual_worker.add_task(station._task, cost)
    
    def add_worker(self, name: Optional[str] = None, timedt: Optional[float] = None) -> Worker:
        """
        Add a new worker to the framework.
        
        Args:
            name: Worker name
            timedt: Worker loop interval
            
        Returns:
            The created worker
        """
        worker = self._new_worker(name, timedt)
        self._workers.append(worker)
        return worker
    
    def remove_worker(self, worker: Worker) -> bool:
        """
        Remove a worker from the framework.
        
        Args:
            worker: The worker to remove
            
        Returns:
            True if removed
        """
        try:
            self._workers.remove(worker)
            worker.stop()
            return True
        except ValueError:
            return False
    
    def update(self) -> None:
        """Update the framework - process events."""
        self._ealloter.update()
    
    @staticmethod
    def parallel(
        task: Union[Task, Callable],
        *fn_args: Any,
        delta: float = 0.5,
        count: int = 1,
        **fn_kwgs: Any
    ) -> Worker:
        """
        Execute a task in parallel using a temporary worker.
        
        Args:
            task: Task or callable to execute
            fn_args: Arguments for callable
            delta: Worker interval
            count: Execution count (for callables)
            fn_kwgs: Keyword arguments for callable
            
        Returns:
            The worker executing the task
        """
        worker = Worker(mindt=delta, always=False)
        
        if isinstance(task, Task):
            worker.add_task(task)
        else:
            t = Task(task, fn_args, fn_kwgs, times=count)
            worker.add_task(t)
        
        worker.start()
        return worker
    
    def __str__(self) -> str:
        return f"EventFramework[{self.name}](workers={len(self._workers)}, stations={len(self.stations)})"
    
    def __repr__(self) -> str:
        return self.__str__()


# Convenience alias
Parallel = EventFramework.parallel
