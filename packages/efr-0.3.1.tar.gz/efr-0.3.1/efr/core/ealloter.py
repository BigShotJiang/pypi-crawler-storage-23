"""
Event Alloter Module - Event allocator for distributing events to stations.

事件分配器模块 - 将事件分发到各个站点。
"""

from __future__ import annotations

import traceback
from typing import Any, List, Optional

from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.eerrors import SolutionMissing


class EventAlloter:
    """
    Event allocator that distributes events to registered stations.
    
    事件分配器，将事件分发到已注册的站点。
    
    When update() is called, the alloter:
    1. Retrieves events from the event queue
    2. Iterates through registered stations (sorted by priority)
    3. For each event, calls station.filter() to check interest
    4. If interested, pushes event to station's queue
    
    Attributes:
        equeue: The source event queue
        step: Max events to process per update
        timeout: Timeout for event retrieval
    """
    
    def __init__(
        self,
        equeue: EventQueue,
        step: Optional[int] = None,
        timeout: Optional[float] = None
    ) -> None:
        """
        Initialize the event alloter.
        
        Args:
            equeue: The source event queue
            step: Max events to process per update (None = unlimited)
            timeout: Timeout for event retrieval (None = infinite)
        """
        self._efr: Any = None
        self._equeue: EventQueue = equeue
        self.step: Optional[int] = step
        self.timeout: Optional[float] = timeout
        
        # Stations sorted by level (higher first)
        self._stations: List[EventStation] = []
    
    @property
    def efr(self) -> Any:
        """Get the associated EventFramework."""
        return self._efr
    
    @efr.setter
    def efr(self, value: Any) -> None:
        """Set the associated EventFramework."""
        self._efr = value
    
    @property
    def stations(self) -> List[EventStation]:
        """Get list of registered stations."""
        return self._stations.copy()
    
    def login(self, station: EventStation) -> bool:
        """
        Register a station with the alloter.
        
        Stations are sorted by level (higher = earlier in list).
        
        Args:
            station: The station to register
            
        Returns:
            True if registered successfully, False if already registered
        """
        if station in self._stations:
            return False
        
        station.efr = self._efr
        
        # Insert in priority order (higher level first)
        inserted = False
        for i, s in enumerate(self._stations):
            if station.level > s.level:
                self._stations.insert(i, station)
                inserted = True
                break
        
        if not inserted:
            self._stations.append(station)
        
        return True
    
    def logoff(self, station: EventStation) -> bool:
        """
        Unregister a station.
        
        Args:
            station: The station to unregister
            
        Returns:
            True if unregistered or not found, False on error
        """
        try:
            station.efr = None
            if station in self._stations:
                self._stations.remove(station)
            return True
        except Exception:
            return False
    
    def update(self) -> None:
        """
        Process events from queue and distribute to stations.
        Called by framework's update loop.
        """
        events = self._equeue.release(self.step, self.timeout)
        
        for event in events:
            processed = False
            
            for station in self._stations:
                # Check if station wants this event
                try:
                    interested = station.filter(event)
                except Exception as err:
                    event.set_state(EventState.EXCEPT)
                    err.trace = traceback.format_exc()  # type: ignore
                    if self._efr and hasattr(self._efr, '_log'):
                        self._efr._log(f"Filter error at {station.key}: {err}")
                    continue
                
                # Push to station if interested
                if interested:
                    if station.push(event):
                        processed = True
                        event.times_left -= 1
                        if event.times_left <= 0:
                            break
            
            # Mark as exception if no station processed it
            if not processed:
                event.set_state(EventState.EXCEPT)
                # Create exception for trace
                try:
                    raise SolutionMissing(event)
                except SolutionMissing as err:
                    err.trace = traceback.format_exc()  # type: ignore
                    if self._efr and hasattr(self._efr, '_log'):
                        self._efr._log(f"Event {event.trace} refused by all stations")
    
    def __str__(self) -> str:
        return f"EventAlloter(stations={len(self._stations)}, step={self.step})"
    
    def __repr__(self) -> str:
        return self.__str__()
