from efr import EventFramework, EventSystem, Event
import time

# 创建框架
efr = EventFramework(name="hybrid")

# 消费者：通过EventSystem监听（auto_worker=True 自动分配工作线程）
events = EventSystem(eframework=efr)

@events.listen("job_queue")
def consumer(data):
    job_id = data["job_id"]
    print(f"[Consumer] Processing job {job_id}")
    return {"job_id": job_id, "status": "completed"}

# 生产者：直接通过Event推送事件
for i in range(5):
    event = Event(
        task={"job_id": i, "data": f"payload_{i}"},
        dest="job_queue",
        priority=5
    )
    efr.push(event)
    time.sleep(0.1)

# 启动并运行
efr.start()
time.sleep(1)  # 等待处理完成
events.stop()
efr.quit()