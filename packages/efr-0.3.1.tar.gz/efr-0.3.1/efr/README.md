# efr - Event Framework

Python事件驱动框架，用于构建可扩展的异步应用。

## 安装

```bash
pip install efr
```

## 核心概念

- **Event**: 事件单元，包含任务数据、状态、优先级等
- **EventQueue**: 线程安全的事件队列
- **EventStation**: 事件处理站点，负责过滤和处理特定事件
- **EventFramework**: 主框架，整合队列、站点和工作线程
- **EventSystem**: 嵌入式事件系统，支持独立模式或框架集成
- **Cost**: 站点/任务负载强度，用于自动worker负载均衡（默认=1）

## 快速开始

### 方式1: 使用 EventSystem（推荐，简单事件）

```python
from efr import EventSystem

events = EventSystem()

# 消费者：监听任务
@events.listen("task_queue")
def consumer(data):
    task_id = data["task_id"]
    print(f"[Consumer] Processing task {task_id}")
    return {"result": "success", "task_id": task_id}

# 生产者：推送任务
for i in range(5):
    events.pushEvent("task_queue", {"task_id": i, "payload": f"data_{i}"})

events.stop()
```

### 方式2: 使用 EventFramework（多线程）

```python
from efr import EventFramework, Event, EventStation
import time

# 创建框架（auto_task_count=3 表示每个自动worker最多承载3个单位的负载）
efr = EventFramework(name="producer_consumer", auto_task_count=3)

# 消费者：定义处理函数
def consumer(event):
    task = event.task
    print(f"[Consumer] Processing task {task['id']}")
    return {"status": "done", "id": task["id"]}

# 创建消费者站点并自动分配工作线程
station = EventStation(key="task_queue", respond_fn=consumer)
efr.login(station, True)  # True = 自动创建worker

# 启动框架
efr.start()

# 生产者：推送任务
for i in range(5):
    event = Event(task={"id": i}, dest="task_queue")
    efr.push(event)
    time.sleep(0.1)

time.sleep(1)  # 等待处理完成
efr.quit()
```

### 方式3: Embed消费 + Estation生产（组合使用）

```python
from efr import EventFramework, EventSystem, Event
import time

# 创建框架
efr = EventFramework(name="hybrid")

# 消费者：通过EventSystem监听（auto_worker=True 自动分配工作线程）
events = EventSystem(eframework=efr)

@events.listen("job_queue")
def consumer(data):
    job_id = data["job_id"]
    print(f"[Consumer] Processing job {job_id}")
    return {"job_id": job_id, "status": "completed"}

# 生产者：直接通过Event推送事件
for i in range(5):
    event = Event(
        task={"job_id": i, "data": f"payload_{i}"},
        dest="job_queue",
        priority=5
    )
    efr.push(event)
    time.sleep(0.1)

# 启动并运行
efr.start()
time.sleep(1)  # 等待处理完成
events.stop()
efr.quit()
```

## 事件状态

- `OFFLINE`: 已创建，未入队
- `JUNIOR`: 在队列中等待
- `URGENT`: 正在被处理
- `FINISH`: 已成功处理
- `RETIRED`: 已被所有站点处理
- `EXCEPT`: 处理异常

## 高级功能

### 带优先级的事件系统

```python
from efr import PrioritizedEventSystem

events = PrioritizedEventSystem()

# 高优先级消费者先处理
@events.listen("task_queue", priority=10)
def urgent_consumer(data):
    print(f"[Urgent] Processing high priority task {data['task_id']}")

# 低优先级消费者后处理
@events.listen("task_queue", priority=1)
def normal_consumer(data):
    print(f"[Normal] Processing normal task {data['task_id']}")

# 生产者推送任务
events.pushEvent("task_queue", {"task_id": 1})
```

### 源过滤

```python
# 只接收来自 "payment_service" 源的任务
@events.listen("task_queue", "payment_service")
def payment_consumer(data):
    print(f"[Payment] Processing: {data}")

# 推送时指定源
events.pushEvent("task_queue", {
    "source": "payment_service",
    "amount": 100
})
```

### 动态框架切换

```python
from efr import EventFramework, EventSystem

# 独立模式（单线程）
events = EventSystem()

# 后期附加到框架（转为多线程）
efr = EventFramework()
events.eframework = efr
efr.start()

# 现在推送的事件会走框架队列
events.pushEvent("task_queue", {"task_id": 1})

# 分离回独立模式
del events.eframework
```

## API参考

### EventFramework

| 方法/属性 | 说明                                                                         |
|-----------|----------------------------------------------------------------------------|
| `__init__(..., auto_task_count=1)` | 初始化，`auto_task_count`设置每个自动worker的负载(cost)上限[1,10]                         |
| `start()` | 启动框架和工作线程                                                                  |
| `quit()` | 停止框架                                                                       |
| `push(event)` | 推送事件到队列                                                                    |
| `login(station, worker=True)` | 注册站点，`worker`可为`True`（自动，使用station.cost）、`int`（使用指定cost）、`Worker`实例或`None` |
| `logoff(station)` | 注销站点                                                                       |
| `add_worker(name)` | 添加工作线程（手动创建，不会被自动释放）                                                       |
| `assign(station, worker=True)` | 分配worker，`worker`可为`True`（自动）、`int`（指定cost）、`Worker`实例或`None`（取消分配）        |
| `auto_task_count` | 获取/设置自动worker的cost上限，修改后同步到所有自动worker                                      |

### EventSystem

| 方法 | 说明 |
|------|------|
| `__init__(eframework=None, auto_worker=True)` | 初始化，`auto_worker`控制是否自动分配worker及是否使用cost机制 |
| `listenFor(event, callback, *sources)` | 注册监听器 |
| `listen(event, *sources)` | 装饰器方式注册 |
| `pushEvent(event, data, *targets)` | 推送事件 |
| `cancelListen(event, callback)` | 取消监听 |
| `hasListeners(event)` | 检查是否有监听器 |
| `clear()` | 清除所有监听器 |
| `stop()` | 停止并清理 |

**属性**

| 属性 | 说明 |
|------|------|
| `eframework` | 获取/设置关联的框架。设为None等价于删除。切换时会自动清理旧框架的worker绑定 |

### Worker 负载管理（Cost 机制）

框架通过 **cost** 机制实现基于负载强度的自动工作线程分配。

**基本概念**

- **Station Cost**: 每个 EventStation 的负载强度（默认=1）
- **Task Cost**: 分配给 Worker 的每个任务的负载值（默认=1）
- **Worker Capacity**: `auto_task_count` 定义 Worker 的负载上限（1-10，默认=1）

**分配规则**

当自动分配 Worker 时（`login(station, True)` 或 `login(station, int)`）：
1. 检查现有自动 Worker 的 `total_cost()` 是否 `< auto_task_count`
2. 如果有容量，分配给该 Worker
3. 如果无容量，创建新的自动 Worker

```python
# 创建框架（每个自动worker的cost上限为5）
efr = EventFramework(name="app", auto_task_count=5)

# 创建站点并指定cost（负载强度）
# 高负载站点（cost=3）
heavy_station = EventStation(key="heavy", respond_fn=process_heavy, cost=3)
efr.login(heavy_station, True)  # 占用3/5的capacity

# 低负载站点（cost=1，默认）
light_station = EventStation(key="light", respond_fn=process_light, cost=1)
efr.login(light_station, True)  # 可与heavy_station共用同一个worker（3+1=4 < 5）

# 使用自定义int覆盖station的cost
# 这将使用cost=4而不是station.cost=3
efr.login(heavy_station, worker=4)  # 强制使用cost=4
```

**类级默认 Cost**

通过类属性 `COST` 设置子类的默认 cost：

```python
# 定义高负载站点类型
class HeavyStation(EventStation):
    COST = 5  # 类级默认cost

# 自动使用类级cost
station = HeavyStation(key="heavy")  # cost = 5

# 实例级覆盖
station2 = HeavyStation(key="medium", cost=3)  # cost = 3

# 运行时修改类级默认值
EventStation.COST = 2  # 影响所有新创建的实例
```

**手动分配 Worker**

手动创建的 Worker 不受 cost 限制，也不会被自动释放：

```python
# 手动创建worker（不会被自动释放）
manual_worker = efr.add_worker("manual")
efr.login(station, manual_worker)  # 不使用cost机制

# 仅注册站点，不分配worker
efr.login(station, None)

# 取消worker分配，释放auto worker
efr.assign(station, None)
```

**动态调整负载上限**

修改 `auto_task_count` 会同步到所有自动管理的 Worker：

```python
# 初始上限为3
efr = EventFramework(auto_task_count=3)
efr.login(station1, True)  # 分配给worker_0

# 调整为5，所有自动worker同步更新
efr.auto_task_count = 5  # worker_0.auto_task_count 也变为5
```

**API 行为总结**

| 方法 | 行为 |
|------|------|
| `login(station, True)` | 自动分配，使用 `station.cost` |
| `login(station, int)` | 自动分配，使用指定的 int 作为 cost（覆盖 station.cost） |
| `login(station, worker)` | 使用指定 Worker，忽略 cost 机制 |
| `login(station, None)` | 仅注册站点，不分配 Worker |
| `assign(station, True)` | 同 `login(station, True)` |
| `assign(station, int)` | 同 `login(station, int)` |
| `assign(station, None)` | 取消分配，释放 auto worker |

### EventStation

| 方法/属性 | 说明 |
|-----------|------|
| `__init__(..., cost=None)` | 初始化站点，`cost=None`时使用类属性`COST` |
| `cost` | 获取/设置站点的负载强度（最小值为1） |
| `COST` (类属性) | 类级默认cost，所有实例默认使用此值 |
| `key` | 站点标识符 |
| `level` | 优先级（越高越优先处理） |
| `filter(event)` | 过滤事件 |
| `respond(event)` | 处理事件 |

```python
# 使用类级默认cost
class HeavyStation(EventStation):
    COST = 5

station = HeavyStation(key="heavy")  # cost = 5
```

### Worker

| 方法/属性 | 说明 |
|-----------|------|
| `__init__(..., auto_managed=False, auto_task_count=1)` | 初始化worker |
| `add_task(task, cost=1)` | 添加任务，`cost`仅在auto_managed模式下追踪 |
| `total_cost()` | 获取所有任务的cost总和（仅auto_managed模式） |
| `auto_task_count` | 获取/设置cost上限[1,10] |
| `auto_managed` | 是否为自动管理（无任务时自动释放） |

### PrioritizedEventSystem

与 EventSystem 相同，额外支持 `priority` 参数：

```python
@events.listen("event", priority=10)  # priority越高越早处理
def handler(data):
    pass
```

## 项目结构

```
efr/
├── core/           # 核心组件
│   ├── event.py    # Event类
│   ├── equeue.py   # 事件队列
│   ├── estation.py # 处理站点
│   ├── ealloter.py # 事件分配器
│   ├── eframework.py # 主框架
│   └── eerrors.py  # 异常类
├── embed/          # 嵌入式事件系统
│   └── api.py      # EventSystem
├── utils/          # 工具类
│   ├── worker.py   # 工作线程
│   └── task.py     # 任务单元
└── doc/examples/   # 示例代码
```

## 依赖

- Python >= 3.10
- loguru >= 0.7.0

