"""
ID Generator Module - Random ID generation utilities.

ID生成器模块 - 随机ID生成工具。
"""

from __future__ import annotations

from random import randint
from typing import List


# Lookup table for 10^n - 1
_SEARCH_MAX = 32
_search_table: List[int] = [10 * 10**i - 1 for i in range(_SEARCH_MAX)]


def NewRandom(ulen: int = 16) -> int:
    """
    Generate a random integer with specified digit length.
    
    生成指定位数的随机整数。
    
    Args:
        ulen: Number of digits (1-32)
        
    Returns:
        Random integer
        
    Raises:
        ValueError: If ulen is out of range
        
    Example:
        >>> NewRandom(8)
        12345678
    """
    if not 0 < ulen <= _SEARCH_MAX:
        raise ValueError(f"ulen must be between 1 and {_SEARCH_MAX}")
    return randint(0, _search_table[ulen - 1])


def NewRandomID(ulen: int = 16) -> str:
    """
    Generate a random ID string with specified length.
    
    生成指定长度的随机ID字符串。
    
    Args:
        ulen: Length of ID (1-32)
        
    Returns:
        Random ID string with leading zeros
        
    Example:
        >>> NewRandomID(8)
        '01234567'
    """
    return f"{NewRandom(ulen):0>{ulen}d}"


class IDGenerator:
    """
    Configurable ID generator.
    
    可配置的ID生成器。
    
    Attributes:
        length: ID length
        prefix: Optional prefix for generated IDs
        suffix: Optional suffix for generated IDs
    """
    
    def __init__(self, length: int = 16, prefix: str = "", suffix: str = "") -> None:
        """
        Initialize ID generator.
        
        Args:
            length: ID length
            prefix: Optional prefix
            suffix: Optional suffix
        """
        self.length = length
        self.prefix = prefix
        self.suffix = suffix
    
    def generate(self) -> str:
        """Generate a new ID."""
        return f"{self.prefix}{NewRandomID(self.length)}{self.suffix}"
    
    def __call__(self) -> str:
        """Generate ID when called."""
        return self.generate()
