"""
Task Module - Executable task unit.

任务模块 - 可执行的任务单元。
"""

from __future__ import annotations

from math import inf
from typing import Any, Callable, Optional, Tuple, Dict


# Constants for task execution count
ONCE = 1
CIRCLE = inf


class Task:
    """
    Executable task unit.
    
    可执行的任务单元。
    
    A Task wraps a callable with its arguments and tracks execution count.
    Can be configured to execute once or infinitely (circular).
    
    Attributes:
        target: The callable to execute
        args: Positional arguments
        kwargs: Keyword arguments
        left: Remaining executions
    """
    
    ONCE = ONCE
    CIRCLE = CIRCLE
    
    def __init__(
        self,
        target: Callable[..., Any] = lambda: None,
        args: Tuple[Any, ...] = (),
        kwargs: Optional[Dict[str, Any]] = None,
        times: float = ONCE
    ) -> None:
        """
        Initialize the task.
        
        Args:
            target: The callable to execute
            args: Positional arguments
            kwargs: Keyword arguments
            times: Execution count (1 = once, inf = circular)
        """
        self.target: Callable[..., Any] = target
        self.args: Tuple[Any, ...] = args
        self.kwargs: Dict[str, Any] = kwargs or {}
        self.left: float = times
        self._total: float = times
    
    def __call__(self, *extra_args: Any, **extra_kwargs: Any) -> Any:
        """
        Execute the task.
        
        Args:
            extra_args: Additional positional arguments
            extra_kwargs: Additional keyword arguments
            
        Returns:
            Result of target execution
        """
        if self.left > 0:
            self.left -= 1
            # Merge args and kwargs
            merged_args = extra_args + self.args[len(extra_args):]
            merged_kwargs = {**self.kwargs, **extra_kwargs}
            return self.target(*merged_args, **merged_kwargs)
        return None
    
    def reset(self) -> None:
        """Reset execution count to initial value."""
        self.left = self._total
    
    def is_done(self) -> bool:
        """Check if task has completed all executions."""
        return self.left <= 0
    
    def is_circular(self) -> bool:
        """Check if task is circular (infinite executions)."""
        return self._total == CIRCLE
    
    def __str__(self) -> str:
        return f"Task[target={self.target.__name__}, left={self.left}]"
    
    def __repr__(self) -> str:
        return self.__str__()


# Stop task sentinel - used to signal worker stop
class _StopTask(Task):
    """Internal stop task sentinel."""
    def __init__(self) -> None:
        super().__init__(lambda: None, times=0)


STOPTASK = _StopTask()
