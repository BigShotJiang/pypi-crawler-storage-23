"""
Worker Module - Thread-based task executor.

工作线程模块 - 基于线程的任务执行器。
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional

from efr.utils.task import Task, STOPTASK


class Worker(threading.Thread):
    """
    Worker thread that executes tasks in a loop.

    工作线程，循环执行任务。

    The worker runs in a loop, executing all pending tasks each iteration.
    It can be configured to run continuously or stop when tasks are empty.

    Attributes:
        mindt: Minimum loop interval in seconds
        always: Whether to keep running when no tasks
        alive: Whether the worker should continue running
        auto_managed: Whether this worker is auto-managed (auto-released when no tasks)

    Example:
        >>> def work():
        ...     print("Working...")
        >>> worker = Worker(mindt=1.0)
        >>> worker.add_task(Task(work, times=Task.CIRCLE))
        >>> worker.start()
        >>> time.sleep(5)
        >>> worker.stop()
    """

    def __init__(
        self,
        name: Optional[str] = None,
        daemon: bool = True,
        mindt: float = 0.5,
        always: bool = True,
        auto_managed: bool = False,
        auto_task_count: int = 1
    ) -> None:
        """
        Initialize the worker.

        Args:
            name: Worker thread name
            daemon: Whether to run as daemon thread
            mindt: Minimum loop interval
            always: Keep running even when no tasks
            auto_managed: If True, worker is auto-managed and released when no tasks
            auto_task_count: Max cost per auto worker (for auto mode capacity check)
        """
        super().__init__(name=name, daemon=daemon)
        self.mindt: float = mindt
        self.always: bool = always
        self.auto_managed: bool = auto_managed
        self._auto_task_count: int = max(1, min(10, auto_task_count))
        self.alive: bool = True
        self._tasks: List[Task] = []
        self._task_costs: Dict[Task, int] = {}  # Track cost for each task (for auto mode)
        self._lock: threading.Lock = threading.Lock()

    @property
    def auto_task_count(self) -> int:
        """Get or set max cost per auto worker (1-10)."""
        return self._auto_task_count

    @auto_task_count.setter
    def auto_task_count(self, value: int) -> None:
        """Set max cost per auto worker, clamped to [1, 10]."""
        self._auto_task_count = max(1, min(10, value))

    def run(self) -> None:
        """Main worker loop."""
        while self.alive:
            next_time = time.time() + self.mindt
            
            # Execute all pending tasks
            with self._lock:
                tasks = self._tasks.copy()
            
            remaining: List[Task] = []
            for task in tasks:
                try:
                    task()
                except Exception as e:
                    # Log error but continue
                    print(f"Task error: {e}")
                
                if task.left > 0:
                    remaining.append(task)
                
                if not self.alive:
                    break
            
            with self._lock:
                self._tasks = remaining
            
            # Auto-stop if not always and no tasks
            if not self.always and not self._tasks:
                self.alive = False
                break
            
            # Sleep until next iteration
            sleep_time = next_time - time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
    
    def add_task(self, task: Task, cost: int = 1) -> bool:
        """
        Add a task to the worker.

        Args:
            task: The task to add
            cost: Load cost of this task (only used in auto mode, default=1)

        Returns:
            True if added successfully
        """
        with self._lock:
            self._tasks.append(task)
            if self.auto_managed:
                self._task_costs[task] = cost
        return True
    
    def remove_task(self, task: Task) -> bool:
        """
        Remove a task from the worker.

        Args:
            task: The task to remove

        Returns:
            True if removed
        """
        with self._lock:
            try:
                self._tasks.remove(task)
                self._task_costs.pop(task, None)
                return True
            except ValueError:
                return False
    
    def stop(self) -> None:
        """Signal the worker to stop."""
        self.alive = False
    
    def has_tasks(self) -> bool:
        """Check if worker has pending tasks."""
        with self._lock:
            return len(self._tasks) > 0
    
    def task_count(self) -> int:
        """Get number of pending tasks."""
        with self._lock:
            return len(self._tasks)

    def total_cost(self) -> int:
        """Get total cost of all tasks (for auto mode)."""
        with self._lock:
            return sum(self._task_costs.values())

    def __str__(self) -> str:
        return f"Worker[{self.name}](tasks={self.task_count()}, alive={self.alive})"
    
    def __repr__(self) -> str:
        return self.__str__()
