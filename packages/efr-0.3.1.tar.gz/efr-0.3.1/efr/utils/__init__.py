"""
efr.utils - Utility modules for the efr library.

This module provides utility classes and functions:
- Worker: Thread-based task executor
- Task: Executable task unit
- Trace: Error tracing utility
- IdGenerator: Random ID generation
- Functions: General utility functions
- Exceptions: Custom exception classes
"""

from efr.utils.functions import singleton, EmptyFunction
from efr.utils.id_generator import NewRandom, NewRandomID
from efr.utils.task import Task, ONCE, CIRCLE
from efr.utils.worker import Worker
from efr.utils.trace import Trace
from efr.utils.exceptions import (
    SolutionMissing,
    WorkerError,
    TaskError,
    TraceError,
    IDGenerationError
)

__all__ = [
    "singleton",
    "EmptyFunction",
    "NewRandom",
    "NewRandomID",
    "Task",
    "ONCE",
    "CIRCLE",
    "Worker",
    "Trace",
    "SolutionMissing",
    "WorkerError",
    "TaskError",
    "TraceError",
    "IDGenerationError",
]
