"""
efr - Event Framework Library

A Python event-driven framework for building scalable applications.

Main Components:
    EventSystem: Simple event system (recommended for most use cases)
    PrioritizedEventSystem: Event system with priority support
    EventFramework: Multi-threaded event framework
    Event, EventStation, EventQueue: Core event components

Example:
    >>> from efr import EventSystem
    >>>
    >>> events = EventSystem()
    >>> events.listenFor("data", process_data)
    >>> events.pushEvent("data", {"key": "value"})
"""

__version__ = "0.1.0"

# Import core components for convenience
from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.ealloter import EventAlloter
from efr.core.eframework import EventFramework
from efr.core.eerrors import (
    SolutionMissing,
    WorkerError,
    TaskError,
    FrameworkError
)

# Import embed components for convenience
from efr.embed.api import EventSystem, PrioritizedEventSystem

__all__ = [
    # Version
    "__version__",
    # Core components
    "Event",
    "EventState",
    "EventQueue",
    "EventStation",
    "EventAlloter",
    "EventFramework",
    # Embed components
    "EventSystem",
    "PrioritizedEventSystem",
    # Errors
    "SolutionMissing",
    "WorkerError",
    "TaskError",
    "FrameworkError",
]
