"""
Example: Using the efr.embed Module

This example demonstrates how to use the embedded event system
in both standalone mode and with EventFramework integration.

示例：使用efr.embed模块

本示例展示如何在独立模式和EventFramework集成模式下
使用嵌入式事件系统。
"""

import sys
sys.path.insert(0, '/mnt/okcomputer/output')

from efr.embed import EventSystem, PrioritizedEventSystem
from efr.core import EventFramework


def example_standalone_mode():
    """
    Example 1: Standalone Mode (Non-threaded)
    
    示例1：独立模式（非线程）
    """
    print("=" * 60)
    print("Example 1: Standalone Mode (Non-threaded)")
    print("=" * 60)
    
    # Create event system in standalone mode
    events = EventSystem()
    print(f"Mode: {'Framework' if events.eframework else 'Standalone'}")
    
    # Register listeners
    @events.listen("user_login")
    def on_user_login(data):
        print(f"  [Listener] User logged in: {data}")
    
    @events.listen("user_logout")
    def on_user_logout(data):
        print(f"  [Listener] User logged out: {data}")
    
    # Push events
    print("\nPushing events:")
    events.pushEvent("user_login", {"user": "alice", "time": "10:00"})
    events.pushEvent("user_logout", {"user": "bob", "time": "10:05"})
    
    # Clean up
    events.stop()
    print()


def example_with_framework():
    """
    Example 2: With EventFramework at Initialization
    
    示例2：初始化时传入EventFramework
    """
    print("=" * 60)
    print("Example 2: With EventFramework at Initialization")
    print("=" * 60)
    
    # Create framework
    efr = EventFramework(name="example_framework", log_immediate=False)
    
    # Create event system with framework
    events = EventSystem(eframework=efr)
    print(f"Mode: {'Framework' if events.eframework else 'Standalone'}")
    print(f"Framework name: {events.eframework.name}")
    
    # Register listeners
    @events.listen("message")
    def on_message(data):
        print(f"  [Listener] Message received: {data}")
    
    # Push events
    print("\nPushing events:")
    events.pushEvent("message", "Hello from framework!")
    
    # Clean up
    events.stop()
    efr.quit()
    print()


def example_delayed_attachment():
    """
    Example 3: Delayed Framework Attachment
    
    示例3：延迟框架附加
    """
    print("=" * 60)
    print("Example 3: Delayed Framework Attachment")
    print("=" * 60)
    
    # Create event system in standalone mode
    events = EventSystem()
    print(f"Initial mode: {'Framework' if events.eframework else 'Standalone'}")
    
    # Register listeners in standalone mode
    @events.listen("event1")
    def on_event1(data):
        print(f"  [Listener] Event 1: {data}")
    
    @events.listen("event2")
    def on_event2(data):
        print(f"  [Listener] Event 2: {data}")
    
    # Push events in standalone mode
    print("\nPushing events in standalone mode:")
    events.pushEvent("event1", "Standalone data 1")
    
    # Create framework and attach
    efr = EventFramework(name="delayed_framework", log_immediate=False)
    events.eframework = efr
    print(f"\nAfter attachment mode: {'Framework' if events.eframework else 'Standalone'}")
    
    # Push events with framework
    print("\nPushing events with framework:")
    events.pushEvent("event2", "Framework data 2")
    
    # Clean up
    events.stop()
    efr.quit()
    print()


def example_framework_detachment():
    """
    Example 4: Framework Detachment
    
    示例4：框架分离
    """
    print("=" * 60)
    print("Example 4: Framework Detachment")
    print("=" * 60)
    
    # Create framework and event system
    efr = EventFramework(name="detach_framework", log_immediate=False)
    events = EventSystem(eframework=efr)

    @events.listen("test_event")
    def on_test(data):
        print(f"  [Listener] Test: {data}")

    print(f"Initial mode: {'Framework' if events.eframework else 'Standalone'}")
    events.pushEvent("test_event", "With framework")

    # Detach from framework
    del events.eframework
    print(f"\nAfter detachment mode: {'Framework' if events.eframework else 'Standalone'}")
    
    # Push events in standalone mode
    events.pushEvent("test_event", "Standalone again")
    
    # Clean up
    events.stop()
    efr.quit()
    print()


def example_framework_switching():
    """
    Example 5: Switching Between Frameworks
    
    示例5：在框架之间切换
    """
    print("=" * 60)
    print("Example 5: Switching Between Frameworks")
    print("=" * 60)
    
    # Create two frameworks
    efr1 = EventFramework(name="framework_1", log_immediate=False)
    efr2 = EventFramework(name="framework_2", log_immediate=False)
    
    # Create event system with first framework
    events = EventSystem(eframework=efr1)

    @events.listen("switch_event")
    def on_switch(data):
        print(f"  [Listener] Switch: {data}")

    print(f"Current framework: {events.eframework.name}")
    events.pushEvent("switch_event", "First framework")

    # Switch to second framework
    events.eframework = efr2
    print(f"\nAfter switch: {events.eframework.name}")
    events.pushEvent("switch_event", "Second framework")
    
    # Clean up
    events.stop()
    efr1.quit()
    efr2.quit()
    print()


def example_source_filtering():
    """
    Example 6: Source Filtering
    
    示例6：源过滤
    """
    print("=" * 60)
    print("Example 6: Source Filtering")
    print("=" * 60)
    
    events = EventSystem()
    
    # Listen only for events from specific sources
    @events.listen("alert", "security")
    def on_security_alert(data):
        print(f"  [Security] Alert: {data}")
    
    @events.listen("alert", "system")
    def on_system_alert(data):
        print(f"  [System] Alert: {data}")
    
    print("Pushing events with different sources:")
    
    # This will trigger security listener
    events.pushEvent("alert", {"source": "security", "message": "Intrusion detected"})
    
    # This will trigger system listener
    events.pushEvent("alert", {"source": "system", "message": "Disk full"})
    
    # This will trigger both (if we had a listener without source filter)
    # But currently no listener without source filter, so 0 delivered
    count = events.pushEvent("alert", {"source": "other", "message": "Unknown"})
    print(f"  Events with 'other' source delivered to: {count} listeners")
    
    events.stop()
    print()


def example_prioritized_events():
    """
    Example 7: Prioritized Event System
    
    示例7：优先级事件系统
    """
    print("=" * 60)
    print("Example 7: Prioritized Event System")
    print("=" * 60)
    
    events = PrioritizedEventSystem()
    
    results = []
    
    # Register listeners with different priorities
    @events.listen("process", priority=1)
    def low_priority(data):
        results.append("low")
        print(f"  [Priority 1] Low priority handler")
    
    @events.listen("process", priority=10)
    def high_priority(data):
        results.append("high")
        print(f"  [Priority 10] High priority handler")
    
    @events.listen("process", priority=5)
    def medium_priority(data):
        results.append("medium")
        print(f"  [Priority 5] Medium priority handler")
    
    print("Pushing event (should be delivered in priority order):")
    events.pushEvent("process", "data")
    
    print(f"\nDelivery order: {results}")
    print("Expected: ['high', 'medium', 'low']")
    
    events.stop()
    print()


def example_method_chaining():
    """
    Example 8: Method Chaining
    
    示例8：方法链
    """
    print("=" * 60)
    print("Example 8: Method Chaining")
    print("=" * 60)
    
    events = EventSystem()
    
    # Chain multiple operations
    results = []
    
    (events
        .listenFor("event1", lambda d: results.append(f"event1: {d}"))
        .listenFor("event2", lambda d: results.append(f"event2: {d}"))
        .listenFor("event3", lambda d: results.append(f"event3: {d}")))
    
    events.pushEvent("event1", "A")
    events.pushEvent("event2", "B")
    events.pushEvent("event3", "C")
    
    print(f"Results: {results}")
    
    events.stop()
    print()


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("efr.embed Module Usage Examples")
    print("=" * 60 + "\n")
    
    example_standalone_mode()
    example_with_framework()
    example_delayed_attachment()
    example_framework_detachment()
    example_framework_switching()
    example_source_filtering()
    example_prioritized_events()
    example_method_chaining()
    
    print("=" * 60)
    print("All examples completed!")
    print("=" * 60)
