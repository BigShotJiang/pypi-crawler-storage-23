"""
基本用法示例 - 展示 efr 框架的核心功能

Basic Usage Example - Demonstrates core features of efr framework
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import time
from efr import EventFramework, Event, EventStation


def main():
    print("=" * 60)
    print("efr Framework - Basic Usage Example")
    print("=" * 60)
    
    # 创建框架实例
    # Create framework instance
    framework = EventFramework(
        name="example_app",
        log_path="example.log",
        log_level="INFO"
    )
    
    # 结果存储
    results = []
    
    # 定义事件处理器
    # Define event handler
    def process_order(event):
        order_id = event.task.get("order_id")
        amount = event.task.get("amount")
        result = f"Processed order {order_id} with amount ${amount}"
        print(f"  [Processor] {result}")
        results.append(result)
        return result
    
    def log_order(event):
        order_id = event.task.get("order_id")
        result = f"Logged order {order_id}"
        print(f"  [Logger] {result}")
        return result
    
    # 创建工作站
    # Create stations
    processor = EventStation(
        key="order_processor",
        respond_fn=process_order,
        level=10  # 高优先级 / High priority
    )
    
    logger = EventStation(
        key="order_logger",
        respond_fn=log_order,
        level=5   # 低优先级 / Low priority
    )
    
    # 为工作站创建工作线程
    # Create workers for stations
    processor_worker = framework.add_worker("processor_worker", timedt=0.05)
    logger_worker = framework.add_worker("logger_worker", timedt=0.05)
    
    # 注册工作站
    # Register stations
    framework.login(processor, processor_worker)
    framework.login(logger, logger_worker)
    
    # 启动框架
    # Start framework
    print("\n[1] Starting framework...")
    framework.start()
    
    # 推送事件
    # Push events
    print("\n[2] Pushing events...")
    orders = [
        {"order_id": "ORD-001", "amount": 100.0},
        {"order_id": "ORD-002", "amount": 250.5},
        {"order_id": "ORD-003", "amount": 75.25},
    ]
    
    for order in orders:
        event = Event(
            task=order,
            dest="order_processor",  # 目标工作站
            source="web_api",
            tags={"order", "payment"}
        )
        framework.push(event)
        print(f"  Pushed: {order['order_id']}")
    
    # 等待处理完成
    # Wait for processing
    print("\n[3] Waiting for processing...")
    time.sleep(1.0)
    
    # 显示结果
    # Show results
    print(f"\n[4] Results: {len(results)} events processed")
    
    # 停止框架
    # Stop framework
    print("\n[5] Stopping framework...")
    framework.quit()
    
    print("\n" + "=" * 60)
    print("Example completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
