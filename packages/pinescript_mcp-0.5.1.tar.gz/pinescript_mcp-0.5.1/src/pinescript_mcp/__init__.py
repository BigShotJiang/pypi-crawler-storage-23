"""Pine Script v6 Documentation MCP Server.

Provides tools to list, search, and read Pine Script v6 documentation
for use with AI assistants like Claude.
"""

__version__ = "0.5.1"
