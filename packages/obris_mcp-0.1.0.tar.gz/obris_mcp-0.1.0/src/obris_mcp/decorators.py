from functools import wraps
import httpx


class APIError(Exception):
    """API error with user-friendly message."""
    pass


def handle_api_errors(func):
    """Decorator to catch API errors and return user-friendly messages."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except APIError as e:
            return str(e)
        except httpx.HTTPStatusError as e:
            return f"Error: API request failed ({e.response.status_code})"
        except httpx.RequestError as e:
            return f"Error: Could not connect to API ({e})"
    return wrapper