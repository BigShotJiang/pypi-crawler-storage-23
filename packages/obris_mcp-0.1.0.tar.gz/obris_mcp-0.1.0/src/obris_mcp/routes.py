API_PREFIX = "/v1"


def _path(*segments: str) -> str:
    return f"{API_PREFIX}/{'/'.join(segments)}"


# Projects
def projects() -> str:
    return _path("projects")


def project(project_id: str) -> str:
    return _path("projects", project_id)


def project_context(project_id: str) -> str:
    return _path("projects", project_id, "context")


# References
def references(source_type: str | None = None) -> str:
    if source_type:
        return _path("references", source_type)
    return _path("references")


# Auth
def api_keys() -> str:
    return _path("auth", "api-keys")


def api_key(key_id: str) -> str:
    return _path("auth", "api-keys", key_id)
