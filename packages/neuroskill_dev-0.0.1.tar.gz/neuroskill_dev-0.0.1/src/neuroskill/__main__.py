"""Allow running as ``python -m neuroskill``."""
from neuroskill.cli import main

main()
