"""
neuroskill — Python CLI for the NeuroSkill real-time EEG analysis API.

Communicates with a locally running Skill server over WebSocket or HTTP,
giving you instant terminal access to EEG brain-state scores, sleep staging,
session history, annotations, similarity search, and more.

.. warning::
    **Research Use Only.**  All metrics are experimental outputs derived from
    consumer-grade EXG hardware.  They are **not** validated clinical
    measurements, not FDA/CE-cleared, and must not be used for diagnosis,
    treatment decisions, or any medical purpose.
"""

__version__ = "0.0.1"
__author__ = "NeuroSkill team"
__email__ = "hello@neuroskill.com"
