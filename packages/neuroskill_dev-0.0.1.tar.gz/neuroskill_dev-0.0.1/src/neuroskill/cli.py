#!/usr/bin/env python3
"""
neuroskill — Command-line interface for the Skill WebSocket API.

Python port of the TypeScript neuroskill CLI.

Usage:
    neuroskill <command> [options]

Commands:
    status                          Full device/session/scores snapshot
    session [index]                 Metrics + trends for one session (0=latest)
    sessions                        List all recording sessions
    say "text"                      Speak text via on-device TTS
    notify "title" ["body"]         Native OS notification
    label "text"                    Create a timestamped annotation
    search-labels "query"           Semantic label search
    interactive "keyword"           Cross-modal 4-layer graph search
    search                          ANN EEG-similarity search
    compare                         Side-by-side A/B metrics
    sleep [index]                   Sleep staging
    calibrations [list|get <id>]    Manage calibration profiles
    calibrate                       Open calibration window
    timer                           Open focus-timer window
    umap                            3D UMAP projection
    listen                          Stream broadcast events
    raw '{"command":"..."}'         Send arbitrary JSON

Options:
    --port <n>          Connect to explicit port (skips mDNS)
    --ws                Force WebSocket transport
    --http              Force HTTP transport
    --json              Output raw JSON (pipe-safe)
    --full              Print JSON in addition to summary
    --no-color          Disable ANSI colors
    --poll <n>          (status) Re-poll every N seconds
    --mode <m>          (search-labels) text|context|both
    --k <n>             Number of nearest neighbours
    --k-text <n>        (interactive) k for text-label search
    --k-eeg <n>         (interactive) k for EEG-similarity search
    --k-labels <n>      (interactive) k for label-proximity search
    --reach <n>         (interactive) temporal reach in minutes
    --ef <n>            HNSW ef parameter
    --seconds <n>       (listen) duration in seconds
    --start <utc>       Range start (unix seconds)
    --end <utc>         Range end (unix seconds)
    --a-start/--a-end   Session A range
    --b-start/--b-end   Session B range
    --trends            (sessions) Show per-session metric trends
    --dot               (interactive) Graphviz DOT output
    --context "..."     (label) Long-form annotation body
    --at <utc>          (label) Backdate timestamp
    --voice <name>      (say) Voice name
    --profile <p>       (calibrate) Profile name or UUID
    --help              Show this help
    --version           Print version and exit
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

# ── Version ───────────────────────────────────────────────────────────────────
CLI_VERSION = "0.0.1"

# ── ANSI colours ──────────────────────────────────────────────────────────────
GRAY    = "\x1b[90m"
GREEN   = "\x1b[32m"
RED     = "\x1b[31m"
CYAN    = "\x1b[36m"
YELLOW  = "\x1b[33m"
BLUE    = "\x1b[34m"
MAGENTA = "\x1b[35m"
BOLD    = "\x1b[1m"
DIM     = "\x1b[2m"
RESET   = "\x1b[0m"


def _apply_no_color() -> None:
    """Zero-out all ANSI escape constants."""
    global GRAY, GREEN, RED, CYAN, YELLOW, BLUE, MAGENTA, BOLD, DIM, RESET
    GRAY = GREEN = RED = CYAN = YELLOW = BLUE = MAGENTA = BOLD = DIM = RESET = ""


# ── Global state ──────────────────────────────────────────────────────────────
json_mode   = False
full_mode   = False
no_color_mode = bool(os.environ.get("NO_COLOR")) or not sys.stdout.isatty()


# ── Output helpers ────────────────────────────────────────────────────────────

def _print(msg: str = "") -> None:
    """Print to stdout, suppressed in --json mode."""
    if not json_mode:
        print(msg, flush=True)


def _print_result(data: Any) -> None:
    """Print final result — JSON in --json mode, colorized in --full mode."""
    if json_mode or full_mode:
        print(_colorize_json(data), flush=True)


def _print_error(msg: str) -> None:
    """Print error and exit(1)."""
    if json_mode:
        print(json.dumps({"error": msg}), flush=True)
    else:
        print(f"{RED}{BOLD}error:{RESET} {msg}", file=sys.stderr, flush=True)
    sys.exit(1)


def _print_info(msg: str) -> None:
    """Print dim info to stderr (never pollutes JSON stdout)."""
    if not json_mode:
        print(f"{DIM}{msg}{RESET}", file=sys.stderr, flush=True)


def _print_progress(msg: str) -> None:
    """Overwrite the current stderr line with a progress message."""
    if not json_mode:
        print(f"\r{DIM}{msg}{RESET}", end="", file=sys.stderr, flush=True)


def _clear_progress() -> None:
    """Clear the current progress line on stderr."""
    if not json_mode:
        print("\r\x1b[K", end="", file=sys.stderr, flush=True)


# ── Colorised JSON ────────────────────────────────────────────────────────────

def _colorize_json(obj: Any, indent: int = 0) -> str:
    if json_mode:
        return json.dumps(obj, indent=2)
    return _colorize_value(obj, indent)


def _colorize_value(val: Any, indent: int) -> str:
    if val is None:
        return f"{MAGENTA}null{RESET}"
    if isinstance(val, bool):
        return f"{YELLOW}{'true' if val else 'false'}{RESET}"
    if isinstance(val, (int, float)):
        return f"{CYAN}{val}{RESET}"
    if isinstance(val, str):
        escaped = (
            val.replace("\\", "\\\\")
               .replace('"', '\\"')
               .replace("\n", "\\n")
               .replace("\t", "\\t")
        )
        return f'{GREEN}"{escaped}"{RESET}'
    if isinstance(val, list):
        return _colorize_array(val, indent)
    if isinstance(val, dict):
        return _colorize_object(val, indent)
    return str(val)


def _colorize_array(arr: list, indent: int) -> str:
    if not arr:
        return f"{DIM}[]{RESET}"
    # Compact for short primitive arrays
    if len(arr) <= 8 and all(not isinstance(v, (list, dict)) for v in arr):
        items = f"{DIM},{RESET} ".join(_colorize_value(v, 0) for v in arr)
        return f"{DIM}[{RESET}{items}{DIM}]{RESET}"
    pad     = "  " * (indent + 1)
    end_pad = "  " * indent
    items   = f"{DIM},{RESET}\n".join(f"{pad}{_colorize_value(v, indent + 1)}" for v in arr)
    return f"{DIM}[{RESET}\n{items}\n{end_pad}{DIM}]{RESET}"


def _colorize_object(obj: dict, indent: int) -> str:
    if not obj:
        return f"{DIM}{{}}{RESET}"
    pad     = "  " * (indent + 1)
    end_pad = "  " * indent
    entries = f"{DIM},{RESET}\n".join(
        f'{pad}{BLUE}"{k}"{RESET}{DIM}:{RESET} {_colorize_value(v, indent + 1)}'
        for k, v in obj.items()
    )
    return f"{DIM}{{{RESET}\n{entries}\n{end_pad}{DIM}}}{RESET}"


# ── Transport / client ────────────────────────────────────────────────────────

class SkillClient:
    """Manages the WebSocket or HTTP connection to the Skill server."""

    def __init__(self) -> None:
        self.transport: str = "ws"
        self.http_base: str = ""
        self._ws: Any = None               # websockets.ClientConnection
        self._pending: Dict[str, asyncio.Future] = {}
        self._events: "asyncio.Queue[dict]" = asyncio.Queue()
        self._recv_task: Optional[asyncio.Task] = None

    # ── WebSocket ─────────────────────────────────────────────────────────────

    async def connect_ws(self, port: int, timeout: float = 5.0) -> None:
        """Open a WebSocket to ws://127.0.0.1:<port> (raises on failure)."""
        import websockets  # type: ignore[import-untyped]
        self._ws = await asyncio.wait_for(
            websockets.connect(f"ws://127.0.0.1:{port}"),
            timeout=timeout,
        )
        self._recv_task = asyncio.get_running_loop().create_task(self._recv_loop())

    async def _recv_loop(self) -> None:
        """Background task: dispatch incoming WS messages to futures / event queue."""
        try:
            async for raw in self._ws:
                try:
                    data: dict = json.loads(raw)
                except Exception:
                    continue
                if "command" in data:
                    cmd = data["command"]
                    fut = self._pending.pop(cmd, None)
                    if fut and not fut.done():
                        fut.set_result(data)
                elif "event" in data:
                    await self._events.put(data)
        except Exception:
            pass

    async def _probe_ws(self, port: int, timeout: float = 1.5) -> bool:
        """Return True if a WS handshake succeeds within *timeout* seconds."""
        try:
            import websockets  # type: ignore[import-untyped]
            ws = await asyncio.wait_for(
                websockets.connect(f"ws://127.0.0.1:{port}"),
                timeout=timeout,
            )
            await ws.close()
            return True
        except Exception:
            return False

    # ── Send ──────────────────────────────────────────────────────────────────

    async def send(self, cmd: dict, timeout_ms: int = 30_000) -> dict:
        """Send a command and return the parsed response."""
        if self.transport == "http":
            return await self._send_http(cmd)
        return await self._send_ws(cmd, timeout_ms)

    async def _send_ws(self, cmd: dict, timeout_ms: int) -> dict:
        loop    = asyncio.get_running_loop()
        cmd_name = cmd["command"]
        fut     = loop.create_future()
        self._pending[cmd_name] = fut
        await self._ws.send(json.dumps(cmd))
        try:
            return await asyncio.wait_for(asyncio.shield(fut), timeout=timeout_ms / 1000)
        except asyncio.TimeoutError:
            self._pending.pop(cmd_name, None)
            raise Exception(f"timeout after {timeout_ms}ms")

    async def _send_http(self, cmd: dict) -> dict:
        url  = f"{self.http_base}/"
        data = json.dumps(cmd).encode()
        req  = urllib.request.Request(
            url, data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            loop = asyncio.get_running_loop()
            with await loop.run_in_executor(
                None, lambda: urllib.request.urlopen(req, timeout=30)
            ) as resp:
                return json.loads(resp.read())
        except Exception as exc:
            raise Exception(
                f"could not reach Skill at {self.http_base}/ — is it running? ({exc})\n"
                "  Tip: use --port to specify the port manually."
            ) from exc

    # ── Events ────────────────────────────────────────────────────────────────

    async def collect_events(self, seconds: float) -> List[dict]:
        """Passively collect broadcast events for *seconds* seconds."""
        events: List[dict] = []
        loop    = asyncio.get_running_loop()
        deadline = loop.time() + seconds
        while True:
            remaining = deadline - loop.time()
            if remaining <= 0:
                break
            try:
                event = await asyncio.wait_for(
                    asyncio.shield(self._events.get()),
                    timeout=remaining,
                )
                events.append(event)
            except asyncio.TimeoutError:
                break
        return events

    # ── Cleanup ───────────────────────────────────────────────────────────────

    async def close(self) -> None:
        if self._recv_task:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass


# Module-level client (instantiated inside main())
_client: Optional[SkillClient] = None


async def _send(cmd: dict, timeout_ms: int = 30_000) -> dict:
    assert _client is not None
    result = await _client.send(cmd, timeout_ms)
    if not isinstance(result, dict):
        _print_error(f"unexpected response type: {type(result)}")
    return result


# ── Port discovery ────────────────────────────────────────────────────────────

async def _discover_mdns(timeout: float = 5.0) -> Optional[int]:
    """Discover Skill server via mDNS (_skill._tcp.local.).

    Design notes
    ============
    1. ``handlers=`` must be a list of plain *callables*.  Passing a
       ``ServiceListener`` subclass instance raises TypeError because zeroconf's
       internal ``Signal.fire`` calls each handler as ``h(**kwargs)``.

    2. ``zeroconf.get_service_info()`` is a *blocking* synchronous call.
       Calling it from inside an asyncio callback (the handler is invoked
       from ``_SelectorDatagramTransport._read_ready`` which runs in the
       event loop) raises
       ``RuntimeError: Use AsyncServiceInfo.async_request from the event loop``.
       The fix is to schedule an async coroutine via
       ``asyncio.get_running_loop().create_task()`` from the sync handler.
    """
    try:
        from zeroconf import ServiceStateChange  # type: ignore[import-untyped]
        from zeroconf.asyncio import (  # type: ignore[import-untyped]
            AsyncServiceBrowser,
            AsyncServiceInfo,
            AsyncZeroconf,
        )
    except ImportError:
        return None

    result: Optional[int] = None
    found  = asyncio.Event()
    loop   = asyncio.get_running_loop()

    async def _resolve(zc_instance: Any, service_type: str, name: str) -> None:
        """Async resolution — uses AsyncServiceInfo.async_request (event-loop safe)."""
        nonlocal result
        if found.is_set():
            return
        try:
            info = AsyncServiceInfo(service_type, name)
            await info.async_request(zc_instance, 3000)
            if info.port and not found.is_set():
                result = info.port
                found.set()
        except Exception:
            pass

    def _on_change(
        zeroconf: Any,
        service_type: str,
        name: str,
        state_change: Any,
    ) -> None:
        """Sync handler registered on the Signal — must not block or await."""
        if state_change is not ServiceStateChange.Added:
            return
        # Schedule async resolution on the running event loop.
        loop.create_task(_resolve(zeroconf, service_type, name))

    zconf   = AsyncZeroconf()
    browser = AsyncServiceBrowser(
        zconf.zeroconf,
        "_skill._tcp.local.",
        handlers=[_on_change],
    )
    try:
        await asyncio.wait_for(found.wait(), timeout=timeout)
    except asyncio.TimeoutError:
        pass
    finally:
        await browser.async_cancel()
        await zconf.async_close()

    return result


async def _discover_lsof() -> Optional[int]:
    """Fall back to pgrep + lsof to find the Skill server port."""
    assert _client is not None
    try:
        ps = subprocess.run(
            ["pgrep", "-if", "skill"],
            capture_output=True, text=True,
        )
        for pid in ps.stdout.strip().split("\n"):
            pid = pid.strip()
            if not pid:
                continue
            try:
                lsof = subprocess.run(
                    ["lsof", "-iTCP", "-sTCP:LISTEN", "-nP", "-p", pid],
                    capture_output=True, text=True,
                )
                for m in re.finditer(r":(\d{4,5})\s+\(LISTEN\)", lsof.stdout):
                    port = int(m.group(1))
                    if await _client._probe_ws(port):
                        return port
            except Exception:
                continue
    except Exception:
        pass
    return None


async def _discover(explicit_port: Optional[int]) -> int:
    """Resolve the server port (explicit → mDNS → lsof)."""
    if explicit_port is not None:
        return explicit_port

    _print_info("discovering Skill via mDNS…")
    port = await _discover_mdns()
    if port:
        _print_info(f"found Skill at port {port}")
        return port

    _print_info("mDNS timeout — trying lsof fallback…")
    port = await _discover_lsof()
    if port:
        return port

    _print_error(
        "could not discover Skill. Is it running? "
        "Use --port <n> to specify manually."
    )


async def _try_connect_once(port: int, timeout_ms: int = 3000) -> bool:
    """Return True and store the open WS if a single connection attempt succeeds."""
    assert _client is not None
    try:
        import websockets  # type: ignore[import-untyped]
        ws = await asyncio.wait_for(
            websockets.connect(f"ws://127.0.0.1:{port}"),
            timeout=timeout_ms / 1000,
        )
        # Store it so _recv_loop can be started
        _client._ws = ws
        return True
    except Exception:
        return False


# ── Formatting helpers ────────────────────────────────────────────────────────

def _fmt_ts(utc: int) -> str:
    """Format a unix timestamp as a human-readable local date+time string.

    Produces the same output as TypeScript's ``toLocaleString()`` —
    e.g. ``"2/24/2026, 8:00:00 AM"`` — without leading zeros on month,
    day or hour.

    Uses explicit integer formatting instead of ``%-m``/``%-I`` (Linux-only
    strftime extension that fails on Windows) so this works on all platforms.
    """
    dt = datetime.fromtimestamp(utc)
    hh_24 = dt.hour
    hh_12 = hh_24 % 12 or 12  # convert 0 → 12, 13 → 1, etc.
    am_pm = "AM" if hh_24 < 12 else "PM"
    return f"{dt.month}/{dt.day}/{dt.year}, {hh_12}:{dt.minute:02d}:{dt.second:02d} {am_pm}"


def _fmt_dur(secs: int) -> str:
    """Format a duration in seconds as a compact string: 2h 15m / 42m 30s / 10s."""
    if secs >= 3600:
        return f"{secs // 3600}h {(secs % 3600) // 60}m"
    if secs >= 60:
        return f"{secs // 60}m {secs % 60}s"
    return f"{secs}s"


def _progress_bar(pct: int, width: int) -> str:
    """Render a Unicode block progress bar."""
    filled = round(width * pct / 100)
    empty  = width - filled
    return f"{BLUE}{'█' * filled}{GRAY}{'░' * empty}{RESET}"


def _print_range(label: str, start: int, end: int, is_default: bool) -> None:
    tag = (
        f"{DIM}(auto: {_fmt_ts(start)} → {_fmt_ts(end)}, {_fmt_dur(end - start)}){RESET}"
        if is_default else ""
    )
    _print(f"  {DIM}{label}:{RESET} {CYAN}{start}{RESET}{DIM}–{RESET}{CYAN}{end}{RESET} {tag}")


def _print_rerun(cmd_line: str) -> None:
    _print(f"\n  {DIM}rerun:{RESET} {YELLOW}neuroskill {cmd_line}{RESET}\n")


# ── Session cache helpers ─────────────────────────────────────────────────────

_session_cache: Optional[List[dict]] = None


async def _get_sessions() -> List[dict]:
    global _session_cache
    if _session_cache is not None:
        return _session_cache
    r = await _send({"command": "sessions"})
    _session_cache = r.get("sessions", []) if r.get("ok") else []
    return _session_cache


async def _auto_range(fallback_secs: int = 600) -> Tuple[int, int]:
    sessions = await _get_sessions()
    if sessions:
        last = sessions[0]
        return last["start_utc"], last["end_utc"]
    now = int(time.time())
    return now - fallback_secs, now


async def _auto_range_ab() -> Tuple[int, int, int, int]:
    sessions = await _get_sessions()
    if len(sessions) >= 2:
        a, b = sessions[1], sessions[0]
        return a["start_utc"], a["end_utc"], b["start_utc"], b["end_utc"]
    if len(sessions) == 1:
        s   = sessions[0]
        mid = (s["start_utc"] + s["end_utc"]) // 2
        return s["start_utc"], mid, mid, s["end_utc"]
    now = int(time.time())
    return now - 7200, now - 3600, now - 3600, now


# ── Argument dataclass ────────────────────────────────────────────────────────

@dataclass
class Args:
    command:       str           = ""
    port:          Optional[int] = None
    json:          bool          = False
    full:          bool          = False
    http:          bool          = False
    ws:            bool          = False
    text:          Optional[str] = None
    body:          Optional[str] = None
    start:         Optional[int] = None
    end:           Optional[int] = None
    a_start:       Optional[int] = None
    a_end:         Optional[int] = None
    b_start:       Optional[int] = None
    b_end:         Optional[int] = None
    k:             Optional[int] = None
    ef:            Optional[int] = None
    mode:          Optional[str] = None
    profile:       Optional[str] = None
    seconds:       Optional[int] = None
    raw_json:      Optional[str] = None
    trends:        bool          = False
    session_index: Optional[int] = None
    keyword:       Optional[str] = None
    dot:           bool          = False
    k_text:        Optional[int] = None
    k_eeg:         Optional[int] = None
    k_labels:      Optional[int] = None
    reach:         Optional[int] = None
    poll:          Optional[int] = None
    context:       Optional[str] = None
    at:            Optional[int] = None
    voice:         Optional[str] = None
    sub_action:    Optional[str] = None
    id:            Optional[int] = None
    no_color:      bool          = False


def _parse_args() -> Args:
    argv = sys.argv[1:]
    args = Args()

    KNOWN_FLAGS = {
        "--port", "--json", "--full", "--trends", "--http", "--ws", "--dot",
        "--help", "-h", "--version", "-v", "--no-color",
        "--start", "--end", "--a-start", "--a-end", "--b-start", "--b-end",
        "--k", "--k-text", "--k-eeg", "--k-labels", "--reach", "--ef",
        "--mode", "--profile", "--seconds", "--poll",
        "--context", "--at", "--voice",
    }

    i = 0
    while i < len(argv):
        a = argv[i]

        def next_int(flag: str) -> int:
            nonlocal i
            i += 1
            if i >= len(argv):
                print(f"error: {flag} requires a numeric value", file=sys.stderr)
                sys.exit(1)
            try:
                return int(argv[i])
            except ValueError:
                print(f"error: {flag} requires a numeric value (got: {argv[i]!r})", file=sys.stderr)
                sys.exit(1)

        def next_str() -> str:
            nonlocal i
            i += 1
            if i >= len(argv):
                print(f"error: expected a value after {a}", file=sys.stderr)
                sys.exit(1)
            return argv[i]

        if   a == "--port":          args.port      = next_int("--port")
        elif a == "--json":          args.json      = True
        elif a == "--full":          args.full      = True
        elif a == "--trends":        args.trends    = True
        elif a == "--http":          args.http      = True
        elif a == "--ws":            args.ws        = True
        elif a == "--dot":           args.dot       = True
        elif a == "--no-color":      args.no_color  = True
        elif a in ("--help", "-h"): args.command   = "help"
        elif a in ("--version", "-v"): args.command = "version"
        elif a == "--start":         args.start     = next_int("--start")
        elif a == "--end":           args.end       = next_int("--end")
        elif a == "--a-start":       args.a_start   = next_int("--a-start")
        elif a == "--a-end":         args.a_end     = next_int("--a-end")
        elif a == "--b-start":       args.b_start   = next_int("--b-start")
        elif a == "--b-end":         args.b_end     = next_int("--b-end")
        elif a == "--k":             args.k         = next_int("--k")
        elif a == "--k-text":        args.k_text    = next_int("--k-text")
        elif a == "--k-eeg":         args.k_eeg     = next_int("--k-eeg")
        elif a == "--k-labels":      args.k_labels  = next_int("--k-labels")
        elif a == "--reach":         args.reach     = next_int("--reach")
        elif a == "--ef":            args.ef        = next_int("--ef")
        elif a == "--seconds":       args.seconds   = next_int("--seconds")
        elif a == "--poll":          args.poll      = next_int("--poll")
        elif a == "--at":            args.at        = next_int("--at")
        elif a == "--mode":          args.mode      = next_str()
        elif a == "--profile":       args.profile   = next_str()
        elif a == "--context":       args.context   = next_str()
        elif a == "--voice":         args.voice     = next_str()
        # Positional arguments
        elif not args.command:
            args.command = a.lower()
        elif args.command == "label"         and not args.text:    args.text    = a
        elif args.command == "search-labels" and not args.text:    args.text    = a
        elif args.command == "interactive"   and not args.keyword: args.keyword = a
        elif args.command == "say"           and not args.text:    args.text    = a
        elif args.command == "notify"        and not args.text:    args.text    = a
        elif args.command == "notify"        and not args.body:    args.body    = a
        elif args.command == "raw"           and not args.raw_json: args.raw_json = a
        elif args.command == "calibrations"  and not args.sub_action:
            args.sub_action = a.lower()
        elif (args.command == "calibrations" and args.sub_action == "get"
              and args.id is None):
            try:
                args.id = int(a)
            except ValueError:
                print(f"error: calibrations get requires a numeric id (got: {a!r})", file=sys.stderr)
                sys.exit(1)
        elif args.command in ("session", "sleep"):
            try:
                if a.strip():
                    args.session_index = int(a)
            except ValueError:
                pass
        elif a.startswith("--") and a not in KNOWN_FLAGS:
            print(f'error: unrecognized option "{a}". Run with --help to see available options.', file=sys.stderr)
            sys.exit(1)

        i += 1

    return args


# ── Help ──────────────────────────────────────────────────────────────────────

def _show_help() -> None:
    def m(cmd: str, desc: str) -> str:
        return f"  {CYAN}{cmd:<50}{RESET} {desc}"

    # Pre-compute entries that contain characters problematic in f-string expressions
    m_say        = m('say "text" [--voice <name>]',                  "speak text aloud via on-device TTS")
    m_notify     = m('notify "title" ["body"]',                      "send a native OS notification")
    m_label      = m('label "my annotation" [--context "..."]',      "create a timestamped text annotation")
    m_search_lbl = m('search-labels "query" [--mode m] [--k n]',     "search labels by free text")
    m_inter      = m('interactive "keyword" [--k-text n] [--k-eeg n]',"cross-modal 4-layer graph search")
    m_raw        = m("raw '{\"command\":\"status\"}'",               "send raw JSON, print full response")

    print(f"""
{BOLD}neuroskill{RESET} — command-line interface for the Skill WebSocket / HTTP API

{BOLD}USAGE{RESET}
  neuroskill <command> [options]

{BOLD}COMMANDS{RESET}
{m("status [--poll <secs>]",                             "full device, session, embeddings, scores snapshot")}
{m("session [index]",                                   "all metrics + trends for one session (0=latest, 1=prev, …)")}
{m("sessions",                                          "list all recording sessions across all days")}
{m_say}
{m_notify}
{m_label}
{m_search_lbl}
{m_inter}
{m("search [--start <u>] [--end <u>] [--k n]",          "ANN EEG-similarity search on embeddings")}
{m("compare [--a-start ..] [--a-end ..] [--b-start ..]","side-by-side metrics + UMAP")}
{m("sleep [index] [--start <u>] [--end <u>]",           "sleep staging — index selects session")}
{m("calibrations [list|get <id>]",                      "list calibration profiles or inspect one")}
{m("calibrate [--profile <name-or-id>]",                "open calibration window and start immediately")}
{m("timer",                                             "open focus-timer window and start work phase")}
{m("umap [--a-start ..] [--a-end ..] [--b-start ..]",   "3D UMAP projection with live progress")}
{m("listen [--seconds <n>]",                            "stream broadcast events (default: 5 s)")}
{m_raw}

{BOLD}OPTIONS{RESET}
  {YELLOW}--port <n>{RESET}        connect to explicit port (skips mDNS discovery)
  {YELLOW}--ws{RESET}              force WebSocket transport
  {YELLOW}--http{RESET}            force HTTP REST (no live events)
  {DIM}(neither){RESET}         auto: try WebSocket, silently fall back to HTTP
  {YELLOW}--json{RESET}            output raw JSON (pipe-safe, no colours)
  {YELLOW}--full{RESET}            print full JSON response after the human-readable summary
  {YELLOW}--no-color{RESET}        disable ANSI colour output (also via NO_COLOR env var)
  {YELLOW}--poll <n>{RESET}        (status) re-poll every N seconds
  {YELLOW}--trends{RESET}          (sessions) show per-session metric trends
  {YELLOW}--mode <m>{RESET}        search-labels: text | context | both (default: text)
  {YELLOW}--k <n>{RESET}           number of nearest neighbours
  {YELLOW}--ef <n>{RESET}          HNSW ef parameter for search-labels
  {YELLOW}--dot{RESET}             (interactive) output Graphviz DOT — pipe to dot -Tsvg
  {YELLOW}--k-text <n>{RESET}      (interactive) k for text-label search (default: 5)
  {YELLOW}--k-eeg <n>{RESET}       (interactive) k for EEG-similarity search (default: 5)
  {YELLOW}--k-labels <n>{RESET}    (interactive) k for label-proximity step (default: 3)
  {YELLOW}--reach <n>{RESET}       (interactive) temporal reach in minutes (default: 10)
  {YELLOW}--context "..."{RESET}   (label) long-form annotation body
  {YELLOW}--at <utc>{RESET}        (label) backdate to a specific unix second
  {YELLOW}--voice <name>{RESET}    (say) voice name, e.g. Jasper
  {YELLOW}--profile <p>{RESET}     (calibrate) profile name or UUID
  {YELLOW}--seconds <n>{RESET}     (listen) duration in seconds (default: 5)
  {YELLOW}--help{RESET}            show this help
  {YELLOW}--version{RESET}         print CLI version and exit

{BOLD}EXAMPLES{RESET}
  neuroskill status
  neuroskill status --json | python3 -m json.tool
  neuroskill status --poll 5
  neuroskill session 0
  neuroskill sessions --trends
  neuroskill say "Eyes open."
  neuroskill notify "Session done" "Great work!"
  neuroskill label "meditation start"
  neuroskill label "breathwork" --context "box breathing 4-4-4-4"
  neuroskill search-labels "deep focus" --k 10
  neuroskill search-labels "anxiety" --mode both
  neuroskill interactive "flow state" --k-eeg 8 --reach 15
  neuroskill interactive "focus" --dot | dot -Tsvg > graph.svg
  neuroskill search
  neuroskill compare
  neuroskill sleep 0
  neuroskill calibrations
  neuroskill calibrate --profile "Eyes Open"
  neuroskill timer
  neuroskill umap
  neuroskill listen --seconds 30
  neuroskill raw '{{"command":"status"}}'
  neuroskill status --http --port 8375
""")
    sys.exit(0)


# ── Command handlers ──────────────────────────────────────────────────────────

async def _cmd_status(args: Args) -> None:
    """status — Full device / session / scores snapshot."""

    async def _once() -> None:
        r = await _send({"command": "status"})
        if not r.get("ok"):
            _print_error(f"server returned ok=false: {r.get('error')}")

        if not json_mode:
            # Device
            if r.get("device"):
                d = r["device"]
                state_col = GREEN if d.get("state") == "connected" else (YELLOW if d.get("state") == "connecting" else RED)
                try:
                    _bat = float(d.get("battery") or 0)
                except (TypeError, ValueError):
                    _bat = 0.0
                bat_col = GREEN if _bat >= 50 else (YELLOW if _bat >= 20 else RED)
                _print("")
                _print(f"  {BOLD}Device{RESET}")
                line = f"  {DIM}state:{RESET}    {state_col}{d.get('state','unknown')}{RESET}"
                if d.get("name"):     line += f"   {DIM}name:{RESET} {CYAN}{d['name']}{RESET}"
                if d.get("battery") is not None:
                    bat_val = d['battery']
                    bat_str = f"{bat_val:.0f}" if isinstance(bat_val, float) else str(bat_val)
                    line += f"   {DIM}battery:{RESET} {bat_col}{bat_str}%{RESET}"
                if d.get("firmware"): line += f"   {DIM}firmware:{RESET} {DIM}{d['firmware']}{RESET}"
                _print(line)
                if any(d.get(k) is not None for k in ("eeg_samples","ppg_samples","imu_samples")):
                    parts = []
                    if d.get("eeg_samples") is not None: parts.append(f"EEG {CYAN}{d['eeg_samples']}{RESET}")
                    if d.get("ppg_samples") is not None: parts.append(f"PPG {CYAN}{d['ppg_samples']}{RESET}")
                    if d.get("imu_samples") is not None: parts.append(f"IMU {CYAN}{d['imu_samples']}{RESET}")
                    _print(f"  {DIM}samples:{RESET}  {'  '.join(parts)}")

            # Session
            if r.get("session"):
                s = r["session"]
                _print("")
                _print(f"  {BOLD}Session{RESET}")
                line = f"  {DIM}started:{RESET}  {CYAN}{_fmt_ts(s['start_utc'])}{RESET}"
                if s.get("duration_secs") is not None: line += f"   {DIM}duration:{RESET} {CYAN}{_fmt_dur(s['duration_secs'])}{RESET}"
                if s.get("n_epochs")      is not None: line += f"   {DIM}epochs:{RESET} {CYAN}{s['n_epochs']}{RESET}"
                _print(line)

            # Signal quality
            # The server may return signal_quality as:
            #   dict  {"tp9": 0.95, "af7": 0.88, ...}   (documented form)
            #   list  [0.95, 0.88, 0.91, 0.97]           (observed from server)
            # Values may also arrive as strings ("0.95") rather than floats.
            # Normalise everything to Dict[str, float] before display.
            if r.get("signal_quality") is not None:
                q_raw = r["signal_quality"]
                _ELECTRODES = ("tp9", "af7", "af8", "tp10")

                def _to_float(v: Any) -> Optional[float]:
                    if v is None:
                        return None
                    try:
                        return float(v)
                    except (TypeError, ValueError):
                        return None

                if isinstance(q_raw, list):
                    q_dict: Dict[str, Optional[float]] = {
                        k: _to_float(v) for k, v in zip(_ELECTRODES, q_raw)
                    }
                elif isinstance(q_raw, dict):
                    q_dict = {k: _to_float(q_raw.get(k)) for k in _ELECTRODES}
                else:
                    q_dict = {}

                def q_color(v: float) -> str:
                    return GREEN if v >= 0.9 else (YELLOW if v >= 0.7 else RED)

                def q_fmt(label: str, v: Optional[float]) -> str:
                    if v is None:
                        return ""
                    return f"{DIM}{label}:{RESET} {q_color(v)}{v * 100:.0f}%{RESET}"

                parts = [q_fmt(k, q_dict.get(k)) for k in _ELECTRODES]
                parts = [p for p in parts if p]
                if parts:
                    _print("")
                    _print(f"  {BOLD}Signal Quality{RESET}")
                    _print(f"  {'   '.join(parts)}")

            # Scores
            if r.get("scores"):
                s = r["scores"]
                score_metrics = [
                    ("focus","focus"), ("relaxation","relaxation"), ("engagement","engagement"),
                    ("hr","hr"), ("meditation","meditation"), ("drowsiness","drowsiness"),
                    ("mood","mood"), ("snr","snr"), ("stillness","stillness"),
                    ("cognitive_load","cog.load"),
                ]
                present = [(k,lbl) for k,lbl in score_metrics if s.get(k) is not None]
                if present:
                    _print("")
                    _print(f"  {BOLD}Scores{RESET}")
                    cols = 3
                    for idx in range(0, len(present), cols):
                        row = present[idx:idx+cols]
                        line_parts = []
                        for k, lbl in row:
                            raw = s[k]
                            try:
                                v = float(raw)
                                vs = f"{v:.2f}" if v != int(v) else f"{int(v)}"
                            except (TypeError, ValueError):
                                vs = str(raw)
                            line_parts.append(f"{DIM}{lbl:<12}{RESET}{CYAN}{vs:>6}{RESET}")
                        _print(f"  {'   '.join(line_parts)}")

            # EEG bands
            if r.get("scores", {}).get("bands"):
                b = r["scores"]["bands"]
                band_metrics = [
                    ("δ delta","rel_delta"), ("θ theta","rel_theta"), ("α alpha","rel_alpha"),
                    ("β beta","rel_beta"),   ("γ gamma","rel_gamma"),
                ]
                present = [(lbl,k) for lbl,k in band_metrics if b.get(k) is not None]
                if present:
                    _print("")
                    _print(f"  {BOLD}EEG Bands{RESET}")
                    cols = 3
                    for idx in range(0, len(present), cols):
                        row = present[idx:idx+cols]
                        line_parts = []
                        for lbl, k in row:
                            try:
                                line_parts.append(f"{DIM}{lbl:<12}{RESET}{CYAN}{float(b[k])*100:>6.1f}%{RESET}")
                            except (TypeError, ValueError):
                                line_parts.append(f"{DIM}{lbl:<12}{RESET}{CYAN}{str(b[k]):>6}{RESET}")
                        _print(f"  {'   '.join(line_parts)}")

            # EEG Ratios
            if r.get("scores"):
                s = r["scores"]

                def _fval(raw: Any) -> Optional[float]:
                    """Safely coerce a server value to float; return None on failure."""
                    if raw is None:
                        return None
                    try:
                        return float(raw)
                    except (TypeError, ValueError):
                        return None

                ratio_metrics = [
                    ("FAA","faa",3), ("theta/alpha","tar",3), ("beta/alpha","bar",3),
                    ("delta/theta","dtr",3), ("theta/beta","tbr",3), ("PSE","pse",3),
                    ("alpha peak (Hz)","apf",2), ("band-pwr slope","bps",3),
                    ("coherence","coherence",3), ("mu suppression","mu_suppression",3),
                    ("SEF95 (Hz)","sef95",2), ("spec. centroid","spectral_centroid",2),
                    ("laterality idx","laterality_index",3),
                ]
                present = [(lbl,k,dec) for lbl,k,dec in ratio_metrics
                           if _fval(s.get(k)) not in (None, 0.0)]
                if present:
                    _print("")
                    _print(f"  {BOLD}EEG Ratios & Indices{RESET}")
                    cols = 3
                    for idx in range(0, len(present), cols):
                        row = present[idx:idx+cols]
                        line_parts = [f"{DIM}{lbl:<16}{RESET}{CYAN}{_fval(s[k]):>7.{dec}f}{RESET}"
                                      for lbl,k,dec in row]
                        _print(f"  {'   '.join(line_parts)}")

                complexity_metrics = [
                    ("Hjorth act.","hjorth_activity"), ("Hjorth mob.","hjorth_mobility"),
                    ("Hjorth cplx.","hjorth_complexity"), ("perm. entropy","permutation_entropy"),
                    ("Higuchi FD","higuchi_fd"), ("DFA exponent","dfa_exponent"),
                    ("sample entropy","sample_entropy"), ("PAC θ-γ","pac_theta_gamma"),
                ]
                cpresent = [(lbl,k) for lbl,k in complexity_metrics
                            if _fval(s.get(k)) not in (None, 0.0)]
                if cpresent:
                    _print("")
                    _print(f"  {BOLD}EEG Complexity{RESET}")
                    cols = 3
                    for idx in range(0, len(cpresent), cols):
                        row = cpresent[idx:idx+cols]
                        line_parts = [f"{DIM}{lbl:<16}{RESET}{CYAN}{_fval(s[k]):>7.3f}{RESET}"
                                      for lbl,k in row]
                        _print(f"  {'   '.join(line_parts)}")

            # Embeddings
            if r.get("embeddings"):
                e = r["embeddings"]
                _print("")
                _print(f"  {BOLD}Embeddings{RESET}")
                _print(f"  {DIM}today:{RESET} {CYAN}{e.get('today',0)}{RESET}   {DIM}total:{RESET} {CYAN}{e.get('total',0)}{RESET}   {DIM}recording days:{RESET} {CYAN}{e.get('recording_days',0)}{RESET}")

            # Labels
            if r.get("labels") is not None:
                lbl_data   = r["labels"]
                lbl_count  = lbl_data.get("total", lbl_data) if isinstance(lbl_data, dict) else lbl_data
                recent: list = lbl_data.get("recent", []) if isinstance(lbl_data, dict) else []
                _print("")
                _print(f"  {BOLD}Labels{RESET}  {DIM}({lbl_count} total){RESET}")
                if not recent:
                    _print(f"  {DIM}no labels yet{RESET}")
                for lbl in recent:
                    _print(f"  {DIM}#{lbl['id']}{RESET}  {GREEN}\"{lbl['text']}\"{RESET}  {DIM}{_fmt_ts(lbl['created_at'])}{RESET}")

            # Calibration
            if r.get("calibration") is not None:
                cal = r["calibration"]
                _print("")
                _print(f"  {BOLD}Calibration{RESET}")
                if isinstance(cal, (int, float)):
                    _print(f"  {DIM}last:{RESET} {CYAN}{_fmt_ts(int(cal))}{RESET}")
                elif isinstance(cal, dict):
                    # Timestamp — try several known field names
                    ts_raw = (cal.get("last_calibration_utc") or cal.get("last_utc")
                              or cal.get("completed_at") or cal.get("timestamp")
                              or cal.get("last") or cal.get("created_at"))
                    if isinstance(ts_raw, (int, float)):
                        _print(f"  {DIM}last:{RESET} {CYAN}{_fmt_ts(int(ts_raw))}{RESET}")
                    elif ts_raw is not None:
                        _print(f"  {DIM}last:{RESET} {CYAN}{ts_raw}{RESET}")
                    # Profile name
                    if cal.get("name"):
                        _print(f"  {DIM}profile:{RESET} {CYAN}{cal['name']}{RESET}")
                    # Other scalar fields
                    _SKIP_CAL = frozenset({"last_calibration_utc","last_utc","completed_at",
                                           "timestamp","last","created_at","actions","labels",
                                           "steps","profile_id","id","name","auto_start"})
                    for ck, cv in cal.items():
                        if ck in _SKIP_CAL or cv is None or isinstance(cv, (dict, list)):
                            continue
                        _print(f"  {DIM}{ck}:{RESET} {CYAN}{cv}{RESET}")
                    # Action labels as a sequence
                    items_raw = (cal.get("actions") or cal.get("labels") or cal.get("steps") or [])
                    if isinstance(items_raw, list) and items_raw:
                        def _name_of(item: Any) -> str:
                            if isinstance(item, str):
                                return item
                            if isinstance(item, dict):
                                return str(item.get("name") or item.get("label")
                                           or item.get("title") or item.get("action")
                                           or item)
                            return str(item)
                        sep   = f"{DIM} → {RESET}"
                        names = sep.join(f"{CYAN}{_name_of(it)}{RESET}" for it in items_raw)
                        _print(f"  {DIM}labels:{RESET} {names}")

            # Sleep 48h summary
            if r.get("sleep"):
                s = r["sleep"]
                total = s.get("total_epochs", 0)
                def pct(n: int) -> str:
                    return f" {DIM}({n/max(total,1)*100:.0f}%){RESET}" if total else ""
                _print("")
                _print(f"  {BOLD}Sleep (48 h){RESET}")
                epoch_secs = s.get("epoch_secs", 5)
                _print(f"  {DIM}total:{RESET} {CYAN}{total}{RESET} epochs"
                       f"  {DIM}({total * epoch_secs // 60} min){RESET}")
                if s.get("wake_epochs") is not None:
                    _print(
                        f"  {GREEN}Wake{RESET}  {CYAN}{s['wake_epochs']}{RESET}{pct(s['wake_epochs'])}"
                        f"   {YELLOW}N1{RESET}  {CYAN}{s.get('n1_epochs',0)}{RESET}{pct(s.get('n1_epochs',0))}"
                        f"   {BLUE}N2{RESET}  {CYAN}{s.get('n2_epochs',0)}{RESET}{pct(s.get('n2_epochs',0))}"
                        f"   {MAGENTA}N3{RESET}  {CYAN}{s.get('n3_epochs',0)}{RESET}{pct(s.get('n3_epochs',0))}"
                        f"   {RED}REM{RESET} {CYAN}{s.get('rem_epochs',0)}{RESET}{pct(s.get('rem_epochs',0))}"
                    )

            # Recording history
            if r.get("history"):
                h = r["history"]
                _print("")
                _print(f"  {BOLD}Recording History{RESET}")
                _print(f"  {DIM}sessions:{RESET} {CYAN}{h.get('total_sessions')}{RESET}"
                       f"  {DIM}days:{RESET} {CYAN}{h.get('recording_days')}{RESET}"
                       f"  {DIM}streak:{RESET} {GREEN}{h.get('current_streak_days')}d{RESET}"
                       f"  {DIM}total:{RESET} {CYAN}{h.get('total_recording_hours',0):.1f}h{RESET}")
                _print(f"  {DIM}longest:{RESET} {CYAN}{h.get('longest_session_min',0):.0f}{RESET}min"
                       f"  {DIM}avg:{RESET} {CYAN}{h.get('avg_session_min',0):.0f}{RESET}min")

                tvsa = h.get("today_vs_avg", {})
                if tvsa:
                    _print(f"\n  {BOLD}Today vs 7-Day Average{RESET}")
                    for metric, v in tvsa.items():
                        arrow = (f"{GREEN}↑{RESET}" if v.get("direction") == "up"
                                 else f"{RED}↓{RESET}" if v.get("direction") == "down"
                                 else f"{DIM}→{RESET}")
                        dp = v.get("delta_pct", 0)
                        pct_str = f"+{dp:.1f}%" if dp > 0 else f"{dp:.1f}%"
                        _print(f"    {metric:<18} {CYAN}{v.get('today',0):>7.2f}{RESET}"
                               f" {DIM}vs{RESET} {CYAN}{v.get('avg_7d',0):>7.2f}{RESET}"
                               f"  {arrow} {pct_str}")
            _print("")

        _print_result(r)

    if args.poll:
        _print(f"{BOLD}⚡ status{RESET} {DIM}(polling every {args.poll}s — press Ctrl+C to stop){RESET}")
        while True:
            _print(f"\n{DIM}── {datetime.now().strftime('%H:%M:%S')} {'─' * 46}{RESET}")
            await _once()
            await asyncio.sleep(args.poll)
    else:
        _print(f"{BOLD}⚡ status{RESET}")
        await _once()


async def _cmd_session(args: Args) -> None:
    """session [index] — Full metric breakdown for one session."""
    idx = args.session_index if args.session_index is not None else 0
    _print(f"{BOLD}⚡ session{RESET} {DIM}[{idx}]{RESET}")

    sr   = await _send({"command": "sessions"})
    if not sr.get("ok"):
        _print_error(f"sessions failed: {sr.get('error')}")
    lst: list = sr.get("sessions", [])
    if not lst:
        _print_error("no sessions recorded yet")
    if idx >= len(lst):
        _print_error(f"session index {idx} out of range — only {len(lst)} session(s) available (0–{len(lst)-1})")

    s = lst[idx]
    if not json_mode:
        dt_e = datetime.fromtimestamp(s["end_utc"])
        hh_e = dt_e.hour % 12 or 12
        end_str = f"{hh_e}:{dt_e.minute:02d}:{dt_e.second:02d} {'AM' if dt_e.hour < 12 else 'PM'}"
        _print(f"  {CYAN}{s['day']}{RESET}  {_fmt_ts(s['start_utc'])} → {end_str}"
               f"  {YELLOW}{_fmt_dur(s['end_utc']-s['start_utc'])}{RESET}"
               f"  {DIM}{s['n_epochs']} epochs{RESET}")
        if len(lst) > 1:
            _print(f"  {DIM}(index {idx} of {len(lst)-1}; use `session {idx+1}` for previous){RESET}")

    tm = await _send({"command": "session_metrics", "start_utc": s["start_utc"], "end_utc": s["end_utc"]})
    if not tm.get("ok"):
        _print_error(f"session_metrics failed: {tm.get('error')}")

    if json_mode:
        _print_result(tm)
        return

    m  = tm.get("metrics", {})
    f  = tm.get("first", {})
    sc = tm.get("second", {})
    t  = tm.get("trends", {})

    def arrow_of(direction: str) -> str:
        return (f"{GREEN}↑{RESET}" if direction == "up"
                else f"{RED}↓{RESET}" if direction == "down"
                else f"{DIM}→{RESET}")

    def row(label: str, key: str, dec: int = 2, pct: bool = False) -> Optional[str]:
        avg = m.get(key)
        fv  = f.get(key)
        sv  = sc.get(key)
        if avg is None or (avg == 0 and fv == 0 and sv == 0):
            return None
        fmt = (lambda v: f"{v*100:.0f}%") if pct else (lambda v: f"{v:.{dec}f}")
        direction = t.get(key, "flat")
        delta = f"{DIM}({fmt(fv or 0)} → {fmt(sv or 0)}){RESET}"
        return (f"  {DIM}{label:<22}{RESET}"
                f"{CYAN}{fmt(avg):>7}{RESET}"
                f"  {arrow_of(direction)}  {delta}")

    def section(title: str, rows: list) -> None:
        lines = [r for r in rows if r is not None]
        if not lines:
            return
        _print(f"\n  {BOLD}{title}{RESET}")
        for line in lines:
            _print(line)

    section("Core Scores", [
        row("focus",          "focus"),
        row("relaxation",     "relaxation"),
        row("engagement",     "engagement"),
        row("meditation",     "meditation"),
        row("mood",           "mood"),
        row("cognitive load", "cognitive_load"),
        row("drowsiness",     "drowsiness"),
    ])
    section("PPG / Heart", [
        row("heart rate (bpm)",   "hr",               1),
        row("rmssd (ms)",         "rmssd",            1),
        row("sdnn (ms)",          "sdnn",             1),
        row("pnn50 (%)",          "pnn50",            1),
        row("lf/hf ratio",        "lf_hf_ratio",      2),
        row("resp. rate",         "respiratory_rate", 1),
        row("SpO₂",              "spo2_estimate",    1),
        row("perfusion idx",      "perfusion_index",  3),
        row("stress index",       "stress_index",     2),
    ])
    section("EEG Bands", [
        row("δ delta",   "rel_delta",      1, True),
        row("θ theta",   "rel_theta",      1, True),
        row("α alpha",   "rel_alpha",      1, True),
        row("β beta",    "rel_beta",       1, True),
        row("γ gamma",   "rel_gamma",      1, True),
        row("high γ",    "rel_high_gamma", 1, True),
    ])
    section("EEG Ratios & Indices", [
        row("FAA",               "faa",              3),
        row("theta/alpha",       "tar",              3),
        row("beta/alpha",        "bar",              3),
        row("delta/theta",       "dtr",              3),
        row("theta/beta",        "tbr",              3),
        row("PSE",               "pse",              3),
        row("alpha peak (Hz)",   "apf",              2),
        row("band-pwr slope",    "bps",              3),
        row("SNR (dB)",          "snr",              1),
        row("coherence",         "coherence",        3),
        row("mu suppression",    "mu_suppression",   3),
        row("SEF95 (Hz)",        "sef95",            2),
        row("spectral centroid", "spectral_centroid",2),
        row("laterality idx",    "laterality_index", 3),
    ])
    section("Complexity Measures", [
        row("Hjorth activity",   "hjorth_activity",     3),
        row("Hjorth mobility",   "hjorth_mobility",     3),
        row("Hjorth complexity", "hjorth_complexity",   3),
        row("perm. entropy",     "permutation_entropy", 3),
        row("Higuchi FD",        "higuchi_fd",          3),
        row("DFA exponent",      "dfa_exponent",        3),
        row("sample entropy",    "sample_entropy",      3),
        row("PAC θ-γ",          "pac_theta_gamma",     3),
    ])
    section("Motion & Artifacts", [
        row("stillness",        "stillness",        2),
        row("head pitch",       "head_pitch",       1),
        row("head roll",        "head_roll",        1),
        row("nods",             "nod_count",        0),
        row("head shakes",      "shake_count",      0),
        row("blinks",           "blink_count",      0),
        row("blink rate /min",  "blink_rate",       1),
        row("jaw clenches",     "jaw_clench_count", 0),
        row("jaw clench rate",  "jaw_clench_rate",  1),
    ])
    _print("")
    _print_result(tm)


async def _cmd_sessions(args: Args) -> None:
    """sessions — List all recording sessions."""
    _print(f"{BOLD}⚡ sessions{RESET}")
    r = await _send({"command": "sessions"})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")

    if json_mode:
        _print_result(r)
        return

    lst: list = r.get("sessions", [])
    _print(f"{GREEN}{len(lst)}{RESET} session(s)\n")

    for s in lst:
        dt_e = datetime.fromtimestamp(s["end_utc"])
        hh_e = dt_e.hour % 12 or 12
        end_str = f"{hh_e}:{dt_e.minute:02d}:{dt_e.second:02d} {'AM' if dt_e.hour < 12 else 'PM'}"
        _print(f"  {CYAN}{s['day']}{RESET}  {_fmt_ts(s['start_utc'])} → {end_str}"
               f"  {YELLOW}{_fmt_dur(s['end_utc']-s['start_utc'])}{RESET}"
               f"  {DIM}{s['n_epochs']} epochs{RESET}")

        if args.trends and s.get("n_epochs", 0) >= 4:
            _print_progress(f"  loading trends for {s['day']}…")
            tm = await _send({"command": "session_metrics",
                               "start_utc": s["start_utc"], "end_utc": s["end_utc"]})
            _clear_progress()
            if not tm.get("ok") or not tm.get("metrics"):
                continue
            met = tm["metrics"]
            trd = tm.get("trends", {})
            def arrow(d: str) -> str:
                return f"{GREEN}↑{RESET}" if d == "up" else f"{RED}↓{RESET}" if d == "down" else f"{DIM}→{RESET}"
            tokens = []
            for lbl, mkey, tkey, dec in [
                ("focus","focus","focus",2), ("relax","relaxation","relaxation",2),
                ("hr","hr","hr",1), ("medit","mood","meditation",2),
                ("eng","engagement","engagement",2), ("snr","snr","snr",1),
            ]:
                v = met.get(mkey)
                if v is not None and v != 0:
                    tokens.append(f"{DIM}{lbl}{RESET} {CYAN}{v:.{dec}f}{RESET}{arrow(trd.get(tkey,'flat'))}")
            if tokens:
                _print(f"    {'  '.join(tokens)}")
            bands = [("δ","rel_delta"),("θ","rel_theta"),("α","rel_alpha"),
                     ("β","rel_beta"),("γ","rel_gamma")]
            band_tokens = []
            for sym, key in bands:
                v = met.get(key)
                if v is not None and v != 0:
                    band_tokens.append(f"{DIM}{sym}{RESET} {CYAN}{v*100:.0f}%{RESET}")
            if band_tokens:
                _print(f"    {DIM}bands:{RESET} {'  '.join(band_tokens)}")

    _print("")
    _print_result(r)


async def _cmd_say(args: Args) -> None:
    """say — Speak text aloud via on-device TTS."""
    text = args.text
    if not text:
        _print_error('usage: neuroskill say "text to speak" [--voice <name>]')
    voice_label = f"  {DIM}voice: {CYAN}{args.voice}{RESET}" if args.voice else ""
    _print(f'{BOLD}⚡ say{RESET} {GREEN}"{text}"{RESET}{voice_label}')
    payload: dict = {"command": "say", "text": text}
    if args.voice:
        payload["voice"] = args.voice
    r = await _send(payload)
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    if not json_mode:
        voice_used = f"  {DIM}(voice: {CYAN}{r['voice']}{RESET}{DIM}){RESET}" if r.get("voice") else ""
        _print(f'  {DIM}spoken:{RESET} {GREEN}"{r.get("spoken", text)}"{RESET}{voice_used}')
    _print_result(r)


async def _cmd_notify(args: Args) -> None:
    """notify — Send a native OS notification."""
    title = args.text
    if not title:
        _print_error('usage: neuroskill notify "title" ["body"]')
    body_str = f' {DIM}"{args.body}"{RESET}' if args.body else ""
    _print(f'{BOLD}⚡ notify{RESET} {GREEN}"{title}"{RESET}{body_str}')
    cmd: dict = {"command": "notify", "title": title}
    if args.body:
        cmd["body"] = args.body
    r = await _send(cmd)
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    _print_result(r)


async def _cmd_calibrations(args: Args) -> None:
    """calibrations — List or inspect calibration profiles."""
    sub = args.sub_action or "list"

    if sub == "get":
        if args.id is None:
            _print_error("usage: neuroskill calibrations get <id>")
        _print(f"{BOLD}⚡ calibrations get{RESET} {CYAN}{args.id}{RESET}")
        r = await _send({"command": "get_calibration", "id": args.id})
        if not r.get("ok"):
            _print_error(f"server returned ok=false: {r.get('error')}")
        if not json_mode and r.get("profile"):
            p = r["profile"]
            _print("")
            _print(f"  {BOLD}{p.get('name','(unnamed)')}{RESET}  {DIM}id {p.get('id')}{RESET}")
            if p.get("loop_count") is not None:        _print(f"  {DIM}loop count:{RESET}     {CYAN}{p['loop_count']}{RESET}")
            if p.get("break_duration_secs") is not None: _print(f"  {DIM}break duration:{RESET} {CYAN}{p['break_duration_secs']}s{RESET}")
            if p.get("auto_start") is not None:        _print(f"  {DIM}auto start:{RESET}     {CYAN}{p['auto_start']}{RESET}")
            actions = p.get("actions", [])
            if actions:
                _print(f"  {DIM}actions:{RESET}")
                for i, act in enumerate(actions):
                    name = act if isinstance(act, str) else act.get("name", act.get("label", str(act)))
                    _print(f"    {DIM}{i+1}.{RESET} {CYAN}{name}{RESET}")
            _print("")
        _print_result(r)
        return

    # list
    _print(f"{BOLD}⚡ calibrations{RESET}")
    r = await _send({"command": "list_calibrations"})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    if not json_mode and r.get("profiles"):
        profiles = r["profiles"]
        if not profiles:
            _print(f"  {DIM}no calibration profiles found{RESET}")
        else:
            _print(f"\n  {DIM}{'id':<6} {'name':<30} {'actions':<6} loop{RESET}")
            _print(f"  {DIM}{'─' * 58}{RESET}")
            for p in profiles:
                n_actions = len(p.get("actions", [])) if isinstance(p.get("actions"), list) else "?"
                loops     = str(p.get("loop_count", "–"))
                _print(f"  {CYAN}{str(p.get('id','')):<6}{RESET} {p.get('name',''):<30} {str(n_actions):<6} {loops}")
            _print("")
    _print_result(r)


async def _cmd_calibrate(args: Args) -> None:
    """calibrate — Open calibration window and start a profile."""
    _print(f"{BOLD}⚡ calibrate{RESET}")

    profile_id: Optional[str] = None
    if args.profile:
        lr = await _send({"command": "list_calibrations"})
        if not lr.get("ok"):
            _print_error(f"could not list profiles: {lr.get('error')}")
        profiles = lr.get("profiles", [])
        if not profiles:
            _print_error("no calibration profiles found")
        match = next((p for p in profiles if p.get("id") == args.profile), None)
        if not match:
            match = next((p for p in profiles
                          if args.profile.lower() in p.get("name","").lower()), None)
        if not match:
            names = "\n    ".join(f'"{p.get("name")}" ({p.get("id")})' for p in profiles)
            _print_error(f'profile "{args.profile}" not found.\n  Available:\n    {names}')
        profile_id = match.get("id")
        _print(f"  {DIM}profile:{RESET} {CYAN}{match.get('name')}{RESET}  {DIM}({profile_id}){RESET}")
    else:
        _print(f"  {DIM}profile:{RESET} {DIM}active (server default){RESET}")

    cmd: dict = {"command": "run_calibration"}
    if profile_id:
        cmd["id"] = profile_id
    r = await _send(cmd, 15_000)
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    _print_result(r)


async def _cmd_timer() -> None:
    """timer — Open focus-timer window."""
    _print(f"{BOLD}⚡ timer{RESET}")
    r = await _send({"command": "timer"})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    _print_result(r)


async def _cmd_label(args: Args) -> None:
    """label — Create a timestamped text annotation."""
    text = args.text
    if not text:
        _print_error('usage: neuroskill label "your annotation text"')
    ctx_note = f"  {DIM}(+context){RESET}" if args.context else ""
    at_note  = f"  {DIM}at {datetime.fromtimestamp(args.at).strftime('%-m/%-d/%Y %H:%M:%S')}{RESET}" if args.at else ""
    _print(f'{BOLD}⚡ label{RESET} {GREEN}"{text}"{RESET}{ctx_note}{at_note}')
    payload: dict = {"command": "label", "text": text}
    if args.context:
        payload["context"] = args.context
    if args.at:
        payload["label_start_utc"] = args.at
    r = await _send(payload)
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")
    _print_result(r)


async def _cmd_search_labels(args: Args) -> None:
    """search-labels — Semantic label search."""
    if not args.text:
        _print_error('usage: neuroskill search-labels "your query text"')
    query = args.text
    k     = args.k or 10
    mode  = args.mode or "text"
    if mode not in ("text", "context", "both"):
        _print_error(f'invalid --mode "{mode}": must be text, context, or both')

    _print(f'{BOLD}⚡ search-labels{RESET} {GREEN}"{query}"{RESET}  {DIM}(mode: {mode}, k: {k}){RESET}')
    cmd: dict = {"command": "search_labels", "query": query, "k": k, "mode": mode}
    if args.ef is not None:
        cmd["ef"] = args.ef
    r = await _send(cmd, 30_000)
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")

    if not json_mode:
        results = r.get("results", [])
        _print(f"\n  {DIM}model:{RESET}  {CYAN}{r.get('model','unknown')}{RESET}")
        _print(f"  {DIM}k:{RESET}      {CYAN}{r.get('k')}{RESET}   {DIM}results:{RESET} {GREEN}{r.get('count', len(results))}{RESET}\n")

        if not results:
            _print(f"  {DIM}no results — labels may not be embedded yet{RESET}")
        else:
            for hit in results:
                sim_pct  = f"{hit.get('similarity', 0) * 100:.0f}%"
                dist_str = f"{hit.get('distance', 0):.4f}"
                _print(f"  {BOLD}#{hit.get('label_id')}{RESET}  {GREEN}\"{hit.get('text')}\"{RESET}")
                _print(f"     {DIM}similarity:{RESET} {CYAN}{sim_pct}{RESET}  {DIM}distance:{RESET} {CYAN}{dist_str}{RESET}  {DIM}model:{RESET} {hit.get('embedding_model','?')}")
                _print(f"     {DIM}recorded:{RESET}  {_fmt_ts(hit.get('created_at',0))}  {DIM}({hit.get('eeg_end',0)-hit.get('eeg_start',0)}s window){RESET}")
                if hit.get("context"):
                    preview = hit["context"][:80] + "…" if len(hit["context"]) > 80 else hit["context"]
                    _print(f"     {DIM}context:{RESET}   {preview}")
                eeg = hit.get("eeg_metrics") or {}
                if eeg:
                    parts = [f"{k}={CYAN}{eeg[k]:.2f}{RESET}"
                             for k in ("focus","relaxation","engagement","hr","mood") if k in eeg]
                    if parts:
                        _print(f"     {DIM}eeg:{RESET}       {'  '.join(parts)}")
                _print("")

    _print_result(r)


async def _cmd_interactive(args: Args) -> None:
    """interactive — Cross-modal 4-layer graph search."""
    if not args.keyword:
        _print_error('usage: neuroskill interactive "your keyword"')
    query   = args.keyword
    k_text  = args.k_text  or 5
    k_eeg   = args.k_eeg   or 5
    k_labels = args.k_labels or 3
    reach   = args.reach   or 10

    if not args.dot:
        _print(f'{BOLD}⚡ interactive{RESET} {GREEN}"{query}"{RESET}  '
               f'{DIM}(k-text:{k_text}, k-eeg:{k_eeg}, k-labels:{k_labels}, reach:{reach}m){RESET}')

    r = await _send({
        "command":       "interactive_search",
        "query":         query,
        "k_text":        k_text,
        "k_eeg":         k_eeg,
        "k_labels":      k_labels,
        "reach_minutes": reach,
    }, 60_000)
    if r.get("error"):
        _print_error(f"server returned error: {r['error']}")

    # DOT output
    if args.dot:
        if not r.get("dot"):
            _print_error("server did not return a DOT graph")
        sys.stdout.write(r["dot"] + "\n")
        return

    if not json_mode:
        nodes: list = r.get("nodes", [])
        edges: list = r.get("edges", [])
        text_labels  = [n for n in nodes if n["kind"] == "text_label"]
        eeg_points   = [n for n in nodes if n["kind"] == "eeg_point"]
        found_labels = [n for n in nodes if n["kind"] == "found_label"]
        edge_kinds: Dict[str, int] = {}
        for e in edges:
            edge_kinds[e["kind"]] = edge_kinds.get(e["kind"], 0) + 1

        _print("")
        _print(f"  {BOLD}Graph{RESET}  {CYAN}{len(nodes)}{RESET} node{'s' if len(nodes)!=1 else ''}"
               f" · {CYAN}{len(edges)}{RESET} edge{'s' if len(edges)!=1 else ''}")
        if edge_kinds:
            ek = "  ".join(f"{DIM}{k}{RESET} ×{CYAN}{c}{RESET}" for k, c in edge_kinds.items())
            _print(f"  {DIM}edges:{RESET}  {ek}")
        _print(f"  {DIM}{'─' * 54}{RESET}")

        _print(f"\n  {MAGENTA}●{RESET} {BOLD}query{RESET}  {GREEN}\"{query}\"{RESET}")

        if text_labels:
            _print(f"\n  {BLUE}◆{RESET} {BOLD}Text Labels{RESET}  "
                   f"{DIM}({len(text_labels)} semantically similar {'label' if len(text_labels)==1 else 'labels'}){RESET}")
            for i, n in enumerate(text_labels):
                sim   = (1 - n.get("distance", 1)) * 100
                sim_c = GREEN if n.get("distance",1) < 0.1 else (CYAN if n.get("distance",1) < 0.25 else YELLOW)
                when  = f"  {DIM}{_fmt_ts(n['timestamp_unix'])}{RESET}" if n.get("timestamp_unix") else ""
                _print(f"  {DIM}#{i}{RESET}  {GREEN}\"{n.get('text','?')}\"{RESET}{when}")
                _print(f"      {DIM}similarity:{RESET} {sim_c}{sim:.0f}%{RESET}  {DIM}dist:{RESET} {sim_c}{n.get('distance',0):.4f}{RESET}")
                eeg = n.get("eeg_metrics") or {}
                if eeg:
                    parts = [f"{DIM}{k}{RESET} {CYAN}{eeg[k]:.2f}{RESET}"
                             for k in ("focus","relaxation","engagement","hr","meditation") if isinstance(eeg.get(k), (int,float))]
                    if parts:
                        _print(f"      {'  '.join(parts)}")
        else:
            _print(f"\n  {DIM}No text labels found — annotate moments with `neuroskill label \"...\"` first.{RESET}")

        if eeg_points:
            _print(f"\n  {YELLOW}◈{RESET} {BOLD}EEG Moments{RESET}  "
                   f"{DIM}({len(eeg_points)} neural {'moment' if len(eeg_points)==1 else 'moments'} found){RESET}")
            for i, n in enumerate(eeg_points):
                when   = _fmt_ts(n["timestamp_unix"]) if n.get("timestamp_unix") else "?"
                dist_c = GREEN if n.get("distance",1) < 0.1 else (CYAN if n.get("distance",1) < 0.2 else YELLOW)
                _print(f"  {DIM}#{i}{RESET}  {CYAN}{when}{RESET}   {DIM}dist:{RESET} {dist_c}{n.get('distance',0):.4f}{RESET}  {DIM}← {n.get('parent_id','?')}{RESET}")
        else:
            _print(f"\n  {DIM}No EEG moments found.{RESET}")

        if found_labels:
            _print(f"\n  {GREEN}◉{RESET} {BOLD}Nearby Labels{RESET}  "
                   f"{DIM}({len(found_labels)} {'label' if len(found_labels)==1 else 'labels'} found near EEG moments){RESET}")
            for i, n in enumerate(found_labels):
                when = _fmt_ts(n["timestamp_unix"]) if n.get("timestamp_unix") else "?"
                mins = f"{n.get('distance', 0) * reach:.1f}"
                _print(f"  {DIM}#{i}{RESET}  {GREEN}\"{n.get('text','?')}\"{RESET}   {DIM}{when}  {mins}m from EEG point{RESET}")

        if r.get("dot"):
            _print(f"\n  {DIM}tip: rerun with --dot | dot -Tsvg > graph.svg  to visualize{RESET}")
        _print("")

    _print_result(r)


async def _cmd_search(args: Args) -> None:
    """search — ANN EEG-similarity search."""
    has_explicit = args.start is not None or args.end is not None
    if has_explicit:
        now   = int(time.time())
        start = args.start or now - 600
        end   = args.end   or now
    else:
        start, end = await _auto_range(600)
    k = args.k or 5

    _print(f"{BOLD}⚡ search{RESET}")
    _print_range("range", start, end, not has_explicit)
    _print(f"  {DIM}k:{RESET} {CYAN}{k}{RESET}")
    if not has_explicit:
        _print_rerun(f"search --start {start} --end {end} --k {k}")

    r = await _send({"command": "search", "start_utc": start, "end_utc": end, "k": k})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")

    if not json_mode and r.get("result"):
        res = r["result"]
        a   = res.get("analysis", {})
        all_neighbors = [n for q in res.get("results", []) for n in q.get("neighbors", [])]

        _print("")
        _print(f"  {BOLD}Search Results{RESET}")
        _print(f"  {DIM}query epochs:{RESET} {CYAN}{res.get('query_count')}{RESET}"
               f"   {DIM}searched days:{RESET} {CYAN}{len(res.get('searched_days',[]))}{RESET}"
               f"   {DIM}total matches:{RESET} {CYAN}{len(all_neighbors)}{RESET}"
               + (f"   {DIM}span:{RESET} {CYAN}{a['time_span_hours']:.1f}h{RESET}" if a.get("time_span_hours") else ""))

        if a.get("distance_stats"):
            d = a["distance_stats"]
            sim_pct = max(0, min(100, round((1 - d.get("mean", 1)) * 100)))
            _print(f"\n  {BOLD}Match Quality{RESET}  {DIM}(cosine distance — lower = more similar){RESET}")
            _print(f"  {_progress_bar(sim_pct, 24)}  {DIM}similarity{RESET} {CYAN}{sim_pct}%{RESET}")
            _print(f"  {DIM}min{RESET} {CYAN}{d.get('min')}{RESET}"
                   f"   {DIM}mean{RESET} {CYAN}{d.get('mean')}{RESET}"
                   f"   {DIM}max{RESET} {CYAN}{d.get('max')}{RESET}"
                   f"   {DIM}σ{RESET} {CYAN}{d.get('stddev')}{RESET}")

        # Neighbour metrics — full table matching TypeScript cmdSearch
        METRIC_DEFS = [
            ("focus",          "focus",          2),
            ("relaxation",     "relaxation",     2),
            ("engagement",     "engagement",     2),
            ("meditation",     "meditation",     2),
            ("mood",           "mood",           2),
            ("cognitive load", "cognitive_load", 2),
            ("drowsiness",     "drowsiness",     2),
            ("hr (bpm)",       "hr",             1),
            ("snr (dB)",       "snr",            1),
            ("α alpha",        "rel_alpha",      2),
            ("β beta",         "rel_beta",       2),
            ("θ theta",        "rel_theta",      2),
            ("FAA",            "faa",            3),
            ("θ/α ratio",      "tar",            3),
        ]
        # Build min/max ranges from individual neighbor records
        ranges: Dict[str, Dict[str, float]] = {}
        for nb in all_neighbors:
            met = nb.get("metrics") or {}
            for _, key, _ in METRIC_DEFS:
                v = met.get(key)
                if v is None:
                    continue
                try:
                    fv = float(v)
                except (TypeError, ValueError):
                    continue
                if key not in ranges:
                    ranges[key] = {"min": fv, "max": fv}
                else:
                    ranges[key]["min"] = min(ranges[key]["min"], fv)
                    ranges[key]["max"] = max(ranges[key]["max"], fv)

        nm = a.get("neighbor_metrics", {})
        present_metrics = [(lbl, key, dec) for lbl, key, dec in METRIC_DEFS if nm.get(key) is not None]
        if present_metrics:
            _print(f"\n  {BOLD}Neighbor Metrics{RESET}  {DIM}(avg · min–max across {len(all_neighbors)} matches){RESET}")
            for lbl, key, dec in present_metrics:
                try:
                    avg = float(nm[key])
                except (TypeError, ValueError):
                    continue
                rng = ""
                if key in ranges:
                    rng = f"  {DIM}{ranges[key]['min']:.{dec}f} – {ranges[key]['max']:.{dec}f}{RESET}"
                _print(f"  {DIM}{lbl:<18}{RESET} {CYAN}{avg:>7.{dec}f}{RESET}{rng}")

        # Top 5 matches
        top = sorted(all_neighbors, key=lambda n: n.get("distance", 1))[:5]
        if top:
            _print(f"\n  {BOLD}Top Matches{RESET}  {DIM}(closest by cosine distance){RESET}")
            for i, n in enumerate(top):
                when    = _fmt_ts(n.get("timestamp_unix", 0))
                d       = n.get("distance", 1)
                dist_c  = GREEN if d < 0.1 else (CYAN if d < 0.2 else YELLOW)
                line    = f"  {DIM}#{i+1}{RESET}  {CYAN}{when}{RESET}  {DIM}dist{RESET} {dist_c}{d:.4f}{RESET}"
                met     = n.get("metrics", {}) or {}
                parts   = []
                if met.get("focus")      is not None: parts.append(f"focus {CYAN}{met['focus']:.2f}{RESET}")
                if met.get("relaxation") is not None: parts.append(f"relax {CYAN}{met['relaxation']:.2f}{RESET}")
                if met.get("hr")         is not None: parts.append(f"hr {CYAN}{met['hr']:.1f}{RESET}")
                if parts: line += "   " + "  ".join(parts)
                lbls = n.get("labels", [])
                if lbls:
                    label_str = ", ".join(f'"{l["text"]}"' for l in lbls if isinstance(l, dict))
                    if label_str: line += f"   {DIM}{label_str}{RESET}"
                _print(line)

        # Temporal distribution
        hour_dist = a.get("temporal_distribution", {})
        if hour_dist:
            entries = sorted([(int(h), c) for h, c in hour_dist.items()])
            max_c   = max((c for _, c in entries), default=1)
            _print(f"\n  {BOLD}Temporal Distribution{RESET}  {DIM}(matches by hour of day, UTC){RESET}")
            for h in range(12):
                left  = next(((hr, c) for hr, c in entries if hr == h), None)
                right = next(((hr, c) for hr, c in entries if hr == h + 12), None)
                def fmt_bar(entry: Optional[Tuple[int,int]]) -> str:
                    if not entry: return " " * 32
                    hr, cnt = entry
                    length  = round(cnt / max_c * 12)
                    bar     = f"{BLUE}{'█'*length}{DIM}{'░'*(12-length)}{RESET}"
                    return f"{DIM}{hr:2}:00{RESET} {bar} {CYAN}{cnt:4}{RESET}"
                _print(f"  {fmt_bar(left)}    {fmt_bar(right)}")

        top_days = a.get("top_days", [])
        if top_days:
            days = "   ".join(f"{CYAN}{d}{RESET} {DIM}({c}){RESET}" for d, c in top_days)
            _print(f"\n  {DIM}top days:{RESET}  {days}")

        _print("")

    _print_result(r)


async def _cmd_compare(args: Args) -> None:
    """compare — Side-by-side A/B session comparison."""
    has_explicit = any(x is not None for x in (args.a_start, args.a_end, args.b_start, args.b_end))
    if has_explicit:
        now    = int(time.time())
        a_s    = args.a_start or now - 7200
        a_e    = args.a_end   or now - 3600
        b_s    = args.b_start or now - 3600
        b_e    = args.b_end   or now
    else:
        a_s, a_e, b_s, b_e = await _auto_range_ab()

    _print(f"{BOLD}⚡ compare{RESET}")
    _print_range("A", a_s, a_e, not has_explicit)
    _print_range("B", b_s, b_e, not has_explicit)
    if not has_explicit:
        _print_rerun(f"compare --a-start {a_s} --a-end {a_e} --b-start {b_s} --b-end {b_e}")

    r = await _send({"command":"compare",
                     "a_start_utc":a_s,"a_end_utc":a_e,
                     "b_start_utc":b_s,"b_end_utc":b_e})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")

    if not json_mode and r.get("insights"):
        ins = r["insights"]
        _print("")
        _print(f"  {BOLD}Compare Insights{RESET}  {DIM}({ins.get('n_epochs_a')} vs {ins.get('n_epochs_b')} epochs){RESET}")

        deltas = ins.get("deltas", {})
        if deltas:
            _print(f"\n  {'metric':<18} {'A':>8} {'B':>8} {'Δ':>8} {'Δ%':>7}  dir")
            _print(f"  {DIM}{'─'*60}{RESET}")
            for m in ["focus","relaxation","engagement","meditation","hr","drowsiness","mood","snr","stillness","cognitive_load"]:
                d = deltas.get(m)
                if not d: continue
                arrow = (f"{GREEN}↑{RESET}" if d.get("direction") == "up"
                         else f"{RED}↓{RESET}" if d.get("direction") == "down"
                         else f"{DIM}→{RESET}")
                dp    = d.get("pct", 0)
                pct_s = f"+{dp:.1f}%" if dp > 0 else f"{dp:.1f}%"
                ab    = d.get("abs", 0)
                _print(f"  {m:<18} {CYAN}{(d.get('a') or 0):>8.2f}{RESET}"
                       f" {CYAN}{(d.get('b') or 0):>8.2f}{RESET}"
                       f" {('+' if ab >= 0 else '')}{ab:>7.2f} {pct_s:>7}  {arrow}")

        if ins.get("improved"):
            _print(f"\n  {GREEN}▲ improved:{RESET} {', '.join(ins['improved'])}")
        if ins.get("declined"):
            _print(f"  {RED}▼ declined:{RESET} {', '.join(ins['declined'])}")
        _print("")

    _print_result(r)


async def _cmd_sleep(args: Args) -> None:
    """sleep — Sleep staging."""
    has_explicit = args.start is not None or args.end is not None
    has_index    = args.session_index is not None
    range_default = False

    if has_explicit:
        now   = int(time.time())
        start = args.start or now - 28800
        end   = args.end   or now
    elif has_index:
        sessions = await _get_sessions()
        idx = args.session_index
        if not sessions:
            _print_error("no sessions recorded yet")
        if idx >= len(sessions):
            _print_error(f"session index {idx} out of range — only {len(sessions)} session(s) available")
        s = sessions[idx]
        start, end = s["start_utc"], s["end_utc"]
    else:
        range_default = True
        sessions = await _get_sessions()
        now = int(time.time())
        cutoff = now - 86400
        recent = [s for s in sessions if s["end_utc"] > cutoff]
        if recent:
            start = recent[-1]["start_utc"]
            end   = recent[0]["end_utc"]
        elif sessions:
            start, end = sessions[0]["start_utc"], sessions[0]["end_utc"]
        else:
            start, end = now - 28800, now

    idx_label = f"  {DIM}[session {args.session_index}]{RESET}" if has_index else ""
    _print(f"{BOLD}⚡ sleep{RESET}{idx_label}")
    _print_range("range", start, end, range_default)
    if range_default:
        _print_rerun(f"sleep --start {start} --end {end}")

    r = await _send({"command": "sleep", "start_utc": start, "end_utc": end})
    if not r.get("ok"):
        _print_error(f"server returned ok=false: {r.get('error')}")

    if not json_mode and r.get("summary"):
        s     = r["summary"]
        total = s.get("total_epochs", 0)
        eps   = s.get("epoch_secs", 5)
        def pct(n: int) -> str:
            return f" {DIM}({n/max(total,1)*100:.1f}%){RESET}"
        _print("")
        _print(f"  {BOLD}Sleep Summary{RESET}")
        _print(f"  {DIM}total:{RESET} {CYAN}{total}{RESET} epochs ({CYAN}{total*eps//60}{RESET} min)")
        _print(f"  {GREEN}Wake{RESET}  {s.get('wake_epochs',0)}{pct(s.get('wake_epochs',0))}")
        _print(f"  {YELLOW}N1{RESET}    {s.get('n1_epochs',0)}{pct(s.get('n1_epochs',0))}")
        _print(f"  {BLUE}N2{RESET}    {s.get('n2_epochs',0)}{pct(s.get('n2_epochs',0))}")
        _print(f"  {MAGENTA}N3{RESET}    {s.get('n3_epochs',0)}{pct(s.get('n3_epochs',0))}")
        _print(f"  {RED}REM{RESET}   {s.get('rem_epochs',0)}{pct(s.get('rem_epochs',0))}")

    if not json_mode and r.get("analysis"):
        a = r["analysis"]
        _print("")
        _print(f"  {BOLD}Sleep Analysis{RESET}")
        if a.get("efficiency_pct")    is not None: _print(f"  {DIM}efficiency:{RESET}    {CYAN}{a['efficiency_pct']:.1f}%{RESET}")
        if a.get("onset_latency_min") is not None: _print(f"  {DIM}onset latency:{RESET} {CYAN}{a['onset_latency_min']:.1f}{RESET} min")
        if a.get("rem_latency_min")   is not None: _print(f"  {DIM}REM latency:{RESET}   {CYAN}{a['rem_latency_min']:.1f}{RESET} min")
        _print(f"  {DIM}transitions:{RESET}   {CYAN}{a.get('transitions')}{RESET}  {DIM}awakenings:{RESET} {CYAN}{a.get('awakenings')}{RESET}")
        if a.get("stage_minutes"):
            sm = a["stage_minutes"]
            _print(f"\n  {DIM}Stage durations:{RESET} Wake {CYAN}{sm.get('wake')}m{RESET}  N1 {CYAN}{sm.get('n1')}m{RESET}  N2 {CYAN}{sm.get('n2')}m{RESET}  N3 {CYAN}{sm.get('n3')}m{RESET}  REM {CYAN}{sm.get('rem')}m{RESET}")
        if a.get("bouts"):
            _print(f"\n  {DIM}Bout analysis:{RESET}")
            for stage, b in a["bouts"].items():
                _print(f"    {stage:<6} {CYAN}{b.get('count')}{RESET} bouts  avg {CYAN}{b.get('mean_min',0):.1f}m{RESET}  max {CYAN}{b.get('max_min',0):.1f}m{RESET}")

    if not json_mode:
        _print("")
    _print_result(r)


async def _cmd_umap(args: Args) -> None:
    """umap — 3D UMAP projection with polling."""
    has_explicit = any(x is not None for x in (args.a_start, args.a_end, args.b_start, args.b_end))
    if has_explicit:
        now = int(time.time())
        SIX_H = 6 * 3600
        a_s = args.a_start or now - SIX_H
        a_e = args.a_end   or now - SIX_H // 2
        b_s = args.b_start or now - SIX_H // 2
        b_e = args.b_end   or now
    else:
        a_s, a_e, b_s, b_e = await _auto_range_ab()

    _print(f"{BOLD}⚡ umap{RESET}")
    _print_range("A", a_s, a_e, not has_explicit)
    _print_range("B", b_s, b_e, not has_explicit)
    if not has_explicit:
        _print_rerun(f"umap --a-start {a_s} --a-end {a_e} --b-start {b_s} --b-end {b_e}")

    # Enqueue
    enq = await _send({
        "command": "umap",
        "a_start_utc": a_s, "a_end_utc": a_e,
        "b_start_utc": b_s, "b_end_utc": b_e,
    }, 30_000)
    if not enq.get("ok"):
        _print_error(f"enqueue failed: {enq.get('error')}")
    job_id = enq.get("job_id")
    if job_id is None:
        _print_error("no job_id returned")
    _print_info(f"enqueued job_id={job_id}  n_a={enq.get('n_a')}  n_b={enq.get('n_b')}  est={enq.get('estimated_secs')}s")

    # Poll
    POLL_TIMEOUT = 300.0
    poll_start   = time.monotonic()
    result: Optional[dict] = None

    while time.monotonic() - poll_start < POLL_TIMEOUT:
        await asyncio.sleep(2)
        try:
            poll = await _send({"command": "umap_poll", "job_id": job_id}, 60_000)
        except Exception:
            elapsed = time.monotonic() - poll_start
            _print_progress(f"⏳ waiting for GPU… {elapsed:.0f}s elapsed")
            continue

        status = poll.get("status")
        if status == "complete":
            _clear_progress()
            result = poll
            break
        if status == "error":
            _clear_progress()
            _print_error(f"UMAP job error: {poll.get('error')}")
        if status == "not_found":
            _clear_progress()
            _print_error(f"job {job_id} not found")

        p = poll.get("progress", {})
        elapsed = time.monotonic() - poll_start
        if p and p.get("total_epochs", 0) > 0:
            pct = round(p["epoch"] / p["total_epochs"] * 100)
            bar = _progress_bar(pct, 30)
            eta = (p["total_epochs"] - p["epoch"]) * p["epoch_ms"] / 1000 if p.get("epoch_ms") else 0
            _print_progress(f"{bar} {pct}%  epoch {p['epoch']}/{p['total_epochs']}  {p.get('epoch_ms',0):.0f}ms/ep  ~{eta:.0f}s left")
        else:
            _print_progress(f"⏳ initializing… {elapsed:.0f}s")

    if not result:
        _clear_progress()
        _print_error(f"UMAP timed out after {POLL_TIMEOUT:.0f}s")

    _print_info(f"completed in {result.get('elapsed_ms')}ms")

    umap_result = result.get("result") or result
    if not json_mode and umap_result.get("analysis"):
        a = umap_result["analysis"]
        _print("")
        _print(f"  {BOLD}UMAP Cluster Analysis{RESET}")
        if a.get("separation_score")       is not None: _print(f"  {DIM}separation score:{RESET} {CYAN}{a['separation_score']:.2f}{RESET}  {DIM}(higher = better A/B separation){RESET}")
        if a.get("inter_cluster_distance") is not None: _print(f"  {DIM}inter-cluster:{RESET}    {CYAN}{a['inter_cluster_distance']:.2f}{RESET}")
        if a.get("intra_spread_a")         is not None: _print(f"  {DIM}intra-spread A:{RESET}   {CYAN}{a['intra_spread_a']:.2f}{RESET}  {DIM}B:{RESET} {CYAN}{a.get('intra_spread_b',0):.2f}{RESET}")
        ca, cb = a.get("centroid_a"), a.get("centroid_b")
        if ca and cb:
            fmt_pt = lambda p: f"({', '.join(f'{v:.2f}' for v in p)})"
            _print(f"  {DIM}centroid A:{RESET} {fmt_pt(ca)}  {DIM}B:{RESET} {fmt_pt(cb)}")
        n_out = (a.get("n_outliers_a") or 0) + (a.get("n_outliers_b") or 0)
        if n_out:
            _print(f"  {YELLOW}outliers:{RESET} {a.get('n_outliers_a')} in A, {a.get('n_outliers_b')} in B")
        _print("")

    _print_result(result)


async def _cmd_listen(args: Args) -> None:
    """listen — Collect broadcast events for N seconds."""
    assert _client is not None
    if _client.transport == "http":
        _print_error(
            "listen requires WebSocket (HTTP has no push events).\n"
            "  Use --ws to force WebSocket, or omit --http for auto-transport."
        )
    seconds = args.seconds or 5
    _print(f"{BOLD}⚡ listen{RESET} {DIM}for {seconds}s…{RESET}\n")

    # Live countdown
    remaining = [seconds]
    async def _tick() -> None:
        while remaining[0] > 0:
            await asyncio.sleep(1)
            remaining[0] -= 1
            if remaining[0] > 0:
                _print_progress(f"⏳ {remaining[0]}s remaining…")
    tick_task = asyncio.get_running_loop().create_task(_tick())

    events = await _client.collect_events(seconds)
    tick_task.cancel()
    _clear_progress()

    if json_mode:
        _print_result(events)
        return

    if not events:
        _print(f"  {DIM}no events received (is a Muse connected?){RESET}")
        return

    by_type: Dict[str, int] = {}
    for e in events:
        by_type[e.get("event", "unknown")] = by_type.get(e.get("event", "unknown"), 0) + 1
    for etype, count in by_type.items():
        _print(f"  {CYAN}{etype}{RESET} {DIM}×{count}{RESET}")
    _print("")
    _print_result(events)


async def _cmd_raw(args: Args) -> None:
    """raw — Send arbitrary JSON and print the response."""
    if not args.raw_json:
        _print_error("usage: neuroskill raw '{\"command\":\"status\"}'")
    try:
        cmd = json.loads(args.raw_json)
    except Exception:
        _print_error(f"invalid JSON: {args.raw_json}")
    if "command" not in cmd:
        _print_error('JSON must have a "command" field')
    _print(f'{BOLD}⚡ raw{RESET} {DIM}{cmd["command"]}{RESET}')
    r = await _send(cmd, 60_000)
    _print_result(r)


# ── Main ──────────────────────────────────────────────────────────────────────

async def _async_main() -> None:
    global _client, json_mode, full_mode, no_color_mode

    args = _parse_args()
    json_mode    = args.json
    full_mode    = args.full
    no_color_mode = no_color_mode or args.no_color or bool(os.environ.get("NO_COLOR"))

    if no_color_mode or json_mode:
        _apply_no_color()

    if args.command == "version":
        print(f"neuroskill {CLI_VERSION}")
        sys.exit(0)

    if args.command == "help" or not args.command:
        _show_help()

    # Initialize client
    _client = SkillClient()

    port = await _discover(args.port)
    _client.http_base = f"http://127.0.0.1:{port}"

    if args.http:
        _client.transport = "http"
        _print_info(f"transport: HTTP {_client.http_base}")
    elif args.ws:
        _client.transport = "ws"
        for attempt in range(1, 4):
            try:
                await _client.connect_ws(port)
                _print_info(f"transport: WebSocket ws://127.0.0.1:{port}")
                break
            except Exception as exc:
                if attempt >= 3:
                    _print_error(f"failed to connect after 3 attempts: {exc}")
                await asyncio.sleep(1)
    else:
        # Auto-transport: try WebSocket first, fall back to HTTP
        _print_info("auto-transport: probing WebSocket…")
        ok = await _try_connect_once(port)
        if ok:
            _client.transport = "ws"
            _client._recv_task = asyncio.get_running_loop().create_task(_client._recv_loop())
            _print_info(f"transport: WebSocket ws://127.0.0.1:{port}")
        else:
            _client.transport = "http"
            _print_info(f"WebSocket unavailable — transport: HTTP {_client.http_base}")

    try:
        cmd = args.command
        if   cmd == "status":        await _cmd_status(args)
        elif cmd == "session":       await _cmd_session(args)
        elif cmd == "sessions":      await _cmd_sessions(args)
        elif cmd == "say":           await _cmd_say(args)
        elif cmd == "notify":        await _cmd_notify(args)
        elif cmd == "calibrations":  await _cmd_calibrations(args)
        elif cmd == "calibrate":     await _cmd_calibrate(args)
        elif cmd == "timer":         await _cmd_timer()
        elif cmd == "label":         await _cmd_label(args)
        elif cmd == "search-labels": await _cmd_search_labels(args)
        elif cmd == "interactive":   await _cmd_interactive(args)
        elif cmd == "search":        await _cmd_search(args)
        elif cmd == "compare":       await _cmd_compare(args)
        elif cmd == "sleep":         await _cmd_sleep(args)
        elif cmd == "umap":          await _cmd_umap(args)
        elif cmd == "listen":        await _cmd_listen(args)
        elif cmd == "raw":           await _cmd_raw(args)
        else:
            _print_error(
                f'unknown command: "{cmd}". Run with --help to see available commands.'
            )
    finally:
        await _client.close()


def main() -> None:
    """Entry point — runs the async main loop."""
    try:
        asyncio.run(_async_main())
    except KeyboardInterrupt:
        if not json_mode:
            print(f"\n{DIM}interrupted{RESET}", file=sys.stderr)
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as exc:
        _print_error(str(exc))
