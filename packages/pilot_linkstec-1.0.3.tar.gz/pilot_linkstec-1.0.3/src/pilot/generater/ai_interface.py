from abc import ABC, abstractmethod
from typing import Dict, Any


class AIInterface(ABC):
    @abstractmethod
    def generate_content(self, prompt: str) -> Dict[str, Any]:
        pass