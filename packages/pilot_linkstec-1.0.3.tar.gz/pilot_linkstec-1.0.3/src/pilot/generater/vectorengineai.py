import os
import threading
from typing import Dict, Any, Optional
from pilot.generater.ai_base import AIBase

import requests


class VectorEngineAISingleton(AIBase):
    _instance: Optional['VectorEngineAISingleton'] = None
    _lock = threading.Lock()

    def __new__(cls, model_name: str, base_url: str):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(VectorEngineAISingleton, cls).__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self, model_name: str, base_url: str):
        if not self._initialized:
            with self._lock:
                if not self._initialized:
                    self.model_name = model_name
                    # 假设传入的 base_url 是 "https://api.vectorengine.ai" 或包含 "/v1beta"
                    # 这里确保 url 拼接的正确性
                    self.base_url = base_url.rstrip('/')

                    # 从系统环境变量获取 api_key
                    self.api_key = os.environ.get("vector_key")
                    if not self.api_key:
                        raise ValueError("环境变量 'vector_key' 未设置，请在运行前配置该环境变量。")

                    # 初始化 Session 并设置全局 Headers (包含身份验证)
                    self._session = requests.Session()
                    self._session.headers.update({
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self.api_key}"
                    })

                    self._initialized = True

    def generate_content(self, prompt: str, reasoning: str = "") -> Dict[str, Any]:
        """複数スレッドから安全に呼び出し可能"""
        try:
            # 构建基础的 Payload 结构 (Gemini 格式)
            payload = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": prompt}]
                    }
                ],
                "generationConfig": {
                    "temperature": 1,
                    "topP": 1,
                    "maxOutputTokens": 65532
                #    "thinkingConfig": {
                #        "includeThoughts": True,
                #        "thinkingBudget": 26240
                #    }
                }
            }

            # 如果传入了 reasoning 参数，将其作为 System Instruction
            #if reasoning:
            #    payload["systemInstruction"] = {
            #        "parts": [{"text": reasoning}]
            #    }

            # 模型名称现在是 URL 路径的一部分
            # 例如: https://api.vectorengine.ai/v1beta/models/gemini-2.5-pro:generateContent
            api_endpoint = f"{self.base_url}/v1beta/models/{self.model_name}:generateContent"

            resp = self._session.post(
                api_endpoint,
                json=payload,
                timeout=600
            )
            resp.raise_for_status()
            data = resp.json()

            # 解析 Gemini 格式的返回值
            # 考虑到 includeThoughts=True，可能会返回多个 part，这里将它们拼接起来
            content_parts = data["candidates"][0]["content"]["parts"]
            content = "".join([part.get("text", "") for part in content_parts])

            return {
                "prompt": prompt,
                "response": self._remove_code_fence(content),
                "success": True,
                "error": None
            }

        except Exception as e:
            return {
                "prompt": prompt,
                "response": None,
                "success": False,
                "error": str(e)
            }

    def start_chat(self):
        """
        VertexAI の ChatSession と完全互換は不可能だが、
        既存コードを壊さないために「退化実装」を提供
        """
        return _VectorEngineChatSession(self)

    def count_tokens(self, text: str) -> int:
        return 1

    def _remove_code_fence(self, text: str) -> str:
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        return "\n".join(lines)

    @classmethod
    def get_instance(cls, model_name: str, base_url: str) -> 'VectorEngineAISingleton':
        return cls(model_name, base_url)


class _VectorEngineChatSession:
    """
    VertexAI ChatSession の「最低限互換」
    """

    def __init__(self, client: VectorEngineAISingleton):
        self._client = client
        self._messages = []

    def send_message(self, message: str):
        # 添加用户的消息 (Gemini 格式)
        self._messages.append({
            "role": "user",
            "parts": [{"text": message}]
        })

        payload = {
            "contents": self._messages,
            "generationConfig": {
                "temperature": 1,
                "topP": 1,
                "thinkingConfig": {
                    "includeThoughts": True,
                    "thinkingBudget": 26240
                }
            }
        }

        api_endpoint = f"{self._client.base_url}/v1beta/models/{self._client.model_name}:generateContent"

        resp = self._client._session.post(
            api_endpoint,
            json=payload,
            timeout=60
        )
        resp.raise_for_status()
        data = resp.json()

        # 解析回复
        content_parts = data["candidates"][0]["content"]["parts"]
        reply = "".join([part.get("text", "") for part in content_parts])

        # 将助手的回复加入历史记录
        # 注意：在类似 Gemini 的接口中，助手的 role 通常是 "model" 而不是 "assistant"
        self._messages.append({
            "role": "model",
            "parts": [{"text": reply}]
        })

        class _Resp:
            def __init__(self, text):
                self.text = text

        return _Resp(reply)