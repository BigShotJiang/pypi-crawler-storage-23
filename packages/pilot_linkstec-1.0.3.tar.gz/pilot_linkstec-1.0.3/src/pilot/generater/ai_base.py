from typing import Dict, Any

from pilot.generater.ai_interface import AIInterface

class AIBase(AIInterface):
    def generate_content(self, prompt: str) -> Dict[str, Any]:
        pass