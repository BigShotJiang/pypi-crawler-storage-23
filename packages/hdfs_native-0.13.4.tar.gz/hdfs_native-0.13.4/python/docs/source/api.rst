API
===

.. automodapi:: hdfs_native
   :no-inheritance-diagram: