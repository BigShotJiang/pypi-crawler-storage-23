FileWriter
==========

.. currentmodule:: hdfs_native

.. autoclass:: FileWriter
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~FileWriter.close
      ~FileWriter.writable
      ~FileWriter.write

   .. rubric:: Methods Documentation

   .. automethod:: close
   .. automethod:: writable
   .. automethod:: write
