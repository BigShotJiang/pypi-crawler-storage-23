AsyncFileWriter
===============

.. currentmodule:: hdfs_native

.. autoclass:: AsyncFileWriter
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~AsyncFileWriter.close
      ~AsyncFileWriter.writable
      ~AsyncFileWriter.write

   .. rubric:: Methods Documentation

   .. automethod:: close
   .. automethod:: writable
   .. automethod:: write
