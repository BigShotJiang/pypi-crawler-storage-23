"""Diagrid CLI commands."""
