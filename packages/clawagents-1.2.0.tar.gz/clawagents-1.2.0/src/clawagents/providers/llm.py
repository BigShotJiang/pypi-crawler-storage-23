from typing import Literal, Callable, Coroutine, Any, AsyncGenerator
from abc import ABC, abstractmethod

from openai import AsyncOpenAI
from google import genai
from google.genai import types

from clawagents.config.config import EngineConfig


class LLMMessage:
    def __init__(self, role: Literal["system", "user", "assistant"], content: str):
        self.role = role
        self.content = content


class LLMResponse:
    def __init__(self, content: str, model: str, tokens_used: int):
        self.content = content
        self.model = model
        self.tokens_used = tokens_used


class LLMProvider(ABC):
    name: str

    @abstractmethod
    async def chat(
        self,
        messages: list[LLMMessage],
        on_chunk: Callable[[str], Coroutine[Any, Any, None]] | Callable[[str], None] | None = None
    ) -> LLMResponse:
        pass


# ─── OpenAI Provider ───────────────────────────────────────────────────────

class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(self, config: EngineConfig):
        self.client = AsyncOpenAI(api_key=config.openai_api_key)
        self.model = config.openai_model

    async def chat(
        self,
        messages: list[LLMMessage],
        on_chunk: Callable[[str], Coroutine[Any, Any, None]] | Callable[[str], None] | None = None
    ) -> LLMResponse:
        formatted_messages = [{"role": m.role, "content": m.content} for m in messages]

        if not on_chunk:
            # Non-streaming fallback
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=formatted_messages,
            )
            return LLMResponse(
                content=response.choices[0].message.content or "",
                model=self.model,
                tokens_used=response.usage.total_tokens if response.usage else 0,
            )

        # Streaming implementation
        response_stream = await self.client.chat.completions.create(
            model=self.model,
            messages=formatted_messages,
            stream=True,
            stream_options={"include_usage": True},
        )

        full_content = ""
        final_tokens = 0

        async for chunk in response_stream:
            if len(chunk.choices) > 0 and chunk.choices[0].delta.content:
                text_chunk = chunk.choices[0].delta.content
                full_content += text_chunk
                # Handle both async and sync callbacks
                import asyncio
                if asyncio.iscoroutinefunction(on_chunk):
                    await on_chunk(text_chunk)
                else:
                    on_chunk(text_chunk)
            
            if chunk.usage:
                final_tokens = chunk.usage.total_tokens

        return LLMResponse(
            content=full_content,
            model=self.model,
            tokens_used=final_tokens,
        )


# ─── Gemini Provider ───────────────────────────────────────────────────────

class GeminiProvider(LLMProvider):
    name = "gemini"

    def __init__(self, config: EngineConfig):
        self.client = genai.Client(api_key=config.gemini_api_key)
        self.model = config.gemini_model

    async def chat(
        self,
        messages: list[LLMMessage],
        on_chunk: Callable[[str], Coroutine[Any, Any, None]] | Callable[[str], None] | None = None
    ) -> LLMResponse:
        
        system_instruction = "\n".join([m.content for m in messages if m.role == "system"])
        user_messages = "\n\n".join([m.content for m in messages if m.role != "system"])

        config_opts = {}
        if system_instruction:
            config_opts["system_instruction"] = system_instruction
            
        gemini_config = types.GenerateContentConfig(**config_opts)

        if not on_chunk:
            response = await self.client.aio.models.generate_content(
                model=self.model,
                contents=user_messages,
                config=gemini_config
            )
            return LLMResponse(
                content=response.text or "",
                model=self.model,
                tokens_used=response.usage_metadata.candidates_token_count if response.usage_metadata else 0,
            )

        stream = await self.client.aio.models.generate_content_stream(
            model=self.model,
            contents=user_messages,
            config=gemini_config
        )
        
        full_content = ""
        final_tokens = 0

        async for chunk in stream:
            if chunk.text:
                full_content += chunk.text
                import asyncio
                if asyncio.iscoroutinefunction(on_chunk):
                    await on_chunk(chunk.text)
                else:
                    on_chunk(chunk.text)
            
            if chunk.usage_metadata:
                final_tokens = chunk.usage_metadata.candidates_token_count

        return LLMResponse(
            content=full_content,
            model=self.model,
            tokens_used=final_tokens,
        )


# ─── Factory ───────────────────────────────────────────────────────────────

def create_provider(config: EngineConfig) -> LLMProvider:
    if config.get_provider() == "gemini":
        return GeminiProvider(config)
    return OpenAIProvider(config)
