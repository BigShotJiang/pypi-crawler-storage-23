import json
import re
from typing import Any, Dict, Optional, Protocol, List

class ToolResult:
    def __init__(self, success: bool, output: str, error: Optional[str] = None):
        self.success = success
        self.output = output
        self.error = error

class Tool(Protocol):
    name: str
    description: str
    parameters: Dict[str, Dict[str, Any]]

    async def execute(self, args: Dict[str, Any]) -> ToolResult:
        ...

class ToolRegistry:
    def __init__(self):
        self.tools: Dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self.tools[tool.name] = tool

    def get(self, name: str) -> Optional[Tool]:
        return self.tools.get(name)

    def list(self) -> List[Tool]:
        return list(self.tools.values())

    def describe_for_llm(self) -> str:
        tools = self.list()
        if not tools:
            return ""

        desc = "## Available Tools\n\nYou can use the following tools by responding with a JSON block like:\n```json\n{\"tool\": \"tool_name\", \"args\": {\"param\": \"value\"}}\n```\n\n"

        for tool in tools:
            desc += f"### {tool.name}\n{tool.description}\n"
            params = tool.parameters
            if params:
                desc += "Parameters:\n"
                for name, info in params.items():
                    req = " (required)" if info.get("required") else ""
                    desc += f"- `{name}` ({info.get('type')}{req}): {info.get('description')}\n"
            desc += "\n"

        return desc

    def parse_tool_call(self, response: str) -> Optional[Dict[str, Any]]:
        # Try to find a JSON block in the response
        json_match = re.search(r"```(?:json)?\s*\n?([\s\S]*?)\n?\s*```", response)
        if json_match:
            try:
                parsed = json.loads(json_match.group(1))
                if isinstance(parsed, dict) and "tool" in parsed and isinstance(parsed["tool"], str):
                    return {"toolName": parsed["tool"], "args": parsed.get("args") or {}}
            except json.JSONDecodeError:
                pass

        # Also try direct JSON (no code fence)
        try:
            parsed = json.loads(response.strip())
            if isinstance(parsed, dict) and "tool" in parsed and isinstance(parsed["tool"], str):
                return {"toolName": parsed["tool"], "args": parsed.get("args") or {}}
        except json.JSONDecodeError:
            pass

        return None

    async def execute_tool(self, tool_name: str, args: Dict[str, Any]) -> ToolResult:
        tool = self.get(tool_name)
        if not tool:
            return ToolResult(success=False, output="", error=f"Unknown tool: {tool_name}")
        try:
            return await tool.execute(args)
        except Exception as err:
            return ToolResult(success=False, output="", error=f"Tool error: {str(err)}")
