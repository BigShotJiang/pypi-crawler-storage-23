from typing import List, Literal, Optional
from dataclasses import dataclass, field
import json
import sys

from clawagents.providers.llm import LLMProvider, LLMMessage
from clawagents.tools.registry import ToolRegistry


AgentStatus = Literal["understanding", "acting", "verifying", "done", "error"]

@dataclass
class AgentState:
    messages: List[LLMMessage]
    current_task: str
    status: AgentStatus
    result: str
    iterations: int
    max_iterations: int
    tool_calls: int


BASE_SYSTEM_PROMPT = """You are a ClawAgent, an AI assistant that helps users accomplish tasks using tools. You respond with text and tool calls.

## Core Behavior
- Be concise and direct. Don't over-explain unless asked.
- NEVER add unnecessary preamble ("Sure!", "Great question!", "I'll now...").
- If the request is ambiguous, ask questions before acting.

## Doing Tasks
When the user asks you to do something:
1. **Understand first** — read relevant files, check existing patterns.
2. **Act** — use tools to implement the solution. Work quickly but accurately.
3. **Verify** — check your work against what was asked, not against your own output.

Keep working until the task is fully complete."""


async def understand_node(state: AgentState, llm: LLMProvider, tool_desc: str, system_prompt: Optional[str] = None) -> AgentState:
    print(f"  [Understand] Analyzing task: \"{state.current_task}\"")

    prompt_to_use = system_prompt or BASE_SYSTEM_PROMPT
    messages = [
        LLMMessage(role="system", content=f"{prompt_to_use}\n\n{tool_desc}"),
        *state.messages,
        LLMMessage(
            role="user",
            content=f"Analyze this task and create a brief plan of action. Task: \"{state.current_task}\". List the tools you'll use and in what order. Be concise (2-3 sentences)."
        )
    ]

    def on_chunk(chunk: str):
        sys.stdout.write(chunk)
        sys.stdout.flush()

    response = await llm.chat(messages, on_chunk=on_chunk)
    print()

    new_messages = list(state.messages)
    new_messages.append(LLMMessage(role="assistant", content=f"[Understanding] {response.content}"))

    return AgentState(
        messages=new_messages,
        current_task=state.current_task,
        status="acting",
        result=state.result,
        iterations=state.iterations,
        max_iterations=state.max_iterations,
        tool_calls=state.tool_calls
    )


MAX_TOOL_CALLS_PER_ACT = 5

async def act_node(state: AgentState, llm: LLMProvider, tools: ToolRegistry, tool_desc: str, system_prompt: Optional[str] = None) -> AgentState:
    print("  [Act] Executing planned actions...")

    prompt_to_use = system_prompt or BASE_SYSTEM_PROMPT
    messages = [
        LLMMessage(role="system", content=f"{prompt_to_use}\n\n{tool_desc}"),
        *state.messages,
        LLMMessage(
            role="user",
            content="Now execute the task using tools. If a tool is needed, respond with ONLY the JSON tool call block. If no tools are needed, provide the final result directly."
        )
    ]

    current_messages = list(state.messages)
    total_tool_calls = state.tool_calls
    last_result = ""

    def on_chunk(chunk: str):
        sys.stdout.write(chunk)
        sys.stdout.flush()

    for _ in range(MAX_TOOL_CALLS_PER_ACT):
        response = await llm.chat(messages, on_chunk=on_chunk)
        print()
        
        tool_call = tools.parse_tool_call(response.content)

        if not tool_call:
            last_result = response.content
            current_messages.append(LLMMessage(
                role="assistant",
                content=f"[Action] {response.content}"
            ))
            break

        tool_name = tool_call["toolName"]
        args = tool_call["args"]
        print(f"    -> Tool: {tool_name}({json.dumps(args)})")
        
        tool_result = await tools.execute_tool(tool_name, args)
        total_tool_calls += 1

        tool_output = tool_result.output if tool_result.success else f"Error: {tool_result.error}"
        status_tag = "OK" if tool_result.success else "FAIL"
        print(f"    <- {status_tag}: {tool_output[:100]}...")

        current_messages.append(LLMMessage(
            role="assistant",
            content=f"[Tool Call] {tool_name}: {json.dumps(args)}"
        ))
        current_messages.append(LLMMessage(
            role="user",
            content=f"[Tool Result] {tool_output}"
        ))

        messages = [
            LLMMessage(role="system", content=f"{prompt_to_use}\n\n{tool_desc}"),
            *current_messages,
            LLMMessage(
                role="user",
                content="Continue executing. Use another tool if needed, or provide the final result if done."
            )
        ]

        last_result = tool_output

    return AgentState(
        messages=current_messages,
        current_task=state.current_task,
        status="verifying",
        result=last_result,
        iterations=state.iterations,
        max_iterations=state.max_iterations,
        tool_calls=total_tool_calls
    )


async def verify_node(state: AgentState, llm: LLMProvider, tool_desc: str, system_prompt: Optional[str] = None) -> AgentState:
    print("  [Verify] Checking results...")

    prompt_to_use = system_prompt or BASE_SYSTEM_PROMPT
    messages = [
        LLMMessage(role="system", content=prompt_to_use),
        *state.messages,
        LLMMessage(
            role="user",
            content="Verify the quality of the result. Is the task complete and correct? Reply with ONLY \"PASS\" if the result is satisfactory, or \"RETRY: <reason>\" if it needs improvement."
        )
    ]

    def on_chunk(chunk: str):
        sys.stdout.write(chunk)
        sys.stdout.flush()

    response = await llm.chat(messages, on_chunk=on_chunk)
    print()
    
    verdict = response.content.strip()

    if verdict.startswith("PASS") or state.iterations >= state.max_iterations:
        return AgentState(
            messages=state.messages,
            current_task=state.current_task,
            status="done",
            result=state.result,
            iterations=state.iterations + 1,
            max_iterations=state.max_iterations,
            tool_calls=state.tool_calls
        )

    print(f"  [Verify] Needs improvement: {verdict}")
    new_messages = list(state.messages)
    new_messages.append(LLMMessage(role="assistant", content=f"[Verification] {verdict}"))
    
    return AgentState(
        messages=new_messages,
        current_task=state.current_task,
        status="understanding",
        result=state.result,
        iterations=state.iterations + 1,
        max_iterations=state.max_iterations,
        tool_calls=state.tool_calls
    )


async def run_agent_graph(
    task: str, 
    llm: LLMProvider, 
    tools: Optional[ToolRegistry] = None, 
    system_prompt: Optional[str] = None,
    max_iterations: int = 3
) -> AgentState:
    registry = tools or ToolRegistry()
    tool_desc = registry.describe_for_llm()

    state = AgentState(
        messages=[LLMMessage(role="user", content=task)],
        current_task=task,
        status="understanding",
        result="",
        iterations=0,
        max_iterations=max_iterations,
        tool_calls=0
    )

    print(f"\n🦞 ClawAgent starting task: \"{task}\"")
    print(f"   Provider: {llm.name} | Max iterations: {max_iterations}")
    tool_names = [t.name for t in registry.list()]
    print(f"   Tools: {', '.join(tool_names) if tool_names else 'none'}\n")

    while state.status not in ("done", "error"):
        try:
            if state.status == "understanding":
                state = await understand_node(state, llm, tool_desc, system_prompt=system_prompt)
            elif state.status == "acting":
                state = await act_node(state, llm, registry, tool_desc, system_prompt=system_prompt)
            elif state.status == "verifying":
                state = await verify_node(state, llm, tool_desc, system_prompt=system_prompt)
            else:
                state.status = "error"
                state.result = f"Unknown status: {state.status}"
        except Exception as err:
            print(f"  Error in {state.status} node:", err)
            state.status = "error"
            state.result = str(err)

    print(f"\n🦞 ClawAgent finished. Status: {state.status} | Tool calls: {state.tool_calls}")
    return state
