"""serial-hid-kvm: KVM control via CH9329 USB HID emulator + HDMI capture."""
