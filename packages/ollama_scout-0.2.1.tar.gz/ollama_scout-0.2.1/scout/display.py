"""
display.py - Rich terminal UI for ollama-scout.
"""
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text

from .benchmark import BenchmarkEstimate
from .hardware import HardwareProfile
from .recommender import Recommendation

console = Console()

FIT_COLORS = {
    "Excellent": "bold green",
    "Good": "bold yellow",
    "Possible": "dim yellow",
    "Too Large": "red",
}

RUN_MODE_COLORS = {
    "GPU": "cyan",
    "Multi-GPU": "bold cyan",
    "CPU+GPU": "yellow",
    "CPU": "dim white",
    "N/A": "red",
}

USE_CASE_ICONS = {
    "coding": "💻",
    "reasoning": "🧠",
    "chat": "💬",
}


def print_banner():
    from scout import __version__
    banner = Text()
    banner.append("🔭 ollama", style="bold cyan")
    banner.append("-scout", style="bold white")
    banner.append(f"  v{__version__}", style="dim cyan")
    banner.append("  |  LLM Hardware Advisor", style="dim white")
    console.print(Panel(banner, border_style="cyan", padding=(0, 2)))


def print_hardware_summary(hw: HardwareProfile):
    table = Table(
        title="[bold cyan]System Hardware[/bold cyan]",
        box=box.ROUNDED,
        border_style="cyan",
        show_header=True,
        header_style="bold white",
    )
    table.add_column("Component", style="dim white")
    table.add_column("Details", style="white")

    table.add_row("OS", hw.os)
    table.add_row("CPU", hw.cpu_name)
    table.add_row("Cores / Threads", f"{hw.cpu_cores} cores / {hw.cpu_threads} threads")
    table.add_row("RAM", f"{hw.ram_gb} GB")

    if hw.is_unified_memory:
        table.add_row("Memory", "[cyan]Unified (Apple Silicon) — shared GPU/CPU[/cyan]")

    if hw.gpus:
        for i, gpu in enumerate(hw.gpus):
            label = "GPU" if i == 0 else f"GPU {i+1}"
            table.add_row(label, f"{gpu.name}  [cyan]({gpu.vram_gb} GB VRAM)[/cyan]")
        if hw.multi_gpu:
            table.add_row(
                "Combined VRAM",
                f"[bold cyan]{hw.combined_vram_gb} GB across {len(hw.gpus)} GPUs[/bold cyan]",
            )
    else:
        table.add_row("GPU", "[dim]None detected — CPU inference only[/dim]")

    console.print(table)
    console.print()


def print_recommendations_grouped(
    grouped: dict[str, list[Recommendation]],
    pulled_models: list[str],
):
    for use_case, recs in grouped.items():
        if not recs:
            continue
        icon = USE_CASE_ICONS.get(use_case, "🤖")
        title = f"{icon}  [bold white]{use_case.capitalize()} Models[/bold white]"

        table = Table(
            title=title,
            box=box.SIMPLE_HEAVY,
            border_style="bright_black",
            show_header=True,
            header_style="bold dim white",
            padding=(0, 1),
        )
        table.add_column("Model", style="bold white", min_width=16)
        table.add_column("Tag", style="dim white")
        table.add_column("Quant", justify="center")
        table.add_column("Size", justify="right")
        table.add_column("Params", justify="center")
        table.add_column("Fit", justify="center", min_width=9)
        table.add_column("Mode", justify="center", min_width=8)
        table.add_column("Note", style="dim", min_width=20, overflow="fold")
        table.add_column("Status", justify="center")

        for rec in recs:
            fit_style = FIT_COLORS.get(rec.fit_label, "white")
            mode_style = RUN_MODE_COLORS.get(rec.run_mode, "white")
            status = "[green]✔ Pulled[/green]" if rec.model.pulled else "[dim]Available[/dim]"

            table.add_row(
                rec.model.name,
                rec.variant.tag,
                f"[cyan]{rec.variant.quantization}[/cyan]",
                f"[white]{rec.variant.size_gb}GB[/white]",
                f"[dim]{rec.variant.param_size}[/dim]",
                f"[{fit_style}]{rec.fit_label}[/{fit_style}]",
                f"[{mode_style}]{rec.run_mode}[/{mode_style}]",
                rec.note,
                status,
            )

        console.print(table)
        console.print()


def print_recommendations_flat(recs: list[Recommendation]):
    table = Table(
        title="[bold cyan]Recommended Models[/bold cyan]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_black",
        show_header=True,
        header_style="bold dim white",
        padding=(0, 1),
    )
    table.add_column("#", justify="right", style="dim", width=3)
    table.add_column("Model", style="bold white", min_width=20)
    table.add_column("Tag", style="dim white")
    table.add_column("Quant", justify="center")
    table.add_column("Size", justify="right")
    table.add_column("Use Cases", max_width=22)
    table.add_column("Fit", justify="center", min_width=9)
    table.add_column("Mode", justify="center", min_width=8)
    table.add_column("Status", justify="center")

    for i, rec in enumerate(recs, 1):
        fit_style = FIT_COLORS.get(rec.fit_label, "white")
        mode_style = RUN_MODE_COLORS.get(rec.run_mode, "white")
        status = "[green]✔ Pulled[/green]" if rec.model.pulled else "[dim]Available[/dim]"
        use_cases = " ".join(
            USE_CASE_ICONS.get(uc, uc) for uc in rec.model.use_cases
        )
        table.add_row(
            str(i),
            rec.model.name,
            rec.variant.tag,
            f"[cyan]{rec.variant.quantization}[/cyan]",
            f"{rec.variant.size_gb}GB",
            use_cases,
            f"[{fit_style}]{rec.fit_label}[/{fit_style}]",
            f"[{mode_style}]{rec.run_mode}[/{mode_style}]",
            status,
        )

    console.print(table)


def print_benchmark(estimates: list[BenchmarkEstimate]):
    """Print real benchmark results for pulled models."""
    RATING_STYLES = {
        "Fast": ("bold green", "Fast ⚡"),
        "Moderate": ("bold yellow", "Moderate 🔄"),
        "Slow": ("dim yellow", "Slow 🐢"),
    }

    table = Table(
        title="[bold cyan]Real Benchmark Results[/bold cyan]",
        box=box.ROUNDED,
        border_style="cyan",
        show_header=True,
        header_style="bold white",
        padding=(0, 1),
    )
    table.add_column("Model", style="bold white", min_width=25)
    table.add_column("Mode", justify="center")
    table.add_column("Speed", justify="right")
    table.add_column("Rating", justify="center")

    for est in estimates:
        mode_style = RUN_MODE_COLORS.get(est.run_mode, "white")
        style, label = RATING_STYLES.get(est.rating, ("white", est.rating))
        table.add_row(
            est.model_name,
            f"[{mode_style}]{est.run_mode}[/{mode_style}]",
            f"{est.tokens_per_sec} t/s",
            f"[{style}]{label}[/{style}]",
        )

    console.print(table)
    console.print(
        "[dim]Timings measured on your hardware. Actual performance varies "
        "with context length and system load.[/dim]"
    )
    console.print()


def print_model_detail(model, variants_with_scores, pulled_models, hw):
    """Print a detailed view of a single model."""

    is_pulled = model.name in pulled_models
    uc_badges = " ".join(USE_CASE_ICONS.get(uc, uc) for uc in model.use_cases)

    # Header
    header = Text()
    header.append(f"{model.name}", style="bold cyan")
    header.append(f"  {uc_badges}")
    if is_pulled:
        header.append("  [green]✔ Pulled[/green]")

    console.print(Panel(header, border_style="cyan", padding=(0, 2)))
    console.print(f"  [dim]{model.description}[/dim]")
    console.print()

    # Variants table
    table = Table(
        title="[bold white]Available Variants[/bold white]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_black",
        show_header=True,
        header_style="bold dim white",
        padding=(0, 1),
    )
    table.add_column("Tag", style="white")
    table.add_column("Size", justify="right")
    table.add_column("Params", justify="center")
    table.add_column("Quant", justify="center")
    table.add_column("Fit", justify="center", min_width=9)
    table.add_column("Mode", justify="center", min_width=8)
    table.add_column("Note", style="dim", min_width=20, overflow="fold")

    best_variant = None
    best_score = -1

    for variant, score, fit_label, run_mode, note in variants_with_scores:
        fit_style = FIT_COLORS.get(fit_label, "white")
        mode_style = RUN_MODE_COLORS.get(run_mode, "white")
        table.add_row(
            variant.tag,
            f"{variant.size_gb}GB",
            variant.param_size,
            f"[cyan]{variant.quantization}[/cyan]",
            f"[{fit_style}]{fit_label}[/{fit_style}]",
            f"[{mode_style}]{run_mode}[/{mode_style}]",
            note,
        )
        if score > best_score:
            best_score = score
            best_variant = variant

    console.print(table)
    console.print()

    # Pull command for best variant
    if best_variant and best_score >= 0:
        pull_cmd = f"ollama pull {model.name}:{best_variant.tag}"
        console.print(Panel(
            f"[bold]Best fit:[/bold] {model.name}:{best_variant.tag} "
            f"({best_variant.size_gb}GB, {best_variant.quantization})\n"
            f"[bold]Pull command:[/bold] [cyan]{pull_cmd}[/cyan]",
            title="[dim]Recommendation[/dim]",
            border_style="green",
            padding=(0, 2),
        ))
    else:
        console.print("[dim]No compatible variants found for your hardware.[/dim]")

    console.print()


def print_model_comparison(detail1, detail2):
    """Print a side-by-side comparison of two models.

    Each detail is a dict with keys:
        name, description, tag, size_gb, param_size, quantization,
        fit_label, run_mode, score, est_tps, pulled
    Pass None for a detail if the model was not found.
    """
    FIT_RANK = {"Excellent": 3, "Good": 2, "Possible": 1, "Too Large": 0, None: -1}
    MODE_RANK = {"GPU": 3, "CPU+GPU": 2, "CPU": 1, "N/A": 0, None: -1}

    def _val(d, key, default="N/A"):
        if d is None:
            return default
        return d.get(key, default)

    def _highlight(val1, val2, lower_is_better=False):
        """Return (style1, style2) — green for winner, white for loser."""
        if val1 is None or val2 is None:
            return "white", "white"
        if val1 == val2:
            return "white", "white"
        if lower_is_better:
            winner = 1 if val1 < val2 else 2
        else:
            winner = 1 if val1 > val2 else 2
        return (
            ("green" if winner == 1 else "white"),
            ("green" if winner == 2 else "white"),
        )

    name1 = _val(detail1, "name", "Not found")
    name2 = _val(detail2, "name", "Not found")

    table = Table(
        title="[bold cyan]Model Comparison[/bold cyan]",
        box=box.ROUNDED,
        border_style="cyan",
        show_header=True,
        header_style="bold white",
        padding=(0, 1),
    )
    table.add_column("", style="dim white", min_width=14)
    table.add_column(name1, style="white", min_width=20)
    table.add_column(name2, style="white", min_width=20)

    # Description
    table.add_row(
        "Description",
        _val(detail1, "description"),
        _val(detail2, "description"),
    )

    # Best variant
    table.add_row(
        "Best Variant",
        _val(detail1, "tag"),
        _val(detail2, "tag"),
    )

    # Size (lower is better)
    s1 = detail1.get("size_gb") if detail1 else None
    s2 = detail2.get("size_gb") if detail2 else None
    c1, c2 = _highlight(s1, s2, lower_is_better=True)
    table.add_row(
        "Size",
        f"[{c1}]{s1}GB[/{c1}]" if s1 else "N/A",
        f"[{c2}]{s2}GB[/{c2}]" if s2 else "N/A",
    )

    # Params
    table.add_row(
        "Parameters",
        _val(detail1, "param_size"),
        _val(detail2, "param_size"),
    )

    # Quantization
    table.add_row(
        "Quantization",
        _val(detail1, "quantization"),
        _val(detail2, "quantization"),
    )

    # Fit (higher rank is better)
    f1 = _val(detail1, "fit_label", None)
    f2 = _val(detail2, "fit_label", None)
    c1, c2 = _highlight(FIT_RANK.get(f1, -1), FIT_RANK.get(f2, -1))
    fit_style1 = FIT_COLORS.get(f1, "white") if f1 else "dim"
    fit_style2 = FIT_COLORS.get(f2, "white") if f2 else "dim"
    table.add_row(
        "Fit",
        f"[{fit_style1}]{f1 or 'N/A'}[/{fit_style1}]",
        f"[{fit_style2}]{f2 or 'N/A'}[/{fit_style2}]",
    )

    # Run Mode (higher rank is better)
    m1 = _val(detail1, "run_mode", None)
    m2 = _val(detail2, "run_mode", None)
    c1, c2 = _highlight(MODE_RANK.get(m1, -1), MODE_RANK.get(m2, -1))
    table.add_row(
        "Run Mode",
        f"[{c1}]{m1 or 'N/A'}[/{c1}]",
        f"[{c2}]{m2 or 'N/A'}[/{c2}]",
    )

    # Est. Speed (higher is better)
    t1 = detail1.get("est_tps") if detail1 else None
    t2 = detail2.get("est_tps") if detail2 else None
    c1, c2 = _highlight(t1, t2)
    table.add_row(
        "Est. Speed",
        f"[{c1}]{t1} t/s[/{c1}]" if t1 else "N/A",
        f"[{c2}]{t2} t/s[/{c2}]" if t2 else "N/A",
    )

    # Status
    table.add_row(
        "Status",
        "[green]Pulled[/green]" if detail1 and detail1.get("pulled") else "[dim]Not pulled[/dim]",
        "[green]Pulled[/green]" if detail2 and detail2.get("pulled") else "[dim]Not pulled[/dim]",
    )

    console.print(table)
    console.print()

    # Verdict
    score1 = detail1.get("score", -1) if detail1 else -1
    score2 = detail2.get("score", -1) if detail2 else -1
    if detail1 is None and detail2 is None:
        verdict = "Neither model was found."
    elif detail1 is None:
        verdict = f"[bold]{name2}[/bold] wins — {name1} was not found."
    elif detail2 is None:
        verdict = f"[bold]{name1}[/bold] wins — {name2} was not found."
    elif score1 > score2:
        verdict = (
            f"[bold green]{name1}[/bold green] is the better fit "
            f"for your hardware ({_val(detail1, 'fit_label')} / "
            f"{_val(detail1, 'run_mode')})."
        )
    elif score2 > score1:
        verdict = (
            f"[bold green]{name2}[/bold green] is the better fit "
            f"for your hardware ({_val(detail2, 'fit_label')} / "
            f"{_val(detail2, 'run_mode')})."
        )
    else:
        verdict = "Both models are equally matched for your hardware."

    console.print(Panel(
        verdict,
        title="[dim]Verdict[/dim]",
        border_style="green",
        padding=(0, 2),
    ))
    console.print()


def print_legend():
    """Print a legend panel explaining Fit labels and Run Modes."""
    legend_text = Text()
    legend_text.append("Fit Labels:  ", style="bold white")
    legend_text.append("Excellent", style="bold green")
    legend_text.append(" = fits fully in VRAM  |  ", style="dim")
    legend_text.append("Good", style="bold yellow")
    legend_text.append(" = partial CPU offload  |  ", style="dim")
    legend_text.append("Possible", style="dim yellow")
    legend_text.append(" = CPU-only, slower\n", style="dim")
    legend_text.append("Run Modes:   ", style="bold white")
    legend_text.append("GPU", style="cyan")
    legend_text.append(" = full GPU acceleration  |  ", style="dim")
    legend_text.append("CPU+GPU", style="yellow")
    legend_text.append(" = split across GPU + RAM  |  ", style="dim")
    legend_text.append("Multi-GPU", style="bold cyan")
    legend_text.append(" = split across multiple GPUs\n", style="dim")
    legend_text.append("             ", style="bold white")
    legend_text.append("CPU", style="dim white")
    legend_text.append(" = CPU inference only", style="dim")

    console.print(Panel(
        legend_text,
        title="[dim]Legend[/dim]",
        border_style="bright_black",
        padding=(0, 1),
    ))


def print_ollama_not_installed():
    """Print a warning panel when Ollama is not installed."""
    console.print(Panel(
        "[bold yellow]Ollama is not installed or not found in PATH.[/bold yellow]\n\n"
        "Recommendations will still work, but you won't be able to pull or run models.\n\n"
        "[bold]To install Ollama:[/bold]\n"
        "  Linux/macOS:  [cyan]curl -fsSL https://ollama.com/install.sh | sh[/cyan]\n"
        "  Windows:      [cyan]https://ollama.com/download[/cyan]",
        title="[yellow]Ollama Not Found[/yellow]",
        border_style="yellow",
        padding=(0, 2),
    ))
    console.print()


def print_footer():
    """Print a footer with helpful tips."""
    console.print()
    console.print(Panel(
        "[dim]Run with [bold]--help[/bold] for all options  |  "
        "[bold]--offline[/bold] to skip API fetch  |  "
        "[bold]--export[/bold] to save report[/dim]",
        border_style="bright_black",
        padding=(0, 1),
    ))
    console.print()


def prompt_export() -> bool:
    try:
        console.print()
        answer = console.input(
            "[bold yellow]Save results as Markdown report? [y/N]:[/bold yellow] "
        ).strip().lower()
        return answer in ("y", "yes")
    except EOFError:
        return False


def prompt_pull(recs: list[Recommendation]) -> str | None:
    try:
        console.print()
        console.print("[bold yellow]Auto-pull a recommended model?[/bold yellow]")
        for i, rec in enumerate(recs[:10], 1):
            pulled_tag = " [green](already pulled)[/green]" if rec.model.pulled else ""
            label = f"{rec.model.name}:{rec.variant.tag}"
            console.print(
                f"  [dim]{i}.[/dim] [white]{label}[/white]{pulled_tag}"
            )
        console.print(f"  [dim]{0}.[/dim] Skip")
        console.print()
        choice = console.input("[bold]Enter number:[/bold] ").strip()
        if choice == "0" or not choice:
            return None
        try:
            idx = int(choice) - 1
            if 0 <= idx < min(10, len(recs)):
                return f"{recs[idx].model.name}:{recs[idx].variant.tag}"
        except ValueError:
            pass
        return None
    except EOFError:
        return None


def spinner(message: str) -> Progress:
    p = Progress(SpinnerColumn(), TextColumn(f"[cyan]{message}[/cyan]"), transient=True)
    return p


def print_error(msg: str):
    console.print(f"[bold red]Error:[/bold red] {msg}")


def print_success(msg: str):
    console.print(f"[bold green]OK:[/bold green] {msg}")


def print_info(msg: str):
    console.print(f"[dim cyan]>>[/dim cyan]  {msg}")
