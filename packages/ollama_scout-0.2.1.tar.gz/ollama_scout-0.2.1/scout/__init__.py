"""ollama-scout — CLI tool to scan hardware and recommend compatible Ollama LLMs."""

__version__ = "0.2.1"
