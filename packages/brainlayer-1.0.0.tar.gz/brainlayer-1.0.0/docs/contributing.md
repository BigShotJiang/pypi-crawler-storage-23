# Contributing

See the [CONTRIBUTING.md](https://github.com/EtanHey/brainlayer/blob/main/CONTRIBUTING.md) in the repository root for full contribution guidelines, including:

- Development setup
- Project structure
- Running tests
- Pull request process
- Key patterns and conventions
- How to add an MCP tool
