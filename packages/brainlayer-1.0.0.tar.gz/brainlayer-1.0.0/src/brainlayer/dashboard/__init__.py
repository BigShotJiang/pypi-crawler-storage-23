"""BrainLayer Dashboard - Interactive TUI for memory search and management."""

from .app import DashboardApp

__all__ = ["DashboardApp"]
