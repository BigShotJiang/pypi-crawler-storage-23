"""BrainLayer (זיכרון) - Local knowledge pipeline for Claude Code conversations."""

__version__ = "1.0.0"
