def gitignore_template() -> str:
    return """__pycache__/
*.pyc
.env
*.log
.venv/
dist/
"""
