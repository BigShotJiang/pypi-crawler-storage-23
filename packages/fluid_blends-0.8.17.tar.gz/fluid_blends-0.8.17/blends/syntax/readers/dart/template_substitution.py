from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.expression_statement import (
    build_expression_statement_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph

    c_ids = [
        child
        for child in adj_ast(graph, args.n_id)
        if graph.nodes[child]["label_type"] not in {"$", "{", "}"}
    ]

    if len(c_ids) == 1 and graph.nodes[c_ids[0]]["label_type"] == "identifier_dollar_escaped":
        symbol = graph.nodes[c_ids[0]].get("label_text", "")
        return build_symbol_lookup_node(args, symbol)

    return build_expression_statement_node(args, iter(c_ids))
