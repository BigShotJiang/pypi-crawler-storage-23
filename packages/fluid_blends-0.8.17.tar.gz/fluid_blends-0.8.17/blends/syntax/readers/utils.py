from blends.models import NId
from blends.syntax.models import ReaderLogicError


def check_reader_element_consistency(*args: NId | None) -> None:
    if any(arg is None for arg in args):
        msg = "Inconsistent reader element"
        raise ReaderLogicError(msg)


def ensure_nid(value: NId | None) -> NId:
    if value is None:
        msg = "Inconsistent reader element, expected NId but got None"
        raise ReaderLogicError(msg)
    return value
