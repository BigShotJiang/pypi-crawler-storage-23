from blends.models import (
    NId,
)
from blends.syntax.builders.method_declaration import (
    DirectChildren,
    build_method_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    arrow_id = args.ast_graph.nodes[args.n_id]
    block_id = arrow_id["label_field_body"]
    params = arrow_id.get("label_field_parameter") or arrow_id.get("label_field_parameters")

    direct: DirectChildren = {"block_id": block_id}
    if params:
        direct["parameters_id"] = params

    return build_method_declaration_node(args, None, direct, {})
