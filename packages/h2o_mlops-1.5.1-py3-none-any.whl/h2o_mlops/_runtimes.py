from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, NamedTuple, Optional, Union

from h2o_mlops import _core, _utils, _workspaces, h2o_mlops_autogen, options
from h2o_mlops._unset import UNSET, UnsetType

# ============================================================================
# Runtime Management Classes
# ============================================================================


class BaseMLOpsRuntimes:
    """Base class for Runtime resource management with shared list/count logic."""

    def __init__(self, client: _core.Client, parent_resource_name: str):
        self._client = client
        self._parent_resource_name = parent_resource_name
        self._field_name_mapping = {
            "name": "display_name",
            "description": "description",
            "model_type": "model_type",
            "runtime_image": "runtime_image",
            "state": "state",
            "created_time": "create_time",
            "last_modified_time": "update_time",
        }

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List Runtimes."""
        return self._list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count Runtimes."""
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression, **selectors
        )
        return int(
            self._client._backend.runtime.runtime.count_runtimes(
                parent=self._parent_resource_name,
                filter=_utils._convert_filter_expression_to_string(
                    filter_expression, self._field_name_mapping
                ),
                _request_timeout=self._client._global_request_timeout,
            ).count
        )

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """Internal list implementation with pagination."""
        response = self._client._backend.runtime.runtime.list_runtimes(
            parent=self._parent_resource_name,
            page_token=page_token,
            **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
            _request_timeout=self._client._global_request_timeout,
        )
        data = [
            {
                "name": r.display_name,
                "model_type": r.model_type,
                "state": r.state,
                "uid": _utils._convert_resource_name_to_uid(r.name),
                "raw_info": r,
            }
            for r in response.runtimes
        ]
        return _utils.Table(
            data=data,
            keys=["name", "model_type", "state", "uid"],
            get_method=lambda x: MLOpsRuntimeResource(self._client, x["raw_info"]),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=self.count,
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )


class MLOpsRuntimeResource:
    """Represents a single Runtime resource in H2O MLOps."""

    def __init__(
        self,
        client: _core.Client,
        raw_info: h2o_mlops_autogen.V1Runtime,
    ):
        self._client = client
        self._raw_info = raw_info
        self._resource_name = raw_info.name

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    name={self.name!r},\n"
            f"    description={self.description!r},\n"
            f"    model_type={self.model_type!r},\n"
            f"    state={self.state!r},\n"
            f"    created_time={self.created_time!r},\n"
            f"    last_modified_time={self.last_modified_time!r},\n"
            f")>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Name: {self.name}\n"
            f"Description: {self.description}\n"
            f"Model Type: {self.model_type}\n"
            f"State: {self.state}\n"
            f"Created Time: {self.created_time}\n"
            f"Last Modified Time: {self.last_modified_time}"
        )

    @property
    def uid(self) -> str:
        """Runtime unique ID."""
        return _utils._convert_resource_name_to_uid(self._resource_name)

    @property
    def name(self) -> str:
        """Runtime display name."""
        return self._raw_info.display_name

    @property
    def description(self) -> str:
        """Runtime description."""
        return self._raw_info.description

    @property
    def model_type(self) -> str:
        """Model type supported by this runtime."""
        return self._raw_info.model_type

    @property
    def state(self) -> str:
        """Runtime state."""
        return str(self._raw_info.state.value)

    @property
    def created_time(self) -> datetime:
        """Runtime creation time."""
        return self._raw_info.create_time

    @property
    def last_modified_time(self) -> datetime:
        """Runtime last modification time."""
        return self._raw_info.update_time

    @property
    def state_reason(self) -> str:
        """Reason for current state."""
        return self._raw_info.state_reason

    @property
    def state_updated_time(self) -> datetime:
        """State last update time."""
        return self._raw_info.state_update_time

    @property
    def runtime_image(self) -> MLOpsRuntimeImage:
        """Runtime image object."""
        # Resource name format: workspaces/{workspace_uid}/runtimeImages/{image_uid}
        raw_info = self._client._backend.runtime.runtime_image.get_runtime_image(
            name=self._raw_info.runtime_image,
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image
        return MLOpsRuntimeImage(self._client, raw_info)

    @property
    def environment_variables(self) -> Dict[str, str]:
        """Environment variables for the runtime."""
        return self._raw_info.environment_variables or {}

    @property
    def read_only_data_volume(self) -> bool:
        """Whether the data volume is read-only."""
        return self._raw_info.data_volume_read_only or False

    @property
    def volumes(self) -> Optional[List[options.VolumeOptions]]:
        """Volume mounts for the runtime."""
        if self._raw_info.volumes:
            return [
                options.VolumeOptions._from_raw_info(v) for v in self._raw_info.volumes
            ]
        return None

    @property
    def security_context(self) -> Optional[options.SecurityContextOptions]:
        """Security context for the runtime."""
        if self._raw_info.security_context:
            return options.SecurityContextOptions._from_raw_info(
                self._raw_info.security_context
            )
        return None

    @property
    def scoring_endpoint(self) -> str:
        """Scoring endpoint URL."""
        return self._raw_info.scoring_endpoint

    @property
    def selector(self) -> Dict[str, str]:
        """Selector defines key-value pairs that must match experiment metadata
        for this runtime to be eligible for deployment.
        All entries must match (AND semantics).
        An empty selector matches all experiments."""
        return self._raw_info.selector or {}

    @property
    def managed_by_bootstrap(self) -> bool:
        """Whether runtime is managed by bootstrap."""
        return self._raw_info.managed_by_bootstrap or False

    def update(
        self,
        name: Optional[str] = None,
        description: Optional[Union[str, UnsetType]] = UNSET,
        environment_variables: Optional[Union[Dict[str, str], UnsetType]] = UNSET,
        read_only_data_volume: Optional[Union[bool, UnsetType]] = UNSET,
        volumes: Optional[Union[List[options.VolumeOptions], UnsetType]] = UNSET,
        security_context: Optional[
            Union[options.SecurityContextOptions, UnsetType]
        ] = UNSET,
        selector: Optional[Union[Dict[str, str], UnsetType]] = UNSET,
    ) -> None:
        """Update Runtime configuration.

        Args:
            name: Display name for the runtime
            description: Runtime description
            environment_variables: Environment variables
            read_only_data_volume: Whether data volume is read-only
            volumes: Volume mount configurations
            security_context: Security context configuration
            selector: Selector defines key-value pairs that must match experiment
                metadata for this runtime to be eligible for deployment.
                All entries must match (AND semantics).
                An empty selector matches all experiments.
        """
        update_mask = []
        # RequiredTheRuntimeResourceToUpdate requires immutable fields
        # (model_type, runtime_image) but we don't add them to update_mask since
        # they can't be changed
        update_resource = h2o_mlops_autogen.RequiredTheRuntimeResourceToUpdate(
            model_type=self._raw_info.model_type,
            runtime_image=self._raw_info.runtime_image,
        )
        if name is not None:
            update_resource.display_name = name
            update_mask.append("display_name")
        if not isinstance(description, UnsetType):
            update_resource.description = description if description is not None else ""
            update_mask.append("description")
        if not isinstance(environment_variables, UnsetType):
            update_resource.environment_variables = environment_variables
            update_mask.append("environment_variables")
        if not isinstance(read_only_data_volume, UnsetType):
            update_resource.data_volume_read_only = read_only_data_volume
            update_mask.append("data_volume_read_only")
        if not isinstance(volumes, UnsetType):
            if isinstance(volumes, list):
                update_resource.volumes = [v._to_raw_info() for v in volumes]
            else:
                update_resource.volumes = []
            update_mask.append("volume_mounts")
        if not isinstance(security_context, UnsetType):
            if isinstance(security_context, options.SecurityContextOptions):
                update_resource.security_context = security_context._to_raw_info()
            else:
                update_resource.security_context = None
            update_mask.append("security_context")
        if not isinstance(selector, UnsetType):
            update_resource.selector = selector or {}
            update_mask.append("selector")
        if update_mask:
            self._raw_info = self._client._backend.runtime.runtime.update_runtime(
                runtime_name=self._resource_name,
                runtime=update_resource,
                update_mask=",".join(update_mask),
                _request_timeout=self._client._global_request_timeout,
            ).runtime

    def delete(self) -> None:
        """Delete Runtime."""
        self._client._backend.runtime.runtime.delete_runtime(
            name_1=self._resource_name,
            _request_timeout=self._client._global_request_timeout,
        )

    def deprecate(self, reason: Optional[str] = None) -> None:
        """Mark Runtime as deprecated.

        Args:
            reason: Optional reason for deprecation
        """
        self._raw_info = self._client._backend.runtime.runtime.deprecate_runtime(
            name_2=self._resource_name,
            body=h2o_mlops_autogen.DeprecateRuntimeRequest(reason=reason),
            _request_timeout=self._client._global_request_timeout,
        ).runtime

    def disable(self, reason: Optional[str] = None) -> None:
        """Disable Runtime."""
        self._raw_info = self._client._backend.runtime.runtime.disable_runtime(
            name_2=self._resource_name,
            body=h2o_mlops_autogen.DisableRuntimeRequest(reason=reason),
            _request_timeout=self._client._global_request_timeout,
        ).runtime

    def enable(self) -> None:
        """Re-enable disabled Runtime."""
        self._raw_info = self._client._backend.runtime.runtime.enable_runtime(
            name_1=self._resource_name,
            body={},
            _request_timeout=self._client._global_request_timeout,
        ).runtime


class MLOpsWorkspaceRuntimes(BaseMLOpsRuntimes):
    """Manage Runtime resources within a workspace."""

    def __init__(
        self,
        client: _core.Client,
        workspace: _workspaces.Workspace,
    ):
        parent_resource_name = f"workspaces/{workspace.uid}"
        super().__init__(client, parent_resource_name)
        self._workspace = workspace

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List Runtimes in workspace.

        Examples::

            # filter on columns by using selectors
            workspace.runtimes.list(name="my-runtime")

            # use an index to get an H2O MLOps entity referenced by the table
            runtime = workspace.runtimes.list()[0]

            # filter by state
            workspace.runtimes.list(
                opts=options.ListOptions(
                    filter_expression=options.FilterExpression(
                        filters=[
                            options.FilterOptions(
                                field="state",
                                value="ACTIVE"
                            )
                        ]
                    )
                )
            )
        """
        return super().list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count Runtimes in workspace."""
        return super().count(filter_expression=filter_expression, **selectors)

    def get(self, uid: str) -> MLOpsRuntimeResource:
        """Get Runtime by UID.

        Args:
            uid: H2O MLOps unique ID for the Runtime.

        Returns:
            MLOpsRuntimeResource object
        """
        raw_info = self._client._backend.runtime.runtime.get_runtime(
            name_2=f"{self._parent_resource_name}/runtimes/{uid}",
            _request_timeout=self._client._global_request_timeout,
        ).runtime
        return MLOpsRuntimeResource(self._client, raw_info)

    def create(
        self,
        name: str,
        runtime_image: Union[MLOpsRuntimeImage, str],
        model_type: str,
        description: Optional[str] = None,
        environment_variables: Optional[Dict[str, str]] = None,
        read_only_data_volume: bool = False,
        volumes: Optional[List[options.VolumeOptions]] = None,
        security_context: Optional[options.SecurityContextOptions] = None,
        selector: Optional[Dict[str, str]] = None,
    ) -> MLOpsRuntimeResource:
        """Create new Runtime.

        Args:
            name: Display name for the runtime
            runtime_image: MLOpsRuntimeImage object or runtime image resource name
            model_type: Model type (e.g., "h2o3", "sklearn")
            description: Runtime description
            environment_variables: Environment variables
            read_only_data_volume: Whether data volume should be read-only
            volumes: Volume mount configurations
            security_context: Security context configuration
            selector: Selector defines key-value pairs that must match experiment
                metadata for this runtime to be eligible for deployment.
                All entries must match (AND semantics).
                An empty selector matches all experiments.

        Returns:
            Created MLOpsRuntimeResource object
        """
        # Extract resource name from MLOpsRuntimeImage object or use string directly
        runtime_image_name = (
            runtime_image._resource_name
            if isinstance(runtime_image, MLOpsRuntimeImage)
            else runtime_image
        )

        runtime = h2o_mlops_autogen.V1Runtime(
            display_name=name,
            description=description or "",
            runtime_image=runtime_image_name,
            model_type=model_type,
            environment_variables=environment_variables,
            data_volume_read_only=read_only_data_volume,
            volumes=[v._to_raw_info() for v in volumes] if volumes else None,
            security_context=(
                security_context._to_raw_info() if security_context else None
            ),
            selector=selector or {},
        )

        raw_info = self._client._backend.runtime.runtime.create_runtime(
            parent=self._parent_resource_name,
            runtime=runtime,
            _request_timeout=self._client._global_request_timeout,
        ).runtime

        return MLOpsRuntimeResource(self._client, raw_info)


class MLOpsAllRuntimes(BaseMLOpsRuntimes):
    """List and count Runtime resources across all workspaces."""

    def __init__(self, client: _core.Client):
        super().__init__(client, parent_resource_name="workspaces/-")

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List Runtimes across all workspaces."""
        return super().list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count Runtimes across all workspaces."""
        return super().count(filter_expression=filter_expression, **selectors)


# ============================================================================
# RuntimeImage Management Classes
# ============================================================================


class BaseMLOpsRuntimeImages:
    """Base class for RuntimeImage resource management with shared list/count logic."""

    def __init__(self, client: _core.Client, parent_resource_name: str):
        self._client = client
        self._parent_resource_name = parent_resource_name
        self._field_name_mapping = {
            "name": "display_name",
            "description": "description",
            "docker_image": "docker_image",
            "state": "state",
            "created_time": "create_time",
            "last_modified_time": "update_time",
        }

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List RuntimeImages."""
        return self._list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count RuntimeImages."""
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression, **selectors
        )
        return int(
            self._client._backend.runtime.runtime_image.count_runtime_images(
                parent=self._parent_resource_name,
                filter=_utils._convert_filter_expression_to_string(
                    filter_expression, self._field_name_mapping
                ),
                _request_timeout=self._client._global_request_timeout,
            ).count
        )

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """Internal list implementation with pagination."""
        response = self._client._backend.runtime.runtime_image.list_runtime_images(
            parent=self._parent_resource_name,
            page_token=page_token,
            **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
            _request_timeout=self._client._global_request_timeout,
        )
        data = [
            {
                "name": r.display_name,
                "docker_image": r.docker_image,
                "state": r.state,
                "uid": _utils._convert_resource_name_to_uid(r.name),
                "raw_info": r,
            }
            for r in response.runtime_images
        ]
        return _utils.Table(
            data=data,
            keys=["name", "docker_image", "state", "uid"],
            get_method=lambda x: MLOpsRuntimeImage(self._client, x["raw_info"]),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=self.count,
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )


class MLOpsRuntimeImage:
    """Represents a single RuntimeImage resource in H2O MLOps."""

    def __init__(
        self,
        client: _core.Client,
        raw_info: h2o_mlops_autogen.V1RuntimeImage,
    ):
        self._client = client
        self._raw_info = raw_info
        self._resource_name = raw_info.name

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    name={self.name!r},\n"
            f"    description={self.description!r},\n"
            f"    docker_image={self.docker_image!r},\n"
            f"    state={self.state!r},\n"
            f"    created_time={self.created_time!r},\n"
            f"    last_modified_time={self.last_modified_time!r},\n"
            f")>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Name: {self.name}\n"
            f"Description: {self.description}\n"
            f"Docker Image: {self.docker_image}\n"
            f"State: {self.state}\n"
            f"Created Time: {self.created_time}\n"
            f"Last Modified Time: {self.last_modified_time}"
        )

    @property
    def uid(self) -> str:
        """RuntimeImage unique ID."""
        return _utils._convert_resource_name_to_uid(self._resource_name)

    @property
    def name(self) -> str:
        """RuntimeImage display name."""
        return self._raw_info.display_name

    @property
    def description(self) -> str:
        """RuntimeImage description."""
        return self._raw_info.description

    @property
    def docker_image(self) -> str:
        """Docker image URI."""
        return self._raw_info.docker_image

    @property
    def state(self) -> str:
        """RuntimeImage state."""
        return str(self._raw_info.state.value)

    @property
    def created_time(self) -> datetime:
        """RuntimeImage creation time."""
        return self._raw_info.create_time

    @property
    def last_modified_time(self) -> datetime:
        """RuntimeImage last modification time."""
        return self._raw_info.update_time

    @property
    def state_reason(self) -> str:
        """Reason for current state."""
        return self._raw_info.state_reason

    @property
    def state_updated_time(self) -> datetime:
        """State last update time."""
        return self._raw_info.state_update_time

    @property
    def current_version(self) -> Optional[MLOpsRuntimeImageVersion]:
        """Current active version object.

        Returns the latest version with state=ACTIVE,
        or state=DEPRECATED if no ACTIVE exists.
        DISABLED versions are excluded. Returns None if all versions are disabled.
        """
        if not self._raw_info.current_version:
            return None

        backend = self._client._backend.runtime.runtime_image_version
        raw_info = backend.get_runtime_image_version(
            name_1=self._raw_info.current_version,
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version
        return MLOpsRuntimeImageVersion(self._client, self, raw_info)

    @property
    def managed_by_bootstrap(self) -> bool:
        """Whether runtime image is managed by bootstrap."""
        return self._raw_info.managed_by_bootstrap or False

    @property
    def versions(self) -> MLOpsRuntimeImageVersions:
        """Access versions of this runtime image."""
        return MLOpsRuntimeImageVersions(self._client, self)

    def update(
        self,
        name: Optional[str] = None,
        description: Optional[Union[str, UnsetType]] = UNSET,
        docker_image: Optional[str] = None,
        version: Optional[str] = None,
    ) -> None:
        """Update RuntimeImage configuration.

        Args:
            name: Display name for the runtime image
            description: Runtime image description
            docker_image: Docker image URI
            version: Optional version string (e.g., "v1.0.0" or "1.0.0").
                Only used when docker_image is also provided.
                If not specified, version will be extracted from the docker image tag.
                This is an input-only field used during update operations.
        """
        update_mask = []
        update_resource = h2o_mlops_autogen.RequiredRuntimeImageResource()
        if name is not None:
            update_resource.display_name = name
            update_mask.append("display_name")
        if not isinstance(description, UnsetType):
            update_resource.description = description if description is not None else ""
            update_mask.append("description")
        if docker_image is not None:
            update_resource.docker_image = docker_image
            update_mask.append("docker_image")
            # Version is only valid when docker_image is being updated
            if version is not None:
                update_resource.runtime_image_version_id = version
        if update_mask:
            self._raw_info = (
                self._client._backend.runtime.runtime_image.update_runtime_image(
                    runtime_image_name=self._resource_name,
                    runtime_image=update_resource,
                    update_mask=",".join(update_mask),
                    _request_timeout=self._client._global_request_timeout,
                ).runtime_image
            )

    def delete(self) -> None:
        """Delete RuntimeImage."""
        self._client._backend.runtime.runtime_image.delete_runtime_image(
            name=self._resource_name,
            _request_timeout=self._client._global_request_timeout,
        )

    def deprecate(self, reason: Optional[str] = None) -> None:
        """Mark RuntimeImage as deprecated.

        Args:
            reason: Optional reason for deprecation
        """
        self._raw_info = (
            self._client._backend.runtime.runtime_image.deprecate_runtime_image(
                name=self._resource_name,
                body=h2o_mlops_autogen.DeprecateRuntimeImageRequest(reason=reason),
                _request_timeout=self._client._global_request_timeout,
            ).runtime_image
        )

    def disable(self, reason: Optional[str] = None) -> None:
        """Disable RuntimeImage."""
        self._raw_info = (
            self._client._backend.runtime.runtime_image.disable_runtime_image(
                name=self._resource_name,
                body=h2o_mlops_autogen.DisableRuntimeImageRequest(reason=reason),
                _request_timeout=self._client._global_request_timeout,
            ).runtime_image
        )

    def enable(self) -> None:
        """Re-enable disabled RuntimeImage."""
        self._raw_info = (
            self._client._backend.runtime.runtime_image.enable_runtime_image(
                name=self._resource_name,
                body={},
                _request_timeout=self._client._global_request_timeout,
            ).runtime_image
        )


class MLOpsRuntimeImages(BaseMLOpsRuntimeImages):
    """Manage RuntimeImage resources within a workspace."""

    def __init__(
        self,
        client: _core.Client,
        workspace: _workspaces.Workspace,
    ):
        parent_resource_name = f"workspaces/{workspace.uid}"
        super().__init__(client, parent_resource_name)
        self._workspace = workspace

    def get(self, uid: str) -> MLOpsRuntimeImage:
        """Get RuntimeImage by UID.

        Args:
            uid: H2O MLOps unique ID for the RuntimeImage.

        Returns:
            MLOpsRuntimeImage object
        """
        raw_info = self._client._backend.runtime.runtime_image.get_runtime_image(
            name=f"{self._parent_resource_name}/runtimeImages/{uid}",
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image
        return MLOpsRuntimeImage(self._client, raw_info)

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List RuntimeImages in workspace.

        Examples::

            # filter on columns by using selectors
            workspace.runtimes.images.list(name="my-image")

            # use an index to get an H2O MLOps entity referenced by the table
            image = workspace.runtimes.images.list()[0]

            # filter by state
            workspace.runtimes.images.list(state="ACTIVE")
        """
        return super().list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count RuntimeImages in workspace."""
        return super().count(filter_expression=filter_expression, **selectors)

    def create(
        self,
        name: str,
        docker_image: str,
        description: Optional[str] = None,
        version: Optional[str] = None,
    ) -> MLOpsRuntimeImage:
        """Create new RuntimeImage.

        Args:
            name: Display name for the runtime image
            docker_image: Docker image URI (e.g., "docker.io/h2oai/runtime:1.0.0")
            description: Runtime image description
            version: Optional version string (e.g., "v1.0.0" or "1.0.0").
                If not specified, version will be extracted from the docker image tag.
                Required when the docker image tag is not a standard semantic version
                (e.g., "latest", "stable", custom tags).
                This is an input-only field used during creation.
                Examples:
                - docker_image="h2oai/scorer:2.3.5"
                  → version extracted: "v2.3.5"
                - docker_image="h2oai/scorer:latest", version="v1.0.0"
                  → version used: "v1.0.0"

        Returns:
            Created MLOpsRuntimeImage object
        """
        runtime_image = h2o_mlops_autogen.V1RuntimeImage(
            display_name=name,
            description=description or "",
            docker_image=docker_image,
            runtime_image_version_id=version,
        )

        raw_info = self._client._backend.runtime.runtime_image.create_runtime_image(
            parent=self._parent_resource_name,
            runtime_image=runtime_image,
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image

        return MLOpsRuntimeImage(self._client, raw_info)


class MLOpsAllRuntimeImages(BaseMLOpsRuntimeImages):
    """List and count RuntimeImage resources across all workspaces."""

    def __init__(self, client: _core.Client):
        super().__init__(client, parent_resource_name="workspaces/-")

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List RuntimeImages across all workspaces."""
        return super().list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count RuntimeImages across all workspaces."""
        return super().count(filter_expression=filter_expression, **selectors)


# ============================================================================
# RuntimeImageVersion Management Classes
# ============================================================================


class MLOpsRuntimeImageVersion:
    """Represents a single RuntimeImageVersion resource in H2O MLOps."""

    def __init__(
        self,
        client: _core.Client,
        runtime_image: MLOpsRuntimeImage,
        raw_info: h2o_mlops_autogen.V1RuntimeImageVersion,
    ):
        self._client = client
        self._runtime_image = runtime_image
        self._raw_info = raw_info
        self._resource_name = raw_info.name

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    version={self.version!r},\n"
            f"    docker_image={self.docker_image!r},\n"
            f"    state={self.state!r},\n"
            f"    created_time={self.created_time!r},\n"
            f"    readiness_probe_path={self.readiness_probe_path!r},\n"
            f")>"
        )

    def __str__(self) -> str:
        return (
            f"Version: {self.version}\n"
            f"Docker Image: {self.docker_image}\n"
            f"State: {self.state}\n"
            f"Created Time: {self.created_time}\n"
            f"Readiness Probe Path: {self.readiness_probe_path}"
        )

    @property
    def version(self) -> str:
        """Version string (extracted from resource name)."""
        # Version is the last part of the resource name:
        # workspaces/*/runtimeImages/*/versions/{version}
        return _utils._convert_resource_name_to_uid(self._resource_name)

    @property
    def docker_image(self) -> str:
        """Docker image URI for this version."""
        return self._raw_info.image

    @property
    def state(self) -> str:
        """RuntimeImageVersion state."""
        return str(self._raw_info.state.value)

    @property
    def created_time(self) -> datetime:
        """RuntimeImageVersion creation time."""
        return self._raw_info.create_time

    @property
    def state_reason(self) -> str:
        """Reason for the current state."""
        return self._raw_info.state_reason

    @property
    def state_updated_time(self) -> datetime:
        """State last update time."""
        return self._raw_info.state_update_time

    @property
    def readiness_probe_path(self) -> Optional[str]:
        """HTTP path for readiness and startup K8s probes.

        If not set, defaults to /readyz on the server side.
        Use /model/schema for older images that do not implement /readyz.
        """
        return self._raw_info.readiness_probe_path

    def activate(self) -> None:
        """Activate this version."""
        backend = self._client._backend.runtime.runtime_image_version
        self._raw_info = backend.activate_runtime_image_version(
            name=self._resource_name,
            body={},
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version

    def deprecate(self, reason: Optional[str] = None) -> None:
        """Mark RuntimeImageVersion as deprecated.

        Args:
            reason: Optional reason for deprecation
        """
        backend = self._client._backend.runtime.runtime_image_version
        self._raw_info = backend.deprecate_runtime_image_version(
            name_1=self._resource_name,
            body=h2o_mlops_autogen.DeprecateRuntimeImageVersionRequest(reason=reason),
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version

    def disable(self, reason: Optional[str] = None) -> None:
        """Disable RuntimeImageVersion."""
        backend = self._client._backend.runtime.runtime_image_version
        self._raw_info = backend.disable_runtime_image_version(
            name_1=self._resource_name,
            body=h2o_mlops_autogen.DisableRuntimeImageVersionRequest(reason=reason),
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version


class MLOpsRuntimeImageVersions:
    """Manage RuntimeImageVersion resources for a RuntimeImage."""

    def __init__(self, client: _core.Client, runtime_image: MLOpsRuntimeImage):
        self._client = client
        self._runtime_image = runtime_image
        self._parent_resource_name = runtime_image._resource_name

        self._field_name_mapping = {
            "version": "version",
            "state": "state",
            "created_time": "create_time",
        }

    def get(self, version: str) -> MLOpsRuntimeImageVersion:
        """Get RuntimeImageVersion by version.

        Args:
            version: Version string (e.g., "v1.0.0" or "1.0.0")

        Returns:
            MLOpsRuntimeImageVersion object
        """
        backend = self._client._backend.runtime.runtime_image_version
        raw_info = backend.get_runtime_image_version(
            name_1=f"{self._parent_resource_name}/versions/{version}",
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version
        return MLOpsRuntimeImageVersion(self._client, self._runtime_image, raw_info)

    def list(  # noqa A003
        self,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """List RuntimeImageVersions for this RuntimeImage.

        Examples::

            # Get runtime image
            image = mlops.runtimes.images.get("image-uid")

            # List versions
            versions = image.versions.list()

            # Get specific version
            version = image.versions.list()[0]
        """
        return self._list(opts=opts, **selectors)

    def create(
        self,
        docker_image: str,
        version: Optional[str] = None,
        readiness_probe_path: Optional[str] = None,
    ) -> MLOpsRuntimeImageVersion:
        """Create new RuntimeImageVersion.

        Args:
            docker_image: Docker image URI (e.g., "docker.io/h2oai/runtime:1.0.0")
            version: Optional version string (e.g., "v1.0.0" or "1.0.0").
                If not specified, version will be extracted from the docker image tag.
                Required when the docker image tag is not a standard semantic version
                (e.g., "latest", "stable", custom tags).
                Examples:
                - docker_image="h2oai/scorer:2.3.5" → version extracted: "v2.3.5"
                - docker_image="h2oai/scorer:latest", version="v1.0.0" →
                version used: "v1.0.0"
            readiness_probe_path: Optional HTTP path for readiness and startup K8s
                probes. If not set, defaults to /readyz on the server side.
                Use /model/schema for older images that do not implement /readyz.

        Returns:
            Created MLOpsRuntimeImageVersion object
        """
        backend = self._client._backend.runtime.runtime_image_version
        raw_info = backend.create_runtime_image_version(
            parent=self._parent_resource_name,
            runtime_image_version=h2o_mlops_autogen.V1RuntimeImageVersion(
                image=docker_image,
                readiness_probe_path=readiness_probe_path,
            ),
            runtime_image_version_id=version,
            _request_timeout=self._client._global_request_timeout,
        ).runtime_image_version

        return MLOpsRuntimeImageVersion(self._client, self._runtime_image, raw_info)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count RuntimeImageVersions."""
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression, **selectors
        )
        backend = self._client._backend.runtime.runtime_image_version
        return int(
            backend.count_runtime_image_versions(
                parent=self._parent_resource_name,
                filter=_utils._convert_filter_expression_to_string(
                    filter_expression, self._field_name_mapping
                ),
                _request_timeout=self._client._global_request_timeout,
            ).count
        )

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        """Internal list implementation with pagination."""
        backend = self._client._backend.runtime.runtime_image_version
        response = backend.list_runtime_image_versions(
            parent=self._parent_resource_name,
            page_token=page_token,
            **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
            _request_timeout=self._client._global_request_timeout,
        )
        data = [
            {
                "version": _utils._convert_resource_name_to_uid(r.name),
                "docker_image": r.image,  # Docker image URI
                "state": r.state,
                "raw_info": r,
            }
            for r in response.runtime_image_versions
        ]
        return _utils.Table(
            data=data,
            keys=["version", "docker_image", "state"],
            get_method=lambda x: MLOpsRuntimeImageVersion(
                self._client, self._runtime_image, x["raw_info"]
            ),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=self.count,
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )


# ============================================================================
# Runtime Container for Client-Level Access
# ============================================================================


class MLOpsRuntimes:
    """Container for runtime-related resources with cross-workspace access."""

    def __init__(self, client: _core.Client):
        self._client = client

    @property
    def scoring(self) -> MLOpsScoringRuntimes:
        """Access artifact composition scoring runtimes.

        Scoring runtimes are compositions that include:
        - artifact_type: Type of model artifact
        - artifact_processor: How to process the artifact
        - runtime: The runtime environment (MLOpsScoringRuntimeInfo)
        - model_type: Type of model
        """
        return MLOpsScoringRuntimes(client=self._client)

    def list(self, **kwargs: Any) -> _utils.Table:  # noqa A003
        """List runtimes across all workspaces."""
        return MLOpsAllRuntimes(self._client).list(**kwargs)

    def count(self, **kwargs: Any) -> int:
        """Count runtimes across all workspaces."""
        return MLOpsAllRuntimes(self._client).count(**kwargs)


class MLOpsScoringRuntime:
    def __init__(self, raw_info: h2o_mlops_autogen.V2ArtifactComposition):
        self._raw_info = raw_info

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    runtime={self.runtime.uid!r},\n"
            f"    artifact_type={self.artifact_type.uid!r},\n"
            f"    artifact_processor={self.artifact_processor.uid!r},\n"
            f"    model_type={self.model_type.uid!r},\n"
            f")'>"
        )

    def __str__(self) -> str:
        return (
            f"Runtime: {self.runtime.name}\n"
            f"Artifact Type: {self.artifact_type.name}\n"
            f"Artifact Processor: {self.artifact_processor.name}\n"
            f"Model Type: {self.model_type.name}"
        )

    @property
    def runtime(self) -> MLOpsScoringRuntimeInfo:
        r = self._raw_info.runtime
        return MLOpsScoringRuntimeInfo(
            uid=r.name,
            name=r.display_name,
            model_type=r.model_type,
            image=r.image,
            state=r.state,
        )

    @property
    def artifact_type(self) -> MLOpsArtifactType:
        at = self._raw_info.deployable_artifact_type
        return MLOpsArtifactType(
            uid=at.name,
            name=at.display_name,
            artifact_type=at.artifact_type,
        )

    @property
    def artifact_processor(self) -> MLOpsArtifactProcessor:
        ap = self._raw_info.artifact_processor
        return MLOpsArtifactProcessor(
            uid=ap.name,
            name=ap.display_name,
            artifact_type=ap.deployable_artifact_type,
            model_type=ap.model_type,
            image=ap.image,
        )

    @property
    def model_type(self) -> MLOpsModelType:
        mt = self._raw_info.model_type
        return MLOpsModelType(uid=mt.name, name=mt.display_name)


class MLOpsScoringRuntimes:
    def __init__(self, client: _core.Client):
        self._client = client

    def get(self, artifact_type: str, runtime_uid: str) -> MLOpsScoringRuntime:
        """Get the Scoring Runtime object corresponding
        to a Scoring Runtime in H2O MLOps.

        Args:
            artifact_type: H2O MLOps unique ID of the Artifact Type.
            runtime_uid: H2O MLOps unique ID of the Runtime.
        """
        scoring_runtime_table = self.list(
            artifact_type=artifact_type, runtime_uid=runtime_uid
        )
        if not scoring_runtime_table:
            raise LookupError(
                f"Scoring runtime for artifact_type='{artifact_type}' and "
                f"runtime_uid='{runtime_uid}' not found."
            )
        return scoring_runtime_table[0]

    def list(self, **selectors: Any) -> _utils.Table:  # noqa A003
        """Retrieve Table of Scoring Runtimes available in the H2O MLOps.

        Examples::

            # filter on columns by using selectors
            mlops.runtimes.scoring.list(runtime_uid="demo")

            # use an index to get an H2O MLOps entity referenced by the table
            scoring_runtime = mlops.runtimes.scoring.list()[0]
        """
        srv = self._client._backend.deployer.composition
        compositions = srv.list_artifact_compositions(
            _request_timeout=self._client._global_request_timeout,
        ).artifact_compositions
        data = [
            {
                "artifact_type": c.deployable_artifact_type.name,
                "runtime_uid": c.runtime.name,
                "runtime_name": c.runtime.display_name,
                "raw_info": c,
            }
            for c in compositions
        ]
        return _utils.Table(
            data=data,
            keys=["artifact_type", "runtime_uid", "runtime_name"],
            get_method=lambda x: MLOpsScoringRuntime(x["raw_info"]),
            **selectors,
        )


class MLOpsScoringRuntimeInfo(NamedTuple):
    """Information about a scoring runtime from composition service."""

    uid: str
    name: str
    model_type: str
    image: str
    state: str


# Backward compatibility alias for code written before Runtime Management API
# was introduced. In older versions, MLOpsRuntime was this NamedTuple.
# The Runtime API resource class is now named MLOpsRuntimeResource.
MLOpsRuntime = MLOpsScoringRuntimeInfo


class MLOpsArtifactType(NamedTuple):
    uid: str
    name: str
    artifact_type: str


class MLOpsArtifactProcessor(NamedTuple):
    uid: str
    name: str
    artifact_type: str
    model_type: str
    image: str


class MLOpsModelType(NamedTuple):
    uid: str
    name: str
