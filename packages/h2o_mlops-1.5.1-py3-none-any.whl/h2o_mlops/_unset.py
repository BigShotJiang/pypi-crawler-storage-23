class UnsetType:
    pass


UNSET = UnsetType()
