from __future__ import annotations

import time
from datetime import datetime
from typing import Any, Optional, Union

from h2o_mlops import (
    _core,
    _deployments,
    _utils,
    _workspaces,
    h2o_mlops_autogen,
    options,
)
from h2o_mlops._unset import UNSET, UnsetType
from h2o_mlops.errors import MLOpsEndpointError


class MLOpsEndpoint:
    """Interact with an Endpoint on H2O MLOps."""

    def __init__(
        self,
        client: _core.Client,
        workspace: _workspaces.Workspace,
        raw_info: h2o_mlops_autogen.V2Endpoint,
    ):
        self._client = client
        self._workspace = workspace
        self._raw_info = raw_info

        self._resource_name = raw_info.name
        self._parent_resource_name = raw_info.name.rsplit("/", 2)[0]

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    name={self.name!r},\n"
            f"    description={self.description!r},\n"
            f"    path={self.path!r},\n"
            f"    created_time={self.created_time!r},\n"
            f"    last_modified_time={self.last_modified_time!r},\n"
            f")'>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Name: {self.name}\n"
            f"Description: {self.description}\n"
            f"Path: {self.path}\n"
            f"Created Time: {self.created_time}\n"
            f"Last Modified Time: {self.last_modified_time}"
        )

    @property
    def uid(self) -> str:
        """Endpoint unique ID."""
        return _utils._convert_resource_name_to_uid(
            resource_name=self._resource_name,
        )

    @property
    def name(self) -> str:
        """Endpoint display name."""
        return self._raw_info.display_name

    @property
    def description(self) -> str:
        """Endpoint description."""
        return self._raw_info.description

    @property
    def path(self) -> str:
        """Path of the Endpoint appends to the MLOps URL."""
        return self._raw_info.path

    @property
    def created_time(self) -> datetime:
        """Endpoint created time."""
        return self._raw_info.create_time

    @property
    def last_modified_time(self) -> datetime:
        """Endpoint last modified time."""
        return self._raw_info.update_time

    @property
    def target_deployment(self) -> Optional[_deployments.MLOpsScoringDeployment]:
        """MLOps deployment the Endpoint points to."""
        self._refresh()
        if self._raw_info.target:
            target_uid = self._raw_info.target.split("/")[-1]
            return self._workspace.deployments.get(target_uid)
        return None

    @property
    def state(self) -> str:
        """Endpoint state."""
        self._refresh()
        return str(self._raw_info.state.value)

    @property
    def is_ready(self) -> bool:
        """Indicates whether the endpoint is in a Ready state."""
        return self.state == h2o_mlops_autogen.V2EndpointState.ENDPOINT_STATE_READY

    def wait_for_ready(
        self, timeout: int = 60, interval: int = 5, fail_fast: bool = True
    ) -> None:
        """Waits for the endpoint to become ready.

        Args:
            timeout: Maximum time to wait in seconds. Default is 60.
            interval: Time to wait between checks in seconds. Default is 5.
            fail_fast: If True, raises immediately when endpoint enters an error
                state. Default is True.

        Raises:
            MLOpsEndpointError: If the endpoint has no target configured, or if
                fail_fast is True and the endpoint enters an error state.
            TimeoutError: If the endpoint does not become ready within the timeout
                period.
        """
        start_time = time.monotonic()
        while True:
            curr_state = self.state
            if curr_state == h2o_mlops_autogen.V2EndpointState.ENDPOINT_STATE_READY:
                return
            # _raw_info is refreshed by self.state above, so target is up to date.
            if not self._raw_info.target:
                raise MLOpsEndpointError(
                    "Endpoint has no target configured "
                    "and will never become ready without a target."
                )
            if (
                fail_fast
                and curr_state == h2o_mlops_autogen.V2EndpointState.ENDPOINT_STATE_ERROR
            ):
                raise MLOpsEndpointError("Endpoint is in an error state.")
            if time.monotonic() - start_time > timeout:
                raise TimeoutError(
                    "Endpoint did not become ready within the timeout period."
                )
            time.sleep(interval)

    def raise_for_error(self) -> None:
        """Raise an error if Endpoint status is Error."""
        if self.state == h2o_mlops_autogen.V2EndpointState.ENDPOINT_STATE_ERROR:
            raise MLOpsEndpointError("Endpoint is in an error state.")

    def update(
        self,
        name: Optional[str] = None,
        description: Optional[Union[str, UnsetType]] = UNSET,
        target_deployment: Optional[
            Union[_deployments.MLOpsScoringDeployment, UnsetType]
        ] = UNSET,
    ) -> None:
        """Change Endpoint settings.

        Args:
           name: display name for the Endpoint
           description: description for the Endpoint
           target_deployment: MLOps deployment the Endpoint points to.
               Set to empty string to disable the Endpoint.
        """
        from h2o_mlops._autogen._h2o_mlops_client.deployer.v2.configuration import (
            Configuration,
        )

        local_vars_configuration = Configuration()
        local_vars_configuration.client_side_validation = False

        update_mask = []
        endpoint = h2o_mlops_autogen.TheEndpointToUpdateWhereTheEndpointSNameFieldIsUsedToIdentifyTheOneToUpdate(  # noqa E501
            path=self.path, local_vars_configuration=local_vars_configuration
        )
        if name is not None:
            endpoint.display_name = name
            update_mask.append("display_name")
        if not isinstance(description, UnsetType):
            endpoint.description = description
            update_mask.append("description")
        if not isinstance(target_deployment, UnsetType):
            if target_deployment:
                deployment_resource_name = (
                    f"{self._parent_resource_name}/deployments/{target_deployment.uid}"
                )
                endpoint.target = deployment_resource_name
            update_mask.append("target")
        if update_mask:
            self._raw_info = self._client._backend.deployer.endpoint.update_endpoint(
                endpoint_name=self._resource_name,
                endpoint=endpoint,
                update_mask=",".join(update_mask),
                _request_timeout=self._client._global_request_timeout,
            ).endpoint

    def delete(self) -> None:
        """Delete Endpoint from the H2O MLOps."""
        self._client._backend.deployer.endpoint.delete_endpoint(
            name_1=self._resource_name,
            _request_timeout=self._client._global_request_timeout,
        )

    def _refresh(self) -> None:
        self._raw_info = self._client._backend.deployer.endpoint.get_endpoint(
            name_3=self._resource_name,
            _request_timeout=self._client._global_request_timeout,
        ).endpoint


class MLOpsEndpoints:
    def __init__(
        self,
        client: _core.Client,
        workspace: _workspaces.Workspace,
    ):
        self._client = client
        self._workspace = workspace
        self._parent_resource_name = f"workspaces/{self._workspace.uid}"

        self._field_name_mapping = {
            "name": "display_name",
            "description": "description",
            "path": "path",
            "target_deployment": "target",
            "created_time": "create_time",
            "last_modified_time": "update_time",
        }

    def create(
        self,
        name: str,
        path: str,
        description: Optional[str] = None,
        target_deployment: Optional[_deployments.MLOpsScoringDeployment] = None,
    ) -> MLOpsEndpoint:
        """Create an Endpoint in H2O MLOps.

        Args:
           name: display name for the Endpoint
           path: path to use for the target deployment URLs
           description: description for the Endpoint
           target_deployment: MLOps deployment the Endpoint points to
        """
        raw_info = self._client._backend.deployer.endpoint.create_endpoint(
            parent=self._parent_resource_name,
            endpoint=h2o_mlops_autogen.V2Endpoint(
                display_name=name,
                description=description or "",
                path=path,
                target=(
                    f"{self._parent_resource_name}/deployments/{target_deployment.uid}"  # noqa E501
                    if target_deployment
                    else None
                ),
            ),
            _request_timeout=self._client._global_request_timeout,
        ).endpoint
        return MLOpsEndpoint(self._client, self._workspace, raw_info)

    def get(
        self,
        uid: Optional[str] = None,
        path: Optional[str] = None,
    ) -> MLOpsEndpoint:
        """Get the Endpoint object corresponding to an H2O MLOps Endpoint.

        Args:
            uid: H2O MLOps unique ID for the Endpoint.
            path: H2O MLOps unique Endpoint path to use for
                the target deployment URLs.
        """
        if uid:
            raw_info = self._client._backend.deployer.endpoint.get_endpoint(
                name_3=f"{self._parent_resource_name}/endpoints/{uid}",
                _request_timeout=self._client._global_request_timeout,
            ).endpoint

            if path and raw_info.path != path:
                raise ValueError(
                    "Provided 'uid' is associated with a different "
                    "'path' than the one given."
                )
            return MLOpsEndpoint(self._client, self._workspace, raw_info)
        if path:
            endpoint_table = self.list(
                opts=options.ListOptions(
                    filter_expression=options.FilterExpression(
                        filters=[
                            options.FilterOptions(field="path", value=path),
                        ],
                    )
                )
            )
            if not endpoint_table:
                raise LookupError(f"Endpoint not found for path '{path}'.")
            return endpoint_table[0]
        raise ValueError(
            "Either 'uid' or 'path' must be provided to retrieve an endpoint."
        )

    def list(  # noqa A003
        self, opts: Optional[options.ListOptions] = None, **selectors: Any
    ) -> _utils.Table:
        """Retrieve Table of Endpoint available in the Environment.

        Examples::

            # filter on columns by using selectors
            workspace.endpoints.list(name="endpoint-demo")

            # use an index to get an H2O MLOps entity referenced by the table
            endpoint = workspace.endpoints.list()[0]
        """
        return self._list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count the Endpoints available in the Workspace."""
        if selectors and "target_deployment_uid" in selectors:
            selectors["target_deployment"] = (
                f"{self._parent_resource_name}/"
                f"deployments/{selectors.pop('target_deployment_uid')}"
            )
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression, **selectors
        )
        return int(
            self._client._backend.deployer.endpoint.count_endpoints(
                parent=self._parent_resource_name,
                filter=_utils._convert_filter_expression_to_string(
                    filter_expression, self._field_name_mapping
                ),
                _request_timeout=self._client._global_request_timeout,
            ).count
        )

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        response = self._client._backend.deployer.endpoint.list_endpoints(
            parent=self._parent_resource_name,
            page_token=page_token,
            **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
            _request_timeout=self._client._global_request_timeout,
        )
        data = [
            {
                "name": e.display_name,
                "path": e.path,
                "uid": e.name.split("/")[-1],
                "target_deployment_uid": e.target.split("/")[-1] if e.target else "",
                "raw_info": e,
            }
            for e in response.endpoints
        ]
        return _utils.Table(
            data=data,
            keys=["name", "path", "uid", "target_deployment_uid"],
            get_method=lambda x: MLOpsEndpoint(
                self._client, self._workspace, x["raw_info"]
            ),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=self.count if {"uid"}.isdisjoint(selectors) else None,
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )
