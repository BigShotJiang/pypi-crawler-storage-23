from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from h2o_secure_store.clients.secret.secret import Secret as H2OSecureStoreSecret
from h2o_secure_store.clients.secret_version.secret_version import (
    SecretVersion as H2OSecureStoreSecretVersion,
)

from h2o_mlops import _core, _users, _utils, _workspaces


class Secret:
    def __init__(self, client: _core.Client, raw_info: H2OSecureStoreSecret):
        self._client = client
        self._raw_info = raw_info

        self._resource_name = raw_info.name
        self._creator_uid = _utils._convert_resource_name_to_uid(
            resource_name=raw_info.creator,
        )

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    name={self.name!r},\n"
            f"    key={self.key!r},\n"
            f"    state={self.state!r},\n"
            f"    creator_uid={self._creator_uid!r},\n"
            f"    created_time={self.created_time!r},\n"
            f")'>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Name: {self.name}\n"
            f"Key: {self.key}\n"
            f"State: {self.state}\n"
            f"Creator UID: {self._creator_uid}\n"
            f"Created Time: {self.created_time}"
        )

    @property
    def uid(self) -> str:
        """Secret unique ID."""
        return self._raw_info.uid

    @property
    def name(self) -> str:
        """Secret display name."""
        return self._raw_info.display_name

    @property
    def key(self) -> str:
        """Secret key."""
        return self._raw_info.get_secret_id()

    @property
    def state(self) -> str:
        """Secret state."""
        return self._raw_info.state.value

    @property
    def creator(self) -> _users.MLOpsUser:
        """Secret creator."""
        return self._client.users.get(self._creator_uid)

    @property
    def created_time(self) -> datetime:
        """Secret created time."""
        return self._raw_info.create_time

    @property
    def deleted_time(self) -> Optional[datetime]:
        """Secret deleted time."""
        return self._raw_info.delete_time

    @property
    def purge_time(self) -> Optional[datetime]:
        """Time when the Secret is scheduled to be purged."""
        return self._raw_info.purge_time

    @property
    def annotations(self) -> Dict[str, str]:
        """Secret annotations."""
        return self._raw_info.annotations

    def versions(self, **selectors: Any) -> _utils.Table:
        """Retrieve Table of the H2O Secure Store Secret's Versions.

        Examples::

            # filter on columns by using selectors
            secret.versions(uid="12xt4d")

            # use an index to get an H2O Secure Store entity referenced by the table
            secret_version = secret.versions()[0]
        """
        secret_versions = []
        srv = self._client._h2o_secure_store.secret_version_client
        response = srv.list_secret_versions(parent=self._resource_name)
        secret_versions += response.secret_versions
        while response.next_page_token:
            response = srv.list_secret_versions(
                parent=self._resource_name,
                page_token=response.next_page_token,
            )
            secret_versions += response.secret_versions
        data = [
            {
                "uid": sv.uid,
                "version": sv.get_secret_version_id(),
                "creator_uid": _utils._convert_resource_name_to_uid(
                    resource_name=sv.creator,
                ),
                "created_time": sv.create_time.strftime("%Y-%m-%d %I:%M:%S %p"),
            }
            for sv in secret_versions
        ]
        return _utils.Table(
            data=data,
            keys=["created_time", "version", "creator_uid"],
            get_method=lambda x: x,
            **selectors,
        )

    def reveal(self, version: str = "latest") -> bytes:
        """Reveal secret."""
        srv = self._client._h2o_secure_store.secret_version_client
        return srv.reveal_secret_version_value(
            name=f"{self._resource_name}/versions/{version}",
        )

    def update(self, value: bytes) -> None:
        """Update secret.

        Args:
            value: The secret payload. (Must be no larger than 64KiB.)
        """
        self._client._h2o_secure_store.secret_version_client.create_secret_version(
            parent=self._resource_name,
            secret_version=H2OSecureStoreSecretVersion(
                value=value,
            ),
        )

    def delete(self) -> None:
        """Delete secret."""
        self._client._h2o_secure_store.secret_client.delete_secret(
            name=self._resource_name,
        )

    def restore(self) -> None:
        """Restore secret."""
        self._client._h2o_secure_store.secret_client.undelete_secret(
            name=self._resource_name,
        )

    def _refresh(self) -> None:
        self._raw_info = self._client._h2o_secure_store.secret_client.get_secret(
            name=self._resource_name,
        )


class Secrets:
    def __init__(
        self,
        client: _core.Client,
        workspace: _workspaces.Workspace,
    ):
        self._client = client
        self._workspace = workspace
        self._parent_resource_name = f"workspaces/{self._workspace.uid}"

    def create(
        self,
        name: Optional[str] = None,
        key: Optional[str] = None,
        value: Optional[bytes] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Secret:
        """Create a Secret in H2O Secure Store.

        Args:
            name: Human-readable name of the Secret.
            key: The unique key to use for the Secret. If left unspecified,
            the server will generate one.
            This value must:
                - contain 1-63 characters
                - contain only lowercase alphanumeric characters or hyphen ('-')
                - start with an alphabetic character
                - end with an alphanumeric character
            value: The secret payload. (Must be no larger than 64KiB.)
            annotations: Arbitrary metadata associated with the Secret.
        """
        raw_info = self._client._h2o_secure_store.secret_client.create_secret(
            parent=self._parent_resource_name,
            secret_id=key or "",
            display_name=name or "",
            annotations=annotations,
        )
        if value:
            self._client._h2o_secure_store.secret_version_client.create_secret_version(
                parent=raw_info.name,
                secret_version=H2OSecureStoreSecretVersion(
                    value=value,
                ),
            )
        return Secret(client=self._client, raw_info=raw_info)

    def get(self, key: str) -> Secret:
        """Get the Secret object corresponding to an H2O Secure Store Secret.

        Args:
            key: The unique key to use for the Secret.
        """
        raw_info = self._client._h2o_secure_store.secret_client.get_secret(
            name=f"{self._parent_resource_name}/secrets/{key}",
        )
        return Secret(client=self._client, raw_info=raw_info)

    def list(self, **selectors: Any) -> _utils.Table:  # noqa A003
        """Retrieve Table of H2O Secure Store Secrets available in the Workspace.

        Examples::

            # filter on columns by using selectors
            workspace.secrets.list(name="demo")

            # use an index to get an H2O Secure Store entity referenced by the table
            secret = workspace.secrets.list()[0]
        """
        secrets = []
        response = self._client._h2o_secure_store.secret_client.list_secrets(
            parent=self._parent_resource_name,
            show_deleted=True,
        )
        secrets += response.secrets
        while response.next_page_token:
            response = self._client._h2o_secure_store.secret_client.list_secrets(
                parent=self._parent_resource_name,
                show_deleted=True,
                page_token=response.next_page_token,
            )
            secrets += response.secrets
        data = [
            {
                "name": s.display_name,
                "key": s.get_secret_id(),
                "state": s.state.value,
                "raw_info": s,
            }
            for s in secrets
        ]
        return _utils.Table(
            data=data,
            keys=["name", "key", "state"],
            get_method=lambda x: Secret(self._client, x["raw_info"]),
            **selectors,
        )
