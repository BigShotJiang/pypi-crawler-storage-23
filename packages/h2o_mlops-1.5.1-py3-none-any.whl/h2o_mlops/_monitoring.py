from __future__ import annotations

from datetime import datetime
from typing import Any, Optional, Union

from h2o_mlops import _core, _utils, h2o_mlops_autogen, options, types


class MLOpsMonitoring:
    def __init__(self, client: _core.Client, parent_resource_name: str):
        self._client = client
        self._parent_resource_name = parent_resource_name

        # It helps to use the *2 version of the method if parent resource is a job
        self._is_batch_scoring_job = "jobs" in parent_resource_name

    @property
    def baseline_aggregates(self) -> MLOpsBaselineAggregates:
        return MLOpsBaselineAggregates(
            client=self._client,
            parent_resource_name=f"{self._parent_resource_name}/experiments/-",
            is_batch_scoring_job=self._is_batch_scoring_job,
        )

    @property
    def scoring_aggregates(self) -> MLOpsScoringAggregates:
        return MLOpsScoringAggregates(
            client=self._client,
            parent_resource_name=f"{self._parent_resource_name}/experiments/-",
            is_batch_scoring_job=self._is_batch_scoring_job,
        )

    def delete(self) -> None:
        """Delete monitoring data for the deployment, including baselines."""
        if self._is_batch_scoring_job:
            raise NotImplementedError(
                "Deleting monitoring data for batch scoring jobs is unsupported."
            )
        self._client._backend.deployer.deployment.delete_deployment_monitoring(
            name=self._parent_resource_name,
            _request_timeout=self._client._global_request_timeout,
        )


class MLOpsMonitoringAggregate:
    def __init__(
        self,
        raw_info: Union[
            h2o_mlops_autogen.MonitoringV2BaselineAggregation,
            h2o_mlops_autogen.MonitoringV2ScoringAggregation,
        ],
    ):
        self._raw_info = raw_info

    @property
    def uid(self) -> str:
        """Monitoring aggregate unique ID."""
        return self._raw_info.id

    @property
    def column(self) -> options.Column:
        """Monitoring aggregate column."""
        return options.Column(
            name=self._raw_info.column,
            logical_type=types.ColumnLogicalType._from_raw_info(
                raw_info=getattr(self._raw_info, "logical_type", None),
            ),
            is_model_output=self._raw_info.is_model_output,
        )

    @property
    def numerical_aggregate(self) -> Optional[options.NumericalAggregate]:
        """Monitoring numerical aggregate."""
        if raw_info := self._raw_info.numerical_aggregate:
            return options.NumericalAggregate._from_raw_info(raw_info)
        return None

    @property
    def categorical_aggregate(self) -> Optional[options.CategoricalAggregate]:
        """Monitoring categorical aggregate."""
        if raw_info := self._raw_info.categorical_aggregate:
            return options.CategoricalAggregate._from_raw_info(raw_info)
        return None

    @property
    def text_aggregate(self) -> Optional[options.TextAggregate]:
        """Monitoring text aggregate."""
        if raw_info := self._raw_info.text_aggregate:
            return options.TextAggregate._from_raw_info(raw_info)
        return None

    @property
    def missing_values(self) -> Optional[options.MissingValues]:
        """Monitoring data missing values."""
        if raw_info := self._raw_info.missing_values:
            return options.MissingValues._from_raw_info(raw_info)
        return None


class MLOpsBaselineAggregate(MLOpsMonitoringAggregate):
    def __init__(self, raw_info: h2o_mlops_autogen.MonitoringV2BaselineAggregation):
        super().__init__(raw_info)

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    column={self.column.name!r},\n"
            f"    logical_type={self.column.logical_type!r},\n"
            f"    is_model_output={self.column.is_model_output!r},\n"
            f")'>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Column: {self.column.name}\n"
            f"Logical Type: {self.column.logical_type}\n"
            f"Is Model Output: {self.column.is_model_output}"
        )


class MLOpsScoringAggregate(MLOpsMonitoringAggregate):
    def __init__(self, raw_info: h2o_mlops_autogen.MonitoringV2ScoringAggregation):
        super().__init__(raw_info)
        self._local_raw_info = raw_info

    def __repr__(self) -> str:
        return (
            f"<class '{self.__class__.__module__}.{self.__class__.__name__}(\n"
            f"    uid={self.uid!r},\n"
            f"    column={self.column.name!r},\n"
            f"    logical_type={self.column.logical_type!r},\n"
            f"    is_model_output={self.column.is_model_output!r},\n"
            f"    timestamp={self.timestamp!r},\n"
            f"    aggregation_window={self.aggregation_window!r},\n"
            f")'>"
        )

    def __str__(self) -> str:
        return (
            f"UID: {self.uid}\n"
            f"Column: {self.column.name}\n"
            f"Logical Type: {self.column.logical_type}\n"
            f"Is Model Output: {self.column.is_model_output}\n"
            f"Timestamp: {self.timestamp!r}\n"
            f"Aggregation Window: {self.aggregation_window!r}"
        )

    @property
    def timestamp(self) -> datetime:
        """Scoring aggregation start time."""
        return self._local_raw_info.start_time

    @property
    def aggregation_window(self) -> str:
        """Scoring aggregation window."""
        return self._local_raw_info.segment_duration


class MLOpsBaselineAggregates:
    def __init__(
        self,
        client: _core.Client,
        parent_resource_name: str,
        is_batch_scoring_job: bool,
    ):
        self._client = client
        self._parent_resource_name = parent_resource_name
        self._is_batch_scoring_job = is_batch_scoring_job

        self._field_name_mapping = {
            "uid": "id",
            "experiment_uids": "experiment_ids",
            "column": "column_name",
            "type": "logical_type",
            "timestamp": "timestamp",
        }

    def list(  # noqa A003
        self, opts: Optional[options.ListOptions] = None, **selectors: Any
    ) -> _utils.Table:
        """Retrieve Table of Baseline Aggregates available for the Experiment.

        Args:
            opts: Optional ListOptions for sorting and filtering.
            **selectors: Keyword arguments for filtering (e.g., column="age").

        Returns:
            Table of baseline aggregates with columns: column, type,
            is_model_output, uid.

        Examples::

            # List all baseline aggregates
            aggregates = deployment.monitoring.baseline_aggregates.list()

            # Filter on specific column using selectors
            age_aggregates = (
                deployment.monitoring.baseline_aggregates.list(column="age")
            )

            # Get a single baseline aggregate by index
            first_aggregate = deployment.monitoring.baseline_aggregates.list()[0]
            print(f"Column: {first_aggregate.column.name}")
            print(f"UID: {first_aggregate.uid}")

            # Access aggregate properties
            if first_aggregate.numerical_aggregate:
                print(f"Mean: {first_aggregate.numerical_aggregate.mean_value}")
                print(
                    f"Std Dev: "
                    f"{first_aggregate.numerical_aggregate.standard_deviation}"
                )

            if first_aggregate.categorical_aggregate:
                print(
                    f"Value Counts: "
                    f"{first_aggregate.categorical_aggregate.value_counts}"
                )

            # Iterate through all baseline aggregates
            for aggregate in deployment.monitoring.baseline_aggregates.list():
                print(
                    f"Column: {aggregate.column.name}, "
                    f"Type: {aggregate.column.logical_type}"
                )
        """
        return self._list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count the Baseline Aggregates available for the Experiment."""
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression, **selectors
        )
        filter_str = _utils._convert_filter_expression_to_string(
            filter_expression, self._field_name_mapping
        )
        if self._is_batch_scoring_job:
            result = (
                self._client._backend.monitoring.aggregate.count_baseline_aggregates2(
                    parent_1=self._parent_resource_name,
                    filter=filter_str,
                    _request_timeout=self._client._global_request_timeout,
                )
            )
        else:
            result = (
                self._client._backend.monitoring.aggregate.count_baseline_aggregates(
                    parent=self._parent_resource_name,
                    filter=filter_str,
                    _request_timeout=self._client._global_request_timeout,
                )
            )
        return int(result.count)

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        if self._is_batch_scoring_job:
            response = (
                self._client._backend.monitoring.aggregate.list_baseline_aggregates2(
                    parent_1=self._parent_resource_name,
                    page_token=page_token,
                    **_utils._convert_list_opts_to_api_args(
                        opts, self._field_name_mapping
                    ),
                    _request_timeout=self._client._global_request_timeout,
                )
            )
        else:
            response = (
                self._client._backend.monitoring.aggregate.list_baseline_aggregates(
                    parent=self._parent_resource_name,
                    page_token=page_token,
                    **_utils._convert_list_opts_to_api_args(
                        opts, self._field_name_mapping
                    ),
                    _request_timeout=self._client._global_request_timeout,
                )
            )
        data = [
            {
                "column": ba.column,
                "type": ba.logical_type,
                "is_model_output": ba.is_model_output,
                "uid": ba.id,
                "raw_info": ba,
            }
            for ba in response.baseline_aggregates
        ]
        return _utils.Table(
            data=data,
            keys=["column", "type", "is_model_output", "uid"],
            get_method=lambda x: MLOpsBaselineAggregate(x["raw_info"]),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=(
                self.count if {"is_model_output"}.isdisjoint(selectors) else None
            ),
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )


class MLOpsScoringAggregates:
    def __init__(
        self,
        client: _core.Client,
        parent_resource_name: str,
        is_batch_scoring_job: bool,
    ):
        self._client = client
        self._parent_resource_name = parent_resource_name
        self._is_batch_scoring_job = is_batch_scoring_job

        self._field_name_mapping = {
            "uid": "id",
            "experiment_uids": "experiment_ids",
            "column": "column_name",
            "type": "logical_type",
            "timestamp": "timestamp",
        }

    def list(  # noqa A003
        self, opts: Optional[options.ListOptions] = None, **selectors: Any
    ) -> _utils.Table:
        """Retrieve Table of Scoring Aggregates available for the Experiment.

        Args:
            opts: Optional ListOptions for sorting and filtering.
            **selectors: Keyword arguments for filtering (e.g., column="age").

        Returns:
            Table of scoring aggregates with columns: timestamp, column,
            is_model_output, uid.

        Examples::

            # List all scoring aggregates
            aggregates = deployment.monitoring.scoring_aggregates.list()

            # Filter on specific column using selectors
            age_aggregates = (
                deployment.monitoring.scoring_aggregates.list(column="age")
            )

            # Get a single scoring aggregate by index
            first_aggregate = (
                deployment.monitoring.scoring_aggregates.list()[0]
            )
            print(f"Column: {first_aggregate.column.name}")
            print(f"UID: {first_aggregate.uid}")
            print(f"Timestamp: {first_aggregate.timestamp}")
            print(f"Aggregation Window: {first_aggregate.aggregation_window}")

            # Access aggregate properties
            if first_aggregate.numerical_aggregate:
                print(f"Mean: {first_aggregate.numerical_aggregate.mean_value}")
                print(
                    f"Std Dev: "
                    f"{first_aggregate.numerical_aggregate.standard_deviation}"
                )
                print(
                    f"Bin Edges: "
                    f"{first_aggregate.numerical_aggregate.bin_edges}"
                )
                print(
                    f"Bin Count: "
                    f"{first_aggregate.numerical_aggregate.bin_count}"
                )

            if first_aggregate.categorical_aggregate:
                print(
                    f"Value Counts: "
                    f"{first_aggregate.categorical_aggregate.value_counts}"
                )

            if first_aggregate.missing_values:
                print(f"Missing Rows: {first_aggregate.missing_values.row_count}")

            # Iterate through all scoring aggregates
            for aggregate in deployment.monitoring.scoring_aggregates.list():
                print(
                    f"Time: {aggregate.timestamp}, "
                    f"Column: {aggregate.column.name}"
                )
        """
        return self._list(opts=opts, **selectors)

    def count(
        self,
        filter_expression: Optional[options.FilterExpression] = None,
        **selectors: Any,
    ) -> int:
        """Count the Scoring Aggregates available for the Experiment."""
        if selectors and "experiment_uid" in selectors:
            selectors["experiment_uids"] = selectors.pop("experiment_uid")
        filter_expression = _utils._merge_selectors_with_filter(
            filter_expression,
            {"experiment_uids": types.OperatorType.CONTAINS},
            **selectors,
        )
        filter_str = _utils._convert_filter_expression_to_string(
            filter_expression, self._field_name_mapping
        )
        if self._is_batch_scoring_job:
            result = self._client._backend.monitoring.aggregate.count_aggregates2(
                parent_1=self._parent_resource_name,
                filter=filter_str,
                _request_timeout=self._client._global_request_timeout,
            )
        else:
            result = self._client._backend.monitoring.aggregate.count_aggregates(
                parent=self._parent_resource_name,
                filter=filter_str,
                _request_timeout=self._client._global_request_timeout,
            )
        return int(result.count)

    def _list(
        self,
        page_token: Optional[str] = None,
        opts: Optional[options.ListOptions] = None,
        **selectors: Any,
    ) -> _utils.Table:
        if self._is_batch_scoring_job:
            response = self._client._backend.monitoring.aggregate.list_aggregates2(
                parent_1=self._parent_resource_name,
                page_token=page_token,
                **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
                _request_timeout=self._client._global_request_timeout,
            )
        else:
            response = self._client._backend.monitoring.aggregate.list_aggregates(
                parent=self._parent_resource_name,
                page_token=page_token,
                **_utils._convert_list_opts_to_api_args(opts, self._field_name_mapping),
                _request_timeout=self._client._global_request_timeout,
            )
        data = [
            {
                "timestamp": a.start_time.strftime("%Y-%m-%d %I:%M:%S %p"),
                "column": a.column,
                "type": a.logical_type,
                "is_model_output": a.is_model_output,
                "experiment_uid": a.experiment_ids[0],
                "uid": a.id,
                "raw_info": a,
            }
            for a in response.aggregates
        ]
        return _utils.Table(
            data=data,
            keys=[
                "timestamp",
                "column",
                "type",
                "is_model_output",
                "experiment_uid",
                "uid",
            ],
            get_method=lambda x: MLOpsScoringAggregate(x["raw_info"]),
            list_method=self._list,
            list_args={"opts": opts, **selectors},
            next_page_token=response.next_page_token,
            count_method=(
                self.count if {"is_model_output"}.isdisjoint(selectors) else None
            ),
            count_args={
                "filter_expression": opts.filter_expression if opts else None,
                **selectors,
            },
            **selectors,
        )
