"""Shared utilities for AVP benchmarks."""
