"""Debate benchmark: multi-round deliberation on StrategyQA."""
