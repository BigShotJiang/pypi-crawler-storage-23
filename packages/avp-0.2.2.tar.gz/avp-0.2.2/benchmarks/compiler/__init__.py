"""Compiler (Plan-Execute) benchmark: 3-agent chain on MATH-500."""
