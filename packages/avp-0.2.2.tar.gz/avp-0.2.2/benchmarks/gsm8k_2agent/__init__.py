"""2-Agent GSM8K benchmark: Researcher → Solver handoff."""
