"""Supervisor (Router) benchmark: dynamic routing on MMLU."""
