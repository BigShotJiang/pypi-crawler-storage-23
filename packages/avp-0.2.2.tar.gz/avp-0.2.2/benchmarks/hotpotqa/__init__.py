"""HotpotQA multi-hop QA benchmark for AVP."""
