"""Fan-out aggregation benchmark: parallel specialists + aggregator."""
