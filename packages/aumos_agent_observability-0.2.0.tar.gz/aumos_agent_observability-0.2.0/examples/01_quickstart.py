"""Quickstart example for agent-observability.

Run this script after installing the package::

    pip install agent-observability
    python examples/01_quickstart.py

This script demonstrates the most common workflow. Replace the
placeholder logic below with real usage as the library evolves.
"""
from __future__ import annotations

import agent_observability


def main() -> None:
    print(f"agent-observability version: {agent_observability.__version__}")
    print("Quickstart complete. Extend this example with real usage.")


if __name__ == "__main__":
    main()
