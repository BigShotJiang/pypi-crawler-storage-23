# Code of Conduct

This project follows the AumOS organisation Code of Conduct.

Please read the full text at:
https://github.com/aumos-ai/.github/blob/main/CODE_OF_CONDUCT.md

In summary: be respectful, assume good faith, and keep discussions
focused on the technical work. Harassment and discrimination of any
kind are not tolerated.

To report a violation contact the maintainers via the email listed
in the organisation security policy.
