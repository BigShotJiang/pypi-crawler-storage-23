"""Synthetic datasets for agent-observability benchmarks."""
