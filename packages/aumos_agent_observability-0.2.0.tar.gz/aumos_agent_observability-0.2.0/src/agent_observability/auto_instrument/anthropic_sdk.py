"""AnthropicInstrumentor re-export from agent_observability.instrumentors."""
from __future__ import annotations

from agent_observability.instrumentors.anthropic_sdk import AnthropicInstrumentor

__all__ = ["AnthropicInstrumentor"]
