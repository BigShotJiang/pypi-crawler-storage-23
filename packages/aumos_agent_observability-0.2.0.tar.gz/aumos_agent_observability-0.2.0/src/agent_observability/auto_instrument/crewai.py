"""CrewAIInstrumentor re-export from agent_observability.instrumentors."""
from __future__ import annotations

from agent_observability.instrumentors.crewai import CrewAIInstrumentor

__all__ = ["CrewAIInstrumentor"]
