"""AutoGenInstrumentor re-export from agent_observability.instrumentors."""
from __future__ import annotations

from agent_observability.instrumentors.autogen import AutoGenInstrumentor

__all__ = ["AutoGenInstrumentor"]
