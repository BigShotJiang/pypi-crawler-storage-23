"""OpenAIInstrumentor re-export from agent_observability.instrumentors."""
from __future__ import annotations

from agent_observability.instrumentors.openai_sdk import OpenAIInstrumentor

__all__ = ["OpenAIInstrumentor"]
