"""LangChainInstrumentor re-export from agent_observability.instrumentors."""
from __future__ import annotations

from agent_observability.instrumentors.langchain import LangChainInstrumentor

__all__ = ["LangChainInstrumentor"]
