"""OTel GenAI semantic convention package."""
from __future__ import annotations
