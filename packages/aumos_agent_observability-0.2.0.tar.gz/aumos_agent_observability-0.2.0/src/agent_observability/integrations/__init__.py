"""Integration adapters for agent-observability.

Optional third-party integrations. Install extras to enable:

    pip install aumos-agent-observability[langfuse]
"""
