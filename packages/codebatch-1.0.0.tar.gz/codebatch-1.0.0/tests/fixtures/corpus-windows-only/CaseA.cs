// CaseA.cs - uppercase variant
// On case-insensitive filesystems, this conflicts with casea.cs
namespace Test
{
    public class CaseA
    {
        public void Method() { }
    }
}
