"""Hanzo CLI — KMS subcommands."""
