"""Hanzo CLI — unified command-line interface for the Hanzo platform."""

__version__ = "0.1.0"
