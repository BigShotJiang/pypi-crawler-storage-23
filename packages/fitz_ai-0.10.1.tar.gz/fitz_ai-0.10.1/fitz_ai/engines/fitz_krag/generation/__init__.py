# fitz_ai/engines/fitz_krag/generation/__init__.py
