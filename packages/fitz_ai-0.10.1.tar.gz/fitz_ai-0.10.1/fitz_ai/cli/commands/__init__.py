# fitz_ai/cli/commands/__init__.py
"""
CLI commands.

Commands are loaded lazily - only imported when invoked.
"""
