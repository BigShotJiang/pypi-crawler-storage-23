# fitz_ai/ingestion/enrichment/prompts/chunk/__init__.py
"""Chunk-level enrichment prompts."""
