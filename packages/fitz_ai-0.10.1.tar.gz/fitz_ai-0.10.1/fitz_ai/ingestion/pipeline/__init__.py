# fitz_ai/ingestion/pipeline/__init__.py
"""Ingestion pipeline package (engine-specific pipelines live in engines/)."""
