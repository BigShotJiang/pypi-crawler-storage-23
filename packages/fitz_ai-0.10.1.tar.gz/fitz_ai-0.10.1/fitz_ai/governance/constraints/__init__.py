# fitz_ai/governance/constraints/__init__.py
"""Constraint system for epistemic correctness."""
