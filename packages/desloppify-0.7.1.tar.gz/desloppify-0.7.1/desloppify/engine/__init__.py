"""Engine-layer packages: detectors, scoring, planning, policy, and state internals."""
