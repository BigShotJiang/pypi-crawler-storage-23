"""Context signal modules for review context pipelines."""
