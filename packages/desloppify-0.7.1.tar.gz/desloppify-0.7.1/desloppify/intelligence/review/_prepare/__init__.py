"""Internal helpers for review preparation."""
