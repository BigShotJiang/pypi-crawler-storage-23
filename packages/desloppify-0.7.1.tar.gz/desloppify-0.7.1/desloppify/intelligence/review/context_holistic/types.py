"""Type aliases for holistic review context package."""

from desloppify.intelligence.review._context.models import HolisticContext

__all__ = ["HolisticContext"]
