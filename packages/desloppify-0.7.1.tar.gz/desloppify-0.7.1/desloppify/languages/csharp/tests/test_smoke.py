def test_csharp_test_package_smoke():
    assert True
