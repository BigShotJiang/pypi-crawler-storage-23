"""Desloppify — Automated cruft detection + LLM-ready analysis."""

from __future__ import annotations
