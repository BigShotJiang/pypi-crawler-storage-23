"""Output generation: visualization, scorecard, and treemap rendering."""

from desloppify.app.output import visualize

__all__ = ["visualize"]
