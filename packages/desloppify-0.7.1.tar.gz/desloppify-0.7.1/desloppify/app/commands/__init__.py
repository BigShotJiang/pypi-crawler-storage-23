"""Command handlers for the desloppify CLI."""
