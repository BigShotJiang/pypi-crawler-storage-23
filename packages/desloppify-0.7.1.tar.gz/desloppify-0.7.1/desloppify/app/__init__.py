"""Application-layer packages: CLI, commands, and output surfaces."""
