"""Tests for Plinth."""
