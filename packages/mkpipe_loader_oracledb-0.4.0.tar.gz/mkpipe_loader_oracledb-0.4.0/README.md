# mkpipe-loader-oracledb

Oracle Database loader plugin for mkpipe.
