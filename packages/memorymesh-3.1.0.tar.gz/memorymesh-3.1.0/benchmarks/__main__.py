"""Allow running benchmarks as ``python -m benchmarks``."""

from benchmarks.bench_memorymesh import main

main()
