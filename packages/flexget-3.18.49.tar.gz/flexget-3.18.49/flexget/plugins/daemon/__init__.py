"""Plugins which run alongside the daemon."""
