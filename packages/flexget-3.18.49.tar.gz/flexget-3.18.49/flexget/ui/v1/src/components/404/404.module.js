/* global angular */
(function () {
  'use strict';

  angular.module('components.404', ['blocks.router']);
})();
