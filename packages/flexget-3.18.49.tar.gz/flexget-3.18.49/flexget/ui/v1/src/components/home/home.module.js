/* global angular */
(function () {
  'use strict';

  angular.module('components.home', ['blocks.router']);
})();
