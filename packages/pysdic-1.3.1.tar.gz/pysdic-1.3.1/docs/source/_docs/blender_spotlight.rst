.. currentmodule:: pysdic.blender

Blender SpotLight Class
==================================================================

.. autoclass:: BlenderSpotLight
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance: