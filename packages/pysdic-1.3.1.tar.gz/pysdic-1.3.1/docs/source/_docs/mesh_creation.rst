.. currentmodule:: pysdic

Create triangle 3 meshes for SDIC analyses in 3D space
========================================================

.. contents:: Table of Contents
   :local:
   :depth: 2
   :backlinks: top

The package ``pysdic`` provides functions to create 3D surface meshes from heightmap functions or axisymmetric profiles using 3-node triangular elements. These meshes can be used in Stereo Digital Image Correlation (SDIC) analyses or for visualization purposes.
The meshes can be used in Stereo Digital Image Correlation (SDIC) analyses or for visualization purposes.

.. autosummary::
   :toctree: ../_autosummary/

   create_triangle_3_heightmap
   create_triangle_3_axisymmetric

   

