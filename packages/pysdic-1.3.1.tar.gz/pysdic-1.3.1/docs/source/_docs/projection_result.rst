.. currentmodule:: pysdic

ProjectionResult 
===========================================

.. autoclass:: ProjectionResult
    :members:
    :inherited-members:
    :show-inheritance:

