.. currentmodule:: pysdic

Optical Flow Operations
==========================

The package includes functions to compute the optical flow between two images based on ``OpenCV`` ``DIS`` (Dense Inverse Search) algorithm. The optical flow can be computed for a specific channel of the images and for a specific region of interest. The computed optical flow can be visualized using quiver plots or color-coded flow maps. 

.. autosummary:: 
    :toctree: ../_autosummary/

    compute_optical_flow 
    display_optical_flow

