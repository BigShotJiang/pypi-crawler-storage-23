.. currentmodule:: pysdic

ImageProjectionResult
===========================================

.. autoclass:: ImageProjectionResult
    :members:
    :inherited-members:
    :show-inheritance:

