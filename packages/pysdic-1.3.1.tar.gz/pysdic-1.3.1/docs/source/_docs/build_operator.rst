.. currentmodule:: pysdic

Build Displacement Operator
==========================================

.. autofunction:: build_displacement_operator