.. currentmodule:: pysdic.blender

Blender Experiment Class
==================================================================

.. autoclass:: BlenderExperiment
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance: