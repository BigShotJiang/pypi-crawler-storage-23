Installation
============

To install ``pysdic``, you can use the following command:

.. code-block:: bash

    pip install pysdic

Or install it directly from the GitHub repository using:

.. code-block:: bash

    pip install git+https://github.com/Artezaru/pysdic.git

Requiements
------------

The following dependencies are required to use ``pysdic``:

- **NumPy**: A fundamental package for scientific computing in Python.
- **SciPy**: A library used for scientific and technical computing.
- **Matplotlib**: A plotting library for creating static, animated, and interactive visualizations
- **OpenCV**: A library for computer vision and image processing.
- **Open3D**: A library for 3D data processing and visualization.
- **PyVista**: A library for 3D visualization and analysis of scientific data.
- **PyCVCam**: A library for camera control and image acquisition.
- **Meshio**: A library for reading and writing mesh files in various formats.
- **Py3DFrame**: A library for working with 3D data frames.
