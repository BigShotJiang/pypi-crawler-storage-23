﻿pysdic.Image.from\_array
========================

.. currentmodule:: pysdic

.. automethod:: Image.from_array