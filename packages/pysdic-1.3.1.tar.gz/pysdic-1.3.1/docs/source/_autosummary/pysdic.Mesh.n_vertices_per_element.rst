﻿pysdic.Mesh.n\_vertices\_per\_element
=====================================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_vertices_per_element