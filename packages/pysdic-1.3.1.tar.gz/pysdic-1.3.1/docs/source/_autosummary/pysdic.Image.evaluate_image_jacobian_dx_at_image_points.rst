﻿pysdic.Image.evaluate\_image\_jacobian\_dx\_at\_image\_points
=============================================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_jacobian_dx_at_image_points