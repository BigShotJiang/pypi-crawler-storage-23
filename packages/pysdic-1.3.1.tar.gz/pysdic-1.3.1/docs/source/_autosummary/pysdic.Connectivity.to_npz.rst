﻿pysdic.Connectivity.to\_npz
===========================

.. currentmodule:: pysdic

.. automethod:: Connectivity.to_npz