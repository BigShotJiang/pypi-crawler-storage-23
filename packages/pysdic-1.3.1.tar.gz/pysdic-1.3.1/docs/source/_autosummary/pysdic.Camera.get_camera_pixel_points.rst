﻿pysdic.Camera.get\_camera\_pixel\_points
========================================

.. currentmodule:: pysdic

.. automethod:: Camera.get_camera_pixel_points