﻿pysdic.Image.image
==================

.. currentmodule:: pysdic

.. autoproperty:: Image.image