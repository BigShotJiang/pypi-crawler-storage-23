﻿pysdic.PointCloud.get\_property
===============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.get_property