﻿pysdic.Image.pixel\_points\_to\_image\_points
=============================================

.. currentmodule:: pysdic

.. automethod:: Image.pixel_points_to_image_points