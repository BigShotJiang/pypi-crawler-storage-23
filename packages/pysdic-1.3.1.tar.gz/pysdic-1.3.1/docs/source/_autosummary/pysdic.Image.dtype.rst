﻿pysdic.Image.dtype
==================

.. currentmodule:: pysdic

.. autoproperty:: Image.dtype