﻿pysdic.IntegrationPoints.has\_property
======================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.has_property