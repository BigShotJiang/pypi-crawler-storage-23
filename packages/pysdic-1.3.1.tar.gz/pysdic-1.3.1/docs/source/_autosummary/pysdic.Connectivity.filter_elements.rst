﻿pysdic.Connectivity.filter\_elements
====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.filter_elements