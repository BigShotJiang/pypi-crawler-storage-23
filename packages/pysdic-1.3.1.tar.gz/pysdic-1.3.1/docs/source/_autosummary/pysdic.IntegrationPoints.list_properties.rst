﻿pysdic.IntegrationPoints.list\_properties
=========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.list_properties