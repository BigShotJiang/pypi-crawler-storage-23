﻿pysdic.Camera.get\_camera\_rays
===============================

.. currentmodule:: pysdic

.. automethod:: Camera.get_camera_rays