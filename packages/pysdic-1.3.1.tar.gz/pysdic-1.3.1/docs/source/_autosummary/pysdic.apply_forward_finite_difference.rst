﻿pysdic.apply\_forward\_finite\_difference
=========================================

.. currentmodule:: pysdic

.. autofunction:: apply_forward_finite_difference