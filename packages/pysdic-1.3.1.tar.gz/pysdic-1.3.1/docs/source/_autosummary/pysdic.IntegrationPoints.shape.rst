﻿pysdic.IntegrationPoints.shape
==============================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.shape