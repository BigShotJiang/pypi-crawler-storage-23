﻿pysdic.Mesh.remove\_vertices
============================

.. currentmodule:: pysdic

.. automethod:: Mesh.remove_vertices