﻿pysdic.Connectivity.n\_vertices\_per\_element
=============================================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.n_vertices_per_element