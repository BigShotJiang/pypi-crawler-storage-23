﻿pysdic.create\_triangle\_3\_axisymmetric
========================================

.. currentmodule:: pysdic

.. autofunction:: create_triangle_3_axisymmetric