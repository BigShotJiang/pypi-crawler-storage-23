﻿pysdic.Mesh.vertices
====================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.vertices