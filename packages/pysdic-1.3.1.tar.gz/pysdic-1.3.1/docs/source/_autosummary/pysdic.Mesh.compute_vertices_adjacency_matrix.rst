﻿pysdic.Mesh.compute\_vertices\_adjacency\_matrix
================================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_vertices_adjacency_matrix