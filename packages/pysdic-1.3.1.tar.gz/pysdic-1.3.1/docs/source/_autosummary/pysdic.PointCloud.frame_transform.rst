﻿pysdic.PointCloud.frame\_transform
==================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.frame_transform