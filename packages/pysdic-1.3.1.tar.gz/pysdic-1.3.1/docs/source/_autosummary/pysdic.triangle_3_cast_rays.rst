﻿pysdic.triangle\_3\_cast\_rays
==============================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_cast_rays