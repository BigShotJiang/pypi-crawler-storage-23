﻿pysdic.create\_elements\_adjacency\_graph
=========================================

.. currentmodule:: pysdic

.. autofunction:: create_elements_adjacency_graph