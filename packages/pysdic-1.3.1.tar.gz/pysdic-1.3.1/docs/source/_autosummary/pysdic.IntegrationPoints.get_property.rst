﻿pysdic.IntegrationPoints.get\_property
======================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.get_property