﻿pysdic.Mesh.compute\_property\_interpolation
============================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_property_interpolation