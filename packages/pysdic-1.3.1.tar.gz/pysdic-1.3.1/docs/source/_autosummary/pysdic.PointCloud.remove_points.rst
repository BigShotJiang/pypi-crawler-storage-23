﻿pysdic.PointCloud.remove\_points
================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.remove_points