﻿pysdic.PointCloud.from\_vtk
===========================

.. currentmodule:: pysdic

.. automethod:: PointCloud.from_vtk