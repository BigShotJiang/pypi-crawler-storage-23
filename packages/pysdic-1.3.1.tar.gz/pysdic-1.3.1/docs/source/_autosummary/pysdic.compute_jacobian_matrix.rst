﻿pysdic.compute\_jacobian\_matrix
================================

.. currentmodule:: pysdic

.. autofunction:: compute_jacobian_matrix