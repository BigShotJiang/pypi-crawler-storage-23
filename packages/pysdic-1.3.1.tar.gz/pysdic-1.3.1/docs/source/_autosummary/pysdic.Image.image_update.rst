﻿pysdic.Image.image\_update
==========================

.. currentmodule:: pysdic

.. automethod:: Image.image_update