﻿pysdic.PointCloud.n\_dimensions
===============================

.. currentmodule:: pysdic

.. autoproperty:: PointCloud.n_dimensions