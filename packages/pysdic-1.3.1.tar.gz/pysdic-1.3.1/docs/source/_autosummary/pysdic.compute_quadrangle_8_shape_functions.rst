﻿pysdic.compute\_quadrangle\_8\_shape\_functions
===============================================

.. currentmodule:: pysdic

.. autofunction:: compute_quadrangle_8_shape_functions