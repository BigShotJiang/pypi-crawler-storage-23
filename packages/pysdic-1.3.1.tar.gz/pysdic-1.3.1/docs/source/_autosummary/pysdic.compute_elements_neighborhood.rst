﻿pysdic.compute\_elements\_neighborhood
======================================

.. currentmodule:: pysdic

.. autofunction:: compute_elements_neighborhood