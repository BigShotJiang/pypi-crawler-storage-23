﻿pysdic.Image.get\_interpolation\_function
=========================================

.. currentmodule:: pysdic

.. automethod:: Image.get_interpolation_function