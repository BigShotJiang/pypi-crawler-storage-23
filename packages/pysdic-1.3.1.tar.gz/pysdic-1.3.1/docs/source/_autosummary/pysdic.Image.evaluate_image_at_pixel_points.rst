﻿pysdic.Image.evaluate\_image\_at\_pixel\_points
===============================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_at_pixel_points