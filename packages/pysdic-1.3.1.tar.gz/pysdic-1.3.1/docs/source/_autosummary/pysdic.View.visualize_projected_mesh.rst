﻿pysdic.View.visualize\_projected\_mesh
======================================

.. currentmodule:: pysdic

.. automethod:: View.visualize_projected_mesh