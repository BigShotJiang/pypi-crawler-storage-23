﻿pysdic.Mesh.from\_vtk
=====================

.. currentmodule:: pysdic

.. automethod:: Mesh.from_vtk