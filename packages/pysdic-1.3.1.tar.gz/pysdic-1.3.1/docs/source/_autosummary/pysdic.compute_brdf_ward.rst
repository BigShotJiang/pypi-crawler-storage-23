﻿pysdic.compute\_brdf\_ward
==========================

.. currentmodule:: pysdic

.. autofunction:: compute_brdf_ward