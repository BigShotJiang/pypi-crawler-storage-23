﻿pysdic.IntegrationPoints.n\_topological\_dimensions
===================================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.n_topological_dimensions