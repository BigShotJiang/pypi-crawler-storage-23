﻿pysdic.IntegrationPoints.weights
================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.weights