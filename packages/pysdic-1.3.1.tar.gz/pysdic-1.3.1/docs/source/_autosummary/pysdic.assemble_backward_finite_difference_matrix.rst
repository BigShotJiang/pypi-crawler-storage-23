﻿pysdic.assemble\_backward\_finite\_difference\_matrix
=====================================================

.. currentmodule:: pysdic

.. autofunction:: assemble_backward_finite_difference_matrix