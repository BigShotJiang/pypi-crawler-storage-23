﻿pysdic.get\_triangle\_6\_gauss\_points
======================================

.. currentmodule:: pysdic

.. autofunction:: get_triangle_6_gauss_points