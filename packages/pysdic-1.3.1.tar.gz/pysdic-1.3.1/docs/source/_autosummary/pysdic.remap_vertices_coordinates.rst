﻿pysdic.remap\_vertices\_coordinates
===================================

.. currentmodule:: pysdic

.. autofunction:: remap_vertices_coordinates