﻿pysdic.create\_vertices\_adjacency\_graph
=========================================

.. currentmodule:: pysdic

.. autofunction:: create_vertices_adjacency_graph