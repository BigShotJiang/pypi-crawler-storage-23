﻿pysdic.Image.get\_image\_image\_points
======================================

.. currentmodule:: pysdic

.. automethod:: Image.get_image_image_points