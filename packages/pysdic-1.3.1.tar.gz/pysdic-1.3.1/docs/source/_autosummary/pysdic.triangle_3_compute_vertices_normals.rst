﻿pysdic.triangle\_3\_compute\_vertices\_normals
==============================================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_compute_vertices_normals