﻿pysdic.Connectivity.list\_properties
====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.list_properties