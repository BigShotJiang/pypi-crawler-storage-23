﻿pysdic.Connectivity.shape
=========================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.shape