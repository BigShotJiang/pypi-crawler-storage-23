﻿pysdic.get\_gauss\_points
=========================

.. currentmodule:: pysdic

.. autofunction:: get_gauss_points