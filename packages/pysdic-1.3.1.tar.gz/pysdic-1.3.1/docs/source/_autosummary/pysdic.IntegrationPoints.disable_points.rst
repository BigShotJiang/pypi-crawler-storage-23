﻿pysdic.IntegrationPoints.disable\_points
========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.disable_points