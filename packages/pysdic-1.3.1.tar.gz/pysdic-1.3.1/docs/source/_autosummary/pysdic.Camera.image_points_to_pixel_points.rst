﻿pysdic.Camera.image\_points\_to\_pixel\_points
==============================================

.. currentmodule:: pysdic

.. automethod:: Camera.image_points_to_pixel_points