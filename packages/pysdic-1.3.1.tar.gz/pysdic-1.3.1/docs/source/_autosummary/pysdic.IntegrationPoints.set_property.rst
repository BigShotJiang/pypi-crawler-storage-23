﻿pysdic.IntegrationPoints.set\_property
======================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.set_property