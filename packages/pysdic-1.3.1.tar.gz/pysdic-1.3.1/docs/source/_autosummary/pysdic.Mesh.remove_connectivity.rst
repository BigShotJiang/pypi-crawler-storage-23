﻿pysdic.Mesh.remove\_connectivity
================================

.. currentmodule:: pysdic

.. automethod:: Mesh.remove_connectivity