﻿pysdic.Connectivity.concatenate
===============================

.. currentmodule:: pysdic

.. automethod:: Connectivity.concatenate