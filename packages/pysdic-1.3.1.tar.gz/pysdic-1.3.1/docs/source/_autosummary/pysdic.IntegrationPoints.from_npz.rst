﻿pysdic.IntegrationPoints.from\_npz
==================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.from_npz