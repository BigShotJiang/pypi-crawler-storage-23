﻿pysdic.PointCloud.delete\_property
==================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.delete_property