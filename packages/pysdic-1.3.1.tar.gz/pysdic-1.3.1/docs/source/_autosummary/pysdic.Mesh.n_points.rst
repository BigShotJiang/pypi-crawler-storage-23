﻿pysdic.Mesh.n\_points
=====================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_points