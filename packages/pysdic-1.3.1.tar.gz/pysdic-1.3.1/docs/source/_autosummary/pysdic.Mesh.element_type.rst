﻿pysdic.Mesh.element\_type
=========================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.element_type