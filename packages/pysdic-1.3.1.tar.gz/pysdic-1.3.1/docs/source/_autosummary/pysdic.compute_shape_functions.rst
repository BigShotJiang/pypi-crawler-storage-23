﻿pysdic.compute\_shape\_functions
================================

.. currentmodule:: pysdic

.. autofunction:: compute_shape_functions