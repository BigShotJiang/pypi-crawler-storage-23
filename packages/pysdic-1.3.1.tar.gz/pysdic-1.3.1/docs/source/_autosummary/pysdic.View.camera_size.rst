﻿pysdic.View.camera\_size
========================

.. currentmodule:: pysdic

.. autoproperty:: View.camera_size