﻿pysdic.assemble\_property\_interpolation
========================================

.. currentmodule:: pysdic

.. autofunction:: assemble_property_interpolation