﻿pysdic.PointCloud.coordinates
=============================

.. currentmodule:: pysdic

.. autoproperty:: PointCloud.coordinates