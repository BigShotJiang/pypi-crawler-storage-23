﻿pysdic.Mesh.copy
================

.. currentmodule:: pysdic

.. automethod:: Mesh.copy