﻿pysdic.Mesh.list\_precomputed
=============================

.. currentmodule:: pysdic

.. automethod:: Mesh.list_precomputed