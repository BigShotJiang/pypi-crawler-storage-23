﻿pysdic.Camera.visualize\_projected\_point\_cloud
================================================

.. currentmodule:: pysdic

.. automethod:: Camera.visualize_projected_point_cloud