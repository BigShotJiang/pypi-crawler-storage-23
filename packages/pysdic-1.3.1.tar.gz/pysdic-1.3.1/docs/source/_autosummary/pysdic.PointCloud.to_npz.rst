﻿pysdic.PointCloud.to\_npz
=========================

.. currentmodule:: pysdic

.. automethod:: PointCloud.to_npz