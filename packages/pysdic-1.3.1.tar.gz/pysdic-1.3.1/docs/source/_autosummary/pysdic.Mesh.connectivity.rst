﻿pysdic.Mesh.connectivity
========================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.connectivity