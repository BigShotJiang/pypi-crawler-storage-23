﻿pysdic.compute\_vertices\_adjacency\_matrix
===========================================

.. currentmodule:: pysdic

.. autofunction:: compute_vertices_adjacency_matrix