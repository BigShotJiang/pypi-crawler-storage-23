﻿pysdic.Image.evaluate\_image\_jacobian\_dv\_at\_pixel\_points
=============================================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_jacobian_dv_at_pixel_points