﻿pysdic.Connectivity.set\_property
=================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.set_property