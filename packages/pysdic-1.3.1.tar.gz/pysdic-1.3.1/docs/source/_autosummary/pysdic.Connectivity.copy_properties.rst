﻿pysdic.Connectivity.copy\_properties
====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.copy_properties