﻿pysdic.triangle\_3\_mesh\_from\_open3d
======================================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_mesh_from_open3d