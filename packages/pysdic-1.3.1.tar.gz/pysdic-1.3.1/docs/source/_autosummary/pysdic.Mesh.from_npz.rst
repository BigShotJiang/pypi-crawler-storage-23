﻿pysdic.Mesh.from\_npz
=====================

.. currentmodule:: pysdic

.. automethod:: Mesh.from_npz