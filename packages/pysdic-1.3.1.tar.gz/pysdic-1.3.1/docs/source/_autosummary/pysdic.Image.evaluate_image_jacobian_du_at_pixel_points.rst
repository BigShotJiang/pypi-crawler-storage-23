﻿pysdic.Image.evaluate\_image\_jacobian\_du\_at\_pixel\_points
=============================================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_jacobian_du_at_pixel_points