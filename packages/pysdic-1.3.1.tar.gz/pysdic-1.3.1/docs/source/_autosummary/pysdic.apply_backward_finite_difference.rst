﻿pysdic.apply\_backward\_finite\_difference
==========================================

.. currentmodule:: pysdic

.. autofunction:: apply_backward_finite_difference