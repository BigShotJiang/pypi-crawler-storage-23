﻿pysdic.View.image\_project
==========================

.. currentmodule:: pysdic

.. automethod:: View.image_project