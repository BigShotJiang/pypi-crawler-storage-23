﻿pysdic.Connectivity.keep\_elements
==================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.keep_elements