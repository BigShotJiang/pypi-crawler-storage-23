﻿pysdic.PointCloud.shape
=======================

.. currentmodule:: pysdic

.. autoproperty:: PointCloud.shape