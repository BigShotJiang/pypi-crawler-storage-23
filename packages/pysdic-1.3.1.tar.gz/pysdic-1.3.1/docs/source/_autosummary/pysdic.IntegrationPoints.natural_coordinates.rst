﻿pysdic.IntegrationPoints.natural\_coordinates
=============================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.natural_coordinates