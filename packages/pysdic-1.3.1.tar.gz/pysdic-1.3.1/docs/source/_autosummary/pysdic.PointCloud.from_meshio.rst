﻿pysdic.PointCloud.from\_meshio
==============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.from_meshio