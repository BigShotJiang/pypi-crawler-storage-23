﻿pysdic.Connectivity.from\_array
===============================

.. currentmodule:: pysdic

.. automethod:: Connectivity.from_array