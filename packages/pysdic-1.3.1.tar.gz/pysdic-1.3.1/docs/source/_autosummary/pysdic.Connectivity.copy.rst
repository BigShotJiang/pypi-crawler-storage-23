﻿pysdic.Connectivity.copy
========================

.. currentmodule:: pysdic

.. automethod:: Connectivity.copy