﻿pysdic.Image.from\_file
=======================

.. currentmodule:: pysdic

.. automethod:: Image.from_file