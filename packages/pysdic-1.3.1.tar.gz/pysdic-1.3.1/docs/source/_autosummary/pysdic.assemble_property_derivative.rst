﻿pysdic.assemble\_property\_derivative
=====================================

.. currentmodule:: pysdic

.. autofunction:: assemble_property_derivative