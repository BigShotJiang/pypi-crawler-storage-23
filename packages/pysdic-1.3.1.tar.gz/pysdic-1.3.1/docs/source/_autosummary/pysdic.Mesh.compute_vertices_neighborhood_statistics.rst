﻿pysdic.Mesh.compute\_vertices\_neighborhood\_statistics
=======================================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_vertices_neighborhood_statistics