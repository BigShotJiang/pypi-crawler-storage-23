﻿pysdic.Image.n\_channels
========================

.. currentmodule:: pysdic

.. autoproperty:: Image.n_channels