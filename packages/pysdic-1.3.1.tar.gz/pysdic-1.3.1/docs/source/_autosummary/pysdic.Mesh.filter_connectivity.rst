﻿pysdic.Mesh.filter\_connectivity
================================

.. currentmodule:: pysdic

.. automethod:: Mesh.filter_connectivity