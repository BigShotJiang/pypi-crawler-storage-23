﻿pysdic.Connectivity.to\_array
=============================

.. currentmodule:: pysdic

.. automethod:: Connectivity.to_array