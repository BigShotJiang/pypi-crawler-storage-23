﻿pysdic.IntegrationPoints.copy
=============================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.copy