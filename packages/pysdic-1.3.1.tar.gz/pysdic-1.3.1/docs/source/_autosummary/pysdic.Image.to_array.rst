﻿pysdic.Image.to\_array
======================

.. currentmodule:: pysdic

.. automethod:: Image.to_array