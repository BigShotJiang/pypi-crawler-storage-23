﻿pysdic.PointCloud.points
========================

.. currentmodule:: pysdic

.. autoproperty:: PointCloud.points