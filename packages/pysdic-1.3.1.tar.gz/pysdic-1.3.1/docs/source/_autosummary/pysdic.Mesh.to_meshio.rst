﻿pysdic.Mesh.to\_meshio
======================

.. currentmodule:: pysdic

.. automethod:: Mesh.to_meshio