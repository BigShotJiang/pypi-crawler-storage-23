﻿pysdic.Mesh.n\_dimensions
=========================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_dimensions