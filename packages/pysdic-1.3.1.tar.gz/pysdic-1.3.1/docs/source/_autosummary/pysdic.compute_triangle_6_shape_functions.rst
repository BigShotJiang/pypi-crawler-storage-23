﻿pysdic.compute\_triangle\_6\_shape\_functions
=============================================

.. currentmodule:: pysdic

.. autofunction:: compute_triangle_6_shape_functions