﻿pysdic.get\_triangle\_3\_gauss\_points
======================================

.. currentmodule:: pysdic

.. autofunction:: get_triangle_3_gauss_points