﻿pysdic.Image.image\_points\_to\_pixel\_points
=============================================

.. currentmodule:: pysdic

.. automethod:: Image.image_points_to_pixel_points