﻿pysdic.assemble\_property\_projection
=====================================

.. currentmodule:: pysdic

.. autofunction:: assemble_property_projection