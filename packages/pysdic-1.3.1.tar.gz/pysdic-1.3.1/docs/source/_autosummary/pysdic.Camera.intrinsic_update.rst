﻿pysdic.Camera.intrinsic\_update
===============================

.. currentmodule:: pysdic

.. automethod:: Camera.intrinsic_update