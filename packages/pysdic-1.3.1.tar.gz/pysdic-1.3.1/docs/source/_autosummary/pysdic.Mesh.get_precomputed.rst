﻿pysdic.Mesh.get\_precomputed
============================

.. currentmodule:: pysdic

.. automethod:: Mesh.get_precomputed