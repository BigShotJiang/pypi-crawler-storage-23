﻿pysdic.Image.evaluate\_image\_at\_image\_points
===============================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_at_image_points