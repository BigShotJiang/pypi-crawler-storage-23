﻿pysdic.IntegrationPoints.delete\_property
=========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.delete_property