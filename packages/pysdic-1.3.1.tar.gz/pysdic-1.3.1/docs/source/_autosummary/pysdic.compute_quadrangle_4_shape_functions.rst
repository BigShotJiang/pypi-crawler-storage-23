﻿pysdic.compute\_quadrangle\_4\_shape\_functions
===============================================

.. currentmodule:: pysdic

.. autofunction:: compute_quadrangle_4_shape_functions