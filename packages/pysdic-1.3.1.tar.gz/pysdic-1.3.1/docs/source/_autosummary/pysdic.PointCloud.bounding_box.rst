﻿pysdic.PointCloud.bounding\_box
===============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.bounding_box