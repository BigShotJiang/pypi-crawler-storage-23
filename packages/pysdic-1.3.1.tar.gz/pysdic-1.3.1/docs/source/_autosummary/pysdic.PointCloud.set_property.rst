﻿pysdic.PointCloud.set\_property
===============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.set_property