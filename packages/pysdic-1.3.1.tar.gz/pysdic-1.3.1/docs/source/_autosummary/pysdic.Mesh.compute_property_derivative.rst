﻿pysdic.Mesh.compute\_property\_derivative
=========================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_property_derivative