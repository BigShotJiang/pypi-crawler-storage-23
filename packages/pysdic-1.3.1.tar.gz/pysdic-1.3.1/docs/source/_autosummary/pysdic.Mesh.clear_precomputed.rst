﻿pysdic.Mesh.clear\_precomputed
==============================

.. currentmodule:: pysdic

.. automethod:: Mesh.clear_precomputed