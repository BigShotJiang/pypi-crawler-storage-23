﻿pysdic.Mesh.keep\_connectivity
==============================

.. currentmodule:: pysdic

.. automethod:: Mesh.keep_connectivity