﻿pysdic.PointCloud.all\_close
============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.all_close