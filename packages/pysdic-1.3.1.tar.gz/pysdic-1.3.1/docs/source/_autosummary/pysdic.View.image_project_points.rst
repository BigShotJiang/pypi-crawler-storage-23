﻿pysdic.View.image\_project\_points
==================================

.. currentmodule:: pysdic

.. automethod:: View.image_project_points