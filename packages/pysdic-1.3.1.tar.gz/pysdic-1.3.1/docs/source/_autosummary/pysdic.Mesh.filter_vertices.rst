﻿pysdic.Mesh.filter\_vertices
============================

.. currentmodule:: pysdic

.. automethod:: Mesh.filter_vertices