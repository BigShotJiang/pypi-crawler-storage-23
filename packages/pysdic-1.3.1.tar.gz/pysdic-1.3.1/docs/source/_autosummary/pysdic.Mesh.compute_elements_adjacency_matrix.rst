﻿pysdic.Mesh.compute\_elements\_adjacency\_matrix
================================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_elements_adjacency_matrix