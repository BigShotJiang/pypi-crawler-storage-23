﻿pysdic.IntegrationPoints.clear\_properties
==========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.clear_properties