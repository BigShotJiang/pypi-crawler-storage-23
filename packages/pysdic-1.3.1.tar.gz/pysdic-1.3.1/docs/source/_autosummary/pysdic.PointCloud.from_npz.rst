﻿pysdic.PointCloud.from\_npz
===========================

.. currentmodule:: pysdic

.. automethod:: PointCloud.from_npz