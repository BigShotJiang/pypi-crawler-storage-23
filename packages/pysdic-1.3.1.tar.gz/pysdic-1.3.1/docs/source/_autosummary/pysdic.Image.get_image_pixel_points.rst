﻿pysdic.Image.get\_image\_pixel\_points
======================================

.. currentmodule:: pysdic

.. automethod:: Image.get_image_pixel_points