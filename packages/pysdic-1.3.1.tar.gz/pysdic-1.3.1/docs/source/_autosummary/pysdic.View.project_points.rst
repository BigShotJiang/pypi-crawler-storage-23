﻿pysdic.View.project\_points
===========================

.. currentmodule:: pysdic

.. automethod:: View.project_points