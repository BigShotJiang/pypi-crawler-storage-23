﻿pysdic.Camera.size\_update
==========================

.. currentmodule:: pysdic

.. automethod:: Camera.size_update