﻿pysdic.IntegrationPoints.get\_precomputed
=========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.get_precomputed