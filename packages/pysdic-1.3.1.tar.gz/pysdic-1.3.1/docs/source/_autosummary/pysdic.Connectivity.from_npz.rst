﻿pysdic.Connectivity.from\_npz
=============================

.. currentmodule:: pysdic

.. automethod:: Connectivity.from_npz