﻿pysdic.compute\_elements\_adjacency\_matrix
===========================================

.. currentmodule:: pysdic

.. autofunction:: compute_elements_adjacency_matrix