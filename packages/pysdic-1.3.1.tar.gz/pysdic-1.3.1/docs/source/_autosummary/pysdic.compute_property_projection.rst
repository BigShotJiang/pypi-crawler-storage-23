﻿pysdic.compute\_property\_projection
====================================

.. currentmodule:: pysdic

.. autofunction:: compute_property_projection