﻿pysdic.Image.ndim
=================

.. currentmodule:: pysdic

.. autoproperty:: Image.ndim