﻿pysdic.Image.is\_color
======================

.. currentmodule:: pysdic

.. autoproperty:: Image.is_color