﻿pysdic.assemble\_central\_finite\_difference\_matrix
====================================================

.. currentmodule:: pysdic

.. autofunction:: assemble_central_finite_difference_matrix