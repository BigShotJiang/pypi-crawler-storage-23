﻿pysdic.Camera.visualize\_projected\_mesh
========================================

.. currentmodule:: pysdic

.. automethod:: Camera.visualize_projected_mesh