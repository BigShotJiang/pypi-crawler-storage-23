﻿pysdic.PointCloud.n\_points
===========================

.. currentmodule:: pysdic

.. autoproperty:: PointCloud.n_points