﻿pysdic.get\_quadrangle\_4\_gauss\_points
========================================

.. currentmodule:: pysdic

.. autofunction:: get_quadrangle_4_gauss_points