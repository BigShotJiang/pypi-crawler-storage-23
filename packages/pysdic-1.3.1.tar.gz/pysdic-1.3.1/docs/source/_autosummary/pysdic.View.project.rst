﻿pysdic.View.project
===================

.. currentmodule:: pysdic

.. automethod:: View.project