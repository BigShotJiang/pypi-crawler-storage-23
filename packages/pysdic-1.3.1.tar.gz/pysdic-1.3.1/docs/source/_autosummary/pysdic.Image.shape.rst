﻿pysdic.Image.shape
==================

.. currentmodule:: pysdic

.. autoproperty:: Image.shape