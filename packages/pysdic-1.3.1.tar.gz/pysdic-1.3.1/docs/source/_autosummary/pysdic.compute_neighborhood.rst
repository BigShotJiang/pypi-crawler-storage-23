﻿pysdic.compute\_neighborhood
============================

.. currentmodule:: pysdic

.. autofunction:: compute_neighborhood