﻿pysdic.Mesh.remove\_unused\_vertices
====================================

.. currentmodule:: pysdic

.. automethod:: Mesh.remove_unused_vertices