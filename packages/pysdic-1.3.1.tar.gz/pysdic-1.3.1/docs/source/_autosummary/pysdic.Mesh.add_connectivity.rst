﻿pysdic.Mesh.add\_connectivity
=============================

.. currentmodule:: pysdic

.. automethod:: Mesh.add_connectivity