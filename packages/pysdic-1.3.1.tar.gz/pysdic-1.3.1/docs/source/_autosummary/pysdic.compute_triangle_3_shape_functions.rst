﻿pysdic.compute\_triangle\_3\_shape\_functions
=============================================

.. currentmodule:: pysdic

.. autofunction:: compute_triangle_3_shape_functions