﻿pysdic.IntegrationPoints.n\_valids
==================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.n_valids