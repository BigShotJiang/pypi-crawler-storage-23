﻿pysdic.Image.width
==================

.. currentmodule:: pysdic

.. autoproperty:: Image.width