﻿pysdic.compute\_shape\_function\_matrix
=======================================

.. currentmodule:: pysdic

.. autofunction:: compute_shape_function_matrix