﻿pysdic.IntegrationPoints.remove\_invalids
=========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.remove_invalids