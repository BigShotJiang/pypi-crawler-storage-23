﻿pysdic.compute\_bouguer\_law
============================

.. currentmodule:: pysdic

.. autofunction:: compute_bouguer_law