﻿pysdic.Mesh.elements
====================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.elements