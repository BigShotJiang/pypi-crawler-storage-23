﻿pysdic.triangle\_3\_compute\_elements\_areas
============================================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_compute_elements_areas