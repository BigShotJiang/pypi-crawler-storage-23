﻿pysdic.Camera.sensor\_width
===========================

.. currentmodule:: pysdic

.. autoproperty:: Camera.sensor_width