﻿pysdic.IntegrationPoints.element\_indices
=========================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.element_indices