﻿pysdic.PointCloud.filter\_points
================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.filter_points