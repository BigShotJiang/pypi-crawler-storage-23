﻿pysdic.Mesh.n\_vertices
=======================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_vertices