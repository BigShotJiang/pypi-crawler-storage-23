﻿pysdic.Mesh.compute\_elements\_neighborhood
===========================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_elements_neighborhood