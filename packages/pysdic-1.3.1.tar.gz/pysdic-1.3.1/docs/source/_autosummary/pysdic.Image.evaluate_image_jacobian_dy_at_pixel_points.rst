﻿pysdic.Image.evaluate\_image\_jacobian\_dy\_at\_pixel\_points
=============================================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_jacobian_dy_at_pixel_points