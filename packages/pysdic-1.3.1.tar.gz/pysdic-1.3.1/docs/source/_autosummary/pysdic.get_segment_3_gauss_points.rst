﻿pysdic.get\_segment\_3\_gauss\_points
=====================================

.. currentmodule:: pysdic

.. autofunction:: get_segment_3_gauss_points