﻿pysdic.Mesh.keep\_vertices
==========================

.. currentmodule:: pysdic

.. automethod:: Mesh.keep_vertices