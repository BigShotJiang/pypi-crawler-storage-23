﻿pysdic.PointCloud.has\_property
===============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.has_property