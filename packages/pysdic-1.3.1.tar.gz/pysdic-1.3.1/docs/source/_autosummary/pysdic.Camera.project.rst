﻿pysdic.Camera.project
=====================

.. currentmodule:: pysdic

.. automethod:: Camera.project