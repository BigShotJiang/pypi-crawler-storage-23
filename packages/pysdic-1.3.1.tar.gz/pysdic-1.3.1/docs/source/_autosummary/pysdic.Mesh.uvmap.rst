﻿pysdic.Mesh.uvmap
=================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.uvmap