﻿pysdic.assemble\_shape\_function\_matrix
========================================

.. currentmodule:: pysdic

.. autofunction:: assemble_shape_function_matrix