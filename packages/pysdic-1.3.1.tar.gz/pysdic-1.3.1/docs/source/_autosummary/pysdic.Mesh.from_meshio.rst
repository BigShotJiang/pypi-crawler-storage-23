﻿pysdic.Mesh.from\_meshio
========================

.. currentmodule:: pysdic

.. automethod:: Mesh.from_meshio