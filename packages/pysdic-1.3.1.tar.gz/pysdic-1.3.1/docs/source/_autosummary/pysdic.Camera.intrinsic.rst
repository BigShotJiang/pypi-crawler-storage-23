﻿pysdic.Camera.intrinsic
=======================

.. currentmodule:: pysdic

.. autoproperty:: Camera.intrinsic