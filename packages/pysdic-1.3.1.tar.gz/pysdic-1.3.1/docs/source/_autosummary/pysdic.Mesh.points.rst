﻿pysdic.Mesh.points
==================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.points