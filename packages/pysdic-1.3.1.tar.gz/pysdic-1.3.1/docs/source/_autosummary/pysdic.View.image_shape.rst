﻿pysdic.View.image\_shape
========================

.. currentmodule:: pysdic

.. autoproperty:: View.image_shape