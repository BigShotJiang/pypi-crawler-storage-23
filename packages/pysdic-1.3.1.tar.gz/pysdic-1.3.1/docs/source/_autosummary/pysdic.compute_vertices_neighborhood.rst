﻿pysdic.compute\_vertices\_neighborhood
======================================

.. currentmodule:: pysdic

.. autofunction:: compute_vertices_neighborhood