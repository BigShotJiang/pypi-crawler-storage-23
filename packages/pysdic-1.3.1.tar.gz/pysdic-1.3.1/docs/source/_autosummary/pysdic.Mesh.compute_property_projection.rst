﻿pysdic.Mesh.compute\_property\_projection
=========================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_property_projection