﻿pysdic.Camera.sensor\_height
============================

.. currentmodule:: pysdic

.. autoproperty:: Camera.sensor_height