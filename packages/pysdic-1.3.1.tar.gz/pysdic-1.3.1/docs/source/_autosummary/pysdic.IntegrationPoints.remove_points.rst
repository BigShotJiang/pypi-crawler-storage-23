﻿pysdic.IntegrationPoints.remove\_points
=======================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.remove_points