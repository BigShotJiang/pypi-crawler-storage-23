﻿pysdic.Connectivity.element\_type
=================================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.element_type