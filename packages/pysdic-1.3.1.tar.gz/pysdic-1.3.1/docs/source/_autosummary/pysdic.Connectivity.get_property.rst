﻿pysdic.Connectivity.get\_property
=================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.get_property