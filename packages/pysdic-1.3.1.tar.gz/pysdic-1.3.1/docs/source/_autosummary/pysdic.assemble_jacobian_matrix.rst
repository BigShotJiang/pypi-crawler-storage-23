﻿pysdic.assemble\_jacobian\_matrix
=================================

.. currentmodule:: pysdic

.. autofunction:: assemble_jacobian_matrix