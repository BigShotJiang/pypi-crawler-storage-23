﻿pysdic.Image.construct\_interpolation\_functions
================================================

.. currentmodule:: pysdic

.. automethod:: Image.construct_interpolation_functions