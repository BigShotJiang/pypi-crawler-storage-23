﻿pysdic.compute\_central\_finite\_difference\_coefficients
=========================================================

.. currentmodule:: pysdic

.. autofunction:: compute_central_finite_difference_coefficients