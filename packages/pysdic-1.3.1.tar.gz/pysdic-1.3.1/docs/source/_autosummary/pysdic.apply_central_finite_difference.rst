﻿pysdic.apply\_central\_finite\_difference
=========================================

.. currentmodule:: pysdic

.. autofunction:: apply_central_finite_difference