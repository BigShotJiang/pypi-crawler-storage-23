﻿pysdic.Mesh.n\_elements
=======================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_elements