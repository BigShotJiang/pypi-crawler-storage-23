﻿pysdic.Camera.project\_points
=============================

.. currentmodule:: pysdic

.. automethod:: Camera.project_points