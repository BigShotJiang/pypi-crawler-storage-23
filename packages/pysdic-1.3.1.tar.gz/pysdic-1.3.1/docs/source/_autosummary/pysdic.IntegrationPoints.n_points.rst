﻿pysdic.IntegrationPoints.n\_points
==================================

.. currentmodule:: pysdic

.. autoproperty:: IntegrationPoints.n_points