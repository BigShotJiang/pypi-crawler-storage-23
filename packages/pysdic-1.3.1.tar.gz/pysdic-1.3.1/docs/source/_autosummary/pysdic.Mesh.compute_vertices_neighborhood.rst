﻿pysdic.Mesh.compute\_vertices\_neighborhood
===========================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_vertices_neighborhood