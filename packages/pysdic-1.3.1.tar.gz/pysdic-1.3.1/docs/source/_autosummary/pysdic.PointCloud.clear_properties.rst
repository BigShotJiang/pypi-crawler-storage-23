﻿pysdic.PointCloud.clear\_properties
===================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.clear_properties