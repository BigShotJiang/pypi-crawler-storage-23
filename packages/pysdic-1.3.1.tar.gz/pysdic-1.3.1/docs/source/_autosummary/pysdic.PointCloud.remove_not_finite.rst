﻿pysdic.PointCloud.remove\_not\_finite
=====================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.remove_not_finite