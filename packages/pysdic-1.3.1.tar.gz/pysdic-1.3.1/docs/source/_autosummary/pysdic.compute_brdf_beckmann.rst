﻿pysdic.compute\_brdf\_beckmann
==============================

.. currentmodule:: pysdic

.. autofunction:: compute_brdf_beckmann