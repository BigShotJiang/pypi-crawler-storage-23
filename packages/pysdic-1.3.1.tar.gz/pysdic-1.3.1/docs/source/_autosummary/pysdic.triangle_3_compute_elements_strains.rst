﻿pysdic.triangle\_3\_compute\_elements\_strains
==============================================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_compute_elements_strains