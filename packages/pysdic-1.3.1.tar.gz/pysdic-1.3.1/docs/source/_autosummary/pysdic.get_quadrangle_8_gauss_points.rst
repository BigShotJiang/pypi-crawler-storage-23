﻿pysdic.get\_quadrangle\_8\_gauss\_points
========================================

.. currentmodule:: pysdic

.. autofunction:: get_quadrangle_8_gauss_points