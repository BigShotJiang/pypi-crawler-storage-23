﻿pysdic.Connectivity.n\_elements
===============================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.n_elements