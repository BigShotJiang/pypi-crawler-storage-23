﻿pysdic.get\_segment\_2\_gauss\_points
=====================================

.. currentmodule:: pysdic

.. autofunction:: get_segment_2_gauss_points