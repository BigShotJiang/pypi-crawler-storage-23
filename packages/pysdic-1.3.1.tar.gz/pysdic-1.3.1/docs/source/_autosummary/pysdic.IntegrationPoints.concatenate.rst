﻿pysdic.IntegrationPoints.concatenate
====================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.concatenate