﻿pysdic.Mesh.compute\_shape\_functions
=====================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_shape_functions