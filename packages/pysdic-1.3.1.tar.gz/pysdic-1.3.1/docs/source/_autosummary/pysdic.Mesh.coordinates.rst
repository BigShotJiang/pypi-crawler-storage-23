﻿pysdic.Mesh.coordinates
=======================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.coordinates