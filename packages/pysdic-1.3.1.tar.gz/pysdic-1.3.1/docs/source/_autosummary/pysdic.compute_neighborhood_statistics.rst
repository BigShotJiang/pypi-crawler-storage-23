﻿pysdic.compute\_neighborhood\_statistics
========================================

.. currentmodule:: pysdic

.. autofunction:: compute_neighborhood_statistics