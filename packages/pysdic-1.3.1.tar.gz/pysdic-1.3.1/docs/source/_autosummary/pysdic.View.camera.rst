﻿pysdic.View.camera
==================

.. currentmodule:: pysdic

.. autoproperty:: View.camera