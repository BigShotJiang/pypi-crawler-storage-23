﻿pysdic.Mesh.n\_topological\_dimensions
======================================

.. currentmodule:: pysdic

.. autoproperty:: Mesh.n_topological_dimensions