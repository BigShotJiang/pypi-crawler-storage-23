﻿pysdic.Camera.distortion\_update
================================

.. currentmodule:: pysdic

.. automethod:: Camera.distortion_update