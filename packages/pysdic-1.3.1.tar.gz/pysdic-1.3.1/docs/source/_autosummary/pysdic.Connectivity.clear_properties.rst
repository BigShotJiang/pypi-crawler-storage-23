﻿pysdic.Connectivity.clear\_properties
=====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.clear_properties