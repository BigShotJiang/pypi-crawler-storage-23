﻿pysdic.Connectivity.remove\_elements
====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.remove_elements