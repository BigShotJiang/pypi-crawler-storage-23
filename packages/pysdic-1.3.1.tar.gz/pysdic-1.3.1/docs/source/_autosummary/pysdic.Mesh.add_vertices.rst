﻿pysdic.Mesh.add\_vertices
=========================

.. currentmodule:: pysdic

.. automethod:: Mesh.add_vertices