﻿pysdic.Image.to\_file
=====================

.. currentmodule:: pysdic

.. automethod:: Image.to_file