﻿pysdic.Connectivity.n\_topological\_dimensions
==============================================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.n_topological_dimensions