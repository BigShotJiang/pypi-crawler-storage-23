﻿pysdic.compute\_property\_derivative
====================================

.. currentmodule:: pysdic

.. autofunction:: compute_property_derivative