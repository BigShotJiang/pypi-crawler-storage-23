﻿pysdic.Camera.get\_camera\_normalized\_points
=============================================

.. currentmodule:: pysdic

.. automethod:: Camera.get_camera_normalized_points