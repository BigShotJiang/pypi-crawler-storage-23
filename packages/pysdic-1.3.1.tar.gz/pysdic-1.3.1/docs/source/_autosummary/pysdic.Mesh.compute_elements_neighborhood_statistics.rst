﻿pysdic.Mesh.compute\_elements\_neighborhood\_statistics
=======================================================

.. currentmodule:: pysdic

.. automethod:: Mesh.compute_elements_neighborhood_statistics