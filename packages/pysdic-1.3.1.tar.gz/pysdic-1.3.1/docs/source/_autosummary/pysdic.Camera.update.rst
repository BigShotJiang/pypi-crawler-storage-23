﻿pysdic.Camera.update
====================

.. currentmodule:: pysdic

.. automethod:: Camera.update