﻿pysdic.Mesh.get\_used\_vertices\_mask
=====================================

.. currentmodule:: pysdic

.. automethod:: Mesh.get_used_vertices_mask