﻿pysdic.Image.height
===================

.. currentmodule:: pysdic

.. autoproperty:: Image.height