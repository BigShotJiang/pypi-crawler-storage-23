﻿pysdic.compute\_optical\_flow
=============================

.. currentmodule:: pysdic

.. autofunction:: compute_optical_flow