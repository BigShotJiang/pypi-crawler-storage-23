﻿pysdic.View.image
=================

.. currentmodule:: pysdic

.. autoproperty:: View.image