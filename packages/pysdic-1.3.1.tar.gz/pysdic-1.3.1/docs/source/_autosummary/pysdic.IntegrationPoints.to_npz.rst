﻿pysdic.IntegrationPoints.to\_npz
================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.to_npz