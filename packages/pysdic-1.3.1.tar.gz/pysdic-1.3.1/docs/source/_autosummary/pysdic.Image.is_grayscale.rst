﻿pysdic.Image.is\_grayscale
==========================

.. currentmodule:: pysdic

.. autoproperty:: Image.is_grayscale