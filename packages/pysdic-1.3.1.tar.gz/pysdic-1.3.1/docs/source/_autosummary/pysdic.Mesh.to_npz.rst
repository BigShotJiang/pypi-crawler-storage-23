﻿pysdic.Mesh.to\_npz
===================

.. currentmodule:: pysdic

.. automethod:: Mesh.to_npz