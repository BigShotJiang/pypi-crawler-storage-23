﻿pysdic.compute\_backward\_finite\_difference\_coefficients
==========================================================

.. currentmodule:: pysdic

.. autofunction:: compute_backward_finite_difference_coefficients