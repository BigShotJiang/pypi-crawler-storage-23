﻿pysdic.IntegrationPoints.list\_precomputed
==========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.list_precomputed