﻿pysdic.compute\_adjacency\_matrix
=================================

.. currentmodule:: pysdic

.. autofunction:: compute_adjacency_matrix