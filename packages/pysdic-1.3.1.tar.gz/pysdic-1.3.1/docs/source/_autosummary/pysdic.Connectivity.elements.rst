﻿pysdic.Connectivity.elements
============================

.. currentmodule:: pysdic

.. autoproperty:: Connectivity.elements