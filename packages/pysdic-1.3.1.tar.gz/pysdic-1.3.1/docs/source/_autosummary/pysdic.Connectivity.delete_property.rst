﻿pysdic.Connectivity.delete\_property
====================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.delete_property