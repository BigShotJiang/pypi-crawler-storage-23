﻿pysdic.Camera.extrinsic
=======================

.. currentmodule:: pysdic

.. autoproperty:: Camera.extrinsic