﻿pysdic.PointCloud.copy\_properties
==================================

.. currentmodule:: pysdic

.. automethod:: PointCloud.copy_properties