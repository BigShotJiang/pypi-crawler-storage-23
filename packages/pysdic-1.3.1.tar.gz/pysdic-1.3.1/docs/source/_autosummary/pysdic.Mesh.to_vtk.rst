﻿pysdic.Mesh.to\_vtk
===================

.. currentmodule:: pysdic

.. automethod:: Mesh.to_vtk