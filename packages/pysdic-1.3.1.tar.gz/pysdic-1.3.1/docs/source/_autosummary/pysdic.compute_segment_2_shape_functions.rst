﻿pysdic.compute\_segment\_2\_shape\_functions
============================================

.. currentmodule:: pysdic

.. autofunction:: compute_segment_2_shape_functions