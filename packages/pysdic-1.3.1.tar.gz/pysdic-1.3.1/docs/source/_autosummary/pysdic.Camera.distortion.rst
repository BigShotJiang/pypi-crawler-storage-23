﻿pysdic.Camera.distortion
========================

.. currentmodule:: pysdic

.. autoproperty:: Camera.distortion