﻿pysdic.triangle\_3\_mesh\_to\_open3d
====================================

.. currentmodule:: pysdic

.. autofunction:: triangle_3_mesh_to_open3d