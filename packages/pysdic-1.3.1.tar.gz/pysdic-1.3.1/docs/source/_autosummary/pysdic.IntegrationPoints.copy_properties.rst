﻿pysdic.IntegrationPoints.copy\_properties
=========================================

.. currentmodule:: pysdic

.. automethod:: IntegrationPoints.copy_properties