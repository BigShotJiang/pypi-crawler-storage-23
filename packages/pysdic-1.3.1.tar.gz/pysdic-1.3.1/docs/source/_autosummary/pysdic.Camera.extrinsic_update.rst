﻿pysdic.Camera.extrinsic\_update
===============================

.. currentmodule:: pysdic

.. automethod:: Camera.extrinsic_update