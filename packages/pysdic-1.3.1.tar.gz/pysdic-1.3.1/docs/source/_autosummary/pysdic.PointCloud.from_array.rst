﻿pysdic.PointCloud.from\_array
=============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.from_array