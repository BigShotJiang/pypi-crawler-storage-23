﻿pysdic.Image.evaluate\_image\_jacobian\_dy\_at\_image\_points
=============================================================

.. currentmodule:: pysdic

.. automethod:: Image.evaluate_image_jacobian_dy_at_image_points