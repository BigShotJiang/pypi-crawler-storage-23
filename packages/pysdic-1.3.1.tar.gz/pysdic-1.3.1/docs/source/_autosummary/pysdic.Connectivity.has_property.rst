﻿pysdic.Connectivity.has\_property
=================================

.. currentmodule:: pysdic

.. automethod:: Connectivity.has_property