﻿pysdic.PointCloud.keep\_points
==============================

.. currentmodule:: pysdic

.. automethod:: PointCloud.keep_points