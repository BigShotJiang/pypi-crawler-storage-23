import os

DISPLAY = True
TEXTURE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'texture.tiff')