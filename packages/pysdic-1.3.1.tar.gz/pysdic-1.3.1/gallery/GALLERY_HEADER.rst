.. _gallery:

Example Gallery
================

This section contains a collection of examples demonstrating how to use the package ``pysdic`` for various applications. 

