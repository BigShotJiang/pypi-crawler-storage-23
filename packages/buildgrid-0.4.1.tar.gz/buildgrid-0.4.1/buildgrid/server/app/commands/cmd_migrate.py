# Copyright (C) 2026 Bloomberg LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#  <http://www.apache.org/licenses/LICENSE-2.0>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""
Migrate command
===============

Migrate databases mentioned in BuildGrid configuration.
"""

from importlib.resources import files

from alembic import command
from alembic.config import Config
import click

from buildgrid.server.app.cli import Context, pass_context
from buildgrid.server.sql.provider import SqlProvider


@click.group(name="migrate", short_help="Tool for migrating BuildGrid's databases.")
@pass_context
def cli(context: Context) -> None:
    pass


@cli.command("apply", short_help="Apply database migrations")
@click.argument("CONNECTION_STRING", type=click.STRING)
@pass_context
def apply(context: Context, connection_string: str) -> None:
    sql = SqlProvider(connection_string=connection_string)

    click.echo("Migrating database...")
    alembic_config: Config = Config()
    alembic_config.set_main_option("script_location", str(files("buildgrid.server.sql").joinpath("alembic")))
    with sql._engine.begin() as connection:
        # NOTE: pylint doesn't like this for some reason, but it is the
        # documented way to set the connection.
        # https://alembic.sqlalchemy.org/en/latest/api/config.html#alembic.config.Config
        alembic_config.attributes["connection"] = connection
        command.upgrade(alembic_config, "head")
    click.echo("Done!")
