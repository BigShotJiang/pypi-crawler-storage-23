def main():
    print("Hello from slsqp-jax!")


if __name__ == "__main__":
    main()
