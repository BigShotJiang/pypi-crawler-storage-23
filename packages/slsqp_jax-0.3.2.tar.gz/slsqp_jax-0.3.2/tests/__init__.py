"""Test suite for SLSQP-JAX."""
