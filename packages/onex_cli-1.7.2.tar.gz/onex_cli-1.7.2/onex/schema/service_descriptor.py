"""
Service descriptor Pydantic models.

This module defines the complete schema for service.yml files using Pydantic.
These models serve as the single source of truth for:
- Schema validation (CLI and platform)
- Auto-generated documentation
- JSON Schema export for IDE support
- Type hints for service configuration
"""

from typing import List, Optional, Dict, Any, Literal, Union, Annotated
from pydantic import BaseModel, Field, field_validator, model_validator
from enum import Enum
import re


# ============================================================================
# Resource and Configuration Models
# ============================================================================

class ResourcesConfig(BaseModel):
    """
    Resource limits and reservations for containerized services.

    Examples:
        - CPU: "0.5" (half a core), "2.0" (2 cores)
        - Memory: "512M", "1G", "2G"
    """

    cpu: Optional[str] = Field(
        None,
        description="CPU limit in cores (e.g., '0.5', '2.0')",
        examples=["0.5", "1.0", "2.0"]
    )

    memory: Optional[str] = Field(
        None,
        description="Memory limit (e.g., '512M', '1G', '2G')",
        examples=["512M", "1G", "2G"]
    )

    cpu_reservation: Optional[str] = Field(
        None,
        description="Guaranteed CPU allocation",
        examples=["0.25", "0.5"]
    )

    memory_reservation: Optional[str] = Field(
        None,
        description="Guaranteed memory allocation",
        examples=["256M", "512M"]
    )

    @field_validator('cpu', 'cpu_reservation')
    @classmethod
    def validate_cpu(cls, v: Optional[str]) -> Optional[str]:
        """Validate CPU format (e.g., '0.5', '2.0')"""
        if v is None:
            return v
        if not re.match(r'^\d+(\.\d+)?$', v):
            raise ValueError("CPU must be a number (e.g., '0.5', '2.0')")
        return v

    @field_validator('memory', 'memory_reservation')
    @classmethod
    def validate_memory(cls, v: Optional[str]) -> Optional[str]:
        """Validate memory format (e.g., '512M', '1G')"""
        if v is None:
            return v
        if not re.match(r'^\d+[MG]$', v):
            raise ValueError("Memory must end with M or G (e.g., '512M', '1G')")
        return v


class HealthCheckConfig(BaseModel):
    """
    Health check configuration for containerized services.

    The platform uses this to monitor service health and restart unhealthy containers.
    """

    endpoint: str = Field(
        default="/health",
        description="Health check HTTP endpoint",
        examples=["/health", "/api/health", "/status"]
    )

    interval: str = Field(
        default="30s",
        description="Time between health checks",
        examples=["20s", "30s", "60s"]
    )

    timeout: str = Field(
        default="10s",
        description="Health check timeout",
        examples=["5s", "10s", "15s"]
    )

    retries: int = Field(
        default=3,
        description="Consecutive failures before unhealthy",
        ge=1,
        le=10
    )

    start_period: str = Field(
        default="40s",
        description="Grace period on container start",
        examples=["30s", "40s", "60s"]
    )

    @field_validator('interval', 'timeout', 'start_period')
    @classmethod
    def validate_duration(cls, v: str) -> str:
        """Validate duration format (e.g., '30s', '1m')"""
        if not re.match(r'^\d+[smh]$', v):
            raise ValueError("Duration must end with s (seconds), m (minutes), or h (hours)")
        return v


class UpdateConfig(BaseModel):
    """
    Rolling update configuration for containerized services.

    Controls how services are updated without downtime.
    """

    parallelism: int = Field(
        default=1,
        description="How many replicas to update simultaneously",
        ge=1
    )

    delay: str = Field(
        default="10s",
        description="Delay between update batches",
        examples=["5s", "10s", "30s"]
    )

    failure_action: Literal["pause", "continue", "rollback"] = Field(
        default="rollback",
        description="Action on update failure"
    )

    monitor: str = Field(
        default="60s",
        description="Monitor duration after each update",
        examples=["30s", "60s", "120s"]
    )

    @field_validator('delay', 'monitor')
    @classmethod
    def validate_duration(cls, v: str) -> str:
        """Validate duration format"""
        if not re.match(r'^\d+[smh]$', v):
            raise ValueError("Duration must end with s, m, or h")
        return v


class RestartPolicyConfig(BaseModel):
    """
    Container restart policy configuration.

    Controls automatic restart behavior for failed containers.
    """

    condition: Literal["none", "on-failure", "any"] = Field(
        default="on-failure",
        description="When to restart container"
    )

    delay: str = Field(
        default="5s",
        description="Delay before restart",
        examples=["5s", "10s", "30s"]
    )

    max_attempts: int = Field(
        default=3,
        description="Maximum restart attempts",
        ge=0,
        le=10
    )

    @field_validator('delay')
    @classmethod
    def validate_duration(cls, v: str) -> str:
        """Validate duration format"""
        if not re.match(r'^\d+[smh]$', v):
            raise ValueError("Duration must end with s, m, or h")
        return v


class ContainerConfig(BaseModel):
    """
    Container-specific deployment configuration.

    Only used when deployment.mode = "container".
    Controls replica count, resources, health checks, and update strategy.
    """

    replicas: int = Field(
        default=1,
        description="Number of container instances",
        ge=1,
        le=100
    )

    resources: Optional[ResourcesConfig] = Field(
        None,
        description="CPU and memory limits"
    )

    healthcheck: Optional[HealthCheckConfig] = Field(
        None,
        description="Health check configuration"
    )

    update: Optional[UpdateConfig] = Field(
        None,
        description="Rolling update configuration"
    )

    restart_policy: Optional[RestartPolicyConfig] = Field(
        None,
        description="Container restart policy"
    )


class DeploymentConfig(BaseModel):
    """
    Deployment configuration for the service.

    Two modes:
    - shared-runtime: Service loaded into shared runtime container (faster, lower overhead)
    - container: Service deployed as separate Docker container (isolation, independent scaling)
    """

    mode: Literal["shared-runtime", "container"] = Field(
        default="shared-runtime",
        description="Deployment mode: shared-runtime or container"
    )

    container: Optional[ContainerConfig] = Field(
        None,
        description="Container configuration (only for mode=container)"
    )

    @model_validator(mode='after')
    def validate_container_config(self):
        """Ensure container config exists when mode=container"""
        if self.mode == "container" and self.container is None:
            # Provide default container config
            self.container = ContainerConfig()
        return self


# ============================================================================
# Route and API Models
# ============================================================================

class RouteDefinition(BaseModel):
    """
    API route definition.

    Registers an HTTP endpoint in the gateway routing table.
    """

    path: str = Field(
        ...,
        description="API endpoint path (must start with /)",
        examples=["/api/auth/login", "/api/products/{id}", "/health"]
    )

    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"] = Field(
        ...,
        description="HTTP method"
    )

    description: Optional[str] = Field(
        None,
        description="Human-readable description of the endpoint"
    )

    @field_validator('path')
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate path starts with /"""
        if not v.startswith('/'):
            raise ValueError("Route path must start with /")
        return v


# ============================================================================
# Function and Trigger Models
# ============================================================================

class TriggerType(str, Enum):
    """
    Types of triggers that can invoke a function.

    Similar to AWS Lambda event sources or Serverless Framework events.
    """
    HTTP = "http"           # HTTP endpoint (API Gateway)
    SCHEDULE = "schedule"   # Cron/scheduled trigger (CloudWatch Events)
    EVENT = "event"         # Event-driven trigger (EventBridge)
    STREAM = "stream"       # Database change stream (DynamoDB Streams)
    S3 = "s3"              # S3/MinIO bucket events (S3 Event Notifications)


class BaseTrigger(BaseModel):
    """Base trigger configuration shared by all trigger types"""

    type: TriggerType = Field(..., description="Trigger type")

    name: Optional[str] = Field(
        None,
        description="Trigger name for identification in logs and debugging",
        examples=["api_endpoint", "daily_batch", "order_completed"]
    )

    description: Optional[str] = Field(
        None,
        description="Human-readable description of the trigger"
    )

    enabled: bool = Field(
        default=True,
        description="Enable/disable this trigger"
    )


class HttpTrigger(BaseTrigger):
    """
    HTTP endpoint trigger.

    Creates an API endpoint that invokes the function when called.
    Replaces the routes field with function-specific HTTP triggers.
    """

    type: Literal[TriggerType.HTTP] = TriggerType.HTTP

    path: str = Field(
        ...,
        description="API path (must start with /)",
        examples=["/api/invoices", "/webhooks/stripe", "/health"]
    )

    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"] = Field(
        ...,
        description="HTTP method"
    )

    public: bool = Field(
        default=False,
        description="Skip authentication (public endpoint). Default: false (requires auth)"
    )

    @field_validator('path')
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate path starts with /"""
        if not v.startswith('/'):
            raise ValueError("HTTP path must start with /")
        return v


class ScheduleTrigger(BaseTrigger):
    """
    Scheduled/cron trigger.

    Invokes the function on a schedule (e.g., daily reports, cleanup tasks).
    Similar to AWS CloudWatch Events or Serverless Framework schedule event.
    """

    type: Literal[TriggerType.SCHEDULE] = TriggerType.SCHEDULE

    cron: str = Field(
        ...,
        description="Cron expression (5 or 6 parts: minute hour day month weekday [year])",
        examples=["0 8 * * *", "*/15 * * * *", "0 2 * * 0"]
    )

    timezone: str = Field(
        default="UTC",
        description="Timezone for cron evaluation",
        examples=["UTC", "Asia/Ho_Chi_Minh", "America/New_York", "Europe/London"]
    )

    input: Optional[Dict[str, Any]] = Field(
        None,
        description="Static input payload passed to function on each invocation",
        examples=[{"report_type": "daily"}, {"cleanup_days": 30}]
    )

    @field_validator('cron')
    @classmethod
    def validate_cron(cls, v: str) -> str:
        """Validate cron expression format"""
        parts = v.split()
        if len(parts) not in [5, 6]:
            raise ValueError(
                "Cron expression must have 5 or 6 parts (minute hour day month weekday [year]). "
                f"Got {len(parts)} parts: '{v}'"
            )
        return v


class EventFilter(BaseModel):
    """
    Content-based filter for event triggers.

    Uses JSONPath to extract fields from event payload and compare against values.
    All filters must match for the event to trigger the function.
    """

    field: str = Field(
        ...,
        description="JSONPath expression to extract field from event (e.g., '$.status', '$.total', '$.customer.email')",
        examples=["$.status", "$.total", "$.customer.email", "$.items[0].quantity"]
    )

    operator: Literal["==", "!=", ">", ">=", "<", "<=", "in", "contains"] = Field(
        ...,
        description="Comparison operator"
    )

    value: Any = Field(
        ...,
        description="Value to compare against",
        examples=["COMPLETED", 100, ["PENDING", "PROCESSING"], "@company.com"]
    )


class EventTrigger(BaseTrigger):
    """
    Event-driven trigger.

    Invokes the function when an event matching the pattern is published to NATS.
    Similar to AWS EventBridge rules or Serverless Framework EventBridge event.

    Supports:
    - Pattern matching (source, event type)
    - Content-based filtering (JSONPath filters)
    - Payload transformation (map event fields to function input)
    """

    type: Literal[TriggerType.EVENT] = TriggerType.EVENT

    source: Optional[str] = Field(
        None,
        description="Event source service (e.g., 'order', 'product', 'customer')",
        examples=["order", "product", "customer", "inventory"]
    )

    event_type: str = Field(
        ...,
        description="Event type pattern (supports wildcards: *, >)",
        examples=["order.status.changed", "product.*", "customer.registered", "inventory.low"]
    )

    filters: Optional[List[EventFilter]] = Field(
        None,
        description="Content-based filters (all must match). Uses JSONPath."
    )

    transform: Optional[Dict[str, str]] = Field(
        None,
        description="Payload transformation using JSONPath. Maps target fields to event fields.",
        examples=[{
            "order_id": "$.order_id",
            "total": "$.total",
            "customer_id": "$.customer_id"
        }]
    )


class StreamTrigger(BaseTrigger):
    """
    Database change stream trigger.

    Invokes the function when documents change in MongoDB collection.
    Similar to AWS DynamoDB Streams or Azure Cosmos DB Change Feed.

    Watches MongoDB change streams and reacts to insert/update/delete operations.
    """

    type: Literal[TriggerType.STREAM] = TriggerType.STREAM

    database: str = Field(
        ...,
        description="MongoDB database name to watch",
        examples=["order_db", "product_db", "customer_db"]
    )

    collection: str = Field(
        ...,
        description="MongoDB collection name to watch",
        examples=["orders", "products", "customers"]
    )

    operations: List[Literal["insert", "update", "delete", "replace"]] = Field(
        ...,
        description="Operations to watch (at least one required)",
        min_length=1,
        examples=[["insert", "update"], ["update"], ["insert", "update", "delete"]]
    )

    filters: Optional[List[EventFilter]] = Field(
        None,
        description="Content-based filters on change stream document (uses JSONPath on fullDocument or updateDescription)"
    )

    transform: Optional[Dict[str, str]] = Field(
        None,
        description="Payload transformation using JSONPath",
        examples=[{
            "order_id": "$.fullDocument._id",
            "status": "$.fullDocument.status"
        }]
    )

    batch_size: int = Field(
        default=1,
        description="Number of change events to batch before invoking function (1 = process immediately)",
        ge=1,
        le=100
    )


class S3Trigger(BaseTrigger):
    """
    S3/MinIO bucket event trigger.

    Invokes the function when objects are created/deleted in S3/MinIO buckets.
    Similar to AWS S3 Event Notifications or AWS Lambda S3 triggers.

    Watches S3/MinIO bucket events and reacts to object operations.
    """

    type: Literal[TriggerType.S3] = TriggerType.S3

    bucket: str = Field(
        ...,
        description="S3/MinIO bucket name to watch",
        examples=["product-images", "uploads", "documents"]
    )

    events: List[str] = Field(
        ...,
        description="S3 event types to watch (e.g., s3:ObjectCreated:*, s3:ObjectRemoved:*)",
        examples=[
            ["s3:ObjectCreated:*"],
            ["s3:ObjectCreated:Put", "s3:ObjectCreated:Post"],
            ["s3:ObjectRemoved:*"]
        ]
    )

    prefix: Optional[str] = Field(
        None,
        description="Filter by object key prefix (e.g., 'images/', 'uploads/2024/')",
        examples=["images/", "uploads/2024/", "documents/invoices/"]
    )

    suffix: Optional[str] = Field(
        None,
        description="Filter by object key suffix (e.g., '.jpg', '.pdf', '.csv')",
        examples=[".jpg", ".pdf", ".csv", ".json"]
    )

    @field_validator('bucket')
    @classmethod
    def validate_bucket(cls, v: str) -> str:
        """Validate bucket name (lowercase, alphanumeric + hyphens)"""
        if not re.match(r'^[a-z][a-z0-9-]*$', v):
            raise ValueError(
                f"Bucket name '{v}' must be lowercase with alphanumeric + hyphens"
            )
        return v


# Discriminated union of all trigger types
# Pydantic will automatically validate and deserialize to correct subclass
TriggerConfig = Annotated[
    Union[HttpTrigger, ScheduleTrigger, EventTrigger, StreamTrigger, S3Trigger],
    Field(discriminator='type')
]


class FunctionDefinition(BaseModel):
    """
    Function definition with triggers.

    Similar to AWS Lambda functions or Serverless Framework functions.
    Each function can have multiple triggers (HTTP, schedule, event, stream).

    All functions are invocable via platform's Invoke Service (sync/async),
    even if they have no triggers defined.

    Example:
        ```yaml
        name: createInvoice
        handler: handlers.invoice.create
        timeout: 300
        triggers:
          - type: http
            path: /api/invoices
            method: POST
          - type: event
            source: order
            event_type: order.status.changed
            filters:
              - field: $.status
                operator: "=="
                value: "COMPLETED"
        ```
    """

    name: str = Field(
        ...,
        description="Function name (alphanumeric + underscores)",
        examples=["createInvoice", "sendEmail", "generateReport", "handleWebhook"]
    )

    handler: str = Field(
        ...,
        description="Python module path to handler function",
        examples=[
            "handlers.invoice.create",
            "handlers.email.send",
            "handlers.reports.generate_daily",
            "src.webhooks.stripe_handler"
        ]
    )

    description: Optional[str] = Field(
        None,
        description="Human-readable function description"
    )

    timeout: int = Field(
        default=300,
        description="Function execution timeout in seconds",
        ge=1,
        le=3600  # Max 1 hour
    )

    memory: Optional[str] = Field(
        None,
        description="Memory limit (e.g., '256M', '512M', '1G')",
        examples=["256M", "512M", "1G", "2G"]
    )

    triggers: List[TriggerConfig] = Field(
        default_factory=list,
        description="Event sources that trigger this function. Empty list = invoke-only function."
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate function name (alphanumeric + underscores)"""
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]*$', v):
            raise ValueError(
                f"Function name must start with letter and contain only alphanumeric characters + underscores. "
                f"Invalid: '{v}'"
            )
        return v

    @field_validator('handler')
    @classmethod
    def validate_handler(cls, v: str) -> str:
        """Validate handler is a valid Python module path"""
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_.]*$', v):
            raise ValueError(
                f"Handler must be a valid Python module path (e.g., 'handlers.invoice.create'). "
                f"Invalid: '{v}'"
            )
        return v

    @field_validator('memory')
    @classmethod
    def validate_memory(cls, v: Optional[str]) -> Optional[str]:
        """Validate memory format (e.g., '512M', '1G')"""
        if v is not None and not re.match(r'^\d+[MG]$', v):
            raise ValueError(
                f"Memory must end with M or G (e.g., '512M', '1G'). "
                f"Invalid: '{v}'"
            )
        return v


# ============================================================================
# Dependency Models
# ============================================================================

class DependenciesConfig(BaseModel):
    """
    Service dependencies configuration.

    Defines platform services this service requires.
    Platform ensures dependencies are healthy before starting the service.
    """

    services: Optional[List[str]] = Field(
        None,
        description="Required platform services (mongodb, redis, nats, etc.)",
        examples=[["mongodb", "redis"], ["mongodb", "redis", "nats"]]
    )

    optional: Optional[List[str]] = Field(
        None,
        description="Optional services (service works without them)",
        examples=[["elasticsearch"], ["minio"]]
    )

    @field_validator('services', 'optional')
    @classmethod
    def validate_service_names(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Validate service names are lowercase"""
        if v is None:
            return v

        valid_services = {
            "mongodb", "redis", "elasticsearch", "nats",
            "minio", "postgres"
        }

        for service in v:
            if service not in valid_services:
                raise ValueError(
                    f"Unknown service '{service}'. "
                    f"Valid services: {', '.join(sorted(valid_services))}"
                )

        return v


# ============================================================================
# Metadata Models
# ============================================================================

class MetadataConfig(BaseModel):
    """
    Service metadata for documentation and tracking.

    Optional information about service ownership, documentation, and categorization.
    """

    owner: Optional[str] = Field(
        None,
        description="Team or person responsible for the service",
        examples=["auth-team", "platform-team"]
    )

    repo: Optional[str] = Field(
        None,
        description="Source code repository URL",
        examples=["https://github.com/onexapis/onexeos-services"]
    )

    docs: Optional[str] = Field(
        None,
        description="Documentation URL",
        examples=["https://docs.onexeos.com/services/auth"]
    )

    tags: Optional[List[str]] = Field(
        None,
        description="Tags for categorization and discovery",
        examples=[["authentication", "security"], ["high-traffic", "critical"]]
    )


# ============================================================================
# Platform Resources Models
# ============================================================================

class NATSStreamConfig(BaseModel):
    """
    NATS JetStream stream configuration.

    Defines a NATS stream for event publishing/subscription.
    Streams are automatically provisioned at deployment time.
    """

    name: str = Field(
        ...,
        description="Stream name (uppercase, alphanumeric + underscores)",
        examples=["PRODUCT_EVENTS", "ORDER_NOTIFICATIONS"]
    )

    subjects: List[str] = Field(
        ...,
        description="NATS subject patterns this stream handles",
        examples=[["product.created", "product.updated"], ["order.>"]]
    )

    retention: Literal["limits", "interest", "workqueue"] = Field(
        default="limits",
        description="Retention policy: limits (time/size), interest (consumer-based), workqueue (delete after ack)"
    )

    max_age_days: Optional[int] = Field(
        default=7,
        description="Maximum message age in days (null = no limit)",
        ge=1
    )

    max_bytes: str = Field(
        default="100MB",
        description="Maximum stream size (e.g., '100MB', '1GB')",
        examples=["100MB", "500MB", "1GB"]
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate stream name (uppercase, alphanumeric + underscores)"""
        if not re.match(r'^[A-Z][A-Z0-9_]*$', v):
            raise ValueError(
                f"Stream name must be uppercase with alphanumeric + underscores: '{v}'"
            )
        return v

    @field_validator('subjects')
    @classmethod
    def validate_subjects(cls, v: List[str]) -> List[str]:
        """Ensure at least one subject"""
        if not v:
            raise ValueError("At least one subject is required")
        return v

    @field_validator('max_bytes')
    @classmethod
    def validate_max_bytes(cls, v: str) -> str:
        """Validate size format (e.g., '100MB', '1GB')"""
        if not re.match(r'^\d+[MG]B?$', v):
            raise ValueError("max_bytes must be format like '100MB', '1GB'")
        return v


class MongoDBIndexConfig(BaseModel):
    """
    MongoDB index configuration.

    Defines an index for a MongoDB collection.
    """

    fields: Dict[str, int] = Field(
        ...,
        description="Index fields with sort order (1 for ascending, -1 for descending)",
        examples=[{"email": 1}, {"created_at": -1, "status": 1}]
    )

    unique: bool = Field(
        default=False,
        description="Whether index enforces uniqueness"
    )

    name: Optional[str] = Field(
        default=None,
        description="Index name (auto-generated if not provided)"
    )

    sparse: bool = Field(
        default=False,
        description="Whether index is sparse (only indexes documents with the field)"
    )


class MongoDBCollectionConfig(BaseModel):
    """
    MongoDB collection configuration with optional indexes.
    """

    name: str = Field(
        ...,
        description="Collection name (lowercase, alphanumeric + underscores)",
        examples=["users", "products", "orders"]
    )

    indexes: Optional[List[MongoDBIndexConfig]] = Field(
        default=None,
        description="Indexes to create on this collection"
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate collection name"""
        if not re.match(r'^[a-z][a-z0-9_]*$', v):
            raise ValueError(
                f"Collection name '{v}' must be lowercase with alphanumeric + underscores"
            )
        return v


class MongoDBDatabaseConfig(BaseModel):
    """
    MongoDB database configuration.

    Defines a MongoDB database and collections for service data storage.
    Databases and collections are automatically created at deployment time.

    Supports two formats:
    1. Simple: List of collection names (strings)
    2. Advanced: List of collection configs with indexes

    Examples:
        # Simple format
        databases:
          - name: "product_db"
            collections: ["products", "categories"]

        # Advanced format with indexes
        databases:
          - name: "product_db"
            collections:
              - name: "users"
                indexes:
                  - fields: {email: 1}
                    unique: true
                  - fields: {created_at: -1}
    """

    name: str = Field(
        ...,
        description="Database name (lowercase, alphanumeric + underscores)",
        examples=["product_db", "order_database"]
    )

    collections: List[Union[str, MongoDBCollectionConfig]] = Field(
        ...,
        description="Collection names (simple) or collection configs (with indexes)",
        examples=[
            ["products", "categories", "inventory"],
            [{"name": "users", "indexes": [{"fields": {"email": 1}, "unique": True}]}]
        ]
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate database name (lowercase, alphanumeric + underscores)"""
        if not re.match(r'^[a-z][a-z0-9_]*$', v):
            raise ValueError(
                f"Database name must be lowercase with alphanumeric + underscores: '{v}'"
            )
        return v

    @field_validator('collections')
    @classmethod
    def validate_collections(cls, v: List[Union[str, MongoDBCollectionConfig]]) -> List[Union[str, MongoDBCollectionConfig]]:
        """Ensure at least one collection and valid names"""
        if not v:
            raise ValueError("At least one collection is required")

        for collection in v:
            # String format already validated by Pydantic
            # MongoDBCollectionConfig format validated by its own validator
            if isinstance(collection, str):
                if not re.match(r'^[a-z][a-z0-9_]*$', collection):
                    raise ValueError(
                        f"Collection name '{collection}' must be lowercase with alphanumeric + underscores"
                    )
        return v


class ElasticsearchIndexConfig(BaseModel):
    """
    Elasticsearch index configuration.

    Defines an Elasticsearch index for search and analytics.
    Indices are automatically created at deployment time.
    """

    name: str = Field(
        ...,
        description="Index name (lowercase, alphanumeric + hyphens/underscores)",
        examples=["products", "orders-2024"]
    )

    mappings: Optional[Dict[str, Any]] = Field(
        None,
        description="Index mappings (Elasticsearch mapping schema)"
    )

    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate index name (lowercase, alphanumeric + hyphens/underscores)"""
        if not re.match(r'^[a-z][a-z0-9_-]*$', v):
            raise ValueError(
                f"Index name must be lowercase with alphanumeric + hyphens/underscores: '{v}'"
            )
        return v


class PlatformResourcesConfig(BaseModel):
    """
    Platform infrastructure resources required by this service.

    Declarative resource provisioning:
    - NATS streams for event publishing/subscription
    - MongoDB databases and collections for data storage
    - Redis namespaces for caching and state
    - Elasticsearch indices for search
    - MinIO buckets for object storage

    All resources are validated against protected platform resources at deployment time.
    Services CANNOT use platform-reserved names (e.g., 'INVOKE', 'platform:', 'onexeos').
    """

    streams: Optional[List[NATSStreamConfig]] = Field(
        None,
        description="NATS JetStream streams to provision"
    )

    databases: Optional[List[MongoDBDatabaseConfig]] = Field(
        None,
        description="MongoDB databases to provision"
    )

    redis_namespaces: Optional[List[str]] = Field(
        None,
        description="Redis key prefixes (namespaces) to register (e.g., 'product:', 'order:cache:')",
        examples=[["product:cache:", "product:session:"], ["order:"]]
    )

    indices: Optional[List[ElasticsearchIndexConfig]] = Field(
        None,
        description="Elasticsearch indices to provision"
    )

    buckets: Optional[List[str]] = Field(
        None,
        description="MinIO S3 buckets to provision (lowercase, alphanumeric + hyphens)",
        examples=[["product-images", "product-documents"], ["order-attachments"]]
    )

    @field_validator('redis_namespaces')
    @classmethod
    def validate_redis_namespaces(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Validate Redis namespace format (should end with :)"""
        if v is None:
            return v

        for namespace in v:
            if not namespace.endswith(':'):
                raise ValueError(
                    f"Redis namespace '{namespace}' should end with ':' (e.g., 'product:', 'cache:')"
                )
            if not re.match(r'^[a-z][a-z0-9_:-]*:$', namespace):
                raise ValueError(
                    f"Redis namespace '{namespace}' must be lowercase with alphanumeric + underscores/hyphens/colons"
                )
        return v

    @field_validator('buckets')
    @classmethod
    def validate_buckets(cls, v: Optional[List[str]]) -> Optional[List[str]]:
        """Validate MinIO bucket names (lowercase, alphanumeric + hyphens)"""
        if v is None:
            return v

        for bucket in v:
            if not re.match(r'^[a-z][a-z0-9-]*$', bucket):
                raise ValueError(
                    f"Bucket name '{bucket}' must be lowercase with alphanumeric + hyphens"
                )
        return v


# ============================================================================
# Main Service Descriptor Model
# ============================================================================

class ServiceDescriptor(BaseModel):
    """
    Complete service descriptor schema for service.yml files.

    This is the root model that defines the entire service configuration.
    All services must provide at minimum: name, version, and deployment config.

    Example:
        ```yaml
        name: auth
        version: 1.0.0
        description: Authentication service

        deployment:
          mode: shared-runtime

        functions:
          - name: login
            handler: handlers.auth.login
            timeout: 30
            triggers:
              - type: http
                path: /api/auth/login
                method: POST
                description: User login endpoint

        dependencies:
          services:
            - mongodb
            - redis
        ```
    """

    # Core fields (required)
    name: str = Field(
        ...,
        description="Service identifier (lowercase, alphanumeric + hyphens, max 50 chars)",
        examples=["auth", "product-catalog", "user-service"]
    )

    version: str = Field(
        ...,
        description="Semantic version (MAJOR.MINOR.PATCH)",
        examples=["1.0.0", "2.1.3", "0.9.1"]
    )

    description: Optional[str] = Field(
        None,
        description="Human-readable service description"
    )

    # Deployment configuration (required)
    deployment: DeploymentConfig = Field(
        ...,
        description="Deployment mode and configuration"
    )

    # Functions (optional)
    functions: Optional[List[FunctionDefinition]] = Field(
        None,
        description="Function definitions with triggers (HTTP, schedule, event, stream). All functions are invocable via platform."
    )

    # Dependencies (optional)
    dependencies: Optional[DependenciesConfig] = Field(
        None,
        description="Platform service dependencies"
    )

    # Python requirements (optional)
    requirements: Optional[List[str]] = Field(
        None,
        description="Python package dependencies",
        examples=[
            ["pydantic>=2.0.0", "bcrypt>=4.0.0"],
            ["pandas>=2.0.0", "numpy>=1.24.0"]
        ]
    )

    # Environment-specific configuration (optional)
    environments: Optional[Dict[str, Dict[str, Any]]] = Field(
        None,
        description="Environment-specific overrides (dev, staging, production)",
        examples=[{
            "dev": {"replicas": 1, "debug": True},
            "production": {"replicas": 5, "debug": False}
        }]
    )

    # Metadata (optional)
    metadata: Optional[MetadataConfig] = Field(
        None,
        description="Service metadata and documentation"
    )

    # Platform resources (optional)
    resources: Optional[PlatformResourcesConfig] = Field(
        None,
        description="Platform infrastructure resources to provision (NATS streams, MongoDB databases, Redis namespaces, etc.)"
    )

    # Validation
    @field_validator('name')
    @classmethod
    def validate_name(cls, v: str) -> str:
        """
        Validate service name:
        - Lowercase alphanumeric and hyphens only
        - Must start with a letter
        - Max 50 characters
        """
        if not re.match(r'^[a-z][a-z0-9-]{0,49}$', v):
            raise ValueError(
                "Service name must:\n"
                "- Start with a lowercase letter\n"
                "- Contain only lowercase letters, numbers, and hyphens\n"
                "- Be max 50 characters\n"
                f"Invalid: '{v}'"
            )
        return v

    @field_validator('version')
    @classmethod
    def validate_version(cls, v: str) -> str:
        """
        Validate semantic version format: MAJOR.MINOR.PATCH
        """
        if not re.match(r'^\d+\.\d+\.\d+$', v):
            raise ValueError(
                f"Version must follow semantic versioning (e.g., '1.0.0', '2.1.3'). "
                f"Invalid: '{v}'"
            )
        return v

    @model_validator(mode='after')
    def validate_unique_http_triggers(self):
        """
        Ensure no duplicate HTTP triggers across all functions.

        Multiple functions cannot have the same HTTP path + method combination.
        """
        if not self.functions:
            return self

        seen_routes = set()
        for func in self.functions:
            for trigger in func.triggers:
                # Check if trigger is HttpTrigger
                if isinstance(trigger, HttpTrigger):
                    route_key = f"{trigger.method}:{trigger.path}"
                    if route_key in seen_routes:
                        raise ValueError(
                            f"Duplicate HTTP route in function '{func.name}': "
                            f"{trigger.method} {trigger.path}. "
                            f"Each HTTP path+method combination must be unique across all functions."
                        )
                    seen_routes.add(route_key)

        return self

    class Config:
        json_schema_extra = {
            "examples": [
                {
                    "name": "auth",
                    "version": "1.0.0",
                    "description": "Authentication service",
                    "deployment": {
                        "mode": "shared-runtime"
                    },
                    "functions": [
                        {
                            "name": "login",
                            "handler": "handlers.auth.login",
                            "description": "User authentication",
                            "timeout": 30,
                            "triggers": [
                                {
                                    "type": "http",
                                    "name": "login_endpoint",
                                    "path": "/api/auth/login",
                                    "method": "POST",
                                    "description": "User login endpoint"
                                }
                            ]
                        },
                        {
                            "name": "refreshToken",
                            "handler": "handlers.auth.refresh",
                            "timeout": 15,
                            "triggers": []  # Invoke-only function
                        }
                    ],
                    "dependencies": {
                        "services": ["mongodb", "redis"]
                    }
                },
                {
                    "name": "automation",
                    "version": "3.1.2",
                    "description": "Automation and workflow service with multi-trigger functions",
                    "deployment": {
                        "mode": "container",
                        "container": {
                            "replicas": 3,
                            "resources": {
                                "cpu": "1.0",
                                "memory": "1G"
                            }
                        }
                    },
                    "functions": [
                        {
                            "name": "createInvoice",
                            "handler": "handlers.invoice.create",
                            "description": "Create invoice (multi-trigger)",
                            "timeout": 300,
                            "triggers": [
                                {
                                    "type": "http",
                                    "name": "api_endpoint",
                                    "path": "/api/invoices",
                                    "method": "POST"
                                },
                                {
                                    "type": "schedule",
                                    "name": "daily_batch",
                                    "cron": "0 8 * * *",
                                    "timezone": "Asia/Ho_Chi_Minh",
                                    "input": {"report_type": "daily"}
                                },
                                {
                                    "type": "event",
                                    "name": "order_completed",
                                    "source": "order",
                                    "event_type": "order.status.changed",
                                    "filters": [
                                        {
                                            "field": "$.new_status",
                                            "operator": "==",
                                            "value": "COMPLETED"
                                        },
                                        {
                                            "field": "$.total",
                                            "operator": ">",
                                            "value": 0
                                        }
                                    ],
                                    "transform": {
                                        "order_id": "$.order_id",
                                        "customer_id": "$.customer_id",
                                        "total": "$.total"
                                    }
                                },
                                {
                                    "type": "stream",
                                    "name": "order_db_changes",
                                    "database": "order_db",
                                    "collection": "orders",
                                    "operations": ["update"],
                                    "filters": [
                                        {
                                            "field": "$.fullDocument.status",
                                            "operator": "==",
                                            "value": "COMPLETED"
                                        }
                                    ],
                                    "transform": {
                                        "order_id": "$.fullDocument._id"
                                    }
                                }
                            ]
                        },
                        {
                            "name": "sendEmail",
                            "handler": "handlers.email.send",
                            "timeout": 30,
                            "triggers": []  # Called by other functions only
                        }
                    ],
                    "dependencies": {
                        "services": ["mongodb", "redis", "nats"]
                    }
                },
                {
                    "name": "product",
                    "version": "2.0.0",
                    "description": "Product catalog service with resources and functions",
                    "deployment": {
                        "mode": "shared-runtime"
                    },
                    "functions": [
                        {
                            "name": "listProducts",
                            "handler": "handlers.product.list",
                            "timeout": 60,
                            "triggers": [
                                {
                                    "type": "http",
                                    "path": "/api/products",
                                    "method": "GET"
                                }
                            ]
                        },
                        {
                            "name": "createProduct",
                            "handler": "handlers.product.create",
                            "timeout": 120,
                            "triggers": [
                                {
                                    "type": "http",
                                    "path": "/api/products",
                                    "method": "POST"
                                }
                            ]
                        }
                    ],
                    "dependencies": {
                        "services": ["mongodb", "redis", "nats", "elasticsearch", "minio"]
                    },
                    "resources": {
                        "streams": [
                            {
                                "name": "PRODUCT_EVENTS",
                                "subjects": ["product.created", "product.updated", "product.deleted"],
                                "retention": "limits",
                                "max_age_days": 14,
                                "max_bytes": "500MB"
                            }
                        ],
                        "databases": [
                            {
                                "name": "product_db",
                                "collections": ["products", "categories", "inventory", "price_history"]
                            }
                        ],
                        "redis_namespaces": ["product:cache:", "product:session:"],
                        "indices": [
                            {
                                "name": "products",
                                "mappings": {
                                    "properties": {
                                        "name": {"type": "text"},
                                        "sku": {"type": "keyword"},
                                        "price": {"type": "double"}
                                    }
                                }
                            }
                        ],
                        "buckets": ["product-images", "product-documents"]
                    }
                }
            ]
        }
