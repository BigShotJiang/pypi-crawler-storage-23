"""
Credential Encryption Utilities

Securely encrypt and decrypt credentials for auto-token refresh.

Uses AES-256 encryption with machine-specific key derivation.
"""

import base64
import hashlib
import platform
import getpass
from pathlib import Path
from typing import Optional, Tuple
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


def get_machine_salt() -> bytes:
    """
    Generate a machine-specific salt for key derivation.

    Uses a combination of:
    - Machine hostname
    - Current username
    - Platform info

    This ensures encrypted credentials are tied to this specific machine.

    Returns:
        32-byte salt unique to this machine
    """
    # Combine multiple machine-specific identifiers
    identifiers = [
        platform.node(),  # Machine hostname
        getpass.getuser(),  # Current username
        platform.system(),  # OS type (Darwin, Linux, Windows)
        platform.machine(),  # Architecture (x86_64, arm64, etc.)
    ]

    # Create deterministic salt from machine identifiers
    combined = '|'.join(identifiers)
    salt = hashlib.sha256(combined.encode()).digest()

    return salt


def derive_encryption_key(password: str, salt: bytes) -> bytes:
    """
    Derive encryption key from password and salt using PBKDF2.

    Args:
        password: User password or master key
        salt: Machine-specific salt

    Returns:
        32-byte encryption key suitable for Fernet
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,  # OWASP recommendation
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key


def get_default_encryption_key() -> bytes:
    """
    Get default encryption key for this machine.

    Uses machine-specific salt so encrypted data can only be
    decrypted on the same machine.

    Returns:
        Encryption key
    """
    # Use a hardcoded master password combined with machine salt
    # This is less secure than user-provided password, but acceptable for:
    # 1. VPN-protected environments
    # 2. Developer workstations (not production)
    # 3. Opt-in feature (user must have VPN config with embedded credentials)
    master_password = "onex-cli-auto-refresh-v1"
    salt = get_machine_salt()
    return derive_encryption_key(master_password, salt)


def encrypt_credentials(email: str, password: str, key: Optional[bytes] = None) -> str:
    """
    Encrypt email and password for secure storage.

    Args:
        email: User email
        password: User password
        key: Encryption key (defaults to machine-specific key)

    Returns:
        Base64-encoded encrypted credentials

    Example:
        encrypted = encrypt_credentials("user@example.com", "secret123")
        # Returns: "gAAAAABh..."
    """
    if key is None:
        key = get_default_encryption_key()

    # Combine email and password with delimiter
    credentials = f"{email}|||{password}"

    # Encrypt using Fernet (AES-128-CBC with HMAC)
    fernet = Fernet(key)
    encrypted = fernet.encrypt(credentials.encode())

    # Return base64-encoded string for JSON storage
    return base64.urlsafe_b64encode(encrypted).decode('utf-8')


def decrypt_credentials(encrypted_data: str, key: Optional[bytes] = None) -> Tuple[str, str]:
    """
    Decrypt credentials from encrypted storage.

    Args:
        encrypted_data: Base64-encoded encrypted credentials
        key: Encryption key (defaults to machine-specific key)

    Returns:
        Tuple of (email, password)

    Raises:
        ValueError: If decryption fails or data format is invalid

    Example:
        email, password = decrypt_credentials("gAAAAABh...")
    """
    if key is None:
        key = get_default_encryption_key()

    try:
        # Decode base64
        encrypted = base64.urlsafe_b64decode(encrypted_data.encode('utf-8'))

        # Decrypt using Fernet
        fernet = Fernet(key)
        decrypted = fernet.decrypt(encrypted).decode('utf-8')

        # Split email and password
        parts = decrypted.split('|||')
        if len(parts) != 2:
            raise ValueError("Invalid credential format")

        email, password = parts
        return email, password

    except Exception as e:
        raise ValueError(f"Failed to decrypt credentials: {str(e)}")


def test_encryption():
    """
    Test encryption/decryption round-trip.

    Returns:
        True if test passes, raises exception otherwise
    """
    # Test data
    test_email = "test@example.com"
    test_password = "supersecret123"

    # Encrypt
    encrypted = encrypt_credentials(test_email, test_password)

    # Decrypt
    email, password = decrypt_credentials(encrypted)

    # Verify
    assert email == test_email, f"Email mismatch: {email} != {test_email}"
    assert password == test_password, f"Password mismatch: {password} != {test_password}"

    return True


if __name__ == "__main__":
    # Run tests
    print("Testing credential encryption...")
    test_encryption()
    print("✅ Encryption test passed")

    # Show machine salt (for debugging)
    salt = get_machine_salt()
    print(f"\nMachine salt: {base64.b64encode(salt).decode()}")

    # Demo
    print("\nDemo:")
    encrypted = encrypt_credentials("demo@onexeos.com", "demo123")
    print(f"Encrypted: {encrypted}")

    email, password = decrypt_credentials(encrypted)
    print(f"Decrypted: email={email}, password={password}")
