"""
Utility functions for OneXEOS CLI
"""

# Import all helper functions from helpers module
from .helpers import (
    load_service_yml,
    create_service_bundle,
    get_shared_libs_path,
    validate_service_structure,
    validate_service_schema,
    validate_bundle_compilation,
    format_size,
    print_success,
    print_error,
    print_info,
    print_warning,
    print_header,
    print_section_header,
    print_footer,
    format_timestamp,
    format_current_time,
    format_duration,
    print_metrics_table,
    print_progress_bar,
    print_tree_item,
    monitor_deployment_progress,
    format_progress_message,
    get_auth_data,
    get_auth_headers,
    require_auth,
)

# Import email utilities
from .email import (
    send_email,
    # send_vpn_config_email - removed, use bash scripts in scripts/vpn/
)

__all__ = [
    # Helper functions
    'load_service_yml',
    'create_service_bundle',
    'get_shared_libs_path',
    'validate_service_structure',
    'validate_service_schema',
    'validate_bundle_compilation',
    'format_size',
    'print_success',
    'print_error',
    'print_info',
    'print_warning',
    'print_header',
    'print_section_header',
    'print_footer',
    'format_timestamp',
    'format_current_time',
    'format_duration',
    'print_metrics_table',
    'print_progress_bar',
    'print_tree_item',
    'monitor_deployment_progress',
    'format_progress_message',
    'get_auth_data',
    'get_auth_headers',
    'require_auth',
    # Email functions
    'send_email',
]
