"""
OneX MCP Server

Model Context Protocol server that exposes OneX CLI commands as tools
for AI assistants to investigate issues, debug services, and manage the platform.

Usage:
    onex-mcp  # Runs stdio-based MCP server for Claude Desktop

Architecture:
    - Uses subprocess to call existing onex CLI commands
    - Async/await for non-blocking execution
    - Comprehensive error handling
    - Structured output for AI consumption
"""

import asyncio
import json
import sys
from pathlib import Path
from typing import Optional

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print("Error: MCP package not installed", file=sys.stderr)
    print("Install with: pip install -e '.[mcp]'", file=sys.stderr)
    sys.exit(1)


# Initialize MCP server
mcp = FastMCP("onex-platform")


def get_active_environment() -> str:
    """Get active environment from ~/.onex/active-env, fallback to 'local'"""
    try:
        from pathlib import Path
        active_file = Path.home() / '.onex' / 'active-env'
        if active_file.exists():
            return active_file.read_text().strip()
    except Exception:
        pass
    return 'local'


async def run_onex_command(*args: str, timeout: int = 30) -> tuple[str, str, int]:
    """
    Execute onex CLI command via subprocess.

    Args:
        *args: Command arguments (e.g., 'platform', 'check')
        timeout: Command timeout in seconds

    Returns:
        Tuple of (stdout, stderr, returncode)
    """
    try:
        process = await asyncio.create_subprocess_exec(
            'onex', *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout
        )

        return (
            stdout.decode('utf-8'),
            stderr.decode('utf-8'),
            process.returncode or 0
        )

    except asyncio.TimeoutError:
        return "", f"Command timed out after {timeout} seconds", 1
    except FileNotFoundError:
        return "", "Error: 'onex' command not found. Is it installed?", 1
    except Exception as e:
        return "", f"Error executing command: {str(e)}", 1


# =============================================================================
# PLATFORM TOOLS
# =============================================================================

@mcp.tool()
async def onex_platform_check(env: str = None) -> str:
    """Check OneX platform infrastructure health.

    Verifies all core platform services are running and healthy:
    - MongoDB (database)
    - Redis (cache and queues)
    - NATS (message streaming)
    - Elasticsearch (search engine)
    - MinIO (object storage)
    - Gateway (API gateway)

    This is the FIRST tool to run when investigating any issue.
    If platform services are down, nothing will work.

    Args:
        env: Environment to check (local/dev/staging/prod). Default: active environment

    Returns:
        Formatted health status of all platform services with ✅/❌ indicators

    Examples:
        User: "Is my platform healthy?"
        → onex_platform_check()

        User: "Check dev environment"
        → onex_platform_check(env="dev")
    """
    if env is None:
        env = get_active_environment()

    stdout, stderr, code = await run_onex_command('platform', 'check', '--env', env)

    if code != 0:
        return f"Error checking platform health:\n{stderr}\n{stdout}"

    return stdout


# =============================================================================
# DEBUGGING TOOLS
# =============================================================================

@mcp.tool()
async def onex_trace(
    trace_id: str,
    env: str = None,
    follow: bool = False,
    json_output: bool = False
) -> str:
    """Track a request through the platform using trace_id.

    Shows complete request timeline across all services:
    - Gateway received request
    - Runtime forwarded to service
    - Service handler execution
    - Response path back to client

    Includes timestamps, durations, and error details.
    CRITICAL for debugging API failures and performance issues.

    Args:
        trace_id: Request trace ID from x-trace-id response header
        env: Environment (local/dev/staging/prod). Default: active environment
        follow: Follow trace in real-time (for long-running requests)
        json_output: Return JSON format instead of formatted text

    Returns:
        Complete request trace with timing information and errors

    Examples:
        User: "Why did this API call fail? trace_id: 550e8400-e29b-41d4-a716-446655440000"
        → onex_trace(trace_id="550e8400-e29b-41d4-a716-446655440000")

        User: "Trace this request in dev"
        → onex_trace(trace_id="...", env="dev")
    """
    if env is None:
        env = get_active_environment()

    cmd = ['trace', trace_id, '--env', env]
    if follow:
        cmd.append('--follow')
    if json_output:
        cmd.append('--json')

    stdout, stderr, code = await run_onex_command(*cmd, timeout=60 if follow else 30)

    if code != 0:
        return f"Error tracing request:\n{stderr}\n{stdout}"

    return stdout


@mcp.tool()
async def onex_logs(
    service_name: str,
    env: str = None,
    follow: bool = False,
    lines: int = 100,
    level: str = None,
    trace_id: str = None,
    user_id: str = None,
    company_id: str = None,
    path: str = None,
    method: str = None,
    event: str = None,
    grep: str = None,
    last: str = None
) -> str:
    """View service logs from platform with powerful filtering.

    Fetches recent logs for a deployed service with advanced filtering options.
    Perfect for debugging specific issues, tracking user requests, and finding errors.

    Args:
        service_name: Name of the service (e.g., 'email-service', 'product', 'auth')
        env: Environment (local/dev/staging/prod). Default: active environment
        follow: Follow logs in real-time (like tail -f)
        lines: Number of recent lines to show. Default: 100
        level: Filter by level (ERROR, WARNING, INFO, DEBUG) - comma-separated
        trace_id: Filter by trace ID to track specific request
        user_id: Filter by user ID to track specific user's activity
        company_id: Filter by company/tenant ID
        path: Filter by API path (e.g., "/auth/login")
        method: Filter by HTTP method (GET, POST, etc.)
        event: Filter by event type (service_ready, error, etc.)
        grep: Search message with regex pattern
        last: Time range (e.g., "1h", "30m", "24h")

    Returns:
        Recent log entries with timestamps and log levels, filtered by criteria

    Examples:
        User: "Show me auth errors from the last hour"
        → onex_logs(service_name="auth", level="ERROR", last="1h")

        User: "Find login attempts for user john@example.com"
        → onex_logs(service_name="auth", path="/auth/login", grep="john@example.com")

        User: "Debug this trace: abc-123-def"
        → onex_logs(service_name="auth", trace_id="abc-123-def", lines=500)

        User: "What errors happened after the 2pm deployment?"
        → onex_logs(service_name="product", level="ERROR", last="2h")

        User: "Show me all product service warnings and errors"
        → onex_logs(service_name="product", level="ERROR,WARNING", lines=200)

        User: "Track user123's activity in the last 6 hours"
        → onex_logs(service_name="auth", user_id="user123", last="6h")
    """
    if env is None:
        env = get_active_environment()

    cmd = ['logs', service_name, '--env', env, '--lines', str(lines)]
    if follow:
        cmd.append('--follow')

    # Add filter options if provided
    if level:
        cmd.extend(['--level', level])
    if trace_id:
        cmd.extend(['--trace-id', trace_id])
    if user_id:
        cmd.extend(['--user-id', user_id])
    if company_id:
        cmd.extend(['--company-id', company_id])
    if path:
        cmd.extend(['--path', path])
    if method:
        cmd.extend(['--method', method])
    if event:
        cmd.extend(['--event', event])
    if grep:
        cmd.extend(['--grep', grep])
    if last:
        cmd.extend(['--last', last])

    stdout, stderr, code = await run_onex_command(*cmd, timeout=60 if follow else 30)

    if code != 0:
        return f"Error fetching logs:\n{stderr}\n{stdout}"

    return stdout


@mcp.tool()
async def onex_status(
    service_name: Optional[str] = None,
    env: str = None
) -> str:
    """Check service deployment status and health.

    Shows:
    - Service version and deployment time
    - Running/stopped status
    - HTTP routes registered
    - Request metrics (count, errors, latency)
    - Resource usage

    If no service_name provided, lists ALL deployed services.

    Args:
        service_name: Optional service name. If None, lists all services
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Service status details or list of all services

    Examples:
        User: "What services are deployed?"
        → onex_status()

        User: "Is email-service running?"
        → onex_status(service_name="email-service")

        User: "Check product service health in dev"
        → onex_status(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    cmd = ['status', '--env', env]
    if service_name:
        cmd.append(service_name)

    stdout, stderr, code = await run_onex_command(*cmd)

    if code != 0:
        return f"Error checking status:\n{stderr}\n{stdout}"

    return stdout


# =============================================================================
# INVOCATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_invoke(
    function_name: str,
    payload: str,
    env: str = None,
    is_async: bool = False,
    timeout: int = 60
) -> str:
    """Invoke a service handler directly with test data.

    Executes a Lambda-like function handler with provided payload.
    Useful for:
    - Testing handlers without HTTP requests
    - Debugging function logic
    - Running background tasks
    - Integration testing

    Args:
        function_name: Handler name in format 'service:handler' (e.g., 'order:processOrder')
        payload: JSON payload as string (e.g., '{"orderId": "123"}')
        env: Environment (local/dev/staging/prod). Default: active environment
        is_async: Run asynchronously (fire-and-forget). Default: False
        timeout: Timeout in seconds for sync invokes. Default: 60

    Returns:
        Handler execution result with timing or async job ID

    Examples:
        User: "Test the processOrder handler with order 123"
        → onex_invoke(
            function_name="order:processOrder",
            payload='{"orderId": "123"}'
          )

        User: "Send async email"
        → onex_invoke(
            function_name="email:sendEmail",
            payload='{"to": "user@example.com", "subject": "Test"}',
            is_async=True
          )
    """
    if env is None:
        env = get_active_environment()

    cmd = ['invoke', function_name, '--payload', payload, '--env', env, '--timeout', str(timeout)]
    if is_async:
        cmd.append('--async')

    stdout, stderr, code = await run_onex_command(*cmd, timeout=timeout + 10)

    if code != 0:
        return f"Error invoking handler:\n{stderr}\n{stdout}"

    return stdout


# =============================================================================
# VALIDATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_validate(service_dir: str = ".") -> str:
    """Validate service.yml schema without deploying.

    Checks service configuration for:
    - Required fields (name, runtime, handler)
    - Valid route definitions
    - Resource configurations
    - Trigger configurations
    - Schema compliance

    Run this BEFORE deploying to catch configuration errors early.

    Args:
        service_dir: Path to service directory. Default: current directory

    Returns:
        Validation result with specific errors or success message

    Examples:
        User: "Validate my service.yml"
        → onex_validate()

        User: "Check if product service config is valid"
        → onex_validate(service_dir="../services/product")
    """
    cmd = ['validate', '--service-dir', service_dir]

    stdout, stderr, code = await run_onex_command(*cmd)

    if code != 0:
        return f"Validation failed:\n{stderr}\n{stdout}"

    return stdout


# =============================================================================
# SERVICE SCAFFOLDING TOOLS
# =============================================================================

@mcp.tool()
async def onex_create(
    name: str,
    template: str,
    description: Optional[str] = None,
    author: Optional[str] = "platform-team",
    output: Optional[str] = None,
    no_validate: bool = False
) -> str:
    """Create new service from template.

    Scaffolds a new service with production-ready structure.
    Reduces time-to-first-service from 2 hours to under 5 minutes.

    Available templates:
    - minimal: Single endpoint, quickest deployment
    - rest-api: Full CRUD operations with database
    - event-driven: Schedules + NATS event handlers
    - crud-service: Layered architecture (models, repos, services)

    Args:
        name: Service name in kebab-case (e.g., 'my-product-service')
        template: Template type (minimal/rest-api/event-driven/crud-service)
        description: Service description (optional)
        author: Author/team name (default: 'platform-team')
        output: Output directory (default: ./services/<name>)
        no_validate: Skip validation after creation

    Returns:
        Success message with created files and next steps

    Examples:
        User: "Create a REST API service called product-catalog"
        → onex_create(name="product-catalog", template="rest-api")

        User: "Scaffold a minimal service for health checks"
        → onex_create(name="health-check", template="minimal",
                      description="Health check endpoint")

        User: "Generate an event-driven service for notifications"
        → onex_create(name="notification-service", template="event-driven",
                      description="Email and SMS notifications", author="backend-team")
    """
    cmd = ['create', '--name', name, '--template', template]

    if description:
        cmd.extend(['--description', description])

    if author:
        cmd.extend(['--author', author])

    if output:
        cmd.extend(['--output', output])

    if no_validate:
        cmd.append('--no-validate')

    stdout, stderr, code = await run_onex_command(*cmd, timeout=60)

    if code != 0:
        return f"Error creating service:\n{stderr}\n{stdout}"

    return stdout


# =============================================================================
# SERVER MAIN
# =============================================================================

def main():
    """Main entry point for onex-mcp command."""
    import sys

    # FastMCP will handle stdio transport automatically
    # No print statements allowed - will corrupt JSON-RPC messages
    try:
        mcp.run(transport="stdio")
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
