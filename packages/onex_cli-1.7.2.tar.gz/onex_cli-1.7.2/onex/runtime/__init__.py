"""
Runtime module for local service development and debugging
"""

from .local_runtime import app

__all__ = ['app']
