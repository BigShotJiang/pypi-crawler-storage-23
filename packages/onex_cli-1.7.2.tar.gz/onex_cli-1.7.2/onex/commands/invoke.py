"""
Invoke command - Call invoke handlers directly from CLI
"""

import click
import json
import os
import requests
import time
import uuid
from pathlib import Path
from onex.config import get_config, get_access_token
from onex.utils import (
    print_success, print_error, print_info, print_warning,
    print_header, print_section_header, print_footer,
    print_metrics_table, format_current_time, format_duration
)


@click.command()
@click.argument('function_name', required=False)
@click.option('--payload', help='JSON payload string')
@click.option('--payload-file', type=click.Path(exists=True), help='Path to JSON payload file')
@click.option('--async', 'is_async', is_flag=True, help='Invoke asynchronously (fire-and-forget)')
@click.option('--list', 'list_handlers', is_flag=True, help='List all registered invoke handlers')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--timeout', default=60, help='Timeout in seconds for sync invokes (default: 60)')
@click.option('--pretty', is_flag=True, help='Pretty print JSON output')
def invoke(function_name, payload, payload_file, is_async, list_handlers, env, platform_url, timeout, pretty):
    """
    Invoke handlers directly from CLI

    Examples:
      onex invoke --list
      onex invoke order:importOrderHandle --payload '{"file": "orders.csv"}'
      onex invoke demo:processFile --payload-file batch.json --async
    """
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    # Get access token for authentication
    access_token = get_access_token(env)
    if not access_token:
        print_error("Authentication required")
        print_info(f"Please login: onex login --env {env}")
        return

    # List handlers
    if list_handlers:
        _list_invoke_handlers(platform_base_url, access_token, pretty)
        return

    # Validate function_name is provided
    if not function_name:
        print_error("Function name required (or use --list to see all handlers)")
        print_info("Usage: onex invoke <service>:<handler_name> --payload '{...}'")
        return

    # Parse payload
    payload_data = _parse_payload(payload, payload_file)
    if payload_data is None:
        return

    # Invoke handler
    if is_async:
        _invoke_async(platform_base_url, function_name, payload_data, access_token, pretty)
    else:
        _invoke_sync(platform_base_url, function_name, payload_data, access_token, timeout, pretty)


def _list_invoke_handlers(platform_url: str, access_token: str, pretty: bool):
    """List all registered invoke handlers"""
    click.echo("📋 Fetching registered invoke handlers...")
    click.echo()

    headers = {'Authorization': f'Bearer {access_token}'}

    # Try runtime endpoint first (has full metadata)
    try:
        runtime_url = platform_url.replace(':8000', ':8001')
        response = requests.get(f"{runtime_url}/_internal/invokes", headers=headers, timeout=10)

        if response.status_code == 200:
            data = response.json()
            invokes = data.get('invokes', [])
            total = data.get('total', 0)
            sources = data.get('sources', {})

            if not invokes:
                print_info("No invoke handlers registered")
                print_info("Deploy a service with invokes defined in service.yml")
                return

            click.echo(f"Found {total} invoke handler(s):")
            click.echo(f"Sources: Registry={sources.get('registry', 0)}, Redis={sources.get('redis', 0)}")
            click.echo()

            # Group by service
            by_service = {}
            for inv in invokes:
                service = inv.get('service', 'unknown')
                if service not in by_service:
                    by_service[service] = []
                by_service[service].append(inv)

            # Display grouped by service
            for service, handlers in sorted(by_service.items()):
                click.echo(click.style(f"📦 {service}", fg='cyan', bold=True))

                for handler in handlers:
                    func_name = handler.get('simple_name')
                    qualified = handler.get('function_name')
                    docs = handler.get('docs', {})
                    summary = docs.get('summary', 'No description')
                    handler_type = docs.get('type', 'sync')

                    # Show handler with type indicator
                    type_icon = "⚡" if handler_type == 'async' else "🔄"
                    click.echo(f"  {type_icon} {click.style(func_name, fg='green')}")
                    click.echo(f"     {summary}")
                    click.echo(f"     Invoke: {click.style(qualified, fg='yellow')}")

                    # Show example if available
                    if docs.get('payload_example'):
                        example_json = json.dumps(docs['payload_example'], indent=2)
                        click.echo(f"     Example payload: {example_json}")

                    click.echo()

            print_info(f"Platform: {platform_url}")

        else:
            print_error(f"Failed to fetch handlers: HTTP {response.status_code}")

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_url}")
        print_info("Make sure platform is running")

    except Exception as e:
        print_error(f"Error fetching handlers: {e}")


def _parse_payload(payload_str: str, payload_file: str):
    """Parse payload from string or file"""
    if not payload_str and not payload_file:
        print_error("Either --payload or --payload-file is required")
        print_info("Use --payload '{}' for empty payload")
        return None

    try:
        if payload_file:
            with open(payload_file, 'r') as f:
                return json.load(f)
        else:
            return json.loads(payload_str)

    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        return None

    except Exception as e:
        print_error(f"Error reading payload: {e}")
        return None


def _invoke_sync(platform_url: str, function_name: str, payload: dict, access_token: str, timeout: int, pretty: bool):
    """Invoke handler synchronously"""
    # Generate trace_id for this invocation
    trace_id = str(uuid.uuid4())

    # Determine environment from URL
    env = "local" if "localhost" in platform_url else "dev"

    # Print header
    print_header(f"INVOKE: {function_name} (synchronous)", icon="🚀")

    # Show context
    metrics = {
        "Environment": env,
        "Platform": platform_url,
        "Started at": format_current_time(),
        "Trace ID": click.style(trace_id, fg='yellow')
    }
    print_metrics_table(metrics)

    endpoint = f"{platform_url}/api/invoke/sync"

    try:
        start_time = time.time()

        response = requests.post(
            endpoint,
            json={
                'function_name': function_name,
                'payload': payload
            },
            headers={
                'Authorization': f'Bearer {access_token}',  # JWT authentication
                'X-Trace-ID': trace_id,  # Send trace_id for request tracking
            },
            timeout=timeout
        )

        elapsed_ms = (time.time() - start_time) * 1000

        if response.status_code == 200:
            data = response.json()
            result = data.get('result')
            exec_time = data.get('execution_time_ms', elapsed_ms)
            returned_trace_id = data.get('trace_id', trace_id)

            # Calculate network time
            network_time = elapsed_ms - exec_time if exec_time else elapsed_ms

            # Show execution metrics
            print_section_header("⏱️  EXECUTION METRICS")
            exec_metrics = {
                "Total Time": format_duration(elapsed_ms),
                "Handler Time": format_duration(exec_time),
                "Network Time": format_duration(network_time),
                "Status": click.style("200 OK", fg='green')
            }
            print_metrics_table(exec_metrics)

            # Show result
            print_section_header("📊 RESULT")
            if pretty:
                click.echo(json.dumps(result, indent=2))
            else:
                click.echo(json.dumps(result))

            # Show footer with next steps
            click.echo()
            click.echo(f"💡 Query trace: onex trace {returned_trace_id} --env {env}")
            print_footer()

        elif response.status_code == 404:
            click.echo()
            print_error(f"Handler '{function_name}' not found")
            print_info("Use 'onex invoke --list' to see all registered handlers")
            print_footer()

        elif response.status_code == 500:
            error_data = response.json()
            click.echo()
            print_error("Handler execution failed")
            print_section_header("❌ ERROR DETAILS")
            if pretty:
                click.echo(json.dumps(error_data, indent=2))
            else:
                click.echo(json.dumps(error_data))
            print_footer()

        else:
            click.echo()
            print_error(f"Invoke failed: HTTP {response.status_code}")
            click.echo(response.text)
            print_footer()

    except requests.exceptions.Timeout:
        click.echo()
        print_error(f"Invoke timed out after {timeout} seconds")
        print_info("Use --timeout to increase timeout (or use --async for long-running tasks)")
        print_footer()

    except requests.exceptions.ConnectionError:
        click.echo()
        print_error(f"Cannot connect to platform at {platform_url}")
        print_info("Make sure platform is running")
        print_footer()

    except Exception as e:
        click.echo()
        print_error(f"Error invoking handler: {e}")
        print_footer()


def _invoke_async(platform_url: str, function_name: str, payload: dict, access_token: str, pretty: bool):
    """Invoke handler asynchronously"""
    # Generate trace_id for this invocation
    trace_id = str(uuid.uuid4())

    # Determine environment from URL
    env = "local" if "localhost" in platform_url else "dev"

    # Print header
    print_header(f"INVOKE: {function_name} (asynchronous)", icon="⚡")

    # Show context
    metrics = {
        "Environment": env,
        "Platform": platform_url,
        "Started at": format_current_time(),
        "Trace ID": click.style(trace_id, fg='yellow')
    }
    print_metrics_table(metrics)

    endpoint = f"{platform_url}/api/invoke/async"

    try:
        start_time = time.time()

        response = requests.post(
            endpoint,
            json={
                'function_name': function_name,
                'payload': payload
            },
            headers={
                'Authorization': f'Bearer {access_token}',  # JWT authentication
                'X-Trace-ID': trace_id,  # Send trace_id for request tracking
            },
            timeout=10  # Quick timeout for async (just publishes to NATS)
        )

        elapsed_ms = (time.time() - start_time) * 1000

        if response.status_code == 202:
            data = response.json()
            subject = data.get('subject', 'N/A')
            msg_id = data.get('msg_id', 'N/A')

            # Show async execution details
            print_section_header("📮 ASYNC EXECUTION")
            async_metrics = {
                "NATS Subject": subject,
                "Message ID": msg_id,
                "Published in": format_duration(elapsed_ms),
                "Status": click.style("202 Accepted", fg='green')
            }
            print_metrics_table(async_metrics)

            # Show next steps
            click.echo()
            print_warning("Handler executes in background")
            click.echo(f"    Check execution: onex trace {trace_id} --env {env} --follow")
            click.echo()
            click.echo(f"💡 Monitor logs: docker logs minimal-async-worker -f")
            print_footer()

        elif response.status_code == 404:
            click.echo()
            print_error(f"Handler '{function_name}' not found")
            print_info("Use 'onex invoke --list' to see all registered handlers")
            print_footer()

        else:
            click.echo()
            print_error(f"Async invoke failed: HTTP {response.status_code}")
            click.echo(response.text)
            print_footer()

    except requests.exceptions.ConnectionError:
        click.echo()
        print_error(f"Cannot connect to platform at {platform_url}")
        print_info("Make sure platform is running")
        print_footer()

    except Exception as e:
        click.echo()
        print_error(f"Error invoking handler: {e}")
        print_footer()
