"""
Trace command - Track requests through the platform using trace_id
"""

import click
import requests
import json
import time
from datetime import datetime
from onex.config import get_config, get_access_token
from onex.utils import (
    print_success, print_error, print_info, print_warning,
    print_header, print_section_header, print_footer,
    print_metrics_table, print_progress_bar, print_tree_item,
    format_timestamp, format_current_time, format_duration
)


@click.command()
@click.argument('trace_id')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output raw JSON')
@click.option('--follow', '-f', is_flag=True, help='Follow trace in real-time (poll for new logs)')
def trace(trace_id, env, platform_url, output_json, follow):
    """
    Track a request through the platform using trace_id

    Shows the complete timeline of a request as it flows through:
    Gateway → Runtime → Service → External calls

    Examples:
      onex trace abc123-def456-789
      onex trace abc123-def456-789 --json
      onex trace abc123-def456-789 --follow
    """
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    # Use JWT token instead of API key
    access_token = get_access_token(env)

    if not access_token:
        print_error("Authentication required")
        print_info(f"Please login: onex login --env {env}")
        return

    if follow:
        _follow_trace(platform_base_url, trace_id, access_token, output_json)
    else:
        _query_trace_once(platform_base_url, trace_id, access_token, output_json)


def _query_trace_once(platform_url: str, trace_id: str, access_token: str, output_json: bool):
    """Query trace once and display results"""
    # Determine environment from URL
    env = "local" if "localhost" in platform_url else "dev"

    # Print header
    print_header(f"TRACE: {trace_id}", icon="🔍")

    # Show context
    metrics = {
        "Environment": env,
        "Platform": platform_url,
        "Queried at": format_current_time()
    }
    print_metrics_table(metrics)

    try:
        response = requests.get(
            f"{platform_url}/_internal/trace/{trace_id}",
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=30
        )

        if response.status_code == 200:
            data = response.json()

            if output_json:
                # Raw JSON output
                click.echo(json.dumps(data, indent=2))
                return

            # Human-readable output
            timeline = data.get('timeline', [])
            total_logs = data.get('total_logs', 0)

            if total_logs == 0:
                click.echo()
                print_info(f"No logs found for trace_id: {trace_id}")
                print_info("This could mean:")
                print_info("  - Request hasn't been processed yet")
                print_info("  - Trace_id is incorrect")
                print_info("  - Logs have expired (older than 24 hours)")
                print_footer()
                return

            # Extract summary information
            summary = _extract_summary(timeline)

            # Show summary
            print_section_header("📊 SUMMARY")
            summary_metrics = {
                "Total Logs": f"{total_logs} entries",
                "Components": summary['components'],
                "Time Span": format_duration(summary['duration']),
                "Request": summary['request'],
                "Status": summary['status']
            }
            print_metrics_table(summary_metrics)

            # Display timeline
            _display_timeline(timeline)

            # Display performance breakdown
            _display_performance(timeline)

            print_footer()

        elif response.status_code == 401:
            click.echo()

            # Try to parse error detail from Gateway
            error_detail = "Invalid or expired token"
            try:
                error_data = response.json()
                error_detail = error_data.get('detail', error_detail)
            except:
                pass

            print_error(f"Authentication failed: {error_detail}")
            print_info(f"Please run: onex login --env {env}")

            # Show token info for debugging
            from onex.utils.auth import get_token_info
            token_info = get_token_info(env)
            if token_info:
                if token_info['is_expired']:
                    print_warning(f"   Your token expired {token_info['time_remaining']} ago")
                else:
                    print_info(f"   Token expires in: {token_info['time_remaining']}")
                print_info(f"   Token expires at: {token_info['expires_at']}")

            print_footer()

        elif response.status_code == 503:
            click.echo()
            print_error("Loki service unavailable")
            print_info("Make sure observability stack is running")
            print_footer()

        else:
            click.echo()
            print_error(f"Failed to query trace: HTTP {response.status_code}")
            try:
                error_detail = response.json()
                click.echo(f"   Error: {error_detail.get('detail', 'Unknown error')}")
            except:
                click.echo(f"   Response: {response.text}")
            print_footer()

    except requests.exceptions.ConnectionError:
        click.echo()
        print_error(f"Cannot connect to platform at {platform_url}")
        print_info("Make sure platform is running")
        print_footer()

    except Exception as e:
        click.echo()
        print_error(f"Error querying trace: {e}")
        print_footer()


def _follow_trace(platform_url: str, trace_id: str, access_token: str, output_json: bool):
    """Follow trace in real-time by polling"""
    click.echo(f"🔍 Following trace: {click.style(trace_id, fg='cyan')}")
    click.echo(f"   Polling for new logs every 2 seconds...")
    click.echo(f"   Press CTRL+C to stop")
    click.echo()

    seen_timestamps = set()

    try:
        while True:
            response = requests.get(
                f"{platform_url}/_internal/trace/{trace_id}",
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=30
            )

            if response.status_code == 200:
                data = response.json()
                timeline = data.get('timeline', [])

                # Filter out logs we've already seen
                new_logs = [
                    log for log in timeline
                    if log['timestamp'] not in seen_timestamps
                ]

                if new_logs:
                    for log in new_logs:
                        _display_log_entry(log, output_json)
                        seen_timestamps.add(log['timestamp'])

            time.sleep(2)

    except KeyboardInterrupt:
        click.echo()
        print_info("Stopped following trace")


def _extract_summary(timeline: list) -> dict:
    """Extract summary information from timeline"""
    if not timeline:
        return {
            'components': '0',
            'duration': 0,
            'request': 'Unknown',
            'status': 'Unknown'
        }

    # Get unique components
    components = set(log.get('component', 'unknown') for log in timeline)

    # Calculate duration
    start_time = timeline[0]['timestamp']
    end_time = timeline[-1]['timestamp']
    duration = end_time - start_time

    # Extract request info from first log
    first_log = timeline[0]
    message = first_log.get('message', '')

    # Try to parse request method and path
    request = message
    if 'POST' in message or 'GET' in message or 'PUT' in message or 'DELETE' in message:
        parts = message.split()
        if len(parts) >= 2:
            request = f"{parts[0]} {parts[1]}"

    # Determine status from logs
    status = "Unknown"
    for log in timeline:
        msg = log.get('message', '')
        if '200' in msg:
            status = click.style("✓ 200 OK", fg='green')
            break
        elif '201' in msg or '202' in msg:
            status = click.style(f"✓ {msg.split()[2]}", fg='green')
            break
        elif '4' in msg or '5' in msg:
            status = click.style(f"✗ Error", fg='red')
            break

    return {
        'components': f"{len(components)} ({', '.join(sorted(components))})",
        'duration': duration,
        'request': request,
        'status': status
    }


def _display_timeline(timeline: list):
    """Display timeline of logs in human-readable format"""
    print_section_header("🔄 REQUEST FLOW")

    # Group logs by component while preserving order
    component_groups = []
    current_component = None
    current_group = None

    for log in timeline:
        component = log.get('component', 'unknown')
        timestamp = log.get('timestamp', 0)
        event = log.get('event', '')

        # Check if we need to start a new group
        if component != current_component:
            if current_group:
                component_groups.append(current_group)

            # Determine phase icon and name
            phase_icons = {
                'demo': '📦',
                'gateway': '🌐',
                'shared-runtime': '🔧',
                'event-bridge': '🎯',
                'trigger-scheduler': '⏰',
                'stream-trigger': '🌊'
            }

            phase_names = {
                'demo': 'TRIGGER',
                'gateway': 'GATEWAY',
                'shared-runtime': 'SHARED-RUNTIME',
                'event-bridge': 'EVENT BRIDGE',
                'trigger-scheduler': 'SCHEDULER',
                'stream-trigger': 'STREAM WATCHER'
            }

            icon = phase_icons.get(component, '📦')
            name = phase_names.get(component, component.upper())

            current_group = {
                'component': component,
                'name': f"{icon} {name}",
                'logs': [log],
                'start': timestamp
            }
            current_component = component
        else:
            current_group['logs'].append(log)
            current_group['end'] = timestamp

    if current_group:
        component_groups.append(current_group)

    # Display each component group
    for group_idx, group in enumerate(component_groups):
        is_last_group = group_idx == len(component_groups) - 1

        # Group header with duration
        duration_str = ""
        if 'end' in group:
            duration_ms = group['end'] - group['start']
            if duration_ms > 0:
                duration_str = f" ({format_duration(duration_ms)})"

        click.echo(f"\n{group['name']}{duration_str}")

        # Display logs in this group
        for log_idx, log in enumerate(group['logs']):
            is_last_log = log_idx == len(group['logs']) - 1
            _display_log_entry_enhanced(log, is_last_log and is_last_group)


def _display_log_entry_enhanced(log: dict, is_last: bool = False):
    """Display enhanced log entry with structured data"""
    timestamp = log.get('timestamp', 0)
    level = log.get('level', 'INFO')
    event = log.get('event', '')
    message = log.get('message', '')
    method = log.get('method', '')
    path = log.get('path', '')
    status_code = log.get('status_code')
    duration_ms = log.get('duration_ms')
    labels = log.get('labels', {})

    # Format timestamp (show only time for cleaner output)
    time_str = format_timestamp(timestamp, show_date=False)

    # Build event description
    event_desc = {
        'request_received': '📥 Received',
        'request_completed': '📤 Completed',
        'http_request': '📥 Received',
        'http_request_received': '📥 Received',
        'http_response': '📤 Responded',
        'http_request_completed': '📤 Responded',
        'invoke_request': '⚡ Invoke Called',
        'invoke_handler_called': '⚡ Invoke Called',
        'invoke_success': '✅ Invoke Completed',
        'invoke_handler_completed': '✅ Invoke Completed',
        'invoke_error': '❌ Invoke Failed',
        'stream_triggered': '🌊 Stream Detected',
        'stream_success': '✅ Stream Completed',
        'stream_error': '❌ Stream Failed',
        'event_triggered': '🎯 Event Matched',
        'event_success': '✅ Event Completed',
        'event_error': '❌ Event Failed',
        'schedule_triggered': '⏰ Schedule Fired',
        'schedule_success': '✅ Schedule Completed',
        'schedule_error': '❌ Schedule Failed',
    }.get(event, event or 'Log')

    # Build main line
    parts = [time_str, event_desc]

    if method and path:
        parts.append(f"{click.style(method, fg='cyan')} {click.style(path, fg='blue')}")
    elif message and message != event:
        # Don't show raw JSON for invoke logs - we show details below
        if event not in ['invoke_handler_called', 'invoke_handler_completed']:
            parts.append(message)

    if status_code:
        if status_code < 400:
            parts.append(click.style(f"→ {status_code}", fg='green'))
        else:
            parts.append(click.style(f"→ {status_code}", fg='red'))

    if duration_ms:
        duration_color = 'green' if duration_ms < 1000 else ('yellow' if duration_ms < 3000 else 'red')
        parts.append(click.style(f"({duration_ms:.1f}ms)", fg=duration_color))

    # Print main line with tree structure
    connector = "└─" if is_last else "├─"
    click.echo(f"  {connector} {' '.join(parts)}")

    # Show additional details from structured log data
    log_data = log.get('data', {})
    details = []

    # Trigger-specific fields from labels
    if labels.get('operation'):
        details.append(f"Operation: {click.style(labels['operation'], fg='yellow')}")
    if labels.get('collection'):
        details.append(f"Collection: {click.style(labels['collection'], fg='cyan')}")
    if labels.get('function'):
        details.append(f"Function: {click.style(labels['function'], fg='green')}")
    if labels.get('trigger_id'):
        details.append(f"Trigger: {labels['trigger_id']}")

    # Extract interesting fields from structured data
    if log_data.get('function_name'):
        details.append(f"Function: {click.style(log_data['function_name'], fg='green')}")
    if log_data.get('service') and log_data['service'] not in ['demo', 'gateway', 'shared-runtime']:
        details.append(f"Service: {log_data['service']}")
    if log_data.get('handler'):
        details.append(f"Handler: {log_data['handler']}")
    if log_data.get('execution_time_ms'):
        exec_time = log_data['execution_time_ms']
        exec_color = 'green' if exec_time < 1000 else ('yellow' if exec_time < 3000 else 'red')
        details.append(f"Execution: {click.style(f'{exec_time:.1f}ms', fg=exec_color)}")
    if log_data.get('error'):
        details.append(click.style(f"Error: {log_data['error']}", fg='red'))
    if log_data.get('error_type'):
        details.append(click.style(f"Type: {log_data['error_type']}", fg='red'))

    # Show details with tree structure
    for detail in details:
        indent = "     " if is_last else "  │  "
        click.echo(f"{indent}{detail}")


def _display_log_entry(log: dict, output_json: bool):
    """Display a single log entry"""
    if output_json:
        click.echo(json.dumps(log))
        return

    timestamp = log.get('timestamp', 0)
    level = log.get('level', 'INFO')
    message = log.get('message', '')
    data = log.get('data', {})

    # Format timestamp
    time_str = format_timestamp(timestamp, show_date=False)

    # Color code by level
    level_colors = {
        'INFO': 'white',
        'WARNING': 'yellow',
        'ERROR': 'red',
        'DEBUG': 'cyan'
    }
    level_color = level_colors.get(level, 'white')

    # Format output
    level_formatted = f"{level:7}"
    click.echo(f"  {time_str} {click.style(level_formatted, fg=level_color)} {message}")

    # Extract metadata from message
    metadata = []

    # Check if message contains HTTP method and path
    msg_parts = message.split()
    if len(msg_parts) >= 2 and msg_parts[0] in ['POST', 'GET', 'PUT', 'DELETE', 'PATCH']:
        if len(msg_parts) >= 2:
            metadata.append(("Method", msg_parts[0]))
            if '/' in msg_parts[1]:
                metadata.append(("Path", msg_parts[1]))
        if len(msg_parts) >= 3 and msg_parts[2].isdigit():
            status = int(msg_parts[2])
            status_color = 'green' if status < 400 else 'red'
            metadata.append(("Status", click.style(f"{status} OK" if status < 400 else str(status), fg=status_color)))
        if len(msg_parts) >= 4 and 'ms' in msg_parts[3]:
            metadata.append(("Duration", msg_parts[3]))

    # Show metadata if present
    for i, (key, value) in enumerate(metadata):
        is_last = i == len(metadata) - 1
        print_tree_item(f"{key}: {value}", is_last=is_last)

    # Show additional data if present
    additional_data = []
    if data.get('duration_ms'):
        additional_data.append(("Duration", f"{data['duration_ms']}ms"))
    if data.get('status_code'):
        status = data['status_code']
        status_color = 'green' if status < 400 else 'red'
        additional_data.append(("Status", click.style(str(status), fg=status_color)))
    if data.get('error'):
        additional_data.append(("Error", click.style(data['error'], fg='red')))

    for i, (key, value) in enumerate(additional_data):
        is_last = i == len(additional_data) - 1
        print_tree_item(f"{key}: {value}", is_last=is_last)


def _display_performance(timeline: list):
    """Display performance breakdown showing sequential waterfall timeline"""
    if not timeline:
        return

    # Get absolute start time (T0)
    t0 = timeline[0]['timestamp']

    # Track component transitions (when each component first appears)
    component_flows = []
    seen_components = set()

    for log in timeline:
        component = log.get('component', 'unknown')
        timestamp = log.get('timestamp', 0)

        if component not in seen_components:
            # New component appeared - record the transition
            component_flows.append({
                'component': component,
                'start': timestamp,
                'end': timestamp,
                'logs': [log]
            })
            seen_components.add(component)
        else:
            # Update end time for current component
            for flow in reversed(component_flows):
                if flow['component'] == component:
                    flow['end'] = timestamp
                    flow['logs'].append(log)
                    break

    if not component_flows:
        return

    # Calculate total request duration
    total_duration = timeline[-1]['timestamp'] - t0

    if total_duration == 0:
        return

    # Display sequential flow
    print_section_header("⏱️  SEQUENTIAL FLOW (Waterfall)")

    # Show timeline ruler
    _display_timeline_ruler(total_duration)
    click.echo()

    # Display each component in chronological order
    for idx, flow in enumerate(component_flows):
        component = flow['component']
        start_offset = flow['start'] - t0  # When this component started (relative to T0)
        duration = flow['end'] - flow['start']  # How long this component was active
        log_count = len(flow['logs'])

        # Determine if this is a nested component
        # (started after Gateway, ended before total duration)
        is_nested = idx > 0 and start_offset > 0
        indent = "  " if is_nested else ""
        prefix = "  └─► " if is_nested else ""

        # Format component name
        component_name = {
            'gateway': 'Gateway',
            'shared-runtime': 'Shared Runtime',
            'event-bridge': 'Event Bridge',
            'trigger-scheduler': 'Trigger Scheduler',
            'stream-trigger': 'Stream Trigger'
        }.get(component, component.capitalize())

        # Build the label
        if is_nested:
            label = f"{prefix}{component_name}"
            timing = f"{format_duration(duration)} (starts at +{format_duration(start_offset)})"
        else:
            label = f"{component_name}"
            timing = f"{format_duration(duration)} total"

        # Show component line
        click.echo(f"{indent}{click.style(label, fg='cyan', bold=True)}: {timing}")

        # Show waterfall bar
        _display_waterfall_bar(start_offset, duration, total_duration, indent, is_nested)

        # Add spacing between components
        if idx < len(component_flows) - 1:
            click.echo()

    click.echo()


def _display_timeline_ruler(total_duration: float):
    """Display timeline ruler showing 0ms → duration"""
    bar_width = 50

    # Format start and end times
    start_label = "0ms"
    mid_label = format_duration(total_duration / 2)
    end_label = format_duration(total_duration)

    # Calculate positions for labels
    mid_pos = bar_width // 2
    end_pos = bar_width

    # Build ruler line
    ruler = "├" + "─" * (bar_width - 2) + "┤"

    # Build tick marks
    ticks = "┼" + " " * (mid_pos - 1) + "┼" + " " * (bar_width - mid_pos - 2) + "┼"

    # Build labels line
    # Pad labels to align with tick marks
    labels_line = f"{start_label:<{mid_pos}}{mid_label:^{bar_width - mid_pos - len(end_label)}}{end_label:>{len(end_label)}}"

    # Display ruler
    click.echo(click.style(labels_line, fg='white', dim=True))
    click.echo(click.style(ruler, fg='white', dim=True))


def _display_waterfall_bar(start_offset: float, duration: float, total_duration: float, indent: str, is_nested: bool):
    """Display waterfall bar showing when component was active"""
    bar_width = 50

    # Calculate bar segments
    start_ratio = start_offset / total_duration
    duration_ratio = duration / total_duration

    # Calculate character positions
    start_pos = int(start_ratio * bar_width)
    bar_length = max(1, int(duration_ratio * bar_width))

    # Build the bar
    empty_before = " " * start_pos
    filled = "█" * bar_length
    empty_after = " " * max(0, bar_width - start_pos - bar_length)

    # Choose color based on nesting
    color = 'green' if not is_nested else 'blue'

    # Display bar
    bar = f"{empty_before}{click.style(filled, fg=color)}{empty_after}"
    click.echo(f"{indent}{bar}")

    # Show timing details below the bar
    if start_offset > 0:
        timing_detail = f"  (waiting {format_duration(start_offset)}, then active {format_duration(duration)})"
        click.echo(f"{indent}{click.style(timing_detail, fg='white', dim=True)}")
