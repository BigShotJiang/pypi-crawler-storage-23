"""
OneX MCP Server Configuration Commands

Manages Model Context Protocol (MCP) server setup for Claude Code/Desktop.
Automatically configures Claude to use OneX CLI tools as AI-accessible debugging tools.

Commands:
  onex mcp setup   - Auto-configure MCP server (one-time setup)
  onex mcp remove  - Remove MCP server configuration
  onex mcp status  - Check MCP server configuration status
"""

import sys
import subprocess
import click
from pathlib import Path
from onex.utils import print_success, print_error, print_info, print_warning


@click.group()
def mcp():
    """Configure MCP server for Claude Code/Desktop"""
    pass


@mcp.command()
def setup():
    """
    Auto-configure OneX MCP server for Claude Code.

    This command:
    1. Auto-detects onex-mcp installation path
    2. Configures Claude Code to use OneX tools
    3. Runs only once (uses marker file)

    After setup, Claude can debug your platform with natural language:
      - "Is my platform healthy?"
      - "Debug this API failure, trace_id: abc123"
      - "Show me email-service logs"
    """
    from onex.config import get_onex_dir

    # Check if already configured
    config_dir = get_onex_dir()
    marker_file = config_dir / '.mcp_setup_done'

    if marker_file.exists():
        print_info("✅ MCP server already configured")
        print_info("   Run 'onex mcp status' to verify")
        print_info("   Run 'onex mcp remove' to reconfigure")
        return

    click.echo()
    print_info("🔧 Setting up OneX MCP Server for Claude Code...")
    click.echo()

    # Step 1: Check MCP package is installed
    try:
        import mcp
        print_success("✓ MCP package found")
    except ImportError:
        print_error("✗ MCP package not installed")
        print_info("  Install with: pip install -e '../onexeos-platform/onex-cli[mcp]'")
        sys.exit(1)

    # Step 2: Auto-detect onex-mcp path
    # When installed via pip install -e, the shebang uses venv's Python
    # So we can find onex-mcp in the same bin directory as current Python
    python_exe = Path(sys.executable)
    bin_dir = python_exe.parent

    # Windows uses .exe extension, Unix doesn't
    if sys.platform == 'win32':
        onex_mcp_path = bin_dir / 'onex-mcp.exe'
    else:
        onex_mcp_path = bin_dir / 'onex-mcp'

    if not onex_mcp_path.exists():
        print_error(f"✗ onex-mcp not found at: {onex_mcp_path}")
        print_info("  Make sure you installed with: pip install onex-cli")
        sys.exit(1)

    print_success(f"✓ Found onex-mcp at: {onex_mcp_path}")

    # Step 3: Check if claude CLI is available
    try:
        result = subprocess.run(
            ['claude', 'mcp', 'list'],
            capture_output=True,
            text=True,
            timeout=10
        )
        print_success("✓ Claude Code CLI found")
    except FileNotFoundError:
        print_error("✗ Claude Code CLI not found")
        print_info("  Make sure Claude Code is installed and 'claude' command is in PATH")
        print_info("  See: https://docs.claude.com/en/docs/claude-code")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        print_warning("⚠ Claude Code CLI responding slowly")

    # Step 4: Add MCP server to Claude Code
    try:
        print_info(f"  Adding onex-platform MCP server...")

        cmd = [
            'claude', 'mcp', 'add',
            '--transport', 'stdio',
            '--scope', 'user',
            'onex-platform',
            '--',
            str(onex_mcp_path)
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode == 0:
            print_success("✓ MCP server configured successfully")
        else:
            # Check if already exists
            if 'already exists' in result.stderr.lower() or 'already exists' in result.stdout.lower():
                print_warning("⚠ MCP server 'onex-platform' already exists")
                print_info("  Run 'onex mcp remove' first to reconfigure")
            else:
                print_error(f"✗ Failed to add MCP server")
                print_info(f"  Error: {result.stderr or result.stdout}")
                sys.exit(1)

    except subprocess.TimeoutExpired:
        print_error("✗ Claude Code CLI timed out")
        sys.exit(1)
    except Exception as e:
        print_error(f"✗ Failed to configure MCP server: {e}")
        sys.exit(1)

    # Step 5: Mark as done
    config_dir.mkdir(parents=True, exist_ok=True)
    marker_file.touch()

    # Step 6: Show success message
    click.echo()
    print_success("🎉 OneX MCP Server configured successfully!")
    click.echo()
    print_info("Next steps:")
    print_info("  1. Restart Claude Code completely")
    print_info("  2. Open Claude Code and type: /mcp")
    print_info("  3. You should see 'onex-platform' with 7 tools")
    click.echo()
    print_info("Example usage in Claude Code:")
    print_info('  "Is my platform healthy?"')
    print_info('  "Debug trace_id: 550e8400-e29b-41d4-a716-446655440000"')
    print_info('  "Show me email-service logs"')
    click.echo()
    print_info("Run 'onex mcp status' to verify configuration")
    click.echo()


@mcp.command()
def remove():
    """
    Remove OneX MCP server from Claude Code.

    Useful for:
    - Reconfiguring with different settings
    - Uninstalling MCP server
    - Troubleshooting issues
    """
    from onex.config import get_onex_dir

    click.echo()
    print_info("🗑️  Removing OneX MCP Server...")
    click.echo()

    # Remove from Claude Code
    try:
        result = subprocess.run(
            ['claude', 'mcp', 'remove', 'onex-platform'],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode == 0:
            print_success("✓ MCP server removed from Claude Code")
        else:
            if 'not found' in result.stderr.lower() or 'not found' in result.stdout.lower():
                print_warning("⚠ MCP server 'onex-platform' not found (already removed)")
            else:
                print_error(f"✗ Failed to remove MCP server")
                print_info(f"  Error: {result.stderr or result.stdout}")
                sys.exit(1)

    except FileNotFoundError:
        print_error("✗ Claude Code CLI not found")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        print_error("✗ Claude Code CLI timed out")
        sys.exit(1)
    except Exception as e:
        print_error(f"✗ Failed to remove MCP server: {e}")
        sys.exit(1)

    # Remove marker file
    config_dir = get_onex_dir()
    marker_file = config_dir / '.mcp_setup_done'
    if marker_file.exists():
        marker_file.unlink()
        print_success("✓ Cleared setup marker")

    click.echo()
    print_success("✅ OneX MCP Server removed")
    print_info("   Run 'onex mcp setup' to reconfigure")
    click.echo()


@mcp.command()
def status():
    """
    Check OneX MCP server configuration status.

    Shows:
    - Whether MCP server is configured
    - Installation path
    - Claude Code connection status
    - Available tools
    """
    click.echo()
    print_info("📊 OneX MCP Server Status")
    click.echo()

    # Check if onex-mcp is installed
    python_exe = Path(sys.executable)
    bin_dir = python_exe.parent

    # Windows uses .exe extension, Unix doesn't
    if sys.platform == 'win32':
        onex_mcp_path = bin_dir / 'onex-mcp.exe'
    else:
        onex_mcp_path = bin_dir / 'onex-mcp'

    if onex_mcp_path.exists():
        print_success(f"✓ onex-mcp installed: {onex_mcp_path}")
    else:
        print_error(f"✗ onex-mcp not found")
        print_info("  Install with: pip install -e '../onexeos-platform/onex-cli[mcp]'")
        click.echo()
        return

    # Check MCP package
    try:
        import mcp
        # MCP package doesn't expose __version__, just check it's installed
        print_success("✓ MCP package installed")
    except ImportError:
        print_error("✗ MCP package not installed")
        print_info("  Install with: pip install onex-cli")
        click.echo()
        return

    # Check Claude Code configuration
    try:
        result = subprocess.run(
            ['claude', 'mcp', 'get', 'onex-platform'],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode == 0:
            print_success("✓ MCP server configured in Claude Code")
            click.echo()
            print_info("Configuration details:")
            # Show the output from claude mcp get
            for line in result.stdout.strip().split('\n'):
                print_info(f"  {line}")
        else:
            print_warning("⚠ MCP server not configured in Claude Code")
            print_info("  Run 'onex mcp setup' to configure")

    except FileNotFoundError:
        print_warning("⚠ Claude Code CLI not found")
        print_info("  Install Claude Code to use MCP features")
    except subprocess.TimeoutExpired:
        print_warning("⚠ Claude Code CLI responding slowly")
    except Exception as e:
        print_warning(f"⚠ Could not check Claude Code status: {e}")

    click.echo()
    print_info("Available tools (7):")
    print_info("  • onex_platform_check - Platform health")
    print_info("  • onex_trace          - Request tracing")
    print_info("  • onex_logs           - Service logs")
    print_info("  • onex_status         - Deployment status")
    print_info("  • onex_invoke         - Invoke handlers")
    print_info("  • onex_validate       - Validate config")
    print_info("  • onex_create         - Service scaffolding")
    click.echo()
    print_info("Documentation:")
    print_info("  onex-cli/onex/mcp/README.md")
    print_info("  onex-cli/onex/mcp/SERVICE_DEVELOPER_GUIDE.md")
    click.echo()


if __name__ == '__main__':
    mcp()
