"""
VPN management commands
"""

import click
from pathlib import Path
from onex.utils import print_success, print_info, print_error, print_warning


@click.group()
def vpn():
    """Manage WireGuard VPN connections"""
    pass


@vpn.command('setup')
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--no-connect', is_flag=True, help='Import config but do not connect')
def setup(config_file, no_connect):
    """Setup VPN from config file"""
    from onex.vpn import setup_vpn
    from onex.vpn.wireguard_manager import WireGuardError

    click.echo("🔧 Setting up VPN...")
    click.echo()

    try:
        result = setup_vpn(config_file, auto_connect=not no_connect)

        print_success(f"VPN configured: {result['interface']}")
        click.echo()

        print_info(f"VPN IP:       {result['vpn_ip']}")
        print_info(f"Gateway:      {result['gateway_ip']}")
        print_info(f"Environment:  {result['environment']}")
        print_info(f"Platform URL: {result['platform_url']}")

        click.echo()

        if result['connected']:
            print_success("✅ VPN connected")

            if result['gateway_reachable']:
                print_success("✅ Platform gateway reachable")
                click.echo()
                print_info("Next steps:")
                print_info(f"  onex login --env {result['environment']}")
                print_info("  onex debug --service <service-name>")
            else:
                print_warning("⚠️  Platform gateway not responding")
                print_info("The gateway might be down or still starting.")
        else:
            print_info("VPN configured but not connected")
            print_info(f"To connect: onex vpn connect {result['environment']}")

    except WireGuardError as e:
        print_error(f"VPN setup failed: {str(e)}")
        return 1

    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


# Removed: onex vpn connect/disconnect commands - replaced by onex switch
# Use: onex switch <env> instead


@vpn.command('status')
def vpn_status():
    """Show VPN connection status"""
    from onex.vpn.setup_vpn import list_configured_vpns, get_vpn_info, get_environment_from_interface

    vpns = list_configured_vpns()

    if not vpns:
        print_warning("No VPN connections configured")
        print_info("Run: onex vpn setup <config-file>")
        return

    click.echo("VPN Connections:")
    click.echo()

    for vpn in vpns:
        env = get_environment_from_interface(vpn) or 'unknown'
        info = get_vpn_info(vpn)

        if info and info['connected']:
            click.echo(f"  ✅ {env.upper():<8} {vpn:<25} CONNECTED")

            if info.get('latest_handshake'):
                print_info(f"     Last handshake: {info['latest_handshake']}")

            if info.get('transfer'):
                rx = info['transfer'].get('rx', 'N/A')
                tx = info['transfer'].get('tx', 'N/A')
                print_info(f"     Transfer: ↓ {rx} / ↑ {tx}")
        else:
            click.echo(f"  ⚪ {env.upper():<8} {vpn:<25} DISCONNECTED")

        click.echo()


@vpn.command('list')
def vpn_list():
    """List all configured VPNs"""
    from onex.vpn.setup_vpn import list_configured_vpns, get_environment_from_interface

    vpns = list_configured_vpns()

    if not vpns:
        print_warning("No VPN connections configured")
        print_info("Run: onex vpn setup <config-file>")
        return

    click.echo("Configured VPNs:")
    click.echo()

    for vpn in vpns:
        env = get_environment_from_interface(vpn) or 'unknown'
        click.echo(f"  • {vpn:<30} ({env.upper()})")

    click.echo()
    print_info(f"Total: {len(vpns)} VPN(s) configured")
