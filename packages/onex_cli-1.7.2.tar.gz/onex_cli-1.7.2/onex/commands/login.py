"""
Login to OneXEOS platform with email and password
"""

import click
import json
import requests
from pathlib import Path
from getpass import getpass
from datetime import datetime
from onex.utils import print_success, print_info, print_error, print_warning


def get_onex_dir() -> Path:
    """Get ~/.onex directory, create if doesn't exist"""
    onex_dir = Path.home() / '.onex'
    onex_dir.mkdir(exist_ok=True)
    return onex_dir


def load_environments() -> dict:
    """Load all environments from ~/.onex/environments.json"""
    env_file = get_onex_dir() / 'environments.json'
    if not env_file.exists():
        return {}

    with env_file.open() as f:
        return json.load(f)


def save_environments(envs: dict):
    """Save environments to ~/.onex/environments.json"""
    env_file = get_onex_dir() / 'environments.json'
    with env_file.open('w') as f:
        json.dump(envs, f, indent=2)
    env_file.chmod(0o600)


def set_active_environment(env: str):
    """Set active environment"""
    active_file = get_onex_dir() / 'active-env'
    active_file.write_text(env)
    active_file.chmod(0o644)


def find_repo_root() -> Path:
    """Find service repository root by looking for services/ directory"""
    cwd = Path.cwd()

    # Walk up from current directory
    for parent in [cwd] + list(cwd.parents):
        if (parent / 'services').exists() and (parent / 'services').is_dir():
            return parent

    return None


def transform_docker_hostnames_to_vpn(value: str, vpn_ip: str) -> str:
    """
    Transform Docker-internal hostnames to VPN IP addresses

    When debugging from Mac via VPN, we need to use VPN IP instead of Docker hostnames.
    Examples:
        mongodb://mongodb:27017 → mongodb://10.0.0.1:27017
        redis://password@redis:6379 → redis://password@10.0.0.1:6379
        nats://nats:4222 → nats://10.0.0.1:4222
        minio:9000 → 10.0.0.1:9000
    """
    if not value or not vpn_ip:
        return value

    import re

    # Map of Docker service names
    docker_services = ['mongodb', 'redis', 'nats', 'minio', 'elasticsearch']

    # Replace each Docker hostname with VPN IP
    # We need to match the hostname in URIs without matching the protocol name
    result = value
    for service in docker_services:
        # Pattern 1: @SERVICE:port (after credentials in URI)
        # Example: mongodb://user:pass@mongodb:27017 → mongodb://user:pass@10.0.0.1:27017
        result = re.sub(rf'@{service}:', f'@{vpn_ip}:', result)

        # Pattern 2: ://SERVICE:port (protocol://hostname format)
        # Match any protocol followed by ://service:
        # Example: mongodb://mongodb:27017, nats://nats:4222, http://mongodb:27017
        # We want to replace the SERVICE (hostname) but keep the protocol
        def replace_host(match):
            protocol_part = match.group(1)
            # Always replace hostname, keep protocol
            return f'{protocol_part}://{vpn_ip}:'

        result = re.sub(rf'(\w+)://{service}:', replace_host, result)

        # Pattern 3: ^SERVICE:port (standalone at start, NOT followed by //)
        # Example: minio:9000 → 10.0.0.1:9000
        # But NOT: nats://nats:4222 (protocol with ://)
        result = re.sub(rf'^{service}:(?!//)', f'{vpn_ip}:', result)

    return result


def _transform_credentials_for_vpn(credentials: dict, platform_url: str) -> dict:
    """
    Transform all service URIs from Docker hostnames to VPN IPs.

    This ensures credentials stored in environments.json have VPN-accessible IPs
    instead of Docker-internal hostnames. This is critical for CLI commands that
    read from environments.json (like platform check, deploy, etc).

    Args:
        credentials: Credential dict from gateway (contains Docker hostnames)
        platform_url: Platform URL (e.g., "http://10.0.0.1:8000")

    Returns:
        Transformed credentials dict with VPN IPs
    """
    import re

    # Extract VPN IP from platform_url (e.g., "http://10.0.0.1:8000" -> "10.0.0.1")
    ip_match = re.match(r'https?://(\d+\.\d+\.\d+\.\d+):\d+', platform_url)
    if not ip_match:
        return credentials  # No VPN IP, return as-is (localhost scenario)

    vpn_ip = ip_match.group(1)

    # Transform each credential value
    transformed = {}
    for key, value in credentials.items():
        if isinstance(value, str):
            transformed[key] = transform_docker_hostnames_to_vpn(value, vpn_ip)
        else:
            transformed[key] = value

    return transformed


def auto_generate_env(env: str, credentials: dict, platform_url: str) -> bool:
    """
    Automatically generate .env.{env} file in repo root after login
    and create/update symlink .env -> .env.{env} (Unix) or copy .env.{env} -> .env (Windows)

    On Windows, symlinks require administrator privileges, so we use file copy instead.

    Returns True if .env was generated, False otherwise
    """
    repo_root = find_repo_root()

    if not repo_root:
        return False

    # Extract VPN IP from platform URL if present (e.g., http://10.0.0.1:8000)
    import re
    vpn_ip_match = re.match(r'https?://(\d+\.\d+\.\d+\.\d+):\d+', platform_url)
    vpn_ip = vpn_ip_match.group(1) if vpn_ip_match else None

    # Parse Redis URI to extract individual components
    redis_uri = credentials.get('redis_uri', '') or ''
    redis_host = vpn_ip if vpn_ip else 'localhost'  # Default to VPN IP if available
    redis_port = '6379'
    redis_password = credentials.get('redis_password', '') or ''

    if redis_uri:
        # Transform Docker hostnames to VPN IP if debugging via VPN
        if vpn_ip:
            redis_uri = transform_docker_hostnames_to_vpn(redis_uri, vpn_ip)

        match = re.match(r'redis://(?::([^@]+)@)?([^:]+):(\d+)', redis_uri)
        if match:
            import urllib.parse
            # URL-decode password from URI (it's URL-encoded in the URI)
            redis_password = urllib.parse.unquote(match.group(1)) if match.group(1) else redis_password
            redis_host = match.group(2)
            redis_port = match.group(3)
    elif vpn_ip:
        # If redis_uri is not provided but we have VPN IP, construct URI with password
        if redis_password:
            redis_uri = f'redis://:{redis_password}@{vpn_ip}:{redis_port}'
        else:
            redis_uri = f'redis://{vpn_ip}:{redis_port}'

    # Fix MongoDB URI for local debugging
    mongodb_uri = credentials.get('mongodb_uri', '')

    # Transform Docker hostnames to VPN IP if debugging via VPN
    if vpn_ip and mongodb_uri:
        mongodb_uri = transform_docker_hostnames_to_vpn(mongodb_uri, vpn_ip)

    # Add directConnection=true for VPN or localhost connections to bypass replica set discovery
    if mongodb_uri and (vpn_ip or 'localhost' in mongodb_uri):
        if '?' in mongodb_uri:
            if 'directConnection' not in mongodb_uri:
                mongodb_uri += '&directConnection=true'
        else:
            mongodb_uri += '?directConnection=true'

    # Transform other connection strings
    nats_url = credentials.get('nats_url', '')
    if vpn_ip and nats_url:
        nats_url = transform_docker_hostnames_to_vpn(nats_url, vpn_ip)

    elasticsearch_url = credentials.get('elasticsearch_url', '')
    if vpn_ip and elasticsearch_url:
        elasticsearch_url = transform_docker_hostnames_to_vpn(elasticsearch_url, vpn_ip)

    minio_endpoint = credentials.get('minio_endpoint', '')
    if vpn_ip and minio_endpoint:
        minio_endpoint = transform_docker_hostnames_to_vpn(minio_endpoint, vpn_ip)

    # Generate .env content
    env_content = f"""# Auto-generated by: onex login
# Environment: {env}
# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
# DO NOT commit to git!

# Platform Connection
PLATFORM_URL={platform_url}
GATEWAY_URL={platform_url}

# Database
MONGODB_URI={mongodb_uri}
MONGODB_DATABASE={credentials.get('mongodb_database', 'onexeos-service')}

# Cache
REDIS_URI={redis_uri}
REDIS_HOST={redis_host}
REDIS_PORT={redis_port}
REDIS_PASSWORD={redis_password}

# Messaging
NATS_URL={nats_url}

# Search
ELASTICSEARCH_URL={elasticsearch_url}

# Storage
MINIO_ENDPOINT={minio_endpoint}
MINIO_ACCESS_KEY={credentials.get('minio_access_key', '')}
MINIO_SECRET_KEY={credentials.get('minio_secret_key', '')}

# Email Service
EMAIL_SERVICE_URL={credentials.get('email_service_url', 'http://localhost:8900')}

# Authentication
JWT_SECRET_KEY={credentials.get('jwt_secret_key', '')}
JWT_ALGORITHM={credentials.get('jwt_algorithm', 'HS256')}
JWT_ACCESS_TOKEN_EXPIRE_MINUTES={credentials.get('jwt_access_token_expire_minutes', 60)}

# SMTP (if configured - DEPRECATED: Use EMAIL_SERVICE_URL instead)
SMTP_HOST={credentials.get('smtp_host', '')}
SMTP_PORT={credentials.get('smtp_port', '')}
SMTP_USERNAME={credentials.get('smtp_username', '')}
SMTP_PASSWORD={credentials.get('smtp_password', '')}

# Development
DEBUG=true
LOG_LEVEL=DEBUG
ENV={env}
ENVIRONMENT={env}

# GitHub Token (for installing private repositories)
GITHUB_TOKEN={credentials.get('github_token', '')}
"""

    # Write .env.{env} file
    env_file = repo_root / f'.env.{env}'
    env_file.write_text(env_content)

    # Set permissions (Unix-only)
    try:
        env_file.chmod(0o600)  # Owner read/write only
    except (OSError, NotImplementedError):
        # Windows doesn't support chmod in the same way
        pass

    # Create or update .env file (symlink on Unix, copy on Windows)
    symlink_file = repo_root / '.env'

    # Remove existing symlink or file
    if symlink_file.exists() or symlink_file.is_symlink():
        symlink_file.unlink()

    # Platform-specific .env file handling
    import platform
    import shutil

    if platform.system() == 'Windows':
        # Windows: Copy file instead of symlink (no admin privileges required)
        shutil.copy2(env_file, symlink_file)
        print_info(f"   Note: .env is a copy of .env.{env} (Windows doesn't support symlinks without admin)")
    else:
        # Unix/Linux/Mac: Create symlink
        import os
        os.symlink(f'.env.{env}', symlink_file)

    return True


@click.command()
@click.option('--env',
              type=click.Choice(['local', 'dev', 'staging', 'prod'], case_sensitive=False),
              required=True,
              help='Environment to login to')
@click.option('--email', help='User email (not required for local)')
def login(env, email):
    """Login to OneXEOS platform and download environment credentials"""

    # Normalize environment name
    env = env.lower()

    # Environment configuration
    env_urls = {
        'local': 'http://localhost:8000',
        'dev': 'http://10.0.0.1:8000',
        'staging': 'http://10.0.1.1:8000',
        'prod': 'http://10.0.2.1:8000'
    }

    platform_url = env_urls.get(env)

    # LOCAL environment - no authentication required
    if env == 'local':
        click.echo("🔧 Setting up LOCAL environment...")
        click.echo()
        print_info(f"📡 Connecting to {platform_url}...")

        try:
            # Check if platform is running
            response = requests.get(f"{platform_url}/health", timeout=5)
            if response.status_code != 200:
                print_error("Platform health check failed")
                print_info("Make sure platform is running:")
                print_info("  cd onexeos-platform-NEW/docker")
                print_info("  docker compose up -d")
                return

            print_success("✅ Platform is running")

            # Download environment configuration
            print_info("📥 Downloading environment credentials...")
            response = requests.get(f"{platform_url}/_internal/env-config/local", timeout=10)

            if response.status_code != 200:
                print_error(f"Failed to get environment config: HTTP {response.status_code}")
                return

            credentials = response.json()

            # Load existing environments
            envs = load_environments()

            # Store local environment
            from datetime import datetime, timedelta
            envs['local'] = {
                'platform_url': platform_url,
                'credentials': credentials,
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            }

            save_environments(envs)
            set_active_environment('local')

            print_success("✅ Local environment configured")
            print_success("✅ Set as active environment")

            # Auto-generate .env.local file
            click.echo()
            import platform as plat
            if auto_generate_env('local', credentials, platform_url):
                print_success("✅ Generated .env.local in repository root")

                # Show platform-specific message about .env file creation
                if plat.system() == 'Windows':
                    print_success("✅ Created .env file (copy of .env.local)")
                    print_warning("   Note: On Windows, .env is a copy. After switching environments,")
                    print_warning("   run 'onex switch local' to update .env file.")
                else:
                    print_success("✅ Created symlink: .env → .env.local")

                print_info("✅ Ready to debug!")
                click.echo()
                print_info("Next steps:")
                print_info("  • onex debug --service <name>    (start debugging)")
                print_info("  • onex deploy                    (deploy to local)")
            else:
                print_warning("⚠️  Not in a service repository")
                print_info("You can still:")
                print_info("  • onex deploy       (deploys to local)")

        except requests.exceptions.ConnectionError:
            print_error(f"Could not connect to {platform_url}")
            print_info("Make sure platform is running:")
            print_info("  cd onexeos-platform-NEW/docker")
            print_info("  docker compose up -d")
        except Exception as e:
            print_error(f"Setup failed: {str(e)}")

        return

    # DEV/STAGING/PROD - require authentication
    click.echo(f"🔐 Login to {env.upper()} environment")
    click.echo(f"📡 Platform URL: {platform_url}")
    click.echo()

    # Get email
    if not email:
        email = click.prompt("Email")

    # Get password (hidden input)
    password = getpass("Password: ")

    if not password:
        print_error("Password cannot be empty")
        return

    click.echo()
    print_info("🔑 Authenticating...")

    try:
        # Determine auth service URL
        # For local environment, auth-service is on port 8100
        # For dev/staging/prod, extract host from platform_url and use port 8100
        if env == 'local':
            auth_service_url = platform_url.replace(':8000', ':8100')
        else:
            # Extract host from platform_url (e.g., http://10.0.0.1:8000 -> http://10.0.0.1:8100)
            from urllib.parse import urlparse
            parsed = urlparse(platform_url)
            auth_service_url = f"{parsed.scheme}://{parsed.hostname}:8100"

        # Login to auth service (platform service on port 8100, NOT gateway)
        response = requests.post(
            f"{auth_service_url}/auth/login",
            json={
                "email": email,
                "password": password
            },
            timeout=10
        )

        if response.status_code != 200:
            try:
                error_detail = response.json().get('detail', 'Unknown error')
            except:
                error_detail = response.text

            print_error(f"Login failed: {error_detail}")
            return

        # Parse login response
        login_data = response.json()
        access_token = login_data.get('AccessToken') or login_data.get('access_token')

        if not access_token:
            print_error("Invalid response from server (no access token)")
            return

        print_success("✅ Login successful")

        # Download environment credentials
        print_info("📥 Downloading environment credentials...")

        response = requests.get(
            f"{platform_url}/_internal/env-config/{env}",
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )

        if response.status_code != 200:
            print_error(f"Failed to get environment config: HTTP {response.status_code}")
            print_info("Your token may not have permission to access this environment")
            return

        credentials = response.json()
        print_success("✅ Credentials downloaded")

        # Calculate token expiration
        from datetime import datetime, timedelta
        expires_in = login_data.get('ExpiresIn', 3600)
        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

        # Load existing environments
        envs = load_environments()

        # Store environment configuration
        # Transform Docker hostnames to VPN IPs before storing (for dev/staging/prod)
        # This ensures all CLI commands reading from environments.json get VPN-accessible IPs
        envs[env] = {
            'platform_url': platform_url,
            'access_token': access_token,
            'token_type': login_data.get('TokenType', 'bearer'),
            'expires_in': expires_in,
            'expires_at': expires_at.isoformat() + 'Z',
            'user': {
                'email': email,
                'role': 'developer',  # Could be extracted from JWT claims
                'permissions': []
            },
            'credentials': _transform_credentials_for_vpn(credentials, platform_url),
            'last_updated': datetime.utcnow().isoformat() + 'Z'
        }

        save_environments(envs)
        set_active_environment(env)

        print_success("✅ Credentials stored securely")
        click.echo()
        print_info(f"Logged in as: {email}")
        print_info(f"Environment: {env}")
        print_success(f"✅ Set as active environment")

        # Auto-generate .env.{env} file
        click.echo()
        import platform as plat
        if auto_generate_env(env, credentials, platform_url):
            print_success(f"✅ Generated .env.{env} in repository root")

            # Show platform-specific message about .env file creation
            if plat.system() == 'Windows':
                print_success(f"✅ Created .env file (copy of .env.{env})")
                print_warning("   Note: On Windows, .env is a copy. After switching environments,")
                print_warning(f"   run 'onex switch {env}' to update .env file.")
            else:
                print_success(f"✅ Created symlink: .env → .env.{env}")

            print_info("✅ Ready to debug!")
            click.echo()
            print_info("Next steps:")
            print_info(f"  • onex debug --service <name>    (start debugging)")
            print_info(f"  • onex deploy                    (deploy to {env})")
            print_info(f"  • onex switch <env>              (switch environments)")
        else:
            print_warning("⚠️  Not in a service repository")
            print_info("You can still:")
            print_info(f"  • onex deploy       (deploys to {env})")
        click.echo()

    except requests.exceptions.ConnectionError:
        print_error(f"Could not connect to {platform_url}")
        print_info("Make sure:")
        print_info("  1. You are connected to VPN")
        print_info("  2. The platform is running")
        print_info("  3. Auth service is available")

    except requests.exceptions.Timeout:
        print_error("Request timed out")
        print_info("The server might be slow or unreachable")

    except Exception as e:
        print_error(f"Login failed: {str(e)}")
        import traceback
        traceback.print_exc()
