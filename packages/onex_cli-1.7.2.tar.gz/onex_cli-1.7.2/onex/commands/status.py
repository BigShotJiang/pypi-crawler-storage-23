"""
Status command - Check service status on platform
"""

import click
import requests
from onex.config import get_config, get_access_token
from onex.utils import print_success, print_error, print_info, print_warning


@click.command()
@click.argument('service_name', required=False)
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
def status(service_name, env, platform_url):
    """Check service status on platform"""
    from onex.config import get_active_environment

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    # Get access token for authentication
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    if service_name:
        # Check specific service
        click.echo(f"🔍 Checking status of {service_name}...")
        click.echo()

        status_url = f"{platform_base_url}/_internal/services/{service_name}"

        try:
            response = requests.get(status_url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()

                click.echo(f"📦 Service: {data.get('name')}")
                click.echo(f"   Version: {data.get('version', 'N/A')}")
                click.echo(f"   Status: {data.get('status', 'unknown')}")
                click.echo(f"   Mode: {data.get('mode', 'shared')}")

                if data.get('mode') == 'isolated':
                    click.echo(f"   Replicas: {data.get('replicas', 0)}")
                    click.echo(f"   Container: {data.get('container_name', 'N/A')}")

                click.echo()
                click.echo("🔗 Routes:")
                for route in data.get('routes', []):
                    method = route.get('method', 'GET')
                    path = route.get('path', '')
                    click.echo(f"   {method:6} {path}")

                click.echo()
                click.echo("📊 Metrics:")
                metrics = data.get('metrics', {})
                click.echo(f"   Requests: {metrics.get('total_requests', 0)}")
                click.echo(f"   Errors: {metrics.get('error_count', 0)}")
                click.echo(f"   Avg Response Time: {metrics.get('avg_response_time', 0):.2f}ms")

                # Health status
                health = data.get('health', 'unknown')
                if health == 'healthy':
                    print_success(f"Service is healthy")
                elif health == 'unhealthy':
                    print_error(f"Service is unhealthy")
                else:
                    print_warning(f"Service health: {health}")

            elif response.status_code == 401:
                print_error("Authentication required")
                print_info(f"Please login: onex login --env {env}")

            elif response.status_code == 404:
                print_error(f"Service '{service_name}' not found")
                print_info("Check deployed services with: onex status")

            else:
                print_error(f"Failed to get status: {response.status_code}")

        except requests.exceptions.ConnectionError:
            print_error(f"Cannot connect to platform at {platform_base_url}")
            print_info("Make sure platform is running")

        except Exception as e:
            print_error(f"Error checking status: {e}")

    else:
        # List all services
        click.echo("📋 Listing all deployed services...")
        click.echo()

        services_url = f"{platform_base_url}/_internal/services"

        try:
            response = requests.get(services_url, headers=headers, timeout=10)

            if response.status_code == 200:
                data = response.json()
                services = data.get('services', {})

                if not services:
                    print_info("No services deployed")
                    print_info("Deploy a service with: onex deploy")
                    return

                click.echo(f"Found {len(services)} service(s):")
                click.echo()

                # Table header
                click.echo(f"{'Service':<20} {'Version':<10} {'Mode':<12} {'Status':<10} {'Routes':<8}")
                click.echo("-" * 70)

                for svc_name, svc_data in services.items():
                    version = svc_data.get('version', 'N/A')
                    mode = svc_data.get('mode', 'shared')
                    status_val = svc_data.get('status', 'unknown')
                    route_count = len(svc_data.get('apis', []))

                    # Color code status
                    if status_val == 'running':
                        status_colored = click.style(status_val, fg='green')
                    elif status_val == 'error':
                        status_colored = click.style(status_val, fg='red')
                    else:
                        status_colored = status_val

                    click.echo(f"{svc_name:<20} {version:<10} {mode:<12} {status_colored:<19} {route_count:<8}")

                click.echo()
                print_info(f"Platform: {platform_base_url}")
                print_info("Use 'onex status <service_name>' for detailed info")

            elif response.status_code == 401:
                print_error("Authentication required")
                print_info(f"Please login: onex login --env {env}")

            else:
                print_error(f"Failed to list services: {response.status_code}")

        except requests.exceptions.ConnectionError:
            print_error(f"Cannot connect to platform at {platform_base_url}")
            print_info("Make sure platform is running")

        except Exception as e:
            print_error(f"Error listing services: {e}")
