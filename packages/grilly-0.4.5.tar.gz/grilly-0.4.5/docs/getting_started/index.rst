Getting Started
===============

This section gives you a practical, step-by-step onboarding path.

.. toctree::
   :maxdepth: 2

   installation
   quickstart
   core_concepts
   pytorch_users
