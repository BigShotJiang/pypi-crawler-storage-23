grilly.backend package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   grilly.backend.experimental

Submodules
----------

grilly.backend.affect module
----------------------------

.. automodule:: grilly.backend.affect
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.attention module
-------------------------------

.. automodule:: grilly.backend.attention
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.autograd\_core module
------------------------------------

.. automodule:: grilly.backend.autograd_core
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.base module
--------------------------

.. automodule:: grilly.backend.base
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.buffer\_pool module
----------------------------------

.. automodule:: grilly.backend.buffer_pool
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.capsule\_transformer module
------------------------------------------

.. automodule:: grilly.backend.capsule_transformer
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.cells module
---------------------------

.. automodule:: grilly.backend.cells
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.compute module
-----------------------------

.. automodule:: grilly.backend.compute
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.contrastive module
---------------------------------

.. automodule:: grilly.backend.contrastive
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.conv module
--------------------------

.. automodule:: grilly.backend.conv
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.core module
--------------------------

.. automodule:: grilly.backend.core
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.faiss module
---------------------------

.. automodule:: grilly.backend.faiss
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.fft module
-------------------------

.. automodule:: grilly.backend.fft
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.fnn module
-------------------------

.. automodule:: grilly.backend.fnn
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.hilbert module
-----------------------------

.. automodule:: grilly.backend.hilbert
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.learning module
------------------------------

.. automodule:: grilly.backend.learning
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.lora module
--------------------------

.. automodule:: grilly.backend.lora
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.memory module
----------------------------

.. automodule:: grilly.backend.memory
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.normalization module
-----------------------------------

.. automodule:: grilly.backend.normalization
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.pipelines module
-------------------------------

.. automodule:: grilly.backend.pipelines
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.pooling module
-----------------------------

.. automodule:: grilly.backend.pooling
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.shader\_registry module
--------------------------------------

.. automodule:: grilly.backend.shader_registry
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.snn module
-------------------------

.. automodule:: grilly.backend.snn
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.snn\_compute module
----------------------------------

.. automodule:: grilly.backend.snn_compute
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.snn\_visualizer module
-------------------------------------

.. automodule:: grilly.backend.snn_visualizer
   :members:
   :undoc-members:
   :show-inheritance:

grilly.backend.vma\_wrapper module
----------------------------------

.. automodule:: grilly.backend.vma_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: handle
   :noindex:

Module contents
---------------

.. automodule:: grilly.backend
   :noindex:
