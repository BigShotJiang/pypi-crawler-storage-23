API Reference
=============

This section is generated from the codebase and documents modules, classes,
and functions across Grilly. Each submodule is rendered as its own HTML page.

.. toctree::
   :maxdepth: 2
   :caption: API Packages

   generated/grilly.backend
   generated/grilly.datasets
   generated/grilly.experimental
   generated/grilly.functional
   generated/grilly.nn
   generated/grilly.optim
   generated/grilly.scripts
   generated/grilly.utils

The pages below are generated recursively from importable modules and include
all submodules as independent pages.

.. autosummary::
   :toctree: generated
   :recursive:

   grilly.backend
   grilly.datasets
   grilly.experimental
   grilly.functional
   grilly.nn
   grilly.optim
   grilly.scripts
   grilly.utils
