"""
Tests for grilly.experimental namespace.

Test-Driven Development: Tests are written first, then implementations.
"""
