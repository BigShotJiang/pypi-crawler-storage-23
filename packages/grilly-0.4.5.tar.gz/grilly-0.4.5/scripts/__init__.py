"""
Grilly utility scripts for installation and setup.
"""
