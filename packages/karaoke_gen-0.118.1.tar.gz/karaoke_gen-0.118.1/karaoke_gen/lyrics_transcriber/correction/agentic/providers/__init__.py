"""AI provider scaffolding for agentic correction (config, health checks)."""

__all__ = [
]


