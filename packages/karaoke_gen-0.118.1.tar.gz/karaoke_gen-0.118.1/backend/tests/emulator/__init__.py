"""
Emulator integration tests.

These tests run against local GCP emulators (Firestore, GCS)
to provide true integration testing without cloud costs.
"""

