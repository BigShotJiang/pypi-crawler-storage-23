"""Tracer source assets for Swordfish MCP."""
