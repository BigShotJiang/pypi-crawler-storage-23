"""MCP integration package for Swordfish."""
