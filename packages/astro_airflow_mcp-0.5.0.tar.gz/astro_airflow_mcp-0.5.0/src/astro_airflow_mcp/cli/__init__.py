"""CLI package for af tool."""

from astro_airflow_mcp.cli.main import app

__all__ = ["app"]
