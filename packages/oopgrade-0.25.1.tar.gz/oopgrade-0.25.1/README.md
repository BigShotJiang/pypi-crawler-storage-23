# OOpgrade

[![Tests](https://github.com/gisce/oopgrade/actions/workflows/tests.yml/badge.svg)](https://github.com/gisce/oopgrade/actions/workflows/tests.yml)

> [!CAUTION]  
> The API is quite unstable due to active development.

> [!NOTE]
> OpenObject upgrade lib forked from the [openupgrade project](https://github.com/OCA/OpenUpgrade/tree/5.0/bin/openupgrade) and improved and adapted to meet our needs.


## MigrationHelper

Per ara podeu consultar la documentació de la classe al RFC [MigrationHelper](https://rfc.gisce.net/t/migrationhelper/2500).
