"""
LaminarNet — Structured Orthogonal State Space Sequence Model
A novel neural architecture for sequence modeling merging SSM, RNN, and Hierarchical processing.

Core mechanisms:
  1. Geometric Drift Fields (GDF) — Parallelizable rotation-based state evolution (via Prefix Sum)
  2. Cross-Stratum Routing (CSR) — Bidirectional multi-resolution exchange
  3. Phase Mesh Encoding (PME) — Stabilized coupled oscillator position encoding
"""

import math
from dataclasses import dataclass
from typing import Optional, List

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class LaminarNetConfig:
    vocab_size: int = 32000
    d_model: int = 256
    n_heads: int = 8
    n_layers: int = 6
    d_ff: int = 512
    n_strata: int = 2          # number of resolution strata
    strata_ratios: tuple = (1, 4)  # compression ratios
    n_oscillators: int = 16    # phase mesh oscillators
    seq_len: int = 2048        # Extended context length capability
    dropout: float = 0.1
    conv_kernel: int = 5       # base local mixing kernel


# ─────────────────────────────────────────────────────────────
# 1. Geometric Drift Field (GDF) — Parallelized
# ─────────────────────────────────────────────────────────────

class GeometricDriftField(nn.Module):
    """
    Parallelizable Geometric Drift Field using Cumulative Sum (Prefix Scan).
    
    Replace sequential RNN loop with O(N) parallel prefix sum.
    Implements a simplified complex-valued rotation (element-wise phase shift).
    Includes a 'Forget Gate' for information flow control.
    """

    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        
        # 1. Rotation Generator (Thetas)
        # Projects input to rotation angles. Tanh ensures range [-1, 1] rad (approx).
        self.to_theta = nn.Linear(d_model, d_model)
        
        # 2. Input Projection (Content)
        self.to_input = nn.Linear(d_model, d_model)
        
        # 3. Forget Gate (decay factor)
        # Sigmoid activated, controls how much previous state is retained/rotated vs decayed.
        self.to_gate = nn.Linear(d_model, d_model)
        
        # 4. Output Projection
        self.to_output = nn.Linear(d_model, d_model)
        
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (Batch, SeqLen, Dim)
        returns: (Batch, SeqLen, Dim)
        """
        residual = x
        x = self.norm(x)
        
        B, N, D = x.shape
        H = self.n_heads
        D_H = self.d_head
        
        # A. Generate Rotation Angles (Thetas)
        # Tanh limits rotation magnitude for stability
        theta = torch.tanh(self.to_theta(x)) # (B, N, D)
        
        # B. Generate Forget Gate
        # Gate \in (0, 1). Small value = forget, Large = keep.
        gate = torch.sigmoid(self.to_gate(x)) # (B, N, D)
        
        # C. Parallel Prefix Sum (Cumulative Rotation)
        # Reshape for multi-head view: (B, N, H, D_H)
        theta = theta.view(B, N, H, D_H)
        
        # CAUSAL MASKING IS CRITICAL HERE w/ CUMSUM
        # cumsum by default sums everything up to index i.
        # This is naturally causal: cumsum[i] = sum(0..i).
        # It depends ONLY on past if theta[i] depends only on x[i].
        # Since theta is derived from x projection, it is causal.
        # HOWEVER, if we used bidirectional or non-masked attention, it would leak.
        # Here we are using element-wise projections.
        
        # Wait, the issue might be in how we use 'v_rotated'.
        # v_rotated[i] = v[i] * cos(sum(theta[0..i]))
        # This looks causal.
        
        # Let's check LocalMixing.
        # LocalMixing uses Conv1d with padding=kernel-1 and then trims.
        # x = x[..., :residual.shape[1]]
        # If kernel=5, pad=4.
        # Input: [0, 1, 2]
        # Padded: [P, P, P, P, 0, 1, 2] (Left pad)
        # Conv window size 5.
        # Output[0] centered at...?
        # PyTorch Conv1d without padding is valid.
        
        # In LocalMixing: padding=kernel_size-1.
        # Default Conv1d behavior:
        # If we want causal, we usually pad (K-1) on left, 0 on right.
        # self.conv(x) with padding=K-1 in PyTorch adds (K-1)/2 on both sides if not specified? 
        # No, 'padding' arg adds to both sides by default!
        # TARGET: padding=(K-1, 0)
        
        # FIXING GDF Just in case:
        # The rotation logic is fine casually.
        
        cum_theta = torch.cumsum(theta, dim=1) 
        
        # D. Prepare Content (Input)
        v = self.to_input(x).view(B, N, H, D_H)
        
        # Sol: The leakage is likely in LocalMixing or CSR.
        # GDF looks mathematically causal (prefix sum).
        
        cos_rot = torch.cos(cum_theta)
        sin_rot = torch.sin(cum_theta)
        
        v_rotated = v * cos_rot + (torch.flip(v, dims=[-1]) * sin_rot)
        
        # Apply Forget Gate
        v_gated = v_rotated * gate.view(B, N, H, D_H)
        
        # F. Output Projection
        out = v_gated.reshape(B, N, D)
        out = self.to_output(out)
        out = self.dropout(out)
        
        return residual + out


# ─────────────────────────────────────────────────────────────
# 2. Cross-Stratum Routing (CSR) — Robust
# ─────────────────────────────────────────────────────────────

class CrossStratumRouting(nn.Module):
    """
    Bidirectional information exchange between adjacent strata with robust padding.
    """

    def __init__(self, d_model: int, stride: int):
        super().__init__()
        self.stride = stride
        kernel = stride * 2
        
        # Promotion (Fine -> Coarse)
        # Causal Padding: Left = Kernel - 1
        self.pad_up = nn.ConstantPad1d((kernel - 1, 0), 0.0)
        self.conv_up = nn.Conv1d(d_model, d_model, kernel_size=kernel, 
                                 stride=stride, padding=0)
        self.gate_up = nn.Linear(d_model, d_model)
        
        # Demotion (Coarse -> Fine)
        # To be Causal: h_coarse[i] (summary of chunk i) must ONLY affect h_fine >= chunk i+1.
        # Standard TransposeConv with symmetric padding leaks: h_coarse[i] affects h_fine[i*S - P ...].
        # We set P=0 -> h_coarse[i] affects h_fine[i*S ...].
        # Then we explicitly PAD LEFT by S to shift effect to h_fine[i*S + S ...].
        # Note: We remove the 'kernel//2' padding which was centering it (and leaking).
        self.conv_down = nn.ConvTranspose1d(d_model, d_model, kernel_size=kernel, 
                                            stride=stride, padding=0)
        self.gate_down = nn.Linear(d_model, d_model)

    def forward(self, h_fine: torch.Tensor, h_coarse: torch.Tensor):
        """
        Safely exchanges info even if shapes don't align perfectly due to stride.
        """
        # Save original lengths to ensure shape consistency
        L_fine = h_fine.shape[1]
        L_coarse = h_coarse.shape[1]
        
        # ── PROMOTE ──
        # h_fine: (B, L_f, D) -> (B, D, L_f)
        x_fine = (h_fine * torch.sigmoid(self.gate_up(h_fine))).transpose(1, 2)
        
        # Conv1d output length formula: L_out = (L_in + 2*padding - dilation*(kernel-1) - 1)/stride + 1
        x_padded = self.pad_up(x_fine)
        promote = self.conv_up(x_padded).transpose(1, 2) # (B, L_new, D)
        
        # Robust Slicing: enforce exact length match with coarse stratum
        if promote.shape[1] > L_coarse:
            promote = promote[:, :L_coarse, :]
        elif promote.shape[1] < L_coarse:
            # Pad with zeros if short (rare with correct settings)
            pad_len = L_coarse - promote.shape[1]
            promote = F.pad(promote, (0, 0, 0, pad_len))
            
        h_coarse = h_coarse + promote
        
        # ── DEMOTE ──
        # h_coarse: (B, L_c, D) -> (B, D, L_c)
        x_coarse = (h_coarse * torch.sigmoid(self.gate_down(h_coarse))).transpose(1, 2)
        
        # With padding=0, Input 0 maps to 0..K.
        demote = self.conv_down(x_coarse).transpose(1, 2) # (B, L_new, D)
        
        # SHIFT RIGHT by Stride (Causal Delay)
        # This ensures Coarse[i] (summary of 0..i*S) only affects Fine > i*S.
        # Padding last 2 dims: (0, 0) for dim -1 (D), (stride, 0) for dim -2 (L).
        demote = F.pad(demote, (0, 0, self.stride, 0))
        
        # Robust Slicing for fine stratum
        if demote.shape[1] > L_fine:
            demote = demote[:, :L_fine, :]
        elif demote.shape[1] < L_fine:
            pad_len = L_fine - demote.shape[1]
            demote = F.pad(demote, (0, 0, 0, pad_len))
            
        h_fine = h_fine + demote
        
        return h_fine, h_coarse


# ─────────────────────────────────────────────────────────────
# 3. Phase Mesh Encoding (PME) — Stabilized
# ─────────────────────────────────────────────────────────────

class PhaseMeshEncoding(nn.Module):
    """
    Stabilized Coupled Oscillator Encoding.
    Adds normalization to coupling and phase clipping to prevent chaos in gradients.
    """

    def __init__(self, d_model: int, n_oscillators: int = 16, seq_len: int = 2048):
        super().__init__()
        self.P = n_oscillators
        self.d_model = d_model
        
        # Log-linear frequencies
        freqs = torch.exp(torch.linspace(
            math.log(2 * math.pi / seq_len),
            math.log(2 * math.pi / 4),
            n_oscillators
        ))
        self.omega = nn.Parameter(freqs)
        
        # Coupling matrix - initialized very small for stability
        self.K = nn.Parameter(torch.randn(n_oscillators, n_oscillators) * 0.001)
        
        self.proj = nn.Linear(n_oscillators * 2, d_model, bias=False)
        
        # Cache
        self._cache_len = -1
        self._cache_embed = None

    def _compute_phases(self, seq_len: int, device: torch.device):
        phases = torch.zeros(seq_len, self.P, device=device)
        
        # Iterative update (Kuramoto)
        # This part is sequential but only runs once per sequence length (cached)
        # or implies a fixed computational cost O(L) not O(L^2).
        for t in range(1, seq_len):
            prev = phases[t-1]
            
            # Phase difference matrix: (P, 1) - (1, P) = (P, P)
            diff = prev.unsqueeze(0) - prev.unsqueeze(1)
            
            # Coupling force: sum(K * sin(diff))
            # STABILIZATION: Tanh on coupling to prevent explosive updates
            interaction = torch.tanh((self.K * torch.sin(diff)).sum(dim=1))
            
            # Update: new = old + natural_freq + interaction
            delta = self.omega + interaction
            
            # STABILIZATION: Clip delta to avoid phase jumps > pi
            delta = torch.clamp(delta, -3.14, 3.14)
            
            phases[t] = prev + delta
            
        return phases

    def forward(self, input_len: int, device: torch.device):
        # Return cached if valid
        if not self.training and self._cache_len == input_len and self._cache_embed is not None:
             if self._cache_embed.device == device:
                 return self._cache_embed

        phases = self._compute_phases(input_len, device)
        
        # Embed: [cos(phi), sin(phi)]
        feat = torch.cat([torch.cos(phases), torch.sin(phases)], dim=-1)
        emb = self.proj(feat)
        
        if not self.training:
            self._cache_len = input_len
            self._cache_embed = emb
            
        return emb


# ─────────────────────────────────────────────────────────────
# 4. Local Mixing & FFN (Standard Components)
# ─────────────────────────────────────────────────────────────

class LocalMixing(nn.Module):
    """Depthwise Separable Causal Conv1d"""
    def __init__(self, d_model: int, kernel_size: int = 5):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.conv = nn.Conv1d(d_model, d_model, kernel_size=kernel_size, 
                              groups=d_model, padding=0) # Padding handled explicitly
        self.pad = nn.ConstantPad1d((kernel_size - 1, 0), 0.0)
        self.pt_conv = nn.Conv1d(d_model, d_model, kernel_size=1)
        self.act = nn.SiLU()

    def forward(self, x):
        # x: (B, N, D)
        residual = x
        x = self.norm(x).transpose(1, 2)
        x = self.pad(x)
        x = self.conv(x)
        # x = x[..., :residual.shape[1]] # No trimming needed with explicit left pad + valid conv
        x = self.act(x)
        x = self.pt_conv(x).transpose(1, 2)
        return residual + x


class SwiGLUFFN(nn.Module):
    """Gated FFN"""
    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.w1 = nn.Linear(d_model, d_ff, bias=False)
        self.w2 = nn.Linear(d_ff, d_model, bias=False)
        self.w3 = nn.Linear(d_model, d_ff, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        residual = x
        x = self.norm(x)
        x = F.silu(self.w1(x)) * self.w3(x)
        x = self.w2(x)
        x = self.dropout(x)
        return residual + x


# ─────────────────────────────────────────────────────────────
# 5. Laminar Block & Main Model
# ─────────────────────────────────────────────────────────────

class LaminarBlock(nn.Module):
    def __init__(self, config: LaminarNetConfig):
        super().__init__()
        self.S = config.n_strata
        
        self.gdfs = nn.ModuleList([
            GeometricDriftField(config.d_model, config.n_heads, config.dropout)
            for _ in range(self.S)
        ])
        
        self.mixers = nn.ModuleList([
            LocalMixing(config.d_model, kernel_size=config.conv_kernel * config.strata_ratios[s])
            for s in range(self.S)
        ])
        
        self.csrs = nn.ModuleList()
        for s in range(self.S - 1):
            stride = config.strata_ratios[s+1] // config.strata_ratios[s]
            self.csrs.append(CrossStratumRouting(config.d_model, stride))
            
        self.ffns = nn.ModuleList([
            SwiGLUFFN(config.d_model, config.d_ff, config.dropout)
            for _ in range(self.S)
        ])

    def forward(self, strata: List[torch.Tensor]):
        # 1. Geometric Drift (Global State Evolution)
        for s in range(self.S):
            strata[s] = self.gdfs[s](strata[s])
            
        # 2. Local Mixing (Local Context)
        for s in range(self.S):
            strata[s] = self.mixers[s](strata[s])
            
        # 3. CSR (Hierarchical Exchange)
        for s in range(self.S - 1):
            strata[s], strata[s+1] = self.csrs[s](strata[s], strata[s+1])
            
        # 4. FFN (Processing)
        for s in range(self.S):
            strata[s] = self.ffns[s](strata[s])
            
        return strata


class LaminarNet(nn.Module):
    def __init__(self, config: LaminarNetConfig):
        super().__init__()
        self.config = config
        d = config.d_model
        
        self.tok_emb = nn.Embedding(config.vocab_size, d)
        self.phase_mesh = PhaseMeshEncoding(d, config.n_oscillators, config.seq_len)
        self.dropout = nn.Dropout(config.dropout)
        
        # Strata Initializers (Learned Downsampling)
        self.strata_init = nn.ModuleList()
        for s in range(1, config.n_strata):
            r = config.strata_ratios[s]
            # Causal Downsampling: Pad left by kernel-1 corresponds to seeing only past
            # We implement this by applying pad manually or using a wrapper
            # Here: explicit pad + valid conv
            self.strata_init.append(nn.Sequential(
                nn.ConstantPad1d((r*2 - 1, 0), 0.0),
                nn.Conv1d(d, d, kernel_size=r*2, stride=r, padding=0)
            ))
            
        self.blocks = nn.ModuleList([
            LaminarBlock(config) for _ in range(config.n_layers)
        ])
        
        self.norm_out = nn.LayerNorm(d)
        self.head = nn.Linear(d, config.vocab_size, bias=False)
        self.head.weight = self.tok_emb.weight # Tie weights

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, nn.Conv1d):
            torch.nn.init.kaiming_normal_(module.weight)

    def forward(self, input_ids):
        B, N = input_ids.shape
        device = input_ids.device
        
        # Embed + Pos
        x = self.tok_emb(input_ids)
        pos = self.phase_mesh(N, device)
        x = self.dropout(x + pos)
        
        # Init Strata
        strata = [x]
        for init_layer in self.strata_init:
            # (B, N, D) -> (B, D, N) -> conv -> (B, D, N') -> (B, N', D)
            feat = x.transpose(1, 2)
            down = init_layer(feat).transpose(1, 2)
            
            # Conv output length might need trimming to match exact stride ratio
            # Simple fix: just append, CSR handles mismatch robustness
            strata.append(down)
            
        # Layers
        for block in self.blocks:
            strata = block(strata)
            
        # Output (from fine stratum)
        out = self.norm_out(strata[0])
        logits = self.head(out)
        return logits

    def count_parameters(self):
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


if __name__ == "__main__":
    # Smoke Test
    conf = LaminarNetConfig()
    model = LaminarNet(conf)
    print(f"Model Params: {model.count_parameters():,}")
    
    x = torch.randint(0, conf.vocab_size, (2, 256))
    y = model(x)
    print(f"Input: {x.shape} -> Output: {y.shape}")
    assert y.shape == (2, 256, conf.vocab_size)
    print("Test Passed: Parallel LaminarNet is operational.")
