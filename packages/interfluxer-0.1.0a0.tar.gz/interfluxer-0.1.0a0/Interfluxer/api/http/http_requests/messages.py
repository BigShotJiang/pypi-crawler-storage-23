from typing import TYPE_CHECKING, cast, TypedDict

import discord_typings

from Interfluxer.models.internal.protocols import CanRequest
from Interfluxer.client.utils.serializer import dict_filter_none
from ..route import Route

__all__ = ("MessageRequests",)


if TYPE_CHECKING:
    from Interfluxer.models.external.snowflake import Snowflake_Type
    from Interfluxer import UPLOADABLE_TYPE


class GetAnswerVotersData(TypedDict):
    users: list[discord_typings.UserData]


class MessageRequests(CanRequest):
    async def create_message(
        self,
        payload: dict,
        channel_id: "Snowflake_Type",
        files: list["UPLOADABLE_TYPE"] | None = None,  # todo type payload
    ) -> discord_typings.MessageData:
        """
        Send a message to the specified channel.

        Args:
            payload: The message to send
            channel_id: id of the channel to send message in
            files: Any files to send with this message

        Returns:
            The resulting message object

        """
        result = await self.request(
            Route("POST", "/channels/{channel_id}/messages", channel_id=channel_id), payload=payload, files=files
        )
        return cast(discord_typings.MessageData, result)

    async def delete_message(
        self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type", reason: str | None = None
    ) -> None:
        """
        Deletes a message from the specified channel.

        Args:
            channel_id: The id of the channel to delete the message from
            message_id: The id of the message to delete
            reason: The reason for this action

        """
        await self.request(
            Route(
                "DELETE", "/channels/{channel_id}/messages/{message_id}", channel_id=channel_id, message_id=message_id
            ),
            reason=reason,
        )

    async def bulk_delete_messages(
        self,
        channel_id: "Snowflake_Type",
        message_ids: list["Snowflake_Type"],
        reason: str | None = None,
    ) -> None:
        """
        Delete multiple messages in a single request.

        Args:
            channel_id: The id of the channel these messages are in
            message_ids: A list of message ids to delete
            reason: The reason for this action

        """
        payload = {"messages": [int(message_id) for message_id in message_ids]}

        await self.request(
            Route("POST", "/channels/{channel_id}/messages/bulk-delete", channel_id=channel_id),
            payload=payload,
            reason=reason,
        )

    async def get_message(
        self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type"
    ) -> discord_typings.MessageData:
        """
        Get a specific message in the channel. Returns a message object on success.

        Args:
            channel_id: the channel this message belongs to
            message_id: the id of the message

        Returns:
            message or None

        """
        result = await self.request(
            Route("GET", "/channels/{channel_id}/messages/{message_id}", channel_id=channel_id, message_id=message_id)
        )
        return cast(discord_typings.MessageData, result)

    async def pin_message(self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type") -> None:
        """
        Pin a message to a channel.

        Args:
            channel_id: Channel to pin message to
            message_id: Message to pin

        """
        await self.request(
            Route("PUT", "/channels/{channel_id}/pins/{message_id}", channel_id=channel_id, message_id=message_id)
        )

    async def unpin_message(self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type") -> None:
        """
        Unpin a message to a channel.

        Args:
            channel_id: Channel to unpin message to
            message_id: Message to unpin

        """
        await self.request(
            Route("DELETE", "/channels/{channel_id}/pins/{message_id}", channel_id=channel_id, message_id=message_id)
        )

    async def edit_message(
        self,
        payload: dict,
        channel_id: "Snowflake_Type",
        message_id: "Snowflake_Type",
        files: list["UPLOADABLE_TYPE"] | None = None,
    ) -> discord_typings.MessageData:
        """
        Edit an existing message.

        Args:
            payload:
            channel_id: Channel of message to edit.
            message_id: Message to edit.
            files: Any files to send with this message

        Returns:
            Message object of edited message

        """
        result = await self.request(
            Route(
                "PATCH", "/channels/{channel_id}/messages/{message_id}", channel_id=channel_id, message_id=message_id
            ),
            payload=payload,
            files=files,
        )
        return cast(discord_typings.MessageData, result)

    async def crosspost_message(
        self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type"
    ) -> discord_typings.MessageData:
        """
        Crosspost a message in a News Channel to following channels.

        Args:
            channel_id: Channel the message is in
            message_id: The id of the message to crosspost
        Returns:
            message object

        """
        result = await self.request(
            Route(
                "POST",
                "/channels/{channel_id}/messages/{message_id}/crosspost",
                channel_id=channel_id,
                message_id=message_id,
            )
        )
        return cast(discord_typings.MessageData, result)

    async def get_answer_voters(
        self,
        channel_id: "Snowflake_Type",
        message_id: "Snowflake_Type",
        answer_id: int,
        after: "Snowflake_Type | None" = None,
        limit: int = 25,
    ) -> GetAnswerVotersData:
        """
        Get a list of users that voted for this specific answer.

        Args:
            channel_id: Channel the message is in
            message_id: The message with the poll
            answer_id: The answer to get voters for
            after: Get messages after this user ID
            limit: The max number of users to return (default 25, max 100)

        Returns:
            GetAnswerVotersData: A response that has a list of users that voted for the answer

        """
        result = await self.request(
            Route(
                "GET",
                "/channels/{channel_id}/polls/{message_id}/answers/{answer_id}",
                channel_id=channel_id,
                message_id=message_id,
                answer_id=answer_id,
            ),
            params=dict_filter_none({"after": after, "limit": limit}),
        )
        return cast(GetAnswerVotersData, result)

    async def end_poll(self, channel_id: "Snowflake_Type", message_id: "Snowflake_Type") -> discord_typings.MessageData:
        """
        Ends a poll. Only can end polls from the current bot.

        Args:
            channel_id: Channel the message is in
            message_id: The message with the poll

        Returns:
            message object

        """
        result = await self.request(
            Route(
                "POST",
                "/channels/{channel_id}/polls/{message_id}/expire",
                channel_id=channel_id,
                message_id=message_id,
            )
        )
        return cast(discord_typings.MessageData, result)
