### Project description

A lightweight AES encryption and decryption utility that can be used both as a command-line tool and as a Python package.

## Prerequisites

**python >3.8** required*


## To install
```
pip install fcrypt
```


## Dependencies
cryptography:*46.0.5* ( Will install automatically )


## Build Debian
```
python setup.py --command-packages=stdeb.command bdist_deb
```





