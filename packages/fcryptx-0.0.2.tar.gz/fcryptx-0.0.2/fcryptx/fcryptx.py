#! /usr/bin/python3

from .lib.Arguments import Arguments
from .algorithms.Aes import Aes
import sys
from pathlib import Path



class fcryptx:
    def __init__(self,args: Arguments):
        self.args = args

    @classmethod
    def cli_args(cls):
        args = Arguments(sys.argv)
        return cls(args)

    @staticmethod
    def help():
        print("Usage: fcryptx [--e|--d] --algorithm=<algorithm> --key=<my_secretkey> --file=<path> [--out=<path>]")

    def run(self):
        arg = self.args


        allowed_options = {'--e', '--d', '--algorithm', '--key', '--file', '--out'}

        for raw in sys.argv[1:]:
            option = raw.split('=')[0]
            if option not in allowed_options:
                fcryptx.help()
                raise ValueError(f"Unknown argument: {option}")

        if not arg.hasOption('--file'):
            fcryptx.help()
            raise ValueError("File name should not be empty")
        
        file = Path(arg.getOptionValue('--file'))


        if not file.exists():
            raise FileNotFoundError("File does not exist")

        if not arg.hasOption('--key'):
            fcryptx.help()
            raise ValueError("Enter the key value")

        if not arg.hasOption('--algorithm'):
            fcryptx.help()
            raise ValueError("Enter a valid AES algorithm")
        

        secret_key =  arg.getOptionValue('--key')
        algorithm = arg.getOptionValue('--algorithm')

        bit_length = self._parse_algorithm(algorithm)

        if arg.hasOption('--e') and arg.hasOption('--d'):
            raise ValueError("Cannot use --e and --d together")

        if (arg.hasOption('--e')):
            # encryption
            data = None
            with open(file, 'r') as fp:
                data = fp.read()

            aes = Aes(secret_key)
            encrypted_data = aes.encrypt(data,bit_length)

            output_folder = arg.getOptionValue('--out') if arg.hasOption('--out') else '.'
    
            output_path = Path(output_folder)
            output_path.mkdir(parents=True, exist_ok=True)

            # Create full output file path properly
            output_file = output_path / (file.stem + '.enc')


            with open(output_file,'wb') as fp:
                fp.write(encrypted_data)
        elif(arg.hasOption('--d')):
            # decryption
            data = None
            with open(file, 'r') as fp:
                data = fp.read()
            aes = Aes(secret_key)
            decrypted_data = aes.decrypt(data,bit_length)

            output_folder = arg.getOptionValue('--out') if arg.hasOption('--out') else '.'
    
            output_path = Path(output_folder)
            output_path.mkdir(parents=True, exist_ok=True)

            # Create full output file path properly
            output_file = output_path / (file.stem + '.txt')


            with open(output_file,'wb') as fp:
                fp.write(decrypted_data)
        else:
            raise ValueError("Specify --e for encryption or --d for decryption")
        

    def _parse_algorithm(self,algorithm):
        try:
            name, size = algorithm.split('-')
            bit_length = int(size)
            if name.lower() != "aes" or bit_length not in {128,192,256}:
                raise ValueError
            
            return bit_length
        
        except ValueError:
            raise ValueError("Algorithm must be AES-128, AES-192, or AES-256")

            

def main():
    try:
        if len(sys.argv) <= 3:
            fcryptx.help()
            sys.exit(1)   

        fcryptx.cli_args().run()

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

        

