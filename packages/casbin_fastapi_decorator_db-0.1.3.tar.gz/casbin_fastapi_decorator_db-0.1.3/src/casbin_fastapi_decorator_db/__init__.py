"""Database-backed Casbin enforcer provider."""

from casbin_fastapi_decorator_db._provider import DatabaseEnforcerProvider

__all__ = ["DatabaseEnforcerProvider"]
