"""
Entry point for running kyber as a module: python -m kyber
"""

from kyber.cli.commands import app

if __name__ == "__main__":
    app()
