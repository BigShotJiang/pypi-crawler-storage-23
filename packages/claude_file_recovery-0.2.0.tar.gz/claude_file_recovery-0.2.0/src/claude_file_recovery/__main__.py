from claude_file_recovery.cli import app

app()
