import asyncio
import os
import logging
import httpx
from langchain_core.tools import StructuredTool
from a2a.types import AgentCard

logger = logging.getLogger(__name__)

if os.getenv("HTTPX_LOGGING") == "true":
    logging.getLogger("httpx").setLevel(logging.DEBUG)


async def registry_heart_beat(name: str, registry: 'AgentRegistryLookup', agent_card: AgentCard, interval_sec: int,
                              get_expire_at: callable) -> None:
    registry.put_agent_card(name=name, agent_card=agent_card.model_dump(), expire_at=get_expire_at())
    while True:
        try:
            registry.patch_agent_expiry(name=name, expire_at=get_expire_at())
        except Exception as e:
            logger.error(f"Failed to send heart beat to registry: {e}")
        await asyncio.sleep(interval_sec)


class AgentRegistryLookup:
    def __init__(self, registry_url: str, req_opts: dict[str, str] | None):
        self.registry_url = registry_url
        self.req_opts = req_opts if req_opts else {}
        self.client = httpx.Client(headers=self.req_opts, timeout=30)

    def get_agent_cards(self) -> list[dict]:
        response = self.client.get(url=f"{self.registry_url}/agent-cards")
        response.raise_for_status()
        return response.json()

    def get_agent_card(self, name: str) -> dict | None:
        response = self.client.get(url=f"{self.registry_url}/agent-card/{name}")
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()

    def put_agent_card(self, name: str, agent_card: dict, expire_at: int) -> None:
        response = self.client.put(
            url=f"{self.registry_url}/agent-card/{name}",
            params={"expire_at": str(expire_at)},
            json=agent_card,
        )
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error during put_agent_card: {e}")
            if response.text:
                logger.error(f"Response content: {response.text}")
            raise

    def patch_agent_expiry(self, name: str, expire_at: int) -> None:
        response = self.client.patch(
            url=f"{self.registry_url}/agent-card/{name}/heartbeat",
            params={"expire_at": str(expire_at)},
        )
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error during patch_agent_expiry: {e}")
            if response.text:
                logger.error(f"Response content: {response.text}")
            raise

    def as_tool(self) -> StructuredTool:
        return StructuredTool.from_function(func=lambda: self.get_agent_cards(), name="agent_card_lookup",
                                            description="Gets all available agent cards")


class McpRegistryLookup:
    def __init__(self, registry_url: str, req_opts: dict[str, str] = {}):
        self.registry_url = registry_url
        self.client = httpx.Client(timeout=30, headers=req_opts)

    def get_mcp_tool_for_agent(self, agent_name: str) -> list[dict]:
        response = self.client.get(url=f"{self.registry_url}/mcp/agent/{agent_name}/servers")
        response.raise_for_status()
        return response.json()