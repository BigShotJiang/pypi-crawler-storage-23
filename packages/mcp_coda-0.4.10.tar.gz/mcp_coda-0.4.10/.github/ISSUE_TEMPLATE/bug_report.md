---
name: Bug report
about: Report a bug or unexpected behavior
title: ""
labels: bug
assignees: ""
---

**Tool name**
Which tool(s) are affected? (e.g. `coda_list_docs`, `coda_get_row`)

**Describe the bug**
A clear description of what happened.

**Expected behavior**
What should have happened instead.

**Error output**
```
Paste the error JSON or traceback here
```

**Environment**
- mcp-coda version: (e.g. 0.3.0)
- Python version:
- MCP client: (e.g. Claude Code, Cursor, VS Code)

**Additional context**
Any other relevant details.
