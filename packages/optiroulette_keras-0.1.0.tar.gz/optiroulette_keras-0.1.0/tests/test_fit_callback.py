import os

os.environ.setdefault("KERAS_BACKEND", "torch")

import pytest

keras = pytest.importorskip("keras")
torch = pytest.importorskip("torch")

from torch.utils.data import DataLoader, TensorDataset

from optiroulette_keras import create_fit_callback, create_roulette_callback


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_runs_with_model_fit():
    x = torch.randn(128, 8)
    y = torch.randint(0, 3, (128,))
    loader = DataLoader(TensorDataset(x, y), batch_size=32, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(16, activation="relu"),
            keras.layers.Dense(3),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="epoch",
        seed=7,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    history = model.fit(
        loader,
        validation_data=loader,
        epochs=2,
        callbacks=[roulette_cb],
        verbose=0,
    )

    assert "accuracy" in history.history
    assert controller.step_count > 0
    assert not any(key.startswith("optiroulette_") for key in history.history.keys())


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_batch_switching_updates_optimizer():
    x = torch.randn(96, 8)
    y = torch.randint(0, 2, (96,))
    loader = DataLoader(TensorDataset(x, y), batch_size=24, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(8, activation="relu"),
            keras.layers.Dense(2),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="batch",
        switch_every_steps=1,
        switch_probability=1.0,
        avoid_repeat=True,
        seed=11,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    model.fit(loader, epochs=1, callbacks=[roulette_cb], verbose=0)

    assert len(controller.switch_history) > 0
    assert set(controller.get_epoch_selection_counts().keys()) == {"adam", "sgd"}
    assert controller.step_count == len(loader)


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_verbose_one_does_not_break_progbar():
    x = torch.randn(96, 8)
    y = torch.randint(0, 2, (96,))
    loader = DataLoader(TensorDataset(x, y), batch_size=24, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(8, activation="relu"),
            keras.layers.Dense(2),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="batch",
        verbose=2,
        seed=123,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    history = model.fit(
        loader,
        validation_data=loader,
        epochs=1,
        callbacks=[roulette_cb],
        verbose=1,
    )
    assert "loss" in history.history
    assert any(key.startswith("optiroulette_") for key in history.history.keys())


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_verbose_one_prints_only_active_optimizer(capsys):
    x = torch.randn(96, 8)
    y = torch.randint(0, 2, (96,))
    loader = DataLoader(TensorDataset(x, y), batch_size=24, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(8, activation="relu"),
            keras.layers.Dense(2),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="batch",
        switch_every_steps=1,
        switch_probability=1.0,
        avoid_repeat=True,
        verbose=1,
        track_logs=True,
        seed=321,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    history = model.fit(
        loader,
        validation_data=loader,
        epochs=1,
        callbacks=[roulette_cb],
        verbose=0,
    )

    out = capsys.readouterr().out
    assert "active_optimizer=" in out
    assert not any(key.startswith("optiroulette_") for key in history.history.keys())


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_supports_external_torch_optimizers():
    x = torch.randn(128, 8)
    y = torch.randint(0, 3, (128,))
    loader = DataLoader(TensorDataset(x, y), batch_size=32, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(16, activation="relu"),
            keras.layers.Dense(3),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "ranger": {
                "lr": 1e-3,
                "betas": (0.95, 0.999),
                "alpha": 0.5,
                "k": 5,
                "N_sma_threshold": 5,
                "eps": 1e-5,
            },
            "adan": {
                "lr": 1e-3,
                "betas": (0.98, 0.92, 0.99),
            },
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="batch",
        switch_every_steps=1,
        switch_probability=1.0,
        avoid_repeat=True,
        seed=99,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    history = model.fit(
        loader,
        validation_data=loader,
        epochs=1,
        callbacks=[roulette_cb],
        verbose=0,
    )

    assert "loss" in history.history
    assert set(controller.optimizers.keys()) == {"ranger", "adan"}


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_create_fit_callback_alias_matches_new_name():
    controller_new, callback_new = create_roulette_callback(
        optimizer_specs={"adam": {"learning_rate": 1e-3}},
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        seed=123,
        verbose=0,
    )
    controller_old, callback_old = create_fit_callback(
        optimizer_specs={"adam": {"learning_rate": 1e-3}},
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        seed=123,
        verbose=0,
    )

    assert type(controller_new) is type(controller_old)
    assert type(callback_new) is type(callback_old)
    assert controller_new.active_optimizer_name == controller_old.active_optimizer_name


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_fit_callback_builds_optimizers_lazily():
    x = torch.randn(96, 8)
    y = torch.randint(0, 2, (96,))
    loader = DataLoader(TensorDataset(x, y), batch_size=24, shuffle=False)

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(8, activation="relu"),
            keras.layers.Dense(2),
        ]
    )

    controller, roulette_cb = create_roulette_callback(
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        roulette={"warmup_epochs": 0, "warmup_optimizer": None, "warmup_config": {}},
        switch_granularity="batch",
        switch_probability=0.0,
        seed=123,
    )

    model.compile(
        optimizer=controller.active_optimizer,
        loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=["accuracy"],
    )
    model.fit(loader, epochs=1, callbacks=[roulette_cb], verbose=0)

    adam = controller.optimizers["adam"]
    sgd = controller.optimizers["sgd"]
    assert getattr(adam, "_torch_optimizer", None) is not None
    assert getattr(sgd, "_torch_optimizer", None) is None
