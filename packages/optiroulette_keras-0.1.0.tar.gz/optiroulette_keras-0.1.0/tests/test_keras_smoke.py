import os

os.environ.setdefault("KERAS_BACKEND", "torch")

import pytest

keras = pytest.importorskip("keras")
torch = pytest.importorskip("torch")

from optiroulette_keras import OptiRoulette


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_custom_smoke_apply_gradients():
    model = keras.Sequential(
        [
            keras.layers.Input(shape=(8,)),
            keras.layers.Dense(2),
        ]
    )

    optimizer = OptiRoulette(
        model.trainable_variables,
        optimizer_specs={
            "adam": {"learning_rate": 1e-3},
            "sgd": {"learning_rate": 1e-2, "momentum": 0.9},
        },
        switch_granularity="batch",
        switch_every_steps=1,
        switch_probability=1.0,
        avoid_repeat=True,
    )

    optimizer.on_epoch_start(0)
    optimizer.on_batch_start(0)

    grads_and_vars = []
    for var in model.trainable_variables:
        grads_and_vars.append((torch.randn_like(var.value), var))

    optimizer.apply_gradients(grads_and_vars)

    assert optimizer.step_count == 1
    assert optimizer.active_optimizer_name in {"adam", "sgd"}


@pytest.mark.skipif(
    keras.config.backend() != "torch",
    reason="requires Keras torch backend",
)
def test_default_profile_instantiates():
    model = keras.Sequential([keras.layers.Input(shape=(4,)), keras.layers.Dense(2)])
    optimizer = OptiRoulette(model.trainable_variables)
    assert optimizer.active_optimizer_name in optimizer.optimizers
    assert "ranger" in optimizer.optimizers
    assert "adan" in optimizer.optimizers
