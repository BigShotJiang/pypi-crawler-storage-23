"""Compatibility alias for capitalized module imports."""

from optiroulette_keras import *  # noqa: F401,F403
