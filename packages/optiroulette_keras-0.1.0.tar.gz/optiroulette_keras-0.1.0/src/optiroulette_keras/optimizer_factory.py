"""Utility functions to create Keras and external torch optimizers dynamically."""
from __future__ import annotations

import importlib
import inspect
from typing import Any, Dict, Iterable

import torch

from .backend import ensure_torch_backend

_KERAS_OPTIMIZER_CLASSES: Dict[str, type] | None = None
_TORCH_OPTIMIZER_CLASSES: Dict[str, type] | None = None
_TORCH_OPT = None
_TORCH_OPT_LOADED = False
_KERAS_ADAPTER_KWARGS = {
    "clipnorm",
    "clipvalue",
    "global_clipnorm",
    "use_ema",
    "ema_momentum",
    "ema_overwrite_frequency",
    "loss_scale_factor",
    "gradient_accumulation_steps",
    "name",
}


class UnsupportedOptimizerError(ValueError):
    """Raised when an optimizer cannot be resolved for the active backend."""


def _normalize_optimizer_cfg(cfg: Dict[str, Any] | None) -> Dict[str, Any]:
    normalized = dict(cfg or {})
    if "betas" in normalized and isinstance(normalized["betas"], list):
        normalized["betas"] = tuple(normalized["betas"])
    if "nus" in normalized and isinstance(normalized["nus"], list):
        normalized["nus"] = tuple(normalized["nus"])
    return normalized


def _normalize_keras_cfg(name: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(cfg)
    if "lr" in normalized and "learning_rate" not in normalized:
        normalized["learning_rate"] = normalized["lr"]
    if "betas" in normalized and isinstance(normalized["betas"], tuple):
        if len(normalized["betas"]) >= 2:
            normalized.setdefault("beta_1", normalized["betas"][0])
            normalized.setdefault("beta_2", normalized["betas"][1])
        normalized.pop("betas", None)
    if "alpha" in normalized and "rho" not in normalized:
        normalized["rho"] = normalized["alpha"]
    if str(name).lower() == "amsgrad":
        normalized["amsgrad"] = True
    normalized.pop("lr", None)
    normalized.pop("alpha", None)
    normalized.pop("N_sma_threshold", None)
    return normalized


def _normalize_torch_cfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(cfg)
    if "learning_rate" in normalized and "lr" not in normalized:
        normalized["lr"] = normalized.pop("learning_rate")
    if "beta_1" in normalized and "beta_2" in normalized and "betas" not in normalized:
        normalized["betas"] = (normalized.pop("beta_1"), normalized.pop("beta_2"))
    if "rho" in normalized and "alpha" not in normalized:
        normalized["alpha"] = normalized["rho"]
    if "N_sma_threshold" in normalized and "n_sma_threshold" not in normalized:
        normalized["n_sma_threshold"] = normalized.pop("N_sma_threshold")
    return normalized


def _filter_supported_kwargs(cls: type, cfg: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(cls.__init__)
    except (TypeError, ValueError):
        return dict(cfg)

    params = sig.parameters
    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return dict(cfg)

    accepted = set(params.keys()) - {"self", "args", "kwargs"}
    return {k: v for k, v in cfg.items() if k in accepted}


def _canonical_optimizer_name(name: str) -> str:
    key = str(name).lower()
    aliases = {
        "amsgrad": "adam",
    }
    return aliases.get(key, key)


def _build_keras_optimizer_dict() -> Dict[str, type]:
    ensure_torch_backend()
    keras = importlib.import_module("keras")

    classes: Dict[str, type] = {}
    optimizer_base = keras.optimizers.Optimizer
    for name in dir(keras.optimizers):
        cls = getattr(keras.optimizers, name)
        if inspect.isclass(cls) and issubclass(cls, optimizer_base):
            classes[name.lower()] = cls
    return classes


def _get_torch_optimizer_module(force_reload: bool = False):
    global _TORCH_OPT, _TORCH_OPT_LOADED
    if force_reload:
        _TORCH_OPT = None
        _TORCH_OPT_LOADED = False
    if not _TORCH_OPT_LOADED:
        try:
            _TORCH_OPT = importlib.import_module("pytorch_optimizer")
        except ImportError:
            _TORCH_OPT = None
        _TORCH_OPT_LOADED = True
    return _TORCH_OPT


def _build_torch_optimizer_dict() -> Dict[str, type]:
    classes: Dict[str, type] = {}

    modules = [torch.optim]
    torch_opt = _get_torch_optimizer_module()
    if torch_opt is not None:
        modules.append(torch_opt)

    for module in modules:
        for name, cls in module.__dict__.items():
            if inspect.isclass(cls) and issubclass(cls, torch.optim.Optimizer):
                classes[name.lower()] = cls
    return classes


def _get_keras_optimizer_class(name: str) -> type:
    global _KERAS_OPTIMIZER_CLASSES
    if _KERAS_OPTIMIZER_CLASSES is None:
        _KERAS_OPTIMIZER_CLASSES = _build_keras_optimizer_dict()

    key = _canonical_optimizer_name(name)
    if key not in _KERAS_OPTIMIZER_CLASSES:
        raise UnsupportedOptimizerError(
            f"Unknown Keras optimizer: {name}. Supported: {sorted(_KERAS_OPTIMIZER_CLASSES.keys())}"
        )
    return _KERAS_OPTIMIZER_CLASSES[key]


def _get_torch_optimizer_class(name: str) -> type:
    global _TORCH_OPTIMIZER_CLASSES
    if _TORCH_OPTIMIZER_CLASSES is None:
        _TORCH_OPTIMIZER_CLASSES = _build_torch_optimizer_dict()

    key = str(name).lower()
    if key == "amsgrad":
        key = "adam"
    if key not in _TORCH_OPTIMIZER_CLASSES:
        if _get_torch_optimizer_module(force_reload=True) is not None:
            _TORCH_OPTIMIZER_CLASSES = _build_torch_optimizer_dict()
        if key in (_TORCH_OPTIMIZER_CLASSES or {}):
            return _TORCH_OPTIMIZER_CLASSES[key]
        if _get_torch_optimizer_module() is None:
            raise UnsupportedOptimizerError(
                f"Unknown optimizer: {name}. Install 'pytorch-optimizer' for advanced optimizers."
            )
        raise UnsupportedOptimizerError(f"Unknown optimizer: {name}")
    return _TORCH_OPTIMIZER_CLASSES[key]


def list_supported_optimizers() -> Iterable[str]:
    """Return supported optimizer names from Keras + pytorch-optimizer."""
    names = set()
    try:
        names.update(_build_keras_optimizer_dict().keys())
    except Exception:
        pass
    try:
        names.update(_build_torch_optimizer_dict().keys())
    except Exception:
        pass
    names.add("amsgrad")
    return sorted(names)


def is_optimizer_supported(name: str) -> bool:
    """Return ``True`` when optimizer name resolves in Keras or torch adapter."""
    return str(name).lower() in set(list_supported_optimizers())


def create_optimizer(name: str, cfg: Dict[str, Any] | None = None):
    """Instantiate optimizer by name using Keras or torch external adapter."""
    ensure_torch_backend()
    normalized_cfg = _normalize_optimizer_cfg(cfg)

    try:
        torch_cls = _get_torch_optimizer_class(name)
        torch_cfg = _normalize_torch_cfg(normalized_cfg)
        if str(name).lower() == "amsgrad":
            torch_cfg["amsgrad"] = True

        adapter_kwargs: Dict[str, Any] = {}
        for key in list(torch_cfg.keys()):
            if key in _KERAS_ADAPTER_KWARGS:
                adapter_kwargs[key] = torch_cfg.pop(key)
        if "lr" in torch_cfg:
            adapter_kwargs.setdefault("learning_rate", torch_cfg["lr"])

        from .torch_external_optimizer import TorchExternalOptimizer

        return TorchExternalOptimizer(
            torch_cls,
            optimizer_name=str(name).lower(),
            optimizer_cfg=torch_cfg,
            **adapter_kwargs,
        )
    except UnsupportedOptimizerError:
        pass

    keras_cls = _get_keras_optimizer_class(name)
    keras_cfg = _normalize_keras_cfg(name, normalized_cfg)
    filtered_cfg = _filter_supported_kwargs(keras_cls, keras_cfg)
    return keras_cls(**filtered_cfg)
