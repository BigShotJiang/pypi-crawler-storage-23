"""Backend guards for Keras runtime behavior."""
from __future__ import annotations

import importlib
import os


def get_backend_name() -> str:
    """Return the active Keras backend name."""
    keras = importlib.import_module("keras")
    return str(keras.config.backend())


def ensure_torch_backend() -> None:
    """Raise when Keras is not configured to use the PyTorch backend."""
    backend = get_backend_name()
    if backend == "torch":
        return

    requested = os.environ.get("KERAS_BACKEND")
    requested_hint = (
        f"KERAS_BACKEND is currently {requested!r}."
        if requested is not None
        else "KERAS_BACKEND is not set."
    )
    raise RuntimeError(
        "OptiRoulette-Keras currently supports only the PyTorch backend. "
        "Set KERAS_BACKEND=torch before importing keras. "
        f"Active backend: {backend!r}. {requested_hint}"
    )
