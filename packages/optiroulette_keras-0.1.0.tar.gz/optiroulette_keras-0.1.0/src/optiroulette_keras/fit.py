"""model.fit integration for OptiRoulette-Keras (torch backend)."""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Tuple

from .backend import ensure_torch_backend
from .opti_roulette import OptiRoulette, OptiRouletteOptimizer


class _BaseCallback:
    """Backend-agnostic callback base compatible with Keras callback hooks."""

    model: Any
    params: Dict[str, Any]

    def set_model(self, model: Any) -> None:
        self.model = model

    def set_params(self, params: Dict[str, Any]) -> None:
        self.params = params

    def on_train_begin(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_train_end(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_epoch_begin(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del epoch, logs

    def on_epoch_end(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del epoch, logs

    def on_train_batch_begin(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs

    def on_train_batch_end(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs

    def on_test_begin(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_test_end(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_test_batch_begin(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs

    def on_test_batch_end(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs

    def on_predict_begin(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_predict_end(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs

    def on_predict_batch_begin(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs

    def on_predict_batch_end(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs


class OptiRouletteCallback(_BaseCallback):
    """Keras callback that applies OptiRoulette optimizer switching."""

    def __init__(
        self,
        controller: OptiRouletteOptimizer,
        *,
        verbose: int = 0,
        track_logs: Optional[bool] = None,
        val_acc_key: str = "auto",
    ) -> None:
        ensure_torch_backend()
        self.controller = controller
        self.verbose = int(verbose)
        # Verbose policy:
        # 0 -> no OptiRoulette output
        # 1 -> print only active optimizer
        # 2 -> include detailed OptiRoulette metrics in model.fit logs/progbar
        if track_logs is None:
            self.track_logs = self.verbose >= 2
        else:
            self.track_logs = bool(track_logs)
        self.val_acc_key = str(val_acc_key)
        self._last_optimizer_name: Optional[str] = None
        self._last_announced_name: Optional[str] = None
        self._optimizer_index = {
            name: idx for idx, name in enumerate(controller.optimizers.keys())
        }

    def _maybe_print(self, message: str) -> None:
        if self.verbose > 0:
            print(f"[OptiRoulette] {message}")

    def _maybe_print_active_optimizer(self, *, force: bool = False) -> None:
        if self.verbose != 1:
            return
        name = self.controller.active_optimizer_name
        if force or name != self._last_announced_name:
            self._last_announced_name = name
            self._maybe_print(f"active_optimizer={name}")

    def _sync_model_optimizer(self, *, reason: str) -> None:
        name = self.controller.active_optimizer_name
        optimizer = self.controller.active_optimizer

        current_model_opt = getattr(self.model, "optimizer", None)
        if (
            self._last_optimizer_name == name
            and current_model_opt is optimizer
        ):
            return

        self.model.optimizer = optimizer
        self._last_optimizer_name = name
        if self.verbose >= 2:
            self._maybe_print(f"{reason}: {name}")

    def _extract_val_acc(self, logs: Optional[Dict[str, Any]]) -> Optional[float]:
        if not logs:
            return None

        if self.val_acc_key != "auto":
            value = logs.get(self.val_acc_key)
            if value is None:
                return None
            return float(value)

        preferred = [
            "val_accuracy",
            "val_acc",
            "val_sparse_categorical_accuracy",
            "val_categorical_accuracy",
        ]
        for key in preferred:
            value = logs.get(key)
            if value is not None:
                return float(value)

        for key, value in logs.items():
            key_lower = str(key).lower()
            if key_lower.startswith("val_") and "acc" in key_lower and value is not None:
                return float(value)
        return None

    def on_train_begin(self, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs
        trainable_variables = getattr(self.model, "trainable_variables", None)
        if trainable_variables is not None:
            self.controller.build(trainable_variables)
        self._sync_model_optimizer(reason="train_begin")

    def on_epoch_begin(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs
        self.controller.reset_epoch_stats()
        self.controller.on_epoch_start(epoch)
        self._sync_model_optimizer(reason=f"epoch_{epoch + 1}_begin")
        self._maybe_print_active_optimizer(force=True)

    def on_train_batch_begin(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del logs
        self.controller.on_batch_start(batch)
        self._sync_model_optimizer(reason=f"batch_{batch}")
        self._maybe_print_active_optimizer()

    def on_train_batch_end(self, batch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        del batch, logs
        # model.fit executes optimizer steps internally, so we advance roulette
        # counters here to keep switch_every_steps semantics intact.
        self.controller.notify_step_end()

    def on_epoch_end(self, epoch: int, logs: Optional[Dict[str, Any]] = None) -> None:
        val_acc = self._extract_val_acc(logs)
        self.controller.on_epoch_end(val_acc=val_acc)
        self._sync_model_optimizer(reason=f"epoch_{epoch + 1}_end")

        if self.track_logs and self.verbose >= 2 and logs is not None:
            active_name = self.controller.active_optimizer_name
            logs["optiroulette_active_index"] = float(
                self._optimizer_index.get(active_name, -1)
            )
            logs["optiroulette_switch_count"] = float(len(self.controller.switch_history))
            for name, count in self.controller.get_epoch_selection_counts().items():
                logs[f"optiroulette_count_{name}"] = float(count)


def create_roulette_callback(
    trainable_variables: Optional[Iterable[Any]] = None,
    *,
    optimizer_specs: Optional[Any] = None,
    optimizers: Optional[Dict[str, Any]] = None,
    roulette: Optional[Dict[str, Any]] = None,
    pool_config: Optional[Any] = None,
    lr_scaling_rules: Optional[Dict[str, Any]] = None,
    active_names: Optional[list[str]] = None,
    backup_names: Optional[list[str]] = None,
    switch_granularity: Optional[str] = None,
    switch_every_steps: Optional[int] = None,
    switch_probability: Optional[float] = None,
    avoid_repeat: Optional[bool] = None,
    warmup_optimizer: Optional[str] = None,
    drop_after_warmup: bool = False,
    warmup_epochs: int = 0,
    warmup_config: Optional[Dict[str, Any]] = None,
    seed: Optional[int] = None,
    logger: Optional[Any] = None,
    verbose: int = 0,
    track_logs: Optional[bool] = None,
    val_acc_key: str = "auto",
) -> Tuple[OptiRoulette, OptiRouletteCallback]:
    """Build controller + callback pair for ``model.compile``/``model.fit`` usage."""
    controller = OptiRoulette(
        trainable_variables=trainable_variables,
        optimizer_specs=optimizer_specs,
        optimizers=optimizers,
        roulette=roulette,
        pool_config=pool_config,
        lr_scaling_rules=lr_scaling_rules,
        active_names=active_names,
        backup_names=backup_names,
        switch_granularity=switch_granularity,
        switch_every_steps=switch_every_steps,
        switch_probability=switch_probability,
        avoid_repeat=avoid_repeat,
        warmup_optimizer=warmup_optimizer,
        drop_after_warmup=drop_after_warmup,
        warmup_epochs=warmup_epochs,
        warmup_config=warmup_config,
        seed=seed,
        logger=logger,
    )
    callback = OptiRouletteCallback(
        controller,
        verbose=verbose,
        track_logs=track_logs,
        val_acc_key=val_acc_key,
    )
    return controller, callback


class OptiRouletteFitCallback(OptiRouletteCallback):
    """Backward-compatible alias for ``OptiRouletteCallback``."""


def create_fit_callback(
    trainable_variables: Optional[Iterable[Any]] = None,
    *,
    optimizer_specs: Optional[Any] = None,
    optimizers: Optional[Dict[str, Any]] = None,
    roulette: Optional[Dict[str, Any]] = None,
    pool_config: Optional[Any] = None,
    lr_scaling_rules: Optional[Dict[str, Any]] = None,
    active_names: Optional[list[str]] = None,
    backup_names: Optional[list[str]] = None,
    switch_granularity: Optional[str] = None,
    switch_every_steps: Optional[int] = None,
    switch_probability: Optional[float] = None,
    avoid_repeat: Optional[bool] = None,
    warmup_optimizer: Optional[str] = None,
    drop_after_warmup: bool = False,
    warmup_epochs: int = 0,
    warmup_config: Optional[Dict[str, Any]] = None,
    seed: Optional[int] = None,
    logger: Optional[Any] = None,
    verbose: int = 0,
    track_logs: Optional[bool] = None,
    val_acc_key: str = "auto",
) -> Tuple[OptiRoulette, OptiRouletteCallback]:
    """Backward-compatible alias for ``create_roulette_callback``."""
    return create_roulette_callback(
        trainable_variables=trainable_variables,
        optimizer_specs=optimizer_specs,
        optimizers=optimizers,
        roulette=roulette,
        pool_config=pool_config,
        lr_scaling_rules=lr_scaling_rules,
        active_names=active_names,
        backup_names=backup_names,
        switch_granularity=switch_granularity,
        switch_every_steps=switch_every_steps,
        switch_probability=switch_probability,
        avoid_repeat=avoid_repeat,
        warmup_optimizer=warmup_optimizer,
        drop_after_warmup=drop_after_warmup,
        warmup_epochs=warmup_epochs,
        warmup_config=warmup_config,
        seed=seed,
        logger=logger,
        verbose=verbose,
        track_logs=track_logs,
        val_acc_key=val_acc_key,
    )
