"""Package resources for OptiRoulette-Keras."""
