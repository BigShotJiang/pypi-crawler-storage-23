from .core import EasyHTTPAsync
from .wrapper import EasyHTTP

__version__ = "0.3.3"
__author__ = "slpuk"
__all__ = [
    "EasyHTTPAsync",
    "EasyHTTP"
]