"""MCP server setup and configuration."""

import json
from dataclasses import dataclass

from mcp.server import Server
from mcp.types import Resource, TextContent

from maeris_mcp.schemas.registry import SchemaRegistry
from maeris_mcp.storage.api_store import APIStore
from maeris_mcp.storage.security_store import SecurityScanStore
from maeris_mcp.tools.api_tools import (
    clear_stored_apis_tool,
    get_stored_apis_tool,
    handle_clear_stored_apis,
    handle_get_stored_apis,
)
from maeris_mcp.tools.api_scan import api_scan_tool, handle_api_scan
from maeris_mcp.tools.get_schema import get_extraction_schema_tool, handle_get_extraction_schema
from maeris_mcp.tools.maeris_sync import handle_push_to_maeris, push_to_maeris_tool
from maeris_mcp.tools.process_data import handle_process_extracted_data, process_extracted_data_tool
from maeris_mcp.tools.security_scan import (
    clear_security_scans_tool,
    list_security_checks_tool,
    get_security_scans_tool,
    handle_clear_security_scans,
    handle_list_security_checks,
    handle_get_security_scans,
    handle_security_scan,
    security_scan_tool,
)


@dataclass
class ServerConfig:
    """Server configuration."""

    name: str = "maeris"
    version: str = "1.0.0"


def create_server(config: ServerConfig | None = None) -> Server:
    """Create and configure the MCP server."""
    config = config or ServerConfig()

    server = Server(config.name)

    # Initialize dependencies
    registry = SchemaRegistry()
    api_store = APIStore()
    security_store = SecurityScanStore()

    # Register tools
    _register_tools(server, registry, api_store, security_store)

    # Register resources
    _register_resources(server, registry)

    return server


def _register_tools(
    server: Server,
    registry: SchemaRegistry,
    api_store: APIStore,
    security_store: SecurityScanStore,
) -> None:
    """Register all tools with the server."""

    # List all tools
    @server.list_tools()
    async def list_tools():
        return [
            get_extraction_schema_tool(),
            process_extracted_data_tool(),
            get_stored_apis_tool(),
            clear_stored_apis_tool(),
            push_to_maeris_tool(),
            list_security_checks_tool(),
            security_scan_tool(),
            get_security_scans_tool(),
            clear_security_scans_tool(),
            api_scan_tool(),
        ]

    # Handle tool calls
    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        match name:
            case "get_extraction_schema":
                return await handle_get_extraction_schema(registry, arguments)
            case "process_extracted_data":
                return await handle_process_extracted_data(registry, api_store, arguments)
            case "get_stored_apis":
                return await handle_get_stored_apis(api_store, arguments)
            case "clear_stored_apis":
                return await handle_clear_stored_apis(api_store, arguments)
            case "push_to_maeris":
                return await handle_push_to_maeris(api_store, security_store, arguments)
            case "list_security_checks":
                return await handle_list_security_checks(arguments)
            case "security_scan":
                return await handle_security_scan(security_store, arguments)
            case "get_security_scans":
                return await handle_get_security_scans(security_store, arguments)
            case "clear_security_scans":
                return await handle_clear_security_scans(security_store, arguments)
            case "api_scan":
                return await handle_api_scan(api_store, arguments)
            case _:
                return [TextContent(type="text", text=f"Unknown tool: {name}")]


def _register_resources(server: Server, registry: SchemaRegistry) -> None:
    """Register schema resources with the server."""

    resource_configs = [
        ("schema://react/component", "React Component Schema", "react-component-v1"),
        ("schema://react/project", "React Project Schema", "react-project-v1"),
        ("schema://react/search", "React Search Schema", "react-search-v1"),
        ("schema://frontend/api", "Frontend API Schema", "frontend-api-v1"),
    ]

    @server.list_resources()
    async def list_resources():
        resources = []
        for uri, name, schema_id in resource_configs:
            schema = registry.get(schema_id)
            if schema:
                resources.append(
                    Resource(
                        uri=uri,
                        name=name,
                        description=f"JSON Schema for {schema.description}",
                        mimeType="application/schema+json",
                    )
                )
        return resources

    @server.read_resource()
    async def read_resource(uri: str):
        for res_uri, name, schema_id in resource_configs:
            if uri == res_uri:
                schema = registry.get(schema_id)
                if schema:
                    return json.dumps(schema.json_schema, indent=2)
        return f"Resource not found: {uri}"
