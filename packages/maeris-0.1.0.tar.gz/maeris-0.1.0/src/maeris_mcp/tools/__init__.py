"""MCP tools for the Maeris server."""
