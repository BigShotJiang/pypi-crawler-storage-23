"""CLI commands for Maeris MCP."""

import hashlib
import json
import os
import sys
from pathlib import Path

# Force UTF-8 output on Windows (avoids CP1252 UnicodeEncodeError for checkmarks, arrows, etc.)
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import click
import structlog

from maeris_mcp.auth.oauth import AuthenticationError, OAuthFlow
from maeris_mcp.auth.token_store import TokenStore

logger = structlog.get_logger(__name__)


# Load .env file if it exists (for development)
def load_env_file() -> None:
    """Load environment variables from .env file if present."""
    try:
        from dotenv import load_dotenv

        # Try multiple locations for .env file
        locations = [
            Path.cwd() / ".env",  # Current working directory
            Path.home() / ".maeris" / ".env",  # User home config
            Path(__file__).parent.parent.parent.parent / ".env",  # Project root
        ]

        for env_path in locations:
            if env_path.exists():
                load_dotenv(env_path, override=False)  # Don't override existing env vars
                break
    except ImportError:
        # python-dotenv not installed, skip
        pass


# Load .env on module import
load_env_file()


def _repo_config_dir(repo_path: Path | None = None) -> Path:
    """Return the credentials directory for the current (or given) repo path.

    Credentials are stored at ~/.maeris/repos/<hash>/ where <hash> is derived
    from the absolute repo path, keeping credentials off-disk from the repo.
    """
    path = repo_path or Path.cwd()
    repo_hash = hashlib.sha256(str(path.resolve()).encode()).hexdigest()[:16]
    return Path.home() / ".maeris" / "repos" / repo_hash


_LEGACY_SERVER_NAMES = {"maeris-security", "maeris-mcp"}


def _write_mcp_json(config_dir: Path) -> None:
    """Write (or update) .mcp.json in the current directory.

    Sets MAERIS_CONFIG_DIR so the MCP server process loads the correct
    repo-specific credentials at runtime. Removes any legacy server entries
    (e.g. maeris-security, maeris) to avoid duplicate servers.
    """
    mcp_json_path = Path.cwd() / ".mcp.json"
    config = json.loads(mcp_json_path.read_text()) if mcp_json_path.exists() else {}
    servers = config.setdefault("mcpServers", {})

    # Remove stale entries from previous installs
    for legacy in _LEGACY_SERVER_NAMES:
        servers.pop(legacy, None)

    servers["maeris"] = {
        "command": "maeris",
        "args": ["serve"],
        "env": {
            "MAERIS_CONFIG_DIR": str(config_dir),
        },
    }
    mcp_json_path.write_text(json.dumps(config, indent=2))


@click.group()
@click.version_option(version="1.0.0", prog_name="maeris")
def cli() -> None:
    """Maeris MCP - Security and API scanning for your codebase.

    \b
    Quick Start (run from your project root):
      1. maeris init     # Register the MCP server for this repo
      2. Restart Claude Code
      3. Ask Claude to scan your code for security vulnerabilities or API calls

    \b
    Optional:
      maeris login       # Authenticate for features that require an account
    """
    pass


@cli.command()
def init() -> None:
    """Register the MCP server for the current repository.

    Writes .mcp.json to the current directory so Claude Code runs the
    MCP server automatically. No authentication required — security and
    API scans work immediately after restarting Claude Code.

    \b
    To access features that require an account, run 'maeris login'
    after initialising.
    """
    config_dir = _repo_config_dir()
    mcp_json_path = Path.cwd() / ".mcp.json"
    is_new = not mcp_json_path.exists()

    _write_mcp_json(config_dir)

    click.secho("✓ .mcp.json written", fg="green")
    click.echo(f"  Location: {mcp_json_path}")
    click.echo()

    if is_new:
        click.echo("  Restart Claude Code to activate the MCP server.")
    else:
        click.echo("  MCP config updated — restart Claude Code if not already running.")

    click.echo()
    click.echo("  To access authenticated features, run 'maeris login'.")


@cli.command()
@click.option(
    "--token",
    help="Provide Firebase ID token directly (skip browser OAuth)",
    envvar="MAERIS_TOKEN",
)
def login(token: str | None) -> None:
    """Authenticate with Maeris Portal for the current repository.

    Credentials are stored per-repo (keyed by the current directory) so
    each project is fully isolated. Run this from your project root.
    """
    config_dir = _repo_config_dir()
    token_store = TokenStore(config_dir=config_dir)

    mcp_json_exists = (Path.cwd() / ".mcp.json").exists()

    if token:
        # Direct token input (for testing or CI/CD)
        click.echo("Validating token...")
        try:
            token_store.save_token(token)
            _write_mcp_json(config_dir)
            _show_login_success(token_store, not mcp_json_exists)
        except Exception as e:
            click.secho(f"✗ Invalid token: {e}", fg="red")
            sys.exit(1)
    else:
        # Browser OAuth flow
        app_url = os.getenv("MAERIS_APP_URL", "https://autoe-light-dev.up.railway.app")

        click.echo("Authenticating with Maeris Portal...")
        click.echo(f"  Browser will open to: {app_url}\n")

        oauth = OAuthFlow(app_url=app_url)
        try:
            token_data = oauth.authenticate()
            token_store.save_token(
                access_token=token_data["access_token"],
                token_type=token_data.get("token_type", "Bearer"),
            )
            _write_mcp_json(config_dir)
            _show_login_success(token_store, not mcp_json_exists)
        except TimeoutError:
            click.secho(
                "✗ Authentication timeout. Please try again.",
                fg="red",
            )
            sys.exit(1)
        except AuthenticationError as e:
            click.secho(f"✗ Authentication failed: {e}", fg="red")
            sys.exit(1)
        except Exception as e:
            logger.error("authentication_error", error=str(e), exc_info=True)
            click.secho(f"✗ Unexpected error: {e}", fg="red")
            sys.exit(1)


def _show_login_success(token_store: TokenStore, is_first_login: bool = True) -> None:
    """Display successful login message with user info."""
    click.secho("\n✓ Authentication successful!", fg="green")

    email = token_store.get_email()
    app_name = token_store.get_app_name()
    app_id = token_store.get_app_id()

    if email:
        click.echo(f"  Email: {email}")

    if app_name:
        click.secho(f"  Active app: {app_name}", fg="cyan")
    elif app_id:
        click.secho(f"  Active app: {app_id}", fg="cyan")
    else:
        click.secho("  ⚠ No application linked to this account.", fg="yellow")

    if is_first_login:
        click.echo("\n  .mcp.json written — restart Claude Code to activate.")
    else:
        click.echo("\n  Credentials updated — no restart needed.")


@cli.command()
def logout() -> None:
    """Sign out and remove stored credentials for the current repository."""
    config_dir = _repo_config_dir()
    token_store = TokenStore(config_dir=config_dir)

    if not token_store.is_authenticated():
        click.echo("Not currently authenticated for this repository.")
        return

    token_store.clear()
    click.secho("✓ Signed out successfully", fg="green")
    click.echo(f"  Credentials removed from {config_dir}")


@cli.command()
def status() -> None:
    """Show authentication status for the current repository."""
    config_dir = _repo_config_dir()
    token_store = TokenStore(config_dir=config_dir)

    if not token_store.is_authenticated():
        click.secho("Not authenticated for this repository.", fg="yellow")
        click.echo("\nRun 'maeris login' from your project root to authenticate.")
        return

    if token_store.is_token_expired():
        click.secho("⚠ Token expired", fg="yellow")
        click.echo("Run 'maeris login' to re-authenticate.")
        return

    email = token_store.get_email()
    app_name = token_store.get_app_name()

    click.secho("✓ Authenticated", fg="green")
    click.echo()

    if email:
        click.echo(f"  Email:       {email}")
    if app_name:
        click.echo(f"  Active app:  {app_name}")

    click.echo(f"  Credentials: {token_store.credentials_file}")


@cli.command("switch-app")
def switch_app() -> None:
    """Switch the active application for the current repository.

    Fetches the list of applications from Maeris and lets you choose
    which one to use. The selected app ID is saved to credentials so
    all subsequent pushes target the correct application.
    """
    import asyncio

    config_dir = _repo_config_dir()
    token_store = TokenStore(config_dir=config_dir)

    if not token_store.is_authenticated():
        click.secho("✗ Not authenticated. Run 'maeris login' first.", fg="red")
        sys.exit(1)

    if token_store.is_token_expired():
        click.secho("✗ Token expired. Run 'maeris login' to re-authenticate.", fg="red")
        sys.exit(1)

    click.echo("Fetching applications...")

    async def _fetch() -> list[dict]:
        from maeris_mcp.maeris.client import MaerisClient
        token_data = token_store.get_token_data() or {}
        async with MaerisClient(
            token=token_data.get("access_token"),
            user_id=token_data.get("user_id"),
        ) as client:
            return await client.get_applications()

    try:
        apps = asyncio.run(_fetch())
    except Exception as e:
        click.secho(f"✗ Failed to fetch applications: {e}", fg="red")
        sys.exit(1)

    if not apps:
        click.secho("✗ No applications found for your account.", fg="yellow")
        sys.exit(1)

    # Display numbered list
    click.echo()
    current_app_id = token_store.get_app_id()
    for i, app in enumerate(apps, 1):
        app_id = app.get("appid", "")
        app_name = app.get("name") or app_id
        marker = " (current)" if app_id == current_app_id else ""
        click.echo(f"  {i}) {app_name}{click.style(marker, fg='cyan')}")

    click.echo()

    # Prompt: accept a number or an app name
    try:
        raw = click.prompt("Select application (number or name)").strip()
    except click.Abort:
        click.echo("\nAborted.")
        sys.exit(0)

    selected = None
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(apps):
            selected = apps[idx]
        else:
            click.secho(f"✗ Number out of range. Enter 1-{len(apps)}.", fg="red")
            sys.exit(1)
    else:
        needle = raw.lower()
        selected = next(
            (a for a in apps if (a.get("name") or "").lower() == needle), None
        ) or next(
            (a for a in apps if (a.get("name") or "").lower().startswith(needle)), None
        )
        if not selected:
            click.secho(f"✗ No application matching '{raw}'.", fg="red")
            sys.exit(1)

    app_id = selected.get("appid", "")
    app_name = selected.get("name") or app_id

    if not app_id:
        click.secho("✗ Selected application has no ID.", fg="red")
        click.secho(f"  Raw response: {selected}", fg="yellow")
        sys.exit(1)

    token_store.save_app_id(app_id, app_name)
    click.secho(f"\n✓ Switched to: {app_name}", fg="green")
    click.echo(f"  App ID: {app_id}")


@cli.command()
@click.option("--mode", type=click.Choice(["stdio", "http"]), default="stdio")
@click.option("--port", default=8080, help="HTTP mode port (default: 8080)")
def serve(mode: str, port: int) -> None:
    """Run MCP server.

    \b
    Modes:
      stdio: Standard input/output (default, for Claude CLI)
      http:  HTTP server (for Claude Desktop over HTTP)

    \b
    Examples:
      maeris serve                    # Run in stdio mode
      maeris serve --mode http        # Run HTTP server
      maeris serve --mode http --port 3000
    """
    # Import here to avoid circular dependencies
    from maeris_mcp.main import main

    click.echo(f"Starting Maeris MCP server in {mode} mode...")
    if mode == "http":
        click.echo(f"  Listening on port {port}")

    # Run the MCP server — pass args explicitly so Click doesn't re-parse sys.argv
    args = ["--mode", mode, "--port", str(port)]
    main(args, standalone_mode=True)


if __name__ == "__main__":
    cli()
