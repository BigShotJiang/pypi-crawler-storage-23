"""HTTP client for the Maeris API."""

import os

import structlog
import httpx

from maeris_mcp.maeris.types import (
    CollectionChildItem,
    CreateCollectionRequest,
    MaerisAPI,
    MaerisSecurityFinding,
    MaerisSecurityScan,
)

DEFAULT_BASE_URL = os.getenv("MAERIS_API_URL", "https://mirabilis-dev.up.railway.app")
DEFAULT_TIMEOUT = 30.0
DEFAULT_SECURITY_SCAN_PATH = os.getenv("MAERIS_SECURITY_SCAN_PATH", "/security/scans")
DEFAULT_SECURITY_FINDINGS_PATH = os.getenv(
    "MAERIS_SECURITY_FINDINGS_PATH",
    "/security/findings",
)

logger = structlog.get_logger()


class AuthenticationError(Exception):
    """Raised when authentication fails or token is invalid."""

    pass


class MaerisClient:
    """Async HTTP client for the Maeris API."""

    def __init__(
        self,
        base_url: str | None = None,
        token: str | None = None,
        user_id: str | None = None,
    ) -> None:
        """Initialize Maeris API client.

        Credentials are loaded from TokenStore if not provided explicitly.
        Every request sends Authorization, application_id, and autoelight_userId headers.

        Args:
            base_url: Maeris API base URL
            token: Firebase ID token; loaded from TokenStore if omitted
        """
        self.base_url = base_url or DEFAULT_BASE_URL
        self._client = httpx.AsyncClient(timeout=DEFAULT_TIMEOUT)

        stored = self._load_credentials_from_store()
        self.token = token or stored.get("token") or ""
        self.application_id = stored.get("application_id") or ""
        self.user_id = user_id or stored.get("user_id") or ""

    def _load_credentials_from_store(self) -> dict:
        """Load token, application_id, and user_id from TokenStore.

        Respects the MAERIS_CONFIG_DIR env var so that per-repo credentials
        written by 'maeris login' (and referenced via .mcp.json) are used
        instead of any global store.
        """
        try:
            from pathlib import Path

            from maeris_mcp.auth.token_store import TokenStore

            config_dir_env = os.getenv("MAERIS_CONFIG_DIR")
            config_dir = Path(config_dir_env) if config_dir_env else None
            data = TokenStore(config_dir=config_dir).get_token_data() or {}
            return {
                "token": data.get("access_token"),
                "application_id": data.get("app_id"),
                "user_id": data.get("user_id"),
            }
        except ImportError:
            logger.debug("token_store_not_available")
            return {}

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "MaerisClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    def _get_headers(self) -> dict[str, str]:
        """Get common headers for all Maeris API requests."""
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if self.application_id:
            headers["application_id"] = self.application_id
        if self.user_id:
            headers["autoelight_userId"] = self.user_id
        return headers

    async def _make_request(
        self,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        """Make HTTP request with automatic token refresh on 401.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            **kwargs: Additional arguments for httpx request

        Returns:
            HTTP response

        Raises:
            AuthenticationError: If authentication fails
        """
        response = await self._client.request(method, url, **kwargs)

        # Handle 401 Unauthorized - token expired or invalid
        if response.status_code == 401:
            logger.warning("authentication_failed", status=401, url=url)

            # TODO: Implement token refresh flow
            # For now, just raise authentication error
            raise AuthenticationError(
                "Authentication failed. Token may be expired. Run 'maeris login' to re-authenticate."
            )

        return response

    async def get_applications(self) -> list[dict]:
        """Fetch all applications the user has access to."""
        url = f"{self.base_url}/application"
        logger.info("fetching applications", url=url)

        response = await self._make_request("GET", url, headers=self._get_headers())

        if not response.is_success:
            raise Exception(
                f"Get applications failed with status {response.status_code}: {response.text}"
            )

        result = response.json()

        # Handle common response shapes: list or wrapped object
        if isinstance(result, list):
            return result
        for key in ["applications", "data", "results", "items"]:
            if isinstance(result.get(key), list):
                return result[key]

        logger.warning("unexpected applications response shape", result=result)
        return []

    async def create_collection(self, name: str) -> str:
        """Create a new collection in Maeris."""
        url = f"{self.base_url}/api_collection"
        payload = CreateCollectionRequest(name=name, parent_collection_id="")

        logger.info("creating collection", name=name, url=url)

        response = await self._client.post(
            url,
            json=payload.model_dump(by_alias=True),
            headers=self._get_headers(),
        )

        logger.info("collection response", status=response.status_code, body=response.text)

        if not response.is_success:
            raise Exception(
                f"Create collection failed with status {response.status_code}: {response.text}"
            )

        result = response.json()

        # Try to extract ID from response (multiple possible field names)
        for key in ["api_collection_id", "id", "_id", "collection_id"]:
            if collection_id := result.get(key):
                logger.info("collection created", id=collection_id)
                return str(collection_id)

        logger.warning("collection created but no ID in response")
        return ""

    async def create_api(self, api: MaerisAPI) -> str:
        """Create a new API entry in Maeris."""
        url = f"{self.base_url}/apis"

        logger.info("creating API", name=api.name, method=api.type, url=url)
        logger.debug("API payload", payload=api.model_dump())

        response = await self._client.post(
            url,
            json=api.model_dump(by_alias=True),
            headers=self._get_headers(),
        )

        logger.info("API response", status=response.status_code, body=response.text)

        if not response.is_success:
            raise Exception(
                f"Create API failed with status {response.status_code}: {response.text}"
            )

        result = response.json()

        # Try to extract ID from response
        for key in ["id", "_id", "api_id"]:
            if api_id := result.get(key):
                logger.info("API created", id=api_id)
                return str(api_id)

        logger.warning("API created but no ID in response")
        return ""

    async def add_api_to_collection(self, collection_id: str, api_id: str) -> None:
        """Add an API to a collection."""
        url = f"{self.base_url}/api_collection/{collection_id}/child"
        payload = {
            "children": [CollectionChildItem(type="REQUEST", id=api_id).model_dump()]
        }

        logger.info(
            "adding API to collection",
            api_id=api_id,
            collection_id=collection_id,
            url=url,
        )
        logger.debug("add-to-collection payload", payload=payload)

        response = await self._client.post(url, json=payload, headers=self._get_headers())

        logger.info(
            "add-to-collection response",
            status=response.status_code,
            body=response.text,
        )

        if not response.is_success:
            raise Exception(
                f"Add API to collection failed with status {response.status_code}: {response.text}"
            )

        logger.info("API added to collection", api_id=api_id, collection_id=collection_id)

    async def create_security_scan(self, scan: MaerisSecurityScan) -> str:
        """Create a consolidated security scan entry in Maeris."""
        url = f"{self.base_url}{DEFAULT_SECURITY_SCAN_PATH}"

        logger.info("creating security scan", scan_id=scan.scan_id, url=url)
        logger.debug("security scan payload", payload=scan.model_dump())

        response = await self._client.post(
            url,
            json=scan.model_dump(by_alias=True),
            headers=self._get_headers(),
        )

        logger.info("security scan response", status=response.status_code, body=response.text)

        if not response.is_success:
            raise Exception(
                f"Create security scan failed with status {response.status_code}: {response.text}"
            )

        result = response.json()
        for key in [
            "scan_id",
            "scanId",
            "security_scan_id",
            "securityScanId",
            "id",
            "_id",
        ]:
            if scan_id := result.get(key):
                logger.info("security scan created", id=scan_id)
                return str(scan_id)

        logger.warning("security scan created but no ID in response")
        return scan.scan_id

    def _build_security_finding_payload(self, finding: MaerisSecurityFinding) -> dict:
        """Convert a finding model to the backend payload format."""
        data = finding.model_dump(by_alias=True)
        cvss = data.get("cvss")
        if isinstance(cvss, dict):
            data["cvss"] = cvss.get("score", 0.0)
        if "reference_links" in data and "references" not in data:
            data["references"] = data.pop("reference_links") or []
        data.setdefault("references", [])
        return data

    async def create_security_finding(self, finding: MaerisSecurityFinding) -> str:
        """Create an individual security scan finding in Maeris."""
        url = f"{self.base_url}{DEFAULT_SECURITY_FINDINGS_PATH}"

        logger.info(
            "creating security finding",
            scan_id=finding.scan_id,
            finding_id=finding.scan_finding_id,
            url=url,
        )
        logger.debug("security finding payload", payload=finding.model_dump())

        payload = {"findings": [self._build_security_finding_payload(finding)]}
        response = await self._client.post(url, json=payload, headers=self._get_headers())

        logger.info("security finding response", status=response.status_code, body=response.text)

        if not response.is_success:
            raise Exception(
                f"Create security finding failed with status {response.status_code}: {response.text}"
            )

        result = response.json()
        for key in ["scan_finding_id", "security_scan_finding_id", "id", "_id", "finding_id"]:
            if finding_id := result.get(key):
                logger.info("security finding created", id=finding_id)
                return str(finding_id)

        logger.warning("security finding created but no ID in response")
        return finding.scan_finding_id

    async def create_security_findings(
        self,
        findings: list[MaerisSecurityFinding],
    ) -> list[str]:
        """Create security scan findings in Maeris (batch)."""
        url = f"{self.base_url}{DEFAULT_SECURITY_FINDINGS_PATH}"

        logger.info(
            "creating security findings batch",
            count=len(findings),
            url=url,
        )
        logger.debug(
            "security findings payload",
            payload=[f.model_dump() for f in findings],
        )

        payload = {"findings": [self._build_security_finding_payload(f) for f in findings]}
        response = await self._client.post(url, json=payload, headers=self._get_headers())

        logger.info("security findings response", status=response.status_code, body=response.text)

        if not response.is_success:
            raise Exception(
                f"Create security findings failed with status {response.status_code}: {response.text}"
            )

        result = response.json()

        def _extract_ids(items: list[dict]) -> list[str]:
            ids: list[str] = []
            for item in items:
                for key in ["scan_finding_id", "security_scan_finding_id", "id", "_id", "finding_id"]:
                    if value := item.get(key):
                        ids.append(str(value))
                        break
            return ids

        if isinstance(result, dict):
            if isinstance(result.get("findings"), list):
                ids = _extract_ids(result["findings"])
                if ids:
                    return ids
            if isinstance(result.get("ids"), list):
                return [str(v) for v in result["ids"]]
            if isinstance(result.get("results"), list):
                ids = _extract_ids(result["results"])
                if ids:
                    return ids
        elif isinstance(result, list):
            ids = _extract_ids(result)
            if ids:
                return ids

        return [f.scan_finding_id for f in findings]
