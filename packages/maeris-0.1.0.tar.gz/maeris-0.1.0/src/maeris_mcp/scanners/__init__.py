"""Code reading utilities for security analysis."""
