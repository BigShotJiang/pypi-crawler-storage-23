"""Load and organize static-feasible security checks for LLM-guided scans."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CHECKS_PATH = Path(__file__).with_name("security_checks.json")
DOC_FALLBACK_PATH = Path(__file__).resolve().parents[3] / "docs" / "owasp-static-checklist.md"


def load_checks() -> list[dict[str, Any]]:
    """Load static-feasible checks from the bundled JSON file."""
    checks: list[dict[str, Any]] = []
    if CHECKS_PATH.exists():
        try:
            payload = json.loads(CHECKS_PATH.read_text(encoding="utf-8"))
            checks = payload.get("checks", [])
        except Exception:
            checks = []
    if checks:
        return [c for c in checks if isinstance(c, dict)]
    if DOC_FALLBACK_PATH.exists():
        return _parse_checks_from_markdown(DOC_FALLBACK_PATH)
    return []


def _slugify(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in value)
    cleaned = "_".join([p for p in cleaned.split("_") if p])
    return cleaned or "check"


def _parse_checks_from_markdown(path: Path) -> list[dict[str, Any]]:
    section = ""
    checks: list[dict[str, Any]] = []
    used_ids: set[str] = set()
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line.startswith("## "):
            section = line[3:].strip()
            continue
        if not line.startswith("|"):
            continue
        if "Static feasible?" in line or line.startswith("| ---"):
            continue
        parts = [p.strip() for p in line.strip("|").split("|")]
        if len(parts) < 5:
            continue
        check, static_feasible, current_support, justification, source = parts[:5]
        if static_feasible not in ("Yes", "Partial"):
            continue
        owasp_category = ""
        if len(check) >= 3 and check[0] == "A" and check[1:3].isdigit():
            owasp_category = check[:3]
        cid = _slugify(check)
        if cid in used_ids:
            suffix = 2
            while f"{cid}_{suffix}" in used_ids:
                suffix += 1
            cid = f"{cid}_{suffix}"
        used_ids.add(cid)
        checks.append({
            "id": cid,
            "title": check,
            "section": section,
            "owasp_category": owasp_category,
            "source": source,
            "static_feasible": static_feasible.lower(),
            "current_support": current_support.lower(),
            "notes": justification,
        })
    return checks


def build_profiles(checks: list[dict[str, Any]]) -> dict[str, list[str]]:
    """Build scan profiles grouped by section."""
    section_to_ids: dict[str, list[str]] = {}
    for c in checks:
        section = c.get("section") or ""
        cid = c.get("id")
        if not cid:
            continue
        section_to_ids.setdefault(section, []).append(cid)

    def ids_for_sections(sections: list[str]) -> list[str]:
        ids: list[str] = []
        for s in sections:
            ids.extend(section_to_ids.get(s, []))
        return ids

    profiles: dict[str, list[str]] = {
        "all_static": [c["id"] for c in checks if c.get("id")],
        "owasp_top10_static": ids_for_sections(["OWASP Top 10 (A01-A10)"]),
        "api_static": ids_for_sections(["API Security Testing (OWASP API Top 10 + API-specific checks)"]),
        "infra_static": ids_for_sections([
            "Network Security / Pentesting",
            "Cloud Security Testing (AWS, GCP, Azure)",
            "Container & DevOps Security",
        ]),
        "sast_static": ids_for_sections(["SAST - Static Application Security Testing"]),
        "auth_session_static": ids_for_sections([
            "Authentication & Authorization Security",
            "Session Security",
        ]),
        "data_exposure_static": ids_for_sections(["Data Exposure & PII Leakage"]),
    }

    # Remove empty profiles
    return {name: ids for name, ids in profiles.items() if ids}


def get_checks_and_profiles() -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    checks = load_checks()
    profiles = build_profiles(checks)
    return checks, profiles
