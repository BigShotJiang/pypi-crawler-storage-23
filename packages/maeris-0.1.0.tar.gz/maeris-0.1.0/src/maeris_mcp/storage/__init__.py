"""Storage layer for the Maeris MCP server."""
