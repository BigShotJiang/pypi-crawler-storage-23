"""Thread-safe in-memory storage for security scan results and sessions."""

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone

from maeris_mcp.types.security import (
    ScanSummary,
    SecurityFinding,
    SecurityScanResult,
    SeverityCounts,
    StoredSecurityScan,
)


@dataclass
class ScanMeta:
    """Additional metadata required for a scan session."""

    scan_root: str
    base_for_rel: str


@dataclass
class ScanIndexes:
    """Hashmap indexes for fast lookup of findings."""

    by_file: dict[str, list[str]] = field(default_factory=dict)
    by_rule: dict[str, list[str]] = field(default_factory=dict)
    by_owasp: dict[str, list[str]] = field(default_factory=dict)
    by_severity: dict[str, list[str]] = field(default_factory=dict)
    by_id: dict[str, SecurityFinding] = field(default_factory=dict)
    fingerprints: set[str] = field(default_factory=set)


class SecurityScanStore:
    """Thread-safe storage for security scan results."""

    def __init__(self, max_scans: int = 100) -> None:
        self._lock = threading.RLock()
        self._scans: dict[str, StoredSecurityScan] = {}
        self._meta: dict[str, ScanMeta] = {}
        self._indexes: dict[str, ScanIndexes] = {}
        self._max_scans = max_scans

    def store(self, result: SecurityScanResult) -> str:
        """Store a scan result and return its ID."""
        return self.create_scan(
            result=result,
            file_list=[],
            selected_checks=[],
            scan_profile=None,
            scan_root=result.target_path,
            base_for_rel=result.target_path,
        )

    def create_scan(
        self,
        result: SecurityScanResult,
        file_list: list[str],
        selected_checks: list[str],
        scan_profile: str | None,
        scan_root: str,
        base_for_rel: str,
    ) -> str:
        """Create a scan session and store its initial result."""
        with self._lock:
            self._enforce_max_size()
            now = datetime.now(timezone.utc).isoformat()
            stored = StoredSecurityScan(
                id=result.scan_id,
                target_path=result.target_path,
                result=result,
                stored_at=now,
                last_accessed=now,
                status="pending",
                selected_checks=selected_checks,
                scan_profile=scan_profile,
                file_list=file_list,
                pushed_to_maeris=False,
                pushed_at=None,
            )
            self._scans[result.scan_id] = stored
            self._meta[result.scan_id] = ScanMeta(scan_root=scan_root, base_for_rel=base_for_rel)
            self._indexes[result.scan_id] = ScanIndexes()
            return result.scan_id

    def get(self, scan_id: str) -> StoredSecurityScan | None:
        """Retrieve a scan by ID."""
        with self._lock:
            if scan := self._scans.get(scan_id):
                scan.last_accessed = datetime.now(timezone.utc).isoformat()
                return scan
            return None

    def get_all(self) -> list[StoredSecurityScan]:
        """Return all stored scans."""
        with self._lock:
            return list(self._scans.values())

    def get_meta(self, scan_id: str) -> ScanMeta | None:
        """Get additional scan metadata."""
        with self._lock:
            return self._meta.get(scan_id)

    def search_findings(
        self,
        scan_id: str,
        *,
        file_path: str | None = None,
        rule_id: str | None = None,
        owasp: str | None = None,
        severity: str | None = None,
    ) -> list[SecurityFinding]:
        """Search findings by indexed fields (internal use)."""
        with self._lock:
            indexes = self._indexes.get(scan_id)
            if not indexes:
                return []

            id_sets: list[set[str]] = []
            if file_path:
                id_sets.append(set(indexes.by_file.get(file_path, [])))
            if rule_id:
                id_sets.append(set(indexes.by_rule.get(rule_id, [])))
            if owasp:
                key = owasp.split(":", 1)[0]
                id_sets.append(set(indexes.by_owasp.get(key, [])))
            if severity:
                id_sets.append(set(indexes.by_severity.get(severity.lower(), [])))

            if not id_sets:
                return list(indexes.by_id.values())

            result_ids = set.intersection(*id_sets) if id_sets else set()
            return [indexes.by_id[i] for i in result_ids if i in indexes.by_id]

    def add_findings(self, scan_id: str, findings: list[SecurityFinding]) -> dict[str, int]:
        """Add findings to a scan, updating indexes and de-duplicating."""
        with self._lock:
            scan = self._scans.get(scan_id)
            indexes = self._indexes.get(scan_id)
            if not scan or not indexes:
                return {"added": 0, "deduped": 0}
            if scan.status == "completed":
                return {"added": 0, "deduped": 0}

            added = 0
            deduped = 0
            for finding in findings:
                fingerprint = self._fingerprint(finding)
                if fingerprint in indexes.fingerprints:
                    deduped += 1
                    continue
                indexes.fingerprints.add(fingerprint)
                scan.result.findings.append(finding)
                self._index_finding(indexes, finding)
                added += 1
            return {"added": added, "deduped": deduped}

    def finalize_scan(self, scan_id: str) -> StoredSecurityScan | None:
        """Finalize a scan: compute summary and mark completed."""
        with self._lock:
            scan = self._scans.get(scan_id)
            if not scan:
                return None
            files_scanned = len(scan.file_list)
            scan.result.summary = self._compute_summary(scan.result.findings, files_scanned)
            scan.status = "completed"
            return scan

    def delete(self, scan_id: str) -> bool:
        """Delete a scan by ID. Returns True if it existed."""
        with self._lock:
            if scan_id not in self._scans:
                return False
            del self._scans[scan_id]
            self._meta.pop(scan_id, None)
            self._indexes.pop(scan_id, None)
            return True

    def clear(self) -> int:
        """Delete all scans. Returns the number deleted."""
        with self._lock:
            count = len(self._scans)
            self._scans.clear()
            self._meta.clear()
            self._indexes.clear()
            return count

    def get_recent(self, n: int) -> list[StoredSecurityScan]:
        """Return up to N most recent scans, newest first."""
        with self._lock:
            scans = list(self._scans.values())
        scans.sort(key=lambda s: s.stored_at, reverse=True)
        return scans[:n]

    def mark_pushed(self, scan_id: str) -> None:
        """Mark a scan as pushed to Maeris."""
        with self._lock:
            scan = self._scans.get(scan_id)
            if scan:
                scan.pushed_to_maeris = True
                scan.pushed_at = datetime.now(timezone.utc).isoformat()

    def _enforce_max_size(self) -> None:
        if len(self._scans) < self._max_scans:
            return
        oldest_id = min(self._scans.keys(), key=lambda k: self._scans[k].stored_at)
        del self._scans[oldest_id]
        self._meta.pop(oldest_id, None)
        self._indexes.pop(oldest_id, None)

    @staticmethod
    def _fingerprint(finding: SecurityFinding) -> str:
        return f"{finding.rule_id}|{finding.file_path}|{finding.line_start}|{finding.title}"

    @staticmethod
    def _index_finding(indexes: ScanIndexes, finding: SecurityFinding) -> None:
        indexes.by_id[finding.id] = finding
        indexes.by_file.setdefault(finding.file_path, []).append(finding.id)
        indexes.by_rule.setdefault(finding.rule_id, []).append(finding.id)
        if finding.owasp_category:
            indexes.by_owasp.setdefault(finding.owasp_category.value, []).append(finding.id)
        indexes.by_severity.setdefault(finding.severity.value, []).append(finding.id)

    @staticmethod
    def _compute_summary(findings: list[SecurityFinding], files_scanned: int) -> ScanSummary:
        severity_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0}
        owasp_counts: dict[str, int] = {}
        for finding in findings:
            sev = finding.severity.value if finding.severity else "medium"
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
            if finding.owasp_category:
                code = finding.owasp_category.value
                owasp_counts[code] = owasp_counts.get(code, 0) + 1

        return ScanSummary(
            total_findings=len(findings),
            by_severity=SeverityCounts(**severity_counts),
            by_owasp_category=owasp_counts,
            files_scanned=files_scanned,
        )
