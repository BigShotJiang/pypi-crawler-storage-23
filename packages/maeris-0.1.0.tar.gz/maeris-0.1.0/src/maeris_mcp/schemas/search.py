"""React code search schema."""

from maeris_mcp.schemas.registry import Schema
from maeris_mcp.types.protocol import ExtractionInstructions, OperationType


def search_schema() -> Schema:
    """Return the JSON schema for search operations."""
    return Schema(
        id="react-search-v1",
        name="React Code Search",
        description="Schema for searching components, functions, and patterns in a React codebase",
        applicable_operations=[
            OperationType.SEARCH_COMPONENTS,
            OperationType.SEARCH_FUNCTIONS,
            OperationType.FIND_PATTERNS,
        ],
        json_schema={
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "ReactSearchResults",
            "description": "Search results from a React codebase",
            "type": "object",
            "required": ["query", "matches"],
            "properties": {
                "query": {"type": "string", "description": "The search query that was executed"},
                "searchType": {
                    "type": "string",
                    "enum": ["component", "function", "hook", "pattern", "general"],
                    "description": "Type of search performed",
                },
                "matches": {
                    "type": "array",
                    "description": "Search results",
                    "items": {
                        "type": "object",
                        "required": ["name", "filePath", "matchType"],
                        "properties": {
                            "name": {"type": "string", "description": "Name of the matched item"},
                            "filePath": {"type": "string", "description": "File path where the match was found"},
                            "matchType": {
                                "type": "string",
                                "enum": ["component", "function", "hook", "type", "pattern"],
                                "description": "Type of the matched item",
                            },
                            "signature": {"type": "string", "description": "Function/component signature (types only, no implementation)"},
                            "description": {"type": "string", "description": "Brief description of what this item does"},
                            "relevanceScore": {"type": "number", "minimum": 0, "maximum": 1, "description": "How relevant this match is to the query (0-1)"},
                            "usedBy": {"type": "array", "items": {"type": "string"}, "description": "List of files that use this item"},
                            "uses": {"type": "array", "items": {"type": "string"}, "description": "List of dependencies this item uses"},
                        },
                    },
                },
                "totalMatches": {"type": "integer", "description": "Total number of matches found"},
                "searchMetadata": {
                    "type": "object",
                    "description": "Information about the search",
                    "properties": {
                        "filesSearched": {"type": "integer", "description": "Number of files searched"},
                        "searchScope": {"type": "string", "description": "Scope of the search (e.g., 'src/', 'components/')"},
                    },
                },
            },
        },
        instructions=ExtractionInstructions(
            overview="Search for components, functions, hooks, or patterns in the codebase and return structured results.",
            steps=[
                "1. Understand the search query and determine the search type",
                "2. Scan relevant files based on the query",
                "3. For each match, extract name, location, and signature",
                "4. Assess relevance and rank results",
                "5. Identify relationships (usedBy, uses)",
            ],
            field_guidance={
                "signature": "Include function signature with parameter and return types. No implementation.",
                "description": "Brief description of what the item does based on its name, JSDoc, and usage.",
                "relevanceScore": "Score from 0-1 based on how well the item matches the query.",
                "usedBy": "List file paths that import or use this item.",
            },
            privacy_notes=[
                "Never include actual source code implementations",
                "Signatures should only include type information",
                "Descriptions should be generic, not containing business logic details",
                "Don't expose any hardcoded values or configuration from the code",
            ],
        ),
    )
