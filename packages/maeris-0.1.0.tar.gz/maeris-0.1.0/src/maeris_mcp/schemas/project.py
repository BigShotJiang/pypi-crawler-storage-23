"""React project extraction schema."""

from maeris_mcp.schemas.registry import Schema
from maeris_mcp.types.protocol import ExtractionInstructions, OperationType


def project_extraction_schema() -> Schema:
    """Return the JSON schema for project-level extraction."""
    return Schema(
        id="react-project-v1",
        name="React Project Extraction",
        description="Schema for extracting project-wide React codebase information",
        applicable_operations=[
            OperationType.ANALYZE_PROJECT,
            OperationType.GENERATE_DOCS,
        ],
        json_schema={
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "ReactProjectExtraction",
            "description": "Structured data extracted from a React project",
            "type": "object",
            "required": ["projectName", "rootPath", "fileStructure", "components"],
            "properties": {
                "projectName": {
                    "type": "string",
                    "description": "Name of the project (from package.json or directory name)",
                },
                "rootPath": {
                    "type": "string",
                    "description": "Root path of the project",
                },
                "fileStructure": {
                    "type": "object",
                    "description": "Summary of project file structure",
                    "required": ["totalFiles", "componentFiles"],
                    "properties": {
                        "totalFiles": {"type": "integer", "description": "Total number of relevant files"},
                        "componentFiles": {"type": "array", "items": {"type": "string"}, "description": "Paths to component files"},
                        "hookFiles": {"type": "array", "items": {"type": "string"}, "description": "Paths to custom hook files"},
                        "utilityFiles": {"type": "array", "items": {"type": "string"}, "description": "Paths to utility/helper files"},
                    },
                },
                "components": {
                    "type": "array",
                    "description": "Summary of all React components",
                    "items": {
                        "type": "object",
                        "required": ["name", "filePath", "componentType"],
                        "properties": {
                            "name": {"type": "string", "description": "Component name"},
                            "filePath": {"type": "string", "description": "File path relative to root"},
                            "componentType": {"type": "string", "enum": ["functional", "class", "forwardRef", "memo", "hoc"], "description": "Type of component"},
                            "propsCount": {"type": "integer", "description": "Number of props"},
                            "hooksUsed": {"type": "array", "items": {"type": "string"}, "description": "Names of hooks used"},
                        },
                    },
                },
                "customHooks": {
                    "type": "array",
                    "description": "Custom hooks defined in the project",
                    "items": {
                        "type": "object",
                        "required": ["name", "filePath"],
                        "properties": {
                            "name": {"type": "string", "description": "Hook name (e.g., useAuth)"},
                            "filePath": {"type": "string", "description": "File path"},
                            "parameters": {"type": "array", "items": {"type": "string"}, "description": "Parameter names and types"},
                            "returnType": {"type": "string", "description": "Return type description"},
                        },
                    },
                },
                "dependencyEdges": {
                    "type": "array",
                    "description": "Import relationships between files",
                    "items": {
                        "type": "object",
                        "required": ["source", "target", "importType"],
                        "properties": {
                            "source": {"type": "string", "description": "File that imports"},
                            "target": {"type": "string", "description": "File being imported"},
                            "importType": {"type": "string", "enum": ["component", "hook", "utility", "external"], "description": "Type of import"},
                        },
                    },
                },
                "techStack": {
                    "type": "object",
                    "description": "Detected technology stack",
                    "properties": {
                        "stateManagement": {"type": "string", "description": "State management library (redux, zustand, mobx, context, etc.)"},
                        "styling": {"type": "string", "description": "Styling approach (css-modules, styled-components, tailwind, etc.)"},
                        "routing": {"type": "string", "description": "Routing library (react-router, next-router, etc.)"},
                    },
                },
            },
        },
        instructions=ExtractionInstructions(
            overview="Extract a high-level overview of a React project structure without including source code.",
            steps=[
                "1. Identify the project name from package.json",
                "2. Scan directory structure for component, hook, and utility files",
                "3. For each component, extract name, type, props count, and hooks used",
                "4. Identify custom hooks and their signatures",
                "5. Map import relationships between files",
                "6. Detect the tech stack from dependencies and usage patterns",
            ],
            field_guidance={
                "components": "List all React components with basic metadata. Don't include implementation details.",
                "customHooks": "List custom hooks (functions starting with 'use'). Include parameter and return types.",
                "dependencyEdges": "Map which files import which other files. Focus on internal dependencies.",
                "techStack": "Detect from package.json dependencies and import patterns.",
            },
            privacy_notes=[
                "Only include file paths and names, never file contents",
                "For types, use TypeScript notation without implementation details",
                "Don't include any environment variables or configuration values",
                "Don't include any API keys, secrets, or sensitive data paths",
            ],
        ),
    )
