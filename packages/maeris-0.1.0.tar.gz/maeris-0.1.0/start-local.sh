#!/bin/bash
set -e

# Ensure dependencies are installed
echo "==> Installing dependencies with uv..."
uv pip install -e .

# Parse arguments
MODE="${1:-stdio}"
PORT="${2:-8080}"

LOG_FILE="/tmp/maeris-mcp.log"
echo "==> Starting maeris-mcp in ${MODE} mode..."
echo "    Logs: $LOG_FILE"

# Always tail logs in background
tail -f "$LOG_FILE" 2>/dev/null &
TAIL_PID=$!
trap "kill $TAIL_PID 2>/dev/null" EXIT

if [ "$MODE" = "http" ]; then
    echo "    Server will be available at http://localhost:${PORT}/mcp"
    python -m maeris_mcp --mode=http --port="$PORT"
else
    python -m maeris_mcp
fi
