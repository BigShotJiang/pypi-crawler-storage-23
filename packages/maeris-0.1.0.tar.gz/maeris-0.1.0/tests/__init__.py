"""Tests for the Maeris MCP server."""
