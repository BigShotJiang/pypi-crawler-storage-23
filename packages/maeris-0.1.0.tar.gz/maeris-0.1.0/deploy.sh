#!/bin/bash
set -e

# Configuration - update these values
PROJECT_ID="future-lane-478716-f2"
REGION="us-central1"
SERVICE_NAME="maeris-mcp"
IMAGE_NAME="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

echo "==> Deploying ${SERVICE_NAME} to Cloud Run"
echo "    Project: ${PROJECT_ID}"
echo "    Region:  ${REGION}"

# Build the container image
echo "==> Building container image..."
podman build -t ${IMAGE_NAME} .

# Push to Google Container Registry
echo "==> Pushing to GCR..."
podman push ${IMAGE_NAME}

# Deploy to Cloud Run
echo "==> Deploying to Cloud Run..."
gcloud run deploy ${SERVICE_NAME} \
  --image ${IMAGE_NAME} \
  --platform managed \
  --region ${REGION} \
  --project ${PROJECT_ID} \
  --allow-unauthenticated \
  --port 8080

echo "==> Deployment complete!"
gcloud run services describe ${SERVICE_NAME} --region ${REGION} --project ${PROJECT_ID} --format='value(status.url)'
