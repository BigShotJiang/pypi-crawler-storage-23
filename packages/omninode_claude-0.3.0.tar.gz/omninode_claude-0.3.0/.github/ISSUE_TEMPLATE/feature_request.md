---
name: Feature Request
about: Suggest an enhancement
title: '[Feature] '
labels: enhancement
---
## Problem
## Proposed solution
## Alternatives considered
