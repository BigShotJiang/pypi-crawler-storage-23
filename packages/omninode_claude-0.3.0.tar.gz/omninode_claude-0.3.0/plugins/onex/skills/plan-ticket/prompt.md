# Plan Ticket - Template Generator

Generate a copyable YAML contract template for ticket creation.

**Announce at start:** "I'm using the plan-ticket skill to generate a ticket template."

---

## Behavior

1. Parse any arguments provided (e.g., `/plan-ticket add caching to API`)
2. Output a single YAML template block
3. Pre-fill fields based on context when available
4. Include instructions for next steps

---

## Template Output

Always output this template, pre-filling fields when context is available:

~~~markdown
Here's your ticket contract template:

```yaml
# Ticket Contract Template
# Edit this and pass to: /create-ticket --from-contract contract.yaml

title: "{TITLE_FROM_ARGS_OR_PLACEHOLDER}"
repo: "{DETECTED_REPO_OR_omniclaude}"

requirements:
  - id: "R1"
    statement: "{INFERRED_OR_PLACEHOLDER}"
    rationale: "{INFERRED_OR_PLACEHOLDER}"
    acceptance:
      - "{INFERRED_OR_PLACEHOLDER}"

  # Add more requirements:
  # - id: "R2"
  #   statement: "..."
  #   rationale: "..."
  #   acceptance:
  #     - "..."

verification:
  - id: "V1"
    title: "Unit tests pass"
    kind: "unit_tests"
    command: "uv run pytest tests/"
    expected: "exit 0"
    blocking: true
  - id: "V2"
    title: "Lint passes"
    kind: "lint"
    command: "uv run ruff check ."
    expected: "exit 0"
    blocking: true

context:
  relevant_files: []
  patterns_found: []
  notes: ""
```

**Next steps:**
1. Copy and edit the template above
2. Save to `contract.yaml` (or use inline)
3. Run: `/create-ticket --from-contract contract.yaml --team Omninode`

**Optional flags for /create-ticket:**
- `--parent OMN-1234` - Set parent ticket
- `--blocked-by OMN-1235,OMN-1236` - Set blocking tickets
- `--project "Project Name"` - Add to Linear project
~~~

---

## Pre-filling Logic

When arguments are provided, intelligently pre-fill:

| Argument Pattern | Pre-fill |
|------------------|----------|
| Contains repo name | Set `repo` field |
| Describes a goal | Set `title` field |
| Mentions "fix" or "bug" | Suggest bug-fix requirement template |
| Mentions "add" or "feature" | Suggest feature requirement template |
| Mentions specific file | Add to `context.relevant_files` |

### Example: `/plan-ticket add rate limiting to API in omnibase_core`

```yaml
title: "Add rate limiting to API"
repo: "omnibase_core"

requirements:
  - id: "R1"
    statement: "API endpoints must enforce rate limits"
    rationale: "Prevent abuse and ensure fair resource usage"
    acceptance:
      - "Rate limit headers included in responses"
      - "429 status returned when limit exceeded"
```

---

## Repository Detection

Detect repo from:
1. Explicit mention in args ("in omnibase_core")
2. Current working directory
3. Default to "omniclaude" if unknown

Valid repos: `omnibase_core`, `omniclaude`, `omnibase_infra`, `omnidash`, `omniintelligence`, `omnimemory`, `omninode_infra`

---

## No Interactive Prompts

This skill does NOT use AskUserQuestion. It outputs a single copyable block and instructions. The user edits the template themselves and passes it to `/create-ticket`.
