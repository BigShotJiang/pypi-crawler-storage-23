# VERTICAL-001 Demo Runbook (DEPRECATED)

> **Deprecated**: This runbook was retired as part of OMN-2058 (DB-SPLIT).

The demo scripts (`demo_consume_store.py`, `demo_query_patterns.py`), the `learned_patterns`
table, and direct access to the `omninode_bridge` database have all been removed from this
repository. Pattern storage functionality has been migrated to **omnibase_infra**.

For current database setup, see `scripts/init-db.sh`.
