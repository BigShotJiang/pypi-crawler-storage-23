from django.urls import path

from .mcp import MCPView

urlpatterns = [
    path("", MCPView.as_view(), name="statezero_mcp"),
]
