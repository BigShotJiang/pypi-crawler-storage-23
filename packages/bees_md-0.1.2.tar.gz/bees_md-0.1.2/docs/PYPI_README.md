## Overview

Bees is a markdown-based ticket management system for LLM-assisted development. After install the `bees` command is available in your shell.

## Installation

```bash
# CLI only
pipx install bees-md

# CLI + MCP server (required for bees serve)
pipx install 'bees-md[serve]'
```

## Documentation

Full docs at [github.com/gabemahoney/bees](https://github.com/gabemahoney/bees)
