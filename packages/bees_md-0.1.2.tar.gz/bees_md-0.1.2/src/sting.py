"""Bees sting command — emits CLI reference in non-MCP sessions.

When invoked:
  1. Detect if CWD is in a bees-managed scope. No match → silent exit 0.
  2. Scan known Claude config locations for a bees MCP server entry.
     Match in global or current-project scope → MCP mode → silent exit 0.
  3. Otherwise print the plain-text CLI reference and exit 0.
"""

import json
import logging
import re
import sys
from pathlib import Path

from .repo_utils import get_repo_root_from_path
from .config import load_global_config, find_matching_scope

logger = logging.getLogger(__name__)

# Matches "bees", "bees-mcp", "my_bees", but NOT "frisbees"
_BEES_PATTERN = re.compile(r"(?i)(?:^|[-_])bees(?:$|[-_])")

_CLI_REFERENCE = """\
BEES TICKET SYSTEM — CLI REFERENCE

You are in a bees-managed project. Use the bees CLI for all ticket operations.
All commands output JSON to stdout. Exit 0 on success, exit 1 on error.
Repo root is auto-detected from your working directory.

TICKET LIFECYCLE STATES: pupa -> larva -> worker -> finished

COMMON COMMANDS

  Show tickets:
    bees show-ticket <id> [<id2> ...]

  Create a ticket:
    bees create-ticket --type <bee|t1|t2> --title "..." --hive <name> [--description "..."] [--parent <id>] [--status <status>]

  Update a ticket:
    bees update-ticket <id> [--title "..."] [--description "..."] [--status <status>] [--labels '["a","b"]']

  Delete a ticket:
    bees delete-ticket <id> [--clean-dependencies]

  Query tickets (ad-hoc YAML):
    bees execute-freeform-query --yaml "- ['type=bee', 'status=open']" [--hives backend,frontend]

  Query tickets (saved query):
    bees execute-named-query <name> [--hives backend,frontend]

ALL COMMANDS

  Tickets:   create-ticket, update-ticket, delete-ticket, show-ticket
  Queries:   execute-freeform-query, execute-named-query, add-named-query
  Hives:     colonize-hive, list-hives, abandon-hive, rename-hive, sanitize-hive
  Index:     generate-index, get-types
  Other:     move-bee, undertaker

Run bees <command> -h for usage details on any command."""


def _key_matches_bees(key: str) -> bool:
    """Return True if the MCP server key matches the bees pattern."""
    return bool(_BEES_PATTERN.search(key))


def _has_bees_in_mcp_servers(mcp_servers: object) -> bool:
    """Return True if any key in mcp_servers dict matches the bees pattern."""
    if not isinstance(mcp_servers, dict):
        return False
    return any(_key_matches_bees(k) for k in mcp_servers)


def _detect_mcp(repo_root: Path) -> bool:
    """Scan the three Claude config locations for a bees MCP server entry.

    Returns True if bees MCP is configured for the global scope or for the
    current repo_root project scope.  A match scoped to a *different* project
    does NOT count.
    """
    home = Path.home()

    # --- Location 1 & 2: ~/.claude.json ---
    claude_json = home / ".claude.json"
    try:
        raw = claude_json.read_text(encoding="utf-8")
        data = json.loads(raw)

        # 1. Top-level mcpServers (global scope)
        if _has_bees_in_mcp_servers(data.get("mcpServers")):
            return True

        # 2. Per-project entry matching current repo root
        projects = data.get("projects")
        if isinstance(projects, dict):
            repo_root_str = str(repo_root)
            project_data = projects.get(repo_root_str)
            if isinstance(project_data, dict):
                if _has_bees_in_mcp_servers(project_data.get("mcpServers")):
                    return True
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError):
        pass  # malformed or unreadable — skip silently

    # --- Location 3: <repo_root>/.mcp.json ---
    dot_mcp = repo_root / ".mcp.json"
    try:
        raw = dot_mcp.read_text(encoding="utf-8")
        data = json.loads(raw)
        if _has_bees_in_mcp_servers(data.get("mcpServers")):
            return True
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError):
        pass

    # --- Location 4: <repo_root>/.claude/settings.local.json ---
    settings_local = repo_root / ".claude" / "settings.local.json"
    try:
        raw = settings_local.read_text(encoding="utf-8")
        data = json.loads(raw)
        if _has_bees_in_mcp_servers(data.get("mcpServers")):
            return True
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError):
        pass

    return False


def handle_sting(args):
    """Handle the `bees sting` command."""
    # Step 1 — Scope detection
    repo_root = get_repo_root_from_path(Path.cwd())
    global_config = load_global_config()
    matching_scope = find_matching_scope(repo_root, global_config)
    if matching_scope is None:
        sys.exit(0)

    # Step 2 — MCP detection
    if _detect_mcp(repo_root):
        sys.exit(0)

    # Step 3 — Output CLI reference
    print(_CLI_REFERENCE)
    sys.exit(0)
