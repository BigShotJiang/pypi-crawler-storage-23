"""Factory functions for creating tickets with YAML frontmatter."""

from datetime import datetime
from typing import Any

from .constants import SCHEMA_VERSION
from .id_utils import extract_existing_ids_from_all_hives, generate_guid, generate_unique_ticket_id
from .writer import write_ticket_file


def _add_child_to_parent_backlink(child_id: str, parent_id: str) -> None:
    """Update parent ticket's children array to include child_id (deferred import to avoid circularity)."""
    from .mcp_relationships import _add_child_to_parent  # noqa: PLC0415
    _add_child_to_parent(child_id, parent_id)


def create_bee(
    title: str,
    hive_name: str,
    description: str = "",
    labels: list[str] | None = None,
    up_dependencies: list[str] | None = None,
    down_dependencies: list[str] | None = None,
    status: str = "open",
    ticket_id: str | None = None,
    egg: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
    guid: str | None = None,
) -> str:
    """
    Create a Bee ticket with YAML frontmatter.

    Args:
        title: Bee title (required)
        description: Bee description
        labels: List of label strings
        up_dependencies: List of ticket IDs that block this bee
        down_dependencies: List of ticket IDs that this bee blocks
        status: Status string (default: "open")
        ticket_id: Optional specific ID to use (auto-generated if not provided)
        hive_name: Hive name determining storage location (required, e.g., "backend" stores in backend hive)

    Returns:
        The created ticket ID

    Raises:
        ValueError: If required fields are missing or invalid

    Examples:
        >>> bee_id = create_bee(
        ...     title="Implement Auth System",
        ...     description="Build user authentication",
        ...     labels=["security", "backend"],
        ...     hive_name="backend",
        ... )
        >>> bee_id.startswith("b.")
        True
        >>> bee_id = create_bee(
        ...     title="Frontend Dashboard",
        ...     hive_name="frontend",
        ... )
        >>> bee_id.startswith("b.")
        True
    """
    if not title:
        raise ValueError("Bee title is required")

    # Generate unique ID if not provided
    if ticket_id is None:
        existing_ids = extract_existing_ids_from_all_hives()
        ticket_id = generate_unique_ticket_id("bee", existing_ids=existing_ids, hive_name=hive_name)

    # Build frontmatter data
    # Note: description is NOT included in frontmatter - it's written to the markdown body only
    frontmatter_data = {
        "id": ticket_id,
        "type": "bee",
        "title": title,
        "labels": labels or [],
        "up_dependencies": up_dependencies or [],
        "down_dependencies": down_dependencies or [],
        "status": status,
        "created_at": datetime.now(),
        "schema_version": SCHEMA_VERSION,
        "egg": egg,
    }

    # Always include guid; auto-generate from short_id if not provided
    short_id = ticket_id.split(".", 1)[1] if "." in ticket_id else ticket_id
    frontmatter_data["guid"] = guid if guid is not None else generate_guid(short_id)

    # Write ticket file
    write_ticket_file(
        ticket_id=ticket_id,
        ticket_type="bee",
        frontmatter_data=frontmatter_data,
        body=description,
        hive_name=hive_name,
    )

    return ticket_id


def create_child_tier(
    ticket_type: str,
    title: str,
    parent: str,
    hive_name: str,
    description: str = "",
    labels: list[str] | None = None,
    up_dependencies: list[str] | None = None,
    down_dependencies: list[str] | None = None,
    status: str = "open",
    ticket_id: str | None = None,
    guid: str | None = None,
) -> str:
    """
    Create a child tier ticket (t1, t2, t3, etc.) with YAML frontmatter.

    This generic function handles creation of any dynamic tier type configured
    in the child_tiers config. It accepts the ticket_type as a parameter.

    Args:
        ticket_type: Type of tier ticket (e.g., "t1", "t2", "t3")
        title: Ticket title (required)
        parent: Parent ticket ID (required for all child tiers)
        hive_name: Hive name to prefix the ID with (required)
        description: Ticket description
        labels: List of label strings
        up_dependencies: List of ticket IDs that block this ticket
        down_dependencies: List of ticket IDs that this ticket blocks
        status: Status string (default: "open")
        ticket_id: Optional specific ID to use (auto-generated if not provided)

    Returns:
        The created ticket ID

    Raises:
        ValueError: If required fields are missing or invalid

    Examples:
        >>> t1_id = create_child_tier(
        ...     ticket_type="t1",
        ...     title="Build login feature",
        ...     parent="b.Amx",
        ...     hive_name="backend",
        ... )
        >>> t1_id.startswith("t1.")
        True
    """
    if not title:
        raise ValueError(f"{ticket_type} title is required")
    if not parent:
        raise ValueError(f"{ticket_type} parent is required")

    # Generate unique ID if not provided
    if ticket_id is None:
        existing_ids = extract_existing_ids_from_all_hives()
        ticket_id = generate_unique_ticket_id(ticket_type, existing_ids=existing_ids, hive_name=hive_name)

    # Build frontmatter data
    # Note: description is NOT included in frontmatter - it's written to the markdown body only
    frontmatter_data = {
        "id": ticket_id,
        "type": ticket_type,
        "title": title,
        "parent": parent,
        "labels": labels or [],
        "up_dependencies": up_dependencies or [],
        "down_dependencies": down_dependencies or [],
        "status": status,
        "created_at": datetime.now(),
        "schema_version": SCHEMA_VERSION,
    }

    # Always include guid; auto-generate from short_id if not provided
    short_id = ticket_id.split(".", 1)[1] if "." in ticket_id else ticket_id
    frontmatter_data["guid"] = guid if guid is not None else generate_guid(short_id)

    # Write ticket file
    write_ticket_file(
        ticket_id=ticket_id,
        ticket_type=ticket_type,
        frontmatter_data=frontmatter_data,
        body=description,
        hive_name=hive_name,
    )

    # Maintain parent-children backlink so the hive stays structurally valid
    _add_child_to_parent_backlink(ticket_id, parent)

    return ticket_id
