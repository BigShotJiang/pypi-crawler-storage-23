"""Hive configuration helper utilities for sanitize_hive and other hive management commands."""

from pathlib import Path
from typing import Any

from .config import BeesConfig, get_scoped_config, load_bees_config
from .id_utils import normalize_hive_name


def get_hive_config(hive_name: str) -> dict[str, Any] | None:
    """
    Get configuration for a specific hive by name.

    Normalizes the hive name and looks it up in ~/.bees/config.json.

    Args:
        hive_name: The hive name (display name or normalized form accepted)

    Returns:
        Dict with 'path', 'display_name', 'created_at' if hive is registered,
        None if hive not registered or config doesn't exist

    Examples:
        >>> get_hive_config("Backend")
        {'path': '/path/to/backend', 'display_name': 'Backend', 'created_at': '2026-02-01T...'}
        >>> get_hive_config("back_end")  # Same result with normalized name
        {'path': '/path/to/backend', 'display_name': 'Backend', 'created_at': '2026-02-01T...'}
        >>> get_hive_config("nonexistent")
        None
    """
    # Normalize hive name
    normalized = normalize_hive_name(hive_name)

    # Load config
    config = load_bees_config()

    # Return None if config doesn't exist
    if config is None:
        return None

    # Look up hive in config
    if normalized not in config.hives:
        return None

    # Return hive config as dict
    hive_config = config.hives[normalized]
    return {"path": hive_config.path, "display_name": hive_config.display_name, "created_at": hive_config.created_at}


def load_hives_config() -> BeesConfig | None:
    """
    Load entire ~/.bees/config.json configuration.

    Returns:
        BeesConfig object if file exists, None if not found
    """
    return load_bees_config()


def hive_integrity_gate(hive_name: str, repo_root: Path | None) -> dict | None:
    """Check hive integrity and return error dict if corrupt, None if healthy."""
    if repo_root is None:
        from .repo_context import get_repo_root as _get_ctx_root
        try:
            repo_root = _get_ctx_root()
        except RuntimeError:
            repo_root = Path.cwd()
    result = check_hive_integrity(hive_name, repo_root)
    if result is None:
        return None
    normalized_name, error_list = result
    return {
        "status": "error",
        "error_type": "hive_corrupt",
        "hive_name": normalized_name,
        "message": f"Hive '{normalized_name}' is corrupt. Run sanitize_hive('{normalized_name}') to repair it.",
        "errors": error_list,
    }


def check_hive_integrity(hive_name: str, repo_root: Path | None) -> None | tuple[str, list[str]]:
    """Check integrity of a hive without writing or moving any files on disk.

    Runs all linter validation checks (excluding directory structure enforcement)
    against the named hive. Returns None if the hive is healthy, or a tuple of
    (normalized_hive_name, error_messages) if corruption is detected.

    Args:
        hive_name: The hive name to check (display or normalized form)
        repo_root: Path to the repository root, used to resolve the scoped config

    Returns:
        None if the hive passes all integrity checks, or
        (normalized_hive_name, [error_message, ...]) if errors are found
    """
    from .linter import Linter

    if repo_root is None:
        from .repo_context import get_repo_root as _get_ctx_root
        try:
            repo_root = _get_ctx_root()
        except RuntimeError:
            repo_root = Path.cwd()
    repo_root = Path(repo_root)
    normalized = normalize_hive_name(hive_name)
    config = get_scoped_config(repo_root)

    if config is None or normalized not in config.hives:
        return None

    hive_path = config.hives[normalized].path
    linter = Linter(tickets_dir=hive_path, hive_name=normalized, config=config, auto_fix=False)
    report = linter.run(detect_only=True)

    if not report.is_corrupt():
        return None

    return (normalized, [error.message for error in report.errors])
