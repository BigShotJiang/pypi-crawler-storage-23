"""
MCP Server for Bees Ticket Management System

Provides FastMCP server infrastructure with tool registration for ticket operations.
This module owns the MCP adapter layer: resolving repo_root from context and
injecting it into the pure core functions.
"""

import logging
from pathlib import Path
from typing import Any, Literal

from fastmcp import Context, FastMCP

from .config import load_bees_config  # noqa: F401 - re-exported for test mocking
from .mcp_hive_ops import (
    _abandon_hive,
    _colonize_hive,
    _list_hives,
    _rename_hive,
    _sanitize_hive,
    colonize_hive_core,  # noqa: F401 - re-exported
)
from .mcp_hive_utils import scan_for_hive, validate_hive_path  # noqa: F401 - re-exported
from .mcp_index_ops import _generate_index
from .mcp_move_bee import _move_bee
from .mcp_query_ops import _add_named_query, _execute_freeform_query, _execute_named_query
from .mcp_roots import get_client_repo_root, get_repo_root, resolve_repo_root  # noqa: F401 - re-exported
from .repo_utils import get_repo_root_from_path  # noqa: F401 - re-exported
from .mcp_ticket_ops import _create_ticket, _delete_ticket, _get_types, _show_ticket, _update_ticket
from .mcp_undertaker import _undertaker
from .repo_context import repo_root_context

# Ensure log directory exists
log_dir = Path.home() / ".bees"
log_dir.mkdir(exist_ok=True)

# Configure logging to file for MCP stdio compatibility
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    filename=log_dir / "mcp.log",
    filemode="a",
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP(
    "bees",
    instructions=(
        "IMPORTANT: When this MCP server is available, ALWAYS use these MCP tools "
        "instead of running `bees` CLI commands via Bash. MCP tools return structured "
        "data directly and are the preferred interface for all ticket and hive operations. "
        "Never invoke the `bees` CLI (e.g. `bees show`, `bees list`, `bees update`) when "
        "an equivalent MCP tool exists — use the tool instead."
    ),
)

# Server state
_server_running = False

# Sentinel for __UNSET__ pattern
_UNSET: Literal["__UNSET__"] = "__UNSET__"


# ── Server lifecycle ──────────────────────────────────────────────────────────

def start_server() -> dict[str, Any]:
    """
    Start the MCP server.

    Returns:
        dict: Server status information
    """
    global _server_running

    try:
        logger.info("Starting Bees MCP Server...")
        _server_running = True
        logger.info("Bees MCP Server started successfully")

        return {"status": "running", "name": "bees", "version": "0.1.0"}
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        _server_running = False
        raise


def stop_server() -> dict[str, Any]:
    """
    Stop the MCP server.

    Returns:
        dict: Server status information
    """
    global _server_running

    try:
        logger.info("Stopping Bees MCP Server...")
        _server_running = False
        logger.info("Bees MCP Server stopped successfully")

        return {"status": "stopped", "name": "bees"}
    except Exception as e:
        logger.error(f"Failed to stop server: {e}")
        raise


def _health_check() -> dict[str, Any]:
    """
    Check the health status of the MCP server.

    Returns:
        dict: Health status including server state and readiness
    """
    return {
        "status": "healthy" if _server_running else "stopped",
        "server_running": _server_running,
        "name": "bees",
        "version": "0.1.0",
        "ready": _server_running,
    }


# ── Tool registrations (adapter layer) ───────────────────────────────────────

@mcp.tool()
def health_check() -> dict[str, Any]:
    """Check the health status of the MCP server."""
    return _health_check()


@mcp.tool()
async def create_ticket(
    ticket_type: str,
    title: str,
    hive_name: str,
    description: str = "",
    parent: str | None = None,
    children: list[str] | None = None,
    up_dependencies: list[str] | None = None,
    down_dependencies: list[str] | None = None,
    labels: list[str] | None = None,
    status: str | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
    egg: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
) -> dict[str, Any]:
    """Create a new ticket (bee or dynamic tier type)."""
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _create_ticket(
            ticket_type=ticket_type,
            title=title,
            hive_name=hive_name,
            description=description,
            parent=parent,
            children=children,
            up_dependencies=up_dependencies,
            down_dependencies=down_dependencies,
            labels=labels,
            status=status,
            egg=egg,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def update_ticket(
    ticket_id: str | list[str],
    title: str | None | Literal["__UNSET__"] = _UNSET,
    description: str | None | Literal["__UNSET__"] = _UNSET,
    parent: str | None | Literal["__UNSET__"] = _UNSET,
    children: list[str] | None = _UNSET,  # type: ignore[assignment]
    up_dependencies: list[str] | None = _UNSET,  # type: ignore[assignment]
    down_dependencies: list[str] | None = _UNSET,  # type: ignore[assignment]
    labels: list[str] | None = _UNSET,  # type: ignore[assignment]
    add_labels: list[str] | None = None,
    remove_labels: list[str] | None = None,
    status: str | None | Literal["__UNSET__"] = _UNSET,
    egg: dict[str, Any] | list[Any] | str | int | float | bool | None = _UNSET,  # type: ignore[assignment]
    ctx: Context | None = None,
    repo_root: str | None = None,
    hive_name: str | None = None,
) -> dict[str, Any]:
    """Update one or more existing tickets.

    Supports two call signatures:

    **Single update** (``ticket_id`` is a ``str``):
        Updates one ticket with any combination of fields.

    **Batch update** (``ticket_id`` is a ``list[str]``):
        Updates multiple tickets applying the same status, add_labels, and remove_labels to each.
        Non-batchable fields (``title``, ``description``, ``egg``, ``labels``,
        ``up_dependencies``, ``down_dependencies``) raise ``ValueError`` if set.

    Args:
        ticket_id: ID of the ticket to update (str), or list of IDs for batch update (list[str])
        title: New title for the ticket (single mode only)
        description: New description for the ticket (single mode only)
        parent: IMMUTABLE - Cannot be changed after ticket creation (raises ValueError if set)
        children: IMMUTABLE - Cannot be changed after ticket creation (raises ValueError if set)
        up_dependencies: New list of blocking dependency ticket IDs (single mode only)
        down_dependencies: New list of dependent ticket IDs (single mode only)
        labels: New list of labels, full replace (single mode only)
        add_labels: Labels to add to the ticket (additive, deduplicates)
        remove_labels: Labels to remove from the ticket
        status: New status
        egg: New egg data (arbitrary structured data, single mode only)
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)
        hive_name: Optional hive name for O(1) lookup. If not provided, scans all hives.

    Returns:
        dict: ``{"status": "success", "updated": [...], "not_found": [...], "failed": [...]}``

    Raises:
        ValueError: If parent/children are set, non-batchable fields used in batch mode,
            or validation fails

    Note:
        Parent and children fields are immutable after ticket creation.
        When updating dependencies, the change is automatically reflected
        bidirectionally in related tickets.
        Operation order per ticket: ``labels`` full-replace first, then ``add_labels``,
        then ``remove_labels``. If a label appears in both ``add_labels`` and
        ``remove_labels``, it ends up removed.
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _update_ticket(
            ticket_id=ticket_id,
            title=title,
            description=description,
            parent=parent,
            children=children,
            up_dependencies=up_dependencies,
            down_dependencies=down_dependencies,
            labels=labels,
            add_labels=add_labels,
            remove_labels=remove_labels,
            status=status,
            egg=egg,
            hive_name=hive_name,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def delete_ticket(
    ticket_ids: str | list[str],
    ctx: Context | None = None,
    repo_root: str | None = None,
    hive_name: str | None = None,
    clean_dependencies: bool = False,
) -> dict[str, Any]:
    """Delete one or more tickets and their subtrees.

    Supports two call signatures:

    **Single delete** (``ticket_ids`` is a ``str``):
        Deletes one ticket and its entire subtree using a two-phase algorithm.
        Returns ``{status, ticket_id, ticket_type, message}``.

    **Bulk delete** (``ticket_ids`` is a ``list[str]``):
        Iterates the list and applies the same two-phase algorithm to each ID.
        Returns ``{status, deleted, not_found, failed}``.
        An empty list returns success immediately with all arrays empty.

    Phase 1 — Collection:
        Calls ``_collect_deletion_set`` to walk the subtree depth-first and
        build an ordered list of ticket IDs (leaves first, root last).  If any
        ticket in the subtree cannot be read the operation halts before any
        directory is removed.

    Cleanup Phase — Dependency cleanup (optional, ``clean_dependencies=True``):
        Before any filesystem deletions, iterates every ticket in the deletion
        set and removes dangling dependency references from surviving tickets.
        For each dependency ID outside the deletion set:
        - If the dep is in the ticket's ``up_dependencies``, removes the ticket
          from that external ticket's ``down_dependencies``.
        - If the dep is in the ticket's ``down_dependencies``, removes the
          ticket from that external ticket's ``up_dependencies``.
        ``FileNotFoundError`` during removal is silently skipped; any other
        exception halts cleanup and returns an error immediately (no deletions
        have occurred at this point).

    Phase 2 — Deletion:
        Iterates the collected list bottom-up, resolves each ticket's
        directory, and removes it with ``shutil.rmtree``.  A safety guard
        prevents accidental deletion of the hive root directory.  If a
        directory is already missing it is logged and skipped; any other
        OS error halts the loop immediately.

    Args:
        ticket_ids: Single ticket ID (str) or list of ticket IDs (list[str]).
            When str, backward-compatible single-delete behavior.
            When list, bulk deletion of multiple independent tickets.
        ctx: FastMCP Context (auto-injected, gets client's repo root).
        repo_root: Optional explicit repo root path (fallback for non-Roots clients).
        hive_name: Optional hive name for O(1) lookup. If not provided, scans all hives.
        clean_dependencies: When ``True``, removes references to deleted tickets
            from surviving tickets' dependency fields before deletion.  Cleanup
            runs before any filesystem deletions; missing tickets are skipped
            silently; any other error halts the operation immediately.
            Defaults to ``False`` (dependency fields in surviving tickets are
            left unchanged).

    Returns:
        Single mode (str input):
            dict with ``status``, ``ticket_id``, ``ticket_type``, and ``message`` keys.
        Bulk mode (list input):
            dict with ``status``, ``deleted``, ``not_found``, and ``failed`` keys.

    Raises:
        ValueError: If a ticket doesn't exist, the hive is invalid, or a
            read/delete error occurs.

    Note:
        When a ticket is deleted:
        - All child tickets are deleted (cascade behaviour)
        - The entire directory subtree under each ticket is removed
        - Hive root directory is never deleted (safety guard)
        - Dependency cleanup is opt-in via ``clean_dependencies=True``; by
          default, relationship fields in surviving tickets are NOT modified
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _delete_ticket(
            ticket_ids=ticket_ids,
            hive_name=hive_name,
            clean_dependencies=clean_dependencies,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def show_ticket(
    ticket_ids: list[str],
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Retrieve and return ticket data for one or more ticket IDs.

    Args:
        ticket_ids: List of ticket IDs to retrieve (e.g., ['b.Amx', 'b.Xyz'])
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)

    Returns:
        dict: Bulk response with ticket data
            {
                "status": "success",
                "tickets": [
                    {
                        "ticket_id": str,
                        "ticket_type": str,
                        "title": str,
                        "description": str,
                        "labels": list[str],
                        "parent": str | None,
                        "children": list[str] | None,
                        "up_dependencies": list[str] | None,
                        "down_dependencies": list[str] | None,
                        "ticket_status": str,
                        "created_at": str,
                        "schema_version": str,
                        "egg": any,
                        "guid": str
                    },
                    ...
                ],
                "not_found": ["b.missing"],
                "errors": [{"id": "b.xxx", "reason": "egg resolver timed out: ..."}]
            }

        `not_found` contains IDs of tickets that could not be located or read.
        `errors` contains IDs of tickets that were found but failed during egg resolution.

    Example:
        >>> _show_ticket(['b.Amx', 'b.Xyz'])
        {'status': 'success', 'tickets': [{...}, {...}], 'not_found': [], 'errors': []}
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _show_ticket(
            ticket_ids=ticket_ids,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def get_types(
    ctx: Context | None = None,
    repo_root: str | None = None,
    hive_name: str | None = None,
) -> dict[str, Any]:
    """Get ticket type configuration from child_tiers config.

    Returns tier structure with friendly names and parent relationships, allowing LLMs
    to understand the ticket hierarchy and use friendly names in ticket operations.

    **Understanding Tier Hierarchy:**
    - **Bee (t0)**: Always the top-level tier, immutable and built-in
    - **Child tiers (t1, t2, t3...)**: Configured dynamically in ~/.bees/config.json
    - Each child tier has a parent tier (bee or another child tier)
    - Tiers are sequential: t1 → t2 → t3 (no gaps allowed)

    **Using Friendly Names:**
    - When creating tickets, you can use either tier IDs (t0, t1, t2) or friendly names
    - Example: ticket_type="Task" is equivalent to ticket_type="t1" (if t1 is configured as "Task")
    - Friendly names are case-sensitive as configured

    **Parent/Child Constraints:**
    - Bees (t0) cannot have parents, only children (t1 tickets if configured)
    - Child tier tickets (t1, t2, t3...) MUST have a parent from the tier above
    - Example hierarchy: Bee → Task (t1) → Subtask (t2)

    **Empty Configuration:**
    - If child_tiers is empty {}, only bees are allowed (bees-only system)
    - This is valid and indicates no child tiers are configured

    **Per-Hive Mode:**
    - If hive_name is provided, returns tiers for that specific hive only
    - If hive_name is omitted and any hive has non-None child_tiers, returns per-hive map
    - If hive_name is omitted and no hive has non-None child_tiers, returns flat tiers (backward compatible)

    Args:
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)
        hive_name: Optional hive name to get tiers for a specific hive

    Returns:
        dict: Tier configuration with structure:
            When hive_name provided or no per-hive config:
            {
                "status": "success",
                "tiers": {
                    "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                    "t1": {"singular": "Task" | null, "plural": "Tasks" | null, "parent": "t0"},
                    ...
                }
            }

            When hive_name omitted and per-hive config exists:
            {
                "status": "success",
                "per_hive": true,
                "hives": {
                    "hive_name": {
                        "tiers": {
                            "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                            ...
                        }
                    },
                    ...
                }
            }

    Raises:
        ValueError: If config not found or hive_name not found in configuration

    Example:
        >>> _get_types()
        {
            "status": "success",
            "tiers": {
                "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                "t1": {"singular": "Task", "plural": "Tasks", "parent": "t0"},
                "t2": {"singular": "Subtask", "plural": "Subtasks", "parent": "t1"}
            }
        }

        >>> _get_types(hive_name="backend")
        {
            "status": "success",
            "tiers": {
                "t0": {"singular": "Bee", "plural": "Bees", "parent": null}
            }
        }
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _get_types(
            hive_name=hive_name,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def colonize_hive(
    name: str,
    path: str,
    child_tiers: dict[str, list] | None = None,
    egg_resolver: str | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Create and register a new hive at the specified path.

    This MCP tool wrapper exposes the colonize_hive() core function, which:
    - Normalizes the hive display name
    - Validates the path is absolute, exists, and within the repository
    - Checks for duplicate normalized hive names
    - Creates the hive directory structure (/evicted, .hive marker)
    - Registers the hive in ~/.bees/config.json

    LLM USAGE INSTRUCTIONS:
        ALWAYS ask the user for the hive name and path if they are not explicitly provided.
        - Ask: "What should the hive be named?" if name is not provided
        - Ask: "Where should the hive be located (absolute path)?" if path is not provided
        DO NOT proceed with this tool call until both parameters are provided by the user.

    Args:
        name: Display name for the hive (e.g., 'Back End', 'Frontend')
               Will be normalized for internal use (e.g., 'back_end', 'frontend')
        path: Absolute path to the directory where the hive should be created
              Must be within the repository root
        child_tiers: Optional per-hive child tiers configuration
                     Format: {"t1": ["Task", "Tasks"], "t2": ["Subtask", "Subtasks"]}
                     If None: hive inherits from scope/global config
                     If {}: hive is bees-only (no child tiers)
        egg_resolver: Optional path to egg resolver script for this hive (e.g., '/repo/resolve_eggs.sh')
                      If None: hive inherits egg_resolver from scope/global config
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)

    Returns:
        dict: Operation result with status and details
            On success: {
                'status': 'success',
                'message': 'Hive created and registered successfully',
                'normalized_name': str,  # Internal hive identifier
                'display_name': str,     # Original display name
                'path': str,             # Absolute path to hive directory
                'child_tiers': dict | None  # Child tiers config if provided
            }
            On error: {
                'status': 'error',
                'message': str,          # Human-readable error description
                'error_type': str,       # Error category
                'validation_details': dict  # Additional error context
            }

    Raises:
        ValueError: If validation fails or operation cannot be completed

    Example:
        >>> _colonize_hive('Back End', '/Users/user/projects/myrepo/tickets/backend')
        {
            'status': 'success',
            'message': 'Hive created and registered successfully',
            'normalized_name': 'back_end',
            'display_name': 'Back End',
            'path': '/Users/user/projects/myrepo/tickets/backend'
        }

    Error Conditions:
        - Invalid name: Name normalizes to empty string (no alphanumeric chars)
        - Invalid path: Path is not absolute, doesn't exist, or outside repo
        - Duplicate name: Normalized name already exists in registry
        - Invalid child_tiers: Gaps in tier keys, invalid format, or validation fails
        - Filesystem error: Cannot create directories or write files
        - Config error: Cannot read or write ~/.bees/config.json
    """
    # Special colonize_hive fallback logic:
    # 1. Try MCP Roots protocol via get_repo_root(ctx)
    # 2. If roots succeeds, validate the hive path is within that repo
    # 3. If hive path is outside detected repo, fall back to path-based detection
    # 4. If roots fails entirely, use path-based detection
    hive_path = Path(path)
    resolved_root = None

    if ctx:
        try:
            roots_root = await get_repo_root(ctx)
            if roots_root:
                logger.info(f"colonize_hive adapter: Got repo root from MCP context: {roots_root}")
                # Verify the hive path is within the detected repo root
                try:
                    hive_path.resolve(strict=False).relative_to(roots_root.resolve())
                    resolved_root = roots_root
                except ValueError:
                    # Hive path is outside detected repo root — use hive path
                    logger.warning(
                        f"colonize_hive adapter: Hive path {hive_path} outside repo root {roots_root}, "
                        "using hive path"
                    )
                    resolved_root = get_repo_root_from_path(hive_path)
            else:
                logger.warning("colonize_hive adapter: Roots protocol unavailable, using hive path")
                resolved_root = get_repo_root_from_path(hive_path)
        except Exception:
            resolved_root = get_repo_root_from_path(hive_path)
    elif repo_root:
        resolved_root = Path(repo_root)
    else:
        resolved_root = get_repo_root_from_path(hive_path)

    return await _colonize_hive(
        name=name,
        path=path,
        child_tiers=child_tiers,
        repo_root=resolved_root,
        egg_resolver=egg_resolver,
    )


@mcp.tool()
async def list_hives(
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """List all registered hives in the repository.

    Reads ~/.bees/config.json from the client's repository to retrieve all
    registered hives and returns structured information about each hive
    including display name, normalized name, and path.

    Args:
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)

    Returns:
        dict: List of hives with their details
            On success with hives: {
                'status': 'success',
                'hives': [
                    {
                        'display_name': str,      # User-facing hive name
                        'normalized_name': str,   # Internal identifier
                        'path': str              # Absolute path to hive directory
                    },
                    ...
                ]
            }
            On success with no hives: {
                'status': 'success',
                'hives': [],
                'message': 'No hives configured'
            }

    Example:
        >>> await _list_hives(ctx)
        {
            'status': 'success',
            'hives': [
                {
                    'display_name': 'Back End',
                    'normalized_name': 'back_end',
                    'path': '/Users/user/projects/myrepo/tickets/backend'
                },
                {
                    'display_name': 'Frontend',
                    'normalized_name': 'frontend',
                    'path': '/Users/user/projects/myrepo/tickets/frontend'
                }
            ]
        }
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _list_hives(resolved_root=resolved_root)


@mcp.tool()
async def abandon_hive(
    hive_name: str,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Stop tracking a hive without deleting ticket files.

    Removes the hive entry from ~/.bees/config.json while leaving all ticket
    files and the .hive marker intact on the filesystem. This allows users
    to stop tracking a hive without data loss and re-colonize it later if needed.

    Args:
        hive_name: Display name or normalized name of the hive to abandon
        ctx: FastMCP Context (auto-injected, gets client's repo root)
        repo_root: Optional explicit repo root path (fallback for non-Roots clients)

    Returns:
        dict: Operation result with status and details
            {
                'status': 'success',
                'message': 'Hive abandoned successfully',
                'display_name': str,     # Original display name
                'normalized_name': str,  # Internal hive identifier
                'path': str              # Path where files remain
            }

    Raises:
        ValueError: If hive doesn't exist or operation cannot be completed

    Example:
        >>> _abandon_hive('Back End')
        {
            'status': 'success',
            'message': 'Hive "Back End" abandoned successfully',
            'display_name': 'Back End',
            'normalized_name': 'back_end',
            'path': '/Users/user/projects/myrepo/tickets/backend'
        }

    Error Conditions:
        - Hive not found: Normalized name doesn't exist in config
        - Config read error: Cannot read ~/.bees/config.json
        - Config write error: Cannot write updated config
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _abandon_hive(hive_name=hive_name, resolved_root=resolved_root)


@mcp.tool()
async def rename_hive(
    old_name: str,
    new_name: str,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Rename a hive by updating its name in config and .hive marker.

    With the new ID system, hive names are NOT part of ticket IDs, so renaming
    a hive only requires updating configuration and metadata. Ticket files and
    IDs remain unchanged.

    This operation updates:
    - Config: changes hive key from old_name to new_name, updates display_name
    - .hive marker: updates normalized_name and display_name in hive directory marker file

    This operation does NOT update:
    - Ticket IDs (no longer contain hive name)
    - Ticket filenames (unchanged, based on ID)
    - Frontmatter (id field unchanged)

    Args:
        old_name: Current hive name (will be normalized for lookup)
        new_name: Desired new hive name (will be normalized and validated for uniqueness)
        ctx: FastMCP Context (auto-injected, gets client's repo root)

    Returns:
        dict: Success/error status with operation details
            On success: {
                'status': 'success',
                'message': 'Hive renamed successfully',
                'old_name': str,
                'new_name': str
            }
            On error: {
                'status': 'error',
                'message': str,
                'error_type': str
            }

    Raises:
        ValueError: If old_name doesn't exist or new_name conflicts with existing hive

    Example:
        >>> rename_hive('backend', 'api_layer')
        {'status': 'success', 'old_name': 'backend', 'new_name': 'api_layer', ...}
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _rename_hive(old_name=old_name, new_name=new_name, resolved_root=resolved_root)


@mcp.tool()
async def sanitize_hive(
    hive_name: str,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Validate and auto-fix malformed tickets in a hive.

    Runs the linter on all tickets in the specified hive with hive-aware validations:
    - Validates ticket IDs match hive prefix format (hive_name.bees-*)
    - Runs existing linter rules (structure, required fields, bidirectional relationships, etc.)
    - Attempts to automatically fix detected problems where possible

    Args:
        hive_name: Display name or normalized form of hive to sanitize
        ctx: FastMCP Context (auto-injected, gets client's repo root)

    Returns:
        Dict with:
        - status: 'success' or 'error'
        - message: Summary message
        - fixes_applied: List of fix actions taken (if any)
        - errors_remaining: List of unfixable errors (if any)
        - is_corrupt: Whether database is corrupt after sanitization

    Example:
        >>> sanitize_hive("Backend")
        {
            "status": "success",
            "message": "Hive sanitized successfully",
            "fixes_applied": [...],
            "errors_remaining": [],
            "is_corrupt": False
        }
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _sanitize_hive(hive_name=hive_name, resolved_root=resolved_root)


@mcp.tool()
def add_named_query(name: str, query_yaml: str) -> dict[str, Any]:
    """Register a new named query for reuse.

    All queries are validated when registered to ensure they have valid structure.

    Args:
        name: Name for the query (used to execute it later)
        query_yaml: YAML string representing the query structure

    Returns:
        dict: Success status and query information

    Raises:
        ValueError: If query structure is invalid or name is invalid

    Example:
        query_yaml = '''
        - - type=t1
          - label~beta
        - - parent
        '''
    """
    return _add_named_query(name=name, query_yaml=query_yaml)


@mcp.tool()
async def execute_named_query(
    query_name: str,
    hive_names: list[str] | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Execute a named query.

    Before execution, performs a pre-flight integrity check on all participating
    hives. Participating hives are the hives listed in hive_names if provided,
    or all configured hives otherwise. The check is fail-fast: the first corrupt
    hive encountered causes an immediate hive_corrupt error return without
    proceeding to the PipelineEvaluator.

    Args:
        query_name: Name of the registered query to execute
        hive_names: Optional list of hive names to filter results (default: None = all hives)
        ctx: FastMCP Context (auto-injected, gets client's repo root)

    Returns:
        dict: Query results with list of matching ticket IDs and metadata, or a
            hive_corrupt error dict if any participating hive fails integrity checks

    Raises:
        ValueError: If query name not found, hive not found, or execution fails

    Example:
        execute_named_query("open_tasks")
        execute_named_query("open_tasks", ["backend", "frontend"])
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _execute_named_query(
            query_name=query_name,
            hive_names=hive_names,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def execute_freeform_query(
    query_yaml: str,
    hive_names: list[str] | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Execute a YAML query pipeline directly without persisting it.

    This function enables one-step ad-hoc query execution without polluting
    the query registry. The query is validated and executed immediately without
    being saved to disk.

    Before execution, performs a pre-flight integrity check on all participating
    hives. Participating hives are the hives listed in hive_names if provided,
    or all configured hives otherwise. The check is fail-fast: the first corrupt
    hive encountered causes an immediate hive_corrupt error return without
    proceeding to the PipelineEvaluator.

    Args:
        query_yaml: YAML string representing the query pipeline structure
        hive_names: Optional list of hive names to filter results (default: None = all hives)
        ctx: FastMCP Context (auto-injected, gets client's repo root)

    Returns:
        dict: Query results with list of matching ticket IDs and metadata, or a
            hive_corrupt error dict if any participating hive fails integrity checks
            {
                "status": "success",
                "result_count": int,
                "ticket_ids": list[str],
                "stages_executed": int
            }

    Raises:
        ValueError: If query structure is invalid, hive not found, or execution fails

    Example:
        execute_freeform_query("- ['type=bee']\\n- ['children']")
        execute_freeform_query("- ['type=t1', 'status=open']", ["backend"])
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _execute_freeform_query(
            query_yaml=query_yaml,
            hive_names=hive_names,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def generate_index(
    status: str | None = None,
    type: str | None = None,
    hive_name: str | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Generate markdown index of all tickets with optional filters.

    Scans the tickets directory and creates a formatted markdown index.
    Optionally filters tickets by status and/or type. Can generate per-hive
    indexes or indexes for all hives.

    When hive_name is provided, generates and writes index only for that hive
    to {hive_path}/index.md. Returns a hive_corrupt error if integrity fails.

    When hive_name is omitted, iterates all registered hives and generates
    separate index.md files for each healthy hive. Corrupt hives are skipped
    (not written) and their names are collected in skipped_hives.

    Args:
        status: Optional status filter (e.g., 'open', 'completed')
        type: Optional type filter (e.g., 'bee', 't1', 't2')
        hive_name: Optional hive name to generate index for specific hive only.
                   If provided, generates index only for that hive.
                   If omitted, generates indexes for all healthy hives.

    Returns:
        dict: Success response with keys:
              - status: "success"
              - markdown: generated markdown string (last hive processed, or
                empty string if all hives were skipped/no hives configured)
              - skipped_hives: list of hive names skipped due to corruption
                (always present; empty list when hive_name is specified)
              On corrupt single-hive request, returns error dict with keys:
              status, error_type, hive_name, message, errors.

    Example:
        result = _generate_index()
        result = _generate_index(status='open')
        result = _generate_index(type='bee')
        result = _generate_index(status='open', type='t1')
        result = _generate_index(hive_name='backend')
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _generate_index(
            status=status,
            type=type,
            hive_name=hive_name,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def undertaker(
    hive_name: str,
    query_yaml: str | None = None,
    query_name: str | None = None,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Archive bee tickets matching a query into the hive's cemetery/ directory.

    Thin async wrapper that resolves repo_root, sets context, and delegates
    to _undertaker_core.

    Args:
        hive_name: Hive to operate on (required)
        query_yaml: YAML string for freeform query (mutually exclusive with query_name)
        query_name: Name of a registered query (mutually exclusive with query_yaml)
        ctx: FastMCP Context (auto-injected)
        repo_root: Optional explicit repo root path

    Returns:
        dict with status, archived_count, archived_guids, skipped
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _undertaker(
            hive_name=hive_name,
            query_yaml=query_yaml,
            query_name=query_name,
            resolved_root=resolved_root,
        )


@mcp.tool()
async def move_bee(
    bee_ids: list[str],
    destination_hive: str,
    ctx: Context | None = None,
    repo_root: str | None = None,
) -> dict[str, Any]:
    """Move bee tickets to a different hive within the same scope.

    Thin async wrapper that resolves repo_root, sets context, and delegates
    to _move_bee_core.

    Destination hive integrity is checked before executing the move.
    Source hive corruption does NOT block the move.

    Constraints:
        - Only bee tickets (b. prefix) can be moved; non-bee IDs are rejected
        - Source and destination hives must belong to the same scope
        - Cemetery is never a valid destination
        - Bee IDs are preserved unchanged — only the directory location changes
        - Each bee is moved atomically and independently (per-bee atomic move)

    Args:
        bee_ids (list[str]): Bee ticket IDs to move (e.g., ["b.Amx", "b.X4F"]).
                             Empty list returns success immediately with no operations performed.
        destination_hive (str): Normalized name of the destination hive (e.g., "back_end").
        ctx (Context | None): FastMCP Context (auto-injected when called from MCP server).
        repo_root (str | None): Optional explicit repo root path; resolved from MCP context
                                if not provided.

    Returns:
        dict: Operation result. On success:
            {
                'status': 'success',
                'moved': list[str],      # Bee IDs successfully moved
                'skipped': list[str],    # Bee IDs already in destination hive
                'not_found': list[str],  # Bee IDs not found in any registered hive
                'failed': list[dict],    # Dicts with 'id' and 'reason' for each failure
            }
        On error (destination hive not found, cemetery destination, etc.):
            {
                'status': 'error',
                'message': str,      # Human-readable error description
                'error_type': str,   # Error category (e.g., 'hive_not_found', 'cemetery_destination')
            }
        On corrupt destination hive:
            {
                'status': 'error',
                'error_type': 'hive_corrupt',
                'hive_name': str,    # Normalized name of the corrupt hive
                'message': str,      # Human-readable error description
                'errors': list[str], # Lint error messages from integrity check
            }

    Example:
        >>> await _move_bee(["b.Amx", "b.X4F"], "backlog")
        {
            'status': 'success',
            'moved': ['b.Amx', 'b.X4F'],
            'skipped': [],
            'not_found': [],
            'failed': []
        }

    Error Conditions:
        - hive_not_found: destination_hive not registered in config
        - cemetery_destination: destination is the cemetery directory
        - hive_corrupt: destination hive fails integrity checks (source hive is not checked)
        - Malformed ID: bee_id fails ticket ID format validation → added to failed list
        - Non-bee ticket: bee_id does not start with 'b.' → added to failed list
        - Cross-scope move: source and destination in different scopes → added to failed list
        - Filesystem error: shutil.move fails → added to failed list with exception message
    """
    if ctx:
        resolved_root = await resolve_repo_root(ctx, repo_root)
    else:
        resolved_root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(resolved_root):
        return await _move_bee(
            bee_ids=bee_ids,
            destination_hive=destination_hive,
            resolved_root=resolved_root,
        )


if __name__ == "__main__":
    logger.info("Running Bees MCP Server directly")
    start_server()
    mcp.run()
