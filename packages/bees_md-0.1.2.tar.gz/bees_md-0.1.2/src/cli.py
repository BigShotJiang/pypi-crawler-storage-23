"""CLI entry point for the bees ticket management system.

All commands write JSON to stdout. Exit codes:
  0 = success (result["status"] == "success")
  1 = known error (result["status"] == "error")
  2 = usage/argument error
"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

from .config import set_config_path
from .repo_utils import get_repo_root_from_path
from .repo_context import repo_root_context
from .mcp_ticket_ops import _create_ticket, _update_ticket, _delete_ticket, _show_ticket, _get_types
from .mcp_query_ops import _add_named_query, _execute_named_query, _execute_freeform_query
from .mcp_hive_ops import colonize_hive_core, _list_hives, _abandon_hive, _rename_hive, _sanitize_hive
from .mcp_index_ops import _generate_index
from .mcp_move_bee import _move_bee
from .mcp_undertaker import _undertaker
from .sting import handle_sting
from .setup_claude import handle_setup_claude_cli

logger = logging.getLogger(__name__)

# Sentinel for update-ticket: absent flag = "do not change"
_UNSET = "__UNSET__"


class BeesArgumentParser(argparse.ArgumentParser):
    """ArgumentParser that writes usage errors as JSON to stdout."""

    def error(self, message):
        json.dump({"status": "error", "message": message}, sys.stdout)
        print()
        sys.exit(2)


def parse_json_arg(value, arg_name):
    """Parse a JSON string argument. 'null' -> None."""
    if value == "null":
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        raise argparse.ArgumentTypeError(f"Invalid JSON for {arg_name}: {value}") from exc


# ---------------------------------------------------------------------------
# Shared handler helpers
# ---------------------------------------------------------------------------

def _output_result(result: dict) -> None:
    """Write JSON result to stdout and exit with appropriate code."""
    json.dump(result, sys.stdout)
    print()
    sys.exit(0 if result.get("status") == "success" else 1)


def _run_in_repo(coro) -> dict:
    """Resolve repo root, set context, and run an async coroutine."""
    root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(root):
        return asyncio.run(coro)


def _configure_file_logging() -> Path:
    """Redirect root logger to ~/.bees/mcp.log (file-only). Returns log path."""
    log_path = Path.home() / ".bees" / "mcp.log"
    log_path.parent.mkdir(exist_ok=True)
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    file_handler = logging.FileHandler(log_path, mode="a")
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    root_logger.addHandler(file_handler)
    root_logger.setLevel(logging.INFO)
    return log_path


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def handle_create_ticket(args):
    result = _run_in_repo(
        _create_ticket(
            ticket_type=args.type,
            title=args.title,
            hive_name=args.hive,
            description=args.description or "",
            parent=args.parent,
            children=parse_json_arg(args.children, "--children") if args.children is not None else None,
            up_dependencies=parse_json_arg(args.up_deps, "--up-deps") if args.up_deps is not None else None,
            down_dependencies=parse_json_arg(args.down_deps, "--down-deps") if args.down_deps is not None else None,
            labels=parse_json_arg(args.labels, "--labels") if args.labels is not None else None,
            status=args.status,
            egg=parse_json_arg(args.egg, "--egg") if args.egg is not None else None,
        )
    )
    _output_result(result)


def handle_show_ticket(args):
    root = get_repo_root_from_path(Path.cwd())
    with repo_root_context(root):
        result = asyncio.run(_show_ticket(ticket_ids=args.ids, resolved_root=root))
    _output_result(result)


def handle_update_ticket(args):
    root = get_repo_root_from_path(Path.cwd())

    # Build kwargs: only pass fields that were explicitly provided (not _UNSET)
    kwargs = {
        "ticket_id": args.id,
    }

    if args.title is not _UNSET:
        kwargs["title"] = args.title
    if args.description is not _UNSET:
        kwargs["description"] = args.description
    if args.status is not _UNSET:
        kwargs["status"] = args.status
    if args.labels is not _UNSET:
        kwargs["labels"] = parse_json_arg(args.labels, "--labels")
    if args.up_deps is not _UNSET:
        kwargs["up_dependencies"] = parse_json_arg(args.up_deps, "--up-deps")
    if args.down_deps is not _UNSET:
        kwargs["down_dependencies"] = parse_json_arg(args.down_deps, "--down-deps")
    if args.egg is not _UNSET:
        kwargs["egg"] = parse_json_arg(args.egg, "--egg")
    if args.hive is not _UNSET:
        kwargs["hive_name"] = args.hive

    with repo_root_context(root):
        result = asyncio.run(_update_ticket(**kwargs))
    _output_result(result)


def handle_delete_ticket(args):
    ticket_ids = args.ids[0] if len(args.ids) == 1 else args.ids
    result = _run_in_repo(
        _delete_ticket(
            ticket_ids=ticket_ids,
            hive_name=args.hive if args.hive is not None else None,
            clean_dependencies=args.clean_dependencies,
        )
    )
    _output_result(result)


def handle_get_types(args):
    result = _run_in_repo(
        _get_types(hive_name=args.hive if args.hive is not None else None)
    )
    _output_result(result)


# ---------------------------------------------------------------------------
# Query handlers
# ---------------------------------------------------------------------------

def handle_add_named_query(args):
    result = _add_named_query(name=args.name, query_yaml=args.yaml)
    _output_result(result)


def handle_execute_named_query(args):
    hive_list = args.hives.split(",") if args.hives else None
    result = _run_in_repo(_execute_named_query(query_name=args.name, hive_names=hive_list))
    _output_result(result)


def handle_execute_freeform_query(args):
    hive_list = args.hives.split(",") if args.hives else None
    result = _run_in_repo(_execute_freeform_query(query_yaml=args.yaml, hive_names=hive_list))
    _output_result(result)


# ---------------------------------------------------------------------------
# Hive handlers
# ---------------------------------------------------------------------------

def handle_colonize_hive(args):
    parsed_child_tiers = parse_json_arg(args.child_tiers, "--child-tiers") if args.child_tiers is not None else None
    result = _run_in_repo(
        colonize_hive_core(
            name=args.name,
            path=args.path,
            child_tiers=parsed_child_tiers,
            egg_resolver=args.egg_resolver,
        )
    )
    _output_result(result)


def handle_list_hives(args):
    result = _run_in_repo(_list_hives())
    _output_result(result)


def handle_abandon_hive(args):
    result = _run_in_repo(_abandon_hive(hive_name=args.name))
    _output_result(result)


def handle_rename_hive(args):
    result = _run_in_repo(_rename_hive(old_name=args.old_name, new_name=args.new_name))
    _output_result(result)


def handle_sanitize_hive(args):
    result = _run_in_repo(_sanitize_hive(hive_name=args.name))
    _output_result(result)


# ---------------------------------------------------------------------------
# Utility handlers
# ---------------------------------------------------------------------------

def handle_generate_index(args):
    result = _run_in_repo(_generate_index(status=args.status, type=args.type, hive_name=args.hive))
    _output_result(result)


def handle_move_bee(args):
    result = _run_in_repo(_move_bee(bee_ids=args.ids, destination_hive=args.destination))
    _output_result(result)


def handle_undertaker(args):
    result = _run_in_repo(
        _undertaker(
            hive_name=args.hive,
            query_yaml=args.yaml,
            query_name=args.query_name,
        )
    )
    _output_result(result)


# ---------------------------------------------------------------------------
# Serve handler
# ---------------------------------------------------------------------------

def handle_serve(args):
    # [serve] guard: fastmcp must be importable before we pull in mcp_server
    try:
        import fastmcp  # noqa: F401
    except ImportError:
        json.dump(
            {
                "status": "error",
                "message": (
                    "Missing required dependency: fastmcp. "
                    "Install with: pip install bees-cli[serve]"
                ),
            },
            sys.stdout,
        )
        print()
        sys.exit(1)

    # Neither flag supplied → print usage and exit
    if not args.stdio and not args.http:
        # args lives on the serve subparser; re-parse to get usage from it
        args.serve_parser.print_usage()
        sys.exit(2)

    if args.config:
        set_config_path(args.config)

    if args.http:
        # Reconfigure logging to file-only (required for clean HTTP server output)
        _configure_file_logging()

        # Deferred imports — must not happen at module level to avoid pulling
        # uvicorn/starlette/fastmcp at CLI load time.
        try:
            import uvicorn
            from starlette.requests import Request
            from starlette.responses import JSONResponse
            from .mcp_server import start_server, stop_server, mcp, _health_check
            from .mcp_undertaker import UndertakerScheduler
            from .config import load_bees_config
        except ImportError as e:
            logger.error(f"Failed to start server: Missing dependency - {e}")
            logger.error("Please install required dependencies with: poetry install")
            sys.exit(1)

        # Nested helpers defined here to avoid top-level starlette/logging deps
        async def health_endpoint(request: Request) -> JSONResponse:
            try:
                health_data = _health_check()
                return JSONResponse(content=health_data, status_code=200)
            except Exception as exc:
                logger.error(f"Health check failed: {exc}")
                return JSONResponse(
                    content={"status": "error", "message": str(exc)}, status_code=500
                )

        def setup_http_routes(app):
            app.add_route("/health", health_endpoint, methods=["GET", "POST"])
            logger.info("HTTP routes configured: /health")
            logger.info("MCP endpoint /mcp provided by FastMCP")

        def setup_signal_handlers(shutdown_callback):
            import signal as _signal

            def _handler(signum, frame):
                logger.info(f"Received signal {signum}, shutting down gracefully...")
                shutdown_callback()

            _signal.signal(_signal.SIGINT, _handler)
            _signal.signal(_signal.SIGTERM, _handler)

        try:
            repo_root = get_repo_root_from_path(Path.cwd())

            with repo_root_context(repo_root):
                logger.info("Validating bees config schema...")
                try:
                    bees_config = load_bees_config()
                    if bees_config is not None:
                        tier_count = len(bees_config.child_tiers) if bees_config.child_tiers else 0
                        logger.info(
                            f"Bees config validated successfully: {tier_count} tier(s) configured"
                        )
                        for hive_name, hive_cfg in bees_config.hives.items():
                            has_seconds = hive_cfg.undertaker_schedule_seconds is not None
                            has_qy = hive_cfg.undertaker_schedule_query_yaml is not None
                            has_qn = hive_cfg.undertaker_schedule_query_name is not None
                            has_any = (
                                has_seconds
                                or has_qy
                                or has_qn
                                or hive_cfg.undertaker_schedule_log_path is not None
                            )
                            if not has_any:
                                continue
                            if not has_seconds:
                                raise ValueError(
                                    f"Hive '{hive_name}' undertaker-schedule requires interval_seconds"
                                )
                            if has_qy and has_qn:
                                raise ValueError(
                                    f"Hive '{hive_name}' undertaker-schedule must specify "
                                    f"query_yaml or query_name, not both"
                                )
                            if not has_qy and not has_qn:
                                raise ValueError(
                                    f"Hive '{hive_name}' undertaker-schedule requires "
                                    f"query_yaml or query_name"
                                )
                            if hive_cfg.undertaker_schedule_log_path:
                                log_parent = Path(hive_cfg.undertaker_schedule_log_path).parent
                                if not log_parent.exists():
                                    raise ValueError(
                                        f"Hive '{hive_name}' undertaker-schedule.log_path parent "
                                        f"directory does not exist: {log_parent}"
                                    )
                            logger.info(
                                f"Hive '{hive_name}' undertaker schedule: "
                                f"every {hive_cfg.undertaker_schedule_seconds}s"
                            )
                    else:
                        logger.info("No bees config found - operating in default mode")
                except ValueError as e:
                    logger.error("=" * 60)
                    logger.error("INVALID BEES CONFIGURATION")
                    logger.error("=" * 60)
                    logger.error(f"Configuration validation failed: {e}")
                    logger.error("")
                    logger.error("Fix ~/.bees/config.json to resolve validation errors.")
                    logger.error("See documentation for child_tiers schema requirements:")
                    logger.error("  - Keys must be t1, t2, t3... with no gaps")
                    logger.error("  - Values must be [] or [singular, plural]")
                    logger.error("  - Friendly names must be unique across tiers")
                    logger.error("=" * 60)
                    sys.exit(2)

                logger.info("=" * 60)
                logger.info("Bees MCP Server")
                logger.info("=" * 60)
                logger.info(f"Host: {args.host}")
                logger.info(f"Port: {args.port}")
                logger.info("=" * 60)

                start_server()

                undertaker_scheduler = None
                if bees_config is not None:
                    undertaker_scheduler = UndertakerScheduler(bees_config, repo_root)

                http_app = mcp.http_app()
                setup_http_routes(http_app)

                if undertaker_scheduler is not None and undertaker_scheduler.active:
                    undertaker_scheduler.start()

                def _shutdown():
                    if undertaker_scheduler is not None:
                        undertaker_scheduler.stop()
                    stop_server()

                setup_signal_handlers(_shutdown)

                logger.info(f"Launching HTTP server on {args.host}:{args.port}...")
                logger.info("MCP Server is running. Press Ctrl+C to stop.")

                uvicorn.run(http_app, host=args.host, port=args.port, log_level="info")

        except FileNotFoundError as e:
            logger.error(f"Configuration error: {e}")
            sys.exit(1)
        except OSError as e:
            if "Address already in use" in str(e) or e.errno == 48:
                logger.error(f"Failed to start server: Port {args.port} is already in use")
                logger.error(
                    f"Please stop the other service using port {args.port} or use a different port"
                )
            elif "Permission denied" in str(e) or e.errno == 13:
                logger.error(
                    f"Failed to start server: Permission denied for {args.host}:{args.port}"
                )
                logger.error(
                    "Try using a port number above 1024 or run with appropriate permissions"
                )
            else:
                logger.error(f"Failed to start server: Network error - {e}")
                logger.error(f"Check that {args.host}:{args.port} is a valid address")
            sys.exit(1)
        except RuntimeError as e:
            logger.error(f"Failed to start server: {e}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            sys.exit(1)
        return

    # --stdio path
    # Reconfigure logging to file-only (required for stdio MCP compatibility)
    _configure_file_logging()

    # Deferred import — must not happen at module level to avoid pulling fastmcp
    # at CLI load time.  The [serve] guard above ensures fastmcp is present before
    # this import executes (mcp_server imports fastmcp at its module level).
    from .mcp_server import start_server, mcp  # noqa: PLC0415

    try:
        repo_root = get_repo_root_from_path(Path.cwd())
        with repo_root_context(repo_root):
            start_server()
            mcp.run(transport="stdio")
    except Exception as exc:
        logger.error(f"stdio transport error: {exc}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Parser construction
# ---------------------------------------------------------------------------

def build_parser():
    parser = BeesArgumentParser(
        prog="bees",
        description="Bees ticket management CLI",
    )
    subparsers = parser.add_subparsers(
        title="commands",
        parser_class=BeesArgumentParser,
    )

    # --- create-ticket ---
    p_create = subparsers.add_parser("create-ticket", help="Create a new ticket")
    p_create.add_argument("--type", required=True, dest="type", help="Ticket type (bee, t1, t2, or friendly name)")
    p_create.add_argument("--title", required=True, help="Ticket title")
    p_create.add_argument("--hive", required=True, help="Hive name")
    p_create.add_argument("--description", default=None, help="Ticket description")
    p_create.add_argument("--parent", default=None, help="Parent ticket ID")
    p_create.add_argument("--children", default=None, metavar="JSON", help="JSON array of child ticket IDs")
    p_create.add_argument("--up-deps", default=None, dest="up_deps", metavar="JSON", help="JSON array of blocking dependency IDs")
    p_create.add_argument("--down-deps", default=None, dest="down_deps", metavar="JSON", help="JSON array of dependent ticket IDs")
    p_create.add_argument("--labels", default=None, metavar="JSON", help="JSON array of label strings")
    p_create.add_argument("--status", default=None, help="Ticket status")
    p_create.add_argument("--egg", default=None, metavar="JSON", help="Egg data as JSON value")
    p_create.set_defaults(func=handle_create_ticket)

    # --- show-ticket ---
    p_show = subparsers.add_parser("show-ticket", help="Retrieve one or more tickets")
    p_show.add_argument("ids", nargs="+", metavar="ID", help="One or more ticket IDs")
    p_show.set_defaults(func=handle_show_ticket)

    # --- update-ticket ---
    p_update = subparsers.add_parser("update-ticket", help="Update an existing ticket")
    p_update.add_argument("id", metavar="ID", help="Ticket ID to update")
    p_update.add_argument("--title", default=_UNSET, help="New title")
    p_update.add_argument("--description", default=_UNSET, help="New description")
    p_update.add_argument("--status", default=_UNSET, help="New status")
    p_update.add_argument("--labels", default=_UNSET, dest="labels", metavar="JSON", help="JSON array of labels (null to clear)")
    p_update.add_argument("--up-deps", default=_UNSET, dest="up_deps", metavar="JSON", help="JSON array of blocking dependency IDs (null to clear)")
    p_update.add_argument("--down-deps", default=_UNSET, dest="down_deps", metavar="JSON", help="JSON array of dependent ticket IDs (null to clear)")
    p_update.add_argument("--egg", default=_UNSET, metavar="JSON", help="Egg data as JSON value (null to clear)")
    p_update.add_argument("--hive", default=_UNSET, help="Hive name for O(1) lookup")
    p_update.set_defaults(func=handle_update_ticket)

    # --- delete-ticket ---
    p_delete = subparsers.add_parser("delete-ticket", help="Delete one or more tickets")
    p_delete.add_argument("ids", nargs="+", metavar="ID", help="One or more ticket IDs")
    p_delete.add_argument("--hive", default=None, help="Hive name for O(1) lookup")
    p_delete.add_argument(
        "--clean-dependencies",
        action="store_true",
        default=False,
        dest="clean_dependencies",
        help="Remove dependency references from surviving tickets",
    )
    p_delete.add_argument(
        "--no-clean-dependencies",
        action="store_false",
        dest="clean_dependencies",
        help="Do not remove dependency references (default)",
    )
    p_delete.set_defaults(func=handle_delete_ticket)

    # --- get-types ---
    p_types = subparsers.add_parser("get-types", help="Get ticket type configuration")
    p_types.add_argument("--hive", default=None, help="Hive name to get tiers for specific hive")
    p_types.set_defaults(func=handle_get_types)

    # --- add-named-query ---
    p_anq = subparsers.add_parser("add-named-query", help="Register a named query")
    p_anq.add_argument("name", metavar="NAME", help="Query name")
    p_anq.add_argument("--yaml", required=True, metavar="YAML", help="YAML query string")
    p_anq.set_defaults(func=handle_add_named_query)

    # --- execute-named-query ---
    p_enq = subparsers.add_parser("execute-named-query", help="Execute a registered named query")
    p_enq.add_argument("name", metavar="NAME", help="Query name")
    p_enq.add_argument("--hives", default=None, metavar="HIVES", help="Comma-separated list of hive names to filter results")
    p_enq.set_defaults(func=handle_execute_named_query)

    # --- execute-freeform-query ---
    p_efq = subparsers.add_parser("execute-freeform-query", help="Execute an ad-hoc YAML query")
    p_efq.add_argument("--yaml", required=True, metavar="YAML", help="YAML query string")
    p_efq.add_argument("--hives", default=None, metavar="HIVES", help="Comma-separated list of hive names to filter results")
    p_efq.set_defaults(func=handle_execute_freeform_query)

    # --- colonize-hive ---
    p_colonize = subparsers.add_parser("colonize-hive", help="Create and register a new hive")
    p_colonize.add_argument("--name", required=True, help="Hive display name")
    p_colonize.add_argument("--path", required=True, metavar="PATH", help="Absolute path for the hive directory")
    p_colonize.add_argument("--child-tiers", default=None, dest="child_tiers", metavar="JSON", help="Per-hive child tiers config as JSON")
    p_colonize.add_argument("--egg-resolver", default=None, dest="egg_resolver", metavar="PATH", help="Path to egg resolver script")
    p_colonize.set_defaults(func=handle_colonize_hive)

    # --- list-hives ---
    p_list_hives = subparsers.add_parser("list-hives", help="List all registered hives")
    p_list_hives.set_defaults(func=handle_list_hives)

    # --- abandon-hive ---
    p_abandon = subparsers.add_parser("abandon-hive", help="Stop tracking a hive without deleting files")
    p_abandon.add_argument("name", metavar="NAME", help="Hive name")
    p_abandon.set_defaults(func=handle_abandon_hive)

    # --- rename-hive ---
    p_rename = subparsers.add_parser("rename-hive", help="Rename a hive")
    p_rename.add_argument("old_name", metavar="OLD_NAME", help="Current hive name")
    p_rename.add_argument("new_name", metavar="NEW_NAME", help="New hive name")
    p_rename.set_defaults(func=handle_rename_hive)

    # --- sanitize-hive ---
    p_sanitize = subparsers.add_parser("sanitize-hive", help="Validate and auto-fix malformed tickets in a hive")
    p_sanitize.add_argument("name", metavar="NAME", help="Hive name")
    p_sanitize.set_defaults(func=handle_sanitize_hive)

    # --- generate-index ---
    p_index = subparsers.add_parser("generate-index", help="Generate markdown index of tickets")
    p_index.add_argument("--status", default=None, help="Filter by status")
    p_index.add_argument("--type", default=None, help="Filter by ticket type")
    p_index.add_argument("--hive", default=None, help="Hive name to generate index for")
    p_index.set_defaults(func=handle_generate_index)

    # --- move-bee ---
    p_move = subparsers.add_parser("move-bee", help="Move bee tickets to a different hive")
    p_move.add_argument("ids", nargs="+", metavar="ID", help="One or more bee ticket IDs to move")
    p_move.add_argument("--destination", required=True, metavar="HIVE", help="Destination hive name")
    p_move.set_defaults(func=handle_move_bee)

    # --- undertaker ---
    p_undertaker = subparsers.add_parser("undertaker", help="Archive bee tickets matching a query")
    p_undertaker.add_argument("--hive", required=True, metavar="HIVE", help="Hive to operate on")
    undertaker_group = p_undertaker.add_mutually_exclusive_group()
    undertaker_group.add_argument("--yaml", default=None, metavar="YAML", help="YAML freeform query string")
    undertaker_group.add_argument("--query-name", default=None, dest="query_name", metavar="NAME", help="Name of a registered query")
    p_undertaker.set_defaults(func=handle_undertaker)

    # --- sting ---
    p_sting = subparsers.add_parser("sting", help="Output bees context for Claude Code sessions")
    p_sting.set_defaults(func=handle_sting)

    # --- setup ---
    p_setup = subparsers.add_parser("setup", help="Configure integrations")
    setup_sub = p_setup.add_subparsers(title="targets", parser_class=BeesArgumentParser)

    # --- setup claude ---
    p_claude = setup_sub.add_parser("claude", help="Configure Claude Code integration")
    claude_sub = p_claude.add_subparsers(title="modes", parser_class=BeesArgumentParser)

    # --- setup claude cli ---
    p_cli_mode = claude_sub.add_parser("cli", help="Install sting hooks only")
    p_cli_mode.add_argument("--remove", action="store_true", default=False, help="Remove hooks")
    p_cli_mode.add_argument("--project", action="store_true", default=False, help="Write to .claude/settings.local.json")
    p_cli_mode.set_defaults(func=handle_setup_claude_cli)

    # --- serve ---
    p_serve = subparsers.add_parser("serve", help="Start the MCP server")
    transport_group = p_serve.add_mutually_exclusive_group()
    transport_group.add_argument(
        "--stdio",
        action="store_true",
        default=False,
        help="Run MCP server over stdio transport",
    )
    transport_group.add_argument(
        "--http",
        action="store_true",
        default=False,
        help="Run MCP server over HTTP transport",
    )
    p_serve.add_argument(
        "--host",
        default="127.0.0.1",
        metavar="HOST",
        help="Host to bind the HTTP server to (default: 127.0.0.1)",
    )
    p_serve.add_argument(
        "--port",
        type=int,
        default=8000,
        metavar="PORT",
        help="Port to bind the HTTP server to (default: 8000)",
    )
    p_serve.add_argument(
        "--config",
        default=None,
        metavar="PATH",
        help="Path to bees config file",
    )
    p_serve.set_defaults(func=handle_serve, serve_parser=p_serve)

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_usage()
        sys.exit(2)
    args.func(args)


if __name__ == "__main__":
    main()
