"""
Ticket CRUD Operations for Bees MCP Server

This module contains the core ticket create, read, update, and delete operations
extracted from mcp_server.py. These functions handle:
- Ticket creation (_create_ticket)
- Ticket updates (_update_ticket)
- Ticket deletion (_delete_ticket)
- Ticket retrieval (_show_ticket)

All operations include validation and error handling. Create and update operations include bidirectional relationship sync. Delete operations use a two-phase bottom-up algorithm and do not modify relationship fields in surviving tickets.
"""

import logging
import os
import re
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

from . import cache
from .config import load_bees_config, resolve_child_tiers_for_hive, resolve_egg_resolver, resolve_egg_resolver_timeout
from .repo_utils import get_repo_root_from_path  # noqa: F401 - kept for monkeypatching in tests
from .hive_utils import hive_integrity_gate
from .id_utils import extract_existing_ids_from_all_hives, generate_guid, generate_unique_ticket_id, normalize_hive_name
from .mcp_relationships import (
    _add_to_down_dependencies,
    _add_to_up_dependencies,
    _remove_child_from_parent,
    _remove_from_down_dependencies,
    _remove_from_up_dependencies,
    _update_bidirectional_relationships,
)
from .paths import find_ticket_file, get_ticket_path, infer_ticket_type_from_id
from .reader import read_ticket
from .ticket_factory import create_bee, create_child_tier
from .writer import write_ticket_file

# Logger
logger = logging.getLogger(__name__)

# Sentinel value for unset optional parameters
_UNSET: Literal["__UNSET__"] = "__UNSET__"


def find_hive_for_ticket(ticket_id: str) -> str | None:
    """
    Scan all configured hives to find which one contains the given ticket.

    This is a fallback mechanism used when callers do not provide a hive_name parameter.
    Provides O(n) scanning across all hives to locate a ticket by its ID.

    Scans recursively for hierarchical storage pattern: {ticket_id}/{ticket_id}.md

    Args:
        ticket_id: The ticket ID to search for (e.g., 'b.Amx', 't1.X4F2')

    Returns:
        str: The hive name (normalized) if ticket found, None otherwise

    Example:
        >>> find_hive_for_ticket('b.Amx')
        'backend'
        >>> find_hive_for_ticket('nonexistent.id')
        None
    """
    config = load_bees_config()
    if not config or not config.hives:
        return None

    for hive_name, hive_config in config.hives.items():
        hive_path = Path(hive_config.path)

        # Selective traversal: only enters ticket-ID directories
        if find_ticket_file(hive_path, ticket_id) is not None:
            return hive_name

    return None


def validate_ticket_type(ticket_type: str, hive_name: str | None = None) -> None:
    """
    Validate that ticket_type is a valid tier type against current config.

    Valid types include:
    - "bee" (always valid)
    - Configured tier types from child_tiers config (t1, t2, t3...)

    Args:
        ticket_type: The ticket type to validate
        hive_name: Optional hive name for per-hive child_tiers resolution

    Raises:
        ValueError: If ticket_type is not valid, with descriptive message showing all valid types
    """
    # "bee" is always valid (early return before loading config)
    if ticket_type == "bee":
        return

    from .config import resolve_child_tiers_for_hive

    config = load_bees_config()

    # Resolve child_tiers based on hive_name
    if hive_name is not None:
        child_tiers = resolve_child_tiers_for_hive(hive_name, config)
    else:
        # When hive_name is None, use scope-level config.child_tiers
        # If config.child_tiers is None (not configured), default to {}
        child_tiers = config.child_tiers if config and config.child_tiers is not None else {}

    # Build set of valid types
    valid_types = {"bee"}
    if child_tiers:
        valid_types.update(child_tiers.keys())

    # Validate ticket_type
    if ticket_type not in valid_types:
        sorted_types = sorted(valid_types)
        types_str = ", ".join(sorted_types)
        if hive_name is not None:
            error_msg = f"Unknown ticket type '{ticket_type}' for hive '{hive_name}'. Valid types: {types_str}"
        else:
            error_msg = f"Unknown ticket type '{ticket_type}'. Valid types: {types_str}"
        logger.error(error_msg)
        raise ValueError(error_msg)


def validate_parent_tier_relationship(
    ticket_type: str, parent_id: str | None, parent_type: str | None, hive_name: str | None = None
) -> bool:
    """
    Validate that parent ticket type matches expected tier hierarchy.

    Tier hierarchy rules:
    - bee (t0): No parent allowed
    - t1: Parent must be bee (t0)
    - t2: Parent must be t1
    - t3: Parent must be t2
    - etc.

    Args:
        ticket_type: Type of ticket being created (bee, t1, t2, etc.)
        parent_id: Parent ticket ID (can be None for bees)
        parent_type: Type of parent ticket (bee, t1, t2, etc.)
        hive_name: Optional hive name for per-hive child_tiers resolution

    Returns:
        True if validation passes

    Raises:
        ValueError: If parent type does not match expected tier for ticket_type
    """
    from .config import resolve_child_tiers_for_hive

    config = load_bees_config()

    # Bees cannot have parents (existing behavior)
    if ticket_type == "bee":
        if parent_id is not None:
            error_msg = "Bees cannot have a parent"
            logger.error(error_msg)
            raise ValueError(error_msg)
        return True

    # Resolve child_tiers based on hive_name
    if hive_name is not None:
        child_tiers = resolve_child_tiers_for_hive(hive_name, config)
    else:
        # When hive_name is None, use scope-level config.child_tiers
        # If config.child_tiers is None (not configured), default to {}
        child_tiers = config.child_tiers if config and config.child_tiers is not None else {}

    # For child tiers (t1, t2, t3...), validate against config
    if child_tiers and ticket_type in child_tiers:
        # Determine expected parent tier
        # t1 -> t0 (bee), t2 -> t1, t3 -> t2, etc.
        if ticket_type == "t1":
            expected_parent = "t0"  # t0 = bee
        else:
            # Extract tier number and calculate parent
            tier_num = int(ticket_type[1:])
            expected_parent = f"t{tier_num - 1}"

        # All child tiers require a parent
        if parent_type is None:
            expected_display = "bee" if expected_parent == "t0" else expected_parent
            error_msg = f"{ticket_type} ticket must have {expected_display} parent, got None"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Map t0 to "bee" for comparison
        actual_parent = "t0" if parent_type == "bee" else parent_type

        if actual_parent != expected_parent:
            # Format error message with user-friendly names
            expected_display = "bee" if expected_parent == "t0" else expected_parent
            actual_display = "bee" if parent_type == "bee" else parent_type
            error_msg = f"{ticket_type} ticket must have {expected_display} parent, got {actual_display}"
            logger.error(error_msg)
            raise ValueError(error_msg)

    return True


async def _create_ticket(
    ticket_type: str,
    title: str,
    hive_name: str,
    description: str = "",
    parent: str | None = None,
    children: list[str] | None = None,
    up_dependencies: list[str] | None = None,
    down_dependencies: list[str] | None = None,
    labels: list[str] | None = None,
    status: str | None = None,
    egg: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """
    Create a new ticket (bee or dynamic tier type).

    Args:
        ticket_type: Type of ticket to create - 'bee' or tier type (t1, t2, t3...) from child_tiers config.
        title: Title of the ticket (required)
        hive_name: Hive name determining storage location (required, e.g., "backend" stores in backend hive)
        description: Detailed description of the ticket
        parent: Parent ticket ID (required for tier types, not allowed for bees)
        children: List of child ticket IDs
        up_dependencies: List of ticket IDs that this ticket depends on (blocking tickets)
        down_dependencies: List of ticket IDs that depend on this ticket
        labels: List of label strings
        status: Status of the ticket (e.g., 'open', 'in_progress', 'completed')
        egg: Optional egg data
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: Created ticket information including ticket_id

    Raises:
        ValueError: If ticket_type is invalid or validation fails
    """
    # Validate title is not empty
    if not title or not title.strip():
        error_msg = "Ticket title cannot be empty"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Validate hive_name (required parameter)
    if not hive_name or not hive_name.strip():
        error_msg = "hive_name is required and cannot be empty"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Check if hive_name contains at least one alphanumeric character
    if not re.search(r"[a-zA-Z0-9]", hive_name):
        error_msg = f"Invalid hive_name: '{hive_name}'. Hive name must contain at least one alphanumeric character"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Validate hive exists in config
    # Design Decision: create_ticket is STRICT and does not attempt hive recovery via scan_for_hive.
    # Rationale:
    #   - Write operations (create/update/delete) should be explicit and fail fast
    #   - Consistency: update_ticket and delete_ticket also fail fast without recovery attempts
    #   - scan_for_hive is a recovery mechanism for read operations, not normal write flows
    #   - Creating tickets requires explicit hive specification to avoid ambiguity
    # See docs/architecture/ for full architectural rationale
    normalized_hive = normalize_hive_name(hive_name)
    logger.info(f"create_ticket: Using repo root: {resolved_root}")

    # Validate ticket_type against config
    validate_ticket_type(ticket_type, normalized_hive)

    config = load_bees_config()

    # Enforce bees-only hive restriction
    child_tiers = resolve_child_tiers_for_hive(normalized_hive, config)
    if child_tiers == {} and ticket_type != "bee":
        raise ValueError(
            f"Hive '{hive_name}' is configured as bees-only. "
            f"Only bee (t0) tickets can be created."
        )
    logger.info(f"create_ticket: Config hives: {list(config.hives.keys()) if config else 'None'}")
    logger.info(f"create_ticket: Looking for hive: '{normalized_hive}'")

    if not config or normalized_hive not in config.hives:
        available_hives = list(config.hives.keys()) if config else []

        error_msg = (
            f"Hive '{hive_name}' (normalized: '{normalized_hive}') not found in config.\n"
            f"  Repo root (from MCP context): {resolved_root}\n"
            f"  Available hives: {available_hives}\n"
            "\n"
            "Please create the hive first using colonize_hive in the correct repository.\n"
            "If the hive directory exists but isn't registered, run colonize_hive to register it."
        )

        logger.error(error_msg)
        raise ValueError(error_msg)

    # Validate hive path exists and is writable
    hive_path = Path(config.hives[normalized_hive].path)

    # Resolve symlinks to get the actual path
    try:
        hive_resolved_path = hive_path.resolve(strict=False)
    except (OSError, RuntimeError) as e:
        error_msg = f"Failed to resolve hive path '{hive_path}': {e}"
        logger.error(error_msg)
        raise ValueError(error_msg) from None

    # Check if path exists
    if not hive_resolved_path.exists():
        error_msg = (
            f"Hive path does not exist: '{hive_resolved_path}'. "
            "Please create the directory before creating tickets."
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Check if path is a directory
    if not hive_resolved_path.is_dir():
        error_msg = f"Hive path is not a directory: '{hive_resolved_path}'. Path must be a directory, not a file."
        logger.error(error_msg)
        raise ValueError(error_msg)

    if not os.access(hive_resolved_path, os.W_OK):
        error_msg = f"Hive directory is not writable: '{hive_resolved_path}'. Please check directory permissions."
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Integrity gate: abort if hive is corrupt before any writes
    gate_error = hive_integrity_gate(normalized_hive, resolved_root)
    if gate_error is not None:
        return gate_error

    # Validate parent-child tier hierarchy (basic validation before existence check)
    # This validates bee cannot have parent without needing to check if parent exists
    if ticket_type == "bee" and parent:
        error_msg = "Bees cannot have a parent"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Validate parent ticket exists
    parent_type = None
    if parent:
        parent_type = infer_ticket_type_from_id(parent)
        if not parent_type:
            error_msg = f"Parent ticket does not exist: {parent}"
            logger.error(error_msg)
            raise ValueError(error_msg)

    # Validate parent-child tier hierarchy (full validation after parent type known)
    validate_parent_tier_relationship(ticket_type, parent, parent_type, normalized_hive)

    # Validate dependency tickets exist
    if up_dependencies:
        for dep_id in up_dependencies:
            dep_type = infer_ticket_type_from_id(dep_id)
            if not dep_type:
                error_msg = f"Dependency ticket does not exist: {dep_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)
            if dep_type != ticket_type:
                error_msg = (
                    f"Cross-type dependency not allowed: ticket type '{ticket_type}' "
                    f"cannot depend on {dep_id} (type {dep_type})"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)

    if down_dependencies:
        for dep_id in down_dependencies:
            dep_type = infer_ticket_type_from_id(dep_id)
            if not dep_type:
                error_msg = f"Dependency ticket does not exist: {dep_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)
            if dep_type != ticket_type:
                error_msg = (
                    f"Cross-type dependency not allowed: ticket type '{ticket_type}' "
                    f"cannot depend on {dep_id} (type {dep_type})"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)

    # Validate children tickets exist
    if children:
        for child_id in children:
            child_type = infer_ticket_type_from_id(child_id)
            if not child_type:
                error_msg = f"Child ticket does not exist: {child_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)

    # Check for circular dependencies
    if up_dependencies and down_dependencies:
        circular_deps = set(up_dependencies) & set(down_dependencies)
        if circular_deps:
            error_msg = (
                "Circular dependency detected: ticket cannot both depend on and be depended on "
                f"by the same tickets: {circular_deps}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

    # Generate ticket ID and GUID before calling factory
    existing_ids = extract_existing_ids_from_all_hives()
    ticket_id = generate_unique_ticket_id(ticket_type, existing_ids=existing_ids, hive_name=normalized_hive)
    # Extract short_id (part after the dot) and generate GUID
    short_id = ticket_id.split(".", 1)[1]
    guid = generate_guid(short_id)

    # Call appropriate factory function based on ticket type
    try:
        if ticket_type == "bee":
            ticket_id = create_bee(
                title=title,
                description=description,
                labels=labels,
                up_dependencies=up_dependencies,
                down_dependencies=down_dependencies,
                status=status or "open",
                hive_name=hive_name,
                egg=egg,
                ticket_id=ticket_id,
                guid=guid,
            )
        else:
            # Handle dynamic tier types (t1, t2, t3, etc.)
            # These are validated by validate_ticket_type() against config.child_tiers
            # All child tiers require a parent, similar to task/subtask
            if parent is None:
                error_msg = f"{ticket_type} tickets require a parent"
                logger.error(error_msg)
                raise ValueError(error_msg)

            ticket_id = create_child_tier(
                ticket_type=ticket_type,
                title=title,
                parent=parent,
                description=description,
                labels=labels,
                up_dependencies=up_dependencies,
                down_dependencies=down_dependencies,
                status=status or "open",
                hive_name=hive_name,
                ticket_id=ticket_id,
                guid=guid,
            )

        logger.info(f"Successfully created {ticket_type} ticket: {ticket_id}")

        # Update bidirectional relationships in related tickets
        _update_bidirectional_relationships(
            new_ticket_id=ticket_id,
            parent=parent,
            children=children,
            up_dependencies=up_dependencies,
            down_dependencies=down_dependencies,
        )

        return {
            "status": "success",
            "ticket_id": ticket_id,
            "ticket_type": ticket_type,
            "title": title,
            "guid": guid,
        }

    except Exception as e:
        import traceback

        logger.error(f"Failed to create {ticket_type} ticket: {e}")
        logger.error(f"Full traceback:\n{''.join(traceback.format_exc())}")
        raise


def _apply_label_ops(
    ticket: Any,
    add_labels: list[str] | None,
    remove_labels: list[str] | None,
) -> None:
    """Apply add_labels and remove_labels mutations to a ticket in-place."""
    if add_labels:
        existing = set(ticket.labels or [])
        for lbl in dict.fromkeys(add_labels):
            if lbl not in existing:
                ticket.labels = (ticket.labels or []) + [lbl]
                existing.add(lbl)
    if remove_labels:
        remove_set = set(dict.fromkeys(remove_labels))
        ticket.labels = [lbl for lbl in (ticket.labels or []) if lbl not in remove_set]


async def _update_ticket(
    ticket_id: str | list[str],
    title: str | None | Literal["__UNSET__"] = _UNSET,
    description: str | None | Literal["__UNSET__"] = _UNSET,
    parent: str | None | Literal["__UNSET__"] = _UNSET,
    children: list[str] | None = _UNSET,  # type: ignore[assignment]  # _UNSET sentinel; Literal excluded to prevent MCP schema conflict
    up_dependencies: list[str] | None = _UNSET,  # type: ignore[assignment]  # _UNSET sentinel; Literal excluded to prevent MCP schema conflict
    down_dependencies: list[str] | None = _UNSET,  # type: ignore[assignment]  # _UNSET sentinel; Literal excluded to prevent MCP schema conflict
    labels: list[str] | None = _UNSET,  # type: ignore[assignment]  # _UNSET sentinel; Literal excluded to prevent MCP schema conflict
    add_labels: list[str] | None = None,
    remove_labels: list[str] | None = None,
    status: str | None | Literal["__UNSET__"] = _UNSET,
    egg: dict[str, Any] | list[Any] | str | int | float | bool | None = _UNSET,  # type: ignore[assignment]  # _UNSET sentinel
    hive_name: str | None = None,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """
    Update one or more existing tickets.

    Supports two call signatures:

    **Single update** (``ticket_id`` is a ``str``):
        Updates one ticket with any combination of fields.
        Returns ``{"status": "success", "updated": [ticket_id], "not_found": [], "failed": []}``.

    **Batch update** (``ticket_id`` is a ``list[str]``):
        Updates multiple tickets applying status, add_labels, and remove_labels to each.
        Non-batchable fields (``title``, ``description``, ``egg``, ``labels``,
        ``up_dependencies``, ``down_dependencies``) raise ``ValueError`` if set.
        Returns ``{"status": "success", "updated": [...], "not_found": [...], "failed": [...]}``.
        An empty list returns success immediately with all arrays empty.

    Args:
        ticket_id: ID of the ticket to update (str), or list of IDs for batch update (list[str])
        title: New title for the ticket (single mode only)
        description: New description for the ticket (single mode only)
        parent: IMMUTABLE - Cannot be changed after ticket creation (raises ValueError if set)
        children: IMMUTABLE - Cannot be changed after ticket creation (raises ValueError if set)
        up_dependencies: New list of blocking dependency ticket IDs (single mode only)
        down_dependencies: New list of dependent ticket IDs (single mode only)
        labels: New list of labels, full replace (single mode only)
        add_labels: Labels to add to the ticket (additive, deduplicates)
        remove_labels: Labels to remove from the ticket
        status: New status
        egg: New egg data (arbitrary structured data, single mode only)
        hive_name: Optional hive name for O(1) lookup. If not provided, scans all hives.
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: ``{"status": "success", "updated": [...], "not_found": [...], "failed": [...]}``

    Raises:
        ValueError: If parent/children are set, non-batchable fields used in batch mode,
            or validation fails

    Note:
        Parent and children fields are immutable after ticket creation.
        When updating dependencies, the change is automatically reflected
        bidirectionally in related tickets.
        Operation order per ticket: ``labels`` full-replace first, then ``add_labels``,
        then ``remove_labels``. If a label appears in both ``add_labels`` and
        ``remove_labels``, it ends up removed.
    """
    # ── Routing: list → batch-update ────────────────────────────────────
    if isinstance(ticket_id, list):
        if not ticket_id:
            return {"status": "success", "updated": [], "not_found": [], "failed": []}

        ticket_ids = list(dict.fromkeys(ticket_id))

        # Fail-fast: non-batchable fields must not be set
        NON_BATCHABLE = {
            "title": title,
            "description": description,
            "egg": egg,
            "labels": labels,
            "up_dependencies": up_dependencies,
            "down_dependencies": down_dependencies,
        }
        for field_name, value in NON_BATCHABLE.items():
            if value is not _UNSET:
                raise ValueError(f"Field '{field_name}' is not supported for batch updates (list ticket_id)")

        # Enforce immutable fields before any I/O
        if parent is not _UNSET:
            raise ValueError("Parent field is immutable and cannot be changed after ticket creation")
        if children is not _UNSET:
            raise ValueError("Children field is immutable and cannot be changed after ticket creation")

        # If hive_name provided, validate config once before the loop
        if hive_name:
            config = load_bees_config()
            if not config or hive_name not in config.hives:
                raise ValueError(f"Hive '{hive_name}' not found in configuration")

        updated: list[str] = []
        not_found: list[str] = []
        failed: list[dict[str, str]] = []

        for tid in ticket_ids:
            # Resolve hive for this ticket
            if hive_name:
                resolved_hive = hive_name
            else:
                resolved_hive = find_hive_for_ticket(tid)
                if not resolved_hive:
                    not_found.append(tid)
                    continue

            try:
                # Integrity gate
                gate_error = hive_integrity_gate(resolved_hive, resolved_root)
                if gate_error is not None:
                    failed.append({"id": tid, "reason": gate_error.get("message", "Hive integrity check failed")})
                    continue

                # Validate ticket exists
                ticket_type = infer_ticket_type_from_id(tid)
                if not ticket_type:
                    failed.append({"id": tid, "reason": f"Ticket does not exist: {tid}"})
                    continue

                # Read existing ticket
                ticket_path = get_ticket_path(tid, ticket_type, resolved_hive)
                ticket = read_ticket(ticket_path, hive_name=resolved_hive)

                # Apply status
                if status is not _UNSET:
                    ticket.status = status  # type: ignore[assignment]

                # Apply add_labels / remove_labels
                _apply_label_ops(ticket, add_labels, remove_labels)

                # Write updated ticket
                frontmatter_data = asdict(ticket)
                frontmatter_data.pop("description", None)
                write_ticket_file(
                    ticket_id=tid,
                    ticket_type=ticket_type,
                    frontmatter_data=frontmatter_data,
                    body=ticket.description or "",
                    hive_name=resolved_hive,
                )
                cache.evict(tid)
                logger.info(f"Successfully updated ticket: {tid}")
                updated.append(tid)

            except Exception as e:
                logger.error(f"Failed to update ticket {tid}: {e}")
                failed.append({"id": tid, "reason": str(e)})

        return {"status": "success", "updated": updated, "not_found": not_found, "failed": failed}

    # ── Single-update path (ticket_id is str) ───────────────────────────
    # Resolve hive_name: use provided value or scan all hives
    if hive_name:
        # O(1) lookup using provided hive_name
        resolved_hive = hive_name
        # Validate hive exists in config
        config = load_bees_config()
        if not config or resolved_hive not in config.hives:
            error_msg = f"Hive '{resolved_hive}' not found in configuration"
            logger.error(error_msg)
            raise ValueError(error_msg)
    else:
        # O(n) scan across all hives to find ticket
        resolved_hive = find_hive_for_ticket(ticket_id)
        if not resolved_hive:
            error_msg = f"Ticket not found in any configured hive: {ticket_id}"
            logger.error(error_msg)
            raise ValueError(error_msg)

    # Integrity gate: abort if hive is corrupt before any writes
    gate_error = hive_integrity_gate(resolved_hive, resolved_root)
    if gate_error is not None:
        return gate_error

    # Validate ticket exists
    ticket_type = infer_ticket_type_from_id(ticket_id)
    if not ticket_type:
        error_msg = f"Ticket does not exist: {ticket_id}"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Enforce immutable fields
    if parent is not _UNSET:
        error_msg = "Parent field is immutable and cannot be changed after ticket creation"
        logger.error(error_msg)
        raise ValueError(error_msg)

    if children is not _UNSET:
        error_msg = "Children field is immutable and cannot be changed after ticket creation"
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Read existing ticket
    ticket_path = get_ticket_path(ticket_id, ticket_type, resolved_hive)
    try:
        ticket = read_ticket(ticket_path, hive_name=resolved_hive)
    except FileNotFoundError:
        error_msg = f"Ticket file not found: {ticket_id}"
        logger.error(error_msg)
        raise ValueError(error_msg) from None
    except Exception as e:
        error_msg = f"Failed to read ticket {ticket_id}: {e}"
        logger.error(error_msg)
        raise ValueError(error_msg) from e

    # Validate relationship ticket IDs exist
    if up_dependencies is not _UNSET and up_dependencies is not None:
        for dep_id in up_dependencies:
            dep_type = infer_ticket_type_from_id(dep_id)
            if not dep_type:
                error_msg = f"Dependency ticket does not exist: {dep_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)
            if dep_type != ticket_type:
                error_msg = (
                    f"Cross-type dependency not allowed: {ticket_id} (type {ticket_type}) "
                    f"cannot depend on {dep_id} (type {dep_type})"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)

    if down_dependencies is not _UNSET and down_dependencies is not None:
        for dep_id in down_dependencies:
            dep_type = infer_ticket_type_from_id(dep_id)
            if not dep_type:
                error_msg = f"Dependency ticket does not exist: {dep_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)
            if dep_type != ticket_type:
                error_msg = (
                    f"Cross-type dependency not allowed: {ticket_id} (type {ticket_type}) "
                    f"cannot depend on {dep_id} (type {dep_type})"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)

    # Check for circular dependencies if both up and down are being updated
    if (
        up_dependencies is not _UNSET
        and up_dependencies is not None
        and down_dependencies is not _UNSET
        and down_dependencies is not None
    ):
        circular_deps = set(up_dependencies) & set(down_dependencies)
        if circular_deps:
            error_msg = (
                "Circular dependency detected: ticket cannot both depend on and be depended on "
                f"by the same tickets: {circular_deps}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

    # Update basic fields (non-relationship fields)
    if title is not _UNSET:
        if title is None or not title.strip():
            error_msg = "Ticket title cannot be empty"
            logger.error(error_msg)
            raise ValueError(error_msg)
        ticket.title = title

    if description is not _UNSET:
        # description can be None or empty string
        ticket.description = description if description else ""

    if labels is not _UNSET:
        # labels can be None (which means empty list)
        assert labels != _UNSET  # Type narrowing
        ticket.labels = labels if labels is not None else []

    if status is not _UNSET:
        ticket.status = status  # type: ignore[assignment]

    if egg is not _UNSET:
        ticket.egg = egg

    # Apply add_labels / remove_labels
    _apply_label_ops(ticket, add_labels, remove_labels)

    # Handle relationship updates with bidirectional consistency
    # Track old relationships to determine what changed
    old_up_deps = set(ticket.up_dependencies or [])
    old_down_deps = set(ticket.down_dependencies or [])

    # Update relationship fields if provided
    if up_dependencies is not _UNSET:
        assert up_dependencies != _UNSET  # Type narrowing
        ticket.up_dependencies = up_dependencies if up_dependencies is not None else []
    if down_dependencies is not _UNSET:
        assert down_dependencies != _UNSET  # Type narrowing
        ticket.down_dependencies = down_dependencies if down_dependencies is not None else []

    # Write updated ticket
    frontmatter_data = asdict(ticket)
    # Remove description from frontmatter - it belongs in the body only
    frontmatter_data.pop("description", None)
    write_ticket_file(
        ticket_id=ticket_id,
        ticket_type=ticket_type,
        frontmatter_data=frontmatter_data,
        body=ticket.description or "",
        hive_name=resolved_hive,
    )
    cache.evict(ticket_id)

    # Sync bidirectional relationships
    new_up_deps = set(ticket.up_dependencies or [])
    new_down_deps = set(ticket.down_dependencies or [])

    # Handle up_dependencies changes
    if up_dependencies is not _UNSET:
        removed_up = old_up_deps - new_up_deps
        added_up = new_up_deps - old_up_deps

        for dep_id in removed_up:
            _remove_from_down_dependencies(ticket_id, dep_id)

        for dep_id in added_up:
            _add_to_down_dependencies(ticket_id, dep_id)

    # Handle down_dependencies changes
    if down_dependencies is not _UNSET:
        removed_down = old_down_deps - new_down_deps
        added_down = new_down_deps - old_down_deps

        for dep_id in removed_down:
            _remove_from_up_dependencies(ticket_id, dep_id)

        for dep_id in added_down:
            _add_to_up_dependencies(ticket_id, dep_id)

    logger.info(f"Successfully updated ticket: {ticket_id}")

    return {"status": "success", "updated": [ticket_id], "not_found": [], "failed": []}


def _collect_deletion_set(ticket_id: str, hive_name: str) -> list[str]:
    """Collect all ticket IDs in a subtree for bottom-up deletion.

    Performs depth-first traversal using each ticket's ``children`` field.
    Returns IDs ordered leaves-first so callers can delete without orphaning
    child directories.

    Args:
        ticket_id: Root ticket of the subtree to collect.
        hive_name: Hive that contains the ticket (used for path resolution).

    Returns:
        List of ticket IDs ordered for bottom-up deletion (leaves first,
        *ticket_id* last).

    Raises:
        ValueError: If any ticket in the subtree cannot be read.
    """
    result: list[str] = []
    stack: list[str] = [ticket_id]

    while stack:
        current_id = stack.pop()

        ticket_type = infer_ticket_type_from_id(current_id)
        if not ticket_type:
            raise ValueError(f"Ticket does not exist: {current_id}")

        ticket_path = get_ticket_path(current_id, ticket_type, hive_name)
        try:
            ticket = read_ticket(ticket_path, hive_name=hive_name)
        except FileNotFoundError:
            raise ValueError(f"Ticket file not found: {current_id}") from None
        except Exception as e:
            raise ValueError(f"Failed to read ticket {current_id}: {e}") from e

        # Push children onto the stack so they are visited before we
        # record this ticket – depth-first ensures leaves come first.
        if ticket.children:
            for child_id in ticket.children:
                stack.append(child_id)

        # Append then reverse at end: O(n) vs O(n²) for insert(0, ...).
        # Children are pushed to the stack after the parent, so the parent
        # is appended before its descendants; reversing at the end yields
        # leaves-first order.
        result.append(current_id)

    result.reverse()
    return result


def _clean_external_dependencies(deletion_ids: list[str], resolved_hive: str) -> None:
    """Remove deleted subtree from external tickets' dependency fields before deletion.

    For every ticket in *deletion_ids*, removes references to that ticket from
    the ``up_dependencies`` / ``down_dependencies`` arrays of tickets that are
    **outside** the deletion set.  Tickets inside the set are skipped (they are
    being deleted anyway).

    Args:
        deletion_ids: Ordered list of ticket IDs to be deleted (from
            ``_collect_deletion_set``).
        resolved_hive: Hive that contains all tickets in the deletion set.

    Raises:
        ValueError: If reading a ticket in the deletion set fails (other than
            FileNotFoundError), or if updating an external ticket fails (other
            than FileNotFoundError, which is silently skipped).
    """
    deletion_set = set(deletion_ids)
    for tid in deletion_ids:
        t_type = infer_ticket_type_from_id(tid)
        if not t_type:
            continue

        t_path = get_ticket_path(tid, t_type, resolved_hive)
        try:
            ticket = read_ticket(t_path, hive_name=resolved_hive)
        except FileNotFoundError:
            continue
        except Exception as e:
            error_msg = f"Failed to read ticket {tid} during dependency cleanup: {e}"
            logger.error(error_msg)
            raise ValueError(error_msg) from e

        for dep_id in (ticket.up_dependencies or []):
            if dep_id in deletion_set:
                continue
            try:
                _remove_from_down_dependencies(tid, dep_id)
            except FileNotFoundError:
                pass
            except Exception as e:
                error_msg = f"Failed to clean down_dependencies for {dep_id}: {e}"
                logger.error(error_msg)
                raise ValueError(error_msg) from e

        for dep_id in (ticket.down_dependencies or []):
            if dep_id in deletion_set:
                continue
            try:
                _remove_from_up_dependencies(tid, dep_id)
            except FileNotFoundError:
                pass
            except Exception as e:
                error_msg = f"Failed to clean up_dependencies for {dep_id}: {e}"
                logger.error(error_msg)
                raise ValueError(error_msg) from e

    logger.info(f"Cleanup phase complete: dependency references removed for {len(deletion_ids)} ticket(s)")


async def _delete_ticket(
    ticket_ids: str | list[str],
    hive_name: str | None = None,
    clean_dependencies: bool = False,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """Delete one or more tickets and their subtrees.

    Supports two call signatures:

    **Single delete** (``ticket_ids`` is a ``str``):
        Deletes one ticket and its entire subtree using a two-phase algorithm.
        Returns ``{status, ticket_id, ticket_type, message}``.

    **Bulk delete** (``ticket_ids`` is a ``list[str]``):
        Iterates the list and applies the same two-phase algorithm to each ID.
        Returns ``{status, deleted, not_found, failed}``.
        An empty list returns success immediately with all arrays empty.

    Phase 1 — Collection:
        Calls ``_collect_deletion_set`` to walk the subtree depth-first and
        build an ordered list of ticket IDs (leaves first, root last).  If any
        ticket in the subtree cannot be read the operation halts before any
        directory is removed.

    Cleanup Phase — Dependency cleanup (optional, ``clean_dependencies=True``):
        Before any filesystem deletions, iterates every ticket in the deletion
        set and removes dangling dependency references from surviving tickets.
        For each dependency ID outside the deletion set:
        - If the dep is in the ticket's ``up_dependencies``, removes the ticket
          from that external ticket's ``down_dependencies``.
        - If the dep is in the ticket's ``down_dependencies``, removes the
          ticket from that external ticket's ``up_dependencies``.
        ``FileNotFoundError`` during removal is silently skipped; any other
        exception halts cleanup and returns an error immediately (no deletions
        have occurred at this point).

    Phase 2 — Deletion:
        Iterates the collected list bottom-up, resolves each ticket's
        directory, and removes it with ``shutil.rmtree``.  A safety guard
        prevents accidental deletion of the hive root directory.  If a
        directory is already missing it is logged and skipped; any other
        OS error halts the loop immediately.

    Args:
        ticket_ids: Single ticket ID (str) or list of ticket IDs (list[str]).
            When str, backward-compatible single-delete behavior.
            When list, bulk deletion of multiple independent tickets.
        hive_name: Optional hive name for O(1) lookup. If not provided, scans all hives.
        clean_dependencies: When ``True``, removes references to deleted tickets
            from surviving tickets' dependency fields before deletion.  Cleanup
            runs before any filesystem deletions; missing tickets are skipped
            silently; any other error halts the operation immediately.
            Defaults to ``False`` (dependency fields in surviving tickets are
            left unchanged).
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        Single mode (str input):
            dict with ``status``, ``ticket_id``, ``ticket_type``, and ``message`` keys.
        Bulk mode (list input):
            dict with ``status``, ``deleted``, ``not_found``, and ``failed`` keys.

    Raises:
        ValueError: If a ticket doesn't exist, the hive is invalid, or a
            read/delete error occurs.

    Note:
        When a ticket is deleted:
        - All child tickets are deleted (cascade behaviour)
        - The entire directory subtree under each ticket is removed
        - Hive root directory is never deleted (safety guard)
        - Dependency cleanup is opt-in via ``clean_dependencies=True``; by
          default, relationship fields in surviving tickets are NOT modified
    """
    # ── Routing: str → single-delete, list → bulk-delete ────
    if isinstance(ticket_ids, str):
        ticket_id = ticket_ids

        # Resolve hive_name: use provided value or scan all hives
        if hive_name:
            resolved_hive = hive_name
            config = load_bees_config()
            if not config or resolved_hive not in config.hives:
                error_msg = f"Hive '{resolved_hive}' not found in configuration"
                logger.error(error_msg)
                raise ValueError(error_msg)
        else:
            resolved_hive = find_hive_for_ticket(ticket_id)
            if not resolved_hive:
                error_msg = f"Ticket not found in any configured hive: {ticket_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)

        # Integrity gate: abort if hive is corrupt before deletion phases
        gate_error = hive_integrity_gate(resolved_hive, resolved_root)
        if gate_error is not None:
            return gate_error

        # ── Phase 1: Collection ──────────────────────────────────────
        # Walks the entire subtree.  Raises ValueError on any read error
        # so nothing is deleted if the tree can't be fully traversed.
        deletion_ids = _collect_deletion_set(ticket_id, resolved_hive)
        # Capture root ticket type before deletion removes the file
        root_ticket_type = infer_ticket_type_from_id(ticket_id)
        logger.info(f"Phase 1 complete: collected {len(deletion_ids)} ticket(s) for deletion")

        # ── Cleanup Phase: Dependency cleanup (optional) ─────────────
        if clean_dependencies:
            _clean_external_dependencies(deletion_ids, resolved_hive)

        # ── Parent Backlink Cleanup ───────────────────────────────────
        # Remove the root ticket from its parent's children array so the
        # parent does not retain a stale reference after deletion.
        if root_ticket_type:
            root_path = get_ticket_path(ticket_id, root_ticket_type, resolved_hive)
            try:
                root_ticket = read_ticket(root_path, hive_name=resolved_hive)
                parent_id = root_ticket.parent
                if parent_id and parent_id not in set(deletion_ids):
                    try:
                        _remove_child_from_parent(ticket_id, parent_id)
                        logger.info(f"Removed {ticket_id} from parent {parent_id} children array")
                    except FileNotFoundError:
                        pass
            except FileNotFoundError:
                pass

        # ── Phase 2: Deletion (bottom-up) ────────────────────────────
        config = load_bees_config()
        hive_path = Path(config.hives[resolved_hive].path) if config else None

        for tid in deletion_ids:
            t_type = infer_ticket_type_from_id(tid)
            if not t_type:
                error_msg = f"Ticket does not exist: {tid}"
                logger.error(error_msg)
                raise ValueError(error_msg)

            try:
                t_path = get_ticket_path(tid, t_type, resolved_hive)
            except FileNotFoundError:
                logger.warning(f"Ticket directory already missing, skipping: {tid}")
                continue

            ticket_dir = t_path.parent

            # Safety guard: never delete the hive root directory
            if hive_path and ticket_dir == hive_path:
                error_msg = f"Cannot delete hive root directory: {ticket_dir}"
                logger.error(error_msg)
                raise ValueError(error_msg)

            try:
                shutil.rmtree(ticket_dir)
                cache.evict(tid)
                logger.info(f"Deleted ticket directory: {ticket_dir}")
            except FileNotFoundError:
                logger.warning(f"Directory already removed, skipping: {ticket_dir}")
            except Exception as e:
                error_msg = f"Failed to delete ticket directory {ticket_dir}: {e}"
                logger.error(error_msg)
                raise ValueError(error_msg) from e

        return {
            "status": "success",
            "ticket_id": ticket_id,
            "ticket_type": root_ticket_type,
            "message": f"Successfully deleted ticket {ticket_id}",
        }

    # ── Bulk-delete path (ticket_ids is list[str]) ───────────────
    if not ticket_ids:
        return {"status": "success", "deleted": [], "not_found": [], "failed": []}

    deleted: list[str] = []
    not_found: list[str] = []
    failed: list[dict[str, str]] = []

    for bulk_id in ticket_ids:
        # Resolve hive for this ticket
        if hive_name:
            resolved_hive = hive_name
            config = load_bees_config()
            if not config or resolved_hive not in config.hives:
                raise ValueError(f"Hive '{resolved_hive}' not found in configuration")
        else:
            resolved_hive = find_hive_for_ticket(bulk_id)
            if not resolved_hive:
                not_found.append(bulk_id)
                continue

        try:
            # Integrity gate
            gate_error = hive_integrity_gate(resolved_hive, resolved_root)
            if gate_error is not None:
                failed.append({"id": bulk_id, "reason": gate_error.get("message", "Hive integrity check failed")})
                continue

            # ── Phase 1: Collection ──────────────────────────────────
            deletion_ids = _collect_deletion_set(bulk_id, resolved_hive)
            root_ticket_type = infer_ticket_type_from_id(bulk_id)
            logger.info(f"Bulk delete – Phase 1 complete for {bulk_id}: collected {len(deletion_ids)} ticket(s)")

            # ── Cleanup Phase: Dependency cleanup (optional) ─────────
            if clean_dependencies:
                _clean_external_dependencies(deletion_ids, resolved_hive)

            # ── Parent Backlink Cleanup ───────────────────────────────
            if root_ticket_type:
                root_path = get_ticket_path(bulk_id, root_ticket_type, resolved_hive)
                try:
                    root_ticket = read_ticket(root_path, hive_name=resolved_hive)
                    parent_id = root_ticket.parent
                    if parent_id and parent_id not in set(deletion_ids):
                        try:
                            _remove_child_from_parent(bulk_id, parent_id)
                            logger.info(f"Removed {bulk_id} from parent {parent_id} children array")
                        except FileNotFoundError:
                            pass
                except FileNotFoundError:
                    pass

            # ── Phase 2: Deletion (bottom-up) ────────────────────────
            config = load_bees_config()
            hive_path = Path(config.hives[resolved_hive].path) if config else None

            for del_id in deletion_ids:
                t_type = infer_ticket_type_from_id(del_id)
                if not t_type:
                    raise ValueError(f"Ticket does not exist: {del_id}")

                try:
                    t_path = get_ticket_path(del_id, t_type, resolved_hive)
                except FileNotFoundError:
                    logger.warning(f"Ticket directory already missing, skipping: {del_id}")
                    continue

                ticket_dir = t_path.parent

                # Safety guard: never delete the hive root directory
                if hive_path and ticket_dir == hive_path:
                    raise ValueError(f"Cannot delete hive root directory: {ticket_dir}")

                try:
                    shutil.rmtree(ticket_dir)
                    cache.evict(del_id)
                    logger.info(f"Deleted ticket directory: {ticket_dir}")
                except FileNotFoundError:
                    logger.warning(f"Directory already removed, skipping: {ticket_dir}")
                except Exception as e:
                    raise ValueError(f"Failed to delete ticket directory {ticket_dir}: {e}") from e

            deleted.append(bulk_id)

        except Exception as e:
            logger.error(f"Bulk delete failed for {bulk_id}: {e}")
            failed.append({"id": bulk_id, "reason": str(e)})

    return {"status": "success", "deleted": deleted, "not_found": not_found, "failed": failed}


async def _show_ticket(
    ticket_ids: list[str], resolved_root: Path | None = None
) -> dict[str, Any]:
    """
    Retrieve and return ticket data for one or more ticket IDs.

    Args:
        ticket_ids: List of ticket IDs to retrieve (e.g., ['b.Amx', 'b.Xyz'])
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: Bulk response with ticket data
            {
                "status": "success",
                "tickets": [
                    {
                        "ticket_id": str,
                        "ticket_type": str,
                        "title": str,
                        "description": str,
                        "labels": list[str],
                        "parent": str | None,
                        "children": list[str] | None,
                        "up_dependencies": list[str] | None,
                        "down_dependencies": list[str] | None,
                        "ticket_status": str,
                        "created_at": str,
                        "schema_version": str,
                        "egg": any,
                        "guid": str
                    },
                    ...
                ],
                "not_found": ["b.missing"],
                "errors": [{"id": "b.xxx", "reason": "egg resolver timed out: ..."}]
            }

        `not_found` contains IDs of tickets that could not be located or read.
        `errors` contains IDs of tickets that were found but failed during egg resolution.

    Example:
        >>> _show_ticket(['b.Amx', 'b.Xyz'])
        {'status': 'success', 'tickets': [{...}, {...}], 'not_found': [], 'errors': []}
    """
    if not ticket_ids:
        return {"status": "success", "tickets": [], "not_found": [], "errors": []}

    # Import resolver functions locally to avoid circular import
    from .mcp_egg_ops import _default_resolver, _invoke_custom_resolver

    config = load_bees_config()
    tickets = []
    not_found = []
    errors = []

    for ticket_id in ticket_ids:
        try:
            # Validate ticket_id is not empty
            if not ticket_id or not ticket_id.strip():
                raise ValueError("ticket_id cannot be empty")

            # O(n) scan across all hives to find ticket
            resolved_hive = find_hive_for_ticket(ticket_id)
            if not resolved_hive:
                raise ValueError(f"Ticket not found in any configured hive: {ticket_id}")

            # Integrity gate: hive corruption aborts the entire operation
            gate_error = hive_integrity_gate(resolved_hive, resolved_root)
            if gate_error is not None:
                logger.warning(
                    f"Aborting bulk show_ticket due to hive corruption, "
                    f"{len(tickets)} tickets already resolved will not be returned."
                )
                return gate_error

            # Infer ticket type from ID
            ticket_type = infer_ticket_type_from_id(ticket_id)
            if not ticket_type:
                raise ValueError(f"Ticket does not exist: {ticket_id}")

            # Get ticket path and read ticket
            ticket_path = get_ticket_path(ticket_id, ticket_type, resolved_hive)
            ticket = read_ticket(ticket_path, hive_name=resolved_hive)

            # Resolve egg value using the three-level resolution hierarchy
            egg_resolver = resolve_egg_resolver(resolved_hive, config)
            timeout = resolve_egg_resolver_timeout(resolved_hive, config)

            if egg_resolver is None:
                resolved_resources = _default_resolver(ticket.egg)
            else:
                resolved_resources = await _invoke_custom_resolver(
                    egg_resolver, ticket.egg, resolved_root, timeout
                )

            ticket_data = {
                "ticket_id": ticket.id,
                "ticket_type": ticket.type,
                "title": ticket.title,
                "description": ticket.description,
                "labels": ticket.labels,
                "parent": ticket.parent,
                "children": ticket.children,
                "up_dependencies": ticket.up_dependencies,
                "down_dependencies": ticket.down_dependencies,
                "ticket_status": ticket.status,
                "created_at": ticket.created_at.isoformat() if ticket.created_at else None,
                "schema_version": ticket.schema_version,
                "egg": resolved_resources,
                "guid": ticket.guid,
            }
            tickets.append(ticket_data)
            logger.info(f"Successfully retrieved ticket: {ticket_id}")

        except RuntimeError as e:
            logger.warning(f"Egg resolver failure for {ticket_id}, adding to errors: {e}")
            errors.append({"id": ticket_id, "reason": str(e)})
        except (ValueError, FileNotFoundError):
            logger.warning(f"Ticket not found or unreadable, adding to not_found: {ticket_id}")
            not_found.append(ticket_id)

    return {"status": "success", "tickets": tickets, "not_found": not_found, "errors": errors}


def _build_tier_structure(child_tiers: dict) -> dict:
    """
    Build tier structure dict from resolved child_tiers config.

    Args:
        child_tiers: Resolved child_tiers dict (from resolve_child_tiers_for_hive or config.child_tiers)

    Returns:
        dict: Tier structure with t0 (bee) and all child tiers
            {
                "t0": {"singular": "Bee", "plural": "Bees", "parent": None},
                "t1": {"singular": "Task", "plural": "Tasks", "parent": "t0"},
                ...
            }
    """
    # Build tier structure starting with bee (t0)
    tiers = {"t0": {"singular": "Bee", "plural": "Bees", "parent": None}}

    # Add child tiers from resolved config
    # child_tiers is {} for bees-only hives (no child tiers added)
    for tier_id in sorted(child_tiers.keys()):
        tier_config = child_tiers[tier_id]

        # Determine parent tier
        tier_num = int(tier_id[1:])
        parent_tier = f"t{tier_num - 1}" if tier_num > 1 else "t0"

        tiers[tier_id] = {
            "singular": tier_config.singular,
            "plural": tier_config.plural,
            "parent": parent_tier,
        }

    return tiers


async def _get_types(
    hive_name: str | None = None,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """
    Get ticket type configuration from child_tiers config.

    Returns tier structure with friendly names and parent relationships, allowing LLMs
    to understand the ticket hierarchy and use friendly names in ticket operations.

    **Understanding Tier Hierarchy:**
    - **Bee (t0)**: Always the top-level tier, immutable and built-in
    - **Child tiers (t1, t2, t3...)**: Configured dynamically in ~/.bees/config.json
    - Each child tier has a parent tier (bee or another child tier)
    - Tiers are sequential: t1 → t2 → t3 (no gaps allowed)

    **Using Friendly Names:**
    - When creating tickets, you can use either tier IDs (t0, t1, t2) or friendly names
    - Example: ticket_type="Task" is equivalent to ticket_type="t1" (if t1 is configured as "Task")
    - Friendly names are case-sensitive as configured

    **Parent/Child Constraints:**
    - Bees (t0) cannot have parents, only children (t1 tickets if configured)
    - Child tier tickets (t1, t2, t3...) MUST have a parent from the tier above
    - Example hierarchy: Bee → Task (t1) → Subtask (t2)

    **Empty Configuration:**
    - If child_tiers is empty {}, only bees are allowed (bees-only system)
    - This is valid and indicates no child tiers are configured

    **Per-Hive Mode:**
    - If hive_name is provided, returns tiers for that specific hive only
    - If hive_name is omitted and any hive has non-None child_tiers, returns per-hive map
    - If hive_name is omitted and no hive has non-None child_tiers, returns flat tiers (backward compatible)

    Args:
        hive_name: Optional hive name to get tiers for a specific hive
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: Tier configuration with structure:
            When hive_name provided or no per-hive config:
            {
                "status": "success",
                "tiers": {
                    "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                    "t1": {"singular": "Task" | null, "plural": "Tasks" | null, "parent": "t0"},
                    ...
                }
            }

            When hive_name omitted and per-hive config exists:
            {
                "status": "success",
                "per_hive": true,
                "hives": {
                    "hive_name": {
                        "tiers": {
                            "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                            ...
                        }
                    },
                    ...
                }
            }

    Raises:
        ValueError: If config not found or hive_name not found in configuration

    Example:
        >>> _get_types()
        {
            "status": "success",
            "tiers": {
                "t0": {"singular": "Bee", "plural": "Bees", "parent": null},
                "t1": {"singular": "Task", "plural": "Tasks", "parent": "t0"},
                "t2": {"singular": "Subtask", "plural": "Subtasks", "parent": "t1"}
            }
        }

        >>> _get_types(hive_name="backend")
        {
            "status": "success",
            "tiers": {
                "t0": {"singular": "Bee", "plural": "Bees", "parent": null}
            }
        }
    """
    # Load config
    config = load_bees_config()

    if config is None:
        error_msg = "Configuration not found. Please run colonize_hive to set up ~/.bees/config.json first."
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Mode 1: hive_name provided - return tiers for specific hive
    if hive_name is not None:
        normalized_hive = normalize_hive_name(hive_name)

        # Validate hive exists
        if normalized_hive not in config.hives:
            error_msg = f"Hive '{normalized_hive}' not found in configuration"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Resolve child_tiers for this specific hive
        child_tiers = resolve_child_tiers_for_hive(normalized_hive, config)

        # Build tier structure using helper
        tiers = _build_tier_structure(child_tiers)

        logger.info(
            f"Successfully retrieved tier configuration for hive '{normalized_hive}' with {len(tiers)} tiers"
        )
        return {"status": "success", "tiers": tiers}

    # Mode 2/3: hive_name omitted - check if any hive has per-hive child_tiers
    has_per_hive_tiers = any(
        hive_config.child_tiers is not None for hive_config in config.hives.values()
    )

    if has_per_hive_tiers:
        # Mode 2: Per-hive map
        hives_dict = {}

        for hive_name_key, _hive_config in config.hives.items():
            # Resolve child_tiers for this hive
            child_tiers = resolve_child_tiers_for_hive(hive_name_key, config)

            # Build tier structure using helper
            tiers = _build_tier_structure(child_tiers)

            hives_dict[hive_name_key] = {"tiers": tiers}

        logger.info(f"Successfully retrieved per-hive tier configuration for {len(hives_dict)} hives")
        return {"status": "success", "per_hive": True, "hives": hives_dict}

    # Mode 3: Backward compatible - flat tiers from scope-level config
    # Build tier structure starting with bee (t0)
    tiers = {"t0": {"singular": "Bee", "plural": "Bees", "parent": None}}

    # Add child tiers from scope-level config
    # child_tiers may be None (not configured = fall through) or {} (bees-only)
    for tier_id in sorted((config.child_tiers or {}).keys()):
        tier_config = config.child_tiers[tier_id]

        # Determine parent tier
        # Extract tier number (e.g., "t1" -> 1, "t2" -> 2)
        tier_num = int(tier_id[1:])
        parent_tier = f"t{tier_num - 1}" if tier_num > 1 else "t0"

        tiers[tier_id] = {"singular": tier_config.singular, "plural": tier_config.plural, "parent": parent_tier}

    logger.info(f"Successfully retrieved tier configuration with {len(tiers)} tiers")

    return {"status": "success", "tiers": tiers}
