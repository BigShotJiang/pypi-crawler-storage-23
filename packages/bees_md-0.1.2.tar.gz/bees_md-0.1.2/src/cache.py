"""Ticket read cache module.

Provides a module-level singleton cache for read_ticket() results.
Key: ticket_id → Value: (mtime, Ticket)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import Ticket

__all__ = ["contains", "get", "put", "evict", "clear"]

# Module-private backing store: ticket_id -> (mtime, Ticket)
_cache: dict[str, tuple[float, Ticket]] = {}


def contains(ticket_id: str) -> bool:
    """Return True if ticket_id is present in the cache, regardless of mtime."""
    return ticket_id in _cache


def get(ticket_id: str) -> tuple[float, Ticket] | None:
    """Return (mtime, Ticket) for the given ticket_id, or None if not cached."""
    return _cache.get(ticket_id)


def put(ticket_id: str, mtime: float, ticket: Ticket) -> None:
    """Store (mtime, Ticket) under the given ticket_id."""
    _cache[ticket_id] = (mtime, ticket)


def evict(ticket_id: str) -> None:
    """Remove entry for the given ticket_id if present."""
    _cache.pop(ticket_id, None)


def clear() -> None:
    """Remove all entries from the cache."""
    _cache.clear()
