"""ID generation and validation utilities for tickets."""

import random
import re
from pathlib import Path

from src.constants import GUID_CHARSET, GUID_LENGTH

from . import cache

# New ID format: {type_prefix}.{shortID}
# Examples: b.Amx, t1.X4F2, t2.R8P2k
# Pattern: b.XXX (3 chars) OR t{N}.{N+3 chars}
# Charset: 1-9, A-H,J-N,P-Z, a-k,m-z (excludes 0,O,I,l)
ID_PATTERN = re.compile(r"^(b\.[1-9A-HJ-NP-Za-km-z]{3}|t(\d+)\.[1-9A-HJ-NP-Za-km-z]+)$")


def normalize_hive_name(hive_name: str) -> str:
    """
    Normalize hive name to lowercase with underscores.

    NOTE: This function is still used for hive name normalization in config and file operations,
    but is no longer used for ID generation (IDs no longer contain hive names).

    Args:
        hive_name: The hive name to normalize

    Returns:
        Normalized hive name (lowercase, spaces/hyphens converted to underscores)

    Examples:
        >>> normalize_hive_name("BackEnd")
        'backend'
        >>> normalize_hive_name("My Hive")
        'my_hive'
        >>> normalize_hive_name("front-end")
        'front_end'
    """
    # Replace spaces and hyphens with underscores, convert to lowercase
    normalized = hive_name.lower().replace(" ", "_").replace("-", "_")
    # Remove any characters that aren't alphanumeric or underscore
    normalized = re.sub(r"[^a-z0-9_]", "", normalized)
    # Ensure it starts with a letter or underscore
    if normalized and not normalized[0].isalpha() and normalized[0] != "_":
        normalized = "_" + normalized
    return normalized


def resolve_tier_info(ticket_type: str, hive_name: str | None = None) -> tuple[str, int]:
    """
    Map ticket type to type prefix and shortID length.

    Args:
        ticket_type: Type string - "bee", "t1", "t2", etc., or friendly names from child_tiers config
        hive_name: Optional hive name for per-hive child_tiers resolution

    Returns:
        tuple[str, int]: (type_prefix, shortID_length)
        - Bee (t0): ("b", 3)
        - t1: ("t1", 4)
        - t2: ("t2", 5)
        - t{N}: ("t{N}", N+3)

    Raises:
        ValueError: If ticket_type is invalid or not configured

    Examples:
        >>> resolve_tier_info("bee")
        ("b", 3)
        >>> resolve_tier_info("t1")
        ("t1", 4)
        >>> resolve_tier_info("Task")  # if t1 has friendly name "Task"
        ("t1", 4)
    """
    # Handle "bee" (tier 0)
    if ticket_type == "bee":
        return ("b", 3)

    # Check if it's already a tier ID (t1, t2, t3...)
    tier_pattern = re.compile(r"^t(\d+)$")
    match = tier_pattern.match(ticket_type)
    if match:
        tier_num = int(match.group(1))
        length = tier_num + 3
        return (ticket_type, length)

    # Not a tier ID, check if it's a friendly name
    try:
        from .config import load_bees_config, resolve_child_tiers_for_hive
    except ImportError:
        raise ValueError(f"Invalid ticket_type: {ticket_type}. Must be 'bee' or 't{{N}}' format.") from None

    config = load_bees_config()

    # Resolve child_tiers based on hive_name
    if hive_name is not None:
        # Per-hive resolution
        child_tiers = resolve_child_tiers_for_hive(hive_name, config)
    else:
        # Backward compatibility: use scope-level child_tiers
        child_tiers = config.child_tiers if config else None

    if not child_tiers:
        raise ValueError(f"Invalid ticket_type: {ticket_type}. No child_tiers configured.")

    # Search for friendly name in child_tiers
    for tier_key, tier_config in child_tiers.items():
        if ticket_type == tier_config.singular or ticket_type == tier_config.plural:
            # Found it - extract tier number from tier_key
            match = tier_pattern.match(tier_key)
            if match:
                tier_num = int(match.group(1))
                length = tier_num + 3
                return (tier_key, length)

    raise ValueError(
        f"Invalid ticket_type: {ticket_type}. Must be 'bee', a tier ID like 't1', "
        "or a friendly name from child_tiers config."
    )


def generate_ticket_id(ticket_type: str, hive_name: str | None = None) -> str:
    """
    Generate a ticket ID with type-prefixed format.

    Format: {type_prefix}.{shortID}
    Examples: b.Amx, t1.X4F2, t2.R8P2k

    Args:
        ticket_type: Ticket type - "bee", "t1", "t2", etc., or friendly name from child_tiers
        hive_name: Optional hive name for per-hive child_tiers resolution

    Returns:
        A ticket ID string with type prefix and random shortID

    Raises:
        ValueError: If ticket_type is invalid

    Note:
        This function generates random IDs but does not check for collisions.
        Use generate_unique_ticket_id() for collision detection.

    Examples:
        >>> generate_ticket_id("bee")  # Returns something like "b.Amx"
        "b.Amx"
        >>> generate_ticket_id("t1")  # Returns something like "t1.X4F2"
        "t1.X4F2"
    """
    prefix, length = resolve_tier_info(ticket_type, hive_name=hive_name)
    short_id = "".join(random.choices(GUID_CHARSET, k=length))
    return f"{prefix}.{short_id}"


def generate_guid(short_id: str) -> str:
    """
    Generate a 22-char GUID starting with the given short_id.

    The GUID is composed of the short_id followed by random characters
    from GUID_CHARSET to fill the remaining length up to GUID_LENGTH (22).

    Args:
        short_id: The ticket's short ID (e.g., "Amx" from "b.Amx")

    Returns:
        A 22-character string starting with short_id, all chars in GUID_CHARSET

    Examples:
        >>> guid = generate_guid("Amx")
        >>> len(guid) == 22
        True
        >>> guid.startswith("Amx")
        True
    """
    remaining = GUID_LENGTH - len(short_id)
    suffix = "".join(random.choices(GUID_CHARSET, k=remaining))
    return short_id + suffix


_TICKET_ID_DIR_PATTERN = re.compile(r"^(b\.[a-zA-Z0-9]+|t\d+\.[a-zA-Z0-9]+)$")


def is_ticket_id(name: str) -> bool:
    """Check if a string looks like a ticket ID.

    Uses a relaxed pattern for directory traversal filtering — matches the
    general ticket ID format (b.XXX or t{N}.XXX) with any alphanumeric chars.
    Does not enforce charset or length constraints. Use is_valid_ticket_id()
    for strict validation.

    Args:
        name: String to check (typically a directory name)

    Returns:
        True if name matches the ticket ID format
    """
    return bool(_TICKET_ID_DIR_PATTERN.match(name))


def is_valid_ticket_id(ticket_id: str) -> bool:
    """
    Validate that a ticket ID matches the required format.

    Validates both format and length constraints:
    - b.XXX must have exactly 3-char shortID
    - t{N}.{shortID} must have shortID length = N+3

    Args:
        ticket_id: The ID string to validate

    Returns:
        True if the ID is valid, False otherwise

    Examples:
        >>> is_valid_ticket_id("b.Amx")
        True
        >>> is_valid_ticket_id("t1.X4F2")
        True
        >>> is_valid_ticket_id("t2.R8P2k")
        True
        >>> is_valid_ticket_id("b.Amx9")  # wrong length for bee
        False
    """
    if not ticket_id or not isinstance(ticket_id, str):
        return False

    # Check basic pattern
    match = ID_PATTERN.match(ticket_id)
    if not match:
        return False

    # Validate length constraints
    if ticket_id.startswith("b."):
        # Bee must have 3-char shortID
        short_id = ticket_id[2:]  # everything after "b."
        return len(short_id) == 3

    elif ticket_id.startswith("t"):
        # Extract tier number and shortID
        prefix, _, short_id = ticket_id.partition(".")
        if not prefix.startswith("t"):
            return False

        try:
            tier_num = int(prefix[1:])  # extract number from "t1", "t2", etc.
            expected_length = tier_num + 3
            return len(short_id) == expected_length
        except ValueError:
            return False

    return False


def generate_unique_ticket_id(
    ticket_type: str,
    existing_ids: set[str] | None = None,
    max_attempts: int = 100,
    hive_name: str | None = None,
) -> str:
    """
    Generate a unique ticket ID with collision detection.

    Args:
        ticket_type: Ticket type - "bee", "t1", "t2", etc., or friendly name from child_tiers
        existing_ids: Optional set of existing IDs to check against
        max_attempts: Maximum number of generation attempts before raising error
        hive_name: Optional hive name for per-hive child_tiers resolution

    Returns:
        A unique ticket ID string with type prefix

    Raises:
        RuntimeError: If unable to generate unique ID within max_attempts
        ValueError: If ticket_type is invalid

    Examples:
        >>> existing = {"b.Amx", "b.X4F"}
        >>> new_id = generate_unique_ticket_id("bee", existing)
        >>> new_id not in existing
        True
        >>> new_id.startswith("b.")
        True
    """
    if existing_ids is None:
        existing_ids = set()

    for _ in range(max_attempts):
        ticket_id = generate_ticket_id(ticket_type=ticket_type, hive_name=hive_name)
        if ticket_id not in existing_ids:
            return ticket_id

    raise RuntimeError(
        f"Failed to generate unique ticket ID after {max_attempts} attempts. "
        "This is extremely unlikely with the current ID space."
    )


def extract_existing_ids_from_directory(tickets_dir: Path) -> set[str]:
    """
    Extract all existing ticket IDs from ticket files in a directory.

    With hierarchical storage, scans hive directory recursively for all .md files.
    On warm cache, uses cache.contains() to skip is_valid_ticket_id() regex
    validation for already-known ticket IDs.

    Args:
        tickets_dir: Path to the hive root directory

    Returns:
        Set of existing ticket IDs found in filenames

    Examples:
        >>> extract_existing_ids_from_directory(Path("backend"))
        {'b.Amx', 'b.X4F', 't1.X4F2'}
    """
    existing_ids = set()

    # Scan hive directory recursively for .md files
    if tickets_dir.exists():
        for md_file in tickets_dir.glob("**/*.md"):
            # Skip cemetery directories
            if "cemetery" in md_file.parts:
                continue
            # Extract ID from filename (without .md extension)
            # CRITICAL: Use .name.removesuffix() not .stem because IDs contain dots
            # Path("b.Amx.md").stem returns "b", not "b.Amx"
            filename = md_file.name.removesuffix(".md")
            if cache.contains(filename) or is_valid_ticket_id(filename):
                existing_ids.add(filename)

    return existing_ids


def extract_existing_ids_from_all_hives() -> set[str]:
    """
    Extract all existing ticket IDs from all configured hives.

    Scans all hive directories defined in ~/.bees/config.json and collects
    all ticket IDs across all hives. IDs are globally unique across hives.

    Returns:
        Set of existing ticket IDs found across all hives

    Examples:
        >>> extract_existing_ids_from_all_hives()
        {'b.Amx', 'b.X4F', 't1.X4F2', 't2.R8P2k'}
    """
    from pathlib import Path

    existing_ids = set()

    # Import here to avoid circular dependency
    try:
        from .config import load_bees_config
    except ImportError:
        # If config module not available, return empty set
        return existing_ids

    # Load hive configuration
    config = load_bees_config()

    if not config or not config.hives:
        # No hives configured - return empty set
        return existing_ids

    # Scan each hive directory
    for _hive_name, hive_config in config.hives.items():
        hive_path = Path(hive_config.path)

        if not hive_path.exists():
            continue

        # Extract IDs from this hive's directory
        hive_ids = extract_existing_ids_from_directory(hive_path)
        existing_ids.update(hive_ids)

    return existing_ids
