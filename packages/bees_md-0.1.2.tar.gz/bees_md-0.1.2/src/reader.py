"""Ticket reader module for loading and parsing ticket files."""

from datetime import datetime
from pathlib import Path
from typing import Any

from . import cache
from .models import Ticket
from .parser import ParseError, parse_frontmatter
from .types import TicketType
from .validator import ValidationError, validate_structure

__all__ = ["get_ticket_type", "read_ticket"]


def read_ticket(file_path: Path | str, hive_name: str | None = None) -> Ticket:
    """
    Read and parse a ticket file, returning a Ticket object.

    Uses a module-level cache keyed on ticket_id. A stat() check on the file
    determines freshness: cache hit on mtime match, re-read on mismatch,
    read+cache on miss. FileNotFoundError on stat evicts the entry and
    propagates; other OSError propagates without eviction.

    Args:
        file_path: Path to the ticket markdown file
        hive_name: Deprecated. Accepted for backwards compatibility but ignored.

    Returns:
        Ticket object with type specified in frontmatter

    Raises:
        FileNotFoundError: If file doesn't exist
        ParseError: If file has invalid format or YAML
        ValidationError: If ticket data doesn't match schema

    Examples:
        >>> ticket = read_ticket("backend/b.Amx.md")
        >>> ticket.id
        'b.Amx'
        >>> ticket.type
        'bee'
    """
    file_path = Path(file_path)
    ticket_id = file_path.stem

    # Stat the file to get mtime; evict on FileNotFoundError, propagate other OSError
    try:
        file_mtime = file_path.stat().st_mtime
    except FileNotFoundError:
        cache.evict(ticket_id)
        raise
    except OSError:
        raise

    # Check cache
    cached = cache.get(ticket_id)
    if cached is not None:
        cached_mtime, cached_ticket = cached
        if cached_mtime == file_mtime:
            return cached_ticket
        # mtime mismatch — fall through to re-read

    # Parse file
    frontmatter, body = parse_frontmatter(file_path)

    # Check for schema_version field to confirm this is a Bees ticket
    if "schema_version" not in frontmatter:
        raise ValidationError("Markdown file is not a valid Bees ticket: missing 'schema_version' field in frontmatter")

    # Validate structural requirements only (permissive - allows invalid types)
    validate_structure(frontmatter)

    # Capture raw frontmatter keys before any mutations (used by linter for disallowed field detection)
    raw_keys = frozenset(frontmatter.keys())

    # Add description from body
    frontmatter["description"] = body

    # Convert date strings to datetime if present
    for date_field in ["created_at"]:
        if date_field in frontmatter and frontmatter[date_field]:
            if isinstance(frontmatter[date_field], str):
                try:
                    frontmatter[date_field] = datetime.fromisoformat(frontmatter[date_field])
                except (ValueError, TypeError) as e:
                    # Log warning but keep as string if parsing fails
                    import warnings

                    warnings.warn(
                        f"Could not parse {date_field} as ISO datetime: {e}. "
                        f"Keeping as string: {frontmatter[date_field]}",
                        stacklevel=2,
                    )

    # Return Ticket object - type validation happens in __post_init__
    ticket = Ticket(**_filter_ticket_fields(frontmatter))
    ticket._raw_keys = raw_keys

    cache.put(ticket_id, file_mtime, ticket)

    return ticket


def get_ticket_type(ticket_id: str) -> TicketType | None:
    """Return the type of a ticket given its ID.

    Checks the in-memory cache first to avoid a filesystem walk. On a cache
    miss, scans all configured hives to find the ticket file and reads it via
    read_ticket(), which populates the cache as a side effect.

    Args:
        ticket_id: The ticket ID (e.g., "b.Amx", "t1.X4F2")

    Returns:
        The ticket type ('bee', 't1', 't2', etc.) if found, None otherwise.
    """
    if not ticket_id:
        return None

    # Fast path: check memory cache before filesystem walk
    cached = cache.get(ticket_id)
    if cached is not None:
        return cached[1].type

    # Slow path: scan all hives for the ticket file
    from .config import load_bees_config
    from .paths import find_ticket_file

    config = load_bees_config()
    if not config or not config.hives:
        return None

    for hive_name, hive_config in config.hives.items():
        base_dir = Path(hive_config.path)
        md_file = find_ticket_file(base_dir, ticket_id)
        if md_file is not None:
            try:
                ticket = read_ticket(md_file, hive_name=hive_name)
                return ticket.type
            except (FileNotFoundError, ParseError, ValidationError):
                continue

    return None


def _filter_ticket_fields(data: dict[str, Any]) -> dict[str, Any]:
    """
    Filter frontmatter to only include fields defined in Ticket model.

    Args:
        data: Full frontmatter dictionary

    Returns:
        Filtered dictionary with only known ticket fields
    """
    known_fields = {
        "id",
        "type",
        "title",
        "description",
        "labels",
        "up_dependencies",
        "down_dependencies",
        "parent",
        "children",
        "egg",
        "created_at",
        "status",
        "schema_version",
        "guid",
    }

    return {k: v for k, v in data.items() if k in known_fields}
