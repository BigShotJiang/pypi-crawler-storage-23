"""
Move Bee MCP Tool — moves bee tickets between hives within the same scope.

Validates source and destination hives, checks scope compatibility,
and performs moves of bee ticket directories.
"""

import logging
import shutil
from pathlib import Path
from typing import Any

from .config import get_scope_key_for_hive, load_bees_config, load_global_config
from .hive_utils import hive_integrity_gate
from .id_utils import is_valid_ticket_id
from .paths import find_ticket_file
from .repo_utils import get_repo_root_from_path  # noqa: F401 - kept for monkeypatching in tests

logger = logging.getLogger(__name__)


def _move_bee_core(
    bee_ids: list[str],
    destination_hive: str,
) -> dict[str, Any]:
    """Synchronous core of the move_bee operation — runs inside an active repo_root_context.

    Args:
        bee_ids: List of bee ticket IDs to move (e.g., ["b.Amx", "b.X4F"])
        destination_hive: Normalized name of the destination hive

    Returns:
        dict with status and moved/skipped/not_found/failed lists.
        On error: dict with status "error", message, and error_type.
    """
    # ── Empty list → return success immediately (no validation needed) ────
    if not bee_ids:
        return {
            "status": "success",
            "moved": [],
            "skipped": [],
            "not_found": [],
            "failed": [],
        }

    # ── Load config and validate destination hive ─────────────────────────
    config = load_bees_config()
    if not config or destination_hive not in config.hives:
        return {
            "status": "error",
            "message": f"Destination hive '{destination_hive}' not found.",
            "error_type": "hive_not_found",
        }

    dest_path = Path(config.hives[destination_hive].path)

    # ── Prevent cemetery as a destination ────────────────────────────────
    if destination_hive == "cemetery" or dest_path.name == "cemetery":
        return {
            "status": "error",
            "message": "Cannot move bees into the cemetery.",
            "error_type": "cemetery_destination",
        }

    # ── Load global config once for scope lookups ─────────────────────────
    global_config = load_global_config()

    # ── Process each bee ID ───────────────────────────────────────────────
    moved: list[str] = []
    skipped: list[str] = []
    not_found: list[str] = []
    failed: list[dict[str, str]] = []

    for bee_id in bee_ids:
        # Validate ticket ID format
        if not is_valid_ticket_id(bee_id):
            failed.append({"id": bee_id, "reason": "malformed ticket ID"})
            continue

        # Only bees (b. prefix) can be moved
        if not bee_id.startswith("b."):
            failed.append({"id": bee_id, "reason": "cannot move non-bee tickets"})
            continue

        # Find bee across all registered hives
        ticket_file = None
        source_hive_name = None
        for hive_name, hive_config in config.hives.items():
            hive_path = Path(hive_config.path)
            found = find_ticket_file(hive_path, bee_id)
            if found is not None:
                ticket_file = found
                source_hive_name = hive_name
                break

        if ticket_file is None:
            not_found.append(bee_id)
            continue

        # Already in destination — skip
        if source_hive_name == destination_hive:
            skipped.append(bee_id)
            continue

        # Verify source and destination are in the same scope
        try:
            source_scope = get_scope_key_for_hive(source_hive_name, global_config)
            dest_scope = get_scope_key_for_hive(destination_hive, global_config)
        except ValueError as e:
            failed.append({"id": bee_id, "reason": str(e)})
            continue

        if source_scope != dest_scope:
            failed.append({
                "id": bee_id,
                "reason": "source and destination hives are in different scopes",
            })
            continue

        # Perform the move
        bee_dir = ticket_file.parent
        dest_bee_path = dest_path / bee_dir.name
        if dest_bee_path.exists():
            failed.append({"id": bee_id, "reason": f"destination already exists: {dest_bee_path}"})
            continue
        try:
            shutil.move(str(bee_dir), str(dest_bee_path))
            moved.append(bee_id)
        except Exception as e:
            failed.append({"id": bee_id, "reason": str(e)})

    return {
        "status": "success",
        "moved": moved,
        "skipped": skipped,
        "not_found": not_found,
        "failed": failed,
    }


async def _move_bee(
    bee_ids: list[str],
    destination_hive: str,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """Move bee tickets to a different hive within the same scope.

    Thin async wrapper that resolves repo_root, sets context, and delegates
    to _move_bee_core.

    Destination hive integrity is checked before executing the move.
    Source hive corruption does NOT block the move.

    Constraints:
        - Only bee tickets (b. prefix) can be moved; non-bee IDs are rejected
        - Source and destination hives must belong to the same scope
        - Cemetery is never a valid destination
        - Bee IDs are preserved unchanged — only the directory location changes
        - Each bee is moved atomically and independently (per-bee atomic move)

    Args:
        bee_ids (list[str]): Bee ticket IDs to move (e.g., ["b.Amx", "b.X4F"]).
                             Empty list returns success immediately with no operations performed.
        destination_hive (str): Normalized name of the destination hive (e.g., "back_end").
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: Operation result. On success:
            {
                'status': 'success',
                'moved': list[str],      # Bee IDs successfully moved
                'skipped': list[str],    # Bee IDs already in destination hive
                'not_found': list[str],  # Bee IDs not found in any registered hive
                'failed': list[dict],    # Dicts with 'id' and 'reason' for each failure
            }
        On error (destination hive not found, cemetery destination, etc.):
            {
                'status': 'error',
                'message': str,      # Human-readable error description
                'error_type': str,   # Error category (e.g., 'hive_not_found', 'cemetery_destination')
            }
        On corrupt destination hive:
            {
                'status': 'error',
                'error_type': 'hive_corrupt',
                'hive_name': str,    # Normalized name of the corrupt hive
                'message': str,      # Human-readable error description
                'errors': list[str], # Lint error messages from integrity check
            }

    Example:
        >>> await _move_bee(["b.Amx", "b.X4F"], "backlog")
        {
            'status': 'success',
            'moved': ['b.Amx', 'b.X4F'],
            'skipped': [],
            'not_found': [],
            'failed': []
        }

    Error Conditions:
        - hive_not_found: destination_hive not registered in config
        - cemetery_destination: destination is the cemetery directory
        - hive_corrupt: destination hive fails integrity checks (source hive is not checked)
        - Malformed ID: bee_id fails ticket ID format validation → added to failed list
        - Non-bee ticket: bee_id does not start with 'b.' → added to failed list
        - Cross-scope move: source and destination in different scopes → added to failed list
        - Filesystem error: shutil.move fails → added to failed list with exception message
    """
    gate_error = hive_integrity_gate(destination_hive, resolved_root)
    if gate_error is not None:
        return gate_error
    return _move_bee_core(bee_ids, destination_hive)
