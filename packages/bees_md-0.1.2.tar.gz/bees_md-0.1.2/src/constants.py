"""Constants used throughout the Bees ticket system."""

SCHEMA_VERSION = "1.0.0"

# Base58-style charset (58 chars)
# Excluded for visual ambiguity: 0, O, I, l
# Allowed: 1-9, A-H, J-N, P-Z, a-k, m-z
GUID_CHARSET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

GUID_LENGTH = 22
