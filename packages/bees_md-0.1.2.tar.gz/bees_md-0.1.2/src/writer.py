"""Markdown file writer with YAML frontmatter serialization."""

import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from .constants import SCHEMA_VERSION
from .paths import compute_ticket_directory, get_ticket_path
from .types import TicketType
from .validator import validate_id_format


class BlockScalarDumper(yaml.SafeDumper):
    """Custom YAML dumper that uses block scalar style (|) for multi-line strings."""

    pass


def str_representer(dumper, data):
    """Represent strings using block scalar style if they contain newlines."""
    if "\n" in data:
        # Use literal block scalar style (|) for multi-line strings
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
    # Use default style for single-line strings
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


# Register the custom string representer
BlockScalarDumper.add_representer(str, str_representer)


def serialize_frontmatter(data: dict[str, Any]) -> str:
    """
    Serialize a Python dict to YAML frontmatter format.

    Handles special characters, multiline strings, arrays, and nested fields.
    Formats with leading and trailing --- separators.

    Args:
        data: Dictionary containing ticket metadata

    Returns:
        YAML frontmatter string with --- delimiters

    Examples:
        >>> data = {"id": "b.Amx", "type": "bee", "title": "Test"}
        >>> frontmatter = serialize_frontmatter(data)
        >>> frontmatter.startswith("---\\n")
        True
        >>> frontmatter.endswith("---\\n")
        True
    """
    # Convert datetime objects to ISO format strings for YAML serialization
    serializable_data = {}
    for key, value in data.items():
        if isinstance(value, datetime):
            serializable_data[key] = value.isoformat()
        elif value is None:
            serializable_data[key] = value
        elif isinstance(value, list) and not value:
            # Skip empty lists to keep frontmatter clean
            continue
        else:
            serializable_data[key] = value

    # Use safe_dump with BlockScalarDumper for proper multi-line formatting
    # default_flow_style=False ensures arrays and objects use block style
    # sort_keys=False preserves field order
    # allow_unicode=True handles special characters
    # Dumper=BlockScalarDumper uses | syntax for multi-line strings
    yaml_content = yaml.dump(
        serializable_data,
        Dumper=BlockScalarDumper,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )

    # Wrap with --- delimiters
    return f"---\n{yaml_content}---\n"


def write_ticket_file(
    ticket_id: str,
    ticket_type: TicketType,
    frontmatter_data: dict[str, Any],
    body: str = "",
    hive_name: str = "",
) -> Path:
    """
    Write a ticket markdown file with YAML frontmatter and body content.

    Uses atomic write operations (temp file + rename) for safety.
    Creates hierarchical directory structure where each ticket has its own directory.

    For new tickets, computes directory path from parent chain in frontmatter.
    For existing tickets (updates), finds current location via recursive scan.

    Directory structure:
    - Bees: {hive_root}/{ticket_id}/{ticket_id}.md
    - Children: {hive_root}/{parent_id}/{ticket_id}/{ticket_id}.md

    Args:
        ticket_id: The ticket ID (e.g., "b.Amx")
        ticket_type: The type of ticket ("bee", "t1", "t2", etc.)
        frontmatter_data: Dictionary of ticket metadata for YAML frontmatter (must include 'parent' field for child tickets)
        body: Optional markdown body content
        hive_name: Hive name for storage location (required)

    Returns:
        Path to the created ticket file

    Raises:
        ValueError: If ticket_id or ticket_type is invalid
        OSError: If file write operation fails
        FileNotFoundError: If parent ticket doesn't exist (for new child tickets)

    Examples:
        >>> data = {"id": "b.Amx", "type": "bee", "title": "Test Bee"}
        >>> path = write_ticket_file("b.Amx", "bee", data, "# Description", "backend")
        >>> path.exists()
        True
    """
    # Validate ticket_id format before any filesystem operations
    if not validate_id_format(ticket_id):
        raise ValueError(f"Invalid ticket ID format: {ticket_id}")

    # Try to get path for existing ticket, or compute path for new ticket
    try:
        # For existing tickets (updates), find via recursive scan
        target_path = get_ticket_path(ticket_id, ticket_type, hive_name)
    except FileNotFoundError:
        # For new tickets, compute the directory path from parent chain
        parent_id = frontmatter_data.get("parent") if isinstance(frontmatter_data, dict) else None
        ticket_dir = compute_ticket_directory(ticket_id, parent_id, hive_name)
        target_path = ticket_dir / f"{ticket_id}.md"

    # Ensure the ticket's directory exists (creates full directory chain)
    # For hierarchical storage, this creates {hive_root}/{bee_id}/{task_id}/... structure
    target_path.parent.mkdir(parents=True, exist_ok=True)

    # Ensure schema_version is present in frontmatter
    if "schema_version" not in frontmatter_data:
        frontmatter_data = {**frontmatter_data, "schema_version": SCHEMA_VERSION}

    # Serialize frontmatter
    frontmatter = serialize_frontmatter(frontmatter_data)

    # Combine frontmatter and body
    content = frontmatter
    if body:
        # Ensure body starts on a new line after frontmatter
        content += f"\n{body}\n"

    # Atomic write: write to temp file, then rename
    # This ensures we never have partial/corrupted files
    temp_fd, temp_path = tempfile.mkstemp(
        dir=target_path.parent,
        prefix=f".{ticket_id}_",
        suffix=".md.tmp",
    )

    try:
        # Write content to temp file
        with os.fdopen(temp_fd, "w", encoding="utf-8") as f:
            f.write(content)

        # Atomically move temp file to target location
        os.rename(temp_path, target_path)

        return target_path

    except Exception:
        # Clean up temp file on error
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise
