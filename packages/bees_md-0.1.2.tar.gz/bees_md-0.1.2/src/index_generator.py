"""Index generation module for creating markdown index of all tickets."""

from datetime import datetime
from pathlib import Path

from .models import Ticket
from .paths import list_tickets
from .reader import read_ticket

__all__ = ["scan_tickets", "format_index_markdown", "generate_index", "is_index_stale"]


def _get_tier_display_names(hive_name: str | None = None) -> dict[str, str]:
    """
    Load tier display names from config.

    Reads child_tiers from config and returns a mapping of tier IDs
    to plural friendly names. Falls back to tier ID when friendly names are None.

    Args:
        hive_name: Optional hive name. When provided, resolves child_tiers for that hive
                   using the fallback chain (hive → scope → global → bees-only).
                   When omitted, uses scope-level child_tiers (legacy behavior).

    Returns:
        Dictionary mapping tier IDs to display names, e.g.:
        - {"t1": "Tasks", "t2": "Subtasks"} when friendly names defined
        - {"t1": "t1", "t2": "t2"} when friendly names are None
        - {} if no config or child_tiers not defined

    Examples:
        >>> names = _get_tier_display_names()
        >>> names.get("t1", "t1")
        'Tasks'
        >>> names = _get_tier_display_names(hive_name="backend")
        >>> names.get("t1", "t1")
        'Epic'
    """
    from .config import load_bees_config, resolve_child_tiers_for_hive

    config = load_bees_config()

    if not config:
        return {}

    # Resolve child_tiers based on hive_name parameter
    if hive_name:
        # Per-hive resolution using fallback chain
        child_tiers = resolve_child_tiers_for_hive(hive_name, config)
    else:
        # Legacy behavior: use scope-level child_tiers
        child_tiers = config.child_tiers

    # Return empty dict if no child_tiers
    if not child_tiers:
        return {}

    # Build mapping: tier_id -> display name (plural friendly name or tier_id fallback)
    result = {}
    for tier_id, tier_config in child_tiers.items():
        # Use plural friendly name if available, otherwise fall back to tier ID
        display_name = tier_config.plural if tier_config.plural else tier_id
        result[tier_id] = display_name

    return result


def scan_tickets(
    status_filter: str | None = None, type_filter: str | None = None, hive_name: str | None = None
) -> dict[str, list[Ticket]]:
    """
    Scan tickets/ directory and load all ticket metadata.

    Scans hive root directories (flat storage) and loads all ticket files,
    grouping them by type from YAML frontmatter. Optionally filters results
    by status, type, and/or hive.

    Args:
        status_filter: Optional status to filter by (e.g., 'open', 'completed')
        type_filter: Optional type to filter by (e.g., 'bee', 't1', 't2')
        hive_name: Optional hive name to filter by (e.g., 'backend'). When provided,
                   only returns tickets belonging to that hive. When omitted, returns
                   tickets from all hives.

    Returns:
        Dictionary with ticket type keys (e.g., 'bee', 't1', 't2') containing lists of
        corresponding Ticket objects. Empty lists if no tickets of that type exist
        or if filtered out.

    Examples:
        >>> tickets = scan_tickets()
        >>> len(tickets['bee'])
        5
        >>> tickets = scan_tickets(status_filter='open')
        >>> tickets = scan_tickets(type_filter='bee')
        >>> tickets = scan_tickets(status_filter='completed', type_filter='t1')
        >>> tickets = scan_tickets(hive_name='backend')
    """
    # Initialize result dictionary dynamically from config
    # Build keys as: "bee" + tier IDs from child_tiers (t1, t2, t3...)
    from .config import load_bees_config, resolve_child_tiers_for_hive

    config = load_bees_config()

    # Start with "bee" key
    result: dict[str, list[Ticket]] = {"bee": []}

    # Add tier keys from config (resolve per-hive if hive_name provided)
    if config:
        # Resolve child_tiers based on hive_name parameter
        if hive_name:
            # Per-hive resolution using fallback chain
            child_tiers = resolve_child_tiers_for_hive(hive_name, config)
        else:
            # Legacy behavior: use scope-level child_tiers
            child_tiers = config.child_tiers

        if child_tiers:
            # Sort tier keys to maintain order (t1, t2, t3...)
            tier_keys = sorted(child_tiers.keys(), key=lambda x: int(x[1:]))
            for tier_id in tier_keys:
                result[tier_id] = []

    # Get all ticket files
    all_ticket_paths = list_tickets()

    # Config is required for hive resolution; list_tickets() already returns []
    # when config is None, but guard explicitly so ticket_hive derivation is always safe.
    if not config:
        return result

    # Load each ticket and group by type
    for ticket_path in all_ticket_paths:
        try:
            # Determine which hive this ticket belongs to for cache keying
            ticket_hive: str | None = None
            for _h_name, _h_config in config.hives.items():
                try:
                    ticket_path.relative_to(Path(_h_config.path))
                    ticket_hive = _h_name
                    break
                except ValueError:
                    continue

            ticket = read_ticket(ticket_path, hive_name=ticket_hive)

            # Apply filters
            if status_filter and ticket.status != status_filter:
                continue
            if type_filter and ticket.type != type_filter:
                continue

            # Apply hive filter - check if ticket file is in the specified hive
            if hive_name:
                # With new ID format, hive is NOT part of ticket ID
                # Instead, check if ticket_path is within the hive directory
                if hive_name in config.hives:
                    hive_path = Path(config.hives[hive_name].path)
                    # Check if ticket file is in this hive's directory
                    try:
                        ticket_path.relative_to(hive_path)
                    except ValueError:
                        # ticket_path is not under hive_path, skip it
                        continue
                else:
                    # Hive not in config, skip all tickets
                    continue

            # Group ticket by type, skipping if type not in result dict
            if ticket.type in result:
                result[ticket.type].append(ticket)
        except Exception as e:
            # Log warning but continue processing other tickets
            import warnings

            warnings.warn(f"Failed to load ticket {ticket_path}: {e}. Skipping.", stacklevel=2)
            continue

    return result


def format_index_markdown(
    tickets: dict[str, list[Ticket]], include_timestamp: bool = True, hive_name: str | None = None
) -> str:
    """
    Generate formatted markdown index from grouped ticket data.

    Creates a structured markdown document with sections organized by ticket type.
    Each ticket shows ID, title, status, and hierarchy information.
    With hierarchical storage, generates correct relative links to nested ticket files.

    Args:
        tickets: Dictionary with ticket type keys (e.g., 'bee', 't1', 't2') containing
                 lists of Ticket objects
        include_timestamp: If True, includes generation timestamp in header
        hive_name: Optional hive name for computing correct relative paths to ticket files

    Returns:
        Formatted markdown string with all tickets organized by type

    Examples:
        >>> tickets = scan_tickets()
        >>> markdown = format_index_markdown(tickets)
        >>> print(markdown)
        # Ticket Index

        ## Bees
        - [b.Amx] Authentication System (open)
        ...
    """
    lines = []

    # Add header
    lines.append("# Ticket Index")
    lines.append("")

    # Add timestamp metadata
    if include_timestamp:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines.append(f"*Generated: {timestamp}*")
        lines.append("")

    # Build sections dynamically based on what's in the tickets dict
    # Start with Bees section
    sections = [("Bees", "bee")]

    # Infer sections from tickets dict keys (what scan_tickets returned)
    ticket_keys = set(tickets.keys()) - {"bee"}

    # Check for tier keys (t1, t2, t3...)
    tier_keys_set = {k for k in ticket_keys if k.startswith("t") and k[1:].isdigit()}

    if tier_keys_set:
        # Has tier keys - try to get friendly names from config, fall back to tier IDs
        tier_display_names = _get_tier_display_names(hive_name)

        # Sort tier keys to maintain order (t1, t2, t3...)
        sorted_tier_keys = sorted(tier_keys_set, key=lambda x: int(x[1:]))

        for tier_id in sorted_tier_keys:
            # Use friendly name if available, otherwise use tier ID
            display_name = tier_display_names.get(tier_id, tier_id) if tier_display_names else tier_id
            sections.append((display_name, tier_id))

    for section_title, ticket_type in sections:
        lines.append(f"## {section_title}")
        lines.append("")

        ticket_list = tickets.get(ticket_type, [])

        if not ticket_list:
            lines.append("*No tickets found*")
            lines.append("")
        else:
            # Sort by ID for consistent ordering
            sorted_tickets = sorted(ticket_list, key=lambda t: t.id)

            for ticket in sorted_tickets:
                # Format: - [ticket-id: title](relative/path/to/ticket.md) (status)
                status = ticket.status or "unknown"

                # For hierarchical storage, compute relative path from hive root to ticket file
                if hive_name:
                    try:
                        from .config import load_bees_config
                        from .paths import get_ticket_path

                        config = load_bees_config()
                        if config and hive_name in config.hives:
                            # Get ticket's absolute path
                            ticket_path = get_ticket_path(ticket.id, ticket.type, hive_name)
                            hive_path = Path(config.hives[hive_name].path)

                            # Compute relative path from hive root (where index.md lives) to ticket file
                            ticket_link = str(ticket_path.relative_to(hive_path))
                        else:
                            # Fallback to simple pattern if config not available
                            ticket_link = f"{ticket.id}/{ticket.id}.md"
                    except Exception:
                        # Fallback to simple pattern if path resolution fails
                        ticket_link = f"{ticket.id}/{ticket.id}.md"
                else:
                    # No hive_name provided - use simple pattern (bee-level directories)
                    ticket_link = f"{ticket.id}/{ticket.id}.md"

                line = f"- [{ticket.id}: {ticket.title}]({ticket_link}) ({status})"

                # Add parent info for subtasks
                if ticket.parent:
                    line += f" (parent: {ticket.parent})"

                lines.append(line)

            lines.append("")

    return "\n".join(lines)


def is_index_stale(hive_name: str | None = None) -> bool:
    """
    Check if index.md files are stale (older than ticket files).

    Scans hive directories recursively (hierarchical storage) to check if any
    ticket file is newer than the index. Excludes special directories and only
    checks files matching {ticket_id}/{ticket_id}.md pattern.

    If hive_name is provided, checks only that hive's index.
    If hive_name is None, checks all hive indexes.

    Args:
        hive_name: Optional hive name to check. If None, checks all hives.

    Returns:
        True if any index needs regeneration, False if all indexes are up-to-date

    Examples:
        >>> is_index_stale()
        True
        >>> is_index_stale("backend")
        False
    """
    from .config import load_bees_config

    config = load_bees_config()

    if not config or not config.hives:
        # No hives configured - nothing to check
        return False

    # Determine which hives to check
    if hive_name:
        if hive_name not in config.hives:
            return True  # Hive doesn't exist, treat as stale
        hives_to_check = [(hive_name, config.hives[hive_name])]
    else:
        hives_to_check = list(config.hives.items())

    # Check each hive's index
    for _hive_key, hive_config in hives_to_check:
        hive_path = Path(hive_config.path)

        if not hive_path.exists():
            continue

        index_path = hive_path / "index.md"

        # If index doesn't exist, it's stale
        if not index_path.exists():
            return True

        # Get index modification time
        index_mtime = index_path.stat().st_mtime

        # Check ticket files using selective traversal (only enters ticket-ID directories)
        from .paths import iter_ticket_files

        for ticket_path in iter_ticket_files(hive_path):
            # Check if ticket file is newer than index
            if ticket_path.stat().st_mtime > index_mtime:
                return True

    return False


def generate_index(
    status_filter: str | None = None, type_filter: str | None = None, hive_name: str | None = None
) -> str:
    """
    Generate complete markdown index for all tickets and write to disk.

    High-level orchestration function that scans the tickets directory,
    loads all tickets, formats them into a markdown index, and writes to
    the appropriate location. Can generate per-hive indexes or indexes
    for all hives.

    When hive_name is provided, generates and writes index only for that hive
    to {hive_path}/index.md.

    When hive_name is omitted, iterates all registered hives and generates
    separate index.md files for each hive at their respective hive roots.

    Args:
        status_filter: Optional status to filter by (e.g., 'open', 'completed')
        type_filter: Optional type to filter by (e.g., 'bee', 't1', 't2')
        hive_name: Optional hive name to generate index for specific hive only.
                   If provided, generates index only for that hive.
                   If omitted, generates indexes for all hives.

    Returns:
        Complete markdown index as a string (for single hive or last hive processed)

    Examples:
        >>> index_md = generate_index()
        >>> print(index_md)
        # Ticket Index
        ## Bees
        ...
        >>> open_tickets = generate_index(status_filter='open')
        >>> bees_only = generate_index(type_filter='bee')
        >>> backend_index = generate_index(hive_name='backend')
    """
    from .config import load_bees_config

    config = load_bees_config()

    if hive_name:
        # Generate index for specific hive
        tickets = scan_tickets(status_filter, type_filter, hive_name)
        markdown = format_index_markdown(tickets, include_timestamp=True, hive_name=hive_name)

        # Write to hive root directory
        if config and hive_name in config.hives:
            hive_path = Path(config.hives[hive_name].path)
            index_path = hive_path / "index.md"
            index_path.write_text(markdown)
        else:
            # Hive not in config - write to {cwd}/{hive_name}/index.md
            hive_path = Path.cwd() / hive_name
            index_path = hive_path / "index.md"
            # Create directory if needed
            hive_path.mkdir(parents=True, exist_ok=True)
            index_path.write_text(markdown)

        return markdown
    else:
        # Generate indexes for all hives
        if not config or not config.hives:
            # No hives configured - just return markdown without writing
            # (backward compatibility for tests and legacy usage)
            tickets = scan_tickets(status_filter, type_filter, None)
            markdown = format_index_markdown(tickets, include_timestamp=True)
            return markdown

        # Iterate all hives and generate separate indexes
        last_markdown = ""
        for hive_name_key in config.hives:
            tickets = scan_tickets(status_filter, type_filter, hive_name_key)
            markdown = format_index_markdown(tickets, include_timestamp=True, hive_name=hive_name_key)

            # Write to hive root directory
            hive_path = Path(config.hives[hive_name_key].path)

            # Skip if hive path doesn't exist (e.g., config from different environment)
            if not hive_path.exists():
                continue

            index_path = hive_path / "index.md"
            index_path.write_text(markdown)

            last_markdown = markdown

        # If no hives were actually written (all paths invalid), return markdown for all tickets
        if not last_markdown:
            tickets = scan_tickets(status_filter, type_filter, None)
            last_markdown = format_index_markdown(tickets, include_timestamp=True)

        return last_markdown
