"""
MCP Index Operations Module

Provides index generation functionality for the Bees MCP server.
Handles filtering and generation of ticket indexes.
"""

import logging
from pathlib import Path
from typing import Any

from .config import load_bees_config
from .hive_utils import check_hive_integrity, hive_integrity_gate
from .index_generator import generate_index
from .repo_utils import get_repo_root_from_path  # noqa: F401 - kept for monkeypatching in tests

logger = logging.getLogger(__name__)


async def _generate_index(
    status: str | None = None,
    type: str | None = None,
    hive_name: str | None = None,
    resolved_root: Path | None = None,
) -> dict[str, Any]:
    """
    Generate markdown index of all tickets with optional filters.

    Scans the tickets directory and creates a formatted markdown index.
    Optionally filters tickets by status and/or type. Can generate per-hive
    indexes or indexes for all hives.

    When hive_name is provided, generates and writes index only for that hive
    to {hive_path}/index.md. Returns a hive_corrupt error if integrity fails.

    When hive_name is omitted, iterates all registered hives and generates
    separate index.md files for each healthy hive. Corrupt hives are skipped
    (not written) and their names are collected in skipped_hives.

    Args:
        status: Optional status filter (e.g., 'open', 'completed')
        type: Optional type filter (e.g., 'bee', 't1', 't2')
        hive_name: Optional hive name to generate index for specific hive only.
                   If provided, generates index only for that hive.
                   If omitted, generates indexes for all healthy hives.
        resolved_root: Pre-resolved repo root path (injected by adapter)

    Returns:
        dict: Success response with keys:
              - status: "success"
              - markdown: generated markdown string (last hive processed, or
                empty string if all hives were skipped/no hives configured)
              - skipped_hives: list of hive names skipped due to corruption
                (always present; empty list when hive_name is specified)
              On corrupt single-hive request, returns error dict with keys:
              status, error_type, hive_name, message, errors.

    Example:
        result = _generate_index()
        result = _generate_index(status='open')
        result = _generate_index(type='bee')
        result = _generate_index(status='open', type='t1')
        result = _generate_index(hive_name='backend')
    """
    try:
        if hive_name:
            # Integrity gate: abort if hive is corrupt
            gate_error = hive_integrity_gate(hive_name, resolved_root)
            if gate_error is not None:
                return gate_error
            index_markdown = generate_index(status_filter=status, type_filter=type, hive_name=hive_name)
            logger.info(f"Successfully generated ticket index (status={status}, type={type}, hive_name={hive_name})")
            return {"status": "success", "markdown": index_markdown, "skipped_hives": []}
        else:
            config = load_bees_config()
            skipped_hives: list[str] = []
            last_markdown = ""

            if config and config.hives:
                for h_name in config.hives:
                    integrity_result = check_hive_integrity(h_name, resolved_root)
                    if integrity_result is not None:
                        skipped_hives.append(h_name)
                        logger.warning(f"Skipping corrupt hive '{h_name}' during global index generation")
                        continue
                    last_markdown = generate_index(status_filter=status, type_filter=type, hive_name=h_name)
            else:
                last_markdown = generate_index(status_filter=status, type_filter=type, hive_name=None)

            logger.info(
                f"Successfully generated ticket index "
                f"(status={status}, type={type}, skipped_hives={skipped_hives})"
            )
            return {"status": "success", "markdown": last_markdown, "skipped_hives": skipped_hives}
    except Exception as e:
        error_msg = f"Failed to generate index: {e}"
        logger.error(error_msg)
        raise ValueError(error_msg) from e
