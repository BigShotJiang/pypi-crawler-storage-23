# era_py

Helpers for the Python port of *Empirical Research in Accounting: Tools and Methods*.

## Install

```
pip install era-py
pip install "era-py[tables]"
```

## Usage
```python
from era_py import load_data, ols_dropcollinear

camp = load_data("camp_attendance")
```
