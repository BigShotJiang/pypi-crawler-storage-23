"""
Thin Python bindings for the MARISA Trie C++ library.

This package exposes the upstream MARISA API with minimal abstraction.
For detailed API behavior and semantics, refer to the official MARISA documentation:

    https://www.s-yata.jp/marisa-trie/docs/readme.en.html

This project vendors the upstream source to ensure reproducible builds,
while keeping the implementation faithful to the original API.
"""

__version__ = '1.0.5'
