0.0.5 (2022-08-02)
==================

- Removing dependency of navigator.conf

0.0.3 (2022-08-02)
==================

- Code migrated from Navigator API
- Added basic support for Cookie Storage
- Migrated Redis storage to aioredis > 2.x

0.0.1 (2022-08-02)
==================

- First public release
