"""NAV Session Storage Module."""
