# Aegis — Coding Conventions for AI Assistants

## Project Overview

Aegis is the Adaptive Intelligence Layer for AI Agents by Metronis, Inc.
Three products on one platform: **Aegis Eval**, **Aegis Train**, **Aegis Memory**.

## Language & Runtime

- Python 3.11+ (strict typing, `from __future__ import annotations`)
- TypeScript/React for `dashboard/`
- FastAPI for `src/aegis/api/`

## Code Style

- **Formatter**: `ruff format` (line-length 100)
- **Linter**: `ruff check` with rules E, F, I, N, UP, B, SIM, TCH
- **Type checker**: `mypy --strict` with pydantic plugin
- **Imports**: Use `from __future__ import annotations` in every module
- **Naming**: snake_case for Python, camelCase for TypeScript
- **Docstrings**: Google-style, required for all public classes and functions

## Architecture

```
src/aegis/
├── adapters/     # Agent framework bridges (OpenAI, Anthropic, LangChain, etc.)
├── api/          # FastAPI application and route handlers
├── arena/        # Competitive leaderboard and submission system
├── cli/          # Typer CLI (aegis eval run, aegis train start, etc.)
├── core/         # Shared types (Pydantic V1 schemas), exceptions, settings
├── eval/         # Evaluation engine, dimensions (7 tiers), scorers, judges
├── ingestion/    # Document parsing and chunking pipeline
├── memory/       # Memory store, operations (12 ops), knowledge graph, provenance
├── observatory/  # Runtime monitoring (reward hacking, gradient health, drift)
├── plugins/      # Domain plugins (legal, finance, safety)
├── security/     # RBAC, governance, compliance
├── training/     # RL training engine (AMIR-GRPO, GRPO-SG), optimizers, replay
```

## Key Patterns

- **Pydantic BaseModel** for all data structures (V1 schema suffix, e.g. `TrajectoryV1`)
- **Protocol classes** for extensible interfaces (e.g. `RLTrainer`)
- **Registry pattern** for dimensions (`@register_dimension`)
- **Triangulated scoring**: rule-based + semantic + LLM judge
- **Settings via Pydantic BaseSettings** with `.env` loading

## Testing

- `pytest` with `pytest-asyncio` for async tests
- Test files mirror source structure: `tests/test_<module>.py`
- Markers: `@pytest.mark.integration` for tests needing external services
- Run: `make test` or `python -m pytest tests/ -v`

## Commands

```bash
make install     # pip install -e ".[dev,all]"
make test        # pytest tests/ -v
make lint        # ruff check src/ tests/
make format      # ruff format src/ tests/
make typecheck   # mypy src/aegis/
make coverage    # pytest --cov=aegis --cov-fail-under=80
make docs        # mkdocs serve
make docker-up   # docker compose up -d
```

## Dependency Rules

- Core package has minimal deps: pydantic, typer, rich, httpx, pyyaml
- Heavy deps are optional extras: torch, transformers, sentence-transformers
- Use `TYPE_CHECKING` guards for optional imports
- Never import torch/transformers at module level in non-training code
