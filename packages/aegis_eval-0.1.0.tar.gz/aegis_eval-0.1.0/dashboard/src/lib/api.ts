const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// ---------------------------------------------------------------------------
// Eval types
// ---------------------------------------------------------------------------

export interface EvalRun {
  run_id: string;
  agent_id: string;
  overall_score: number;
  num_dimensions: number;
  created_at: string;
}

export interface DimensionScore {
  dimension_id: string;
  score: number;
  num_cases: number;
  tier: number;
}

export interface EvalRunDetail {
  run_id: string;
  agent_id: string;
  status: string;
  overall_score: number;
  dimension_scores: DimensionScore[] | Record<string, number>;
  diagnostic: Record<string, unknown>;
  created_at: string;
}

export interface DimensionInfo {
  dimension_id: string;
  name: string;
  tier: number;
  description: string;
  scorer_type: string | null;
  phase: string | null;
  domain: string | null;
}

// ---------------------------------------------------------------------------
// Training types
// ---------------------------------------------------------------------------

export interface TrainingJob {
  job_id: string;
  customer_id: string;
  domain: string;
  optimizer: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface TrainingJobDetail {
  job_id: string;
  customer_id: string;
  domain: string;
  optimizer: string;
  status: string;
  lora_config: {
    rank: number;
    alpha: number;
    dropout: number;
    target_modules: string[];
  };
  curriculum: { stage: number; name: string; difficulty: number; num_episodes: number }[];
  metrics: {
    current_stage: number;
    total_stages: number;
    episodes_completed: number;
    mean_reward: number;
    best_reward: number;
    loss: number | null;
  };
  created_at: string;
  updated_at: string;
}

export interface MetricsSeriesPoint {
  stage_index: number;
  reward: number;
  loss: number;
  kl_divergence: number;
  entropy: number;
}

export interface MetricsSeries {
  job_id: string;
  status: string;
  series: MetricsSeriesPoint[];
}

export interface ObservatoryCheck {
  healthy: boolean;
  score: number;
  details: Record<string, unknown>;
  recommendations: string[];
}

export interface ObservatoryReport {
  job_id: string;
  status: string;
  overall_healthy: boolean;
  composite_score: number;
  checks: Record<string, ObservatoryCheck>;
}

// ---------------------------------------------------------------------------
// Memory types
// ---------------------------------------------------------------------------

export interface MemoryEntry {
  id: string;
  key: string;
  value: unknown;
  memory_tier: string;
  confidence: number;
  timestamp: string;
  metadata: Record<string, unknown>;
}

export interface MemoryHealth {
  total_entries: number;
  tier_counts: Record<string, number>;
  vector_index_size: number;
  knowledge_graph_nodes: number;
  knowledge_graph_edges: number;
  [key: string]: unknown;
}

export interface MemorySnapshot {
  timestamp: string;
  total_entries: number;
  tier_counts: Record<string, number>;
  entries: MemoryEntry[];
}

export interface AuditEvent {
  id: string;
  operation: string;
  key: string;
  agent_id: string;
  customer_id: string;
  timestamp: string;
  [key: string]: unknown;
}

// ---------------------------------------------------------------------------
// Ingestion types
// ---------------------------------------------------------------------------

export interface IngestionHistoryItem {
  document_id: string;
  source_path: string;
  num_chunks: number;
  modality: string;
}

export interface IngestionChunk {
  content: string;
  modality: string;
  source_path: string;
  chunk_index: number;
  metadata: Record<string, unknown>;
  confidence: number;
}

export interface IngestionResult {
  document_id: string;
  source_path: string;
  num_chunks: number;
  modality: string;
  chunks: IngestionChunk[];
  storage_counts: Record<string, number>;
}

export interface ParserInfo {
  name: string;
  extensions: string[];
  modalities: string[];
}

export interface SupportedFormatsResponse {
  extensions: string[];
  parsers: ParserInfo[];
}

// ---------------------------------------------------------------------------
// Generic fetcher
// ---------------------------------------------------------------------------

async function apiFetch<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`API error ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`API error ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

async function apiPostForm<T>(path: string, body: FormData): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    body,
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`API error ${res.status}: ${await res.text()}`);
  }
  return res.json();
}

// ---------------------------------------------------------------------------
// Eval API
// ---------------------------------------------------------------------------

export async function listEvalRuns(
  limit = 20,
  offset = 0
): Promise<EvalRun[]> {
  return apiFetch<EvalRun[]>(
    `/eval/runs?limit=${limit}&offset=${offset}`
  );
}

export async function getEvalRun(runId: string): Promise<EvalRunDetail> {
  return apiFetch<EvalRunDetail>(`/eval/runs/${runId}`);
}

export async function listDimensions(): Promise<DimensionInfo[]> {
  return apiFetch<DimensionInfo[]>(`/eval/dimensions`);
}

// ---------------------------------------------------------------------------
// Training API
// ---------------------------------------------------------------------------

export async function listTrainingJobs(
  limit = 20,
  offset = 0
): Promise<TrainingJob[]> {
  return apiFetch<TrainingJob[]>(
    `/training/jobs?limit=${limit}&offset=${offset}`
  );
}

export async function getTrainingJob(jobId: string): Promise<TrainingJobDetail> {
  return apiFetch<TrainingJobDetail>(`/training/jobs/${jobId}`);
}

export async function getMetricsSeries(jobId: string): Promise<MetricsSeries> {
  return apiFetch<MetricsSeries>(`/training/jobs/${jobId}/metrics/series`);
}

export async function getObservatoryReport(jobId: string): Promise<ObservatoryReport> {
  return apiFetch<ObservatoryReport>(`/training/jobs/${jobId}/observatory`);
}

export async function createTrainingJob(body: {
  customer_id: string;
  domain: string;
  optimizer?: string;
}): Promise<{ job_id: string; status: string }> {
  return apiPost<{ job_id: string; status: string }>(`/training/jobs`, body);
}

// ---------------------------------------------------------------------------
// Memory API
// ---------------------------------------------------------------------------

export async function getMemoryHealth(): Promise<MemoryHealth> {
  return apiFetch<MemoryHealth>(`/memory/health`);
}

export async function getMemorySnapshot(timestamp: string): Promise<MemorySnapshot> {
  return apiFetch<MemorySnapshot>(`/memory/snapshots/${timestamp}`);
}

export async function queryMemory(
  query: string,
  customerId: string,
  limit = 50
): Promise<MemoryEntry[]> {
  return apiPost<MemoryEntry[]>(`/memory/query`, {
    query,
    customer_id: customerId,
    limit,
  });
}

export async function getAuditTrail(): Promise<AuditEvent[]> {
  return apiFetch<AuditEvent[]>(`/memory/audit`);
}

export async function retrieveMemory(
  query: string,
  mode = "auto",
  limit = 10
): Promise<MemoryEntry[]> {
  return apiPost<MemoryEntry[]>(`/memory/retrieve`, { query, mode, limit });
}

// ---------------------------------------------------------------------------
// Ingestion API
// ---------------------------------------------------------------------------

export async function uploadDocument(
  file: File,
  store = false
): Promise<IngestionResult> {
  const data = new FormData();
  data.append("file", file);
  return apiPostForm<IngestionResult>(`/v1/ingestion/upload?store=${store}`, data);
}

export async function listIngestionHistory(): Promise<IngestionHistoryItem[]> {
  return apiFetch<IngestionHistoryItem[]>(`/v1/ingestion/history`);
}

export async function listSupportedFormats(): Promise<SupportedFormatsResponse> {
  return apiFetch<SupportedFormatsResponse>(`/v1/ingestion/formats`);
}

export async function getIngestionStatus(documentId: string): Promise<IngestionResult> {
  return apiFetch<IngestionResult>(`/v1/ingestion/${documentId}`);
}

export async function retryIngestion(documentId: string, store = false): Promise<IngestionResult> {
  return apiPost<IngestionResult>(`/v1/ingestion/${documentId}/retry?store=${store}`, {});
}
