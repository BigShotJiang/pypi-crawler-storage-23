"use client";

import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  Cell,
} from "recharts";

/** Tier labels matching the 7-tier Aegis eval hierarchy. */
const TIER_LABELS: Record<number, string> = {
  1: "Memory Fidelity",
  2: "Context Intelligence",
  3: "Learning Dynamics",
  4: "Reasoning Quality",
  5: "Meta-Cognition",
  6: "Collaborative Context",
  7: "Security & Adversarial",
};

interface DimensionEntry {
  dimension_id: string;
  score: number;
  tier: number;
}

interface DimensionHeatmapProps {
  dimensions: DimensionEntry[];
}

function scoreColor(score: number): string {
  if (score >= 0.8) return "#22c55e";
  if (score >= 0.6) return "#84cc16";
  if (score >= 0.4) return "#eab308";
  if (score >= 0.2) return "#f97316";
  return "#ef4444";
}

interface HeatmapTooltipProps {
  active?: boolean;
  payload?: { payload: { name: string; score: number; tierLabel: string } }[];
}

function HeatmapTooltip({ active, payload }: HeatmapTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  const data = payload[0].payload;
  return (
    <div className="bg-[#1a1a1a] border border-[#333] rounded-md px-3 py-2 text-sm">
      <div className="font-medium text-white">{data.name}</div>
      <div className="text-gray-400 text-xs mt-0.5">{data.tierLabel}</div>
      <div className="mt-1 tabular-nums" style={{ color: scoreColor(data.score) }}>
        {(data.score * 100).toFixed(1)}%
      </div>
    </div>
  );
}

export default function DimensionHeatmap({ dimensions }: DimensionHeatmapProps) {
  if (dimensions.length === 0) {
    return <p className="text-sm text-gray-500">No dimension data available.</p>;
  }

  // Group dimensions by tier and assign x-index within each tier
  const tierGroups = new Map<number, DimensionEntry[]>();
  for (const d of dimensions) {
    const group = tierGroups.get(d.tier) || [];
    group.push(d);
    tierGroups.set(d.tier, group);
  }

  const data = dimensions.map((d) => {
    const group = tierGroups.get(d.tier) || [];
    const xIndex = group.indexOf(d);
    return {
      x: xIndex,
      y: d.tier,
      z: d.score,
      score: d.score,
      name: d.dimension_id.replace(/_/g, " "),
      tierLabel: TIER_LABELS[d.tier] || `Tier ${d.tier}`,
    };
  });

  const maxX = Math.max(...data.map((d) => d.x), 0);

  return (
    <ResponsiveContainer width="100%" height={320}>
      <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 140 }}>
        <XAxis
          type="number"
          dataKey="x"
          domain={[0, maxX + 1]}
          tick={false}
          axisLine={false}
          name="Index"
        />
        <YAxis
          type="number"
          dataKey="y"
          domain={[0.5, 7.5]}
          ticks={[1, 2, 3, 4, 5, 6, 7]}
          tickFormatter={(val: number) => TIER_LABELS[val] || `Tier ${val}`}
          tick={{ fill: "#ccc", fontSize: 11 }}
          width={130}
          reversed
        />
        <ZAxis type="number" dataKey="z" range={[120, 400]} />
        <Tooltip content={<HeatmapTooltip />} />
        <Scatter data={data}>
          {data.map((entry, idx) => (
            <Cell key={idx} fill={scoreColor(entry.score)} fillOpacity={0.85} />
          ))}
        </Scatter>
      </ScatterChart>
    </ResponsiveContainer>
  );
}
