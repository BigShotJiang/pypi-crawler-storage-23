"use client";

import { useState } from "react";
import ScoreBadge from "@/components/ScoreBadge";

/** Tier labels matching the 7-tier Aegis eval hierarchy. */
const TIER_LABELS: Record<number, string> = {
  1: "Memory Fidelity",
  2: "Context Intelligence",
  3: "Learning Dynamics",
  4: "Reasoning Quality",
  5: "Meta-Cognition",
  6: "Collaborative Context",
  7: "Security & Adversarial",
};

const TIER_DESCRIPTIONS: Record<number, string> = {
  1: "Accuracy of storage, retrieval, and temporal consistency of agent memory.",
  2: "Ability to track, prioritize, and reason over context windows.",
  3: "Capacity for in-context learning, adaptation, and skill acquisition.",
  4: "Quality of multi-step reasoning, planning, and causal inference.",
  5: "Self-monitoring, confidence calibration, and strategy selection.",
  6: "Multi-agent coordination, delegation, and shared state management.",
  7: "Robustness against adversarial prompts, jailbreaks, and data poisoning.",
};

interface DimensionEntry {
  dimension_id: string;
  score: number;
  num_cases: number;
  tier: number;
}

interface TierBreakdownProps {
  dimensions: DimensionEntry[];
}

interface TierGroup {
  tier: number;
  label: string;
  description: string;
  avgScore: number;
  dimensions: DimensionEntry[];
}

function buildTierGroups(dimensions: DimensionEntry[]): TierGroup[] {
  const groups = new Map<number, DimensionEntry[]>();
  for (const d of dimensions) {
    const list = groups.get(d.tier) || [];
    list.push(d);
    groups.set(d.tier, list);
  }

  const result: TierGroup[] = [];
  for (const [tier, dims] of groups.entries()) {
    const avg = dims.reduce((sum, d) => sum + d.score, 0) / dims.length;
    result.push({
      tier,
      label: TIER_LABELS[tier] || `Tier ${tier}`,
      description: TIER_DESCRIPTIONS[tier] || "",
      avgScore: avg,
      dimensions: dims.sort((a, b) => b.score - a.score),
    });
  }

  return result.sort((a, b) => a.tier - b.tier);
}

function scoreBarColor(score: number): string {
  if (score >= 0.8) return "bg-green-500";
  if (score >= 0.6) return "bg-lime-500";
  if (score >= 0.4) return "bg-yellow-500";
  if (score >= 0.2) return "bg-orange-500";
  return "bg-red-500";
}

export default function TierBreakdown({ dimensions }: TierBreakdownProps) {
  const groups = buildTierGroups(dimensions);
  const [openTiers, setOpenTiers] = useState<Set<number>>(
    new Set(groups.map((g) => g.tier))
  );

  function toggle(tier: number) {
    setOpenTiers((prev) => {
      const next = new Set(prev);
      if (next.has(tier)) {
        next.delete(tier);
      } else {
        next.add(tier);
      }
      return next;
    });
  }

  if (groups.length === 0) {
    return <p className="text-sm text-gray-500">No tier data available.</p>;
  }

  return (
    <div className="space-y-2">
      {groups.map((group) => {
        const isOpen = openTiers.has(group.tier);
        return (
          <div
            key={group.tier}
            className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg overflow-hidden"
          >
            {/* Accordion header */}
            <button
              onClick={() => toggle(group.tier)}
              className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#1a1a1a] transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-gray-500 w-6">
                  T{group.tier}
                </span>
                <span className="font-medium text-sm">{group.label}</span>
                <span className="text-xs text-gray-500">
                  ({group.dimensions.length} dimension
                  {group.dimensions.length !== 1 ? "s" : ""})
                </span>
              </div>
              <div className="flex items-center gap-3">
                <ScoreBadge score={group.avgScore} size="sm" />
                <span className="text-gray-500 text-xs">
                  {isOpen ? "\u25B2" : "\u25BC"}
                </span>
              </div>
            </button>

            {/* Accordion body */}
            {isOpen && (
              <div className="border-t border-[var(--card-border)] px-4 py-3">
                {group.description && (
                  <p className="text-xs text-gray-500 mb-3">{group.description}</p>
                )}
                <div className="space-y-2">
                  {group.dimensions.map((dim) => (
                    <div
                      key={dim.dimension_id}
                      className="flex items-center gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs text-gray-300 truncate">
                            {dim.dimension_id.replace(/_/g, " ")}
                          </span>
                          <span className="text-xs tabular-nums text-gray-400 ml-2">
                            {(dim.score * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full h-1.5 bg-[#222] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${scoreBarColor(dim.score)}`}
                            style={{ width: `${dim.score * 100}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-600 w-14 text-right">
                        {dim.num_cases} case{dim.num_cases !== 1 ? "s" : ""}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
