"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const TIER_LABELS: Record<number, string> = {
  1: "Memory Fidelity",
  2: "Context Intelligence",
  3: "Learning Dynamics",
  4: "Reasoning Quality",
  5: "Meta-Cognition",
  6: "Collaborative Context",
  7: "Security & Adversarial",
};

const TIER_COLORS: Record<number, string> = {
  1: "#6366f1",
  2: "#8b5cf6",
  3: "#a78bfa",
  4: "#3b82f6",
  5: "#06b6d4",
  6: "#14b8a6",
  7: "#f97316",
};

interface DimensionEntry {
  dimension_id: string;
  score: number;
  tier: number;
  num_cases: number;
}

interface ScoreChartProps {
  /** Supports both legacy Record<string,number> and new DimensionEntry[] formats. */
  scores: Record<string, number> | DimensionEntry[];
}

interface ChartRow {
  dimension: string;
  score: number;
  tier: number;
  tierLabel: string;
  numCases: number;
}

function normalizeData(scores: Record<string, number> | DimensionEntry[]): ChartRow[] {
  if (Array.isArray(scores)) {
    return scores
      .map((d) => ({
        dimension: d.dimension_id.replace(/_/g, " "),
        score: Math.round(d.score * 100) / 100,
        tier: d.tier,
        tierLabel: TIER_LABELS[d.tier] || `Tier ${d.tier}`,
        numCases: d.num_cases,
      }))
      .sort((a, b) => a.tier - b.tier || b.score - a.score);
  }

  // Legacy format: flat Record<string, number>
  return Object.entries(scores)
    .map(([dimension, score]) => ({
      dimension: dimension.replace(/_/g, " "),
      score: Math.round(score * 100) / 100,
      tier: 0,
      tierLabel: "",
      numCases: 0,
    }))
    .sort((a, b) => b.score - a.score);
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: { payload: ChartRow }[];
}

function ChartTooltip({ active, payload }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-[#1a1a1a] border border-[#333] rounded-md px-3 py-2 text-sm">
      <div className="font-medium text-white capitalize">{d.dimension}</div>
      {d.tierLabel && (
        <div className="text-xs text-gray-400 mt-0.5">{d.tierLabel}</div>
      )}
      <div className="mt-1 tabular-nums text-[var(--accent-light)]">
        {(d.score * 100).toFixed(1)}%
      </div>
      {d.numCases > 0 && (
        <div className="text-[10px] text-gray-500 mt-0.5">
          {d.numCases} test case{d.numCases !== 1 ? "s" : ""}
        </div>
      )}
    </div>
  );
}

export default function ScoreChart({ scores }: ScoreChartProps) {
  const data = normalizeData(scores);

  if (data.length === 0) {
    return (
      <p className="text-sm text-gray-500">No dimension scores available.</p>
    );
  }

  const hasTiers = data.some((d) => d.tier > 0);

  return (
    <ResponsiveContainer width="100%" height={Math.max(200, data.length * 36)}>
      <BarChart data={data} layout="vertical" margin={{ left: 140 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#333" />
        <XAxis
          type="number"
          domain={[0, 1]}
          tick={{ fill: "#999", fontSize: 12 }}
        />
        <YAxis
          type="category"
          dataKey="dimension"
          tick={{ fill: "#ccc", fontSize: 11 }}
          width={130}
        />
        <Tooltip content={<ChartTooltip />} />
        <Bar dataKey="score" radius={[0, 4, 4, 0]}>
          {data.map((entry, idx) => (
            <Cell
              key={idx}
              fill={
                hasTiers
                  ? TIER_COLORS[entry.tier] || "#6366f1"
                  : "#6366f1"
              }
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
