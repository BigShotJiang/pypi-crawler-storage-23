"use client";

import { useEffect, useRef, useState, useCallback } from "react";

interface GraphNode {
  id: string;
  label: string;
  tier: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
}

interface GraphEdge {
  source: string;
  target: string;
  relation: string;
}

interface KnowledgeGraphVizProps {
  entries: {
    key: string;
    memory_tier: string;
    metadata: Record<string, unknown>;
  }[];
}

const TIER_NODE_COLOR: Record<string, string> = {
  working: "#3b82f6",
  session: "#8b5cf6",
  permanent: "#22c55e",
  episodic: "#eab308",
  semantic: "#06b6d4",
  procedural: "#f97316",
  strategic: "#ef4444",
};

function buildGraph(
  entries: KnowledgeGraphVizProps["entries"]
): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const nodeSet = new Set<string>();

  for (const entry of entries) {
    if (!nodeSet.has(entry.key)) {
      nodeSet.add(entry.key);
      nodes.push({
        id: entry.key,
        label: entry.key.length > 20 ? entry.key.slice(0, 18) + "\u2026" : entry.key,
        tier: entry.memory_tier,
        x: Math.random() * 600 + 50,
        y: Math.random() * 350 + 50,
        vx: 0,
        vy: 0,
      });
    }

    // Extract links from metadata
    const links = entry.metadata?.links;
    if (Array.isArray(links)) {
      for (const link of links) {
        if (typeof link === "object" && link !== null) {
          const target = (link as Record<string, string>).target || (link as Record<string, string>).key;
          const relation = (link as Record<string, string>).relation || "related";
          if (target && target !== entry.key) {
            edges.push({ source: entry.key, target, relation });
            if (!nodeSet.has(target)) {
              nodeSet.add(target);
              nodes.push({
                id: target,
                label: target.length > 20 ? target.slice(0, 18) + "\u2026" : target,
                tier: "unknown",
                x: Math.random() * 600 + 50,
                y: Math.random() * 350 + 50,
                vx: 0,
                vy: 0,
              });
            }
          }
        }
      }
    }
  }

  // If no edges exist, create proximity edges by tier for visualization
  if (edges.length === 0 && nodes.length > 1) {
    const tierGroups = new Map<string, string[]>();
    for (const node of nodes) {
      const group = tierGroups.get(node.tier) || [];
      group.push(node.id);
      tierGroups.set(node.tier, group);
    }
    for (const [, group] of tierGroups) {
      for (let i = 0; i < group.length - 1 && i < 3; i++) {
        edges.push({
          source: group[i],
          target: group[i + 1],
          relation: "same_tier",
        });
      }
    }
  }

  return { nodes, edges };
}

export default function KnowledgeGraphViz({ entries }: KnowledgeGraphVizProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [graphData, setGraphData] = useState<{
    nodes: GraphNode[];
    edges: GraphEdge[];
  }>({ nodes: [], edges: [] });
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    const { nodes, edges } = buildGraph(entries);
    setGraphData({ nodes, edges });
  }, [entries]);

  // Simple force-directed simulation
  const simulate = useCallback(() => {
    setGraphData((prev) => {
      const nodes = prev.nodes.map((n) => ({ ...n }));
      const edges = prev.edges;
      const nodeMap = new Map(nodes.map((n) => [n.id, n]));

      // Repulsion between nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i];
          const b = nodes[j];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = 800 / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          a.vx -= fx;
          a.vy -= fy;
          b.vx += fx;
          b.vy += fy;
        }
      }

      // Attraction along edges
      for (const edge of edges) {
        const a = nodeMap.get(edge.source);
        const b = nodeMap.get(edge.target);
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (dist - 120) * 0.005;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        a.vx += fx;
        a.vy += fy;
        b.vx -= fx;
        b.vy -= fy;
      }

      // Center gravity
      for (const node of nodes) {
        node.vx += (350 - node.x) * 0.001;
        node.vy += (225 - node.y) * 0.001;
      }

      // Apply velocities with damping
      for (const node of nodes) {
        node.vx *= 0.85;
        node.vy *= 0.85;
        node.x += node.vx;
        node.y += node.vy;
        // Clamp to bounds
        node.x = Math.max(30, Math.min(670, node.x));
        node.y = Math.max(30, Math.min(420, node.y));
      }

      return { nodes, edges };
    });
  }, []);

  useEffect(() => {
    let ticks = 0;
    const maxTicks = 150;

    function tick() {
      if (ticks >= maxTicks) return;
      simulate();
      ticks++;
      animFrameRef.current = requestAnimationFrame(tick);
    }

    animFrameRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [simulate, entries]);

  function handleMouseDown(nodeId: string) {
    setDragging(nodeId);
  }

  function handleMouseMove(e: React.MouseEvent) {
    if (!dragging || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setGraphData((prev) => ({
      ...prev,
      nodes: prev.nodes.map((n) =>
        n.id === dragging ? { ...n, x, y, vx: 0, vy: 0 } : n
      ),
    }));
  }

  function handleMouseUp() {
    setDragging(null);
  }

  if (entries.length === 0) {
    return (
      <div className="text-sm text-gray-500 text-center py-8">
        No entries to visualize. Store memory entries to see the knowledge graph.
      </div>
    );
  }

  const nodeMap = new Map(graphData.nodes.map((n) => [n.id, n]));

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 700 450"
      className="w-full h-auto bg-[#0a0a0a] rounded-lg border border-[var(--card-border)]"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Edges */}
      {graphData.edges.map((edge, i) => {
        const source = nodeMap.get(edge.source);
        const target = nodeMap.get(edge.target);
        if (!source || !target) return null;
        const isHighlighted =
          hoveredNode === edge.source || hoveredNode === edge.target;
        return (
          <g key={`edge-${i}`}>
            <line
              x1={source.x}
              y1={source.y}
              x2={target.x}
              y2={target.y}
              stroke={isHighlighted ? "#6366f1" : "#333"}
              strokeWidth={isHighlighted ? 2 : 1}
              opacity={isHighlighted ? 0.8 : 0.4}
            />
            {isHighlighted && (
              <text
                x={(source.x + target.x) / 2}
                y={(source.y + target.y) / 2 - 5}
                textAnchor="middle"
                fill="#999"
                fontSize={9}
              >
                {edge.relation}
              </text>
            )}
          </g>
        );
      })}

      {/* Nodes */}
      {graphData.nodes.map((node) => {
        const color = TIER_NODE_COLOR[node.tier] || "#666";
        const isHovered = hoveredNode === node.id;
        return (
          <g
            key={node.id}
            onMouseEnter={() => setHoveredNode(node.id)}
            onMouseLeave={() => setHoveredNode(null)}
            onMouseDown={() => handleMouseDown(node.id)}
            style={{ cursor: "grab" }}
          >
            <circle
              cx={node.x}
              cy={node.y}
              r={isHovered ? 10 : 7}
              fill={color}
              opacity={isHovered ? 1 : 0.7}
              stroke={isHovered ? "#fff" : "none"}
              strokeWidth={isHovered ? 2 : 0}
            />
            <text
              x={node.x}
              y={node.y + 18}
              textAnchor="middle"
              fill={isHovered ? "#fff" : "#999"}
              fontSize={isHovered ? 11 : 9}
            >
              {node.label}
            </text>
          </g>
        );
      })}

      {/* Legend */}
      <g transform="translate(10, 10)">
        {Object.entries(TIER_NODE_COLOR)
          .slice(0, 5)
          .map(([tier, color], i) => (
            <g key={tier} transform={`translate(0, ${i * 16})`}>
              <circle cx={5} cy={5} r={4} fill={color} opacity={0.7} />
              <text x={14} y={9} fill="#999" fontSize={9}>
                {tier}
              </text>
            </g>
          ))}
      </g>
    </svg>
  );
}
