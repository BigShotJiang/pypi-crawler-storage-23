interface ScoreBadgeProps {
  score: number;
  size?: "sm" | "md" | "lg";
}

export default function ScoreBadge({ score, size = "md" }: ScoreBadgeProps) {
  const color =
    score >= 0.8
      ? "text-green-400"
      : score >= 0.5
        ? "text-yellow-400"
        : "text-red-400";

  const sizes = {
    sm: "text-sm",
    md: "text-lg font-semibold",
    lg: "text-3xl font-bold",
  };

  return (
    <span className={`${color} ${sizes[size]} tabular-nums`}>
      {(score * 100).toFixed(1)}%
    </span>
  );
}
