"use client";

import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface MetricsSeriesPoint {
  stage_index: number;
  reward: number;
  loss: number;
  kl_divergence: number;
  entropy: number;
}

interface MetricsChartProps {
  series: MetricsSeriesPoint[];
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: { name: string; value: number; color: string }[];
  label?: number;
}

function ChartTooltip({ active, payload, label }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-[#1a1a1a] border border-[#333] rounded-md px-3 py-2 text-sm">
      <div className="text-xs text-gray-400 mb-1">Stage {label}</div>
      {payload.map((item) => (
        <div key={item.name} className="flex items-center gap-2 text-xs">
          <span
            className="w-2 h-2 rounded-full inline-block"
            style={{ backgroundColor: item.color }}
          />
          <span className="text-gray-300">{item.name}:</span>
          <span className="tabular-nums text-white">
            {item.value.toFixed(4)}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function MetricsChart({ series }: MetricsChartProps) {
  if (series.length === 0) {
    return (
      <div className="text-sm text-gray-500 text-center py-8">
        No metrics data available yet. Run the training job to generate metrics.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Reward + Loss chart */}
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-3">
          Reward &amp; Loss
        </h3>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={series}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis
              dataKey="stage_index"
              tick={{ fill: "#999", fontSize: 11 }}
              label={{
                value: "Stage",
                position: "insideBottomRight",
                offset: -5,
                fill: "#666",
                fontSize: 11,
              }}
            />
            <YAxis tick={{ fill: "#999", fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: 11, color: "#999" }}
            />
            <Line
              type="monotone"
              dataKey="reward"
              stroke="#22c55e"
              strokeWidth={2}
              dot={{ r: 3, fill: "#22c55e" }}
              name="Reward"
            />
            <Line
              type="monotone"
              dataKey="loss"
              stroke="#ef4444"
              strokeWidth={2}
              dot={{ r: 3, fill: "#ef4444" }}
              name="Loss"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* KL Divergence + Entropy chart */}
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-3">
          KL Divergence &amp; Entropy
        </h3>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={series}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis
              dataKey="stage_index"
              tick={{ fill: "#999", fontSize: 11 }}
              label={{
                value: "Stage",
                position: "insideBottomRight",
                offset: -5,
                fill: "#666",
                fontSize: 11,
              }}
            />
            <YAxis tick={{ fill: "#999", fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: 11, color: "#999" }}
            />
            <Line
              type="monotone"
              dataKey="kl_divergence"
              stroke="#eab308"
              strokeWidth={2}
              dot={{ r: 3, fill: "#eab308" }}
              name="KL Divergence"
            />
            <Line
              type="monotone"
              dataKey="entropy"
              stroke="#6366f1"
              strokeWidth={2}
              dot={{ r: 3, fill: "#6366f1" }}
              name="Entropy"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
