"use client";

interface ObservatoryCheck {
  healthy: boolean;
  score: number;
  details: Record<string, unknown>;
  recommendations: string[];
}

interface ObservatoryPanelProps {
  overallHealthy: boolean;
  compositeScore: number;
  checks: Record<string, ObservatoryCheck>;
}

function statusIcon(healthy: boolean): string {
  return healthy ? "\u2713" : "\u2717";
}

function statusColor(healthy: boolean): string {
  return healthy ? "text-green-400" : "text-red-400";
}

function scoreBg(score: number): string {
  if (score >= 0.8) return "bg-green-500/20 text-green-400";
  if (score >= 0.6) return "bg-yellow-500/20 text-yellow-400";
  return "bg-red-500/20 text-red-400";
}

const CHECK_LABELS: Record<string, string> = {
  reward_hacking: "Reward Hacking",
  gradient_health: "Gradient Health",
  memory_health: "Memory Health",
  drift: "Distribution Drift",
};

export default function ObservatoryPanel({
  overallHealthy,
  compositeScore,
  checks,
}: ObservatoryPanelProps) {
  const checkEntries = Object.entries(checks);

  return (
    <div className="space-y-4">
      {/* Overall health banner */}
      <div
        className={`rounded-lg px-4 py-3 flex items-center justify-between ${
          overallHealthy
            ? "bg-green-500/10 border border-green-500/20"
            : "bg-red-500/10 border border-red-500/20"
        }`}
      >
        <div className="flex items-center gap-3">
          <span className={`text-lg font-bold ${statusColor(overallHealthy)}`}>
            {statusIcon(overallHealthy)}
          </span>
          <span className="text-sm font-medium">
            {overallHealthy
              ? "All Observatory checks passing"
              : "Observatory detected issues"}
          </span>
        </div>
        <div className={`text-sm font-mono px-2 py-1 rounded ${scoreBg(compositeScore)}`}>
          {(compositeScore * 100).toFixed(1)}%
        </div>
      </div>

      {/* Individual checks */}
      {checkEntries.length === 0 ? (
        <p className="text-sm text-gray-500">No check data available.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {checkEntries.map(([name, check]) => (
            <div
              key={name}
              className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold ${statusColor(check.healthy)}`}>
                    {statusIcon(check.healthy)}
                  </span>
                  <span className="text-sm font-medium">
                    {CHECK_LABELS[name] || name.replace(/_/g, " ")}
                  </span>
                </div>
                <span
                  className={`text-xs font-mono px-1.5 py-0.5 rounded ${scoreBg(
                    check.score
                  )}`}
                >
                  {(check.score * 100).toFixed(0)}%
                </span>
              </div>

              {/* Details */}
              {Object.keys(check.details).length > 0 && (
                <div className="mb-2">
                  {Object.entries(check.details).map(([key, value]) => (
                    <div
                      key={key}
                      className="flex justify-between text-xs text-gray-400"
                    >
                      <span>{key.replace(/_/g, " ")}</span>
                      <span className="tabular-nums text-gray-300">
                        {typeof value === "number"
                          ? value.toFixed(4)
                          : String(value)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Recommendations */}
              {check.recommendations.length > 0 && (
                <div className="mt-2 border-t border-[var(--card-border)] pt-2">
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">
                    Recommendations
                  </div>
                  <ul className="space-y-0.5">
                    {check.recommendations.map((rec, i) => (
                      <li key={i} className="text-xs text-gray-400">
                        &bull; {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
