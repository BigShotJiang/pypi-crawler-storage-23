"use client";

import { useState, useMemo } from "react";

interface MemoryEntry {
  id: string;
  key: string;
  value: unknown;
  memory_tier: string;
  confidence: number;
  timestamp: string;
  metadata: Record<string, unknown>;
}

interface MemoryTableProps {
  entries: MemoryEntry[];
}

const tierBadgeColor: Record<string, string> = {
  working: "bg-blue-500/20 text-blue-300",
  session: "bg-purple-500/20 text-purple-300",
  permanent: "bg-green-500/20 text-green-300",
  episodic: "bg-yellow-500/20 text-yellow-300",
  semantic: "bg-cyan-500/20 text-cyan-300",
  procedural: "bg-orange-500/20 text-orange-300",
  strategic: "bg-red-500/20 text-red-300",
};

function truncateValue(value: unknown, maxLen = 80): string {
  const s = typeof value === "string" ? value : JSON.stringify(value);
  if (s.length <= maxLen) return s;
  return s.slice(0, maxLen) + "\u2026";
}

function confidenceColor(c: number): string {
  if (c >= 0.8) return "text-green-400";
  if (c >= 0.5) return "text-yellow-400";
  return "text-red-400";
}

export default function MemoryTable({ entries }: MemoryTableProps) {
  const [search, setSearch] = useState("");
  const [tierFilter, setTierFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"key" | "confidence" | "timestamp">(
    "timestamp"
  );
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  // Get unique tiers from the data
  const tiers = useMemo(() => {
    const set = new Set(entries.map((e) => e.memory_tier));
    return Array.from(set).sort();
  }, [entries]);

  // Filter and sort
  const filtered = useMemo(() => {
    let result = entries;

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (e) =>
          e.key.toLowerCase().includes(q) ||
          truncateValue(e.value).toLowerCase().includes(q)
      );
    }

    if (tierFilter !== "all") {
      result = result.filter((e) => e.memory_tier === tierFilter);
    }

    result = [...result].sort((a, b) => {
      let cmp = 0;
      if (sortBy === "key") {
        cmp = a.key.localeCompare(b.key);
      } else if (sortBy === "confidence") {
        cmp = a.confidence - b.confidence;
      } else {
        cmp =
          new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      }
      return sortDir === "asc" ? cmp : -cmp;
    });

    return result;
  }, [entries, search, tierFilter, sortBy, sortDir]);

  function handleSort(col: "key" | "confidence" | "timestamp") {
    if (sortBy === col) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortBy(col);
      setSortDir(col === "confidence" ? "desc" : "asc");
    }
  }

  function sortIndicator(col: string) {
    if (sortBy !== col) return "";
    return sortDir === "asc" ? " \u25B2" : " \u25BC";
  }

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        <input
          type="text"
          placeholder="Search keys or values..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)] flex-1 min-w-[200px]"
        />
        <select
          value={tierFilter}
          onChange={(e) => setTierFilter(e.target.value)}
          className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
        >
          <option value="all">All tiers</option>
          {tiers.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="text-sm text-gray-500 py-4 text-center">
          {entries.length === 0
            ? "No memory entries found."
            : "No entries match your search."}
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--card-border)] text-xs text-gray-500">
                <th
                  className="text-left py-2 pr-4 cursor-pointer hover:text-gray-300"
                  onClick={() => handleSort("key")}
                >
                  Key{sortIndicator("key")}
                </th>
                <th className="text-left py-2 pr-4">Value</th>
                <th className="text-left py-2 pr-4">Tier</th>
                <th
                  className="text-right py-2 pr-4 cursor-pointer hover:text-gray-300"
                  onClick={() => handleSort("confidence")}
                >
                  Confidence{sortIndicator("confidence")}
                </th>
                <th
                  className="text-right py-2 cursor-pointer hover:text-gray-300"
                  onClick={() => handleSort("timestamp")}
                >
                  Timestamp{sortIndicator("timestamp")}
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((entry) => (
                <tr
                  key={entry.id}
                  className="border-b border-[var(--card-border)] hover:bg-[#1a1a1a] transition-colors"
                >
                  <td className="py-2 pr-4">
                    <a
                      href={`/memory/${encodeURIComponent(entry.key)}`}
                      className="text-[var(--accent-light)] hover:underline font-mono text-xs"
                    >
                      {entry.key}
                    </a>
                  </td>
                  <td className="py-2 pr-4 text-xs text-gray-400 max-w-xs truncate">
                    {truncateValue(entry.value)}
                  </td>
                  <td className="py-2 pr-4">
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        tierBadgeColor[entry.memory_tier] ||
                        "bg-gray-500/20 text-gray-300"
                      }`}
                    >
                      {entry.memory_tier}
                    </span>
                  </td>
                  <td
                    className={`py-2 pr-4 text-right tabular-nums text-xs ${confidenceColor(
                      entry.confidence
                    )}`}
                  >
                    {(entry.confidence * 100).toFixed(1)}%
                  </td>
                  <td className="py-2 text-right text-xs text-gray-600">
                    {new Date(entry.timestamp).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-xs text-gray-600 mt-2">
            Showing {filtered.length} of {entries.length} entries
          </div>
        </div>
      )}
    </div>
  );
}
