"use client";

import { useState, useEffect, useCallback } from "react";
import { useParams } from "next/navigation";
import ScoreBadge from "@/components/ScoreBadge";
import ScoreChart from "@/components/ScoreChart";
import TierBreakdown from "@/components/TierBreakdown";
import DimensionHeatmap from "@/components/DimensionHeatmap";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface DimensionScore {
  dimension_id: string;
  score: number;
  num_cases: number;
  tier: number;
}

interface EvalRunDetail {
  run_id: string;
  agent_id: string;
  status: string;
  overall_score: number;
  dimension_scores: DimensionScore[] | Record<string, number>;
  diagnostic: Record<string, unknown>;
  created_at: string;
}

type ViewMode = "partner" | "engineer";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/* ------------------------------------------------------------------ */
/*  API                                                                */
/* ------------------------------------------------------------------ */

async function getEvalRun(runId: string): Promise<EvalRunDetail | null> {
  try {
    const res = await fetch(`${API_URL}/v1/evals/runs/${runId}`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${API_URL}/eval/runs/${runId}`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function normalizeDimensions(
  raw: DimensionScore[] | Record<string, number>
): DimensionScore[] {
  if (Array.isArray(raw)) return raw;
  return Object.entries(raw).map(([id, score]) => ({
    dimension_id: id,
    score,
    num_cases: 0,
    tier: 0,
  }));
}

function tierAverages(dims: DimensionScore[]): Record<number, number> {
  const groups = new Map<number, number[]>();
  for (const d of dims) {
    if (d.tier === 0) continue;
    const list = groups.get(d.tier) || [];
    list.push(d.score);
    groups.set(d.tier, list);
  }
  const result: Record<number, number> = {};
  for (const [tier, scores] of groups.entries()) {
    result[tier] = scores.reduce((a, b) => a + b, 0) / scores.length;
  }
  return result;
}

const TIER_LABELS: Record<number, string> = {
  1: "Memory",
  2: "Context",
  3: "Learning",
  4: "Reasoning",
  5: "Meta-Cog",
  6: "Collab",
  7: "Security",
};

/* ------------------------------------------------------------------ */
/*  Diagnostics generator                                              */
/* ------------------------------------------------------------------ */

interface DiagnosticMessage {
  severity: "critical" | "warning" | "info";
  message: string;
}

function generateDiagnostics(
  dimensions: DimensionScore[],
  tierAvgs: Record<number, number>,
  overallScore: number
): DiagnosticMessage[] {
  const messages: DiagnosticMessage[] = [];

  // Overall assessment
  if (overallScore < 0.4) {
    messages.push({
      severity: "critical",
      message: `Overall score is ${(overallScore * 100).toFixed(1)}%, indicating significant deficiencies across multiple evaluation tiers. Immediate attention is required.`,
    });
  } else if (overallScore < 0.65) {
    messages.push({
      severity: "warning",
      message: `Overall score of ${(overallScore * 100).toFixed(1)}% suggests room for improvement. Focus on the weakest tiers to maximize gains.`,
    });
  } else {
    messages.push({
      severity: "info",
      message: `Overall score of ${(overallScore * 100).toFixed(1)}% indicates solid performance. Fine-tune specific dimensions for further improvement.`,
    });
  }

  // Tier-level diagnostics
  if (tierAvgs[1] !== undefined && tierAvgs[1] < 0.5) {
    messages.push({
      severity: "critical",
      message: `Memory fidelity is weak at ${(tierAvgs[1] * 100).toFixed(1)}%. Your agent may treat outdated information as current, or lose track of previously stored facts. Consider reviewing memory retrieval and temporal consistency.`,
    });
  }

  if (tierAvgs[2] !== undefined && tierAvgs[2] < 0.5) {
    messages.push({
      severity: "warning",
      message: `Context intelligence scores ${(tierAvgs[2] * 100).toFixed(1)}%. The agent struggles to prioritize relevant context, potentially leading to responses that miss critical information from the conversation window.`,
    });
  }

  if (tierAvgs[3] !== undefined && tierAvgs[3] < 0.5) {
    messages.push({
      severity: "warning",
      message: `Learning dynamics at ${(tierAvgs[3] * 100).toFixed(1)}% indicates limited in-context learning capability. The agent may not adapt its behavior based on feedback within a session.`,
    });
  }

  if (tierAvgs[4] !== undefined && tierAvgs[4] < 0.5) {
    messages.push({
      severity: "critical",
      message: `Reasoning quality is at ${(tierAvgs[4] * 100).toFixed(1)}%. Multi-step reasoning and causal inference are below threshold, which can lead to incorrect conclusions in complex scenarios.`,
    });
  }

  if (tierAvgs[5] !== undefined && tierAvgs[5] < 0.5) {
    messages.push({
      severity: "warning",
      message: `Meta-cognition scores ${(tierAvgs[5] * 100).toFixed(1)}%. The agent shows poor self-monitoring and confidence calibration -- it may express high confidence in incorrect answers.`,
    });
  }

  if (tierAvgs[6] !== undefined && tierAvgs[6] < 0.5) {
    messages.push({
      severity: "warning",
      message: `Collaborative context at ${(tierAvgs[6] * 100).toFixed(1)}% suggests weak multi-agent coordination. Shared state management and delegation may be unreliable.`,
    });
  }

  if (tierAvgs[7] !== undefined && tierAvgs[7] < 0.5) {
    messages.push({
      severity: "critical",
      message: `Security score is ${(tierAvgs[7] * 100).toFixed(1)}%. The agent is vulnerable to adversarial prompts, jailbreaks, or data poisoning attacks. This should be addressed before production deployment.`,
    });
  }

  // Dimension-level diagnostics for worst performers
  const sorted = [...dimensions].sort((a, b) => a.score - b.score);
  const worstDims = sorted.filter((d) => d.score < 0.4).slice(0, 3);
  for (const dim of worstDims) {
    const dimName = dim.dimension_id.replace(/_/g, " ");
    messages.push({
      severity: "critical",
      message: `"${dimName}" scored only ${(dim.score * 100).toFixed(1)}% across ${dim.num_cases} test cases. This dimension requires targeted improvement.`,
    });
  }

  // Retrieval-specific diagnostics
  const retrievalDim = dimensions.find(
    (d) =>
      d.dimension_id.includes("retrieval") ||
      d.dimension_id.includes("recall")
  );
  if (retrievalDim && retrievalDim.score < 0.6) {
    messages.push({
      severity: "warning",
      message: `Memory retrieval precision is weak at ${(retrievalDim.score * 100).toFixed(1)}%. The agent may retrieve many documents but only a fraction are relevant to the query.`,
    });
  }

  return messages;
}

/* ------------------------------------------------------------------ */
/*  Severity badge                                                     */
/* ------------------------------------------------------------------ */

function SeverityBadge({ severity }: { severity: string }) {
  const styles: Record<string, string> = {
    critical: "bg-red-900/30 text-red-400 border-red-800",
    warning: "bg-yellow-900/30 text-yellow-400 border-yellow-800",
    info: "bg-blue-900/30 text-blue-400 border-blue-800",
  };
  return (
    <span
      className={`text-[10px] px-2 py-0.5 rounded-full border ${styles[severity] || styles.info}`}
    >
      {severity}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Main component                                                     */
/* ------------------------------------------------------------------ */

export default function EvalRunPage() {
  const params = useParams();
  const runId = params.runId as string;

  const [run, setRun] = useState<EvalRunDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>("partner");
  const [showRawJson, setShowRawJson] = useState(false);

  const loadRun = useCallback(async () => {
    setLoading(true);
    const data = await getEvalRun(runId);
    setRun(data);
    setLoading(false);
  }, [runId]);

  useEffect(() => {
    loadRun();
  }, [loadRun]);

  if (loading) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400">Loading eval run...</p>
      </div>
    );
  }

  if (!run) {
    return (
      <div className="text-center py-16">
        <h1 className="text-xl font-bold mb-2">Run not found</h1>
        <p className="text-gray-500">ID: {runId}</p>
        <a
          href="/"
          className="text-[var(--accent-light)] text-sm mt-4 inline-block"
        >
          Back to runs
        </a>
      </div>
    );
  }

  const dimensions = normalizeDimensions(run.dimension_scores);
  const hasTiers = dimensions.some((d) => d.tier > 0);
  const tierAvgs = hasTiers ? tierAverages(dimensions) : {};
  const dimCount = dimensions.length;
  const diagnosticMessages = generateDiagnostics(
    dimensions,
    tierAvgs,
    run.overall_score
  );

  function handlePdfExport() {
    window.print();
  }

  return (
    <div className="print:bg-white print:text-black">
      <a
        href="/"
        className="text-sm text-gray-500 hover:text-gray-300 mb-4 inline-block print:hidden"
      >
        &larr; All runs
      </a>

      {/* ============================================================ */}
      {/*  ROLE-BASED VIEW TOGGLE                                       */}
      {/* ============================================================ */}
      <div className="flex items-center gap-2 mb-4 print:hidden">
        <span className="text-xs text-gray-500">View:</span>
        <button
          onClick={() => setViewMode("partner")}
          className={`text-xs px-3 py-1 rounded-md border transition-colors ${
            viewMode === "partner"
              ? "bg-[var(--accent)] text-white border-[var(--accent)]"
              : "border-[var(--card-border)] hover:bg-[var(--card)] text-gray-400"
          }`}
        >
          Partner View
        </button>
        <button
          onClick={() => setViewMode("engineer")}
          className={`text-xs px-3 py-1 rounded-md border transition-colors ${
            viewMode === "engineer"
              ? "bg-[var(--accent)] text-white border-[var(--accent)]"
              : "border-[var(--card-border)] hover:bg-[var(--card)] text-gray-400"
          }`}
        >
          Engineer View
        </button>
      </div>

      {/* ============================================================ */}
      {/*  HEADER                                                       */}
      {/* ============================================================ */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold print:text-black">
            {run.agent_id || "Eval Run"}
          </h1>
          <p className="text-sm text-gray-500 font-mono mt-1 print:text-gray-600">
            {run.run_id}
          </p>
          <p className="text-xs text-gray-600 mt-1">
            {new Date(run.created_at).toLocaleString()} &middot; {dimCount}{" "}
            dimensions
            {run.status && (
              <>
                {" "}&middot;{" "}
                <span
                  className={
                    run.status === "completed"
                      ? "text-green-400 print:text-green-700"
                      : "text-yellow-400 print:text-yellow-700"
                  }
                >
                  {run.status}
                </span>
              </>
            )}
          </p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500 mb-1">Overall Score</div>
          <ScoreBadge score={run.overall_score} size="lg" />
          {/* PDF Export */}
          <div className="mt-3 print:hidden">
            <button
              onClick={handlePdfExport}
              className="bg-[var(--accent)] hover:bg-[var(--accent-light)] text-white text-xs px-4 py-1.5 rounded-md transition-colors"
            >
              Download PDF Report
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/*  TIER SUMMARY CARDS                                           */}
      {/* ============================================================ */}
      {hasTiers && Object.keys(tierAvgs).length > 0 && (
        <div className="grid grid-cols-7 gap-2 mb-6">
          {[1, 2, 3, 4, 5, 6, 7].map((t) => (
            <div
              key={t}
              className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-3 text-center print:border-gray-300"
            >
              <div className="text-[10px] text-gray-500 mb-1">
                {TIER_LABELS[t] || `T${t}`}
              </div>
              {tierAvgs[t] !== undefined ? (
                <ScoreBadge score={tierAvgs[t]} size="sm" />
              ) : (
                <span className="text-xs text-gray-600">--</span>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ============================================================ */}
      {/*  PLAIN-ENGLISH DIAGNOSTICS                                    */}
      {/* ============================================================ */}
      {diagnosticMessages.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:border-gray-300">
          <h2 className="text-lg font-semibold mb-4 print:text-black">
            {viewMode === "partner" ? "Executive Summary" : "Diagnostics"}
          </h2>
          <div className="space-y-3">
            {diagnosticMessages.map((diag, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 text-sm"
              >
                <div className="mt-0.5 shrink-0">
                  <SeverityBadge severity={diag.severity} />
                </div>
                <p className="text-gray-300 print:text-gray-700 leading-relaxed">
                  {diag.message}
                </p>
              </div>
            ))}
          </div>
          {viewMode === "partner" && (
            <div className="mt-4 pt-4 border-t border-[var(--card-border)]">
              <h3 className="text-sm font-semibold text-gray-300 mb-2">
                Business Impact
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                {run.overall_score >= 0.8
                  ? "This agent demonstrates production-grade reliability. Risk of client-facing errors is minimal."
                  : run.overall_score >= 0.6
                    ? "Moderate risk of errors in edge cases. Suitable for internal use with human oversight. Not recommended for unsupervised client-facing deployment."
                    : "High risk of errors that could impact client outcomes. Recommend additional training iterations before any deployment."}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/*  HEATMAP (both views)                                         */}
      {/* ============================================================ */}
      {hasTiers && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:border-gray-300 print:hidden">
          <h2 className="text-lg font-semibold mb-4">Dimension Heatmap</h2>
          <DimensionHeatmap dimensions={dimensions} />
        </div>
      )}

      {/* ============================================================ */}
      {/*  TIER BREAKDOWN (both views, expanded in engineer)            */}
      {/* ============================================================ */}
      {hasTiers && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-4 print:text-black">
            Tier Breakdown
          </h2>
          <TierBreakdown dimensions={dimensions} />
        </div>
      )}

      {/* ============================================================ */}
      {/*  DIMENSION SCORES BAR CHART                                   */}
      {/* ============================================================ */}
      {viewMode === "engineer" && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:hidden">
          <h2 className="text-lg font-semibold mb-4">Dimension Scores</h2>
          <ScoreChart scores={hasTiers ? dimensions : run.dimension_scores} />
        </div>
      )}

      {/* ============================================================ */}
      {/*  DIAGNOSTIC RAW DATA (engineer only)                          */}
      {/* ============================================================ */}
      {viewMode === "engineer" &&
        run.diagnostic &&
        Object.keys(run.diagnostic).length > 0 && (
          <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:hidden">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Diagnostics Data</h2>
              <button
                onClick={() => setShowRawJson(!showRawJson)}
                className="text-xs text-[var(--accent-light)] hover:text-white transition-colors"
              >
                {showRawJson ? "Hide Raw JSON" : "Show Raw JSON"}
              </button>
            </div>
            {showRawJson && (
              <pre className="text-xs text-gray-400 overflow-x-auto whitespace-pre-wrap bg-[#0a0a0a] rounded-md p-4 border border-[var(--card-border)]">
                {JSON.stringify(run.diagnostic, null, 2)}
              </pre>
            )}
          </div>
        )}

      {/* ============================================================ */}
      {/*  ENGINEER: FULL DIMENSION TABLE                               */}
      {/* ============================================================ */}
      {viewMode === "engineer" && dimensions.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:hidden">
          <h2 className="text-lg font-semibold mb-4">
            All Dimensions ({dimensions.length})
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-gray-400">
                <tr>
                  <th className="px-3 py-2">Dimension</th>
                  <th className="px-3 py-2">Tier</th>
                  <th className="px-3 py-2">Score</th>
                  <th className="px-3 py-2">Cases</th>
                </tr>
              </thead>
              <tbody>
                {[...dimensions]
                  .sort((a, b) => a.score - b.score)
                  .map((dim) => (
                    <tr
                      key={dim.dimension_id}
                      className="border-t border-[var(--card-border)]"
                    >
                      <td className="px-3 py-2 font-mono text-xs">
                        {dim.dimension_id}
                      </td>
                      <td className="px-3 py-2 text-gray-500">
                        {TIER_LABELS[dim.tier] || `T${dim.tier}`}
                      </td>
                      <td className="px-3 py-2">
                        <span
                          className={`tabular-nums font-semibold ${
                            dim.score >= 0.8
                              ? "text-green-400"
                              : dim.score >= 0.5
                                ? "text-yellow-400"
                                : "text-red-400"
                          }`}
                        >
                          {(dim.score * 100).toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-3 py-2 text-gray-500">
                        {dim.num_cases}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/*  PARTNER: RECOMMENDATIONS                                     */}
      {/* ============================================================ */}
      {viewMode === "partner" && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6 print:border-gray-300">
          <h2 className="text-lg font-semibold mb-4 print:text-black">
            Recommendations
          </h2>
          <div className="space-y-3">
            {run.overall_score < 0.8 && (
              <div className="flex items-start gap-3 text-sm">
                <span className="text-[var(--accent-light)] mt-0.5 shrink-0">1.</span>
                <p className="text-gray-300 print:text-gray-700">
                  Schedule a targeted training iteration focusing on the weakest
                  tiers. Use the Aegis Train pipeline with domain-specific
                  curriculum to improve scores.
                </p>
              </div>
            )}
            {tierAvgs[7] !== undefined && tierAvgs[7] < 0.7 && (
              <div className="flex items-start gap-3 text-sm">
                <span className="text-[var(--accent-light)] mt-0.5 shrink-0">2.</span>
                <p className="text-gray-300 print:text-gray-700">
                  Run adversarial red-teaming before deployment. Security scores
                  are below the recommended threshold for production use.
                </p>
              </div>
            )}
            <div className="flex items-start gap-3 text-sm">
              <span className="text-[var(--accent-light)] mt-0.5 shrink-0">
                {run.overall_score < 0.8 && tierAvgs[7] !== undefined && tierAvgs[7] < 0.7 ? "3" : run.overall_score < 0.8 ? "2" : "1"}.
              </span>
              <p className="text-gray-300 print:text-gray-700">
                Re-evaluate after improvements using the same rubric for
                consistent comparison. Consider establishing a bi-weekly eval
                cadence.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Print-only footer */}
      <div className="hidden print:block mt-8 pt-4 border-t border-gray-300 text-xs text-gray-500">
        <p>
          Aegis Eval Report | Run: {run.run_id} | Agent: {run.agent_id} |
          Generated: {new Date().toLocaleString()}
        </p>
      </div>
    </div>
  );
}
