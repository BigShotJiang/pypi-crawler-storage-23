import ScoreBadge from "@/components/ScoreBadge";

interface EvalRun {
  run_id: string;
  agent_id: string;
  overall_score: number;
  num_dimensions: number;
  created_at: string;
}

async function getEvalRuns(): Promise<EvalRun[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/eval/runs?limit=50`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    return res.json();
  } catch {
    return [];
  }
}

export default async function EvalDashboard() {
  const runs = await getEvalRuns();

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Eval Runs</h1>

      {runs.length === 0 ? (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-8 text-center">
          <p className="text-gray-400 mb-2">No eval runs yet.</p>
          <p className="text-sm text-gray-600">
            Run <code className="text-[var(--accent-light)]">aegis eval run</code>{" "}
            to create your first evaluation.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {runs.map((run) => (
            <a
              key={run.run_id}
              href={`/eval/${run.run_id}`}
              className="block bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4 hover:border-[var(--accent)] transition-colors"
            >
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-mono text-sm text-gray-400">
                    {run.run_id.slice(0, 8)}
                  </span>
                  <span className="ml-3 text-sm">{run.agent_id}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-gray-500">
                    {run.num_dimensions} dimensions
                  </span>
                  <ScoreBadge score={run.overall_score} />
                </div>
              </div>
              <div className="mt-1 text-xs text-gray-600">
                {new Date(run.created_at).toLocaleString()}
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
