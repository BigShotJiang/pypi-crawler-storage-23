"use client";

import { useState, useEffect, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type CriterionType =
  | "MUST_INCLUDE"
  | "MUST_NOT_INCLUDE"
  | "QUALITY_RANGE"
  | "CONTAINS_KEYWORD"
  | "FORMAT_CHECK"
  | "SEMANTIC_SIMILARITY"
  | "WORD_COUNT_RANGE"
  | "CUSTOM";

const CRITERION_TYPE_LABELS: Record<CriterionType, string> = {
  MUST_INCLUDE: "Must Include",
  MUST_NOT_INCLUDE: "Must Not Include",
  QUALITY_RANGE: "Quality Range",
  CONTAINS_KEYWORD: "Contains Keyword",
  FORMAT_CHECK: "Format Check",
  SEMANTIC_SIMILARITY: "Semantic Similarity",
  WORD_COUNT_RANGE: "Word Count Range",
  CUSTOM: "Custom",
};

interface Criterion {
  id: string;
  type: CriterionType;
  description: string;
  expected_value: string;
  weight: number;
}

interface Rubric {
  rubric_id: string;
  name: string;
  domain: string;
  criteria: Criterion[];
  created_at: string;
  updated_at: string;
}

interface CalibrationEvent {
  sample_id: string;
  judgment: string;
  timestamp: string;
}

interface ConnectedRun {
  run_id: string;
  agent_id: string;
  overall_score: number;
  created_at: string;
}

/* ------------------------------------------------------------------ */
/*  API helpers                                                        */
/* ------------------------------------------------------------------ */

async function fetchRubric(rubricId: string): Promise<Rubric | null> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics/${rubricId}`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return null;
}

async function updateRubric(
  rubricId: string,
  payload: { name?: string; domain?: string; criteria?: Criterion[] }
): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics/${rubricId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function deleteRubric(rubricId: string): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics/${rubricId}`, {
      method: "DELETE",
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function duplicateRubric(rubricId: string): Promise<Rubric | null> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics/${rubricId}/duplicate`, {
      method: "POST",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return null;
}

async function fetchCalibrationHistory(
  rubricId: string
): Promise<CalibrationEvent[]> {
  try {
    const res = await fetch(
      `${API_URL}/v1/rubrics/${rubricId}/calibration/history`,
      { cache: "no-store" }
    );
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return [];
}

async function fetchConnectedRuns(
  rubricId: string
): Promise<ConnectedRun[]> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics/${rubricId}/runs`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return [];
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function RubricDetailPage() {
  const params = useParams();
  const router = useRouter();
  const rubricId = params.rubricId as string;

  const [rubric, setRubric] = useState<Rubric | null>(null);
  const [loading, setLoading] = useState(true);
  const [calibrationHistory, setCalibrationHistory] = useState<
    CalibrationEvent[]
  >([]);
  const [connectedRuns, setConnectedRuns] = useState<ConnectedRun[]>([]);

  /* Inline editing state */
  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [editDraft, setEditDraft] = useState<Criterion | null>(null);
  const [saving, setSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    const [r, cal, runs] = await Promise.all([
      fetchRubric(rubricId),
      fetchCalibrationHistory(rubricId),
      fetchConnectedRuns(rubricId),
    ]);
    setRubric(r);
    setCalibrationHistory(cal);
    setConnectedRuns(runs);
    setLoading(false);
  }, [rubricId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  /* ---- Edit helpers ---- */
  function startEdit(idx: number) {
    if (!rubric) return;
    setEditingIdx(idx);
    setEditDraft({ ...rubric.criteria[idx] });
  }

  async function saveEdit() {
    if (!rubric || editingIdx === null || !editDraft) return;
    setSaving(true);
    const updatedCriteria = [...rubric.criteria];
    updatedCriteria[editingIdx] = editDraft;
    const ok = await updateRubric(rubricId, { criteria: updatedCriteria });
    if (ok) {
      setRubric({ ...rubric, criteria: updatedCriteria });
    }
    setEditingIdx(null);
    setEditDraft(null);
    setSaving(false);
  }

  function cancelEdit() {
    setEditingIdx(null);
    setEditDraft(null);
  }

  /* ---- Delete ---- */
  async function handleDelete() {
    const ok = await deleteRubric(rubricId);
    if (ok) {
      router.push("/rubrics");
    }
  }

  /* ---- Duplicate ---- */
  async function handleDuplicate() {
    const dup = await duplicateRubric(rubricId);
    if (dup) {
      router.push(`/rubrics/${dup.rubric_id}`);
    }
  }

  /* ---- Loading / Not found ---- */
  if (loading) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400">Loading rubric...</p>
      </div>
    );
  }

  if (!rubric) {
    return (
      <div className="text-center py-16">
        <h1 className="text-xl font-bold mb-2">Rubric not found</h1>
        <p className="text-gray-500 font-mono text-sm">{rubricId}</p>
        <a
          href="/rubrics"
          className="text-[var(--accent-light)] text-sm mt-4 inline-block"
        >
          Back to rubrics
        </a>
      </div>
    );
  }

  /* ---- Render ---- */
  return (
    <div>
      <a
        href="/rubrics"
        className="text-sm text-gray-500 hover:text-gray-300 mb-4 inline-block"
      >
        &larr; All rubrics
      </a>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">{rubric.name}</h1>
          <p className="text-sm text-gray-500 font-mono mt-1">
            {rubric.rubric_id}
          </p>
          <p className="text-xs text-gray-600 mt-1">
            <span className="inline-block bg-[#1a1a2e] text-[var(--accent-light)] text-xs px-2 py-0.5 rounded-full mr-2">
              {rubric.domain}
            </span>
            {rubric.criteria.length} criteria &middot; Created{" "}
            {new Date(rubric.created_at).toLocaleDateString()} &middot; Updated{" "}
            {new Date(rubric.updated_at).toLocaleDateString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleDuplicate}
            className="text-sm text-gray-400 hover:text-white border border-[var(--card-border)] px-3 py-1.5 rounded-md transition-colors"
          >
            Duplicate
          </button>
          <button
            onClick={() => setShowDeleteConfirm(true)}
            className="text-sm text-red-400 hover:text-red-300 border border-red-800 px-3 py-1.5 rounded-md transition-colors"
          >
            Delete
          </button>
        </div>
      </div>

      {/* Delete confirmation */}
      {showDeleteConfirm && (
        <div className="bg-red-950/30 border border-red-800 rounded-lg p-4 mb-6">
          <p className="text-sm text-red-300 mb-3">
            Are you sure you want to delete this rubric? This action cannot be
            undone.
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-500 text-white text-sm px-4 py-1.5 rounded-md transition-colors"
            >
              Yes, Delete
            </button>
            <button
              onClick={() => setShowDeleteConfirm(false)}
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/*  CRITERIA                                                     */}
      {/* ============================================================ */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Criteria</h2>
        {rubric.criteria.length === 0 ? (
          <p className="text-sm text-gray-500">
            No criteria defined in this rubric.
          </p>
        ) : (
          <div className="space-y-3">
            {rubric.criteria.map((criterion, idx) => (
              <div
                key={criterion.id || idx}
                className="bg-[#0d0d0d] border border-[var(--card-border)] rounded-lg p-4"
              >
                {editingIdx === idx && editDraft ? (
                  /* Inline edit mode */
                  <div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">
                          Type
                        </label>
                        <select
                          value={editDraft.type}
                          onChange={(e) =>
                            setEditDraft({
                              ...editDraft,
                              type: e.target.value as CriterionType,
                            })
                          }
                          className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
                        >
                          {Object.entries(CRITERION_TYPE_LABELS).map(
                            ([k, v]) => (
                              <option key={k} value={k}>
                                {v}
                              </option>
                            )
                          )}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">
                          Description
                        </label>
                        <input
                          type="text"
                          value={editDraft.description}
                          onChange={(e) =>
                            setEditDraft({
                              ...editDraft,
                              description: e.target.value,
                            })
                          }
                          className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">
                          Expected Value
                        </label>
                        <input
                          type="text"
                          value={editDraft.expected_value}
                          onChange={(e) =>
                            setEditDraft({
                              ...editDraft,
                              expected_value: e.target.value,
                            })
                          }
                          className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
                        />
                      </div>
                    </div>
                    <div className="mb-3">
                      <label className="block text-xs text-gray-500 mb-1">
                        Weight: {editDraft.weight.toFixed(2)}
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={editDraft.weight}
                        onChange={(e) =>
                          setEditDraft({
                            ...editDraft,
                            weight: parseFloat(e.target.value),
                          })
                        }
                        className="w-full accent-[var(--accent)]"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={saveEdit}
                        disabled={saving}
                        className="bg-[var(--accent)] hover:bg-[var(--accent-light)] disabled:opacity-50 text-white text-xs px-3 py-1.5 rounded-md transition-colors"
                      >
                        {saving ? "Saving..." : "Save"}
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="text-xs text-gray-400 hover:text-white transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Display mode */
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-mono text-gray-500 w-6">
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs bg-[#1a1a2e] text-[var(--accent-light)] px-2 py-0.5 rounded-full">
                          {CRITERION_TYPE_LABELS[criterion.type]}
                        </span>
                        <span className="text-sm text-gray-300 truncate">
                          {criterion.description}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">
                        Expected: {criterion.expected_value || "--"} | Weight:{" "}
                        {criterion.weight.toFixed(2)}
                      </div>
                    </div>
                    <button
                      onClick={() => startEdit(idx)}
                      className="text-xs text-[var(--accent-light)] hover:text-white transition-colors"
                    >
                      Edit
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/*  CALIBRATION HISTORY                                          */}
      {/* ============================================================ */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Calibration History</h2>
        {calibrationHistory.length === 0 ? (
          <p className="text-sm text-gray-500">
            No calibration events recorded. Use the Calibrate button on the
            rubric list to start calibrating.
          </p>
        ) : (
          <div className="space-y-1 max-h-60 overflow-y-auto">
            {calibrationHistory.map((event, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 text-xs py-1.5 border-b border-[var(--card-border)] last:border-0"
              >
                <span className="font-mono text-gray-500 w-20">
                  {event.sample_id.slice(0, 8)}
                </span>
                <span
                  className={
                    event.judgment === "accept"
                      ? "text-green-400"
                      : "text-red-400"
                  }
                >
                  {event.judgment}
                </span>
                <span className="ml-auto text-gray-600">
                  {new Date(event.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/*  CONNECTED EVAL RUNS                                          */}
      {/* ============================================================ */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Connected Eval Runs</h2>
        {connectedRuns.length === 0 ? (
          <p className="text-sm text-gray-500">
            No eval runs have used this rubric yet.
          </p>
        ) : (
          <div className="space-y-2">
            {connectedRuns.map((run) => (
              <a
                key={run.run_id}
                href={`/eval/${run.run_id}`}
                className="flex items-center justify-between text-sm py-2 px-3 rounded-md hover:bg-[#1a1a1a] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono text-gray-400">
                    {run.run_id.slice(0, 8)}
                  </span>
                  <span>{run.agent_id}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`tabular-nums font-semibold ${
                      run.overall_score >= 0.8
                        ? "text-green-400"
                        : run.overall_score >= 0.5
                          ? "text-yellow-400"
                          : "text-red-400"
                    }`}
                  >
                    {(run.overall_score * 100).toFixed(1)}%
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(run.created_at).toLocaleDateString()}
                  </span>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
