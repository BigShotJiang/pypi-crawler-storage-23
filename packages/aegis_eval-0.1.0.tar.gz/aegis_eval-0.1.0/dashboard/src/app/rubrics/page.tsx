"use client";

import { useState, useEffect, useCallback } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type CriterionType =
  | "MUST_INCLUDE"
  | "MUST_NOT_INCLUDE"
  | "QUALITY_RANGE"
  | "CONTAINS_KEYWORD"
  | "FORMAT_CHECK"
  | "SEMANTIC_SIMILARITY"
  | "WORD_COUNT_RANGE"
  | "CUSTOM";

const CRITERION_TYPES: CriterionType[] = [
  "MUST_INCLUDE",
  "MUST_NOT_INCLUDE",
  "QUALITY_RANGE",
  "CONTAINS_KEYWORD",
  "FORMAT_CHECK",
  "SEMANTIC_SIMILARITY",
  "WORD_COUNT_RANGE",
  "CUSTOM",
];

const CRITERION_TYPE_LABELS: Record<CriterionType, string> = {
  MUST_INCLUDE: "Must Include",
  MUST_NOT_INCLUDE: "Must Not Include",
  QUALITY_RANGE: "Quality Range",
  CONTAINS_KEYWORD: "Contains Keyword",
  FORMAT_CHECK: "Format Check",
  SEMANTIC_SIMILARITY: "Semantic Similarity",
  WORD_COUNT_RANGE: "Word Count Range",
  CUSTOM: "Custom",
};

interface Criterion {
  id: string;
  type: CriterionType;
  description: string;
  expected_value: string;
  weight: number;
}

interface Rubric {
  rubric_id: string;
  name: string;
  domain: string;
  criteria: Criterion[];
  created_at: string;
  updated_at: string;
}

interface CalibrationSample {
  id: string;
  output: string;
  expected_judgment: string | null;
  expert_judgment: string | null;
}

/* ------------------------------------------------------------------ */
/*  API helpers                                                        */
/* ------------------------------------------------------------------ */

async function fetchRubrics(): Promise<Rubric[]> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics`, { cache: "no-store" });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return [];
}

async function createRubric(payload: {
  name: string;
  domain: string;
  criteria: Omit<Criterion, "id">[];
}): Promise<Rubric | null> {
  try {
    const res = await fetch(`${API_URL}/v1/rubrics`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return null;
}

async function fetchCalibrationSamples(
  rubricId: string
): Promise<CalibrationSample[]> {
  try {
    const res = await fetch(
      `${API_URL}/v1/rubrics/${rubricId}/calibration/samples`,
      { cache: "no-store" }
    );
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return [];
}

async function submitCalibrationJudgment(
  rubricId: string,
  sampleId: string,
  judgment: "accept" | "reject"
): Promise<boolean> {
  try {
    const res = await fetch(
      `${API_URL}/v1/rubrics/${rubricId}/calibration/judge`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sample_id: sampleId, judgment }),
      }
    );
    return res.ok;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/*  Helper: expected-value input per criterion type                     */
/* ------------------------------------------------------------------ */

function ExpectedValueInput({
  type,
  value,
  onChange,
}: {
  type: CriterionType;
  value: string;
  onChange: (v: string) => void;
}) {
  const base =
    "bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)] w-full";

  switch (type) {
    case "MUST_INCLUDE":
    case "MUST_NOT_INCLUDE":
    case "CONTAINS_KEYWORD":
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Required text or keyword"
          className={base}
        />
      );
    case "QUALITY_RANGE":
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="e.g. 0.6-1.0"
          className={base}
        />
      );
    case "FORMAT_CHECK":
      return (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={base}
        >
          <option value="">Select format...</option>
          <option value="json">JSON</option>
          <option value="markdown">Markdown</option>
          <option value="bullet_list">Bullet List</option>
          <option value="numbered_list">Numbered List</option>
          <option value="citation_format">Citation Format</option>
          <option value="custom_regex">Custom Regex</option>
        </select>
      );
    case "SEMANTIC_SIMILARITY":
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Reference text for similarity comparison"
          className={base}
        />
      );
    case "WORD_COUNT_RANGE":
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="e.g. 100-500"
          className={base}
        />
      );
    case "CUSTOM":
      return (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Custom evaluation logic or prompt"
          rows={2}
          className={base + " resize-y"}
        />
      );
  }
}

/* ------------------------------------------------------------------ */
/*  Reward signal preview                                              */
/* ------------------------------------------------------------------ */

function RewardPreview({ criteria }: { criteria: Criterion[] }) {
  if (criteria.length === 0) return null;

  const totalWeight = criteria.reduce((s, c) => s + c.weight, 0);

  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-5">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">
        Reward Signal Preview
      </h3>
      <p className="text-xs text-gray-500 mb-3">
        Each criterion maps to a reward component. The final reward is the
        weighted sum of individual scores.
      </p>
      <div className="space-y-2">
        {criteria.map((c, idx) => {
          const normalizedWeight =
            totalWeight > 0 ? c.weight / totalWeight : 0;
          return (
            <div key={idx} className="flex items-center gap-3 text-xs">
              <span className="w-6 text-gray-500 font-mono">{idx + 1}</span>
              <span className="flex-1 text-gray-300 truncate">
                {c.description || CRITERION_TYPE_LABELS[c.type]}
              </span>
              <span className="text-gray-500 w-24 text-right">
                {CRITERION_TYPE_LABELS[c.type]}
              </span>
              <div className="w-32 flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-[#222] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[var(--accent)]"
                    style={{ width: `${normalizedWeight * 100}%` }}
                  />
                </div>
                <span className="text-gray-400 tabular-nums w-10 text-right">
                  {(normalizedWeight * 100).toFixed(0)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-3 pt-3 border-t border-[var(--card-border)] text-xs text-gray-500">
        Total weight: {totalWeight.toFixed(2)} | Criteria count:{" "}
        {criteria.length} | Reward = sum(w_i * score_i) / sum(w_i)
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main page component                                                */
/* ------------------------------------------------------------------ */

export default function RubricsPage() {
  /* ---- Rubric list state ---- */
  const [rubrics, setRubrics] = useState<Rubric[]>([]);
  const [loading, setLoading] = useState(true);

  /* ---- Create form state ---- */
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("legal");
  const [criteria, setCriteria] = useState<Criterion[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  /* ---- Calibration state ---- */
  const [calibratingRubricId, setCalibratingRubricId] = useState<string | null>(
    null
  );
  const [calibrationSamples, setCalibrationSamples] = useState<
    CalibrationSample[]
  >([]);
  const [calibrationIdx, setCalibrationIdx] = useState(0);
  const [calibrationLoading, setCalibrationLoading] = useState(false);

  /* ---- Load rubrics ---- */
  const loadRubrics = useCallback(async () => {
    setLoading(true);
    const data = await fetchRubrics();
    setRubrics(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadRubrics();
  }, [loadRubrics]);

  /* ---- Criteria management ---- */
  function addCriterion() {
    setCriteria((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        type: "MUST_INCLUDE",
        description: "",
        expected_value: "",
        weight: 0.5,
      },
    ]);
  }

  function updateCriterion(idx: number, patch: Partial<Criterion>) {
    setCriteria((prev) =>
      prev.map((c, i) => (i === idx ? { ...c, ...patch } : c))
    );
  }

  function removeCriterion(idx: number) {
    setCriteria((prev) => prev.filter((_, i) => i !== idx));
  }

  /* ---- Submit rubric ---- */
  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (criteria.length === 0) {
      setFormError("Add at least one criterion.");
      return;
    }
    setSubmitting(true);
    setFormError(null);

    const result = await createRubric({
      name,
      domain,
      criteria: criteria.map(({ type, description, expected_value, weight }) => ({
        type,
        description,
        expected_value,
        weight,
      })),
    });

    if (result) {
      setName("");
      setDomain("legal");
      setCriteria([]);
      setShowForm(false);
      await loadRubrics();
    } else {
      setFormError("Failed to create rubric. Check the API server.");
    }
    setSubmitting(false);
  }

  /* ---- Export JSON ---- */
  function exportRubric(rubric: Rubric) {
    const blob = new Blob([JSON.stringify(rubric, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${rubric.name.replace(/\s+/g, "_").toLowerCase()}_rubric.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /* ---- Calibration ---- */
  async function startCalibration(rubricId: string) {
    setCalibratingRubricId(rubricId);
    setCalibrationLoading(true);
    setCalibrationIdx(0);
    const samples = await fetchCalibrationSamples(rubricId);
    setCalibrationSamples(samples);
    setCalibrationLoading(false);
  }

  async function handleJudgment(judgment: "accept" | "reject") {
    if (!calibratingRubricId || calibrationSamples.length === 0) return;
    const sample = calibrationSamples[calibrationIdx];
    await submitCalibrationJudgment(calibratingRubricId, sample.id, judgment);
    if (calibrationIdx < calibrationSamples.length - 1) {
      setCalibrationIdx((prev) => prev + 1);
    } else {
      setCalibratingRubricId(null);
      setCalibrationSamples([]);
      setCalibrationIdx(0);
    }
  }

  /* ---- Render ---- */
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Rubric Builder</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-[var(--accent)] hover:bg-[var(--accent-light)] text-white text-sm px-4 py-1.5 rounded-md transition-colors"
        >
          {showForm ? "Cancel" : "+ New Rubric"}
        </button>
      </div>

      {/* ============================================================ */}
      {/*  CREATE FORM                                                  */}
      {/* ============================================================ */}
      {showForm && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Create New Rubric</h2>
          <form onSubmit={handleCreate}>
            {/* Name + domain row */}
            <div className="flex flex-wrap gap-4 mb-5">
              <div className="flex-1 min-w-[200px]">
                <label className="block text-xs text-gray-500 mb-1">
                  Rubric Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Contract Review v2"
                  required
                  className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)]"
                />
              </div>
              <div className="w-48">
                <label className="block text-xs text-gray-500 mb-1">
                  Domain
                </label>
                <select
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
                >
                  <option value="legal">Legal</option>
                  <option value="finance">Finance</option>
                  <option value="medical">Medical</option>
                  <option value="engineering">Engineering</option>
                  <option value="custom">Custom</option>
                </select>
              </div>
            </div>

            {/* ---- Criteria list ---- */}
            <div className="mb-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-300">
                  Criteria ({criteria.length})
                </h3>
                <button
                  type="button"
                  onClick={addCriterion}
                  className="text-xs text-[var(--accent-light)] hover:text-white transition-colors"
                >
                  + Add Criterion
                </button>
              </div>

              {criteria.length === 0 && (
                <div className="text-center py-6 border border-dashed border-[var(--card-border)] rounded-lg">
                  <p className="text-sm text-gray-500 mb-2">
                    No criteria yet.
                  </p>
                  <button
                    type="button"
                    onClick={addCriterion}
                    className="text-sm text-[var(--accent-light)] hover:text-white transition-colors"
                  >
                    Add your first criterion
                  </button>
                </div>
              )}

              <div className="space-y-3">
                {criteria.map((criterion, idx) => (
                  <div
                    key={criterion.id}
                    className="bg-[#0d0d0d] border border-[var(--card-border)] rounded-lg p-4"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <span className="text-xs font-mono text-gray-500">
                        Criterion {idx + 1}
                      </span>
                      <button
                        type="button"
                        onClick={() => removeCriterion(idx)}
                        className="text-xs text-red-400 hover:text-red-300 transition-colors"
                      >
                        Remove
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                      {/* Type selector */}
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">
                          Type
                        </label>
                        <select
                          value={criterion.type}
                          onChange={(e) =>
                            updateCriterion(idx, {
                              type: e.target.value as CriterionType,
                              expected_value: "",
                            })
                          }
                          className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
                        >
                          {CRITERION_TYPES.map((t) => (
                            <option key={t} value={t}>
                              {CRITERION_TYPE_LABELS[t]}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Description */}
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">
                          Description
                        </label>
                        <input
                          type="text"
                          value={criterion.description}
                          onChange={(e) =>
                            updateCriterion(idx, {
                              description: e.target.value,
                            })
                          }
                          placeholder="What this criterion evaluates"
                          className="w-full bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)]"
                        />
                      </div>
                    </div>

                    {/* Expected value */}
                    <div className="mb-3">
                      <label className="block text-xs text-gray-500 mb-1">
                        Expected Value / Configuration
                      </label>
                      <ExpectedValueInput
                        type={criterion.type}
                        value={criterion.expected_value}
                        onChange={(v) =>
                          updateCriterion(idx, { expected_value: v })
                        }
                      />
                    </div>

                    {/* Weight slider */}
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">
                        Weight:{" "}
                        <span className="text-white tabular-nums">
                          {criterion.weight.toFixed(2)}
                        </span>
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={criterion.weight}
                        onChange={(e) =>
                          updateCriterion(idx, {
                            weight: parseFloat(e.target.value),
                          })
                        }
                        className="w-full accent-[var(--accent)]"
                      />
                      <div className="flex justify-between text-[10px] text-gray-600">
                        <span>0</span>
                        <span>0.5</span>
                        <span>1</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ---- Reward preview ---- */}
            {criteria.length > 0 && (
              <div className="mb-5">
                <RewardPreview criteria={criteria} />
              </div>
            )}

            {/* ---- Submit ---- */}
            {formError && (
              <p className="text-xs text-red-400 mb-3">{formError}</p>
            )}
            <div className="flex items-center gap-3">
              <button
                type="submit"
                disabled={submitting}
                className="bg-[var(--accent)] hover:bg-[var(--accent-light)] disabled:opacity-50 text-white text-sm px-5 py-2 rounded-md transition-colors"
              >
                {submitting ? "Creating..." : "Create Rubric"}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-sm text-gray-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ============================================================ */}
      {/*  CALIBRATION PANEL                                            */}
      {/* ============================================================ */}
      {calibratingRubricId && (
        <div className="bg-[var(--card)] border border-[var(--accent)] rounded-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Calibration</h2>
            <button
              onClick={() => {
                setCalibratingRubricId(null);
                setCalibrationSamples([]);
              }}
              className="text-xs text-gray-400 hover:text-white transition-colors"
            >
              Close
            </button>
          </div>

          {calibrationLoading ? (
            <p className="text-sm text-gray-400">Loading samples...</p>
          ) : calibrationSamples.length === 0 ? (
            <p className="text-sm text-gray-500">
              No calibration samples available. Run eval cases to generate
              samples for calibration.
            </p>
          ) : (
            <div>
              {/* Progress */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 h-1.5 bg-[#222] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[var(--accent)]"
                    style={{
                      width: `${((calibrationIdx + 1) / calibrationSamples.length) * 100}%`,
                    }}
                  />
                </div>
                <span className="text-xs text-gray-400 tabular-nums">
                  {calibrationIdx + 1} / {calibrationSamples.length}
                </span>
              </div>

              {/* Sample output */}
              <div className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md p-4 mb-4 max-h-48 overflow-y-auto">
                <pre className="text-xs text-gray-300 whitespace-pre-wrap">
                  {calibrationSamples[calibrationIdx].output}
                </pre>
              </div>

              {/* Judgment buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleJudgment("accept")}
                  className="bg-green-600 hover:bg-green-500 text-white text-sm px-5 py-2 rounded-md transition-colors"
                >
                  Accept
                </button>
                <button
                  onClick={() => handleJudgment("reject")}
                  className="bg-red-600 hover:bg-red-500 text-white text-sm px-5 py-2 rounded-md transition-colors"
                >
                  Reject
                </button>
                <span className="text-xs text-gray-500 ml-2">
                  Does this output meet the rubric criteria?
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/*  RUBRIC LIST TABLE                                            */}
      {/* ============================================================ */}
      {loading ? (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-8 text-center">
          <p className="text-gray-400">Loading rubrics...</p>
        </div>
      ) : rubrics.length === 0 ? (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-8 text-center">
          <p className="text-gray-400 mb-2">No rubrics defined yet.</p>
          <p className="text-sm text-gray-600">
            Click{" "}
            <button
              onClick={() => setShowForm(true)}
              className="text-[var(--accent-light)] hover:underline"
            >
              + New Rubric
            </button>{" "}
            to create your first evaluation rubric, or use the API at{" "}
            <code className="text-[var(--accent-light)]">
              POST /v1/rubrics
            </code>
            .
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[var(--card-border)]">
          <table className="w-full text-sm">
            <thead className="bg-[var(--card)] text-left text-gray-400">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Domain</th>
                <th className="px-4 py-3">Criteria</th>
                <th className="px-4 py-3">Last Updated</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rubrics.map((rubric) => (
                <tr
                  key={rubric.rubric_id}
                  className="border-t border-[var(--card-border)] hover:bg-[var(--card)]/60"
                >
                  <td className="px-4 py-3">
                    <a
                      href={`/rubrics/${rubric.rubric_id}`}
                      className="text-[var(--accent-light)] hover:underline font-medium"
                    >
                      {rubric.name}
                    </a>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-block bg-[#1a1a2e] text-[var(--accent-light)] text-xs px-2 py-0.5 rounded-full">
                      {rubric.domain}
                    </span>
                  </td>
                  <td className="px-4 py-3 tabular-nums">
                    {rubric.criteria?.length ?? 0}
                  </td>
                  <td className="px-4 py-3 text-gray-500">
                    {new Date(rubric.updated_at).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => startCalibration(rubric.rubric_id)}
                        className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                      >
                        Calibrate
                      </button>
                      <button
                        onClick={() => exportRubric(rubric)}
                        className="text-xs text-gray-400 hover:text-white transition-colors"
                      >
                        Export
                      </button>
                      <a
                        href={`/rubrics/${rubric.rubric_id}`}
                        className="text-xs text-gray-400 hover:text-white transition-colors"
                      >
                        Edit
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
