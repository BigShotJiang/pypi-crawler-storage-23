import IngestionClient from "./IngestionClient";

export default function IngestionPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Ingestion Pipeline</h1>
      <IngestionClient />
    </div>
  );
}
