"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

interface Chunk {
  content: string;
  modality: string;
  source_path: string;
  chunk_index: number;
  metadata: Record<string, unknown>;
  confidence: number;
}

interface IngestionResult {
  document_id: string;
  source_path: string;
  num_chunks: number;
  modality: string;
  chunks: Chunk[];
  storage_counts: Record<string, number>;
}

interface IngestionHistoryItem {
  document_id: string;
  source_path: string;
  num_chunks: number;
  modality: string;
}

interface ParserInfo {
  name: string;
  extensions: string[];
  modalities: string[];
}

interface SupportedFormatsResponse {
  extensions: string[];
  parsers: ParserInfo[];
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function requestJson<T>(paths: string[], init?: RequestInit): Promise<T> {
  let lastError = "Unknown API error";

  for (const path of paths) {
    try {
      const response = await fetch(`${API_BASE}${path}`, {
        cache: "no-store",
        ...init,
      });

      if (!response.ok) {
        lastError = `${response.status} ${response.statusText}`;
        continue;
      }

      return (await response.json()) as T;
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }
  }

  throw new Error(lastError);
}

export default function IngestionClient() {
  const [history, setHistory] = useState<IngestionHistoryItem[]>([]);
  const [formats, setFormats] = useState<SupportedFormatsResponse | null>(null);
  const [selected, setSelected] = useState<IngestionResult | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [store, setStore] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [loadingFormats, setLoadingFormats] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const extensionsPreview = useMemo(() => {
    if (!formats || formats.extensions.length === 0) {
      return "No formats detected yet";
    }
    return formats.extensions.join(", ");
  }, [formats]);

  const loadHistory = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const data = await requestJson<IngestionHistoryItem[]>([
        "/v1/ingestion/history",
        "/ingestion/history",
      ]);
      setHistory(data);
    } catch (err) {
      setError(`Failed to load ingestion history: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  const loadFormats = useCallback(async () => {
    setLoadingFormats(true);
    try {
      const data = await requestJson<SupportedFormatsResponse>([
        "/v1/ingestion/formats",
        "/ingestion/formats",
      ]);
      setFormats(data);
    } catch (err) {
      setError(`Failed to load supported formats: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setLoadingFormats(false);
    }
  }, []);

  useEffect(() => {
    void loadHistory();
    void loadFormats();
  }, [loadHistory, loadFormats]);

  const handleUpload = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!file) {
      setError("Select a document before uploading.");
      return;
    }

    const body = new FormData();
    body.append("file", file);

    setUploading(true);
    try {
      const result = await requestJson<IngestionResult>([
        `/v1/ingestion/upload?store=${store}`,
        `/ingestion/upload?store=${store}`,
      ], {
        method: "POST",
        body,
      });

      setSelected(result);
      setSuccess(
        `Ingested ${result.source_path} (${result.num_chunks} chunks, modality ${result.modality}).`
      );
      await loadHistory();
    } catch (err) {
      setError(`Upload failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setUploading(false);
    }
  };

  const handleStatus = async (documentId: string) => {
    setError(null);
    setSuccess(null);
    try {
      const result = await requestJson<IngestionResult>([
        `/v1/ingestion/${documentId}`,
        `/ingestion/${documentId}`,
      ]);
      setSelected(result);
    } catch (err) {
      setError(`Failed to load status for ${documentId}: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleRetry = async (documentId: string) => {
    setError(null);
    setSuccess(null);
    try {
      const result = await requestJson<IngestionResult>([
        `/v1/ingestion/${documentId}/retry?store=${store}`,
        `/ingestion/${documentId}/retry?store=${store}`,
      ], {
        method: "POST",
      });
      setSelected(result);
      setSuccess(
        `Retried ingestion for ${result.source_path}. New document id: ${result.document_id}`
      );
      await loadHistory();
    } catch (err) {
      setError(`Retry failed for ${documentId}: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  return (
    <div className="space-y-6">
      <section className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Upload and Ingest</h2>

        <form className="space-y-4" onSubmit={handleUpload}>
          <input
            type="file"
            onChange={(e) => {
              setFile(e.target.files?.[0] ?? null);
            }}
            className="block w-full text-sm text-gray-300 file:mr-4 file:rounded-md file:border-0 file:bg-[var(--accent)] file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-[var(--accent-dark)]"
          />

          <label className="inline-flex items-center gap-2 text-sm text-gray-300">
            <input
              type="checkbox"
              checked={store}
              onChange={(e) => {
                setStore(e.target.checked);
              }}
              className="rounded border-[var(--card-border)] bg-[#0a0a0a]"
            />
            Persist chunks to configured backends (pgvector/Neo4j)
          </label>

          <div>
            <button
              type="submit"
              disabled={uploading}
              className="rounded-md bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
            >
              {uploading ? "Uploading..." : "Upload and Ingest"}
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-4 rounded-md border border-red-700/40 bg-red-900/20 px-3 py-2 text-sm text-red-300">
            {error}
          </div>
        )}
        {success && (
          <div className="mt-4 rounded-md border border-green-700/40 bg-green-900/20 px-3 py-2 text-sm text-green-300">
            {success}
          </div>
        )}
      </section>

      <section className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Supported Formats</h2>
          <button
            type="button"
            onClick={() => {
              void loadFormats();
            }}
            className="text-xs text-[var(--accent-light)] hover:underline"
          >
            Refresh
          </button>
        </div>

        {loadingFormats ? (
          <p className="text-sm text-gray-500">Loading formats...</p>
        ) : (
          <>
            <p className="text-sm text-gray-400 mb-3">{extensionsPreview}</p>
            <div className="space-y-2">
              {(formats?.parsers || []).map((parser) => (
                <div
                  key={parser.name}
                  className="rounded-md border border-[var(--card-border)] bg-black/20 px-3 py-2"
                >
                  <div className="text-sm font-medium text-gray-200">{parser.name}</div>
                  <div className="text-xs text-gray-500">
                    Extensions: {parser.extensions.join(", ")}
                  </div>
                  <div className="text-xs text-gray-500">
                    Modalities: {parser.modalities.join(", ")}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      <section className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Ingestion History</h2>
          <button
            type="button"
            onClick={() => {
              void loadHistory();
            }}
            className="text-xs text-[var(--accent-light)] hover:underline"
          >
            Refresh
          </button>
        </div>

        {loadingHistory ? (
          <p className="text-sm text-gray-500">Loading history...</p>
        ) : history.length === 0 ? (
          <p className="text-sm text-gray-500">No ingestions yet.</p>
        ) : (
          <div className="space-y-2">
            {history.map((item) => (
              <div
                key={item.document_id}
                className="rounded-md border border-[var(--card-border)] bg-black/20 px-3 py-2"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="font-mono text-xs text-gray-500">{item.document_id}</div>
                    <div className="text-sm text-gray-200">{item.source_path}</div>
                    <div className="text-xs text-gray-500">
                      {item.num_chunks} chunks · modality {item.modality}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        void handleStatus(item.document_id);
                      }}
                      className="rounded-md border border-[var(--card-border)] px-2 py-1 text-xs text-gray-300 hover:bg-black/30"
                    >
                      Status
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        void handleRetry(item.document_id);
                      }}
                      className="rounded-md border border-[var(--card-border)] px-2 py-1 text-xs text-gray-300 hover:bg-black/30"
                    >
                      Retry
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {selected && (
        <section className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-3">Selected Ingestion Status</h2>
          <div className="space-y-1 text-sm">
            <div>
              <span className="text-gray-500">Document ID: </span>
              <span className="font-mono text-gray-200">{selected.document_id}</span>
            </div>
            <div>
              <span className="text-gray-500">Source: </span>
              <span className="text-gray-200">{selected.source_path}</span>
            </div>
            <div>
              <span className="text-gray-500">Chunks: </span>
              <span className="text-gray-200">{selected.num_chunks}</span>
            </div>
            <div>
              <span className="text-gray-500">Modality: </span>
              <span className="text-gray-200">{selected.modality}</span>
            </div>
            <div>
              <span className="text-gray-500">Stored to: </span>
              <span className="text-gray-200">
                {Object.keys(selected.storage_counts).length > 0
                  ? JSON.stringify(selected.storage_counts)
                  : "not persisted"}
              </span>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <h3 className="text-sm font-semibold text-gray-300">Chunk Preview</h3>
            {selected.chunks.slice(0, 5).map((chunk) => (
              <div
                key={`${chunk.source_path}:${chunk.chunk_index}`}
                className="rounded-md border border-[var(--card-border)] bg-black/20 px-3 py-2"
              >
                <div className="text-xs text-gray-500 mb-1">
                  #{chunk.chunk_index} · {chunk.modality} · confidence {chunk.confidence.toFixed(2)}
                </div>
                <div className="text-sm text-gray-300 line-clamp-4">{chunk.content}</div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
