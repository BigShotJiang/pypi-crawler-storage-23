import CreateTrainingJobForm from "./CreateTrainingJobForm";
import AdapterManagement from "./AdapterManagement";

interface TrainingJob {
  job_id: string;
  customer_id: string;
  domain: string;
  optimizer: string;
  status: string;
  metrics: {
    current_stage: number;
    total_stages: number;
    episodes_completed: number;
    mean_reward: number;
    best_reward: number;
    loss: number | null;
  };
  created_at: string;
  updated_at: string;
}

async function getTrainingJobs(): Promise<TrainingJob[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/train/jobs`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/training/jobs?limit=50`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    return res.json();
  } catch {
    return [];
  }
}

const statusColor: Record<string, string> = {
  created: "text-gray-400",
  queued: "text-blue-300",
  running: "text-blue-400",
  completed: "text-green-400",
  failed: "text-red-400",
  cancelled: "text-yellow-400",
  stopping: "text-orange-400",
  stopped: "text-orange-400",
};

const statusDot: Record<string, string> = {
  created: "bg-gray-400",
  queued: "bg-blue-300",
  running: "bg-blue-400",
  completed: "bg-green-400",
  failed: "bg-red-400",
  cancelled: "bg-yellow-400",
  stopping: "bg-orange-400",
  stopped: "bg-orange-400",
};

export default async function TrainingPage() {
  const jobs = await getTrainingJobs();

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Training Jobs</h1>
      </div>

      {/* Creation form */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-5 mb-6">
        <h2 className="text-sm font-semibold text-gray-300 mb-3">
          Create New Training Job
        </h2>
        <CreateTrainingJobForm />
      </div>

      {/* Job list */}
      {jobs.length === 0 ? (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-8 text-center">
          <p className="text-gray-400 mb-2">No training jobs yet.</p>
          <p className="text-sm text-gray-600">
            Use the form above or the API to create a training job.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {jobs.map((job) => (
            <a
              key={job.job_id}
              href={`/training/${job.job_id}`}
              className="block bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4 hover:border-[var(--accent)] transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm text-gray-400">
                    {job.job_id.slice(0, 8)}
                  </span>
                  <span className="text-sm font-medium">{job.domain}</span>
                  <span className="text-xs text-gray-500">
                    ({job.optimizer})
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${statusDot[job.status] || "bg-gray-400"}`}
                  />
                  <span
                    className={`text-sm font-medium ${statusColor[job.status] || "text-gray-400"}`}
                  >
                    {job.status}
                  </span>
                </div>
              </div>

              {/* Metrics summary row */}
              {job.metrics && job.metrics.episodes_completed > 0 && (
                <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                  <span>
                    Stage {job.metrics.current_stage}/{job.metrics.total_stages}
                  </span>
                  <span>
                    {job.metrics.episodes_completed} episodes
                  </span>
                  <span>
                    Mean reward:{" "}
                    <span className="text-green-400 tabular-nums">
                      {job.metrics.mean_reward.toFixed(4)}
                    </span>
                  </span>
                  {job.metrics.loss !== null && (
                    <span>
                      Loss:{" "}
                      <span className="text-red-400 tabular-nums">
                        {job.metrics.loss.toFixed(4)}
                      </span>
                    </span>
                  )}
                </div>
              )}

              <div className="mt-1 text-xs text-gray-600">
                Customer: {job.customer_id || "\u2014"} &middot;{" "}
                {new Date(job.created_at).toLocaleString()}
              </div>
            </a>
          ))}
        </div>
      )}

      {/* Adapter Management */}
      <div className="mt-6">
        <AdapterManagement />
      </div>
    </div>
  );
}
