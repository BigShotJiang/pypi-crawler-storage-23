"use client";

import { useState } from "react";

export default function CreateTrainingJobForm() {
  const [customerId, setCustomerId] = useState("");
  const [domain, setDomain] = useState("legal");
  const [optimizer, setOptimizer] = useState("grpo");
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setResult(null);
    setError(null);

    const apiUrl =
      process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

    try {
      const res = await fetch(`${apiUrl}/v1/train/jobs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer_id: customerId,
          domain,
          optimizer,
        }),
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || `HTTP ${res.status}`);
      }

      const data = await res.json();
      setResult(`Created job ${data.job_id} (${data.status})`);
      setCustomerId("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-wrap items-end gap-3">
      <div>
        <label className="block text-xs text-gray-500 mb-1">Customer ID</label>
        <input
          type="text"
          value={customerId}
          onChange={(e) => setCustomerId(e.target.value)}
          placeholder="acme-corp"
          required
          className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)]"
        />
      </div>
      <div>
        <label className="block text-xs text-gray-500 mb-1">Domain</label>
        <select
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
        >
          <option value="legal">Legal</option>
          <option value="finance">Finance</option>
          <option value="safety">Safety</option>
          <option value="memory">Memory</option>
        </select>
      </div>
      <div>
        <label className="block text-xs text-gray-500 mb-1">Optimizer</label>
        <select
          value={optimizer}
          onChange={(e) => setOptimizer(e.target.value)}
          className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
        >
          <option value="grpo">GRPO</option>
          <option value="amir-grpo">AMIR-GRPO</option>
          <option value="grpo-sg">GRPO-SG</option>
          <option value="ppo">PPO</option>
          <option value="dpo">DPO</option>
        </select>
      </div>
      <button
        type="submit"
        disabled={submitting}
        className="bg-[var(--accent)] hover:bg-[var(--accent-light)] disabled:opacity-50 text-white text-sm px-4 py-1.5 rounded-md transition-colors"
      >
        {submitting ? "Creating..." : "Create Job"}
      </button>

      {result && (
        <span className="text-xs text-green-400 ml-2">{result}</span>
      )}
      {error && (
        <span className="text-xs text-red-400 ml-2">Error: {error}</span>
      )}
    </form>
  );
}
