"use client";

import { useState, useEffect, useCallback } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface Adapter {
  adapter_id: string;
  version: string;
  domain: string;
  created_at: string;
  eval_score: number;
  production_score: number | null;
  status: "deployed" | "staging" | "archived" | "rolling_back";
  job_id: string;
}

/* ------------------------------------------------------------------ */
/*  API helpers                                                        */
/* ------------------------------------------------------------------ */

async function fetchAdapters(): Promise<Adapter[]> {
  try {
    const res = await fetch(`${API_URL}/v1/train/adapters`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  return [];
}

async function rollbackAdapter(adapterId: string): Promise<boolean> {
  try {
    const res = await fetch(
      `${API_URL}/v1/train/adapters/${adapterId}/rollback`,
      { method: "POST" }
    );
    return res.ok;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

const statusColor: Record<string, string> = {
  deployed: "text-green-400",
  staging: "text-blue-400",
  archived: "text-gray-400",
  rolling_back: "text-orange-400",
};

const statusDot: Record<string, string> = {
  deployed: "bg-green-400",
  staging: "bg-blue-400",
  archived: "bg-gray-400",
  rolling_back: "bg-orange-400",
};

export default function AdapterManagement() {
  const [adapters, setAdapters] = useState<Adapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [rollbackTarget, setRollbackTarget] = useState<string | null>(null);
  const [compareIds, setCompareIds] = useState<Set<string>>(new Set());

  const loadAdapters = useCallback(async () => {
    setLoading(true);
    const data = await fetchAdapters();
    setAdapters(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadAdapters();
  }, [loadAdapters]);

  async function handleRollback(adapterId: string) {
    const ok = await rollbackAdapter(adapterId);
    if (ok) {
      setRollbackTarget(null);
      await loadAdapters();
    }
  }

  function toggleCompare(adapterId: string) {
    setCompareIds((prev) => {
      const next = new Set(prev);
      if (next.has(adapterId)) {
        next.delete(adapterId);
      } else if (next.size < 2) {
        next.add(adapterId);
      }
      return next;
    });
  }

  const compareAdapters = adapters.filter((a) => compareIds.has(a.adapter_id));

  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
      <h2 className="text-lg font-semibold mb-4">LoRA Adapter Management</h2>

      {loading ? (
        <p className="text-sm text-gray-400">Loading adapters...</p>
      ) : adapters.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-gray-400 mb-2">No adapters deployed yet.</p>
          <p className="text-sm text-gray-600">
            Complete a training job to generate a LoRA adapter.
          </p>
        </div>
      ) : (
        <>
          {/* A/B comparison panel */}
          {compareAdapters.length === 2 && (
            <div className="bg-[#0d0d0d] border border-[var(--accent)] rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-300">
                  A/B Comparison
                </h3>
                <button
                  onClick={() => setCompareIds(new Set())}
                  className="text-xs text-gray-400 hover:text-white transition-colors"
                >
                  Clear
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {compareAdapters.map((adapter, i) => (
                  <div
                    key={adapter.adapter_id}
                    className="border border-[var(--card-border)] rounded-lg p-3"
                  >
                    <div className="text-xs text-gray-500 mb-1">
                      {i === 0 ? "Adapter A" : "Adapter B"}
                    </div>
                    <div className="text-sm font-medium mb-2">
                      {adapter.domain} v{adapter.version}
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Eval Score</span>
                        <span
                          className={`tabular-nums font-semibold ${
                            adapter.eval_score >= 0.8
                              ? "text-green-400"
                              : adapter.eval_score >= 0.5
                                ? "text-yellow-400"
                                : "text-red-400"
                          }`}
                        >
                          {(adapter.eval_score * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Prod Score</span>
                        <span className="tabular-nums text-gray-300">
                          {adapter.production_score !== null
                            ? `${(adapter.production_score * 100).toFixed(1)}%`
                            : "--"}
                        </span>
                      </div>
                      {adapter.production_score !== null && (
                        <div className="flex justify-between">
                          <span className="text-gray-500">Delta</span>
                          <span
                            className={`tabular-nums font-semibold ${
                              adapter.production_score >= adapter.eval_score
                                ? "text-green-400"
                                : "text-red-400"
                            }`}
                          >
                            {adapter.production_score >= adapter.eval_score
                              ? "+"
                              : ""}
                            {(
                              (adapter.production_score - adapter.eval_score) *
                              100
                            ).toFixed(1)}
                            %
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Visual comparison bars */}
              <div className="mt-3 space-y-2">
                <div>
                  <div className="text-xs text-gray-500 mb-1">
                    Eval Score Comparison
                  </div>
                  <div className="flex gap-2">
                    {compareAdapters.map((adapter, i) => (
                      <div key={adapter.adapter_id} className="flex-1">
                        <div className="h-2 bg-[#222] rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${i === 0 ? "bg-[var(--accent)]" : "bg-cyan-500"}`}
                            style={{
                              width: `${adapter.eval_score * 100}%`,
                            }}
                          />
                        </div>
                        <div className="text-[10px] text-gray-500 mt-0.5">
                          {i === 0 ? "A" : "B"}:{" "}
                          {(adapter.eval_score * 100).toFixed(1)}%
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Adapter list */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-gray-400">
                <tr>
                  <th className="px-3 py-2 w-8">A/B</th>
                  <th className="px-3 py-2">Domain</th>
                  <th className="px-3 py-2">Version</th>
                  <th className="px-3 py-2">Eval Score</th>
                  <th className="px-3 py-2">Prod Score</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2">Created</th>
                  <th className="px-3 py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {adapters.map((adapter) => (
                  <tr
                    key={adapter.adapter_id}
                    className="border-t border-[var(--card-border)]"
                  >
                    <td className="px-3 py-2">
                      <input
                        type="checkbox"
                        checked={compareIds.has(adapter.adapter_id)}
                        onChange={() => toggleCompare(adapter.adapter_id)}
                        disabled={
                          !compareIds.has(adapter.adapter_id) &&
                          compareIds.size >= 2
                        }
                        className="accent-[var(--accent)]"
                      />
                    </td>
                    <td className="px-3 py-2 font-medium">
                      {adapter.domain}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs text-gray-400">
                      v{adapter.version}
                    </td>
                    <td className="px-3 py-2">
                      <span
                        className={`tabular-nums font-semibold ${
                          adapter.eval_score >= 0.8
                            ? "text-green-400"
                            : adapter.eval_score >= 0.5
                              ? "text-yellow-400"
                              : "text-red-400"
                        }`}
                      >
                        {(adapter.eval_score * 100).toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      {adapter.production_score !== null ? (
                        <div className="flex items-center gap-2">
                          <span className="tabular-nums text-gray-300">
                            {(adapter.production_score * 100).toFixed(1)}%
                          </span>
                          <span
                            className={`text-[10px] tabular-nums ${
                              adapter.production_score >= adapter.eval_score
                                ? "text-green-400"
                                : "text-red-400"
                            }`}
                          >
                            {adapter.production_score >= adapter.eval_score
                              ? "+"
                              : ""}
                            {(
                              (adapter.production_score - adapter.eval_score) *
                              100
                            ).toFixed(1)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-600">--</span>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${statusDot[adapter.status] || "bg-gray-400"}`}
                        />
                        <span
                          className={`text-xs ${statusColor[adapter.status] || "text-gray-400"}`}
                        >
                          {adapter.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-3 py-2 text-xs text-gray-500">
                      {new Date(adapter.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-3 py-2 text-right">
                      {adapter.status === "deployed" && (
                        <>
                          {rollbackTarget === adapter.adapter_id ? (
                            <div className="flex items-center justify-end gap-2">
                              <span className="text-[10px] text-yellow-400">
                                Rollback?
                              </span>
                              <button
                                onClick={() =>
                                  handleRollback(adapter.adapter_id)
                                }
                                className="text-xs text-red-400 hover:text-red-300 transition-colors"
                              >
                                Confirm
                              </button>
                              <button
                                onClick={() => setRollbackTarget(null)}
                                className="text-xs text-gray-400 hover:text-white transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() =>
                                setRollbackTarget(adapter.adapter_id)
                              }
                              className="text-xs text-orange-400 hover:text-orange-300 transition-colors"
                            >
                              Rollback
                            </button>
                          )}
                        </>
                      )}
                      {adapter.status !== "deployed" && (
                        <a
                          href={`/training/${adapter.job_id}`}
                          className="text-xs text-gray-400 hover:text-white transition-colors"
                        >
                          View Job
                        </a>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
