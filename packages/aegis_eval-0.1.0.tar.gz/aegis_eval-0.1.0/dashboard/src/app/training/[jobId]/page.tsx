import MetricsChart from "@/components/MetricsChart";
import ObservatoryPanel from "@/components/ObservatoryPanel";

interface TrainingMetrics {
  current_stage: number;
  total_stages: number;
  episodes_completed: number;
  mean_reward: number;
  best_reward: number;
  loss: number | null;
}

interface CurriculumStage {
  stage: number;
  name: string;
  difficulty: number;
  num_episodes: number;
}

interface TrainingJobDetail {
  job_id: string;
  customer_id: string;
  domain: string;
  optimizer: string;
  status: string;
  lora_config: {
    rank: number;
    alpha: number;
    dropout: number;
    target_modules: string[];
  };
  curriculum: CurriculumStage[];
  metrics: TrainingMetrics;
  created_at: string;
  updated_at: string;
}

interface MetricsSeriesPoint {
  stage_index: number;
  reward: number;
  loss: number;
  kl_divergence: number;
  entropy: number;
}

interface MetricsSeries {
  job_id: string;
  status: string;
  series: MetricsSeriesPoint[];
}

interface ObservatoryCheck {
  healthy: boolean;
  score: number;
  details: Record<string, unknown>;
  recommendations: string[];
}

interface ObservatoryReport {
  job_id: string;
  status: string;
  overall_healthy: boolean;
  composite_score: number;
  checks: Record<string, ObservatoryCheck>;
}

async function getTrainingJob(
  jobId: string
): Promise<TrainingJobDetail | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/train/jobs/${jobId}`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/training/jobs/${jobId}`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

async function getMetricsSeries(
  jobId: string
): Promise<MetricsSeries | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(
      `${apiUrl}/v1/train/jobs/${jobId}/metrics/series`,
      { cache: "no-store" }
    );
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(
      `${apiUrl}/training/jobs/${jobId}/metrics/series`,
      { cache: "no-store" }
    );
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

async function getObservatory(
  jobId: string
): Promise<ObservatoryReport | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(
      `${apiUrl}/v1/train/jobs/${jobId}/observatory`,
      { cache: "no-store" }
    );
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(
      `${apiUrl}/training/jobs/${jobId}/observatory`,
      { cache: "no-store" }
    );
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

const statusColor: Record<string, string> = {
  created: "text-gray-400",
  queued: "text-blue-300",
  running: "text-blue-400",
  completed: "text-green-400",
  failed: "text-red-400",
  cancelled: "text-yellow-400",
};

export default async function TrainingJobPage({
  params,
}: {
  params: Promise<{ jobId: string }>;
}) {
  const { jobId } = await params;

  const [job, metricsSeries, observatory] = await Promise.all([
    getTrainingJob(jobId),
    getMetricsSeries(jobId),
    getObservatory(jobId),
  ]);

  if (!job) {
    return (
      <div className="text-center py-16">
        <h1 className="text-xl font-bold mb-2">Training job not found</h1>
        <p className="text-gray-500 font-mono text-sm">{jobId}</p>
        <a
          href="/training"
          className="text-[var(--accent-light)] text-sm mt-4 inline-block"
        >
          Back to training
        </a>
      </div>
    );
  }

  const m = job.metrics;

  return (
    <div>
      <a
        href="/training"
        className="text-sm text-gray-500 hover:text-gray-300 mb-4 inline-block"
      >
        &larr; All training jobs
      </a>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">{job.domain}</h1>
          <p className="text-sm text-gray-500 font-mono mt-1">{job.job_id}</p>
          <p className="text-xs text-gray-600 mt-1">
            Customer: {job.customer_id || "\u2014"} &middot; Optimizer:{" "}
            {job.optimizer} &middot;{" "}
            {new Date(job.created_at).toLocaleString()}
          </p>
        </div>
        <span
          className={`text-lg font-semibold ${statusColor[job.status] || "text-gray-400"}`}
        >
          {job.status}
        </span>
      </div>

      {/* Metrics summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <MetricCard label="Stage" value={`${m.current_stage}/${m.total_stages}`} />
        <MetricCard label="Episodes" value={String(m.episodes_completed)} />
        <MetricCard
          label="Mean Reward"
          value={m.mean_reward.toFixed(4)}
          valueColor="text-green-400"
        />
        <MetricCard
          label="Best Reward"
          value={m.best_reward.toFixed(4)}
          valueColor="text-green-300"
        />
        <MetricCard
          label="Loss"
          value={m.loss !== null ? m.loss.toFixed(4) : "\u2014"}
          valueColor={m.loss !== null ? "text-red-400" : "text-gray-500"}
        />
      </div>

      {/* LoRA configuration */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4 mb-6">
        <h2 className="text-sm font-semibold text-gray-300 mb-2">
          LoRA Configuration
        </h2>
        <div className="flex flex-wrap gap-4 text-xs text-gray-400">
          <span>
            Rank: <span className="text-white">{job.lora_config.rank}</span>
          </span>
          <span>
            Alpha: <span className="text-white">{job.lora_config.alpha}</span>
          </span>
          <span>
            Dropout:{" "}
            <span className="text-white">{job.lora_config.dropout}</span>
          </span>
          <span>
            Targets:{" "}
            <span className="text-white font-mono">
              {job.lora_config.target_modules.join(", ")}
            </span>
          </span>
        </div>
      </div>

      {/* Curriculum */}
      {job.curriculum.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4 mb-6">
          <h2 className="text-sm font-semibold text-gray-300 mb-2">
            Curriculum
          </h2>
          <div className="space-y-1">
            {job.curriculum.map((stage) => (
              <div
                key={stage.stage}
                className="flex items-center gap-4 text-xs"
              >
                <span className="text-gray-500 w-12">
                  Stage {stage.stage}
                </span>
                <span className="text-white flex-1">{stage.name}</span>
                <span className="text-gray-400">
                  Difficulty {stage.difficulty}
                </span>
                <span className="text-gray-500">
                  {stage.num_episodes} episodes
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Metrics time-series chart */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Training Metrics</h2>
        <MetricsChart series={metricsSeries?.series || []} />
      </div>

      {/* Observatory panel */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Observatory</h2>
        {observatory ? (
          <ObservatoryPanel
            overallHealthy={observatory.overall_healthy}
            compositeScore={observatory.composite_score}
            checks={observatory.checks}
          />
        ) : (
          <p className="text-sm text-gray-500">
            Observatory data not available. Run the training job to generate health checks.
          </p>
        )}
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  valueColor,
}: {
  label: string;
  value: string;
  valueColor?: string;
}) {
  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-3">
      <div className="text-[10px] text-gray-500 mb-1">{label}</div>
      <div className={`text-lg font-bold tabular-nums ${valueColor || "text-white"}`}>
        {value}
      </div>
    </div>
  );
}
