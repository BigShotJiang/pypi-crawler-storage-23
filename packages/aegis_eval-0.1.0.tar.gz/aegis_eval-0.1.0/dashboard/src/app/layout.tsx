import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aegis Dashboard",
  description:
    "The Adaptive Intelligence Layer for AI Agents — eval, train, memory.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">
        <div className="min-h-screen flex">
          <nav className="w-56 border-r border-[var(--card-border)] p-4 flex flex-col gap-2">
            <div className="text-xl font-bold text-[var(--accent-light)] mb-6">
              Aegis
            </div>
            <NavLink href="/" label="Eval Runs" />
            <NavLink href="/arena" label="Arena" />
            <NavLink href="/training" label="Training" />
            <NavLink href="/rubrics" label="Rubrics" />
            <NavLink href="/memory" label="Memory" />
            <NavLink href="/ingestion" label="Ingestion" />
          </nav>
          <main className="flex-1 p-6">{children}</main>
        </div>
      </body>
    </html>
  );
}

function NavLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      className="px-3 py-2 rounded-md text-sm hover:bg-[var(--card)] transition-colors"
    >
      {label}
    </a>
  );
}
