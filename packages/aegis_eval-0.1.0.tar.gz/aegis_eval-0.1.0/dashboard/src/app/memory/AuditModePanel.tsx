"use client";

import { useState } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface SnapshotEntry {
  id: string;
  key: string;
  value: unknown;
  memory_tier: string;
  confidence: number;
  timestamp: string;
}

export default function AuditModePanel() {
  const [date, setDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [entries, setEntries] = useState<SnapshotEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function reconstructState() {
    if (!date) return;
    setLoading(true);
    setError(null);
    setEntries(null);

    const isoDate = new Date(date).toISOString();

    try {
      let res = await fetch(`${API_URL}/v1/memory/snapshots/${isoDate}`, {
        cache: "no-store",
      });

      if (!res.ok) {
        res = await fetch(`${API_URL}/memory/snapshots/${isoDate}`, {
          cache: "no-store",
        });
      }

      if (res.ok) {
        const data = await res.json();
        setEntries(data.entries || []);
      } else {
        setError("Failed to reconstruct memory state at the selected date.");
      }
    } catch {
      setError("Could not connect to the API server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
      <h2 className="text-lg font-semibold mb-4">Point-in-Time Audit</h2>
      <p className="text-xs text-gray-500 mb-4">
        Reconstruct the full memory state as it existed at a specific point in
        time. Useful for compliance audits and debugging historical behavior.
      </p>

      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div>
          <label className="block text-xs text-gray-500 mb-1">
            Select Date
          </label>
          <input
            type="datetime-local"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)]"
          />
        </div>
        <button
          onClick={reconstructState}
          disabled={!date || loading}
          className="bg-[var(--accent)] hover:bg-[var(--accent-light)] disabled:opacity-50 text-white text-sm px-4 py-1.5 rounded-md transition-colors"
        >
          {loading ? "Reconstructing..." : "Reconstruct Memory State"}
        </button>
      </div>

      {error && <p className="text-xs text-red-400 mb-3">{error}</p>}

      {entries !== null && (
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">
              {entries.length} entries at{" "}
              {new Date(date).toLocaleString()}
            </span>
          </div>

          {entries.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No memory entries existed at the selected time.
            </p>
          ) : (
            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-gray-400 sticky top-0 bg-[var(--card)]">
                  <tr>
                    <th className="px-3 py-2">Key</th>
                    <th className="px-3 py-2">Tier</th>
                    <th className="px-3 py-2">Value</th>
                    <th className="px-3 py-2">Confidence</th>
                    <th className="px-3 py-2">Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((entry) => (
                    <tr
                      key={entry.id}
                      className="border-t border-[var(--card-border)]"
                    >
                      <td className="px-3 py-2 font-mono text-xs text-[var(--accent-light)]">
                        {entry.key}
                      </td>
                      <td className="px-3 py-2">
                        <span className="text-xs bg-[#1a1a2e] text-[var(--accent-light)] px-2 py-0.5 rounded-full">
                          {entry.memory_tier}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-400 max-w-xs truncate">
                        {typeof entry.value === "string"
                          ? entry.value
                          : JSON.stringify(entry.value)}
                      </td>
                      <td className="px-3 py-2 tabular-nums text-xs">
                        {(entry.confidence * 100).toFixed(0)}%
                      </td>
                      <td className="px-3 py-2 text-xs text-gray-500">
                        {new Date(entry.timestamp).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
