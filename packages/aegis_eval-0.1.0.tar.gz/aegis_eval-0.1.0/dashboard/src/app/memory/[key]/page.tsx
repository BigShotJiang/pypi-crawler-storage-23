interface MemoryEntry {
  id: string;
  key: string;
  value: unknown;
  memory_tier: string;
  confidence: number;
  timestamp: string;
  metadata: Record<string, unknown>;
}

interface AuditEvent {
  id?: string;
  operation: string;
  key: string;
  agent_id?: string;
  customer_id?: string;
  timestamp: string;
  [key: string]: unknown;
}

async function getMemoryEntry(key: string): Promise<MemoryEntry | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/memory/retrieve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: key, mode: "key", limit: 1 }),
      cache: "no-store",
    });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) return data[0];
    }
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/memory/retrieve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: key, mode: "key", limit: 1 }),
      cache: "no-store",
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) return data[0];
    return null;
  } catch {
    return null;
  }
}

async function getAuditTrail(key: string): Promise<AuditEvent[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/memory/audit`, {
      cache: "no-store",
    });
    if (res.ok) {
      const events: AuditEvent[] = await res.json();
      return events.filter((e) => e.key === key);
    }
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/memory/audit`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const events: AuditEvent[] = await res.json();
    return events.filter((e) => e.key === key);
  } catch {
    return [];
  }
}

const tierBadgeColor: Record<string, string> = {
  working: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  session: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  permanent: "bg-green-500/20 text-green-300 border-green-500/30",
  episodic: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
  semantic: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  procedural: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  strategic: "bg-red-500/20 text-red-300 border-red-500/30",
};

const operationColor: Record<string, string> = {
  store: "text-green-400",
  retrieve: "text-blue-400",
  update: "text-yellow-400",
  forget: "text-red-400",
  link: "text-purple-400",
  promote: "text-cyan-400",
  demote: "text-orange-400",
  compress: "text-gray-400",
  verify: "text-lime-400",
  annotate: "text-pink-400",
  split: "text-indigo-400",
  merge: "text-teal-400",
};

function confidenceColor(c: number): string {
  if (c >= 0.8) return "text-green-400";
  if (c >= 0.5) return "text-yellow-400";
  return "text-red-400";
}

function formatValue(value: unknown): string {
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

export default async function MemoryEntryPage({
  params,
}: {
  params: Promise<{ key: string }>;
}) {
  const { key: rawKey } = await params;
  const key = decodeURIComponent(rawKey);

  const [entry, auditEvents] = await Promise.all([
    getMemoryEntry(key),
    getAuditTrail(key),
  ]);

  if (!entry) {
    return (
      <div className="text-center py-16">
        <h1 className="text-xl font-bold mb-2">Memory entry not found</h1>
        <p className="text-gray-500 font-mono text-sm">{key}</p>
        <a
          href="/memory"
          className="text-[var(--accent-light)] text-sm mt-4 inline-block"
        >
          Back to memory explorer
        </a>
      </div>
    );
  }

  const provenance = entry.metadata?.provenance as Record<string, unknown> | undefined;
  const tags = entry.metadata?.tags;
  const links = entry.metadata?.links;

  return (
    <div>
      <a
        href="/memory"
        className="text-sm text-gray-500 hover:text-gray-300 mb-4 inline-block"
      >
        &larr; Memory Explorer
      </a>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold font-mono">{key}</h1>
          <div className="flex items-center gap-3 mt-2">
            <span
              className={`text-xs px-2 py-0.5 rounded-full border ${
                tierBadgeColor[entry.memory_tier] ||
                "bg-gray-500/20 text-gray-300 border-gray-500/30"
              }`}
            >
              {entry.memory_tier}
            </span>
            <span className={`text-sm tabular-nums ${confidenceColor(entry.confidence)}`}>
              {(entry.confidence * 100).toFixed(1)}% confidence
            </span>
            <span className="text-xs text-gray-600">
              {new Date(entry.timestamp).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Value */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
        <h2 className="text-sm font-semibold text-gray-300 mb-3">Value</h2>
        <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono bg-[#0a0a0a] rounded-md p-4 overflow-x-auto">
          {formatValue(entry.value)}
        </pre>
      </div>

      {/* Provenance */}
      {provenance && Object.keys(provenance).length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-sm font-semibold text-gray-300 mb-3">
            Provenance
          </h2>
          <div className="space-y-1">
            {Object.entries(provenance).map(([pKey, pVal]) => (
              <div key={pKey} className="flex items-start gap-3 text-xs">
                <span className="text-gray-500 w-32 shrink-0">{pKey}</span>
                <span className="text-gray-300 font-mono">
                  {typeof pVal === "string" ? pVal : JSON.stringify(pVal)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tags */}
      {Array.isArray(tags) && tags.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-sm font-semibold text-gray-300 mb-3">Tags</h2>
          <div className="flex flex-wrap gap-2">
            {(tags as string[]).map((tag) => (
              <span
                key={tag}
                className="text-xs bg-[var(--accent)]/20 text-[var(--accent-light)] px-2 py-0.5 rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Links */}
      {Array.isArray(links) && links.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-sm font-semibold text-gray-300 mb-3">Links</h2>
          <div className="space-y-1">
            {(links as { target?: string; key?: string; relation?: string }[]).map(
              (link, idx) => {
                const target = link.target || link.key || "unknown";
                return (
                  <div key={idx} className="flex items-center gap-3 text-xs">
                    <span className="text-purple-400">
                      {link.relation || "related"}
                    </span>
                    <span className="text-gray-500">&rarr;</span>
                    <a
                      href={`/memory/${encodeURIComponent(target)}`}
                      className="text-[var(--accent-light)] hover:underline font-mono"
                    >
                      {target}
                    </a>
                  </div>
                );
              }
            )}
          </div>
        </div>
      )}

      {/* Metadata */}
      {Object.keys(entry.metadata).length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-sm font-semibold text-gray-300 mb-3">
            Full Metadata
          </h2>
          <pre className="text-xs text-gray-400 whitespace-pre-wrap font-mono bg-[#0a0a0a] rounded-md p-4 overflow-x-auto">
            {JSON.stringify(entry.metadata, null, 2)}
          </pre>
        </div>
      )}

      {/* Audit trail / provenance history */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <h2 className="text-sm font-semibold text-gray-300 mb-3">
          Operation History
        </h2>
        {auditEvents.length > 0 ? (
          <div className="space-y-1">
            {auditEvents.map((event, idx) => (
              <div
                key={event.id || idx}
                className="flex items-center gap-3 text-xs py-1.5 border-b border-[var(--card-border)] last:border-0"
              >
                <span
                  className={`font-mono w-16 ${
                    operationColor[event.operation] || "text-gray-400"
                  }`}
                >
                  {event.operation}
                </span>
                {event.agent_id && (
                  <span className="text-gray-500">
                    agent: {event.agent_id}
                  </span>
                )}
                {event.customer_id && (
                  <span className="text-gray-600">
                    customer: {event.customer_id}
                  </span>
                )}
                <span className="ml-auto text-gray-600">
                  {new Date(event.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500">
            No operation history available for this entry.
          </p>
        )}
      </div>
    </div>
  );
}
