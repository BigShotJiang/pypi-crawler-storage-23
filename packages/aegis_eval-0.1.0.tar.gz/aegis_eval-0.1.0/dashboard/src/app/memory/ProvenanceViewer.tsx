"use client";

import { useState } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface ProvenanceStep {
  stage: string;
  label: string;
  detail: string;
  timestamp: string;
  metadata: Record<string, unknown>;
}

interface ProvenanceChain {
  memory_key: string;
  steps: ProvenanceStep[];
}

const STAGE_COLORS: Record<string, string> = {
  source: "border-blue-500 bg-blue-900/20",
  extraction: "border-cyan-500 bg-cyan-900/20",
  embedding: "border-purple-500 bg-purple-900/20",
  storage: "border-green-500 bg-green-900/20",
  retrieval: "border-yellow-500 bg-yellow-900/20",
  reasoning: "border-orange-500 bg-orange-900/20",
  output: "border-red-500 bg-red-900/20",
};

const STAGE_DOT_COLORS: Record<string, string> = {
  source: "bg-blue-500",
  extraction: "bg-cyan-500",
  embedding: "bg-purple-500",
  storage: "bg-green-500",
  retrieval: "bg-yellow-500",
  reasoning: "bg-orange-500",
  output: "bg-red-500",
};

export default function ProvenanceViewer({
  memoryKeys,
}: {
  memoryKeys: string[];
}) {
  const [selectedKey, setSelectedKey] = useState("");
  const [customKey, setCustomKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [chain, setChain] = useState<ProvenanceChain | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set());

  async function traceProvenance() {
    const key = selectedKey || customKey;
    if (!key) return;

    setLoading(true);
    setError(null);
    setChain(null);
    setExpandedSteps(new Set());

    try {
      let res = await fetch(
        `${API_URL}/v1/memory/provenance/${encodeURIComponent(key)}`,
        { cache: "no-store" }
      );

      if (!res.ok) {
        res = await fetch(
          `${API_URL}/memory/provenance/${encodeURIComponent(key)}`,
          { cache: "no-store" }
        );
      }

      if (res.ok) {
        const data = await res.json();
        setChain(data);
      } else {
        setError("No provenance data found for this memory entry.");
      }
    } catch {
      setError("Could not connect to the API server.");
    } finally {
      setLoading(false);
    }
  }

  function toggleStep(idx: number) {
    setExpandedSteps((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) {
        next.delete(idx);
      } else {
        next.add(idx);
      }
      return next;
    });
  }

  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
      <h2 className="text-lg font-semibold mb-4">Trace Provenance</h2>
      <p className="text-xs text-gray-500 mb-4">
        Trace the full lifecycle of a memory entry: from source document through
        extraction, embedding, storage, retrieval, reasoning, and output.
      </p>

      <div className="flex flex-wrap items-end gap-3 mb-4">
        {memoryKeys.length > 0 && (
          <div>
            <label className="block text-xs text-gray-500 mb-1">
              Select Entry
            </label>
            <select
              value={selectedKey}
              onChange={(e) => {
                setSelectedKey(e.target.value);
                setCustomKey("");
              }}
              className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:border-[var(--accent)] min-w-[200px]"
            >
              <option value="">Choose a memory key...</option>
              {memoryKeys.map((key) => (
                <option key={key} value={key}>
                  {key}
                </option>
              ))}
            </select>
          </div>
        )}
        <div>
          <label className="block text-xs text-gray-500 mb-1">
            Or enter key
          </label>
          <input
            type="text"
            value={customKey}
            onChange={(e) => {
              setCustomKey(e.target.value);
              setSelectedKey("");
            }}
            placeholder="memory_key"
            className="bg-[#0a0a0a] border border-[var(--card-border)] rounded-md px-3 py-1.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[var(--accent)]"
          />
        </div>
        <button
          onClick={traceProvenance}
          disabled={(!selectedKey && !customKey) || loading}
          className="bg-[var(--accent)] hover:bg-[var(--accent-light)] disabled:opacity-50 text-white text-sm px-4 py-1.5 rounded-md transition-colors"
        >
          {loading ? "Tracing..." : "Trace"}
        </button>
      </div>

      {error && <p className="text-xs text-red-400 mb-3">{error}</p>}

      {/* Provenance chain timeline */}
      {chain && chain.steps.length > 0 && (
        <div className="mt-4">
          <div className="text-sm text-gray-400 mb-3">
            Provenance chain for{" "}
            <span className="font-mono text-[var(--accent-light)]">
              {chain.memory_key}
            </span>{" "}
            ({chain.steps.length} stages)
          </div>

          <div className="relative ml-4">
            {/* Vertical line */}
            <div className="absolute left-2 top-3 bottom-3 w-px bg-[var(--card-border)]" />

            <div className="space-y-3">
              {chain.steps.map((step, idx) => {
                const isExpanded = expandedSteps.has(idx);
                const dotColor =
                  STAGE_DOT_COLORS[step.stage] || "bg-gray-500";
                const cardColor =
                  STAGE_COLORS[step.stage] ||
                  "border-gray-500 bg-gray-900/20";

                return (
                  <div key={idx} className="relative pl-8">
                    {/* Dot on timeline */}
                    <div
                      className={`absolute left-0 top-3 w-4 h-4 rounded-full ${dotColor} border-2 border-[var(--card)]`}
                    />

                    {/* Step card */}
                    <button
                      onClick={() => toggleStep(idx)}
                      className={`w-full text-left border-l-2 ${cardColor} rounded-r-lg px-4 py-3 hover:opacity-90 transition-opacity`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-gray-400 uppercase">
                            {step.stage}
                          </span>
                          <span className="text-sm text-gray-200">
                            {step.label}
                          </span>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(step.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        {step.detail}
                      </p>
                    </button>

                    {/* Expanded metadata */}
                    {isExpanded &&
                      step.metadata &&
                      Object.keys(step.metadata).length > 0 && (
                        <div className="ml-4 mt-1 bg-[#0a0a0a] border border-[var(--card-border)] rounded-md p-3">
                          <pre className="text-[10px] text-gray-500 overflow-x-auto whitespace-pre-wrap">
                            {JSON.stringify(step.metadata, null, 2)}
                          </pre>
                        </div>
                      )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {chain && chain.steps.length === 0 && (
        <p className="text-sm text-gray-500 text-center py-4">
          No provenance steps found for this memory entry.
        </p>
      )}
    </div>
  );
}
