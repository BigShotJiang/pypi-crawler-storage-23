import MemoryTable from "@/components/MemoryTable";
import KnowledgeGraphViz from "@/components/KnowledgeGraphViz";
import AuditModePanel from "./AuditModePanel";
import ProvenanceViewer from "./ProvenanceViewer";

interface MemoryEntry {
  id: string;
  key: string;
  value: unknown;
  memory_tier: string;
  confidence: number;
  timestamp: string;
  metadata: Record<string, unknown>;
}

interface MemoryHealth {
  total_entries: number;
  tier_counts: Record<string, number>;
  [key: string]: unknown;
}

interface AuditEvent {
  id?: string;
  operation: string;
  key: string;
  agent_id?: string;
  customer_id?: string;
  timestamp: string;
  [key: string]: unknown;
}

async function getMemoryHealth(): Promise<MemoryHealth | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/memory/health`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/memory/health`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

async function getMemorySnapshot(): Promise<MemoryEntry[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  const now = new Date().toISOString();
  try {
    const res = await fetch(`${apiUrl}/v1/memory/snapshots/${now}`, {
      cache: "no-store",
    });
    if (res.ok) {
      const data = await res.json();
      return data.entries || [];
    }
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/memory/snapshots/${now}`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.entries || [];
  } catch {
    return [];
  }
}

async function getRecentAudit(): Promise<AuditEvent[]> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/v1/memory/audit`, {
      cache: "no-store",
    });
    if (res.ok) return res.json();
  } catch {
    // fall through
  }
  try {
    const res = await fetch(`${apiUrl}/memory/audit`, {
      cache: "no-store",
    });
    if (!res.ok) return [];
    return res.json();
  } catch {
    return [];
  }
}

const operationColor: Record<string, string> = {
  store: "text-green-400",
  retrieve: "text-blue-400",
  update: "text-yellow-400",
  forget: "text-red-400",
  link: "text-purple-400",
  promote: "text-cyan-400",
  demote: "text-orange-400",
  compress: "text-gray-400",
  verify: "text-lime-400",
  annotate: "text-pink-400",
  split: "text-indigo-400",
  merge: "text-teal-400",
};

export default async function MemoryPage() {
  const [health, entries, auditEvents] = await Promise.all([
    getMemoryHealth(),
    getMemorySnapshot(),
    getRecentAudit(),
  ]);

  const tierCounts = health?.tier_counts || {};
  const totalEntries = health?.total_entries || entries.length;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Memory Explorer</h1>

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Entries" value={String(totalEntries)} />
        {Object.entries(tierCounts).map(([tier, count]) => (
          <StatCard
            key={tier}
            label={tier.charAt(0).toUpperCase() + tier.slice(1)}
            value={String(count)}
          />
        ))}
        {Object.keys(tierCounts).length === 0 && (
          <>
            <StatCard label="Working" value="\u2014" />
            <StatCard label="Session" value="\u2014" />
            <StatCard label="Permanent" value="\u2014" />
          </>
        )}
      </div>

      {/* Knowledge Graph */}
      {entries.length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Knowledge Graph</h2>
          <KnowledgeGraphViz
            entries={entries.map((e) => ({
              key: e.key,
              memory_tier: e.memory_tier,
              metadata: e.metadata,
            }))}
          />
        </div>
      )}

      {/* Memory entries table */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4">Memory Entries</h2>
        {entries.length > 0 ? (
          <MemoryTable entries={entries} />
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-400 mb-2">No memory entries yet.</p>
            <p className="text-sm text-gray-600">
              Use{" "}
              <code className="text-[var(--accent-light)]">
                POST /v1/memory/store
              </code>{" "}
              or emit memory events to populate the store.
            </p>
          </div>
        )}
      </div>

      {/* Point-in-Time Audit */}
      <AuditModePanel />

      {/* Provenance Viewer */}
      <ProvenanceViewer memoryKeys={entries.map((e) => e.key)} />

      {/* Recent operations */}
      <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-6">
        <h2 className="text-lg font-semibold mb-4">Recent Operations</h2>
        {auditEvents.length > 0 ? (
          <div className="space-y-1 max-h-80 overflow-y-auto">
            {auditEvents.slice(0, 50).map((event, idx) => (
              <div
                key={event.id || idx}
                className="flex items-center gap-3 text-xs py-1.5 border-b border-[var(--card-border)] last:border-0"
              >
                <span
                  className={`font-mono w-16 ${
                    operationColor[event.operation] || "text-gray-400"
                  }`}
                >
                  {event.operation}
                </span>
                <a
                  href={`/memory/${encodeURIComponent(event.key)}`}
                  className="text-[var(--accent-light)] hover:underline font-mono"
                >
                  {event.key}
                </a>
                {event.agent_id && (
                  <span className="text-gray-600">
                    agent: {event.agent_id}
                  </span>
                )}
                <span className="ml-auto text-gray-600">
                  {new Date(event.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-500 text-center py-4">
            No operations recorded yet. Memory operations will appear here as
            they occur.
          </p>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-4">
      <div className="text-xs text-gray-500 mb-1">{label}</div>
      <div className="text-xl font-bold">{value}</div>
    </div>
  );
}
