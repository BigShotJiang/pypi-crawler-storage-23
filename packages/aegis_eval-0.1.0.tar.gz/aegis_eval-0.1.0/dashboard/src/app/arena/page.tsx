interface ArenaEntry {
  rank: number;
  agent_id: string;
  agent_name: string;
  framework: string;
  overall_score: number;
  dimension_count: number;
  domain_scores: Record<string, number>;
  elo_rating: number;
}

interface ArenaLeaderboardResponse {
  generated_at: string;
  total_entries: number;
  entries: ArenaEntry[];
}

const SORT_OPTIONS: Array<{ key: string; label: string }> = [
  { key: "aggregate", label: "Overall" },
  { key: "dimension", label: "Dimension Avg" },
  { key: "domain", label: "Domain Score" },
];

async function getArenaLeaderboard(
  sortBy: string,
): Promise<ArenaLeaderboardResponse | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(
      `${apiUrl}/v1/arena/leaderboard?sort_by=${encodeURIComponent(sortBy)}`,
      {
        cache: "no-store",
      },
    );
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

type ArenaPageProps = {
  searchParams?: Promise<{
    sort?: string;
  }>;
};

export default async function ArenaPage({
  searchParams,
}: ArenaPageProps) {
  const resolved = (await searchParams) ?? {};
  const sort = resolved.sort ?? "aggregate";
  const data = await getArenaLeaderboard(sort);
  const entries = data?.entries ?? [];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Arena Leaderboard</h1>
        <div className="flex items-center gap-2 text-sm">
          {SORT_OPTIONS.map((option) => (
            <a
              key={option.key}
              href={`/arena?sort=${option.key}`}
              className={`px-3 py-1 rounded-md border ${
                sort === option.key
                  ? "bg-[var(--accent)] text-white border-[var(--accent)]"
                  : "border-[var(--card-border)] hover:bg-[var(--card)]"
              }`}
            >
              {option.label}
            </a>
          ))}
        </div>
      </div>

      {entries.length === 0 ? (
        <div className="bg-[var(--card)] border border-[var(--card-border)] rounded-lg p-8 text-center">
          <p className="text-gray-300 mb-2">No arena submissions yet.</p>
          <p className="text-sm text-gray-500">
            Submit an agent via{" "}
            <code className="text-[var(--accent-light)]">POST /v1/arena/submit</code>.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[var(--card-border)]">
          <table className="w-full text-sm">
            <thead className="bg-[var(--card)] text-left text-gray-400">
              <tr>
                <th className="px-4 py-3">Rank</th>
                <th className="px-4 py-3">Agent</th>
                <th className="px-4 py-3">Framework</th>
                <th className="px-4 py-3">Overall</th>
                <th className="px-4 py-3">ELO</th>
                <th className="px-4 py-3">Dimensions</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <tr
                  key={entry.agent_id}
                  className="border-t border-[var(--card-border)] hover:bg-[var(--card)]/60"
                >
                  <td className="px-4 py-3 font-mono">#{entry.rank}</td>
                  <td className="px-4 py-3">
                    <span>{entry.agent_name || entry.agent_id.slice(0, 8)}</span>
                    <span className="ml-2 text-xs text-gray-500 font-mono">
                      {entry.agent_id.slice(0, 8)}
                    </span>
                  </td>
                  <td className="px-4 py-3">{entry.framework}</td>
                  <td className="px-4 py-3 font-semibold">
                    {(entry.overall_score * 100).toFixed(1)}%
                  </td>
                  <td className="px-4 py-3">{entry.elo_rating.toFixed(2)}</td>
                  <td className="px-4 py-3">{entry.dimension_count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
