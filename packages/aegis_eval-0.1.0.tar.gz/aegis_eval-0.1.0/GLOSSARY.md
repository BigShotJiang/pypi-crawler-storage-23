# Aegis Glossary

- **Aegis Eval**: The evaluation subsystem that scores agent behavior across capability and safety dimensions.
- **Aegis Train**: The training subsystem that improves agents using staged reinforcement learning workflows.
- **Aegis Memory**: The memory subsystem that stores, retrieves, and transforms long-lived agent knowledge.
- **AMIR-GRPO**: Adaptive Multi-stage Iterative Reward GRPO training approach used in Aegis.
- **GRPO-SG**: Staged-gating variant of GRPO that progressively unlocks policy capabilities.
- **PODS**: Promotion and rollback decision gates based on eval regressions and safety criteria.
- **Observatory**: Monitoring subsystem for reward integrity, drift, anomalies, and runtime health.
- **TrajectoryV1**: Canonical step-by-step execution trace schema used across adapters and evaluation.
- **JudgePacketV1**: Triangulated scoring record containing rule, semantic, and LLM-judge signals.
- **Tier**: One level in the seven-tier intelligence hierarchy used to organize dimensions.
- **Dimension**: A single measurable capability/safety criterion evaluated for an agent.
- **Triangulated Scoring**: Score composition from rule-based, semantic, and LLM-judge components.
- **Domain Plugin**: Extension package that contributes domain-specific dimensions and case generation.
- **Replay Buffer**: Training component that reuses past trajectories for sample efficiency and stability.
- **EWC**: Elastic Weight Consolidation regularization to mitigate catastrophic forgetting.
- **Reward Integrity**: Mechanisms that detect and penalize reward hacking behavior.
