# Scoring

Aegis uses **triangulated scoring** to evaluate each dimension through three independent backends. This reduces single-method bias and produces calibrated results.

## Three scoring backends

### 1. Rule-Based Scorer

Deterministic checks that produce binary or continuous scores. Always works, no external dependencies.

**Rule types:**

| Rule | Description |
|------|-------------|
| `exact_match` | Case-insensitive exact match |
| `contains` | Substring presence check |
| `not_contains` | Negative substring assertion |
| `regex` | Regular expression pattern match |
| `json_field_match` | Extract and compare a field from dict ground truth |
| `json_field_present` | Check if a field name exists |
| `numeric_range` | Validate a number falls within min/max bounds |
| `length_range` | Check output length constraints |
| `fuzzy_match` | SequenceMatcher similarity ratio |
| `all_of` | AND composition (average of sub-rules) |
| `any_of` | OR composition (max of sub-rules) |

### 2. Semantic Scorer

Embedding-based similarity using `sentence-transformers`. Captures meaning beyond exact text matches.

- Lazily loads the embedding model on first use
- Falls back to `0.0` if `sentence-transformers` is not installed
- Install with: `pip install aegis-eval[scoring]`

### 3. LLM Judge

Sends the agent output and ground truth to an LLM with a structured rubric prompt. The judge returns a JSON score with reasoning.

- Supports **OpenAI** (`gpt-4o`, `o1-*`, etc.) and **Anthropic** (`claude-*`) backends
- Auto-detects provider from model name
- Falls back to a deterministic mock backend when no API key is set
- Includes automatic retry with exponential backoff on transient failures (429, 5xx)

## Triangulated ensemble

The `TriangulatedJudge` combines all three scores into a weighted ensemble:

```
ensemble = w_rule * rule_score + w_semantic * semantic_score + w_llm * llm_score
```

Default weights are equal (`1/3` each). The judge also computes a **disagreement signal** (standard deviation of the three scores) to flag dimensions where scorers diverge significantly.

## Output: JudgePacketV1

Each dimension evaluation produces a `JudgePacketV1` containing:

| Field | Type | Description |
|-------|------|-------------|
| `rule_score` | float | Rule-based scorer result |
| `semantic_score` | float | Semantic similarity result |
| `judge_scores` | dict | LLM judge scores (supports multi-judge ensemble) |
| `ensemble_score` | float | Final weighted score in [0.0, 1.0] |
| `disagreement` | float | Scorer divergence signal (0 = unanimous, 1 = max) |
| `explanation` | str | Human-readable score breakdown |
| `evidence` | list | Supporting evidence from the evaluation |

## Diagnostic reports

After scoring, Aegis generates a diagnostic report with:

- Tier-level score aggregation
- Weak and strong dimension identification
- Root cause analysis (systematic tier weakness, cascading issues, high variance)
- Training focus recommendations (top 3 dimensions to improve)
