# Launching Aegis: The Adaptive Intelligence Layer for AI Agents

Aegis is now available as an open-source framework for evaluating, training, and memory-enabling AI agents.

## Why We Built Aegis

Most agent systems can answer prompts, but they struggle to:

- improve from feedback over time,
- preserve high-fidelity memory across long workflows,
- and prove progress with robust, repeatable evaluation.

Aegis addresses this with one integrated stack:

- **Aegis Eval** for capability and safety measurement,
- **Aegis Train** for staged RL-based improvement loops,
- **Aegis Memory** for durable, auditable memory operations.

## What’s in the First Release

- 7-tier eval hierarchy with core and domain dimensions
- Triangulated scoring (rule-based, semantic, and LLM judge)
- Adapter layer for popular agent frameworks
- FastAPI + CLI surfaces for local and service usage
- Memory operations with provenance-aware event logging

## Getting Started

```bash
pip install aegis-eval
aegis eval dimensions
aegis eval run --config examples/eval.yaml
```

## Who Should Use Aegis

- teams shipping production copilots/agents,
- research groups studying learning-in-the-loop systems,
- platform teams that need auditable agent quality gates.

## What’s Next

- deeper optimizer integrations for GPU training workflows,
- expanded benchmark suites for legal/finance environments,
- richer production deployment templates (cloud + k8s),
- community plugin ecosystem for new domains.
