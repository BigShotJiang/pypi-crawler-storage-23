# API Docs

This section is generated from source docstrings using `mkdocstrings`.

The pages below document the public runtime interfaces used by:

- `aegis` CLI flows
- FastAPI server routes
- Evaluation and training pipelines
- Adapter integrations

Use this reference when implementing integrations or extending Aegis internals.
