# Core Types

::: aegis.core.types
