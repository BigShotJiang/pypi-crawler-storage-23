# Adapters

::: aegis.adapters.openai

::: aegis.adapters.anthropic

::: aegis.adapters.langchain

::: aegis.adapters.llamaindex

::: aegis.adapters.langgraph

::: aegis.adapters.dspy

::: aegis.adapters.rest
