# Domain Plugins

Plugins extend Aegis Eval with industry-specific dimensions and scoring criteria. They are auto-discovered via Python entry points.

## Built-in plugins

### Legal (18 dimensions)

Evaluates agents on legal-domain capabilities: clause retention, precedent tracking, citation validity, confidentiality boundary enforcement, jurisdictional awareness, statutory interpretation, and more.

```bash
aegis eval run --domain legal
```

### Finance (20 dimensions)

Evaluates agents on financial-domain capabilities: numerical retention, FINRA/SEC compliance verification, materiality judgment, portfolio context tracking, risk factor memory, earnings data accuracy, and more.

```bash
aegis eval run --domain finance
```

### Safety (12 dimensions)

Evaluates agents on safety and adversarial resilience: prompt injection detection, PII leakage prevention, privilege boundary enforcement, jailbreak resistance, data exfiltration detection, and more.

```bash
aegis eval run --domain safety
```

## Using plugins in config

```yaml
eval:
  domain_plugins:
    - legal
    - finance
```

## Creating a custom plugin

1. Create a class extending `DomainPlugin`:

```python
from aegis.plugins.base import DomainPlugin
from aegis.eval.dimensions.base import Dimension
from aegis.core.types import EvalTier, ScorerType, Phase


class MyDomainPlugin(DomainPlugin):
    @property
    def name(self) -> str:
        return "my_domain"

    @property
    def description(self) -> str:
        return "My custom domain plugin"

    def get_dimensions(self) -> list[Dimension]:
        return [
            # Return your custom Dimension instances
        ]
```

2. Register the entry point in your `pyproject.toml`:

```toml
[project.entry-points."aegis.plugins"]
my_domain = "my_package.plugin:MyDomainPlugin"
```

3. Install your package and the plugin dimensions are available automatically:

```bash
aegis eval dimensions --domain my_domain
```

## Plugin case loading

Plugins can load test cases from local files. Supported formats:

- `.jsonl` -- one JSON object per line
- `.json` -- array of objects
- `.csv` -- tabular test cases
- Directory of text files -- one case per file

Configure the source in your eval config:

```yaml
eval:
  scenarios:
    source: ./my_cases/legal_tests.jsonl
```
