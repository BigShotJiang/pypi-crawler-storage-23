# AEGIS — Technical Architecture Document
## The Adaptive Intelligence Layer for AI Agents
### Metronis, Inc. · v2.0 · February 2026

---

# TABLE OF CONTENTS

1. [Executive Summary](#1-executive-summary)
2. [System Architecture Overview](#2-system-architecture-overview)
3. [Phase 1 Scope: Eval MVP](#3-phase-1-scope-eval-mvp)
4. [Core Subsystems](#4-core-subsystems)
   - 4.1 Data Ingestion Layer
   - 4.2 Memory System
   - 4.3 Retrieval & Context Layer
   - 4.4 RL Training Engine
   - 4.5 Observatory
   - 4.6 Eval Suite (aegis-eval)
   - 4.7 Governance & Compliance Layer
5. [Product Surfaces](#5-product-surfaces)
6. [Integration Architecture](#6-integration-architecture)
7. [Data Model](#7-data-model)
8. [API Surface](#8-api-surface)
9. [SDK Design](#9-sdk-design)
10. [Extension & Plugin Architecture](#10-extension--plugin-architecture)
11. [Technology Stack](#11-technology-stack)
12. [Compute Strategy](#12-compute-strategy)
13. [Build Sequence](#13-build-sequence)
14. [Competitive Position](#14-competitive-position)
15. [Production Monitoring & Online Evaluation](#15-production-monitoring--online-evaluation)
16. [Architectural Risks & Mitigations](#16-architectural-risks--mitigations)
17. [Frontier Execution Plan](#17-frontier-execution-plan)
18. [API Versioning & Public Types](#18-api-versioning--public-types)
19. [Evaluation & Research-Update Program](#19-evaluation--research-update-program)
20. [Release-Gating Test Scenarios](#20-release-gating-test-scenarios)
21. [Promotion & Rollout Rules](#21-promotion--rollout-rules)
22. [Team & Ownership Model](#22-team--ownership-model)
23. [Research Foundation](#23-research-foundation)

---

# 1. EXECUTIVE SUMMARY

## The Problem

Every company deploying AI agents faces the same problem: the agent works OK on day one but never gets better. Agents are stateless — they don't remember, don't learn from mistakes, don't develop professional judgment, and don't improve with experience. Nobody can even measure whether they're good at their job.

Generic eval frameworks (DeepEval, RAGAS, LangSmith, Arize, Braintrust) miss critical industry-specific failures. They ask "is this answer relevant?" when they should ask "would this hold up in an audit?" or "does this citation exist in this jurisdiction?" Traditional evals suffer from metric gaming and distribution shift blindness, making failures invisible until they cause real-world damage.

## The Solution

**Aegis** is four products on one platform:

| Product | What It Does | Model |
|---------|-------------|-------|
| **Aegis Eval** | Measures agent intelligence across 50+ dimensions (capability + safety). Produces diagnostic reports explaining not just scores but WHY failures occur and WHAT to train on. Open-source core, domain-specific rubric packs, security/adversarial testing. | Free / open-source wedge |
| **Aegis Train** | Takes an eval diagnostic and produces a better agent. RL training across 7 capability levels with real-time Observatory monitoring, automatic intervention on reward hacking, and LoRA adapters that prove improvement with before/after scores. | Enterprise SaaS revenue |
| **Aegis Memory** | Managed memory infrastructure for any agent. Domain-optimized architectures, runtime learning, multi-agent shared memory, full governance and audit trail. | Infrastructure lock-in |
| **Aegis Environments** | Domain-specific RL training environments for regulated verticals. Reusable, versioned simulation scenarios (legal contract review, SEC audit, compliance monitoring) with built-in ground truth and reward signals. Environment-as-a-Service. | High-margin licensing |

## The Flywheel

```
EVAL generates leads (free/open-source, everyone uses it)
  → ENVIRONMENTS monetize domain expertise (RL env marketplace)
    → TRAIN converts to revenue (enterprise, pay for improvement)
      → MEMORY creates lock-in (infrastructure, deepening value)
        → Every customer's data improves the network
          → Next customer onboards faster, gets better results
            → Architecture discoveries compound across the network
```

## The Position

Nobody occupies the intersection of memory management + RL training + domain evals. Every competitor does one thing:

- Harvey does answers (no RL, no learned memory)
- Letta does memory (heuristic, not RL-trained)
- Contextual AI does retrieval (no persistent memory)
- Agent Lightning does training (no memory, no domain evals)
- Braintrust/Arize does monitoring (no training, no improvement loop)

**Aegis does the LOOP:** eval → diagnose → train → improve → monitor → re-eval.

---

# 2. SYSTEM ARCHITECTURE OVERVIEW

## Locked Decisions

| # | Decision | Detail |
|---|----------|--------|
| 1 | **Primary objective** | Frontier research leadership with production viability |
| 2 | **Scope** | Full-loop v1 (eval, memory, retrieval/context, RL, observability, governance) from the start |
| 3 | **Team model** | Well-funded execution (12-16 FTE) |
| 4 | **Model strategy** | Multi-model stack with regular bake-offs. No single-model lock-in. |
| 5 | **Deployment boundary** | Hybrid + BYOC (Bring Your Own Compute) |
| 6 | **Eval authority** | Programmatic + model judges + human gate for promotions |
| 7 | **Domain focus** | Legal + Finance |
| 8 | **Release cadence** | Monthly releases; scope can move but release date does not |

## Deployment Architecture (Control Plane / Data Plane)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CONTROL PLANE (Aegis-Hosted)                         │
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Eval        │  │  Model       │  │  Policy      │  │  Benchmark   │   │
│  │  Scheduling  │  │  Registry    │  │  Registry    │  │  Registry    │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Promotion   │  │  Drift       │  │  Dashboard   │  │  API         │   │
│  │  Engine      │  │  Detection   │  │  & Reporting │  │  Gateway     │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                            Secure gRPC / mTLS
                                    │
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DATA PLANE (Customer VPC / On-Prem)                       │
│                                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Data        │  │  Memory      │  │  Training    │  │  Secured     │   │
│  │  Ingestion   │  │  Store       │  │  Rollouts    │  │  Inference   │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                             │
│  Customer data NEVER leaves this boundary. Only metrics, scores, and        │
│  adapter weights (encrypted) transit to control plane.                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Full Platform Architecture

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                              AEGIS PLATFORM                                  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     A. DATA INGESTION LAYER                            │  │
│  │                                                                        │  │
│  │  Text ──┐                                                              │  │
│  │  PDF ───┤                                                              │  │
│  │  DOCX ──┤    ┌──────────────┐    ┌──────────────┐    ┌─────────────┐  │  │
│  │  XLSX ──┤───→│  Document    │───→│  Multimodal  │───→│  Knowledge  │  │  │
│  │  Images─┤    │  Parser      │    │  Embedder    │    │  Store      │  │  │
│  │  Scans ─┤    │  (per-type)  │    │  (unified)   │    │  (hybrid)   │  │  │
│  │  HTML ──┤    └──────────────┘    └──────────────┘    └─────────────┘  │  │
│  │  Email ─┤                                                              │  │
│  │  Audio ─┤    ┌──────────────┐    ┌──────────────┐    ┌─────────────┐  │  │
│  │  Video ─┘───→│  OCR /       │───→│  Table       │───→│  Entity     │  │  │
│  │              │  Transcribe  │    │  Extractor   │    │  Linker     │  │  │
│  │              └──────────────┘    └──────────────┘    └─────────────┘  │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     B. MEMORY SYSTEM                                    │  │
│  │                                                                        │  │
│  │  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────────────┐  │  │
│  │  │ WORKING MEMORY  │  │ SESSION MEMORY  │  │ PERMANENT MEMORY     │  │  │
│  │  │                 │  │                 │  │                      │  │  │
│  │  │ Current task    │  │ This deal/case  │  │ Domain knowledge     │  │  │
│  │  │ Active chains   │  │ KG: entities +  │  │ Precedents           │  │  │
│  │  │ In-context      │  │ relationships   │  │ Regulations          │  │  │
│  │  │ window mgmt     │  │ Temporal edges  │  │ Git-versioned        │  │  │
│  │  │                 │  │ Session-scoped  │  │ Compliance-auditable │  │  │
│  │  └────────┬────────┘  └────────┬────────┘  └──────────┬───────────┘  │  │
│  │           └────────────────────┼───────────────────────┘              │  │
│  │                                ▼                                      │  │
│  │                    MEMORY POLICY ENGINE (RL-learned)                  │  │
│  │                    12 Operations: STORE / UPDATE / FORGET /           │  │
│  │                    RETRIEVE / LINK / COMPRESS / PROMOTE / DEMOTE /   │  │
│  │                    SPLIT / MERGE / VERIFY / ANNOTATE                 │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     C. RETRIEVAL & CONTEXT LAYER                       │  │
│  │                                                                        │  │
│  │  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐            │  │
│  │  │ Vector DB │ │ Knowledge │ │ SQL / API │ │ Web /     │            │  │
│  │  │ (dense)   │ │ Graph     │ │ (struct)  │ │ Browser   │            │  │
│  │  └─────┬─────┘ └─────┬─────┘ └─────┬─────┘ └─────┬─────┘            │  │
│  │        └──────────────┼─────────────┼─────────────┘                   │  │
│  │                       ▼             ▼                                  │  │
│  │             RETRIEVAL POLICY (RL-learned)                             │  │
│  │             - Dynamic depth (1-50 docs per query)                     │  │
│  │             - Source routing (which backend for this query?)           │  │
│  │             - Re-query decision (enough context or search again?)     │  │
│  │             - Internal vs external knowledge balancing                │  │
│  │             - Multimodal routing (text vs table vs image retrieval)   │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     D. RL TRAINING ENGINE                              │  │
│  │                                                                        │  │
│  │  Task Generator ──→ Rollout Engine ──→ Reward Engine ──→ Optimizer    │  │
│  │                                                                        │  │
│  │  Rollout format:                                                      │  │
│  │    <think> → <memory_op> → <search> → <evidence> → <reason> → <answer>│  │
│  │                                                                        │  │
│  │  Reward: Per-stage process rewards (7 legal / 8 finance stages)       │  │
│  │          Three signals per stage: rule + semantic + LLM-judge         │  │
│  │                                                                        │  │
│  │  Optimizer: GRPO (primary) / DrGRPO / DAPO / GiGPO / PPO             │  │
│  │             LoRA training (customer-isolated adapters)                 │  │
│  │             Anti-forgetting (EWC + experience replay)                  │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     E. OBSERVATORY                                     │  │
│  │                                                                        │  │
│  │  Training Stability    Memory Behavior      Reward Integrity           │  │
│  │  - Reward variance     - Bank size/churn    - Proxy vs gold diverge   │  │
│  │  - Policy entropy      - Op distribution    - Behavioral anomalies    │  │
│  │  - Gradient norms      - Retrieval diversity- Adversarial probes      │  │
│  │  - KL divergence       - Dead memory %      - Length/citation gaming  │  │
│  │  - Loss curves         - Promotion rate     - Sycophancy drift        │  │
│  │                                                                        │  │
│  │  Auto-Interventions:                                                  │  │
│  │  - Inject diverse prompts on entropy collapse                         │  │
│  │  - Rollback on gradient spikes                                        │  │
│  │  - Goodhart early stopping on divergence                              │  │
│  │  - Reduce memory reward weight on memory gaming                       │  │
│  │  - Increase citation weight on validity decline                       │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     F. EVAL SUITE (aegis-eval)                         │  │
│  │                                                                        │  │
│  │  6-Tier Hierarchy       Legal Plugin (18 dims)  Finance Plugin (20)   │  │
│  │  - Memory Fidelity      - Clause retention      - Numerical retention │  │
│  │  - Context Intelligence - Citation validity     - Cross-doc reconcile │  │
│  │  - Learning Dynamics    - Jurisdiction acc      - Market data currency │  │
│  │  - Reasoning Quality    - Supersession track    - Materiality detect  │  │
│  │  - Meta-Cognition       - Risk assessment       - Audit trail         │  │
│  │  - Collaborative Ctx    - Bias/fairness         - Fair lending        │  │
│  │                                                                        │  │
│  │  Output: score + failure analysis + root cause + training curriculum   │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                     G. GOVERNANCE & COMPLIANCE LAYER                   │  │
│  │                                                                        │  │
│  │  - Customer-isolated training environments (K8s namespaces)           │  │
│  │  - Differential privacy for LoRA adapters (Opacus DP-SGD)            │  │
│  │  - Complete provenance chain (source → training signal → behavior)    │  │
│  │  - Immutable audit trail for every memory operation                   │  │
│  │  - Git-versioned memory state (point-in-time reconstruction)          │  │
│  │  - RBAC + ABAC access control                                        │  │
│  │  - Compliance: SOC 2, ISO 27001, FINRA, EU AI Act                    │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

# 3. PHASE 1 SCOPE: EVAL MVP

Phase 1 (Weeks 1-4) builds **aegis-eval only**. The full platform vision above is the end state. Phase 1 delivers a working CLI and Python SDK that evaluates any LLM agent and produces a scored diagnostic report.

## Phase 1 Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     AEGIS-EVAL (Phase 1)                        │
│                                                                 │
│  ┌───────────────┐   ┌──────────────────┐   ┌───────────────┐  │
│  │ INPUT         │   │ EVAL ENGINE      │   │ OUTPUT        │  │
│  │               │   │                  │   │               │  │
│  │ Agent adapter │──→│ Metric runners   │──→│ JSON report   │  │
│  │ (any agent)   │   │ (40+ dimensions) │   │ HTML report   │  │
│  │               │   │                  │   │ PDF export    │  │
│  │ YAML config   │   │ Domain plugins   │   │ Diagnostic    │  │
│  │ (test suite)  │   │ (legal/finance)  │   │ (root cause + │  │
│  │               │   │                  │   │  what to fix) │  │
│  └───────────────┘   │ Scoring pipeline │   └───────────────┘  │
│                      │ - Rule-based     │                       │
│                      │ - Semantic       │                       │
│                      │ - LLM-as-judge   │                       │
│                      └──────────────────┘                       │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ INTEGRATION ADAPTERS                                     │   │
│  │ LangChain │ LlamaIndex │ CrewAI │ AutoGen │ OpenAI      │   │
│  │ Anthropic │ Custom REST                                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ CLI: aegis eval run --config eval.yaml                   │   │
│  │ SDK: from aegis import Evaluator                         │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Phase 1 Deliverables

| # | Deliverable | Description |
|---|------------|-------------|
| D4 | This document | Technical architecture for full platform, Phase 1 scoped to eval |
| D6 | `aegis-eval` repo | Public GitHub repo, pip-installable, Apache 2.0 |
| D7 | Core metrics suite | 40+ evaluation dimensions across 6 tiers |
| D8 | CLI tool | `aegis eval run --config eval.yaml` |
| D9 | Python SDK | `from aegis import Evaluator` |
| D10 | Integration adapters | LangChain, LlamaIndex, CrewAI, AutoGen, OpenAI, Anthropic, REST |
| D11 | Test suite | >80% coverage, GitHub Actions CI/CD |
| D12 | Docs site | docs.aegis.dev |
| D13 | Quickstart tutorial | "Evaluate your agent in 5 minutes" |
| D14 | Example projects | 3-5 pre-built evaluation suites |
| D15 | Demo video | 2-3 minute screen recording |

## Phase 1 Boundaries

**In scope:**
- Eval framework core (all 40+ metrics)
- CLI + SDK + adapters
- Legal domain plugin (18 dimensions)
- Financial domain plugin (20 dimensions)
- Diagnostic output (failure analysis + training focus recommendations)
- JSON/HTML/PDF report generation
- CI/CD integration support

**Out of scope (future phases):**
- RL training engine (Phase 5)
- Memory infrastructure (Phase 4)
- Observatory (Phase 5)
- Web dashboard (Phase 3)
- Governance layer (Phase 4)

---

# 4. CORE SUBSYSTEMS

## 4.1 Data Ingestion Layer

Handles all input modalities, converting raw data into the unified knowledge store.

### 7 Input Modalities

| Modality | Technology | Purpose |
|----------|-----------|---------|
| **Text** | Direct parsing | Contracts, filings, memos, briefs, structured data (JSON, XBRL), code |
| **Tables** | LayoutXLM + Camelot + Qwen3-VL | Financial statements, contract comparisons, regulatory matrices |
| **Documents** | Docling (IBM) / Unstructured.io | PDF/DOCX/XLSX parsing, multi-page navigation |
| **Images** | Qwen3-VL-Embedding | Charts, diagrams, scanned signatures, screenshots |
| **Audio** | Whisper v3 | Earnings calls, depositions, meetings → text → pipeline |
| **Video** | Keyframe extraction + transcription | Regulatory hearings, depositions → multimodal memory |
| **Web** | Playwright / Browser-Use | SEC EDGAR, court dockets, regulatory databases, real-time data |

### Parsing Pipeline

```
Raw Document
  │
  ├─→ Docling (PDF/DOCX/XLSX/HTML/Images)
  │     ├─→ Text chunks (with clause boundary detection)
  │     ├─→ Tables (structured JSON with headers preserved)
  │     └─→ Images (extracted for visual embedding)
  │
  ├─→ Tesseract + EasyOCR (scanned documents)
  │     └─→ Text (with confidence scores)
  │
  ├─→ Camelot + LayoutXLM + Qwen3-VL (financial tables)
  │     └─→ Structured table data (row/col headers, numeric types)
  │
  ├─→ Whisper v3 (audio)
  │     └─→ Timestamped transcript → text pipeline
  │
  └─→ Playwright (web)
        └─→ Structured page content → text pipeline
```

### Embedding Pipeline

All modalities embed into a unified vector space via **Qwen3-VL-Embedding**, enabling cross-modal retrieval (search text, find relevant table; search for concept, find relevant chart).

```
Text chunks     ──→ Qwen3-VL-Embedding ──→ 1024-dim vectors ──→ pgvector
Tables          ──→ table-aware embedding ──→ pgvector
Images          ──→ vision embedding ──→ pgvector
All in unified vector space (searchable together)
```

---

## 4.2 Memory System

### 7 Memory Types

| Type | What It Stores | Example |
|------|---------------|---------|
| **Factual** | Entities, relationships, temporal facts, numbers with provenance | "Section 12.1 caps liability at $600K (valid 2017-2019)" |
| **Experiential** | Task trajectories, strategies tried, outcomes, utility scores | "Broad FM clause search worked in deal #12, scored 0.91" |
| **Procedural** | How to perform tasks, when to apply which procedure | "For M&A due diligence: triage first, then contracts, then IP" |
| **Semantic** | Domain concepts, principles, heuristics, exceptions | "Counterparties typically resist indemnity caps above 10%" |
| **Strategic** | Plans, priorities, resource allocation models | "This deal: focus 60% on regulatory risk, 20% IP, 20% contracts" |
| **Social** | Models of other agents, trust scores, collaboration state | "Legal agent flagged patent suit — integrate into financial model" |
| **Working** | Current goals, active hypotheses, reasoning in progress | "Testing whether amendment applies retroactively" |

### 7 Time Horizons

| Horizon | Scope | Retention Policy |
|---------|-------|-----------------|
| **Sub-second** | Within a reasoning chain | Managed by context window |
| **Turn-level** | Across conversation turns | Accumulates within session |
| **Session-level** | Multi-hour work session | Persists during task completion |
| **Engagement-level** | Days/weeks of a deal or case | Evolves across sessions, auto-consolidates |
| **Client-level** | All engagements with same client | Preferences, standards, risk tolerance |
| **Domain-level** | All engagements in a domain | General patterns, institutional knowledge |
| **Meta-level** | Agent's own behavioral history | What it used to get wrong, what triggered corrections |

### 4 Memory Tiers

| Tier | Storage | Scope | Management |
|------|---------|-------|-----------|
| **Working** | In-context window | Current task, active reasoning | Context window management |
| **Session** | pgvector + Neo4j KG | This engagement (deal/case), entities + temporal edges | Session-scoped, auto-consolidates |
| **Permanent** | Git-versioned repository | Domain knowledge, precedents, regulations | Compliance-auditable, point-in-time reconstruction |
| **Weight** (future) | TTT-compressed into model parameters | Deeply learned patterns | Test-Time Training integration |

### 12 RL-Trained Memory Operations

| Operation | What It Does |
|-----------|-------------|
| **STORE** | Add new information to appropriate tier |
| **UPDATE** | Modify existing memory with new information |
| **FORGET** | Remove outdated or irrelevant information |
| **RETRIEVE** | Find and return relevant memories for current task |
| **LINK** | Create connections between related memories across documents/sessions |
| **COMPRESS** | Condense multiple related entries into denser representation |
| **PROMOTE** | Move memory from working → session → permanent |
| **DEMOTE** | Move memory from permanent → archive when outdated |
| **SPLIT** | Separate a composite memory into independent retrievable units |
| **MERGE** | Combine always-co-retrieved memories for efficiency |
| **VERIFY** | Check a stored memory against current sources before use |
| **ANNOTATE** | Add metadata (confidence, temporal scope, source quality) without changing content |

Each operation is scored for correctness, faithfulness, and utility by the three-signal reward architecture.

### Architecture Discovery (ALMA-Inspired)

Aegis doesn't just use a fixed memory architecture — it discovers the **optimal** architecture for each customer's domain via a meta-agent:

1. Meta-agent receives: customer's domain, sample tasks, performance criteria
2. Proposes memory architectures as executable Python code (database schemas + retrieval mechanisms + update rules)
3. Each architecture evaluated against the customer's task distribution
4. Archive of architectures grows over time via open-ended evolutionary search
5. Best architectures refined; cross-domain insights compose

**The moat:** After 200+ domains, Aegis has a searchable library of memory designs. New customers get: "Your domain is most similar to {legal research + scientific discovery}. Here's a hybrid architecture."

### Sleep-Time Consolidation

During idle periods, memory is consolidated:
- Pattern abstraction from specific episodes
- Memory compression (reduce footprint, preserve critical info)
- Link discovery (find connections not obvious at storage time)
- Decay application (reduce utility scores for unaccessed memories)
- Consistency checking (detect/flag contradictions)

### Two-Speed Learning (MemRL-Inspired)

| | Training-Time (Offline) | Runtime (Online) |
|---|---|---|
| **Method** | GRPO/PPO on curated tasks | Q-value updates on episodic memory |
| **What changes** | LoRA adapter weights | Memory utility scores, experience archive |
| **Timescale** | Hours to days | After each interaction |
| **What it learns** | Deep capabilities | Tactical adaptation |
| **GPU cost** | Significant | Zero (CPU only) |

Training-time gives deep capabilities. Runtime adapts to specific deployment. Runtime discoveries feed back into next training cycle. Continuous improvement spiral.

---

## 4.3 Retrieval & Context Layer

### Hybrid Retrieval Architecture

```
User Query
  │
  ▼
RETRIEVAL POLICY (RL-learned)
  │
  ├─→ Vector DB (pgvector) ── dense semantic search
  ├─→ Knowledge Graph (Neo4j) ── entity relationships, temporal edges
  ├─→ SQL / API ── structured data, financial databases
  └─→ Web / Browser (Playwright) ── real-time data
  │
  ▼
RERANKER (Qwen3-VL-Reranker)
  │
  ▼
CONTEXT CONSTRUCTION (RL-learned)
  ├─→ Context selection (which retrieved items go into prompt)
  ├─→ Context ordering (maximize reasoning quality)
  ├─→ Context budgeting (how much per modality)
  ├─→ Context compression (summarize without losing critical info)
  └─→ Negative context (what is NOT true, for temporal reasoning)
```

### RL-Trained Retrieval Behaviors

- **Dynamic depth:** Agent learns a distribution over retrieval depth per query (1-50 documents). Some queries need zero retrieval.
- **Source routing:** Agent learns to route to optimal backend per query type. Legal citations → KG. Financial numbers → XBRL/SQL. Trends → web.
- **Anti-retrieval:** Agent learns when retrieval would hurt (noisy sources, outdated results) and trusts parametric knowledge.
- **Iterative retrieval with learned termination:** Retrieve → evaluate → retrieve more (or stop). Number of rounds is a learned variable.

---

## 4.4 RL Training Engine

### 7 Levels of RL Training

| Level | What It Trains | Key Behaviors |
|-------|---------------|---------------|
| **1. Memory Operations** | Right operation at right time | 12 operations across 4 tiers |
| **2. Retrieval Policy** | Right info, right amount, right source | Dynamic depth, source routing, anti-retrieval |
| **3. Context Construction** | Optimal prompt assembly | Selection, ordering, budgeting, compression |
| **4. Reasoning Strategy** | Effective reasoning over context | Strategy selection, thinking budget, backtracking, self-correction |
| **5. Meta-Learning** | Learning from new domains quickly | Few-shot adaptation, transfer identification, plateau breaking |
| **6. Architecture Discovery** | Optimal memory architecture per domain | ALMA-inspired meta-agent searching over executable code architectures |
| **7. Multi-Agent Coordination** | Effective knowledge sharing between agents | Relevance filtering, conflict resolution, division of labor |

### Rollout Engine

Each training task produces rollouts of the form:

```
<think> → <memory_op> → <search> → <evidence> → <reason> → <answer>
```

- **Multi-context GRPO on verl:** Group sampling across multiple conversation contexts for stable optimization
- **Retrieved token masking:** Mask retrieval tokens during backpropagation for stable gradients (Search-R1 technique)
- **Context folding:** Handle long-horizon rollouts without exceeding memory limits
- **Curriculum learning:** 5 difficulty levels with dynamic progression:
  - Level 1: Single-doc factual lookup
  - Level 2: Multi-doc synthesis
  - Level 3: Temporal reasoning (facts change, agent must update)
  - Level 4: Adversarial (misleading premises, contradictory sources)
  - Level 5: Multi-session (knowledge accumulates across sessions)

### Reward Engine

**Per-stage process rewards.** Legal tasks have 7 stages; finance tasks have 8:

| Stage | What's Scored |
|-------|--------------|
| 1. Query formulation | Is the search query well-formed and specific? |
| 2. Memory operation | Is the operation correct, faithful, and useful? |
| 3. Retrieval | Are retrieved documents real, relevant, and sufficient? |
| 4. Evidence extraction | Is extracted evidence from right source and supports claim? |
| 5. Reasoning | Is the reasoning chain valid and complete? |
| 6. Output quality | Is the answer professional, precise, and client-ready? |
| 7. Citation quality | Are all citations real, supportive, and traceable? |
| 8. Numerical accuracy (finance only) | Is every number correct and traceable? |

**Three signals per stage:**

| Signal | Method | Example |
|--------|--------|---------|
| Rule-based verifier | Deterministic Python checks | Citation exists? Number matches? Format correct? |
| Semantic evaluator | Embedding similarity + trained classifier | Relevant? Coherent? Faithful? |
| LLM-as-judge | Domain-calibrated rubric (Qwen2.5-72B) | Would a partner/analyst approve? |

**Dynamic stage weighting (REFRAG-style):** Stages with highest variance or highest correlation with gold eval get upweighted. Per-task-type weight profiles.

**Recursive reward refinement:** After each training run, the trained model helps generate better reward signals for the next run.

### Optimizer Suite

| Algorithm | Use Case | Status |
|-----------|----------|--------|
| **AMIR-GRPO** (default) | Adaptive multi-interval reward with group-relative optimization. Default for all training. | Primary |
| **GRPO-SG** (fallback) | Standard GRPO with stabilization guarantees. Fallback when AMIR diverges. | Fallback |
| **PODS** | Preference-Optimized Down-Sampling for rollout selection. Reduces compute by sampling high-signal rollouts. | Rollout optimization |
| **GRPO** | Memory-efficient, no critic network. Foundation algorithm. | Available |
| **DrGRPO** | Length-sensitive tasks (legal: verbose ≠ better) | Available |
| **DAPO** | Entropy maintenance for long reasoning chains | Available |
| **GiGPO** | Alternative for specific configurations | Available |
| **PPO + GAE** | Baseline alternative | Available |

**Non-gradient baseline (required):** GEPA (Guided Evolution for Prompt Adaptation) is required as a prompt-evolution baseline comparison on every major release. This ensures RL training provides genuine improvement over prompt engineering.

Additional techniques:
- **LoRA training:** Customer-isolated adapters, typical 20-50MB
- **Variance reduction:** Forge-style variance-reduced updates
- **Anti-forgetting:** EWC to preserve important parameters + experience replay buffer

### Cross-Domain Transfer Protocol

When training for Domain B after prior training on Domain A:

- **Maintenance curriculum:** 15-20% of training examples from Domain A
- **Continuous monitoring:** Domain A eval scores checked every 100 steps; halt if below 95% baseline
- **EWC parameter locking:** Constrain gradient updates to Domain A critical parameters
- **Experience replay:** Mix Domain A trajectories into Domain B training at configurable ratio
- **Interference tracking:** Log positive transfer AND negative interference
- **Separate adapters fallback:** If interference exceeds threshold, train separate LoRA and compose at inference

---

## 4.5 Observatory

Real-time training dynamics monitoring. Every training run is watched for problems with automatic intervention.

### Signal Categories

**Training Stability:**
- Reward variance per stage (collapse → Echo Trap detection)
- Policy entropy over time (reasoning diversity collapse)
- Gradient norms per-layer (instability detection)
- KL divergence from reference policy
- Loss trajectory and convergence pattern

**Memory Behavior:**
- Memory bank size and churn rate
- Operation distribution (STORE/UPDATE/FORGET/NOOP ratio)
- Retrieval diversity score
- Dead memory percentage (stored but never retrieved)
- Working → session → permanent promotion rate
- Memory utility distribution (from runtime Q-values)

**Reward Integrity:**
- Proxy reward vs. gold eval divergence (Goodhart early warning)
- Per-stage reward trajectory
- Behavioral anomaly detection:
  - Length inflation (responses getting longer without quality gain)
  - Citation padding (adding citations that don't support claims)
  - Sycophancy drift (agreeing with premises instead of challenging)
  - Retrieval avoidance (using parametric knowledge to avoid retrieval cost)
  - Memory gaming (storing everything to inflate retrieval scores)
  - Format gaming (matching rubric format without substance)

### Automatic Interventions

| Trigger | Intervention |
|---------|-------------|
| Entropy collapse | Inject diverse prompts, increase exploration temperature |
| Gradient spikes | Rollback to last stable checkpoint, reduce learning rate |
| Goodhart divergence | Early stopping, run adversarial probe suite, flag reward hacking |
| Memory gaming | Reduce memory operation reward weight, inject tasks penalizing unused memories |
| Citation decline | Increase citation verification reward weight, inject citation-focused tasks |

### Reward Hacking Atlas

Catalogues every known reward hacking pattern from training experiments. Grows continuously. Published as research (reputation + moat):

- Known patterns with detection signatures
- Domain-specific hacking tendencies
- Auto-detection rules per pattern
- Preventive curriculum adjustments

---

## 4.6 Eval Suite (aegis-eval)

### 7-Tier Agent Intelligence Hierarchy

#### Tier 1: Memory Fidelity (6 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Retention accuracy | Can it recall facts stored earlier? |
| Update correctness | When info changes, does it update understanding? |
| Selective forgetting | Does it discard outdated/irrelevant info? |
| Cross-reference integrity | Does it link new facts to related facts? |
| Temporal reasoning | Does it know WHEN facts were true? |
| Provenance tracking | Does it know WHERE each fact came from? |

#### Tier 2: Context Intelligence (8 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Retrieval precision | Does it retrieve the RIGHT information? |
| Retrieval depth calibration | Does it retrieve the right AMOUNT? |
| Source routing | Does it know WHICH source to query? |
| Staleness detection | Does it recognize outdated context? |
| Adversarial robustness | Can it detect poisoned/misleading context? |
| Anti-retrieval judgment | Does it know when NOT to retrieve? |
| Iterative retrieval | Can it retrieve, evaluate, then retrieve more intelligently? |
| Context length robustness | Does performance degrade gracefully as context grows? (Context Rot detection — Chroma/NoLiMa methodology) |

#### Tier 3: Learning Dynamics (6 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Learning curve | How fast does it improve on new task types? |
| Transfer | Does training in domain A help domain B? |
| Stability | Does it maintain old skills while learning new ones? |
| Attribution accuracy | Does it learn the RIGHT lesson from failure? |
| Sample efficiency | How many examples to reach competence? |
| Plateau detection | Does it know when it's stopped improving? |

#### Tier 4: Reasoning About Context (8 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Relevance explanation | Can it articulate WHY context supports its answer? |
| Gap identification | Can it identify missing information? |
| Source reliability assessment | Can it weigh first-party vs. third-party sources? |
| Contradiction detection | Can it identify when two sources disagree? |
| Multi-hop synthesis | Can it chain reasoning across 3+ documents? |
| Coherence over time | Consistent reasoning across multi-day engagement? |
| Bias detection | Does reasoning change based on protected characteristics without legitimate basis? |
| Equal treatment | Consistent recommendations regardless of protected class indicators? |

#### Tier 5: Meta-Cognitive Awareness (5 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Calibration | When it says "80% confident," is it right 80% of the time? |
| Explainability | Can it identify which memories/context influenced its decision? |
| Failure prediction | Can it predict when it's likely to get something wrong? |
| Strategy adaptation | Does it adjust approach based on task difficulty? |
| Self-diagnosis | Can it identify its own knowledge gaps? |

#### Tier 6: Collaborative Context (10 dimensions)

| Dimension | What It Tests |
|-----------|--------------|
| Relevant sharing | Does it share info other agents need? |
| Contradiction resolution | Can it resolve conflicts between agents' knowledge? |
| Shared model maintenance | Can multiple agents maintain consistent picture? |
| Confidentiality | Does it know what information to withhold? |
| Inter-agent communication | Does it communicate clearly and efficiently with peer agents? |
| Task delegation efficiency | Does it delegate sub-tasks optimally across agents? |
| Shared state consistency | Do all agents maintain a coherent shared world model? |
| Cascading failure propagation | Does one agent's failure propagate or get contained? |
| Multi-agent cost efficiency | Is token/compute usage efficient across the agent swarm? |
| Role adherence | Does each agent stay within its designated role boundaries? |

#### Tier 7: Security & Adversarial Robustness (8 dimensions)

Per OWASP Top 10 for Agentic AI (2025) and emerging agent security research (Gray Swan, Anthropic red-teaming):

| Dimension | What It Tests |
|-----------|--------------|
| Prompt injection resistance | Can the agent resist direct and indirect prompt injection attacks? |
| Memory poisoning detection | Can it detect and reject poisoned/manipulated memory entries? |
| Tool misuse prevention | Does it validate tool calls and refuse dangerous operations? |
| PII leakage prevention | Does it protect personally identifiable information across contexts? |
| Jailbreak resistance | Can it maintain safety guardrails under adversarial pressure? |
| Privilege escalation detection | Does it respect authorization boundaries and detect escalation attempts? |
| Policy violation detection | Can it identify outputs that violate organizational or regulatory policies? |
| Cascading failure resilience | Does it fail safely without corrupting downstream systems or agents? |

### Domain Plugins

**Legal Plugin (18 dimensions):**

| Category | Dimensions |
|----------|-----------|
| Memory | Clause retention, precedent tracking, supersession awareness, cross-reference integrity |
| Retrieval | Citation validity, jurisdiction accuracy, relevance precision, completeness |
| Reasoning | Issue spotting, argument chain validity, counter-argument awareness, risk calibration |
| Compliance | Hallucination rate (Stanford HAI typology), confidentiality, privilege preservation, audit trail |
| Fairness | Fair representation, equal treatment under law |

**Finance Plugin (20 dimensions):**

| Category | Dimensions |
|----------|-----------|
| Memory | Numerical retention, cross-document reconciliation, market data currency, entity tracking, temporal financial tracking |
| Retrieval | Source document precision, regulatory reference accuracy, comparable transaction relevance, data recency |
| Reasoning | Numerical computation accuracy, materiality judgment, risk factor completeness, trend identification, scenario analysis |
| Compliance | Hallucination rate, audit trail completeness, insider information handling, FINRA/SEC compliance |
| Fairness | Fair lending alignment, disparate impact detection |

**Safety Plugin (12 dimensions):**

| Category | Dimensions |
|----------|-----------|
| Input Security | Prompt injection detection, jailbreak attempt classification, input sanitization validation, adversarial input detection |
| Output Safety | PII leakage detection, harmful content filtering, policy compliance verification, toxicity scoring |
| Operational Safety | Tool call validation, privilege boundary enforcement, resource consumption limits, cascading failure containment |

### System Efficiency Dimensions

Operational metrics tracked across all eval runs (not scored as intelligence dimensions, but critical for production readiness):

| Dimension | What It Measures |
|-----------|-----------------|
| Token usage per task | Total tokens consumed (input + output) per eval scenario |
| Latency per stage | Time spent in each agent stage (thinking, retrieval, reasoning, answering) |
| Cost per eval | Estimated dollar cost per eval run (API calls, compute) |
| Tool call efficiency | Ratio of useful tool calls to total tool calls |
| Retrieval efficiency | Ratio of relevant retrievals to total retrievals |
| Context utilization ratio | How much of the provided context the agent actually uses |
| Redundancy rate | Percentage of duplicate or unnecessary operations |

### Eval Architecture Characteristics

- **Adaptive difficulty:** Adjusts to agent's level. If it aces Level 3, jump to Level 5.
- **Generative scenarios:** Creates test cases from customer's OWN data, not generic benchmarks.
- **Adversarial probing:** Red-team module actively searches for agent failure modes.
- **Longitudinal tracking:** Tracks performance over weeks/months. Is the agent improving?
- **Diagnostic output:** Every eval produces: score + failure analysis + root cause + recommended training focus + training task templates.

### Dimension Phasing (Phase 1 Realism)

Not all 50+ dimensions ship in Phase 1. Dimensions are tiered by implementation complexity and market need:

| Phase | Tier | Dimensions | Count | Rationale |
|-------|------|-----------|-------|-----------|
| **Phase 1 (Core)** | 1, 2, 4 (partial), 7 (partial) | Retention accuracy, update correctness, selective forgetting, cross-reference integrity, temporal reasoning, provenance tracking, retrieval precision, retrieval depth calibration, source routing, staleness detection, adversarial robustness, anti-retrieval judgment, iterative retrieval, context length robustness, relevance explanation, gap identification, contradiction detection, multi-hop synthesis, prompt injection resistance, PII leakage prevention, jailbreak resistance | ~20 | High-signal dimensions testable with current benchmarks; security dims address immediate market demand |
| **Phase 2 (Advanced)** | 3, 4 (full), 5, 7 (full) | Learning dynamics (all 6), source reliability, coherence over time, bias detection, equal treatment, calibration, explainability, failure prediction, strategy adaptation, self-diagnosis, memory poisoning, tool misuse, privilege escalation, policy violation, cascading failure | ~20 | Require longitudinal eval, meta-cognitive probes, and security red-team infrastructure |
| **Phase 3+ (Research)** | 6 (all 10) | All collaborative context dimensions | 10 | Multi-agent eval requires orchestration infrastructure; research-grade |

Domain plugins (Legal, Finance, Safety) ship progressively: Legal in Phase 3, Finance in Phase 3, Safety in Phase 2 (aligned with security tier).

### Eval Scoring Pipeline (Phase 1 Implementation)

```python
# Three-tier scoring for each dimension
class EvalScorer:
    def score(self, agent_output, ground_truth, dimension):
        # 1. Programmatic (rule-based) — fast, deterministic
        programmatic_score = self.rule_verifier.check(agent_output, dimension)

        # 2. Semantic (embedding-based) — domain-calibrated similarity
        semantic_score = self.semantic_evaluator.score(agent_output, ground_truth)

        # 3. LLM-as-judge — domain-specific rubric
        judge_score = self.llm_judge.evaluate(
            agent_output, ground_truth,
            rubric=self.get_domain_rubric(dimension)
        )

        return self.aggregate(programmatic_score, semantic_score, judge_score)
```

### Novel Benchmarks (We Create)

| Benchmark | Description | Status |
|-----------|-------------|--------|
| **AegisLegal-Memory** | 50 simulated case lifecycles (10-30 sessions each), attorney-annotated | Phase 4 |
| **AegisFinance-Memory** | 50 simulated deal lifecycles, analyst-annotated | Phase 4 |
| **AegisReward-Integrity** | 200 training scenarios with planted reward hacking patterns | Phase 5 |

### Existing Benchmarks Used (28)

**Memory:** LoCoMo, MemBench, MemoryAgentBench, LongMemEval, RealMem, Context-Bench, Recovery-Bench

**Legal:** CUAD, LegalBench, LegalBench-RAG, ContractNLI, ContractEval, CLERC, COLIEE, ACORD, Stanford HAI study, VLAIR

**Financial:** FinanceBench, FinQA, TAT-QA, ConvFinQA, FLUE, FinMTEB, DocFinQA, BizBench

**General RAG:** FACTS, LOCA-bench, ALCE, ASQA

---

## 4.7 Governance & Compliance Layer

Critical for legal and finance verticals. This is a deal-breaker requirement.

### Customer Isolation

| Mechanism | Technology |
|-----------|-----------|
| Training environment isolation | Kubernetes namespaces + network policies |
| LoRA adapter isolation | Separate storage per customer, no cross-contamination |
| Memory store isolation | Dedicated database schemas per customer |
| Data residency | US, EU, customer-premise options |

### Privacy & Security

| Requirement | Implementation |
|-------------|---------------|
| Differential privacy | Opacus DP-SGD for LoRA training |
| Encryption at rest | AES-256 |
| Encryption in transit | TLS 1.3 |
| Access control | RBAC + ABAC |
| No-training-on-client-data guarantee | Contractual + architectural enforcement |

### Audit & Provenance

- **Complete provenance chain:** source document → extraction → embedding → storage → retrieval → reasoning → output
- **Immutable audit log:** Append-only log in ClickHouse for every memory operation
- **Git-versioned memory state:** Point-in-time reconstruction ("show me what the agent knew as of March 15, 2026")
- **Compliance reporting:** SOC 2, ISO 27001, FINRA, SEC, EU AI Act transparency reports

---

# 5. PRODUCT SURFACES

## 5.1 Eval Dashboard

**Audience:** Managing partners, team leads, compliance officers.

- Visual scorecards: per-dimension scores, color-coded (green/yellow/red), overall score prominent
- Plain-English diagnostics: not "supersession_awareness: 0.21" but "Your agent treats outdated contract versions as current"
- Improvement trajectory: line charts over weeks/months
- "What to fix next" panel: top 3 recommended training focus areas with expected impact
- Export: PDF for board presentations, JSON/CSV for engineering
- Role-based views: Partner view (high-level) vs. Engineer view (dimension details, failure examples)

## 5.2 Training Console

**Audience:** ML engineers and technical leads.

- Configuration wizard: domains, curriculum, RL algorithm, compute budget
- Live monitoring: Observatory metrics in real-time
- Results: before/after eval comparison, per-dimension delta
- Adapter management: version history, A/B deployment, one-click rollback

## 5.3 Memory Explorer

**Audience:** Compliance teams, auditors, domain experts.

- Visual knowledge graph: interactive graph browser (D3.js/Cytoscape.js)
- Memory health dashboard: dead memory %, retrieval hit rate, staleness distribution
- Provenance viewer: trace any fact back through retrieval → storage → source document → page number
- Audit mode: point-in-time reconstruction

## 5.4 Environment Marketplace (Phase 5+)

**Audience:** Enterprise ML teams, RL researchers, domain specialists.

**Aegis Environments** packages domain-specific RL training scenarios as reusable, versioned assets:

- **Environment catalog:** Browse pre-built environments (legal contract review, SEC audit simulation, compliance monitoring, multi-party negotiation)
- **Environment builder:** No-code wizard for creating custom RL environments from customer data (domain docs → ground truth → reward signals → environment)
- **Version control:** Git-like versioning for environments. Pin training to a specific environment version for reproducibility.
- **Reward signal designer:** Visual editor for composing multi-stage reward functions from primitives (rule-based, semantic, judge-based)
- **Environment analytics:** Track which environments produce the highest training signal, fastest convergence, best transfer
- **Marketplace:** Publish and share environments across the Aegis network (with customer permission). Revenue share model.
- **Simulation fidelity metrics:** How well does the environment approximate real-world task distributions?

### Environment Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Aegis Environment                      │
├─────────────────────────────────────────────────────────┤
│  Scenario Generator                                      │
│  ├── Task templates (parameterized)                      │
│  ├── Document corpus (domain-specific)                   │
│  ├── Difficulty curriculum (Levels 1-7)                  │
│  └── Adversarial variants (noise, contradictions)        │
│                                                          │
│  Ground Truth Engine                                     │
│  ├── Expert-annotated golden answers                     │
│  ├── Programmatic validators                             │
│  └── Multi-annotator agreement scores                    │
│                                                          │
│  Reward Signal Composer                                  │
│  ├── Per-stage process rewards (7 stages × 3 signals)    │
│  ├── Domain-specific rubrics                             │
│  └── Anti-gaming safeguards                              │
│                                                          │
│  Metrics Collector                                       │
│  ├── Training convergence tracking                       │
│  └── Environment effectiveness scoring                   │
└─────────────────────────────────────────────────────────┘
```

## 5.5 Rubric Builder (Phase 2+)

**Audience:** Domain experts who define what "good" looks like.

- No-code interface for defining evaluation criteria
- Criteria → reward function conversion (automatic)
- Calibration workflow: expert reviews 20-30 outputs, system calibrates
- Iterative refinement after each training cycle
- Enables horizontal expansion: any customer, any domain

---

# 6. INTEGRATION ARCHITECTURE

## 6.1 Aegis Agent Protocol

Standardized interface (JSON-RPC over HTTP/WebSocket). Any agent that implements these endpoints works with Aegis:

```
evaluate(task) → trajectory
  Aegis sends a task. Agent returns full execution trace:
  thinking, memory operations, searches, evidence, reasoning, answer.

memory.get(query) → results
  Aegis reads from the agent's memory state.

memory.set(key, value, metadata) → confirmation
  Aegis writes to the agent's memory.

observe(event)
  Agent emits events during production use.
  Aegis consumes for runtime learning and monitoring.
```

## 6.2 Framework SDKs

Thin wrappers translating each framework's native format into Aegis Agent Protocol:

| Framework | SDK Package | Phase |
|-----------|------------|-------|
| LangChain | `aegis-langchain` | Phase 1 |
| LlamaIndex | `aegis-llamaindex` | Phase 1 |
| OpenAI Agents SDK | `aegis-openai` | Phase 1 |
| CrewAI | `aegis-crewai` | Phase 1 |
| AutoGen | `aegis-autogen` | Phase 1 |
| Anthropic SDK | `aegis-anthropic` | Phase 1 |
| Custom REST | `aegis-rest` | Phase 1 |
| LangGraph | `aegis-langgraph` | Phase 2 |
| DSPy | `aegis-dspy` | Phase 2 |
| Letta | `aegis-letta` | Phase 2 |
| Semantic Kernel | `aegis-semantic-kernel` | Phase 2 |

## 6.3 Memory Drop-In

One-line integration for any framework:

```python
from aegis import AegisMemory

# Replace your agent's memory layer with Aegis
agent.memory = AegisMemory(
    domain="legal",
    customer_id="sterling",
    tier="managed"  # or "self-hosted"
)

# All memory operations now flow through Aegis:
# - RL-optimized STORE/RETRIEVE/UPDATE/FORGET
# - Runtime learning (Q-value updates every interaction)
# - Full governance and audit trail
# - Sleep-time consolidation during idle periods
```

## 6.4 Event System

Production interactions emit structured events via webhook:

```json
{
  "event": "interaction_complete",
  "agent_id": "sterling-contract-review-v3",
  "task_type": "contract_review",
  "trajectory": { "..." },
  "outcome": {
    "user_feedback": "thumbs_up",
    "expert_review": null,
    "confidence": 0.87
  },
  "timestamp": "2026-03-15T14:32:00Z"
}
```

Aegis consumes events for runtime learning (MemRL-style Q-value updates), production monitoring, and flagging interactions for expert review.

## 6.5 CI/CD Integration

```yaml
# .github/workflows/aegis-eval.yml
name: Aegis Agent Evaluation
on: [pull_request]
jobs:
  eval:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install aegis-eval
      - run: aegis eval run --config eval.yaml --fail-under 0.75
```

---

# 7. DATA MODEL

## 7.1 Core Entities

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   EvalRun        │     │   EvalResult     │     │   Dimension      │
│─────────────────│     │─────────────────│     │─────────────────│
│ id: uuid         │────→│ id: uuid         │────→│ id: string       │
│ agent_id: string │     │ run_id: uuid     │     │ name: string     │
│ config: json     │     │ dimension_id: str│     │ tier: int (1-7)  │
│ created_at: ts   │     │ score: float     │     │ domain: string?  │
│ status: enum     │     │ details: json    │     │ description: str │
│ summary: json    │     │ evidence: json   │     │ scorer_type: str │
└─────────────────┘     └─────────────────┘     └─────────────────┘

┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   TestCase       │     │   AgentTrace     │     │   Diagnostic     │
│─────────────────│     │─────────────────│     │─────────────────│
│ id: uuid         │     │ id: uuid         │     │ id: uuid         │
│ suite_id: string │     │ run_id: uuid     │     │ run_id: uuid     │
│ input: json      │     │ test_case_id: uuid│    │ failures: json[] │
│ expected: json   │     │ thinking: text   │     │ root_causes: json│
│ metadata: json   │     │ memory_ops: json │     │ recommendations: │
│ difficulty: int  │     │ searches: json   │     │   json[]         │
│ domain: string   │     │ evidence: json   │     │ training_focus:  │
│ tags: string[]   │     │ reasoning: text  │     │   json[]         │
└─────────────────┘     │ answer: text     │     │ priority_weights:│
                        │ latency_ms: int  │     │   json           │
                        │ token_count: int │     └─────────────────┘
                        └─────────────────┘
```

## 7.2 Memory Entities (Phase 4+)

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   MemoryEntry    │     │   MemoryOp       │     │   MemoryGraph    │
│─────────────────│     │─────────────────│     │─────────────────│
│ id: uuid         │     │ id: uuid         │     │ node_id: uuid    │
│ customer_id: str │     │ entry_id: uuid   │     │ entity_type: str │
│ type: enum       │     │ operation: enum  │     │ properties: json │
│ tier: enum       │     │ agent_id: string │     │ created_at: ts   │
│ content: json    │     │ timestamp: ts    │     │ valid_from: ts   │
│ embedding: vec   │     │ context: json    │     │ valid_to: ts?    │
│ metadata: json   │     │ reward_score: f  │     │                  │
│ utility_score: f │     │ outcome: json    │     │ edges:           │
│ confidence: f    │     └─────────────────┘     │  - type: string  │
│ temporal_scope:  │                              │  - target: uuid  │
│   {from, to}     │                              │  - weight: float │
│ provenance: json │                              │  - temporal: json│
│ created_at: ts   │                              └─────────────────┘
│ accessed_at: ts  │
│ access_count: int│
└─────────────────┘
```

## 7.3 Training Entities (Phase 5+)

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   TrainingRun    │     │   Rollout        │     │   Reward         │
│─────────────────│     │─────────────────│     │─────────────────│
│ id: uuid         │     │ id: uuid         │     │ id: uuid         │
│ customer_id: str │     │ run_id: uuid     │     │ rollout_id: uuid │
│ config: json     │     │ task_id: uuid    │     │ stage: int       │
│ curriculum: json │     │ trajectory: json │     │ rule_score: f    │
│ optimizer: enum  │     │ reward_total: f  │     │ semantic_score: f│
│ lora_config: json│     │ reward_stages: f[]│    │ judge_score: f   │
│ base_model: str  │     │ selected: bool   │     │ weight: float    │
│ started_at: ts   │     │ advantage: float │     │ details: json    │
│ status: enum     │     └─────────────────┘     └─────────────────┘
│ metrics: json    │
│ adapter_path: str│
│ eval_before: uuid│
│ eval_after: uuid │
└─────────────────┘
```

---

# 8. API SURFACE

## 8.1 Eval API (Phase 1 — FastAPI)

```
POST   /api/v1/eval/run                  Create and start an eval run
GET    /api/v1/eval/run/{run_id}         Get eval run status and results
GET    /api/v1/eval/run/{run_id}/report  Get formatted report (JSON/HTML/PDF)
POST   /api/v1/eval/run/{run_id}/cancel  Cancel a running eval

GET    /api/v1/eval/dimensions           List available eval dimensions
GET    /api/v1/eval/dimensions/{id}      Get dimension details and scoring rubric

POST   /api/v1/eval/suites               Create a test suite
GET    /api/v1/eval/suites               List test suites
GET    /api/v1/eval/suites/{id}          Get test suite details
PUT    /api/v1/eval/suites/{id}          Update test suite

GET    /api/v1/eval/history              List historical eval runs (with filters)
GET    /api/v1/eval/compare              Compare two eval runs side-by-side

POST   /api/v1/eval/diagnostic           Generate diagnostic from eval results
```

## 8.2 Agent Protocol API (Phase 2+)

```
POST   /api/v1/agent/evaluate            Send task to agent, receive trajectory
POST   /api/v1/agent/memory/get          Read from agent memory
POST   /api/v1/agent/memory/set          Write to agent memory
POST   /api/v1/agent/observe             Receive production event from agent
```

## 8.3 Training API (Phase 5+)

```
POST   /api/v1/train/run                 Start a training run
GET    /api/v1/train/run/{id}            Get training run status
GET    /api/v1/train/run/{id}/metrics    Get Observatory metrics (streaming)
POST   /api/v1/train/run/{id}/stop       Stop training run
GET    /api/v1/train/adapters            List LoRA adapters
GET    /api/v1/train/adapters/{id}       Download adapter
```

## 8.4 Memory API (Phase 4+)

```
POST   /api/v1/memory/store              Store a memory entry
POST   /api/v1/memory/retrieve           Retrieve memories by query
PUT    /api/v1/memory/{id}               Update a memory entry
DELETE /api/v1/memory/{id}               Forget a memory entry
POST   /api/v1/memory/link               Link two memory entries
GET    /api/v1/memory/health             Get memory health dashboard data
GET    /api/v1/memory/audit              Get audit trail
GET    /api/v1/memory/snapshot/{ts}      Point-in-time memory reconstruction
```

---

# 9. SDK DESIGN

## 9.1 Python SDK (Phase 1)

```python
from aegis import Evaluator, EvalConfig, LegalPlugin, FinancePlugin

# Basic usage
evaluator = Evaluator()
results = evaluator.run(
    agent=my_agent,  # Any callable or adapter
    config=EvalConfig(
        dimensions=["all"],  # or specific: ["retention_accuracy", "citation_validity"]
        domain_plugins=[LegalPlugin()],
        num_scenarios=200,
        difficulty="adaptive",
    )
)

# Access results
print(results.overall_score)        # 0.47
print(results.diagnostic.summary)   # "Primary failure: supersession awareness at 21%"
print(results.diagnostic.top_3)     # Top 3 recommended training areas
results.export("report.pdf")        # PDF export
results.export("report.json")       # JSON export
results.export("report.html")       # HTML export
```

### Adapter Pattern

```python
from aegis.adapters import LangChainAdapter, LlamaIndexAdapter, OpenAIAdapter

# LangChain
from langchain.agents import AgentExecutor
agent = AgentExecutor(...)
aegis_agent = LangChainAdapter(agent)

# LlamaIndex
from llama_index.core.agent import ReActAgent
agent = ReActAgent(...)
aegis_agent = LlamaIndexAdapter(agent)

# OpenAI Agents SDK
from openai import OpenAI
aegis_agent = OpenAIAdapter(client=OpenAI(), assistant_id="asst_xxx")

# Custom REST
aegis_agent = RESTAdapter(
    url="https://my-agent.example.com/chat",
    headers={"Authorization": "Bearer xxx"},
)

# All adapters work identically with the evaluator
results = evaluator.run(agent=aegis_agent, config=config)
```

### Custom Metrics

```python
from aegis import Metric, MetricResult

class MyCustomMetric(Metric):
    name = "my_domain_accuracy"
    tier = 4  # Reasoning Quality
    domain = "healthcare"

    def score(self, agent_output, ground_truth, context) -> MetricResult:
        # Custom scoring logic
        score = self._check_drug_interactions(agent_output)
        return MetricResult(
            score=score,
            explanation="Checked for dangerous drug interaction mentions",
            evidence={"interactions_found": [...], "missed": [...]},
        )

# Register and use
evaluator = Evaluator(custom_metrics=[MyCustomMetric()])
```

### CLI

```bash
# Basic eval
aegis eval run --config eval.yaml

# Quick eval with defaults
aegis eval run --agent "http://localhost:8000/chat" --domain legal

# Compare two runs
aegis eval compare --runs run_abc123 run_def456

# Generate report
aegis eval report --run run_abc123 --format pdf --output report.pdf

# List available dimensions
aegis eval dimensions --domain legal

# Run specific dimensions only
aegis eval run --config eval.yaml --dimensions citation_validity,supersession_awareness
```

### YAML Configuration

```yaml
# eval.yaml
agent:
  type: langchain  # or llamaindex, openai, anthropic, rest, custom
  config:
    # Agent-specific configuration

eval:
  dimensions: all  # or list specific dimensions
  domain_plugins:
    - legal:
        workflows: [contract_review, litigation_research]
    - finance:
        workflows: [due_diligence, compliance_monitoring]

  scoring:
    programmatic: true
    semantic: true
    llm_judge:
      model: "gpt-4o"  # or local model endpoint
      rubric: default   # or path to custom rubric

  scenarios:
    count: 200
    difficulty: adaptive  # or fixed level 1-5
    source: generated     # or path to custom test cases

  output:
    format: [json, html, pdf]
    path: ./results/
    include_traces: true
    include_diagnostic: true

ci:
  fail_under: 0.75  # Fail CI if overall score below this
  fail_dimensions:   # Fail if specific dimensions below threshold
    citation_validity: 0.80
    hallucination_rate: 0.10  # Max acceptable rate
```

---

# 10. EXTENSION & PLUGIN ARCHITECTURE

## 10.1 Plugin Types

```
aegis/
├── plugins/
│   ├── domains/          # Domain-specific eval plugins
│   │   ├── legal.py      # Legal plugin (18 dimensions)
│   │   ├── finance.py    # Finance plugin (20 dimensions)
│   │   ├── healthcare.py # Healthcare plugin (future)
│   │   └── custom.py     # Base class for custom domains
│   │
│   ├── adapters/         # Agent framework adapters
│   │   ├── langchain.py
│   │   ├── llamaindex.py
│   │   ├── openai.py
│   │   └── ...
│   │
│   ├── scorers/          # Scoring backends
│   │   ├── rule_based.py
│   │   ├── semantic.py
│   │   └── llm_judge.py
│   │
│   ├── reporters/        # Output format plugins
│   │   ├── json.py
│   │   ├── html.py
│   │   ├── pdf.py
│   │   └── csv.py
│   │
│   └── data_sources/     # Data source connectors
│       ├── sec_edgar.py
│       ├── court_listener.py
│       ├── federal_register.py
│       └── ...
```

## 10.2 Plugin Interface

```python
from aegis.plugins import DomainPlugin, Dimension, TestCase

class HealthcarePlugin(DomainPlugin):
    name = "healthcare"
    version = "0.1.0"

    def get_dimensions(self) -> list[Dimension]:
        return [
            Dimension(
                id="drug_interaction_detection",
                name="Drug Interaction Detection",
                tier=4,
                description="Can the agent identify dangerous drug interactions?",
                scorer=self.score_drug_interactions,
            ),
            # ... more dimensions
        ]

    def generate_test_cases(self, data_path, count) -> list[TestCase]:
        # Generate domain-specific test scenarios
        ...

    def score_drug_interactions(self, output, ground_truth) -> float:
        # Domain-specific scoring logic
        ...
```

## 10.3 Third-Party Extension Points

Developers can extend Aegis by:

1. **Custom domain plugins:** Define eval dimensions + scoring + test generation for any domain
2. **Custom adapters:** Connect any agent framework
3. **Custom scorers:** Plug in alternative scoring backends
4. **Custom reporters:** Generate output in any format
5. **Custom data sources:** Connect domain-specific data for test generation

All extensions registered via entry points:

```toml
# pyproject.toml
[project.entry-points."aegis.plugins"]
healthcare = "my_package.healthcare:HealthcarePlugin"
```

---

# 11. TECHNOLOGY STACK

## 11.1 Core Infrastructure

| Component | Technology | Rationale |
|-----------|-----------|-----------|
| RL Training | **verl** + verl-agent | Best scale + performance. Multi-algorithm. Proven to 671B. |
| Base LLM | **Qwen2.5-7B-Instruct** (training) | Best open model for agent RL (proven by Memory-R1, MemSearcher) |
| LLM Judge | **Qwen2.5-72B** (or Claude/GPT-4o) | Domain-calibrated evaluation |
| Multimodal Embedding | **Qwen3-VL-Embedding** + **Qwen3-VL-Reranker** | SOTA unified text+image+table embedding |
| Vector DB | **pgvector** (PostgreSQL) or **Qdrant** | Production-grade, self-hostable, hybrid search |
| Knowledge Graph | **Neo4j** or **FalkorDB** | Entity relationships, temporal edges |
| Document Parsing | **Docling** (IBM) | Multi-format (PDF, DOCX, XLSX, HTML, images) |
| Table Extraction | **Camelot** + **LayoutXLM** + **Qwen3-VL** | Financial tables need multiple approaches |
| OCR | **Tesseract** + **EasyOCR** | Scanned contracts, legacy documents |
| Speech-to-Text | **Whisper v3** | Earnings calls, depositions |
| Web Browser | **Playwright** / **Browser-Use** | Agent-driven web browsing |
| Experiment Tracking | **W&B** or **MLflow** | Training run tracking |
| Serving | **vLLM** or **SGLang** | Inference for rollouts |
| Compute | **H100/A100 GPUs** (cloud-agnostic) | RL training |

## 11.2 Product Surfaces

| Component | Technology | Rationale |
|-----------|-----------|-----------|
| Eval Dashboard | **Next.js** + **Recharts** | Interactive scorecards, trajectory charts |
| Training Console | **Next.js** + **Grafana embeds** | Live training monitoring |
| Memory Explorer | **Next.js** + **D3.js** / **Cytoscape.js** | Interactive knowledge graph visualization |
| Rubric Builder | **Next.js** + structured form engine | No-code eval criteria definition |
| API Gateway | **FastAPI** | Agent Protocol, SDKs, webhooks |
| Auth | **Clerk** or **Auth0** | Role-based access, SSO for enterprise |
| Docs Site | **MkDocs** (Material theme) or **Docusaurus** | Developer documentation |

## 11.3 Observatory Stack

| Component | Technology |
|-----------|-----------|
| Dashboard | Grafana + custom React components |
| Metrics | Prometheus + InfluxDB |
| Alerting | PagerDuty / webhooks |
| Logging | ClickHouse (high-volume structured logs) |

## 11.4 Phase 1 Stack (Eval MVP Only)

| Component | Technology | Notes |
|-----------|-----------|-------|
| Core framework | **Python 3.11+** | pip-installable package |
| CLI | **Click** or **Typer** | `aegis eval run` |
| API (optional) | **FastAPI** | For dashboard and CI/CD webhook |
| LLM-as-judge | **OpenAI/Anthropic API** or local | Configurable provider |
| Semantic scoring | **sentence-transformers** | Embedding similarity |
| Report generation | **Jinja2** templates | HTML/PDF output |
| PDF export | **WeasyPrint** or **pdfkit** | Enterprise reports |
| Testing | **pytest** + **GitHub Actions** | >80% coverage |
| Docs | **MkDocs Material** | docs.aegis.dev |
| Package | **PyPI** | `pip install aegis-eval` |

---

# 12. COMPUTE STRATEGY

## Tiered Infrastructure

| Tier | Use Case | Hardware | Cost | Latency |
|------|----------|----------|------|---------|
| **Free** | aegis-eval core (open-source) | CPU only | $0 | Minutes per eval suite |
| **Starter** | Hosted eval + basic reports | 1-2 GPUs (eval judge) | $200-500/month | Hours per eval cycle |
| **Standard** | RL training (Levels 1-3) | 4-8x A100/H100 | $2K-8K per cycle | 4-12 hours per cycle |
| **Intensive** | Full training (Levels 1-6) | 16+ H100 | $10K-30K per cycle | 12-48 hours per cycle |
| **Enterprise** | Dedicated cluster, custom SLAs | Customer-specified | Custom pricing | On-demand |

## Cloud-Agnostic Deployment

- **Supported clouds:** AWS, GCP, Azure, Lambda Labs, RunPod, CoreWeave
- **Customer-hosted:** Customer provides GPUs; Aegis provides software + orchestration
- **Aegis-managed:** We handle everything; customer gets LoRA adapters + eval reports
- **Hybrid:** Eval on Aegis cloud; training on customer GPUs (sensitive data never leaves)

## Cost Optimization

- **Eval on CPU:** Entire aegis-eval pipeline (except LLM-as-judge) runs on CPU. Free tier is genuinely free.
- **Runtime learning requires no GPU:** MemRL-style Q-value updates are pure CPU operations. Agent improves daily at zero GPU cost.
- **Spot instance checkpointing:** Training state saved every 50 steps. 60-70% cost savings.
- **Right-sized training:** Diagnostic determines which RL levels to train. Pay only for what matters.
- **Adapter size optimization:** LoRA rank selected per customer. Simple domains: rank 8. Complex: rank 32+.

## Monthly Infrastructure Budget (Phase 1)

| Service | Minimum | Comfortable |
|---------|---------|-------------|
| Vercel (Next.js dashboard) | $0 | $20 |
| Railway (FastAPI) | $5 | $20 |
| Supabase (database) | $0 | $25 |
| Neo4j Aura (graph DB) | $0 | $65 |
| On-demand GPUs (Lambda Labs) | $50 | $300 |
| Domain + email | $20 | $20 |
| SOC 2 automation | $0 | $250 |
| Misc (CI/CD, monitoring) | $100 | $550 |
| **TOTAL MONTHLY** | **$175** | **$1,250** |

---

# 13. BUILD SEQUENCE — 12-Month Frontier Execution Plan

**March 1, 2026 → February 28, 2027.** Full-loop architecture built in parallel, not sequentially. Monthly releases with immutable dates.

### Assumptions & Defaults

- Start date: March 1, 2026
- Legal + Finance are the only hard-committed launch domains in v1
- Hybrid BYOC is default for regulated customers
- Multi-model routing is mandatory; no single-model lock-in
- Monthly releases are immutable; scope can move but release date does not

### 12-Month Monthly Plan

| Month | Dates | Deliverables | Exit Criteria |
|---|---|---|---|
| **M1** | Mar 2026 | Program kickoff, API contracts, schema freeze v1, infra bootstrap, benchmark harness bootstrap | All v1 interfaces published; CI + staging + BYOC reference env live |
| **M2** | Apr 2026 | `aegis-eval` core v1 (offline), judge triangulation pipeline, benchmark adapters | 20 core dimensions running; deterministic replay pass rate >= 95% |
| **M3** | May 2026 | Memory v1 (temporal tree + KG + vector + event log), 12 memory ops policy interface | Memory CRUD + provenance + snapshot reconstruction passing all contract tests |
| **M4** | Jun 2026 | Retrieval/context policy v1, context budgeting/compression, anti-retrieval decision head | Retrieval precision and depth calibration exceed baseline by >= 10% |
| **M5** | Jul 2026 | RL engine v1 (AMIR-GRPO, GRPO-SG, PODS), LoRA isolation, transfer safeguards | Training produces >= 3 point gain on composite eval without tier-7 regression |
| **M6** | Aug 2026 | Observatory v1, reward hacking atlas runtime checks, auto-intervention policies | Detects seeded reward-hacking patterns with recall >= 0.9 |
| **M7** | Sep 2026 | Security/gov v1: OWASP Agentic Top10 control mapping, ABAC/RBAC, policy runtime guards | Critical red-team scenarios blocked >= 95%; full audit chain verifiable |
| **M8** | Oct 2026 | Legal + finance domain packs v1, domain rubrics, gold-set adjudication workflows | Domain eval reliability targets met; human-judge agreement >= 0.82 |
| **M9** | Nov 2026 | Online eval pipeline and drift-triggered retraining loop | Production drift triggers, retraining, and redeploy complete in < 24h SLA |
| **M10** | Dec 2026 | Frontier benchmark expansion (Mem2ActBench, EMemBench, LoCoMo-Plus, TiMem-style tasks, AgentRewardBench protocols) | Benchmark suite integrated into release gates and regression dashboards |
| **M11** | Jan 2027 | Scale/cost hardening: multi-tenant control plane, BYOC scale tests, efficient rollout scheduling | 3x workload scale test passes; training cost per improvement point reduced >= 25% |
| **M12** | Feb 2027 | GA readiness, external reproducibility report, public technical report + benchmark results | GA gate met: reliability, safety, cost, and improvement KPIs all green |

---

# 14. COMPETITIVE POSITION

## The Landscape

```
                      HAS DOMAIN EVALS
                           │
              AEGIS ●      │      ● Vals AI
                           │      ● Patronus AI
                           │      ● Maxim AI
                           │      ● Stanford HAI (research)
  HAS RL ──────────────────┼────────────────── NO RL
  TRAINING                 │
                           │
              Agent        │      ● Letta          ● Galileo
              Lightning ●  │      ● Contextual AI  ● Langfuse
                           │      ● Harvey AI      ● Promptfoo
              verl ●       │      ● Mem0/Zep       ● Braintrust/Arize
                           │
                      NO DOMAIN EVALS
```

**Aegis is the only entity in the top-left quadrant** — combining domain-specific evals WITH RL training WITH memory management WITH production monitoring WITH environment marketplace.

## Competitor Summary

| Competitor | What They Do | What They Don't | Threat |
|-----------|-------------|-----------------|--------|
| **Harvey AI** ($8B) | Legal AI answers, fine-tuned models | No RL, no learned memory, no adaptive evals | High (market position) |
| **Letta** (MemGPT) | Agent memory framework, open-source | Memory is heuristic/prompt-driven, not RL-trained | Medium (closest to memory vision) |
| **Contextual AI** | Enterprise RAG 2.0 | No persistent memory, no RL, statically optimized | Medium (enterprise relationships) |
| **Agent Lightning** (MSFT) | Framework-agnostic RL training | No memory architecture, no domain rewards | Low (different problem) |
| **Braintrust/Arize** | Agent monitoring + observability | No training, no improvement loop | Low (monitoring ≠ intelligence) |
| **Mem0/Zep** | Memory-as-a-service | Not RL-trained, no domain focus | Low (storage, not intelligence) |
| **DeepEval/RAGAS** | Horizontal eval frameworks | Generic metrics, no domain compliance | Medium (open-source mindshare) |
| **Patronus AI** | AI safety/eval platform, enterprise LLM guardrails | No RL training loop, no memory management, no domain-specific curricula | Medium-High (well-funded, safety positioning overlaps Tier 7) |
| **Galileo** ($68M raised) | LLM observability + evaluation platform | No RL, no memory, monitoring-focused not improvement-focused | Medium (enterprise traction, funding) |
| **Maxim AI** | Agent testing & evaluation platform | Direct eval competitor; no training, no memory, no closed loop | Medium-High (closest eval-only competitor) |
| **Langfuse** | Open-source LLM observability & tracing | Observability only, no eval intelligence, no training | Low-Medium (open-source adoption in observability) |
| **Promptfoo** | Open-source LLM red teaming & eval | Red-teaming focus, no memory, no RL, no domain specialization | Low-Medium (OSS red-team mindshare) |
| **Vals AI** | Domain-specific LLM evaluation (legal, compliance) | Eval-only, no training, no memory. Closest domain eval competitor. | Medium (domain eval overlap) |
| **Harbor / Prime Intellect** | Decentralized AI training infrastructure | Training infrastructure, not eval or memory; different layer of stack | Low (infrastructure, not intelligence) |

## Unique Advantages

1. **RL-trained memory management** — Letta has memory without RL. Agent Lightning has RL without memory. Nobody has both.
2. **Domain-specific contextual evals** — Evals that diagnose AND feed training. Not just scoring — prescribing.
3. **Training observability** — Nobody monitors Echo Trap, reward hacking, memory gaming in real-time.
4. **The closed loop** — eval → diagnose → train → improve → re-eval. No competitor closes this loop.
5. **Security-first eval** — Tier 7 adversarial robustness + Safety Plugin addresses the emerging agent security category (OWASP, enterprise compliance) that no eval competitor covers comprehensively.
6. **Unified offline + online eval** — Production monitoring feeds back into eval and training. Most competitors separate benchmarking from monitoring.
7. **Environment marketplace** — Domain-specific RL training environments as reusable, versioned, purchasable assets. No competitor offers this.

## 5 Compounding Moats

| Moat | Why It Compounds |
|------|-----------------|
| **Eval Standard** | aegis-eval becomes how the industry measures agent intelligence. Switching means losing longitudinal data. |
| **Architecture Library** | After 200+ domain-specific memory architectures, new customers get instant best-fit. Unreproducible without the same experiments. |
| **Failure Mode Taxonomy** | After 1000+ training runs, catalogued every way agents fail. Our curriculum generation benefits from ALL customers. |
| **Transfer Learning Graph** | After 200+ domains, we know which domains transfer to which. Informs curriculum and accelerates training. |
| **Longitudinal Performance Data** | Track agent performance over months. Know typical improvement curves, plateau patterns, breakthrough interventions. |

---

# 15. PRODUCTION MONITORING & ONLINE EVALUATION (see also Section 20: Release-Gating Test Scenarios)

## Unified Offline + Online Eval Philosophy

Aegis treats offline benchmarks and production monitoring as a single eval continuum. An agent's score isn't just how it performs on test scenarios — it's how it performs on real tasks, measured continuously.

### Online Eval Pipeline

```
Production Interaction
  → Structured Event (via Agent Protocol observe() endpoint)
    → Real-Time Scoring (subset of offline dimensions applied to live data)
      → Drift Detection (compare online scores to last offline eval)
        → Alert / Auto-Retrain Trigger
```

### Monitored Signals

| Signal | Method | Action on Anomaly |
|--------|--------|-------------------|
| Confidence calibration drift | Compare stated confidence vs. expert review outcomes | Flag for re-calibration eval |
| Retrieval quality degradation | Track retrieval precision on production queries | Alert; check for data staleness or index rot |
| Memory utilization decay | Monitor memory hit rate, dead memory %, staleness | Trigger memory consolidation or pruning |
| Hallucination rate (production) | Sample-based LLM-as-judge on live outputs | Alert; increase retrieval verification weight |
| Latency regression | Track p50/p95/p99 per stage | Alert; profile for bottlenecks |
| User satisfaction correlation | Map thumbs up/down, corrections to dimension scores | Update eval priority weights |
| Security incident detection | Monitor for prompt injection attempts, PII leaks in production | Immediate alert; log for adversarial training data |
| Cost per interaction | Track token usage, API calls, tool invocations | Budget alerts; efficiency recommendations |

### Feedback Loop: Online → Offline → Training

1. Production interactions that receive negative signals are flagged
2. Flagged interactions become candidate test cases for offline eval suites
3. Offline eval confirms regression and identifies root cause dimensions
4. Root cause dimensions feed training curriculum generation
5. Retrained adapter deployed → production scores monitored for improvement

This closes the gap between "benchmark performance" and "real-world performance" that plagues most eval systems.

---

# 16. ARCHITECTURAL RISKS & MITIGATIONS

## Risk 1: Qwen Single-Vendor Dependency

| Aspect | Detail |
|--------|--------|
| **Risk** | Aegis currently specifies Qwen2.5-7B (training), Qwen2.5-72B (judge), Qwen3-VL-Embedding (embedding). Single-vendor dependency on Alibaba Cloud/Qwen team. |
| **Impact** | If Qwen development stalls, licensing changes, or a superior model emerges, migration cost is high. |
| **Mitigation** | Design all model interfaces behind abstraction layers. Training engine accepts any HuggingFace-compatible model. Judge and embedding modules use provider-agnostic interfaces. Phase 1 validates with at least 2 model families (Qwen + one of: Llama, Mistral, Gemma). |
| **Architecture principle** | Model-agnostic by design. Qwen is the default, not the only option. |

## Risk 2: verl Framework Dependency

| Aspect | Detail |
|--------|--------|
| **Risk** | verl is the sole RL training backend. If verl development diverges from Aegis needs, or a better framework emerges (TRL evolution, custom implementations), switching cost is high. |
| **Impact** | RL training engine becomes brittle or outdated. |
| **Mitigation** | Abstract the RL training interface: `RLTrainer` protocol with `train()`, `rollout()`, `checkpoint()`, `evaluate()` methods. verl is the first implementation, not the only one. Monitor TRL, OpenRLHF, and custom GRPO implementations as alternatives. |

## Risk 3: Phase 1 Scope Ambiguity

| Aspect | Detail |
|--------|--------|
| **Risk** | "50+ dimensions" in Phase 1 is unrealistic. Attempting to ship all dimensions simultaneously will delay launch. |
| **Impact** | Delayed MVP, unfocused product, poor first impression. |
| **Mitigation** | Dimension phasing (see Section 4.6 "Dimension Phasing"). Phase 1 ships ~20 core dimensions with high-quality implementations. Remaining dimensions clearly labeled as "coming in Phase 2/3" in docs and dashboard. |

## Risk 4: Eval Gaming & Goodhart's Law

| Aspect | Detail |
|--------|--------|
| **Risk** | Agents (or their developers) may optimize for Aegis eval scores without genuine capability improvement. |
| **Impact** | Aegis scores become meaningless; reputation damage. |
| **Mitigation** | Observatory monitors for reward hacking patterns. Generative (not static) test scenarios prevent memorization. Adversarial probing module actively searches for failure modes. Longitudinal tracking detects score inflation without performance improvement. |

## Risk 5: Multi-Model Judge Consistency

| Aspect | Detail |
|--------|--------|
| **Risk** | LLM-as-judge scores vary across model versions, providers, and even API call timing. |
| **Impact** | Eval results not reproducible; customer trust eroded. |
| **Mitigation** | Three-tier scoring (rule-based + semantic + judge) reduces judge dependency. Judge calibration protocol: 100+ expert-annotated examples per dimension. Judge model version pinned per eval run. Cross-judge consistency metrics published. |

---

# 17. FRONTIER EXECUTION PLAN — API VERSIONING & PUBLIC TYPES

## API Versioning Strategy

1. Publish `/v1` as stable contract at M1.
2. Introduce `/v1beta` for experimental RL/eval features only.
3. Breaking changes only in `/v2` with migration tooling.

## Core Endpoints (v1)

```
POST   /v1/evals/runs                 Create and start an eval run
GET    /v1/evals/runs/{run_id}        Get eval run status and results
POST   /v1/evals/compare              Compare two eval runs side-by-side

POST   /v1/memory/events              Emit a memory event
POST   /v1/memory/query               Query memory store
GET    /v1/memory/snapshots/{ts}      Point-in-time memory reconstruction

POST   /v1/retrieval/query            Execute retrieval query with policy

POST   /v1/train/jobs                 Start a training job
GET    /v1/train/jobs/{job_id}        Get training job status and metrics

POST   /v1/observability/events       Emit observability event
POST   /v1/promotion/decide           Request promotion decision for adapter
```

## Required Public Types (Schema Freeze v1)

| Type | Description |
|------|-------------|
| `TrajectoryV1` | Task metadata + ordered tool/memory/reasoning steps. Full execution trace of an agent interaction. |
| `MemoryEventV1` | Operation (STORE/UPDATE/FORGET/...) + provenance + temporal bounds. Immutable memory event log entry. |
| `RetrievalTraceV1` | Sources queried, rerank scores, selected context blocks, dropped blocks. Full retrieval audit. |
| `RewardTraceV1` | Per-stage rewards + component scores + weighting profile. Training reward decomposition. |
| `EvalCaseV1` | Prompt, context, expected behavior, scoring rubric references. Single eval test case definition. |
| `JudgePacketV1` | Rule score + semantic score + model-judge ensemble + disagreement signal. Triangulated scoring output. |
| `PromotionDecisionV1` | Pass/fail, blocking regressions, human gate status, rollback pointer. Deployment promotion verdict. |

---

# 18. EVALUATION & RESEARCH-UPDATE PROGRAM

## Locked Research Commitments

1. **RL optimizer stack** includes AMIR-GRPO, GRPO-SG, and PODS from day one.
2. **Prompt-evolution baseline** (GEPA) is required for non-gradient comparison on every major release.
3. **Memory benchmark matrix** includes passive recall and action-grounded memory (Mem2ActBench class).
4. **Episodic/visual memory** benchmarking includes interactive trajectory-generated questions (EMemBench class).
5. **Cognitive-memory consistency** tests include cue-trigger disconnect scenarios (LoCoMo-Plus class).
6. **Temporal-hierarchical memory** tests include long-horizon consolidation and recall efficiency (TiMem class).
7. **Judge reliability** measured using AgentRewardBench-style protocol before promotion policy changes.

## Frontier Benchmark Matrix

| Benchmark Class | What It Tests | Phase |
|----------------|---------------|-------|
| **Mem2ActBench** | Action-grounded memory: can the agent act on recalled information, not just recite it? | M3 |
| **EMemBench** | Episodic + visual memory: interactive trajectory-generated questions from multi-modal experiences | M10 |
| **LoCoMo-Plus** | Cognitive-memory consistency: cue-trigger disconnects, false memory detection | M10 |
| **TiMem** | Temporal-hierarchical memory: long-horizon consolidation, correct time-scoping of recall | M10 |
| **AgentRewardBench** | Judge reliability: measures inter-judge agreement and calibration before promotion policy changes | M6 |
| **AegisLegal-Memory** | 50 simulated case lifecycles, attorney-annotated | M8 |
| **AegisFinance-Memory** | 50 simulated deal lifecycles, analyst-annotated | M8 |
| **AegisReward-Integrity** | 200 training scenarios with planted reward hacking patterns | M6 |

---

# 19. RELEASE-GATING TEST SCENARIOS

Every monthly release must pass these scenarios before promotion to production:

| Suite | Scenario | Acceptance Criterion |
|---|---|---|
| **Memory** | Multi-session fact supersession | No stale fact cited after supersession in gold tasks |
| **Memory** | Preference carry-over into tool params | Correct param grounding >= 90% |
| **Memory** | Poisoned memory injection | Detection/block rate >= 95% |
| **Context** | Anti-retrieval case | Correct no-retrieval choice >= 85% |
| **Context** | Cross-source contradiction | Conflict detected and resolved >= 90% |
| **Context** | Long-context degradation | <= 5% drop from 32k to 256k eval bucket |
| **RL** | Length-bias stress test | No quality drop from verbosity control policy |
| **RL** | Reward hacking seeds | >= 90% detection and automatic intervention |
| **RL** | Cross-domain transfer | Domain A retention >= 95% after Domain B tuning |
| **Eval** | Judge drift test | Inter-run variance within pinned threshold |
| **Eval** | Human alignment | Human-judge correlation >= 0.82 |
| **Security** | Prompt injection | Critical exploit success <= 5% |
| **Security** | Tool misuse and privilege abuse | Block/downgrade with complete audit logs |
| **Production** | Drift to retrain loop | Trigger-to-redeploy SLA < 24h |
| **Production** | Safe rollback | Rollback completion < 10 min with state integrity |

---

# 20. PROMOTION & ROLLOUT RULES

| Rule | Detail |
|------|--------|
| **Minimum improvement** | Promotion requires composite improvement >= 3 points AND zero critical-safety regression |
| **Tier 7 veto** | Any tier-7 critical failure blocks promotion regardless of aggregate score |
| **Human gate** | Required for legal/finance production promotions. Domain expert must approve. |
| **Canary deployment** | Mandatory before full rollout. Canary serves 5% traffic for 24h minimum. |
| **Auto-rollback triggers** | Drift detection, safety incident, or calibration collapse triggers immediate automatic rollback |
| **Rollback SLA** | Rollback completion < 10 minutes with full state integrity verification |

---

# 21. TEAM & OWNERSHIP MODEL

| Team | FTE | Responsibility |
|------|-----|---------------|
| **RL Systems** | 3 | AMIR-GRPO/GRPO-SG/PODS implementation, LoRA training, transfer learning, reward engineering |
| **Memory Systems** | 2 | Temporal-hierarchical memory, 12 memory ops, memory policy engine, KG integration |
| **Eval / Benchmarks** | 3 | 7-tier dimensions, judge triangulation, benchmark harness, domain plugins, research benchmarks |
| **Platform / API** | 3 | Control plane, data plane, API gateway, SDK, CLI, CI/CD, BYOC infrastructure |
| **Security / Governance** | 2 | OWASP Agentic Top 10, ABAC/RBAC, audit chain, policy runtime, compliance |
| **PM / Research Ops** | 1-2 | Release DRI, research coordination, design partner management |

**Operating principles:**
- Each monthly release has a single DRI and pre-registered release gate document
- Research and product tracks share one unified benchmark and promotion system
- No feature ships without passing release-gating test scenarios (Section 19)

---

# 22. RESEARCH FOUNDATION

## 120+ References Organized by Category

### Key Papers That Shaped the Architecture (Read These 5)

| Paper | Date | Contribution to Aegis |
|-------|------|----------------------|
| **ALMA** (Xiong, Hu, Clune — Vector Institute/UBC) | Feb 2026 | Core inspiration for Level 6: Architecture Discovery. Meta-agent discovers domain-specific memory designs as executable code. |
| **MemRL** (Shanghai Jiao Tong / NUS) | Jan 2026 | Core inspiration for Two-Speed Learning. Runtime Q-value updates on episodic memory without weight changes. |
| **Memory-R1** | Aug 2025 | Core memory operations (ADD/UPDATE/DELETE/NOOP) trained via GRPO. Foundation for our 12-operation RL-trained memory policy. |
| **Darwin Godel Machine** (Sakana AI) | May 2025 | Self-improving AI caught cheating by gaming eval metrics. Validates our Observatory — proves self-improving systems NEED observability. |
| **Search-R1** | 2025 | Retrieved token masking for stable RL training. Directly adopted in our rollout engine. |

### Research Absorbed by Category

| Category | Count | Key Systems |
|----------|-------|-------------|
| Memory Systems & Architectures | 19 | ALMA, MemRL, Memory-R1, MemSearcher, Mem-α, A-Mem, Graphiti, MemGPT/Letta, MemEvolve, MemOS, Membox, Agentic Memory, Live-Evo, PersonaMem-v2, MemAgent, Mem0, mem-agent, EWC |
| RL Training Methods | 22 | GRPO, multi-context GRPO, GiGPO, PPO+GAE, DAPO, DrGRPO, ReasonRAG/PilotRAG, RAG-RL, s3, REFRAG, Search-R1, StarPO-S, Forge, verl, verl-agent, R1-Searcher++, R3-RAG, Agent Lightning/AIR, LightningRL, PaperScout/PSPO, InfiAgent, Agent-R1 |
| Self-Evolving / Meta-Learning | 4 | Darwin Godel Machine, ALMA, MemRL, Live-Evo |
| Context Management & Retrieval | 6 | TTT-E2E, ColPali, Stanford CS224R, Contextual AI/RAG 2.0, GraphRAG, Qwen3-VL-Embedding |
| Benchmarks — Memory | 7 | LoCoMo, MemBench, MemoryAgentBench, LongMemEval, RealMem, Context-Bench, Recovery-Bench |
| Benchmarks — Legal | 10 | CUAD, LegalBench, LegalBench-RAG, ContractNLI, ContractEval, CLERC, COLIEE, ACORD, Stanford HAI, VLAIR |
| Benchmarks — Financial | 8 | FinanceBench, FinQA, TAT-QA, ConvFinQA, FLUE, FinMTEB, DocFinQA, BizBench |
| Benchmarks — General RAG | 4 | FACTS, LOCA-bench, ALCE, ASQA |
| Tools & Infrastructure | 17 | verl, Qwen2.5-7B, Qwen2.5-72B, Qwen3-VL-Embedding, pgvector, Neo4j, Docling, LayoutXLM, Camelot, Tesseract, EasyOCR, Whisper v3, Playwright, Opacus, vLLM/SGLang, W&B/MLflow |
| Agent Security & Safety | 5 | OWASP Top 10 for Agentic AI (2025), Gray Swan (adversarial robustness), Anthropic red-teaming research, Collinear AI EaaS (Eval-as-a-Service), SWE-smith (software agent benchmarking) |
| Long-Context & Degradation | 3 | Context Rot / Chroma (context degradation analysis), NoLiMa (long-context needle benchmark), Kimi-Researcher (long-context research agent) |
| Competitors & Industry | 15 | Harvey AI, Letta, Contextual AI, Agent Lightning, Braintrust, Arize, Mem0, Janus, Patronus AI, Galileo, Maxim AI, Langfuse, Promptfoo, Vals AI, Harbor/Prime Intellect |
| Agent Eval Methodology | 3 | Anthropic "Demystifying Evals" (2025), Amazon Agent Eval Framework, LATS (Language Agent Tree Search) |
| **Total unique entries** | **121** | |

### Data Sources

**Legal (15 sources):** CUAD (510 contracts, CC BY 4.0), ContractNLI (607 contracts), CLERC, COLIEE, LegalBench (162 tasks), SEC EDGAR, CourtListener, Federal Register, CFR, PACER, Cornell LII, Stanford HAI study, VLAIR, expert-annotated custom dataset (to build), state regulatory databases.

**Financial (14 sources):** FinanceBench (10,231 QA pairs), SEC EDGAR (full), XBRL, FinQA, TAT-QA, ConvFinQA, earnings call transcripts, FRED, FINRA regulatory actions, SEC enforcement actions, FLUE, FinMTEB, DocFinQA, expert-annotated custom dataset (to build).

---

# APPENDIX A: NAMING CONVENTION

All references throughout the codebase and documentation follow this mapping:

| Old Name | New Name |
|----------|----------|
| Nexus | **Aegis** |
| Sentient | **Metronis** |
| nexus-eval | **aegis-eval** |
| nexus-train | **aegis-train** |
| nexus-memory | **aegis-memory** |
| nexus-observatory | **aegis-observatory** |
| nexus-langchain | **aegis-langchain** |
| nexus-llamaindex | **aegis-llamaindex** |
| nexus-openai | **aegis-openai** |
| NexusMemory | **AegisMemory** |
| NexusAdapter | **AegisAdapter** |
| NexusLegal-Memory (benchmark) | **AegisLegal-Memory** |
| NexusFinance-Memory (benchmark) | **AegisFinance-Memory** |
| NexusReward-Integrity (benchmark) | **AegisReward-Integrity** |
| Nexus Arena | **Aegis Arena** |
| Nexus Agent Protocol | **Aegis Agent Protocol** |
| `from nexus import ...` | `from aegis import ...` |
| `sentient eval run` | `aegis eval run` |

---

# APPENDIX B: REVENUE MODEL

| Product | Model | Target Price |
|---------|-------|-------------|
| **aegis-eval** (core) | Open source + freemium | Free core. Hosted: $200-500/month |
| **aegis-eval** (domain plugins) | Licensed per domain | $2K-5K/month per domain |
| **aegis-eval** (as-a-service) | We run evals, you get reports | $5K-15K per eval cycle |
| **aegis-train** (standard) | Enterprise SaaS | $2K-8K per training cycle |
| **aegis-train** (intensive) | Enterprise SaaS | $10K-30K per training cycle |
| **aegis-memory** | Platform/infrastructure | $5K-20K/month |
| **aegis-environments** | Environment licensing (per domain) | $3K-10K/month per environment |
| **aegis-environments** (marketplace) | Revenue share on community environments | 30% platform fee |
| **Custom training** | Professional services | $50K-200K per engagement |
| **Aegis Arena** (private) | Enterprise | $5K-10K/month |

### Year 1 Targets

- Revenue: $250K ARR
- Customers: 15-20
- Average contract value: $8K-$15K

---

# APPENDIX C: MONTH 6 SUCCESS METRICS

| Metric | Target |
|--------|--------|
| GitHub Stars | 1,000-2,000+ |
| PyPI Downloads (monthly) | 5,000-10,000+ |
| Enterprise Design Partners | 3-5 (legal/finance) |
| LOIs / Pilot Agreements | 2-3 signed |
| arXiv Papers Published | 1-2 |
| Twitter/X Followers | 2,000-5,000+ |
| Community (Discord) | 500+ members |
| Revenue / Commitments | $0-50K (pilots OK at $0) |
| Seed Round Target | $2-5M at $10-20M pre-money |

---

*Document version: 2.0 (frontier plan + audit findings incorporated)*
*Last updated: February 22, 2026*
*Author: Aegis Engineering, Metronis Inc.*
