# Original Plan Capability Matrix

This artifact compares the implemented Aegis repository against the original plan inputs and records evidence-backed status per capability.

## Scope

- Implementation window: Phase 1 to Phase 3 only.
- Explicitly excluded from execution scope: Phase 4 launch/outreach work.
- Canonical machine-readable source: `docs/comparison/original-plan-capability-matrix.csv`.

## Source Documents

- `nexus-definitive-product-spec-v2.md`
- `nexus-complete-build-blueprint.md`
- `nexus-full-possibility-space.md`
- `nexus-end-to-end-walkthrough.md`
- `nexus-audit-and-competitive-comparison.md`
- `docs/architecture.md`

## Matrix Schema

- `capability_id`
- `source_doc`
- `phase`
- `codable`
- `repo_status`
- `evidence_code`
- `evidence_test`
- `gap_action`
- `deferred_by_plan`

## Status Summary

| Metric | Value |
|---|---:|
| Total capabilities | 40 |
| Implemented | 30 |
| Partial | 4 |
| Deferred by plan | 5 |
| Non-codable ignored | 1 |
| Phase P1 rows | 28 |
| Phase P2 rows | 4 |
| Phase P3 rows | 5 |
| Phase P4 rows | 3 |

## Full Capability Matrix

| capability_id | source_doc | phase | codable | repo_status | evidence_code | evidence_test | gap_action | deferred_by_plan |
|---|---|---|---|---|---|---|---|---|
| CAP-001-agent-protocol | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/core/types.py;src/aegis/api/routes/eval.py;src/aegis/api/routes/training.py | tests/test_api.py;tests/integration/test_api_e2e.py | none | false |
| CAP-002-framework-sdks | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/adapters/openai.py;src/aegis/adapters/anthropic.py;src/aegis/adapters/langchain.py;src/aegis/adapters/llamaindex.py;src/aegis/adapters/langgraph.py;src/aegis/adapters/dspy.py;src/aegis/adapters/letta.py | tests/test_adapters.py;tests/test_adapters_real.py | none | false |
| CAP-003-memory-dropin | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/memory/manager.py;src/aegis/memory/operations.py;src/aegis/memory/vector.py | tests/test_memory_operations.py;tests/test_memory_subsystems.py | none | false |
| CAP-004-event-system | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/events/dispatcher.py;src/aegis/events/router.py;src/aegis/events/webhooks.py;src/aegis/api/routes/events.py | tests/test_events_stack.py;tests/test_api_online_events.py | none | false |
| CAP-005-eval-hierarchy | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/eval/dimensions/tier1_memory.py;src/aegis/eval/dimensions/tier2_context.py;src/aegis/eval/dimensions/tier3_learning.py;src/aegis/eval/dimensions/tier4_reasoning.py;src/aegis/eval/dimensions/tier5_metacognition.py;src/aegis/eval/dimensions/tier6_collaborative.py | tests/test_dimensions.py;tests/test_m4_dimensions.py | none | false |
| CAP-006-domain-plugins | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/plugins/legal.py;src/aegis/plugins/finance.py;src/aegis/plugins/safety.py | tests/test_domain_plugins.py;tests/test_plugins.py | none | false |
| CAP-007-training-levels | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/levels.py;src/aegis/training/architecture_discovery.py;src/aegis/training/multi_agent.py | tests/test_training_advanced.py;tests/test_training_architecture_discovery.py;tests/test_training_multi_agent.py | none | false |
| CAP-008-rollout-engine | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/rollout.py;src/aegis/training/engine.py | tests/test_training_engine.py | none | false |
| CAP-009-reward-engine | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/rewards.py;src/aegis/training/reward_refinement.py;src/aegis/eval/benchmarks/reward_integrity.py | tests/test_reward_refinement.py;tests/test_reward_integrity_benchmark.py | none | false |
| CAP-010-grpo-optimizer | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/engine.py;src/aegis/training/optimizers.py;src/aegis/training/verl_bridge.py | tests/test_training_engine.py;tests/test_optimizers.py;tests/test_verl_bridge.py | none | false |
| CAP-011-transfer-protocol | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/transfer.py | tests/test_transfer_protocol.py;tests/test_training_transfer.py | none | false |
| CAP-012-two-speed-learning | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/two_speed_bridge.py;src/aegis/memory/consolidation.py | tests/test_two_speed_bridge.py;tests/test_memory_advanced.py | none | false |
| CAP-013-observatory-signals | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/observatory/monitor.py;src/aegis/observatory/metrics_exporter.py;src/aegis/observatory/hacking_atlas.py | tests/test_observatory_monitor.py;tests/test_observatory_metrics_exporter.py | none | false |
| CAP-014-auto-interventions | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/observatory/auto_intervention.py;src/aegis/observatory/interventions.py | tests/test_observatory_monitor.py;tests/test_security_infra.py | none | false |
| CAP-015-memory-types-and-horizons | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/memory/memory_types.py;src/aegis/memory/time_horizons.py | tests/test_time_horizons.py;tests/test_memory_advanced.py | none | false |
| CAP-016-memory-ops-12 | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/memory/operations.py | tests/test_memory_operations.py | none | false |
| CAP-017-architecture-discovery | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/training/architecture_discovery.py;src/aegis/memory/architecture_search.py | tests/test_training_architecture_discovery.py;tests/test_memory_advanced.py | none | false |
| CAP-018-governance-rbac-abac | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/security/rbac.py;src/aegis/security/abac.py;src/aegis/security/governance.py | tests/test_security_access.py;tests/test_security_abac_encryption.py;tests/test_governance.py | none | false |
| CAP-019-encryption-and-dp | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/security/encryption.py;src/aegis/security/differential_privacy.py;src/aegis/security/compliance_reports.py | tests/test_security_abac_encryption.py;tests/test_security_infra.py | none | false |
| CAP-020-multimodal-ingestion | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/ingestion/audio.py;src/aegis/ingestion/video.py;src/aegis/ingestion/images.py;src/aegis/ingestion/tables.py;src/aegis/ingestion/web.py;src/aegis/ingestion/docling_parser.py;src/aegis/ingestion/xbrl.py | tests/test_ingestion_modalities.py;tests/test_ingestion_advanced.py;tests/test_docling_parser.py;tests/test_xbrl_parser.py | none | false |
| CAP-021-compute-tiering | nexus-definitive-product-spec-v2.md | P1 | true | partial | src/aegis/training/cloud_launcher.py;src/aegis/core/settings.py | tests/test_training_cloud_tracking_hf.py | expand multi-cloud launcher profiles and cost policy docs | false |
| CAP-022-eval-dashboard | nexus-definitive-product-spec-v2.md | P1 | true | implemented | dashboard/src/app/eval/[runId]/page.tsx;dashboard/src/lib/api.ts | tests/integration/test_api_e2e.py | none | false |
| CAP-023-training-console | nexus-definitive-product-spec-v2.md | P1 | true | partial | dashboard/src/app/training/page.tsx;dashboard/src/app/training/AdapterManagement.tsx | tests/test_training_engine.py | add live observatory stream and job-control e2e UI tests | false |
| CAP-024-memory-explorer | nexus-definitive-product-spec-v2.md | P1 | true | partial | dashboard/src/app/memory/page.tsx;dashboard/src/app/memory/ProvenanceViewer.tsx | tests/test_memory_event_log.py | expand graph traversal and snapshot drill-down UI flows | false |
| CAP-025-rubric-builder | nexus-definitive-product-spec-v2.md | P1 | true | partial | src/aegis/eval/scorers/rubrics.py;dashboard/src/app/rubrics/ | tests/test_domain_plugins.py | wire full no-code rubric-to-reward calibration workflow | false |
| CAP-026-novel-benchmarks | nexus-definitive-product-spec-v2.md | P1 | true | implemented | src/aegis/eval/benchmarks/legal_memory_scale.py;src/aegis/eval/benchmarks/reward_integrity.py | tests/test_legal_memory_scale_benchmark.py;tests/test_reward_integrity_benchmark.py | none | false |
| CAP-027-comparison-matrix | nexus-audit-and-competitive-comparison.md | P1 | true | implemented | docs/comparison/original-plan-capability-matrix.md;docs/comparison/original-plan-capability-matrix.csv | scripts/verify_plan_acceptance.sh | none | false |
| CAP-028-gpu-env-validation | nexus-end-to-end-walkthrough.md | P2 | true | implemented | scripts/training/validate_gpu_env.sh | none | none | false |
| CAP-029-gpu-proof-runner | nexus-end-to-end-walkthrough.md | P2 | true | implemented | scripts/training/run_gpu_proof.sh;configs/training/legal_gpu_smoke.yaml;configs/eval/legal_baseline.yaml;configs/eval/legal_trained.yaml | none | none | false |
| CAP-030-proof-artifact-schema | nexus-end-to-end-walkthrough.md | P2 | true | implemented | src/aegis/training/proof_artifacts.py;scripts/training/collect_proof.py | tests/test_training_proof_artifacts.py | none | false |
| CAP-031-closed-loop-real-backend | nexus-end-to-end-walkthrough.md | P2 | true | implemented | examples/closed_loop_demo.py;scripts/run_closed_loop_demo.sh | tests/test_closed_loop_demo.py | none | false |
| CAP-032-release-prep-scripts | nexus-complete-build-blueprint.md | P3 | true | implemented | scripts/release/prepare_release.sh;scripts/release/smoke_install_check.sh;docs/runbooks/publish_pypi_github_ghcr.md | none | none | false |
| CAP-033-release-notes-template | nexus-complete-build-blueprint.md | P3 | true | implemented | ops/release/release_notes_v0.1.0.md | none | none | false |
| CAP-034-live-pypi-publish | nexus-complete-build-blueprint.md | P3 | true | deferred_by_plan | docs/runbooks/publish_pypi_github_ghcr.md | none | manual publish intentionally deferred in this execution pass | true |
| CAP-035-live-github-release | nexus-complete-build-blueprint.md | P3 | true | deferred_by_plan | docs/runbooks/publish_pypi_github_ghcr.md | none | manual release creation deferred in this execution pass | true |
| CAP-036-live-ghcr-push | nexus-complete-build-blueprint.md | P3 | true | deferred_by_plan | docs/runbooks/publish_pypi_github_ghcr.md | none | manual container publish deferred in this execution pass | true |
| CAP-037-phase4-launch-execution | nexus-complete-build-blueprint.md | P4 | false | deferred_by_plan | ops/release/closed_loop_demo_video_script.md;ops/launch/ | none | explicitly excluded by requested scope | true |
| CAP-038-competitive-positioning | nexus-audit-and-competitive-comparison.md | P4 | false | non_codable_ignored | docs/architecture.md | none | business narrative tracked but not a code deliverable | false |
| CAP-039-investor-and-partner-outreach | nexus-audit-and-competitive-comparison.md | P4 | false | deferred_by_plan | ops/fundraising/;ops/launch/ | none | phase 4 excluded from current implementation | true |
| CAP-040-frontier-architecture-alignment | docs/architecture.md | P1 | true | implemented | docs/architecture.md;src/aegis/api/app.py;src/aegis/training/engine.py;src/aegis/security/governance.py | tests/integration/test_api_e2e.py;tests/test_training_engine.py;tests/test_governance.py | none | false |
