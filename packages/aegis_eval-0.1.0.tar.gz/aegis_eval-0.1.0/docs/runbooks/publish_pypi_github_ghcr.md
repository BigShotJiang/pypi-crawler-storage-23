# Publish Runbook (PyPI, GitHub Release, GHCR)

This runbook documents manual publish commands for Phase 3.
It does **not** perform publish automatically.

## Preconditions

- Local release prep completed:

```bash
bash scripts/release/prepare_release.sh
```

- Credentials available in your shell:

```bash
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-..."
export GH_TOKEN="ghp_..."
```

## 1. TestPyPI Upload (Recommended)

```bash
twine upload --repository testpypi dist/*
```

Validate install from TestPyPI:

```bash
python -m venv /tmp/aegis-testpypi
source /tmp/aegis-testpypi/bin/activate
pip install --upgrade pip
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple aegis-eval
python -c "import aegis; print(aegis.__version__)"
```

## 2. Production PyPI Upload

```bash
twine upload dist/*
```

## 3. Git Tag + GitHub Release

```bash
git tag -a v0.1.0 -m "Aegis v0.1.0"
git push origin v0.1.0
```

Create a GitHub release:

```bash
gh release create v0.1.0 dist/* \
  --title "Aegis v0.1.0" \
  --generate-notes
```

## 4. GHCR Docker Publish

Build and push image:

```bash
docker build -t ghcr.io/metronis-space/aegis:0.1.0 .
echo "$GH_TOKEN" | docker login ghcr.io -u <github-user> --password-stdin
docker push ghcr.io/metronis-space/aegis:0.1.0
```

## 5. Post-Publish Checks

- PyPI package page resolves.
- `pip install aegis-eval` works in clean venv.
- GitHub release has wheels/sdist attached.
- GHCR image pull succeeds.
- Links to proof artifacts and HuggingFace adapter are present.
