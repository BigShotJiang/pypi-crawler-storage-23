# GPU Training Proof Runbook

This runbook executes a reproducible proof pipeline for Phase 2 artifacts.

## Objective

Produce these canonical artifacts in `results/proof/`:

- `baseline_eval.json`
- `trained_eval.json`
- `delta_report.json`
- `adapter_manifest.json`

## Prerequisites

- Python environment with Aegis installed (`pip install -e ".[dev,full]"` or equivalent).
- CUDA GPU host for real training (`torch` + `verl` + NVIDIA driver).
- Optional: `HF_TOKEN` set for downstream adapter publishing.

## 1. Validate Environment

```bash
bash scripts/training/validate_gpu_env.sh --json results/proof/gpu_env.json
```

For strict validation (exit non-zero if real GPU path is unavailable):

```bash
bash scripts/training/validate_gpu_env.sh --strict
```

## 2. Dry-Run the Proof Pipeline

```bash
bash scripts/training/run_gpu_proof.sh --dry-run
```

This confirms all command wiring without launching training.

## 3. Execute Proof Pipeline

```bash
bash scripts/training/run_gpu_proof.sh
```

Optional overrides:

```bash
bash scripts/training/run_gpu_proof.sh \
  --training-config configs/training/legal_gpu_smoke.yaml \
  --baseline-config configs/eval/legal_baseline.yaml \
  --trained-config configs/eval/legal_trained.yaml \
  --output-dir results/proof
```

## 4. Collect / Rebuild Artifacts Manually

If baseline and trained evals already exist:

```bash
python scripts/training/collect_proof.py \
  --baseline results/proof/baseline \
  --trained results/proof/trained \
  --training-result results/proof/training_result.json \
  --config configs/training/legal_gpu_smoke.yaml \
  --output-dir results/proof
```

## 5. Closed-Loop Demo (Real Artifact Mode)

```bash
python examples/closed_loop_demo.py \
  --backend real \
  --real-baseline results/proof/baseline_eval.json \
  --real-trained results/proof/trained_eval.json \
  --output results/proof/closed_loop_demo_real.json
```

## Expected Outputs

- `delta_report.json` should contain positive `overall_delta` for a successful improvement cycle.
- `adapter_manifest.json` should include backend, model name, and adapter path metadata.
- `gpu_env.json` should capture hardware/software evidence for reproducibility.
