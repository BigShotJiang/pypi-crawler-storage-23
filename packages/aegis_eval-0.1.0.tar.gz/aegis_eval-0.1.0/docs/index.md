# Aegis

**The Adaptive Intelligence Layer for AI Agents** -- eval, train, and memory on one platform.

Aegis is an open-source framework by [Metronis, Inc.](https://aegis.dev) that provides three integrated products for building, evaluating, and improving AI agents.

| Product | What it does |
|---------|-------------|
| **Aegis Eval** | 101 evaluation dimensions, triangulated scoring, scenario generation, diagnostic reporting |
| **Aegis Train** | GRPO-based RL training engine with progressive memory-op unlocking and Observatory monitoring |
| **Aegis Memory** | 7 memory types, 12 RL-trained operations, knowledge graph, vector store, provenance tracking |

## Architecture

```
+----------------------------------------------------------+
|                      Aegis Platform                      |
+-----------------+-----------------+----------------------+
|   Aegis Eval    |   Aegis Train   |    Aegis Memory      |
|   101 dims      |   GRPO engine   |  7 types / 12 ops    |
|   3 scorers     |   Observatory   |  KG / Vectors / Log  |
+-----------------+-----------------+----------------------+
|           Adapters / API / CLI / Plugins                 |
+----------------------------------------------------------+
```

## Quick links

- [Quickstart](quickstart.md) -- install and run your first evaluation
- [CLI Reference](cli-reference.md) -- all commands and flags
- [Dimensions](dimensions.md) -- full 101-dimension catalog
- [Configuration](configuration.md) -- YAML config and environment variables
- [Scoring](scoring.md) -- how triangulated scoring works
- [Plugins](plugins.md) -- domain plugins and custom extensions
- [Adapters](adapters.md) -- agent framework integrations
- [API Reference](api-reference.md) -- REST API endpoints

## Installation

```bash
pip install aegis-eval
```

See the [Quickstart](quickstart.md) for more installation options and your first evaluation run.

## License

Apache License 2.0. See [LICENSE](https://github.com/metronis-space/aegis/blob/main/LICENSE) for details.
