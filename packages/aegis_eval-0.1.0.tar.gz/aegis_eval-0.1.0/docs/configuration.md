# Configuration

Aegis is configured via a YAML file (typically `eval.yaml`) and environment variables.

## YAML config reference

```yaml
eval:
  # Dimensions to evaluate: "all" or a list of IDs
  dimensions: all

  # Domain plugins to load
  domain_plugins:
    - legal
    - finance

  scoring:
    programmatic: true    # Rule-based scorer
    semantic: true         # Embedding-based scorer
    llm_judge:
      model: "gpt-4o"
      # provider: openai   # Auto-detected from model name; override explicitly
      rubric: default
      temperature: 0.0
      max_tokens: 2048

  scenarios:
    count: 200             # Number of test scenarios to generate
    difficulty: medium     # easy, medium, or hard
    seed: 42               # Optional seed for reproducibility
    source: generated      # Or path to custom test cases

  output:
    format: [json, html]   # Output formats
    path: ./results/       # Output directory
    include_traces: true
    include_diagnostic: true

ci:
  fail_under: 0.75         # Minimum composite score
  fail_dimensions:          # Per-dimension thresholds
    retention_accuracy: 0.80
    pii_leakage_prevention: 0.90
```

## Environment variables

| Variable | Description | Example |
|----------|-------------|---------|
| `AEGIS_LLM_PROVIDER` | Force LLM provider: `openai`, `anthropic`, or `mock` | `anthropic` |
| `AEGIS_LLM_MODEL` | Override the judge model name | `claude-sonnet-4-5-20250929` |
| `AEGIS_OPENAI_API_KEY` | OpenAI API key (preferred for OpenAI) | `sk-...` |
| `AEGIS_ANTHROPIC_API_KEY` | Anthropic API key (preferred for Anthropic) | `sk-ant-...` |
| `AEGIS_LLM_API_KEY` | Generic fallback API key (used when provider-specific key is absent) | `sk-...` |

### API security/runtime settings

| Variable | Description | Example |
|----------|-------------|---------|
| `AEGIS_CORS_ORIGINS` | Comma-separated allowed CORS origins | `https://app.example.com,https://staging.example.com` |
| `AEGIS_RATE_LIMIT_RPM` | Rate-limit refill budget per minute | `120` |
| `AEGIS_RATE_LIMIT_BURST` | Additional burst tokens above RPM | `30` |
| `AEGIS_RATE_LIMIT_ANONYMOUS` | Apply rate limits to non-API-key traffic by IP (`true`/`false`) | `false` |
| `AEGIS_MAX_REQUEST_SIZE` | Maximum request body bytes before `413` | `10485760` |

### Provider resolution order

1. If `AEGIS_LLM_PROVIDER` is set, use that provider explicitly
2. If `AEGIS_LLM_MODEL` is set, override the model from config
3. Auto-detect provider from the model name:
    - `gpt-*`, `o1-*`, `o3-*`, `o4-*` -> OpenAI
    - `claude-*` -> Anthropic
4. Look for an API key: provider-specific first (`AEGIS_OPENAI_API_KEY` or `AEGIS_ANTHROPIC_API_KEY`), then generic (`AEGIS_LLM_API_KEY`)
5. No key found -> fall back to the deterministic `MockLLMBackend`

## Deterministic mode

When no API key is set, Aegis runs in fully deterministic local mode:

- **LLM Judge** uses a `MockLLMBackend` that scores via text similarity heuristics
- **Semantic Scorer** falls back to `0.0` if `sentence-transformers` is not installed
- **Rule-Based Scorer** always works (no external dependencies)

This makes Aegis safe to run in CI without any API keys configured.
