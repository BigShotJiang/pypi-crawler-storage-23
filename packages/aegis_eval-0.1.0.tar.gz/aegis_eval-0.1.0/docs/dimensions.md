# Evaluation Dimensions

Aegis evaluates AI agents across **101 dimensions** organized into 7 core tiers plus 3 domain-specific plugins.

## Tier 1: Memory Fidelity (6 dimensions)

| ID | Name | Description |
|---|---|---|
| `retention_accuracy` | Retention Accuracy | Accuracy of verbatim and semantic retention of stored facts |
| `update_correctness` | Update Correctness | Correctness of in-place memory updates without side-effect corruption |
| `selective_forgetting` | Selective Forgetting | Ability to forget specific facts without collateral information loss |
| `cross_reference_integrity` | Cross-Reference Integrity | Consistency and correctness of links between related memory entries |
| `temporal_reasoning` | Temporal Reasoning | Correct handling of time-sensitive facts and temporal validity windows |
| `provenance_tracking` | Provenance Tracking | Accuracy and completeness of provenance metadata attached to memories |

## Tier 2: Context Intelligence (8 dimensions)

| ID | Name | Description |
|---|---|---|
| `retrieval_precision` | Retrieval Precision | Precision of retrieved context relative to the query |
| `retrieval_depth_calibration` | Retrieval Depth Calibration | Appropriateness of retrieval depth relative to query complexity |
| `source_routing` | Source Routing | Accuracy of routing queries to the correct retrieval backend |
| `staleness_detection` | Staleness Detection | Detection and deprioritization of outdated context blocks |
| `adversarial_robustness` | Adversarial Robustness | Robustness of retrieval pipeline against adversarial query perturbations |
| `anti_retrieval_judgment` | Anti-Retrieval Judgment | Correctness of the decision to skip retrieval when context is unnecessary |
| `iterative_retrieval` | Iterative Retrieval | Quality of iterative query refinement across multiple retrieval rounds |
| `context_length_robustness` | Context Length Robustness | Stability of answer quality across varying context window sizes |

## Tier 3: Learning Dynamics (6 dimensions)

| ID | Name | Description |
|---|---|---|
| `learning_curve` | Learning Curve | Rate of performance improvement as more examples are provided |
| `transfer` | Transfer | Generalization of learned patterns to related but unseen tasks |
| `stability` | Stability | Resistance to catastrophic forgetting and performance degradation |
| `attribution_accuracy` | Attribution Accuracy | Accuracy of credit assignment across contributing factors |
| `sample_efficiency` | Sample Efficiency | Number of examples required to reach a target performance level |
| `plateau_detection` | Plateau Detection | Detection of and strategic response to learning plateaus |

## Tier 4: Reasoning Quality (8 dimensions)

| ID | Name | Description |
|---|---|---|
| `relevance_explanation` | Relevance Explanation | Quality of explanations for context relevance to the user query |
| `gap_identification` | Gap Identification | Detection of knowledge gaps and missing information in context |
| `source_reliability_assessment` | Source Reliability Assessment | Accuracy of source reliability and credibility assessments |
| `contradiction_detection` | Contradiction Detection | Accuracy of detecting contradictions across retrieved sources |
| `multi_hop_synthesis` | Multi-Hop Synthesis | Quality of multi-hop reasoning that chains evidence across sources |
| `coherence_over_time` | Coherence Over Time | Logical consistency of reasoning across multiple conversation turns |
| `bias_detection` | Bias Detection | Detection and mitigation of cognitive biases in reasoning |
| `equal_treatment` | Equal Treatment | Fairness of treatment and consistency across demographic groups |

## Tier 5: Meta-Cognition (5 dimensions)

| ID | Name | Description |
|---|---|---|
| `calibration` | Calibration | Alignment between expressed confidence and actual accuracy |
| `explainability` | Explainability | Quality and faithfulness of self-generated decision explanations |
| `failure_prediction` | Failure Prediction | Accuracy of predicting when own output is likely to be incorrect |
| `strategy_adaptation` | Strategy Adaptation | Dynamic adaptation of reasoning strategy based on task characteristics |
| `self_diagnosis` | Self-Diagnosis | Quality of self-diagnosis when the agent identifies its own errors |

## Tier 6: Collaborative Context (10 dimensions)

| ID | Name | Description |
|---|---|---|
| `relevant_sharing` | Relevant Sharing | Precision and recall of information shared with collaborating agents |
| `contradiction_resolution` | Contradiction Resolution | Quality of resolution when peer agents provide conflicting information |
| `shared_model_maintenance` | Shared Model Maintenance | Accuracy of the shared world model maintained across collaborating agents |
| `confidentiality` | Confidentiality | Enforcement of information boundaries and access controls |
| `inter_agent_communication` | Inter-Agent Communication | Efficiency, clarity, and correctness of inter-agent messaging |
| `task_delegation_efficiency` | Task Delegation Efficiency | Efficiency and correctness of task decomposition and delegation |
| `shared_state_consistency` | Shared State Consistency | Consistency of shared state when multiple agents operate concurrently |
| `cascading_failure_propagation` | Cascading Failure Propagation | Containment of failures to prevent cascading across the agent network |
| `multi_agent_cost_efficiency` | Multi-Agent Cost Efficiency | Token and compute efficiency of multi-agent collaboration |
| `role_adherence` | Role Adherence | Consistency of behaviour within the agent's assigned role boundaries |

## Tier 7: Security & Adversarial (8 dimensions)

| ID | Name | Description |
|---|---|---|
| `prompt_injection_resistance` | Prompt Injection Resistance | Resilience against direct and indirect prompt injection attempts |
| `memory_poisoning_detection` | Memory Poisoning Detection | Detection and rejection of attempts to poison the memory store |
| `tool_misuse_prevention` | Tool Misuse Prevention | Prevention of dangerous, unauthorized, or unintended tool invocations |
| `pii_leakage_prevention` | PII Leakage Prevention | Detection and prevention of PII exposure in agent outputs |
| `jailbreak_resistance` | Jailbreak Resistance | Resilience against jailbreak attacks and system prompt extraction |
| `privilege_escalation_detection` | Privilege Escalation Detection | Detection and prevention of privilege escalation attempts |
| `policy_violation_detection` | Policy Violation Detection | Detection of agent outputs that violate safety or business policies |
| `cascading_failure_resilience` | Cascading Failure Resilience | Containment of adversarially-triggered cascading failure scenarios |

---

## Domain Plugins

### Legal (18 dimensions)

| ID | Name | Description |
|---|---|---|
| `clause_retention` | Clause Retention | Accuracy of preserving original clause language and intent |
| `precedent_tracking` | Precedent Tracking | Ability to identify and track relevant legal precedents |
| `supersession_awareness` | Supersession Awareness | Detection of superseded statutes, rules, or clauses |
| `cross_reference_integrity` | Cross-Reference Integrity | Correctness of internal and external cross-references |
| `citation_validity` | Citation Validity | Verification that legal citations are valid and current |
| `jurisdiction_accuracy` | Jurisdiction Accuracy | Correctness of jurisdictional applicability claims |
| `relevance_precision` | Relevance Precision | Precision of retrieved documents relative to the query |
| `completeness` | Completeness | Coverage of all legally relevant issues and materials |
| `issue_spotting` | Issue Spotting | Ability to identify key legal issues in a fact pattern |
| `argument_chain_validity` | Argument Chain Validity | Logical coherence of multi-step legal arguments |
| `counter_argument_awareness` | Counter-Argument Awareness | Recognition and addressing of opposing legal arguments |
| `risk_calibration` | Risk Calibration | Accuracy of legal risk assessments and probability estimates |
| `hallucination_rate` | Hallucination Rate | Frequency of fabricated legal facts, cases, or statutes |
| `confidentiality` | Confidentiality | Protection of confidential client information |
| `privilege_preservation` | Privilege Preservation | Maintenance of attorney-client and work-product privilege |
| `audit_trail` | Audit Trail | Completeness and integrity of the decision audit trail |
| `fair_representation` | Fair Representation | Equitable treatment of all parties in legal analysis |
| `equal_treatment_under_law` | Equal Treatment Under Law | Consistency of legal standards applied regardless of party identity |

### Finance (20 dimensions)

| ID | Name | Description |
|---|---|---|
| `numerical_retention` | Numerical Retention | Accuracy of preserving numerical values from source documents |
| `cross_document_reconciliation` | Cross-Document Reconciliation | Consistency of figures across multiple financial documents |
| `market_data_currency` | Market Data Currency | Use of up-to-date market data and pricing information |
| `entity_tracking` | Entity Tracking | Correct identification and tracking of corporate entities |
| `temporal_financial_tracking` | Temporal Financial Tracking | Proper handling of time-series financial data and periods |
| `source_document_precision` | Source Document Precision | Precision of references back to source financial documents |
| `regulatory_reference_accuracy` | Regulatory Reference Accuracy | Correctness of regulatory citations (SEC filings, GAAP, etc.) |
| `comparable_transaction_relevance` | Comparable Transaction Relevance | Relevance and appropriateness of comparable transaction selections |
| `data_recency` | Data Recency | Verification that data used is sufficiently current |
| `numerical_computation_accuracy` | Numerical Computation Accuracy | Correctness of financial calculations and derived metrics |
| `materiality_judgment` | Materiality Judgment | Appropriate assessment of financial materiality thresholds |
| `risk_factor_completeness` | Risk Factor Completeness | Comprehensive identification of relevant risk factors |
| `trend_identification` | Trend Identification | Ability to identify and characterise financial trends |
| `scenario_analysis` | Scenario Analysis | Quality and plausibility of financial scenario modelling |
| `hallucination_rate` | Hallucination Rate | Frequency of fabricated financial data, ratios, or events |
| `audit_trail_completeness` | Audit Trail Completeness | Completeness of the decision and computation audit trail |
| `insider_information_handling` | Insider Information Handling | Proper treatment and isolation of material non-public information |
| `finra_sec_compliance` | FINRA/SEC Compliance | Adherence to FINRA and SEC regulatory requirements |
| `fair_lending_alignment` | Fair Lending Alignment | Compliance with fair lending regulations (ECOA, FHA) |
| `disparate_impact_detection` | Disparate Impact Detection | Identification of potential disparate impact in financial decisions |

### Safety (12 dimensions)

| ID | Name | Description |
|---|---|---|
| `prompt_injection_detection` | Prompt Injection Detection | Ability to detect and neutralise prompt injection attacks |
| `jailbreak_attempt_classification` | Jailbreak Attempt Classification | Classification accuracy for jailbreak attempts |
| `input_sanitization_validation` | Input Sanitization Validation | Effectiveness of input sanitisation and validation routines |
| `adversarial_input_detection` | Adversarial Input Detection | Detection of adversarially crafted inputs designed to mislead |
| `pii_leakage_detection` | PII Leakage Detection | Identification and prevention of PII leaks |
| `harmful_content_filtering` | Harmful Content Filtering | Effectiveness of filtering harmful, violent, or illegal content |
| `policy_compliance_verification` | Policy Compliance Verification | Verification that outputs comply with organisational policies |
| `toxicity_scoring` | Toxicity Scoring | Measurement of toxic, biased, or offensive language in outputs |
| `tool_call_validation` | Tool Call Validation | Validation that tool calls are authorised and correctly scoped |
| `privilege_boundary_enforcement` | Privilege Boundary Enforcement | Enforcement of least-privilege boundaries for agent actions |
| `resource_consumption_limits` | Resource Consumption Limits | Adherence to CPU, memory, and API call budget limits |
| `cascading_failure_containment` | Cascading Failure Containment | Containment of failures to prevent cascading across components |
