# Quickstart

## Installation

**Core package:**

```bash
pip install aegis-eval
```

**With optional extras:**

```bash
pip install aegis-eval[api]      # + FastAPI server
pip install aegis-eval[scoring]  # + sentence-transformers, numpy
pip install aegis-eval[all]      # Everything
```

**Development setup:**

```bash
git clone https://github.com/metronis-space/aegis.git
cd aegis
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,all]"
```

Requires **Python 3.11+**.

## Run your first evaluation

### Python

```python
from aegis import Evaluator, EvalConfig

evaluator = Evaluator(config=EvalConfig(dimensions="all"))
result = evaluator.run()

print(f"Overall score: {result.overall_score:.2%}")
for tier_name, tier_score in result.tier_scores.items():
    print(f"  {tier_name}: {tier_score:.2%}")
```

### CLI

```bash
aegis eval run --config eval.yaml
```

### Inspect dimensions

```bash
aegis eval dimensions
aegis eval dimensions --domain legal
```

## Configure the LLM judge

By default, Aegis uses a deterministic mock backend when no API key is set.
To use a real LLM judge, set the appropriate environment variables:

=== "OpenAI"

    ```bash
    export AEGIS_OPENAI_API_KEY=sk-...
    aegis eval run --config eval.yaml
    ```

=== "Anthropic"

    ```bash
    export AEGIS_ANTHROPIC_API_KEY=sk-ant-...
    export AEGIS_LLM_MODEL=claude-sonnet-4-5-20250929
    aegis eval run --config eval.yaml
    ```

=== "Generic (OpenAI-compatible)"

    ```bash
    export AEGIS_LLM_API_KEY=sk-...
    aegis eval run --config eval.yaml
    ```

The provider is auto-detected from the model name (`gpt-*` / `o1-*` / `o3-*` / `o4-*` for OpenAI, `claude-*` for Anthropic). Override with `AEGIS_LLM_PROVIDER=openai|anthropic|mock`.

## CI integration

Add Aegis to your CI pipeline with a pass/fail gate:

```bash
pip install aegis-eval
aegis eval run --config eval.yaml --fail-under 0.75
```

The CLI exits with code 1 if the composite score falls below the threshold.

## Next steps

- [Configuration](configuration.md) -- full YAML config reference
- [Dimensions](dimensions.md) -- browse all 101 evaluation dimensions
- [Plugins](plugins.md) -- add domain-specific dimensions
- [Adapters](adapters.md) -- connect your agent framework
