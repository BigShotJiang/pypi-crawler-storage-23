# Agent Adapters

Adapters connect agent frameworks to Aegis, normalizing interactions into `TrajectoryV1` format for evaluation.

## Built-in adapters

### OpenAI

Wraps the OpenAI Assistants API.

```python
from openai import OpenAI
from aegis.adapters import OpenAIAdapter

client = OpenAI()
adapter = OpenAIAdapter(client=client, assistant_id="asst_xyz123")
```

### Anthropic

Wraps the Anthropic Messages API.

```python
from anthropic import Anthropic
from aegis.adapters import AnthropicAdapter

client = Anthropic()
adapter = AnthropicAdapter(client=client, model="claude-sonnet-4-5-20250929")
```

### LangChain

Wraps LangChain `AgentExecutor` or any runnable with `.invoke()`.

```python
from aegis.adapters import LangChainAdapter

adapter = LangChainAdapter(agent_executor=executor, agent_id="my_agent")
```

### LlamaIndex

Wraps LlamaIndex query engines.

```python
from llama_index.core import VectorStoreIndex
from aegis.adapters import LlamaIndexAdapter

index = VectorStoreIndex.from_documents(docs)
adapter = LlamaIndexAdapter(query_engine=index.as_query_engine())
```

### REST

Generic HTTP adapter for any REST-compatible agent endpoint.

```python
from aegis.adapters import RESTAdapter

adapter = RESTAdapter(
    url="http://my-agent:8000/eval",
    headers={"Authorization": "Bearer token123"},
    timeout=120.0,
)
```

The REST adapter expects the agent to return JSON with an `"output"` field:

```json
{
    "output": "agent answer text",
    "steps": [],
    "metadata": {}
}
```

### CrewAI

Wraps CrewAI `Crew` instances.

```python
from crewai import Crew
from aegis.adapters import CrewAIAdapter

adapter = CrewAIAdapter(crew=crew, agent_id="my_crew")
```

### AutoGen

Wraps Microsoft AutoGen agents.

```python
from autogen import AssistantAgent
from aegis.adapters import AutoGenAdapter

adapter = AutoGenAdapter(agent=agent, agent_id="autogen_assistant")
```

## Using adapters with eval

Pass an adapter to the CLI via the `--agent` flag (REST only) or configure it in Python:

```python
from aegis import Evaluator, EvalConfig
from aegis.adapters import AnthropicAdapter
from anthropic import Anthropic

adapter = AnthropicAdapter(client=Anthropic(), model="claude-sonnet-4-5-20250929")
evaluator = Evaluator(config=EvalConfig(dimensions="all"))
result = evaluator.run(agent=adapter)
```

## Custom adapters

Implement the `AgentAdapter` base class:

```python
from aegis.adapters.base import AgentAdapter
from aegis.core.types import EvalCaseV1, TrajectoryV1


class MyAdapter(AgentAdapter):
    @property
    def name(self) -> str:
        return "my_adapter"

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        # Call your agent and return a TrajectoryV1
        ...
```
