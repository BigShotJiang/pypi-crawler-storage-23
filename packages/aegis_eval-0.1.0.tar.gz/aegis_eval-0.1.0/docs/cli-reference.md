# CLI Reference

The `aegis` CLI is built with [Typer](https://typer.tiangolo.com/) and organized into command groups.

## `aegis version`

Print the Aegis version and exit.

```bash
aegis version
```

## `aegis eval`

### `aegis eval run`

Run an evaluation against an agent.

```bash
aegis eval run [OPTIONS]
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--config` | `-c` | Path | — | Path to `eval.yaml` configuration file |
| `--dimensions` | `-d` | str | — | Comma-separated dimension IDs to evaluate |
| `--agent` | `-a` | str | — | Agent REST endpoint URL |
| `--domain` | | str | — | Domain filter (e.g. `legal`, `finance`) |
| `--fail-under` | | float | — | Minimum composite score to pass (exit 1 if below) |
| `--output` | `-o` | Path | — | Output directory for results |

CLI flags override values from the YAML config.

**Examples:**

```bash
# Run with config file
aegis eval run --config eval.yaml

# Run specific dimensions
aegis eval run --dimensions retention_accuracy,citation_validity

# Run with fail threshold
aegis eval run --config eval.yaml --fail-under 0.80

# Run against a REST agent
aegis eval run --config eval.yaml --agent http://localhost:8000/eval
```

### `aegis eval dimensions`

List all registered evaluation dimensions.

```bash
aegis eval dimensions [OPTIONS]
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--domain` | `-d` | str | — | Filter by domain (`legal`, `finance`, `safety`) |

**Examples:**

```bash
aegis eval dimensions
aegis eval dimensions --domain legal
```

### `aegis eval compare`

Compare two evaluation runs side by side.

```bash
aegis eval compare --runs RUN_A --runs RUN_B
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--runs` | `-r` | str | — | Run ID (provide exactly twice) |

### `aegis eval report`

Generate an evaluation report for a completed run.

```bash
aegis eval report --run RUN_ID [OPTIONS]
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--run` | `-r` | str | — | Run ID to report on |
| `--format` | `-f` | str | `json` | Output format: `json`, `text`, `html`, `pdf` |
| `--output` | `-o` | Path | — | Output file path |

**Examples:**

```bash
aegis eval report --run abc123 --format json --output report.json
aegis eval report --run abc123 --format html
```

## `aegis memory`

### `aegis memory health`

Display memory subsystem health status.

```bash
aegis memory health
```

### `aegis memory audit`

Display the memory subsystem audit trail.

```bash
aegis memory audit
```

## `aegis train`

### `aegis train start`

Create a new training job.

```bash
aegis train start [OPTIONS]
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--model` | `-m` | str | `base-agent-v1` | Base model name |
| `--trainer` | `-t` | str | `amir-grpo` | Trainer type: `amir-grpo` or `grpo-sg` |
| `--lr` | | float | `1e-5` | Learning rate |

### `aegis train status`

Show the status of a training job.

```bash
aegis train status --job-id JOB_ID
```

| Flag | Short | Type | Default | Description |
|------|-------|------|---------|-------------|
| `--job-id` | `-j` | str | — | Training job ID |
