# Glossary

Definitions of all Aegis-specific terms, algorithms, and concepts.

---

## Algorithms & Training

**AMIR-GRPO** (Adaptive Multi-stage Iterative Reward GRPO)
: The primary RL training algorithm in Aegis Train. Decomposes rewards across multiple evaluation stages and applies group-relative policy optimisation with dynamic reward weighting.

**GRPO-SG** (GRPO with Staged Gating)
: Training algorithm for the memory policy network. Progressively unlocks more complex memory operations across training stages using gated curriculum learning.

**DrGRPO** (Dynamic Reward GRPO)
: Length-bias elimination GRPO optimizer. Normalises rewards by response length to prevent verbose-but-empty answers from gaming the reward signal.

**DAPO** (Dynamic Entropy-Aware Policy Optimization)
: Optimizer that maintains policy entropy during long training runs via an adaptive entropy bonus, preventing premature policy collapse.

**GiGPO** (Group-Invariant Gradient Policy Optimization)
: Optimizer with importance sampling corrections that allows efficient reuse of off-policy rollouts from previous policy versions.

**Forge**
: Variance-reduced optimizer that maintains a running baseline of rewards (via EMA) and uses it as a control variate to reduce gradient variance.

**PODS** (Prioritized On-policy Data Selection)
: Rollout down-selection strategy applied before optimizer updates. Ranks rollouts by a composite signal of reward, novelty, and length penalty, then keeps only the top-k fraction.

**EWC** (Elastic Weight Consolidation)
: Regularisation technique that penalises changes to parameters important for previously learned domains, mitigating catastrophic forgetting during multi-domain training.

---

## Evaluation

**Dimension**
: A single measurable aspect of agent intelligence (e.g., "Retention Accuracy", "Causal Reasoning"). Each dimension has a unique ID, belongs to one tier, and implements a `score()` method.

**Tier**
: One of 7 hierarchical levels of evaluation complexity:

| Tier | Name | Focus |
|------|------|-------|
| 1 | Memory Fidelity | Accurate storage, update, retrieval |
| 2 | Context Intelligence | Relevance, grounding, retrieval quality |
| 3 | Learning Dynamics | Adaptation, correction integration |
| 4 | Reasoning | Causal chains, logic, planning |
| 5 | Meta-cognition | Confidence calibration, self-correction |
| 6 | Collaborative | Perspective-taking, conflict resolution |
| 7 | Security & Trust | Injection resistance, PII, adversarial robustness |

**Triangulated Scoring**
: Aegis's default scoring strategy that combines three independent backends -- rule-based (deterministic), semantic (embedding similarity), and LLM judge (model-based) -- into a single ensemble score with a disagreement metric.

**JudgePacketV1**
: The standard output of a scoring operation. Contains rule score, semantic score, LLM judge scores, ensemble score, disagreement, and explanation.

**Phase**
: Rollout phase for a dimension: **CORE** (shipped at launch), **ADVANCED** (enabled once baseline is stable), **RESEARCH** (experimental, informational only).

**Domain Plugin**
: An extension module that adds domain-specific evaluation dimensions. Built-in plugins: Legal (18 dims), Finance (20 dims), Safety.

---

## Memory

### Memory Types (7 types)

| Type | Description |
|------|-------------|
| Session | Short-lived, current conversation context |
| Episodic | Specific events with temporal anchoring |
| Semantic | General knowledge and facts |
| Procedural | How-to knowledge and learned procedures |
| Prospective | Future intentions and planned actions |
| Social | Information about people and relationships |
| Meta | Memories about memory operations themselves |

### Memory Operations (12 ops)

| Operation | Description |
|-----------|-------------|
| STORE | Persist a new memory entry |
| RETRIEVE | Fetch an entry by key |
| UPDATE | Modify an existing entry's value |
| FORGET | Remove an entry |
| LINK | Create semantic edges between entries |
| COMPRESS | Summarise verbose entries via extractive summarization |
| PROMOTE | Move entry to a higher (more persistent) tier |
| DEMOTE | Move entry to a lower tier |
| SPLIT | Decompose entry into constituent facts |
| MERGE | Combine related entries with conflict resolution |
| VERIFY | Check entry integrity and temporal validity |
| ANNOTATE | Attach metadata from downstream processing |

**Memory Tier**
: Persistence level of a memory entry: **Working** (ephemeral), **Session** (conversation-scoped), **Permanent** (long-term).

**Provenance**
: Source attribution metadata attached to every memory entry, tracking where information came from and how it was transformed.

**Time Horizon**
: One of 7 temporal scopes for memory queries: immediate, short-term, medium-term, long-term, episodic, lifetime, and archival.

---

## Observatory

**Observatory**
: The runtime monitoring subsystem that watches for anomalies in training and inference: reward hacking, gradient instability, memory pressure, and distribution drift.

**Reward Hacking**
: When an agent exploits shortcuts in the reward signal to achieve high scores without genuine capability improvement. Patterns include length inflation, citation padding, sycophancy, and format gaming.

**Goodhart's Law Detection**
: Observatory feature that detects when optimising a proxy metric diverges from the true objective.

**Auto-Intervention**
: Automated response system that triggers corrective actions (learning rate reduction, rollback, alert) when Observatory detects critical anomalies.

---

## Architecture

**Adapter**
: A bridge class that connects the Aegis evaluation engine to a specific agent framework (OpenAI, Anthropic, LangChain, LlamaIndex, LangGraph, DSPy, REST).

**TrajectoryV1**
: The standard recording of an agent's execution: a sequence of steps (reasoning, tool calls, retrieval, answers) with timestamps, token counts, and metadata.

**Arena**
: The competitive evaluation system where agents are ranked on a leaderboard using ELO ratings across multiple evaluation dimensions.

**Knowledge Graph**
: Neo4j-backed graph database storing semantic relationships between memory entries as typed, weighted edges.

**Vector Store**
: pgvector-backed embedding storage for semantic similarity search across memory entries.

---

## Infrastructure

**Kustomize**
: Kubernetes configuration management tool. Aegis provides base manifests with dev and prod overlays.

**Sealed Secrets**
: Encrypted Kubernetes secrets that can be safely committed to version control.

**HPA** (Horizontal Pod Autoscaler)
: Automatically scales API server replicas based on CPU utilization.
