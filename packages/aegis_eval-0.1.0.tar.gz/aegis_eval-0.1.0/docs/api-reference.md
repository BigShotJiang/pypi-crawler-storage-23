# API Reference

Launch the FastAPI server:

```bash
pip install aegis-eval[api]
uvicorn aegis.api.app:app --host 0.0.0.0 --port 8000
```

OpenAPI docs are available at `/docs` when the server is running.

## Health

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Liveness probe |

## Eval

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/evals/runs` | Create a new evaluation run |
| `GET` | `/v1/evals/runs/{run_id}` | Get eval run status and results |
| `POST` | `/v1/evals/compare` | Compare two evaluation runs |
| `GET` | `/v1/evals/dimensions` | List all registered dimensions |
| `GET` | `/v1/evals/dimensions/{dimension_id}` | Get single dimension details |
| `GET` | `/v1/evals/runs/{run_id}/report` | Get eval report (JSON or HTML) |
| `POST` | `/v1/evals/runs/{run_id}/cancel` | Cancel a running eval |
| `GET` | `/v1/evals/history` | List historical evals |
| `POST` | `/v1/evals/diagnostic` | Generate diagnostic report |
| `GET` | `/v1/evals/benchmarks` | List benchmark suites available to API |
| `POST` | `/v1/evals/benchmarks/run` | Run a benchmark suite |
| `GET` | `/v1/evals/benchmarks/history` | List benchmark run history |
| `GET` | `/v1/evals/benchmarks/runs/{run_id}` | Get benchmark run details |

## Training

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/train/jobs` | Create a training job |
| `GET` | `/v1/train/jobs` | List all training jobs |
| `GET` | `/v1/train/jobs/{job_id}` | Get training job status |
| `POST` | `/v1/train/jobs/{job_id}/run` | Execute a training job |
| `POST` | `/v1/train/jobs/{job_id}/enqueue` | Queue a training job |
| `POST` | `/v1/train/jobs/{job_id}/tick` | Advance queued job by one tick |
| `POST` | `/v1/train/jobs/{job_id}/stop` | Stop or cancel a training job |
| `GET` | `/v1/train/jobs/{job_id}/result` | Get training result payload |
| `GET` | `/v1/train/jobs/{job_id}/metrics` | Get training metrics snapshot |
| `GET` | `/v1/train/jobs/{job_id}/metrics/series` | Get per-stage metrics series |
| `GET` | `/v1/train/jobs/{job_id}/observatory` | Get observatory health checks |
| `GET` | `/v1/train/adapters` | List produced LoRA adapters |
| `GET` | `/v1/train/adapters/{adapter_id}` | Get adapter metadata |
| `GET` | `/v1/train/adapters/{adapter_id}/download` | Download adapter payload |

## Memory

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/memory/events` | Emit a memory event |
| `POST` | `/v1/memory/query` | Query the memory store |
| `POST` | `/v1/memory/store` | Create a memory entry |
| `POST` | `/v1/memory/retrieve` | Retrieve memory entries |
| `PUT` | `/v1/memory/{key}` | Update an entry |
| `DELETE` | `/v1/memory/{key}` | Forget (delete) an entry |
| `POST` | `/v1/memory/link` | Link two entries semantically |
| `GET` | `/v1/memory/health` | Memory subsystem health check |
| `GET` | `/v1/memory/audit` | Memory audit trail |
| `GET` | `/v1/memory/snapshots/{timestamp}` | Point-in-time snapshot |

## Retrieval

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/retrieval/query` | Execute a retrieval query |
| `GET` | `/v1/retrieval/benchmark/m4` | Run M4 precision/depth benchmark |

## Ingestion

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/ingestion/upload` | Upload and ingest a document |
| `GET` | `/v1/ingestion/history` | List ingestion runs |
| `GET` | `/v1/ingestion/formats` | List supported formats and parsers |
| `GET` | `/v1/ingestion/{document_id}` | Get ingestion status/details |
| `POST` | `/v1/ingestion/{document_id}/retry` | Retry ingesting a prior document |

## Arena

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/arena/submit` | Submit an agent to arena and evaluate |
| `GET` | `/v1/arena/leaderboard` | Get arena leaderboard |
| `GET` | `/v1/arena/agent/{agent_id}` | Get arena agent details |

## Observability

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/observability/events` | Ingest observability events |

## Promotion

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/promotion/decide` | Get adapter promotion decision |

## Events

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/events/publish` | Publish event to bus |
| `GET` | `/v1/events/history` | Get event history |
| `POST` | `/v1/events/webhooks` | Register a webhook |
| `DELETE` | `/v1/events/webhooks/{webhook_id}` | Deregister a webhook |
| `GET` | `/v1/events/webhooks` | List webhooks |
| `GET` | `/v1/events/webhooks/queue` | Inspect pending webhook queue |
| `GET` | `/v1/events/webhooks/deliveries` | List webhook delivery attempts |
| `POST` | `/v1/events/webhooks/process` | Process queued deliveries (supports retry simulation) |
| `GET` | `/v1/events/webhooks/stats` | Webhook delivery statistics |
| `GET` | `/v1/events/dead-letters` | Failed event deliveries |

## Online Eval

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/v1/online-eval/score` | Score a production interaction |
| `POST` | `/v1/online-eval/baselines` | Set baseline scores |
| `GET` | `/v1/online-eval/summary` | Pipeline summary |
| `GET` | `/v1/online-eval/alerts` | Get alerts |
| `POST` | `/v1/online-eval/alerts/{alert_id}/acknowledge` | Acknowledge an alert |
| `GET` | `/v1/online-eval/drift` | Check drift |
| `GET` | `/v1/online-eval/scores` | Recent scores |
