# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-23

### Added

- **Evaluation engine** with 101 dimensions across 7 tiers (Memory Fidelity, Context Management, Learning & Adaptation, Reasoning & Planning, Metacognition, Collaborative Intelligence, Security & Adversarial)
- **Triangulated scoring** — rule-based, semantic, and LLM judge ensembles with disagreement tracking
- **Multi-provider LLM backends** — OpenAI, Anthropic, and deterministic mock (zero-key CI mode) with rate limiting, cost tracking, and exponential backoff
- **Domain plugins** — Legal (18 dimensions) and Finance (20 dimensions) vertical packs
- **Domain benchmark suites** — Legal (40 cases), Finance (40 cases), Memory (25 cases) with `aegis eval benchmark` CLI
- **Dataset downloaders** — CUAD, LegalBench, FinanceBench via HuggingFace with `aegis data download` CLI
- **CLI** — `aegis eval run`, `aegis eval compare`, `aegis eval report`, `aegis eval dimensions`, `aegis eval list`, `aegis eval benchmark`, `aegis data download`, `aegis train start`, `aegis train status`, `aegis memory health`, `aegis memory audit`
- **REST API** — FastAPI routes for eval runs, training jobs, adapter management, ingestion, retrieval, promotion decisions, and observatory health checks
- **Persistence** — SQLite (zero-dependency, `~/.aegis/aegis.db`) and PostgreSQL eval stores
- **Ingestion pipeline** — Document ingestion with pgvector and Neo4j storage sinks, entity extraction
- **Retrieval backends** — pgvector vector search, Neo4j graph traversal, cross-encoder reranking (ms-marco-MiniLM)
- **Training engine** — AMIR-GRPO and GRPO-SG trainers with curriculum scheduling, transfer learning, replay buffers, and PODS rollout selection
- **verl training bridge** — Real GRPO training with LoRA, model loading, manual training fallback, and checkpoint management
- **Training-eval feedback loop** — EvalCallback with dynamic dimension weighting and curriculum integration
- **Observatory monitor** — reward hacking, gradient health, memory health, and distribution drift checks
- **Reporting** — JSON, HTML, PDF, and text export formats with diagnostic summaries
- **Dashboard** — Next.js dashboard with eval drill-down, dimension heatmap, training console, and memory explorer
- **Documentation** — MkDocs Material site with quickstart, configuration, dimensions, plugins, and adapter guides
- **Jupyter notebooks** — Quickstart eval, domain eval, memory operations, ingestion pipeline
- **CI/CD** — GitHub Actions for lint, test, type-check, integration tests, benchmarks, and PyPI release
- **Docker** — Multi-stage Dockerfile for API server, full-stack docker-compose
- **Python examples** — `quickstart.py`, `custom_eval.py`, `compare_runs.py`, `training_example.py`, `ingestion_example.py`, `memory_example.py`
