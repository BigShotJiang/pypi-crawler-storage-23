---
tags:
  - aegis
  - metronis
  - evaluation
  - ai-agents
license: apache-2.0
---

# {repo_id}

This dataset was curated as part of the [Aegis](https://github.com/metronis-space/aegis) evaluation and training framework by [Metronis](https://metronis.space).

## Dataset Description

{description}

- **Curated by:** Metronis
- **Language:** {language}
- **License:** {license}
- **Domain:** {domain}

### Dataset Summary

{summary}

## Dataset Structure

{structure}

### Data Fields

{data_fields}

### Data Splits

| Split | Samples |
|-------|---------|
| train | {train_size} |
| validation | {val_size} |
| test | {test_size} |

## Usage

```python
from datasets import load_dataset

dataset = load_dataset("{repo_id}")
```

{usage}

## Citation

If you use this dataset, please cite:

```bibtex
@software{{aegis2026,
  title = {{Aegis: Adaptive Intelligence Layer for AI Agents}},
  author = {{Metronis}},
  year = {{2026}},
  url = {{https://github.com/metronis-space/aegis}},
}}
```

{citation}
