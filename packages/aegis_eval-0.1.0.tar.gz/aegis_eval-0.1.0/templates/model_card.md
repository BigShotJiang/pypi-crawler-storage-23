---
library_name: peft
base_model: {base_model}
tags:
  - aegis
  - metronis
  - lora
  - rl
  - grpo
license: apache-2.0
---

# {repo_id}

This is a LoRA adapter trained with the [Aegis](https://github.com/metronis-space/aegis) RL training engine by [Metronis](https://metronis.space).

## Model Description

{description}

- **Base Model:** [{base_model}](https://huggingface.co/{base_model})
- **Training Framework:** Aegis Train (GRPO on verl)
- **Adapter Type:** LoRA (Low-Rank Adaptation)
- **Developed by:** Metronis

## Training

{training_details}

### Training Procedure

This adapter was trained using Aegis Train's multi-stage RL pipeline:

1. **Reward Decomposition** -- Process-level rewards across multiple evaluation dimensions
2. **Curriculum Progression** -- 7-level difficulty curriculum with adaptive gating
3. **GRPO Optimization** -- Group Relative Policy Optimization with staged gating

### Training Hyperparameters

| Parameter | Value |
|-----------|-------|
| LoRA Rank | {lora_rank} |
| LoRA Alpha | {lora_alpha} |
| Learning Rate | {learning_rate} |
| Batch Size | {batch_size} |
| Epochs | {epochs} |

## Evaluation Results

{eval_results}

## Usage

```python
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

base_model = AutoModelForCausalLM.from_pretrained("{base_model}")
model = PeftModel.from_pretrained(base_model, "{repo_id}")
tokenizer = AutoTokenizer.from_pretrained("{base_model}")

{usage_example}
```

## Citation

If you use this model, please cite:

```bibtex
@software{{aegis2026,
  title = {{Aegis: Adaptive Intelligence Layer for AI Agents}},
  author = {{Metronis}},
  year = {{2026}},
  url = {{https://github.com/metronis-space/aegis}},
}}
```

{citation}
