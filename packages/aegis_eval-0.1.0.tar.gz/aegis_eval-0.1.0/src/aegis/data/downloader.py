"""Generic HuggingFace dataset downloader with progress, checksums, and caching."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

_DEFAULT_CACHE_DIR = Path.home() / ".aegis" / "datasets"


def _default_cache_dir() -> Path:
    """Return the default cache directory, creating it if needed."""
    _DEFAULT_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return _DEFAULT_CACHE_DIR


class DatasetDownloader:
    """Download datasets from HuggingFace with caching and checksum validation.

    Attempts to use ``huggingface_hub`` if available, otherwise falls back to
    ``httpx`` for direct HTTP downloads from the HuggingFace API.

    Parameters
    ----------
    cache_dir:
        Directory to cache downloaded datasets.  Defaults to
        ``~/.aegis/datasets/``.
    """

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir or _default_cache_dir()
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def download(
        self,
        dataset_name: str,
        subset: str | None = None,
        split: str = "test",
    ) -> Path:
        """Download a HuggingFace dataset and return the path to the cached data.

        Parameters
        ----------
        dataset_name:
            HuggingFace dataset identifier, e.g. ``"nguha/legalbench"``.
        subset:
            Optional dataset subset / configuration name.
        split:
            Dataset split to download (default ``"test"``).

        Returns
        -------
        Path
            Path to the directory containing the cached dataset files.
        """
        safe_name = dataset_name.replace("/", "__")
        dest_dir = self.cache_dir / safe_name
        if subset:
            dest_dir = dest_dir / subset

        marker = dest_dir / ".download_complete"
        if marker.exists():
            return dest_dir

        dest_dir.mkdir(parents=True, exist_ok=True)

        # Try huggingface_hub first, then fall back to httpx.
        try:
            return self._download_via_hub(dataset_name, subset, split, dest_dir, marker)
        except ImportError:
            return self._download_via_httpx(dataset_name, subset, split, dest_dir, marker)

    # ------------------------------------------------------------------
    # HuggingFace Hub download path
    # ------------------------------------------------------------------

    def _download_via_hub(
        self,
        dataset_name: str,
        subset: str | None,
        split: str,
        dest_dir: Path,
        marker: Path,
    ) -> Path:
        """Download using the ``datasets`` library from HuggingFace."""
        try:
            from datasets import load_dataset  # type: ignore[import-not-found]
        except ImportError as exc:
            raise ImportError(
                "The 'datasets' package is required for HuggingFace Hub downloads. "
                "Install it with: pip install 'aegis-eval[data]'"
            ) from exc

        from rich.progress import Progress, SpinnerColumn, TextColumn

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
        ) as progress:
            desc = f"Downloading {dataset_name}"
            if subset:
                desc += f" ({subset})"
            progress.add_task(description=desc, total=None)

            kwargs: dict[str, Any] = {"trust_remote_code": True}
            if subset:
                kwargs["name"] = subset

            try:
                ds = load_dataset(dataset_name, split=split, **kwargs)
            except Exception:
                # Some datasets don't have the requested split; try "train".
                ds = load_dataset(dataset_name, split="train", **kwargs)

            # Save as JSON lines for a portable, inspectable format.
            output_file = dest_dir / "data.jsonl"
            ds.to_json(str(output_file))

        # Write checksum
        checksum = self._sha256(output_file)
        (dest_dir / "sha256.txt").write_text(checksum, encoding="utf-8")

        # Mark complete
        marker.write_text("ok", encoding="utf-8")
        return dest_dir

    # ------------------------------------------------------------------
    # httpx fallback download path
    # ------------------------------------------------------------------

    def _download_via_httpx(
        self,
        dataset_name: str,
        subset: str | None,
        split: str,
        dest_dir: Path,
        marker: Path,
    ) -> Path:
        """Download dataset via the HuggingFace datasets API using httpx."""
        import httpx
        from rich.progress import (
            BarColumn,
            DownloadColumn,
            Progress,
            TextColumn,
            TransferSpeedColumn,
        )

        # Build the API URL.  HuggingFace exposes a rows endpoint that
        # returns JSON data for a given split.
        base_url = "https://datasets-server.huggingface.co/rows"
        params: dict[str, Any] = {
            "dataset": dataset_name,
            "split": split,
            "offset": 0,
            "length": 100,
        }
        if subset:
            params["config"] = subset

        output_file = dest_dir / "data.jsonl"
        rows_collected: list[dict[str, Any]] = []

        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
        ) as progress:
            desc = f"Downloading {dataset_name}"
            if subset:
                desc += f" ({subset})"
            task = progress.add_task(description=desc, total=None)

            offset = 0
            page_size = 100
            while True:
                params["offset"] = offset
                params["length"] = page_size

                resp = httpx.get(base_url, params=params, timeout=60.0)
                resp.raise_for_status()
                payload = resp.json()

                rows = payload.get("rows", [])
                if not rows:
                    break

                for row_wrapper in rows:
                    row_data = row_wrapper.get("row", row_wrapper)
                    rows_collected.append(row_data)

                progress.update(task, advance=len(rows))
                offset += page_size

                # Safety limit: cap at 10 000 rows for httpx fallback.
                if offset >= 10_000:
                    break

        # Write JSONL
        with open(output_file, "w", encoding="utf-8") as fh:
            for row in rows_collected:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")

        # Write checksum
        checksum = self._sha256(output_file)
        (dest_dir / "sha256.txt").write_text(checksum, encoding="utf-8")

        # Mark complete
        marker.write_text("ok", encoding="utf-8")
        return dest_dir

    # ------------------------------------------------------------------
    # Checksum helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sha256(path: Path) -> str:
        """Compute the SHA-256 hex digest of a file."""
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def verify_checksum(self, dataset_dir: Path) -> bool:
        """Verify the SHA-256 checksum of a downloaded dataset.

        Returns ``True`` if valid, ``False`` otherwise.
        """
        data_file = dataset_dir / "data.jsonl"
        checksum_file = dataset_dir / "sha256.txt"
        if not data_file.exists() or not checksum_file.exists():
            return False
        expected = checksum_file.read_text(encoding="utf-8").strip()
        actual = self._sha256(data_file)
        return expected == actual

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def list_cached(self) -> list[dict[str, Any]]:
        """List all cached datasets with their sizes.

        Returns a list of dicts with ``name``, ``path``, ``size_bytes``, and
        ``complete`` keys.
        """
        results: list[dict[str, Any]] = []
        if not self.cache_dir.exists():
            return results

        for entry in sorted(self.cache_dir.iterdir()):
            if not entry.is_dir():
                continue
            size = sum(f.stat().st_size for f in entry.rglob("*") if f.is_file())
            complete = (entry / ".download_complete").exists()
            results.append(
                {
                    "name": entry.name.replace("__", "/"),
                    "path": str(entry),
                    "size_bytes": size,
                    "complete": complete,
                }
            )
        return results

    def clear_cache(self, dataset_name: str | None = None) -> None:
        """Remove cached datasets.

        Parameters
        ----------
        dataset_name:
            If provided, remove only this dataset.  Otherwise remove all.
        """
        if dataset_name:
            safe_name = dataset_name.replace("/", "__")
            target = self.cache_dir / safe_name
            if target.exists():
                shutil.rmtree(target)
        else:
            if self.cache_dir.exists():
                shutil.rmtree(self.cache_dir)
                self.cache_dir.mkdir(parents=True, exist_ok=True)
