"""CUAD (Contract Understanding Atticus Dataset) loader.

Converts CUAD question-answer pairs into :class:`EvalCaseV1` instances
suitable for Aegis legal evaluation.

Reference: https://huggingface.co/datasets/cuad
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.data.downloader import DatasetDownloader

# HuggingFace dataset identifier for CUAD.
CUAD_DATASET = "cuad"

# Default maximum number of examples to load.
DEFAULT_MAX_EXAMPLES = 500

# Map answer lengths to difficulty levels (1-5).
_DIFFICULTY_THRESHOLDS = [
    (20, 1),  # Very short answers -> easy
    (50, 2),  # Short answers -> medium-easy
    (150, 3),  # Medium answers -> medium
    (400, 4),  # Long answers -> hard
]


def _estimate_difficulty(answer: str) -> int:
    """Estimate difficulty based on answer length and complexity."""
    length = len(answer)
    for threshold, level in _DIFFICULTY_THRESHOLDS:
        if length <= threshold:
            return level
    return 5  # Very long / complex answers


def load_cuad(
    cache_dir: Path | None = None,
    max_examples: int = DEFAULT_MAX_EXAMPLES,
) -> list[EvalCaseV1]:
    """Load CUAD and convert to EvalCaseV1 format.

    Parameters
    ----------
    cache_dir:
        Directory for caching downloaded data.  Defaults to
        ``~/.aegis/datasets/``.
    max_examples:
        Maximum number of examples to return (default 500).

    Returns
    -------
    list[EvalCaseV1]
        List of eval cases derived from CUAD question-answer pairs.
    """
    downloader = DatasetDownloader(cache_dir=cache_dir)
    dataset_dir = downloader.download(CUAD_DATASET, split="test")

    data_file = dataset_dir / "data.jsonl"
    if not data_file.exists():
        raise FileNotFoundError(
            f"Expected data file not found at {data_file}. "
            "Try clearing the cache and re-downloading."
        )

    cases: list[EvalCaseV1] = []

    with open(data_file, encoding="utf-8") as fh:
        for line in fh:
            if len(cases) >= max_examples:
                break

            row: dict[str, Any] = json.loads(line)
            case = _convert_cuad_row(row)
            if case is not None:
                cases.append(case)

    return cases


def _convert_cuad_row(row: dict[str, Any]) -> EvalCaseV1 | None:
    """Convert a single CUAD row to an EvalCaseV1.

    CUAD uses a SQuAD-like format with ``question``, ``context``, and
    ``answers`` fields.  Rows with no answer are skipped.
    """
    question = row.get("question", "")
    context_text = row.get("context", "")
    answers = row.get("answers", {})

    # The answers field is a dict with "text" and "answer_start" lists.
    answer_texts: list[str] = []
    if isinstance(answers, dict):
        answer_texts = answers.get("text", [])
    elif isinstance(answers, list):
        answer_texts = [a for a in answers if isinstance(a, str)]

    # Skip unanswerable examples.
    if not answer_texts or all(not t.strip() for t in answer_texts):
        return None

    primary_answer = answer_texts[0].strip()
    if not primary_answer:
        return None

    difficulty = _estimate_difficulty(primary_answer)

    return EvalCaseV1(
        id=str(uuid.uuid4()),
        suite_id="cuad-legal-v1",
        dimension_id="contract_clause_extraction",
        tier=EvalTier.REASONING_QUALITY,
        domain="legal",
        prompt=question,
        context={"document_text": context_text[:2000]},  # Truncate long contexts
        expected={
            "answer": primary_answer,
            "all_answers": answer_texts,
        },
        difficulty=difficulty,
        tags=["cuad", "legal", "contract", "extraction"],
        metadata={"source_dataset": "cuad"},
    )
