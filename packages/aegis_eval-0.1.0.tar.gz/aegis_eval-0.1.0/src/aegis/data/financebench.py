"""FinanceBench dataset loader -- financial QA benchmark.

Loads the ``PatronusAI/financebench`` dataset and converts it into
:class:`EvalCaseV1` instances for Aegis finance evaluation.

Reference: https://huggingface.co/datasets/PatronusAI/financebench
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.data.downloader import DatasetDownloader

# HuggingFace dataset identifier.
FINANCEBENCH_DATASET = "PatronusAI/financebench"

# Default maximum number of examples to load.
DEFAULT_MAX_EXAMPLES = 500

# Map FinanceBench question types to Aegis finance dimensions.
_QUESTION_TYPE_TO_DIMENSION: dict[str, str] = {
    "metrics-generated": "financial_metric_computation",
    "metrics-sourced": "financial_metric_extraction",
    "novel-generated": "financial_novel_analysis",
    "novel-sourced": "financial_novel_extraction",
}
_DEFAULT_DIMENSION = "financial_analysis"

# Map dimensions to eval tiers.
_DIMENSION_TIERS: dict[str, EvalTier] = {
    "financial_metric_computation": EvalTier.REASONING_QUALITY,
    "financial_metric_extraction": EvalTier.CONTEXT_INTELLIGENCE,
    "financial_novel_analysis": EvalTier.REASONING_QUALITY,
    "financial_novel_extraction": EvalTier.CONTEXT_INTELLIGENCE,
    "financial_analysis": EvalTier.REASONING_QUALITY,
}

# Difficulty mapping based on question type.
_QUESTION_TYPE_DIFFICULTY: dict[str, int] = {
    "metrics-sourced": 2,
    "metrics-generated": 3,
    "novel-sourced": 3,
    "novel-generated": 4,
}


def load_financebench(
    cache_dir: Path | None = None,
    max_examples: int = DEFAULT_MAX_EXAMPLES,
) -> list[EvalCaseV1]:
    """Load FinanceBench and convert to EvalCaseV1 format.

    Parameters
    ----------
    cache_dir:
        Directory for caching downloaded data.
    max_examples:
        Maximum number of examples to return (default 500).

    Returns
    -------
    list[EvalCaseV1]
        List of eval cases derived from FinanceBench.
    """
    downloader = DatasetDownloader(cache_dir=cache_dir)
    dataset_dir = downloader.download(FINANCEBENCH_DATASET, split="train")

    data_file = dataset_dir / "data.jsonl"
    if not data_file.exists():
        raise FileNotFoundError(
            f"Expected data file not found at {data_file}. "
            "Try clearing the cache and re-downloading."
        )

    cases: list[EvalCaseV1] = []

    with open(data_file, encoding="utf-8") as fh:
        for line in fh:
            if len(cases) >= max_examples:
                break

            row: dict[str, Any] = json.loads(line)
            case = _convert_financebench_row(row)
            if case is not None:
                cases.append(case)

    return cases


def _convert_financebench_row(row: dict[str, Any]) -> EvalCaseV1 | None:
    """Convert a single FinanceBench row to an EvalCaseV1."""
    # FinanceBench fields: question, answer, evidence, question_type,
    # company, doc_name, etc.
    question = row.get("question", "")
    answer = row.get("answer", "")

    if not question or not answer:
        return None

    question_type = row.get("question_type", "")
    company = row.get("company", "")
    doc_name = row.get("doc_name", "")
    evidence = row.get("evidence", "")

    dimension_id = _QUESTION_TYPE_TO_DIMENSION.get(question_type, _DEFAULT_DIMENSION)
    tier = _DIMENSION_TIERS.get(dimension_id, EvalTier.REASONING_QUALITY)
    difficulty = _QUESTION_TYPE_DIFFICULTY.get(question_type, 3)

    context: dict[str, Any] = {}
    if company:
        context["company"] = company
    if doc_name:
        context["document"] = doc_name
    if evidence:
        context["evidence"] = evidence[:2000]  # Truncate long evidence

    return EvalCaseV1(
        id=str(uuid.uuid4()),
        suite_id="financebench-v1",
        dimension_id=dimension_id,
        tier=tier,
        domain="finance",
        prompt=question,
        context=context,
        expected={"answer": str(answer)},
        difficulty=difficulty,
        tags=["financebench", "finance", question_type]
        if question_type
        else ["financebench", "finance"],
        metadata={
            "source_dataset": "financebench",
            "question_type": question_type,
            "company": company,
        },
    )
