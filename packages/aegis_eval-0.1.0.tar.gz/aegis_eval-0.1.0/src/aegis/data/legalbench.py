"""LegalBench dataset loader -- 162 legal reasoning tasks.

Loads tasks from the ``nguha/legalbench`` HuggingFace dataset and converts
them into :class:`EvalCaseV1` instances mapped to Aegis legal dimension IDs.

Reference: https://huggingface.co/datasets/nguha/legalbench
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.data.downloader import DatasetDownloader

# HuggingFace dataset identifier.
LEGALBENCH_DATASET = "nguha/legalbench"

# -----------------------------------------------------------------------
# Task category -> Aegis dimension ID mapping
# -----------------------------------------------------------------------
# LegalBench tasks are grouped into broad categories.  We map each category
# to an Aegis legal evaluation dimension.

_TASK_TO_DIMENSION: dict[str, str] = {
    # Issue-spotting tasks
    "abercrombie": "legal_issue_spotting",
    "privity": "legal_issue_spotting",
    "diversity_1": "legal_issue_spotting",
    "diversity_2": "legal_issue_spotting",
    "diversity_3": "legal_issue_spotting",
    "diversity_4": "legal_issue_spotting",
    "diversity_5": "legal_issue_spotting",
    "diversity_6": "legal_issue_spotting",
    # Rule application tasks
    "corporate_lobbying": "legal_rule_application",
    "international_citizenship_questions": "legal_rule_application",
    "personal_jurisdiction": "legal_rule_application",
    "supply_chain_disclosure_best_practice_disclosure": "legal_rule_application",
    "supply_chain_disclosure_disclosed_accountability": "legal_rule_application",
    "supply_chain_disclosure_disclosed_audits": "legal_rule_application",
    "supply_chain_disclosure_disclosed_certification": "legal_rule_application",
    "supply_chain_disclosure_disclosed_training": "legal_rule_application",
    # Rule recall / interpretation tasks
    "definition_classification": "legal_rule_recall",
    "citation_prediction_classification": "legal_rule_recall",
    "hearsay": "legal_rule_recall",
    # Contract interpretation
    "contract_nli_confidentiality_of_agreement": "contract_interpretation",
    "contract_nli_explicit_identification": "contract_interpretation",
    "contract_nli_inclusion_of_verbally_conveyed_information": "contract_interpretation",
    "contract_nli_limited_use": "contract_interpretation",
    "contract_nli_no_licensing": "contract_interpretation",
    "contract_nli_notice_on_compelled_disclosure": "contract_interpretation",
    "contract_nli_permissible_acquirement_of_similar_information": "contract_interpretation",
    "contract_nli_permissible_copy": "contract_interpretation",
    "contract_nli_permissible_development_of_similar_information": "contract_interpretation",
    "contract_nli_permissible_post_agreement_possession": "contract_interpretation",
    "contract_nli_return_of_confidential_information": "contract_interpretation",
    "contract_nli_survival_of_obligations": "contract_interpretation",
    "contract_qa": "contract_interpretation",
    "cuad_affiliate_license-Loss": "contract_clause_extraction",
    "cuad_anti-assignment": "contract_clause_extraction",
    "cuad_audit_rights": "contract_clause_extraction",
    "cuad_cap_on_liability": "contract_clause_extraction",
    "cuad_change_of_control": "contract_clause_extraction",
    "cuad_competitive_restriction_exception": "contract_clause_extraction",
    "cuad_covenant_not_to_sue": "contract_clause_extraction",
    "cuad_effective_date": "contract_clause_extraction",
    "cuad_exclusivity": "contract_clause_extraction",
    "cuad_expiration_date": "contract_clause_extraction",
    "cuad_governing_law": "contract_clause_extraction",
    "cuad_insurance": "contract_clause_extraction",
    "cuad_ip_ownership_assignment": "contract_clause_extraction",
    "cuad_irrevocable_or_perpetual_license": "contract_clause_extraction",
    "cuad_joint_ip_ownership": "contract_clause_extraction",
    "cuad_license_grant": "contract_clause_extraction",
    "cuad_liquidated_damages": "contract_clause_extraction",
    "cuad_minimum_commitment": "contract_clause_extraction",
    "cuad_most_favored_nation": "contract_clause_extraction",
    "cuad_no-solicit_of_customers": "contract_clause_extraction",
    "cuad_no-solicit_of_employees": "contract_clause_extraction",
    "cuad_non-compete": "contract_clause_extraction",
    "cuad_non-disparagement": "contract_clause_extraction",
    "cuad_non-transferable_license": "contract_clause_extraction",
    "cuad_notice_period_to_terminate_renewal": "contract_clause_extraction",
    "cuad_post-termination_services": "contract_clause_extraction",
    "cuad_price_restrictions": "contract_clause_extraction",
    "cuad_renewal_term": "contract_clause_extraction",
    "cuad_revenue-profit_sharing": "contract_clause_extraction",
    "cuad_rofr-rofo-rofn": "contract_clause_extraction",
    "cuad_source_code_escrow": "contract_clause_extraction",
    "cuad_termination_for_convenience": "contract_clause_extraction",
    "cuad_third_party_beneficiary": "contract_clause_extraction",
    "cuad_uncapped_liability": "contract_clause_extraction",
    "cuad_unlimited-All_You_Can_Eat-License": "contract_clause_extraction",
    "cuad_volume_restriction": "contract_clause_extraction",
    "cuad_warranty_duration": "contract_clause_extraction",
    # Rhetorical understanding
    "learned_hands_benefits": "legal_rhetorical_understanding",
    "learned_hands_business": "legal_rhetorical_understanding",
    "learned_hands_consumer": "legal_rhetorical_understanding",
    "learned_hands_courts": "legal_rhetorical_understanding",
    "learned_hands_crime": "legal_rhetorical_understanding",
    "learned_hands_divorce": "legal_rhetorical_understanding",
    "learned_hands_domestic_violence": "legal_rhetorical_understanding",
    "learned_hands_education": "legal_rhetorical_understanding",
    "learned_hands_employment": "legal_rhetorical_understanding",
    "learned_hands_estates": "legal_rhetorical_understanding",
    "learned_hands_family": "legal_rhetorical_understanding",
    "learned_hands_health": "legal_rhetorical_understanding",
    "learned_hands_housing": "legal_rhetorical_understanding",
    "learned_hands_immigration": "legal_rhetorical_understanding",
    "learned_hands_torts": "legal_rhetorical_understanding",
    "learned_hands_traffic": "legal_rhetorical_understanding",
    # Statutory reasoning
    "sara_entailment": "statutory_reasoning",
    "sara_numeric": "statutory_reasoning",
    "statutory_reasoning_assessment": "statutory_reasoning",
    "textualism_tool_dictionaries": "statutory_reasoning",
    "textualism_tool_plain": "statutory_reasoning",
    # Legal reasoning / argumentation
    "function_of_decision_section": "legal_reasoning",
    "oral_argument_question_purpose": "legal_reasoning",
    "overruling": "legal_reasoning",
    "scalr": "legal_reasoning",
    "ssla_company_defendants": "legal_reasoning",
    "ssla_individual_defendants": "legal_reasoning",
    "ssla_plaintiff": "legal_reasoning",
    # Interpretation
    "jcrew_blocker": "legal_interpretation",
    "nys_judicial_ethics": "legal_interpretation",
    "opp115_data_retention": "legal_interpretation",
    "opp115_data_security": "legal_interpretation",
    "opp115_do_not_track": "legal_interpretation",
    "opp115_first_party_collection_use": "legal_interpretation",
    "opp115_international_and_specific_audiences": "legal_interpretation",
    "opp115_policy_change": "legal_interpretation",
    "opp115_third_party_sharing_collection": "legal_interpretation",
    "opp115_user_access_edit_and_deletion": "legal_interpretation",
    "opp115_user_choice_control": "legal_interpretation",
    "privacy_policy_entailment": "legal_interpretation",
    "privacy_policy_qa": "legal_interpretation",
    "unfair_tos": "legal_interpretation",
}

# Default dimension for tasks not in the mapping.
_DEFAULT_DIMENSION = "legal_reasoning"

# Map dimension IDs to appropriate eval tiers.
_DIMENSION_TIERS: dict[str, EvalTier] = {
    "legal_issue_spotting": EvalTier.REASONING_QUALITY,
    "legal_rule_application": EvalTier.REASONING_QUALITY,
    "legal_rule_recall": EvalTier.MEMORY_FIDELITY,
    "contract_interpretation": EvalTier.REASONING_QUALITY,
    "contract_clause_extraction": EvalTier.CONTEXT_INTELLIGENCE,
    "legal_rhetorical_understanding": EvalTier.META_COGNITION,
    "statutory_reasoning": EvalTier.REASONING_QUALITY,
    "legal_reasoning": EvalTier.REASONING_QUALITY,
    "legal_interpretation": EvalTier.REASONING_QUALITY,
}


def load_legalbench(
    cache_dir: Path | None = None,
    tasks: list[str] | None = None,
    max_per_task: int = 50,
) -> list[EvalCaseV1]:
    """Load LegalBench and convert to EvalCaseV1 format.

    Parameters
    ----------
    cache_dir:
        Directory for caching downloaded data.
    tasks:
        Optional list of specific task names to load.  If ``None``, loads
        all available tasks.
    max_per_task:
        Maximum number of examples per task (default 50).

    Returns
    -------
    list[EvalCaseV1]
        List of eval cases derived from LegalBench.
    """
    downloader = DatasetDownloader(cache_dir=cache_dir)
    dataset_dir = downloader.download(LEGALBENCH_DATASET, split="test")

    data_file = dataset_dir / "data.jsonl"
    if not data_file.exists():
        raise FileNotFoundError(
            f"Expected data file not found at {data_file}. "
            "Try clearing the cache and re-downloading."
        )

    # Count examples per task for limiting.
    task_counts: dict[str, int] = {}
    cases: list[EvalCaseV1] = []

    with open(data_file, encoding="utf-8") as fh:
        for line in fh:
            row: dict[str, Any] = json.loads(line)
            case = _convert_legalbench_row(row, tasks, task_counts, max_per_task)
            if case is not None:
                cases.append(case)

    return cases


def _convert_legalbench_row(
    row: dict[str, Any],
    tasks_filter: list[str] | None,
    task_counts: dict[str, int],
    max_per_task: int,
) -> EvalCaseV1 | None:
    """Convert a single LegalBench row to an EvalCaseV1."""
    task_name = row.get("task", row.get("name", ""))

    # Apply task filter if specified.
    if tasks_filter and task_name not in tasks_filter:
        return None

    # Enforce per-task limit.
    count = task_counts.get(task_name, 0)
    if count >= max_per_task:
        return None
    task_counts[task_name] = count + 1

    # Extract question and answer.  LegalBench rows typically have
    # "text" or "question" for input and "answer" or "label" for output.
    prompt = row.get("text", row.get("question", row.get("input", "")))
    answer = row.get("answer", row.get("label", row.get("output", "")))

    if not prompt:
        return None

    dimension_id = _TASK_TO_DIMENSION.get(task_name, _DEFAULT_DIMENSION)
    tier = _DIMENSION_TIERS.get(dimension_id, EvalTier.REASONING_QUALITY)

    return EvalCaseV1(
        id=str(uuid.uuid4()),
        suite_id="legalbench-v1",
        dimension_id=dimension_id,
        tier=tier,
        domain="legal",
        prompt=prompt,
        context={"task": task_name},
        expected={"answer": str(answer)},
        difficulty=3,  # LegalBench tasks are generally medium difficulty
        tags=["legalbench", "legal", task_name],
        metadata={"source_dataset": "legalbench", "task": task_name},
    )
