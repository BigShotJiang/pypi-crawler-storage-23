"""Dataset acquisition and conversion for Aegis benchmarks."""
