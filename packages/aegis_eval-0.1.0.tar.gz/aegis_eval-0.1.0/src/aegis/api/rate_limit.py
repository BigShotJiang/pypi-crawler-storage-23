"""Token bucket rate limiter middleware for the Aegis API.

Implements per-client rate limiting using a token bucket algorithm.
Clients are identified by IP address or ``X-API-Key`` header.  The
bucket parameters (capacity, refill rate, burst) are configurable via
:class:`~aegis.core.settings.AegisSettings`.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)


@dataclass
class _TokenBucket:
    """A single token bucket for one client.

    Attributes:
        tokens: Current number of available tokens.
        last_refill: Monotonic timestamp of last refill.
        capacity: Maximum token count (burst size).
        refill_rate: Tokens added per second.
    """

    tokens: float
    last_refill: float
    capacity: float
    refill_rate: float


@dataclass
class RateLimitConfig:
    """Configuration for the rate limiter.

    Attributes:
        requests_per_minute: Sustained request rate per client.
        burst_size: Maximum instantaneous burst above the sustained rate.
        api_key_header: Header name used to identify API-key-based clients.
        limit_anonymous: When True, clients without an API key are rate
            limited by remote IP. When False, only API-key clients are
            rate limited.
    """

    requests_per_minute: int = 100
    burst_size: int = 20
    api_key_header: str = "X-API-Key"
    limit_anonymous: bool = False


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Starlette middleware enforcing per-client token bucket rate limiting.

    Each unique client (identified by the ``X-API-Key`` header, or
    falling back to the remote IP address) gets its own token bucket.
    When the bucket is empty, the middleware responds with
    ``429 Too Many Requests`` and a ``Retry-After`` header.

    Args:
        app: The ASGI application to wrap.
        config: Optional :class:`RateLimitConfig` overriding defaults.
    """

    def __init__(
        self,
        app: object,
        config: RateLimitConfig | None = None,
    ) -> None:
        super().__init__(app)  # type: ignore[arg-type]
        self._config = config or RateLimitConfig()
        self._buckets: dict[str, _TokenBucket] = {}

        # Derive token parameters from config.
        self._capacity = self._config.requests_per_minute + self._config.burst_size
        self._refill_rate = self._config.requests_per_minute / 60.0  # tokens/sec

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _client_key(self, request: Request) -> str | None:
        """Determine the client identifier for rate limiting.

        Prefers the API key header and optionally falls back to client IP
        for anonymous traffic.
        """
        api_key = request.headers.get(self._config.api_key_header.lower())
        if api_key:
            return f"key:{api_key}"
        if not self._config.limit_anonymous:
            return None
        client_host = request.client.host if request.client else "unknown"
        return f"ip:{client_host}"

    def _get_bucket(self, key: str) -> _TokenBucket:
        """Return (and lazily create) the token bucket for *key*."""
        if key not in self._buckets:
            self._buckets[key] = _TokenBucket(
                tokens=float(self._capacity),
                last_refill=time.monotonic(),
                capacity=float(self._capacity),
                refill_rate=self._refill_rate,
            )
        return self._buckets[key]

    @staticmethod
    def _refill(bucket: _TokenBucket) -> None:
        """Add tokens to *bucket* based on elapsed time."""
        now = time.monotonic()
        elapsed = now - bucket.last_refill
        if elapsed > 0:
            bucket.tokens = min(
                bucket.capacity,
                bucket.tokens + elapsed * bucket.refill_rate,
            )
            bucket.last_refill = now

    # ------------------------------------------------------------------
    # Middleware dispatch
    # ------------------------------------------------------------------

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Process the request through the rate limiter."""
        client = self._client_key(request)
        if client is None:
            return await call_next(request)
        bucket = self._get_bucket(client)
        self._refill(bucket)

        if bucket.tokens >= 1.0:
            bucket.tokens -= 1.0
            response = await call_next(request)
            # Inform the client of their remaining budget.
            response.headers["X-RateLimit-Remaining"] = str(int(bucket.tokens))
            response.headers["X-RateLimit-Limit"] = str(int(bucket.capacity))
            return response

        # Bucket exhausted — calculate how long until one token is available.
        retry_after = max(1.0, (1.0 - bucket.tokens) / bucket.refill_rate)
        logger.warning("Rate limit exceeded for client %s", client)
        return JSONResponse(
            status_code=429,
            content={
                "detail": "Too many requests. Please retry later.",
                "retry_after_seconds": round(retry_after, 1),
            },
            headers={
                "Retry-After": str(int(retry_after)),
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Limit": str(int(bucket.capacity)),
            },
        )
