"""Aegis API — main FastAPI application.

Creates the application instance, registers routers under the ``/v1``
prefix, attaches middleware, and exposes a ``/health`` liveness probe.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import aegis
from aegis.api.middleware import RequestIDMiddleware, RequestSizeLimitMiddleware, TimingMiddleware
from aegis.api.rate_limit import RateLimitConfig, RateLimitMiddleware
from aegis.api.routes import (
    arena,
    eval,
    events,
    ingestion,
    memory,
    observability,
    online_eval,
    promotion,
    retrieval,
    training,
)
from aegis.api.routes.efficiency import router as efficiency_router
from aegis.core.settings import get_settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------


def _build_local_runtime_state() -> dict[str, object]:
    """Create deterministic in-process runtime state for local execution."""
    started_at = datetime.now(tz=UTC)
    return {
        "started_at": started_at,
        "status": "initializing",
        "resource_registry": {
            "event_queue": [],
            "background_tasks": [],
            "cache_regions": {},
        },
        "shutdown_hooks": ["flush_event_queue", "clear_cache_regions", "release_background_tasks"],
    }


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler.

    Startup logic (database pools, model loading, etc.) goes before the
    ``yield``; shutdown / cleanup goes after.
    """
    logger.info("Aegis API starting up")
    runtime_state = _build_local_runtime_state()
    runtime_state["status"] = "ready"
    app.state.runtime = runtime_state

    try:
        yield
    finally:
        logger.info("Aegis API shutting down")
        current_state = getattr(app.state, "runtime", runtime_state)
        current_state["status"] = "stopping"

        resources = current_state.get("resource_registry", {})
        if isinstance(resources, dict):
            for value in resources.values():
                if isinstance(value, list | dict):
                    value.clear()

        current_state["status"] = "stopped"
        current_state["stopped_at"] = datetime.now(tz=UTC)
        app.state.runtime = current_state


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------


def create_app() -> FastAPI:
    """Build and return the configured FastAPI application."""

    app = FastAPI(
        title="Aegis API",
        version=aegis.__version__,
        description=(
            "Aegis platform API for agent evaluation, memory management, "
            "training orchestration, retrieval, observability, and promotion."
        ),
        lifespan=lifespan,
    )

    # -- Middleware (order matters: outermost first) -------------------------
    settings = get_settings()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
        allow_headers=["*"],
    )
    app.add_middleware(
        RateLimitMiddleware,
        config=RateLimitConfig(
            requests_per_minute=settings.rate_limit_rpm,
            burst_size=settings.rate_limit_burst,
            limit_anonymous=settings.rate_limit_anonymous,
        ),
    )
    app.add_middleware(
        RequestSizeLimitMiddleware,
        max_content_length=settings.max_request_size,
    )
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(TimingMiddleware)

    # -- Routers -------------------------------------------------------------
    app.include_router(eval.router, prefix="/v1")
    app.include_router(arena.router, prefix="/v1")
    app.include_router(memory.router, prefix="/v1")
    app.include_router(training.router, prefix="/v1")
    app.include_router(retrieval.router, prefix="/v1")
    app.include_router(observability.router, prefix="/v1")
    app.include_router(promotion.router, prefix="/v1")
    app.include_router(events.router, prefix="/v1")
    app.include_router(online_eval.router, prefix="/v1")
    app.include_router(efficiency_router, prefix="/v1")
    app.include_router(ingestion.router, prefix="/v1")

    # -- Top-level routes ----------------------------------------------------

    class HealthResponse(BaseModel):
        """Response schema for the health-check endpoint."""

        status: str
        version: str
        timestamp: datetime

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    async def health_check() -> HealthResponse:
        """Liveness probe.

        Returns ``ok`` when the process is running and able to serve
        requests.  Does **not** verify downstream dependencies.
        """
        return HealthResponse(
            status="ok",
            version=aegis.__version__,
            timestamp=datetime.now(tz=UTC),
        )

    return app


# Convenience: importable application instance.
app = create_app()
