"""Aegis API middleware.

Custom ASGI middleware for cross-cutting concerns: request tracing,
performance timing, and request size enforcement.
"""

from __future__ import annotations

import logging
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Inject a unique ``X-Request-ID`` header into every response.

    If the incoming request already carries the header the existing value is
    propagated; otherwise a new UUID-4 is generated.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
        # Stash on request state so downstream handlers can access it.
        request.state.request_id = request_id

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class TimingMiddleware(BaseHTTPMiddleware):
    """Measure wall-clock request handling time.

    The elapsed duration (in milliseconds) is returned in the
    ``X-Response-Time`` header.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        response.headers["X-Response-Time"] = f"{elapsed_ms:.2f}ms"
        return response


class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject requests whose ``Content-Length`` exceeds a configurable limit.

    When the declared body size is larger than *max_content_length* bytes
    the middleware short-circuits with a ``413 Payload Too Large`` response
    before the body is read.

    Args:
        app: The ASGI application to wrap.
        max_content_length: Maximum allowed request body size in bytes.
            Defaults to 10 MB (``10_485_760``).
    """

    def __init__(
        self,
        app: object,
        max_content_length: int = 10 * 1024 * 1024,
    ) -> None:
        super().__init__(app)  # type: ignore[arg-type]
        self._max_content_length = max_content_length

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        content_length_header = request.headers.get("content-length")
        if content_length_header is not None:
            try:
                content_length = int(content_length_header)
            except (ValueError, TypeError):
                content_length = 0

            if content_length > self._max_content_length:
                logger.warning(
                    "Request body too large: %d bytes (limit %d)",
                    content_length,
                    self._max_content_length,
                )
                return JSONResponse(
                    status_code=413,
                    content={
                        "detail": "Payload too large.",
                        "max_bytes": self._max_content_length,
                        "received_bytes": content_length,
                    },
                )

        return await call_next(request)
