"""Aegis observability routes.

Endpoint for ingesting structured observability events from agents and
infrastructure.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from aegis.observatory.monitor import ObservatoryMonitor

router = APIRouter(prefix="/observability", tags=["observability"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class ObservabilityEventRequest(BaseModel):
    """Structured observability event emitted by an agent or service."""

    event_type: str = Field(
        ...,
        description="Event category, e.g. 'agent.step', 'memory.op', 'retrieval.query'.",
    )
    agent_id: str
    payload: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime | None = Field(
        default=None,
        description="Event timestamp. Server will assign one if omitted.",
    )


class ObservabilityEventResponse(BaseModel):
    """Acknowledgement after ingesting an observability event."""

    id: str
    status: str


# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_event_log: list[dict[str, Any]] = []
_monitor = ObservatoryMonitor()


# ---------------------------------------------------------------------------
# Route handler
# ---------------------------------------------------------------------------


@router.post("/events", response_model=ObservabilityEventResponse, status_code=201)
async def emit_observability_event(
    event: ObservabilityEventRequest,
) -> ObservabilityEventResponse:
    """Ingest a structured observability event.

    Events are validated, timestamped (if not already), and forwarded to
    the observability pipeline for indexing and alerting.
    """
    event_id = str(uuid.uuid4())
    ts = event.timestamp or datetime.now(tz=UTC)

    # Store the event in the in-memory log
    record: dict[str, Any] = {
        "id": event_id,
        "event_type": event.event_type,
        "agent_id": event.agent_id,
        "payload": event.payload,
        "timestamp": ts.isoformat(),
    }

    # If event_type starts with "health_check", run the relevant monitor check
    if event.event_type.startswith("health_check"):
        check_results: dict[str, Any] = {}

        if "reward" in event.event_type:
            result = _monitor.check_reward_hacking(
                reward_traces=event.payload.get("reward_traces"),
            )
            check_results["reward_hacking"] = {
                "healthy": result.healthy,
                "score": result.score,
                "details": result.details,
                "recommendations": result.recommendations,
            }
        elif "gradient" in event.event_type:
            result = _monitor.check_gradient_health(
                gradient_stats=event.payload.get("gradient_stats"),
            )
            check_results["gradient_health"] = {
                "healthy": result.healthy,
                "score": result.score,
                "details": result.details,
                "recommendations": result.recommendations,
            }
        elif "memory" in event.event_type:
            result = _monitor.check_memory_health(
                memory_stats=event.payload.get("memory_stats"),
            )
            check_results["memory_health"] = {
                "healthy": result.healthy,
                "score": result.score,
                "details": result.details,
                "recommendations": result.recommendations,
            }
        elif "drift" in event.event_type:
            result = _monitor.check_drift(
                reference_distribution=event.payload.get("reference_distribution"),
                current_distribution=event.payload.get("current_distribution"),
            )
            check_results["drift"] = {
                "healthy": result.healthy,
                "score": result.score,
                "details": result.details,
                "recommendations": result.recommendations,
            }
        else:
            # Generic health check: run all checks
            all_results = _monitor.run_all_checks()
            for hc in all_results:
                check_results[hc.check_name] = {
                    "healthy": hc.healthy,
                    "score": hc.score,
                    "details": hc.details,
                    "recommendations": hc.recommendations,
                }

        record["health_check_results"] = check_results

    _event_log.append(record)

    return ObservabilityEventResponse(
        id=event_id,
        status="accepted",
    )
