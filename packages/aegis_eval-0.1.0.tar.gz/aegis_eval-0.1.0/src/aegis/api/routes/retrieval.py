"""Aegis retrieval routes.

Endpoint for executing retrieval queries and returning full audit traces.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime

from fastapi import APIRouter
from pydantic import BaseModel, Field

from aegis.core.settings import get_settings
from aegis.core.types import RetrievalTraceV1
from aegis.eval.benchmarks import RetrievalPrecisionDepthBenchmark
from aegis.retrieval.context import ContextConstructor, RetrievalBackend, RetrievalPolicy
from aegis.retrieval.local_index import LocalSourceIndex

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/retrieval", tags=["retrieval"])

_LOCAL_SOURCE_INDEX: LocalSourceIndex | None = None
_RETRIEVAL_BACKENDS: list[RetrievalBackend] | None = None


def _get_local_source_index() -> LocalSourceIndex:
    global _LOCAL_SOURCE_INDEX
    if _LOCAL_SOURCE_INDEX is None:
        _LOCAL_SOURCE_INDEX = LocalSourceIndex()
    return _LOCAL_SOURCE_INDEX


def _get_retrieval_backends() -> list[RetrievalBackend]:
    """Build retrieval backends from centralized settings.

    Returns pgvector and/or Neo4j backends when configured.
    Falls back to an empty list (local index used instead).
    """
    global _RETRIEVAL_BACKENDS
    if _RETRIEVAL_BACKENDS is not None:
        return _RETRIEVAL_BACKENDS

    backends: list[RetrievalBackend] = []
    settings = get_settings()

    if settings.postgres_configured:
        try:
            from aegis.retrieval.pgvector_backend import PgVectorRetriever

            backends.append(PgVectorRetriever(dsn=settings.postgres_dsn))
            logger.info("PgVector retrieval backend enabled")
        except Exception:
            logger.warning("Failed to initialise PgVector backend", exc_info=True)

    if settings.neo4j_configured:
        try:
            from aegis.retrieval.neo4j_backend import Neo4jRetriever

            backends.append(
                Neo4jRetriever(
                    uri=settings.neo4j_uri,
                    user=settings.neo4j_user,
                    password=settings.neo4j_password,
                )
            )
            logger.info("Neo4j retrieval backend enabled")
        except Exception:
            logger.warning("Failed to initialise Neo4j backend", exc_info=True)

    _RETRIEVAL_BACKENDS = backends
    return backends


# ---------------------------------------------------------------------------
# Request model
# ---------------------------------------------------------------------------


class RetrievalQueryRequest(BaseModel):
    """Parameters for a retrieval query."""

    query: str
    sources: list[str] = Field(
        default_factory=lambda: ["vector"],
        description="Source types to query: vector, kg, sql, web.",
    )
    context_budget: int = Field(
        default=4096,
        ge=256,
        description="Maximum token budget for the assembled context.",
    )


# ---------------------------------------------------------------------------
# Route handler
# ---------------------------------------------------------------------------


@router.post("/query", response_model=RetrievalTraceV1)
async def execute_retrieval(request: RetrievalQueryRequest) -> RetrievalTraceV1:
    """Execute a retrieval query across configured sources.

    When database backends (pgvector, Neo4j) are configured via
    environment variables, they are queried alongside the local index.
    Returns a full ``RetrievalTraceV1`` including sources queried,
    rerank scores, and selected/dropped context blocks.
    """
    policy = RetrievalPolicy(
        source_types=request.sources,
        context_budget_tokens=request.context_budget,
        min_relevance_score=0.1,
    )

    backends = _get_retrieval_backends()
    constructor = ContextConstructor(policy=policy, backends=backends)

    # Also fetch from local index as fallback/supplement
    candidate_blocks = _get_local_source_index().query(
        query=request.query,
        source_types=request.sources,
        top_k_per_source=5,
    )
    trace = constructor.retrieve_and_construct(query=request.query, sources=candidate_blocks)

    # Assign fresh UUIDs and timestamp to the trace
    trace.id = str(uuid.uuid4())
    trace.trajectory_id = str(uuid.uuid4())
    trace.timestamp = datetime.now(tz=UTC)

    return trace


@router.get("/benchmark/m4", response_model=dict[str, float | int | bool | str])
async def retrieval_m4_benchmark() -> dict[str, float | int | bool | str]:
    """Run the M4 retrieval precision/depth benchmark and return its summary."""
    benchmark = RetrievalPrecisionDepthBenchmark()
    report = benchmark.evaluate_improvement()
    return {
        "benchmark": str(report["benchmark"]),
        "total_cases": int(report["total_cases"]),
        "baseline_mean": float(report["baseline_mean"]),
        "candidate_mean": float(report["candidate_mean"]),
        "relative_improvement": float(report["relative_improvement"]),
        "target_improvement": float(report["target_improvement"]),
        "meets_target": bool(report["meets_target"]),
        "baseline_precision_mean": float(report["baseline_precision_mean"]),
        "candidate_precision_mean": float(report["candidate_precision_mean"]),
        "baseline_depth_mean": float(report["baseline_depth_mean"]),
        "candidate_depth_mean": float(report["candidate_depth_mean"]),
    }
