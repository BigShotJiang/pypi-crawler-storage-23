"""Aegis Arena API routes.

Endpoints for submitting agents, querying the live leaderboard,
and fetching per-agent arena details.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field, field_validator

from aegis.arena.leaderboard import ELORating, Leaderboard, RankingConfig
from aegis.arena.submission import (
    SubmissionManager,
    SubmissionRunner,
    SubmissionStatus,
    SubmissionValidator,
)

router = APIRouter(prefix="/arena", tags=["arena"])

_submission_manager = SubmissionManager()
_submission_runner = SubmissionRunner()
_leaderboard = Leaderboard()
_elo = ELORating()


class ArenaSubmitRequest(BaseModel):
    """Request payload for submitting an agent to the arena."""

    agent_name: str = Field(min_length=1, max_length=128)
    agent_description: str = Field(default="", max_length=10_000)
    framework: str = Field(min_length=1, max_length=64)
    domains: list[str] = Field(min_length=1, max_length=10)
    model_size: str | None = Field(default=None, max_length=64)
    public: bool = True
    submitted_by: str = Field(default="anonymous", max_length=128)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("domains")
    @classmethod
    def _normalize_domains(cls, values: list[str]) -> list[str]:
        normalized = [value.strip().lower() for value in values if value.strip()]
        if not normalized:
            raise ValueError("domains must include at least one non-empty value")
        # Preserve order while removing duplicates.
        seen: set[str] = set()
        result: list[str] = []
        for value in normalized:
            if value in seen:
                continue
            seen.add(value)
            result.append(value)
        return result


class ArenaScores(BaseModel):
    """Structured score object returned by arena endpoints."""

    overall: float = Field(ge=0.0, le=1.0)
    dimensions: dict[str, float] = Field(default_factory=dict)
    domains: dict[str, float] = Field(default_factory=dict)


class ArenaSubmitResponse(BaseModel):
    """Response for a successful arena submission."""

    submission_id: str
    status: str
    agent_name: str
    framework: str
    rank: int
    total_latency_ms: int
    scores: ArenaScores


class ArenaLeaderboardEntry(BaseModel):
    """A leaderboard row."""

    rank: int
    agent_id: str
    agent_name: str
    framework: str
    overall_score: float = Field(ge=0.0, le=1.0)
    dimension_count: int = Field(ge=0)
    domain_scores: dict[str, float] = Field(default_factory=dict)
    elo_rating: float


class ArenaLeaderboardResponse(BaseModel):
    """Leaderboard response payload."""

    generated_at: datetime
    total_entries: int
    entries: list[ArenaLeaderboardEntry] = Field(default_factory=list)


class ArenaAgentResponse(BaseModel):
    """Detailed profile for a single arena agent."""

    agent_id: str
    agent_name: str
    framework: str
    status: str
    submitted_at: datetime | None = None
    overall_score: float = Field(ge=0.0, le=1.0)
    rank: int = Field(ge=0)
    elo_rating: float
    scores: ArenaScores
    model_size: str | None = None


def _extract_dimension_scores(scores: Any) -> dict[str, float]:
    """Coerce raw score mapping to ``dict[str, float]`` in 0..1."""
    if not isinstance(scores, dict):
        return {}
    normalized: dict[str, float] = {}
    for key, value in scores.items():
        if not isinstance(key, str):
            continue
        if not isinstance(value, int | float):
            continue
        score = max(0.0, min(1.0, float(value)))
        normalized[key] = round(score, 4)
    return normalized


def _domain_scores(
    dimensions: dict[str, float],
    domains: list[str],
) -> dict[str, float]:
    """Aggregate dimension scores into per-domain means."""
    result: dict[str, float] = {}
    for domain in domains:
        domain_dims = [value for key, value in dimensions.items() if key.startswith(f"{domain}_")]
        if not domain_dims:
            continue
        result[domain] = round(sum(domain_dims) / len(domain_dims), 4)
    return result


def _compute_cost(metadata: dict[str, Any]) -> float | None:
    """Extract an optional compute cost estimate from metadata."""
    raw = metadata.get("compute_cost_usd")
    if isinstance(raw, int | float):
        return float(raw)
    if isinstance(raw, str):
        try:
            return float(raw)
        except ValueError:
            return None
    return None


@router.post("/submit", response_model=ArenaSubmitResponse, status_code=201)
async def submit_arena_agent(payload: ArenaSubmitRequest) -> ArenaSubmitResponse:
    """Submit an agent and immediately evaluate it for the arena leaderboard."""
    submission_payload = payload.model_dump()
    validator = SubmissionValidator()
    is_valid, errors = validator.validate(submission_payload)
    if not is_valid:
        raise HTTPException(status_code=422, detail={"errors": errors})

    submission = _submission_manager.submit(
        agent_name=payload.agent_name,
        agent_description=payload.agent_description,
        framework=payload.framework,
        domains=payload.domains,
        public=payload.public,
        submitted_by=payload.submitted_by,
        model_size=payload.model_size,
        metadata=payload.metadata,
    )
    _submission_manager.update_status(submission.id, SubmissionStatus.EVALUATING)

    run_result = _submission_runner.run(submission_payload)
    if run_result.get("status") != "completed":
        _submission_manager.update_status(submission.id, SubmissionStatus.FAILED)
        errors = run_result.get("errors", ["arena evaluation failed"])
        raise HTTPException(status_code=500, detail=errors)

    dimension_scores = _extract_dimension_scores(run_result.get("scores"))
    overall = (
        round(sum(dimension_scores.values()) / len(dimension_scores), 4)
        if dimension_scores
        else 0.0
    )
    domain_scores = _domain_scores(dimension_scores, payload.domains)

    entry = _leaderboard.add_result(
        submission_id=submission.id,
        agent_name=submission.agent_name,
        framework=submission.framework,
        scores={
            "overall": overall,
            "dimensions": dimension_scores,
            "domains": domain_scores,
        },
        model_size=submission.model_size,
        compute_cost=_compute_cost(payload.metadata),
    )
    _submission_manager.update_status(submission.id, SubmissionStatus.COMPLETED)

    # Update ELO against all existing competitors.
    ranked_now = _leaderboard.rank(config=RankingConfig(min_dimensions=0))
    for competitor in ranked_now:
        if competitor.submission_id == entry.submission_id:
            continue
        if entry.overall_score >= competitor.overall_score:
            _elo.update(entry.submission_id, competitor.submission_id)
        else:
            _elo.update(competitor.submission_id, entry.submission_id)

    rank = 0
    for ranked_entry in _leaderboard.rank(config=RankingConfig(min_dimensions=0)):
        if ranked_entry.submission_id == entry.submission_id:
            rank = ranked_entry.rank
            break

    latency_ms = run_result.get("total_latency_ms", 0)
    latency = latency_ms if isinstance(latency_ms, int) else 0

    return ArenaSubmitResponse(
        submission_id=entry.submission_id,
        status="completed",
        agent_name=entry.agent_name,
        framework=entry.framework,
        rank=rank,
        total_latency_ms=latency,
        scores=ArenaScores(
            overall=overall,
            dimensions=dimension_scores,
            domains=domain_scores,
        ),
    )


@router.get("/leaderboard", response_model=ArenaLeaderboardResponse)
async def get_arena_leaderboard(
    sort_by: str = Query(default="aggregate"),
    domain_filter: str | None = Query(default=None),
    model_size_filter: str | None = Query(default=None),
    min_dimensions: int = Query(default=0, ge=0, le=100),
) -> ArenaLeaderboardResponse:
    """Return the arena leaderboard."""
    config = RankingConfig(
        sort_by=sort_by,
        domain_filter=domain_filter,
        model_size_filter=model_size_filter,
        min_dimensions=min_dimensions,
    )
    entries = _leaderboard.rank(config=config)

    rows = [
        ArenaLeaderboardEntry(
            rank=entry.rank,
            agent_id=entry.submission_id,
            agent_name=entry.agent_name,
            framework=entry.framework,
            overall_score=round(entry.overall_score, 4),
            dimension_count=len(entry.dimension_scores),
            domain_scores=entry.domain_scores,
            elo_rating=round(_elo.get_rating(entry.submission_id), 2),
        )
        for entry in entries
    ]

    return ArenaLeaderboardResponse(
        generated_at=datetime.now(tz=UTC),
        total_entries=len(rows),
        entries=rows,
    )


@router.get("/agent/{agent_id}", response_model=ArenaAgentResponse)
async def get_arena_agent(agent_id: str) -> ArenaAgentResponse:
    """Return full arena details for one agent/submission ID."""
    details = _leaderboard.get_agent_details(agent_id)
    if "error" in details:
        raise HTTPException(status_code=404, detail=details["error"])

    submission = _submission_manager.get(agent_id)
    status = submission.status.value if submission is not None else "unknown"
    submitted_at = submission.submitted_at if submission is not None else None

    return ArenaAgentResponse(
        agent_id=agent_id,
        agent_name=str(details.get("agent_name", "")),
        framework=str(details.get("framework", "")),
        status=status,
        submitted_at=submitted_at,
        overall_score=float(details.get("overall_score", 0.0)),
        rank=int(details.get("rank", 0)),
        elo_rating=round(_elo.get_rating(agent_id), 2),
        scores=ArenaScores(
            overall=float(details.get("overall_score", 0.0)),
            dimensions={
                key: float(value)
                for key, value in details.get("dimension_scores", {}).items()
                if isinstance(key, str) and isinstance(value, int | float)
            },
            domains={
                key: float(value)
                for key, value in details.get("domain_scores", {}).items()
                if isinstance(key, str) and isinstance(value, int | float)
            },
        ),
        model_size=details.get("model_size")
        if isinstance(details.get("model_size"), str) or details.get("model_size") is None
        else None,
    )
