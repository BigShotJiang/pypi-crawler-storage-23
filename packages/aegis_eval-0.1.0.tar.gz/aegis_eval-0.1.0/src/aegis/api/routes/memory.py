"""Aegis memory routes.

Endpoints for emitting memory events, querying the memory store,
storing/retrieving/updating/deleting entries, linking, health checks,
audit trails, and point-in-time snapshots.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from aegis.core.types import MemoryEventV1, MemoryOperation, MemoryTier, TemporalBounds
from aegis.memory.manager import MemoryManager

router = APIRouter(prefix="/memory", tags=["memory"])


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_manager: MemoryManager | None = None


def get_manager() -> MemoryManager:
    """Return the module-level :class:`MemoryManager` singleton.

    Uses the factory to create a manager with appropriate backends
    (pgvector, Neo4j) if database URLs are configured, otherwise
    falls back to in-memory stores.
    """
    global _manager
    if _manager is None:
        from aegis.memory.factory import create_memory_manager

        _manager = create_memory_manager()
    return _manager


# ---------------------------------------------------------------------------
# Request / response models (backward-compatible)
# ---------------------------------------------------------------------------


class MemoryEventResponse(BaseModel):
    """Acknowledgement after ingesting a memory event."""

    id: str
    status: str


class MemoryQueryRequest(BaseModel):
    """Query parameters for searching the memory store."""

    query: str
    customer_id: str
    memory_tier: MemoryTier | None = None
    limit: int = Field(default=10, ge=1, le=200)


class MemoryEntryResponse(BaseModel):
    """A single memory entry returned from a query."""

    id: str
    key: str
    value: Any
    memory_tier: MemoryTier
    confidence: float = Field(ge=0.0, le=1.0)
    timestamp: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemorySnapshot(BaseModel):
    """Point-in-time view of the memory store."""

    timestamp: datetime
    total_entries: int
    tier_counts: dict[str, int] = Field(default_factory=dict)
    entries: list[MemoryEntryResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# New request models
# ---------------------------------------------------------------------------


class StoreRequest(BaseModel):
    """Request body for POST /memory/store."""

    key: str
    value: Any
    tier: MemoryTier = MemoryTier.WORKING
    provenance: dict[str, Any] = Field(default_factory=dict)
    temporal_bounds: TemporalBounds | None = None
    agent_id: str = ""
    customer_id: str = ""
    tags: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)


class RetrieveRequest(BaseModel):
    """Request body for POST /memory/retrieve.

    Supports both direct key lookup and semantic search.
    """

    query: str
    mode: str = Field(
        default="auto",
        description="Retrieval mode: 'key' for exact lookup, 'semantic' for vector search, 'auto' tries both.",
    )
    limit: int = Field(default=10, ge=1, le=200)


class UpdateRequest(BaseModel):
    """Request body for PUT /memory/{key}."""

    value: Any


class LinkRequest(BaseModel):
    """Request body for POST /memory/link."""

    key_a: str
    key_b: str
    relation: str = "related"


# ---------------------------------------------------------------------------
# Backward-compatible route handlers
# ---------------------------------------------------------------------------


@router.post("/events", response_model=MemoryEventResponse, status_code=201)
async def emit_memory_event(event: MemoryEventV1) -> MemoryEventResponse:
    """Emit a new memory event.

    Routes the event through the MemoryManager so that all cross-cutting
    concerns (vector index, temporal index, provenance, policy) are applied.
    """
    mgr = get_manager()

    op = event.operation
    if op == MemoryOperation.STORE:
        mgr.store(
            key=event.key,
            value=event.value,
            tier=event.memory_tier,
            provenance=event.provenance,
            confidence=event.confidence,
            agent_id=event.agent_id,
            customer_id=event.customer_id,
        )
    elif op == MemoryOperation.UPDATE:
        mgr.update(event.key, event.value, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.FORGET:
        mgr.forget(event.key, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.RETRIEVE:
        mgr.retrieve(event.key, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.LINK:
        target = event.metadata.get("target_key", "")
        relation = event.metadata.get("relation", "related")
        mgr.link(
            event.key, target, relation, agent_id=event.agent_id, customer_id=event.customer_id
        )
    elif op == MemoryOperation.COMPRESS:
        mgr.compress(event.key, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.PROMOTE:
        mgr.promote(
            event.key, event.memory_tier, agent_id=event.agent_id, customer_id=event.customer_id
        )
    elif op == MemoryOperation.DEMOTE:
        mgr.demote(
            event.key, event.memory_tier, agent_id=event.agent_id, customer_id=event.customer_id
        )
    elif op == MemoryOperation.SPLIT:
        mgr.split(event.key, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.MERGE:
        merge_sources = event.metadata.get("merge_sources", [])
        if len(merge_sources) == 2:
            mgr.merge(
                merge_sources[0],
                merge_sources[1],
                agent_id=event.agent_id,
                customer_id=event.customer_id,
            )
    elif op == MemoryOperation.VERIFY:
        mgr.verify(event.key, agent_id=event.agent_id, customer_id=event.customer_id)
    elif op == MemoryOperation.ANNOTATE:
        mgr.annotate(
            event.key, event.metadata, agent_id=event.agent_id, customer_id=event.customer_id
        )

    return MemoryEventResponse(
        id=event.id,
        status="accepted",
    )


@router.post("/query", response_model=list[MemoryEntryResponse])
async def query_memory(request: MemoryQueryRequest) -> list[MemoryEntryResponse]:
    """Query the memory store.

    Attempts semantic search first; falls back to direct retrieval or
    returns placeholder results for backward compatibility.
    """
    mgr = get_manager()

    # Try semantic search via manager.
    results = mgr.semantic_search(request.query, top_k=request.limit)
    if results:
        return [
            MemoryEntryResponse(
                id=str(uuid.uuid4()),
                key=entry.key,
                value=entry.value,
                memory_tier=entry.tier,
                confidence=entry.confidence,
                timestamp=entry.created_at,
                metadata=entry.metadata,
            )
            for entry in results
        ]

    # Fall back: try direct key retrieval.
    entry = mgr.retrieve(request.query)
    if entry is not None:
        return [
            MemoryEntryResponse(
                id=str(uuid.uuid4()),
                key=entry.key,
                value=entry.value,
                memory_tier=entry.tier,
                confidence=entry.confidence,
                timestamp=entry.created_at,
                metadata=entry.metadata,
            ),
        ]

    return []


# ---------------------------------------------------------------------------
# New route handlers
# ---------------------------------------------------------------------------


@router.post("/store", status_code=201)
async def store_entry(req: StoreRequest) -> dict[str, Any]:
    """Create a new memory entry via the manager.

    Accepts key, value, tier, provenance, temporal_bounds, confidence, and
    tags.  Returns the stored key, tier, confidence, and status.
    """
    mgr = get_manager()
    entry = mgr.store(
        key=req.key,
        value=req.value,
        tier=req.tier,
        provenance=req.provenance,
        temporal_bounds=req.temporal_bounds,
        confidence=req.confidence,
        tags=req.tags,
        agent_id=req.agent_id,
        customer_id=req.customer_id,
    )
    return {
        "key": entry.key,
        "tier": entry.tier.value,
        "confidence": entry.confidence,
        "status": "stored",
    }


@router.post("/retrieve")
async def retrieve_entry(request: RetrieveRequest) -> list[MemoryEntryResponse]:
    """Retrieve memory entries by key lookup and/or semantic search.

    Modes:
    - ``key``: Direct key lookup only.
    - ``semantic``: Vector similarity search only.
    - ``auto`` (default): Tries semantic search first, falls back to key lookup.
    """
    mgr = get_manager()

    results: list[MemoryEntryResponse] = []

    # Semantic search path
    if request.mode in ("semantic", "auto"):
        entries = mgr.semantic_search(request.query, top_k=request.limit)
        if entries:
            return [
                MemoryEntryResponse(
                    id=str(uuid.uuid4()),
                    key=entry.key,
                    value=entry.value,
                    memory_tier=entry.tier,
                    confidence=entry.confidence,
                    timestamp=entry.created_at,
                    metadata=entry.metadata,
                )
                for entry in entries
            ]

    # Key lookup path
    if request.mode in ("key", "auto"):
        entry = mgr.retrieve(request.query)
        if entry is not None:
            return [
                MemoryEntryResponse(
                    id=str(uuid.uuid4()),
                    key=entry.key,
                    value=entry.value,
                    memory_tier=entry.tier,
                    confidence=entry.confidence,
                    timestamp=entry.created_at,
                    metadata=entry.metadata,
                ),
            ]

    return results


@router.put("/{key}")
async def update_entry(key: str, req: UpdateRequest) -> dict[str, Any]:
    """Update an existing memory entry's value."""
    mgr = get_manager()
    ok = mgr.update(key, req.value)
    return {"key": key, "updated": ok}


@router.delete("/{key}")
async def forget_entry(key: str) -> dict[str, Any]:
    """Forget (delete) a memory entry."""
    mgr = get_manager()
    ok = mgr.forget(key)
    return {"key": key, "deleted": ok}


@router.post("/link")
async def link_entries(req: LinkRequest) -> dict[str, Any]:
    """Create a semantic link between two memory entries."""
    mgr = get_manager()
    ok = mgr.link(req.key_a, req.key_b, req.relation)
    return {"key_a": req.key_a, "key_b": req.key_b, "linked": ok}


@router.get("/health")
async def memory_health() -> dict[str, Any]:
    """Return a health dashboard for the memory subsystem."""
    mgr = get_manager()
    return mgr.health()


@router.get("/audit")
async def audit_trail(
    start: str | None = None,
    end: str | None = None,
) -> list[dict[str, Any]]:
    """Return events from the event log, optionally filtered by time.

    Query parameters *start* and *end* are ISO-8601 datetime strings.
    """
    mgr = get_manager()

    start_dt: datetime | None = None
    end_dt: datetime | None = None
    if start is not None:
        start_dt = datetime.fromisoformat(start)
    if end is not None:
        end_dt = datetime.fromisoformat(end)

    events = mgr.audit_trail(start=start_dt, end=end_dt)
    return [event.model_dump(mode="json") for event in events]


@router.get("/snapshots/{timestamp}", response_model=MemorySnapshot)
async def get_memory_snapshot(timestamp: str) -> MemorySnapshot:
    """Retrieve a point-in-time snapshot of the memory store.

    The *timestamp* path parameter should be an ISO-8601 datetime string.
    """
    mgr = get_manager()

    try:
        ts = datetime.fromisoformat(timestamp)
    except (ValueError, TypeError):
        ts = datetime.now(tz=UTC)

    snapshot = mgr.snapshot_at(ts)

    entries = [
        MemoryEntryResponse(
            id=str(uuid.uuid4()),
            key=entry.key,
            value=entry.value,
            memory_tier=entry.tier,
            confidence=entry.confidence,
            timestamp=entry.created_at,
            metadata=entry.metadata,
        )
        for entry in snapshot.entries.values()
    ]

    return MemorySnapshot(
        timestamp=snapshot.timestamp,
        total_entries=snapshot.total_entries,
        tier_counts=snapshot.tier_counts,
        entries=entries,
    )


@router.get("/snapshot/{timestamp}", response_model=MemorySnapshot)
async def get_memory_snapshot_singular(timestamp: str) -> MemorySnapshot:
    """Alias for ``/snapshots/{timestamp}`` — point-in-time memory reconstruction.

    Provided for API consistency (singular noun convention).
    """
    return await get_memory_snapshot(timestamp)
