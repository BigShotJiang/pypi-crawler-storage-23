"""Efficiency tracking API routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from aegis.observatory.efficiency import EfficiencyTracker

router = APIRouter(prefix="/efficiency", tags=["efficiency"])

_tracker = EfficiencyTracker()


class StartRunRequest(BaseModel):
    run_id: str
    model_name: str = "default"


class RecordTokensRequest(BaseModel):
    run_id: str
    input_tokens: int = 0
    output_tokens: int = 0


@router.post("/start", status_code=201)
async def start_run(req: StartRunRequest) -> dict[str, Any]:
    """Start tracking a new eval run."""
    snapshot = _tracker.start_run(req.run_id)
    return {"run_id": snapshot.run_id, "status": "tracking"}


@router.post("/end")
async def end_run(run_id: str) -> dict[str, Any]:
    """End tracking for a run and finalize metrics."""
    snapshot = _tracker.end_run(run_id)
    if not snapshot:
        return {"error": "Run not found"}
    eff = snapshot.efficiency
    return {
        "run_id": snapshot.run_id,
        "total_tokens": eff.total_tokens,
        "latency_ms": eff.latency_ms,
        "cost_usd": eff.cost_estimate_usd,
    }


@router.get("/runs")
async def all_runs() -> list[dict[str, Any]]:
    """List all tracked runs."""
    return _tracker.all_runs()


@router.get("/runs/{run_id}")
async def get_run(run_id: str) -> dict[str, Any]:
    """Get efficiency metrics for a specific run."""
    eff = _tracker.get_efficiency(run_id)
    if not eff:
        return {"error": "Run not found"}
    return eff.model_dump()


@router.get("/compare")
async def compare_runs(run_a: str, run_b: str) -> dict[str, Any]:
    """Compare efficiency between two runs."""
    return _tracker.compare_runs(run_a, run_b)
