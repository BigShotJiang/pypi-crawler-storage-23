"""Aegis evaluation routes.

Endpoints for creating eval runs, retrieving results, comparing runs, and
browsing the dimension catalogue.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, Protocol, cast

from fastapi import APIRouter, HTTPException, Query, Response
from pydantic import BaseModel, Field

from aegis.core.config import AgentConfig
from aegis.core.types import EvalTier
from aegis.eval.benchmarks.harness import BenchmarkHarness

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/evals", tags=["evals"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CreateEvalRunRequest(BaseModel):
    """Payload to kick off a new evaluation run."""

    agent_config: AgentConfig
    dimensions: list[str] | str = "all"
    domain_plugins: list[dict[str, Any]] = Field(default_factory=list)
    num_scenarios: int = Field(default=200, ge=1, le=10_000)
    difficulty: int = Field(default=3, ge=1, le=5)


class EvalRunResponse(BaseModel):
    """Acknowledgement returned when an eval run is created."""

    run_id: str
    status: str
    created_at: datetime


class DimensionScore(BaseModel):
    """Score for a single evaluation dimension."""

    dimension_id: str
    score: float = Field(ge=0.0, le=1.0)
    num_cases: int
    tier: EvalTier


class EvalRunDetailResponse(BaseModel):
    """Full status and results for an evaluation run."""

    run_id: str
    status: str
    overall_score: float | None = None
    dimension_scores: list[DimensionScore] = Field(default_factory=list)
    diagnostic: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class CompareRequest(BaseModel):
    """Request body for comparing two evaluation runs."""

    run_id_a: str
    run_id_b: str


class DimensionDelta(BaseModel):
    """Score delta for a single dimension between two runs."""

    dimension_id: str
    score_a: float
    score_b: float
    delta: float


class CompareResponse(BaseModel):
    """Per-dimension deltas between two evaluation runs."""

    run_id_a: str
    run_id_b: str
    deltas: list[DimensionDelta]


class DimensionInfo(BaseModel):
    """Catalogue entry describing an evaluation dimension."""

    dimension_id: str
    name: str
    tier: EvalTier
    description: str
    metric_keys: list[str] = Field(default_factory=list)
    scorer_type: str | None = None
    phase: str | None = None
    domain: str | None = None


class EvalHistoryItem(BaseModel):
    """Summary of a historical eval run for listing."""

    run_id: str
    agent_id: str
    status: str
    overall_score: float
    num_dimensions: int
    created_at: datetime


class DiagnosticRequest(BaseModel):
    """Request body for POST /evals/diagnostic."""

    run_id: str


class DiagnosticResponse(BaseModel):
    """Full diagnostic report for an eval run."""

    run_id: str
    overall_score: float = 0.0
    tier_scores: dict[str, float] = Field(default_factory=dict)
    weak_dimensions: list[str] = Field(default_factory=list)
    strong_dimensions: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class BenchmarkSuiteInfo(BaseModel):
    """Metadata describing one benchmark suite."""

    name: str
    case_count: int
    domains: list[str] = Field(default_factory=list)


class BenchmarkRunRequest(BaseModel):
    """Request body for running a benchmark suite."""

    suite: str = Field(min_length=1)
    pass_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    scorer_mode: str = Field(default="mock")
    difficulty_filter: int | None = Field(default=None, ge=1, le=5)
    dimension_filter: str | None = Field(default=None)


class BenchmarkRunResponse(BaseModel):
    """Response body for benchmark runs."""

    suite: str
    suite_size: int
    run_id: str
    overall_score: float
    pass_threshold: float
    passed: bool
    dimension_scores: dict[str, float] = Field(default_factory=dict)
    domains: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    scorer_mode: str = "mock"
    difficulty_filter: int | None = None
    dimension_filter: str | None = None


class BenchmarkHistoryItem(BaseModel):
    """Summary row for benchmark run history."""

    run_id: str
    suite: str
    overall_score: float
    suite_size: int
    passed: bool
    created_at: datetime


# ---------------------------------------------------------------------------
# In-memory eval run store
# ---------------------------------------------------------------------------

from aegis.eval.engine import EvalConfig, EvalResult, Evaluator  # noqa: E402


class _EvalRunRow(Protocol):
    run_id: str


class _BenchmarkRunRow(Protocol):
    run_id: str
    suite: str
    overall_score: float
    suite_size: int
    passed: bool
    created_at: datetime


class _EvalStore(Protocol):
    def save_eval_run(self, result: EvalResult) -> None: ...
    def get_eval_run(self, run_id: str) -> EvalResult | None: ...
    def list_eval_runs(
        self,
        limit: int = 20,
        offset: int = 0,
        agent_id: str | None = None,
    ) -> list[_EvalRunRow]: ...
    def save_benchmark_run(self, run_id: str, run_data: dict[str, Any]) -> None: ...
    def get_benchmark_run(self, run_id: str) -> dict[str, Any] | None: ...
    def list_benchmark_runs(
        self,
        limit: int = 50,
        offset: int = 0,
        suite: str | None = None,
    ) -> list[_BenchmarkRunRow]: ...


_eval_runs: dict[str, EvalResult] = {}
_benchmark_runs: dict[str, BenchmarkRunResponse] = {}

# ---------------------------------------------------------------------------
# SQLite persistence helpers
# ---------------------------------------------------------------------------

_store_instance: _EvalStore | None = None


def _get_store() -> _EvalStore:
    """Lazy singleton for the SQLite store."""
    global _store_instance
    if _store_instance is None:
        from aegis.store.sqlite import SQLiteStore

        _store_instance = cast("_EvalStore", SQLiteStore())
    return _store_instance


def _get_eval_run(run_id: str) -> EvalResult | None:
    """Look up an eval run: in-memory first, then SQLite fallback."""
    result = _eval_runs.get(run_id)
    if result is not None:
        return result
    try:
        result = _get_store().get_eval_run(run_id)
        if result is not None:
            _eval_runs[run_id] = result
        return result
    except Exception:
        return None


def _domain_plugins_for_suite(suite: str) -> list[str]:
    """Map benchmark suite names to evaluator domain plugins."""
    if suite in {
        "legal",
        "legal-memory",
        "legal_memory",
        "legal-memory-scale",
        "legal_memory_scale",
    }:
        return ["legal"]
    if suite in {"finance", "finance-memory", "finance_memory"}:
        return ["finance"]
    if suite in {"reward-integrity", "reward_integrity"}:
        return ["safety"]
    return []


def _save_benchmark_run(run: BenchmarkRunResponse) -> None:
    """Persist benchmark run in-memory and best-effort to backing store."""
    _benchmark_runs[run.run_id] = run
    try:
        _get_store().save_benchmark_run(run.run_id, run.model_dump(mode="json"))
    except Exception:
        logger.warning("Failed to persist benchmark run %s to SQLite", run.run_id, exc_info=True)


def _get_benchmark_run(run_id: str) -> BenchmarkRunResponse | None:
    """Load benchmark run by ID from memory, with store fallback."""
    run = _benchmark_runs.get(run_id)
    if run is not None:
        return run

    try:
        payload = _get_store().get_benchmark_run(run_id)
    except Exception:
        return None

    if payload is None:
        return None

    loaded = BenchmarkRunResponse.model_validate(payload)
    _benchmark_runs[run_id] = loaded
    return loaded


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


@router.post("/runs", response_model=EvalRunResponse, status_code=201)
async def create_eval_run(request: CreateEvalRunRequest) -> EvalRunResponse:
    """Create a new evaluation run.

    Accepts agent configuration, dimensions to evaluate, optional domain
    plugins, scenario count, and difficulty level.  Returns the run ID and
    initial status.
    """
    # Map integer difficulty to string expected by EvalConfig
    difficulty_map = {1: "easy", 2: "easy", 3: "medium", 4: "hard", 5: "hard"}
    difficulty_str = difficulty_map.get(request.difficulty, "medium")

    # Extract domain plugin names if provided as dicts with a "name" key
    domain_plugins: list[str] = []
    for plugin in request.domain_plugins:
        if isinstance(plugin, dict) and "name" in plugin:
            domain_plugins.append(plugin["name"])

    config = EvalConfig(
        dimensions=request.dimensions,
        domain_plugins=domain_plugins,
        num_scenarios=request.num_scenarios,
        difficulty=difficulty_str,
    )

    evaluator = Evaluator(config=config)
    result = evaluator.run()

    # Store the result for later retrieval
    _eval_runs[result.run_id] = result
    try:
        _get_store().save_eval_run(result)
    except Exception:
        logger.warning("Failed to persist eval run %s to SQLite", result.run_id, exc_info=True)

    return EvalRunResponse(
        run_id=result.run_id,
        status="completed",
        created_at=result.created_at,
    )


@router.get("/runs/{run_id}", response_model=EvalRunDetailResponse)
async def get_eval_run(run_id: str) -> EvalRunDetailResponse:
    """Retrieve the current status and results of an evaluation run."""
    result = _get_eval_run(run_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Eval run '{run_id}' not found")

    # Ensure tier modules are imported for registry lookups.
    import aegis.eval.dimensions.tier1_memory  # noqa: F401
    import aegis.eval.dimensions.tier2_context  # noqa: F401
    import aegis.eval.dimensions.tier3_learning  # noqa: F401
    import aegis.eval.dimensions.tier4_reasoning  # noqa: F401
    import aegis.eval.dimensions.tier5_metacognition  # noqa: F401
    import aegis.eval.dimensions.tier6_collaborative  # noqa: F401
    import aegis.eval.dimensions.tier7_security  # noqa: F401
    from aegis.eval.dimensions.registry import DimensionRegistry

    registry = DimensionRegistry.instance()

    dimension_scores: list[DimensionScore] = []
    for dim_id, score in result.dimension_scores.items():
        # Look up tier from the registry; fall back to MEMORY_FIDELITY
        try:
            dim = registry.get(dim_id)
            tier = dim.tier
        except KeyError:
            tier = EvalTier.MEMORY_FIDELITY

        # Count how many judge packets belong to this dimension
        num_cases = sum(1 for p in result.judge_packets if p.dimension_id == dim_id)

        dimension_scores.append(
            DimensionScore(
                dimension_id=dim_id,
                score=round(score, 4),
                num_cases=num_cases,
                tier=tier,
            )
        )

    return EvalRunDetailResponse(
        run_id=run_id,
        status="completed",
        overall_score=round(result.overall_score, 4),
        dimension_scores=dimension_scores,
        diagnostic=result.diagnostic,
        created_at=result.created_at,
    )


@router.post("/compare", response_model=CompareResponse)
async def compare_runs(request: CompareRequest) -> CompareResponse:
    """Compare two evaluation runs and return per-dimension deltas."""
    result_a = _get_eval_run(request.run_id_a)
    if result_a is None:
        raise HTTPException(
            status_code=404,
            detail=f"Eval run '{request.run_id_a}' not found",
        )

    result_b = _get_eval_run(request.run_id_b)
    if result_b is None:
        raise HTTPException(
            status_code=404,
            detail=f"Eval run '{request.run_id_b}' not found",
        )

    comparison = Evaluator().compare(result_a, result_b)

    deltas: list[DimensionDelta] = []
    dimension_deltas: dict[str, float] = comparison.get("dimension_deltas", {})
    for dim_id, delta in dimension_deltas.items():
        score_a = result_a.dimension_scores.get(dim_id, 0.0)
        score_b = result_b.dimension_scores.get(dim_id, 0.0)
        deltas.append(
            DimensionDelta(
                dimension_id=dim_id,
                score_a=round(score_a, 4),
                score_b=round(score_b, 4),
                delta=round(delta, 4),
            )
        )

    return CompareResponse(
        run_id_a=request.run_id_a,
        run_id_b=request.run_id_b,
        deltas=deltas,
    )


@router.get("/dimensions", response_model=list[DimensionInfo])
async def list_dimensions() -> list[DimensionInfo]:
    """List all available evaluation dimensions."""
    # Ensure tier modules are imported for self-registration.
    import aegis.eval.dimensions.tier1_memory  # noqa: F401
    import aegis.eval.dimensions.tier2_context  # noqa: F401
    import aegis.eval.dimensions.tier3_learning  # noqa: F401
    import aegis.eval.dimensions.tier4_reasoning  # noqa: F401
    import aegis.eval.dimensions.tier5_metacognition  # noqa: F401
    import aegis.eval.dimensions.tier6_collaborative  # noqa: F401
    import aegis.eval.dimensions.tier7_security  # noqa: F401
    from aegis.eval.dimensions.registry import DimensionRegistry

    registry = DimensionRegistry.instance()
    dims = registry.all()
    return [
        DimensionInfo(
            dimension_id=d.id,
            name=d.name,
            tier=d.tier,
            description=d.description or "",
            metric_keys=[],
            scorer_type=d.scorer_type.value if d.scorer_type else None,
            phase=d.phase.value if d.phase else None,
            domain=d.domain,
        )
        for d in dims
    ]


@router.get("/dimensions/{dimension_id}", response_model=DimensionInfo)
async def get_dimension(dimension_id: str) -> DimensionInfo:
    """Get details for a single evaluation dimension."""
    import aegis.eval.dimensions.tier1_memory  # noqa: F401
    import aegis.eval.dimensions.tier2_context  # noqa: F401
    import aegis.eval.dimensions.tier3_learning  # noqa: F401
    import aegis.eval.dimensions.tier4_reasoning  # noqa: F401
    import aegis.eval.dimensions.tier5_metacognition  # noqa: F401
    import aegis.eval.dimensions.tier6_collaborative  # noqa: F401
    import aegis.eval.dimensions.tier7_security  # noqa: F401
    from aegis.eval.dimensions.registry import DimensionRegistry

    registry = DimensionRegistry.instance()
    try:
        d = registry.get(dimension_id)
    except KeyError:
        raise HTTPException(
            status_code=404,
            detail=f"Dimension '{dimension_id}' not found",
        ) from None
    return DimensionInfo(
        dimension_id=d.id,
        name=d.name,
        tier=d.tier,
        description=d.description or "",
        metric_keys=[],
        scorer_type=d.scorer_type.value if d.scorer_type else None,
        phase=d.phase.value if d.phase else None,
        domain=d.domain,
    )


@router.get("/benchmarks", response_model=list[BenchmarkSuiteInfo])
async def list_benchmark_suites() -> list[BenchmarkSuiteInfo]:
    """List benchmark suites currently available to the API."""
    harness = BenchmarkHarness()
    suites: list[BenchmarkSuiteInfo] = []
    for name in harness.list_suites():
        try:
            cases = harness.load_suite(name)
        except (KeyError, ModuleNotFoundError):
            continue
        domains = sorted({case.domain for case in cases if case.domain})
        suites.append(BenchmarkSuiteInfo(name=name, case_count=len(cases), domains=domains))
    suites.sort(key=lambda s: s.name)
    return suites


@router.post("/benchmarks/run", response_model=BenchmarkRunResponse)
async def run_benchmark_suite(request: BenchmarkRunRequest) -> BenchmarkRunResponse:
    """Run a benchmark suite and return aggregate scoring results."""
    harness = BenchmarkHarness()
    try:
        cases = harness.load_suite(request.suite)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    selected_cases = cases
    if request.dimension_filter is not None:
        selected_cases = [c for c in selected_cases if c.dimension_id == request.dimension_filter]
    if request.difficulty_filter is not None:
        selected_cases = [c for c in selected_cases if c.difficulty == request.difficulty_filter]

    if not selected_cases:
        raise HTTPException(
            status_code=422,
            detail="No benchmark cases remain after applying filters.",
        )

    domain_plugins = _domain_plugins_for_suite(request.suite)
    evaluator = Evaluator(
        config=EvalConfig(
            dimensions="all",
            domain_plugins=domain_plugins,
            scorer_mode=request.scorer_mode,
        )
    )
    results = harness.run(evaluator=evaluator, suite=selected_cases)

    overall = float(results.get("overall_score", 0.0))
    dim_scores = {dim: float(score) for dim, score in results.get("dimension_scores", {}).items()}
    domains = sorted({case.domain for case in selected_cases if case.domain})

    response = BenchmarkRunResponse(
        suite=request.suite,
        suite_size=int(results.get("suite_size", len(selected_cases))),
        run_id=str(results.get("run_id", "")),
        overall_score=overall,
        pass_threshold=request.pass_threshold,
        passed=overall >= request.pass_threshold,
        dimension_scores=dim_scores,
        domains=domains,
        scorer_mode=request.scorer_mode,
        difficulty_filter=request.difficulty_filter,
        dimension_filter=request.dimension_filter,
    )
    _save_benchmark_run(response)
    return response


@router.get("/benchmarks/runs/{run_id}", response_model=BenchmarkRunResponse)
async def get_benchmark_run(run_id: str) -> BenchmarkRunResponse:
    """Get details for a previously executed benchmark run."""
    run = _get_benchmark_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Benchmark run '{run_id}' not found")
    return run


@router.get("/benchmarks/history", response_model=list[BenchmarkHistoryItem])
async def list_benchmark_history(
    limit: int = Query(default=50, ge=1, le=500, description="Max number of runs to return"),
    offset: int = Query(default=0, ge=0, description="Number of runs to skip"),
    suite: str | None = Query(default=None, description="Filter by suite name"),
) -> list[BenchmarkHistoryItem]:
    """List historical benchmark runs with optional filtering."""
    history: list[BenchmarkHistoryItem] = []
    seen_ids: set[str] = set()

    for run in _benchmark_runs.values():
        if suite is not None and run.suite != suite:
            continue
        history.append(
            BenchmarkHistoryItem(
                run_id=run.run_id,
                suite=run.suite,
                overall_score=round(run.overall_score, 4),
                suite_size=run.suite_size,
                passed=run.passed,
                created_at=run.created_at,
            )
        )
        seen_ids.add(run.run_id)

    try:
        rows = _get_store().list_benchmark_runs(limit=limit + offset, suite=suite)
        for row in rows:
            if row.run_id in seen_ids:
                continue
            history.append(
                BenchmarkHistoryItem(
                    run_id=row.run_id,
                    suite=row.suite,
                    overall_score=round(row.overall_score, 4),
                    suite_size=row.suite_size,
                    passed=row.passed,
                    created_at=row.created_at,
                )
            )
            seen_ids.add(row.run_id)
    except Exception:
        logger.warning("Failed to load benchmark history from store", exc_info=True)

    history.sort(key=lambda item: item.created_at, reverse=True)
    return history[offset : offset + limit]


@router.get("/runs/{run_id}/report")
async def get_eval_report(
    run_id: str,
    format: str = Query(default="json", description="Report format: json or html"),
) -> Response:
    """Return a formatted report for a completed eval run.

    Supports ``json`` and ``html`` output formats via the ``format`` query
    parameter.  Returns the appropriate content-type header.
    """
    result = _get_eval_run(run_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Eval run '{run_id}' not found")

    from aegis.eval.reporting.exporters import HTMLExporter

    report_data = result.model_dump(mode="json", exclude={"judge_packets"})

    if format.lower() == "html":
        exporter = HTMLExporter()
        html_content = exporter._render(report_data)
        return Response(content=html_content, media_type="text/html")

    # Default: JSON
    import json as _json

    json_content = _json.dumps(report_data, indent=2, default=str)
    return Response(content=json_content, media_type="application/json")


@router.post("/runs/{run_id}/cancel")
async def cancel_eval_run(run_id: str) -> dict[str, Any]:
    """Cancel a running evaluation.

    Sets the run status to ``cancelled`` in the in-memory store.  If the
    run does not exist a 404 is returned.  Cancellation is best-effort
    since the current in-process evaluator runs synchronously.
    """
    result = _get_eval_run(run_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Eval run '{run_id}' not found")

    # Mark the run as cancelled by updating diagnostic metadata
    result.diagnostic["status"] = "cancelled"
    result.diagnostic["cancelled_at"] = datetime.now(tz=UTC).isoformat()

    return {
        "run_id": run_id,
        "status": "cancelled",
        "cancelled_at": result.diagnostic["cancelled_at"],
    }


@router.get("/history", response_model=list[EvalHistoryItem])
async def list_eval_history(
    limit: int = Query(default=50, ge=1, le=500, description="Max number of runs to return"),
    offset: int = Query(default=0, ge=0, description="Number of runs to skip"),
    agent_id: str | None = Query(default=None, description="Filter by agent ID"),
) -> list[EvalHistoryItem]:
    """List historical eval runs with optional filtering.

    Supports pagination via ``limit`` and ``offset``, and filtering by
    ``agent_id``.  Results are ordered by creation time (newest first).
    """
    # Merge in-memory runs with persisted runs from SQLite
    seen_ids: set[str] = set()
    runs: list[EvalResult] = []

    for r in _eval_runs.values():
        if agent_id is not None and r.agent_id != agent_id:
            continue
        runs.append(r)
        seen_ids.add(r.run_id)

    try:
        store = _get_store()
        stored_rows = store.list_eval_runs(limit=limit + offset, agent_id=agent_id)
        for row in stored_rows:
            if row.run_id not in seen_ids:
                stored_result = store.get_eval_run(row.run_id)
                if stored_result is not None:
                    runs.append(stored_result)
                    seen_ids.add(row.run_id)
    except Exception:
        logger.warning("Failed to load eval history from store", exc_info=True)

    # Sort by creation time descending (newest first)
    runs.sort(key=lambda r: r.created_at, reverse=True)

    # Apply pagination
    paginated = runs[offset : offset + limit]

    return [
        EvalHistoryItem(
            run_id=r.run_id,
            agent_id=r.agent_id,
            status=r.diagnostic.get("status", "completed"),
            overall_score=round(r.overall_score, 4),
            num_dimensions=len(r.dimension_scores),
            created_at=r.created_at,
        )
        for r in paginated
    ]


@router.post("/diagnostic", response_model=DiagnosticResponse)
async def generate_diagnostic_report(request: DiagnosticRequest) -> DiagnosticResponse:
    """Generate a diagnostic report from an existing eval run.

    The diagnostic includes per-tier score breakdowns, weak/strong dimension
    lists, and actionable improvement recommendations.
    """
    result = _get_eval_run(request.run_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Eval run '{request.run_id}' not found")

    from aegis.eval.reporting.diagnostic import generate_diagnostic

    diag = generate_diagnostic(
        run_id=request.run_id,
        dimension_scores=result.dimension_scores,
    )

    return DiagnosticResponse(
        run_id=diag.get("run_id", request.run_id),
        overall_score=diag.get("overall_score", 0.0),
        tier_scores=diag.get("tier_scores", {}),
        weak_dimensions=diag.get("weak_dimensions", []),
        strong_dimensions=diag.get("strong_dimensions", []),
        recommendations=diag.get("recommendations", []),
        metadata=diag.get("metadata", {}),
    )
