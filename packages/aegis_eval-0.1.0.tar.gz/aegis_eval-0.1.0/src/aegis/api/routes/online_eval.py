"""Online evaluation API routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from aegis.eval.online import OnlineEvalPipeline

router = APIRouter(prefix="/online-eval", tags=["online-eval"])

_pipeline = OnlineEvalPipeline()


class ScoreInteractionRequest(BaseModel):
    agent_id: str
    interaction: dict[str, Any]


class SetBaselineRequest(BaseModel):
    dimension_scores: dict[str, float]


@router.post("/score", status_code=201)
async def score_interaction(req: ScoreInteractionRequest) -> dict[str, Any]:
    """Score a production interaction in real-time."""
    records = _pipeline.score_interaction(req.agent_id, req.interaction)
    return {
        "scores": [{"dimension": r.dimension_id, "score": r.score} for r in records],
        "alerts": len(_pipeline.alert_manager.active_alerts()),
    }


@router.post("/baselines")
async def set_baselines(req: SetBaselineRequest) -> dict[str, Any]:
    """Set baseline scores from an offline eval run."""
    _pipeline.set_baselines(req.dimension_scores)
    return {"status": "baselines_set", "dimensions": len(req.dimension_scores)}


@router.get("/summary")
async def pipeline_summary() -> dict[str, Any]:
    """Get online eval pipeline summary."""
    return _pipeline.summary()


@router.get("/alerts")
async def get_alerts(active_only: bool = True) -> list[dict[str, Any]]:
    """Get alerts from the online eval pipeline."""
    if active_only:
        alerts = _pipeline.alert_manager.active_alerts()
    else:
        alerts = _pipeline.alert_manager.all_alerts()
    return [
        {
            "id": a.id,
            "type": a.alert_type,
            "dimension": a.dimension_id,
            "severity": a.severity,
            "message": a.message,
            "acknowledged": a.acknowledged,
        }
        for a in alerts
    ]


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str) -> dict[str, Any]:
    """Acknowledge an alert."""
    ok = _pipeline.alert_manager.acknowledge(alert_id)
    return {"alert_id": alert_id, "acknowledged": ok}


@router.get("/drift")
async def check_drift() -> list[dict[str, Any]]:
    """Check drift across all monitored signals."""
    results = _pipeline.drift_detector.check_all()
    return [
        {
            "dimension": r.dimension_id,
            "drifted": r.drifted,
            "z_score": r.z_score,
            "baseline_mean": r.baseline_mean,
            "current_mean": r.current_mean,
        }
        for r in results
    ]


@router.get("/scores")
async def recent_scores(limit: int = 50) -> list[dict[str, Any]]:
    """Get recent score records."""
    return _pipeline.recent_scores(limit=limit)
