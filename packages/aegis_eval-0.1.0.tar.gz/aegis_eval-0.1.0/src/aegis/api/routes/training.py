"""Aegis training routes.

Endpoints for launching and monitoring RL/LoRA training jobs.
"""

from __future__ import annotations

import base64
import hashlib
import uuid
from contextlib import suppress
from datetime import UTC, datetime
from typing import Any, Protocol, cast

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from aegis.observatory.monitor import ObservatoryMonitor
from aegis.training.engine import AMIRGRPOTrainer, GRPOSGTrainer, RLTrainer
from aegis.training.transfer import TransferConfig, TransferProtocol

router = APIRouter(prefix="/train", tags=["training"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class LoRAConfig(BaseModel):
    """Low-Rank Adaptation hyper-parameters."""

    rank: int = Field(default=16, ge=1, le=256)
    alpha: float = 32.0
    dropout: float = Field(default=0.05, ge=0.0, le=1.0)
    target_modules: list[str] = Field(
        default_factory=lambda: ["q_proj", "v_proj"],
    )


class CurriculumStage(BaseModel):
    """A single stage in the curriculum schedule."""

    stage: int
    name: str
    difficulty: int = Field(ge=1, le=5)
    num_episodes: int = Field(ge=1)


class CreateTrainingJobRequest(BaseModel):
    """Payload to start a new training job."""

    customer_id: str
    domain: str
    optimizer: str = Field(default="grpo", description="RL optimizer: grpo | ppo | dpo")
    lora_config: LoRAConfig = Field(default_factory=LoRAConfig)
    curriculum: list[CurriculumStage] = Field(default_factory=list)


class TrainingMetrics(BaseModel):
    """Summary training metrics for a completed or in-progress job."""

    current_stage: int = 0
    total_stages: int = 0
    episodes_completed: int = 0
    mean_reward: float = 0.0
    best_reward: float = 0.0
    loss: float | None = None


class TrainingJobResponse(BaseModel):
    """Detailed status of a training job."""

    job_id: str
    customer_id: str
    domain: str
    status: str
    optimizer: str
    lora_config: LoRAConfig
    curriculum: list[CurriculumStage] = Field(default_factory=list)
    metrics: TrainingMetrics = Field(default_factory=TrainingMetrics)
    created_at: datetime
    updated_at: datetime


class AdapterArtifactResponse(BaseModel):
    """Metadata for a produced adapter artifact."""

    adapter_id: str
    job_id: str
    customer_id: str
    domain: str
    optimizer: str
    created_at: datetime
    size_mb: float
    lora_rank: int
    status: str


class AdapterDownloadResponse(BaseModel):
    """Download payload metadata + content for an adapter artifact."""

    adapter_id: str
    file_name: str
    content_type: str
    size_bytes: int
    sha256: str
    payload_base64: str


class StopTrainingJobRequest(BaseModel):
    """Optional payload for stopping a training job."""

    reason: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _total_curriculum_episodes(curriculum: list[CurriculumStage]) -> int:
    if not curriculum:
        return 100
    return sum(stage.num_episodes for stage in curriculum)


def _optimizer_variant_from_request(optimizer: str) -> str:
    key = optimizer.lower()
    if key in ("dapo", "dpo"):
        return "dapo"
    if key in ("gigpo", "gi-gpo"):
        return "gigpo"
    if key in ("forge", "ppo"):
        return "forge"
    return "drgrpo"


def _deterministic_unit_interval(seed: str) -> float:
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return int(digest[:8], 16) / 0xFFFFFFFF


def _transfer_estimate(
    customer_id: str,
    source_domain: str,
    target_domain: str,
) -> tuple[float, float]:
    base_seed = f"{customer_id}:{source_domain}:{target_domain}"
    transfer_score = 0.45 + (_deterministic_unit_interval(f"{base_seed}:transfer") * 0.5)
    interference = 0.01 + (_deterministic_unit_interval(f"{base_seed}:interference") * 0.14)
    return round(transfer_score, 6), round(interference, 6)


def _shared_skills(source_domain: str, target_domain: str) -> list[str]:
    skill_map: dict[str, set[str]] = {
        "legal": {"reasoning", "compliance", "citation_integrity", "risk_assessment"},
        "finance": {"reasoning", "compliance", "numerical_fidelity", "risk_assessment"},
        "safety": {"policy_enforcement", "adversarial_detection", "risk_assessment"},
        "memory": {"state_tracking", "reasoning", "consistency"},
    }
    source_skills = skill_map.get(source_domain, {"reasoning"})
    target_skills = skill_map.get(target_domain, {"reasoning"})
    return sorted(source_skills & target_skills)


def _latest_transfer_source_job(
    current_job_id: str,
    customer_id: str,
    target_domain: str,
) -> tuple[str, dict[str, Any]] | None:
    candidates: list[tuple[str, dict[str, Any]]] = []
    for candidate_job_id, candidate_job in _jobs.items():
        if candidate_job_id == current_job_id:
            continue
        if candidate_job.get("customer_id") != customer_id:
            continue
        if candidate_job.get("domain") == target_domain:
            continue
        if candidate_job.get("status") != "completed":
            continue
        if candidate_job.get("training_result") is None:
            continue
        candidates.append((candidate_job_id, candidate_job))

    if not candidates:
        return None

    candidates.sort(
        key=lambda item: (
            item[1].get("updated_at", datetime.fromtimestamp(0, tz=UTC)),
            item[0],
        ),
        reverse=True,
    )
    return candidates[0]


def _build_metrics(job: dict[str, Any]) -> TrainingMetrics:
    if job.get("metrics") is None:
        return TrainingMetrics()
    stored = job["metrics"]
    return TrainingMetrics(
        current_stage=stored.get("current_stage", 0),
        total_stages=stored.get("total_stages", 0),
        episodes_completed=stored.get("episodes_completed", 0),
        mean_reward=stored.get("mean_reward", 0.0),
        best_reward=stored.get("best_reward", 0.0),
        loss=stored.get("loss"),
    )


def _build_job_response(job_id: str, job: dict[str, Any]) -> TrainingJobResponse:
    return TrainingJobResponse(
        job_id=job_id,
        customer_id=job["customer_id"],
        domain=job["domain"],
        status=job["status"],
        optimizer=job["optimizer"],
        lora_config=job["lora_config"],
        curriculum=job["curriculum"],
        metrics=_build_metrics(job),
        created_at=job["created_at"],
        updated_at=job["updated_at"],
    )


def _build_adapter_response(job_id: str, job: dict[str, Any]) -> AdapterArtifactResponse:
    artifact = job["adapter_artifact"]
    return AdapterArtifactResponse(
        adapter_id=artifact["adapter_id"],
        job_id=job_id,
        customer_id=job["customer_id"],
        domain=job["domain"],
        optimizer=job["optimizer"],
        created_at=artifact["created_at"],
        size_mb=artifact["size_mb"],
        lora_rank=artifact["lora_rank"],
        status=job["status"],
    )


def _build_metrics_series(job_id: str, job: dict[str, Any]) -> dict[str, Any]:
    result = job.get("training_result")
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Training metrics series for job '{job_id}' is not available",
        )

    stage_metrics = result.get("stage_metrics")
    if not isinstance(stage_metrics, list):
        stage_metrics = []

    series: list[dict[str, Any]] = []
    for idx, stage in enumerate(stage_metrics):
        if not isinstance(stage, dict):
            continue
        stage_id = stage.get("stage")
        if stage_id is None:
            stage_id = stage.get("gate_stage", idx)

        series.append(
            {
                "stage_index": int(stage_id),
                "reward": float(stage.get("reward", 0.0)),
                "loss": float(stage.get("loss", 0.0)),
                "kl_divergence": float(stage.get("kl_divergence", 0.0)),
                "entropy": float(stage.get("entropy", 0.0)),
            }
        )

    return {"job_id": job_id, "status": job["status"], "series": series}


def _build_observatory_report(job_id: str, job: dict[str, Any]) -> dict[str, Any]:
    result = job.get("training_result")
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Training observatory report for job '{job_id}' is not available",
        )

    stage_metrics = result.get("stage_metrics")
    if not isinstance(stage_metrics, list):
        stage_metrics = []

    reward_traces: list[dict[str, float]] = []
    gradient_norms: list[float] = []
    reward_values: list[float] = []
    for stage in stage_metrics:
        if not isinstance(stage, dict):
            continue
        reward = float(stage.get("reward", 0.0))
        loss = max(0.0, float(stage.get("loss", 0.0)))
        quality = max(0.0, min(1.0, reward / (1.0 + loss)))
        reward_traces.append({"reward": reward, "quality": quality})
        reward_values.append(reward)
        gradient_norms.append(abs(float(stage.get("policy_loss", 0.0))))

    replay_stats = result.get("replay_buffer_stats", {})
    total_entries = int(replay_stats.get("total", 0))
    capacity = int(replay_stats.get("capacity", 10_000))
    memory_stats = {
        "total_entries": total_entries,
        "capacity": capacity,
        "stale_count": 0,
        "tier_counts": {"working": total_entries},
    }

    def _distribution(values: list[float]) -> dict[str, Any]:
        if not values:
            return {"mean": 0.0, "variance": 0.0, "values": []}
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        return {"mean": mean, "variance": variance, "values": values}

    if len(reward_values) >= 2:
        midpoint = len(reward_values) // 2
        reference_values = reward_values[:midpoint]
        current_values = reward_values[midpoint:]
    else:
        reference_values = reward_values
        current_values = reward_values

    monitor = ObservatoryMonitor()
    reward_check = monitor.check_reward_hacking(reward_traces=reward_traces)
    gradient_check = monitor.check_gradient_health(gradient_stats={"norms": gradient_norms})
    memory_check = monitor.check_memory_health(memory_stats=memory_stats)
    drift_check = monitor.check_drift(
        reference_distribution=_distribution(reference_values),
        current_distribution=_distribution(current_values),
    )

    checks = [reward_check, gradient_check, memory_check, drift_check]
    check_payload: dict[str, Any] = {}
    for check in checks:
        check_payload[check.check_name] = {
            "healthy": check.healthy,
            "score": check.score,
            "details": check.details,
            "recommendations": check.recommendations,
        }

    scores = [c.score for c in checks if c.score is not None]
    composite_score = (sum(scores) / len(scores)) if scores else 1.0
    overall_healthy = all(c.healthy for c in checks)

    return {
        "job_id": job_id,
        "status": job["status"],
        "overall_healthy": overall_healthy,
        "composite_score": round(composite_score, 4),
        "checks": check_payload,
    }


def _execute_training_job(job_id: str, job: dict[str, Any]) -> None:
    trainer = job["trainer"]
    if not isinstance(trainer, RLTrainer):
        raise HTTPException(status_code=500, detail=f"Training job '{job_id}' has invalid trainer")

    curriculum: list[CurriculumStage] = job.get("curriculum", [])
    total_episodes = _total_curriculum_episodes(curriculum)
    optimizer_name = str(job.get("optimizer", "grpo"))

    train_config: dict[str, Any] = {
        "domain": job["domain"],
        "num_episodes": total_episodes,
        "max_steps": max(1000, total_episodes * 10),
        "replay_mix_ratio": float(job.get("replay_mix_ratio", 0.2)),
    }
    if isinstance(trainer, AMIRGRPOTrainer):
        reward_stages = len(curriculum) if curriculum else trainer.num_stages
        train_config["reward_stages"] = reward_stages
        train_config["optimizer_variant"] = _optimizer_variant_from_request(optimizer_name)

    transfer_source_match = _latest_transfer_source_job(
        current_job_id=job_id,
        customer_id=str(job["customer_id"]),
        target_domain=str(job["domain"]),
    )
    transfer_plan: dict[str, Any]
    transfer_safeguards_applied = False

    if transfer_source_match is None:
        transfer_plan = {
            "source_domain": None,
            "target_domain": str(job["domain"]),
            "maintenance_ratio": train_config["replay_mix_ratio"],
            "adjusted_maintenance_ratio": train_config["replay_mix_ratio"],
            "reason": (
                "No prior completed cross-domain job for this customer. "
                "Transfer safeguards not applied."
            ),
            "recommendation": "shared_adapter",
        }
    else:
        source_job_id, source_job = transfer_source_match
        source_domain = str(source_job["domain"])
        target_domain = str(job["domain"])
        transfer_score, interference_score = _transfer_estimate(
            customer_id=str(job["customer_id"]),
            source_domain=source_domain,
            target_domain=target_domain,
        )

        protocol = TransferProtocol(
            config=TransferConfig(
                maintenance_ratio=float(train_config["replay_mix_ratio"]),
                interference_threshold=0.05,
                monitor_interval=100,
                separate_adapter_threshold=0.1,
            )
        )
        protocol.graph.add_edge(
            source=source_domain,
            target=target_domain,
            transfer_score=transfer_score,
            interference_score=interference_score,
            shared_skills=_shared_skills(source_domain, target_domain),
        )

        transfer_plan = protocol.prepare_transfer(
            source_domain=source_domain,
            target_domain=target_domain,
        )
        adjusted_ratio = float(
            transfer_plan.get(
                "adjusted_maintenance_ratio",
                transfer_plan.get("maintenance_ratio", train_config["replay_mix_ratio"]),
            )
        )
        adjusted_ratio = max(0.0, min(adjusted_ratio, 0.6))
        train_config["replay_mix_ratio"] = adjusted_ratio

        transfer_plan["source_job_id"] = source_job_id
        transfer_plan["target_job_id"] = job_id
        transfer_plan["deterministic_transfer_score"] = transfer_score
        transfer_plan["deterministic_interference_estimate"] = interference_score
        transfer_plan["shared_skills"] = _shared_skills(source_domain, target_domain)
        transfer_safeguards_applied = True

    result = trainer.train(train_config)
    result["transfer_plan"] = transfer_plan
    result["transfer_safeguards_applied"] = transfer_safeguards_applied
    result["replay_mix_ratio_effective"] = float(train_config["replay_mix_ratio"])

    stage_count = 0
    if isinstance(result.get("stage_metrics"), list):
        stage_count = len(result["stage_metrics"])

    job["metrics"] = {
        "current_stage": stage_count,
        "total_stages": stage_count,
        "episodes_completed": total_episodes,
        "mean_reward": float(result.get("mean_reward", 0.0)),
        "best_reward": float(result.get("best_reward", 0.0)),
        "loss": result.get("final_loss"),
    }
    job["training_result"] = result
    lora_cfg: LoRAConfig = job["lora_config"]
    job["adapter_artifact"] = {
        "adapter_id": f"{job['domain']}-lora-{job_id[:8]}",
        "created_at": datetime.now(tz=UTC),
        # Lightweight deterministic estimate based on LoRA rank.
        "size_mb": round(8.0 + (lora_cfg.rank * 0.85), 2),
        "lora_rank": lora_cfg.rank,
    }
    job["status"] = "completed"
    job["updated_at"] = datetime.now(tz=UTC)
    _persist_job(job_id, job)


def _find_adapter_job(adapter_id: str) -> tuple[str, dict[str, Any]] | None:
    for job_id, job in _jobs.items():
        artifact = job.get("adapter_artifact")
        if artifact is None:
            continue
        if artifact["adapter_id"] == adapter_id:
            return job_id, job
    return None


def _adapter_payload_bytes(job_id: str, job: dict[str, Any]) -> bytes:
    artifact = job["adapter_artifact"]
    payload = (
        f"adapter_id={artifact['adapter_id']}\n"
        f"job_id={job_id}\n"
        f"customer_id={job['customer_id']}\n"
        f"domain={job['domain']}\n"
        f"optimizer={job['optimizer']}\n"
        f"rank={artifact['lora_rank']}\n"
        f"created_at={artifact['created_at'].isoformat()}\n"
    )
    return payload.encode("utf-8")


# ---------------------------------------------------------------------------
# In-memory job store for development + SQLite persistence
# ---------------------------------------------------------------------------

_jobs: dict[str, dict[str, Any]] = {}


class _TrainingJobRow(Protocol):
    job_id: str


class _TrainingStore(Protocol):
    def save_training_job(self, job_id: str, job_data: dict[str, Any]) -> None: ...
    def get_training_job(self, job_id: str) -> dict[str, Any] | None: ...
    def list_training_jobs(
        self,
        limit: int = 20,
        offset: int = 0,
        customer_id: str | None = None,
    ) -> list[_TrainingJobRow]: ...


_store_instance: _TrainingStore | None = None


def _get_store() -> _TrainingStore:
    """Lazy singleton for the SQLite store."""
    global _store_instance
    if _store_instance is None:
        from aegis.store.sqlite import SQLiteStore

        _store_instance = cast("_TrainingStore", SQLiteStore())
    return _store_instance


def _serialize_job(job: dict[str, Any]) -> dict[str, Any]:
    """Strip non-serialisable keys (e.g. trainer instances) for persistence."""
    return {k: v for k, v in job.items() if k != "trainer"}


def _get_job(job_id: str) -> dict[str, Any] | None:
    """Look up a job: in-memory first, then SQLite fallback."""
    job = _jobs.get(job_id)
    if job is not None:
        return job
    try:
        stored = _get_store().get_training_job(job_id)
        if stored is not None:
            _jobs[job_id] = stored
        return stored
    except Exception:
        return None


def _persist_job(job_id: str, job: dict[str, Any]) -> None:
    """Best-effort persist a job to SQLite."""
    with suppress(Exception):
        _get_store().save_training_job(job_id, _serialize_job(job))


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


@router.post("/jobs", response_model=dict[str, str], status_code=201)
async def create_training_job(request: CreateTrainingJobRequest) -> dict[str, str]:
    """Start a new training job."""
    job_id = str(uuid.uuid4())
    now = datetime.now(tz=UTC)

    # Instantiate the appropriate trainer based on optimizer choice
    optimizer_key = request.optimizer.lower()
    trainer: RLTrainer
    if optimizer_key in ("grpo", "amir-grpo", "amir_grpo"):
        trainer = AMIRGRPOTrainer(
            model_name=f"{request.domain}-agent-v1",
            learning_rate=1e-5,
        )
    elif optimizer_key in ("grpo-sg", "grpo_sg", "ppo", "dpo"):
        trainer = GRPOSGTrainer(
            model_name=f"{request.domain}-memory-policy-v1",
            learning_rate=5e-6,
        )
    else:
        trainer = AMIRGRPOTrainer(
            model_name=f"{request.domain}-agent-v1",
            learning_rate=1e-5,
        )

    job_data = {
        "customer_id": request.customer_id,
        "domain": request.domain,
        "optimizer": request.optimizer,
        "lora_config": request.lora_config,
        "curriculum": request.curriculum,
        "trainer": trainer,
        "status": "created",
        "metrics": None,
        "created_at": now,
        "updated_at": now,
    }
    _jobs[job_id] = job_data
    _persist_job(job_id, job_data)
    return {"job_id": job_id, "status": "created"}


@router.post("/run", response_model=dict[str, str], status_code=201)
async def create_training_run(request: CreateTrainingJobRequest) -> dict[str, str]:
    """Compatibility alias for creating a training run."""
    created = await create_training_job(request)
    return {"run_id": created["job_id"], "status": created["status"]}


@router.get("/jobs", response_model=list[TrainingJobResponse])
async def list_training_jobs() -> list[TrainingJobResponse]:
    """List all training jobs in reverse chronological order."""
    # Merge in-memory jobs with persisted jobs from SQLite
    seen_ids: set[str] = set()
    merged: list[tuple[str, dict[str, Any]]] = []
    for job_id, job in _jobs.items():
        merged.append((job_id, job))
        seen_ids.add(job_id)
    try:
        stored_rows = _get_store().list_training_jobs(limit=100)
        for row in stored_rows:
            if row.job_id not in seen_ids:
                stored_job = _get_store().get_training_job(row.job_id)
                if stored_job is not None:
                    merged.append((row.job_id, stored_job))
                    seen_ids.add(row.job_id)
    except Exception:
        pass

    merged.sort(key=lambda item: item[1]["created_at"], reverse=True)
    return [_build_job_response(job_id, job) for job_id, job in merged]


@router.post("/jobs/{job_id}/enqueue", response_model=dict[str, str])
async def enqueue_training_job(job_id: str) -> dict[str, str]:
    """Queue a training job for deferred execution."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")

    current_status = str(job["status"])
    if current_status == "completed":
        return {"job_id": job_id, "status": "completed"}
    if current_status in ("running", "queued"):
        return {"job_id": job_id, "status": current_status}
    if current_status in ("cancelled", "stopping", "stopped"):
        raise HTTPException(
            status_code=409,
            detail=f"Training job '{job_id}' is not queueable from status '{current_status}'",
        )

    job["status"] = "queued"
    job["updated_at"] = datetime.now(tz=UTC)
    return {"job_id": job_id, "status": "queued"}


@router.post("/run/{run_id}/enqueue", response_model=dict[str, str])
async def enqueue_training_run(run_id: str) -> dict[str, str]:
    """Compatibility alias for queueing a training run."""
    queued = await enqueue_training_job(run_id)
    return {"run_id": queued["job_id"], "status": queued["status"]}


@router.post("/jobs/{job_id}/run", response_model=TrainingJobResponse)
async def run_training_job(job_id: str) -> TrainingJobResponse:
    """Execute a created training job and persist resulting metrics."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")

    if job["status"] == "completed":
        return await get_training_job(job_id)
    if job["status"] == "running":
        raise HTTPException(status_code=409, detail=f"Training job '{job_id}' is already running")
    if job["status"] in ("cancelled", "stopping", "stopped"):
        raise HTTPException(
            status_code=409,
            detail=f"Training job '{job_id}' is not runnable from status '{job['status']}'",
        )

    now = datetime.now(tz=UTC)
    job["status"] = "running"
    job["updated_at"] = now
    _execute_training_job(job_id, job)

    return await get_training_job(job_id)


@router.post("/run/{run_id}/start", response_model=TrainingJobResponse)
async def run_training_run(run_id: str) -> TrainingJobResponse:
    """Compatibility alias for executing a training run."""
    return await run_training_job(run_id)


@router.post("/jobs/{job_id}/tick", response_model=TrainingJobResponse)
async def tick_training_job(job_id: str) -> TrainingJobResponse:
    """Advance a queued job by one scheduler tick (executes queued jobs)."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")

    status = str(job["status"])
    if status == "completed":
        return await get_training_job(job_id)
    if status != "queued":
        raise HTTPException(
            status_code=409,
            detail=f"Training job '{job_id}' is not queued (current status: '{status}')",
        )

    job["status"] = "running"
    job["updated_at"] = datetime.now(tz=UTC)
    _execute_training_job(job_id, job)
    return await get_training_job(job_id)


@router.post("/run/{run_id}/tick", response_model=TrainingJobResponse)
async def tick_training_run(run_id: str) -> TrainingJobResponse:
    """Compatibility alias for advancing a queued run."""
    return await tick_training_job(run_id)


@router.post("/jobs/{job_id}/stop", response_model=dict[str, str])
async def stop_training_job(
    job_id: str,
    request: StopTrainingJobRequest | None = None,
) -> dict[str, str]:
    """Stop or cancel a training job."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")

    current_status = str(job["status"])
    if current_status in ("completed", "cancelled", "stopped"):
        return {"job_id": job_id, "status": current_status}

    next_status = "stopping" if current_status == "running" else "cancelled"

    job["status"] = next_status
    job["updated_at"] = datetime.now(tz=UTC)
    if request is not None and request.reason:
        job["stop_reason"] = request.reason
    _persist_job(job_id, job)
    return {"job_id": job_id, "status": next_status}


@router.post("/run/{run_id}/stop", response_model=dict[str, str])
async def stop_training_run(
    run_id: str,
    request: StopTrainingJobRequest | None = None,
) -> dict[str, str]:
    """Compatibility alias for stopping a training run."""
    stopped = await stop_training_job(run_id, request)
    return {"run_id": stopped["job_id"], "status": stopped["status"]}


@router.get("/jobs/{job_id}/result", response_model=dict[str, Any])
async def get_training_job_result(job_id: str) -> dict[str, Any]:
    """Return the raw training result payload for a completed job."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")

    result = job.get("training_result")
    if result is None:
        raise HTTPException(
            status_code=404,
            detail=f"Training result for job '{job_id}' is not available",
        )

    return {"job_id": job_id, "status": job["status"], "result": result}


@router.get("/run/{run_id}/result", response_model=dict[str, Any])
async def get_training_run_result(run_id: str) -> dict[str, Any]:
    """Compatibility alias for retrieving training run results."""
    result = await get_training_job_result(run_id)
    return {"run_id": result["job_id"], "status": result["status"], "result": result["result"]}


@router.get("/jobs/{job_id}/metrics", response_model=TrainingMetrics)
async def get_training_job_metrics(job_id: str) -> TrainingMetrics:
    """Return training metrics for a job."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")
    return _build_metrics(job)


@router.get("/jobs/{job_id}/metrics/series", response_model=dict[str, Any])
async def get_training_job_metrics_series(job_id: str) -> dict[str, Any]:
    """Return per-stage training metrics series for a completed job."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")
    return _build_metrics_series(job_id, job)


@router.get("/run/{run_id}/metrics", response_model=TrainingMetrics)
async def get_training_run_metrics(run_id: str) -> TrainingMetrics:
    """Compatibility alias for retrieving training run metrics."""
    return await get_training_job_metrics(run_id)


@router.get("/run/{run_id}/metrics/series", response_model=dict[str, Any])
async def get_training_run_metrics_series(run_id: str) -> dict[str, Any]:
    """Compatibility alias for retrieving per-stage run metrics series."""
    return await get_training_job_metrics_series(run_id)


@router.get("/jobs/{job_id}/observatory", response_model=dict[str, Any])
async def get_training_job_observatory(job_id: str) -> dict[str, Any]:
    """Return observatory health checks derived from training outputs."""
    job = _jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")
    return _build_observatory_report(job_id, job)


@router.get("/run/{run_id}/observatory", response_model=dict[str, Any])
async def get_training_run_observatory(run_id: str) -> dict[str, Any]:
    """Compatibility alias for retrieving run observatory checks."""
    return await get_training_job_observatory(run_id)


@router.get("/adapters", response_model=list[AdapterArtifactResponse])
async def list_adapters() -> list[AdapterArtifactResponse]:
    """List adapter artifacts produced by completed training jobs."""
    adapters: list[AdapterArtifactResponse] = []
    for job_id, job in _jobs.items():
        if "adapter_artifact" in job:
            adapters.append(_build_adapter_response(job_id, job))

    adapters.sort(key=lambda item: item.created_at, reverse=True)
    return adapters


@router.get("/adapters/{adapter_id}", response_model=AdapterArtifactResponse)
async def get_adapter(adapter_id: str) -> AdapterArtifactResponse:
    """Get metadata for a single adapter artifact."""
    match = _find_adapter_job(adapter_id)
    if match is not None:
        job_id, job = match
        return _build_adapter_response(job_id, job)

    raise HTTPException(status_code=404, detail=f"Adapter '{adapter_id}' not found")


@router.get("/adapters/{adapter_id}/download", response_model=AdapterDownloadResponse)
async def download_adapter(adapter_id: str) -> AdapterDownloadResponse:
    """Return deterministic adapter bytes and checksum for download workflows."""
    match = _find_adapter_job(adapter_id)
    if match is None:
        raise HTTPException(status_code=404, detail=f"Adapter '{adapter_id}' not found")

    job_id, job = match
    payload_bytes = _adapter_payload_bytes(job_id, job)
    digest = hashlib.sha256(payload_bytes).hexdigest()
    payload_base64 = base64.b64encode(payload_bytes).decode("ascii")

    return AdapterDownloadResponse(
        adapter_id=adapter_id,
        file_name=f"{adapter_id}.adapter.bin",
        content_type="application/octet-stream",
        size_bytes=len(payload_bytes),
        sha256=digest,
        payload_base64=payload_base64,
    )


@router.get("/jobs/{job_id}", response_model=TrainingJobResponse)
async def get_training_job(job_id: str) -> TrainingJobResponse:
    """Retrieve the current status and metrics of a training job."""
    job = _get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Training job '{job_id}' not found")
    return _build_job_response(job_id, job)


@router.get("/run/{run_id}", response_model=TrainingJobResponse)
async def get_training_run(run_id: str) -> TrainingJobResponse:
    """Compatibility alias for retrieving a training run."""
    return await get_training_job(run_id)
