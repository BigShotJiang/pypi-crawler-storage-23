"""Aegis ingestion routes.

Endpoints for document ingestion, listing ingestion results,
and retrieving parsed chunks.
"""

from __future__ import annotations

import logging
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field

from aegis.core.settings import get_settings
from aegis.ingestion.parsers import ParsedChunk
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline, IngestionResult
from aegis.ingestion.sinks import Sink

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ingestion", tags=["ingestion"])

# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------

_pipeline: IngestionPipeline | None = None
_sinks: list[Sink] | None = None


def get_pipeline() -> IngestionPipeline:
    """Return the module-level IngestionPipeline singleton."""
    global _pipeline
    if _pipeline is None:
        _pipeline = IngestionPipeline(IngestionConfig())
    return _pipeline


def get_sinks() -> list[Sink]:
    """Return configured storage sinks from centralized settings.

    Creates sinks lazily from ``AegisSettings`` for pgvector and Neo4j.
    Falls back to an empty
    list if no backends are configured.
    """
    global _sinks
    if _sinks is not None:
        return _sinks

    _sinks = []

    settings = get_settings()

    if settings.postgres_configured:
        try:
            from aegis.ingestion.sinks import PgVectorSink

            _sinks.append(PgVectorSink(dsn=settings.postgres_dsn, enable_embeddings=False))
            logger.info(
                "Ingestion sink: PgVectorSink (%s)",
                settings.postgres_dsn.split("@")[-1],
            )
        except Exception as exc:
            logger.warning("Failed to create PgVectorSink: %s", exc)

    if settings.neo4j_configured:
        try:
            from aegis.ingestion.sinks import Neo4jSink

            _sinks.append(
                Neo4jSink(
                    uri=settings.neo4j_uri,
                    user=settings.neo4j_user,
                    password=settings.neo4j_password,
                )
            )
            logger.info("Ingestion sink: Neo4jSink (%s)", settings.neo4j_uri)
        except Exception as exc:
            logger.warning("Failed to create Neo4jSink: %s", exc)

    return _sinks


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class ChunkResponse(BaseModel):
    """A single parsed chunk."""

    content: str
    modality: str
    source_path: str
    chunk_index: int
    metadata: dict[str, Any] = Field(default_factory=dict)
    confidence: float = 1.0


class IngestionResponse(BaseModel):
    """Response for an ingestion operation."""

    document_id: str
    source_path: str
    num_chunks: int
    modality: str
    chunks: list[ChunkResponse] = Field(default_factory=list)
    storage_counts: dict[str, int] = Field(default_factory=dict)


class IngestionHistoryItem(BaseModel):
    """Summary of a past ingestion."""

    document_id: str
    source_path: str
    num_chunks: int
    modality: str


# ---------------------------------------------------------------------------
# Internal conversion helpers
# ---------------------------------------------------------------------------


def _to_chunk_response(chunk: ParsedChunk) -> ChunkResponse:
    return ChunkResponse(
        content=chunk.content,
        modality=chunk.modality.value,
        source_path=chunk.source_path,
        chunk_index=chunk.chunk_index,
        metadata=chunk.metadata,
        confidence=chunk.confidence,
    )


def _to_ingestion_response(
    result: IngestionResult,
    storage_counts: dict[str, int] | None = None,
) -> IngestionResponse:
    return IngestionResponse(
        document_id=result.document_id,
        source_path=result.source_path,
        num_chunks=result.num_chunks,
        modality=result.modality.value,
        chunks=[_to_chunk_response(c) for c in result.chunks],
        storage_counts=storage_counts or {},
    )


def _find_ingestion_result(document_id: str) -> IngestionResult | None:
    for item in get_pipeline().history():
        if item.document_id == document_id:
            return item
    return None


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/upload", response_model=IngestionResponse, status_code=201)
async def upload_document(
    file: UploadFile,
    store: bool = Query(False, description="Persist chunks to configured storage sinks"),
) -> IngestionResponse:
    """Upload and ingest a document.

    Accepts any supported file format (PDF, DOCX, CSV, JSON, TXT, HTML, etc.).
    Parses the document into chunks and returns the results.

    When *store* is ``True``, the parsed chunks are also written to any
    configured storage backends (pgvector, Neo4j).
    """
    pipeline = get_pipeline()
    content = await file.read()
    filename = file.filename or f"upload-{uuid.uuid4()}"

    result = pipeline.ingest(filename, content=content)

    storage_counts: dict[str, int] = {}
    if store:
        sinks = get_sinks()
        if sinks:
            storage_counts = pipeline.store_results(result, sinks=sinks)

    return _to_ingestion_response(result, storage_counts=storage_counts)


@router.post("/ingest", response_model=IngestionResponse, status_code=201)
async def ingest_path(
    source: str,
    store: bool = Query(False, description="Persist chunks to configured storage sinks"),
) -> IngestionResponse:
    """Ingest a document from a local file path.

    The file must be accessible from the server.

    When *store* is ``True``, the parsed chunks are also written to any
    configured storage backends (pgvector, Neo4j).
    """
    pipeline = get_pipeline()
    result = pipeline.ingest(source)

    storage_counts: dict[str, int] = {}
    if store:
        sinks = get_sinks()
        if sinks:
            storage_counts = pipeline.store_results(result, sinks=sinks)

    return _to_ingestion_response(result, storage_counts=storage_counts)


@router.get("/history", response_model=list[IngestionHistoryItem])
async def ingestion_history() -> list[IngestionHistoryItem]:
    """List all ingestion operations performed in this session."""
    pipeline = get_pipeline()
    return [
        IngestionHistoryItem(
            document_id=r.document_id,
            source_path=r.source_path,
            num_chunks=r.num_chunks,
            modality=r.modality.value,
        )
        for r in pipeline.history()
    ]


@router.get("/formats")
async def supported_formats() -> dict[str, Any]:
    """List all supported file formats and their parsers."""
    pipeline = get_pipeline()
    parsers = pipeline.registry.all_parsers()
    return {
        "extensions": pipeline.registry.supported_extensions(),
        "parsers": [
            {
                "name": type(p).__name__,
                "extensions": p.supported_extensions,
                "modalities": [m.value for m in p.supported_modalities],
            }
            for p in parsers
        ],
    }


@router.get("/{document_id}", response_model=IngestionResponse)
async def ingestion_status(document_id: str) -> IngestionResponse:
    """Retrieve a full ingestion result by document ID."""
    result = _find_ingestion_result(document_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Ingestion '{document_id}' not found")
    return _to_ingestion_response(result)


@router.post("/{document_id}/retry", response_model=IngestionResponse, status_code=201)
async def retry_ingestion(
    document_id: str,
    store: bool = Query(False, description="Persist chunks to configured storage sinks"),
) -> IngestionResponse:
    """Retry ingesting a prior document by document ID.

    Retry is supported for ingestion entries whose ``source_path`` points to a
    readable local file. Upload-only in-memory sources cannot be retried.
    """
    original = _find_ingestion_result(document_id)
    if original is None:
        raise HTTPException(status_code=404, detail=f"Ingestion '{document_id}' not found")

    source = Path(original.source_path)
    if not source.is_file():
        raise HTTPException(
            status_code=400,
            detail=(
                "Retry requires a readable local source file. "
                f"Original source '{original.source_path}' is not available."
            ),
        )

    pipeline = get_pipeline()
    result = pipeline.ingest(source)

    storage_counts: dict[str, int] = {}
    if store:
        sinks = get_sinks()
        if sinks:
            storage_counts = pipeline.store_results(result, sinks=sinks)

    return _to_ingestion_response(result, storage_counts=storage_counts)
