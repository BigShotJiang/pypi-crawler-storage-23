"""Aegis event system routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from aegis.events.dispatcher import EventDispatcher
from aegis.events.router import EventRouter
from aegis.events.webhooks import WebhookManager

router = APIRouter(prefix="/events", tags=["events"])

_dispatcher = EventDispatcher()
_router = EventRouter()
_webhook_manager = WebhookManager()


class PublishRequest(BaseModel):
    event_type: str
    payload: dict[str, Any] = Field(default_factory=dict)
    source: str = ""


class WebhookRegisterRequest(BaseModel):
    url: str
    secret: str = ""
    event_types: list[str] = Field(default_factory=list)
    max_retries: int = 3


class WebhookProcessRequest(BaseModel):
    fail_webhook_ids: list[str] = Field(default_factory=list)
    response_code: int = 200
    failure_code: int = 500


@router.post("/publish", status_code=201)
async def publish_event(req: PublishRequest) -> dict[str, Any]:
    """Publish an event to the event bus."""
    event = _dispatcher.publish(req.event_type, req.payload, req.source)
    _router.route(event)
    _webhook_manager.enqueue(event)
    return event


@router.get("/history")
async def event_history(event_type: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
    """Retrieve recent event history."""
    return _dispatcher.history(event_type=event_type, limit=limit)


@router.post("/webhooks", status_code=201)
async def register_webhook(req: WebhookRegisterRequest) -> dict[str, Any]:
    """Register a webhook endpoint."""
    config = _webhook_manager.register(
        url=req.url,
        secret=req.secret,
        event_types=req.event_types,
        max_retries=req.max_retries,
    )
    return {"id": config.id, "url": config.url, "status": "registered"}


@router.delete("/webhooks/{webhook_id}")
async def deregister_webhook(webhook_id: str) -> dict[str, Any]:
    """Deregister a webhook endpoint."""
    ok = _webhook_manager.deregister(webhook_id)
    return {"webhook_id": webhook_id, "deregistered": ok}


@router.get("/webhooks")
async def list_webhooks(active_only: bool = False) -> list[dict[str, Any]]:
    """List all registered webhooks."""
    hooks = _webhook_manager.list_webhooks(active_only=active_only)
    return [
        {
            "id": h.id,
            "url": h.url,
            "active": h.active,
            "event_types": h.event_types,
        }
        for h in hooks
    ]


@router.get("/webhooks/deliveries")
async def list_deliveries(
    webhook_id: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """List webhook delivery attempts."""
    deliveries = _webhook_manager.delivery_history(webhook_id=webhook_id, limit=limit)
    return [
        {
            "id": d.id,
            "webhook_id": d.webhook_id,
            "event_id": d.event_id,
            "url": d.url,
            "status": d.status,
            "attempts": d.attempts,
            "response_code": d.response_code,
            "error": d.error,
            "last_attempt_at": d.last_attempt_at.isoformat() if d.last_attempt_at else None,
            "created_at": d.created_at.isoformat(),
        }
        for d in deliveries
    ]


@router.get("/webhooks/queue")
async def list_webhook_queue() -> list[dict[str, Any]]:
    """Inspect pending webhook queue entries."""
    return _webhook_manager.pending_deliveries()


@router.post("/webhooks/process")
async def process_webhook_queue(req: WebhookProcessRequest) -> dict[str, Any]:
    """Process queued webhook deliveries and return delivery summary."""
    return _webhook_manager.process_queue(
        fail_webhook_ids=set(req.fail_webhook_ids),
        response_code=req.response_code,
        failure_code=req.failure_code,
    )


@router.get("/webhooks/stats")
async def webhook_stats() -> dict[str, Any]:
    """Get webhook delivery statistics."""
    return _webhook_manager.stats()


@router.get("/dead-letters")
async def dead_letters() -> list[dict[str, Any]]:
    """Get failed event deliveries."""
    return _dispatcher.dead_letters()
