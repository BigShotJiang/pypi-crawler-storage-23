"""Aegis API — FastAPI application.

Re-exports the configured :data:`app` FastAPI instance.
"""

from aegis.api.app import app

__all__ = [
    "app",
]
