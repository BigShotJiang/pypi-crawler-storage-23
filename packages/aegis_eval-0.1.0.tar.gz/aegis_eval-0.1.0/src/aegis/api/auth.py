"""Authentication and authorization middleware for the Aegis API.

Supports JWT bearer tokens, API key authentication, and SSO-ready
integration points for Auth0/Clerk.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass, field
from typing import cast

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class AuthUser:
    """Authenticated user identity and permissions.

    Represents a user that has been verified through either JWT or API key
    authentication.
    """

    user_id: str
    email: str
    roles: list[str] = field(default_factory=list)
    permissions: list[str] = field(default_factory=list)
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass
class APIKey:
    """API key record with scoping and lifecycle management.

    Stores the hashed key alongside metadata for lookup, validation,
    and auditing purposes.
    """

    key_id: str
    hashed_key: str
    user_id: str
    scopes: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    expires_at: float | None = None
    is_active: bool = True


@dataclass
class AuthConfig:
    """Configuration for the authentication provider.

    Controls JWT validation parameters, API key header names, and
    SSO issuer settings.
    """

    jwt_secret: str = ""
    jwt_algorithm: str = "HS256"
    api_key_header: str = "X-API-Key"
    auth_header: str = "Authorization"
    issuer: str = "aegis"
    audience: str = "aegis-api"
    token_expiry_seconds: int = 3600
    api_key_prefix: str = "aegis_"


# ---------------------------------------------------------------------------
# JWT helpers (stdlib-only HMAC-SHA256)
# ---------------------------------------------------------------------------


def _b64url_encode(data: bytes) -> str:
    """Base64url-encode bytes without padding.

    Args:
        data: Raw bytes to encode.

    Returns:
        A base64url-encoded string with padding stripped.
    """
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    """Base64url-decode a string, restoring padding.

    Args:
        s: A base64url-encoded string (padding optional).

    Returns:
        The decoded raw bytes.
    """
    # Restore padding
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


def _create_jwt(payload: dict[str, object], secret: str, algorithm: str = "HS256") -> str:
    """Create a signed JWT token using HMAC-SHA256.

    Args:
        payload: The JWT claims payload to encode.
        secret: The HMAC secret key.
        algorithm: The signing algorithm (only HS256 is supported).

    Returns:
        A signed JWT string in ``header.payload.signature`` format.

    Raises:
        ValueError: If the algorithm is not ``HS256``.
    """
    if algorithm != "HS256":
        msg = f"Only HS256 is supported, got {algorithm}"
        raise ValueError(msg)

    header = {"alg": "HS256", "typ": "JWT"}
    header_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode())
    payload_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode())

    signing_input = f"{header_b64}.{payload_b64}"
    signature = hmac.new(
        secret.encode("utf-8"),
        signing_input.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    signature_b64 = _b64url_encode(signature)

    return f"{header_b64}.{payload_b64}.{signature_b64}"


def _decode_jwt(token: str, secret: str, algorithm: str = "HS256") -> dict[str, object] | None:
    """Decode and verify a JWT token signed with HMAC-SHA256.

    Validates the signature and checks ``exp``, ``iss``, and ``aud`` claims
    if they are present.

    Args:
        token: The JWT string to decode.
        secret: The HMAC secret key used for verification.
        algorithm: Expected algorithm (only HS256 is supported).

    Returns:
        The decoded payload dictionary, or ``None`` if verification fails.
    """
    if algorithm != "HS256":
        return None

    parts = token.split(".")
    if len(parts) != 3:
        return None

    header_b64, payload_b64, signature_b64 = parts

    # Verify header
    try:
        header = json.loads(_b64url_decode(header_b64))
    except (json.JSONDecodeError, Exception):
        return None

    if header.get("alg") != "HS256":
        return None

    # Verify signature
    signing_input = f"{header_b64}.{payload_b64}"
    expected_sig = hmac.new(
        secret.encode("utf-8"),
        signing_input.encode("utf-8"),
        hashlib.sha256,
    ).digest()

    try:
        actual_sig = _b64url_decode(signature_b64)
    except Exception:
        return None

    if not hmac.compare_digest(expected_sig, actual_sig):
        return None

    # Decode payload
    try:
        payload = json.loads(_b64url_decode(payload_b64))
    except (json.JSONDecodeError, Exception):
        return None

    # Check expiration
    exp = payload.get("exp")
    if exp is not None and time.time() > float(exp):
        return None

    return cast("dict[str, object]", payload)


# ---------------------------------------------------------------------------
# API key hashing
# ---------------------------------------------------------------------------


def _hash_api_key(raw_key: str) -> str:
    """Hash an API key using SHA-256 for secure storage.

    Args:
        raw_key: The plaintext API key.

    Returns:
        The hex-encoded SHA-256 hash of the key.
    """
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Permission rules
# ---------------------------------------------------------------------------

# Default role-to-permission mapping for RBAC
_DEFAULT_ROLE_PERMISSIONS: dict[str, list[str]] = {
    "admin": [
        "eval:read",
        "eval:write",
        "eval:delete",
        "training:read",
        "training:write",
        "training:delete",
        "memory:read",
        "memory:write",
        "memory:delete",
        "observatory:read",
        "observatory:write",
        "api_keys:read",
        "api_keys:write",
        "api_keys:delete",
        "users:read",
        "users:write",
    ],
    "developer": [
        "eval:read",
        "eval:write",
        "training:read",
        "training:write",
        "memory:read",
        "memory:write",
        "observatory:read",
        "api_keys:read",
        "api_keys:write",
    ],
    "viewer": [
        "eval:read",
        "training:read",
        "memory:read",
        "observatory:read",
    ],
}


def _resolve_permissions(roles: list[str], explicit_permissions: list[str]) -> list[str]:
    """Resolve the full set of permissions from roles and explicit grants.

    Merges permissions derived from roles with any explicit permissions,
    returning a deduplicated list.

    Args:
        roles: The user's assigned roles.
        explicit_permissions: Permissions granted directly to the user.

    Returns:
        A deduplicated list of all effective permissions.
    """
    all_perms: set[str] = set(explicit_permissions)
    for role in roles:
        role_perms = _DEFAULT_ROLE_PERMISSIONS.get(role, [])
        all_perms.update(role_perms)
    return sorted(all_perms)


# ---------------------------------------------------------------------------
# AuthProvider
# ---------------------------------------------------------------------------


class AuthProvider:
    """Central authentication and authorization provider.

    Manages JWT verification, API key lifecycle, and permission checks.
    Designed to be instantiated once and shared across the application.
    """

    def __init__(self, config: AuthConfig) -> None:
        """Initialize the auth provider with the given configuration.

        Args:
            config: Authentication configuration controlling JWT secrets,
                header names, and issuer settings.
        """
        self._config = config
        # In-memory API key store: key_id -> APIKey
        self._api_keys: dict[str, APIKey] = {}
        # Hash -> key_id lookup for fast authentication
        self._hash_to_key_id: dict[str, str] = {}
        # User ID -> list of key IDs for listing
        self._user_keys: dict[str, list[str]] = {}

    def verify_jwt(self, token: str) -> AuthUser | None:
        """Verify and decode a JWT bearer token.

        Checks the HMAC-SHA256 signature, validates expiration, and
        extracts user identity from the claims.

        Args:
            token: The raw JWT string (without the ``Bearer`` prefix).

        Returns:
            An :class:`AuthUser` if the token is valid, or ``None``.
        """
        if not self._config.jwt_secret:
            return None

        payload = _decode_jwt(token, self._config.jwt_secret, self._config.jwt_algorithm)
        if payload is None:
            return None

        # Validate issuer if present
        iss = payload.get("iss")
        if iss is not None and iss != self._config.issuer:
            return None

        # Validate audience if present
        aud = payload.get("aud")
        if aud is not None:
            if isinstance(aud, list):
                if self._config.audience not in aud:
                    return None
            elif aud != self._config.audience:
                return None

        user_id = payload.get("sub", "")
        email = payload.get("email", "")
        roles = cast("list[str]", payload.get("roles", []))
        explicit_perms = cast("list[str]", payload.get("permissions", []))
        permissions = _resolve_permissions(roles, explicit_perms)

        return AuthUser(
            user_id=str(user_id),
            email=str(email),
            roles=list(roles),
            permissions=permissions,
            metadata={
                "auth_method": "jwt",
                "issued_at": payload.get("iat"),
                "expires_at": payload.get("exp"),
            },
        )

    def verify_api_key(self, key: str) -> AuthUser | None:
        """Look up and verify an API key.

        Checks the key against stored hashes, validates expiration and
        active status, and returns the associated user identity.

        Args:
            key: The raw API key string.

        Returns:
            An :class:`AuthUser` if the key is valid, or ``None``.
        """
        hashed = _hash_api_key(key)
        key_id = self._hash_to_key_id.get(hashed)
        if key_id is None:
            return None

        api_key = self._api_keys.get(key_id)
        if api_key is None:
            return None

        if not api_key.is_active:
            return None

        # Check expiration
        if api_key.expires_at is not None and time.time() > api_key.expires_at:
            return None

        permissions = list(api_key.scopes)

        return AuthUser(
            user_id=api_key.user_id,
            email="",
            roles=[],
            permissions=permissions,
            metadata={
                "auth_method": "api_key",
                "key_id": api_key.key_id,
                "created_at": api_key.created_at,
            },
        )

    def authenticate(self, request_headers: dict[str, str]) -> AuthUser | None:
        """Authenticate a request by trying JWT, then API key.

        Examines the request headers for a Bearer token in the
        Authorization header first, then falls back to the API key header.

        Args:
            request_headers: A dictionary of HTTP request headers.  Keys
                are case-insensitive (normalized internally).

        Returns:
            An :class:`AuthUser` if authentication succeeds, or ``None``.
        """
        # Normalize header keys to lowercase for case-insensitive lookup
        normalized = {k.lower(): v for k, v in request_headers.items()}

        # Try JWT bearer token first
        auth_header = normalized.get(self._config.auth_header.lower(), "")
        if auth_header:
            parts = auth_header.split(None, 1)
            if len(parts) == 2 and parts[0].lower() == "bearer":
                user = self.verify_jwt(parts[1])
                if user is not None:
                    return user

        # Try API key
        api_key_header = normalized.get(self._config.api_key_header.lower(), "")
        if api_key_header:
            user = self.verify_api_key(api_key_header)
            if user is not None:
                return user

        return None

    def authorize(self, user: AuthUser, resource: str, action: str) -> bool:
        """Check whether a user has permission for a resource action.

        Permissions follow the format ``resource:action`` (e.g.
        ``eval:read``, ``training:write``).

        Args:
            user: The authenticated user to check.
            resource: The resource name (e.g. ``"eval"``, ``"training"``).
            action: The action (e.g. ``"read"``, ``"write"``, ``"delete"``).

        Returns:
            ``True`` if the user has the required permission.
        """
        required = f"{resource}:{action}"

        # Direct permission match
        if required in user.permissions:
            return True

        # Wildcard: resource:* grants all actions on a resource
        if f"{resource}:*" in user.permissions:
            return True

        # Global admin wildcard
        return "*:*" in user.permissions

    def create_api_key(
        self, user_id: str, scopes: list[str], *, expires_in_seconds: int | None = None
    ) -> tuple[str, APIKey]:
        """Generate a new API key for a user.

        The raw key is returned exactly once; only the hash is stored.

        Args:
            user_id: The user ID to associate the key with.
            scopes: List of permission scopes for this key.
            expires_in_seconds: Optional TTL; ``None`` for no expiration.

        Returns:
            A tuple of ``(raw_key, api_key_record)``.
        """
        key_id = secrets.token_hex(8)
        raw_key = f"{self._config.api_key_prefix}{secrets.token_urlsafe(32)}"
        hashed = _hash_api_key(raw_key)

        expires_at = None
        if expires_in_seconds is not None:
            expires_at = time.time() + expires_in_seconds

        api_key = APIKey(
            key_id=key_id,
            hashed_key=hashed,
            user_id=user_id,
            scopes=list(scopes),
            expires_at=expires_at,
        )

        self._api_keys[key_id] = api_key
        self._hash_to_key_id[hashed] = key_id
        self._user_keys.setdefault(user_id, []).append(key_id)

        return raw_key, api_key

    def revoke_api_key(self, key_id: str) -> bool:
        """Revoke an API key by marking it inactive.

        The key record is preserved for audit purposes but will no longer
        authenticate requests.

        Args:
            key_id: The ID of the key to revoke.

        Returns:
            ``True`` if the key was found and revoked, ``False`` otherwise.
        """
        api_key = self._api_keys.get(key_id)
        if api_key is None:
            return False

        api_key.is_active = False

        # Remove from hash lookup so it cannot authenticate
        keys_to_remove = [h for h, kid in self._hash_to_key_id.items() if kid == key_id]
        for h in keys_to_remove:
            del self._hash_to_key_id[h]

        return True

    def list_api_keys(self, user_id: str) -> list[APIKey]:
        """List all API keys belonging to a user.

        Returns both active and revoked keys for audit visibility.

        Args:
            user_id: The user ID to list keys for.

        Returns:
            A list of :class:`APIKey` records.
        """
        key_ids = self._user_keys.get(user_id, [])
        keys: list[APIKey] = []
        for key_id in key_ids:
            api_key = self._api_keys.get(key_id)
            if api_key is not None:
                keys.append(api_key)
        return keys

    def create_jwt(
        self,
        user_id: str,
        email: str,
        roles: list[str] | None = None,
        permissions: list[str] | None = None,
        extra_claims: dict[str, object] | None = None,
    ) -> str:
        """Create a signed JWT token for a user.

        Convenience method for issuing tokens. In production, token
        issuance would typically be handled by an SSO provider.

        Args:
            user_id: The subject (``sub``) claim.
            email: The user's email address.
            roles: Optional list of roles to embed.
            permissions: Optional explicit permissions to embed.
            extra_claims: Additional claims to include in the payload.

        Returns:
            A signed JWT string.

        Raises:
            ValueError: If no JWT secret is configured.
        """
        if not self._config.jwt_secret:
            msg = "Cannot create JWT: no jwt_secret configured"
            raise ValueError(msg)

        now = time.time()
        payload: dict[str, object] = {
            "sub": user_id,
            "email": email,
            "iss": self._config.issuer,
            "aud": self._config.audience,
            "iat": int(now),
            "exp": int(now) + self._config.token_expiry_seconds,
        }
        if roles:
            payload["roles"] = roles
        if permissions:
            payload["permissions"] = permissions
        if extra_claims:
            payload.update(extra_claims)

        return _create_jwt(payload, self._config.jwt_secret, self._config.jwt_algorithm)


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

# Module-level default provider (initialized lazily or by the application)
_default_provider: AuthProvider | None = None


def set_default_provider(provider: AuthProvider) -> None:
    """Set the module-level default auth provider.

    Args:
        provider: The :class:`AuthProvider` instance to use as default.
    """
    global _default_provider  # noqa: PLW0603
    _default_provider = provider


def get_default_provider() -> AuthProvider:
    """Return the module-level default auth provider.

    Creates a minimal provider with an empty secret if none has been
    configured.

    Returns:
        The default :class:`AuthProvider`.
    """
    global _default_provider  # noqa: PLW0603
    if _default_provider is None:
        _default_provider = AuthProvider(AuthConfig())
    return _default_provider


def get_current_user(headers: dict[str, str]) -> AuthUser | None:
    """Authenticate a request and return the current user.

    Uses the module-level default :class:`AuthProvider`.

    Args:
        headers: HTTP request headers dictionary.

    Returns:
        An :class:`AuthUser` if authentication succeeds, or ``None``.
    """
    provider = get_default_provider()
    return provider.authenticate(headers)


def require_auth(headers: dict[str, str]) -> AuthUser:
    """Authenticate a request, raising an error on failure.

    Args:
        headers: HTTP request headers dictionary.

    Returns:
        The authenticated :class:`AuthUser`.

    Raises:
        PermissionError: If authentication fails (maps to HTTP 401).
    """
    user = get_current_user(headers)
    if user is None:
        msg = "Authentication required"
        raise PermissionError(msg)
    return user


def require_permission(user: AuthUser, resource: str, action: str) -> None:
    """Check that a user has permission, raising an error if not.

    Args:
        user: The authenticated user.
        resource: The resource to access.
        action: The action to perform.

    Raises:
        PermissionError: If the user lacks the required permission
            (maps to HTTP 403).
    """
    provider = get_default_provider()
    if not provider.authorize(user, resource, action):
        msg = f"Permission denied: {resource}:{action}"
        raise PermissionError(msg)
