"""Aegis Agent Protocol — standardized interface for any agent to work with Aegis.

Defines the protocol version, message/response envelopes, agent registration,
and both server-side dispatch and client-side handler routing.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

PROTOCOL_VERSION: str = "1.0"

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class AgentCapability(str, Enum):
    """Capabilities an agent can declare when registering with Aegis."""

    EVALUATE = "evaluate"
    MEMORY_GET = "memory_get"
    MEMORY_SET = "memory_set"
    OBSERVE = "observe"
    TRAIN = "train"


# Mapping from high-level method names to required capabilities.
_METHOD_CAPABILITY_MAP: dict[str, AgentCapability] = {
    "evaluate": AgentCapability.EVALUATE,
    "memory_get": AgentCapability.MEMORY_GET,
    "memory_set": AgentCapability.MEMORY_SET,
    "observe": AgentCapability.OBSERVE,
    "train": AgentCapability.TRAIN,
}


# ---------------------------------------------------------------------------
# Data classes — protocol envelope
# ---------------------------------------------------------------------------


@dataclass
class ProtocolMessage:
    """An inbound request envelope in the Aegis Agent Protocol."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    method: str = ""
    params: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


@dataclass
class ProtocolResponse:
    """An outbound response envelope in the Aegis Agent Protocol."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    result: Any = None
    error: dict[str, Any] | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


@dataclass
class AgentEndpoint:
    """A registered agent endpoint with its declared capabilities."""

    agent_id: str = ""
    url: str = ""
    capabilities: list[AgentCapability] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    registered_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# AgentProtocolServer
# ---------------------------------------------------------------------------


class AgentProtocolServer:
    """Server-side protocol handler.

    Manages agent registration, capability-based dispatch, and convenience
    methods for common operations (evaluate, memory, observe).
    """

    def __init__(self) -> None:
        self._agents: dict[str, AgentEndpoint] = {}
        self._request_log: list[dict[str, Any]] = []

    # -- Registration -------------------------------------------------------

    def register_agent(
        self,
        agent_id: str,
        url: str,
        capabilities: list[AgentCapability],
        metadata: dict[str, Any] | None = None,
    ) -> AgentEndpoint:
        """Register an agent with the protocol server.

        If the agent is already registered its record is updated in place.
        """
        endpoint = AgentEndpoint(
            agent_id=agent_id,
            url=url,
            capabilities=list(capabilities),
            metadata=metadata or {},
            registered_at=datetime.now(tz=UTC),
        )
        self._agents[agent_id] = endpoint
        return endpoint

    def unregister_agent(self, agent_id: str) -> None:
        """Remove an agent from the registry.

        Raises ``KeyError`` if the agent is not registered.
        """
        if agent_id not in self._agents:
            raise KeyError(f"Agent '{agent_id}' is not registered")
        del self._agents[agent_id]

    def get_agent(self, agent_id: str) -> AgentEndpoint | None:
        """Return the endpoint record for *agent_id*, or ``None``."""
        return self._agents.get(agent_id)

    def list_agents(self) -> list[AgentEndpoint]:
        """Return all registered agent endpoints."""
        return list(self._agents.values())

    # -- Dispatch -----------------------------------------------------------

    def dispatch(
        self,
        agent_id: str,
        method: str,
        params: dict[str, Any] | None = None,
    ) -> ProtocolResponse:
        """Route a request to the right agent.

        Validates that the agent exists and has the required capability for
        the given *method*.  Returns a ``ProtocolResponse`` with the result
        or an error envelope.
        """
        endpoint = self._agents.get(agent_id)
        if endpoint is None:
            return ProtocolResponse(
                error={
                    "code": "AGENT_NOT_FOUND",
                    "message": f"Agent '{agent_id}' is not registered",
                },
            )

        # Capability check
        required = _METHOD_CAPABILITY_MAP.get(method)
        if required is not None and required not in endpoint.capabilities:
            return ProtocolResponse(
                error={
                    "code": "CAPABILITY_MISSING",
                    "message": f"Agent '{agent_id}' lacks capability '{required.value}' for method '{method}'",
                },
            )

        message = ProtocolMessage(
            method=method,
            params=params or {},
        )

        self._request_log.append(
            {
                "agent_id": agent_id,
                "method": method,
                "message_id": message.id,
                "timestamp": message.timestamp.isoformat(),
            }
        )

        # Build a successful dispatch envelope.  In a real networked
        # implementation this would make an HTTP/gRPC call to ``endpoint.url``.
        # Here we return a structured acknowledgement suitable for in-process
        # or test usage.
        return ProtocolResponse(
            result={
                "dispatched": True,
                "agent_id": agent_id,
                "method": method,
                "params": params or {},
                "message_id": message.id,
                "endpoint_url": endpoint.url,
            },
        )

    # -- Convenience helpers ------------------------------------------------

    def evaluate(self, agent_id: str, task: dict[str, Any]) -> ProtocolResponse:
        """Send an evaluation task to an agent."""
        return self.dispatch(agent_id, "evaluate", {"task": task})

    def memory_get(self, agent_id: str, query: str) -> ProtocolResponse:
        """Read memory from an agent."""
        return self.dispatch(agent_id, "memory_get", {"query": query})

    def memory_set(
        self,
        agent_id: str,
        key: str,
        value: Any,
        metadata: dict[str, Any] | None = None,
    ) -> ProtocolResponse:
        """Write memory to an agent."""
        return self.dispatch(
            agent_id,
            "memory_set",
            {"key": key, "value": value, "metadata": metadata or {}},
        )

    def observe(self, agent_id: str, event: dict[str, Any]) -> ProtocolResponse:
        """Emit an observation event to an agent."""
        return self.dispatch(agent_id, "observe", {"event": event})

    def health_check(self, agent_id: str) -> dict[str, Any]:
        """Return health status for an agent.

        Returns basic registration info and reachability status.
        """
        endpoint = self._agents.get(agent_id)
        if endpoint is None:
            return {
                "agent_id": agent_id,
                "registered": False,
                "healthy": False,
            }
        return {
            "agent_id": agent_id,
            "registered": True,
            "healthy": True,
            "url": endpoint.url,
            "capabilities": [c.value for c in endpoint.capabilities],
            "registered_at": endpoint.registered_at.isoformat(),
            "protocol_version": PROTOCOL_VERSION,
        }


# ---------------------------------------------------------------------------
# AgentProtocolClient
# ---------------------------------------------------------------------------


class AgentProtocolClient:
    """Client-side helper for agents to implement the Aegis protocol.

    Agents instantiate this with a map of method names to handler callables.
    Incoming ``ProtocolMessage`` instances are routed to the matching handler.
    """

    def __init__(
        self,
        agent_id: str,
        handler_map: dict[str, Callable[..., Any]] | None = None,
    ) -> None:
        self._agent_id = agent_id
        self._handlers: dict[str, Callable[..., Any]] = dict(handler_map or {})

    @property
    def agent_id(self) -> str:
        return self._agent_id

    def register_handler(self, method: str, handler_fn: Callable[..., Any]) -> None:
        """Register (or replace) a handler for *method*."""
        self._handlers[method] = handler_fn

    def supported_methods(self) -> list[str]:
        """Return the list of methods this client can handle."""
        return sorted(self._handlers.keys())

    def handle(self, message: ProtocolMessage) -> ProtocolResponse:
        """Route an incoming protocol message to the appropriate handler.

        If no handler is registered for the message's method an error response
        is returned.  Handler exceptions are caught and wrapped in an error
        envelope so the protocol never raises.
        """
        handler = self._handlers.get(message.method)
        if handler is None:
            return ProtocolResponse(
                id=message.id,
                error={
                    "code": "METHOD_NOT_FOUND",
                    "message": f"No handler registered for method '{message.method}'",
                },
            )

        try:
            result = handler(message.params)
            return ProtocolResponse(
                id=message.id,
                result=result,
            )
        except Exception as exc:  # noqa: BLE001
            return ProtocolResponse(
                id=message.id,
                error={
                    "code": "HANDLER_ERROR",
                    "message": str(exc),
                    "method": message.method,
                },
            )
