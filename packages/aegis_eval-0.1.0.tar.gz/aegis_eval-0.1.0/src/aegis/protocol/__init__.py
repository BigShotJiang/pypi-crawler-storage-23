"""Aegis Agent Protocol — standardized interface for agent-platform communication.

Re-exports the protocol server, client, and supporting data classes.
"""

from aegis.protocol.agent_protocol import (
    PROTOCOL_VERSION,
    AgentCapability,
    AgentEndpoint,
    AgentProtocolClient,
    AgentProtocolServer,
    ProtocolMessage,
    ProtocolResponse,
)

__all__ = [
    "PROTOCOL_VERSION",
    "AgentCapability",
    "ProtocolMessage",
    "ProtocolResponse",
    "AgentEndpoint",
    "AgentProtocolServer",
    "AgentProtocolClient",
]
