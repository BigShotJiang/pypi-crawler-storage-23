"""Reward engine for per-stage process rewards.

Decomposes rewards across multiple processing stages and combines
three signal types: rule-based, semantic, and judge scores with
dynamic weighting.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any

from aegis.core.types import RewardTraceV1, StageReward


@dataclass
class RewardStageConfig:
    """Configuration for a single reward stage."""

    stage: int
    stage_name: str
    weight: float = 1.0
    rule_weight: float = 0.4
    semantic_weight: float = 0.3
    judge_weight: float = 0.3


# Default stage configs for legal domain (7 stages)
LEGAL_STAGES: list[RewardStageConfig] = [
    RewardStageConfig(0, "case_identification", weight=0.15),
    RewardStageConfig(1, "statute_retrieval", weight=0.15),
    RewardStageConfig(2, "precedent_analysis", weight=0.15),
    RewardStageConfig(3, "argument_construction", weight=0.2),
    RewardStageConfig(4, "citation_accuracy", weight=0.15),
    RewardStageConfig(5, "conclusion_coherence", weight=0.1),
    RewardStageConfig(6, "overall_quality", weight=0.1),
]

# Default stage configs for finance domain (8 stages)
FINANCE_STAGES: list[RewardStageConfig] = [
    RewardStageConfig(0, "data_retrieval", weight=0.1),
    RewardStageConfig(1, "numerical_accuracy", weight=0.15),
    RewardStageConfig(2, "trend_analysis", weight=0.15),
    RewardStageConfig(3, "risk_assessment", weight=0.15),
    RewardStageConfig(4, "regulatory_compliance", weight=0.1),
    RewardStageConfig(5, "recommendation_quality", weight=0.15),
    RewardStageConfig(6, "uncertainty_calibration", weight=0.1),
    RewardStageConfig(7, "overall_quality", weight=0.1),
]

# General stages (5 stages)
GENERAL_STAGES: list[RewardStageConfig] = [
    RewardStageConfig(0, "comprehension", weight=0.2),
    RewardStageConfig(1, "retrieval", weight=0.2),
    RewardStageConfig(2, "reasoning", weight=0.25),
    RewardStageConfig(3, "synthesis", weight=0.2),
    RewardStageConfig(4, "quality", weight=0.15),
]


def _deterministic_score(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Produce a deterministic score from a seed string."""
    digest = hashlib.sha256(seed.encode()).hexdigest()
    normalized = int(digest[:8], 16) / 0xFFFFFFFF
    return low + normalized * (high - low)


class RewardEngine:
    """Computes per-stage process rewards with three signal types.

    Combines rule-based scores, semantic similarity scores, and
    LLM judge scores with dynamic or fixed weighting profiles.
    """

    def __init__(
        self,
        stages: list[RewardStageConfig] | None = None,
        weighting_profile: str = "dynamic",
    ) -> None:
        self._stages = stages or list(GENERAL_STAGES)
        self._weighting_profile = weighting_profile
        self._history: list[RewardTraceV1] = []

    @property
    def stages(self) -> list[RewardStageConfig]:
        return list(self._stages)

    def compute_reward(
        self,
        rollout_id: str,
        stage_scores: dict[str, dict[str, float]] | None = None,
        prompt: str = "",
    ) -> RewardTraceV1:
        """Compute the full reward trace for a rollout.

        Args:
            rollout_id: Identifier of the rollout.
            stage_scores: Optional pre-computed scores per stage.
                Format: {"stage_name": {"rule": 0.8, "semantic": 0.7, "judge": 0.9}}
                If not provided, scores are generated deterministically.
            prompt: Used as seed for deterministic scoring if stage_scores not provided.

        Returns:
            A RewardTraceV1 with per-stage reward decomposition.
        """
        stage_rewards: list[StageReward] = []

        for stage_config in self._stages:
            if stage_scores and stage_config.stage_name in stage_scores:
                scores = stage_scores[stage_config.stage_name]
                rule = scores.get("rule", 0.5)
                semantic = scores.get("semantic", 0.5)
                judge = scores.get("judge", 0.5)
            else:
                # Deterministic fallback
                seed = f"{rollout_id}:{stage_config.stage_name}:{prompt}"
                rule = _deterministic_score(f"rule:{seed}", 0.3, 1.0)
                semantic = _deterministic_score(f"semantic:{seed}", 0.3, 1.0)
                judge = _deterministic_score(f"judge:{seed}", 0.3, 1.0)

            # Apply signal weights
            weighted = (
                rule * stage_config.rule_weight
                + semantic * stage_config.semantic_weight
                + judge * stage_config.judge_weight
            )

            stage_rewards.append(
                StageReward(
                    stage=stage_config.stage,
                    stage_name=stage_config.stage_name,
                    rule_score=round(rule, 4),
                    semantic_score=round(semantic, 4),
                    judge_score=round(judge, 4),
                    weight=stage_config.weight,
                    weighted_score=round(weighted * stage_config.weight, 4),
                )
            )

        total_reward = sum(sr.weighted_score for sr in stage_rewards)

        # Apply dynamic weighting if configured
        if self._weighting_profile == "dynamic" and len(stage_rewards) > 1:
            total_reward = self._apply_dynamic_weighting(stage_rewards)

        trace = RewardTraceV1(
            rollout_id=rollout_id,
            stages=stage_rewards,
            total_reward=round(total_reward, 4),
            weighting_profile=self._weighting_profile,
        )
        self._history.append(trace)
        return trace

    def _apply_dynamic_weighting(self, stage_rewards: list[StageReward]) -> float:
        """Apply dynamic reward weighting based on stage performance.

        Stages where the agent performs poorly get higher weight to
        encourage improvement in weak areas.
        """
        weighted_scores = []
        for sr in stage_rewards:
            # Compute per-stage combined score
            combined = (sr.rule_score + sr.semantic_score + sr.judge_score) / 3
            # Inverse weighting: poor stages get emphasized
            gap = max(0.0, 0.8 - combined)
            weighted_scores.append(sr.weighted_score * (1.0 + gap))

        total_weight = sum(
            sr.weight
            * (1.0 + max(0.0, 0.8 - (sr.rule_score + sr.semantic_score + sr.judge_score) / 3))
            for sr in stage_rewards
        )

        if total_weight > 0:
            return sum(weighted_scores) / total_weight
        return sum(sr.weighted_score for sr in stage_rewards)

    def history(self, limit: int = 100) -> list[RewardTraceV1]:
        """Return recent reward trace history."""
        return self._history[-limit:]

    def summary(self) -> dict[str, Any]:
        """Return reward engine summary statistics."""
        if not self._history:
            return {"total_traces": 0, "stages": len(self._stages)}

        rewards = [t.total_reward for t in self._history]
        return {
            "total_traces": len(self._history),
            "stages": len(self._stages),
            "weighting_profile": self._weighting_profile,
            "mean_reward": round(sum(rewards) / len(rewards), 4),
            "min_reward": round(min(rewards), 4),
            "max_reward": round(max(rewards), 4),
        }

    @classmethod
    def for_domain(cls, domain: str, weighting_profile: str = "dynamic") -> RewardEngine:
        """Factory method to create domain-specific reward engines."""
        if domain == "legal":
            return cls(stages=list(LEGAL_STAGES), weighting_profile=weighting_profile)
        elif domain == "finance":
            return cls(stages=list(FINANCE_STAGES), weighting_profile=weighting_profile)
        return cls(stages=list(GENERAL_STAGES), weighting_profile=weighting_profile)
