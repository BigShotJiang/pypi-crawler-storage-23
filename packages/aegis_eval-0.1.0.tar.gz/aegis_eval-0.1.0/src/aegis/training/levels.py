"""Training levels for the Aegis RL training engine.

Seven levels of capability training, each building on the last:
- Level 1: Memory Operations (STORE, RETRIEVE, UPDATE, FORGET, etc.)
- Level 2: Retrieval Policy (dynamic depth, source routing, iterative retrieval)
- Level 3: Context Construction (context selection, ordering, budgeting, compression)
- Level 4: Reasoning Strategy (CoT selection, backtracking, self-correction, hypothesis testing)
- Level 5: Meta-Learning (few-shot adaptation, transfer, exploration vs exploitation)
- Level 6: Architecture Discovery (ALMA-inspired meta-agent memory architecture search)
- Level 7: Multi-Agent Coordination (knowledge sharing, conflict resolution, division of labor)
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "TrainingLevel",
    "TrainingLevelManager",
    "TRAINING_LEVELS",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _det_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Return a deterministic float in [low, high] derived from *seed*."""
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return low + int(digest[:8], 16) / 0xFFFFFFFF * (high - low)


def _det_int(seed: str, low: int, high: int) -> int:
    """Return a deterministic integer in [low, high] derived from *seed*."""
    return int(_det_float(seed, float(low), float(high) + 0.999))


def _det_choice(seed: str, options: list[Any]) -> Any:
    """Return a deterministic choice from *options* derived from *seed*."""
    if not options:
        return None
    idx = int(hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8], 16) % len(options)
    return options[idx]


def _det_sample(seed: str, options: list[Any], k: int) -> list[Any]:
    """Return a deterministic sample of *k* items from *options*."""
    if not options or k <= 0:
        return []
    result: list[Any] = []
    remaining = list(options)
    for i in range(min(k, len(remaining))):
        idx = int(hashlib.sha256(f"{seed}:{i}".encode()).hexdigest()[:8], 16) % len(remaining)
        result.append(remaining.pop(idx))
    return result


# ---------------------------------------------------------------------------
# TrainingLevel dataclass
# ---------------------------------------------------------------------------


@dataclass
class TrainingLevel:
    """A single training level in the 7-level capability hierarchy.

    Each level trains a specific set of capabilities and builds on
    prerequisites from lower levels.

    Attributes:
        level_id: Integer identifier (1-7).
        name: Short human-readable name.
        description: Detailed description of what this level trains.
        capabilities: List of capability strings this level trains.
        prerequisites: List of level IDs that must be completed first.
        difficulty_range: Tuple of (min, max) curriculum difficulty.
        operations_unlocked: Memory operations available at this level.
        eval_dimensions: Eval dimensions to test after this level.
        task_types: Training task types to generate at this level.
        min_score_to_advance: Minimum mean eval score to advance past this level.
        max_episodes: Maximum number of training episodes at this level.
        metadata: Additional level-specific metadata.
    """

    level_id: int
    name: str
    description: str
    capabilities: list[str]
    prerequisites: list[int]
    difficulty_range: tuple[int, int]
    operations_unlocked: list[str]
    eval_dimensions: list[str]
    task_types: list[str]
    min_score_to_advance: float = 0.7
    max_episodes: int = 5000
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Level definitions
# ---------------------------------------------------------------------------


TRAINING_LEVELS: list[TrainingLevel] = [
    TrainingLevel(
        level_id=1,
        name="Memory Operations",
        description=(
            "Trains basic memory operations: STORE, RETRIEVE, UPDATE, FORGET. "
            "The agent learns to correctly execute individual memory operations "
            "with proper provenance tracking, temporal awareness, and tier "
            "management. This is the foundation all other levels build upon."
        ),
        capabilities=[
            "accurate_storage",
            "precise_retrieval",
            "correct_updates",
            "selective_forgetting",
            "provenance_tracking",
            "temporal_awareness",
            "tier_placement",
        ],
        prerequisites=[],
        difficulty_range=(1, 2),
        operations_unlocked=["STORE", "RETRIEVE", "UPDATE", "FORGET"],
        eval_dimensions=[
            "1.1_verbatim_recall",
            "1.2_temporal_ordering",
            "1.3_source_attribution",
            "1.4_update_propagation",
            "1.5_selective_forgetting",
        ],
        task_types=[
            "store_retrieve",
            "update_forget",
            "provenance_check",
            "temporal_ordering",
            "tier_placement",
        ],
        min_score_to_advance=0.65,
        max_episodes=3000,
    ),
    TrainingLevel(
        level_id=2,
        name="Retrieval Policy",
        description=(
            "Trains dynamic retrieval policies: depth-adaptive search, source "
            "routing across vector/KG/SQL/web backends, iterative retrieval "
            "refinement, and anti-retrieval detection. The agent learns when "
            "and how deeply to search, which sources to query, and when to "
            "stop retrieving."
        ),
        capabilities=[
            "dynamic_depth_search",
            "source_routing",
            "iterative_refinement",
            "anti_retrieval_detection",
            "query_reformulation",
            "relevance_scoring",
            "retrieval_budget_management",
        ],
        prerequisites=[1],
        difficulty_range=(2, 3),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "VERIFY",
        ],
        eval_dimensions=[
            "2.1_context_selection",
            "2.2_source_routing_accuracy",
            "2.3_retrieval_depth",
            "2.4_anti_retrieval",
            "2.5_query_efficiency",
        ],
        task_types=[
            "multi_source_retrieval",
            "depth_adaptive_search",
            "source_routing",
            "iterative_retrieval",
            "anti_retrieval_detection",
        ],
        min_score_to_advance=0.68,
        max_episodes=4000,
    ),
    TrainingLevel(
        level_id=3,
        name="Context Construction",
        description=(
            "Trains context window construction: selecting relevant context "
            "blocks, optimal ordering, token budget management, context "
            "compression, and redundancy elimination. The agent learns to "
            "build maximally informative context windows under tight token "
            "budgets while preserving coherence and completeness."
        ),
        capabilities=[
            "context_selection",
            "context_ordering",
            "token_budgeting",
            "context_compression",
            "redundancy_elimination",
            "salience_ranking",
            "coherence_preservation",
            "gap_detection",
        ],
        prerequisites=[1, 2],
        difficulty_range=(2, 4),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "VERIFY",
        ],
        eval_dimensions=[
            "2.1_context_selection",
            "2.6_context_ordering",
            "2.7_budget_efficiency",
            "2.8_compression_quality",
            "2.9_redundancy_rate",
            "2.10_gap_detection",
        ],
        task_types=[
            "context_selection",
            "context_ordering",
            "budget_constrained_retrieval",
            "context_compression",
            "multi_document_synthesis",
            "gap_detection",
        ],
        min_score_to_advance=0.70,
        max_episodes=5000,
    ),
    TrainingLevel(
        level_id=4,
        name="Reasoning Strategy",
        description=(
            "Trains reasoning strategy selection: chain-of-thought selection, "
            "backtracking, self-correction, hypothesis testing, evidence "
            "grounding, and logical consistency checking. The agent learns to "
            "choose the right reasoning approach for each task and to recover "
            "from reasoning errors."
        ),
        capabilities=[
            "cot_selection",
            "backtracking",
            "self_correction",
            "hypothesis_testing",
            "evidence_grounding",
            "logical_consistency",
            "uncertainty_quantification",
            "reasoning_depth_control",
        ],
        prerequisites=[1, 2, 3],
        difficulty_range=(3, 4),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "VERIFY",
            "ANNOTATE",
        ],
        eval_dimensions=[
            "4.1_logical_consistency",
            "4.2_evidence_grounding",
            "4.3_self_correction",
            "4.4_hypothesis_quality",
            "4.5_reasoning_depth",
            "4.6_uncertainty_calibration",
        ],
        task_types=[
            "multi_step_reasoning",
            "backtracking_recovery",
            "self_correction",
            "hypothesis_testing",
            "evidence_synthesis",
            "contradiction_resolution",
        ],
        min_score_to_advance=0.72,
        max_episodes=5000,
    ),
    TrainingLevel(
        level_id=5,
        name="Meta-Learning",
        description=(
            "Trains meta-learning capabilities: few-shot adaptation to new "
            "tasks, cross-domain transfer, exploration vs exploitation trade-off, "
            "learning rate adaptation, and task difficulty estimation. The agent "
            "learns to learn efficiently from minimal examples and to balance "
            "exploiting known strategies vs exploring new ones."
        ),
        capabilities=[
            "few_shot_adaptation",
            "cross_domain_transfer",
            "exploration_exploitation_balance",
            "learning_rate_adaptation",
            "task_difficulty_estimation",
            "strategy_selection",
            "performance_prediction",
            "curriculum_self_pacing",
        ],
        prerequisites=[1, 2, 3, 4],
        difficulty_range=(3, 5),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "VERIFY",
            "ANNOTATE",
        ],
        eval_dimensions=[
            "3.1_few_shot_adaptation",
            "3.2_transfer_efficiency",
            "3.3_exploration_exploitation",
            "5.1_self_assessment",
            "5.2_strategy_selection",
            "5.3_performance_prediction",
        ],
        task_types=[
            "few_shot_learning",
            "domain_transfer",
            "exploration_exploitation",
            "self_pacing",
            "strategy_adaptation",
            "novel_task_generalization",
        ],
        min_score_to_advance=0.75,
        max_episodes=6000,
    ),
    TrainingLevel(
        level_id=6,
        name="Architecture Discovery",
        description=(
            "ALMA-inspired architecture discovery: the meta-agent searches over "
            "memory architectures expressed as executable code, discovering "
            "domain-specific memory designs that outperform hand-designed "
            "alternatives. Trains architectural search, fitness evaluation, "
            "evolutionary mutation, and cross-domain architecture transfer."
        ),
        capabilities=[
            "architecture_proposal",
            "fitness_evaluation",
            "evolutionary_search",
            "architecture_mutation",
            "cross_domain_architecture_transfer",
            "schema_optimization",
            "retrieval_mechanism_design",
            "update_rule_design",
        ],
        prerequisites=[1, 2, 3, 4, 5],
        difficulty_range=(4, 5),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "SPLIT",
            "MERGE",
            "VERIFY",
            "ANNOTATE",
        ],
        eval_dimensions=[
            "6.1_architecture_quality",
            "6.2_search_efficiency",
            "6.3_transfer_effectiveness",
            "6.4_novelty_score",
            "6.5_fitness_improvement",
        ],
        task_types=[
            "architecture_proposal",
            "architecture_evaluation",
            "evolutionary_search",
            "architecture_transfer",
            "schema_design",
            "retrieval_design",
        ],
        min_score_to_advance=0.78,
        max_episodes=8000,
    ),
    TrainingLevel(
        level_id=7,
        name="Multi-Agent Coordination",
        description=(
            "Trains multi-agent context coordination: knowledge sharing between "
            "agents, conflict resolution for contradictory information, shared "
            "memory construction, division of labor for retrieval tasks, and "
            "deference to agent expertise. The agent learns to collaborate "
            "effectively in multi-agent systems."
        ),
        capabilities=[
            "knowledge_sharing",
            "conflict_resolution",
            "shared_memory_construction",
            "division_of_labor",
            "expertise_deference",
            "relevance_filtering",
            "trust_calibration",
            "coordination_protocol",
        ],
        prerequisites=[1, 2, 3, 4, 5],
        difficulty_range=(4, 5),
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "SPLIT",
            "MERGE",
            "VERIFY",
            "ANNOTATE",
        ],
        eval_dimensions=[
            "6.1_knowledge_sharing",
            "6.2_conflict_resolution",
            "6.3_shared_memory",
            "6.4_division_of_labor",
            "6.5_expertise_deference",
            "6.6_coordination_efficiency",
        ],
        task_types=[
            "knowledge_sharing",
            "conflict_resolution",
            "shared_memory_construction",
            "task_delegation",
            "expertise_routing",
            "multi_agent_retrieval",
        ],
        min_score_to_advance=0.80,
        max_episodes=8000,
    ),
]


# ---------------------------------------------------------------------------
# Level advancement thresholds per dimension
# ---------------------------------------------------------------------------


_LEVEL_ADVANCEMENT_WEIGHTS: dict[int, dict[str, float]] = {
    1: {
        "1.1_verbatim_recall": 0.30,
        "1.2_temporal_ordering": 0.25,
        "1.3_source_attribution": 0.20,
        "1.4_update_propagation": 0.15,
        "1.5_selective_forgetting": 0.10,
    },
    2: {
        "2.1_context_selection": 0.25,
        "2.2_source_routing_accuracy": 0.25,
        "2.3_retrieval_depth": 0.20,
        "2.4_anti_retrieval": 0.15,
        "2.5_query_efficiency": 0.15,
    },
    3: {
        "2.1_context_selection": 0.15,
        "2.6_context_ordering": 0.20,
        "2.7_budget_efficiency": 0.25,
        "2.8_compression_quality": 0.20,
        "2.9_redundancy_rate": 0.10,
        "2.10_gap_detection": 0.10,
    },
    4: {
        "4.1_logical_consistency": 0.20,
        "4.2_evidence_grounding": 0.20,
        "4.3_self_correction": 0.20,
        "4.4_hypothesis_quality": 0.15,
        "4.5_reasoning_depth": 0.15,
        "4.6_uncertainty_calibration": 0.10,
    },
    5: {
        "3.1_few_shot_adaptation": 0.20,
        "3.2_transfer_efficiency": 0.20,
        "3.3_exploration_exploitation": 0.15,
        "5.1_self_assessment": 0.20,
        "5.2_strategy_selection": 0.15,
        "5.3_performance_prediction": 0.10,
    },
    6: {
        "6.1_architecture_quality": 0.25,
        "6.2_search_efficiency": 0.20,
        "6.3_transfer_effectiveness": 0.20,
        "6.4_novelty_score": 0.15,
        "6.5_fitness_improvement": 0.20,
    },
    7: {
        "6.1_knowledge_sharing": 0.20,
        "6.2_conflict_resolution": 0.20,
        "6.3_shared_memory": 0.15,
        "6.4_division_of_labor": 0.15,
        "6.5_expertise_deference": 0.15,
        "6.6_coordination_efficiency": 0.15,
    },
}


# ---------------------------------------------------------------------------
# Task templates for each level
# ---------------------------------------------------------------------------


_LEVEL_TASK_TEMPLATES: dict[int, dict[str, list[str]]] = {
    1: {
        "store_retrieve": [
            "Store the following information and retrieve it precisely: '{fact}'",
            "Create a memory entry for '{entity}' with attributes: {attributes}. Then verify retrieval.",
            "Store '{fact}' with provenance from '{source}'. Verify source attribution on retrieval.",
        ],
        "update_forget": [
            "Update the stored value for '{key}' from '{old_value}' to '{new_value}'. Verify history is preserved.",
            "Selectively forget PII for '{entity}' while retaining non-personal metadata.",
            "Process a GDPR deletion request for '{entity}': remove personal data, retain aggregate stats.",
        ],
        "provenance_check": [
            "Store facts from three sources with different confidence levels. Retrieve the highest-confidence version.",
            "Verify the provenance chain for '{fact}' across {n_sources} sources.",
        ],
        "temporal_ordering": [
            "Store {n_events} events with timestamps and retrieve them in chronological order.",
            "Given overlapping temporal bounds on '{entity}', determine the currently valid value.",
        ],
        "tier_placement": [
            "Decide the appropriate memory tier (working/session/permanent) for '{fact}' given access pattern: {pattern}.",
            "Promote '{fact}' from working to session memory based on access frequency of {frequency} per hour.",
        ],
    },
    2: {
        "multi_source_retrieval": [
            "Answer '{question}' by querying both vector and knowledge graph sources. Merge results by relevance.",
            "Retrieve information about '{entity}' from {n_sources} sources and reconcile conflicting attributes.",
        ],
        "depth_adaptive_search": [
            "For the query '{question}', determine optimal search depth (shallow/medium/deep) based on query complexity.",
            "Start with a shallow search for '{query}'. If results are insufficient, iteratively deepen.",
        ],
        "source_routing": [
            "Route '{query}' to the optimal backend: vector store for semantic, KG for relational, SQL for structured.",
            "Given '{question}' about a financial entity, decide which sources to query and in what order.",
        ],
        "iterative_retrieval": [
            "Answer '{question}' using iterative retrieval: search, evaluate gaps, reformulate query, search again.",
            "Starting from '{initial_query}', refine through {max_iterations} iterations until confidence exceeds {threshold}.",
        ],
        "anti_retrieval_detection": [
            "Detect when retrieval is unnecessary: '{question}' can be answered from existing context without new search.",
            "Evaluate whether the context window already contains sufficient information to answer '{question}'.",
        ],
    },
    3: {
        "context_selection": [
            "Given {n_blocks} candidate context blocks, select the {budget_blocks} most relevant for answering '{question}'.",
            "Rank and select context blocks for '{task}' under a {budget_tokens}-token budget.",
        ],
        "context_ordering": [
            "Order {n_blocks} selected context blocks for maximum coherence when answering '{question}'.",
            "Arrange context from most to least foundational for '{task}', ensuring logical flow.",
        ],
        "budget_constrained_retrieval": [
            "Answer '{question}' using at most {budget_tokens} tokens of context. Compress if necessary.",
            "Construct a context window of exactly {budget_tokens} tokens from {n_candidates} candidates.",
        ],
        "context_compression": [
            "Compress {n_blocks} context blocks from {original_tokens} to {target_tokens} tokens while preserving key facts.",
            "Summarize {n_documents} documents into a single context block under {budget_tokens} tokens.",
        ],
        "multi_document_synthesis": [
            "Synthesize context from {n_documents} documents about '{topic}' into a coherent context window.",
            "Build a unified context from contradictory sources about '{entity}', noting conflicts.",
        ],
        "gap_detection": [
            "Identify missing information in the context for answering '{question}'. List retrieval queries to fill gaps.",
            "Given partial context about '{entity}', detect which critical facts are absent.",
        ],
    },
    4: {
        "multi_step_reasoning": [
            "Solve '{problem}' using multi-step reasoning. Show chain-of-thought and intermediate conclusions.",
            "Break '{complex_question}' into sub-questions, solve each, and synthesize a final answer.",
        ],
        "backtracking_recovery": [
            "Attempt to solve '{problem}'. If initial approach fails, backtrack and try alternative reasoning.",
            "Given an incorrect intermediate conclusion, detect the error and recover the reasoning chain.",
        ],
        "self_correction": [
            "Answer '{question}', then self-evaluate the answer. Correct any identified errors.",
            "Review your reasoning for '{task}': identify logical gaps and fix them before finalizing.",
        ],
        "hypothesis_testing": [
            "For '{observation}', generate {n_hypotheses} hypotheses and systematically test each against evidence.",
            "Given conflicting evidence about '{claim}', test the hypothesis by weighing supporting and opposing facts.",
        ],
        "evidence_synthesis": [
            "Ground your answer to '{question}' in specific evidence from the context. Cite sources.",
            "Synthesize evidence from {n_sources} sources to support or refute '{claim}'.",
        ],
        "contradiction_resolution": [
            "Resolve the contradiction between '{claim_a}' and '{claim_b}' using temporal, source, and confidence analysis.",
            "Two sources disagree on '{topic}'. Apply credibility assessment to determine the more reliable claim.",
        ],
    },
    5: {
        "few_shot_learning": [
            "Given {n_examples} examples of '{task_type}', adapt to solve a novel instance with no further guidance.",
            "Learn the pattern from {n_examples} demonstrations and apply it to '{new_task}'.",
        ],
        "domain_transfer": [
            "Apply skills learned in '{source_domain}' to solve a problem in '{target_domain}'.",
            "Transfer the reasoning pattern from '{source_task}' to '{target_task}' in a different domain.",
        ],
        "exploration_exploitation": [
            "Balance exploring new retrieval strategies vs exploiting known effective ones for '{task_type}'.",
            "Decide whether to try a novel reasoning approach or use the proven strategy for '{problem}'.",
        ],
        "self_pacing": [
            "Estimate the difficulty of '{task}' and adjust your reasoning depth accordingly.",
            "Self-assess readiness for '{advanced_task}'. If not ready, identify prerequisite skills to practice.",
        ],
        "strategy_adaptation": [
            "Your default strategy failed on '{task}'. Adapt your approach based on the failure mode.",
            "Select the optimal reasoning strategy for '{task_type}': deductive, inductive, abductive, or analogical.",
        ],
        "novel_task_generalization": [
            "Generalize from training on '{known_tasks}' to solve the novel task '{new_task}'.",
            "Apply learned meta-strategies to a task type never seen during training: '{novel_task}'.",
        ],
    },
    6: {
        "architecture_proposal": [
            "Propose a memory architecture optimized for '{domain}' with emphasis on '{capability}'.",
            "Design a memory schema for '{use_case}' that handles {n_memory_types} memory types efficiently.",
        ],
        "architecture_evaluation": [
            "Evaluate the fitness of architecture '{arch_name}' on tasks: {task_list}.",
            "Compare architectures '{arch_a}' and '{arch_b}' on {n_metrics} performance metrics.",
        ],
        "evolutionary_search": [
            "Evolve architecture '{parent}' with mutation rate {mutation_rate}. Generate {n_children} variants.",
            "Run {n_generations} generations of evolutionary search to optimize '{metric}' for '{domain}'.",
        ],
        "architecture_transfer": [
            "Transfer the architecture designed for '{source_domain}' to '{target_domain}'. Identify needed adaptations.",
            "Identify reusable components from '{source_arch}' applicable to '{target_domain}'.",
        ],
        "schema_design": [
            "Design a memory schema for '{domain}' that supports all 12 memory operations efficiently.",
            "Create an optimized indexing strategy for '{use_case}' balancing write and read performance.",
        ],
        "retrieval_design": [
            "Design a retrieval mechanism for '{domain}' that routes queries to {n_sources} source types.",
            "Create a hybrid retrieval strategy combining vector similarity and graph traversal for '{use_case}'.",
        ],
    },
    7: {
        "knowledge_sharing": [
            "Agent A has expertise in '{domain_a}' and Agent B in '{domain_b}'. Share relevant knowledge for '{task}'.",
            "Filter and share only task-relevant knowledge from your {n_entries} entries with Agent B.",
        ],
        "conflict_resolution": [
            "Agent A claims '{claim_a}' and Agent B claims '{claim_b}'. Resolve the conflict using evidence and trust.",
            "Mediate between {n_agents} agents with conflicting information about '{topic}'.",
        ],
        "shared_memory_construction": [
            "Construct shared memory from {n_agents} agents' individual knowledge bases for '{task}'.",
            "Merge overlapping memory entries from Agent A and Agent B, resolving duplicates.",
        ],
        "task_delegation": [
            "Assign '{task}' to the best-positioned agent among {n_agents} based on expertise profiles.",
            "Divide '{complex_task}' into sub-tasks and assign each to the agent with the most relevant expertise.",
        ],
        "expertise_routing": [
            "Route the query '{question}' to the agent with the highest expertise in '{domain}'.",
            "Evaluate whether to answer '{question}' yourself or defer to Agent B who has more experience in '{domain}'.",
        ],
        "multi_agent_retrieval": [
            "Coordinate retrieval across {n_agents} agents to answer '{question}'. Each agent searches its own store.",
            "Orchestrate parallel retrieval from {n_agents} agents and merge results for '{task}'.",
        ],
    },
}


# ---------------------------------------------------------------------------
# TrainingLevelManager
# ---------------------------------------------------------------------------


class TrainingLevelManager:
    """Manages the 7-level training capability hierarchy.

    Provides methods to query levels, determine an agent's current level
    from evaluation scores, check advancement eligibility, generate
    curriculum configurations, and produce level-appropriate training tasks.
    """

    def __init__(self, levels: list[TrainingLevel] | None = None) -> None:
        all_levels = levels if levels is not None else TRAINING_LEVELS
        self._levels: dict[int, TrainingLevel] = {level.level_id: level for level in all_levels}
        self._advancement_weights = dict(_LEVEL_ADVANCEMENT_WEIGHTS)
        self._task_templates = dict(_LEVEL_TASK_TEMPLATES)
        self._score_history: dict[str, dict[int, list[float]]] = {}

    # ------------------------------------------------------------------
    # Level queries
    # ------------------------------------------------------------------

    def get_level(self, level_id: int) -> TrainingLevel:
        """Get a training level by its ID.

        Args:
            level_id: Integer level identifier (1-7).

        Returns:
            The requested :class:`TrainingLevel`.

        Raises:
            KeyError: If *level_id* is not a valid level.
        """
        if level_id not in self._levels:
            raise KeyError(
                f"Unknown training level: {level_id}. Valid levels: {sorted(self._levels.keys())}"
            )
        return self._levels[level_id]

    def all_levels(self) -> list[TrainingLevel]:
        """Return all training levels in order.

        Returns:
            A list of :class:`TrainingLevel` objects sorted by level_id.
        """
        return sorted(self._levels.values(), key=lambda lv: lv.level_id)

    def get_prerequisites(self, level_id: int) -> list[TrainingLevel]:
        """Return the prerequisite levels for a given level.

        Args:
            level_id: The level to query prerequisites for.

        Returns:
            A list of prerequisite :class:`TrainingLevel` objects.
        """
        level = self.get_level(level_id)
        return [self._levels[pid] for pid in level.prerequisites if pid in self._levels]

    def are_prerequisites_met(self, level_id: int, completed_levels: set[int]) -> bool:
        """Check whether all prerequisites for a level are met.

        Args:
            level_id: The target level.
            completed_levels: Set of level IDs already completed.

        Returns:
            True if all prerequisites are in *completed_levels*.
        """
        level = self.get_level(level_id)
        return all(prereq in completed_levels for prereq in level.prerequisites)

    # ------------------------------------------------------------------
    # Current level determination
    # ------------------------------------------------------------------

    def get_current_level(self, metrics: dict[str, Any]) -> int:
        """Determine an agent's current training level from eval scores.

        Analyzes the eval scores to find the highest level where the
        agent meets the advancement threshold. The agent's level is one
        above the highest level they have passed.

        Args:
            metrics: Dictionary containing eval scores. Expected keys:
                - ``dimension_scores``: dict mapping dimension IDs to scores (0-1)
                - ``overall_score``: optional float for fallback
                - ``completed_levels``: optional set/list of completed level IDs

        Returns:
            The current training level (1-7).
        """
        dimension_scores = metrics.get("dimension_scores", {})
        overall_score = metrics.get("overall_score", 0.0)
        completed = set(metrics.get("completed_levels", []))

        if not dimension_scores and overall_score <= 0:
            return 1

        highest_passed = 0

        for level_id in sorted(self._levels.keys()):
            level = self._levels[level_id]

            # Check prerequisites
            if level.prerequisites and not all(p <= highest_passed for p in level.prerequisites):
                break

            # Compute weighted score for this level
            weights = self._advancement_weights.get(level_id, {})
            if weights:
                weighted_sum = 0.0
                total_weight = 0.0
                for dim, weight in weights.items():
                    if dim in dimension_scores:
                        weighted_sum += dimension_scores[dim] * weight
                        total_weight += weight
                    else:
                        # If dimension is missing, use overall_score as fallback
                        weighted_sum += overall_score * weight * 0.8
                        total_weight += weight

                level_score = weighted_sum / max(total_weight, 1e-6)
            else:
                level_score = overall_score

            if level_score >= level.min_score_to_advance or level_id in completed:
                highest_passed = level_id
            else:
                break

        # Current level is one above highest passed (capped at max level)
        current = min(highest_passed + 1, max(self._levels.keys()))
        return current

    # ------------------------------------------------------------------
    # Level advancement
    # ------------------------------------------------------------------

    def advance_level(self, current_level: int, eval_scores: dict[str, Any]) -> int | None:
        """Check if the agent is ready to advance and return the next level.

        Evaluates whether the agent's scores on the current level's eval
        dimensions meet the advancement threshold.

        Args:
            current_level: The agent's current level (1-7).
            eval_scores: Dictionary with keys:
                - ``dimension_scores``: dict mapping dimension IDs to scores
                - ``overall_score``: optional overall score
                - ``episodes_at_level``: optional int for minimum episode check

        Returns:
            The next level ID if the agent should advance, or None if not ready.
        """
        if current_level not in self._levels:
            return None

        level = self._levels[current_level]
        max_level = max(self._levels.keys())

        if current_level >= max_level:
            return None  # Already at maximum level

        dimension_scores = eval_scores.get("dimension_scores", {})
        overall_score = eval_scores.get("overall_score", 0.0)
        episodes = eval_scores.get("episodes_at_level", 0)

        # Must have trained for at least some episodes
        min_episodes = max(5, level.max_episodes // 100)
        if episodes < min_episodes:
            return None

        # Compute weighted score for current level
        weights = self._advancement_weights.get(current_level, {})
        if weights:
            weighted_sum = 0.0
            total_weight = 0.0
            dims_evaluated = 0

            for dim, weight in weights.items():
                if dim in dimension_scores:
                    weighted_sum += dimension_scores[dim] * weight
                    total_weight += weight
                    dims_evaluated += 1

            # Require at least half the dimensions to have scores
            if dims_evaluated < len(weights) / 2:
                if overall_score >= level.min_score_to_advance:
                    pass  # Allow advancement on overall score alone
                else:
                    return None

            level_score = (
                weighted_sum / max(total_weight, 1e-6) if total_weight > 0 else overall_score
            )
        else:
            level_score = overall_score

        if level_score >= level.min_score_to_advance:
            next_level = current_level + 1
            if next_level in self._levels:
                # Verify prerequisites for next level are met
                next_level_obj = self._levels[next_level]
                # The current level being passed means it counts as completed
                completed = set(range(1, current_level + 1))
                if all(p in completed for p in next_level_obj.prerequisites):
                    return next_level
            return None

        return None

    # ------------------------------------------------------------------
    # Record score history
    # ------------------------------------------------------------------

    def record_score(self, agent_id: str, level: int, score: float) -> dict[str, Any]:
        """Record a training score for an agent at a specific level.

        Args:
            agent_id: Unique agent identifier.
            level: The training level (1-7).
            score: The score to record (0-1).

        Returns:
            A summary dict with recent statistics and advancement status.
        """
        if agent_id not in self._score_history:
            self._score_history[agent_id] = {}
        if level not in self._score_history[agent_id]:
            self._score_history[agent_id][level] = []

        self._score_history[agent_id][level].append(score)
        scores = self._score_history[agent_id][level]

        recent_10 = scores[-10:]
        recent_mean = sum(recent_10) / len(recent_10)
        all_mean = sum(scores) / len(scores)

        level_obj = self._levels.get(level)
        ready_to_advance = recent_mean >= (level_obj.min_score_to_advance if level_obj else 0.7)

        return {
            "agent_id": agent_id,
            "level": level,
            "total_scores": len(scores),
            "recent_mean": round(recent_mean, 6),
            "all_time_mean": round(all_mean, 6),
            "ready_to_advance": ready_to_advance and len(scores) >= 5,
        }

    # ------------------------------------------------------------------
    # Curriculum configuration
    # ------------------------------------------------------------------

    def get_curriculum_config(self, level: int) -> dict[str, Any]:
        """Return curriculum configuration for a training level.

        Generates a complete curriculum config including difficulty
        distribution, operation set, context limits, and training
        hyperparameters tuned for the level.

        Args:
            level: The training level (1-7).

        Returns:
            A dictionary with curriculum configuration.
        """
        level_obj = self.get_level(level)

        # Difficulty distribution shifts harder at higher levels
        diff_min, diff_max = level_obj.difficulty_range
        easy_weight = max(0.0, 0.5 - (level - 1) * 0.08)
        medium_weight = max(0.1, 0.35 - (level - 1) * 0.03)
        hard_weight = min(0.5, 0.1 + (level - 1) * 0.07)
        adversarial_weight = min(0.3, max(0.0, (level - 2) * 0.07))
        multi_session_weight = min(0.2, max(0.0, (level - 3) * 0.05))

        # Normalize
        total = (
            easy_weight + medium_weight + hard_weight + adversarial_weight + multi_session_weight
        )
        if total > 0:
            easy_weight /= total
            medium_weight /= total
            hard_weight /= total
            adversarial_weight /= total
            multi_session_weight /= total

        # Context and step limits scale with level
        max_context_tokens = 2048 * (2 ** min(level - 1, 4))
        max_steps = 5 + (level - 1) * 3
        max_retrieval_depth = min(level + 1, 5)

        # Learning rate decreases at higher levels (more subtle learning)
        base_lr = 1e-5
        lr_multiplier = max(0.1, 1.0 - (level - 1) * 0.12)

        return {
            "level": level,
            "level_name": level_obj.name,
            "description": level_obj.description,
            "difficulty_range": level_obj.difficulty_range,
            "difficulty_distribution": {
                "easy": round(easy_weight, 4),
                "medium": round(medium_weight, 4),
                "hard": round(hard_weight, 4),
                "adversarial": round(adversarial_weight, 4),
                "multi_session": round(multi_session_weight, 4),
            },
            "operations_unlocked": level_obj.operations_unlocked,
            "eval_dimensions": level_obj.eval_dimensions,
            "task_types": level_obj.task_types,
            "max_context_tokens": max_context_tokens,
            "max_steps": max_steps,
            "max_retrieval_depth": max_retrieval_depth,
            "learning_rate": round(base_lr * lr_multiplier, 8),
            "min_score_to_advance": level_obj.min_score_to_advance,
            "max_episodes": level_obj.max_episodes,
            "group_size": max(4, 8 - (level - 1)),
            "kl_coeff": round(0.05 + (level - 1) * 0.005, 4),
            "replay_mix_ratio": round(min(0.3, 0.1 + (level - 1) * 0.03), 4),
            "prerequisites": level_obj.prerequisites,
        }

    # ------------------------------------------------------------------
    # Task generation
    # ------------------------------------------------------------------

    def generate_level_tasks(self, level: int, count: int) -> list[dict[str, Any]]:
        """Generate training tasks appropriate for a specific level.

        Produces tasks that exercise the capabilities trained at this
        level, with difficulty and complexity matching the level's
        configuration.

        Args:
            level: The training level (1-7).
            count: Number of tasks to generate.

        Returns:
            A list of task dictionaries.
        """
        level_obj = self.get_level(level)
        templates = self._task_templates.get(level, {})
        diff_min, diff_max = level_obj.difficulty_range

        tasks: list[dict[str, Any]] = []

        for i in range(count):
            seed = f"level_task:{level}:{i}"

            # Pick a task type
            task_type = _det_choice(f"task_type:{seed}", level_obj.task_types)

            # Pick a template if available
            type_templates = templates.get(task_type, [])
            if type_templates:
                template = _det_choice(f"template:{seed}", type_templates)
            else:
                template = f"[Level {level}: {level_obj.name}] Perform {task_type} task."

            # Fill in template variables with deterministic values
            prompt = self._fill_template(template, seed, level_obj)

            # Determine difficulty within range
            difficulty = _det_int(f"difficulty:{seed}", diff_min, diff_max)

            # Select relevant operations
            n_ops = _det_int(f"n_ops:{seed}", 1, min(4, len(level_obj.operations_unlocked)))
            ops = _det_sample(f"ops:{seed}", level_obj.operations_unlocked, n_ops)

            # Select eval dimensions to test
            n_dims = _det_int(f"n_dims:{seed}", 1, min(3, len(level_obj.eval_dimensions)))
            dims = _det_sample(f"dims:{seed}", level_obj.eval_dimensions, n_dims)

            task: dict[str, Any] = {
                "id": str(uuid.uuid4()),
                "level": level,
                "level_name": level_obj.name,
                "task_type": task_type,
                "prompt": prompt,
                "difficulty": difficulty,
                "operations_required": ops,
                "eval_dimensions": dims,
                "capabilities_tested": _det_sample(
                    f"caps:{seed}",
                    level_obj.capabilities,
                    min(3, len(level_obj.capabilities)),
                ),
                "context": {
                    "level": level,
                    "task_type": task_type,
                    "difficulty": difficulty,
                    "max_steps": 5 + (level - 1) * 3,
                },
                "expected": {
                    "min_operations": len(ops),
                    "min_evidence_sources": difficulty,
                    "requires_backtracking": level >= 4,
                    "requires_multi_agent": level >= 7,
                },
                "metadata": {
                    "seed": seed,
                    "generator": "TrainingLevelManager",
                    "level_min_score": level_obj.min_score_to_advance,
                },
            }

            tasks.append(task)

        return tasks

    def _fill_template(self, template: str, seed: str, level: TrainingLevel) -> str:
        """Fill template placeholders with deterministic values.

        Args:
            template: A template string with curly-brace placeholders.
            seed: Seed for deterministic generation.
            level: The training level context.

        Returns:
            The filled template string.
        """
        entities = ["Acme Corp", "TechVentures", "GlobalFin", "MedTech Inc", "DataFlow"]
        domains_a = ["legal", "finance", "healthcare", "technology", "energy"]
        domains_b = ["compliance", "risk management", "operations", "strategy", "research"]
        facts = [
            "The quarterly revenue was $142.3M",
            "The contract expires on March 31, 2025",
            "The merger was approved by regulators on January 15",
            "The patent filing covers neural architecture innovations",
            "The compliance audit found 3 material weaknesses",
        ]
        sources = [
            "SEC filing",
            "internal memo",
            "audit report",
            "press release",
            "expert testimony",
        ]
        questions = [
            "What are the key financial metrics for this quarter?",
            "How does this clause affect the contractual obligations?",
            "What is the timeline for regulatory approval?",
            "Which documents support this conclusion?",
            "What are the risk factors identified in the assessment?",
        ]
        topics = [
            "merger terms",
            "patent portfolio",
            "risk exposure",
            "compliance status",
            "revenue recognition",
        ]
        claims = [
            "Revenue grew 15% year-over-year",
            "The indemnification clause is unenforceable",
            "EBITDA exceeds the covenant threshold",
            "The audit findings are immaterial",
            "The patent does not infringe on prior art",
        ]
        tasks = [
            "financial analysis",
            "contract review",
            "risk assessment",
            "compliance checking",
            "document reconciliation",
        ]
        problems = [
            "Reconcile conflicting financial statements",
            "Determine which version of the contract is controlling",
            "Assess regulatory exposure from the audit findings",
            "Evaluate whether the earn-out threshold was met",
            "Determine materiality of the disclosed settlement",
        ]

        # Build replacement map
        replacements: dict[str, str] = {
            "entity": _det_choice(f"entity:{seed}", entities),
            "fact": _det_choice(f"fact:{seed}", facts),
            "source": _det_choice(f"source:{seed}", sources),
            "question": _det_choice(f"question:{seed}", questions),
            "query": _det_choice(f"query:{seed}", questions),
            "initial_query": _det_choice(f"initial_query:{seed}", questions),
            "topic": _det_choice(f"topic:{seed}", topics),
            "claim": _det_choice(f"claim:{seed}", claims),
            "claim_a": _det_choice(f"claim_a:{seed}", claims),
            "claim_b": _det_choice(f"claim_b:{seed}", claims[1:] + claims[:1]),
            "task": _det_choice(f"task:{seed}", tasks),
            "task_type": _det_choice(f"task_type_tpl:{seed}", tasks),
            "complex_question": _det_choice(f"complex_q:{seed}", problems),
            "problem": _det_choice(f"problem:{seed}", problems),
            "observation": _det_choice(f"observation:{seed}", facts),
            "advanced_task": _det_choice(f"advanced:{seed}", problems),
            "novel_task": _det_choice(f"novel:{seed}", problems),
            "new_task": _det_choice(f"new_task:{seed}", tasks),
            "domain": _det_choice(f"domain:{seed}", domains_a),
            "domain_a": _det_choice(f"domain_a:{seed}", domains_a),
            "domain_b": _det_choice(f"domain_b:{seed}", domains_b),
            "source_domain": _det_choice(f"src_domain:{seed}", domains_a),
            "target_domain": _det_choice(f"tgt_domain:{seed}", domains_a[1:] + domains_a[:1]),
            "source_task": _det_choice(f"src_task:{seed}", tasks),
            "target_task": _det_choice(f"tgt_task:{seed}", tasks[1:] + tasks[:1]),
            "capability": _det_choice(f"cap:{seed}", level.capabilities),
            "use_case": _det_choice(f"use_case:{seed}", tasks),
            "arch_name": f"arch-{_det_int(f'arch:{seed}', 1, 100)}",
            "parent": f"arch-{_det_int(f'parent:{seed}', 1, 50)}",
            "arch_a": f"arch-{_det_int(f'arch_a:{seed}', 1, 50)}",
            "arch_b": f"arch-{_det_int(f'arch_b:{seed}', 51, 100)}",
            "source_arch": f"arch-{_det_int(f'src_arch:{seed}', 1, 50)}",
            "metric": _det_choice(
                f"metric:{seed}", ["recall", "precision", "latency", "throughput"]
            ),
            "key": _det_choice(
                f"key:{seed}", ["ceo_name", "revenue_q1", "contract_expiry", "risk_rating"]
            ),
            "old_value": _det_choice(
                f"old_val:{seed}", ["John Smith", "$142.3M", "March 2025", "High"]
            ),
            "new_value": _det_choice(
                f"new_val:{seed}", ["Jane Doe", "$156.7M", "June 2025", "Medium"]
            ),
            "attributes": "industry: technology, founded: 2015, headquarters: Boston",
            "pattern": "accessed 5 times in last hour, decreasing trend",
            "n_sources": str(_det_int(f"n_sources:{seed}", 2, 5)),
            "n_blocks": str(_det_int(f"n_blocks:{seed}", 5, 20)),
            "n_candidates": str(_det_int(f"n_cands:{seed}", 10, 30)),
            "n_documents": str(_det_int(f"n_docs:{seed}", 3, 8)),
            "n_events": str(_det_int(f"n_events:{seed}", 5, 15)),
            "n_entries": str(_det_int(f"n_entries:{seed}", 10, 50)),
            "n_examples": str(_det_int(f"n_examples:{seed}", 2, 5)),
            "n_hypotheses": str(_det_int(f"n_hyp:{seed}", 2, 4)),
            "n_agents": str(_det_int(f"n_agents:{seed}", 2, 5)),
            "n_memory_types": str(_det_int(f"n_mem:{seed}", 3, 7)),
            "n_metrics": str(_det_int(f"n_metrics:{seed}", 3, 6)),
            "n_children": str(_det_int(f"n_children:{seed}", 3, 8)),
            "n_generations": str(_det_int(f"n_gen:{seed}", 5, 20)),
            "budget_tokens": str(_det_int(f"budget:{seed}", 1024, 8192)),
            "budget_blocks": str(_det_int(f"budget_b:{seed}", 3, 8)),
            "original_tokens": str(_det_int(f"orig_tok:{seed}", 4096, 16384)),
            "target_tokens": str(_det_int(f"tgt_tok:{seed}", 1024, 4096)),
            "max_iterations": str(_det_int(f"max_iter:{seed}", 3, 7)),
            "threshold": str(round(_det_float(f"threshold:{seed}", 0.7, 0.95), 2)),
            "frequency": str(_det_int(f"freq:{seed}", 3, 20)),
            "mutation_rate": str(round(_det_float(f"mut:{seed}", 0.05, 0.3), 2)),
            "known_tasks": ", ".join(_det_sample(f"known:{seed}", tasks, 3)),
            "task_list": ", ".join(_det_sample(f"tasklist:{seed}", tasks, 3)),
        }

        result = template
        for key, value in replacements.items():
            placeholder = "{" + key + "}"
            result = result.replace(placeholder, value)

        return result

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary of all training levels and recorded scores.

        Returns:
            A dictionary with level info, score history, and status.
        """
        levels_summary = []
        for level in sorted(self._levels.values(), key=lambda lv: lv.level_id):
            levels_summary.append(
                {
                    "level_id": level.level_id,
                    "name": level.name,
                    "capabilities_count": len(level.capabilities),
                    "prerequisites": level.prerequisites,
                    "difficulty_range": level.difficulty_range,
                    "operations_count": len(level.operations_unlocked),
                    "eval_dimensions_count": len(level.eval_dimensions),
                    "task_types_count": len(level.task_types),
                    "min_score_to_advance": level.min_score_to_advance,
                }
            )

        agents_summary: dict[str, Any] = {}
        for agent_id, level_scores in self._score_history.items():
            agent_levels: dict[str, Any] = {}
            for lvl, scores in level_scores.items():
                recent = scores[-10:]
                agent_levels[str(lvl)] = {
                    "total_scores": len(scores),
                    "recent_mean": round(sum(recent) / len(recent), 6),
                    "all_time_mean": round(sum(scores) / len(scores), 6),
                }
            agents_summary[agent_id] = agent_levels

        return {
            "total_levels": len(self._levels),
            "levels": levels_summary,
            "agents_tracked": len(self._score_history),
            "agents": agents_summary,
        }
