"""Training-evaluation feedback loop callback.

Provides :class:`EvalCallback` that runs evaluation during training
at configurable intervals, feeding results back into the curriculum
engine for dynamic difficulty adjustment and level progression.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class EvalResult:
    """Result from a single evaluation checkpoint during training."""

    episode: int
    mean_score: float
    dimension_scores: dict[str, float] = field(default_factory=dict)
    weak_dimensions: list[str] = field(default_factory=list)
    strong_dimensions: list[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now(tz=UTC).isoformat())


class EvalCallback:
    """Callback that runs evaluation during training and feeds results back.

    Integrates with :class:`CurriculumEngine` to dynamically adjust
    training based on eval performance.

    Args:
        eval_fn: Function that takes a list of eval cases and returns
            a dict with ``mean_score`` and optional ``dimension_scores``.
        eval_cases: Cases to evaluate on.
        eval_interval: Run eval every N episodes.
        curriculum_engine: Optional CurriculumEngine for feedback.
        agent_id: Agent identifier for curriculum tracking.
        weakness_threshold: Dimensions below this score are "weak".
        strength_threshold: Dimensions above this score are "strong".
    """

    def __init__(
        self,
        eval_fn: Callable[[list[dict[str, Any]]], dict[str, Any]],
        eval_cases: list[dict[str, Any]] | None = None,
        eval_interval: int = 10,
        curriculum_engine: Any = None,
        agent_id: str = "default",
        weakness_threshold: float = 0.5,
        strength_threshold: float = 0.8,
    ) -> None:
        self._eval_fn = eval_fn
        self._eval_cases = eval_cases or []
        self._eval_interval = max(1, eval_interval)
        self._curriculum = curriculum_engine
        self._agent_id = agent_id
        self._weakness_threshold = weakness_threshold
        self._strength_threshold = strength_threshold
        self._history: list[EvalResult] = []
        self._weight_adjustments: dict[str, float] = {}

    @property
    def history(self) -> list[EvalResult]:
        """Return evaluation history."""
        return list(self._history)

    @property
    def weight_adjustments(self) -> dict[str, float]:
        """Return current dimension weight adjustments."""
        return dict(self._weight_adjustments)

    def should_eval(self, episode: int) -> bool:
        """Check if evaluation should run at this episode."""
        return episode % self._eval_interval == 0

    def __call__(self, episode: int, metrics: dict[str, Any]) -> EvalResult | None:
        """Called after each training episode.

        Runs evaluation if at the right interval, updates curriculum,
        and computes weight adjustments for weak areas.

        Args:
            episode: Current episode number.
            metrics: Training metrics from the episode.

        Returns:
            EvalResult if evaluation was run, None otherwise.
        """
        if not self.should_eval(episode):
            return None

        if not self._eval_cases:
            return None

        try:
            eval_result = self._eval_fn(self._eval_cases)
        except Exception as exc:
            logger.warning("Eval callback failed at episode %d: %s", episode, exc)
            return None

        mean_score = eval_result.get("mean_score", 0.0)
        dimension_scores = eval_result.get("per_dimension", {})
        if not dimension_scores:
            dimension_scores = eval_result.get("dimension_scores", {})

        # Identify weak and strong dimensions
        weak = [d for d, s in dimension_scores.items() if s < self._weakness_threshold]
        strong = [d for d, s in dimension_scores.items() if s >= self._strength_threshold]

        result = EvalResult(
            episode=episode,
            mean_score=mean_score,
            dimension_scores=dimension_scores,
            weak_dimensions=weak,
            strong_dimensions=strong,
        )
        self._history.append(result)

        # Feed score to curriculum engine
        if self._curriculum:
            self._curriculum.record_score(self._agent_id, mean_score)

        # Compute weight adjustments — boost weak dimensions
        self._update_weights(dimension_scores)

        logger.info(
            "Eval at episode %d: mean=%.4f, weak=%d, strong=%d",
            episode,
            mean_score,
            len(weak),
            len(strong),
        )

        return result

    def _update_weights(self, dimension_scores: dict[str, float]) -> None:
        """Update dimension weight adjustments based on eval scores.

        Dimensions where the agent is weak get higher training weight
        to focus improvement on those areas.
        """
        if not dimension_scores:
            return

        mean_score = sum(dimension_scores.values()) / len(dimension_scores)

        for dim_id, score in dimension_scores.items():
            gap = mean_score - score
            if gap > 0:
                # Weak dimension: boost weight proportional to gap
                self._weight_adjustments[dim_id] = 1.0 + min(gap * 2.0, 1.0)
            else:
                # Strong dimension: slightly reduce weight
                self._weight_adjustments[dim_id] = max(0.5, 1.0 + gap * 0.5)

    def get_training_emphasis(self) -> dict[str, Any]:
        """Return training emphasis based on recent eval results.

        Provides guidance on which dimensions/operations to emphasize
        in the next training episodes.
        """
        if not self._history:
            return {"emphasis": "balanced", "adjustments": {}}

        latest = self._history[-1]

        # Trend analysis: compare to previous eval
        improving = []
        declining = []
        if len(self._history) >= 2:
            prev = self._history[-2]
            for dim_id in latest.dimension_scores:
                curr_score = latest.dimension_scores.get(dim_id, 0)
                prev_score = prev.dimension_scores.get(dim_id, 0)
                delta = curr_score - prev_score
                if delta > 0.05:
                    improving.append(dim_id)
                elif delta < -0.05:
                    declining.append(dim_id)

        return {
            "emphasis": "weakness_focused" if latest.weak_dimensions else "balanced",
            "weak_dimensions": latest.weak_dimensions,
            "strong_dimensions": latest.strong_dimensions,
            "improving": improving,
            "declining": declining,
            "weight_adjustments": dict(self._weight_adjustments),
            "mean_score": latest.mean_score,
        }

    def summary(self) -> dict[str, Any]:
        """Return callback summary statistics."""
        if not self._history:
            return {
                "total_evals": 0,
                "eval_interval": self._eval_interval,
            }

        scores = [r.mean_score for r in self._history]
        return {
            "total_evals": len(self._history),
            "eval_interval": self._eval_interval,
            "latest_score": scores[-1],
            "best_score": max(scores),
            "score_trend": scores[-5:],
            "total_weak_dims": len(self._history[-1].weak_dimensions),
            "total_strong_dims": len(self._history[-1].strong_dimensions),
        }
