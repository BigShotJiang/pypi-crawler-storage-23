"""Checkpoint manager for training state persistence."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast


@dataclass
class Checkpoint:
    """A saved training checkpoint."""

    id: str
    run_id: str
    step: int
    path: str
    metrics: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


class CheckpointManager:
    """Manages training checkpoints with save, restore, and rollback.

    Provides a registry of checkpoints per training run with
    the ability to save state, restore from any checkpoint, and
    rollback to a previous checkpoint.
    """

    def __init__(self, base_dir: str = "./checkpoints") -> None:
        self._base_dir = Path(base_dir)
        self._checkpoints: dict[str, list[Checkpoint]] = {}  # run_id -> checkpoints
        self._active_checkpoint: dict[str, str] = {}  # run_id -> checkpoint_id

    def save(
        self,
        run_id: str,
        step: int,
        state: dict[str, Any],
        metrics: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Checkpoint:
        """Save a training checkpoint."""
        ckpt_id = f"{run_id}_step_{step}"
        ckpt_dir = self._base_dir / run_id
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        ckpt_path = ckpt_dir / f"checkpoint_{step}.json"

        # Write state to file
        ckpt_path.write_text(json.dumps(state, indent=2, default=str))

        checkpoint = Checkpoint(
            id=ckpt_id,
            run_id=run_id,
            step=step,
            path=str(ckpt_path),
            metrics=metrics or {},
            metadata=metadata or {},
        )

        if run_id not in self._checkpoints:
            self._checkpoints[run_id] = []
        self._checkpoints[run_id].append(checkpoint)
        self._active_checkpoint[run_id] = ckpt_id

        return checkpoint

    def restore(self, run_id: str, checkpoint_id: str | None = None) -> dict[str, Any] | None:
        """Restore state from a checkpoint. Uses latest if no ID specified."""
        checkpoints = self._checkpoints.get(run_id, [])
        if not checkpoints:
            return None

        if checkpoint_id:
            ckpt = next((c for c in checkpoints if c.id == checkpoint_id), None)
        else:
            ckpt = checkpoints[-1]

        if not ckpt:
            return None

        path = Path(ckpt.path)
        if not path.exists():
            return None

        state_raw = json.loads(path.read_text())
        if not isinstance(state_raw, dict):
            return None
        self._active_checkpoint[run_id] = ckpt.id
        return cast("dict[str, Any]", state_raw)

    def rollback(self, run_id: str, to_step: int | None = None) -> Checkpoint | None:
        """Rollback to a previous checkpoint.

        If to_step is None, rolls back to the second-to-last checkpoint.
        """
        checkpoints = self._checkpoints.get(run_id, [])
        if not checkpoints:
            return None

        if to_step is not None:
            target = next((c for c in checkpoints if c.step == to_step), None)
        elif len(checkpoints) >= 2:
            target = checkpoints[-2]
        else:
            return None

        if not target:
            return None

        # Remove checkpoints after the target
        self._checkpoints[run_id] = [c for c in checkpoints if c.step <= target.step]
        self._active_checkpoint[run_id] = target.id
        return target

    def list_checkpoints(self, run_id: str) -> list[Checkpoint]:
        """List all checkpoints for a run."""
        return list(self._checkpoints.get(run_id, []))

    def latest(self, run_id: str) -> Checkpoint | None:
        """Get the latest checkpoint for a run."""
        checkpoints = self._checkpoints.get(run_id, [])
        return checkpoints[-1] if checkpoints else None

    def active(self, run_id: str) -> Checkpoint | None:
        """Get the currently active checkpoint for a run."""
        ckpt_id = self._active_checkpoint.get(run_id)
        if not ckpt_id:
            return None
        checkpoints = self._checkpoints.get(run_id, [])
        return next((c for c in checkpoints if c.id == ckpt_id), None)

    def cleanup(self, run_id: str, keep_last: int = 5) -> int:
        """Remove old checkpoints, keeping the last N."""
        checkpoints = self._checkpoints.get(run_id, [])
        if len(checkpoints) <= keep_last:
            return 0

        to_remove = checkpoints[:-keep_last]
        for ckpt in to_remove:
            path = Path(ckpt.path)
            if path.exists():
                path.unlink()

        self._checkpoints[run_id] = checkpoints[-keep_last:]
        return len(to_remove)

    def summary(self) -> dict[str, Any]:
        """Return checkpoint manager summary."""
        return {
            "total_runs": len(self._checkpoints),
            "total_checkpoints": sum(len(c) for c in self._checkpoints.values()),
            "runs": {
                run_id: {
                    "checkpoints": len(ckpts),
                    "latest_step": ckpts[-1].step if ckpts else 0,
                }
                for run_id, ckpts in self._checkpoints.items()
            },
        }
