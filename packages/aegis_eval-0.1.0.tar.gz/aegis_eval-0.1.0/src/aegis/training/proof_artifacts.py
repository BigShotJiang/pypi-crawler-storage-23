"""Helpers for building reproducible GPU training proof artifacts.

This module normalizes eval outputs and training metadata into a compact
artifact bundle consumed by release and benchmarking runbooks.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class EvalArtifactSummary:
    """Normalized summary of a single eval run."""

    run_id: str
    overall_score: float
    dimension_scores: dict[str, float]
    tier_scores: dict[str, float]
    source_file: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _as_float(value: object, default: float = 0.0) -> float:
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


def _as_float_mapping(value: object) -> dict[str, float]:
    if not isinstance(value, dict):
        return {}
    return {str(k): _as_float(v) for k, v in value.items()}


def load_eval_artifact(path: str | Path) -> EvalArtifactSummary:
    """Load and normalize an eval JSON artifact.

    The loader accepts either:
    1. A full ``EvalResult`` payload written by ``aegis eval run``.
    2. A pre-normalized object containing ``run_id``/``overall_score``.
    """

    source = Path(path)
    raw = json.loads(source.read_text(encoding="utf-8"))

    # Some wrappers may nest the actual result payload.
    payload: object = raw.get("result", raw) if isinstance(raw, dict) else raw
    data = payload if isinstance(payload, dict) else {}

    run_id = str(data.get("run_id") or data.get("id") or source.stem)
    overall = _as_float(data.get("overall_score"))
    dimensions = _as_float_mapping(data.get("dimension_scores"))
    tiers = _as_float_mapping(data.get("tier_scores"))

    return EvalArtifactSummary(
        run_id=run_id,
        overall_score=overall,
        dimension_scores=dimensions,
        tier_scores=tiers,
        source_file=str(source),
    )


def build_delta_report(
    baseline: EvalArtifactSummary,
    trained: EvalArtifactSummary,
) -> dict[str, Any]:
    """Build a baseline-vs-trained delta report."""

    dimension_keys = sorted(set(baseline.dimension_scores) | set(trained.dimension_scores))
    tier_keys = sorted(set(baseline.tier_scores) | set(trained.tier_scores))

    dimension_deltas = {
        key: round(
            trained.dimension_scores.get(key, 0.0) - baseline.dimension_scores.get(key, 0.0), 6
        )
        for key in dimension_keys
    }
    tier_deltas = {
        key: round(trained.tier_scores.get(key, 0.0) - baseline.tier_scores.get(key, 0.0), 6)
        for key in tier_keys
    }

    overall_delta = round(trained.overall_score - baseline.overall_score, 6)

    top_dimension_gains = sorted(
        dimension_deltas.items(),
        key=lambda item: item[1],
        reverse=True,
    )[:10]

    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "baseline_run_id": baseline.run_id,
        "trained_run_id": trained.run_id,
        "baseline_overall_score": round(baseline.overall_score, 6),
        "trained_overall_score": round(trained.overall_score, 6),
        "overall_delta": overall_delta,
        "dimension_deltas": dimension_deltas,
        "tier_deltas": tier_deltas,
        "top_dimension_gains": [
            {"dimension": dimension, "delta": delta} for dimension, delta in top_dimension_gains
        ],
    }


def build_adapter_manifest(
    *,
    training_result: dict[str, Any] | None,
    adapter_path: str | None,
    config_path: str | None,
) -> dict[str, Any]:
    """Build manifest metadata for the produced adapter."""

    payload = training_result or {}
    resolved_adapter = adapter_path or str(payload.get("adapter_path", ""))

    return {
        "generated_at": datetime.now(UTC).isoformat(),
        "run_id": str(payload.get("run_id", "")),
        "backend": str(payload.get("backend", "unknown")),
        "status": str(payload.get("status", "unknown")),
        "model_name": str(payload.get("config", {}).get("model_name", "")),
        "domain": str(payload.get("config", {}).get("domain", "")),
        "adapter_path": resolved_adapter,
        "training_config": config_path,
        "metrics": {
            "mean_reward": _as_float(payload.get("mean_reward")),
            "best_reward": _as_float(payload.get("best_reward")),
            "final_loss": _as_float(payload.get("final_loss")),
            "kl_divergence": _as_float(payload.get("kl_divergence")),
            "total_steps": int(_as_float(payload.get("total_steps"))),
        },
    }


def write_json(path: str | Path, payload: dict[str, Any]) -> None:
    """Write JSON payload with stable formatting."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
