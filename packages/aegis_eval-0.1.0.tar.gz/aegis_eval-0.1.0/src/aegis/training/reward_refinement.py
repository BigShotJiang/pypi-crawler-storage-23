"""Recursive reward refinement for the AMIR-GRPO training loop.

After each training stage, analyses reward traces to identify noisy or
weak stages, then adjusts per-stage reward weights via exponential
moving average (EMA) blending.  Iterates until convergence or a
maximum number of refinement iterations is reached.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.core.types import RewardTraceV1
from aegis.training.rewards import RewardEngine, RewardStageConfig

logger = logging.getLogger(__name__)

__all__ = [
    "RefinementAnalysis",
    "RefinementRecord",
    "RecursiveRewardRefiner",
]

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class RefinementAnalysis:
    """Result of analysing reward traces for a single refinement step.

    Attributes:
        stage_variances: Per-stage score variance across traces.
        stage_mean_scores: Per-stage mean weighted score.
        suggested_weights: Proposed new weights for each stage.
        convergence_score: Maximum absolute weight change from this step.
    """

    stage_variances: dict[str, float] = field(default_factory=dict)
    stage_mean_scores: dict[str, float] = field(default_factory=dict)
    suggested_weights: dict[str, float] = field(default_factory=dict)
    convergence_score: float = 1.0


@dataclass
class RefinementRecord:
    """A single refinement iteration record.

    Attributes:
        iteration: The refinement iteration index.
        adjustments: Per-stage weight adjustments applied.
        convergence_score: Convergence metric for this iteration.
        timestamp: When this refinement was performed.
    """

    iteration: int
    adjustments: dict[str, float] = field(default_factory=dict)
    convergence_score: float = 1.0
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# RecursiveRewardRefiner
# ---------------------------------------------------------------------------


class RecursiveRewardRefiner:
    """Iteratively refine reward stage weights based on training traces.

    Algorithm:
        1. Collect reward traces from a completed stage.
        2. Compute per-stage variance (high variance = noisy signal).
        3. Compute per-stage mean score (low mean = weak area).
        4. Derive new weights by up-weighting noisy and weak stages.
        5. Blend new weights with previous via EMA.
        6. Normalise weights to sum to 1.0.
        7. Check convergence (max |delta| < threshold).

    Args:
        max_iterations: Maximum refinement iterations before stopping.
        convergence_threshold: Stop when all weight deltas are below this.
        blend_weight: EMA blend factor (0 = keep old, 1 = use new).
        min_traces: Minimum trace count before refinement activates.
    """

    def __init__(
        self,
        max_iterations: int = 5,
        convergence_threshold: float = 0.01,
        blend_weight: float = 0.3,
        min_traces: int = 50,
    ) -> None:
        self._max_iterations = max_iterations
        self._convergence_threshold = convergence_threshold
        self._blend_weight = blend_weight
        self._min_traces = min_traces
        self._history: list[RefinementRecord] = []
        self._iteration = 0
        self._collected_traces: list[RewardTraceV1] = []

    # -- public API ----------------------------------------------------------

    def analyze_traces(self, traces: list[RewardTraceV1]) -> RefinementAnalysis:
        """Analyse reward traces and compute per-stage statistics.

        For each stage present in the traces, computes the mean weighted
        score and variance across all traces.

        Args:
            traces: List of reward traces to analyse.

        Returns:
            A :class:`RefinementAnalysis` with stage statistics.
        """
        stage_scores: dict[str, list[float]] = {}

        for trace in traces:
            for stage_reward in trace.stages:
                name = stage_reward.stage_name
                stage_scores.setdefault(name, []).append(stage_reward.weighted_score)

        variances: dict[str, float] = {}
        means: dict[str, float] = {}

        for name, scores in stage_scores.items():
            n = len(scores)
            if n == 0:
                variances[name] = 0.0
                means[name] = 0.0
                continue
            mean = sum(scores) / n
            variance = sum((s - mean) ** 2 for s in scores) / n
            means[name] = round(mean, 6)
            variances[name] = round(variance, 6)

        return RefinementAnalysis(
            stage_variances=variances,
            stage_mean_scores=means,
            suggested_weights={},
            convergence_score=1.0,
        )

    def compute_adjustments(
        self,
        analysis: RefinementAnalysis,
        current_configs: list[RewardStageConfig],
    ) -> dict[str, float]:
        """Compute new stage weights from analysis and current config.

        Up-weights stages that have high variance (noisy signal) or low
        mean score (weak area), then normalises to sum to 1.0 and blends
        with the current weights via EMA.

        Args:
            analysis: Output from :meth:`analyze_traces`.
            current_configs: Current reward stage configurations.

        Returns:
            A dict mapping stage name to the new blended weight.
        """
        if not current_configs:
            return {}

        raw_weights: dict[str, float] = {}

        for cfg in current_configs:
            name = cfg.stage_name
            variance = analysis.stage_variances.get(name, 0.0)
            mean_score = analysis.stage_mean_scores.get(name, 0.5)

            # High variance → up-weight (noisy signal needs more emphasis)
            variance_factor = 1.0 + variance * 2.0
            # Low mean → up-weight (weak area needs more training pressure)
            gap_factor = 1.0 + max(0.0, 0.7 - mean_score)

            raw_weights[name] = cfg.weight * variance_factor * gap_factor

        # Normalise raw weights to sum to 1.0
        total = sum(raw_weights.values())
        if total > 0:
            normalised = {k: v / total for k, v in raw_weights.items()}
        else:
            n = len(raw_weights)
            normalised = {k: 1.0 / n for k in raw_weights}

        # EMA blend: w_new = blend * w_computed + (1-blend) * w_old
        blended: dict[str, float] = {}
        for cfg in current_configs:
            name = cfg.stage_name
            new_w = normalised.get(name, cfg.weight)
            blended[name] = round(
                self._blend_weight * new_w + (1.0 - self._blend_weight) * cfg.weight,
                6,
            )

        # Re-normalise after blending
        blend_total = sum(blended.values())
        if blend_total > 0:
            blended = {k: round(v / blend_total, 6) for k, v in blended.items()}

        return blended

    def apply_refinement(self, engine: RewardEngine) -> RewardEngine:
        """Run a single refinement cycle and update engine stage weights.

        Collects traces from the engine's history, computes adjustments,
        and mutates the engine's stage configs in place.

        Args:
            engine: The reward engine whose weights to refine.

        Returns:
            The same engine instance with updated weights.
        """
        traces = engine.history(limit=500)
        all_traces = self._collected_traces + traces

        if len(all_traces) < self._min_traces:
            logger.debug(
                "Skipping refinement: only %d traces (need %d)",
                len(all_traces),
                self._min_traces,
            )
            return engine

        analysis = self.analyze_traces(all_traces)
        current_configs = engine.stages
        new_weights = self.compute_adjustments(analysis, current_configs)

        if not new_weights:
            return engine

        # Compute convergence score (max absolute delta)
        max_delta = 0.0
        adjustments: dict[str, float] = {}
        for cfg in engine.stages:
            old_w = cfg.weight
            new_w = new_weights.get(cfg.stage_name, old_w)
            delta = abs(new_w - old_w)
            max_delta = max(max_delta, delta)
            adjustments[cfg.stage_name] = round(new_w - old_w, 6)

        # Apply new weights to the engine's internal stage configs
        for cfg in engine._stages:
            if cfg.stage_name in new_weights:
                cfg.weight = new_weights[cfg.stage_name]

        self._iteration += 1
        self._history.append(
            RefinementRecord(
                iteration=self._iteration,
                adjustments=adjustments,
                convergence_score=round(max_delta, 6),
            )
        )

        logger.info(
            "Refinement iteration %d: convergence=%.6f",
            self._iteration,
            max_delta,
        )

        return engine

    def refine_after_stage(self, engine: RewardEngine) -> bool:
        """Perform a single refinement step after a training stage.

        Returns ``True`` if the weights have converged (i.e. further
        refinement is unlikely to make meaningful changes).

        Args:
            engine: The reward engine to refine.

        Returns:
            ``True`` if converged, ``False`` otherwise.
        """
        if self._iteration >= self._max_iterations:
            return True

        self.apply_refinement(engine)
        return self.should_converge()

    def should_converge(self) -> bool:
        """Check whether the most recent refinement met the convergence criterion.

        Returns:
            ``True`` if the last convergence score is below the threshold.
        """
        if not self._history:
            return False
        return self._history[-1].convergence_score < self._convergence_threshold

    def collect_traces(self, traces: list[RewardTraceV1]) -> None:
        """Manually feed reward traces for future analysis.

        Args:
            traces: Reward traces to accumulate.
        """
        self._collected_traces.extend(traces)

    def get_refinement_history(self) -> list[RefinementRecord]:
        """Return all refinement records.

        Returns:
            A list of :class:`RefinementRecord` instances.
        """
        return list(self._history)

    def summary(self) -> dict[str, Any]:
        """Return a summary of the refiner state.

        Returns:
            A dict with iteration count, convergence status, and history.
        """
        return {
            "iterations": self._iteration,
            "max_iterations": self._max_iterations,
            "converged": self.should_converge(),
            "convergence_threshold": self._convergence_threshold,
            "blend_weight": self._blend_weight,
            "collected_traces": len(self._collected_traces),
            "history": [
                {
                    "iteration": r.iteration,
                    "convergence_score": r.convergence_score,
                    "adjustments": r.adjustments,
                    "timestamp": r.timestamp.isoformat(),
                }
                for r in self._history
            ],
        }
