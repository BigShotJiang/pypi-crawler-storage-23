"""Upload trained LoRA adapters and datasets to HuggingFace Hub.

Provides the :class:`HFUploader` class for pushing Aegis-trained model
adapters and curated datasets to the HuggingFace Hub.  Supports automatic
model card and dataset card generation from templates.

Usage::

    from aegis.training.hf_upload import HFUploader

    uploader = HFUploader()
    uploader.upload_model(
        local_path="checkpoints/legal-v1",
        repo_id="metronis/aegis-legal-v1",
        model_card_data={"base_model": "Qwen/Qwen2.5-7B", ...},
    )
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from aegis.core.settings import AegisSettings

logger = logging.getLogger(__name__)


class HFUploader:
    """Upload Aegis model adapters and datasets to HuggingFace Hub.

    Parameters
    ----------
    token:
        HuggingFace API token.  If *None*, the ``HF_TOKEN`` environment
        variable is used.  Falls back to the cached token from
        ``huggingface-cli login`` if neither is set.
    """

    def __init__(self, token: str | None = None) -> None:
        settings = AegisSettings()
        self._token = token or settings.hf_token
        self._api: Any | None = None

    # ------------------------------------------------------------------
    # Lazy imports — avoids hard dependency on huggingface_hub at import
    # ------------------------------------------------------------------

    def _get_api(self) -> Any:
        """Return a cached :class:`huggingface_hub.HfApi` instance."""
        if self._api is None:
            try:
                from huggingface_hub import HfApi
            except ImportError as exc:
                raise ImportError(
                    "huggingface_hub is required for HFUploader.  "
                    "Install it with: pip install huggingface_hub"
                ) from exc
            self._api = HfApi(token=self._token)
        return self._api

    # ------------------------------------------------------------------
    # Model upload
    # ------------------------------------------------------------------

    def upload_model(
        self,
        local_path: str | Path,
        repo_id: str,
        model_card_data: dict[str, Any] | None = None,
        *,
        private: bool = False,
        commit_message: str = "Upload Aegis LoRA adapter",
    ) -> str:
        """Upload adapter weights and model card to HuggingFace Hub.

        Parameters
        ----------
        local_path:
            Path to the local directory containing the adapter weights
            (e.g. ``adapter_model.safetensors``, ``adapter_config.json``).
        repo_id:
            Target repository on HuggingFace Hub, e.g.
            ``"metronis/aegis-legal-v1"``.
        model_card_data:
            Optional dictionary of values to interpolate into the model
            card template.  Supported keys include ``base_model``,
            ``description``, ``training_details``, ``eval_results``,
            ``usage_example``, and ``citation``.
        private:
            Whether the repository should be private.
        commit_message:
            Commit message for the upload.

        Returns
        -------
        str
            URL of the uploaded model on HuggingFace Hub.
        """
        local_path = Path(local_path)
        if not local_path.is_dir():
            raise FileNotFoundError(f"Model directory not found: {local_path}")

        api = self._get_api()

        # Ensure repo exists
        api.create_repo(
            repo_id=repo_id,
            repo_type="model",
            private=private,
            exist_ok=True,
        )

        # Generate model card if template data is provided
        if model_card_data is not None:
            card_content = self._render_model_card(model_card_data)
            readme_path = local_path / "README.md"
            readme_path.write_text(card_content, encoding="utf-8")
            logger.info("Generated model card at %s", readme_path)

        # Upload entire directory
        url = api.upload_folder(
            repo_id=repo_id,
            folder_path=str(local_path),
            repo_type="model",
            commit_message=commit_message,
        )

        logger.info("Model uploaded to https://huggingface.co/%s", repo_id)
        return str(url)

    # ------------------------------------------------------------------
    # Dataset upload
    # ------------------------------------------------------------------

    def upload_dataset(
        self,
        local_path: str | Path,
        repo_id: str,
        dataset_card_data: dict[str, Any] | None = None,
        *,
        private: bool = False,
        commit_message: str = "Upload Aegis dataset",
    ) -> str:
        """Upload a dataset and dataset card to HuggingFace Hub.

        Parameters
        ----------
        local_path:
            Path to the local directory containing the dataset files
            (e.g. Parquet, JSONL, or CSV files).
        repo_id:
            Target repository on HuggingFace Hub, e.g.
            ``"metronis/aegis-legal-bench"``.
        dataset_card_data:
            Optional dictionary of values to interpolate into the
            dataset card template.  Supported keys include
            ``description``, ``structure``, ``usage``, and ``citation``.
        private:
            Whether the repository should be private.
        commit_message:
            Commit message for the upload.

        Returns
        -------
        str
            URL of the uploaded dataset on HuggingFace Hub.
        """
        local_path = Path(local_path)
        if not local_path.is_dir():
            raise FileNotFoundError(f"Dataset directory not found: {local_path}")

        api = self._get_api()

        # Ensure repo exists
        api.create_repo(
            repo_id=repo_id,
            repo_type="dataset",
            private=private,
            exist_ok=True,
        )

        # Generate dataset card if template data is provided
        if dataset_card_data is not None:
            card_content = self._render_dataset_card(dataset_card_data)
            readme_path = local_path / "README.md"
            readme_path.write_text(card_content, encoding="utf-8")
            logger.info("Generated dataset card at %s", readme_path)

        # Upload entire directory
        url = api.upload_folder(
            repo_id=repo_id,
            folder_path=str(local_path),
            repo_type="dataset",
            commit_message=commit_message,
        )

        logger.info("Dataset uploaded to https://huggingface.co/datasets/%s", repo_id)
        return str(url)

    # ------------------------------------------------------------------
    # Card rendering helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _render_model_card(data: dict[str, Any]) -> str:
        """Render the model card from the template."""
        template_path = Path(__file__).resolve().parents[3] / "templates" / "model_card.md"
        if template_path.is_file():
            template = template_path.read_text(encoding="utf-8")
        else:
            # Inline fallback template
            template = (
                "---\n"
                "library_name: peft\n"
                "base_model: {base_model}\n"
                "tags:\n"
                "  - aegis\n"
                "  - metronis\n"
                "  - lora\n"
                "  - rl\n"
                "---\n\n"
                "# {repo_id}\n\n"
                "{description}\n"
            )

        return template.format_map(_SafeFormatDict(data))

    @staticmethod
    def _render_dataset_card(data: dict[str, Any]) -> str:
        """Render the dataset card from the template."""
        template_path = Path(__file__).resolve().parents[3] / "templates" / "dataset_card.md"
        if template_path.is_file():
            template = template_path.read_text(encoding="utf-8")
        else:
            # Inline fallback template
            template = "---\ntags:\n  - aegis\n  - metronis\n---\n\n# {repo_id}\n\n{description}\n"

        return template.format_map(_SafeFormatDict(data))


class _SafeFormatDict(dict[str, Any]):
    """Dict subclass that returns the key placeholder for missing keys.

    This allows ``str.format_map`` to leave unreplaced placeholders
    intact instead of raising :class:`KeyError`.
    """

    def __missing__(self, key: str) -> str:
        return f"{{{key}}}"
