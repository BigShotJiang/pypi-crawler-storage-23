"""ALMA-inspired memory architecture discovery engine.

Meta-agent searches over memory architectures expressed as executable code,
discovering domain-specific memory designs that outperform hand-designed
alternatives.  Architectures are represented as code triplets (schema,
retrieval mechanism, update rules) and evolved via an evolutionary search
process with fitness-based selection.

Reference: ALMA — Agentic LLM-based Memory Architecture discovery
(NeurIPS 2024 Workshop).
"""

from __future__ import annotations

import hashlib
import textwrap
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

__all__ = [
    "MemoryArchitecture",
    "ArchitectureLibrary",
    "ArchitectureDiscoveryEngine",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _det_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Return a deterministic float in [low, high] derived from *seed*."""
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return low + int(digest[:8], 16) / 0xFFFFFFFF * (high - low)


def _det_int(seed: str, low: int, high: int) -> int:
    """Return a deterministic integer in [low, high] derived from *seed*."""
    return int(_det_float(seed, float(low), float(high) + 0.999))


def _det_choice(seed: str, options: list[Any]) -> Any:
    """Return a deterministic choice from *options*."""
    if not options:
        return None
    idx = int(hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8], 16) % len(options)
    return options[idx]


def _det_sample(seed: str, options: list[Any], k: int) -> list[Any]:
    """Return a deterministic sample of *k* items from *options*."""
    if not options or k <= 0:
        return []
    result: list[Any] = []
    remaining = list(options)
    for i in range(min(k, len(remaining))):
        idx = int(hashlib.sha256(f"{seed}:{i}".encode()).hexdigest()[:8], 16) % len(remaining)
        result.append(remaining.pop(idx))
    return result


def _arch_id() -> str:
    """Generate a unique architecture ID."""
    return f"arch-{uuid.uuid4().hex[:12]}"


# ---------------------------------------------------------------------------
# Seed architecture templates
# ---------------------------------------------------------------------------


_SCHEMA_TEMPLATES: dict[str, str] = {
    "flat_kv": textwrap.dedent("""\
        # Flat key-value memory schema
        schema = {
            "type": "flat_kv",
            "index": "hash",
            "tiers": ["working", "session", "permanent"],
            "max_entries_per_tier": {"working": 100, "session": 1000, "permanent": 10000},
            "key_type": "string",
            "value_type": "json",
            "metadata_fields": ["timestamp", "provenance", "confidence"],
        }
    """),
    "hierarchical": textwrap.dedent("""\
        # Hierarchical memory schema with parent-child relationships
        schema = {
            "type": "hierarchical",
            "index": "btree",
            "tiers": ["working", "episodic", "semantic", "permanent"],
            "parent_child_links": True,
            "max_depth": 5,
            "key_type": "composite",
            "value_type": "structured",
            "metadata_fields": ["timestamp", "provenance", "confidence", "access_count", "parent_id"],
        }
    """),
    "graph_memory": textwrap.dedent("""\
        # Graph-based memory schema with entity-relation triples
        schema = {
            "type": "graph",
            "index": "adjacency_list",
            "node_types": ["entity", "event", "concept", "relation"],
            "edge_types": ["causes", "precedes", "contains", "contradicts", "supports"],
            "tiers": ["working", "session", "permanent"],
            "max_nodes": 50000,
            "key_type": "uri",
            "value_type": "triple",
            "metadata_fields": ["timestamp", "provenance", "confidence", "weight"],
        }
    """),
    "temporal_buffer": textwrap.dedent("""\
        # Temporal buffer with sliding window and decay
        schema = {
            "type": "temporal_buffer",
            "index": "time_sorted",
            "window_sizes": {"short": 60, "medium": 3600, "long": 86400},
            "decay_function": "exponential",
            "decay_half_life_seconds": 7200,
            "max_entries": 5000,
            "key_type": "timestamp_composite",
            "value_type": "json",
            "metadata_fields": ["timestamp", "decay_weight", "access_recency"],
        }
    """),
    "hybrid_vector_kg": textwrap.dedent("""\
        # Hybrid vector + knowledge graph memory
        schema = {
            "type": "hybrid_vector_kg",
            "vector_index": "hnsw",
            "graph_index": "adjacency_list",
            "embedding_dim": 768,
            "tiers": ["working", "session", "semantic", "permanent"],
            "vector_entries_max": 100000,
            "graph_nodes_max": 50000,
            "key_type": "composite",
            "value_type": "multi_modal",
            "metadata_fields": ["timestamp", "provenance", "confidence", "embedding_hash"],
        }
    """),
}


_RETRIEVAL_TEMPLATES: dict[str, str] = {
    "simple_lookup": textwrap.dedent("""\
        # Simple hash-based lookup retrieval
        def retrieve(query, memory, top_k=5):
            results = memory.exact_match(query.key)
            if not results:
                results = memory.prefix_search(query.key, limit=top_k)
            return sorted(results, key=lambda r: r.confidence, reverse=True)[:top_k]
    """),
    "semantic_search": textwrap.dedent("""\
        # Semantic similarity search with reranking
        def retrieve(query, memory, top_k=10):
            embedding = encode(query.text)
            candidates = memory.vector_search(embedding, limit=top_k * 3)
            reranked = rerank(query.text, candidates)
            return reranked[:top_k]
    """),
    "hybrid_search": textwrap.dedent("""\
        # Hybrid semantic + graph traversal search
        def retrieve(query, memory, top_k=10, max_hops=2):
            vector_results = memory.vector_search(encode(query.text), limit=top_k)
            entities = extract_entities(query.text)
            graph_results = memory.graph_traverse(entities, max_hops=max_hops)
            merged = merge_results(vector_results, graph_results, strategy="rrf")
            return merged[:top_k]
    """),
    "iterative_deepening": textwrap.dedent("""\
        # Iterative deepening retrieval with gap analysis
        def retrieve(query, memory, top_k=10, max_iterations=3):
            results = []
            current_query = query
            for iteration in range(max_iterations):
                batch = memory.search(current_query, limit=top_k)
                results.extend(batch)
                gaps = analyze_gaps(query, results)
                if not gaps:
                    break
                current_query = reformulate(query, gaps)
            return deduplicate(results)[:top_k]
    """),
    "adaptive_routing": textwrap.dedent("""\
        # Adaptive source routing based on query analysis
        def retrieve(query, memory, top_k=10):
            query_type = classify_query(query)
            if query_type == "factual":
                results = memory.exact_search(query, limit=top_k)
            elif query_type == "semantic":
                results = memory.vector_search(encode(query.text), limit=top_k)
            elif query_type == "relational":
                results = memory.graph_search(query, limit=top_k)
            else:
                results = memory.hybrid_search(query, limit=top_k)
            return results
    """),
}


_UPDATE_RULES_TEMPLATES: dict[str, str] = {
    "overwrite": textwrap.dedent("""\
        # Simple overwrite with history preservation
        def update(key, new_value, memory):
            old = memory.get(key)
            if old:
                memory.archive(key, old)
            memory.set(key, new_value, timestamp=now())
    """),
    "merge_with_conflict": textwrap.dedent("""\
        # Merge update with conflict detection
        def update(key, new_value, memory):
            old = memory.get(key)
            if old:
                conflicts = detect_conflicts(old, new_value)
                if conflicts:
                    memory.flag_conflict(key, old, new_value, conflicts)
                merged = merge_values(old, new_value, strategy="newer_wins")
                memory.set(key, merged, timestamp=now(), provenance="merge")
            else:
                memory.set(key, new_value, timestamp=now())
    """),
    "versioned_append": textwrap.dedent("""\
        # Version-controlled append-only updates
        def update(key, new_value, memory):
            version = memory.get_version(key) + 1
            memory.append_version(key, new_value, version=version, timestamp=now())
            memory.set_active_version(key, version)
    """),
    "decay_weighted": textwrap.dedent("""\
        # Decay-weighted update with confidence blending
        def update(key, new_value, memory, new_confidence=1.0):
            old = memory.get(key)
            if old:
                old_weight = old.confidence * decay(old.age)
                new_weight = new_confidence
                blended = blend(old.value, new_value, old_weight, new_weight)
                memory.set(key, blended, confidence=(old_weight + new_weight) / 2)
            else:
                memory.set(key, new_value, confidence=new_confidence)
    """),
    "consensus_based": textwrap.dedent("""\
        # Consensus-based update requiring multi-source agreement
        def update(key, new_value, memory, source=None, min_sources=2):
            memory.add_candidate(key, new_value, source=source)
            candidates = memory.get_candidates(key)
            if len(candidates) >= min_sources:
                consensus = compute_consensus(candidates)
                if consensus.agreement >= 0.7:
                    memory.set(key, consensus.value, provenance="consensus")
                    memory.clear_candidates(key)
    """),
}


# Domain-specific architecture patterns
_DOMAIN_PATTERNS: dict[str, dict[str, str]] = {
    "legal": {
        "preferred_schema": "hierarchical",
        "preferred_retrieval": "hybrid_search",
        "preferred_update": "versioned_append",
        "emphasis": "document_versioning,supersession_tracking,temporal_ordering",
    },
    "finance": {
        "preferred_schema": "hybrid_vector_kg",
        "preferred_retrieval": "adaptive_routing",
        "preferred_update": "merge_with_conflict",
        "emphasis": "numerical_precision,cross_document_reconciliation,regulatory_tracking",
    },
    "healthcare": {
        "preferred_schema": "graph_memory",
        "preferred_retrieval": "hybrid_search",
        "preferred_update": "consensus_based",
        "emphasis": "patient_history,drug_interactions,evidence_grading",
    },
    "general": {
        "preferred_schema": "flat_kv",
        "preferred_retrieval": "semantic_search",
        "preferred_update": "overwrite",
        "emphasis": "general_purpose,flexibility,simplicity",
    },
}


# ---------------------------------------------------------------------------
# MemoryArchitecture
# ---------------------------------------------------------------------------


@dataclass
class MemoryArchitecture:
    """Represents a discovered memory architecture.

    An architecture consists of three executable code components:
    schema (defining the memory structure), retrieval mechanism, and
    update rules.  Architectures have fitness scores and can be evolved
    through mutation.

    Attributes:
        id: Unique identifier for this architecture.
        name: Human-readable name.
        domain: Target domain this architecture is designed for.
        schema_code: Executable Python code defining the memory schema.
        retrieval_code: Code defining retrieval mechanisms.
        update_rules_code: Code defining update rules.
        fitness_score: Overall fitness score (0-1).
        eval_results: Detailed evaluation results.
        parent_ids: Architectures this evolved from.
        generation: Evolutionary generation number.
        created_at: Creation timestamp.
        metadata: Additional metadata.
    """

    id: str = field(default_factory=_arch_id)
    name: str = ""
    domain: str = "general"
    schema_code: str = ""
    retrieval_code: str = ""
    update_rules_code: str = ""
    fitness_score: float = 0.0
    eval_results: dict[str, Any] = field(default_factory=dict)
    parent_ids: list[str] = field(default_factory=list)
    generation: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the architecture to a dictionary.

        Returns:
            A JSON-serializable dictionary of all fields.
        """
        return {
            "id": self.id,
            "name": self.name,
            "domain": self.domain,
            "schema_code": self.schema_code,
            "retrieval_code": self.retrieval_code,
            "update_rules_code": self.update_rules_code,
            "fitness_score": round(self.fitness_score, 6),
            "eval_results": self.eval_results,
            "parent_ids": self.parent_ids,
            "generation": self.generation,
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata,
        }

    def code_fingerprint(self) -> str:
        """Compute a deterministic fingerprint of this architecture's code.

        Returns:
            A hex string fingerprint derived from all code components.
        """
        combined = f"{self.schema_code}|{self.retrieval_code}|{self.update_rules_code}"
        return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:16]


# ---------------------------------------------------------------------------
# ArchitectureLibrary
# ---------------------------------------------------------------------------


class ArchitectureLibrary:
    """Growing archive of discovered memory architectures.

    Stores evaluated architectures indexed by domain and fitness, enabling
    retrieval of the best architectures for a given domain or task profile.
    """

    def __init__(self) -> None:
        self._architectures: dict[str, MemoryArchitecture] = {}
        self._domain_index: dict[str, list[str]] = {}
        self._generation_log: list[dict[str, Any]] = []

    def add(self, arch: MemoryArchitecture) -> None:
        """Add an architecture to the library.

        Args:
            arch: The architecture to add.
        """
        self._architectures[arch.id] = arch

        if arch.domain not in self._domain_index:
            self._domain_index[arch.domain] = []
        self._domain_index[arch.domain].append(arch.id)

        self._generation_log.append(
            {
                "id": arch.id,
                "domain": arch.domain,
                "generation": arch.generation,
                "fitness": round(arch.fitness_score, 6),
                "timestamp": arch.created_at.isoformat(),
            }
        )

    def get(self, arch_id: str) -> MemoryArchitecture | None:
        """Retrieve an architecture by ID.

        Args:
            arch_id: The architecture identifier.

        Returns:
            The architecture, or None if not found.
        """
        return self._architectures.get(arch_id)

    def search(self, domain: str, top_k: int = 5) -> list[MemoryArchitecture]:
        """Search for the best architectures for a domain.

        Returns architectures sorted by fitness score in descending order.

        Args:
            domain: The target domain.
            top_k: Maximum number of results.

        Returns:
            A list of :class:`MemoryArchitecture` objects sorted by fitness.
        """
        arch_ids = self._domain_index.get(domain, [])
        candidates = [self._architectures[aid] for aid in arch_ids if aid in self._architectures]

        # Also include general-purpose architectures as fallback
        if domain != "general":
            general_ids = self._domain_index.get("general", [])
            for aid in general_ids:
                if aid in self._architectures:
                    arch = self._architectures[aid]
                    if arch not in candidates:
                        candidates.append(arch)

        # Sort by fitness descending
        candidates.sort(key=lambda a: a.fitness_score, reverse=True)
        return candidates[:top_k]

    def get_closest(self, domain: str, task_profile: dict[str, Any]) -> MemoryArchitecture | None:
        """Find the architecture closest to a task profile.

        Uses a similarity metric based on the task profile's requirements
        (emphasis areas, memory operations needed, scale) to find the
        best match in the library.

        Args:
            domain: The target domain.
            task_profile: Task requirements dict with keys like
                ``emphasis``, ``operations``, ``scale``, etc.

        Returns:
            The closest matching architecture, or None if the library is empty.
        """
        candidates = self.search(domain, top_k=50)
        if not candidates:
            return None

        target_emphasis = set(str(task_profile.get("emphasis", "")).split(","))
        target_ops = set(task_profile.get("operations", []))
        target_scale = task_profile.get("scale", "medium")

        best_arch: MemoryArchitecture | None = None
        best_score = -1.0

        for arch in candidates:
            # Compute similarity based on metadata overlap
            arch_emphasis = set(str(arch.metadata.get("emphasis", "")).split(","))
            arch_ops = set(arch.metadata.get("operations", []))
            arch_scale = arch.metadata.get("scale", "medium")

            # Emphasis overlap (Jaccard-like)
            emphasis_union = target_emphasis | arch_emphasis
            emphasis_intersect = target_emphasis & arch_emphasis
            emphasis_sim = len(emphasis_intersect) / max(len(emphasis_union), 1)

            # Operations overlap
            ops_union = target_ops | arch_ops
            ops_intersect = target_ops & arch_ops
            ops_sim = len(ops_intersect) / max(len(ops_union), 1) if ops_union else 0.5

            # Scale match (binary)
            scale_sim = 1.0 if target_scale == arch_scale else 0.3

            # Combined similarity (weighted by fitness)
            similarity = (0.4 * emphasis_sim + 0.3 * ops_sim + 0.3 * scale_sim) * (
                0.5 + 0.5 * arch.fitness_score
            )

            if similarity > best_score:
                best_score = similarity
                best_arch = arch

        return best_arch

    def all_architectures(self) -> list[MemoryArchitecture]:
        """Return all architectures in the library.

        Returns:
            A list of all stored :class:`MemoryArchitecture` objects.
        """
        return list(self._architectures.values())

    def summary(self) -> dict[str, Any]:
        """Return a summary of the library contents.

        Returns:
            A dictionary with library statistics.
        """
        domain_counts: dict[str, int] = {}
        domain_best_fitness: dict[str, float] = {}
        domain_mean_fitness: dict[str, float] = {}

        for domain, arch_ids in self._domain_index.items():
            domain_counts[domain] = len(arch_ids)
            fitnesses = [
                self._architectures[aid].fitness_score
                for aid in arch_ids
                if aid in self._architectures
            ]
            if fitnesses:
                domain_best_fitness[domain] = round(max(fitnesses), 6)
                domain_mean_fitness[domain] = round(sum(fitnesses) / len(fitnesses), 6)

        generations = set()
        for arch in self._architectures.values():
            generations.add(arch.generation)

        return {
            "total_architectures": len(self._architectures),
            "domains": list(self._domain_index.keys()),
            "domain_counts": domain_counts,
            "domain_best_fitness": domain_best_fitness,
            "domain_mean_fitness": domain_mean_fitness,
            "max_generation": max(generations) if generations else 0,
            "generation_log_entries": len(self._generation_log),
        }


# ---------------------------------------------------------------------------
# ArchitectureDiscoveryEngine
# ---------------------------------------------------------------------------


class ArchitectureDiscoveryEngine:
    """ALMA-inspired meta-agent for memory architecture discovery.

    Proposes, evaluates, and evolves memory architectures through an
    evolutionary search process.  Each architecture is a code triplet
    (schema, retrieval, update rules) that can be evaluated on domain
    tasks and evolved through mutation and crossover.
    """

    def __init__(
        self,
        library: ArchitectureLibrary | None = None,
        seed_architectures: list[MemoryArchitecture] | None = None,
    ) -> None:
        self._library = library if library is not None else ArchitectureLibrary()
        self._search_runs: list[dict[str, Any]] = []
        self._evaluation_cache: dict[str, float] = {}

        # Seed the library with initial architectures
        if seed_architectures:
            for arch in seed_architectures:
                self._library.add(arch)
        else:
            self._seed_default_architectures()

    @property
    def library(self) -> ArchitectureLibrary:
        """Access the underlying architecture library."""
        return self._library

    # ------------------------------------------------------------------
    # Seeding
    # ------------------------------------------------------------------

    def _seed_default_architectures(self) -> None:
        """Seed the library with hand-designed baseline architectures."""
        for domain, patterns in _DOMAIN_PATTERNS.items():
            schema_key = patterns["preferred_schema"]
            retrieval_key = patterns["preferred_retrieval"]
            update_key = patterns["preferred_update"]

            schema_code = _SCHEMA_TEMPLATES.get(schema_key, _SCHEMA_TEMPLATES["flat_kv"])
            retrieval_code = _RETRIEVAL_TEMPLATES.get(
                retrieval_key, _RETRIEVAL_TEMPLATES["simple_lookup"]
            )
            update_code = _UPDATE_RULES_TEMPLATES.get(
                update_key, _UPDATE_RULES_TEMPLATES["overwrite"]
            )

            # Compute a deterministic baseline fitness
            fitness = _det_float(f"seed_fitness:{domain}:{schema_key}:{retrieval_key}", 0.45, 0.70)

            arch = MemoryArchitecture(
                name=f"baseline-{domain}-{schema_key}",
                domain=domain,
                schema_code=schema_code,
                retrieval_code=retrieval_code,
                update_rules_code=update_code,
                fitness_score=fitness,
                eval_results={
                    "schema_quality": round(_det_float(f"seed_eval_schema:{domain}", 0.5, 0.8), 4),
                    "retrieval_quality": round(
                        _det_float(f"seed_eval_retrieval:{domain}", 0.5, 0.8), 4
                    ),
                    "update_quality": round(_det_float(f"seed_eval_update:{domain}", 0.5, 0.8), 4),
                },
                parent_ids=[],
                generation=0,
                metadata={
                    "emphasis": patterns["emphasis"],
                    "schema_type": schema_key,
                    "retrieval_type": retrieval_key,
                    "update_type": update_key,
                    "seed": True,
                },
            )
            self._library.add(arch)

    # ------------------------------------------------------------------
    # Architecture proposal
    # ------------------------------------------------------------------

    def propose(self, domain: str, task_distribution: dict[str, Any]) -> MemoryArchitecture:
        """Propose a new architecture for a domain given a task distribution.

        Analyzes the task distribution to determine requirements and
        constructs an architecture using the most appropriate components
        from the template library, then applies domain-specific adaptations.

        Args:
            domain: Target domain (e.g. "legal", "finance").
            task_distribution: Dictionary describing the task mix, with keys
                like ``retrieval_heavy``, ``update_heavy``, ``scale``,
                ``temporal_emphasis``, ``multi_hop``, etc.

        Returns:
            A newly proposed :class:`MemoryArchitecture`.
        """
        # Analyze task distribution to pick components
        retrieval_heavy = task_distribution.get("retrieval_heavy", 0.5)
        update_heavy = task_distribution.get("update_heavy", 0.3)
        temporal_emphasis = task_distribution.get("temporal_emphasis", 0.3)
        multi_hop = task_distribution.get("multi_hop", 0.2)
        scale = task_distribution.get("scale", "medium")

        # Select schema based on analysis
        if multi_hop > 0.5:
            schema_key = "graph_memory"
        elif temporal_emphasis > 0.5:
            schema_key = "temporal_buffer"
        elif retrieval_heavy > 0.6:
            schema_key = "hybrid_vector_kg"
        else:
            # Use domain pattern preference or hierarchical as default
            patterns = _DOMAIN_PATTERNS.get(domain, _DOMAIN_PATTERNS["general"])
            schema_key = patterns.get("preferred_schema", "hierarchical")

        # Select retrieval based on analysis
        if retrieval_heavy > 0.7:
            retrieval_key = "iterative_deepening"
        elif multi_hop > 0.4:
            retrieval_key = "hybrid_search"
        elif retrieval_heavy > 0.4:
            retrieval_key = "adaptive_routing"
        else:
            retrieval_key = "semantic_search"

        # Select update rules based on analysis
        if update_heavy > 0.6:
            update_key = "versioned_append"
        elif task_distribution.get("conflict_prone", 0.0) > 0.4:
            update_key = "merge_with_conflict"
        elif task_distribution.get("multi_source", 0.0) > 0.5:
            update_key = "consensus_based"
        else:
            update_key = "decay_weighted"

        schema_code = _SCHEMA_TEMPLATES.get(schema_key, _SCHEMA_TEMPLATES["flat_kv"])
        retrieval_code = _RETRIEVAL_TEMPLATES.get(
            retrieval_key, _RETRIEVAL_TEMPLATES["simple_lookup"]
        )
        update_code = _UPDATE_RULES_TEMPLATES.get(update_key, _UPDATE_RULES_TEMPLATES["overwrite"])

        # Apply domain-specific adaptations to schema code
        domain_patterns = _DOMAIN_PATTERNS.get(domain, {})
        emphasis = domain_patterns.get("emphasis", "general_purpose")

        # Check for close existing architecture to build upon
        closest = self._library.get_closest(domain, task_distribution)
        parent_ids: list[str] = []
        generation = 0
        if closest is not None:
            parent_ids = [closest.id]
            generation = closest.generation + 1

        name = f"proposed-{domain}-{schema_key}-gen{generation}"

        arch = MemoryArchitecture(
            name=name,
            domain=domain,
            schema_code=schema_code,
            retrieval_code=retrieval_code,
            update_rules_code=update_code,
            fitness_score=0.0,  # Not yet evaluated
            eval_results={},
            parent_ids=parent_ids,
            generation=generation,
            metadata={
                "emphasis": emphasis,
                "schema_type": schema_key,
                "retrieval_type": retrieval_key,
                "update_type": update_key,
                "task_distribution": task_distribution,
                "scale": scale,
                "proposed": True,
            },
        )

        return arch

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, arch: MemoryArchitecture, tasks: list[dict[str, Any]]) -> float:
        """Evaluate an architecture's fitness on a set of tasks.

        Computes a composite fitness score by deterministically scoring
        how well the architecture's components match each task's
        requirements.

        Args:
            arch: The architecture to evaluate.
            tasks: A list of task dictionaries, each with keys like
                ``type``, ``difficulty``, ``operations_required``, etc.

        Returns:
            A fitness score in [0, 1].
        """
        if not tasks:
            return 0.0

        # Check cache
        cache_key = f"{arch.code_fingerprint()}:{len(tasks)}"
        if cache_key in self._evaluation_cache:
            return self._evaluation_cache[cache_key]

        task_scores: list[float] = []

        for i, task in enumerate(tasks):
            seed = f"eval:{arch.id}:{i}:{task.get('type', 'unknown')}"

            task_type = task.get("type", "general")
            difficulty = task.get("difficulty", 3)
            ops_required = task.get("operations_required", [])

            # Schema fitness: how well the schema supports required operations
            schema_type = str(arch.metadata.get("schema_type", "flat_kv"))
            schema_fitness = self._compute_schema_fitness(
                schema_type, task_type, ops_required, seed
            )

            # Retrieval fitness: how well the retrieval mechanism handles the task
            retrieval_type = str(arch.metadata.get("retrieval_type", "simple_lookup"))
            retrieval_fitness = self._compute_retrieval_fitness(
                retrieval_type, task_type, difficulty, seed
            )

            # Update fitness: how well update rules handle the task
            update_type = str(arch.metadata.get("update_type", "overwrite"))
            update_fitness = self._compute_update_fitness(
                update_type, task_type, ops_required, seed
            )

            # Domain alignment bonus
            domain_bonus = 0.0
            if arch.domain == task.get("domain", "general"):
                domain_bonus = _det_float(f"domain_bonus:{seed}", 0.05, 0.15)

            # Combined score with component weighting
            task_score = (
                0.35 * schema_fitness
                + 0.35 * retrieval_fitness
                + 0.20 * update_fitness
                + domain_bonus
            )

            # Difficulty scaling: harder tasks give more credit when scored well
            difficulty_scale = 0.8 + 0.04 * min(difficulty, 5)
            task_score = min(1.0, task_score * difficulty_scale)

            task_scores.append(task_score)

        fitness = sum(task_scores) / len(task_scores)
        fitness = round(max(0.0, min(1.0, fitness)), 6)

        # Update architecture
        arch.fitness_score = fitness
        arch.eval_results = {
            "num_tasks": len(tasks),
            "mean_score": round(fitness, 6),
            "min_score": round(min(task_scores), 6),
            "max_score": round(max(task_scores), 6),
            "task_scores": [round(s, 4) for s in task_scores],
        }

        self._evaluation_cache[cache_key] = fitness
        return fitness

    def _compute_schema_fitness(
        self,
        schema_type: str,
        task_type: str,
        ops_required: list[str],
        seed: str,
    ) -> float:
        """Compute schema fitness for a task.

        Args:
            schema_type: Type of schema (flat_kv, hierarchical, etc.).
            task_type: Type of task.
            ops_required: Memory operations the task requires.
            seed: Deterministic seed.

        Returns:
            Schema fitness score (0-1).
        """
        # Base fitness by schema type
        base_scores: dict[str, float] = {
            "flat_kv": 0.50,
            "hierarchical": 0.65,
            "graph_memory": 0.70,
            "temporal_buffer": 0.55,
            "hybrid_vector_kg": 0.75,
        }
        base = base_scores.get(schema_type, 0.50)

        # Task-type bonuses
        if (
            task_type in ("multi_step_reasoning", "knowledge_sharing")
            and schema_type == "graph_memory"
        ):
            base += 0.15
        elif (
            task_type in ("context_compression", "budget_constrained_retrieval")
            and schema_type == "hybrid_vector_kg"
        ):
            base += 0.10
        elif (
            task_type in ("temporal_ordering", "provenance_check")
            and schema_type == "temporal_buffer"
        ):
            base += 0.15

        # Operations support bonus
        complex_ops = {"SPLIT", "MERGE", "LINK", "COMPRESS"}
        required_complex = set(ops_required) & complex_ops
        if required_complex and schema_type in ("graph_memory", "hierarchical", "hybrid_vector_kg"):
            base += 0.05 * len(required_complex)

        # Add deterministic noise
        noise = _det_float(f"schema_noise:{seed}", -0.05, 0.05)

        return max(0.0, min(1.0, base + noise))

    def _compute_retrieval_fitness(
        self,
        retrieval_type: str,
        task_type: str,
        difficulty: int,
        seed: str,
    ) -> float:
        """Compute retrieval fitness for a task.

        Args:
            retrieval_type: Type of retrieval mechanism.
            task_type: Type of task.
            difficulty: Task difficulty (1-5).
            seed: Deterministic seed.

        Returns:
            Retrieval fitness score (0-1).
        """
        base_scores: dict[str, float] = {
            "simple_lookup": 0.45,
            "semantic_search": 0.60,
            "hybrid_search": 0.70,
            "iterative_deepening": 0.72,
            "adaptive_routing": 0.68,
        }
        base = base_scores.get(retrieval_type, 0.50)

        # Higher difficulty benefits from more sophisticated retrieval
        if difficulty >= 4 and retrieval_type in ("iterative_deepening", "hybrid_search"):
            base += 0.10
        elif difficulty <= 2 and retrieval_type == "simple_lookup":
            base += 0.15  # Simple is fine for easy tasks

        # Task-type specific bonuses
        if (
            task_type in ("multi_source_retrieval", "depth_adaptive_search")
            and retrieval_type == "iterative_deepening"
        ):
            base += 0.12
        elif task_type == "source_routing" and retrieval_type == "adaptive_routing":
            base += 0.15

        noise = _det_float(f"retrieval_noise:{seed}", -0.05, 0.05)
        return max(0.0, min(1.0, base + noise))

    def _compute_update_fitness(
        self,
        update_type: str,
        task_type: str,
        ops_required: list[str],
        seed: str,
    ) -> float:
        """Compute update rule fitness for a task.

        Args:
            update_type: Type of update rules.
            task_type: Type of task.
            ops_required: Required memory operations.
            seed: Deterministic seed.

        Returns:
            Update fitness score (0-1).
        """
        base_scores: dict[str, float] = {
            "overwrite": 0.40,
            "merge_with_conflict": 0.65,
            "versioned_append": 0.60,
            "decay_weighted": 0.55,
            "consensus_based": 0.62,
        }
        base = base_scores.get(update_type, 0.45)

        # Update-heavy tasks benefit from sophisticated update rules
        update_ops = {"UPDATE", "FORGET", "MERGE", "SPLIT"}
        required_updates = set(ops_required) & update_ops
        if required_updates:
            if update_type in ("merge_with_conflict", "versioned_append"):
                base += 0.10
            elif update_type == "overwrite":
                base -= 0.05

        # Task-type specific bonuses
        if task_type == "conflict_resolution" and update_type == "merge_with_conflict":
            base += 0.15
        elif task_type == "shared_memory_construction" and update_type == "consensus_based":
            base += 0.12

        noise = _det_float(f"update_noise:{seed}", -0.05, 0.05)
        return max(0.0, min(1.0, base + noise))

    # ------------------------------------------------------------------
    # Evolution
    # ------------------------------------------------------------------

    def evolve(self, parent: MemoryArchitecture, mutation_rate: float = 0.1) -> MemoryArchitecture:
        """Create a mutated variant of a parent architecture.

        Applies stochastic mutations to one or more components of the
        parent architecture based on the mutation rate.

        Args:
            parent: The parent architecture to evolve from.
            mutation_rate: Probability of mutating each component (0-1).

        Returns:
            A new :class:`MemoryArchitecture` variant.
        """
        seed = f"evolve:{parent.id}:{mutation_rate}"

        new_schema = parent.schema_code
        new_retrieval = parent.retrieval_code
        new_update = parent.update_rules_code

        new_schema_type = str(parent.metadata.get("schema_type", "flat_kv"))
        new_retrieval_type = str(parent.metadata.get("retrieval_type", "simple_lookup"))
        new_update_type = str(parent.metadata.get("update_type", "overwrite"))

        schema_types = list(_SCHEMA_TEMPLATES.keys())
        retrieval_types = list(_RETRIEVAL_TEMPLATES.keys())
        update_types = list(_UPDATE_RULES_TEMPLATES.keys())

        mutations_applied: list[str] = []

        # Mutate schema
        if _det_float(f"mutate_schema:{seed}") < mutation_rate:
            # Replace schema with a different type
            other_schemas = [s for s in schema_types if s != new_schema_type]
            if other_schemas:
                new_schema_type = _det_choice(f"new_schema:{seed}", other_schemas)
                new_schema = _SCHEMA_TEMPLATES[new_schema_type]
                mutations_applied.append(f"schema:{new_schema_type}")

        # Mutate retrieval
        if _det_float(f"mutate_retrieval:{seed}") < mutation_rate:
            other_retrievals = [r for r in retrieval_types if r != new_retrieval_type]
            if other_retrievals:
                new_retrieval_type = _det_choice(f"new_retrieval:{seed}", other_retrievals)
                new_retrieval = _RETRIEVAL_TEMPLATES[new_retrieval_type]
                mutations_applied.append(f"retrieval:{new_retrieval_type}")

        # Mutate update rules
        if _det_float(f"mutate_update:{seed}") < mutation_rate:
            other_updates = [u for u in update_types if u != new_update_type]
            if other_updates:
                new_update_type = _det_choice(f"new_update:{seed}", other_updates)
                new_update = _UPDATE_RULES_TEMPLATES[new_update_type]
                mutations_applied.append(f"update:{new_update_type}")

        # If no mutations happened (low mutation rate), force at least one small change
        if not mutations_applied:
            # Apply a minor parameter tweak to one component
            tweak_target = _det_choice(f"tweak_target:{seed}", ["schema", "retrieval", "update"])
            if tweak_target == "schema":
                new_schema = new_schema.rstrip() + f"\n# Tuned variant (seed: {seed[:8]})\n"
                mutations_applied.append("schema:tuned")
            elif tweak_target == "retrieval":
                new_retrieval = new_retrieval.rstrip() + f"\n# Tuned variant (seed: {seed[:8]})\n"
                mutations_applied.append("retrieval:tuned")
            else:
                new_update = new_update.rstrip() + f"\n# Tuned variant (seed: {seed[:8]})\n"
                mutations_applied.append("update:tuned")

        child = MemoryArchitecture(
            name=f"evolved-{parent.domain}-gen{parent.generation + 1}",
            domain=parent.domain,
            schema_code=new_schema,
            retrieval_code=new_retrieval,
            update_rules_code=new_update,
            fitness_score=0.0,
            eval_results={},
            parent_ids=[parent.id],
            generation=parent.generation + 1,
            metadata={
                "emphasis": parent.metadata.get("emphasis", ""),
                "schema_type": new_schema_type,
                "retrieval_type": new_retrieval_type,
                "update_type": new_update_type,
                "mutations": mutations_applied,
                "mutation_rate": mutation_rate,
                "parent_fitness": parent.fitness_score,
                "scale": parent.metadata.get("scale", "medium"),
            },
        )

        return child

    def _crossover(
        self, parent_a: MemoryArchitecture, parent_b: MemoryArchitecture, seed: str
    ) -> MemoryArchitecture:
        """Create a child architecture by crossing over two parents.

        Takes components from each parent based on which parent had the
        better fitness for that component type.

        Args:
            parent_a: First parent architecture.
            parent_b: Second parent architecture.
            seed: Deterministic seed for tie-breaking.

        Returns:
            A new child :class:`MemoryArchitecture`.
        """
        # For each component, pick from the fitter parent (with randomness for exploration)
        a_schema_score = parent_a.eval_results.get("schema_quality", parent_a.fitness_score)
        b_schema_score = parent_b.eval_results.get("schema_quality", parent_b.fitness_score)
        a_retrieval_score = parent_a.eval_results.get("retrieval_quality", parent_a.fitness_score)
        b_retrieval_score = parent_b.eval_results.get("retrieval_quality", parent_b.fitness_score)
        a_update_score = parent_a.eval_results.get("update_quality", parent_a.fitness_score)
        b_update_score = parent_b.eval_results.get("update_quality", parent_b.fitness_score)

        # Schema from fitter parent (with 20% chance of picking the other)
        if _det_float(f"cross_schema:{seed}") < 0.8:
            use_a_schema = a_schema_score >= b_schema_score
        else:
            use_a_schema = a_schema_score < b_schema_score

        if _det_float(f"cross_retrieval:{seed}") < 0.8:
            use_a_retrieval = a_retrieval_score >= b_retrieval_score
        else:
            use_a_retrieval = a_retrieval_score < b_retrieval_score

        if _det_float(f"cross_update:{seed}") < 0.8:
            use_a_update = a_update_score >= b_update_score
        else:
            use_a_update = a_update_score < b_update_score

        schema_parent = parent_a if use_a_schema else parent_b
        retrieval_parent = parent_a if use_a_retrieval else parent_b
        update_parent = parent_a if use_a_update else parent_b

        gen = max(parent_a.generation, parent_b.generation) + 1

        child = MemoryArchitecture(
            name=f"crossover-{parent_a.domain}-gen{gen}",
            domain=parent_a.domain,
            schema_code=schema_parent.schema_code,
            retrieval_code=retrieval_parent.retrieval_code,
            update_rules_code=update_parent.update_rules_code,
            fitness_score=0.0,
            parent_ids=[parent_a.id, parent_b.id],
            generation=gen,
            metadata={
                "emphasis": parent_a.metadata.get("emphasis", ""),
                "schema_type": schema_parent.metadata.get("schema_type", "unknown"),
                "retrieval_type": retrieval_parent.metadata.get("retrieval_type", "unknown"),
                "update_type": update_parent.metadata.get("update_type", "unknown"),
                "crossover": True,
                "schema_from": schema_parent.id,
                "retrieval_from": retrieval_parent.id,
                "update_from": update_parent.id,
                "scale": parent_a.metadata.get("scale", "medium"),
            },
        )

        return child

    # ------------------------------------------------------------------
    # Evolutionary search
    # ------------------------------------------------------------------

    def search(
        self,
        domain: str,
        generations: int = 10,
        population_size: int = 8,
    ) -> MemoryArchitecture:
        """Run an evolutionary architecture search.

        Evolves a population of architectures over multiple generations
        using mutation, crossover, and fitness-based selection.

        Args:
            domain: Target domain for the architecture.
            generations: Number of evolutionary generations to run.
            population_size: Number of architectures per generation.

        Returns:
            The best :class:`MemoryArchitecture` found.
        """
        run_id = f"search-{domain}-{uuid.uuid4().hex[:8]}"

        # Initialize population from existing library + new proposals
        existing = self._library.search(domain, top_k=population_size // 2)
        population: list[MemoryArchitecture] = list(existing)

        # Fill remaining slots with new proposals
        while len(population) < population_size:
            task_dist = {
                "retrieval_heavy": _det_float(f"init_pop:{domain}:{len(population)}:ret", 0.2, 0.8),
                "update_heavy": _det_float(f"init_pop:{domain}:{len(population)}:upd", 0.1, 0.6),
                "temporal_emphasis": _det_float(
                    f"init_pop:{domain}:{len(population)}:temp", 0.1, 0.7
                ),
                "multi_hop": _det_float(f"init_pop:{domain}:{len(population)}:hop", 0.1, 0.6),
                "scale": _det_choice(
                    f"init_pop:{domain}:{len(population)}:scale", ["small", "medium", "large"]
                ),
            }
            proposed = self.propose(domain, task_dist)
            population.append(proposed)

        # Generate evaluation tasks
        eval_tasks = self._generate_eval_tasks(domain, count=20)

        # Evaluate initial population
        for arch in population:
            if arch.fitness_score <= 0:
                self.evaluate(arch, eval_tasks)

        generation_log: list[dict[str, Any]] = []
        best_overall: MemoryArchitecture = max(population, key=lambda a: a.fitness_score)

        for gen in range(generations):
            seed = f"{run_id}:gen:{gen}"

            # Sort by fitness (descending)
            population.sort(key=lambda a: a.fitness_score, reverse=True)

            gen_best = population[0]
            gen_mean = sum(a.fitness_score for a in population) / len(population)
            gen_worst = population[-1]

            generation_log.append(
                {
                    "generation": gen,
                    "best_fitness": round(gen_best.fitness_score, 6),
                    "mean_fitness": round(gen_mean, 6),
                    "worst_fitness": round(gen_worst.fitness_score, 6),
                    "best_id": gen_best.id,
                }
            )

            if gen_best.fitness_score > best_overall.fitness_score:
                best_overall = gen_best

            # Selection: keep top half
            survivors = population[: max(2, population_size // 2)]

            # Create next generation
            next_gen: list[MemoryArchitecture] = list(survivors)

            # Mutation
            mutation_rate = 0.3 - 0.02 * gen  # Decrease mutation rate over time
            mutation_rate = max(0.05, mutation_rate)

            for _i, parent in enumerate(survivors):
                if len(next_gen) >= population_size:
                    break
                child = self.evolve(parent, mutation_rate=mutation_rate)
                self.evaluate(child, eval_tasks)
                next_gen.append(child)
                self._library.add(child)

            # Crossover
            if len(survivors) >= 2:
                for i in range(min(population_size - len(next_gen), len(survivors) - 1)):
                    parent_a = survivors[i]
                    parent_b = survivors[(i + 1) % len(survivors)]
                    child = self._crossover(parent_a, parent_b, f"{seed}:cross:{i}")
                    self.evaluate(child, eval_tasks)
                    next_gen.append(child)
                    self._library.add(child)

            # Fill remaining with random mutations of the best
            while len(next_gen) < population_size:
                parent = _det_choice(f"fill:{seed}:{len(next_gen)}", survivors)
                child = self.evolve(parent, mutation_rate=mutation_rate * 1.5)
                self.evaluate(child, eval_tasks)
                next_gen.append(child)
                self._library.add(child)

            population = next_gen[:population_size]

        # Final selection
        population.sort(key=lambda a: a.fitness_score, reverse=True)
        final_best = population[0]
        if final_best.fitness_score > best_overall.fitness_score:
            best_overall = final_best

        # Add best to library if not already there
        if self._library.get(best_overall.id) is None:
            self._library.add(best_overall)

        self._search_runs.append(
            {
                "run_id": run_id,
                "domain": domain,
                "generations": generations,
                "population_size": population_size,
                "best_fitness": round(best_overall.fitness_score, 6),
                "best_id": best_overall.id,
                "generation_log": generation_log,
            }
        )

        return best_overall

    def _generate_eval_tasks(self, domain: str, count: int = 20) -> list[dict[str, Any]]:
        """Generate evaluation tasks for architecture fitness testing.

        Args:
            domain: Target domain.
            count: Number of tasks to generate.

        Returns:
            A list of task dictionaries.
        """
        task_types_by_domain: dict[str, list[str]] = {
            "legal": [
                "contract_review",
                "supersession_tracking",
                "temporal_reasoning",
                "citation_verification",
                "document_versioning",
            ],
            "finance": [
                "numerical_verification",
                "cross_doc_reconciliation",
                "regulatory_compliance",
                "materiality_judgment",
                "risk_assessment",
            ],
            "healthcare": [
                "patient_history",
                "drug_interaction",
                "clinical_evidence",
                "diagnosis_reasoning",
                "treatment_planning",
            ],
            "general": [
                "store_retrieve",
                "update_forget",
                "link_compress",
                "promote_demote",
                "multi_step_reasoning",
            ],
        }

        available_types = task_types_by_domain.get(domain, task_types_by_domain["general"])

        all_ops = [
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "SPLIT",
            "MERGE",
            "VERIFY",
            "ANNOTATE",
        ]

        tasks: list[dict[str, Any]] = []
        for i in range(count):
            seed = f"eval_task:{domain}:{i}"
            task_type = _det_choice(f"type:{seed}", available_types)
            difficulty = _det_int(f"diff:{seed}", 1, 5)
            n_ops = _det_int(f"n_ops:{seed}", 1, 4)
            ops = _det_sample(f"ops:{seed}", all_ops, n_ops)

            tasks.append(
                {
                    "type": task_type,
                    "domain": domain,
                    "difficulty": difficulty,
                    "operations_required": ops,
                    "context_size": _det_int(f"ctx:{seed}", 1024, 16384),
                }
            )

        return tasks

    # ------------------------------------------------------------------
    # Cross-domain transfer
    # ------------------------------------------------------------------

    def cross_domain_transfer(
        self,
        source_domain: str,
        target_domain: str,
    ) -> MemoryArchitecture:
        """Transfer architecture patterns from one domain to another.

        Finds the best architecture in the source domain and adapts it
        for the target domain by replacing domain-specific components
        while preserving structural patterns that generalize.

        Args:
            source_domain: Domain to transfer from.
            target_domain: Domain to transfer to.

        Returns:
            A new :class:`MemoryArchitecture` adapted for the target domain.
        """
        # Find best source architecture
        source_archs = self._library.search(source_domain, top_k=3)
        if not source_archs:
            # No source architectures: propose fresh for target
            return self.propose(
                target_domain,
                {
                    "retrieval_heavy": 0.5,
                    "update_heavy": 0.3,
                    "scale": "medium",
                },
            )

        source_best = source_archs[0]

        # Determine which components to keep vs replace
        target_patterns = _DOMAIN_PATTERNS.get(target_domain, _DOMAIN_PATTERNS["general"])

        # Schema: keep the structural pattern, adapt type if needed
        source_schema_type = str(source_best.metadata.get("schema_type", "flat_kv"))
        target_preferred_schema = target_patterns.get("preferred_schema", source_schema_type)

        # Compute transfer affinity based on domain similarity
        affinity_score = self._compute_domain_affinity(source_domain, target_domain)

        if affinity_score > 0.6:
            # Domains are similar: keep most components from source
            new_schema_type = source_schema_type
            new_retrieval_type = str(source_best.metadata.get("retrieval_type", "semantic_search"))
            new_update_type = str(source_best.metadata.get("update_type", "overwrite"))
        elif affinity_score > 0.3:
            # Moderate similarity: keep schema, replace retrieval/update
            new_schema_type = source_schema_type
            new_retrieval_type = target_patterns.get("preferred_retrieval", "semantic_search")
            new_update_type = target_patterns.get("preferred_update", "overwrite")
        else:
            # Low similarity: replace most components
            new_schema_type = target_preferred_schema
            new_retrieval_type = target_patterns.get("preferred_retrieval", "semantic_search")
            # Keep update rules from source if they are sophisticated
            source_update = str(source_best.metadata.get("update_type", "overwrite"))
            if source_update in ("merge_with_conflict", "consensus_based", "versioned_append"):
                new_update_type = source_update
            else:
                new_update_type = target_patterns.get("preferred_update", "overwrite")

        new_schema = _SCHEMA_TEMPLATES.get(new_schema_type, _SCHEMA_TEMPLATES["flat_kv"])
        new_retrieval = _RETRIEVAL_TEMPLATES.get(
            new_retrieval_type, _RETRIEVAL_TEMPLATES["simple_lookup"]
        )
        new_update = _UPDATE_RULES_TEMPLATES.get(
            new_update_type, _UPDATE_RULES_TEMPLATES["overwrite"]
        )

        transferred = MemoryArchitecture(
            name=f"transfer-{source_domain}-to-{target_domain}-gen{source_best.generation + 1}",
            domain=target_domain,
            schema_code=new_schema,
            retrieval_code=new_retrieval,
            update_rules_code=new_update,
            fitness_score=0.0,
            parent_ids=[source_best.id],
            generation=source_best.generation + 1,
            metadata={
                "emphasis": target_patterns.get("emphasis", ""),
                "schema_type": new_schema_type,
                "retrieval_type": new_retrieval_type,
                "update_type": new_update_type,
                "transfer_source": source_domain,
                "transfer_target": target_domain,
                "affinity_score": round(affinity_score, 4),
                "source_fitness": source_best.fitness_score,
                "scale": source_best.metadata.get("scale", "medium"),
            },
        )

        # Evaluate on target domain tasks
        target_tasks = self._generate_eval_tasks(target_domain, count=15)
        self.evaluate(transferred, target_tasks)

        self._library.add(transferred)

        return transferred

    def _compute_domain_affinity(self, source: str, target: str) -> float:
        """Compute affinity between two domains for transfer.

        Uses domain-specific heuristics to determine how well
        capabilities transfer between domains.

        Args:
            source: Source domain name.
            target: Target domain name.

        Returns:
            Affinity score in [0, 1].
        """
        if source == target:
            return 1.0

        # Known affinities between domain pairs
        affinities: dict[tuple[str, str], float] = {
            ("legal", "finance"): 0.55,
            ("finance", "legal"): 0.55,
            ("legal", "healthcare"): 0.35,
            ("healthcare", "legal"): 0.35,
            ("finance", "healthcare"): 0.40,
            ("healthcare", "finance"): 0.40,
            ("general", "legal"): 0.30,
            ("general", "finance"): 0.30,
            ("general", "healthcare"): 0.30,
            ("legal", "general"): 0.45,
            ("finance", "general"): 0.45,
            ("healthcare", "general"): 0.45,
        }

        return affinities.get((source, target), _det_float(f"affinity:{source}:{target}", 0.2, 0.5))

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary of the discovery engine state.

        Returns:
            A dictionary with search run history and library statistics.
        """
        return {
            "library": self._library.summary(),
            "search_runs": len(self._search_runs),
            "evaluation_cache_size": len(self._evaluation_cache),
            "search_history": [
                {
                    "run_id": run["run_id"],
                    "domain": run["domain"],
                    "generations": run["generations"],
                    "best_fitness": run["best_fitness"],
                    "best_id": run["best_id"],
                }
                for run in self._search_runs
            ],
        }
