"""Experience replay buffer for training stability.

Stores past rollout experiences and supports uniform, prioritised, and
stratified sampling strategies.  The buffer is used to mix current
training data with historical experiences for anti-forgetting and
training stability.
"""

from __future__ import annotations

import hashlib
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class Experience:
    """A single experience entry in the replay buffer."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    rollout_id: str = ""
    prompt: str = ""
    trajectory_summary: str = ""
    reward: float = 0.0
    domain: str = "general"
    difficulty: int = 1
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Replay Buffer
# ---------------------------------------------------------------------------


def _det_float(seed: str) -> float:
    """Deterministic float in [0, 1)."""
    digest = hashlib.sha256(seed.encode()).hexdigest()
    return int(digest[:8], 16) / 0xFFFFFFFF


class ReplayBuffer:
    """Priority-aware experience replay buffer.

    Supports three sampling strategies:

    * **uniform** — each experience has equal probability.
    * **prioritised** — higher-reward experiences are sampled more
      often, controlled by ``priority_alpha``.
    * **stratified** — balanced sampling across domains and difficulty
      levels to ensure diverse training batches.
    """

    def __init__(
        self,
        capacity: int = 10_000,
        priority_alpha: float = 0.6,
    ) -> None:
        self._capacity = capacity
        self._priority_alpha = priority_alpha

        # Core storage
        self._experiences: list[Experience] = []
        self._id_to_idx: dict[str, int] = {}

        # Priority tracking  (higher = more likely to be sampled)
        self._priorities: dict[str, float] = {}

        # Indices for efficient domain/difficulty lookup
        self._domain_index: dict[str, list[str]] = defaultdict(list)
        self._difficulty_index: dict[int, list[str]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def add(self, experience: Experience) -> None:
        """Add an experience to the buffer.

        If the buffer is at capacity, the lowest-priority experience is
        evicted.  Priority is set from the reward (shifted to be positive).

        Args:
            experience: The experience to add.
        """
        # Evict if at capacity
        if len(self._experiences) >= self._capacity:
            self._evict_lowest_priority()

        idx = len(self._experiences)
        self._experiences.append(experience)
        self._id_to_idx[experience.id] = idx

        # Priority = |reward| + small epsilon so nothing is zero
        priority = abs(experience.reward) + 1e-6
        self._priorities[experience.id] = priority

        self._domain_index[experience.domain].append(experience.id)
        self._difficulty_index[experience.difficulty].append(experience.id)

    def _evict_lowest_priority(self) -> None:
        """Remove the experience with the lowest priority."""
        if not self._priorities:
            return

        min_id = min(self._priorities, key=lambda k: self._priorities[k])
        self._remove_by_id(min_id)

    def _remove_by_id(self, exp_id: str) -> None:
        """Remove an experience by its ID."""
        idx = self._id_to_idx.get(exp_id)
        if idx is None:
            return

        exp = self._experiences[idx]

        # Remove from indices
        if exp.id in self._domain_index.get(exp.domain, []):
            self._domain_index[exp.domain].remove(exp.id)
        if exp.id in self._difficulty_index.get(exp.difficulty, []):
            self._difficulty_index[exp.difficulty].remove(exp.id)

        # Swap with last element for O(1) removal from list
        last_idx = len(self._experiences) - 1
        if idx != last_idx:
            last_exp = self._experiences[last_idx]
            self._experiences[idx] = last_exp
            self._id_to_idx[last_exp.id] = idx

        self._experiences.pop()
        del self._id_to_idx[exp_id]
        self._priorities.pop(exp_id, None)

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def sample(
        self,
        batch_size: int,
        strategy: str = "prioritized",
    ) -> list[Experience]:
        """Sample experiences from the buffer.

        Args:
            batch_size: Number of experiences to sample.
            strategy: One of ``"uniform"``, ``"prioritized"``, or
                ``"stratified"``.

        Returns:
            A list of sampled experiences.
        """
        if not self._experiences:
            return []

        batch_size = min(batch_size, len(self._experiences))

        if strategy == "uniform":
            return self._sample_uniform(batch_size)
        elif strategy == "stratified":
            return self._sample_stratified(batch_size)
        else:
            return self._sample_prioritized(batch_size)

    def _sample_uniform(self, batch_size: int) -> list[Experience]:
        """Uniform random sampling (deterministic via hashing)."""
        indices: list[int] = []
        n = len(self._experiences)
        seen: set[int] = set()

        for i in range(batch_size * 3):  # oversample to handle collisions
            if len(indices) >= batch_size:
                break
            seed = f"uniform:{i}:{n}:{id(self)}"
            idx = int(_det_float(seed) * n)
            idx = min(idx, n - 1)
            if idx not in seen:
                seen.add(idx)
                indices.append(idx)

        return [self._experiences[i] for i in indices[:batch_size]]

    def _sample_prioritized(self, batch_size: int) -> list[Experience]:
        """Priority-weighted sampling.

        Probability of sampling experience ``i`` is proportional to
        ``priority_i ^ alpha``.
        """
        if not self._priorities:
            return self._sample_uniform(batch_size)

        # Build priority-weighted CDF
        id_list = list(self._id_to_idx.keys())
        weights = [self._priorities.get(eid, 1e-6) ** self._priority_alpha for eid in id_list]
        total_weight = sum(weights) or 1e-10
        cdf: list[float] = []
        cumulative = 0.0
        for w in weights:
            cumulative += w / total_weight
            cdf.append(cumulative)

        sampled: list[Experience] = []
        seen_ids: set[str] = set()

        for i in range(batch_size * 3):
            if len(sampled) >= batch_size:
                break
            roll = _det_float(f"priority:{i}:{len(self._experiences)}")
            # Binary search in CDF
            lo, hi = 0, len(cdf) - 1
            while lo < hi:
                mid = (lo + hi) // 2
                if cdf[mid] < roll:
                    lo = mid + 1
                else:
                    hi = mid

            eid = id_list[lo]
            if eid not in seen_ids:
                seen_ids.add(eid)
                idx = self._id_to_idx[eid]
                sampled.append(self._experiences[idx])

        return sampled

    def _sample_stratified(self, batch_size: int) -> list[Experience]:
        """Stratified sampling — balanced across domains and difficulties.

        Divides the batch equally across domains, then within each domain
        slice balances across difficulty levels.
        """
        domains = [d for d, ids in self._domain_index.items() if ids]
        if not domains:
            return self._sample_uniform(batch_size)

        per_domain = max(1, batch_size // len(domains))
        remainder = batch_size - per_domain * len(domains)
        sampled: list[Experience] = []

        for di, domain in enumerate(domains):
            domain_ids = self._domain_index[domain]
            if not domain_ids:
                continue

            n_for_domain = per_domain + (1 if di < remainder else 0)
            # Group by difficulty within this domain
            diff_groups: dict[int, list[str]] = defaultdict(list)
            for eid in domain_ids:
                idx = self._id_to_idx.get(eid)
                if idx is not None:
                    exp = self._experiences[idx]
                    diff_groups[exp.difficulty].append(eid)

            diffs = sorted(diff_groups.keys())
            if not diffs:
                continue

            per_diff = max(1, n_for_domain // len(diffs))
            diff_remainder = n_for_domain - per_diff * len(diffs)
            seen: set[str] = set()

            for dj, diff in enumerate(diffs):
                n_for_diff = per_diff + (1 if dj < diff_remainder else 0)
                candidates = diff_groups[diff]
                for ki in range(min(n_for_diff, len(candidates))):
                    seed = f"stratified:{domain}:{diff}:{ki}"
                    ci = int(_det_float(seed) * len(candidates))
                    ci = min(ci, len(candidates) - 1)
                    eid = candidates[ci]
                    if eid not in seen:
                        seen.add(eid)
                        idx = self._id_to_idx.get(eid)
                        if idx is not None:
                            sampled.append(self._experiences[idx])

        return sampled[:batch_size]

    def sample_for_domain(self, domain: str, batch_size: int) -> list[Experience]:
        """Sample experiences belonging to a specific domain.

        Args:
            domain: Domain to sample from.
            batch_size: Number of experiences.

        Returns:
            A list of sampled experiences from the given domain.
        """
        domain_ids = self._domain_index.get(domain, [])
        if not domain_ids:
            return []

        batch_size = min(batch_size, len(domain_ids))
        sampled: list[Experience] = []
        seen: set[str] = set()

        for i in range(batch_size * 3):
            if len(sampled) >= batch_size:
                break
            seed = f"domain_sample:{domain}:{i}"
            ci = int(_det_float(seed) * len(domain_ids))
            ci = min(ci, len(domain_ids) - 1)
            eid = domain_ids[ci]
            if eid not in seen:
                seen.add(eid)
                idx = self._id_to_idx.get(eid)
                if idx is not None:
                    sampled.append(self._experiences[idx])

        return sampled

    def maintenance_sample(self, domain: str, ratio: float = 0.15) -> list[Experience]:
        """Sample maintenance examples for anti-forgetting.

        Returns a small batch from the specified domain, sized as a
        fraction of the domain's total experience count.  Intended to
        be mixed into training batches for a new domain to prevent
        catastrophic forgetting.

        Args:
            domain: The previous domain to maintain.
            ratio: Fraction of domain experiences to sample (0.15 = 15%).

        Returns:
            A list of maintenance experiences.
        """
        domain_ids = self._domain_index.get(domain, [])
        if not domain_ids:
            return []

        batch_size = max(1, int(len(domain_ids) * ratio))
        return self.sample_for_domain(domain, batch_size)

    # ------------------------------------------------------------------
    # Priority updates & maintenance
    # ------------------------------------------------------------------

    def update_priority(self, experience_id: str, new_priority: float) -> None:
        """Update the priority of an experience.

        Args:
            experience_id: The experience to update.
            new_priority: New priority value (>= 0).
        """
        if experience_id in self._priorities:
            self._priorities[experience_id] = max(new_priority, 1e-6)

    def remove_stale(self, max_age_hours: int = 168) -> int:
        """Remove experiences older than a threshold.

        Args:
            max_age_hours: Maximum age in hours (default 168 = 1 week).

        Returns:
            Number of experiences removed.
        """
        cutoff = datetime.now(tz=UTC) - timedelta(hours=max_age_hours)
        stale_ids: list[str] = []

        for exp in self._experiences:
            if exp.timestamp < cutoff:
                stale_ids.append(exp.id)

        for eid in stale_ids:
            self._remove_by_id(eid)

        return len(stale_ids)

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return buffer statistics.

        Includes counts by domain, by difficulty, and reward distribution.
        """
        if not self._experiences:
            return {
                "total": 0,
                "capacity": self._capacity,
                "utilization": 0.0,
                "domains": {},
                "difficulties": {},
                "reward_stats": {},
            }

        rewards = [e.reward for e in self._experiences]
        mean_r = sum(rewards) / len(rewards)
        min_r = min(rewards)
        max_r = max(rewards)
        var_r = sum((r - mean_r) ** 2 for r in rewards) / len(rewards)

        domain_counts: dict[str, int] = {}
        for domain, ids in self._domain_index.items():
            if ids:
                domain_counts[domain] = len(ids)

        difficulty_counts: dict[int, int] = {}
        for diff, ids in self._difficulty_index.items():
            if ids:
                difficulty_counts[diff] = len(ids)

        return {
            "total": len(self._experiences),
            "capacity": self._capacity,
            "utilization": round(len(self._experiences) / self._capacity, 4),
            "domains": domain_counts,
            "difficulties": difficulty_counts,
            "reward_stats": {
                "mean": round(mean_r, 4),
                "min": round(min_r, 4),
                "max": round(max_r, 4),
                "std": round(var_r**0.5, 4),
            },
        }

    def __len__(self) -> int:
        return len(self._experiences)

    def __contains__(self, experience_id: str) -> bool:
        return experience_id in self._id_to_idx
