"""Cross-domain transfer protocol for catastrophic forgetting prevention.

When training for Domain B after prior training on Domain A:
- Maintenance curriculum: 15-20% examples from Domain A
- Continuous monitoring: Domain A eval every 100 steps, halt if <95% baseline
- EWC parameter locking for critical parameters
- Experience replay with configurable ratio
- Interference tracking graph
- Separate adapter fallback if interference exceeds threshold

This module provides both the original transfer protocol classes (used
by the training engine) and the enhanced transfer learning graph and
cross-domain manager for advanced catastrophic forgetting prevention.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.training.replay_buffer import ReplayBuffer

__all__ = [
    # Original classes (backward-compatible)
    "TransferEdge",
    "TransferGraph",
    "TransferConfig",
    "TransferProtocol",
    # New enhanced classes
    "TransferLearningGraph",
    "CrossDomainTransferManager",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _det_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Return a deterministic float in [low, high] derived from *seed*."""
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return low + int(digest[:8], 16) / 0xFFFFFFFF * (high - low)


def _det_int(seed: str, low: int, high: int) -> int:
    """Return a deterministic integer in [low, high] derived from *seed*."""
    return int(_det_float(seed, float(low), float(high) + 0.999))


# ---------------------------------------------------------------------------
# Data structures (original, backward-compatible)
# ---------------------------------------------------------------------------


@dataclass
class TransferEdge:
    """Directed edge in the transfer graph between two domains."""

    source_domain: str
    target_domain: str
    transfer_score: float = 0.0
    interference_score: float = 0.0
    shared_skills: list[str] = field(default_factory=list)


@dataclass
class TransferConfig:
    """Configuration for the transfer protocol.

    Attributes:
        source_domain: The domain previously trained (to protect).
        target_domain: The domain to train next.
        maintenance_ratio: Fraction of training batch from source domain (0.15 = 15%).
        eval_interval: Steps between source domain eval checks.
        performance_threshold: Halt if source domain drops below this fraction of baseline.
        ewc_lambda: Elastic Weight Consolidation regularization strength.
        interference_threshold: Interference level that triggers warnings.
        use_separate_adapter: Whether to use a separate LoRA adapter (fallback mode).
        monitor_interval: Alias for eval_interval (backward compatibility).
        separate_adapter_threshold: Interference threshold for recommending separate adapter.
    """

    source_domain: str = ""
    target_domain: str = ""
    maintenance_ratio: float = 0.15
    eval_interval: int = 100
    performance_threshold: float = 0.95
    ewc_lambda: float = 0.5
    interference_threshold: float = 0.05
    use_separate_adapter: bool = False
    monitor_interval: int = 100
    separate_adapter_threshold: float = 0.1


# ---------------------------------------------------------------------------
# Transfer Graph (original, backward-compatible)
# ---------------------------------------------------------------------------


class TransferGraph:
    """Directed graph tracking transferability between domains.

    Each edge records how well capabilities transfer from a source
    domain to a target domain and the interference risk.
    """

    def __init__(self) -> None:
        self._edges: dict[tuple[str, str], TransferEdge] = {}
        self._nodes: set[str] = set()

    def add_edge(
        self,
        source: str,
        target: str,
        transfer_score: float,
        interference_score: float,
        shared_skills: list[str] | None = None,
    ) -> TransferEdge:
        """Add or update a directed transfer edge.

        Args:
            source: Source domain.
            target: Target domain.
            transfer_score: How much source training helps target (0-1).
            interference_score: How much target training hurts source (0-1).
            shared_skills: Skills that overlap between domains.

        Returns:
            The created or updated :class:`TransferEdge`.
        """
        self._nodes.add(source)
        self._nodes.add(target)

        edge = TransferEdge(
            source_domain=source,
            target_domain=target,
            transfer_score=transfer_score,
            interference_score=interference_score,
            shared_skills=shared_skills or [],
        )
        self._edges[(source, target)] = edge
        return edge

    def get_transfer_score(self, source: str, target: str) -> float:
        """Get the transfer score from source to target.

        Returns 0.0 if no edge exists.
        """
        edge = self._edges.get((source, target))
        return edge.transfer_score if edge else 0.0

    def get_interference(self, source: str, target: str) -> float:
        """Get the interference score when training target after source.

        Returns 0.0 if no edge exists.
        """
        edge = self._edges.get((source, target))
        return edge.interference_score if edge else 0.0

    def best_source_for(self, target: str) -> str | None:
        """Find the best transfer source for a target domain.

        Selects the source with the highest transfer score that also
        has low interference (below the median interference across all
        edges to this target).

        Args:
            target: The target domain.

        Returns:
            The best source domain name, or None if no edges exist.
        """
        candidates: list[tuple[str, float, float]] = []
        for (src, tgt), edge in self._edges.items():
            if tgt == target:
                candidates.append((src, edge.transfer_score, edge.interference_score))

        if not candidates:
            return None

        if len(candidates) == 1:
            return candidates[0][0]

        # Sort by transfer_score descending, then interference ascending
        candidates.sort(key=lambda x: (-x[1], x[2]))

        # Among the top transfer candidates, prefer low interference
        # Use a composite score: transfer - 2 * interference
        best = max(candidates, key=lambda x: x[1] - 2.0 * x[2])
        return best[0]

    def to_dict(self) -> dict[str, Any]:
        """Serialise the graph to a dictionary."""
        edges_list: list[dict[str, Any]] = []
        for edge in self._edges.values():
            edges_list.append(
                {
                    "source": edge.source_domain,
                    "target": edge.target_domain,
                    "transfer_score": round(edge.transfer_score, 4),
                    "interference_score": round(edge.interference_score, 4),
                    "shared_skills": edge.shared_skills,
                }
            )

        return {
            "nodes": sorted(self._nodes),
            "edges": edges_list,
            "edge_count": len(self._edges),
        }


# ---------------------------------------------------------------------------
# Transfer Protocol (original, backward-compatible)
# ---------------------------------------------------------------------------


class TransferProtocol:
    """Manages cross-domain transfer training.

    Coordinates maintenance sampling, interference monitoring, and
    curriculum mixing when training on a new domain while preserving
    capabilities from previous domains.
    """

    def __init__(
        self,
        config: TransferConfig | None = None,
        replay_buffer: ReplayBuffer | None = None,
    ) -> None:
        self._config = config or TransferConfig()
        self._replay_buffer = replay_buffer
        self._graph = TransferGraph()
        self._interference_history: dict[str, list[float]] = {}
        self._transfer_runs: list[dict[str, Any]] = []

    @property
    def graph(self) -> TransferGraph:
        """Access the underlying transfer graph."""
        return self._graph

    # ------------------------------------------------------------------
    # Transfer preparation
    # ------------------------------------------------------------------

    def prepare_transfer(
        self,
        source_domain: str,
        target_domain: str,
    ) -> dict[str, Any]:
        """Set up transfer training from source to target.

        Computes the transfer plan including:
        - Maintenance ratio and curriculum mix
        - Parameter constraints (which params to protect)
        - Monitoring schedule

        If a replay buffer is available, maintenance samples are drawn
        from it.

        Args:
            source_domain: The domain trained first (to protect).
            target_domain: The domain to train next.

        Returns:
            A transfer plan dictionary.
        """
        plan: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "source_domain": source_domain,
            "target_domain": target_domain,
            "maintenance_ratio": self._config.maintenance_ratio,
            "interference_threshold": self._config.interference_threshold,
            "monitor_interval": self._config.monitor_interval,
            "created_at": datetime.now(tz=UTC).isoformat(),
        }

        # Check if we have transfer graph data
        transfer_score = self._graph.get_transfer_score(source_domain, target_domain)
        interference = self._graph.get_interference(source_domain, target_domain)

        plan["known_transfer_score"] = round(transfer_score, 4)
        plan["known_interference"] = round(interference, 4)

        # Adjust maintenance ratio based on known interference
        if interference > self._config.interference_threshold:
            # Higher interference -> higher maintenance ratio
            adjusted_ratio = min(
                0.5,  # cap at 50%
                self._config.maintenance_ratio * (1.0 + interference * 5),
            )
            plan["adjusted_maintenance_ratio"] = round(adjusted_ratio, 4)
            plan["warning"] = (
                f"High interference ({interference:.2%}) detected between "
                f"'{source_domain}' and '{target_domain}'. Maintenance ratio "
                f"increased to {adjusted_ratio:.1%}."
            )
        else:
            plan["adjusted_maintenance_ratio"] = self._config.maintenance_ratio

        # Prepare maintenance samples
        if self._replay_buffer is not None:
            maintenance = self._replay_buffer.maintenance_sample(
                source_domain,
                ratio=plan["adjusted_maintenance_ratio"],
            )
            plan["maintenance_sample_count"] = len(maintenance)
            plan["maintenance_sample_ids"] = [e.id for e in maintenance]
        else:
            plan["maintenance_sample_count"] = 0
            plan["maintenance_sample_ids"] = []

        # Recommendation on whether to use separate adapter
        if interference > self._config.separate_adapter_threshold:
            plan["recommendation"] = "separate_adapter"
            plan["recommendation_reason"] = (
                f"Interference score ({interference:.2%}) exceeds the separate-"
                f"adapter threshold ({self._config.separate_adapter_threshold:.2%}). "
                f"Recommend training a separate LoRA adapter for '{target_domain}'."
            )
        else:
            plan["recommendation"] = "shared_adapter"
            plan["recommendation_reason"] = (
                f"Interference is manageable ({interference:.2%}). "
                f"Shared adapter with maintenance mixing should suffice."
            )

        # Initialize interference tracking for this run
        run_key = f"{source_domain}->{target_domain}"
        self._interference_history[run_key] = []

        self._transfer_runs.append(plan)
        return plan

    # ------------------------------------------------------------------
    # Interference monitoring
    # ------------------------------------------------------------------

    def monitor_interference(
        self,
        source_scores: list[float],
        baseline_score: float,
    ) -> dict[str, Any]:
        """Check if target training is hurting source domain performance.

        Compares the latest source domain scores against a baseline
        (typically the source score at the end of source training).

        Args:
            source_scores: Recent evaluation scores on the source domain.
            baseline_score: The source domain score before target training.

        Returns:
            A dict with interference analysis and recommendations.
        """
        if not source_scores:
            return {
                "interference_detected": False,
                "score_drop": 0.0,
                "recommendation": "No scores to evaluate.",
            }

        current_mean = sum(source_scores) / len(source_scores)
        score_drop = baseline_score - current_mean
        relative_drop = score_drop / max(abs(baseline_score), 1e-6)

        # Track history
        run_keys = list(self._interference_history.keys())
        if run_keys:
            latest_key = run_keys[-1]
            self._interference_history[latest_key].append(score_drop)

        # Determine if interference is significant
        detected = score_drop > self._config.interference_threshold

        # Check for trend (getting worse over time)
        trend = "stable"
        if run_keys:
            history = self._interference_history.get(run_keys[-1], [])
            if len(history) >= 3:
                recent_3 = history[-3:]
                if all(recent_3[i] < recent_3[i + 1] for i in range(len(recent_3) - 1)):
                    trend = "worsening"
                elif all(recent_3[i] > recent_3[i + 1] for i in range(len(recent_3) - 1)):
                    trend = "improving"

        # Build recommendation
        if not detected:
            recommendation = "No significant interference detected. Continue training."
        elif trend == "worsening":
            recommendation = (
                f"Interference is worsening (score drop: {score_drop:.4f}, "
                f"relative: {relative_drop:.2%}). Consider increasing "
                f"maintenance ratio or switching to a separate adapter."
            )
        elif score_drop > self._config.separate_adapter_threshold:
            recommendation = (
                f"Severe interference detected (score drop: {score_drop:.4f}). "
                f"Strongly recommend separate LoRA adapter."
            )
        else:
            recommendation = (
                f"Moderate interference detected (score drop: {score_drop:.4f}). "
                f"Increase maintenance ratio and monitor closely."
            )

        return {
            "interference_detected": detected,
            "score_drop": round(score_drop, 6),
            "relative_drop": round(relative_drop, 6),
            "current_mean": round(current_mean, 6),
            "baseline_score": round(baseline_score, 6),
            "trend": trend,
            "recommendation": recommendation,
        }

    # ------------------------------------------------------------------
    # Curriculum mixing
    # ------------------------------------------------------------------

    def build_mixed_curriculum(
        self,
        source_domain: str,
        target_domain: str,
        target_tasks: list[dict[str, Any]],
        maintenance_ratio: float | None = None,
    ) -> list[dict[str, Any]]:
        """Build a mixed training curriculum for transfer.

        Interleaves target-domain tasks with maintenance examples from
        the source domain drawn from the replay buffer.

        Args:
            source_domain: Domain to maintain.
            target_domain: Domain to train.
            target_tasks: List of target-domain training task dicts.
            maintenance_ratio: Override for the config maintenance ratio.

        Returns:
            A mixed list of tasks with source maintenance examples
            interleaved.
        """
        ratio = (
            maintenance_ratio if maintenance_ratio is not None else self._config.maintenance_ratio
        )

        if not target_tasks:
            return []

        # Calculate how many maintenance tasks to add
        n_maintenance = max(1, int(len(target_tasks) * ratio / (1.0 - ratio)))

        # Get maintenance examples from replay buffer
        maintenance_tasks: list[dict[str, Any]] = []
        if self._replay_buffer is not None:
            maintenance_experiences = self._replay_buffer.maintenance_sample(
                source_domain,
                ratio=min(ratio * 2, 1.0),
            )
            for exp in maintenance_experiences[:n_maintenance]:
                maintenance_tasks.append(
                    {
                        "id": str(uuid.uuid4()),
                        "prompt": exp.prompt,
                        "domain": source_domain,
                        "difficulty": exp.difficulty,
                        "is_maintenance": True,
                        "source_experience_id": exp.id,
                        "reward_baseline": exp.reward,
                        "metadata": {"maintenance": True, "from_buffer": True},
                    }
                )

        if not maintenance_tasks:
            # No replay buffer data available: synthesize maintenance prompts
            # from target tasks so transfer still uses meaningful source refresh.
            source_anchor = {
                "legal": "contract terms, obligations, and compliance clauses",
                "finance": "financial statements, ratios, and risk disclosures",
                "safety": "policy boundaries, harm prevention, and escalation rules",
            }.get(source_domain, f"{source_domain} domain fundamentals")

            for i in range(n_maintenance):
                target_task = target_tasks[i % len(target_tasks)]
                target_prompt = str(target_task.get("prompt", "")).strip()
                target_difficulty = int(target_task.get("difficulty", 2))
                maintenance_prompt = (
                    f"[maintenance:{source_domain}] Reconcile {source_anchor} with current task: "
                    f"{target_prompt}"
                    if target_prompt
                    else f"[maintenance:{source_domain}] Review {source_anchor}."
                )
                maintenance_tasks.append(
                    {
                        "id": str(uuid.uuid4()),
                        "prompt": maintenance_prompt,
                        "domain": source_domain,
                        "difficulty": max(1, min(5, target_difficulty)),
                        "is_maintenance": True,
                        "metadata": {
                            "maintenance": True,
                            "synthetic": True,
                            "source_anchor": source_anchor,
                            "target_domain": target_domain,
                            "target_task_id": target_task.get("id"),
                        },
                    }
                )

        # Interleave: insert maintenance tasks evenly through target tasks
        mixed: list[dict[str, Any]] = []
        maintenance_interval = max(1, len(target_tasks) // max(len(maintenance_tasks), 1))
        mi = 0  # maintenance index

        for ti, task in enumerate(target_tasks):
            mixed.append(task)
            # Insert a maintenance task at regular intervals
            if (ti + 1) % maintenance_interval == 0 and mi < len(maintenance_tasks):
                mixed.append(maintenance_tasks[mi])
                mi += 1

        # Append any remaining maintenance tasks at the end
        while mi < len(maintenance_tasks):
            mixed.append(maintenance_tasks[mi])
            mi += 1

        return mixed

    # ------------------------------------------------------------------
    # Adapter decision
    # ------------------------------------------------------------------

    def should_separate_adapter(self, interference_history: list[float]) -> bool:
        """Determine if a separate LoRA adapter is warranted.

        Returns True if the mean interference over the history exceeds
        the configured threshold, or if there is a consistent worsening
        trend.

        Args:
            interference_history: List of interference score measurements
                (score drops from baseline).

        Returns:
            True if a separate adapter is recommended.
        """
        if not interference_history:
            return False

        mean_interference = sum(interference_history) / len(interference_history)

        # Check mean exceeds threshold
        if mean_interference > self._config.separate_adapter_threshold:
            return True

        # Check for consistent worsening over the last 5+ measurements
        if len(interference_history) >= 5:
            last_5 = interference_history[-5:]
            consistently_above = all(v > self._config.interference_threshold for v in last_5)
            if consistently_above:
                return True

            # Check monotonically increasing trend
            monotonic_increase = all(last_5[i] < last_5[i + 1] for i in range(len(last_5) - 1))
            if monotonic_increase and last_5[-1] > self._config.interference_threshold:
                return True

        return False

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary of transfer protocol state."""
        return {
            "graph": self._graph.to_dict(),
            "config": {
                "maintenance_ratio": self._config.maintenance_ratio,
                "interference_threshold": self._config.interference_threshold,
                "monitor_interval": self._config.monitor_interval,
                "separate_adapter_threshold": self._config.separate_adapter_threshold,
            },
            "transfer_runs": len(self._transfer_runs),
            "interference_histories": {
                k: {
                    "measurements": len(v),
                    "mean": round(sum(v) / len(v), 6) if v else 0.0,
                    "max": round(max(v), 6) if v else 0.0,
                }
                for k, v in self._interference_history.items()
            },
            "has_replay_buffer": self._replay_buffer is not None,
        }


# ===========================================================================
# NEW: Enhanced transfer learning graph and cross-domain transfer manager
# ===========================================================================


# ---------------------------------------------------------------------------
# TransferLearningGraph
# ---------------------------------------------------------------------------


class TransferLearningGraph:
    """Enhanced transfer learning graph tracking positive transfer and
    negative interference across all domain pairs.

    Extends the basic TransferGraph with historical tracking, affinity
    computation, interference risk assessment, and strategy recommendation.
    Records every transfer measurement over time for trend analysis.
    """

    def __init__(self) -> None:
        self._nodes: set[str] = set()
        self._transfer_history: dict[tuple[str, str], list[dict[str, Any]]] = {}
        self._latest_scores: dict[tuple[str, str], dict[str, float]] = {}
        self._strategy_overrides: dict[tuple[str, str], str] = {}

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    def record_transfer(
        self,
        source: str,
        target: str,
        transfer_score: float,
        interference_score: float,
    ) -> None:
        """Record a transfer measurement between two domains.

        Appends a timestamped measurement to the history and updates
        the latest score snapshot.

        Args:
            source: Source domain.
            target: Target domain.
            transfer_score: How much source training helps target (0-1).
            interference_score: How much target training hurts source (0-1).
        """
        self._nodes.add(source)
        self._nodes.add(target)

        key = (source, target)
        if key not in self._transfer_history:
            self._transfer_history[key] = []

        bounded_transfer_score = max(0.0, min(1.0, transfer_score))
        bounded_interference_score = max(0.0, min(1.0, interference_score))
        measurement: dict[str, Any] = {
            "transfer_score": bounded_transfer_score,
            "interference_score": bounded_interference_score,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "measurement_index": len(self._transfer_history[key]),
        }
        self._transfer_history[key].append(measurement)

        self._latest_scores[key] = {
            "transfer_score": bounded_transfer_score,
            "interference_score": bounded_interference_score,
        }

    # ------------------------------------------------------------------
    # Querying
    # ------------------------------------------------------------------

    def get_transfer_affinity(self, source: str, target: str) -> float:
        """Get the transfer affinity from source to target.

        Affinity combines the latest transfer score with historical
        consistency: a domain pair with consistently high transfer
        scores gets a higher affinity than one with volatile scores.

        Args:
            source: Source domain.
            target: Target domain.

        Returns:
            Transfer affinity score (0-1). Returns 0.0 if no data exists.
        """
        key = (source, target)
        history = self._transfer_history.get(key, [])

        if not history:
            return 0.0

        # Latest transfer score
        latest = self._latest_scores.get(key, {})
        latest_transfer = latest.get("transfer_score", 0.0)

        if len(history) == 1:
            return latest_transfer

        # Historical consistency bonus
        transfer_scores = [float(m["transfer_score"]) for m in history]
        mean_transfer = sum(transfer_scores) / len(transfer_scores)

        # Variance penalty: high variance reduces affinity
        variance = sum((s - mean_transfer) ** 2 for s in transfer_scores) / len(transfer_scores)
        consistency_bonus = max(0.0, 0.1 * (1.0 - min(variance * 10, 1.0)))

        # Trend bonus: improving trend increases affinity
        trend_bonus = 0.0
        if len(transfer_scores) >= 3:
            recent = transfer_scores[-3:]
            if all(recent[i] <= recent[i + 1] for i in range(len(recent) - 1)):
                trend_bonus = 0.05  # Improving trend

        affinity = 0.6 * latest_transfer + 0.3 * mean_transfer + consistency_bonus + trend_bonus
        return float(max(0.0, min(1.0, affinity)))

    def get_interference_risk(self, source: str, target: str) -> float:
        """Get the interference risk when training target after source.

        Risk combines the latest interference score with trend analysis:
        worsening interference trends increase the risk assessment.

        Args:
            source: Source domain.
            target: Target domain.

        Returns:
            Interference risk score (0-1). Returns 0.0 if no data exists.
        """
        key = (source, target)
        history = self._transfer_history.get(key, [])

        if not history:
            return 0.0

        latest = self._latest_scores.get(key, {})
        latest_interference = latest.get("interference_score", 0.0)

        if len(history) == 1:
            return latest_interference

        interference_scores = [float(m["interference_score"]) for m in history]
        mean_interference = sum(interference_scores) / len(interference_scores)

        # Variance: high variance in interference means unpredictable -> higher risk
        variance = sum((s - mean_interference) ** 2 for s in interference_scores) / len(
            interference_scores
        )
        variance_penalty = min(0.1, variance * 5)

        # Trend penalty: worsening trend increases risk
        trend_penalty = 0.0
        if len(interference_scores) >= 3:
            recent = interference_scores[-3:]
            if all(recent[i] <= recent[i + 1] for i in range(len(recent) - 1)):
                trend_penalty = 0.1  # Worsening trend

        # Peak penalty: if interference has ever been very high, maintain elevated risk
        peak_interference = max(interference_scores)
        peak_penalty = max(0.0, (peak_interference - 0.5) * 0.2) if peak_interference > 0.5 else 0.0

        risk = (
            0.5 * latest_interference
            + 0.3 * mean_interference
            + variance_penalty
            + trend_penalty
            + peak_penalty
        )
        return float(max(0.0, min(1.0, risk)))

    def recommend_strategy(self, source: str, target: str) -> str:
        """Recommend a transfer strategy for a domain pair.

        Analyzes the transfer affinity and interference risk to recommend
        one of three strategies:

        - ``"joint"``: Train both domains jointly (high affinity, low risk).
        - ``"ewc"``: Use EWC regularization (moderate affinity/risk).
        - ``"separate_adapter"``: Use separate LoRA adapters (high risk).

        Args:
            source: Source domain.
            target: Target domain.

        Returns:
            One of ``"joint"``, ``"ewc"``, or ``"separate_adapter"``.
        """
        key = (source, target)

        # Check for manual overrides
        if key in self._strategy_overrides:
            return self._strategy_overrides[key]

        affinity = self.get_transfer_affinity(source, target)
        risk = self.get_interference_risk(source, target)

        # Decision boundaries
        if risk >= 0.5:
            return "separate_adapter"
        elif risk >= 0.2:
            if affinity >= 0.6:
                return "ewc"
            else:
                return "separate_adapter"
        else:
            if affinity >= 0.4:
                return "joint"
            else:
                return "ewc"

    def set_strategy_override(self, source: str, target: str, strategy: str) -> None:
        """Manually override the recommended strategy for a domain pair.

        Args:
            source: Source domain.
            target: Target domain.
            strategy: One of ``"joint"``, ``"ewc"``, ``"separate_adapter"``.

        Raises:
            ValueError: If *strategy* is not a valid option.
        """
        valid = {"joint", "ewc", "separate_adapter"}
        if strategy not in valid:
            raise ValueError(f"Invalid strategy '{strategy}'. Must be one of: {valid}")
        self._strategy_overrides[(source, target)] = strategy

    def get_history(self, source: str, target: str) -> list[dict[str, Any]]:
        """Get the full transfer measurement history for a domain pair.

        Args:
            source: Source domain.
            target: Target domain.

        Returns:
            A list of measurement dictionaries.
        """
        return list(self._transfer_history.get((source, target), []))

    def get_all_pairs(self) -> list[tuple[str, str]]:
        """Return all domain pairs with transfer data.

        Returns:
            A list of (source, target) tuples.
        """
        return list(self._transfer_history.keys())

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary of the transfer learning graph.

        Returns:
            A dictionary with graph statistics and per-pair summaries.
        """
        pair_summaries: list[dict[str, Any]] = []
        for (src, tgt), history in self._transfer_history.items():
            transfer_scores = [m["transfer_score"] for m in history]
            interference_scores = [m["interference_score"] for m in history]

            pair_summaries.append(
                {
                    "source": src,
                    "target": tgt,
                    "measurements": len(history),
                    "latest_transfer": round(transfer_scores[-1], 4) if transfer_scores else 0.0,
                    "latest_interference": round(interference_scores[-1], 4)
                    if interference_scores
                    else 0.0,
                    "mean_transfer": round(sum(transfer_scores) / len(transfer_scores), 4)
                    if transfer_scores
                    else 0.0,
                    "mean_interference": round(
                        sum(interference_scores) / len(interference_scores), 4
                    )
                    if interference_scores
                    else 0.0,
                    "affinity": round(self.get_transfer_affinity(src, tgt), 4),
                    "risk": round(self.get_interference_risk(src, tgt), 4),
                    "recommended_strategy": self.recommend_strategy(src, tgt),
                }
            )

        return {
            "nodes": sorted(self._nodes),
            "total_pairs": len(self._transfer_history),
            "total_measurements": sum(len(h) for h in self._transfer_history.values()),
            "strategy_overrides": {
                f"{s}->{t}": v for (s, t), v in self._strategy_overrides.items()
            },
            "pairs": pair_summaries,
        }


# ---------------------------------------------------------------------------
# CrossDomainTransferManager
# ---------------------------------------------------------------------------


class CrossDomainTransferManager:
    """Advanced cross-domain transfer manager with catastrophic forgetting
    prevention.

    Orchestrates the full transfer protocol:
    - Creating maintenance curricula with configurable source domain ratio
    - Monitoring source domain performance against baseline thresholds
    - Deciding when to halt training or switch to separate adapters
    - Managing mixed batches of source and target domain data
    - Tracking interference history and recommending actions
    """

    def __init__(self, config: TransferConfig | None = None) -> None:
        self._config = config or TransferConfig()
        self._baseline_scores: dict[str, float] = {}
        self._performance_history: dict[str, list[dict[str, Any]]] = {}
        self._interference_history: list[float] = []
        self._halt_triggered: bool = False
        self._halt_reason: str = ""
        self._step_count: int = 0
        self._maintenance_count: int = 0
        self._target_count: int = 0

    @property
    def config(self) -> TransferConfig:
        """Access the transfer configuration."""
        return self._config

    @property
    def is_halted(self) -> bool:
        """Whether training has been halted due to interference."""
        return self._halt_triggered

    # ------------------------------------------------------------------
    # Baseline management
    # ------------------------------------------------------------------

    def set_baseline(self, domain: str, score: float) -> None:
        """Set the baseline performance score for a domain.

        Call this before starting transfer training to record the
        source domain's performance level to protect.

        Args:
            domain: Domain name.
            score: Baseline evaluation score (0-1).
        """
        self._baseline_scores[domain] = max(0.0, min(1.0, score))

    def get_baseline(self, domain: str) -> float:
        """Get the baseline score for a domain.

        Args:
            domain: Domain name.

        Returns:
            The baseline score, or 0.0 if not set.
        """
        return self._baseline_scores.get(domain, 0.0)

    # ------------------------------------------------------------------
    # Curriculum creation
    # ------------------------------------------------------------------

    def create_maintenance_curriculum(
        self,
        source_tasks: list[Any],
        target_tasks: list[Any],
    ) -> list[Any]:
        """Create a mixed curriculum with maintenance examples from the source domain.

        Interleaves source domain maintenance tasks with target domain
        tasks according to the configured maintenance ratio (15-20%).

        Args:
            source_tasks: Available source domain tasks.
            target_tasks: Target domain training tasks.

        Returns:
            A mixed curriculum list with source maintenance tasks interleaved.
        """
        if not target_tasks:
            return []

        ratio = self._config.maintenance_ratio
        n_target = len(target_tasks)
        n_maintenance = max(1, int(n_target * ratio / max(1.0 - ratio, 0.01)))

        # Select maintenance tasks (cycle through source tasks if needed)
        maintenance_tasks: list[Any] = []
        if source_tasks:
            for i in range(n_maintenance):
                task = source_tasks[i % len(source_tasks)]
                # Wrap in a maintenance marker if it is a dict
                if isinstance(task, dict):
                    wrapped = dict(task)
                    wrapped["_is_maintenance"] = True
                    wrapped["_maintenance_domain"] = self._config.source_domain
                    maintenance_tasks.append(wrapped)
                else:
                    maintenance_tasks.append(task)

        if not maintenance_tasks:
            return list(target_tasks)

        # Interleave maintenance tasks evenly through the target curriculum
        mixed: list[Any] = []
        interval = max(1, n_target // max(len(maintenance_tasks), 1))
        mi = 0

        for ti, task in enumerate(target_tasks):
            mixed.append(task)
            self._target_count += 1
            if (ti + 1) % interval == 0 and mi < len(maintenance_tasks):
                mixed.append(maintenance_tasks[mi])
                self._maintenance_count += 1
                mi += 1

        # Append remaining maintenance tasks
        while mi < len(maintenance_tasks):
            mixed.append(maintenance_tasks[mi])
            self._maintenance_count += 1
            mi += 1

        return mixed

    # ------------------------------------------------------------------
    # Performance monitoring
    # ------------------------------------------------------------------

    def check_source_performance(self, eval_scores: dict[str, Any]) -> bool:
        """Check if source domain performance is above the safety threshold.

        Compares the current source domain score against the baseline
        multiplied by the performance threshold (default 95%).

        Args:
            eval_scores: Evaluation scores dict with domain names as keys
                and float scores as values, OR a dict with a
                ``source_score`` key.

        Returns:
            True if source performance is above the threshold, False otherwise.
        """
        source_domain = self._config.source_domain

        # Extract source score
        if "source_score" in eval_scores:
            current_score = float(eval_scores["source_score"])
        elif source_domain in eval_scores:
            current_score = float(eval_scores[source_domain])
        else:
            # No source score available, cannot check
            return True

        baseline = self._baseline_scores.get(source_domain, 0.0)
        if baseline <= 0:
            return True  # No baseline set, cannot compare

        threshold_score = baseline * self._config.performance_threshold

        # Record history
        self._step_count += 1
        key = f"{source_domain}_performance"
        if key not in self._performance_history:
            self._performance_history[key] = []
        self._performance_history[key].append(
            {
                "step": self._step_count,
                "score": round(current_score, 6),
                "threshold": round(threshold_score, 6),
                "above_threshold": current_score >= threshold_score,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        return current_score >= threshold_score

    def should_halt(
        self,
        current_scores: dict[str, Any],
        baseline_scores: dict[str, Any],
    ) -> bool:
        """Determine if training should be halted due to unacceptable degradation.

        Halts training if the source domain score drops below the
        performance threshold (default 95% of baseline).

        Args:
            current_scores: Current evaluation scores per domain.
            baseline_scores: Baseline scores per domain before transfer.

        Returns:
            True if training should halt.
        """
        if self._halt_triggered:
            return True

        source_domain = self._config.source_domain
        if not source_domain:
            # Check all provided baselines
            for domain, baseline in baseline_scores.items():
                current = current_scores.get(domain)
                if current is not None and baseline > 0:
                    threshold = baseline * self._config.performance_threshold
                    if float(current) < threshold:
                        self._halt_triggered = True
                        self._halt_reason = (
                            f"Domain '{domain}' dropped to {float(current):.4f}, "
                            f"below {self._config.performance_threshold:.0%} of "
                            f"baseline ({baseline:.4f}). Threshold: {threshold:.4f}."
                        )
                        return True
            return False

        baseline = baseline_scores.get(source_domain, self._baseline_scores.get(source_domain, 0.0))
        current = current_scores.get(source_domain)

        if current is None or baseline <= 0:
            return False

        threshold = baseline * self._config.performance_threshold
        current_val = float(current)

        # Record interference
        interference = max(0.0, baseline - current_val)
        self._interference_history.append(interference)

        if current_val < threshold:
            self._halt_triggered = True
            self._halt_reason = (
                f"Source domain '{source_domain}' score dropped to {current_val:.4f}, "
                f"below {self._config.performance_threshold:.0%} of baseline "
                f"({baseline:.4f}). Threshold: {threshold:.4f}."
            )
            return True

        return False

    def should_use_separate_adapter(self, interference_history: list[float] | None = None) -> bool:
        """Determine if training should switch to a separate LoRA adapter.

        Recommends separate adapters when interference consistently
        exceeds the threshold, indicating that shared training is not
        viable for this domain pair.

        Args:
            interference_history: Optional explicit history. If None,
                uses the internally tracked history.

        Returns:
            True if a separate adapter is recommended.
        """
        history = (
            interference_history if interference_history is not None else self._interference_history
        )

        if not history:
            return self._config.use_separate_adapter

        mean_interference = sum(history) / len(history)

        # Mean exceeds threshold
        if mean_interference > self._config.interference_threshold:
            return True

        # Last 5 measurements all above threshold
        if len(history) >= 5:
            last_5 = history[-5:]
            if all(v > self._config.interference_threshold * 0.8 for v in last_5):
                return True

        # Monotonically increasing and latest is high
        if len(history) >= 3:
            last_3 = history[-3:]
            monotonic = all(last_3[i] <= last_3[i + 1] for i in range(len(last_3) - 1))
            if monotonic and last_3[-1] > self._config.interference_threshold:
                return True

        return self._config.use_separate_adapter

    # ------------------------------------------------------------------
    # Batch management
    # ------------------------------------------------------------------

    def get_mixed_batch(
        self,
        source_buffer: list[Any],
        target_buffer: list[Any],
        batch_size: int,
    ) -> list[Any]:
        """Create a mixed training batch from source and target buffers.

        Draws examples from both buffers according to the maintenance
        ratio to create a single training batch.

        Args:
            source_buffer: Available source domain examples.
            target_buffer: Available target domain examples.
            batch_size: Total batch size.

        Returns:
            A mixed batch list.
        """
        if batch_size <= 0:
            return []

        if not target_buffer:
            return list(source_buffer[:batch_size])

        if not source_buffer:
            return list(target_buffer[:batch_size])

        ratio = self._config.maintenance_ratio
        n_source = max(1, int(batch_size * ratio))
        n_target = batch_size - n_source

        # Ensure we do not exceed available data
        n_source = min(n_source, len(source_buffer))
        n_target = min(n_target, len(target_buffer))

        # Select examples deterministically
        batch: list[Any] = []

        # Source examples (cycle if needed)
        for i in range(n_source):
            seed = f"source_batch:{self._step_count}:{i}"
            idx = _det_int(seed, 0, len(source_buffer) - 1)
            batch.append(source_buffer[idx])

        # Target examples
        for i in range(n_target):
            seed = f"target_batch:{self._step_count}:{i}"
            idx = _det_int(seed, 0, len(target_buffer) - 1)
            batch.append(target_buffer[idx])

        # Interleave: rather than having all source then all target,
        # interleave them for better training stability
        interleaved: list[Any] = []
        source_items = batch[:n_source]
        target_items = batch[n_source:]

        si = 0
        ti = 0
        interval = max(1, n_target // max(n_source, 1))

        for item_idx in range(len(batch)):
            if si < len(source_items) and (
                ti >= len(target_items) or (item_idx + 1) % (interval + 1) == 0
            ):
                interleaved.append(source_items[si])
                si += 1
            elif ti < len(target_items):
                interleaved.append(target_items[ti])
                ti += 1
            elif si < len(source_items):
                interleaved.append(source_items[si])
                si += 1

        return interleaved

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def reset_halt(self) -> None:
        """Reset the halt state to allow training to continue.

        Call this after addressing the interference issue (e.g., by
        increasing the maintenance ratio or switching strategies).
        """
        self._halt_triggered = False
        self._halt_reason = ""

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a comprehensive summary of the transfer manager state.

        Returns:
            A dictionary with configuration, performance history,
            interference tracking, and recommendations.
        """
        interference_mean = (
            round(sum(self._interference_history) / len(self._interference_history), 6)
            if self._interference_history
            else 0.0
        )
        interference_max = (
            round(max(self._interference_history), 6) if self._interference_history else 0.0
        )

        performance_summaries: dict[str, Any] = {}
        for key, history in self._performance_history.items():
            if history:
                scores = [h["score"] for h in history]
                above_count = sum(1 for h in history if h["above_threshold"])
                performance_summaries[key] = {
                    "measurements": len(history),
                    "latest_score": round(scores[-1], 6),
                    "mean_score": round(sum(scores) / len(scores), 6),
                    "above_threshold_count": above_count,
                    "above_threshold_rate": round(above_count / len(history), 4),
                }

        return {
            "config": {
                "source_domain": self._config.source_domain,
                "target_domain": self._config.target_domain,
                "maintenance_ratio": self._config.maintenance_ratio,
                "eval_interval": self._config.eval_interval,
                "performance_threshold": self._config.performance_threshold,
                "ewc_lambda": self._config.ewc_lambda,
                "interference_threshold": self._config.interference_threshold,
                "use_separate_adapter": self._config.use_separate_adapter,
            },
            "baselines": {k: round(v, 6) for k, v in self._baseline_scores.items()},
            "halted": self._halt_triggered,
            "halt_reason": self._halt_reason,
            "step_count": self._step_count,
            "maintenance_count": self._maintenance_count,
            "target_count": self._target_count,
            "effective_maintenance_ratio": round(
                self._maintenance_count / max(self._maintenance_count + self._target_count, 1), 4
            ),
            "interference": {
                "measurements": len(self._interference_history),
                "mean": interference_mean,
                "max": interference_max,
                "should_use_separate_adapter": self.should_use_separate_adapter(),
            },
            "performance": performance_summaries,
        }
