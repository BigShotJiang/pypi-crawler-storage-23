"""Model loading utilities for Aegis training.

Handles loading HuggingFace models and tokenizers with support for:
- LoRA (Low-Rank Adaptation) via peft
- Quantization (4-bit, 8-bit) via bitsandbytes
- Automatic device placement (CPU/CUDA/MPS)
- Precision control (fp16/bf16/fp32)

All external dependencies are optional — functions raise clear errors
when required packages are missing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, cast

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Availability flags
# ---------------------------------------------------------------------------

try:
    import torch

    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer

    _HAS_TRANSFORMERS = True
except ImportError:
    _HAS_TRANSFORMERS = False

try:
    from peft import LoraConfig, TaskType, get_peft_model  # type: ignore[import-not-found]

    _HAS_PEFT = True
except ImportError:
    _HAS_PEFT = False


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class ModelConfig:
    """Configuration for model loading.

    Attributes:
        model_name: HuggingFace model identifier.
        precision: Training precision ("fp16", "bf16", "fp32").
        use_lora: Whether to apply LoRA adapter.
        lora_rank: LoRA rank.
        lora_alpha: LoRA alpha scaling.
        lora_dropout: LoRA dropout rate.
        lora_target_modules: Modules to apply LoRA to.
        quantize: Quantization mode (None, "4bit", "8bit").
        device: Target device ("auto", "cpu", "cuda", "cuda:0", "mps").
        trust_remote_code: Whether to trust remote code for model loading.
        max_seq_length: Maximum sequence length.
    """

    model_name: str = "Qwen/Qwen2.5-7B"
    precision: str = "bf16"
    use_lora: bool = True
    lora_rank: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: list[str] = field(
        default_factory=lambda: ["q_proj", "v_proj", "k_proj", "o_proj"]
    )
    quantize: str | None = None
    device: str = "auto"
    trust_remote_code: bool = True
    max_seq_length: int = 4096


# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------


def resolve_device(device: str = "auto") -> str:
    """Resolve the target device for model placement.

    Args:
        device: Device hint ("auto", "cpu", "cuda", "cuda:N", "mps").

    Returns:
        Resolved device string.
    """
    if not _HAS_TORCH:
        return "cpu"

    if device != "auto":
        return device

    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def get_torch_dtype(precision: str) -> Any:
    """Convert precision string to torch dtype.

    Args:
        precision: One of "fp16", "bf16", "fp32".

    Returns:
        Corresponding torch dtype, or None if torch is unavailable.
    """
    if not _HAS_TORCH:
        return None

    dtype_map = {
        "fp16": torch.float16,
        "bf16": torch.bfloat16,
        "fp32": torch.float32,
    }
    return dtype_map.get(precision, torch.bfloat16)


def load_tokenizer(model_name: str, trust_remote_code: bool = True) -> Any:
    """Load a HuggingFace tokenizer.

    Args:
        model_name: HuggingFace model identifier.
        trust_remote_code: Whether to trust remote code.

    Returns:
        The loaded tokenizer.

    Raises:
        RuntimeError: If transformers is not installed.
    """
    if not _HAS_TRANSFORMERS:
        raise RuntimeError(
            "transformers required for model loading. Install with: pip install 'aegis-eval[gpu]'"
        )

    tokenizer_loader = cast("Any", AutoTokenizer)
    tokenizer = tokenizer_loader.from_pretrained(
        model_name,
        trust_remote_code=trust_remote_code,
    )

    # Ensure pad token is set
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    return tokenizer


def load_model(config: ModelConfig) -> Any:
    """Load a HuggingFace model with optional quantization.

    Args:
        config: Model configuration.

    Returns:
        The loaded model (possibly quantized).

    Raises:
        RuntimeError: If required packages are not installed.
    """
    if not _HAS_TRANSFORMERS:
        raise RuntimeError(
            "transformers required for model loading. Install with: pip install 'aegis-eval[gpu]'"
        )

    device = resolve_device(config.device)
    torch_dtype = get_torch_dtype(config.precision)

    model_kwargs: dict[str, Any] = {
        "trust_remote_code": config.trust_remote_code,
    }

    if torch_dtype is not None:
        model_kwargs["torch_dtype"] = torch_dtype

    # Quantization config
    if config.quantize and _HAS_TORCH:
        try:
            from transformers import BitsAndBytesConfig

            bitsandbytes_config = cast("Any", BitsAndBytesConfig)
            if config.quantize == "4bit":
                model_kwargs["quantization_config"] = bitsandbytes_config(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch_dtype,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_use_double_quant=True,
                )
            elif config.quantize == "8bit":
                model_kwargs["quantization_config"] = bitsandbytes_config(
                    load_in_8bit=True,
                )
            logger.info("Quantization enabled: %s", config.quantize)
        except ImportError:
            logger.warning("bitsandbytes not available, skipping quantization")

    # Device map for multi-GPU or auto placement
    if device in ("auto", "cuda") and _HAS_TORCH and torch.cuda.is_available():
        model_kwargs["device_map"] = "auto"
    else:
        model_kwargs["device_map"] = None

    logger.info(
        "Loading model %s (precision=%s, device=%s, quantize=%s)",
        config.model_name,
        config.precision,
        device,
        config.quantize,
    )

    model = AutoModelForCausalLM.from_pretrained(config.model_name, **model_kwargs)

    # Move to device if no device_map was used
    if model_kwargs.get("device_map") is None and _HAS_TORCH and device != "cpu":
        model = cast("Any", model).to(device)

    return model


def apply_lora(model: Any, config: ModelConfig) -> Any:
    """Apply LoRA adapter to a model.

    Args:
        model: The base model.
        config: Configuration with LoRA parameters.

    Returns:
        The model with LoRA adapter applied.

    Raises:
        RuntimeError: If peft is not installed.
    """
    if not _HAS_PEFT:
        raise RuntimeError("peft required for LoRA. Install with: pip install 'aegis-eval[gpu]'")

    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=config.lora_rank,
        lora_alpha=config.lora_alpha,
        lora_dropout=config.lora_dropout,
        target_modules=config.lora_target_modules,
        bias="none",
    )

    model = get_peft_model(model, lora_config)

    trainable, total = 0, 0
    for param in model.parameters():
        total += param.numel()
        if param.requires_grad:
            trainable += param.numel()

    logger.info(
        "LoRA applied: rank=%d, alpha=%d, trainable=%.2fM/%.2fM (%.1f%%)",
        config.lora_rank,
        config.lora_alpha,
        trainable / 1e6,
        total / 1e6,
        100 * trainable / total if total > 0 else 0,
    )

    return model


def load_model_and_tokenizer(
    config: ModelConfig,
) -> tuple[Any, Any]:
    """Load model and tokenizer with optional LoRA and quantization.

    This is the main entry point for model preparation.

    Args:
        config: Full model configuration.

    Returns:
        Tuple of (model, tokenizer).

    Raises:
        RuntimeError: If required packages are not installed.
    """
    tokenizer = load_tokenizer(config.model_name, config.trust_remote_code)
    model = load_model(config)

    if config.use_lora:
        model = apply_lora(model, config)

    return model, tokenizer
