"""Aegis training engine — RL trainers, curriculum, rewards, and checkpoints.

Re-exports the :class:`RLTrainer` protocol, two concrete trainers
(:class:`AMIRGRPOTrainer` and :class:`GRPOSGTrainer`), plus the
curriculum progression engine, reward decomposition engine, checkpoint
manager, rollout engine, task generator, optimizers, EWC regularizer,
replay buffer, cross-domain transfer protocol, training levels,
architecture discovery, and multi-agent coordination.
"""

from aegis.core.types import RewardTraceV1
from aegis.training.architecture_discovery import (
    ArchitectureDiscoveryEngine,
    ArchitectureLibrary,
    MemoryArchitecture,
)
from aegis.training.checkpoint import Checkpoint, CheckpointManager
from aegis.training.cloud_launcher import AWSLauncher, AWSLauncherConfig, CloudLauncher
from aegis.training.curriculum import (
    CurriculumEngine,
    CurriculumLevel,
    CurriculumProgress,
)
from aegis.training.engine import AMIRGRPOTrainer, GRPOSGTrainer, RLTrainer
from aegis.training.eval_callback import EvalCallback, EvalResult
from aegis.training.ewc import EWCConfig, EWCRegularizer, ParameterImportance
from aegis.training.hf_upload import HFUploader
from aegis.training.levels import (
    TRAINING_LEVELS,
    TrainingLevel,
    TrainingLevelManager,
)
from aegis.training.model_loader import ModelConfig
from aegis.training.multi_agent import (
    AgentProfile,
    ConflictResolver,
    DeferencePolicy,
    DivisionOfLabor,
    MultiAgentCoordinator,
    RelevanceFilter,
    SharedKnowledge,
)
from aegis.training.optimizers import (
    DAPOOptimizer,
    DrGRPOOptimizer,
    ForgeOptimizer,
    GiGPOOptimizer,
    GRPOUpdate,
    OptimizerConfig,
    PODSConfig,
    PODSSelector,
)
from aegis.training.replay_buffer import Experience, ReplayBuffer
from aegis.training.reward_refinement import (
    RecursiveRewardRefiner,
    RefinementAnalysis,
    RefinementRecord,
)
from aegis.training.rewards import RewardEngine, RewardStageConfig
from aegis.training.rollout import Rollout, RolloutConfig, RolloutEngine, RolloutStep
from aegis.training.task_generator import (
    DiagnosticProfile,
    TaskDifficulty,
    TaskGenerator,
    TrainingTask,
)
from aegis.training.tracking import ExperimentTracker
from aegis.training.transfer import (
    CrossDomainTransferManager,
    TransferConfig,
    TransferEdge,
    TransferGraph,
    TransferLearningGraph,
    TransferProtocol,
)
from aegis.training.two_speed_bridge import TwoSpeedBridge

__all__ = [
    # Engine & trainers
    "RLTrainer",
    "AMIRGRPOTrainer",
    "GRPOSGTrainer",
    # Curriculum
    "CurriculumEngine",
    "CurriculumLevel",
    "CurriculumProgress",
    # Training levels
    "TrainingLevel",
    "TrainingLevelManager",
    "TRAINING_LEVELS",
    # Architecture discovery
    "MemoryArchitecture",
    "ArchitectureLibrary",
    "ArchitectureDiscoveryEngine",
    # Multi-agent coordination
    "AgentProfile",
    "SharedKnowledge",
    "RelevanceFilter",
    "ConflictResolver",
    "DivisionOfLabor",
    "DeferencePolicy",
    "MultiAgentCoordinator",
    # Rewards
    "RewardEngine",
    "RewardStageConfig",
    "RewardTraceV1",
    # Checkpoints
    "Checkpoint",
    "CheckpointManager",
    # Rollout engine
    "RolloutConfig",
    "RolloutStep",
    "Rollout",
    "RolloutEngine",
    # Task generator
    "TaskDifficulty",
    "TrainingTask",
    "DiagnosticProfile",
    "TaskGenerator",
    # Optimizers
    "OptimizerConfig",
    "GRPOUpdate",
    "PODSConfig",
    "PODSSelector",
    "DrGRPOOptimizer",
    "DAPOOptimizer",
    "GiGPOOptimizer",
    "ForgeOptimizer",
    # Eval callback
    "EvalCallback",
    "EvalResult",
    # EWC
    "ParameterImportance",
    "EWCConfig",
    "EWCRegularizer",
    # Replay buffer
    "Experience",
    "ReplayBuffer",
    # Model loader
    "ModelConfig",
    # Transfer
    "TransferEdge",
    "TransferGraph",
    "TransferLearningGraph",
    "TransferConfig",
    "TransferProtocol",
    "CrossDomainTransferManager",
    # HuggingFace upload
    "HFUploader",
    # Cloud launcher
    "CloudLauncher",
    "AWSLauncherConfig",
    "AWSLauncher",
    # Reward refinement
    "RecursiveRewardRefiner",
    "RefinementAnalysis",
    "RefinementRecord",
    # Two-speed bridge
    "TwoSpeedBridge",
    # Tracking
    "ExperimentTracker",
]
