"""Elastic Weight Consolidation for catastrophic-forgetting prevention.

Implements EWC regularisation based on Fisher information to constrain
important parameters when training on new domains, preventing the model
from forgetting previously learned capabilities.

Reference: Kirkpatrick et al., "Overcoming catastrophic forgetting in
neural networks" (PNAS 2017).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class ParameterImportance:
    """Importance score for a single parameter in a specific domain."""

    param_name: str
    importance_score: float
    domain: str


@dataclass
class EWCConfig:
    """Configuration for EWC regularisation."""

    lambda_ewc: float = 0.5
    num_samples: int = 200
    domains: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# EWC Regularizer
# ---------------------------------------------------------------------------


class EWCRegularizer:
    """Elastic Weight Consolidation regulariser.

    Computes and stores per-parameter Fisher information estimates for
    each domain.  During training on a new domain, the EWC penalty
    discourages large changes to parameters that were important for
    previous domains:

        ``penalty = lambda * sum_i( F_i * (theta_i - theta*_i)^2 )``

    where ``F_i`` is the Fisher information for parameter ``i`` and
    ``theta*_i`` is the parameter value after training on the prior domain.
    """

    def __init__(self, config: EWCConfig | None = None) -> None:
        self._config = config or EWCConfig()
        # domain -> {param_name -> importance}
        self._importances: dict[str, dict[str, float]] = {}
        # domain -> {param_name -> original_param_values}
        self._original_params: dict[str, dict[str, list[float]]] = {}
        self._importance_threshold: float = 0.01

    # ------------------------------------------------------------------
    # Fisher information
    # ------------------------------------------------------------------

    def compute_importance(self, param_name: str, gradients: list[float]) -> float:
        """Approximate Fisher information for a parameter.

        Fisher information is approximated as the mean of squared
        gradients over a set of samples:

            ``F_i = (1/N) * sum_n( g_n^2 )``

        Args:
            param_name: Name of the parameter.
            gradients: Gradient values across samples.

        Returns:
            The Fisher information estimate (>= 0).
        """
        if not gradients:
            return 0.0

        squared = [g * g for g in gradients]
        fisher = sum(squared) / len(squared)
        return fisher

    # ------------------------------------------------------------------
    # Domain registration
    # ------------------------------------------------------------------

    def register_domain(
        self,
        domain: str,
        param_importances: dict[str, float],
        param_values: dict[str, list[float]] | None = None,
    ) -> None:
        """Register parameter importances and checkpoint values for a domain.

        Call this after completing training on a domain to freeze the
        Fisher-weighted parameter snapshot.

        Args:
            domain: Domain name (e.g. "legal", "finance").
            param_importances: Mapping of param_name -> Fisher information.
            param_values: Optional mapping of param_name -> param values
                (the snapshot ``theta*``).  If not provided, penalties can
                still be computed if original params are supplied at
                penalty-computation time.
        """
        self._importances[domain] = dict(param_importances)
        if param_values is not None:
            self._original_params[domain] = {k: list(v) for k, v in param_values.items()}

        if domain not in self._config.domains:
            self._config.domains.append(domain)

    # ------------------------------------------------------------------
    # Penalty computation
    # ------------------------------------------------------------------

    def compute_penalty(
        self,
        current_params: dict[str, list[float]],
        original_params: dict[str, list[float]],
        domain: str,
    ) -> float:
        """Compute the EWC penalty for a single domain.

        ``penalty = lambda * sum_i( F_i * sum_j( (theta_ij - theta*_ij)^2 ) )``

        where ``j`` iterates over the elements of parameter ``i``.

        Args:
            current_params: Current parameter values.
            original_params: Reference parameter values (``theta*``) from
                the end of training on *domain*.
            domain: The domain whose importances to use.

        Returns:
            The scalar EWC penalty (>= 0).
        """
        importances = self._importances.get(domain, {})
        if not importances:
            return 0.0

        penalty = 0.0
        for param_name, fisher in importances.items():
            if fisher < self._importance_threshold:
                continue

            current = current_params.get(param_name, [])
            original = original_params.get(param_name, [])

            if not current or not original:
                continue

            # Sum of squared differences, element-wise
            min_len = min(len(current), len(original))
            sq_diff = sum((current[j] - original[j]) ** 2 for j in range(min_len))
            penalty += fisher * sq_diff

        return self._config.lambda_ewc * penalty

    def should_constrain(self, param_name: str, domain: str) -> bool:
        """Check whether a parameter is important for a domain.

        Returns True if the Fisher information for this parameter in
        the given domain exceeds the importance threshold.

        Args:
            param_name: The parameter to check.
            domain: The domain to check against.

        Returns:
            True if the parameter is important and should be constrained.
        """
        importances = self._importances.get(domain, {})
        return importances.get(param_name, 0.0) > self._importance_threshold

    def multi_domain_penalty(
        self,
        current_params: dict[str, list[float]],
        originals: dict[str, dict[str, list[float]]],
    ) -> float:
        """Compute combined EWC penalty across multiple domains.

        The total penalty is the sum of per-domain penalties:

            ``total = sum_d( penalty(current, original_d, domain_d) )``

        For domains where *originals* are not provided, the internally
        stored snapshots are used (if available).

        Args:
            current_params: Current parameter values.
            originals: Mapping of domain -> original parameter values.
                Domains not present here will fall back to internally
                stored snapshots.

        Returns:
            Combined scalar penalty.
        """
        total_penalty = 0.0
        all_domains = set(self._importances.keys())

        for domain in all_domains:
            # Prefer externally provided originals; fall back to stored
            if domain in originals:
                orig = originals[domain]
            elif domain in self._original_params:
                orig = self._original_params[domain]
            else:
                continue

            total_penalty += self.compute_penalty(current_params, orig, domain)

        return total_penalty

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary of registered domains and their importances."""
        domain_summaries: dict[str, dict[str, Any]] = {}
        for domain, importances in self._importances.items():
            scores = list(importances.values())
            important_count = sum(1 for s in scores if s > self._importance_threshold)
            domain_summaries[domain] = {
                "total_params": len(scores),
                "important_params": important_count,
                "mean_importance": round(sum(scores) / len(scores), 6) if scores else 0.0,
                "max_importance": round(max(scores), 6) if scores else 0.0,
                "has_stored_params": domain in self._original_params,
            }

        return {
            "lambda_ewc": self._config.lambda_ewc,
            "num_samples": self._config.num_samples,
            "registered_domains": list(self._importances.keys()),
            "importance_threshold": self._importance_threshold,
            "domains": domain_summaries,
        }
