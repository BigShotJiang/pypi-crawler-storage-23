"""Two-Speed Learning Bridge between RL training and memory operations.

Bridges the training engine's rollout-reward loop with the runtime
memory Q-value system (:mod:`aegis.memory.memrl`).  After each scored
rollout, the bridge:

1. Extracts memory operation keys from rollout steps.
2. Derives a scalar feedback signal from the reward trace.
3. Updates per-operation Q-values via :class:`MemRLUpdater`.
4. Periodically syncs discoveries back to the task generator to
   produce targeted tasks for weak memory operations.
"""

from __future__ import annotations

import logging
import re
from collections import defaultdict
from typing import Any

from aegis.core.types import RewardTraceV1
from aegis.memory.memrl import MemRLUpdater
from aegis.training.rollout import Rollout
from aegis.training.task_generator import TaskGenerator

logger = logging.getLogger(__name__)

__all__ = [
    "TwoSpeedBridge",
]

# Memory operation names (matches MemoryOperation enum values)
_ALL_OPS = frozenset(
    {
        "STORE",
        "UPDATE",
        "FORGET",
        "RETRIEVE",
        "LINK",
        "COMPRESS",
        "PROMOTE",
        "DEMOTE",
        "SPLIT",
        "MERGE",
        "VERIFY",
        "ANNOTATE",
    }
)

# Regex to find memory operation tokens in rollout step content
_OP_RE = re.compile(
    r"\b(" + "|".join(_ALL_OPS) + r")\b",
    re.IGNORECASE,
)

# Regex to extract memory keys like "key=..." or "memory_key:..." from content
_KEY_RE = re.compile(
    r"(?:key[=:]|memory_key[=:])\s*([^\s,;]+)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# TwoSpeedBridge
# ---------------------------------------------------------------------------


class TwoSpeedBridge:
    """Bridges RL training signals into runtime memory Q-value updates.

    Maintains per-operation statistics and periodically generates
    targeted training tasks for weak memory operations.

    Args:
        learning_rate: MemRL Q-value learning rate.
        discount_factor: MemRL discount factor.
        sync_interval: Sync discoveries to task generator every N rollouts.
        feedback_blend: Blend factor for deriving scalar feedback from
            reward traces (higher = more weight on total reward).
    """

    def __init__(
        self,
        learning_rate: float = 0.1,
        discount_factor: float = 0.95,
        sync_interval: int = 10,
        feedback_blend: float = 0.7,
    ) -> None:
        self._updater = MemRLUpdater(
            learning_rate=learning_rate,
            discount_factor=discount_factor,
        )
        self._sync_interval = max(1, sync_interval)
        self._feedback_blend = max(0.0, min(1.0, feedback_blend))
        self._rollout_count = 0
        self._sync_count = 0

        # Per-operation tracking
        self._op_totals: dict[str, int] = defaultdict(int)
        self._op_successes: dict[str, int] = defaultdict(int)
        self._op_reward_sums: dict[str, float] = defaultdict(float)

    # -- public API ----------------------------------------------------------

    def on_rollout_scored(self, rollout: Rollout, reward: RewardTraceV1) -> None:
        """Process a scored rollout — the main training-to-memory hook.

        Extracts memory keys and operations from the rollout, computes a
        feedback signal, and updates Q-values.

        Args:
            rollout: The completed training rollout.
            reward: The associated reward trace.
        """
        self._rollout_count += 1
        feedback = self._compute_feedback(reward)
        keys = self._extract_memory_keys(rollout)
        ops = self._extract_operations(rollout)

        if not ops:
            ops = ["RETRIEVE"]

        for op in ops:
            op_upper = op.upper()
            self._op_totals[op_upper] += 1
            self._op_reward_sums[op_upper] += feedback
            if feedback >= 0.5:
                self._op_successes[op_upper] += 1

        # Update Q-values for each extracted key
        for key in keys:
            for op in ops:
                self._updater.record_access(key, operation=op.upper())
                self._updater.update(
                    key=key,
                    feedback_score=feedback,
                    operation=op.upper(),
                    context={
                        "rollout_id": rollout.id,
                        "reward_total": reward.total_reward,
                        "source": "two_speed_bridge",
                    },
                )

        # If no explicit keys found, use rollout ID as a synthetic key
        if not keys:
            synthetic_key = f"rollout:{rollout.id}"
            for op in ops:
                self._updater.update(
                    key=synthetic_key,
                    feedback_score=feedback,
                    operation=op.upper(),
                    context={
                        "rollout_id": rollout.id,
                        "synthetic": True,
                    },
                )

    def sync_discoveries_to_tasks(self, task_gen: TaskGenerator) -> int:
        """Inject targeted tasks for weak memory operations into the task generator.

        Identifies memory operations with low Q-values or low success
        rates and generates extra tasks that exercise those operations.

        Args:
            task_gen: The training task generator to inject tasks into.

        Returns:
            The number of tasks injected.
        """
        if self._rollout_count % self._sync_interval != 0:
            return 0

        weak_ops = self._identify_weak_operations()
        if not weak_ops:
            return 0

        self._sync_count += 1
        injected = 0

        for op in weak_ops:
            tasks = task_gen.generate_for_operation(op)
            injected += len(tasks)

        logger.info(
            "Two-speed sync #%d: injected %d tasks for weak ops %s",
            self._sync_count,
            injected,
            weak_ops,
        )

        return injected

    def get_runtime_statistics(self) -> dict[str, Any]:
        """Return bridge runtime statistics.

        Returns:
            A dict with Q-value stats, update counts, and weak operation
            identification.
        """
        updater_summary = self._updater.summary()
        op_stats: dict[str, dict[str, Any]] = {}

        for op in sorted(set(list(self._op_totals.keys()) + list(self._op_successes.keys()))):
            total = self._op_totals.get(op, 0)
            successes = self._op_successes.get(op, 0)
            reward_sum = self._op_reward_sums.get(op, 0.0)
            op_stats[op] = {
                "total": total,
                "successes": successes,
                "success_rate": round(successes / total, 4) if total > 0 else 0.0,
                "mean_reward": round(reward_sum / total, 4) if total > 0 else 0.0,
            }

        return {
            "rollout_count": self._rollout_count,
            "sync_count": self._sync_count,
            "sync_interval": self._sync_interval,
            "feedback_blend": self._feedback_blend,
            "weak_operations": self._identify_weak_operations(),
            "operation_stats": op_stats,
            "memrl_summary": updater_summary,
        }

    # -- internal helpers ----------------------------------------------------

    def _extract_memory_keys(self, rollout: Rollout) -> list[str]:
        """Parse memory keys from rollout step content and metadata.

        Looks for patterns like ``key=<value>`` or ``memory_key:<value>``
        in step content, and checks step metadata for ``memory_key`` entries.

        Args:
            rollout: The rollout to extract keys from.

        Returns:
            A deduplicated list of memory key strings.
        """
        keys: list[str] = []
        seen: set[str] = set()

        for step in rollout.steps:
            # Check step metadata
            meta_key = step.metadata.get("memory_key")
            if isinstance(meta_key, str) and meta_key and meta_key not in seen:
                keys.append(meta_key)
                seen.add(meta_key)

            # Check step content via regex
            for match in _KEY_RE.finditer(step.content):
                k = match.group(1)
                if k not in seen:
                    keys.append(k)
                    seen.add(k)

            # Check for memory_op metadata indicating a key
            if step.memory_op is not None:
                op_key = step.metadata.get("key")
                if isinstance(op_key, str) and op_key and op_key not in seen:
                    keys.append(op_key)
                    seen.add(op_key)

        return keys

    def _extract_operations(self, rollout: Rollout) -> list[str]:
        """Extract memory operation names from rollout steps.

        Args:
            rollout: The rollout to inspect.

        Returns:
            A list of operation name strings (uppercase).
        """
        ops: list[str] = []
        seen: set[str] = set()

        for step in rollout.steps:
            # Explicit memory_op attribute
            if step.memory_op is not None:
                op = step.memory_op.value.upper()
                if op not in seen:
                    ops.append(op)
                    seen.add(op)

            # Regex scan of content
            for match in _OP_RE.finditer(step.content):
                op = match.group(1).upper()
                if op not in seen:
                    ops.append(op)
                    seen.add(op)

        return ops

    def _compute_feedback(self, reward: RewardTraceV1) -> float:
        """Derive a scalar feedback signal from a reward trace.

        Blends the total reward with the per-stage mean:
        ``feedback = blend * total + (1 - blend) * stage_mean``

        Clamped to [0, 1].

        Args:
            reward: The reward trace from a scored rollout.

        Returns:
            A float in [0, 1] representing the feedback signal.
        """
        total = reward.total_reward
        if reward.stages:
            stage_mean = sum(s.weighted_score for s in reward.stages) / len(reward.stages)
        else:
            stage_mean = total

        feedback = self._feedback_blend * total + (1.0 - self._feedback_blend) * stage_mean
        return max(0.0, min(1.0, feedback))

    def _identify_weak_operations(self) -> list[str]:
        """Find memory operations with low Q-values or low success rates.

        An operation is considered weak if:
        - It has been attempted at least 3 times, AND
        - Its success rate is below 0.4, OR its mean reward is below 0.4.

        Returns:
            A sorted list of weak operation names.
        """
        weak: list[str] = []

        for op in sorted(self._op_totals.keys()):
            total = self._op_totals[op]
            if total < 3:
                continue
            successes = self._op_successes.get(op, 0)
            reward_sum = self._op_reward_sums.get(op, 0.0)
            success_rate = successes / total
            mean_reward = reward_sum / total

            if success_rate < 0.4 or mean_reward < 0.4:
                weak.append(op)

        return weak
