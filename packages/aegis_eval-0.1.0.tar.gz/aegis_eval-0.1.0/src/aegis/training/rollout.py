"""Rollout engine for structured trajectory generation.

Produces multi-step rollouts in the canonical format:
``<think> -> <memory_op> -> <search> -> <evidence> -> <reason> -> <answer>``

Each rollout can be scored by the reward engine, converted to a
:class:`TrajectoryV1`, and used for GRPO group advantage computation.
"""

from __future__ import annotations

import hashlib
import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.core.types import (
    MemoryOperation,
    RewardTraceV1,
    StageReward,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)
from aegis.training.rewards import RewardEngine

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _deterministic_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Deterministic float in [low, high] from a seed string."""
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    normalised = int(digest[:8], 16) / 0xFFFFFFFF
    return low + normalised * (high - low)


def _deterministic_choice(seed: str, options: list[str]) -> str:
    """Pick one element from *options* deterministically."""
    idx = int(hashlib.sha256(seed.encode()).hexdigest()[:8], 16) % len(options)
    return options[idx]


def _deterministic_bool(seed: str, probability: float = 0.5) -> bool:
    """Return True with the given probability, deterministically."""
    return _deterministic_float(seed) < probability


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class RolloutConfig:
    """Configuration for the rollout engine."""

    max_steps: int = 12
    max_tokens: int = 4096
    temperature: float = 0.7
    memory_enabled: bool = True
    retrieval_enabled: bool = True


@dataclass
class RolloutStep:
    """A single step within a rollout."""

    step_idx: int
    kind: StepKind
    content: str
    memory_op: MemoryOperation | None = None
    search_query: str | None = None
    evidence_sources: list[str] = field(default_factory=list)
    reward: float = 0.0
    latency_ms: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Rollout:
    """A complete multi-step rollout produced by the engine."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str = ""
    steps: list[RolloutStep] = field(default_factory=list)
    context: dict[str, Any] = field(default_factory=dict)
    total_reward: float = 0.0
    total_latency_ms: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_trajectory(self) -> TrajectoryV1:
        """Convert this rollout into a :class:`TrajectoryV1`."""
        traj_steps: list[TrajectoryStep] = []
        for step in self.steps:
            meta = dict(step.metadata)
            if step.memory_op is not None:
                meta["memory_op"] = step.memory_op.value
            if step.search_query is not None:
                meta["search_query"] = step.search_query
            if step.evidence_sources:
                meta["evidence_sources"] = step.evidence_sources
            meta["reward"] = step.reward

            traj_steps.append(
                TrajectoryStep(
                    kind=step.kind,
                    content=step.content,
                    latency_ms=step.latency_ms,
                    metadata=meta,
                )
            )

        return TrajectoryV1(
            id=self.id,
            agent_id=self.context.get("agent_id", "rollout-engine"),
            task_id=self.context.get("task_id", self.id),
            steps=traj_steps,
            total_latency_ms=self.total_latency_ms,
            metadata={**self.metadata, "total_reward": self.total_reward},
        )

    def reward_by_stage(self) -> dict[str, float]:
        """Return reward totals grouped by :class:`StepKind`."""
        by_kind: dict[str, float] = {}
        for step in self.steps:
            key = step.kind.value
            by_kind[key] = by_kind.get(key, 0.0) + step.reward
        return {k: round(v, 4) for k, v in by_kind.items()}

    def step_kinds(self) -> dict[str, int]:
        """Return a count of each :class:`StepKind` in the rollout."""
        counter = Counter(step.kind.value for step in self.steps)
        return dict(counter)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


# Canonical step pipeline — each kind maps to a function that produces
# content for that step.

_THINK_PREFIXES = [
    "I need to analyze this task carefully.",
    "Let me break down what is being asked.",
    "First, I should understand the requirements.",
    "I need to consider multiple angles here.",
    "Let me think about what information I need.",
]

_SEARCH_QUERIES_LEGAL = [
    "contract supersession clauses in {topic}",
    "precedent cases involving {topic}",
    "statute of limitations for {topic}",
    "relevant case law regarding {topic}",
    "regulatory requirements for {topic}",
]

_SEARCH_QUERIES_FINANCE = [
    "quarterly earnings data for {topic}",
    "SEC filings related to {topic}",
    "market risk analysis for {topic}",
    "regulatory compliance requirements for {topic}",
    "cross-document reconciliation for {topic}",
]

_SEARCH_QUERIES_GENERAL = [
    "background information on {topic}",
    "relevant documentation for {topic}",
    "best practices regarding {topic}",
    "technical specifications for {topic}",
    "reference material on {topic}",
]

_EVIDENCE_TEMPLATES = [
    "Source [{src}] states: relevant information found regarding the query.",
    "According to [{src}]: data point confirms the hypothesis under review.",
    "From [{src}]: evidence supports the following conclusion about the topic.",
]

_REASON_TEMPLATES = [
    "Based on the evidence gathered, I can conclude that {topic} shows {assessment}.",
    "Cross-referencing the sources, the analysis indicates {assessment} for {topic}.",
    "Synthesizing the retrieved information: {topic} demonstrates {assessment}.",
]

_ANSWER_TEMPLATES = [
    "After thorough analysis, my answer is: {conclusion}",
    "Based on my reasoning and evidence review: {conclusion}",
    "In conclusion, having examined all available information: {conclusion}",
]


class RolloutEngine:
    """Generates structured multi-step rollouts.

    The engine simulates realistic agent behavior through the canonical
    pipeline: THINK -> MEMORY_OP -> SEARCH -> EVIDENCE -> REASON -> ANSWER.
    Deterministic hashing ensures reproducibility when given the same
    prompt and context.
    """

    def __init__(
        self,
        config: RolloutConfig | None = None,
        reward_engine: RewardEngine | None = None,
    ) -> None:
        self._config = config or RolloutConfig()
        self._reward_engine = reward_engine
        self._rollout_count = 0

    # ------------------------------------------------------------------
    # Internal step generators
    # ------------------------------------------------------------------

    def _gen_think_step(self, idx: int, prompt: str, seed: str) -> RolloutStep:
        """Generate a THINK step — the agent reasons about the task."""
        prefix = _deterministic_choice(f"think_prefix:{seed}", _THINK_PREFIXES)
        # Build a thinking narrative based on the prompt
        topic = prompt[:120].strip()
        content = (
            f"{prefix} The task involves: '{topic}'. "
            f"I should identify what information is needed, "
            f"check my memory for relevant prior knowledge, "
            f"and plan my retrieval strategy."
        )
        latency = int(_deterministic_float(f"think_lat:{seed}", 50, 300))
        reward = round(_deterministic_float(f"think_reward:{seed}", 0.3, 0.9), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.THINK,
            content=content,
            reward=reward,
            latency_ms=latency,
            metadata={"phase": "planning"},
        )

    def _gen_memory_op_step(
        self, idx: int, prompt: str, seed: str, memory_state: dict[str, Any] | None
    ) -> RolloutStep:
        """Generate a MEMORY_OP step — store or retrieve from memory."""
        state = memory_state or {}
        has_prior = _deterministic_bool(f"has_prior:{seed}", 0.4)

        if has_prior and state:
            # Retrieve from memory
            op = MemoryOperation.RETRIEVE
            key = _deterministic_choice(f"mem_key:{seed}", list(state.keys()) or ["context"])
            content = (
                f"Retrieving memory entry for key '{key}'. "
                f"Found relevant prior knowledge that can inform this task."
            )
        else:
            # Store initial context
            op_choices = [MemoryOperation.STORE, MemoryOperation.LINK, MemoryOperation.ANNOTATE]
            op = MemoryOperation(
                _deterministic_choice(f"mem_op:{seed}", [o.value for o in op_choices])
            )
            topic = prompt[:60].strip()
            content = (
                f"Performing {op.value} operation: recording task context and "
                f"initial observations about '{topic}' for future reference."
            )

        latency = int(_deterministic_float(f"mem_lat:{seed}", 20, 150))
        reward = round(_deterministic_float(f"mem_reward:{seed}", 0.2, 0.85), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.MEMORY_OP,
            content=content,
            memory_op=op,
            reward=reward,
            latency_ms=latency,
            metadata={"operation": op.value},
        )

    def _gen_search_step(self, idx: int, prompt: str, seed: str, domain: str) -> RolloutStep:
        """Generate a SEARCH step — query external sources."""
        topic = prompt[:80].strip()
        if domain == "legal":
            templates = _SEARCH_QUERIES_LEGAL
        elif domain == "finance":
            templates = _SEARCH_QUERIES_FINANCE
        else:
            templates = _SEARCH_QUERIES_GENERAL

        query_template = _deterministic_choice(f"search_tpl:{seed}", templates)
        query = query_template.format(topic=topic)
        latency = int(_deterministic_float(f"search_lat:{seed}", 100, 800))
        reward = round(_deterministic_float(f"search_reward:{seed}", 0.25, 0.9), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.SEARCH,
            content=f"Executing search: '{query}'",
            search_query=query,
            reward=reward,
            latency_ms=latency,
            metadata={"domain": domain, "query": query},
        )

    def _gen_evidence_step(self, idx: int, prompt: str, seed: str, domain: str) -> RolloutStep:
        """Generate an EVIDENCE step — extract evidence from search results."""
        num_sources = int(_deterministic_float(f"num_sources:{seed}", 1, 4.99))
        sources: list[str] = []
        for si in range(num_sources):
            if domain == "legal":
                source_pool = [
                    "Contract Section 4.2",
                    "Case Law DB",
                    "Statute Archive",
                    "Precedent Index",
                    "Regulatory Filing",
                    "Court Record",
                ]
            elif domain == "finance":
                source_pool = [
                    "SEC Filing 10-K",
                    "Bloomberg Terminal",
                    "EDGAR Database",
                    "Quarterly Report Q3",
                    "Risk Assessment DB",
                    "Market Data Feed",
                ]
            else:
                source_pool = [
                    "Knowledge Base",
                    "Documentation Index",
                    "Reference Manual",
                    "Technical Spec v2.1",
                    "Internal Wiki",
                    "API Reference",
                ]
            sources.append(_deterministic_choice(f"source:{seed}:{si}", source_pool))

        template = _deterministic_choice(f"evidence_tpl:{seed}", _EVIDENCE_TEMPLATES)
        content_parts = [template.format(src=s) for s in sources]
        content = " ".join(content_parts)
        latency = int(_deterministic_float(f"evidence_lat:{seed}", 30, 200))
        reward = round(_deterministic_float(f"evidence_reward:{seed}", 0.3, 0.95), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.EVIDENCE,
            content=content,
            evidence_sources=sources,
            reward=reward,
            latency_ms=latency,
            metadata={"num_sources": len(sources)},
        )

    def _gen_reason_step(self, idx: int, prompt: str, seed: str) -> RolloutStep:
        """Generate a REASON step — synthesize evidence into reasoning."""
        topic = prompt[:60].strip()
        assessments = [
            "consistent patterns across sources",
            "strong alignment with expected behavior",
            "some discrepancies that need attention",
            "clear compliance with stated requirements",
            "nuanced findings requiring careful interpretation",
        ]
        assessment = _deterministic_choice(f"assessment:{seed}", assessments)
        template = _deterministic_choice(f"reason_tpl:{seed}", _REASON_TEMPLATES)
        content = template.format(topic=topic, assessment=assessment)
        latency = int(_deterministic_float(f"reason_lat:{seed}", 60, 400))
        reward = round(_deterministic_float(f"reason_reward:{seed}", 0.35, 0.95), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.REASON,
            content=content,
            reward=reward,
            latency_ms=latency,
            metadata={"assessment": assessment},
        )

    def _gen_answer_step(self, idx: int, prompt: str, seed: str) -> RolloutStep:
        """Generate an ANSWER step — final conclusion."""
        topic = prompt[:60].strip()
        conclusions = [
            f"the analysis of '{topic}' yields a positive assessment with high confidence",
            f"'{topic}' meets the specified criteria with minor reservations noted",
            f"based on comprehensive review, '{topic}' requires additional scrutiny in specific areas",
            f"the evidence strongly supports the stated position regarding '{topic}'",
            f"'{topic}' demonstrates satisfactory compliance; recommended for approval",
        ]
        conclusion = _deterministic_choice(f"conclusion:{seed}", conclusions)
        template = _deterministic_choice(f"answer_tpl:{seed}", _ANSWER_TEMPLATES)
        content = template.format(conclusion=conclusion)
        latency = int(_deterministic_float(f"answer_lat:{seed}", 40, 250))
        reward = round(_deterministic_float(f"answer_reward:{seed}", 0.4, 1.0), 4)

        return RolloutStep(
            step_idx=idx,
            kind=StepKind.ANSWER,
            content=content,
            reward=reward,
            latency_ms=latency,
            metadata={"final": True},
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def execute(
        self,
        prompt: str,
        context: dict[str, Any] | None = None,
        memory_state: dict[str, Any] | None = None,
    ) -> Rollout:
        """Generate a multi-step rollout for a prompt.

        The engine follows the canonical pipeline:
        THINK -> MEMORY_OP -> SEARCH -> EVIDENCE -> REASON -> ANSWER

        Some steps may be skipped based on config (e.g. memory_enabled,
        retrieval_enabled) and deterministic variation.

        Args:
            prompt: The task prompt.
            context: Optional context dict (may include agent_id, task_id, domain).
            memory_state: Optional memory state for retrieval.

        Returns:
            A fully populated :class:`Rollout`.
        """
        ctx = context or {}
        domain = ctx.get("domain", "general")
        rollout_id = str(uuid.uuid4())
        base_seed = f"{prompt}:{rollout_id}"
        self._rollout_count += 1

        steps: list[RolloutStep] = []
        idx = 0

        # Step 1: THINK (always present)
        steps.append(self._gen_think_step(idx, prompt, f"{base_seed}:think"))
        idx += 1

        # Step 2: MEMORY_OP (if enabled)
        if self._config.memory_enabled:
            steps.append(self._gen_memory_op_step(idx, prompt, f"{base_seed}:mem", memory_state))
            idx += 1

            # Possibly a second memory op (update/verify) for complex tasks
            if _deterministic_bool(f"{base_seed}:mem2", 0.3):
                second_ops = [
                    MemoryOperation.UPDATE,
                    MemoryOperation.VERIFY,
                    MemoryOperation.COMPRESS,
                ]
                op2 = MemoryOperation(
                    _deterministic_choice(f"{base_seed}:mem2_op", [o.value for o in second_ops])
                )
                steps.append(
                    RolloutStep(
                        step_idx=idx,
                        kind=StepKind.MEMORY_OP,
                        content=f"Performing additional {op2.value} operation on memory state.",
                        memory_op=op2,
                        reward=round(_deterministic_float(f"{base_seed}:mem2_r", 0.2, 0.7), 4),
                        latency_ms=int(_deterministic_float(f"{base_seed}:mem2_l", 15, 100)),
                        metadata={"operation": op2.value, "secondary": True},
                    )
                )
                idx += 1

        # Step 3: SEARCH (if enabled)
        if self._config.retrieval_enabled:
            steps.append(self._gen_search_step(idx, prompt, f"{base_seed}:search", domain))
            idx += 1

        # Step 4: EVIDENCE
        steps.append(self._gen_evidence_step(idx, prompt, f"{base_seed}:evidence", domain))
        idx += 1

        # Step 5: REASON
        steps.append(self._gen_reason_step(idx, prompt, f"{base_seed}:reason"))
        idx += 1

        # Optionally a second reasoning pass for harder tasks
        if _deterministic_bool(f"{base_seed}:reason2", 0.25) and idx < self._config.max_steps - 1:
            steps.append(self._gen_reason_step(idx, prompt, f"{base_seed}:reason2"))
            idx += 1

        # Step 6: ANSWER
        steps.append(self._gen_answer_step(idx, prompt, f"{base_seed}:answer"))
        idx += 1

        # Truncate to max_steps
        steps = steps[: self._config.max_steps]

        total_latency = sum(s.latency_ms for s in steps)
        total_reward = round(sum(s.reward for s in steps), 4)

        return Rollout(
            id=rollout_id,
            prompt=prompt,
            steps=steps,
            context=ctx,
            total_reward=total_reward,
            total_latency_ms=total_latency,
            metadata={"domain": domain, "config_temperature": self._config.temperature},
        )

    def execute_batch(
        self,
        prompts: list[str],
        contexts: list[dict[str, Any]] | None = None,
    ) -> list[Rollout]:
        """Execute rollouts for multiple prompts.

        Args:
            prompts: List of task prompts.
            contexts: Optional list of context dicts (one per prompt).

        Returns:
            A list of :class:`Rollout` objects.
        """
        ctxs = contexts or [{}] * len(prompts)
        if len(ctxs) < len(prompts):
            ctxs.extend([{}] * (len(prompts) - len(ctxs)))
        return [self.execute(p, c) for p, c in zip(prompts, ctxs, strict=False)]

    def execute_group(
        self,
        prompt: str,
        context: dict[str, Any] | None = None,
        group_size: int = 8,
    ) -> list[Rollout]:
        """GRPO group sampling — generate multiple rollouts for the same prompt.

        Each rollout in the group differs due to unique rollout IDs that
        shift the deterministic hashing, simulating the stochastic sampling
        used in GRPO training.

        Args:
            prompt: The task prompt (same for all group members).
            context: Optional shared context.
            group_size: Number of rollouts to generate.

        Returns:
            A list of :class:`Rollout` objects for advantage computation.
        """
        return [self.execute(prompt, context) for _ in range(group_size)]

    def score_rollout(self, rollout: Rollout) -> RewardTraceV1:
        """Score a rollout using the attached reward engine.

        If no reward engine is available, a simple trace is constructed
        from the per-step rewards already present in the rollout.

        Args:
            rollout: The rollout to score.

        Returns:
            A :class:`RewardTraceV1` with per-stage reward decomposition.
        """
        if self._reward_engine is not None:
            # Build stage scores from rollout step rewards grouped by kind
            stage_scores: dict[str, dict[str, float]] = {}
            kind_rewards: dict[str, list[float]] = {}
            for step in rollout.steps:
                kind_rewards.setdefault(step.kind.value, []).append(step.reward)

            for kind, rewards in kind_rewards.items():
                avg_reward = sum(rewards) / len(rewards)
                stage_scores[kind] = {
                    "rule": round(avg_reward, 4),
                    "semantic": round(avg_reward * 0.9, 4),
                    "judge": round(avg_reward * 0.95, 4),
                }

            return self._reward_engine.compute_reward(
                rollout_id=rollout.id,
                stage_scores=stage_scores,
                prompt=rollout.prompt,
            )

        # Fallback: build a minimal RewardTraceV1 from step data
        stage_rewards: list[StageReward] = []
        for i, step in enumerate(rollout.steps):
            stage_rewards.append(
                StageReward(
                    stage=i,
                    stage_name=step.kind.value,
                    rule_score=round(step.reward, 4),
                    semantic_score=round(step.reward * 0.9, 4),
                    judge_score=round(step.reward * 0.95, 4),
                    weight=round(1.0 / max(len(rollout.steps), 1), 4),
                    weighted_score=round(step.reward / max(len(rollout.steps), 1), 4),
                )
            )

        return RewardTraceV1(
            rollout_id=rollout.id,
            stages=stage_rewards,
            total_reward=rollout.total_reward,
        )

    def compute_advantages(self, group: list[Rollout]) -> list[float]:
        """Compute GRPO advantages for a group of rollouts.

        Advantage for each rollout = (score - group_mean) / group_std.
        If group_std is zero (all identical), advantages are all zero.

        Args:
            group: A list of rollouts generated for the same prompt
                (typically from :meth:`execute_group`).

        Returns:
            A list of advantage values, one per rollout.
        """
        if not group:
            return []

        scores = [r.total_reward for r in group]
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        std = variance**0.5

        if std < 1e-8:
            return [0.0] * len(group)

        return [round((s - mean) / std, 6) for s in scores]

    def mask_retrieved_tokens(self, rollout: Rollout) -> Rollout:
        """Apply Search-R1 gradient masking to retrieval tokens.

        Marks SEARCH and EVIDENCE steps with a ``gradient_mask=False``
        metadata flag, indicating that these tokens should not receive
        gradient updates during policy optimisation.  This prevents the
        model from learning to generate retrieval content (which comes
        from external sources) and instead focuses learning on the
        agent's own reasoning and decisions.

        Args:
            rollout: The rollout to mask.

        Returns:
            A new :class:`Rollout` with masked steps.
        """
        masked_steps: list[RolloutStep] = []
        for step in rollout.steps:
            new_meta = dict(step.metadata)
            if step.kind in (StepKind.SEARCH, StepKind.EVIDENCE):
                new_meta["gradient_mask"] = False
                new_meta["masked_reason"] = "search_r1_retrieval_token"
            else:
                new_meta["gradient_mask"] = True

            masked_steps.append(
                RolloutStep(
                    step_idx=step.step_idx,
                    kind=step.kind,
                    content=step.content,
                    memory_op=step.memory_op,
                    search_query=step.search_query,
                    evidence_sources=list(step.evidence_sources),
                    reward=step.reward,
                    latency_ms=step.latency_ms,
                    metadata=new_meta,
                )
            )

        return Rollout(
            id=rollout.id,
            prompt=rollout.prompt,
            steps=masked_steps,
            context=dict(rollout.context),
            total_reward=rollout.total_reward,
            total_latency_ms=rollout.total_latency_ms,
            created_at=rollout.created_at,
            metadata={**rollout.metadata, "search_r1_masked": True},
        )

    def summary(self) -> dict[str, Any]:
        """Return engine summary statistics."""
        return {
            "rollout_count": self._rollout_count,
            "config": {
                "max_steps": self._config.max_steps,
                "max_tokens": self._config.max_tokens,
                "temperature": self._config.temperature,
                "memory_enabled": self._config.memory_enabled,
                "retrieval_enabled": self._config.retrieval_enabled,
            },
            "has_reward_engine": self._reward_engine is not None,
        }
