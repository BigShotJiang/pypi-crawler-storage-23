"""Bridge module for integrating Aegis RL training with verl.

Provides :class:`VerlTrainingConfig` for configuring real GPU training
and :class:`VerlTrainer` which wraps verl's GRPO trainer with Aegis
reward functions, curriculum progression, and checkpoint management.

When verl and torch are not installed, falls back to the simulated
:class:`AMIRGRPOTrainer`.
"""

from __future__ import annotations

import importlib.util
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

try:
    import torch

    _HAS_TORCH = True
except ImportError:
    _HAS_TORCH = False

_HAS_VERL = importlib.util.find_spec("verl") is not None


@dataclass
class VerlTrainingConfig:
    """Configuration for a real verl-based GRPO training run.

    Attributes:
        model_name: HuggingFace model identifier (e.g. "Qwen/Qwen2.5-7B").
        output_dir: Directory for checkpoints and adapters.
        num_episodes: Number of training episodes.
        rollouts_per_prompt: Number of rollout samples per prompt (GRPO group size).
        max_seq_length: Maximum sequence length for generation.
        learning_rate: Learning rate for AdamW optimizer.
        kl_coeff: KL divergence penalty coefficient.
        use_lora: Whether to use LoRA for parameter-efficient training.
        lora_rank: LoRA rank (only used if use_lora is True).
        lora_alpha: LoRA alpha scaling.
        precision: Training precision ("fp16", "bf16", "fp32").
        gradient_accumulation_steps: Number of gradient accumulation steps.
        reward_stages: Number of reward decomposition stages.
        domain: Training domain ("legal", "finance", "general").
        gpu_ids: List of GPU device IDs to use.
    """

    model_name: str = "Qwen/Qwen2.5-7B"
    output_dir: str = "./checkpoints"
    num_episodes: int = 100
    rollouts_per_prompt: int = 8
    max_seq_length: int = 4096
    learning_rate: float = 1e-5
    kl_coeff: float = 0.05
    use_lora: bool = True
    lora_rank: int = 16
    lora_alpha: int = 32
    precision: str = "bf16"
    gradient_accumulation_steps: int = 4
    reward_stages: int = 5
    domain: str = "legal"
    gpu_ids: list[int] = field(default_factory=lambda: [0])

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_name": self.model_name,
            "output_dir": self.output_dir,
            "num_episodes": self.num_episodes,
            "rollouts_per_prompt": self.rollouts_per_prompt,
            "max_seq_length": self.max_seq_length,
            "learning_rate": self.learning_rate,
            "kl_coeff": self.kl_coeff,
            "use_lora": self.use_lora,
            "lora_rank": self.lora_rank,
            "lora_alpha": self.lora_alpha,
            "precision": self.precision,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "reward_stages": self.reward_stages,
            "domain": self.domain,
            "gpu_ids": self.gpu_ids,
        }

    def save(self, path: str | Path) -> None:
        """Save config to JSON file."""
        Path(path).write_text(json.dumps(self.to_dict(), indent=2))

    @classmethod
    def load(cls, path: str | Path) -> VerlTrainingConfig:
        """Load config from JSON file."""
        data = json.loads(Path(path).read_text())
        return cls(**data)


class VerlTrainer:
    """Bridge between Aegis training pipeline and verl GPU training.

    When verl + torch are available, performs real GRPO training on GPU.
    Otherwise falls back to the simulated AMIRGRPOTrainer.

    Args:
        config: Training configuration.
    """

    def __init__(self, config: VerlTrainingConfig) -> None:
        self._config = config
        self._is_real = _HAS_TORCH and _HAS_VERL
        self._metrics: list[dict[str, Any]] = []

    @property
    def is_real_training(self) -> bool:
        """Whether real GPU training is available."""
        return self._is_real

    @property
    def device_info(self) -> dict[str, Any]:
        """Return available compute device information."""
        if not _HAS_TORCH:
            return {"backend": "simulated", "devices": [], "cuda_available": False}
        return {
            "backend": "verl" if _HAS_VERL else "torch",
            "devices": [
                {
                    "id": i,
                    "name": torch.cuda.get_device_name(i) if torch.cuda.is_available() else "cpu",
                }
                for i in self._config.gpu_ids
            ]
            if torch.cuda.is_available()
            else [{"id": 0, "name": "cpu"}],
            "cuda_available": torch.cuda.is_available(),
            "cuda_device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0,
        }

    def train(self, prompts: list[str], eval_fn: Any = None) -> dict[str, Any]:
        """Run training on the given prompts.

        Args:
            prompts: Training prompts for rollout generation.
            eval_fn: Optional evaluation function called after each episode.

        Returns:
            Training result dict with metrics, status, and adapter path.
        """
        if self._is_real:
            return self._train_real(prompts, eval_fn)
        return self._train_simulated(prompts, eval_fn)

    def _train_real(self, prompts: list[str], eval_fn: Any = None) -> dict[str, Any]:
        """Real training via verl GRPO trainer.

        This method is called when verl and torch are available.
        Implements the full training loop:

        1. Load model + tokenizer via model_loader
        2. Configure LoRA if enabled
        3. Build Aegis reward function wrapper
        4. Wire verl GRPOTrainer with Aegis rewards
        5. Run training with checkpoint management
        6. Save final adapter and metrics

        Falls back to simulated training if model loading or verl
        integration fails.
        """
        import uuid

        from aegis.training.checkpoint import CheckpointManager
        from aegis.training.model_loader import ModelConfig, load_model_and_tokenizer
        from aegis.training.rewards import RewardEngine

        output_dir = Path(self._config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        run_id = f"verl-{self._config.domain}-{uuid.uuid4().hex[:8]}"

        # Save config for reproducibility
        self._config.save(output_dir / "training_config.json")

        logger.info(
            "Starting verl GRPO training: model=%s, episodes=%d, domain=%s, run_id=%s",
            self._config.model_name,
            self._config.num_episodes,
            self._config.domain,
            run_id,
        )

        # 1. Load model + tokenizer
        model_config = ModelConfig(
            model_name=self._config.model_name,
            precision=self._config.precision,
            use_lora=self._config.use_lora,
            lora_rank=self._config.lora_rank,
            lora_alpha=self._config.lora_alpha,
            max_seq_length=self._config.max_seq_length,
        )

        try:
            model, tokenizer = load_model_and_tokenizer(model_config)
        except (RuntimeError, ImportError) as exc:
            logger.warning(
                "Model loading failed (%s), falling back to simulated training",
                exc,
            )
            return self._train_simulated(prompts, eval_fn)

        # 2. Build reward engine
        reward_engine = RewardEngine.for_domain(self._config.domain)
        checkpoint_mgr = CheckpointManager(str(output_dir))

        # 3. Build Aegis reward function for verl
        def aegis_reward_fn(
            prompt_text: str,
            response_text: str,
            rollout_id: str = "",
        ) -> float:
            """Compute Aegis multi-stage reward for a single rollout."""
            rid = rollout_id or f"{run_id}:{hash(prompt_text + response_text)}"
            trace = reward_engine.compute_reward(rollout_id=rid, prompt=prompt_text)
            return trace.total_reward

        # 4. Attempt verl GRPOTrainer integration
        try:
            result = self._run_verl_grpo(
                model=model,
                tokenizer=tokenizer,
                prompts=prompts,
                reward_fn=aegis_reward_fn,
                eval_fn=eval_fn,
                run_id=run_id,
                checkpoint_mgr=checkpoint_mgr,
            )
        except Exception as exc:
            logger.warning(
                "verl GRPOTrainer failed (%s), running manual training loop",
                exc,
            )
            try:
                result = self._run_manual_training(
                    model=model,
                    tokenizer=tokenizer,
                    prompts=prompts,
                    reward_engine=reward_engine,
                    eval_fn=eval_fn,
                    run_id=run_id,
                    checkpoint_mgr=checkpoint_mgr,
                )
            except Exception as manual_exc:
                logger.warning(
                    "Manual training also failed (%s), falling back to simulated",
                    manual_exc,
                )
                sim_result = self._train_simulated(prompts, eval_fn)
                sim_result["run_id"] = run_id
                return sim_result

        # 5. Save final adapter
        adapter_path = output_dir / "final_adapter"
        try:
            if hasattr(model, "save_pretrained"):
                model.save_pretrained(str(adapter_path))
                tokenizer.save_pretrained(str(adapter_path))
                result["adapter_path"] = str(adapter_path)
                logger.info("Saved final adapter to %s", adapter_path)
        except Exception as exc:
            logger.warning("Failed to save adapter: %s", exc)

        result["backend"] = "verl"
        result["run_id"] = run_id
        result["config"] = self._config.to_dict()
        result["reward_summary"] = reward_engine.summary()
        return result

    def _run_verl_grpo(
        self,
        model: Any,
        tokenizer: Any,
        prompts: list[str],
        reward_fn: Any,
        eval_fn: Any,
        run_id: str,
        checkpoint_mgr: Any,
    ) -> dict[str, Any]:
        """Run training using verl's GRPOTrainer.

        This wraps the verl library API. The exact import path depends on
        the verl version installed.
        """
        from verl.trainer.ppo import GRPOTrainer  # type: ignore[import-not-found]

        trainer = GRPOTrainer(
            model=model,
            tokenizer=tokenizer,
            reward_fn=reward_fn,
            num_episodes=self._config.num_episodes,
            rollouts_per_prompt=self._config.rollouts_per_prompt,
            max_seq_length=self._config.max_seq_length,
            learning_rate=self._config.learning_rate,
            kl_coeff=self._config.kl_coeff,
            gradient_accumulation_steps=self._config.gradient_accumulation_steps,
        )

        # Run training
        metrics = trainer.fit(prompts)

        # Save checkpoint
        checkpoint_mgr.save(
            run_id=run_id,
            step=self._config.num_episodes,
            state={"verl_metrics": metrics},
            metrics=metrics if isinstance(metrics, dict) else {},
        )

        if isinstance(metrics, dict):
            return {"status": "completed", **metrics}
        return {"status": "completed", "verl_metrics": metrics}

    def _run_manual_training(
        self,
        model: Any,
        tokenizer: Any,
        prompts: list[str],
        reward_engine: Any,
        eval_fn: Any,
        run_id: str,
        checkpoint_mgr: Any,
    ) -> dict[str, Any]:
        """Manual GRPO training loop when verl's trainer isn't usable.

        Implements the core GRPO algorithm directly:
        - For each episode, sample a prompt batch
        - Generate multiple rollouts per prompt
        - Score with Aegis reward engine
        - Compute group-relative advantages
        - Update model with policy gradient
        """
        import random

        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=self._config.learning_rate,
        )

        stage_metrics: list[dict[str, Any]] = []
        total_steps = 0
        all_rewards: list[float] = []

        num_episodes = self._config.num_episodes
        save_interval = max(1, num_episodes // 5)

        for episode in range(num_episodes):
            # Sample prompt batch
            batch = random.choices(prompts, k=min(len(prompts), 4))
            episode_rewards: list[float] = []
            episode_losses: list[float] = []

            for prompt_text in batch:
                # Generate rollouts
                rollout_rewards: list[float] = []
                rollout_log_probs: list[Any] = []

                for rollout_idx in range(self._config.rollouts_per_prompt):
                    # Tokenize and generate
                    inputs = tokenizer(
                        prompt_text,
                        return_tensors="pt",
                        truncation=True,
                        max_length=self._config.max_seq_length // 2,
                    )
                    inputs = {k: v.to(model.device) for k, v in inputs.items()}

                    with torch.no_grad():
                        outputs = model.generate(
                            **inputs,
                            max_new_tokens=min(256, self._config.max_seq_length // 4),
                            do_sample=True,
                            temperature=0.8,
                            top_p=0.95,
                            return_dict_in_generate=True,
                            output_scores=True,
                        )

                    generated_ids = outputs.sequences[0][inputs["input_ids"].shape[1] :]
                    _ = tokenizer.decode(generated_ids, skip_special_tokens=True)

                    # Compute reward
                    rollout_id = f"{run_id}:ep{episode}:r{rollout_idx}"
                    trace = reward_engine.compute_reward(
                        rollout_id=rollout_id,
                        prompt=prompt_text,
                    )
                    rollout_rewards.append(trace.total_reward)

                    # Compute log probability for policy gradient
                    with torch.no_grad():
                        model_outputs = model(**inputs, labels=outputs.sequences[0:1])
                        log_prob = -model_outputs.loss
                        rollout_log_probs.append(log_prob)

                # GRPO: compute group-relative advantages
                if rollout_rewards:
                    mean_reward = sum(rollout_rewards) / len(rollout_rewards)
                    std_reward = max(
                        1e-8,
                        (
                            sum((r - mean_reward) ** 2 for r in rollout_rewards)
                            / len(rollout_rewards)
                        )
                        ** 0.5,
                    )
                    advantages = [(r - mean_reward) / std_reward for r in rollout_rewards]

                    # Policy gradient loss
                    policy_loss = torch.tensor(0.0, device=model.device)
                    for adv, log_prob in zip(advantages, rollout_log_probs, strict=False):
                        policy_loss = policy_loss - adv * log_prob

                    # KL penalty (approximate)
                    kl_penalty = (
                        self._config.kl_coeff
                        * sum(lp.abs() for lp in rollout_log_probs)
                        / len(rollout_log_probs)
                    )

                    loss = policy_loss / len(rollout_log_probs) + kl_penalty

                    # Backward pass
                    if loss.requires_grad:
                        loss.backward()
                        if (total_steps + 1) % self._config.gradient_accumulation_steps == 0:
                            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                            optimizer.step()
                            optimizer.zero_grad()

                    episode_rewards.extend(rollout_rewards)
                    episode_losses.append(loss.item() if hasattr(loss, "item") else float(loss))

                total_steps += 1

            # Episode metrics
            ep_mean_reward = sum(episode_rewards) / len(episode_rewards) if episode_rewards else 0.0
            ep_mean_loss = sum(episode_losses) / len(episode_losses) if episode_losses else 0.0
            all_rewards.extend(episode_rewards)

            stage_metrics.append(
                {
                    "episode": episode,
                    "reward": round(ep_mean_reward, 6),
                    "loss": round(ep_mean_loss, 6),
                    "steps": total_steps,
                    "num_rollouts": len(episode_rewards),
                }
            )

            # Checkpoint
            if (episode + 1) % save_interval == 0 or episode == num_episodes - 1:
                checkpoint_mgr.save(
                    run_id=run_id,
                    step=episode + 1,
                    state={
                        "episode": episode,
                        "mean_reward": ep_mean_reward,
                        "total_steps": total_steps,
                    },
                    metrics={"reward": ep_mean_reward, "loss": ep_mean_loss},
                )

            # Eval callback
            if eval_fn and (episode + 1) % save_interval == 0:
                try:
                    eval_fn(episode=episode, metrics=stage_metrics[-1])
                except Exception as exc:
                    logger.warning("Eval callback failed at episode %d: %s", episode, exc)

            logger.info(
                "Episode %d/%d: reward=%.4f, loss=%.4f",
                episode + 1,
                num_episodes,
                ep_mean_reward,
                ep_mean_loss,
            )

        mean_reward = sum(all_rewards) / len(all_rewards) if all_rewards else 0.0
        best_reward = max(all_rewards) if all_rewards else 0.0

        return {
            "status": "completed",
            "mean_reward": round(mean_reward, 6),
            "best_reward": round(best_reward, 6),
            "final_loss": round(stage_metrics[-1]["loss"], 6) if stage_metrics else 0.0,
            "kl_divergence": round(self._config.kl_coeff, 6),
            "total_steps": total_steps,
            "stage_metrics": stage_metrics,
        }

    def _train_simulated(self, prompts: list[str], eval_fn: Any = None) -> dict[str, Any]:
        """Simulated training using existing AMIRGRPOTrainer."""
        from aegis.training.engine import AMIRGRPOTrainer

        trainer = AMIRGRPOTrainer(
            num_stages=self._config.reward_stages,
            learning_rate=self._config.learning_rate,
        )
        config = {
            "prompts": prompts,
            "num_episodes": min(self._config.num_episodes, 3),
            "reward_stages": self._config.reward_stages,
            "optimizer": "drgrpo",
            "learning_rate": self._config.learning_rate,
        }
        result = trainer.train(config)
        result["backend"] = "simulated"
        result["config"] = self._config.to_dict()
        return result

    def generate_verl_config(self) -> dict[str, Any]:
        """Generate a verl-compatible YAML config dict.

        Can be written to a YAML file and used with verl CLI:
        ``verl train --config config.yaml``
        """
        return {
            "model": {
                "name": self._config.model_name,
                "precision": self._config.precision,
            },
            "training": {
                "algorithm": "grpo",
                "num_episodes": self._config.num_episodes,
                "rollouts_per_prompt": self._config.rollouts_per_prompt,
                "max_seq_length": self._config.max_seq_length,
                "learning_rate": self._config.learning_rate,
                "kl_coeff": self._config.kl_coeff,
                "gradient_accumulation_steps": self._config.gradient_accumulation_steps,
            },
            "lora": {
                "enabled": self._config.use_lora,
                "rank": self._config.lora_rank,
                "alpha": self._config.lora_alpha,
                "target_modules": ["q_proj", "v_proj", "k_proj", "o_proj"],
            },
            "reward": {
                "type": "multi_stage",
                "stages": self._config.reward_stages,
                "domain": self._config.domain,
            },
            "resources": {
                "gpu_ids": self._config.gpu_ids,
                "num_workers": 4,
            },
            "output": {
                "dir": self._config.output_dir,
                "save_steps": 50,
                "eval_steps": 25,
            },
        }
