"""Cloud launcher abstraction for remote training jobs.

Provides :class:`CloudLauncher`, an abstract base class for launching
training jobs on cloud infrastructure, and :class:`AWSLauncher`, a
concrete implementation that creates AWS SageMaker training jobs with
PyTorch estimators, LoRA configuration, and spot-instance support.

All AWS / boto3 / sagemaker imports are lazy so the module can be
imported in environments without AWS dependencies.
"""

from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy AWS imports
# ---------------------------------------------------------------------------

try:
    import boto3  # type: ignore[import-not-found]

    _HAS_BOTO3 = True
except ImportError:
    boto3 = None
    _HAS_BOTO3 = False

try:
    import sagemaker  # type: ignore[import-not-found]
    from sagemaker.pytorch import PyTorch as SageMakerPyTorch  # type: ignore[import-not-found]

    _HAS_SAGEMAKER = True
except ImportError:
    sagemaker = None
    SageMakerPyTorch = None
    _HAS_SAGEMAKER = False


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class CloudLauncher(ABC):
    """Abstract base class for cloud training launchers.

    Subclasses must implement :meth:`launch`, :meth:`status`,
    :meth:`stop`, and :meth:`download_artifacts`.
    """

    @abstractmethod
    def launch(self, config: dict[str, Any]) -> dict[str, Any]:
        """Launch a training job.

        Args:
            config: Training job configuration (model, hyperparams,
                instance type, etc.).

        Returns:
            A dictionary containing at least ``job_id`` and ``status``.
        """
        ...

    @abstractmethod
    def status(self, job_id: str) -> dict[str, Any]:
        """Check the status of a running or completed job.

        Args:
            job_id: The identifier returned by :meth:`launch`.

        Returns:
            Status dictionary with ``job_id``, ``status``, and
            provider-specific metadata.
        """
        ...

    @abstractmethod
    def stop(self, job_id: str) -> dict[str, Any]:
        """Stop a running training job.

        Args:
            job_id: The identifier returned by :meth:`launch`.

        Returns:
            Result dictionary confirming the stop action.
        """
        ...

    @abstractmethod
    def download_artifacts(self, job_id: str, dest: str) -> dict[str, Any]:
        """Download training artifacts (checkpoints, logs, adapters).

        Args:
            job_id: The identifier returned by :meth:`launch`.
            dest: Local directory to download artifacts into.

        Returns:
            Dictionary listing downloaded paths and sizes.
        """
        ...


# ---------------------------------------------------------------------------
# AWS SageMaker launcher configuration
# ---------------------------------------------------------------------------


@dataclass
class AWSLauncherConfig:
    """Configuration for an AWS SageMaker training launch.

    Attributes:
        role_arn: IAM role ARN for SageMaker execution.
        s3_bucket: S3 bucket for checkpoints and output.
        region: AWS region name.
        instance_type: EC2 instance type for training.
        instance_count: Number of training instances.
        use_spot: Whether to use spot instances for cost savings.
        max_wait_seconds: Max wait time for spot capacity (seconds).
        max_run_seconds: Max training runtime (seconds).
        volume_size_gb: EBS volume size in GB.
        base_job_name: Prefix for SageMaker job names.
    """

    role_arn: str = ""
    s3_bucket: str = "aegis-training-checkpoints"
    region: str = "us-east-1"
    instance_type: str = "ml.g5.xlarge"
    instance_count: int = 1
    use_spot: bool = True
    max_wait_seconds: int = 7200
    max_run_seconds: int = 86400
    volume_size_gb: int = 100
    base_job_name: str = "aegis-train"


# ---------------------------------------------------------------------------
# AWS SageMaker launcher
# ---------------------------------------------------------------------------


class AWSLauncher(CloudLauncher):
    """AWS SageMaker training launcher.

    Creates SageMaker training jobs using the PyTorch estimator with
    LoRA configuration and optional spot-instance pricing.

    Args:
        config: AWS launcher configuration.

    Raises:
        RuntimeError: If boto3 is not installed.
    """

    def __init__(self, config: AWSLauncherConfig | None = None) -> None:
        self._config = config or AWSLauncherConfig()
        self._jobs: dict[str, dict[str, Any]] = {}

        if not _HAS_BOTO3:
            logger.warning(
                "boto3 not installed -- AWSLauncher will operate in dry-run mode. "
                "Install with: pip install boto3"
            )

    # ------------------------------------------------------------------
    # CloudLauncher interface
    # ------------------------------------------------------------------

    def launch(self, config: dict[str, Any]) -> dict[str, Any]:
        """Launch a SageMaker training job.

        The *config* dictionary is merged with the launcher defaults.
        Recognised keys:

        * ``model_name`` -- HuggingFace model id (default ``Qwen/Qwen2.5-7B``)
        * ``domain`` -- Training domain (``legal``, ``finance``, ``general``)
        * ``dataset_path`` -- S3 URI or local path to the training data
        * ``instance_type`` -- Override instance type
        * ``use_spot`` -- Override spot-instance flag
        * ``use_lora`` -- Whether to use LoRA (default ``True``)
        * ``lora_rank`` -- LoRA rank (default ``16``)
        * ``learning_rate`` -- Learning rate (default ``1e-5``)
        * ``num_episodes`` -- Training episodes (default ``100``)
        * ``entry_point`` -- Training script path (default ``train.py``)
        * ``source_dir`` -- Source directory for training code

        Args:
            config: Training job configuration.

        Returns:
            Dictionary with ``job_id``, ``status``, and job metadata.
        """
        job_id = f"{self._config.base_job_name}-{uuid.uuid4().hex[:8]}"
        model_name = config.get("model_name", "Qwen/Qwen2.5-7B")
        domain = config.get("domain", "general")
        instance_type = config.get("instance_type", self._config.instance_type)
        use_spot = config.get("use_spot", self._config.use_spot)
        dataset_path = config.get("dataset_path", "")
        use_lora = config.get("use_lora", True)
        lora_rank = config.get("lora_rank", 16)
        learning_rate = config.get("learning_rate", 1e-5)
        num_episodes = config.get("num_episodes", 100)
        entry_point = config.get("entry_point", "train.py")
        source_dir = config.get("source_dir", "./src")

        hyperparameters = {
            "model-name": model_name,
            "domain": domain,
            "use-lora": str(use_lora),
            "lora-rank": str(lora_rank),
            "learning-rate": str(learning_rate),
            "num-episodes": str(num_episodes),
            "output-dir": "/opt/ml/model",
        }

        s3_output = f"s3://{self._config.s3_bucket}/{job_id}"
        s3_checkpoint = f"s3://{self._config.s3_bucket}/{job_id}/checkpoints"

        job_record: dict[str, Any] = {
            "job_id": job_id,
            "model_name": model_name,
            "domain": domain,
            "instance_type": instance_type,
            "use_spot": use_spot,
            "hyperparameters": hyperparameters,
            "s3_output": s3_output,
            "s3_checkpoint": s3_checkpoint,
            "created_at": datetime.now(UTC).isoformat(),
        }

        if _HAS_BOTO3 and _HAS_SAGEMAKER and self._config.role_arn:
            try:
                job_record = self._launch_sagemaker(
                    job_id=job_id,
                    hyperparameters=hyperparameters,
                    instance_type=instance_type,
                    use_spot=use_spot,
                    s3_output=s3_output,
                    s3_checkpoint=s3_checkpoint,
                    entry_point=entry_point,
                    source_dir=source_dir,
                    dataset_path=dataset_path,
                    job_record=job_record,
                )
            except Exception as exc:
                logger.error("SageMaker launch failed: %s", exc)
                job_record["status"] = "failed"
                job_record["error"] = str(exc)
        else:
            reason = self._dry_run_reason()
            logger.info("Dry-run launch (reason: %s): %s", reason, job_id)
            job_record["status"] = "dry_run"
            job_record["dry_run_reason"] = reason

        self._jobs[job_id] = job_record
        return job_record

    def status(self, job_id: str) -> dict[str, Any]:
        """Check the status of a SageMaker training job.

        Args:
            job_id: SageMaker training job name.

        Returns:
            Status dictionary with ``job_id``, ``status``, and metadata.
        """
        # Check local cache first
        cached = self._jobs.get(job_id)

        if _HAS_BOTO3:
            try:
                client = boto3.client(
                    "sagemaker",
                    region_name=self._config.region,
                )
                response = client.describe_training_job(TrainingJobName=job_id)
                status = response.get("TrainingJobStatus", "Unknown")
                return {
                    "job_id": job_id,
                    "status": status,
                    "secondary_status": response.get("SecondaryStatus", ""),
                    "creation_time": str(response.get("CreationTime", "")),
                    "last_modified": str(response.get("LastModifiedTime", "")),
                    "failure_reason": response.get("FailureReason", ""),
                    "billable_seconds": response.get("BillableTimeInSeconds", 0),
                    "output_path": response.get("OutputDataConfig", {}).get("S3OutputPath", ""),
                }
            except Exception as exc:
                logger.warning("SageMaker status check failed: %s", exc)

        # Fallback to cached record
        if cached:
            return {
                "job_id": job_id,
                "status": cached.get("status", "unknown"),
                "cached": True,
            }

        return {"job_id": job_id, "status": "not_found"}

    def stop(self, job_id: str) -> dict[str, Any]:
        """Stop a running SageMaker training job.

        Args:
            job_id: SageMaker training job name.

        Returns:
            Result dictionary confirming the stop action.
        """
        if _HAS_BOTO3:
            try:
                client = boto3.client(
                    "sagemaker",
                    region_name=self._config.region,
                )
                client.stop_training_job(TrainingJobName=job_id)
                logger.info("Stopped SageMaker job: %s", job_id)

                if job_id in self._jobs:
                    self._jobs[job_id]["status"] = "stopping"

                return {"job_id": job_id, "status": "stopping"}
            except Exception as exc:
                logger.error("Failed to stop SageMaker job %s: %s", job_id, exc)
                return {"job_id": job_id, "status": "error", "error": str(exc)}

        logger.info("Dry-run stop: %s", job_id)
        if job_id in self._jobs:
            self._jobs[job_id]["status"] = "stopped"
        return {"job_id": job_id, "status": "dry_run_stopped"}

    def download_artifacts(self, job_id: str, dest: str) -> dict[str, Any]:
        """Download training artifacts from S3.

        Args:
            job_id: SageMaker training job name.
            dest: Local destination directory.

        Returns:
            Dictionary listing downloaded files or dry-run info.
        """
        dest_path = Path(dest)
        dest_path.mkdir(parents=True, exist_ok=True)

        s3_prefix = f"{self._config.s3_bucket}/{job_id}"

        if _HAS_BOTO3:
            try:
                s3 = boto3.client("s3", region_name=self._config.region)
                paginator = s3.get_paginator("list_objects_v2")
                downloaded: list[dict[str, Any]] = []

                for page in paginator.paginate(
                    Bucket=self._config.s3_bucket,
                    Prefix=job_id,
                ):
                    for obj in page.get("Contents", []):
                        key = obj["Key"]
                        relative = key[len(job_id) :].lstrip("/")
                        if not relative:
                            continue
                        local_file = dest_path / relative
                        local_file.parent.mkdir(parents=True, exist_ok=True)
                        s3.download_file(self._config.s3_bucket, key, str(local_file))
                        downloaded.append(
                            {
                                "key": key,
                                "local_path": str(local_file),
                                "size": obj.get("Size", 0),
                            }
                        )

                logger.info(
                    "Downloaded %d artifacts from s3://%s to %s",
                    len(downloaded),
                    s3_prefix,
                    dest,
                )
                return {
                    "job_id": job_id,
                    "dest": dest,
                    "files": downloaded,
                    "total_files": len(downloaded),
                }
            except Exception as exc:
                logger.error("S3 download failed for %s: %s", job_id, exc)
                return {"job_id": job_id, "status": "error", "error": str(exc)}

        logger.info("Dry-run download: s3://%s -> %s", s3_prefix, dest)
        return {
            "job_id": job_id,
            "dest": dest,
            "status": "dry_run",
            "s3_prefix": f"s3://{s3_prefix}",
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _launch_sagemaker(
        self,
        *,
        job_id: str,
        hyperparameters: dict[str, str],
        instance_type: str,
        use_spot: bool,
        s3_output: str,
        s3_checkpoint: str,
        entry_point: str,
        source_dir: str,
        dataset_path: str,
        job_record: dict[str, Any],
    ) -> dict[str, Any]:
        """Create and start a real SageMaker training job."""
        sess = sagemaker.Session(boto_session=boto3.Session(region_name=self._config.region))

        estimator_kwargs: dict[str, Any] = {
            "entry_point": entry_point,
            "source_dir": source_dir,
            "role": self._config.role_arn,
            "instance_type": instance_type,
            "instance_count": self._config.instance_count,
            "framework_version": "2.2",
            "py_version": "py310",
            "hyperparameters": hyperparameters,
            "output_path": s3_output,
            "checkpoint_s3_uri": s3_checkpoint,
            "volume_size": self._config.volume_size_gb,
            "max_run": self._config.max_run_seconds,
            "sagemaker_session": sess,
            "base_job_name": self._config.base_job_name,
        }

        if use_spot:
            estimator_kwargs["use_spot_instances"] = True
            estimator_kwargs["max_wait"] = self._config.max_wait_seconds

        estimator = SageMakerPyTorch(**estimator_kwargs)

        inputs = {}
        if dataset_path:
            inputs["training"] = dataset_path

        estimator.fit(inputs=inputs if inputs else None, job_name=job_id, wait=False)

        job_record["status"] = "launched"
        job_record["sagemaker_job_name"] = job_id
        logger.info(
            "Launched SageMaker job: %s (instance=%s, spot=%s)", job_id, instance_type, use_spot
        )
        return job_record

    def _dry_run_reason(self) -> str:
        """Return the reason the launcher is in dry-run mode."""
        reasons: list[str] = []
        if not _HAS_BOTO3:
            reasons.append("boto3 not installed")
        if not _HAS_SAGEMAKER:
            reasons.append("sagemaker SDK not installed")
        if not self._config.role_arn:
            reasons.append("no role_arn configured")
        return "; ".join(reasons) if reasons else "unknown"
