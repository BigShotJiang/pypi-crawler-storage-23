"""Curriculum engine for progressive RL training.

Implements a 5-level curriculum that gradually increases task difficulty,
complexity, and the set of available operations as the agent improves.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class CurriculumLevel:
    """A single level in the training curriculum."""

    level: int
    name: str
    description: str = ""
    min_score_to_advance: float = 0.7
    operations_unlocked: list[str] = field(default_factory=list)
    difficulty_range: tuple[int, int] = (1, 5)
    max_context_length: int = 4096
    max_steps: int = 10
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CurriculumProgress:
    """Tracks an agent's progress through the curriculum."""

    agent_id: str
    current_level: int = 1
    scores_per_level: dict[int, list[float]] = field(default_factory=lambda: defaultdict(list))
    level_history: list[dict[str, Any]] = field(default_factory=list)
    started_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    total_episodes: int = 0


# Default 5-level curriculum
DEFAULT_LEVELS: list[CurriculumLevel] = [
    CurriculumLevel(
        level=1,
        name="Foundation",
        description="Basic memory operations and simple retrieval",
        min_score_to_advance=0.6,
        operations_unlocked=["STORE", "RETRIEVE"],
        difficulty_range=(1, 2),
        max_context_length=2048,
        max_steps=5,
    ),
    CurriculumLevel(
        level=2,
        name="Core Operations",
        description="All CRUD operations with moderate complexity",
        min_score_to_advance=0.65,
        operations_unlocked=["STORE", "RETRIEVE", "UPDATE", "FORGET", "LINK"],
        difficulty_range=(2, 3),
        max_context_length=4096,
        max_steps=8,
    ),
    CurriculumLevel(
        level=3,
        name="Advanced Memory",
        description="Tier management, compression, and multi-step reasoning",
        min_score_to_advance=0.7,
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
        ],
        difficulty_range=(3, 4),
        max_context_length=8192,
        max_steps=12,
    ),
    CurriculumLevel(
        level=4,
        name="Complex Reasoning",
        description="Split/merge operations, cross-domain transfer, verification",
        min_score_to_advance=0.75,
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "SPLIT",
            "MERGE",
            "VERIFY",
        ],
        difficulty_range=(3, 5),
        max_context_length=16384,
        max_steps=15,
    ),
    CurriculumLevel(
        level=5,
        name="Mastery",
        description="All operations, maximum difficulty, annotation and meta-learning",
        min_score_to_advance=0.8,
        operations_unlocked=[
            "STORE",
            "RETRIEVE",
            "UPDATE",
            "FORGET",
            "LINK",
            "COMPRESS",
            "PROMOTE",
            "DEMOTE",
            "SPLIT",
            "MERGE",
            "VERIFY",
            "ANNOTATE",
        ],
        difficulty_range=(4, 5),
        max_context_length=32768,
        max_steps=20,
    ),
]


class CurriculumEngine:
    """Manages training curriculum progression.

    Tracks agent progress through curriculum levels, determines when
    advancement is warranted, and generates appropriate training configs
    for each level.
    """

    def __init__(self, levels: list[CurriculumLevel] | None = None) -> None:
        self._levels = {level.level: level for level in (levels or DEFAULT_LEVELS)}
        self._progress: dict[str, CurriculumProgress] = {}

    def register_agent(self, agent_id: str, start_level: int = 1) -> CurriculumProgress:
        """Register an agent for curriculum training."""
        progress = CurriculumProgress(agent_id=agent_id, current_level=start_level)
        self._progress[agent_id] = progress
        return progress

    def get_progress(self, agent_id: str) -> CurriculumProgress | None:
        """Get an agent's curriculum progress."""
        return self._progress.get(agent_id)

    def get_level(self, level_num: int) -> CurriculumLevel | None:
        """Get a curriculum level definition."""
        return self._levels.get(level_num)

    def current_level(self, agent_id: str) -> CurriculumLevel | None:
        """Get the current curriculum level for an agent."""
        progress = self._progress.get(agent_id)
        if not progress:
            return None
        return self._levels.get(progress.current_level)

    def record_score(self, agent_id: str, score: float) -> dict[str, Any]:
        """Record a training episode score and check for level advancement.

        Returns a dict with advancement status and current level info.
        """
        progress = self._progress.get(agent_id)
        if not progress:
            return {"error": "Agent not registered"}

        progress.scores_per_level[progress.current_level].append(score)
        progress.total_episodes += 1

        level = self._levels.get(progress.current_level)
        if not level:
            return {"error": "Invalid level"}

        scores = progress.scores_per_level[progress.current_level]
        recent_mean = sum(scores[-10:]) / len(scores[-10:])  # Last 10 episodes

        advanced = False
        if recent_mean >= level.min_score_to_advance and len(scores) >= 5:
            next_level = progress.current_level + 1
            if next_level in self._levels:
                progress.level_history.append(
                    {
                        "from_level": progress.current_level,
                        "to_level": next_level,
                        "score": round(recent_mean, 4),
                        "episodes": len(scores),
                        "timestamp": datetime.now(tz=UTC).isoformat(),
                    }
                )
                progress.current_level = next_level
                advanced = True

        return {
            "agent_id": agent_id,
            "current_level": progress.current_level,
            "level_name": self._levels[progress.current_level].name,
            "recent_mean": round(recent_mean, 4),
            "advanced": advanced,
            "total_episodes": progress.total_episodes,
        }

    def training_config(self, agent_id: str) -> dict[str, Any]:
        """Generate a training config for the agent's current level."""
        progress = self._progress.get(agent_id)
        if not progress:
            return {"error": "Agent not registered"}

        level = self._levels.get(progress.current_level)
        if not level:
            return {"error": "Invalid level"}

        return {
            "level": level.level,
            "level_name": level.name,
            "operations": level.operations_unlocked,
            "difficulty_min": level.difficulty_range[0],
            "difficulty_max": level.difficulty_range[1],
            "max_context_length": level.max_context_length,
            "max_steps": level.max_steps,
            "min_score_to_advance": level.min_score_to_advance,
        }

    def all_levels(self) -> list[dict[str, Any]]:
        """Return all curriculum level definitions."""
        return [
            {
                "level": level.level,
                "name": level.name,
                "description": level.description,
                "operations": level.operations_unlocked,
                "difficulty_range": level.difficulty_range,
                "min_score": level.min_score_to_advance,
            }
            for level in sorted(self._levels.values(), key=lambda x: x.level)
        ]

    def update_from_eval(
        self,
        agent_id: str,
        eval_result: dict[str, Any],
    ) -> dict[str, Any]:
        """Update curriculum based on evaluation results.

        Adjusts the agent's curriculum progression based on eval scores,
        identifies weak areas to focus on, and optionally adjusts
        difficulty ranges for the current level.

        Args:
            agent_id: The agent identifier.
            eval_result: Evaluation result dict with ``mean_score`` and
                optional ``per_dimension`` or ``dimension_scores`` mapping.

        Returns:
            Dict with curriculum update status and recommendations.
        """
        progress = self._progress.get(agent_id)
        if not progress:
            return {"error": "Agent not registered"}

        mean_score = eval_result.get("mean_score", 0.0)
        dim_scores = eval_result.get("per_dimension", {})
        if not dim_scores:
            dim_scores = eval_result.get("dimension_scores", {})

        # Record the overall score for advancement tracking
        advancement = self.record_score(agent_id, mean_score)

        # Analyze dimension-level weaknesses
        weak_dims: list[str] = []
        strong_dims: list[str] = []
        for dim_id, score in dim_scores.items():
            if score < 0.5:
                weak_dims.append(dim_id)
            elif score >= 0.8:
                strong_dims.append(dim_id)

        # Generate focus recommendations
        recommendations: list[str] = []
        if weak_dims:
            recommendations.append(f"Focus training on weak dimensions: {', '.join(weak_dims[:5])}")
        if mean_score < 0.4:
            recommendations.append("Consider reducing difficulty or revisiting previous level")
        if advancement.get("advanced"):
            recommendations.append(
                f"Agent advanced to level {advancement['current_level']} "
                f"({advancement['level_name']})"
            )

        return {
            "agent_id": agent_id,
            "mean_score": round(mean_score, 4),
            "current_level": advancement.get("current_level", progress.current_level),
            "advanced": advancement.get("advanced", False),
            "weak_dimensions": weak_dims,
            "strong_dimensions": strong_dims,
            "recommendations": recommendations,
            "total_episodes": progress.total_episodes,
        }

    def summary(self) -> dict[str, Any]:
        """Return summary of all agents' curriculum progress."""
        agents = []
        for agent_id, progress in self._progress.items():
            level = self._levels.get(progress.current_level)
            agents.append(
                {
                    "agent_id": agent_id,
                    "current_level": progress.current_level,
                    "level_name": level.name if level else "unknown",
                    "total_episodes": progress.total_episodes,
                    "advancements": len(progress.level_history),
                }
            )
        return {"total_agents": len(agents), "agents": agents}
