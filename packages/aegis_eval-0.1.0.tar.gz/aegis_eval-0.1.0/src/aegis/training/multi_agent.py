"""Multi-agent context coordination training.

Trains agents to share knowledge, resolve conflicts, construct shared memory,
divide labor, and defer to expertise.  This module implements Level 7 of the
training hierarchy, building on all previous levels to enable collaborative
multi-agent behaviour.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

__all__ = [
    "AgentProfile",
    "SharedKnowledge",
    "RelevanceFilter",
    "ConflictResolver",
    "DivisionOfLabor",
    "DeferencePolicy",
    "MultiAgentCoordinator",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _det_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    """Return a deterministic float in [low, high] derived from *seed*."""
    digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return low + int(digest[:8], 16) / 0xFFFFFFFF * (high - low)


def _det_int(seed: str, low: int, high: int) -> int:
    """Return a deterministic integer in [low, high] derived from *seed*."""
    return int(_det_float(seed, float(low), float(high) + 0.999))


def _det_choice(seed: str, options: list[Any]) -> Any:
    """Return a deterministic choice from *options*."""
    if not options:
        return None
    idx = int(hashlib.sha256(seed.encode("utf-8")).hexdigest()[:8], 16) % len(options)
    return options[idx]


# ---------------------------------------------------------------------------
# AgentProfile
# ---------------------------------------------------------------------------


@dataclass
class AgentProfile:
    """Profile of an agent participating in multi-agent coordination.

    Captures the agent's capabilities, domain expertise, trust score,
    and interaction history for use in coordination decisions.

    Attributes:
        agent_id: Unique identifier for this agent.
        name: Human-readable agent name.
        domains: List of domain expertise areas (e.g. ["legal", "finance"]).
        expertise_scores: Mapping of domain to expertise level (0-1).
        trust_score: Overall trust calibration score (0-1).
        capabilities: List of capability strings this agent supports.
        interaction_count: Number of prior interactions with this agent.
        success_rate: Historical success rate in coordinated tasks (0-1).
        last_active: Timestamp of last interaction.
        metadata: Additional profile metadata.
    """

    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    domains: list[str] = field(default_factory=list)
    expertise_scores: dict[str, float] = field(default_factory=dict)
    trust_score: float = 0.5
    capabilities: list[str] = field(default_factory=list)
    interaction_count: int = 0
    success_rate: float = 0.5
    last_active: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)

    def expertise_in(self, domain: str) -> float:
        """Return the expertise score for a specific domain.

        Falls back to a default score based on whether the domain
        appears in the agent's domain list.

        Args:
            domain: The domain to query.

        Returns:
            Expertise score (0-1).
        """
        if domain in self.expertise_scores:
            return self.expertise_scores[domain]
        if domain in self.domains:
            return 0.5  # Known domain, no calibrated score
        return 0.1  # Unknown domain

    def effective_trust(self, domain: str) -> float:
        """Compute effective trust for a domain-specific task.

        Combines the global trust score with domain expertise to produce
        a task-specific trust measure.

        Args:
            domain: The task domain.

        Returns:
            Effective trust score (0-1).
        """
        domain_expertise = self.expertise_in(domain)
        # Weighted combination: 60% trust, 40% expertise
        effective = 0.6 * self.trust_score + 0.4 * domain_expertise
        # Adjust by success rate
        if self.interaction_count >= 5:
            effective = effective * 0.7 + self.success_rate * 0.3
        return max(0.0, min(1.0, effective))

    def to_dict(self) -> dict[str, Any]:
        """Serialize the profile to a dictionary.

        Returns:
            A JSON-serializable dictionary.
        """
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "domains": self.domains,
            "expertise_scores": {k: round(v, 4) for k, v in self.expertise_scores.items()},
            "trust_score": round(self.trust_score, 4),
            "capabilities": self.capabilities,
            "interaction_count": self.interaction_count,
            "success_rate": round(self.success_rate, 4),
            "last_active": self.last_active.isoformat(),
        }


# ---------------------------------------------------------------------------
# SharedKnowledge
# ---------------------------------------------------------------------------


@dataclass
class SharedKnowledge:
    """Shared knowledge base between coordinating agents.

    Maintains a common pool of knowledge entries with provenance
    tracking, conflict flags, and access control metadata.

    Attributes:
        id: Unique identifier for this shared knowledge base.
        name: Descriptive name for the shared context.
        entries: List of knowledge entry dictionaries.
        contributors: Set of agent IDs that have contributed.
        conflict_flags: List of flagged conflicts between entries.
        created_at: Creation timestamp.
        metadata: Additional metadata.
    """

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "shared_knowledge"
    entries: list[dict[str, Any]] = field(default_factory=list)
    contributors: set[str] = field(default_factory=set)
    conflict_flags: list[dict[str, Any]] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)

    def add_entry(
        self,
        content: dict[str, Any],
        contributor_id: str,
        confidence: float = 1.0,
    ) -> str:
        """Add a knowledge entry to the shared base.

        Args:
            content: The knowledge content dictionary.
            contributor_id: ID of the contributing agent.
            confidence: Contributor's confidence in this entry (0-1).

        Returns:
            The ID of the newly added entry.
        """
        entry_id = str(uuid.uuid4())
        entry = {
            "id": entry_id,
            "content": content,
            "contributor_id": contributor_id,
            "confidence": max(0.0, min(1.0, confidence)),
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "version": 1,
            "superseded_by": None,
        }
        self.entries.append(entry)
        self.contributors.add(contributor_id)

        # Check for conflicts with existing entries
        self._check_conflicts(entry)

        return entry_id

    def _check_conflicts(self, new_entry: dict[str, Any]) -> None:
        """Check if a new entry conflicts with existing entries.

        Uses key overlap and content comparison to detect potential
        conflicts.  Flagged conflicts are stored for later resolution.

        Args:
            new_entry: The newly added entry to check.
        """
        new_content = new_entry.get("content", {})
        new_keys = set(new_content.keys()) if isinstance(new_content, dict) else set()

        for existing in self.entries:
            if existing["id"] == new_entry["id"]:
                continue
            if existing.get("superseded_by") is not None:
                continue

            existing_content = existing.get("content", {})
            existing_keys = (
                set(existing_content.keys()) if isinstance(existing_content, dict) else set()
            )

            # Check for key overlap
            overlap = new_keys & existing_keys
            if not overlap:
                continue

            # Check for value conflicts on overlapping keys
            conflicts: list[str] = []
            for key in overlap:
                if (
                    isinstance(new_content, dict)
                    and isinstance(existing_content, dict)
                    and new_content.get(key) != existing_content.get(key)
                ):
                    conflicts.append(key)

            if conflicts:
                self.conflict_flags.append(
                    {
                        "id": str(uuid.uuid4()),
                        "entry_a_id": existing["id"],
                        "entry_b_id": new_entry["id"],
                        "contributor_a": existing.get("contributor_id", "unknown"),
                        "contributor_b": new_entry.get("contributor_id", "unknown"),
                        "conflicting_keys": conflicts,
                        "resolved": False,
                        "resolution": None,
                        "timestamp": datetime.now(tz=UTC).isoformat(),
                    }
                )

    def get_unresolved_conflicts(self) -> list[dict[str, Any]]:
        """Return all unresolved conflicts.

        Returns:
            A list of conflict flag dictionaries where resolved is False.
        """
        return [c for c in self.conflict_flags if not c.get("resolved", False)]

    def resolve_conflict(self, conflict_id: str, resolution: dict[str, Any]) -> bool:
        """Resolve a flagged conflict.

        Args:
            conflict_id: The ID of the conflict to resolve.
            resolution: Resolution details including the winning entry
                and reasoning.

        Returns:
            True if the conflict was found and resolved, False otherwise.
        """
        for conflict in self.conflict_flags:
            if conflict["id"] == conflict_id:
                conflict["resolved"] = True
                conflict["resolution"] = resolution
                conflict["resolved_at"] = datetime.now(tz=UTC).isoformat()

                # Mark the losing entry as superseded
                losing_id = resolution.get("superseded_entry_id")
                if losing_id:
                    for entry in self.entries:
                        if entry["id"] == losing_id:
                            winning_id = resolution.get("winning_entry_id")
                            entry["superseded_by"] = winning_id
                            break

                return True
        return False

    def active_entries(self) -> list[dict[str, Any]]:
        """Return all non-superseded entries.

        Returns:
            A list of active entry dictionaries.
        """
        return [e for e in self.entries if e.get("superseded_by") is None]

    def to_dict(self) -> dict[str, Any]:
        """Serialize the shared knowledge base to a dictionary.

        Returns:
            A JSON-serializable dictionary.
        """
        return {
            "id": self.id,
            "name": self.name,
            "total_entries": len(self.entries),
            "active_entries": len(self.active_entries()),
            "contributors": sorted(self.contributors),
            "unresolved_conflicts": len(self.get_unresolved_conflicts()),
            "total_conflicts": len(self.conflict_flags),
            "created_at": self.created_at.isoformat(),
        }


# ---------------------------------------------------------------------------
# RelevanceFilter
# ---------------------------------------------------------------------------


class RelevanceFilter:
    """Decides what knowledge to share with another agent.

    Not all knowledge is relevant to all agents. The relevance filter
    scores knowledge entries against a target agent's profile to
    determine what should be shared, preventing information overload.
    """

    def __init__(
        self,
        relevance_threshold: float = 0.3,
        max_share_ratio: float = 0.5,
    ) -> None:
        self._relevance_threshold = relevance_threshold
        self._max_share_ratio = max_share_ratio
        self._filter_log: list[dict[str, Any]] = []

    def filter(
        self,
        knowledge: list[dict[str, Any]],
        target_agent: AgentProfile,
    ) -> list[dict[str, Any]]:
        """Filter knowledge entries for relevance to a target agent.

        Scores each entry against the target agent's domain expertise
        and capabilities, returning only entries above the relevance
        threshold.

        Args:
            knowledge: List of knowledge entry dicts. Each should have
                at least ``content`` and optionally ``domain``, ``tags``,
                and ``confidence`` keys.
            target_agent: The agent that will receive the filtered knowledge.

        Returns:
            A filtered list of knowledge entries sorted by relevance.
        """
        if not knowledge:
            return []

        scored_entries: list[tuple[dict[str, Any], float]] = []

        for entry in knowledge:
            relevance = self._score_relevance(entry, target_agent)
            if relevance >= self._relevance_threshold:
                scored_entries.append((entry, relevance))

        # Sort by relevance (descending)
        scored_entries.sort(key=lambda x: x[1], reverse=True)

        # Cap at max_share_ratio of total knowledge
        max_share = max(1, int(len(knowledge) * self._max_share_ratio))
        selected = scored_entries[:max_share]

        # Add relevance score to each entry
        result: list[dict[str, Any]] = []
        for entry, score in selected:
            shared_entry = dict(entry)
            shared_entry["relevance_score"] = round(score, 4)
            result.append(shared_entry)

        self._filter_log.append(
            {
                "target_agent": target_agent.agent_id,
                "total_knowledge": len(knowledge),
                "above_threshold": len(scored_entries),
                "shared": len(result),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        return result

    def _score_relevance(self, entry: dict[str, Any], target: AgentProfile) -> float:
        """Score the relevance of a knowledge entry to a target agent.

        Args:
            entry: Knowledge entry dictionary.
            target: Target agent profile.

        Returns:
            Relevance score (0-1).
        """
        score = 0.0
        components = 0

        # Domain match
        entry_domain = entry.get("domain", "")
        if entry_domain:
            domain_expertise = target.expertise_in(entry_domain)
            # Higher expertise -> more relevant (agent can use it)
            # But also share things slightly outside expertise (learning opportunity)
            if domain_expertise >= 0.3:
                score += domain_expertise * 0.8
            else:
                score += 0.1  # Small base relevance
            components += 1

        # Tag overlap with capabilities
        entry_tags = set(entry.get("tags", []))
        agent_caps = set(target.capabilities)
        if entry_tags and agent_caps:
            overlap = entry_tags & agent_caps
            tag_score = len(overlap) / max(len(entry_tags | agent_caps), 1)
            score += tag_score
            components += 1

        # Confidence weighting: higher confidence entries are more worth sharing
        confidence_raw = entry.get("confidence", 0.5)
        try:
            confidence = float(confidence_raw)
        except (TypeError, ValueError):
            confidence = 0.5
        score += confidence * 0.3
        components += 1

        # Content complexity matching
        content = entry.get("content", {})
        if isinstance(content, dict):
            content_size = len(content)
            # Moderate-size entries are most useful
            if 2 <= content_size <= 10:
                score += 0.2
            elif content_size > 0:
                score += 0.1
            components += 1

        # Recency bonus
        entry_ts = entry.get("timestamp")
        if entry_ts:
            score += 0.1  # Static bonus for having a timestamp
            components += 1

        # Normalize by number of components evaluated
        if components > 0:
            score /= components

        # Deterministic noise based on entry content for differentiation
        entry_key = str(entry.get("id", "")) + target.agent_id
        noise = _det_float(f"relevance:{entry_key}", -0.05, 0.05)
        score += noise

        return max(0.0, min(1.0, score))

    def summary(self) -> dict[str, Any]:
        """Return a summary of filtering activity.

        Returns:
            A dictionary with filter statistics.
        """
        total_filtered = (
            sum(log["total_knowledge"] for log in self._filter_log) if self._filter_log else 0
        )
        total_shared = sum(log["shared"] for log in self._filter_log) if self._filter_log else 0

        return {
            "filter_events": len(self._filter_log),
            "total_knowledge_evaluated": total_filtered,
            "total_shared": total_shared,
            "share_rate": round(total_shared / max(total_filtered, 1), 4),
            "relevance_threshold": self._relevance_threshold,
            "max_share_ratio": self._max_share_ratio,
        }


# ---------------------------------------------------------------------------
# ConflictResolver
# ---------------------------------------------------------------------------


class ConflictResolver:
    """Resolves contradictory information between agents.

    Uses multiple resolution strategies based on evidence quality,
    source credibility, temporal recency, and consensus among agents.
    """

    def __init__(self) -> None:
        self._resolution_log: list[dict[str, Any]] = []
        self._strategy_counts: dict[str, int] = {}

    def resolve(
        self,
        claim_a: dict[str, Any],
        claim_b: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Resolve a conflict between two competing claims.

        Applies multiple resolution strategies and synthesizes a final
        verdict based on the weight of evidence.

        Args:
            claim_a: First claim dict with keys ``value``, ``confidence``,
                ``source``, ``timestamp``, ``evidence`` (list), and
                ``agent_id``.
            claim_b: Second claim dict with the same keys.
            context: Contextual information for resolution, including
                ``domain``, ``agent_profiles`` (dict of AgentProfile),
                and ``resolution_strategy`` (optional override).

        Returns:
            A resolution dict with ``winner``, ``confidence``,
            ``strategy_used``, ``reasoning``, and ``merged_value`` keys.
        """
        seed = f"resolve:{claim_a.get('value', '')}:{claim_b.get('value', '')}"

        strategies = [
            ("confidence", self._resolve_by_confidence(claim_a, claim_b)),
            ("evidence", self._resolve_by_evidence(claim_a, claim_b)),
            ("recency", self._resolve_by_recency(claim_a, claim_b)),
            ("expertise", self._resolve_by_expertise(claim_a, claim_b, context)),
            ("consensus", self._resolve_by_consensus(claim_a, claim_b, context)),
        ]

        # Check for strategy override
        override_strategy = context.get("resolution_strategy")
        if override_strategy:
            for name, result in strategies:
                if name == override_strategy:
                    strategies = [(name, result)]
                    break

        # Aggregate strategy votes
        votes_a = 0.0
        votes_b = 0.0
        vote_details: list[dict[str, str | float]] = []

        for strategy_name, result in strategies:
            winner = result.get("winner", "a")
            strength = result.get("strength", 0.5)
            reasoning = result.get("reasoning", "")

            if winner == "a":
                votes_a += strength
            elif winner == "b":
                votes_b += strength
            else:
                votes_a += strength * 0.5
                votes_b += strength * 0.5

            vote_details.append(
                {
                    "strategy": strategy_name,
                    "winner": winner,
                    "strength": round(strength, 4),
                    "reasoning": reasoning,
                }
            )

        # Determine final winner
        total_votes = votes_a + votes_b
        if total_votes == 0:
            total_votes = 1.0

        if votes_a > votes_b:
            final_winner = "a"
            winning_claim = claim_a
            losing_claim = claim_b
            confidence = votes_a / total_votes
        elif votes_b > votes_a:
            final_winner = "b"
            winning_claim = claim_b
            losing_claim = claim_a
            confidence = votes_b / total_votes
        else:
            # Tie: use deterministic tiebreaker
            if _det_float(seed) >= 0.5:
                final_winner = "a"
                winning_claim = claim_a
                losing_claim = claim_b
            else:
                final_winner = "b"
                winning_claim = claim_b
                losing_claim = claim_a
            confidence = 0.5

        # Determine strategy that most influenced the outcome
        primary_strategy = max(strategies, key=lambda s: s[1].get("strength", 0))[0]

        # Build merged value: winning value with note about conflict
        merged_value = {
            "value": winning_claim.get("value"),
            "source": winning_claim.get("source", "unknown"),
            "confidence": round(confidence, 4),
            "conflict_noted": True,
            "alternative_value": losing_claim.get("value"),
            "alternative_source": losing_claim.get("source", "unknown"),
        }

        # Build reasoning summary
        reasoning_parts = [
            f"{v['strategy']}: {v['reasoning']}" for v in vote_details if v.get("reasoning")
        ]
        reasoning_summary = (
            "; ".join(reasoning_parts) if reasoning_parts else "No detailed reasoning available."
        )

        resolution = {
            "winner": final_winner,
            "winning_claim": winning_claim,
            "losing_claim": losing_claim,
            "confidence": round(confidence, 4),
            "strategy_used": primary_strategy,
            "vote_details": vote_details,
            "votes_a": round(votes_a, 4),
            "votes_b": round(votes_b, 4),
            "merged_value": merged_value,
            "reasoning": reasoning_summary,
            "timestamp": datetime.now(tz=UTC).isoformat(),
        }

        self._resolution_log.append(
            {
                "winner": final_winner,
                "strategy": primary_strategy,
                "confidence": round(confidence, 4),
            }
        )
        self._strategy_counts[primary_strategy] = self._strategy_counts.get(primary_strategy, 0) + 1

        return resolution

    def _resolve_by_confidence(
        self, claim_a: dict[str, Any], claim_b: dict[str, Any]
    ) -> dict[str, Any]:
        """Resolve based on confidence scores.

        Args:
            claim_a: First claim.
            claim_b: Second claim.

        Returns:
            Resolution dict with winner, strength, and reasoning.
        """
        conf_a = float(claim_a.get("confidence", 0.5))
        conf_b = float(claim_b.get("confidence", 0.5))

        if conf_a > conf_b:
            winner = "a"
            strength = min(1.0, (conf_a - conf_b) * 2 + 0.5)
        elif conf_b > conf_a:
            winner = "b"
            strength = min(1.0, (conf_b - conf_a) * 2 + 0.5)
        else:
            winner = "tie"
            strength = 0.5

        return {
            "winner": winner,
            "strength": strength,
            "reasoning": f"Confidence comparison: a={conf_a:.2f} vs b={conf_b:.2f}",
        }

    def _resolve_by_evidence(
        self, claim_a: dict[str, Any], claim_b: dict[str, Any]
    ) -> dict[str, Any]:
        """Resolve based on evidence quality and quantity.

        Args:
            claim_a: First claim.
            claim_b: Second claim.

        Returns:
            Resolution dict with winner, strength, and reasoning.
        """
        evidence_a = claim_a.get("evidence", [])
        evidence_b = claim_b.get("evidence", [])

        count_a = len(evidence_a) if isinstance(evidence_a, list) else 0
        count_b = len(evidence_b) if isinstance(evidence_b, list) else 0

        if count_a > count_b:
            winner = "a"
            strength = min(1.0, 0.5 + 0.1 * (count_a - count_b))
        elif count_b > count_a:
            winner = "b"
            strength = min(1.0, 0.5 + 0.1 * (count_b - count_a))
        else:
            winner = "tie"
            strength = 0.5

        return {
            "winner": winner,
            "strength": strength,
            "reasoning": f"Evidence count: a={count_a} vs b={count_b}",
        }

    def _resolve_by_recency(
        self, claim_a: dict[str, Any], claim_b: dict[str, Any]
    ) -> dict[str, Any]:
        """Resolve based on temporal recency.

        More recent information is typically more reliable, unless
        explicitly noted otherwise.

        Args:
            claim_a: First claim.
            claim_b: Second claim.

        Returns:
            Resolution dict with winner, strength, and reasoning.
        """
        ts_a = claim_a.get("timestamp", "")
        ts_b = claim_b.get("timestamp", "")

        # Compare as strings (ISO format sorts correctly)
        if ts_a and ts_b:
            if ts_a > ts_b:
                winner = "a"
                strength = 0.6
            elif ts_b > ts_a:
                winner = "b"
                strength = 0.6
            else:
                winner = "tie"
                strength = 0.5
        elif ts_a:
            winner = "a"
            strength = 0.55
        elif ts_b:
            winner = "b"
            strength = 0.55
        else:
            winner = "tie"
            strength = 0.3  # Low confidence when no timestamps

        return {
            "winner": winner,
            "strength": strength,
            "reasoning": f"Recency comparison: a='{ts_a}' vs b='{ts_b}'",
        }

    def _resolve_by_expertise(
        self,
        claim_a: dict[str, Any],
        claim_b: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Resolve based on agent expertise in the relevant domain.

        Args:
            claim_a: First claim.
            claim_b: Second claim.
            context: Context with agent_profiles dict.

        Returns:
            Resolution dict with winner, strength, and reasoning.
        """
        domain = context.get("domain", "general")
        profiles = context.get("agent_profiles", {})

        agent_a_id = claim_a.get("agent_id", "")
        agent_b_id = claim_b.get("agent_id", "")

        profile_a = profiles.get(agent_a_id)
        profile_b = profiles.get(agent_b_id)

        expertise_a = 0.5
        expertise_b = 0.5

        if isinstance(profile_a, AgentProfile):
            expertise_a = profile_a.expertise_in(domain)
        elif isinstance(profile_a, dict):
            expertise_a = float(profile_a.get("expertise_scores", {}).get(domain, 0.5))

        if isinstance(profile_b, AgentProfile):
            expertise_b = profile_b.expertise_in(domain)
        elif isinstance(profile_b, dict):
            expertise_b = float(profile_b.get("expertise_scores", {}).get(domain, 0.5))

        if expertise_a > expertise_b:
            winner = "a"
            strength = min(1.0, 0.5 + (expertise_a - expertise_b))
        elif expertise_b > expertise_a:
            winner = "b"
            strength = min(1.0, 0.5 + (expertise_b - expertise_a))
        else:
            winner = "tie"
            strength = 0.5

        return {
            "winner": winner,
            "strength": strength,
            "reasoning": f"Domain '{domain}' expertise: a={expertise_a:.2f} vs b={expertise_b:.2f}",
        }

    def _resolve_by_consensus(
        self,
        claim_a: dict[str, Any],
        claim_b: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Resolve based on consensus from other agents.

        If additional agent opinions are available in the context,
        count votes for each claim.

        Args:
            claim_a: First claim.
            claim_b: Second claim.
            context: Context with optional ``other_opinions`` list.

        Returns:
            Resolution dict with winner, strength, and reasoning.
        """
        other_opinions = context.get("other_opinions", [])

        if not other_opinions:
            return {
                "winner": "tie",
                "strength": 0.3,
                "reasoning": "No consensus data available",
            }

        votes_a = 0.0
        votes_b = 0.0
        value_a = claim_a.get("value")
        value_b = claim_b.get("value")

        for opinion in other_opinions:
            opinion_value = opinion.get("value")
            opinion_confidence = float(opinion.get("confidence", 0.5))

            if opinion_value == value_a:
                votes_a += opinion_confidence
            elif opinion_value == value_b:
                votes_b += opinion_confidence
            # Else: neutral / different opinion

        total_votes = votes_a + votes_b
        if total_votes > 0:
            if votes_a > votes_b:
                winner = "a"
                strength = min(1.0, 0.5 + (votes_a - votes_b) / total_votes * 0.5)
            elif votes_b > votes_a:
                winner = "b"
                strength = min(1.0, 0.5 + (votes_b - votes_a) / total_votes * 0.5)
            else:
                winner = "tie"
                strength = 0.5
        else:
            winner = "tie"
            strength = 0.3

        return {
            "winner": winner,
            "strength": strength,
            "reasoning": f"Consensus votes: a={votes_a:.1f}, b={votes_b:.1f} from {len(other_opinions)} agents",
        }

    def summary(self) -> dict[str, Any]:
        """Return a summary of conflict resolution activity.

        Returns:
            A dictionary with resolution statistics.
        """
        return {
            "total_resolutions": len(self._resolution_log),
            "strategy_counts": dict(self._strategy_counts),
            "mean_confidence": round(
                sum(r["confidence"] for r in self._resolution_log) / len(self._resolution_log), 4
            )
            if self._resolution_log
            else 0.0,
            "winner_distribution": {
                "a": sum(1 for r in self._resolution_log if r["winner"] == "a"),
                "b": sum(1 for r in self._resolution_log if r["winner"] == "b"),
                "tie": sum(1 for r in self._resolution_log if r["winner"] == "tie"),
            },
        }


# ---------------------------------------------------------------------------
# DivisionOfLabor
# ---------------------------------------------------------------------------


class DivisionOfLabor:
    """Routes retrieval work to the best-positioned agent.

    Analyzes task requirements and agent capabilities to assign tasks
    to the agent most likely to succeed, considering expertise, load
    balance, and trust.
    """

    def __init__(self, load_balance_weight: float = 0.2) -> None:
        self._load_balance_weight = load_balance_weight
        self._assignment_log: list[dict[str, Any]] = []
        self._agent_load: dict[str, int] = {}

    def assign(
        self,
        task: dict[str, Any],
        agents: list[AgentProfile],
    ) -> AgentProfile:
        """Assign a task to the best-positioned agent.

        Scores each agent based on domain expertise, capabilities match,
        current load, trust, and success rate.

        Args:
            task: Task dictionary with keys ``domain``, ``type``,
                ``required_capabilities`` (list), ``difficulty``.
            agents: List of available agent profiles.

        Returns:
            The selected :class:`AgentProfile`.

        Raises:
            ValueError: If *agents* is empty.
        """
        if not agents:
            raise ValueError("Cannot assign task: no agents available")

        if len(agents) == 1:
            selected = agents[0]
            self._record_assignment(selected.agent_id, task)
            return selected

        task_domain = task.get("domain", "general")
        required_caps = set(task.get("required_capabilities", []))
        difficulty = task.get("difficulty", 3)

        scored_agents: list[tuple[AgentProfile, float]] = []

        for agent in agents:
            score = self._score_agent_for_task(agent, task_domain, required_caps, difficulty)
            scored_agents.append((agent, score))

        # Sort by score descending
        scored_agents.sort(key=lambda x: x[1], reverse=True)

        selected = scored_agents[0][0]
        self._record_assignment(selected.agent_id, task)

        return selected

    def assign_subtasks(
        self,
        task: dict[str, Any],
        agents: list[AgentProfile],
    ) -> list[tuple[AgentProfile, dict[str, Any]]]:
        """Divide a complex task into subtasks and assign each.

        Decomposes the task based on its ``subtasks`` field (or
        generates subtasks from the task type) and assigns each
        to the most suitable agent.

        Args:
            task: Task dict with optional ``subtasks`` list.
            agents: List of available agents.

        Returns:
            A list of (agent, subtask) tuples.
        """
        if not agents:
            raise ValueError("Cannot assign subtasks: no agents available")

        subtasks = task.get("subtasks", [])
        if not subtasks:
            # Generate default subtasks based on task type
            subtasks = self._decompose_task(task)

        assignments: list[tuple[AgentProfile, dict[str, Any]]] = []

        for subtask in subtasks:
            best_agent = self.assign(subtask, agents)
            assignments.append((best_agent, subtask))

        return assignments

    def _score_agent_for_task(
        self,
        agent: AgentProfile,
        domain: str,
        required_caps: set[str],
        difficulty: int,
    ) -> float:
        """Score an agent's suitability for a task.

        Args:
            agent: Agent to evaluate.
            domain: Task domain.
            required_caps: Required capabilities.
            difficulty: Task difficulty (1-5).

        Returns:
            Suitability score (0-1).
        """
        # Domain expertise (40% weight)
        expertise = agent.expertise_in(domain)
        expertise_score = expertise * 0.4

        # Capability match (25% weight)
        agent_caps = set(agent.capabilities)
        if required_caps:
            cap_overlap = required_caps & agent_caps
            cap_score = (len(cap_overlap) / len(required_caps)) * 0.25
        else:
            cap_score = 0.125  # Default when no specific caps required

        # Trust and success rate (20% weight)
        trust_score = agent.effective_trust(domain) * 0.20

        # Load balance (15% weight)
        current_load = self._agent_load.get(agent.agent_id, 0)
        max_load = max(self._agent_load.values()) if self._agent_load else 1
        load_factor = 1.0 - (current_load / max(max_load, 1)) * self._load_balance_weight
        load_score = max(0.0, load_factor) * 0.15

        # Difficulty adjustment: harder tasks need more expertise
        if difficulty >= 4 and expertise < 0.5:
            expertise_score *= 0.7  # Penalize low expertise on hard tasks

        total = expertise_score + cap_score + trust_score + load_score
        return max(0.0, min(1.0, total))

    def _decompose_task(self, task: dict[str, Any]) -> list[dict[str, Any]]:
        """Decompose a task into subtasks.

        Args:
            task: The task to decompose.

        Returns:
            A list of subtask dictionaries.
        """
        task_type = task.get("type", "general")
        domain = task.get("domain", "general")
        difficulty = task.get("difficulty", 3)

        # Default decomposition patterns
        patterns: dict[str, list[dict[str, str]]] = {
            "multi_source_retrieval": [
                {"type": "retrieval", "focus": "vector_search"},
                {"type": "retrieval", "focus": "graph_search"},
                {"type": "synthesis", "focus": "merge_results"},
            ],
            "conflict_resolution": [
                {"type": "analysis", "focus": "claim_evaluation"},
                {"type": "retrieval", "focus": "evidence_gathering"},
                {"type": "reasoning", "focus": "resolution"},
            ],
            "knowledge_sharing": [
                {"type": "filtering", "focus": "relevance_assessment"},
                {"type": "transfer", "focus": "knowledge_packaging"},
                {"type": "verification", "focus": "receipt_confirmation"},
            ],
        }

        subtask_templates = patterns.get(
            task_type,
            [
                {"type": "analysis", "focus": "task_understanding"},
                {"type": "retrieval", "focus": "information_gathering"},
                {"type": "synthesis", "focus": "answer_construction"},
            ],
        )

        subtasks = []
        for st_template in subtask_templates:
            subtask = {
                "id": str(uuid.uuid4()),
                "parent_task_id": task.get("id", ""),
                "type": st_template["type"],
                "domain": domain,
                "difficulty": max(1, difficulty - 1),
                "focus": st_template["focus"],
                "required_capabilities": task.get("required_capabilities", []),
            }
            subtasks.append(subtask)

        return subtasks

    def _record_assignment(self, agent_id: str, task: dict[str, Any]) -> None:
        """Record a task assignment for tracking.

        Args:
            agent_id: Assigned agent ID.
            task: The assigned task.
        """
        self._agent_load[agent_id] = self._agent_load.get(agent_id, 0) + 1
        self._assignment_log.append(
            {
                "agent_id": agent_id,
                "task_type": task.get("type", "unknown"),
                "domain": task.get("domain", "unknown"),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

    def summary(self) -> dict[str, Any]:
        """Return a summary of task assignment activity.

        Returns:
            A dictionary with assignment statistics.
        """
        agent_assignments: dict[str, int] = {}
        for log_entry in self._assignment_log:
            aid = log_entry["agent_id"]
            agent_assignments[aid] = agent_assignments.get(aid, 0) + 1

        return {
            "total_assignments": len(self._assignment_log),
            "agent_assignments": agent_assignments,
            "agent_load": dict(self._agent_load),
            "load_balance_weight": self._load_balance_weight,
        }


# ---------------------------------------------------------------------------
# DeferencePolicy
# ---------------------------------------------------------------------------


class DeferencePolicy:
    """Determines when an agent should defer to another's expertise.

    Uses self-confidence estimation, domain expertise comparison, and
    historical performance to decide whether the current agent should
    handle a task or defer to a more qualified peer.
    """

    def __init__(
        self,
        confidence_threshold: float = 0.4,
        expertise_gap_threshold: float = 0.25,
    ) -> None:
        self._confidence_threshold = confidence_threshold
        self._expertise_gap_threshold = expertise_gap_threshold
        self._deference_log: list[dict[str, Any]] = []

    def should_defer(
        self,
        task: dict[str, Any],
        self_confidence: float,
        agents: list[AgentProfile],
    ) -> AgentProfile | None:
        """Determine if the current agent should defer to another.

        Deference is recommended when:
        1. Self-confidence is below the threshold, AND
        2. Another agent has significantly higher domain expertise.

        Args:
            task: Task dictionary with ``domain`` and ``difficulty``.
            self_confidence: The current agent's confidence in handling
                this task (0-1).
            agents: List of other available agent profiles.

        Returns:
            The agent to defer to, or None if the current agent should
            handle the task.
        """
        if not agents:
            return None

        domain = task.get("domain", "general")
        difficulty = task.get("difficulty", 3)

        # High confidence: no deference needed
        if self_confidence >= self._confidence_threshold + 0.2:
            self._record_deference(None, task, self_confidence, "high_confidence")
            return None

        # Find the most expert available agent
        best_agent: AgentProfile | None = None
        best_score = 0.0

        for agent in agents:
            expertise = agent.expertise_in(domain)
            trust = agent.effective_trust(domain)
            # Combine expertise and trust
            agent_score = 0.6 * expertise + 0.4 * trust

            # Difficulty adjustment: harder tasks need more expertise gap
            if difficulty >= 4:
                agent_score *= 1.1  # Boost expert agents for hard tasks

            if agent_score > best_score:
                best_score = agent_score
                best_agent = agent

        if best_agent is None:
            self._record_deference(None, task, self_confidence, "no_candidates")
            return None

        # Check if deference is warranted
        expertise_gap = best_score - self_confidence

        if (
            self_confidence < self._confidence_threshold
            and expertise_gap >= self._expertise_gap_threshold
        ):
            self._record_deference(
                best_agent.agent_id, task, self_confidence, "low_confidence_high_gap"
            )
            return best_agent

        if expertise_gap >= self._expertise_gap_threshold * 2:
            # Very large gap: defer even with moderate confidence
            self._record_deference(best_agent.agent_id, task, self_confidence, "very_large_gap")
            return best_agent

        # Difficulty-based deference: defer on hard tasks when not confident
        if (
            difficulty >= 4
            and self_confidence < 0.5
            and expertise_gap >= self._expertise_gap_threshold * 0.7
        ):
            self._record_deference(
                best_agent.agent_id, task, self_confidence, "hard_task_deference"
            )
            return best_agent

        self._record_deference(None, task, self_confidence, "no_deference_needed")
        return None

    def _record_deference(
        self,
        deferred_to: str | None,
        task: dict[str, Any],
        self_confidence: float,
        reason: str,
    ) -> None:
        """Record a deference decision.

        Args:
            deferred_to: Agent ID deferred to, or None.
            task: The task in question.
            self_confidence: Current agent's confidence.
            reason: Reason for the decision.
        """
        self._deference_log.append(
            {
                "deferred": deferred_to is not None,
                "deferred_to": deferred_to,
                "task_domain": task.get("domain", "unknown"),
                "task_difficulty": task.get("difficulty", 0),
                "self_confidence": round(self_confidence, 4),
                "reason": reason,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

    def summary(self) -> dict[str, Any]:
        """Return a summary of deference decisions.

        Returns:
            A dictionary with deference statistics.
        """
        total = len(self._deference_log)
        deferred_count = sum(1 for d in self._deference_log if d["deferred"])
        reasons: dict[str, int] = {}
        for d in self._deference_log:
            r = d["reason"]
            reasons[r] = reasons.get(r, 0) + 1

        return {
            "total_decisions": total,
            "deferred_count": deferred_count,
            "deference_rate": round(deferred_count / max(total, 1), 4),
            "reasons": reasons,
            "confidence_threshold": self._confidence_threshold,
            "expertise_gap_threshold": self._expertise_gap_threshold,
        }


# ---------------------------------------------------------------------------
# MultiAgentCoordinator
# ---------------------------------------------------------------------------


class MultiAgentCoordinator:
    """Orchestrates multi-agent knowledge sharing and coordination.

    Provides a unified interface for registering agents, sharing
    knowledge, resolving conflicts, assigning tasks, and monitoring
    coordination health.
    """

    def __init__(
        self,
        relevance_threshold: float = 0.3,
        confidence_threshold: float = 0.4,
        expertise_gap_threshold: float = 0.25,
        load_balance_weight: float = 0.2,
    ) -> None:
        self._agents: dict[str, AgentProfile] = {}
        self._shared_knowledge = SharedKnowledge(name="coordinator_shared_kb")
        self._relevance_filter = RelevanceFilter(
            relevance_threshold=relevance_threshold,
        )
        self._conflict_resolver = ConflictResolver()
        self._division_of_labor = DivisionOfLabor(
            load_balance_weight=load_balance_weight,
        )
        self._deference_policy = DeferencePolicy(
            confidence_threshold=confidence_threshold,
            expertise_gap_threshold=expertise_gap_threshold,
        )
        self._coordination_log: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Agent management
    # ------------------------------------------------------------------

    def register_agent(self, profile: AgentProfile) -> None:
        """Register an agent for coordination.

        Args:
            profile: The agent's profile.
        """
        self._agents[profile.agent_id] = profile

    def get_agent(self, agent_id: str) -> AgentProfile | None:
        """Get a registered agent's profile.

        Args:
            agent_id: The agent identifier.

        Returns:
            The agent profile, or None if not registered.
        """
        return self._agents.get(agent_id)

    def update_agent(self, agent_id: str, updates: dict[str, Any]) -> bool:
        """Update an agent's profile.

        Args:
            agent_id: The agent to update.
            updates: Dictionary of field updates.

        Returns:
            True if the agent was found and updated.
        """
        agent = self._agents.get(agent_id)
        if agent is None:
            return False

        for key, value in updates.items():
            if hasattr(agent, key):
                setattr(agent, key, value)

        agent.last_active = datetime.now(tz=UTC)
        return True

    # ------------------------------------------------------------------
    # Knowledge sharing
    # ------------------------------------------------------------------

    def share_knowledge(
        self,
        from_agent: str,
        knowledge: list[dict[str, Any]],
    ) -> int:
        """Share knowledge from one agent to all relevant peers.

        Filters knowledge by relevance for each target agent and adds
        shared entries to the shared knowledge base.

        Args:
            from_agent: ID of the agent sharing knowledge.
            knowledge: List of knowledge entry dicts to share.

        Returns:
            Total number of knowledge entries shared (across all agents).
        """
        if from_agent not in self._agents:
            return 0

        total_shared = 0
        source_profile = self._agents[from_agent]

        for agent_id, target_profile in self._agents.items():
            if agent_id == from_agent:
                continue

            # Filter knowledge for relevance to this target
            relevant = self._relevance_filter.filter(knowledge, target_profile)

            for entry in relevant:
                self._shared_knowledge.add_entry(
                    content=entry.get("content", entry),
                    contributor_id=from_agent,
                    confidence=float(entry.get("confidence", 0.8)),
                )
                total_shared += 1

        self._coordination_log.append(
            {
                "action": "share_knowledge",
                "from_agent": from_agent,
                "total_entries": len(knowledge),
                "total_shared": total_shared,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        # Update source agent's interaction count
        source_profile.interaction_count += 1
        source_profile.last_active = datetime.now(tz=UTC)

        return total_shared

    # ------------------------------------------------------------------
    # Conflict resolution
    # ------------------------------------------------------------------

    def resolve_conflict(
        self,
        agents: list[str],
        claim: dict[str, Any],
    ) -> dict[str, Any]:
        """Resolve a conflict involving multiple agents.

        If the claim contains two competing values from different agents,
        applies the conflict resolver to determine the winner.

        Args:
            agents: List of agent IDs involved in the conflict.
            claim: Conflict description with ``claim_a`` and ``claim_b``
                sub-dicts, each containing ``value``, ``agent_id``,
                ``confidence``, ``evidence``, and ``timestamp``.

        Returns:
            Resolution result dictionary.
        """
        claim_a = claim.get("claim_a", {})
        claim_b = claim.get("claim_b", {})

        # Build context with agent profiles
        agent_profiles: dict[str, AgentProfile] = {}
        for agent_id in agents:
            if agent_id in self._agents:
                agent_profiles[agent_id] = self._agents[agent_id]

        context = {
            "domain": claim.get("domain", "general"),
            "agent_profiles": agent_profiles,
            "other_opinions": claim.get("other_opinions", []),
        }

        resolution = self._conflict_resolver.resolve(claim_a, claim_b, context)

        # Update shared knowledge with resolution
        self._shared_knowledge.add_entry(
            content={
                "type": "conflict_resolution",
                "claim_a": claim_a.get("value"),
                "claim_b": claim_b.get("value"),
                "resolution": resolution.get("winner"),
                "winning_value": resolution.get("merged_value", {}).get("value"),
            },
            contributor_id="coordinator",
            confidence=resolution.get("confidence", 0.5),
        )

        self._coordination_log.append(
            {
                "action": "resolve_conflict",
                "agents": agents,
                "winner": resolution.get("winner"),
                "strategy": resolution.get("strategy_used"),
                "confidence": resolution.get("confidence"),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        return resolution

    # ------------------------------------------------------------------
    # Task assignment
    # ------------------------------------------------------------------

    def assign_task(self, task: dict[str, Any]) -> str:
        """Assign a task to the best available agent.

        Args:
            task: Task dictionary with ``domain``, ``type``,
                ``required_capabilities``, and ``difficulty``.

        Returns:
            The agent_id of the assigned agent.

        Raises:
            ValueError: If no agents are registered.
        """
        if not self._agents:
            raise ValueError("No agents registered for task assignment")

        available_agents = list(self._agents.values())
        assigned = self._division_of_labor.assign(task, available_agents)

        self._coordination_log.append(
            {
                "action": "assign_task",
                "assigned_to": assigned.agent_id,
                "task_type": task.get("type", "unknown"),
                "task_domain": task.get("domain", "unknown"),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        # Update the assigned agent's interaction count
        assigned.interaction_count += 1
        assigned.last_active = datetime.now(tz=UTC)

        return assigned.agent_id

    # ------------------------------------------------------------------
    # Deference
    # ------------------------------------------------------------------

    def check_deference(
        self,
        requesting_agent: str,
        task: dict[str, Any],
        self_confidence: float,
    ) -> str | None:
        """Check if an agent should defer to a peer.

        Args:
            requesting_agent: ID of the agent asking.
            task: Task dictionary.
            self_confidence: The asking agent's confidence (0-1).

        Returns:
            Agent ID to defer to, or None.
        """
        other_agents = [profile for aid, profile in self._agents.items() if aid != requesting_agent]

        result = self._deference_policy.should_defer(task, self_confidence, other_agents)

        self._coordination_log.append(
            {
                "action": "check_deference",
                "requesting_agent": requesting_agent,
                "deferred_to": result.agent_id if result else None,
                "self_confidence": round(self_confidence, 4),
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        return result.agent_id if result else None

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a comprehensive summary of coordinator state.

        Returns:
            A dictionary with agent, knowledge, and coordination statistics.
        """
        action_counts: dict[str, int] = {}
        for entry in self._coordination_log:
            action = entry.get("action", "unknown")
            action_counts[action] = action_counts.get(action, 0) + 1

        return {
            "registered_agents": len(self._agents),
            "agents": {aid: profile.to_dict() for aid, profile in self._agents.items()},
            "shared_knowledge": self._shared_knowledge.to_dict(),
            "relevance_filter": self._relevance_filter.summary(),
            "conflict_resolver": self._conflict_resolver.summary(),
            "division_of_labor": self._division_of_labor.summary(),
            "deference_policy": self._deference_policy.summary(),
            "coordination_events": len(self._coordination_log),
            "action_counts": action_counts,
        }
