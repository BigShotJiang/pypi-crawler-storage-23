"""W&B experiment tracking with graceful local fallback.

Provides :class:`ExperimentTracker` which wraps Weights & Biases for
logging training metrics, artifacts, and tables.  When ``wandb`` is not
installed or no ``WANDB_API_KEY`` is set, metrics are written to a local
JSONL file at ``./tracking/{run_name}.jsonl``.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from aegis.core.settings import AegisSettings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy wandb import
# ---------------------------------------------------------------------------

try:
    import wandb  # type: ignore[import-not-found]

    _HAS_WANDB = True
except ImportError:
    wandb = None
    _HAS_WANDB = False


class ExperimentTracker:
    """Experiment tracker that wraps W&B with a local JSON fallback.

    When ``wandb`` is installed and a ``WANDB_API_KEY`` environment
    variable is present, metrics are logged to a real W&B run.  Otherwise
    all calls are recorded to ``./tracking/{run_name}.jsonl`` so that no
    data is silently discarded.

    Args:
        project: W&B project name.
        run_name: Human-readable run name.
        config: Hyperparameter / configuration dictionary logged at init.
        enabled: Master switch.  Set to ``False`` to disable all tracking.
    """

    def __init__(
        self,
        project: str,
        run_name: str,
        config: dict[str, Any] | None = None,
        enabled: bool = True,
    ) -> None:
        self._project = project
        self._run_name = run_name
        self._config = config or {}
        self._enabled = enabled
        self._use_wandb = False
        self._run: Any = None
        self._local_path: Path | None = None

        if not self._enabled:
            logger.info("ExperimentTracker disabled")
            return

        settings = AegisSettings()

        # Attempt W&B initialisation
        if _HAS_WANDB and settings.observability.wandb_api_key:
            try:
                self._run = wandb.init(
                    project=project,
                    name=run_name,
                    config=self._config,
                    reinit=True,
                )
                self._use_wandb = True
                logger.info(
                    "W&B tracking enabled: project=%s, run=%s",
                    project,
                    run_name,
                )
            except Exception as exc:
                logger.warning("W&B init failed (%s), falling back to local", exc)
                self._use_wandb = False
        else:
            reason = "wandb not installed" if not _HAS_WANDB else "WANDB_API_KEY not set"
            logger.info("W&B unavailable (%s), using local JSONL fallback", reason)

        # Set up local fallback path (always created for safety)
        if not self._use_wandb:
            self._local_path = Path("./tracking") / f"{run_name}.jsonl"
            self._local_path.parent.mkdir(parents=True, exist_ok=True)
            # Write initial config entry
            self._write_local(
                {
                    "type": "init",
                    "project": project,
                    "run_name": run_name,
                    "config": self._config,
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_metrics(self, step: int, metrics: dict[str, Any]) -> None:
        """Log per-step metrics.

        Args:
            step: Training step number.
            metrics: Dictionary of metric name to value.
        """
        if not self._enabled:
            return

        if self._use_wandb:
            try:
                wandb.log(metrics, step=step)
            except Exception as exc:
                logger.warning("W&B log_metrics failed at step %d: %s", step, exc)
        else:
            self._write_local(
                {
                    "type": "metrics",
                    "step": step,
                    "metrics": metrics,
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )

    def log_artifact(self, name: str, path: str, artifact_type: str = "model") -> None:
        """Log a file artifact.

        Args:
            name: Artifact name.
            path: File-system path to the artifact.
            artifact_type: Artifact type label (e.g. ``"model"``, ``"dataset"``).
        """
        if not self._enabled:
            return

        if self._use_wandb:
            try:
                artifact = wandb.Artifact(name=name, type=artifact_type)
                artifact_path = Path(path)
                if artifact_path.is_dir():
                    artifact.add_dir(str(artifact_path))
                else:
                    artifact.add_file(str(artifact_path))
                wandb.log_artifact(artifact)
                logger.info("Logged W&B artifact: %s (%s)", name, artifact_type)
            except Exception as exc:
                logger.warning("W&B log_artifact failed for %s: %s", name, exc)
        else:
            self._write_local(
                {
                    "type": "artifact",
                    "name": name,
                    "path": path,
                    "artifact_type": artifact_type,
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )

    def log_table(
        self,
        name: str,
        columns: list[str],
        data: list[list[Any]],
    ) -> None:
        """Log a table of data.

        Args:
            name: Table name / key for W&B.
            columns: Column headers.
            data: List of rows, each row a list of values.
        """
        if not self._enabled:
            return

        if self._use_wandb:
            try:
                table = wandb.Table(columns=columns, data=data)
                wandb.log({name: table})
                logger.info("Logged W&B table: %s (%d rows)", name, len(data))
            except Exception as exc:
                logger.warning("W&B log_table failed for %s: %s", name, exc)
        else:
            self._write_local(
                {
                    "type": "table",
                    "name": name,
                    "columns": columns,
                    "data": data,
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )

    def finish(self) -> None:
        """Finish the tracking run.

        Finalises the W&B run (uploading any remaining data) or writes
        a completion marker to the local JSONL file.
        """
        if not self._enabled:
            return

        if self._use_wandb and self._run is not None:
            try:
                self._run.finish()
                logger.info("W&B run finished: %s", self._run_name)
            except Exception as exc:
                logger.warning("W&B finish failed: %s", exc)
        elif self._local_path is not None:
            self._write_local(
                {
                    "type": "finish",
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )
            logger.info("Local tracking finished: %s", self._local_path)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_wandb(self) -> bool:
        """Whether this tracker is using W&B."""
        return self._use_wandb

    @property
    def local_path(self) -> Path | None:
        """Path to the local JSONL fallback file, or ``None`` if using W&B."""
        return self._local_path

    @property
    def run_name(self) -> str:
        """The run name."""
        return self._run_name

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _write_local(self, record: dict[str, Any]) -> None:
        """Append a JSON record to the local JSONL file."""
        if self._local_path is None:
            return
        try:
            with self._local_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, default=str) + "\n")
        except OSError as exc:
            logger.warning("Failed to write local tracking record: %s", exc)
