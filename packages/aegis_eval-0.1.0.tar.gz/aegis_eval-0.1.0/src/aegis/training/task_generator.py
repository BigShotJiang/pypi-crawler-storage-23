"""Training task generator — the core eval-to-train loop.

Generates realistic, detailed training tasks from eval diagnostics,
producing tasks weighted toward weak dimensions so the RL training
loop focuses effort where the agent needs it most.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any

from aegis.core.types import MemoryOperation

# ---------------------------------------------------------------------------
# Enums & data structures
# ---------------------------------------------------------------------------


class TaskDifficulty(IntEnum):
    """Training task difficulty levels."""

    EASY = 1
    MEDIUM = 2
    HARD = 3
    ADVERSARIAL = 4
    MULTI_SESSION = 5


@dataclass
class TrainingTask:
    """A single training task for the RL loop."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str = ""
    context: dict[str, Any] = field(default_factory=dict)
    difficulty: TaskDifficulty = TaskDifficulty.MEDIUM
    domain: str = "general"
    dimension_focus: str = ""
    expected: dict[str, Any] = field(default_factory=dict)
    memory_ops_required: list[MemoryOperation] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DiagnosticProfile:
    """Summarised diagnostic profile for guiding task generation."""

    weak_dimensions: dict[str, float] = field(default_factory=dict)
    strong_dimensions: dict[str, float] = field(default_factory=dict)
    recommended_focus: list[str] = field(default_factory=list)
    domain: str = "general"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _det_float(seed: str, low: float = 0.0, high: float = 1.0) -> float:
    digest = hashlib.sha256(seed.encode()).hexdigest()
    return low + int(digest[:8], 16) / 0xFFFFFFFF * (high - low)


def _det_choice(seed: str, options: list[Any]) -> Any:
    idx = int(hashlib.sha256(seed.encode()).hexdigest()[:8], 16) % len(options)
    return options[idx]


def _det_int(seed: str, low: int, high: int) -> int:
    return int(_det_float(seed, float(low), float(high) + 0.999))


# ---------------------------------------------------------------------------
# Legal task templates
# ---------------------------------------------------------------------------

_LEGAL_PROMPTS: dict[str, dict[int, list[str]]] = {
    "contract_review": {
        1: [
            (
                "Review the following standard NDA between Acme Corp and Beta Inc. "
                "Identify all confidentiality obligations and their duration. "
                "The NDA was signed on 2024-01-15 with a 2-year term.\n\n"
                "Section 1: Definition of Confidential Information includes trade secrets, "
                "business plans, and customer lists.\n"
                "Section 2: Receiving Party shall not disclose for 24 months from signing.\n"
                "Section 3: Exceptions include publicly available information."
            ),
            (
                "Analyze the termination clause in this service agreement. "
                "The agreement between ServiceCo and ClientOrg allows either party to "
                "terminate with 30 days written notice. Identify any potential ambiguities "
                "in the notice requirements."
            ),
        ],
        2: [
            (
                "Compare the indemnification clauses in two vendor agreements. "
                "Agreement A limits liability to the total fees paid in the prior 12 months. "
                "Agreement B includes uncapped liability for IP infringement but caps "
                "general liability at 2x annual fees. Which poses greater risk to the buyer?"
            ),
            (
                "Review the force majeure clause in a supply chain contract executed "
                "pre-pandemic. Does it cover epidemics or pandemics? Analyze whether "
                "the clause would excuse non-performance during COVID-19 disruptions."
            ),
        ],
        3: [
            (
                "A Master Services Agreement from 2022 contains an integration clause "
                "stating it supersedes all prior agreements. However, a side letter from "
                "2023 modifies payment terms. The client claims the side letter is void. "
                "Analyze whether the side letter is enforceable under the parol evidence "
                "rule and the MSA's amendment provisions."
            ),
        ],
        4: [
            (
                "Adversarial contract analysis: Two parties present conflicting "
                "interpretations of an earn-out clause in an M&A agreement. Buyer claims "
                "the EBITDA calculation should exclude one-time restructuring costs per "
                "GAAP. Seller argues the contract specifies 'adjusted EBITDA as "
                "historically calculated' which always included such costs. A side letter "
                "references 'EBITDA consistent with prior practice' without defining it. "
                "Analyze both positions and identify the stronger legal argument with "
                "reference to applicable precedent."
            ),
        ],
        5: [
            (
                "Multi-session contract evolution: Over three sessions, analyze how a "
                "SaaS subscription agreement has been modified. Session 1 established the "
                "base agreement with standard SLA terms. Session 2 introduced an addendum "
                "changing uptime guarantees from 99.9% to 99.5% and adding a price "
                "escalation clause. Session 3 presents a renewal notice that references "
                "the 'original terms' — determine which version controls and whether the "
                "customer can claim the original 99.9% SLA."
            ),
        ],
    },
    "supersession_tracking": {
        1: [
            (
                "Given two documents — Policy v1.0 dated March 2024 and Policy v2.0 "
                "dated June 2024 — determine which sections in v2.0 supersede v1.0. "
                "v2.0 adds a new Section 5 on data privacy but does not mention "
                "removing any v1.0 sections."
            ),
        ],
        2: [
            (
                "Track the amendment history of a lease agreement through three "
                "amendments spanning 2021-2024. Amendment 1 changed the rent amount. "
                "Amendment 2 extended the term by 2 years. Amendment 3 adds a renewal "
                "option but explicitly states 'all other terms remain unchanged.' "
                "Produce a consolidated view of current effective terms."
            ),
        ],
        3: [
            (
                "A regulatory compliance framework has been updated 5 times over 3 years. "
                "Version 3 introduced a 'sunset clause' that automatically expires certain "
                "requirements after 18 months unless renewed. Versions 4 and 5 did not "
                "explicitly renew those requirements. Determine which requirements from "
                "Version 3 are still active and which have expired by operation of the "
                "sunset clause."
            ),
        ],
        4: [
            (
                "Adversarial supersession: A vendor claims their latest Terms of Service "
                "(v4.0) fully supersedes all prior versions, including a negotiated "
                "enterprise agreement that contained custom pricing terms. The enterprise "
                "agreement contains a clause stating it 'shall not be modified except by "
                "written agreement signed by both parties.' Analyze whether the "
                "unilateral ToS update effectively supersedes the negotiated terms."
            ),
        ],
        5: [
            (
                "Multi-session supersession tracking across a corporate restructuring. "
                "Session 1: Original employment agreements for 50 employees. "
                "Session 2: Company merges with another entity; new entity issues "
                "'updated' employment agreements claiming to supersede originals, but "
                "20 employees never signed the new versions. "
                "Session 3: A dispute arises — determine which agreement governs each "
                "employee class and whether the unsigned 'updated' agreements have any "
                "effect under the doctrine of implied consent."
            ),
        ],
    },
    "temporal_reasoning": {
        1: [
            (
                "A contract was signed on January 1, 2024, with a 90-day notice period "
                "for termination. If a party sends notice on March 15, 2024, what is "
                "the earliest termination date?"
            ),
        ],
        2: [
            (
                "An insurance policy has a claims filing deadline of '60 days from the "
                "date of loss or the date the insured reasonably should have known of "
                "the loss, whichever is later.' A loss occurred on April 1 but was not "
                "discovered until May 15. Calculate the filing deadline and analyze "
                "whether a claim filed on July 20 is timely."
            ),
        ],
        3: [
            (
                "Analyze the interaction between three overlapping limitation periods: "
                "(1) a contractual limitation of 2 years from breach, (2) a statutory "
                "limitation of 6 years for contract claims, and (3) a tolling agreement "
                "that suspended limitations for 180 days during settlement negotiations. "
                "The breach occurred on Feb 1, 2022; negotiations ran from Jan 1, 2024 "
                "to June 30, 2024. Determine the effective deadline under each regime."
            ),
        ],
        4: [
            (
                "A choice-of-law dispute: the contract specifies New York law with a "
                "6-year statute of limitations, but the claim was filed in Delaware "
                "which has a 3-year limitation. The borrowing statute may apply. "
                "Analyze all temporal deadlines and determine if the claim is time-barred "
                "under each possible governing law scenario."
            ),
        ],
        5: [
            (
                "Multi-session temporal analysis: Track the evolution of a product "
                "warranty claim across sessions. Session 1: Product purchased March 2023 "
                "with 1-year warranty. Session 2: Defect discovered Feb 2024; warranty "
                "claim filed March 5, 2024. Manufacturer argues discovery was actually "
                "Nov 2023. Session 3: Extended warranty purchased retroactively in Jan "
                "2024, adding 1 year. Determine warranty coverage status considering all "
                "timelines and the retroactive extension."
            ),
        ],
    },
    "citation_verification": {
        1: [
            (
                "Verify the following legal citation: 'Smith v. Jones, 456 U.S. 789 "
                "(1983).' Confirm the case name, volume, reporter, page number, and year."
            ),
        ],
        2: [
            (
                "A brief cites three cases for the proposition that implied warranties "
                "cannot be disclaimed in consumer contracts. Verify each citation and "
                "determine whether the cited holdings actually support this proposition."
            ),
        ],
        3: [
            (
                "Cross-reference a legal memorandum's citations against the current "
                "status of each case. Three of the ten cited cases may have been "
                "overruled or distinguished. Identify any citations that are no longer "
                "good law and suggest replacement authorities."
            ),
        ],
        4: [
            (
                "Adversarial citation challenge: Opposing counsel's brief cites a case "
                "that was vacated on procedural grounds but later reinstated in part on "
                "different grounds. The cited proposition relies on the vacated portion. "
                "Analyze the citation's validity and draft a response explaining why the "
                "authority should be disregarded."
            ),
        ],
        5: [
            (
                "Multi-session citation tracking: Session 1: Build a citation database "
                "from a 50-page appellate brief. Session 2: A new appellate decision is "
                "issued that affects 4 of the cited authorities. Session 3: Update the "
                "citation database and identify which arguments in the brief are now "
                "weakened by the new decision."
            ),
        ],
    },
}


# ---------------------------------------------------------------------------
# Finance task templates
# ---------------------------------------------------------------------------

_FINANCE_PROMPTS: dict[str, dict[int, list[str]]] = {
    "numerical_verification": {
        1: [
            (
                "Verify the following quarterly revenue figures for TechCorp: "
                "Q1 $142.3M, Q2 $156.7M, Q3 $148.9M, Q4 $167.2M. "
                "The annual report states total annual revenue of $615.1M. "
                "Check if the quarterly figures sum correctly."
            ),
        ],
        2: [
            (
                "Cross-check a company's EBITDA calculation. Operating income is "
                "$45.2M, depreciation is $12.3M, amortization is $8.7M. The "
                "company reports EBITDA of $67.5M. Additionally, they claim an "
                "'adjusted EBITDA' of $72.1M after adding back $4.6M in "
                "restructuring charges. Verify both figures."
            ),
        ],
        3: [
            (
                "A PE firm's model shows a projected IRR of 22% on a $500M LBO "
                "with $350M in debt at 6.5% interest. Entry multiple is 10x EBITDA "
                "($50M), exit multiple projected at 12x in Year 5. Verify the IRR "
                "calculation and identify any assumptions that materially affect the "
                "return. Operating EBITDA is projected to grow 8% annually."
            ),
        ],
        4: [
            (
                "Adversarial numerical verification: A company presents two "
                "versions of its financial statements to different regulators. "
                "Version A (SEC filing) shows revenue of $892.4M with cost of goods "
                "sold of $534.1M. Version B (tax filing) shows revenue of $878.9M "
                "with COGS of $541.7M. Identify the discrepancies, calculate the "
                "impact on reported earnings, and analyze potential explanations "
                "(timing differences, accounting method choices, or potential fraud)."
            ),
        ],
        5: [
            (
                "Multi-session numerical reconciliation: Session 1: Analyze Q1-Q2 "
                "earnings reports with standard metrics. Session 2: Company restates "
                "Q1 numbers, changing revenue recognition timing. Session 3: Reconcile "
                "all three versions (original Q1, restated Q1, and Q2) and determine "
                "the impact on year-to-date metrics, forward guidance, and analyst "
                "consensus estimates."
            ),
        ],
    },
    "cross_doc_reconciliation": {
        1: [
            (
                "Compare the balance sheet total assets from a 10-K filing "
                "($2.34B) with the same figure reported in the annual shareholder "
                "letter ($2.31B). Identify the discrepancy and likely cause."
            ),
        ],
        2: [
            (
                "Reconcile three documents for FiscalYear 2024: (1) the 10-K shows "
                "net income of $123.4M, (2) the earnings press release shows net "
                "income of $127.8M, and (3) the proxy statement shows compensation "
                "expense of $15.2M not reflected in the press release figure. "
                "Determine which figure is correct and explain the discrepancies."
            ),
        ],
        3: [
            (
                "A multinational's segment reporting shows: North America $450M, "
                "Europe $320M, Asia-Pacific $280M, for total revenue of $1.05B. "
                "However, the consolidated income statement shows $1.02B after "
                "inter-segment eliminations of $38M. A footnote references additional "
                "eliminations of '$7M related to transfer pricing adjustments.' "
                "Verify that all figures reconcile correctly."
            ),
        ],
        4: [
            (
                "Adversarial cross-document analysis: Management presents optimistic "
                "forward guidance ($2.1B revenue for FY2025) while the risk factors "
                "section discloses pending litigation that could reduce revenue by "
                "$180-240M. The cash flow statement shows accelerated collections "
                "suggesting channel stuffing. Synthesize all three documents to "
                "produce a realistic revenue estimate and flag potential misrepresentation."
            ),
        ],
        5: [
            (
                "Multi-session document reconciliation: Session 1: Analyze initial "
                "S-1 filing for an IPO with projected financials. Session 2: Compare "
                "the amended S-1/A filing, noting material changes to risk factors "
                "and financial projections. Session 3: Post-IPO, reconcile the first "
                "10-Q against the original S-1 projections and determine if "
                "management met, exceeded, or fell short of promises made to investors."
            ),
        ],
    },
    "regulatory_compliance": {
        1: [
            (
                "Check whether a bank's Tier 1 capital ratio of 8.2% meets the "
                "Basel III minimum requirement. The bank is classified as a "
                "non-systemically important institution."
            ),
        ],
        2: [
            (
                "A broker-dealer reports net capital of $12.5M against a minimum "
                "requirement of $10M under SEC Rule 15c3-1. However, they have $3.2M "
                "in non-allowable assets. Recalculate net capital after exclusions "
                "and determine compliance status."
            ),
        ],
        3: [
            (
                "Analyze a bank's compliance with the Volcker Rule. The bank holds "
                "a $50M position in a CDO that was grandfathered under the original "
                "2014 compliance deadline. A 2024 amendment narrows the grandfather "
                "clause. Determine whether the position is still compliant and "
                "calculate the required divestiture timeline if not."
            ),
        ],
        4: [
            (
                "Adversarial compliance scenario: A fintech company argues it is "
                "exempt from banking regulations because it partners with a chartered "
                "bank rather than holding deposits directly. However, its product "
                "offers 'savings pods' that function identically to demand deposits. "
                "Recent OCC guidance suggests these arrangements may require separate "
                "licensing. Analyze the regulatory exposure and recommend actions."
            ),
        ],
        5: [
            (
                "Multi-session regulatory tracking: Session 1: Establish baseline "
                "compliance profile for a regional bank across FDIC, OCC, and Fed "
                "requirements. Session 2: New FDIC rule changes deposit insurance "
                "calculations affecting the bank's category. Session 3: Fed announces "
                "stress test methodology changes. Determine cumulative impact on the "
                "bank's capital adequacy and required remediation timeline."
            ),
        ],
    },
    "materiality_judgment": {
        1: [
            (
                "A company with $500M annual revenue discovers a $2.5M accounting "
                "error. Determine whether this is material using both quantitative "
                "(percentage of revenue, net income, total assets) and qualitative "
                "factors."
            ),
        ],
        2: [
            (
                "A $50B market-cap pharmaceutical company fails to disclose a Phase "
                "III trial failure for a drug expected to generate $800M in peak "
                "sales. The company argues the trial represented only one of five "
                "pipeline candidates. Analyze materiality considering market "
                "expectations and prior guidance."
            ),
        ],
        3: [
            (
                "Complex materiality assessment: A conglomerate's subsidiary "
                "discovers environmental contamination requiring $120M in remediation "
                "costs. At the parent level, this is 0.3% of assets. At the "
                "subsidiary level, it is 15% of assets. The subsidiary issues its "
                "own public debt. Analyze materiality at both the subsidiary and "
                "consolidated levels, considering SEC Staff Accounting Bulletin 99's "
                "qualitative factors."
            ),
        ],
        4: [
            (
                "Adversarial materiality: Management classifies a $45M legal "
                "settlement as 'not material' for disclosure purposes. An analyst "
                "argues that while quantitatively borderline (2.1% of net income), "
                "the settlement reveals a pattern of compliance failures that could "
                "indicate systemic risk. Apply both SAB 99 and recent case law to "
                "determine whether omitting disclosure violates securities regulations."
            ),
        ],
        5: [
            (
                "Multi-session materiality evolution: Session 1: Assess initial "
                "disclosure of a cybersecurity incident affecting 100K records. "
                "Session 2: Breach scope expands to 2.5M records with evidence of "
                "exfiltrated financial data. Session 3: Class action filed; "
                "estimated liability $50-200M. Re-evaluate materiality at each stage "
                "and determine if earlier disclosures were adequate."
            ),
        ],
    },
}


# ---------------------------------------------------------------------------
# Memory task templates
# ---------------------------------------------------------------------------

_MEMORY_PROMPTS: dict[str, dict[int, list[str]]] = {
    "store_retrieve": {
        1: [
            (
                "Store the following fact: 'The company's fiscal year ends on March "
                "31.' Then immediately retrieve it when asked 'When does the fiscal "
                "year end?'"
            ),
        ],
        2: [
            (
                "Store three related facts about a client: (1) headquarters in "
                "Boston, (2) founded in 2015, (3) primary product is AI-based fraud "
                "detection. Then answer a composite question: 'Describe the client's "
                "background.'"
            ),
        ],
        3: [
            (
                "Store information from two conflicting sources about a merger date. "
                "Source A says 'merger closes Q1 2025,' Source B says 'merger expected "
                "Q2 2025 pending regulatory approval.' When retrieved, the system "
                "should present both with provenance and confidence scores."
            ),
        ],
        4: [
            (
                "Adversarial retrieval: Store 50 facts about various companies over "
                "10 interactions. Then present a query that requires retrieving a "
                "specific fact stored 8 interactions ago, which has been partially "
                "superseded by a later update. The system must return the current "
                "version while noting the update history."
            ),
        ],
        5: [
            (
                "Multi-session store/retrieve: Session 1: Build a knowledge base "
                "about a legal case with 20 key facts. Session 2 (24 hours later): "
                "Query specific facts and verify no degradation. Session 3 (1 week "
                "later): Introduce 5 contradicting facts and verify the system "
                "correctly handles conflicts and provenance tracking."
            ),
        ],
    },
    "update_forget": {
        1: [
            (
                "Store 'CEO is John Smith' and then update it to 'CEO is Jane Doe "
                "effective April 2024.' Verify the update preserves the historical "
                "record while returning the current value."
            ),
        ],
        2: [
            (
                "A client requests data deletion under GDPR Article 17 (right to "
                "erasure). The memory contains 5 entries linked to the client: 2 are "
                "purely personal data (must delete), 2 are aggregated analytics (can "
                "keep), and 1 is a legal hold document (cannot delete). Execute the "
                "appropriate FORGET operations with compliance reasoning."
            ),
        ],
        3: [
            (
                "Cascade update: A parent company changes its name from 'OldCorp' to "
                "'NewCorp.' The memory contains 30 entries referencing 'OldCorp' "
                "across different tiers (working, session, permanent). Execute an "
                "update that propagates the name change consistently while preserving "
                "historical context where appropriate."
            ),
        ],
        4: [
            (
                "Adversarial forget scenario: An external party attempts to trigger "
                "selective forgetting of unfavorable audit findings by submitting a "
                "'correction' request. The system must distinguish between legitimate "
                "updates and adversarial attempts to manipulate the knowledge base. "
                "Verify the audit trail remains intact."
            ),
        ],
        5: [
            (
                "Multi-session update/forget lifecycle: Session 1: Store initial "
                "employee records for a department. Session 2: Department "
                "restructuring — 3 employees transfer, 2 depart (forget PII, retain "
                "project records), 5 new hires. Session 3: Compliance audit — verify "
                "all FORGET operations left proper audit trails and no residual PII "
                "exists for departed employees."
            ),
        ],
    },
    "link_compress": {
        1: [
            (
                "Store two facts: 'Product X was launched in 2023' and 'Product X "
                "reached 1M users in 2024.' Link them as a temporal progression "
                "for the same entity."
            ),
        ],
        2: [
            (
                "Given 10 related memory entries about a single project, compress "
                "them into a summary entry that preserves key decisions, dates, and "
                "stakeholders while reducing token count by at least 60%."
            ),
        ],
        3: [
            (
                "Build a knowledge graph from 15 entries about a corporate "
                "acquisition: link buyer, seller, advisors, regulatory bodies, and "
                "key dates. Then use the graph to answer: 'What is the relationship "
                "between the buyer's legal counsel and the antitrust regulator who "
                "approved the deal?'"
            ),
        ],
        4: [
            (
                "Adversarial linking: Two memory entries contain contradictory "
                "information that appears to be about the same entity but is actually "
                "about two entities with similar names (e.g., 'Delta Airlines' vs "
                "'Delta Financial'). The system must NOT incorrectly link them and "
                "should flag the potential confusion."
            ),
        ],
        5: [
            (
                "Multi-session link/compress: Session 1: Build detailed memory "
                "entries for a 6-month consulting engagement. Session 2: Compress "
                "the engagement into a project summary while preserving actionable "
                "links to key deliverables. Session 3: A follow-up engagement "
                "starts — link the new engagement to the compressed summary and "
                "verify all relevant context is accessible."
            ),
        ],
    },
    "promote_demote": {
        1: [
            (
                "A fact currently in working memory has been accessed 5 times in the "
                "last hour: 'current meeting agenda items.' Decide whether it should "
                "be promoted to session memory."
            ),
        ],
        2: [
            (
                "A session memory entry 'client prefers email over phone' has not "
                "been accessed in 30 days. Evaluate whether to demote it to permanent "
                "storage with reduced priority or forget it entirely."
            ),
        ],
        3: [
            (
                "Manage tier transitions for 20 memory entries based on access "
                "patterns: 5 are hot (accessed daily), 8 are warm (weekly), 4 are "
                "cold (monthly), and 3 have not been accessed in 90 days. Execute "
                "appropriate promote/demote operations with justification."
            ),
        ],
        4: [
            (
                "Adversarial promotion: A pattern of queries is designed to "
                "artificially inflate the access count of a low-value memory entry, "
                "attempting to get it promoted to permanent storage where it would "
                "be harder to remove. Detect the access pattern anomaly and prevent "
                "the unwarranted promotion."
            ),
        ],
        5: [
            (
                "Multi-session tier management: Session 1: Initialize memory tiers "
                "for a new agent deployment with baseline entries. Session 2 (1 week "
                "later): Review access patterns and execute first round of "
                "promotions/demotions. Session 3 (1 month later): Perform full tier "
                "audit, identify entries requiring human review for permanent "
                "promotion, and generate a tier health report."
            ),
        ],
    },
}


# ---------------------------------------------------------------------------
# Dimension -> task category mapping
# ---------------------------------------------------------------------------

_DIMENSION_TO_LEGAL_CATEGORY: dict[str, str] = {
    "tier1_memory_fidelity": "contract_review",
    "tier2_context_intelligence": "supersession_tracking",
    "tier3_learning_dynamics": "temporal_reasoning",
    "tier4_reasoning_quality": "citation_verification",
    "1.1_verbatim_recall": "contract_review",
    "1.2_temporal_ordering": "temporal_reasoning",
    "2.1_context_selection": "supersession_tracking",
    "2.2_contradiction_detection": "supersession_tracking",
    "3.1_few_shot_adaptation": "contract_review",
    "4.1_logical_consistency": "citation_verification",
    "4.2_evidence_grounding": "citation_verification",
}

_DIMENSION_TO_FINANCE_CATEGORY: dict[str, str] = {
    "tier1_memory_fidelity": "numerical_verification",
    "tier2_context_intelligence": "cross_doc_reconciliation",
    "tier3_learning_dynamics": "regulatory_compliance",
    "tier4_reasoning_quality": "materiality_judgment",
    "1.1_verbatim_recall": "numerical_verification",
    "1.2_temporal_ordering": "numerical_verification",
    "2.1_context_selection": "cross_doc_reconciliation",
    "2.2_contradiction_detection": "cross_doc_reconciliation",
    "3.1_few_shot_adaptation": "regulatory_compliance",
    "4.1_logical_consistency": "materiality_judgment",
    "4.2_evidence_grounding": "materiality_judgment",
}

_DIMENSION_TO_MEMORY_CATEGORY: dict[str, str] = {
    "tier1_memory_fidelity": "store_retrieve",
    "tier2_context_intelligence": "link_compress",
    "tier3_learning_dynamics": "update_forget",
    "tier4_reasoning_quality": "promote_demote",
    "1.1_verbatim_recall": "store_retrieve",
    "1.2_temporal_ordering": "store_retrieve",
    "2.1_context_selection": "link_compress",
    "2.2_contradiction_detection": "update_forget",
    "3.1_few_shot_adaptation": "update_forget",
    "4.1_logical_consistency": "promote_demote",
    "5.1_self_assessment": "promote_demote",
}

# Memory ops required per category
_CATEGORY_MEMORY_OPS: dict[str, list[MemoryOperation]] = {
    "contract_review": [MemoryOperation.STORE, MemoryOperation.RETRIEVE],
    "supersession_tracking": [
        MemoryOperation.STORE,
        MemoryOperation.RETRIEVE,
        MemoryOperation.UPDATE,
    ],
    "temporal_reasoning": [MemoryOperation.STORE, MemoryOperation.RETRIEVE, MemoryOperation.VERIFY],
    "citation_verification": [MemoryOperation.RETRIEVE, MemoryOperation.VERIFY],
    "numerical_verification": [MemoryOperation.STORE, MemoryOperation.RETRIEVE],
    "cross_doc_reconciliation": [
        MemoryOperation.STORE,
        MemoryOperation.RETRIEVE,
        MemoryOperation.LINK,
    ],
    "regulatory_compliance": [
        MemoryOperation.RETRIEVE,
        MemoryOperation.VERIFY,
        MemoryOperation.ANNOTATE,
    ],
    "materiality_judgment": [MemoryOperation.RETRIEVE, MemoryOperation.VERIFY],
    "store_retrieve": [MemoryOperation.STORE, MemoryOperation.RETRIEVE],
    "update_forget": [MemoryOperation.UPDATE, MemoryOperation.FORGET],
    "link_compress": [MemoryOperation.LINK, MemoryOperation.COMPRESS],
    "promote_demote": [MemoryOperation.PROMOTE, MemoryOperation.DEMOTE],
}


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------


class TaskGenerator:
    """Generates training tasks from eval diagnostics.

    The generator produces realistic, domain-specific tasks weighted
    by the diagnostic profile's weak dimensions, implementing the core
    eval-to-train feedback loop.
    """

    def __init__(self, domain: str = "general", seed: int = 42) -> None:
        self._domain = domain
        self._seed = seed
        self._profile: DiagnosticProfile | None = None
        self._generated_count = 0

    @classmethod
    def from_diagnostic(cls, diagnostic: dict[str, Any]) -> TaskGenerator:
        """Factory: create a generator from an eval diagnostic dict.

        The diagnostic dict should match the output of
        :func:`aegis.eval.reporting.diagnostic.generate_diagnostic`.

        Args:
            diagnostic: A diagnostic report dictionary.

        Returns:
            A configured :class:`TaskGenerator`.
        """
        domain = diagnostic.get("metadata", {}).get("domain", "general")
        gen = cls(domain=domain)

        # Build dimension score maps from the diagnostic
        weak_dims: dict[str, float] = {}
        strong_dims: dict[str, float] = {}

        # The diagnostic has weak_dimensions as a list of dim IDs
        # and training_focus as an ordered list.  We need to infer
        # scores from tier_scores or metadata.
        training_focus = diagnostic.get("training_focus", [])
        weak_list = diagnostic.get("weak_dimensions", [])
        strong_list = diagnostic.get("strong_dimensions", [])

        # Build approximate scores — use 0.3 for weak, 0.85 for strong
        for dim_id in weak_list:
            weak_dims[dim_id] = 0.35
        for dim_id in strong_list:
            strong_dims[dim_id] = 0.85

        # If metadata has dimension_scores, use the real values
        dim_scores = diagnostic.get("metadata", {}).get("dimension_scores", {})
        for dim_id, score in dim_scores.items():
            if score < 0.5:
                weak_dims[dim_id] = score
            elif score >= 0.8:
                strong_dims[dim_id] = score

        gen._profile = DiagnosticProfile(
            weak_dimensions=weak_dims,
            strong_dimensions=strong_dims,
            recommended_focus=training_focus[:10],
            domain=domain,
        )
        return gen

    def generate(
        self,
        count: int,
        difficulty_distribution: dict[TaskDifficulty, float] | None = None,
    ) -> list[TrainingTask]:
        """Generate training tasks weighted by diagnostic weaknesses.

        Args:
            count: Number of tasks to generate.
            difficulty_distribution: Optional mapping of difficulty to weight
                (e.g. ``{EASY: 0.3, MEDIUM: 0.5, HARD: 0.2}``). If None,
                uses a balanced distribution.

        Returns:
            A list of :class:`TrainingTask` objects.
        """
        dist = difficulty_distribution or {
            TaskDifficulty.EASY: 0.2,
            TaskDifficulty.MEDIUM: 0.35,
            TaskDifficulty.HARD: 0.25,
            TaskDifficulty.ADVERSARIAL: 0.15,
            TaskDifficulty.MULTI_SESSION: 0.05,
        }

        # Build dimension weights — weak dimensions get more tasks
        if self._profile and self._profile.weak_dimensions:
            dims_and_weights = [
                (dim_id, max(0.1, 1.0 - score))
                for dim_id, score in self._profile.weak_dimensions.items()
            ]
        elif self._profile and self._profile.recommended_focus:
            dims_and_weights = [
                (dim_id, 1.0 / (i + 1)) for i, dim_id in enumerate(self._profile.recommended_focus)
            ]
        else:
            # No diagnostic available — use a generic set
            dims_and_weights = [
                ("tier1_memory_fidelity", 0.25),
                ("tier2_context_intelligence", 0.25),
                ("tier3_learning_dynamics", 0.25),
                ("tier4_reasoning_quality", 0.25),
            ]

        total_weight = sum(w for _, w in dims_and_weights)
        normalised = [(d, w / total_weight) for d, w in dims_and_weights]

        tasks: list[TrainingTask] = []
        for i in range(count):
            seed = f"{self._seed}:gen:{i}:{self._generated_count}"
            self._generated_count += 1

            # Pick dimension proportional to weight
            roll = _det_float(f"dim:{seed}")
            cumulative = 0.0
            chosen_dim = normalised[0][0]
            for dim_id, weight in normalised:
                cumulative += weight
                if roll <= cumulative:
                    chosen_dim = dim_id
                    break

            # Pick difficulty according to distribution
            diff_roll = _det_float(f"diff:{seed}")
            cumulative = 0.0
            chosen_diff = TaskDifficulty.MEDIUM
            for diff, prob in sorted(dist.items(), key=lambda x: x[0].value):
                cumulative += prob
                if diff_roll <= cumulative:
                    chosen_diff = diff
                    break

            batch = self.generate_for_dimension(chosen_dim, 1, chosen_diff)
            tasks.extend(batch)

        return tasks

    def generate_for_dimension(
        self,
        dimension_id: str,
        count: int,
        difficulty: TaskDifficulty = TaskDifficulty.MEDIUM,
    ) -> list[TrainingTask]:
        """Generate tasks targeting a specific eval dimension.

        Args:
            dimension_id: The dimension to target.
            count: Number of tasks.
            difficulty: Task difficulty level.

        Returns:
            A list of :class:`TrainingTask` objects.
        """
        tasks: list[TrainingTask] = []
        for i in range(count):
            seed = f"{self._seed}:dim:{dimension_id}:{difficulty.value}:{i}:{self._generated_count}"
            self._generated_count += 1

            if self._domain == "legal":
                task = self._build_legal_tasks(dimension_id, difficulty, 1, seed)[0]
            elif self._domain == "finance":
                task = self._build_finance_tasks(dimension_id, difficulty, 1, seed)[0]
            else:
                # General domain: mix of memory tasks and domain tasks
                if _det_float(f"domain_mix:{seed}") < 0.6:
                    task = self._build_memory_tasks(dimension_id, difficulty, 1, seed)[0]
                else:
                    # Randomly pick legal or finance for variety
                    if _det_float(f"pick_domain:{seed}") < 0.5:
                        task = self._build_legal_tasks(dimension_id, difficulty, 1, seed)[0]
                    else:
                        task = self._build_finance_tasks(dimension_id, difficulty, 1, seed)[0]

            task.dimension_focus = dimension_id
            tasks.append(task)

        return tasks

    def generate_curriculum_batch(self, level: int, count: int) -> list[TrainingTask]:
        """Generate tasks for a specific curriculum level.

        Lower levels produce easier tasks; higher levels produce harder
        and more varied tasks.

        Args:
            level: Curriculum level (1-5).
            count: Number of tasks.

        Returns:
            A list of :class:`TrainingTask` objects.
        """
        # Map curriculum level to difficulty distribution
        level_distributions: dict[int, dict[TaskDifficulty, float]] = {
            1: {TaskDifficulty.EASY: 0.7, TaskDifficulty.MEDIUM: 0.3},
            2: {TaskDifficulty.EASY: 0.3, TaskDifficulty.MEDIUM: 0.5, TaskDifficulty.HARD: 0.2},
            3: {
                TaskDifficulty.MEDIUM: 0.4,
                TaskDifficulty.HARD: 0.4,
                TaskDifficulty.ADVERSARIAL: 0.2,
            },
            4: {
                TaskDifficulty.HARD: 0.3,
                TaskDifficulty.ADVERSARIAL: 0.4,
                TaskDifficulty.MULTI_SESSION: 0.3,
            },
            5: {
                TaskDifficulty.HARD: 0.2,
                TaskDifficulty.ADVERSARIAL: 0.4,
                TaskDifficulty.MULTI_SESSION: 0.4,
            },
        }

        dist = level_distributions.get(level, level_distributions[3])
        return self.generate(count, difficulty_distribution=dist)

    def generate_for_operation(
        self,
        operation: str,
        count: int = 2,
        difficulty: TaskDifficulty = TaskDifficulty.MEDIUM,
    ) -> list[TrainingTask]:
        """Generate tasks targeting a specific memory operation.

        Used by the two-speed bridge to inject targeted tasks for weak
        memory operations.

        Args:
            operation: Memory operation name (e.g. ``"STORE"``, ``"RETRIEVE"``).
            count: Number of tasks to generate.
            difficulty: Task difficulty level.

        Returns:
            A list of :class:`TrainingTask` objects exercising the operation.
        """
        # Map operation to the most relevant memory task category
        op_to_category: dict[str, str] = {
            "STORE": "store_retrieve",
            "RETRIEVE": "store_retrieve",
            "UPDATE": "update_forget",
            "FORGET": "update_forget",
            "LINK": "link_compress",
            "COMPRESS": "link_compress",
            "PROMOTE": "promote_demote",
            "DEMOTE": "promote_demote",
            "SPLIT": "update_forget",
            "MERGE": "link_compress",
            "VERIFY": "store_retrieve",
            "ANNOTATE": "store_retrieve",
        }

        category = op_to_category.get(operation.upper(), "store_retrieve")
        dimension = {v: k for k, v in _DIMENSION_TO_MEMORY_CATEGORY.items()}.get(
            category, "tier1_memory_fidelity"
        )

        tasks: list[TrainingTask] = []
        for i in range(count):
            seed = (
                f"{self._seed}:op_target:{operation}:{difficulty.value}:{i}:{self._generated_count}"
            )
            self._generated_count += 1
            batch = self._build_memory_tasks(dimension, difficulty, 1, seed)
            for task in batch:
                task.tags.append(f"target_op:{operation.upper()}")
                task.metadata["target_operation"] = operation.upper()
            tasks.extend(batch)

        return tasks

    # ------------------------------------------------------------------
    # Private builders
    # ------------------------------------------------------------------

    def _build_legal_tasks(
        self,
        dimension: str,
        difficulty: TaskDifficulty,
        count: int,
        seed: str = "",
    ) -> list[TrainingTask]:
        """Build legal domain tasks."""
        category = _DIMENSION_TO_LEGAL_CATEGORY.get(dimension, "contract_review")
        templates = _LEGAL_PROMPTS.get(category, _LEGAL_PROMPTS["contract_review"])
        diff_val = min(difficulty.value, max(templates.keys()))
        available = templates.get(diff_val, templates[min(templates.keys())])

        tasks: list[TrainingTask] = []
        for i in range(count):
            s = seed or f"{self._seed}:legal:{dimension}:{i}"
            prompt = _det_choice(f"legal_tpl:{s}", available)
            mem_ops = _CATEGORY_MEMORY_OPS.get(
                category, [MemoryOperation.STORE, MemoryOperation.RETRIEVE]
            )

            tasks.append(
                TrainingTask(
                    prompt=prompt,
                    context={"domain": "legal", "category": category},
                    difficulty=difficulty,
                    domain="legal",
                    dimension_focus=dimension,
                    expected={
                        "requires_analysis": True,
                        "domain": "legal",
                        "category": category,
                        "min_evidence_sources": 1 + difficulty.value,
                    },
                    memory_ops_required=list(mem_ops),
                    tags=["legal", category, f"difficulty_{difficulty.value}"],
                    metadata={"seed": s, "template_category": category},
                )
            )

        return tasks

    def _build_finance_tasks(
        self,
        dimension: str,
        difficulty: TaskDifficulty,
        count: int,
        seed: str = "",
    ) -> list[TrainingTask]:
        """Build finance domain tasks."""
        category = _DIMENSION_TO_FINANCE_CATEGORY.get(dimension, "numerical_verification")
        templates = _FINANCE_PROMPTS.get(category, _FINANCE_PROMPTS["numerical_verification"])
        diff_val = min(difficulty.value, max(templates.keys()))
        available = templates.get(diff_val, templates[min(templates.keys())])

        tasks: list[TrainingTask] = []
        for i in range(count):
            s = seed or f"{self._seed}:finance:{dimension}:{i}"
            prompt = _det_choice(f"finance_tpl:{s}", available)
            mem_ops = _CATEGORY_MEMORY_OPS.get(
                category, [MemoryOperation.STORE, MemoryOperation.RETRIEVE]
            )

            tasks.append(
                TrainingTask(
                    prompt=prompt,
                    context={"domain": "finance", "category": category},
                    difficulty=difficulty,
                    domain="finance",
                    dimension_focus=dimension,
                    expected={
                        "requires_numerical_accuracy": True,
                        "domain": "finance",
                        "category": category,
                        "min_evidence_sources": difficulty.value,
                    },
                    memory_ops_required=list(mem_ops),
                    tags=["finance", category, f"difficulty_{difficulty.value}"],
                    metadata={"seed": s, "template_category": category},
                )
            )

        return tasks

    def _build_memory_tasks(
        self,
        dimension: str,
        difficulty: TaskDifficulty,
        count: int,
        seed: str = "",
    ) -> list[TrainingTask]:
        """Build memory operation tasks."""
        category = _DIMENSION_TO_MEMORY_CATEGORY.get(dimension, "store_retrieve")
        templates = _MEMORY_PROMPTS.get(category, _MEMORY_PROMPTS["store_retrieve"])
        diff_val = min(difficulty.value, max(templates.keys()))
        available = templates.get(diff_val, templates[min(templates.keys())])

        tasks: list[TrainingTask] = []
        for i in range(count):
            s = seed or f"{self._seed}:memory:{dimension}:{i}"
            prompt = _det_choice(f"memory_tpl:{s}", available)
            mem_ops = _CATEGORY_MEMORY_OPS.get(
                category, [MemoryOperation.STORE, MemoryOperation.RETRIEVE]
            )

            tasks.append(
                TrainingTask(
                    prompt=prompt,
                    context={"domain": "memory", "category": category},
                    difficulty=difficulty,
                    domain="memory",
                    dimension_focus=dimension,
                    expected={
                        "requires_memory_ops": True,
                        "category": category,
                        "ops_required": [op.value for op in mem_ops],
                    },
                    memory_ops_required=list(mem_ops),
                    tags=["memory", category, f"difficulty_{difficulty.value}"],
                    metadata={"seed": s, "template_category": category},
                )
            )

        return tasks
