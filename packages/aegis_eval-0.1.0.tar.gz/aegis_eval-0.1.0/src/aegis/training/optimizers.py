"""RL optimizer algorithms for policy training.

Implements optimizer variants used in the Aegis training loop plus PODS
rollout selection:

* **DrGRPO** — Length-bias elimination GRPO.  Normalises rewards by
  response length to prevent verbose-but-empty answers.
* **DAPO** — Dynamic entropy-aware optimisation.  Maintains policy entropy
  during long training runs via an adaptive entropy bonus.
* **GiGPO** — Group-relative policy optimisation with importance sampling
  corrections.
* **Forge** — Variance-reduced optimisation with a running baseline.
* **PODS** — Prioritized rollout down-selection before optimizer updates.

All algorithms work with pure numeric computation (no PyTorch dependency)
so they can run in the eval/scoring loop or be used as reference
implementations for the verl-based training backend.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Shared config & update structure
# ---------------------------------------------------------------------------


@dataclass
class OptimizerConfig:
    """Configuration shared across optimizer variants."""

    learning_rate: float = 1e-5
    kl_coeff: float = 0.05
    entropy_coeff: float = 0.01
    clip_range: float = 0.2
    max_grad_norm: float = 1.0
    warmup_steps: int = 100


@dataclass
class GRPOUpdate:
    """Result of a single optimizer update step."""

    advantages: list[float] = field(default_factory=list)
    old_log_probs: list[float] = field(default_factory=list)
    new_log_probs: list[float] = field(default_factory=list)
    kl_divergence: float = 0.0
    policy_loss: float = 0.0
    entropy: float = 0.0


@dataclass
class PODSConfig:
    """Configuration for PODS rollout selection."""

    keep_ratio: float = 0.6
    novelty_weight: float = 0.35
    reward_weight: float = 0.6
    length_penalty: float = 0.002


class PODSSelector:
    """Prioritized rollout selector for deterministic PODS filtering."""

    def __init__(self, config: PODSConfig | None = None) -> None:
        self._config = config or PODSConfig()

    @property
    def config(self) -> PODSConfig:
        return self._config

    def signal_score(self, rollout: dict[str, Any]) -> float:
        """Compute deterministic PODS signal score for a rollout."""
        reward = self._as_float(rollout.get("reward"), default=0.0)
        novelty = self._as_float(rollout.get("novelty"), default=0.5)
        length = self._as_float(rollout.get("length"), default=1.0)
        length = max(length, 1.0)
        normalised_length = min(length / 256.0, 1.0)
        return (
            self._config.reward_weight * reward
            + self._config.novelty_weight * novelty
            - self._config.length_penalty * normalised_length
        )

    def select(self, rollouts: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Select the top-K rollouts by PODS signal with stable tie-breaks."""
        if not rollouts:
            return []

        keep_ratio = max(0.0, min(1.0, self._config.keep_ratio))
        keep_count = max(1, min(len(rollouts), math.ceil(len(rollouts) * keep_ratio)))

        scored: list[tuple[float, str, int, dict[str, Any]]] = []
        for index, rollout in enumerate(rollouts):
            score = self.signal_score(rollout)
            rollout_id = str(rollout.get("rollout_id", f"rollout-{index:04d}"))
            enriched = dict(rollout)
            enriched["pods_signal"] = round(score, 6)
            enriched["pods_rank_key"] = rollout_id
            scored.append((score, rollout_id, index, enriched))

        ranked = sorted(
            scored,
            key=lambda item: (-item[0], item[1], item[2]),
        )
        selected_ranked = ranked[:keep_count]
        # Return selected rollouts in their original order for stable downstream usage.
        selected = sorted(selected_ranked, key=lambda item: item[2])
        return [item[3] for item in selected]

    @staticmethod
    def _as_float(value: Any, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_log(x: float) -> float:
    """Numerically stable log (clamped to avoid log(0))."""
    return math.log(max(x, 1e-10))


def _softmax(logits: list[float]) -> list[float]:
    """Compute softmax probabilities from logits."""
    m = max(logits) if logits else 0.0
    exps = [math.exp(v - m) for v in logits]
    total = sum(exps) or 1e-10
    return [e / total for e in exps]


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _compute_entropy(log_probs: list[float]) -> float:
    """Compute Shannon entropy from log probabilities: -sum(p * log(p))."""
    probs = [math.exp(lp) for lp in log_probs]
    total = sum(probs) or 1e-10
    probs = [p / total for p in probs]
    return -sum(p * _safe_log(p) for p in probs if p > 0)


def _compute_kl(old_log_probs: list[float], new_log_probs: list[float]) -> float:
    """KL(old || new) = sum(old_prob * (old_logp - new_logp))."""
    if len(old_log_probs) != len(new_log_probs):
        return 0.0
    kl = 0.0
    for old_lp, new_lp in zip(old_log_probs, new_log_probs, strict=False):
        old_p = math.exp(old_lp)
        kl += old_p * (old_lp - new_lp)
    return max(kl, 0.0)


def _ppo_clip_loss(
    advantages: list[float],
    old_log_probs: list[float],
    new_log_probs: list[float],
    clip_range: float,
) -> float:
    """Clipped surrogate objective (PPO-style).

    L_clip = -min(ratio * A, clip(ratio, 1-eps, 1+eps) * A)
    averaged over the batch.
    """
    if not advantages:
        return 0.0

    total_loss = 0.0
    for adv, old_lp, new_lp in zip(advantages, old_log_probs, new_log_probs, strict=False):
        ratio = math.exp(new_lp - old_lp)
        clipped_ratio = _clip(ratio, 1.0 - clip_range, 1.0 + clip_range)
        surr1 = ratio * adv
        surr2 = clipped_ratio * adv
        total_loss += -min(surr1, surr2)

    return total_loss / len(advantages)


def _group_keys(group_ids: list[str] | None, size: int) -> list[str]:
    """Return group keys for per-group normalisation."""
    if group_ids is None or len(group_ids) != size:
        return ["global"] * size
    return [str(gid) for gid in group_ids]


def _normalise_by_group(values: list[float], group_ids: list[str]) -> list[float]:
    """Normalise values independently for each group (mean 0, std 1)."""
    if not values:
        return []

    grouped_values: dict[str, list[float]] = {}
    for gid, value in zip(group_ids, values, strict=False):
        grouped_values.setdefault(gid, []).append(value)

    grouped_stats: dict[str, tuple[float, float]] = {}
    for gid, group_vals in grouped_values.items():
        mean = sum(group_vals) / len(group_vals)
        variance = sum((v - mean) ** 2 for v in group_vals) / len(group_vals)
        std = variance**0.5 if variance > 0 else 1.0
        grouped_stats[gid] = (mean, std)

    normalised: list[float] = []
    for gid, value in zip(group_ids, values, strict=False):
        mean, std = grouped_stats[gid]
        normalised.append((value - mean) / std)
    return normalised


def _variance(values: list[float]) -> float:
    if not values:
        return 0.0
    mean = sum(values) / len(values)
    return sum((v - mean) ** 2 for v in values) / len(values)


def _as_float_list(values: list[Any], default: float = 0.0) -> list[float]:
    parsed: list[float] = []
    for value in values:
        try:
            parsed.append(float(value))
        except (TypeError, ValueError):
            parsed.append(default)
    return parsed


# ---------------------------------------------------------------------------
# DrGRPO — Length-bias elimination
# ---------------------------------------------------------------------------


class DrGRPOOptimizer:
    """Length-bias elimination GRPO optimizer.

    Normalises rewards by response length to prevent the model from
    producing verbose-but-empty answers to game the reward signal.
    The normalisation uses ``reward_i / max(length_i, min_length)``
    where ``min_length`` prevents division by near-zero.
    """

    def __init__(self, config: OptimizerConfig | None = None) -> None:
        self._config = config or OptimizerConfig()
        self._step = 0
        self._baseline_ema_alpha = 0.1
        self._global_baseline = 0.0
        self._group_baselines: dict[str, float] = {}

    def apply_length_normalization(self, rewards: list[float], lengths: list[int]) -> list[float]:
        """Normalise rewards by response length.

        Args:
            rewards: Raw reward values per rollout.
            lengths: Response length (in tokens or steps) per rollout.

        Returns:
            Length-normalised reward values.
        """
        if not rewards:
            return []

        min_length = 10  # floor to avoid extreme normalisation
        # Compute mean length for relative normalisation
        mean_len = sum(lengths) / len(lengths) if lengths else 1.0

        normalised: list[float] = []
        for r, length in zip(rewards, lengths, strict=False):
            effective_len = max(length, min_length)
            # Normalise by ratio to mean length so that average-length
            # responses keep roughly the same reward magnitude.
            length_ratio = effective_len / max(mean_len, 1.0)
            normalised.append(r / length_ratio)

        return normalised

    def optimize(
        self,
        advantages: list[float],
        old_log_probs: list[float],
        new_log_probs: list[float],
        *,
        group_ids: list[str] | None = None,
        rewards: list[float] | None = None,
    ) -> tuple[float, dict[str, Any]]:
        """Optimise policy loss using dynamic reward baselines.

        DrGRPO maintains an EMA baseline per group and applies per-group
        normalisation to keep advantage magnitudes stable across uneven
        reward scales.
        """
        if not advantages:
            return 0.0, {
                "algorithm": "drgrpo",
                "group_count": 0.0,
                "baseline_mean": round(self._global_baseline, 6),
                "normalized_advantages": [],
                "kl_divergence": 0.0,
                "entropy": 0.0,
            }

        size = min(len(advantages), len(old_log_probs), len(new_log_probs))
        rewards_safe = rewards if rewards is not None and len(rewards) >= size else None
        group_keys = _group_keys(group_ids, size)

        raw_advantages = advantages[:size]
        if rewards_safe is not None:
            raw_advantages = _as_float_list(rewards_safe[:size], default=0.0)

        baseline_adjusted: list[float] = []
        baselines_used: list[float] = []
        for gid, advantage in zip(group_keys, raw_advantages, strict=False):
            current_baseline = self._group_baselines.get(gid, self._global_baseline)
            updated_baseline = (
                self._baseline_ema_alpha * advantage
                + (1.0 - self._baseline_ema_alpha) * current_baseline
            )
            self._group_baselines[gid] = updated_baseline
            baselines_used.append(updated_baseline)
            baseline_adjusted.append(advantage - updated_baseline)

        global_mean = sum(raw_advantages) / len(raw_advantages)
        self._global_baseline = (
            self._baseline_ema_alpha * global_mean
            + (1.0 - self._baseline_ema_alpha) * self._global_baseline
        )

        normalised_advantages = _normalise_by_group(baseline_adjusted, group_keys)
        old_slice = old_log_probs[:size]
        new_slice = new_log_probs[:size]

        policy_loss = _ppo_clip_loss(
            normalised_advantages,
            old_slice,
            new_slice,
            self._config.clip_range,
        )
        kl = _compute_kl(old_slice, new_slice)
        entropy = _compute_entropy(new_slice)
        total_loss = policy_loss + self._config.kl_coeff * kl - self._config.entropy_coeff * entropy

        metrics: dict[str, Any] = {
            "algorithm": "drgrpo",
            "group_count": float(len(set(group_keys))),
            "baseline_mean": round(sum(baselines_used) / len(baselines_used), 6),
            "global_baseline": round(self._global_baseline, 6),
            "advantage_variance": round(_variance(normalised_advantages), 6),
            "normalized_advantages": [round(a, 6) for a in normalised_advantages],
            "kl_divergence": round(kl, 6),
            "entropy": round(entropy, 6),
        }
        return round(total_loss, 6), metrics

    def compute_update(
        self,
        rollouts: list[dict[str, Any]],
        rewards: list[float],
        lengths: list[int],
    ) -> GRPOUpdate:
        """Compute a DrGRPO update step.

        Args:
            rollouts: Rollout dicts (each should contain ``log_probs``).
            rewards: Raw reward per rollout.
            lengths: Token/step count per rollout.

        Returns:
            A :class:`GRPOUpdate` with length-normalised advantages.
        """
        self._step += 1

        # 1. Length-normalised rewards
        norm_rewards = self.apply_length_normalization(rewards, lengths)

        # 2. Group-relative seed advantages used to project a policy step.
        mean_r = sum(norm_rewards) / len(norm_rewards) if norm_rewards else 0.0
        var_r = (
            sum((r - mean_r) ** 2 for r in norm_rewards) / len(norm_rewards)
            if norm_rewards
            else 0.0
        )
        std_r = var_r**0.5 if var_r > 0 else 1.0
        seed_advantages = [(r - mean_r) / std_r for r in norm_rewards]

        # 3. Extract log probs and construct the post-update policy estimate.
        old_log_probs = [float(r.get("log_prob", _safe_log(0.5))) for r in rollouts]
        new_log_probs = [
            old_lp + self._config.learning_rate * adv
            for old_lp, adv in zip(old_log_probs, seed_advantages, strict=False)
        ]

        group_ids = [str(r.get("group_id", r.get("operation", "global"))) for r in rollouts]
        total_loss, metrics = self.optimize(
            norm_rewards,
            old_log_probs,
            new_log_probs,
            group_ids=group_ids,
            rewards=norm_rewards,
        )
        advantages = metrics.get("normalized_advantages", [])
        kl = float(metrics.get("kl_divergence", 0.0))
        entropy = float(metrics.get("entropy", 0.0))

        return GRPOUpdate(
            advantages=[round(a, 6) for a in advantages],
            old_log_probs=[round(lp, 6) for lp in old_log_probs],
            new_log_probs=[round(lp, 6) for lp in new_log_probs],
            kl_divergence=round(kl, 6),
            policy_loss=round(total_loss, 6),
            entropy=round(entropy, 6),
        )


# ---------------------------------------------------------------------------
# DAPO — Dynamic entropy-aware optimization
# ---------------------------------------------------------------------------


class DAPOOptimizer:
    """Dynamic entropy-aware policy optimization.

    Maintains policy entropy during long training runs by computing
    an adaptive entropy bonus.  When entropy drops below the target
    (the policy is collapsing), the bonus increases.  When entropy is
    above target, the bonus decreases or goes to zero.
    """

    def __init__(self, config: OptimizerConfig | None = None) -> None:
        self._config = config or OptimizerConfig()
        self._target_entropy: float = 1.5  # nats
        self._step = 0
        self._clip_higher_multiplier: float = 1.5

    def compute_entropy_bonus(
        self, entropy_history: list[float], target_entropy: float | None = None
    ) -> float:
        """Compute the adaptive entropy bonus.

        The bonus is proportional to the gap between target entropy and
        the recent average entropy.  When entropy is below target the
        bonus is positive (encouraging exploration); when above target
        the bonus is zero.

        Args:
            entropy_history: Recent entropy values from training.
            target_entropy: Override for the default target.

        Returns:
            An entropy bonus coefficient.
        """
        target = target_entropy if target_entropy is not None else self._target_entropy

        if not entropy_history:
            return self._config.entropy_coeff

        # Use exponential moving average of recent entropy
        recent = entropy_history[-20:]
        alpha = 0.1
        ema = recent[0]
        for val in recent[1:]:
            ema = alpha * val + (1 - alpha) * ema

        gap = target - ema
        if gap <= 0:
            # Entropy is at or above target — no bonus needed
            return 0.0

        # Scale bonus proportionally to the gap, capped at 5x base coefficient
        bonus = self._config.entropy_coeff * (1.0 + 4.0 * min(gap / target, 1.0))
        return round(bonus, 6)

    def _clip_higher_loss(
        self,
        advantages: list[float],
        old_log_probs: list[float],
        new_log_probs: list[float],
    ) -> float:
        """DAPO objective with asymmetric clipping for positive advantages."""
        if not advantages:
            return 0.0

        total_loss = 0.0
        low = 1.0 - self._config.clip_range
        high_default = 1.0 + self._config.clip_range
        high_positive = 1.0 + self._config.clip_range * self._clip_higher_multiplier

        for adv, old_lp, new_lp in zip(advantages, old_log_probs, new_log_probs, strict=False):
            ratio = math.exp(new_lp - old_lp)
            high = high_positive if adv > 0 else high_default
            clipped_ratio = _clip(ratio, low, high)
            surr1 = ratio * adv
            surr2 = clipped_ratio * adv
            total_loss += -min(surr1, surr2)

        return total_loss / len(advantages)

    def optimize(
        self,
        advantages: list[float],
        old_log_probs: list[float],
        new_log_probs: list[float],
        *,
        entropy_history: list[float] | None = None,
    ) -> tuple[float, dict[str, Any]]:
        """Optimise with decoupled advantages + clip-higher strategy."""
        if not advantages:
            return 0.0, {
                "algorithm": "dapo",
                "normalized_advantages": [],
                "entropy_bonus": round(self._config.entropy_coeff, 6),
                "kl_divergence": 0.0,
                "entropy": 0.0,
            }

        size = min(len(advantages), len(old_log_probs), len(new_log_probs))
        raw_advantages = advantages[:size]
        old_slice = old_log_probs[:size]
        new_slice = new_log_probs[:size]

        positives = [a for a in raw_advantages if a >= 0]
        negatives = [a for a in raw_advantages if a < 0]
        pos_mean = sum(positives) / len(positives) if positives else 0.0
        neg_mean = sum(negatives) / len(negatives) if negatives else 0.0
        pos_std = _variance(positives) ** 0.5 if positives else 1.0
        neg_std = _variance(negatives) ** 0.5 if negatives else 1.0
        pos_std = pos_std if pos_std > 0 else 1.0
        neg_std = neg_std if neg_std > 0 else 1.0

        decoupled_advantages: list[float] = []
        for advantage in raw_advantages:
            if advantage >= 0:
                decoupled_advantages.append((advantage - pos_mean) / pos_std)
            else:
                decoupled_advantages.append((advantage - neg_mean) / neg_std)

        policy_loss = self._clip_higher_loss(decoupled_advantages, old_slice, new_slice)
        kl = _compute_kl(old_slice, new_slice)
        entropy = _compute_entropy(new_slice)
        entropy_bonus = self.compute_entropy_bonus(entropy_history or [])
        total_loss = policy_loss + self._config.kl_coeff * kl - entropy_bonus * entropy

        metrics: dict[str, Any] = {
            "algorithm": "dapo",
            "positive_fraction": round(len(positives) / len(raw_advantages), 6),
            "clip_high": round(1.0 + self._config.clip_range * self._clip_higher_multiplier, 6),
            "entropy_bonus": round(entropy_bonus, 6),
            "normalized_advantages": [round(a, 6) for a in decoupled_advantages],
            "kl_divergence": round(kl, 6),
            "entropy": round(entropy, 6),
        }
        return round(total_loss, 6), metrics

    def compute_update(
        self,
        rollouts: list[dict[str, Any]],
        rewards: list[float],
        entropy_history: list[float],
    ) -> GRPOUpdate:
        """Compute a DAPO update step.

        Args:
            rollouts: Rollout dicts.
            rewards: Reward per rollout.
            entropy_history: Historical entropy values.

        Returns:
            A :class:`GRPOUpdate` with entropy-aware loss.
        """
        self._step += 1

        # Group-relative advantages
        mean_r = sum(rewards) / len(rewards) if rewards else 0.0
        var_r = sum((r - mean_r) ** 2 for r in rewards) / len(rewards) if rewards else 0.0
        std_r = var_r**0.5 if var_r > 0 else 1.0
        advantages = [(r - mean_r) / std_r for r in rewards]

        old_log_probs = [r.get("log_prob", _safe_log(0.5)) for r in rollouts]
        new_log_probs = [
            old_lp + self._config.learning_rate * adv
            for old_lp, adv in zip(old_log_probs, advantages, strict=False)
        ]

        total_loss, metrics = self.optimize(
            advantages,
            old_log_probs,
            new_log_probs,
            entropy_history=entropy_history,
        )
        normalized_advantages = metrics.get("normalized_advantages", [])
        kl = float(metrics.get("kl_divergence", 0.0))
        entropy = float(metrics.get("entropy", 0.0))

        return GRPOUpdate(
            advantages=[round(a, 6) for a in normalized_advantages],
            old_log_probs=[round(lp, 6) for lp in old_log_probs],
            new_log_probs=[round(lp, 6) for lp in new_log_probs],
            kl_divergence=round(kl, 6),
            policy_loss=round(total_loss, 6),
            entropy=round(entropy, 6),
        )


# ---------------------------------------------------------------------------
# GiGPO — Group-relative with importance sampling
# ---------------------------------------------------------------------------


class GiGPOOptimizer:
    """Group-relative policy optimization with importance sampling.

    Applies importance-sampling corrections to the policy gradient so
    that off-policy rollouts (generated by a previous policy version)
    can be reused efficiently.  The correction uses the reference
    log-probs from the sampling policy.
    """

    def __init__(self, config: OptimizerConfig | None = None) -> None:
        self._config = config or OptimizerConfig()
        self._step = 0

    def optimize(
        self,
        advantages: list[float],
        old_log_probs: list[float],
        new_log_probs: list[float],
        *,
        group_ids: list[str] | None = None,
        token_advantages: list[list[float]] | None = None,
        reference_log_probs: list[float] | None = None,
    ) -> tuple[float, dict[str, Any]]:
        """Optimise GiGPO with group-invariant, token-level advantages."""
        if not advantages:
            return 0.0, {
                "algorithm": "gigpo",
                "normalized_advantages": [],
                "kl_divergence": 0.0,
                "entropy": 0.0,
            }

        size = min(len(advantages), len(old_log_probs), len(new_log_probs))
        raw_advantages = advantages[:size]
        old_slice = old_log_probs[:size]
        new_slice = new_log_probs[:size]
        group_keys = _group_keys(group_ids, size)

        token_means = [0.0] * size
        if token_advantages is not None and len(token_advantages) >= size:
            token_means = []
            for row in token_advantages[:size]:
                if not row:
                    token_means.append(0.0)
                    continue
                row_f = _as_float_list(row, default=0.0)
                token_means.append(sum(row_f) / len(row_f))

        combined_advantages = [
            0.5 * base + 0.5 * token
            for base, token in zip(raw_advantages, token_means, strict=False)
        ]
        group_invariant = _normalise_by_group(combined_advantages, group_keys)

        ref_slice = (
            reference_log_probs[:size]
            if reference_log_probs is not None and len(reference_log_probs) >= size
            else old_slice
        )
        is_ratios: list[float] = []
        for cur_lp, ref_lp in zip(old_slice, ref_slice, strict=False):
            ratio = _clip(math.exp(cur_lp - ref_lp), 0.1, 10.0)
            is_ratios.append(ratio)

        weighted_advantages = [
            a * ratio for a, ratio in zip(group_invariant, is_ratios, strict=False)
        ]
        weighted_advantages = _normalise_by_group(weighted_advantages, group_keys)

        policy_loss = _ppo_clip_loss(
            weighted_advantages,
            old_slice,
            new_slice,
            self._config.clip_range,
        )
        kl = _compute_kl(ref_slice, new_slice)
        entropy = _compute_entropy(new_slice)
        total_loss = policy_loss + self._config.kl_coeff * kl - self._config.entropy_coeff * entropy

        metrics: dict[str, Any] = {
            "algorithm": "gigpo",
            "group_count": float(len(set(group_keys))),
            "is_ratio_mean": round(sum(is_ratios) / len(is_ratios), 6),
            "token_advantage_mean": round(sum(token_means) / len(token_means), 6),
            "normalized_advantages": [round(a, 6) for a in weighted_advantages],
            "kl_divergence": round(kl, 6),
            "entropy": round(entropy, 6),
        }
        return round(total_loss, 6), metrics

    def compute_update(
        self,
        rollouts: list[dict[str, Any]],
        rewards: list[float],
        reference_log_probs: list[float],
    ) -> GRPOUpdate:
        """Compute a GiGPO update with importance sampling correction.

        Args:
            rollouts: Rollout dicts.
            rewards: Reward per rollout.
            reference_log_probs: Log-probabilities under the reference
                (behaviour) policy that generated the rollouts.

        Returns:
            A :class:`GRPOUpdate` with IS-corrected advantages.
        """
        self._step += 1

        # Group-relative advantages
        mean_r = sum(rewards) / len(rewards) if rewards else 0.0
        var_r = sum((r - mean_r) ** 2 for r in rewards) / len(rewards) if rewards else 0.0
        std_r = var_r**0.5 if var_r > 0 else 1.0
        raw_advantages = [(r - mean_r) / std_r for r in rewards]

        # Current policy log probs from rollouts
        current_log_probs = [float(r.get("log_prob", _safe_log(0.5))) for r in rollouts]

        # New log probs (simulated gradient step)
        new_log_probs = [
            old_lp + self._config.learning_rate * adv
            for old_lp, adv in zip(current_log_probs, raw_advantages, strict=False)
        ]

        group_ids = [str(r.get("group_id", r.get("operation", "global"))) for r in rollouts]
        token_advantages = [r.get("token_advantages", []) for r in rollouts]
        total_loss, metrics = self.optimize(
            raw_advantages,
            current_log_probs,
            new_log_probs,
            group_ids=group_ids,
            token_advantages=token_advantages,
            reference_log_probs=reference_log_probs,
        )
        advantages = metrics.get("normalized_advantages", [])
        kl = float(metrics.get("kl_divergence", 0.0))
        entropy = float(metrics.get("entropy", 0.0))

        return GRPOUpdate(
            advantages=[round(a, 6) for a in advantages],
            old_log_probs=[round(lp, 6) for lp in current_log_probs],
            new_log_probs=[round(lp, 6) for lp in new_log_probs],
            kl_divergence=round(kl, 6),
            policy_loss=round(total_loss, 6),
            entropy=round(entropy, 6),
        )


# ---------------------------------------------------------------------------
# Forge — Variance-reduced optimization
# ---------------------------------------------------------------------------


class ForgeOptimizer:
    """Variance-reduced policy optimization.

    Maintains a running baseline of rewards and uses it to reduce
    gradient variance.  The baseline is updated via exponential moving
    average after each batch, providing a more stable advantage signal.
    """

    def __init__(self, config: OptimizerConfig | None = None) -> None:
        self._config = config or OptimizerConfig()
        self._baseline: float = 0.0
        self._baseline_ema_alpha: float = 0.05
        self._baseline_count: int = 0
        self._step = 0

    def update_baseline(self, new_rewards: list[float]) -> None:
        """Update the running reward baseline.

        Uses EMA for smooth updates.  On the first call, the baseline
        is initialised to the batch mean.

        Args:
            new_rewards: Reward values from the latest batch.
        """
        if not new_rewards:
            return

        batch_mean = sum(new_rewards) / len(new_rewards)

        if self._baseline_count == 0:
            self._baseline = batch_mean
        else:
            self._baseline = (
                self._baseline_ema_alpha * batch_mean
                + (1 - self._baseline_ema_alpha) * self._baseline
            )

        self._baseline_count += 1

    def optimize(
        self,
        advantages: list[float],
        old_log_probs: list[float],
        new_log_probs: list[float],
        *,
        rewards: list[float] | None = None,
        control_variate: list[float] | None = None,
    ) -> tuple[float, dict[str, Any]]:
        """Optimise with a control variate to reduce gradient variance."""
        if not advantages:
            return 0.0, {
                "algorithm": "forge",
                "normalized_advantages": [],
                "baseline": round(self._baseline, 6),
                "variance_reduction": 0.0,
                "kl_divergence": 0.0,
                "entropy": 0.0,
            }

        size = min(len(advantages), len(old_log_probs), len(new_log_probs))
        raw_advantages = advantages[:size]
        old_slice = old_log_probs[:size]
        new_slice = new_log_probs[:size]

        variate: list[float]
        if control_variate is not None and len(control_variate) >= size:
            variate = _as_float_list(control_variate[:size], default=0.0)
        elif rewards is not None and len(rewards) >= size:
            variate = [float(r) - self._baseline for r in rewards[:size]]
        else:
            variate = [0.0] * size

        adjusted_advantages = [adv - cv for adv, cv in zip(raw_advantages, variate, strict=False)]

        mean = sum(adjusted_advantages) / len(adjusted_advantages)
        std = _variance(adjusted_advantages) ** 0.5
        std = std if std > 0 else 1.0
        normalised_advantages = [(a - mean) / std for a in adjusted_advantages]

        policy_loss = _ppo_clip_loss(
            normalised_advantages,
            old_slice,
            new_slice,
            self._config.clip_range,
        )
        kl = _compute_kl(old_slice, new_slice)
        entropy = _compute_entropy(new_slice)
        total_loss = policy_loss + self._config.kl_coeff * kl - self._config.entropy_coeff * entropy

        raw_variance = _variance(raw_advantages)
        adjusted_variance = _variance(adjusted_advantages)
        variance_reduction = max(raw_variance - adjusted_variance, 0.0)

        if rewards is not None and len(rewards) >= size:
            self.update_baseline(_as_float_list(rewards[:size], default=0.0))

        metrics: dict[str, Any] = {
            "algorithm": "forge",
            "baseline": round(self._baseline, 6),
            "variance_reduction": round(variance_reduction, 6),
            "normalized_advantages": [round(a, 6) for a in normalised_advantages],
            "kl_divergence": round(kl, 6),
            "entropy": round(entropy, 6),
        }
        return round(total_loss, 6), metrics

    def compute_update(
        self,
        rollouts: list[dict[str, Any]],
        rewards: list[float],
        baseline_rewards: list[float] | None = None,
    ) -> GRPOUpdate:
        """Compute a Forge variance-reduced update.

        Args:
            rollouts: Rollout dicts.
            rewards: Current batch rewards.
            baseline_rewards: Optional explicit baseline rewards.  If None,
                the internal running baseline is used.

        Returns:
            A :class:`GRPOUpdate` with variance-reduced advantages.
        """
        self._step += 1

        # Determine raw advantages then project policy shift.
        if baseline_rewards is not None and len(baseline_rewards) == len(rewards):
            raw_advantages = [r - b for r, b in zip(rewards, baseline_rewards, strict=False)]
            control_variate = baseline_rewards
        else:
            raw_advantages = [r - self._baseline for r in rewards]
            control_variate = None

        old_log_probs = [float(r.get("log_prob", _safe_log(0.5))) for r in rollouts]
        new_log_probs = [
            old_lp + self._config.learning_rate * adv
            for old_lp, adv in zip(old_log_probs, raw_advantages, strict=False)
        ]

        total_loss, metrics = self.optimize(
            raw_advantages,
            old_log_probs,
            new_log_probs,
            rewards=rewards,
            control_variate=control_variate,
        )
        advantages = metrics.get("normalized_advantages", [])
        kl = float(metrics.get("kl_divergence", 0.0))
        entropy = float(metrics.get("entropy", 0.0))

        return GRPOUpdate(
            advantages=[round(a, 6) for a in advantages],
            old_log_probs=[round(lp, 6) for lp in old_log_probs],
            new_log_probs=[round(lp, 6) for lp in new_log_probs],
            kl_divergence=round(kl, 6),
            policy_loss=round(total_loss, 6),
            entropy=round(entropy, 6),
        )
