"""Goodhart's Law early warning system.

Detects when a proxy reward signal diverges from a true quality (gold)
score — the hallmark of Goodhart's Law in RL-trained systems.  Inspired
by Gao et al. (2023) scaling laws for reward model over-optimization:

    gold ~ d * proxy - beta * proxy^2

where *gold* peaks at a finite proxy level and then declines.  The
monitor fits this quadratic relationship, estimates the divergence
trajectory, and predicts the step at which divergence will exceed a
configurable threshold.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

# ---------------------------------------------------------------------------
# Configuration & result types
# ---------------------------------------------------------------------------


@dataclass
class GoodhartConfig:
    """Configuration for the Goodhart divergence monitor."""

    divergence_threshold: float = 0.15
    window_size: int = 50
    scaling_model: str = "quadratic"  # "linear" or "quadratic"
    early_stop_on_divergence: bool = True


@dataclass
class GoodhartWarning:
    """A divergence warning emitted by :class:`GoodhartMonitor`."""

    proxy_reward: float
    gold_score: float
    divergence: float
    predicted_divergence_point: int | None
    confidence: float
    recommendation: str


# ---------------------------------------------------------------------------
# Math helpers
# ---------------------------------------------------------------------------


def _pearson(xs: list[float], ys: list[float]) -> float:
    """Pearson correlation coefficient between *xs* and *ys*."""
    n = min(len(xs), len(ys))
    if n < 2:
        return 0.0
    mx = sum(xs[:n]) / n
    my = sum(ys[:n]) / n
    cov = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    sx = math.sqrt(sum((xs[i] - mx) ** 2 for i in range(n)))
    sy = math.sqrt(sum((ys[i] - my) ** 2 for i in range(n)))
    denom = sx * sy
    return cov / denom if denom > 1e-12 else 0.0


def _fit_linear(xs: list[float], ys: list[float]) -> tuple[float, float]:
    """Ordinary least-squares linear fit y = a + b*x.

    Returns (a, b).
    """
    n = len(xs)
    if n < 2:
        return 0.0, 0.0
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    den = sum((xs[i] - mx) ** 2 for i in range(n))
    b = num / den if den > 0 else 0.0
    a = my - b * mx
    return a, b


def _fit_quadratic(xs: list[float], ys: list[float]) -> tuple[float, float, float]:
    """Least-squares quadratic fit y = a + b*x + c*x^2.

    Uses the normal equations for a degree-2 polynomial.
    Returns (a, b, c).
    """
    n = len(xs)
    if n < 3:
        a, b = _fit_linear(xs, ys)
        return a, b, 0.0

    # Build sums for the normal equations
    s0 = float(n)
    s1 = sum(xs)
    s2 = sum(x**2 for x in xs)
    s3 = sum(x**3 for x in xs)
    s4 = sum(x**4 for x in xs)
    sy = sum(ys)
    sxy = sum(xs[i] * ys[i] for i in range(n))
    sx2y = sum(xs[i] ** 2 * ys[i] for i in range(n))

    # Normal equations in matrix form:
    # | s0  s1  s2 | |a|   | sy   |
    # | s1  s2  s3 | |b| = | sxy  |
    # | s2  s3  s4 | |c|   | sx2y |
    #
    # Solve via Cramer's rule
    det_m = s0 * (s2 * s4 - s3 * s3) - s1 * (s1 * s4 - s3 * s2) + s2 * (s1 * s3 - s2 * s2)
    if abs(det_m) < 1e-15:
        a, b = _fit_linear(xs, ys)
        return a, b, 0.0

    det_a = sy * (s2 * s4 - s3 * s3) - s1 * (sxy * s4 - s3 * sx2y) + s2 * (sxy * s3 - s2 * sx2y)
    det_b = s0 * (sxy * s4 - s3 * sx2y) - sy * (s1 * s4 - s3 * s2) + s2 * (s1 * sx2y - sxy * s2)
    det_c = s0 * (s2 * sx2y - sxy * s3) - s1 * (s1 * sx2y - sxy * s2) + sy * (s1 * s3 - s2 * s2)

    return det_a / det_m, det_b / det_m, det_c / det_m


def _r_squared(ys: list[float], predicted: list[float]) -> float:
    """Coefficient of determination R^2."""
    n = len(ys)
    if n < 2:
        return 0.0
    my = sum(ys) / n
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((ys[i] - predicted[i]) ** 2 for i in range(n))
    if ss_tot < 1e-12:
        return 1.0
    return 1.0 - ss_res / ss_tot


# ---------------------------------------------------------------------------
# GoodhartMonitor
# ---------------------------------------------------------------------------


class GoodhartMonitor:
    """Monitors proxy reward vs. gold quality for Goodhart divergence.

    Records paired (proxy_reward, gold_score) observations at each
    training step and checks whether the gold score has started to
    *decrease* while the proxy reward continues to *increase* — the
    signature of over-optimization.
    """

    def __init__(self, config: GoodhartConfig | None = None) -> None:
        self._config = config or GoodhartConfig()
        self._steps: list[int] = []
        self._proxy_values: list[float] = []
        self._gold_values: list[float] = []

    # -- Recording ----------------------------------------------------------

    def record(self, step: int, proxy_reward: float, gold_score: float) -> None:
        """Record a paired observation at training *step*."""
        self._steps.append(step)
        self._proxy_values.append(proxy_reward)
        self._gold_values.append(gold_score)

    # -- Checking -----------------------------------------------------------

    def check(self) -> GoodhartWarning | None:
        """Check for proxy-gold divergence.

        Returns a :class:`GoodhartWarning` if the divergence exceeds
        the configured threshold, else ``None``.
        """
        n = len(self._steps)
        if n < 5:
            return None

        # Use the most recent window
        ws = self._config.window_size
        proxy = self._proxy_values[-ws:]
        gold = self._gold_values[-ws:]

        latest_proxy = proxy[-1]
        latest_gold = gold[-1]

        # Divergence = how much proxy exceeds gold relative to early alignment
        # Normalized so that a perfectly aligned pair has divergence 0.
        if len(proxy) >= 4:
            early_proxy = sum(proxy[: len(proxy) // 4]) / max(len(proxy) // 4, 1)
            early_gold = sum(gold[: len(gold) // 4]) / max(len(gold) // 4, 1)
            early_gap = early_proxy - early_gold
            current_gap = latest_proxy - latest_gold
            divergence = current_gap - early_gap
        else:
            divergence = latest_proxy - latest_gold

        divergence_abs = abs(divergence)
        threshold = self._config.divergence_threshold

        if divergence_abs > threshold:
            pred_point = self.predict_divergence_point()
            corr = self.correlation()

            # Confidence based on data size, R^2 of the quadratic fit, and
            # how far past the threshold we are
            data_confidence = min(1.0, n / 50)
            magnitude_confidence = min(1.0, divergence_abs / (threshold * 3))
            confidence = round((data_confidence + magnitude_confidence) / 2, 4)

            recommendation = self._build_recommendation(divergence, corr, pred_point)

            return GoodhartWarning(
                proxy_reward=round(latest_proxy, 6),
                gold_score=round(latest_gold, 6),
                divergence=round(divergence, 6),
                predicted_divergence_point=pred_point,
                confidence=confidence,
                recommendation=recommendation,
            )

        return None

    def predict_divergence_point(self) -> int | None:
        """Predict the training step at which divergence will exceed the threshold.

        Fits the Gao et al. (2023) inspired model:
            gold = d * proxy - beta * proxy^2

        Returns the predicted step, or ``None`` if no divergence is predicted.
        """
        n = len(self._steps)
        if n < 5:
            return None

        proxy = list(self._proxy_values)
        gold = list(self._gold_values)
        steps = list(self._steps)

        if self._config.scaling_model == "quadratic":
            # Fit gold = a + b * proxy + c * proxy^2
            a, b, c = _fit_quadratic(proxy, gold)

            # If c >= 0, the quadratic opens upward — no over-optimization peak
            if c >= 0:
                return None

            # The gold peak occurs at proxy* = -b / (2c)
            proxy_peak = -b / (2 * c)

            # Is current proxy already past the peak?
            latest_proxy = proxy[-1]
            if latest_proxy >= proxy_peak:
                # Already past peak; divergence is happening now
                return steps[-1]

            # Predict how proxy grows over time via linear fit on (step, proxy)
            step_floats = [float(s) for s in steps]
            a_s, b_s = _fit_linear(step_floats, proxy)
            if b_s <= 0:
                return None  # Proxy is not increasing

            # Step at which proxy = proxy_peak
            predicted_step = (proxy_peak - a_s) / b_s
            return int(round(predicted_step))

        else:
            # Linear scaling model: fit divergence as linear in step
            divergences = [proxy[i] - gold[i] for i in range(n)]
            step_floats = [float(s) for s in steps]
            a_d, b_d = _fit_linear(step_floats, divergences)

            if b_d <= 0:
                return None  # Divergence not increasing

            threshold = self._config.divergence_threshold
            current_divergence = divergences[-1]
            if current_divergence >= threshold:
                return steps[-1]

            steps_remaining = (threshold - a_d) / b_d if b_d > 0 else None
            return int(round(steps_remaining)) if steps_remaining is not None else None

    def should_stop(self) -> bool:
        """Whether training should early-stop due to Goodhart divergence."""
        if not self._config.early_stop_on_divergence:
            return False
        warning = self.check()
        return warning is not None

    def correlation(self) -> float:
        """Pearson correlation between proxy reward and gold score."""
        return round(_pearson(self._proxy_values, self._gold_values), 6)

    def plot_data(self) -> dict[str, Any]:
        """Return data formatted for visualization.

        Returns a dict with keys ``steps``, ``proxy_values``,
        ``gold_values``, ``divergence_values``.
        """
        n = len(self._steps)
        divergence_values = [
            round(self._proxy_values[i] - self._gold_values[i], 6) for i in range(n)
        ]
        return {
            "steps": list(self._steps),
            "proxy_values": [round(v, 6) for v in self._proxy_values],
            "gold_values": [round(v, 6) for v in self._gold_values],
            "divergence_values": divergence_values,
        }

    def summary(self) -> dict[str, Any]:
        """Condensed monitor summary."""
        n = len(self._steps)
        warning = self.check()
        return {
            "data_points": n,
            "correlation": self.correlation(),
            "latest_proxy": round(self._proxy_values[-1], 6) if self._proxy_values else None,
            "latest_gold": round(self._gold_values[-1], 6) if self._gold_values else None,
            "divergence_detected": warning is not None,
            "predicted_divergence_point": self.predict_divergence_point(),
            "config": {
                "divergence_threshold": self._config.divergence_threshold,
                "window_size": self._config.window_size,
                "scaling_model": self._config.scaling_model,
                "early_stop_on_divergence": self._config.early_stop_on_divergence,
            },
        }

    # -- Internals ----------------------------------------------------------

    @staticmethod
    def _build_recommendation(divergence: float, corr: float, pred_point: int | None) -> str:
        parts: list[str] = []
        if divergence > 0.3:
            parts.append("Severe proxy-gold divergence detected. Strongly consider early stopping.")
        elif divergence > 0.15:
            parts.append(
                "Moderate divergence detected. Reduce learning rate and increase gold eval frequency."
            )
        else:
            parts.append("Mild divergence detected. Monitor closely.")

        if corr < 0.3:
            parts.append(
                f"Proxy-gold correlation is low ({corr:.2f}). "
                "Reward model may need re-training on updated gold labels."
            )

        if pred_point is not None:
            parts.append(
                f"Divergence predicted to exceed threshold at step {pred_point}. "
                "Consider scheduling a gold eval checkpoint before that step."
            )

        return " ".join(parts)
