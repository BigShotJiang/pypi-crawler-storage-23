"""System efficiency tracking for Aegis eval runs.

Tracks token usage, latency per stage, cost estimates, tool call
efficiency, retrieval efficiency, context utilization, and redundancy
across evaluation runs.
"""

from __future__ import annotations

import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.core.types import SystemEfficiencyV1


@dataclass
class StageMetrics:
    """Metrics for a single processing stage."""

    stage_name: str
    latency_ms: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    calls: int = 0


@dataclass
class EfficiencySnapshot:
    """Point-in-time efficiency snapshot for a run."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    run_id: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    efficiency: SystemEfficiencyV1 = field(default_factory=SystemEfficiencyV1)
    stage_breakdown: list[StageMetrics] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# Cost estimates per 1K tokens (approximate)
_COST_PER_1K: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "claude-sonnet-4-5-20250929": {"input": 0.003, "output": 0.015},
    "claude-haiku-4-5-20251001": {"input": 0.0008, "output": 0.004},
    "default": {"input": 0.002, "output": 0.008},
}


class EfficiencyTracker:
    """Tracks system efficiency metrics across eval runs.

    Provides methods to record token usage, latency, tool calls,
    retrieval operations, and context utilization. Computes cost
    estimates and produces SystemEfficiencyV1 snapshots.
    """

    def __init__(self, model_name: str = "default") -> None:
        self._model_name = model_name
        self._runs: dict[str, EfficiencySnapshot] = {}
        self._active_run: str | None = None
        self._stage_timers: dict[str, dict[str, float]] = defaultdict(
            lambda: {"start": 0.0, "total": 0.0}
        )

    def start_run(self, run_id: str) -> EfficiencySnapshot:
        """Start tracking a new eval run."""
        snapshot = EfficiencySnapshot(run_id=run_id)
        self._runs[run_id] = snapshot
        self._active_run = run_id
        return snapshot

    def end_run(self, run_id: str | None = None) -> EfficiencySnapshot | None:
        """End tracking for a run and finalize metrics."""
        rid = run_id or self._active_run
        if not rid or rid not in self._runs:
            return None

        snapshot = self._runs[rid]
        # Compute derived metrics
        eff = snapshot.efficiency
        eff.cost_estimate_usd = self._estimate_cost(eff.input_tokens, eff.output_tokens)

        if eff.tool_calls_total > 0:
            # tool_calls_useful / tool_calls_total as a ratio
            pass  # Already tracked
        if eff.retrieval_total > 0:
            # retrieval_relevant / retrieval_total
            pass  # Already tracked

        if self._active_run == rid:
            self._active_run = None
        return snapshot

    def record_tokens(
        self,
        input_tokens: int = 0,
        output_tokens: int = 0,
        run_id: str | None = None,
    ) -> None:
        """Record token usage for a run."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return
        eff = snapshot.efficiency
        eff.input_tokens += input_tokens
        eff.output_tokens += output_tokens
        eff.total_tokens = eff.input_tokens + eff.output_tokens

    def record_latency(
        self,
        stage_name: str,
        latency_ms: float,
        run_id: str | None = None,
    ) -> None:
        """Record latency for a processing stage."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return

        eff = snapshot.efficiency
        eff.latency_ms += latency_ms
        eff.latency_per_stage[stage_name] = eff.latency_per_stage.get(stage_name, 0.0) + latency_ms

        # Update stage breakdown
        found = False
        for stage in snapshot.stage_breakdown:
            if stage.stage_name == stage_name:
                stage.latency_ms += latency_ms
                stage.calls += 1
                found = True
                break
        if not found:
            snapshot.stage_breakdown.append(
                StageMetrics(stage_name=stage_name, latency_ms=latency_ms, calls=1)
            )

    def record_tool_call(
        self,
        useful: bool = True,
        run_id: str | None = None,
    ) -> None:
        """Record a tool call (useful or not)."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return
        eff = snapshot.efficiency
        eff.tool_calls_total += 1
        if useful:
            eff.tool_calls_useful += 1

    def record_retrieval(
        self,
        relevant: bool = True,
        run_id: str | None = None,
    ) -> None:
        """Record a retrieval operation (relevant or not)."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return
        eff = snapshot.efficiency
        eff.retrieval_total += 1
        if relevant:
            eff.retrieval_relevant += 1

    def record_context_utilization(
        self,
        total_context_tokens: int,
        used_context_tokens: int,
        run_id: str | None = None,
    ) -> None:
        """Record context window utilization."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return
        if total_context_tokens > 0:
            snapshot.efficiency.context_utilization = round(
                used_context_tokens / total_context_tokens, 4
            )

    def record_redundancy(
        self,
        total_outputs: int,
        unique_outputs: int,
        run_id: str | None = None,
    ) -> None:
        """Record output redundancy rate."""
        snapshot = self._get_snapshot(run_id)
        if not snapshot:
            return
        if total_outputs > 0:
            snapshot.efficiency.redundancy_rate = round(1.0 - unique_outputs / total_outputs, 4)

    def get_snapshot(self, run_id: str | None = None) -> EfficiencySnapshot | None:
        """Get the current snapshot for a run."""
        return self._get_snapshot(run_id)

    def get_efficiency(self, run_id: str | None = None) -> SystemEfficiencyV1 | None:
        """Get SystemEfficiencyV1 for a run."""
        snapshot = self._get_snapshot(run_id)
        return snapshot.efficiency if snapshot else None

    def compare_runs(self, run_id_a: str, run_id_b: str) -> dict[str, Any]:
        """Compare efficiency between two runs."""
        a = self._runs.get(run_id_a)
        b = self._runs.get(run_id_b)
        if not a or not b:
            return {"error": "One or both runs not found"}

        ea, eb = a.efficiency, b.efficiency

        def delta(va: float, vb: float) -> float:
            return round(vb - va, 4)

        def pct_change(va: float, vb: float) -> float:
            if va == 0:
                return 0.0
            return round((vb - va) / va * 100, 2)

        return {
            "run_a": run_id_a,
            "run_b": run_id_b,
            "tokens": {
                "delta": delta(ea.total_tokens, eb.total_tokens),
                "pct_change": pct_change(ea.total_tokens, eb.total_tokens),
            },
            "latency_ms": {
                "delta": delta(ea.latency_ms, eb.latency_ms),
                "pct_change": pct_change(ea.latency_ms, eb.latency_ms),
            },
            "cost_usd": {
                "delta": delta(ea.cost_estimate_usd, eb.cost_estimate_usd),
                "pct_change": pct_change(ea.cost_estimate_usd, eb.cost_estimate_usd),
            },
            "context_utilization": {
                "delta": delta(ea.context_utilization, eb.context_utilization),
            },
        }

    def all_runs(self) -> list[dict[str, Any]]:
        """Return summary of all tracked runs."""
        return [
            {
                "run_id": s.run_id,
                "total_tokens": s.efficiency.total_tokens,
                "latency_ms": s.efficiency.latency_ms,
                "cost_usd": s.efficiency.cost_estimate_usd,
                "tool_calls": s.efficiency.tool_calls_total,
                "retrievals": s.efficiency.retrieval_total,
            }
            for s in self._runs.values()
        ]

    def _get_snapshot(self, run_id: str | None = None) -> EfficiencySnapshot | None:
        """Get snapshot for run_id or active run."""
        rid = run_id or self._active_run
        if not rid:
            return None
        return self._runs.get(rid)

    def _estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost in USD based on model pricing."""
        rates = _COST_PER_1K.get(self._model_name, _COST_PER_1K["default"])
        cost = (input_tokens / 1000) * rates["input"] + (output_tokens / 1000) * rates["output"]
        return round(cost, 6)
