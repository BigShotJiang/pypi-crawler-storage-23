"""Prometheus metrics exporter for Observatory monitoring.

Exposes training metrics, memory health, and observatory signals
as Prometheus-compatible metrics for Grafana dashboards.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Metric types
# ---------------------------------------------------------------------------


@dataclass
class _Counter:
    """A monotonically increasing counter metric."""

    name: str
    help_text: str
    labels: dict[str, float] = field(default_factory=dict)

    def inc(self, label_key: str = "__total__", amount: float = 1.0) -> None:
        """Increment the counter for the given label key."""
        self.labels[label_key] = self.labels.get(label_key, 0.0) + amount

    def get(self, label_key: str = "__total__") -> float:
        """Return the current value for the given label key."""
        return self.labels.get(label_key, 0.0)


@dataclass
class _Gauge:
    """A metric that can go up and down."""

    name: str
    help_text: str
    labels: dict[str, float] = field(default_factory=dict)

    def set(self, value: float, label_key: str = "__total__") -> None:
        """Set the gauge to the given value."""
        self.labels[label_key] = value

    def get(self, label_key: str = "__total__") -> float:
        """Return the current value for the given label key."""
        return self.labels.get(label_key, 0.0)


@dataclass
class _Histogram:
    """A metric that tracks value distributions via buckets."""

    name: str
    help_text: str
    buckets: tuple[float, ...] = (
        5.0,
        10.0,
        25.0,
        50.0,
        100.0,
        250.0,
        500.0,
        1000.0,
        2500.0,
        5000.0,
    )
    _observations: dict[str, list[float]] = field(default_factory=dict)

    def observe(self, value: float, label_key: str = "__total__") -> None:
        """Record an observed value."""
        self._observations.setdefault(label_key, []).append(value)

    def count(self, label_key: str = "__total__") -> int:
        """Return the number of observations for the given label key."""
        return len(self._observations.get(label_key, []))

    def total(self, label_key: str = "__total__") -> float:
        """Return the sum of all observations for the given label key."""
        return sum(self._observations.get(label_key, []))

    def bucket_counts(self, label_key: str = "__total__") -> list[tuple[float, int]]:
        """Return cumulative bucket counts for the given label key."""
        observations = self._observations.get(label_key, [])
        counts: list[tuple[float, int]] = []
        for upper in self.buckets:
            count = sum(1 for v in observations if v <= upper)
            counts.append((upper, count))
        counts.append((float("inf"), len(observations)))
        return counts


# ---------------------------------------------------------------------------
# MetricsExporter
# ---------------------------------------------------------------------------


class MetricsExporter:
    """Prometheus-compatible metrics exporter for Aegis Observatory.

    Collects training metrics, memory operation stats, observatory alerts,
    and eval scores, then exports them in either Prometheus text format or
    JSON for consumption by monitoring systems.

    Thread-safe: all mutations are protected by a lock.
    """

    def __init__(self) -> None:
        """Initialize the metrics exporter with all metric collectors."""
        self._lock = threading.Lock()
        self._start_time = time.monotonic()

        # -- Training metrics -----------------------------------------------
        self._training_steps = _Counter(
            "aegis_training_steps_total",
            "Total number of training steps completed",
        )
        self._training_reward = _Gauge(
            "aegis_training_reward",
            "Current training reward value",
        )
        self._training_loss = _Gauge(
            "aegis_training_loss",
            "Current training loss value",
        )
        self._training_kl_divergence = _Gauge(
            "aegis_training_kl_divergence",
            "Current KL divergence from reference policy",
        )
        self._training_entropy = _Gauge(
            "aegis_training_entropy",
            "Current policy entropy",
        )
        self._training_grad_norm = _Gauge(
            "aegis_training_grad_norm",
            "Current gradient norm",
        )
        self._training_learning_rate = _Gauge(
            "aegis_training_learning_rate",
            "Current learning rate",
        )

        # -- Memory metrics -------------------------------------------------
        self._memory_ops_total = _Counter(
            "aegis_memory_operations_total",
            "Total memory operations by type",
        )
        self._memory_op_duration = _Histogram(
            "aegis_memory_operation_duration_ms",
            "Memory operation duration in milliseconds",
        )
        self._memory_op_errors = _Counter(
            "aegis_memory_operation_errors_total",
            "Total failed memory operations by type",
        )
        self._memory_bank_size = _Gauge(
            "aegis_memory_bank_size",
            "Current number of entries in each memory bank",
        )
        self._memory_dead_pct = _Gauge(
            "aegis_memory_dead_percentage",
            "Percentage of dead (unreachable) memories",
        )

        # -- Observatory metrics -------------------------------------------
        self._observatory_alerts_total = _Counter(
            "aegis_observatory_alerts_total",
            "Total observatory alerts by type and severity",
        )
        self._observatory_interventions = _Counter(
            "aegis_observatory_interventions_total",
            "Total auto-interventions triggered",
        )
        self._goodhart_divergence = _Gauge(
            "aegis_goodhart_divergence",
            "Current Goodhart divergence score",
        )

        # -- Eval metrics --------------------------------------------------
        self._eval_scores = _Gauge(
            "aegis_eval_score",
            "Eval scores by dimension",
        )
        self._eval_runs_total = _Counter(
            "aegis_eval_runs_total",
            "Total eval runs completed",
        )

    def record_training_step(self, metrics: dict[str, float | int | str]) -> None:
        """Record per-step training metrics.

        Args:
            metrics: A dictionary of metric key-value pairs. Recognized
                keys include ``reward``, ``loss``, ``kl_divergence``,
                ``entropy``, ``grad_norm``, ``learning_rate``, and
                ``step``.
        """
        with self._lock:
            step_label = str(metrics.get("step", "latest"))
            self._training_steps.inc()

            if "reward" in metrics:
                self._training_reward.set(float(metrics["reward"]), step_label)
            if "loss" in metrics:
                self._training_loss.set(float(metrics["loss"]), step_label)
            if "kl_divergence" in metrics:
                self._training_kl_divergence.set(float(metrics["kl_divergence"]), step_label)
            if "entropy" in metrics:
                self._training_entropy.set(float(metrics["entropy"]), step_label)
            if "grad_norm" in metrics:
                self._training_grad_norm.set(float(metrics["grad_norm"]), step_label)
            if "learning_rate" in metrics:
                self._training_learning_rate.set(float(metrics["learning_rate"]), step_label)

            # Memory-specific training metrics
            if "memory_bank_size" in metrics:
                self._memory_bank_size.set(float(metrics["memory_bank_size"]), step_label)
            if "dead_memory_pct" in metrics:
                self._memory_dead_pct.set(float(metrics["dead_memory_pct"]), step_label)
            if "goodhart_divergence" in metrics:
                self._goodhart_divergence.set(float(metrics["goodhart_divergence"]), step_label)

    def record_memory_operation(self, operation: str, duration_ms: float, success: bool) -> None:
        """Record a single memory operation.

        Args:
            operation: The type of memory operation (e.g. ``"STORE"``,
                ``"RETRIEVE"``).
            duration_ms: How long the operation took in milliseconds.
            success: Whether the operation completed successfully.
        """
        with self._lock:
            self._memory_ops_total.inc(operation)
            self._memory_op_duration.observe(duration_ms, operation)
            if not success:
                self._memory_op_errors.inc(operation)

    def record_observatory_alert(self, alert_type: str, severity: str) -> None:
        """Record an observatory alert event.

        Args:
            alert_type: The category of alert (e.g. ``"goodhart_warning"``,
                ``"reward_hacking"``, ``"kl_spike"``).
            severity: Alert severity level (e.g. ``"info"``, ``"warning"``,
                ``"critical"``).
        """
        with self._lock:
            label = f"{alert_type}:{severity}"
            self._observatory_alerts_total.inc(label)
            if alert_type == "auto_intervention":
                self._observatory_interventions.inc(severity)

    def record_eval_score(self, dimension: str, score: float) -> None:
        """Record an evaluation score for a specific dimension.

        Args:
            dimension: The eval dimension name (e.g.
                ``"memory_fidelity"``, ``"reasoning_quality"``).
            score: The score value, typically between 0.0 and 1.0.
        """
        with self._lock:
            self._eval_scores.set(score, dimension)
            self._eval_runs_total.inc(dimension)

    def export_prometheus(self) -> str:
        """Generate Prometheus text exposition format output.

        Returns:
            A string in Prometheus text format containing all registered
            metrics and their current values.
        """
        with self._lock:
            lines: list[str] = []
            uptime = time.monotonic() - self._start_time

            # Uptime
            lines.append("# HELP aegis_uptime_seconds Time since exporter started")
            lines.append("# TYPE aegis_uptime_seconds gauge")
            lines.append(f"aegis_uptime_seconds {uptime:.2f}")
            lines.append("")

            # Training steps counter
            lines.extend(self._format_counter(self._training_steps))

            # Training gauges
            for gauge in (
                self._training_reward,
                self._training_loss,
                self._training_kl_divergence,
                self._training_entropy,
                self._training_grad_norm,
                self._training_learning_rate,
                self._memory_bank_size,
                self._memory_dead_pct,
                self._goodhart_divergence,
            ):
                lines.extend(self._format_gauge(gauge))

            # Memory operation counters and histograms
            lines.extend(self._format_counter(self._memory_ops_total))
            lines.extend(self._format_counter(self._memory_op_errors))
            lines.extend(self._format_histogram(self._memory_op_duration))

            # Observatory counters
            lines.extend(self._format_counter(self._observatory_alerts_total))
            lines.extend(self._format_counter(self._observatory_interventions))

            # Eval metrics
            lines.extend(self._format_gauge(self._eval_scores))
            lines.extend(self._format_counter(self._eval_runs_total))

            return "\n".join(lines) + "\n"

    def export_json(self) -> dict[str, object]:
        """Export all metrics as a JSON-serializable dictionary.

        Returns:
            A dictionary with nested sections for ``training``, ``memory``,
            ``observatory``, and ``eval`` metrics.
        """
        with self._lock:
            uptime = time.monotonic() - self._start_time

            return {
                "uptime_seconds": round(uptime, 2),
                "training": {
                    "steps_total": self._training_steps.get(),
                    "reward": dict(self._training_reward.labels),
                    "loss": dict(self._training_loss.labels),
                    "kl_divergence": dict(self._training_kl_divergence.labels),
                    "entropy": dict(self._training_entropy.labels),
                    "grad_norm": dict(self._training_grad_norm.labels),
                    "learning_rate": dict(self._training_learning_rate.labels),
                },
                "memory": {
                    "operations_total": dict(self._memory_ops_total.labels),
                    "operation_errors": dict(self._memory_op_errors.labels),
                    "operation_durations_count": {
                        k: len(v) for k, v in self._memory_op_duration._observations.items()
                    },
                    "operation_durations_sum": {
                        k: sum(v) for k, v in self._memory_op_duration._observations.items()
                    },
                    "bank_size": dict(self._memory_bank_size.labels),
                    "dead_memory_pct": dict(self._memory_dead_pct.labels),
                },
                "observatory": {
                    "alerts_total": dict(self._observatory_alerts_total.labels),
                    "interventions_total": dict(self._observatory_interventions.labels),
                    "goodhart_divergence": dict(self._goodhart_divergence.labels),
                },
                "eval": {
                    "scores": dict(self._eval_scores.labels),
                    "runs_total": dict(self._eval_runs_total.labels),
                },
            }

    # -- Prometheus formatting helpers --------------------------------------

    @staticmethod
    def _format_counter(counter: _Counter) -> list[str]:
        """Format a counter metric in Prometheus text exposition format.

        Args:
            counter: The counter to format.

        Returns:
            List of formatted lines.
        """
        lines: list[str] = []
        lines.append(f"# HELP {counter.name} {counter.help_text}")
        lines.append(f"# TYPE {counter.name} counter")
        for label_key, value in counter.labels.items():
            if label_key == "__total__":
                lines.append(f"{counter.name} {value}")
            else:
                safe_label = label_key.replace('"', '\\"')
                lines.append(f'{counter.name}{{label="{safe_label}"}} {value}')
        if not counter.labels:
            lines.append(f"{counter.name} 0")
        lines.append("")
        return lines

    @staticmethod
    def _format_gauge(gauge: _Gauge) -> list[str]:
        """Format a gauge metric in Prometheus text exposition format.

        Args:
            gauge: The gauge to format.

        Returns:
            List of formatted lines.
        """
        lines: list[str] = []
        lines.append(f"# HELP {gauge.name} {gauge.help_text}")
        lines.append(f"# TYPE {gauge.name} gauge")
        for label_key, value in gauge.labels.items():
            if label_key == "__total__":
                lines.append(f"{gauge.name} {value}")
            else:
                safe_label = label_key.replace('"', '\\"')
                lines.append(f'{gauge.name}{{label="{safe_label}"}} {value}')
        if not gauge.labels:
            lines.append(f"{gauge.name} 0")
        lines.append("")
        return lines

    @staticmethod
    def _format_histogram(histogram: _Histogram) -> list[str]:
        """Format a histogram metric in Prometheus text exposition format.

        Args:
            histogram: The histogram to format.

        Returns:
            List of formatted lines.
        """
        lines: list[str] = []
        lines.append(f"# HELP {histogram.name} {histogram.help_text}")
        lines.append(f"# TYPE {histogram.name} histogram")
        for label_key in histogram._observations:
            safe_label = label_key.replace('"', '\\"')
            prefix = (
                histogram.name
                if label_key == "__total__"
                else f'{histogram.name}{{label="{safe_label}"}}'
            )
            bucket_label = "" if label_key == "__total__" else f'label="{safe_label}",'
            for upper, count in histogram.bucket_counts(label_key):
                le_str = "+Inf" if upper == float("inf") else str(upper)
                lines.append(f'{histogram.name}_bucket{{{bucket_label}le="{le_str}"}} {count}')
            lines.append(f"{prefix}_count {histogram.count(label_key)}")
            lines.append(f"{prefix}_sum {histogram.total(label_key)}")
        if not histogram._observations:
            lines.append(f'{histogram.name}_bucket{{le="+Inf"}} 0')
            lines.append(f"{histogram.name}_count 0")
            lines.append(f"{histogram.name}_sum 0")
        lines.append("")
        return lines
