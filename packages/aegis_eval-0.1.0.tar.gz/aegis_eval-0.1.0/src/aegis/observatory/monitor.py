"""Observatory monitoring engine.

:class:`ObservatoryMonitor` provides runtime health checks for the
training pipeline, memory subsystem, and model behaviour.  Health
checks analyse provided metrics and flag anomalies such as reward
hacking, gradient instability, memory pressure, and distribution drift.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


@dataclass
class HealthCheckResult:
    """Result of a single observatory health check.

    Attributes:
        check_name: The name of the health check.
        healthy: Whether the check passed.
        score: Optional numeric health score in [0.0, 1.0].
        details: Arbitrary details about the check result.
        recommendations: Suggested remediation actions.
    """

    check_name: str
    healthy: bool
    score: float | None = None
    details: dict[str, Any] = field(default_factory=dict)
    recommendations: list[str] = field(default_factory=list)


class ObservatoryMonitor:
    """Runtime monitoring engine for the Aegis platform.

    Provides health checks for reward hacking, gradient health,
    memory subsystem integrity, and distribution drift.

    Args:
        config: Optional monitoring configuration.
    """

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self._config = config or {}

    def check_reward_hacking(
        self,
        reward_traces: list[dict[str, Any]] | None = None,
    ) -> HealthCheckResult:
        """Detect potential reward hacking in training traces.

        Looks for patterns such as reward inflation without corresponding
        quality improvements, reward oscillation, and reward-output
        decorrelation.

        Args:
            reward_traces: Optional list of recent reward trace
                dictionaries to analyse.

        Returns:
            A :class:`HealthCheckResult` indicating whether reward
            hacking is suspected.
        """
        if not reward_traces:
            return HealthCheckResult(
                check_name="reward_hacking",
                healthy=True,
                score=1.0,
                details={"traces_analysed": 0},
                recommendations=[],
            )

        rewards = [t["reward"] for t in reward_traces if "reward" in t]
        if not rewards:
            return HealthCheckResult(
                check_name="reward_hacking",
                healthy=True,
                score=1.0,
                details={"traces_analysed": len(reward_traces)},
                recommendations=[],
            )

        n = len(rewards)
        mean_reward = sum(rewards) / n
        variance = sum((r - mean_reward) ** 2 for r in rewards) / n
        stddev = math.sqrt(variance)

        issues: list[str] = []
        recommendations: list[str] = []

        # Detect inflation
        if mean_reward > 0.95 and stddev < 0.02:
            issues.append("reward_inflation")
            recommendations.append(
                "Reward values are suspiciously high with low variance. "
                "Investigate reward function for exploitation."
            )

        # Detect oscillation in last 10 values
        recent = rewards[-10:] if len(rewards) >= 10 else rewards
        if len(recent) >= 3:
            direction_changes = 0
            for i in range(1, len(recent) - 1):
                prev_dir = recent[i] - recent[i - 1]
                next_dir = recent[i + 1] - recent[i]
                if prev_dir * next_dir < 0:
                    direction_changes += 1
            if direction_changes > 5:
                issues.append("reward_oscillation")
                recommendations.append(
                    "Reward signal is oscillating rapidly. "
                    "Consider smoothing or adjusting learning rate."
                )

        # Detect decorrelation with quality
        qualities = [t["quality"] for t in reward_traces if "quality" in t]
        if len(qualities) == n and n > 1:
            mean_q = sum(qualities) / n
            cov = (
                sum(
                    (r - mean_reward) * (q - mean_q)
                    for r, q in zip(rewards, qualities, strict=False)
                )
                / n
            )
            var_q = sum((q - mean_q) ** 2 for q in qualities) / n
            denom = math.sqrt(variance * var_q)
            correlation = cov / denom if denom > 1e-10 else 0.0
            if correlation < 0.3:
                issues.append("reward_quality_decorrelation")
                recommendations.append(
                    f"Reward-quality correlation is low ({correlation:.2f}). "
                    "Rewards may not reflect actual output quality."
                )

        healthy = len(issues) == 0
        score = 1.0 if healthy else max(0.0, 1.0 - 0.33 * len(issues))

        return HealthCheckResult(
            check_name="reward_hacking",
            healthy=healthy,
            score=score,
            details={
                "traces_analysed": len(reward_traces),
                "mean_reward": mean_reward,
                "stddev": stddev,
                "issues": issues,
            },
            recommendations=recommendations,
        )

    def check_gradient_health(
        self,
        gradient_stats: dict[str, Any] | None = None,
    ) -> HealthCheckResult:
        """Check gradient norms and variance for training stability.

        Flags vanishing gradients, exploding gradients, and high
        gradient variance across parameter groups.

        Args:
            gradient_stats: Optional dictionary of gradient statistics
                (norms, variances, etc.) per parameter group.

        Returns:
            A :class:`HealthCheckResult` indicating gradient health.
        """
        if not gradient_stats:
            return HealthCheckResult(
                check_name="gradient_health",
                healthy=True,
                score=1.0,
                details={},
                recommendations=[],
            )

        norms = gradient_stats.get("norms", [])
        if not norms:
            return HealthCheckResult(
                check_name="gradient_health",
                healthy=True,
                score=1.0,
                details=gradient_stats,
                recommendations=[],
            )

        n = len(norms)
        mean_norm = sum(norms) / n
        variance = sum((x - mean_norm) ** 2 for x in norms) / n
        stdev_norm = math.sqrt(variance)

        issues: list[str] = []
        recommendations: list[str] = []
        severity = "healthy"

        # Detect vanishing gradients
        if mean_norm < 1e-7:
            issues.append("vanishing_gradients")
            recommendations.append(
                "Gradient norms are near zero. "
                "Consider gradient scaling, skip connections, or a higher learning rate."
            )
            severity = "critical"

        # Detect exploding gradients
        if mean_norm > 1e3:
            issues.append("exploding_gradients")
            recommendations.append(
                "Gradient norms are extremely large. "
                "Apply gradient clipping or reduce learning rate."
            )
            severity = "critical"

        # Detect high variance
        if mean_norm > 0 and stdev_norm > 10 * mean_norm:
            issues.append("high_gradient_variance")
            recommendations.append(
                "Gradient variance is very high relative to mean. "
                "Consider batch size increase or gradient accumulation."
            )
            if severity != "critical":
                severity = "warning"

        if not issues:
            score = 1.0
        elif severity == "warning":
            score = 0.5
        else:
            score = 0.0

        return HealthCheckResult(
            check_name="gradient_health",
            healthy=len(issues) == 0,
            score=score,
            details={
                "mean_norm": mean_norm,
                "stdev_norm": stdev_norm,
                "num_samples": n,
                "issues": issues,
                "severity": severity,
            },
            recommendations=recommendations,
        )

    def check_memory_health(
        self,
        memory_stats: dict[str, Any] | None = None,
    ) -> HealthCheckResult:
        """Assess the health of the memory subsystem.

        Checks for memory store capacity, stale entries, orphaned
        links, and tier imbalance.

        Args:
            memory_stats: Optional dictionary of memory store statistics.

        Returns:
            A :class:`HealthCheckResult` indicating memory health.
        """
        if not memory_stats:
            return HealthCheckResult(
                check_name="memory_health",
                healthy=True,
                score=1.0,
                details={},
                recommendations=[],
            )

        total_entries = memory_stats.get("total_entries", 0)
        capacity = memory_stats.get("capacity", 10000)
        stale_count = memory_stats.get("stale_count", 0)
        tier_counts: dict[str, int] = memory_stats.get("tier_counts", {})

        issues: list[str] = []
        recommendations: list[str] = []

        # Detect capacity pressure
        usage_ratio = total_entries / capacity if capacity > 0 else 0.0
        if usage_ratio > 0.9:
            issues.append("capacity_pressure")
            recommendations.append(
                f"Memory usage is at {usage_ratio:.0%} of capacity. "
                "Consider compressing, evicting stale entries, or increasing capacity."
            )

        # Detect staleness
        staleness_ratio = stale_count / max(total_entries, 1)
        if staleness_ratio > 0.3:
            issues.append("high_staleness")
            recommendations.append(
                f"Stale entries represent {staleness_ratio:.0%} of memory. "
                "Run garbage collection or re-validate stale entries."
            )

        # Detect tier imbalance
        if tier_counts and total_entries > 0:
            for tier_name, count in tier_counts.items():
                tier_ratio = count / total_entries
                if tier_ratio > 0.8:
                    issues.append("tier_imbalance")
                    recommendations.append(
                        f"Tier '{tier_name}' holds {tier_ratio:.0%} of all entries. "
                        "Review promotion/demotion policies for better distribution."
                    )
                    break

        healthy = len(issues) == 0
        score = 1.0 if healthy else max(0.0, 1.0 - 0.33 * len(issues))

        return HealthCheckResult(
            check_name="memory_health",
            healthy=healthy,
            score=score,
            details={
                "total_entries": total_entries,
                "capacity": capacity,
                "usage_ratio": usage_ratio,
                "stale_count": stale_count,
                "staleness_ratio": staleness_ratio,
                "tier_counts": tier_counts,
                "issues": issues,
            },
            recommendations=recommendations,
        )

    def check_drift(
        self,
        reference_distribution: dict[str, Any] | None = None,
        current_distribution: dict[str, Any] | None = None,
    ) -> HealthCheckResult:
        """Detect distribution drift between reference and current data.

        Compares score distributions, latency profiles, and error rates
        across evaluation runs to flag significant drift.

        Args:
            reference_distribution: Baseline distribution statistics.
            current_distribution: Current distribution statistics.

        Returns:
            A :class:`HealthCheckResult` indicating whether drift
            exceeds configured thresholds.
        """
        if not reference_distribution or not current_distribution:
            return HealthCheckResult(
                check_name="drift",
                healthy=True,
                score=1.0,
                details={
                    "reference": reference_distribution or {},
                    "current": current_distribution or {},
                },
                recommendations=[],
            )

        ref_mean = reference_distribution.get("mean", 0.0)
        ref_variance = reference_distribution.get("variance", 0.0)
        cur_mean = current_distribution.get("mean", 0.0)

        ref_std = math.sqrt(ref_variance) if ref_variance > 0 else 0.0
        z_score = abs(cur_mean - ref_mean) / max(ref_std, 1e-10)

        issues: list[str] = []
        recommendations: list[str] = []
        ks_stat = 0.0

        # Z-score drift detection
        if z_score > 2.0:
            issues.append("mean_drift")
            recommendations.append(
                f"Distribution mean has shifted significantly (z={z_score:.2f}). "
                "Investigate data pipeline or upstream model changes."
            )

        # KS statistic if both have values
        ref_values = reference_distribution.get("values")
        cur_values = current_distribution.get("values")
        if ref_values and cur_values:
            sorted_ref = sorted(ref_values)
            sorted_cur = sorted(cur_values)
            n_ref = len(sorted_ref)
            n_cur = len(sorted_cur)

            # Merge all unique values and compute CDF difference
            all_values = sorted(set(sorted_ref + sorted_cur))
            max_diff = 0.0
            for v in all_values:
                # CDF for reference: proportion of ref values <= v
                ref_cdf = sum(1 for x in sorted_ref if x <= v) / n_ref
                cur_cdf = sum(1 for x in sorted_cur if x <= v) / n_cur
                diff = abs(ref_cdf - cur_cdf)
                if diff > max_diff:
                    max_diff = diff
            ks_stat = max_diff

            if ks_stat > 0.2:
                issues.append("distribution_drift")
                recommendations.append(
                    f"KS statistic is {ks_stat:.3f}, indicating significant "
                    "distributional drift. Review data quality and sampling."
                )

        score = 1.0 - min(1.0, max(z_score / 4.0, ks_stat))
        healthy = len(issues) == 0

        return HealthCheckResult(
            check_name="drift",
            healthy=healthy,
            score=score,
            details={
                "reference_mean": ref_mean,
                "current_mean": cur_mean,
                "z_score": z_score,
                "ks_stat": ks_stat,
                "issues": issues,
            },
            recommendations=recommendations,
        )

    def run_all_checks(self) -> list[HealthCheckResult]:
        """Run all observatory health checks and return the results.

        Returns:
            A list of :class:`HealthCheckResult` instances, one per
            check.
        """
        return [
            self.check_reward_hacking(),
            self.check_gradient_health(),
            self.check_memory_health(),
            self.check_drift(),
        ]
