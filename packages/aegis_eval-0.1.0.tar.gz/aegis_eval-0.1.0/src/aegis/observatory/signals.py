"""Signal collection and aggregation for the observatory.

Collects metrics from multiple sources (training, memory, retrieval,
eval) and aggregates them for health check consumption.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class Signal:
    """A single metric signal from a monitored source."""

    name: str
    value: float
    source: str = ""  # "training", "memory", "retrieval", "eval"
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


class SignalCollector:
    """Collects and aggregates signals from multiple sources.

    Maintains sliding windows of recent signal values for each
    signal name, enabling trend analysis and anomaly detection.
    """

    def __init__(self, window_size: int = 100) -> None:
        self._window_size = window_size
        self._windows: dict[str, deque[Signal]] = defaultdict(lambda: deque(maxlen=window_size))
        self._total_collected: int = 0

    def record(
        self,
        name: str,
        value: float,
        source: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Signal:
        """Record a signal value."""
        signal = Signal(name=name, value=value, source=source, metadata=metadata or {})
        self._windows[name].append(signal)
        self._total_collected += 1
        return signal

    def record_batch(self, signals: list[dict[str, Any]]) -> int:
        """Record multiple signals at once."""
        count = 0
        for s in signals:
            self.record(
                name=s.get("name", ""),
                value=s.get("value", 0.0),
                source=s.get("source", ""),
                metadata=s.get("metadata"),
            )
            count += 1
        return count

    def get_values(self, name: str, limit: int | None = None) -> list[float]:
        """Get recent values for a signal."""
        window = self._windows.get(name, deque())
        values = [s.value for s in window]
        if limit:
            return values[-limit:]
        return values

    def get_stats(self, name: str) -> dict[str, Any]:
        """Get statistics for a signal."""
        values = self.get_values(name)
        if not values:
            return {"name": name, "count": 0}

        n = len(values)
        mean = sum(values) / n
        variance = sum((v - mean) ** 2 for v in values) / n

        return {
            "name": name,
            "count": n,
            "mean": round(mean, 6),
            "min": round(min(values), 6),
            "max": round(max(values), 6),
            "variance": round(variance, 6),
            "latest": round(values[-1], 6),
        }

    def as_health_check_input(self) -> dict[str, dict[str, Any]]:
        """Format collected signals as inputs for observatory health checks.

        Returns a dict keyed by check type with appropriate data format.
        """
        result: dict[str, dict[str, Any]] = {}

        # Reward traces
        reward_values = self.get_values("reward")
        quality_values = self.get_values("quality")
        if reward_values:
            traces = []
            for i, r in enumerate(reward_values):
                trace: dict[str, Any] = {"reward": r}
                if i < len(quality_values):
                    trace["quality"] = quality_values[i]
                traces.append(trace)
            result["reward_traces"] = {"traces": traces}

        # Gradient stats
        grad_norms = self.get_values("gradient_norm")
        if grad_norms:
            result["gradient_stats"] = {"norms": grad_norms}

        # Memory stats
        mem_total = self.get_values("memory_total_entries")
        mem_capacity = self.get_values("memory_capacity")
        mem_stale = self.get_values("memory_stale_count")
        if mem_total:
            result["memory_stats"] = {
                "total_entries": int(mem_total[-1]) if mem_total else 0,
                "capacity": int(mem_capacity[-1]) if mem_capacity else 10000,
                "stale_count": int(mem_stale[-1]) if mem_stale else 0,
            }

        return result

    def signal_names(self) -> list[str]:
        """Return all signal names being tracked."""
        return list(self._windows.keys())

    def clear(self, name: str | None = None) -> None:
        """Clear signals for a name or all."""
        if name:
            self._windows.pop(name, None)
        else:
            self._windows.clear()
            self._total_collected = 0

    def summary(self) -> dict[str, Any]:
        """Return signal collector summary."""
        return {
            "total_collected": self._total_collected,
            "signal_names": len(self._windows),
            "signals": {
                name: {"count": len(window), "latest": window[-1].value if window else None}
                for name, window in self._windows.items()
            },
        }
