"""Automatic intervention engine for training anomalies.

Takes outputs from the anomaly detector, hacking atlas, and Goodhart
monitor and determines corrective actions.  Respects per-policy
cooldowns and maximum-application limits to prevent intervention storms.
"""

from __future__ import annotations

import enum
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, cast

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class InterventionType(enum.Enum):
    """Corrective actions the engine can recommend or apply."""

    REDUCE_LR = "reduce_lr"
    INCREASE_LR = "increase_lr"
    ROLLBACK_CHECKPOINT = "rollback_checkpoint"
    INJECT_DIVERSE_PROMPTS = "inject_diverse_prompts"
    REDUCE_MEMORY_REWARD_WEIGHT = "reduce_memory_reward_weight"
    INCREASE_CITATION_REWARD = "increase_citation_reward"
    INCREASE_ENTROPY_TEMP = "increase_entropy_temp"
    EARLY_STOP = "early_stop"
    PAUSE_AND_EVAL = "pause_and_eval"
    SWITCH_OPTIMIZER = "switch_optimizer"
    REDUCE_BATCH_SIZE = "reduce_batch_size"


@dataclass
class Intervention:
    """A single corrective intervention."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: InterventionType = InterventionType.PAUSE_AND_EVAL
    trigger: str = ""
    severity: float = 0.0  # 0.0 – 1.0
    config_changes: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    applied: bool = False
    result: dict[str, Any] | None = None


@dataclass
class InterventionPolicy:
    """A rule mapping a trigger condition to an intervention type."""

    name: str
    trigger_conditions: dict[str, Any]
    intervention_type: InterventionType
    config_changes: dict[str, Any] = field(default_factory=dict)
    cooldown_seconds: int = 300
    max_applications: int = 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _matches_anomaly(policy: InterventionPolicy, anomaly: Any) -> bool:
    """Check if *anomaly* matches the policy's trigger conditions.

    Only policies whose trigger_conditions contain ``anomaly_type`` are
    eligible for anomaly matching.  Expects *anomaly* to have ``type``
    (with a ``.value`` attribute) and ``severity`` attributes.
    """
    conds = policy.trigger_conditions
    required_type = conds.get("anomaly_type")
    if required_type is None:
        # This policy is not anomaly-driven (e.g. hacking or goodhart).
        return False

    min_severity = float(conds.get("min_severity", 0.0))

    anomaly_type_val = getattr(anomaly, "type", None)
    if anomaly_type_val is not None:
        anomaly_type_val = getattr(anomaly_type_val, "value", anomaly_type_val)

    if anomaly_type_val != required_type:
        return False

    anomaly_severity = float(getattr(anomaly, "severity", 0.0))
    return anomaly_severity >= min_severity


def _matches_hacking(policy: InterventionPolicy, result: Any) -> bool:
    """Check if a hacking detection result matches the policy.

    Only policies whose trigger_conditions contain ``pattern_id`` are
    eligible for hacking-result matching.
    """
    conds = policy.trigger_conditions
    required_pattern = conds.get("pattern_id")
    if required_pattern is None:
        # This policy is not hacking-driven.
        return False

    min_confidence = float(conds.get("min_confidence", 0.0))

    if getattr(result, "pattern_id", None) != required_pattern:
        return False

    if not bool(getattr(result, "detected", False)):
        return False

    return float(getattr(result, "confidence", 0.0)) >= min_confidence


def _matches_goodhart(policy: InterventionPolicy, warning: Any) -> bool:
    """Check if a Goodhart warning matches the policy."""
    conds = policy.trigger_conditions
    if not conds.get("goodhart_divergence"):
        return False
    if warning is None:
        return False
    min_divergence = float(conds.get("min_divergence", 0.0))
    divergence = cast("float", getattr(warning, "divergence", 0.0))
    return abs(divergence) >= min_divergence


# ---------------------------------------------------------------------------
# Default policies
# ---------------------------------------------------------------------------


def _default_policies() -> list[InterventionPolicy]:
    """Return the built-in intervention policies."""
    return [
        # 1) Entropy collapse -> increase temperature
        InterventionPolicy(
            name="entropy_collapse",
            trigger_conditions={
                "anomaly_type": "entropy_collapse",
                "min_severity": 0.3,
            },
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
            config_changes={
                "temperature_delta": 0.1,
                "entropy_bonus_delta": 0.02,
            },
            cooldown_seconds=600,
            max_applications=5,
        ),
        # 2) Gradient spike -> rollback + reduce LR
        InterventionPolicy(
            name="gradient_spike",
            trigger_conditions={
                "anomaly_type": "gradient_spike",
                "min_severity": 0.4,
            },
            intervention_type=InterventionType.ROLLBACK_CHECKPOINT,
            config_changes={
                "rollback": True,
                "lr_factor": 0.5,
            },
            cooldown_seconds=900,
            max_applications=3,
        ),
        # 3) Reward hacking detected -> reduce memory reward weight
        InterventionPolicy(
            name="reward_hacking_detected",
            trigger_conditions={
                "pattern_id": "memory_gaming",
                "min_confidence": 0.5,
            },
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
            config_changes={
                "memory_reward_weight_delta": -0.05,
            },
            cooldown_seconds=600,
            max_applications=4,
        ),
        # 4) Goodhart divergence -> early stop
        InterventionPolicy(
            name="goodhart_divergence",
            trigger_conditions={
                "goodhart_divergence": True,
                "min_divergence": 0.15,
            },
            intervention_type=InterventionType.EARLY_STOP,
            config_changes={
                "early_stop": True,
                "reason": "goodhart_divergence",
            },
            cooldown_seconds=0,
            max_applications=1,
        ),
        # 5) Citation decline -> increase citation reward
        InterventionPolicy(
            name="citation_decline",
            trigger_conditions={
                "anomaly_type": "citation_anomaly",
                "min_severity": 0.3,
            },
            intervention_type=InterventionType.INCREASE_CITATION_REWARD,
            config_changes={
                "citation_validity_weight_delta": 0.05,
                "hallucination_penalty_delta": 0.03,
            },
            cooldown_seconds=600,
            max_applications=4,
        ),
        # 6) Memory gaming -> reduce memory reward + inject diverse prompts
        InterventionPolicy(
            name="memory_gaming",
            trigger_conditions={
                "pattern_id": "memory_gaming",
                "min_confidence": 0.4,
            },
            intervention_type=InterventionType.INJECT_DIVERSE_PROMPTS,
            config_changes={
                "memory_reward_weight_delta": -0.03,
                "inject_diverse_prompts": True,
                "prompt_diversity_multiplier": 1.5,
            },
            cooldown_seconds=300,
            max_applications=5,
        ),
        # 7) Training stall (vanishing gradients) -> switch optimizer
        InterventionPolicy(
            name="training_stall",
            trigger_conditions={
                "anomaly_type": "gradient_vanish",
                "min_severity": 0.5,
            },
            intervention_type=InterventionType.SWITCH_OPTIMIZER,
            config_changes={
                "optimizer": "adamw",
                "lr_factor": 2.0,
            },
            cooldown_seconds=1800,
            max_applications=2,
        ),
        # 8) Loss spike -> reduce LR + reduce batch size
        InterventionPolicy(
            name="loss_spike",
            trigger_conditions={
                "anomaly_type": "reward_collapse",
                "min_severity": 0.5,
            },
            intervention_type=InterventionType.REDUCE_LR,
            config_changes={
                "lr_factor": 0.3,
                "batch_size_factor": 0.5,
            },
            cooldown_seconds=600,
            max_applications=3,
        ),
    ]


# ---------------------------------------------------------------------------
# AutoInterventionEngine
# ---------------------------------------------------------------------------


class AutoInterventionEngine:
    """Automatic intervention engine.

    Evaluates anomaly detections, reward hacking results, and Goodhart
    warnings against a set of configurable policies and emits
    interventions.  Respects per-policy cooldowns and application limits.
    """

    def __init__(self, policies: list[InterventionPolicy] | None = None) -> None:
        self._policies: list[InterventionPolicy] = (
            list(policies) if policies else _default_policies()
        )
        self._history: list[Intervention] = []
        # Track cooldowns: policy_name -> last application timestamp
        self._last_applied: dict[str, datetime] = {}
        # Track application counts: policy_name -> count
        self._apply_counts: dict[str, int] = defaultdict(int)

    # -- Public API ---------------------------------------------------------

    def evaluate(
        self,
        anomalies: list[Any] | None = None,
        hacking_results: list[Any] | None = None,
        goodhart_warning: Any | None = None,
    ) -> list[Intervention]:
        """Evaluate all inputs and determine interventions.

        *anomalies*: list of :class:`~aegis.observatory.anomaly_detector.Anomaly`
        *hacking_results*: list of :class:`~aegis.observatory.hacking_atlas.DetectionResult`
        *goodhart_warning*: optional :class:`~aegis.observatory.goodhart.GoodhartWarning`

        Returns interventions that should be applied, respecting cooldowns
        and max application limits.
        """
        anomalies = anomalies or []
        hacking_results = hacking_results or []

        interventions: list[Intervention] = []
        now = datetime.now(tz=UTC)

        for policy in self._policies:
            # --- Respect cooldown ---
            if not self._is_available(policy, now):
                continue

            # --- Match against anomalies ---
            triggered = False
            trigger_desc = ""
            trigger_severity = 0.0

            for anomaly in anomalies:
                if _matches_anomaly(policy, anomaly):
                    triggered = True
                    trigger_desc = (
                        f"anomaly:{getattr(getattr(anomaly, 'type', ''), 'value', str(anomaly))}"
                    )
                    trigger_severity = max(trigger_severity, getattr(anomaly, "severity", 0.5))
                    break

            # --- Match against hacking results ---
            if not triggered:
                for result in hacking_results:
                    if _matches_hacking(policy, result):
                        triggered = True
                        trigger_desc = f"hacking:{getattr(result, 'pattern_id', 'unknown')}"
                        trigger_severity = max(trigger_severity, getattr(result, "confidence", 0.5))
                        break

            # --- Match against Goodhart warning ---
            if not triggered and _matches_goodhart(policy, goodhart_warning):
                triggered = True
                trigger_desc = "goodhart_divergence"
                trigger_severity = max(
                    trigger_severity,
                    min(1.0, abs(getattr(goodhart_warning, "divergence", 0.0)) * 3),
                )

            if triggered:
                intervention = Intervention(
                    type=policy.intervention_type,
                    trigger=f"{policy.name}:{trigger_desc}",
                    severity=round(trigger_severity, 4),
                    config_changes=dict(policy.config_changes),
                )
                interventions.append(intervention)
                self._history.append(intervention)
                self._last_applied[policy.name] = now
                self._apply_counts[policy.name] += 1

        return interventions

    def apply(self, intervention: Intervention) -> dict[str, Any]:
        """Mark *intervention* as applied and return its config changes.

        In a real training loop the caller would use the returned
        config changes to update hyper-parameters.
        """
        intervention.applied = True
        intervention.result = {
            "status": "applied",
            "config_changes": dict(intervention.config_changes),
            "applied_at": datetime.now(tz=UTC).isoformat(),
        }
        return dict(intervention.config_changes)

    def register_policy(self, policy: InterventionPolicy) -> None:
        """Add a custom policy."""
        self._policies.append(policy)

    def intervention_history(self) -> list[Intervention]:
        """Full history of interventions created by this engine."""
        return list(self._history)

    def active_cooldowns(self) -> dict[str, Any]:
        """Return policies currently in cooldown with remaining seconds."""
        now = datetime.now(tz=UTC)
        cooldowns: dict[str, Any] = {}
        for policy in self._policies:
            last = self._last_applied.get(policy.name)
            if last is None:
                continue
            elapsed = (now - last).total_seconds()
            remaining = policy.cooldown_seconds - elapsed
            if remaining > 0:
                cooldowns[policy.name] = {
                    "remaining_seconds": round(remaining, 1),
                    "cooldown_seconds": policy.cooldown_seconds,
                    "last_applied": last.isoformat(),
                }
        return cooldowns

    def summary(self) -> dict[str, Any]:
        """Condensed engine summary."""
        by_type: dict[str, int] = defaultdict(int)
        applied_count = 0
        for intervention in self._history:
            by_type[intervention.type.value] += 1
            if intervention.applied:
                applied_count += 1

        return {
            "total_policies": len(self._policies),
            "total_interventions": len(self._history),
            "applied": applied_count,
            "pending": len(self._history) - applied_count,
            "by_type": dict(by_type),
            "application_counts": dict(self._apply_counts),
            "active_cooldowns": len(self.active_cooldowns()),
        }

    # -- Internals ----------------------------------------------------------

    def _is_available(self, policy: InterventionPolicy, now: datetime) -> bool:
        """Check if *policy* is not in cooldown and hasn't exceeded max applications."""
        # Max applications check
        if self._apply_counts[policy.name] >= policy.max_applications:
            return False

        # Cooldown check
        last = self._last_applied.get(policy.name)
        if last is not None:
            elapsed = (now - last).total_seconds()
            if elapsed < policy.cooldown_seconds:
                return False

        return True
