"""Automatic intervention engine for the Aegis observatory.

When health checks detect anomalies, the intervention engine determines
and executes corrective actions such as learning rate adjustments,
checkpoint rollbacks, or alert escalations.
"""

from __future__ import annotations

import uuid
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.observatory.monitor import HealthCheckResult


@dataclass
class Intervention:
    """A corrective action triggered by a health check anomaly."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    trigger_check: str = ""
    intervention_type: str = ""  # "lr_adjustment", "checkpoint_rollback", "alert_escalation", "pause_training", "memory_gc"
    severity: str = "warning"
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    executed: bool = False
    result: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


@dataclass
class InterventionRule:
    """A rule mapping health check results to interventions."""

    check_name: str
    condition: Callable[[HealthCheckResult], bool]
    intervention_type: str
    severity: str = "warning"
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    cooldown_seconds: int = 300
    enabled: bool = True


class InterventionEngine:
    """Determines and tracks corrective actions from health check anomalies.

    Supports configurable rules that map health check results to
    intervention actions. Includes cooldown to prevent intervention storms.
    """

    def __init__(self) -> None:
        self._rules: list[InterventionRule] = []
        self._history: list[Intervention] = []
        self._last_intervention: dict[str, datetime] = {}
        self._setup_default_rules()

    def _setup_default_rules(self) -> None:
        """Set up default intervention rules."""
        self._rules = [
            # Reward hacking interventions
            InterventionRule(
                check_name="reward_hacking",
                condition=lambda r: (
                    not r.healthy and "reward_inflation" in r.details.get("issues", [])
                ),
                intervention_type="pause_training",
                severity="critical",
                description="Pause training due to reward inflation detected",
                parameters={"action": "pause", "reason": "reward_inflation"},
            ),
            InterventionRule(
                check_name="reward_hacking",
                condition=lambda r: (
                    not r.healthy and "reward_oscillation" in r.details.get("issues", [])
                ),
                intervention_type="lr_adjustment",
                severity="warning",
                description="Reduce learning rate due to reward oscillation",
                parameters={"factor": 0.5, "reason": "reward_oscillation"},
            ),
            # Gradient health interventions
            InterventionRule(
                check_name="gradient_health",
                condition=lambda r: (
                    not r.healthy and "exploding_gradients" in r.details.get("issues", [])
                ),
                intervention_type="lr_adjustment",
                severity="critical",
                description="Reduce learning rate due to exploding gradients",
                parameters={"factor": 0.1, "max_norm": 1.0},
            ),
            InterventionRule(
                check_name="gradient_health",
                condition=lambda r: (
                    not r.healthy and "vanishing_gradients" in r.details.get("issues", [])
                ),
                intervention_type="lr_adjustment",
                severity="warning",
                description="Increase learning rate due to vanishing gradients",
                parameters={"factor": 2.0},
            ),
            # Memory health interventions
            InterventionRule(
                check_name="memory_health",
                condition=lambda r: (
                    not r.healthy and "capacity_pressure" in r.details.get("issues", [])
                ),
                intervention_type="memory_gc",
                severity="warning",
                description="Run memory garbage collection due to capacity pressure",
                parameters={"action": "compress_and_evict"},
            ),
            InterventionRule(
                check_name="memory_health",
                condition=lambda r: (
                    not r.healthy and "high_staleness" in r.details.get("issues", [])
                ),
                intervention_type="memory_gc",
                severity="warning",
                description="Clean stale memory entries",
                parameters={"action": "evict_stale"},
            ),
            # Drift interventions
            InterventionRule(
                check_name="drift",
                condition=lambda r: not r.healthy and r.details.get("z_score", 0) > 3.0,
                intervention_type="alert_escalation",
                severity="critical",
                description="Escalate alert due to severe distribution drift",
                parameters={"escalation_level": "critical"},
            ),
            InterventionRule(
                check_name="drift",
                condition=lambda r: (
                    not r.healthy and "distribution_drift" in r.details.get("issues", [])
                ),
                intervention_type="checkpoint_rollback",
                severity="warning",
                description="Consider rollback due to distribution drift",
                parameters={"action": "suggest_rollback"},
            ),
        ]

    def add_rule(self, rule: InterventionRule) -> None:
        """Add an intervention rule."""
        self._rules.append(rule)

    def evaluate(self, check_result: HealthCheckResult) -> list[Intervention]:
        """Evaluate a health check result and trigger matching interventions."""
        interventions: list[Intervention] = []
        now = datetime.now(tz=UTC)

        for rule in self._rules:
            if not rule.enabled:
                continue
            if rule.check_name != check_result.check_name:
                continue

            # Check cooldown
            cooldown_key = f"{rule.check_name}:{rule.intervention_type}"
            last = self._last_intervention.get(cooldown_key)
            if last and (now - last).total_seconds() < rule.cooldown_seconds:
                continue

            # Check condition
            try:
                if rule.condition(check_result):
                    intervention = Intervention(
                        trigger_check=rule.check_name,
                        intervention_type=rule.intervention_type,
                        severity=rule.severity,
                        description=rule.description,
                        parameters=dict(rule.parameters),
                    )
                    interventions.append(intervention)
                    self._history.append(intervention)
                    self._last_intervention[cooldown_key] = now
            except Exception:
                pass  # Skip rules that fail evaluation

        return interventions

    def evaluate_all(self, check_results: list[HealthCheckResult]) -> list[Intervention]:
        """Evaluate multiple health check results."""
        all_interventions: list[Intervention] = []
        for result in check_results:
            all_interventions.extend(self.evaluate(result))
        return all_interventions

    def mark_executed(self, intervention_id: str, result: dict[str, Any] | None = None) -> bool:
        """Mark an intervention as executed."""
        for intervention in self._history:
            if intervention.id == intervention_id:
                intervention.executed = True
                intervention.result = result or {}
                return True
        return False

    def history(self, limit: int = 100) -> list[Intervention]:
        """Return intervention history."""
        return self._history[-limit:]

    def pending(self) -> list[Intervention]:
        """Return interventions that haven't been executed."""
        return [i for i in self._history if not i.executed]

    def summary(self) -> dict[str, Any]:
        """Return intervention engine summary."""
        by_type: dict[str, int] = defaultdict(int)
        for intervention in self._history:
            by_type[intervention.intervention_type] += 1

        return {
            "total_rules": len(self._rules),
            "total_interventions": len(self._history),
            "pending": len(self.pending()),
            "executed": sum(1 for i in self._history if i.executed),
            "by_type": dict(by_type),
        }
