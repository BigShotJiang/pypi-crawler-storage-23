"""Behavioral anomaly detection engine for the Aegis observatory.

Uses z-score analysis, linear regression, and variance tracking to
detect reward spikes/collapses, entropy collapse, gradient pathologies,
response length inflation, and citation anomalies in training signal
streams.
"""

from __future__ import annotations

import enum
import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class AnomalyType(enum.Enum):
    """Categories of behavioral anomalies detected during training."""

    REWARD_SPIKE = "reward_spike"
    REWARD_COLLAPSE = "reward_collapse"
    ENTROPY_COLLAPSE = "entropy_collapse"
    GRADIENT_SPIKE = "gradient_spike"
    GRADIENT_VANISH = "gradient_vanish"
    MEMORY_PRESSURE = "memory_pressure"
    DRIFT_DETECTED = "drift_detected"
    LENGTH_ANOMALY = "length_anomaly"
    CITATION_ANOMALY = "citation_anomaly"
    POLICY_DIVERGENCE = "policy_divergence"


@dataclass
class Anomaly:
    """A single detected anomaly in a signal stream."""

    type: AnomalyType
    severity: float  # 0.0 – 1.0
    timestamp: datetime
    metric_name: str
    metric_value: float
    threshold: float
    window_values: list[float] = field(default_factory=list)
    description: str = ""
    recommended_action: str = ""


# ---------------------------------------------------------------------------
# Statistical helpers
# ---------------------------------------------------------------------------


def _safe_mean(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _safe_stdev(vals: list[float]) -> float:
    if len(vals) < 2:
        return 0.0
    m = _safe_mean(vals)
    return math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1))


def _compute_z_score_for(values: list[float], current: float) -> float:
    """Standard z-score of *current* relative to *values*.

    When the window has zero variance (all identical values), returns
    ``float('inf')`` (signed) if *current* differs from the mean,
    ensuring obvious anomalies in flat baselines are never missed.
    """
    if len(values) < 2:
        return 0.0
    m = _safe_mean(values)
    s = _safe_stdev(values)
    if s < 1e-12:
        # Zero-variance window: any deviation is infinitely unlikely
        diff = current - m
        if abs(diff) < 1e-12:
            return 0.0
        return math.copysign(float("inf"), diff)
    return (current - m) / s


def _compute_trend(values: list[float]) -> float:
    """Linear regression slope of *values* against their index."""
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(values) / n
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den if den > 0 else 0.0


def _ks_two_sample(a: list[float], b: list[float]) -> float:
    """Two-sample Kolmogorov-Smirnov statistic."""
    if not a or not b:
        return 0.0
    sa = sorted(a)
    sb = sorted(b)
    na, nb = len(sa), len(sb)
    all_vals = sorted(set(sa + sb))
    max_diff = 0.0
    for v in all_vals:
        cdf_a = sum(1 for x in sa if x <= v) / na
        cdf_b = sum(1 for x in sb if x <= v) / nb
        diff = abs(cdf_a - cdf_b)
        if diff > max_diff:
            max_diff = diff
    return max_diff


# ---------------------------------------------------------------------------
# Default configuration
# ---------------------------------------------------------------------------

_DEFAULT_CONFIG: dict[str, Any] = {
    # Reward anomaly thresholds
    "reward_z_threshold": 3.0,
    "reward_collapse_z_threshold": -3.0,
    # Entropy
    "entropy_min": 0.1,
    # Gradients
    "gradient_vanish_threshold": 1e-7,
    "gradient_spike_threshold": 100.0,
    # Length
    "length_slope_threshold": 0.5,  # tokens/step
    "length_min_window": 10,
    # Citation
    "citation_validity_drop_threshold": 0.15,
    # Memory
    "memory_pressure_threshold": 0.90,
    # Policy divergence (KS stat)
    "kl_divergence_threshold": 0.25,
}


# ---------------------------------------------------------------------------
# AnomalyDetector
# ---------------------------------------------------------------------------


class AnomalyDetector:
    """Behavioral anomaly detection engine.

    Accepts time-series signal dicts and runs statistical anomaly
    detectors for rewards, entropy, gradients, length trends,
    citation validity, memory pressure, and policy divergence.
    """

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        self._config: dict[str, Any] = {**_DEFAULT_CONFIG, **(config or {})}
        self._history: list[Anomaly] = []

    # -- Public API ---------------------------------------------------------

    def detect_anomalies(self, signals: dict[str, list[float]]) -> list[Anomaly]:
        """Run all anomaly detectors on *signals* and return detected anomalies.

        *signals* is a dict mapping signal names to lists of recent values.
        Recognized signal names:

        - ``reward``: reward values per step
        - ``entropy``: policy entropy per step
        - ``gradient_norm``: gradient L2 norms per step
        - ``response_length``: token count per response
        - ``citation_validity``: fraction of valid citations per step
        - ``citation_count``: citation count per step
        - ``memory_usage``: memory store usage ratio (0-1)
        - ``policy_logprobs``: per-step mean log probs (for divergence)
        - ``reference_logprobs``: reference policy log probs (for divergence)
        """
        anomalies: list[Anomaly] = []

        if "reward" in signals:
            anomalies.extend(self._check_reward_anomalies(signals["reward"]))

        if "entropy" in signals:
            anomalies.extend(self._check_entropy(signals["entropy"]))

        if "gradient_norm" in signals:
            anomalies.extend(self._check_gradients(signals["gradient_norm"]))

        if "response_length" in signals:
            anomalies.extend(self._check_length_trends(signals["response_length"]))

        if "citation_validity" in signals:
            counts = signals.get("citation_count", [])
            anomalies.extend(self._check_citation_trends(signals["citation_validity"], counts))

        if "memory_usage" in signals:
            anomalies.extend(self._check_memory_pressure(signals["memory_usage"]))

        if "policy_logprobs" in signals and "reference_logprobs" in signals:
            anomalies.extend(
                self._check_policy_divergence(
                    signals["policy_logprobs"], signals["reference_logprobs"]
                )
            )

        self._history.extend(anomalies)
        return anomalies

    @property
    def anomaly_history(self) -> list[Anomaly]:
        """All anomalies detected across the lifetime of this detector."""
        return list(self._history)

    def summary(self) -> dict[str, Any]:
        """Return a summary of detection activity."""
        by_type: dict[str, int] = {}
        for a in self._history:
            key = a.type.value
            by_type[key] = by_type.get(key, 0) + 1
        return {
            "total_detected": len(self._history),
            "by_type": by_type,
            "config": dict(self._config),
        }

    # -- Static helpers exposed for external use ----------------------------

    @staticmethod
    def _compute_z_score(values: list[float], current: float) -> float:
        """Standard z-score of *current* relative to *values*."""
        return _compute_z_score_for(values, current)

    @staticmethod
    def _compute_trend(values: list[float]) -> float:
        """Linear regression slope of *values* against their index."""
        return _compute_trend(values)

    # -- Internal detectors -------------------------------------------------

    def _check_reward_anomalies(self, values: list[float]) -> list[Anomaly]:
        """Z-score based spike and collapse detection on reward signal."""
        if len(values) < 5:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        z_spike = self._config["reward_z_threshold"]
        z_collapse = self._config["reward_collapse_z_threshold"]

        # Use all-but-last values as the reference window
        window = values[:-1]
        current = values[-1]
        z = _compute_z_score_for(window, current)

        if z > z_spike:
            severity = min(1.0, (z - z_spike) / z_spike)
            anomalies.append(
                Anomaly(
                    type=AnomalyType.REWARD_SPIKE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="reward",
                    metric_value=current,
                    threshold=z_spike,
                    window_values=list(window[-20:]),
                    description=(
                        f"Reward spiked to {current:.4f} (z={z:.2f}, "
                        f"threshold={z_spike}). Possible reward exploitation."
                    ),
                    recommended_action="Inspect reward function for exploits; consider reward clipping.",
                )
            )

        if z < z_collapse:
            severity = min(1.0, abs(z - z_collapse) / abs(z_collapse))
            anomalies.append(
                Anomaly(
                    type=AnomalyType.REWARD_COLLAPSE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="reward",
                    metric_value=current,
                    threshold=z_collapse,
                    window_values=list(window[-20:]),
                    description=(
                        f"Reward collapsed to {current:.4f} (z={z:.2f}, "
                        f"threshold={z_collapse}). Possible training instability."
                    ),
                    recommended_action="Reduce learning rate and check for data pipeline issues.",
                )
            )

        return anomalies

    def _check_entropy(self, values: list[float]) -> list[Anomaly]:
        """Detect policy entropy collapse (below minimum threshold)."""
        if len(values) < 3:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        entropy_min = self._config["entropy_min"]

        # Check both latest value and trend
        current = values[-1]
        trend = _compute_trend(values)

        if current < entropy_min:
            # Severity scales with how far below the floor we are
            severity = min(1.0, (entropy_min - current) / max(entropy_min, 1e-6))
            anomalies.append(
                Anomaly(
                    type=AnomalyType.ENTROPY_COLLAPSE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="entropy",
                    metric_value=current,
                    threshold=entropy_min,
                    window_values=list(values[-20:]),
                    description=(
                        f"Policy entropy dropped to {current:.6f} (min={entropy_min}). "
                        f"Trend slope={trend:.6f}. Agent may be mode-collapsing."
                    ),
                    recommended_action=(
                        "Increase temperature or add an entropy bonus to the reward. "
                        "Consider KL penalty against reference policy."
                    ),
                )
            )
        elif trend < -0.01 and current < entropy_min * 2:
            # Entropy is declining fast and approaching the floor
            severity = min(1.0, abs(trend) * 10)
            anomalies.append(
                Anomaly(
                    type=AnomalyType.ENTROPY_COLLAPSE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="entropy",
                    metric_value=current,
                    threshold=entropy_min,
                    window_values=list(values[-20:]),
                    description=(
                        f"Entropy declining rapidly (slope={trend:.6f}, current={current:.6f}). "
                        f"Approaching collapse threshold {entropy_min}."
                    ),
                    recommended_action="Pre-emptively increase entropy coefficient before collapse.",
                )
            )

        return anomalies

    def _check_gradients(self, values: list[float]) -> list[Anomaly]:
        """Detect vanishing (<1e-7) and exploding (>100) gradient norms."""
        if len(values) < 3:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        vanish_threshold = self._config["gradient_vanish_threshold"]
        spike_threshold = self._config["gradient_spike_threshold"]

        current = values[-1]

        if current < vanish_threshold:
            severity = min(1.0, vanish_threshold / max(current, 1e-15))
            # Cap at 1.0
            severity = min(severity, 1.0)
            anomalies.append(
                Anomaly(
                    type=AnomalyType.GRADIENT_VANISH,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="gradient_norm",
                    metric_value=current,
                    threshold=vanish_threshold,
                    window_values=list(values[-20:]),
                    description=(
                        f"Gradient norm is {current:.2e}, below vanishing threshold "
                        f"{vanish_threshold:.0e}. Training is effectively stalled."
                    ),
                    recommended_action=(
                        "Increase learning rate, check for dead ReLU, "
                        "or add skip connections / gradient scaling."
                    ),
                )
            )

        if current > spike_threshold:
            severity = min(1.0, math.log10(max(current / spike_threshold, 1.0)) / 3)
            anomalies.append(
                Anomaly(
                    type=AnomalyType.GRADIENT_SPIKE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="gradient_norm",
                    metric_value=current,
                    threshold=spike_threshold,
                    window_values=list(values[-20:]),
                    description=(
                        f"Gradient norm spiked to {current:.2e} (threshold={spike_threshold}). "
                        "Risk of NaN loss."
                    ),
                    recommended_action=(
                        "Apply gradient clipping (max_norm=1.0), reduce learning rate, "
                        "or rollback to last checkpoint."
                    ),
                )
            )

        # Also z-score for subtle spikes
        if len(values) >= 10:
            z = _compute_z_score_for(values[:-1], current)
            if z > 4.0 and current > 1.0:
                severity = min(1.0, (z - 4.0) / 4.0)
                anomalies.append(
                    Anomaly(
                        type=AnomalyType.GRADIENT_SPIKE,
                        severity=round(severity, 4),
                        timestamp=now,
                        metric_name="gradient_norm",
                        metric_value=current,
                        threshold=spike_threshold,
                        window_values=list(values[-20:]),
                        description=(
                            f"Gradient norm z-score is {z:.2f} (current={current:.4f}). "
                            "Relative to recent history this is a significant spike."
                        ),
                        recommended_action="Investigate batch composition; consider gradient accumulation.",
                    )
                )

        return anomalies

    def _check_length_trends(self, values: list[float]) -> list[Anomaly]:
        """Detect response length inflation via linear regression slope."""
        min_window = self._config["length_min_window"]
        if len(values) < min_window:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        slope_threshold = self._config["length_slope_threshold"]

        slope = _compute_trend(values)
        mean_length = _safe_mean(values)

        # Slope is tokens per step.  Also check relative growth.
        if len(values) >= 2 * min_window:
            mid = len(values) // 2
            early_mean = _safe_mean(values[:mid])
            late_mean = _safe_mean(values[mid:])
            relative_growth = (late_mean - early_mean) / max(early_mean, 1.0)
        else:
            relative_growth = 0.0

        if slope > slope_threshold:
            severity = min(1.0, slope / (slope_threshold * 3))
            anomalies.append(
                Anomaly(
                    type=AnomalyType.LENGTH_ANOMALY,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="response_length",
                    metric_value=values[-1],
                    threshold=slope_threshold,
                    window_values=list(values[-20:]),
                    description=(
                        f"Response length trending up (slope={slope:.4f} tokens/step, "
                        f"mean={mean_length:.0f}). Relative growth={relative_growth:.2%}. "
                        "Possible length inflation exploit."
                    ),
                    recommended_action="Add length penalty to reward function; enforce max output token limit.",
                )
            )

        return anomalies

    def _check_citation_trends(
        self,
        validity_scores: list[float],
        counts: list[float],
    ) -> list[Anomaly]:
        """Detect citation count increase paired with validity decrease."""
        if len(validity_scores) < 6:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        drop_threshold = self._config["citation_validity_drop_threshold"]

        mid = len(validity_scores) // 2
        early_val = _safe_mean(validity_scores[:mid])
        late_val = _safe_mean(validity_scores[mid:])
        val_drop = early_val - late_val

        count_increasing = False
        if len(counts) >= 6:
            count_slope = _compute_trend(counts)
            count_increasing = count_slope > 0.01

        if val_drop > drop_threshold:
            severity = min(1.0, val_drop / (drop_threshold * 3))
            desc = (
                f"Citation validity dropped by {val_drop:.4f} "
                f"(early={early_val:.4f}, late={late_val:.4f})."
            )
            if count_increasing:
                desc += " Citation count is simultaneously increasing — likely citation padding."
                severity = min(1.0, severity + 0.2)

            anomalies.append(
                Anomaly(
                    type=AnomalyType.CITATION_ANOMALY,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="citation_validity",
                    metric_value=late_val,
                    threshold=drop_threshold,
                    window_values=list(validity_scores[-20:]),
                    description=desc,
                    recommended_action=(
                        "Increase citation validity reward weight; "
                        "add hallucination penalty for fabricated sources."
                    ),
                )
            )

        return anomalies

    def _check_memory_pressure(self, values: list[float]) -> list[Anomaly]:
        """Detect memory store usage approaching capacity."""
        if not values:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        threshold = self._config["memory_pressure_threshold"]

        current = values[-1]
        if current > threshold:
            severity = min(1.0, (current - threshold) / (1.0 - threshold + 1e-9))
            anomalies.append(
                Anomaly(
                    type=AnomalyType.MEMORY_PRESSURE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="memory_usage",
                    metric_value=current,
                    threshold=threshold,
                    window_values=list(values[-20:]),
                    description=(
                        f"Memory usage at {current:.1%} (threshold={threshold:.0%}). "
                        "Risk of eviction storms or OOM."
                    ),
                    recommended_action="Run memory garbage collection; compress or evict stale entries.",
                )
            )

        return anomalies

    def _check_policy_divergence(
        self,
        policy_logprobs: list[float],
        reference_logprobs: list[float],
    ) -> list[Anomaly]:
        """Detect policy divergence from reference using KS statistic."""
        n = min(len(policy_logprobs), len(reference_logprobs))
        if n < 10:
            return []

        anomalies: list[Anomaly] = []
        now = datetime.now(tz=UTC)
        threshold = self._config["kl_divergence_threshold"]

        pol = policy_logprobs[:n]
        ref = reference_logprobs[:n]

        ks_stat = _ks_two_sample(pol, ref)

        # Also compute approximate mean KL per token
        # KL(policy || ref) ~= mean(policy_logprob - ref_logprob) when both
        # are log probs under the respective policies for the same tokens.
        mean_diff = _safe_mean([p - r for p, r in zip(pol, ref, strict=False)])

        if ks_stat > threshold:
            severity = min(1.0, ks_stat / (threshold * 2))
            anomalies.append(
                Anomaly(
                    type=AnomalyType.POLICY_DIVERGENCE,
                    severity=round(severity, 4),
                    timestamp=now,
                    metric_name="policy_divergence_ks",
                    metric_value=ks_stat,
                    threshold=threshold,
                    window_values=list(pol[-20:]),
                    description=(
                        f"Policy has diverged from reference (KS={ks_stat:.4f}, "
                        f"threshold={threshold}, mean_logprob_diff={mean_diff:.4f}). "
                        "The model may have drifted too far from the base policy."
                    ),
                    recommended_action=(
                        "Increase KL penalty coefficient or rollback to a closer checkpoint."
                    ),
                )
            )

        return anomalies
