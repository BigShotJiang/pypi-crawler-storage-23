"""Aegis Observatory — runtime monitoring, health checks, and efficiency tracking.

Re-exports :class:`ObservatoryMonitor`, :class:`HealthCheckResult`,
:class:`EfficiencyTracker`, :class:`InterventionEngine`,
:class:`Intervention`, :class:`InterventionRule`,
:class:`SignalCollector`, :class:`Signal`,
:class:`HackingAtlas`, :class:`HackingPattern`, :class:`DetectionResult`,
:class:`AnomalyDetector`, :class:`AnomalyType`, :class:`Anomaly`,
:class:`GoodhartMonitor`, :class:`GoodhartConfig`, :class:`GoodhartWarning`,
:class:`AutoInterventionEngine`, :class:`InterventionType`,
:class:`InterventionPolicy`, and related auto-intervention types.
"""

from aegis.observatory.anomaly_detector import Anomaly, AnomalyDetector, AnomalyType
from aegis.observatory.auto_intervention import (
    AutoInterventionEngine,
    InterventionPolicy,
    InterventionType,
)
from aegis.observatory.auto_intervention import Intervention as AutoIntervention
from aegis.observatory.efficiency import EfficiencyTracker
from aegis.observatory.goodhart import GoodhartConfig, GoodhartMonitor, GoodhartWarning
from aegis.observatory.hacking_atlas import DetectionResult, HackingAtlas, HackingPattern
from aegis.observatory.interventions import (
    Intervention,
    InterventionEngine,
    InterventionRule,
)
from aegis.observatory.monitor import HealthCheckResult, ObservatoryMonitor
from aegis.observatory.signals import Signal, SignalCollector

__all__ = [
    # monitor.py
    "ObservatoryMonitor",
    "HealthCheckResult",
    # efficiency.py
    "EfficiencyTracker",
    # interventions.py (existing)
    "InterventionEngine",
    "Intervention",
    "InterventionRule",
    # signals.py
    "SignalCollector",
    "Signal",
    # hacking_atlas.py
    "HackingAtlas",
    "HackingPattern",
    "DetectionResult",
    # anomaly_detector.py
    "AnomalyDetector",
    "AnomalyType",
    "Anomaly",
    # goodhart.py
    "GoodhartMonitor",
    "GoodhartConfig",
    "GoodhartWarning",
    # auto_intervention.py
    "AutoInterventionEngine",
    "AutoIntervention",
    "InterventionType",
    "InterventionPolicy",
]
