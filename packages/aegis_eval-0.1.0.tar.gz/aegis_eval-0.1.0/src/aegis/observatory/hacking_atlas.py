"""Catalog of known reward hacking patterns with detection signatures.

Provides :class:`HackingAtlas`, a registry of known reward hacking
patterns commonly seen in RL-trained language agents.  Each pattern
includes a detection signature (statistical checks on metric streams)
and a prevention strategy suitable for curriculum adjustments.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class HackingPattern:
    """A known reward hacking pattern with detection rules."""

    id: str
    name: str
    description: str
    category: str  # "length", "citation", "sycophancy", "retrieval", "memory", "format"
    detection_signature: dict[str, Any]
    severity: str  # "low", "medium", "high", "critical"
    domain_tendency: list[str] = field(default_factory=list)
    prevention_strategy: str = ""
    first_detected: datetime | None = None


@dataclass
class DetectionResult:
    """Result of running a hacking pattern detector against metrics."""

    pattern_id: str
    detected: bool
    confidence: float
    evidence: dict[str, Any] = field(default_factory=dict)
    recommended_action: str = ""


# ---------------------------------------------------------------------------
# Detector helpers
# ---------------------------------------------------------------------------


def _safe_mean(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _safe_stdev(vals: list[float]) -> float:
    if len(vals) < 2:
        return 0.0
    m = _safe_mean(vals)
    return math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1))


def _linear_slope(vals: list[float]) -> float:
    """Ordinary least-squares slope of *vals* against their index."""
    n = len(vals)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(vals) / n
    num = sum((i - x_mean) * (v - y_mean) for i, v in enumerate(vals))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den if den > 0 else 0.0


def _pearson(xs: list[float], ys: list[float]) -> float:
    n = min(len(xs), len(ys))
    if n < 2:
        return 0.0
    mx, my = sum(xs[:n]) / n, sum(ys[:n]) / n
    cov = sum((xs[i] - mx) * (ys[i] - my) for i in range(n))
    sx = math.sqrt(sum((xs[i] - mx) ** 2 for i in range(n)))
    sy = math.sqrt(sum((ys[i] - my) ** 2 for i in range(n)))
    denom = sx * sy
    return cov / denom if denom > 1e-12 else 0.0


# ---------------------------------------------------------------------------
# Individual detectors
# ---------------------------------------------------------------------------


def _detect_length_inflation(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Check if mean response length increased >threshold while reward stayed flat."""
    lengths: list[float] = metrics.get("response_lengths", [])
    rewards: list[float] = metrics.get("rewards", [])
    threshold_pct: float = sig.get("length_increase_threshold", 0.20)
    reward_flat_band: float = sig.get("reward_flat_band", 0.05)

    if len(lengths) < 10:
        return DetectionResult("length_inflation", False, 0.0, {"reason": "insufficient_data"})

    mid = len(lengths) // 2
    early_mean = _safe_mean(lengths[:mid])
    late_mean = _safe_mean(lengths[mid:])

    if early_mean < 1e-6:
        return DetectionResult("length_inflation", False, 0.0, {"reason": "near_zero_early_mean"})

    length_increase = (late_mean - early_mean) / early_mean

    reward_flat = True
    if len(rewards) >= 10:
        r_mid = len(rewards) // 2
        early_r = _safe_mean(rewards[:r_mid])
        late_r = _safe_mean(rewards[r_mid:])
        reward_change = abs(late_r - early_r) / max(abs(early_r), 1e-6)
        reward_flat = reward_change < reward_flat_band
    else:
        reward_flat = True  # Assume flat if we cannot check

    detected = length_increase > threshold_pct and reward_flat
    confidence = min(1.0, length_increase / (threshold_pct * 2)) if detected else 0.0

    return DetectionResult(
        pattern_id="length_inflation",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "early_mean_length": round(early_mean, 2),
            "late_mean_length": round(late_mean, 2),
            "length_increase_pct": round(length_increase, 4),
            "reward_flat": reward_flat,
        },
        recommended_action="Add a length penalty to the reward function and inject conciseness prompts."
        if detected
        else "",
    )


def _detect_citation_padding(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Citations/response increased but citation validity decreased."""
    counts: list[float] = metrics.get("citation_counts", [])
    validity: list[float] = metrics.get("citation_validity", [])
    count_threshold: float = sig.get("count_increase_threshold", 0.30)
    validity_drop: float = sig.get("validity_drop_threshold", 0.10)

    if len(counts) < 6 or len(validity) < 6:
        return DetectionResult("citation_padding", False, 0.0, {"reason": "insufficient_data"})

    mid_c = len(counts) // 2
    early_count = _safe_mean(counts[:mid_c])
    late_count = _safe_mean(counts[mid_c:])
    count_change = (late_count - early_count) / max(early_count, 1e-6)

    mid_v = len(validity) // 2
    early_val = _safe_mean(validity[:mid_v])
    late_val = _safe_mean(validity[mid_v:])
    val_change = early_val - late_val  # Positive means drop

    detected = count_change > count_threshold and val_change > validity_drop
    confidence = min(1.0, (count_change + val_change) / 2) if detected else 0.0

    return DetectionResult(
        pattern_id="citation_padding",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "count_increase_pct": round(count_change, 4),
            "validity_drop": round(val_change, 4),
            "early_count": round(early_count, 2),
            "late_count": round(late_count, 2),
            "early_validity": round(early_val, 4),
            "late_validity": round(late_val, 4),
        },
        recommended_action="Increase citation validity reward weight and add hallucination penalties."
        if detected
        else "",
    )


def _detect_sycophancy_drift(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Check if agreement rate with user premise exceeds threshold."""
    agreement_rates: list[float] = metrics.get("agreement_rates", [])
    threshold: float = sig.get("agreement_threshold", 0.90)

    if len(agreement_rates) < 5:
        return DetectionResult("sycophancy_drift", False, 0.0, {"reason": "insufficient_data"})

    recent = agreement_rates[-min(20, len(agreement_rates)) :]
    mean_agree = _safe_mean(recent)
    slope = _linear_slope(agreement_rates)

    detected = mean_agree > threshold
    confidence = min(1.0, (mean_agree - threshold) / (1.0 - threshold + 1e-9)) if detected else 0.0

    return DetectionResult(
        pattern_id="sycophancy_drift",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "mean_agreement_rate": round(mean_agree, 4),
            "threshold": threshold,
            "trend_slope": round(slope, 6),
        },
        recommended_action="Inject adversarial prompts with false premises and reward appropriate disagreement."
        if detected
        else "",
    )


def _detect_retrieval_avoidance(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent avoids retrieval to save tokens or avoid penalties."""
    retrieval_rates: list[float] = metrics.get("retrieval_rates", [])
    drop_threshold: float = sig.get("rate_drop_threshold", 0.40)

    if len(retrieval_rates) < 8:
        return DetectionResult("retrieval_avoidance", False, 0.0, {"reason": "insufficient_data"})

    mid = len(retrieval_rates) // 2
    early = _safe_mean(retrieval_rates[:mid])
    late = _safe_mean(retrieval_rates[mid:])
    drop = (early - late) / max(early, 1e-6)

    detected = drop > drop_threshold and early > 0.1
    confidence = min(1.0, drop / (drop_threshold * 1.5)) if detected else 0.0

    return DetectionResult(
        pattern_id="retrieval_avoidance",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "early_retrieval_rate": round(early, 4),
            "late_retrieval_rate": round(late, 4),
            "drop_pct": round(drop, 4),
        },
        recommended_action="Add retrieval utilization floor to reward and include knowledge-intensive tasks."
        if detected
        else "",
    )


def _detect_memory_gaming(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Memory ops/turn increased but dead memory % also increased."""
    ops_per_turn: list[float] = metrics.get("memory_ops_per_turn", [])
    dead_pct: list[float] = metrics.get("dead_memory_pct", [])
    ops_threshold: float = sig.get("ops_increase_threshold", 0.25)
    dead_threshold: float = sig.get("dead_increase_threshold", 0.15)

    if len(ops_per_turn) < 6 or len(dead_pct) < 6:
        return DetectionResult("memory_gaming", False, 0.0, {"reason": "insufficient_data"})

    mid_o = len(ops_per_turn) // 2
    early_ops = _safe_mean(ops_per_turn[:mid_o])
    late_ops = _safe_mean(ops_per_turn[mid_o:])
    ops_change = (late_ops - early_ops) / max(early_ops, 1e-6)

    mid_d = len(dead_pct) // 2
    early_dead = _safe_mean(dead_pct[:mid_d])
    late_dead = _safe_mean(dead_pct[mid_d:])
    dead_change = late_dead - early_dead

    detected = ops_change > ops_threshold and dead_change > dead_threshold
    confidence = min(1.0, (ops_change + dead_change) / 2) if detected else 0.0

    return DetectionResult(
        pattern_id="memory_gaming",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "ops_increase_pct": round(ops_change, 4),
            "dead_memory_increase": round(dead_change, 4),
            "late_ops_per_turn": round(late_ops, 2),
            "late_dead_pct": round(late_dead, 4),
        },
        recommended_action="Reduce memory reward weight and penalize dead memory accumulation."
        if detected
        else "",
    )


def _detect_format_gaming(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent games formatting to earn higher format compliance scores."""
    format_scores: list[float] = metrics.get("format_scores", [])
    content_scores: list[float] = metrics.get("content_scores", [])
    divergence_threshold: float = sig.get("divergence_threshold", 0.25)

    if len(format_scores) < 6 or len(content_scores) < 6:
        return DetectionResult("format_gaming", False, 0.0, {"reason": "insufficient_data"})

    n = min(len(format_scores), len(content_scores))
    mean_fmt = _safe_mean(format_scores[-n:])
    mean_cnt = _safe_mean(content_scores[-n:])
    divergence = mean_fmt - mean_cnt

    slope_fmt = _linear_slope(format_scores)
    slope_cnt = _linear_slope(content_scores)

    detected = divergence > divergence_threshold and slope_fmt > 0 and slope_cnt <= 0
    confidence = min(1.0, divergence / (divergence_threshold * 2)) if detected else 0.0

    return DetectionResult(
        pattern_id="format_gaming",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "mean_format_score": round(mean_fmt, 4),
            "mean_content_score": round(mean_cnt, 4),
            "divergence": round(divergence, 4),
            "format_trend": round(slope_fmt, 6),
            "content_trend": round(slope_cnt, 6),
        },
        recommended_action="Increase content quality weight in reward and cap format bonus."
        if detected
        else "",
    )


def _detect_number_fabrication(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent fabricates numbers / statistics to appear authoritative."""
    numeric_claims: list[float] = metrics.get("numeric_claim_counts", [])
    verification_rates: list[float] = metrics.get("numeric_verification_rates", [])
    claim_threshold: float = sig.get("claim_increase_threshold", 0.30)
    ver_floor: float = sig.get("verification_floor", 0.50)

    if len(numeric_claims) < 6 or len(verification_rates) < 6:
        return DetectionResult("number_fabrication", False, 0.0, {"reason": "insufficient_data"})

    slope = _linear_slope(numeric_claims)
    recent_ver = _safe_mean(verification_rates[-min(10, len(verification_rates)) :])
    mid = len(numeric_claims) // 2
    early_claims = _safe_mean(numeric_claims[:mid])
    late_claims = _safe_mean(numeric_claims[mid:])
    claim_increase = (late_claims - early_claims) / max(early_claims, 1e-6)

    detected = claim_increase > claim_threshold and recent_ver < ver_floor
    confidence = min(1.0, claim_increase * (1 - recent_ver)) if detected else 0.0

    return DetectionResult(
        pattern_id="number_fabrication",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "claim_increase_pct": round(claim_increase, 4),
            "recent_verification_rate": round(recent_ver, 4),
            "claim_trend_slope": round(slope, 6),
        },
        recommended_action="Add numeric grounding verification to the reward pipeline."
        if detected
        else "",
    )


def _detect_source_hallucination(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent invents plausible-sounding but non-existent sources."""
    source_counts: list[float] = metrics.get("source_counts", [])
    hallucination_rates: list[float] = metrics.get("source_hallucination_rates", [])
    hall_threshold: float = sig.get("hallucination_threshold", 0.20)

    if len(hallucination_rates) < 5:
        return DetectionResult("source_hallucination", False, 0.0, {"reason": "insufficient_data"})

    recent_hall = _safe_mean(hallucination_rates[-min(10, len(hallucination_rates)) :])
    hall_slope = _linear_slope(hallucination_rates)

    detected = recent_hall > hall_threshold
    confidence = min(1.0, recent_hall / (hall_threshold * 2)) if detected else 0.0

    return DetectionResult(
        pattern_id="source_hallucination",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "recent_hallucination_rate": round(recent_hall, 4),
            "hallucination_trend": round(hall_slope, 6),
            "mean_source_count": round(_safe_mean(source_counts), 2) if source_counts else 0.0,
        },
        recommended_action="Add source verification step and penalize unverifiable references."
        if detected
        else "",
    )


def _detect_difficulty_avoidance(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent steers toward easy tasks / gives shallow answers on hard ones."""
    difficulty_scores: list[float] = metrics.get("task_difficulty_scores", [])
    performance_scores: list[float] = metrics.get("performance_scores", [])
    correlation_threshold: float = sig.get("difficulty_correlation_floor", -0.3)

    if len(difficulty_scores) < 10 or len(performance_scores) < 10:
        return DetectionResult("difficulty_avoidance", False, 0.0, {"reason": "insufficient_data"})

    n = min(len(difficulty_scores), len(performance_scores))
    corr = _pearson(difficulty_scores[:n], performance_scores[:n])

    # Also check if mean difficulty is trending down
    diff_slope = _linear_slope(difficulty_scores)

    detected = corr < correlation_threshold and diff_slope < -0.001
    confidence = min(1.0, abs(corr) * 0.5 + abs(diff_slope) * 100) if detected else 0.0

    return DetectionResult(
        pattern_id="difficulty_avoidance",
        detected=detected,
        confidence=round(min(confidence, 1.0), 4),
        evidence={
            "difficulty_performance_corr": round(corr, 4),
            "difficulty_trend_slope": round(diff_slope, 6),
        },
        recommended_action="Use curriculum learning with enforced difficulty distribution; reward effort on hard tasks."
        if detected
        else "",
    )


def _detect_reward_correlation_collapse(
    metrics: dict[str, Any], sig: dict[str, Any]
) -> DetectionResult:
    """Reward components become decorrelated, signalling gaming of individual terms."""
    reward_components: dict[str, list[float]] = metrics.get("reward_components", {})
    min_correlation: float = sig.get("min_component_correlation", 0.15)

    if len(reward_components) < 2:
        return DetectionResult(
            "reward_correlation_collapse", False, 0.0, {"reason": "insufficient_components"}
        )

    # Check pairwise correlations between reward components
    names = list(reward_components.keys())
    min_len = min(len(v) for v in reward_components.values())
    if min_len < 10:
        return DetectionResult(
            "reward_correlation_collapse", False, 0.0, {"reason": "insufficient_data"}
        )

    pair_corrs: list[tuple[str, str, float]] = []
    low_count = 0
    total_pairs = 0
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            c = _pearson(
                reward_components[names[i]][:min_len], reward_components[names[j]][:min_len]
            )
            pair_corrs.append((names[i], names[j], round(c, 4)))
            total_pairs += 1
            if abs(c) < min_correlation:
                low_count += 1

    collapse_ratio = low_count / total_pairs if total_pairs > 0 else 0.0
    detected = collapse_ratio > 0.5
    confidence = min(1.0, collapse_ratio) if detected else 0.0

    return DetectionResult(
        pattern_id="reward_correlation_collapse",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "low_correlation_pairs": low_count,
            "total_pairs": total_pairs,
            "collapse_ratio": round(collapse_ratio, 4),
            "pairwise_correlations": pair_corrs,
        },
        recommended_action="Review reward decomposition; consider a single holistic reward or re-weight components."
        if detected
        else "",
    )


def _detect_echo_trap(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Reward variance collapses below threshold — agent found a fixed exploit."""
    rewards: list[float] = metrics.get("rewards", [])
    variance_threshold: float = sig.get("variance_threshold", 0.05)

    if len(rewards) < 10:
        return DetectionResult("echo_trap", False, 0.0, {"reason": "insufficient_data"})

    recent = rewards[-min(50, len(rewards)) :]
    mean_r = _safe_mean(recent)
    variance = sum((r - mean_r) ** 2 for r in recent) / len(recent)

    detected = variance < variance_threshold and mean_r > 0.5
    confidence = min(1.0, (variance_threshold - variance) / variance_threshold) if detected else 0.0

    return DetectionResult(
        pattern_id="echo_trap",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "reward_variance": round(variance, 6),
            "variance_threshold": variance_threshold,
            "mean_reward": round(mean_r, 4),
            "window_size": len(recent),
        },
        recommended_action="Inject prompt diversity, add entropy bonus to reward, and randomize evaluation prompts."
        if detected
        else "",
    )


def _detect_confidence_inflation(metrics: dict[str, Any], sig: dict[str, Any]) -> DetectionResult:
    """Agent reports high confidence regardless of actual accuracy."""
    confidence_scores: list[float] = metrics.get("confidence_scores", [])
    accuracy_scores: list[float] = metrics.get("accuracy_scores", [])
    cal_threshold: float = sig.get("calibration_gap_threshold", 0.20)

    if len(confidence_scores) < 5 or len(accuracy_scores) < 5:
        return DetectionResult("confidence_inflation", False, 0.0, {"reason": "insufficient_data"})

    n = min(len(confidence_scores), len(accuracy_scores))
    mean_conf = _safe_mean(confidence_scores[:n])
    mean_acc = _safe_mean(accuracy_scores[:n])
    calibration_gap = mean_conf - mean_acc

    corr = _pearson(confidence_scores[:n], accuracy_scores[:n])

    detected = calibration_gap > cal_threshold
    confidence = min(1.0, calibration_gap / (cal_threshold * 2)) if detected else 0.0

    return DetectionResult(
        pattern_id="confidence_inflation",
        detected=detected,
        confidence=round(confidence, 4),
        evidence={
            "mean_confidence": round(mean_conf, 4),
            "mean_accuracy": round(mean_acc, 4),
            "calibration_gap": round(calibration_gap, 4),
            "confidence_accuracy_corr": round(corr, 4),
        },
        recommended_action="Add calibration loss to reward; penalize overconfidence on wrong answers."
        if detected
        else "",
    )


# ---------------------------------------------------------------------------
# Dispatcher mapping pattern ids to detector functions
# ---------------------------------------------------------------------------

DetectorFn = Callable[[dict[str, Any], dict[str, Any]], DetectionResult]

_DETECTORS: dict[str, DetectorFn] = {
    "length_inflation": _detect_length_inflation,
    "citation_padding": _detect_citation_padding,
    "sycophancy_drift": _detect_sycophancy_drift,
    "retrieval_avoidance": _detect_retrieval_avoidance,
    "memory_gaming": _detect_memory_gaming,
    "format_gaming": _detect_format_gaming,
    "number_fabrication": _detect_number_fabrication,
    "source_hallucination": _detect_source_hallucination,
    "difficulty_avoidance": _detect_difficulty_avoidance,
    "reward_correlation_collapse": _detect_reward_correlation_collapse,
    "echo_trap": _detect_echo_trap,
    "confidence_inflation": _detect_confidence_inflation,
}


# ---------------------------------------------------------------------------
# HackingAtlas
# ---------------------------------------------------------------------------


class HackingAtlas:
    """Registry of known reward hacking patterns with detection engines.

    Pre-loaded with 12+ empirically observed patterns spanning length,
    citation, sycophancy, retrieval, memory, and format gaming.
    """

    def __init__(self) -> None:
        self._patterns: dict[str, HackingPattern] = {}
        self._load_default_patterns()

    # -- Public API ---------------------------------------------------------

    def detect(self, pattern_id: str, metrics: dict[str, Any]) -> DetectionResult:
        """Run a specific pattern detector against *metrics*.

        Returns a :class:`DetectionResult` with detection status, confidence,
        evidence, and recommended action.
        """
        pattern = self._patterns.get(pattern_id)
        if pattern is None:
            return DetectionResult(
                pattern_id=pattern_id,
                detected=False,
                confidence=0.0,
                evidence={"error": f"Unknown pattern: {pattern_id}"},
            )
        detector = _DETECTORS.get(pattern_id)
        if detector is None:
            return DetectionResult(
                pattern_id=pattern_id,
                detected=False,
                confidence=0.0,
                evidence={"error": f"No detector registered for {pattern_id}"},
            )
        return detector(metrics, pattern.detection_signature)

    def detect_all(self, metrics: dict[str, Any]) -> list[DetectionResult]:
        """Run every registered detector and return results."""
        results: list[DetectionResult] = []
        for pid in self._patterns:
            results.append(self.detect(pid, metrics))
        return results

    def register_pattern(self, pattern: HackingPattern) -> None:
        """Add or overwrite a pattern in the atlas."""
        self._patterns[pattern.id] = pattern

    def get_pattern(self, pattern_id: str) -> HackingPattern | None:
        """Look up a pattern by id."""
        return self._patterns.get(pattern_id)

    def patterns_for_domain(self, domain: str) -> list[HackingPattern]:
        """Return all patterns whose *domain_tendency* includes *domain*."""
        return [p for p in self._patterns.values() if domain in p.domain_tendency]

    def get_prevention_curriculum(self, detected_patterns: list[str]) -> dict[str, Any]:
        """Generate training curriculum adjustments to counter detected patterns.

        Returns a dict with keys:

        - ``reward_adjustments``: Changes to reward component weights.
        - ``data_augmentation``: Additional training data strategies.
        - ``training_config``: Hyper-parameter changes.
        - ``evaluation_additions``: New eval checks to add.
        """
        reward_adjustments: dict[str, float] = {}
        data_augmentation: list[str] = []
        training_config: dict[str, Any] = {}
        evaluation_additions: list[str] = []

        for pid in detected_patterns:
            pattern = self._patterns.get(pid)
            if pattern is None:
                continue

            cat = pattern.category

            if cat == "length":
                reward_adjustments["length_penalty_weight"] = (
                    reward_adjustments.get("length_penalty_weight", 0.0) + 0.15
                )
                data_augmentation.append(
                    "Add concise answer exemplars (target length 50-200 tokens)."
                )
                training_config["max_output_tokens"] = min(
                    training_config.get("max_output_tokens", 2048), 1024
                )
                evaluation_additions.append("length_efficiency_check")

            elif cat == "citation":
                reward_adjustments["citation_validity_weight"] = (
                    reward_adjustments.get("citation_validity_weight", 0.0) + 0.20
                )
                reward_adjustments["citation_count_weight"] = max(
                    reward_adjustments.get("citation_count_weight", 0.10) - 0.05, 0.0
                )
                data_augmentation.append("Include tasks requiring verification of cited sources.")
                evaluation_additions.append("citation_grounding_check")

            elif cat == "sycophancy":
                reward_adjustments["disagreement_bonus"] = (
                    reward_adjustments.get("disagreement_bonus", 0.0) + 0.10
                )
                data_augmentation.append(
                    "Add adversarial prompts with false premises that require pushback."
                )
                training_config["adversarial_prompt_ratio"] = 0.15
                evaluation_additions.append("sycophancy_resistance_check")

            elif cat == "retrieval":
                reward_adjustments["retrieval_utilization_weight"] = (
                    reward_adjustments.get("retrieval_utilization_weight", 0.0) + 0.10
                )
                data_augmentation.append(
                    "Include knowledge-intensive tasks requiring multi-hop retrieval."
                )
                evaluation_additions.append("retrieval_depth_check")

            elif cat == "memory":
                reward_adjustments["memory_ops_weight"] = max(
                    reward_adjustments.get("memory_ops_weight", 0.15) - 0.05, 0.0
                )
                reward_adjustments["dead_memory_penalty"] = (
                    reward_adjustments.get("dead_memory_penalty", 0.0) + 0.10
                )
                data_augmentation.append(
                    "Add multi-turn conversations that test meaningful memory use."
                )
                training_config["memory_gc_interval"] = min(
                    training_config.get("memory_gc_interval", 100), 50
                )
                evaluation_additions.append("memory_utilization_check")

            elif cat == "format":
                reward_adjustments["format_compliance_cap"] = min(
                    reward_adjustments.get("format_compliance_cap", 0.20), 0.15
                )
                reward_adjustments["content_quality_weight"] = (
                    reward_adjustments.get("content_quality_weight", 0.0) + 0.20
                )
                data_augmentation.append(
                    "Include free-form response tasks without format constraints."
                )
                evaluation_additions.append("content_depth_check")

        # Global adjustments when multiple patterns detected
        if len(detected_patterns) >= 3:
            training_config["entropy_bonus"] = training_config.get("entropy_bonus", 0.0) + 0.05
            training_config["prompt_diversity_multiplier"] = 2.0
            data_augmentation.append(
                "Significantly diversify prompt distribution to prevent exploitation."
            )
            evaluation_additions.append("multi_pattern_hacking_audit")

        return {
            "detected_patterns": detected_patterns,
            "reward_adjustments": reward_adjustments,
            "data_augmentation": data_augmentation,
            "training_config": training_config,
            "evaluation_additions": list(set(evaluation_additions)),
        }

    def export(self) -> dict[str, Any]:
        """Full atlas export as a plain dict."""
        return {
            pid: {
                "id": p.id,
                "name": p.name,
                "description": p.description,
                "category": p.category,
                "detection_signature": p.detection_signature,
                "severity": p.severity,
                "domain_tendency": p.domain_tendency,
                "prevention_strategy": p.prevention_strategy,
                "first_detected": p.first_detected.isoformat() if p.first_detected else None,
            }
            for pid, p in self._patterns.items()
        }

    def summary(self) -> dict[str, Any]:
        """Condensed atlas summary."""
        by_category: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        for p in self._patterns.values():
            by_category[p.category] = by_category.get(p.category, 0) + 1
            by_severity[p.severity] = by_severity.get(p.severity, 0) + 1

        return {
            "total_patterns": len(self._patterns),
            "by_category": by_category,
            "by_severity": by_severity,
            "pattern_ids": list(self._patterns.keys()),
        }

    # -- Default patterns ---------------------------------------------------

    def _load_default_patterns(self) -> None:  # noqa: C901 (intentionally large for exhaustive coverage)
        defaults: list[HackingPattern] = [
            HackingPattern(
                id="length_inflation",
                name="Length Inflation",
                description=(
                    "Agent learns to produce longer responses to inflate reward "
                    "without improving actual quality. Common in RLHF when reward "
                    "models correlate length with helpfulness."
                ),
                category="length",
                detection_signature={
                    "length_increase_threshold": 0.20,
                    "reward_flat_band": 0.05,
                },
                severity="medium",
                domain_tendency=["legal", "finance", "general"],
                prevention_strategy=(
                    "Apply a conciseness bonus that rewards information density. "
                    "Normalize reward by output length."
                ),
            ),
            HackingPattern(
                id="citation_padding",
                name="Citation Padding",
                description=(
                    "Agent adds superfluous citations to earn citation-count rewards, "
                    "while citation validity degrades."
                ),
                category="citation",
                detection_signature={
                    "count_increase_threshold": 0.30,
                    "validity_drop_threshold": 0.10,
                },
                severity="high",
                domain_tendency=["legal", "medical", "research"],
                prevention_strategy=(
                    "Replace citation-count reward with citation-validity reward. "
                    "Add a grounding check for each reference."
                ),
            ),
            HackingPattern(
                id="sycophancy_drift",
                name="Sycophancy Drift",
                description=(
                    "Agent learns to agree with user statements regardless of "
                    "factual accuracy in order to maximise helpfulness ratings."
                ),
                category="sycophancy",
                detection_signature={
                    "agreement_threshold": 0.90,
                },
                severity="high",
                domain_tendency=["general", "medical", "legal"],
                prevention_strategy=(
                    "Include adversarial prompts with incorrect premises. "
                    "Reward appropriate disagreement."
                ),
                first_detected=datetime(2023, 6, 1, tzinfo=UTC),
            ),
            HackingPattern(
                id="retrieval_avoidance",
                name="Retrieval Avoidance",
                description=(
                    "Agent avoids issuing retrieval calls to minimize latency "
                    "or token cost, relying on possibly stale parametric knowledge."
                ),
                category="retrieval",
                detection_signature={
                    "rate_drop_threshold": 0.40,
                },
                severity="medium",
                domain_tendency=["finance", "legal", "news"],
                prevention_strategy=(
                    "Set a minimum retrieval utilization floor. Include "
                    "knowledge-intensive tasks requiring recent information."
                ),
            ),
            HackingPattern(
                id="memory_gaming",
                name="Memory Gaming",
                description=(
                    "Agent increases memory operations per turn to earn memory-use "
                    "rewards but accumulates dead (never-retrieved) entries."
                ),
                category="memory",
                detection_signature={
                    "ops_increase_threshold": 0.25,
                    "dead_increase_threshold": 0.15,
                },
                severity="high",
                domain_tendency=["general", "customer_support"],
                prevention_strategy=(
                    "Penalize dead memory accumulation. Reward memory recall "
                    "relevance rather than raw operation count."
                ),
            ),
            HackingPattern(
                id="format_gaming",
                name="Format Gaming",
                description=(
                    "Agent optimizes formatting (headers, bullet points, markdown) "
                    "to earn format compliance scores while content quality declines."
                ),
                category="format",
                detection_signature={
                    "divergence_threshold": 0.25,
                },
                severity="medium",
                domain_tendency=["general", "education"],
                prevention_strategy=(
                    "Cap format compliance reward. Increase weight on content "
                    "substance and correctness."
                ),
            ),
            HackingPattern(
                id="number_fabrication",
                name="Number Fabrication",
                description=(
                    "Agent invents plausible statistics and numbers to appear "
                    "authoritative. Particularly dangerous in finance and medical."
                ),
                category="citation",
                detection_signature={
                    "claim_increase_threshold": 0.30,
                    "verification_floor": 0.50,
                },
                severity="critical",
                domain_tendency=["finance", "medical", "research"],
                prevention_strategy=(
                    "Add a numeric grounding verification step. Penalize "
                    "unverifiable numeric claims heavily."
                ),
            ),
            HackingPattern(
                id="source_hallucination",
                name="Source Hallucination",
                description=(
                    "Agent cites non-existent papers, URLs, or legal cases that "
                    "sound plausible but cannot be verified."
                ),
                category="citation",
                detection_signature={
                    "hallucination_threshold": 0.20,
                },
                severity="critical",
                domain_tendency=["legal", "medical", "research", "finance"],
                prevention_strategy=(
                    "Mandate retrieval-backed citations only. Run automated "
                    "existence checks on every cited source."
                ),
                first_detected=datetime(2023, 3, 1, tzinfo=UTC),
            ),
            HackingPattern(
                id="difficulty_avoidance",
                name="Difficulty Avoidance",
                description=(
                    "Agent steers conversations toward easy sub-tasks or gives "
                    "shallow answers on hard questions to maintain high reward."
                ),
                category="retrieval",
                detection_signature={
                    "difficulty_correlation_floor": -0.3,
                },
                severity="medium",
                domain_tendency=["education", "general", "research"],
                prevention_strategy=(
                    "Enforce a difficulty distribution in the curriculum. "
                    "Reward effort and depth on harder tasks."
                ),
            ),
            HackingPattern(
                id="reward_correlation_collapse",
                name="Reward Correlation Collapse",
                description=(
                    "Pairwise correlations between reward components collapse, "
                    "indicating the agent is gaming individual reward terms in "
                    "isolation rather than producing holistically good outputs."
                ),
                category="format",
                detection_signature={
                    "min_component_correlation": 0.15,
                },
                severity="high",
                domain_tendency=["general", "finance", "legal"],
                prevention_strategy=(
                    "Re-calibrate reward component weights. Consider switching "
                    "to a single holistic reward model."
                ),
            ),
            HackingPattern(
                id="echo_trap",
                name="Echo Trap",
                description=(
                    "Reward variance collapses to near-zero because the agent has "
                    "found a single exploitative strategy that always scores well. "
                    "Diversity and creativity vanish."
                ),
                category="format",
                detection_signature={
                    "variance_threshold": 0.05,
                },
                severity="high",
                domain_tendency=["general", "customer_support", "education"],
                prevention_strategy=(
                    "Add an entropy bonus. Diversify the prompt distribution. "
                    "Randomize evaluation criteria."
                ),
            ),
            HackingPattern(
                id="confidence_inflation",
                name="Confidence Inflation",
                description=(
                    "Agent expresses high confidence even when its answers are "
                    "wrong, exploiting reward models that conflate confidence "
                    "with correctness."
                ),
                category="sycophancy",
                detection_signature={
                    "calibration_gap_threshold": 0.20,
                },
                severity="high",
                domain_tendency=["medical", "legal", "finance"],
                prevention_strategy=(
                    "Add calibration loss penalizing the gap between expressed "
                    "confidence and actual accuracy."
                ),
            ),
        ]

        for p in defaults:
            self._patterns[p.id] = p
