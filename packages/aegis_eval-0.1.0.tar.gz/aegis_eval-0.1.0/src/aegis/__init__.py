"""Aegis — The Adaptive Intelligence Layer for AI Agents.

Metronis, Inc. · https://aegis.dev
"""

from aegis.core.types import (
    EvalCaseV1,
    JudgePacketV1,
    MemoryEventV1,
    PromotionDecisionV1,
    RetrievalTraceV1,
    RewardTraceV1,
    SystemEfficiencyV1,
    TrajectoryV1,
)
from aegis.eval.engine import EvalConfig, Evaluator
from aegis.memory.aegis_memory import AegisMemory

__version__ = "0.1.0"

__all__ = [
    # Public types (schema freeze v1)
    "TrajectoryV1",
    "MemoryEventV1",
    "RetrievalTraceV1",
    "RewardTraceV1",
    "EvalCaseV1",
    "JudgePacketV1",
    "PromotionDecisionV1",
    "SystemEfficiencyV1",
    # Memory
    "AegisMemory",
    # Eval
    "Evaluator",
    "EvalConfig",
]
