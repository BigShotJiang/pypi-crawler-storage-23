"""Event router — routes events to typed handler functions."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol


class EventHandler(Protocol):
    """Protocol for event handlers."""

    def handle(self, event: dict[str, Any]) -> dict[str, Any] | None: ...


@dataclass
class RouteRule:
    """A routing rule mapping event patterns to handlers."""

    pattern: str  # event type pattern, supports wildcards like "memory.*"
    handler: EventHandler | Callable[[dict[str, Any]], dict[str, Any] | None]
    priority: int = 0
    enabled: bool = True


class EventRouter:
    """Routes events to appropriate handlers based on event type patterns.

    Supports exact matching and prefix-wildcard patterns (e.g. ``"memory.*"``).
    Multiple handlers can match the same event; they execute in priority order.
    """

    def __init__(self) -> None:
        self._routes: list[RouteRule] = []
        self._results: list[dict[str, Any]] = []

    def add_route(
        self,
        pattern: str,
        handler: EventHandler | Callable[[dict[str, Any]], dict[str, Any] | None],
        priority: int = 0,
    ) -> None:
        """Add a routing rule."""
        self._routes.append(RouteRule(pattern=pattern, handler=handler, priority=priority))
        self._routes.sort(key=lambda r: r.priority, reverse=True)

    def remove_route(self, pattern: str) -> bool:
        """Remove all routes matching a pattern."""
        original = len(self._routes)
        self._routes = [r for r in self._routes if r.pattern != pattern]
        return len(self._routes) < original

    def route(self, event: dict[str, Any]) -> list[dict[str, Any]]:
        """Route an event through matching handlers. Returns handler results."""
        event_type = event.get("event_type", "")
        results: list[dict[str, Any]] = []

        for rule in self._routes:
            if not rule.enabled:
                continue
            if not self._matches(rule.pattern, event_type):
                continue

            handler = rule.handler
            result = handler.handle(event) if hasattr(handler, "handle") else handler(event)

            if result is not None:
                results.append(result)

        self._results.extend(results)
        return results

    def routes(self) -> list[dict[str, Any]]:
        """Return all registered routes."""
        return [
            {"pattern": r.pattern, "priority": r.priority, "enabled": r.enabled}
            for r in self._routes
        ]

    def results_log(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent routing results."""
        return self._results[-limit:]

    @staticmethod
    def _matches(pattern: str, event_type: str) -> bool:
        """Check if an event type matches a pattern (exact or prefix.*)."""
        if pattern == "*":
            return True
        if pattern == event_type:
            return True
        if pattern.endswith(".*"):
            prefix = pattern[:-2]
            return event_type.startswith(prefix + ".") or event_type == prefix
        return False
