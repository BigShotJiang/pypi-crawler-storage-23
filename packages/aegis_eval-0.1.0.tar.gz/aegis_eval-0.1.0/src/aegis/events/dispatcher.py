"""Event dispatcher with publish/subscribe pattern."""

from __future__ import annotations

import uuid
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class EventSubscription:
    """A subscription to one or more event types."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_types: list[str] = field(default_factory=list)  # empty = all events
    callback: Callable[[dict[str, Any]], None] | None = None
    filter_fn: Callable[[dict[str, Any]], bool] | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    active: bool = True


class EventDispatcher:
    """Central event bus for Aegis.

    Supports typed event publishing, subscriber registration with optional
    filters, event history, and dead-letter tracking.
    """

    def __init__(self, max_history: int = 10000) -> None:
        self._subscribers: dict[str, list[EventSubscription]] = defaultdict(list)
        self._global_subscribers: list[EventSubscription] = []
        self._history: list[dict[str, Any]] = []
        self._max_history = max_history
        self._dead_letters: list[dict[str, Any]] = []

    def subscribe(
        self,
        event_types: list[str] | None = None,
        callback: Callable[[dict[str, Any]], None] | None = None,
        filter_fn: Callable[[dict[str, Any]], bool] | None = None,
    ) -> EventSubscription:
        """Register a subscriber for specific event types or all events."""
        sub = EventSubscription(
            event_types=event_types or [],
            callback=callback,
            filter_fn=filter_fn,
        )
        if not event_types:
            self._global_subscribers.append(sub)
        else:
            for et in event_types:
                self._subscribers[et].append(sub)
        return sub

    def unsubscribe(self, subscription_id: str) -> bool:
        """Remove a subscription by ID."""
        # Check global subscribers
        for i, sub in enumerate(self._global_subscribers):
            if sub.id == subscription_id:
                self._global_subscribers.pop(i)
                return True
        # Check typed subscribers
        for _et, subs in self._subscribers.items():
            for i, sub in enumerate(subs):
                if sub.id == subscription_id:
                    subs.pop(i)
                    return True
        return False

    def publish(
        self,
        event_type: str,
        payload: dict[str, Any] | None = None,
        source: str = "",
    ) -> dict[str, Any]:
        """Publish an event and dispatch to matching subscribers."""
        event: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "event_type": event_type,
            "payload": payload or {},
            "source": source,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "delivered_to": 0,
            "failed_deliveries": 0,
        }

        # Collect matching subscribers
        targets = list(self._global_subscribers) + list(self._subscribers.get(event_type, []))

        delivered = 0
        failed = 0
        for sub in targets:
            if not sub.active:
                continue
            # Apply filter
            if sub.filter_fn and not sub.filter_fn(event):
                continue
            # Deliver
            if sub.callback:
                try:
                    sub.callback(event)
                    delivered += 1
                except Exception:
                    failed += 1
                    self._dead_letters.append(
                        {
                            "event": event,
                            "subscription_id": sub.id,
                            "timestamp": datetime.now(tz=UTC).isoformat(),
                        }
                    )

        event["delivered_to"] = delivered
        event["failed_deliveries"] = failed

        # Store in history
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history :]

        return event

    def history(self, event_type: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent events, optionally filtered by type."""
        events = self._history
        if event_type:
            events = [e for e in events if e["event_type"] == event_type]
        return events[-limit:]

    def dead_letters(self) -> list[dict[str, Any]]:
        """Return events that failed delivery."""
        return list(self._dead_letters)

    def subscriber_count(self, event_type: str | None = None) -> int:
        """Count active subscribers for an event type or total."""
        if event_type:
            return len([s for s in self._subscribers.get(event_type, []) if s.active])
        total = len([s for s in self._global_subscribers if s.active])
        for subs in self._subscribers.values():
            total += len([s for s in subs if s.active])
        return total

    def clear_history(self) -> int:
        """Clear event history, return count cleared."""
        count = len(self._history)
        self._history.clear()
        self._dead_letters.clear()
        return count
