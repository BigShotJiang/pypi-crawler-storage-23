"""Webhook delivery manager."""

from __future__ import annotations

import hashlib
import hmac
import json
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class WebhookConfig:
    """Configuration for a webhook endpoint."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    url: str = ""
    secret: str = ""
    event_types: list[str] = field(default_factory=list)  # empty = all
    active: bool = True
    max_retries: int = 3
    timeout_ms: int = 5000
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class WebhookDelivery:
    """Record of a webhook delivery attempt."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    webhook_id: str = ""
    event_id: str = ""
    url: str = ""
    status: str = "pending"  # pending, delivered, failed, retrying
    attempts: int = 0
    last_attempt_at: datetime | None = None
    response_code: int | None = None
    error: str | None = None
    payload_hash: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


class WebhookManager:
    """Manages webhook registrations and delivery tracking.

    Note: Actual HTTP delivery is not performed (requires httpx/aiohttp).
    This class manages the webhook lifecycle and delivery queue that an
    external worker would consume.
    """

    def __init__(self) -> None:
        self._webhooks: dict[str, WebhookConfig] = {}
        self._deliveries: list[WebhookDelivery] = []
        self._delivery_queue: list[dict[str, Any]] = []

    def register(
        self,
        url: str,
        secret: str = "",
        event_types: list[str] | None = None,
        max_retries: int = 3,
        timeout_ms: int = 5000,
        metadata: dict[str, Any] | None = None,
    ) -> WebhookConfig:
        """Register a new webhook endpoint."""
        config = WebhookConfig(
            url=url,
            secret=secret,
            event_types=event_types or [],
            max_retries=max_retries,
            timeout_ms=timeout_ms,
            metadata=metadata or {},
        )
        self._webhooks[config.id] = config
        return config

    def deregister(self, webhook_id: str) -> bool:
        """Remove a webhook registration."""
        if webhook_id in self._webhooks:
            del self._webhooks[webhook_id]
            return True
        return False

    def get(self, webhook_id: str) -> WebhookConfig | None:
        """Get a webhook by ID."""
        return self._webhooks.get(webhook_id)

    def list_webhooks(self, active_only: bool = False) -> list[WebhookConfig]:
        """List all registered webhooks."""
        hooks = list(self._webhooks.values())
        if active_only:
            hooks = [h for h in hooks if h.active]
        return hooks

    def enqueue(self, event: dict[str, Any]) -> list[WebhookDelivery]:
        """Enqueue an event for delivery to matching webhooks."""
        event_type = event.get("event_type", "")
        deliveries: list[WebhookDelivery] = []

        for webhook in self._webhooks.values():
            if not webhook.active:
                continue
            # Check event type match
            if webhook.event_types and event_type not in webhook.event_types:
                continue

            payload = json.dumps(event, default=str)
            payload_hash = hashlib.sha256(payload.encode()).hexdigest()[:16]

            delivery = WebhookDelivery(
                webhook_id=webhook.id,
                event_id=event.get("id", ""),
                url=webhook.url,
                status="pending",
                payload_hash=payload_hash,
            )
            self._deliveries.append(delivery)
            self._delivery_queue.append(
                {
                    "delivery_id": delivery.id,
                    "webhook_id": webhook.id,
                    "url": webhook.url,
                    "payload": event,
                    "secret": webhook.secret,
                    "max_retries": webhook.max_retries,
                    "timeout_ms": webhook.timeout_ms,
                }
            )
            deliveries.append(delivery)

        return deliveries

    def mark_delivered(self, delivery_id: str, response_code: int = 200) -> bool:
        """Mark a delivery as successfully completed."""
        delivery = self._find_delivery(delivery_id)
        if delivery is not None:
            delivery.status = "delivered"
            delivery.response_code = response_code
            delivery.attempts += 1
            delivery.last_attempt_at = datetime.now(tz=UTC)
            return True
        return False

    def mark_failed(
        self,
        delivery_id: str,
        error: str = "",
        response_code: int | None = None,
    ) -> bool:
        """Mark a delivery as failed."""
        delivery = self._find_delivery(delivery_id)
        if delivery is not None:
            delivery.attempts += 1
            delivery.last_attempt_at = datetime.now(tz=UTC)
            delivery.error = error
            delivery.response_code = response_code
            # Check if we should retry
            webhook = self._webhooks.get(delivery.webhook_id)
            max_retries = webhook.max_retries if webhook else 3
            if delivery.attempts < max_retries:
                delivery.status = "retrying"
            else:
                delivery.status = "failed"
            return True
        return False

    def process_queue(
        self,
        fail_webhook_ids: set[str] | None = None,
        response_code: int = 200,
        failure_code: int = 500,
    ) -> dict[str, int]:
        """Process queued deliveries with optional deterministic failure simulation.

        Failed deliveries that still have retries remaining are re-enqueued.
        This allows API/integration paths to validate success, failure, and
        retry behavior without requiring external HTTP workers.
        """
        fail_webhook_ids = fail_webhook_ids or set()
        queue = self.drain_queue()

        processed = 0
        delivered = 0
        failed = 0
        retried = 0

        for item in queue:
            processed += 1
            delivery_id = str(item.get("delivery_id", ""))
            webhook_id = str(item.get("webhook_id", ""))

            should_fail = webhook_id in fail_webhook_ids
            if should_fail:
                self.mark_failed(
                    delivery_id=delivery_id,
                    error="simulated_delivery_failure",
                    response_code=failure_code,
                )
                delivery = self._find_delivery(delivery_id)
                if delivery is not None and delivery.status == "retrying":
                    retried += 1
                    self._delivery_queue.append(item)
                else:
                    failed += 1
                continue

            self.mark_delivered(delivery_id=delivery_id, response_code=response_code)
            delivered += 1

        return {
            "processed": processed,
            "delivered": delivered,
            "failed": failed,
            "retried": retried,
            "queue_size": len(self._delivery_queue),
        }

    def pending_deliveries(self) -> list[dict[str, Any]]:
        """Return the pending delivery queue."""
        return list(self._delivery_queue)

    def drain_queue(self) -> list[dict[str, Any]]:
        """Drain and return the delivery queue."""
        queue = list(self._delivery_queue)
        self._delivery_queue.clear()
        return queue

    def delivery_history(
        self, webhook_id: str | None = None, limit: int = 100
    ) -> list[WebhookDelivery]:
        """Return delivery history, optionally filtered by webhook."""
        deliveries = self._deliveries
        if webhook_id:
            deliveries = [d for d in deliveries if d.webhook_id == webhook_id]
        return deliveries[-limit:]

    def compute_signature(self, payload: str, secret: str) -> str:
        """Compute HMAC-SHA256 signature for webhook payload verification."""
        return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

    def stats(self) -> dict[str, Any]:
        """Return delivery statistics."""
        total = len(self._deliveries)
        delivered = sum(1 for d in self._deliveries if d.status == "delivered")
        failed = sum(1 for d in self._deliveries if d.status == "failed")
        pending = sum(1 for d in self._deliveries if d.status in ("pending", "retrying"))
        return {
            "total_webhooks": len(self._webhooks),
            "active_webhooks": len([w for w in self._webhooks.values() if w.active]),
            "total_deliveries": total,
            "delivered": delivered,
            "failed": failed,
            "pending": pending,
            "queue_size": len(self._delivery_queue),
        }

    def _find_delivery(self, delivery_id: str) -> WebhookDelivery | None:
        for delivery in self._deliveries:
            if delivery.id == delivery_id:
                return delivery
        return None
