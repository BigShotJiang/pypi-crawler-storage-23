"""Aegis CLI — Typer-based command-line interface.

Re-exports the top-level :data:`app` Typer instance.
"""

from aegis.cli.main import app

__all__ = [
    "app",
]
