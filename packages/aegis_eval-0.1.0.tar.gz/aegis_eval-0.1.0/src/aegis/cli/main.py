"""Aegis CLI — Typer-based command-line interface.

Entry point registered as ``aegis`` in pyproject.toml.

Usage examples::

    aegis version
    aegis eval run --config eval.yaml --dimensions retention_accuracy,hallucination_rate
    aegis eval compare --runs RUN_A RUN_B
    aegis eval report --run RUN_ID --format json --output ./report.json
    aegis eval dimensions --domain legal
    aegis data download --dataset cuad
    aegis data list
    aegis data info --dataset cuad
    aegis memory health
    aegis memory audit
    aegis train start
    aegis train status --job-id JOB_ID
"""

from __future__ import annotations

import uuid
from contextlib import suppress
from pathlib import Path
from typing import Annotated, Any

import typer
import yaml  # type: ignore[import-untyped]
from rich.console import Console
from rich.table import Table

import aegis
from aegis.eval.engine import EvalConfig, EvalResult, Evaluator
from aegis.store.sqlite import SQLiteStore

console = Console()

# ---------------------------------------------------------------------------
# In-memory run store + SQLite persistence
# ---------------------------------------------------------------------------

_run_store: dict[str, EvalResult] = {}
_RUN_STORE_DIR = Path(".aegis") / "runs"

_store_instance: SQLiteStore | None = None


def _get_store() -> SQLiteStore:
    global _store_instance
    if _store_instance is None:
        _store_instance = SQLiteStore()
    return _store_instance


def _result_path(run_id: str) -> Path:
    return _RUN_STORE_DIR / f"{run_id}.json"


def _save_run_result(result: EvalResult) -> None:
    _run_store[result.run_id] = result
    _RUN_STORE_DIR.mkdir(parents=True, exist_ok=True)
    _result_path(result.run_id).write_text(
        result.model_dump_json(indent=2),
        encoding="utf-8",
    )
    with suppress(Exception):
        _get_store().save_eval_run(result)


def _load_run_result(run_id: str) -> EvalResult | None:
    if run_id in _run_store:
        return _run_store[run_id]

    path = _result_path(run_id)
    if path.exists():
        try:
            result: EvalResult = EvalResult.model_validate_json(path.read_text(encoding="utf-8"))
            _run_store[run_id] = result
            return result
        except Exception:
            pass

    # Fall back to SQLite store
    try:
        store_result = _get_store().get_eval_run(run_id)
        if store_result is not None:
            _run_store[run_id] = store_result
            return store_result
    except Exception:
        pass

    return None


# ---------------------------------------------------------------------------
# Top-level app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="aegis",
    help="Aegis — The Adaptive Intelligence Layer for AI Agents.",
    no_args_is_help=True,
)

# ---------------------------------------------------------------------------
# `aegis version`
# ---------------------------------------------------------------------------


@app.command()
def version() -> None:
    """Print the Aegis version and exit."""
    console.print(f"aegis {aegis.__version__}")


# ---------------------------------------------------------------------------
# `aegis eval` sub-command group
# ---------------------------------------------------------------------------

eval_app = typer.Typer(
    name="eval",
    help="Evaluation commands — run, compare, report, and inspect dimensions.",
    no_args_is_help=True,
)
app.add_typer(eval_app, name="eval")


def _load_yaml_config(path: Path) -> dict[str, Any]:
    """Load and return raw YAML data from *path*.

    Supports configs where the eval settings live under a top-level ``eval:``
    key (as in ``examples/eval.yaml``) as well as flat configs that map
    directly to :class:`AegisConfig`.
    """
    with open(path) as fh:
        data: dict[str, Any] = yaml.safe_load(fh) or {}
    return data


@eval_app.command("run")
def eval_run(
    config: Annotated[
        Path | None,
        typer.Option("--config", "-c", help="Path to eval.yaml configuration file."),
    ] = None,
    dimensions: Annotated[
        str | None,
        typer.Option(
            "--dimensions",
            "-d",
            help="Comma-separated list of dimension IDs to evaluate.",
        ),
    ] = None,
    agent: Annotated[
        str | None,
        typer.Option("--agent", "-a", help="Agent REST endpoint URL."),
    ] = None,
    domain: Annotated[
        str | None,
        typer.Option("--domain", help="Domain filter (e.g. legal, finance)."),
    ] = None,
    fail_under: Annotated[
        float | None,
        typer.Option("--fail-under", help="Minimum composite score to pass."),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output directory for results."),
    ] = None,
    scorer_mode: Annotated[
        str,
        typer.Option(
            "--scorer-mode",
            help="Scoring mode: mock, llm, hybrid, or auto.",
        ),
    ] = "auto",
) -> None:
    """Run an evaluation against an agent.

    Loads the config file (if provided), creates an Evaluator, executes the
    evaluation pipeline, and prints results as a rich table.  Exits with
    code 1 if the composite score falls below ``--fail-under``.

    When ``--config`` points to a YAML file the CLI extracts dimensions,
    num_scenarios, difficulty, seed, domain plugins, and CI thresholds
    from it.  CLI flags override any values found in the YAML.
    """
    # -------------------------------------------------------------------
    # 1. Load YAML config (if provided)
    # -------------------------------------------------------------------
    yaml_data: dict[str, Any] = {}
    if config is not None:
        if not config.exists():
            console.print(f"[red]Error:[/red] Config file not found: {config}")
            raise typer.Exit(code=1)

        yaml_data = _load_yaml_config(config)

    # The YAML may nest eval settings under an ``eval:`` key.
    eval_section: dict[str, Any] = yaml_data.get("eval", yaml_data)
    ci_section: dict[str, Any] = yaml_data.get("ci", {})

    # -------------------------------------------------------------------
    # 2. Extract fields from YAML (with sane defaults)
    # -------------------------------------------------------------------
    yaml_dimensions: list[str] | str = eval_section.get("dimensions", "all")
    yaml_domain_plugins: list[str] = eval_section.get("domain_plugins", [])
    yaml_scenarios: dict[str, Any] = eval_section.get("scenarios", {})
    yaml_num_scenarios: int = yaml_scenarios.get("count", 10)
    yaml_difficulty: str = yaml_scenarios.get("difficulty", "medium")
    yaml_seed: int | None = yaml_scenarios.get("seed")
    yaml_fail_under: float = ci_section.get("fail_under", 0.75)

    yaml_output_section: dict[str, Any] = eval_section.get("output", {})
    yaml_output_formats: list[str] = yaml_output_section.get("format", ["json"])
    if isinstance(yaml_output_formats, str):
        yaml_output_formats = [yaml_output_formats]
    yaml_output_path: str = yaml_output_section.get("path", "./results/")

    # -------------------------------------------------------------------
    # 3. Apply CLI overrides
    # -------------------------------------------------------------------
    dim_list: list[str] | str = yaml_dimensions
    if dimensions:
        dim_list = [d.strip() for d in dimensions.split(",")]

    domain_plugins: list[str] = yaml_domain_plugins
    if domain:
        domain_plugins = [domain]

    effective_fail_under: float = fail_under if fail_under is not None else yaml_fail_under
    effective_output_path: Path = output if output is not None else Path(yaml_output_path)

    # -------------------------------------------------------------------
    # 4. Build EvalConfig and run
    # -------------------------------------------------------------------
    yaml_scorer_mode = eval_section.get("scorer_mode", "auto")
    effective_scorer_mode = scorer_mode if scorer_mode != "auto" else yaml_scorer_mode

    eval_cfg = EvalConfig(
        dimensions=dim_list,
        domain_plugins=domain_plugins,
        num_scenarios=yaml_num_scenarios,
        difficulty=yaml_difficulty,
        output_formats=yaml_output_formats,
        seed=yaml_seed,
        scorer_mode=effective_scorer_mode,
    )

    evaluator = Evaluator(config=eval_cfg)
    result: EvalResult = evaluator.run()
    _save_run_result(result)

    # Optionally write results to the output directory
    effective_output_path.mkdir(parents=True, exist_ok=True)
    result_file = effective_output_path / f"{result.run_id}.json"
    result_file.write_text(result.model_dump_json(indent=2), encoding="utf-8")

    # -------------------------------------------------------------------
    # 5. Display results
    # -------------------------------------------------------------------
    table = Table(title="Aegis Evaluation Results", show_lines=True)
    table.add_column("Dimension", style="cyan", no_wrap=True)
    table.add_column("Score", justify="right", style="green")
    table.add_column("Status", justify="center")

    for dim_id, score in result.dimension_scores.items():
        status = "[green]PASS[/green]" if score >= effective_fail_under else "[red]FAIL[/red]"
        table.add_row(dim_id, f"{score:.4f}", status)

    console.print(table)

    # Composite summary
    passed = result.overall_score >= effective_fail_under
    status_str = "[green]PASSED[/green]" if passed else "[red]FAILED[/red]"
    console.print(
        f"\nComposite score: {result.overall_score:.4f}  |  "
        f"Threshold: {effective_fail_under:.4f}  |  Result: {status_str}"
    )
    console.print(f"Run ID: {result.run_id}")
    console.print(f"Results written to: {result_file}")

    if not passed:
        raise typer.Exit(code=1)


@eval_app.command("compare")
def eval_compare(
    runs: Annotated[
        list[str],
        typer.Option("--runs", "-r", help="Two run IDs to compare."),
    ],
) -> None:
    """Compare two evaluation runs side by side.

    Accepts exactly two run IDs and displays per-dimension score deltas.
    """
    if len(runs) != 2:
        console.print("[red]Error:[/red] Exactly two run IDs are required.")
        raise typer.Exit(code=1)

    run_a_id, run_b_id = runs[0], runs[1]

    # Load runs from the in-memory store.
    result_a = _load_run_result(run_a_id)
    if result_a is None:
        console.print(f"[red]Error:[/red] Run '{run_a_id}' not found in store.")
        raise typer.Exit(code=1)
    result_b = _load_run_result(run_b_id)
    if result_b is None:
        console.print(f"[red]Error:[/red] Run '{run_b_id}' not found in store.")
        raise typer.Exit(code=1)

    console.print(f"Comparing runs: [cyan]{run_a_id}[/cyan] vs [cyan]{run_b_id}[/cyan]")

    # Use the Evaluator.compare helper to compute deltas.
    evaluator = Evaluator()
    comparison = evaluator.compare(result_a, result_b)

    table = Table(title=f"Run Comparison: {run_a_id} vs {run_b_id}", show_lines=True)
    table.add_column("Dimension", style="cyan", no_wrap=True)
    table.add_column(f"{run_a_id}", justify="right", style="white")
    table.add_column(f"{run_b_id}", justify="right", style="white")
    table.add_column("Delta", justify="right")
    table.add_column("Direction", justify="center")

    for dim_id, delta in comparison["dimension_deltas"].items():
        score_a = result_a.dimension_scores.get(dim_id, 0.0)
        score_b = result_b.dimension_scores.get(dim_id, 0.0)

        if delta > 0:
            direction = "[green]improved[/green]"
            delta_str = f"[green]+{delta:.4f}[/green]"
        elif delta < 0:
            direction = "[red]regressed[/red]"
            delta_str = f"[red]{delta:.4f}[/red]"
        else:
            direction = "[dim]unchanged[/dim]"
            delta_str = f"{delta:.4f}"

        table.add_row(dim_id, f"{score_a:.4f}", f"{score_b:.4f}", delta_str, direction)

    console.print(table)

    overall_delta = comparison["overall_delta"]
    console.print(
        f"\nOverall delta: {overall_delta:+.4f}  |  "
        f"Improved: {len(comparison['improved'])}  |  "
        f"Regressed: {len(comparison['regressed'])}  |  "
        f"Unchanged: {len(comparison['unchanged'])}"
    )


def _render_html_report(result: EvalResult) -> str:
    """Render an EvalResult as a self-contained HTML report."""
    dim_rows = ""
    for dim_id, score in result.dimension_scores.items():
        color = "#2ecc71" if score >= 0.75 else "#e74c3c"
        dim_rows += (
            f"<tr><td>{dim_id}</td>"
            f'<td style="color:{color};text-align:right">{score:.4f}</td></tr>\n'
        )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Aegis Eval Report — {result.run_id}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; max-width: 900px; margin: 2rem auto; }}
    h1 {{ color: #2c3e50; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ddd; padding: 8px 12px; }}
    th {{ background: #34495e; color: #fff; text-align: left; }}
    .meta {{ color: #666; }}
  </style>
</head>
<body>
  <h1>Aegis Evaluation Report</h1>
  <p class="meta">Run ID: <code>{result.run_id}</code></p>
  <p class="meta">Agent ID: <code>{result.agent_id}</code></p>
  <p class="meta">Created: {result.created_at.isoformat()}</p>
  <h2>Overall Score: {result.overall_score:.4f}</h2>
  <table>
    <thead><tr><th>Dimension</th><th>Score</th></tr></thead>
    <tbody>
{dim_rows}
    </tbody>
  </table>
  <p class="meta">Judge Packets: {len(result.judge_packets)}</p>
</body>
</html>"""


@eval_app.command("report")
def eval_report(
    run: Annotated[
        str,
        typer.Option("--run", "-r", help="Run ID to generate a report for."),
    ],
    format: Annotated[
        str,
        typer.Option("--format", "-f", help="Report format: json, text, html, or pdf."),
    ] = "json",
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output file path."),
    ] = None,
) -> None:
    """Generate an evaluation report for a completed run.

    Supports JSON, text, HTML, and PDF output formats.
    """
    valid_formats = {"json", "text", "html", "pdf"}
    if format not in valid_formats:
        console.print(
            f"[red]Error:[/red] Invalid format '{format}'. "
            f"Choose from: {', '.join(sorted(valid_formats))}"
        )
        raise typer.Exit(code=1)

    result = _load_run_result(run)
    if result is None:
        console.print(f"[red]Error:[/red] Run '{run}' not found in store.")
        raise typer.Exit(code=1)

    if format == "json":
        report_content = result.model_dump_json(indent=2)
    elif format == "html":
        report_content = _render_html_report(result)
    elif format == "pdf":
        # PDF generation: render HTML then convert.  If weasyprint is not
        # installed we fall back to writing HTML and notifying the user.
        html_content = _render_html_report(result)
        try:
            from weasyprint import HTML  # type: ignore[import-not-found]

            if output is None:
                output = Path(f"{result.run_id}.pdf")
            output.parent.mkdir(parents=True, exist_ok=True)
            HTML(string=html_content).write_pdf(str(output))
            console.print(f"PDF report written to [cyan]{output}[/cyan].")
            return
        except ImportError:
            console.print(
                "[yellow]Warning:[/yellow] weasyprint is not installed. "
                "Falling back to HTML output. Install with: pip install weasyprint"
            )
            report_content = html_content
            format = "html"  # noqa: A001  — intentional shadow for the fallback
    else:
        # Human-readable text summary.
        lines: list[str] = []
        lines.append("Aegis Evaluation Report")
        lines.append("=======================")
        lines.append(f"Run ID:        {result.run_id}")
        lines.append(f"Agent ID:      {result.agent_id}")
        lines.append(f"Overall Score: {result.overall_score:.4f}")
        lines.append(f"Created At:    {result.created_at.isoformat()}")
        lines.append("")
        lines.append("Dimension Scores:")
        lines.append("-----------------")
        for dim_id, score in result.dimension_scores.items():
            lines.append(f"  {dim_id:<40s} {score:.4f}")
        lines.append("")
        lines.append(f"Judge Packets: {len(result.judge_packets)}")
        report_content = "\n".join(lines)

    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(report_content, encoding="utf-8")
        console.print(f"Report written to [cyan]{output}[/cyan] ({format.upper()} format).")
    else:
        console.print(report_content)


@eval_app.command("dimensions")
def eval_dimensions(
    domain: Annotated[
        str | None,
        typer.Option("--domain", "-d", help="Filter dimensions by domain."),
    ] = None,
) -> None:
    """List all available evaluation dimensions.

    Optionally filter by domain (e.g. ``--domain legal``).
    """
    from aegis.eval.dimensions.base import Dimension
    from aegis.eval.dimensions.registry import DimensionRegistry
    from aegis.plugins import FinancePlugin, LegalPlugin, SafetyPlugin

    registry = DimensionRegistry.instance()

    # Collect core dimensions plus built-in domain plugin dimensions.
    core_dims = registry.list_by_domain(domain) if domain else registry.all()
    plugin_dims: list[Dimension] = []
    for plugin in [LegalPlugin(), FinancePlugin(), SafetyPlugin()]:
        plugin_dims.extend(plugin.get_dimensions())

    if domain:
        plugin_dims = [d for d in plugin_dims if d.domain == domain]

    # Merge, deduplicating by id.
    seen_ids = {d.id for d in core_dims}
    dims = list(core_dims)
    for d in plugin_dims:
        if d.id not in seen_ids:
            dims.append(d)
            seen_ids.add(d.id)

    table = Table(title="Aegis Evaluation Dimensions", show_lines=True)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="white")
    table.add_column("Tier", justify="center", style="yellow")
    table.add_column("Domain", justify="center", style="magenta")
    table.add_column("Phase", justify="center", style="green")
    table.add_column("Description", style="dim")

    for dim in dims:
        table.add_row(
            dim.id,
            dim.name,
            str(dim.tier.value),
            dim.domain or "-",
            dim.phase.value,
            dim.description or "-",
        )

    console.print(table)
    console.print(f"\nTotal: {len(dims)} dimension(s)")


@eval_app.command("list")
def eval_list(
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Maximum number of runs to display."),
    ] = 20,
    agent: Annotated[
        str | None,
        typer.Option("--agent", "-a", help="Filter by agent ID."),
    ] = None,
) -> None:
    """List recent evaluation runs from the persistent store."""
    store = _get_store()
    rows = store.list_eval_runs(limit=limit, agent_id=agent)

    if not rows:
        console.print("[dim]No evaluation runs found.[/dim]")
        return

    table = Table(title="Evaluation Runs", show_lines=True)
    table.add_column("Run ID", style="cyan", no_wrap=True)
    table.add_column("Agent", style="white")
    table.add_column("Score", justify="right", style="green")
    table.add_column("Dims", justify="right", style="yellow")
    table.add_column("Created", style="dim")

    for row in rows:
        table.add_row(
            row.run_id[:12],
            row.agent_id or "-",
            f"{row.overall_score:.4f}",
            str(row.num_dimensions),
            row.created_at.strftime("%Y-%m-%d %H:%M"),
        )

    console.print(table)
    console.print(f"\nShowing {len(rows)} run(s)")


@eval_app.command("benchmark")
def eval_benchmark(
    suite: Annotated[
        str,
        typer.Option(
            "--suite",
            "-s",
            help="Benchmark suite name. Run `aegis eval benchmark-list` to see all available suites.",
        ),
    ],
    agent: Annotated[
        str | None,
        typer.Option("--agent", "-a", help="Agent endpoint URL."),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output file path for results."),
    ] = None,
) -> None:
    """Run a benchmark suite against an agent.

    Loads the named benchmark suite, runs it through the evaluator, and
    displays per-dimension scores as a rich table.  Optionally saves the
    full results to a JSON file.

    Example::

        aegis eval benchmark --suite legal
        aegis eval benchmark --suite legal-memory
        aegis eval benchmark --suite finance --output results.json
    """
    from aegis.eval.benchmarks.harness import BenchmarkHarness

    harness = BenchmarkHarness()
    valid_suites = harness.list_suites()
    if suite not in valid_suites:
        console.print(
            f"[red]Error:[/red] Unknown suite '{suite}'. Choose from: {', '.join(valid_suites)}"
        )
        raise typer.Exit(code=1)

    try:
        cases = harness.load_suite(suite)
    except KeyError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    console.print(f"\n[bold cyan]Running benchmark suite:[/bold cyan] {suite} ({len(cases)} cases)")

    # Determine domain for evaluator config.
    domain_plugins: list[str] = []
    if suite in (
        "legal",
        "legal-memory",
        "legal_memory",
        "legal-memory-scale",
        "legal_memory_scale",
    ):
        domain_plugins = ["legal"]
    elif suite in ("finance", "finance-memory", "finance_memory"):
        domain_plugins = ["finance"]
    elif suite in ("reward-integrity", "reward_integrity"):
        domain_plugins = ["safety"]

    eval_cfg = EvalConfig(
        dimensions="all",
        domain_plugins=domain_plugins,
        scorer_mode="mock",
    )
    evaluator = Evaluator(config=eval_cfg)
    results = harness.run(evaluator, cases, agent=agent)

    # Display results table.
    table = Table(
        title=f"Benchmark Results: {suite} ({results['suite_size']} cases)",
        show_lines=True,
    )
    table.add_column("Dimension", style="cyan", no_wrap=True)
    table.add_column("Score", justify="right", style="green")
    table.add_column("Status", justify="center")

    for dim_id, score in results.get("dimension_scores", {}).items():
        status = "[green]PASS[/green]" if score >= 0.75 else "[red]FAIL[/red]"
        table.add_row(dim_id, f"{score:.4f}", status)

    console.print(table)

    overall = results.get("overall_score", 0.0)
    passed = overall >= 0.75
    status_str = "[green]PASSED[/green]" if passed else "[red]FAILED[/red]"
    console.print(f"\nOverall score: {overall:.4f}  |  Threshold: 0.7500  |  Result: {status_str}")
    console.print(f"Run ID: {results.get('run_id', 'N/A')}")

    if output is not None:
        import json

        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(results.get("result", results), indent=2, default=str),
            encoding="utf-8",
        )
        console.print(f"Results written to: [cyan]{output}[/cyan]")


@eval_app.command("benchmark-list")
def eval_benchmark_list() -> None:
    """List all benchmark suites available in the harness."""
    from aegis.eval.benchmarks.harness import BenchmarkHarness

    harness = BenchmarkHarness()
    suites = harness.list_suites()

    table = Table(title="Available Benchmark Suites", show_lines=True)
    table.add_column("Suite", style="cyan", no_wrap=True)
    table.add_column("Cases", justify="right", style="green")
    table.add_column("Domains", style="yellow")

    for name in suites:
        try:
            cases = harness.load_suite(name)
        except KeyError:
            continue
        domains = sorted({case.domain for case in cases if case.domain})
        domain_text = ", ".join(domains) if domains else "-"
        table.add_row(name, str(len(cases)), domain_text)

    console.print(table)


# ---------------------------------------------------------------------------
# `aegis memory` sub-command group
# ---------------------------------------------------------------------------

memory_app = typer.Typer(
    name="memory",
    help="Memory subsystem commands — health checks and audit trail.",
    no_args_is_help=True,
)
app.add_typer(memory_app, name="memory")


@memory_app.command("health")
def memory_health() -> None:
    """Display the health status of the memory subsystem."""
    from aegis.memory.manager import MemoryManager

    manager = MemoryManager(enable_vectors=False)
    health = manager.health()

    table = Table(title="Memory Subsystem Health", show_lines=True)
    table.add_column("Metric", style="cyan", no_wrap=True)
    table.add_column("Value", justify="right", style="green")

    table.add_row("Total Entries", str(health.get("total_entries", 0)))
    table.add_row("Event Log Size", str(health.get("event_log_size", 0)))
    integrity = health.get("integrity_ok", False)
    integrity_str = "[green]OK[/green]" if integrity else "[red]FAILED[/red]"
    table.add_row("Integrity", integrity_str)

    tier_counts = health.get("tier_counts", {})
    for tier_name, count in tier_counts.items():
        table.add_row(f"Tier: {tier_name}", str(count))

    console.print(table)


@memory_app.command("audit")
def memory_audit() -> None:
    """Display the memory subsystem audit trail."""
    from aegis.memory.manager import MemoryManager

    manager = MemoryManager(enable_vectors=False)
    events = manager.audit_trail()

    if not events:
        console.print("[dim]No audit events recorded.[/dim]")
        return

    table = Table(title="Memory Audit Trail", show_lines=True)
    table.add_column("Timestamp", style="cyan", no_wrap=True)
    table.add_column("Operation", style="yellow")
    table.add_column("Key", style="white")
    table.add_column("Tier", style="magenta")
    table.add_column("Agent", style="dim")

    for event in events:
        table.add_row(
            event.timestamp.isoformat() if hasattr(event, "timestamp") else "-",
            event.operation.value if hasattr(event, "operation") else str(event.operation),
            getattr(event, "key", "-"),
            event.memory_tier.value if hasattr(event, "memory_tier") else "-",
            getattr(event, "agent_id", "-") or "-",
        )

    console.print(table)
    console.print(f"\nTotal events: {len(events)}")


# ---------------------------------------------------------------------------
# `aegis data` sub-command group
# ---------------------------------------------------------------------------

data_app = typer.Typer(
    name="data",
    help="Dataset management — download and inspect benchmark data.",
    no_args_is_help=True,
)
app.add_typer(data_app, name="data")

_DATASET_CHOICES = ["cuad", "legalbench", "financebench", "all"]


@data_app.command("download")
def data_download(
    dataset: Annotated[
        str,
        typer.Option(
            "--dataset",
            "-d",
            help="Dataset to download: cuad, legalbench, financebench, or all.",
        ),
    ] = "all",
    cache_dir: Annotated[
        Path | None,
        typer.Option("--cache-dir", help="Cache directory for downloaded data."),
    ] = None,
) -> None:
    """Download benchmark datasets for Aegis evaluation.

    Downloads the specified dataset (or all datasets) from HuggingFace and
    converts them to EvalCaseV1 format.
    """
    if dataset not in _DATASET_CHOICES:
        console.print(
            f"[red]Error:[/red] Unknown dataset '{dataset}'. "
            f"Choose from: {', '.join(_DATASET_CHOICES)}"
        )
        raise typer.Exit(code=1)

    targets = ["cuad", "legalbench", "financebench"] if dataset == "all" else [dataset]
    failures = 0

    for name in targets:
        console.print(f"\n[bold cyan]Downloading {name}...[/bold cyan]")
        try:
            cases = _load_dataset_by_name(name, cache_dir)
            console.print(f"  [green]Loaded {len(cases)} eval cases from {name}.[/green]")
        except Exception as exc:
            console.print(f"  [red]Failed to download {name}: {exc}[/red]")
            failures += 1

    if failures:
        console.print(f"\n[red]Completed with {failures} failure(s).[/red]")
        raise typer.Exit(code=1)
    else:
        console.print("\n[green]All requested datasets downloaded successfully.[/green]")


@data_app.command("list")
def data_list() -> None:
    """Show downloaded datasets and their sizes."""
    from aegis.data.downloader import DatasetDownloader

    downloader = DatasetDownloader()
    cached = downloader.list_cached()

    if not cached:
        console.print("[dim]No datasets downloaded yet.[/dim]")
        console.print("Run [cyan]aegis data download --dataset all[/cyan] to get started.")
        return

    table = Table(title="Downloaded Datasets", show_lines=True)
    table.add_column("Dataset", style="cyan", no_wrap=True)
    table.add_column("Size", justify="right", style="green")
    table.add_column("Status", justify="center")
    table.add_column("Path", style="dim")

    for entry in cached:
        size_mb = entry["size_bytes"] / (1024 * 1024)
        if size_mb >= 1.0:
            size_str = f"{size_mb:.1f} MB"
        else:
            size_kb = entry["size_bytes"] / 1024
            size_str = f"{size_kb:.1f} KB"

        status = "[green]complete[/green]" if entry["complete"] else "[yellow]partial[/yellow]"
        table.add_row(entry["name"], size_str, status, entry["path"])

    console.print(table)


@data_app.command("info")
def data_info(
    dataset: Annotated[
        str,
        typer.Option("--dataset", "-d", help="Dataset to inspect."),
    ],
) -> None:
    """Show detailed information about a downloaded dataset."""
    from aegis.data.downloader import DatasetDownloader

    downloader = DatasetDownloader()
    cached = downloader.list_cached()

    # Find the matching dataset.
    match = None
    for entry in cached:
        if entry["name"] == dataset or dataset in entry["name"]:
            match = entry
            break

    if match is None:
        console.print(
            f"[red]Error:[/red] Dataset '{dataset}' not found in cache. "
            "Run [cyan]aegis data download[/cyan] first."
        )
        raise typer.Exit(code=1)

    dataset_dir = Path(match["path"])
    data_file = dataset_dir / "data.jsonl"

    # Count lines in the data file.
    line_count = 0
    if data_file.exists():
        with open(data_file, encoding="utf-8") as fh:
            for _ in fh:
                line_count += 1

    checksum_file = dataset_dir / "sha256.txt"
    checksum = "N/A"
    if checksum_file.exists():
        checksum = checksum_file.read_text(encoding="utf-8").strip()[:16] + "..."

    table = Table(title=f"Dataset: {match['name']}", show_lines=True)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="green")

    size_mb = match["size_bytes"] / (1024 * 1024)
    table.add_row("Name", match["name"])
    table.add_row("Path", match["path"])
    table.add_row("Size", f"{size_mb:.2f} MB")
    table.add_row("Rows", str(line_count))
    table.add_row("Complete", "Yes" if match["complete"] else "No")
    table.add_row("Checksum (SHA256)", checksum)
    table.add_row("Integrity", "OK" if downloader.verify_checksum(dataset_dir) else "FAILED")

    console.print(table)


def _load_dataset_by_name(name: str, cache_dir: Path | None) -> list[Any]:
    """Load a dataset by name, returning a list of EvalCaseV1 instances."""
    if name == "cuad":
        from aegis.data.cuad import load_cuad

        return load_cuad(cache_dir=cache_dir)
    elif name == "legalbench":
        from aegis.data.legalbench import load_legalbench

        return load_legalbench(cache_dir=cache_dir)
    elif name == "financebench":
        from aegis.data.financebench import load_financebench

        return load_financebench(cache_dir=cache_dir)
    else:
        msg = f"Unknown dataset: {name}"
        raise ValueError(msg)


# ---------------------------------------------------------------------------
# `aegis train` sub-command group
# ---------------------------------------------------------------------------

train_app = typer.Typer(
    name="train",
    help="Training commands — start and monitor training jobs.",
    no_args_is_help=True,
)
app.add_typer(train_app, name="train")

# In-memory training job store.
_job_store: dict[str, dict[str, Any]] = {}


@train_app.command("start")
def train_start(
    model: Annotated[
        str,
        typer.Option("--model", "-m", help="Base model name."),
    ] = "base-agent-v1",
    trainer: Annotated[
        str,
        typer.Option("--trainer", "-t", help="Trainer type: amir-grpo or grpo-sg."),
    ] = "amir-grpo",
    learning_rate: Annotated[
        float,
        typer.Option("--lr", help="Learning rate."),
    ] = 1e-5,
) -> None:
    """Create a new training job and display its configuration."""
    from aegis.training.engine import AMIRGRPOTrainer, GRPOSGTrainer

    job_id = str(uuid.uuid4())[:8]

    if trainer == "grpo-sg":
        GRPOSGTrainer(model_name=model, learning_rate=learning_rate)
        trainer_display = "GRPO-SG"
    else:
        AMIRGRPOTrainer(model_name=model, learning_rate=learning_rate)
        trainer_display = "AMIR-GRPO"

    job_info: dict[str, Any] = {
        "job_id": job_id,
        "status": "created",
        "trainer": trainer_display,
        "model": model,
        "learning_rate": learning_rate,
    }
    _job_store[job_id] = job_info
    with suppress(Exception):
        _get_store().save_training_job(job_id, job_info)

    table = Table(title="Training Job Created", show_lines=True)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="green")

    table.add_row("Job ID", job_id)
    table.add_row("Status", "created")
    table.add_row("Trainer", trainer_display)
    table.add_row("Model", model)
    table.add_row("Learning Rate", f"{learning_rate:.2e}")

    console.print(table)


@train_app.command("status")
def train_status(
    job_id: Annotated[
        str,
        typer.Option("--job-id", "-j", help="Training job ID."),
    ],
) -> None:
    """Show the status of a training job."""
    if job_id not in _job_store:
        # Fall back to SQLite store
        try:
            stored = _get_store().get_training_job(job_id)
            if stored is not None:
                _job_store[job_id] = stored
        except Exception:
            pass
    if job_id not in _job_store:
        console.print(f"[red]Error:[/red] Job '{job_id}' not found.")
        raise typer.Exit(code=1)

    job_info = _job_store[job_id]

    table = Table(title=f"Training Job: {job_id}", show_lines=True)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="green")

    for key, value in job_info.items():
        table.add_row(key, str(value))

    console.print(table)
