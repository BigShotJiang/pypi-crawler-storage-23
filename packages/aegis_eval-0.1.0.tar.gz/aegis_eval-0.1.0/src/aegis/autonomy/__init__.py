"""Aegis Autonomy — progressive trust scoring and escalation policy engine.

Re-exports the trust engine, escalation engine, and supporting data classes.
"""

from aegis.autonomy.escalation import (
    EscalationEngine,
    EscalationEvent,
    EscalationPolicy,
    EscalationReason,
)
from aegis.autonomy.trust import (
    TrustConfig,
    TrustEngine,
    TrustLevel,
    TrustScore,
)

__all__ = [
    "TrustLevel",
    "TrustScore",
    "TrustConfig",
    "TrustEngine",
    "EscalationReason",
    "EscalationEvent",
    "EscalationPolicy",
    "EscalationEngine",
]
