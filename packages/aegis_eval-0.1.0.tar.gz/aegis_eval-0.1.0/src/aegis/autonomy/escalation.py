"""Escalation policy engine for the Aegis autonomy subsystem.

Provides configurable policies that determine when agent actions require
human review, records escalation events, and tracks resolution outcomes.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class EscalationReason(str, Enum):
    """Standard reasons for escalating an agent action to a human."""

    LOW_CONFIDENCE = "low_confidence"
    HIGH_RISK = "high_risk"
    NOVEL_SCENARIO = "novel_scenario"
    CONTRADICTORY_EVIDENCE = "contradictory_evidence"
    COMPLIANCE_REQUIRED = "compliance_required"
    TRUST_INSUFFICIENT = "trust_insufficient"
    EXPLICIT_REQUEST = "explicit_request"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class EscalationEvent:
    """A recorded escalation event."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = ""
    reason: EscalationReason = EscalationReason.LOW_CONFIDENCE
    task_summary: str = ""
    confidence: float = 0.0
    risk_level: float = 0.0
    recommended_action: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    resolved: bool = False
    resolution: str | None = None
    resolver: str | None = None


@dataclass
class EscalationPolicy:
    """A policy that defines conditions under which escalation is triggered."""

    name: str = ""
    conditions: dict[str, Any] = field(default_factory=dict)
    auto_escalate: bool = False
    notification_targets: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Default policies
# ---------------------------------------------------------------------------


def _default_policies() -> list[EscalationPolicy]:
    """Create sensible default escalation policies."""
    return [
        EscalationPolicy(
            name="low_confidence",
            conditions={"max_confidence": 0.4},
            auto_escalate=True,
            notification_targets=["ops-team"],
        ),
        EscalationPolicy(
            name="high_risk",
            conditions={"min_risk": 0.7},
            auto_escalate=True,
            notification_targets=["ops-team", "risk-team"],
        ),
        EscalationPolicy(
            name="compliance_required",
            conditions={"requires_compliance": True},
            auto_escalate=True,
            notification_targets=["compliance-team"],
        ),
        EscalationPolicy(
            name="novel_scenario",
            conditions={"max_confidence": 0.5, "min_risk": 0.5},
            auto_escalate=False,
            notification_targets=["ops-team"],
        ),
    ]


# ---------------------------------------------------------------------------
# EscalationEngine
# ---------------------------------------------------------------------------


class EscalationEngine:
    """Evaluates escalation policies and manages escalation event lifecycle.

    Checks incoming agent actions against registered policies, creates
    escalation events when thresholds are breached, and tracks resolution.
    """

    def __init__(self, policies: list[EscalationPolicy] | None = None) -> None:
        self._policies: list[EscalationPolicy] = (
            policies if policies is not None else _default_policies()
        )
        self._events: dict[str, EscalationEvent] = {}
        self._total_evaluations: int = 0

    # -- Policy management --------------------------------------------------

    def register_policy(self, policy: EscalationPolicy) -> None:
        """Add a new escalation policy.

        If a policy with the same name already exists it is replaced.
        """
        self._policies = [p for p in self._policies if p.name != policy.name]
        self._policies.append(policy)

    @property
    def policies(self) -> list[EscalationPolicy]:
        return list(self._policies)

    # -- Evaluation ---------------------------------------------------------

    def should_escalate(
        self,
        agent_id: str,
        confidence: float,
        risk: float,
        context: dict[str, Any] | None = None,
    ) -> EscalationEvent | None:
        """Evaluate whether an action should be escalated.

        Checks *confidence* and *risk* against all registered policies.
        Returns an ``EscalationEvent`` if any policy triggers, or ``None``.
        """
        self._total_evaluations += 1
        ctx = context or {}

        for policy in self._policies:
            triggered, reason = self._evaluate_policy(policy, confidence, risk, ctx)
            if triggered:
                recommended = self._recommend_action(reason, confidence, risk)
                event = EscalationEvent(
                    agent_id=agent_id,
                    reason=reason,
                    task_summary=ctx.get("task_summary", ""),
                    confidence=confidence,
                    risk_level=risk,
                    recommended_action=recommended,
                )
                if policy.auto_escalate:
                    self._events[event.id] = event
                return event

        return None

    def escalate(self, event: EscalationEvent) -> EscalationEvent:
        """Record an escalation event (created externally or from should_escalate).

        Returns the event with its id registered in the engine.
        """
        self._events[event.id] = event
        return event

    # -- Resolution ---------------------------------------------------------

    def resolve(
        self,
        event_id: str,
        resolution: str,
        resolver: str,
    ) -> EscalationEvent:
        """Mark an escalation as resolved.

        Raises ``KeyError`` if the event is not found.
        """
        event = self._events.get(event_id)
        if event is None:
            raise KeyError(f"Escalation event '{event_id}' not found")

        event.resolved = True
        event.resolution = resolution
        event.resolver = resolver
        return event

    # -- Queries ------------------------------------------------------------

    def pending_escalations(self, agent_id: str | None = None) -> list[EscalationEvent]:
        """Return unresolved escalation events, optionally filtered by agent."""
        events = [e for e in self._events.values() if not e.resolved]
        if agent_id is not None:
            events = [e for e in events if e.agent_id == agent_id]
        events.sort(key=lambda e: e.timestamp, reverse=True)
        return events

    def escalation_rate(self, agent_id: str | None = None) -> float:
        """Percentage of evaluations that resulted in escalation.

        If *agent_id* is provided, returns the rate for that agent only
        (using agent event count vs. total evaluations as an approximation).
        """
        if self._total_evaluations == 0:
            return 0.0

        if agent_id is not None:
            agent_events = [e for e in self._events.values() if e.agent_id == agent_id]
            # Agent-specific rate approximation: escalations / total evals
            return len(agent_events) / self._total_evaluations

        return len(self._events) / self._total_evaluations

    # -- Summary ------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return aggregate escalation statistics."""
        events = list(self._events.values())
        resolved = [e for e in events if e.resolved]
        pending = [e for e in events if not e.resolved]

        reason_dist: dict[str, int] = {}
        for e in events:
            reason_dist[e.reason.value] = reason_dist.get(e.reason.value, 0) + 1

        agent_dist: dict[str, int] = {}
        for e in events:
            agent_dist[e.agent_id] = agent_dist.get(e.agent_id, 0) + 1

        return {
            "total_events": len(events),
            "resolved": len(resolved),
            "pending": len(pending),
            "total_evaluations": self._total_evaluations,
            "escalation_rate": round(self.escalation_rate(), 4),
            "by_reason": reason_dist,
            "by_agent": agent_dist,
            "policies_count": len(self._policies),
        }

    # -- Internal -----------------------------------------------------------

    def _evaluate_policy(
        self,
        policy: EscalationPolicy,
        confidence: float,
        risk: float,
        context: dict[str, Any],
    ) -> tuple[bool, EscalationReason]:
        """Check whether a single policy triggers.

        Returns (triggered, reason).
        """
        conditions = policy.conditions

        # Explicit request always triggers
        if context.get("explicit_request"):
            return True, EscalationReason.EXPLICIT_REQUEST

        # Compliance-required check
        if conditions.get("requires_compliance") and context.get("requires_compliance"):
            return True, EscalationReason.COMPLIANCE_REQUIRED

        # Confidence threshold
        max_confidence = conditions.get("max_confidence")
        min_risk = conditions.get("min_risk")

        # Both conditions present: trigger if both are met
        if (
            max_confidence is not None
            and min_risk is not None
            and confidence <= max_confidence
            and risk >= min_risk
        ):
            # Determine the dominant reason
            if risk >= 0.7:
                return True, EscalationReason.HIGH_RISK
            if confidence <= 0.3:
                return True, EscalationReason.LOW_CONFIDENCE
            return True, EscalationReason.NOVEL_SCENARIO

        # Only confidence condition
        if max_confidence is not None and min_risk is None and confidence <= max_confidence:
            return True, EscalationReason.LOW_CONFIDENCE

        # Only risk condition
        if min_risk is not None and max_confidence is None and risk >= min_risk:
            return True, EscalationReason.HIGH_RISK

        # Contradictory evidence check
        if context.get("contradictory_evidence"):
            return True, EscalationReason.CONTRADICTORY_EVIDENCE

        # Trust insufficient (passed via context)
        if context.get("trust_insufficient"):
            return True, EscalationReason.TRUST_INSUFFICIENT

        return False, EscalationReason.LOW_CONFIDENCE

    def _recommend_action(
        self,
        reason: EscalationReason,
        confidence: float,
        risk: float,
    ) -> str:
        """Generate a recommended action string based on escalation context."""
        if reason == EscalationReason.HIGH_RISK:
            if risk >= 0.9:
                return "Block action and require senior reviewer approval"
            return "Require human review before proceeding"

        if reason == EscalationReason.LOW_CONFIDENCE:
            if confidence <= 0.2:
                return "Reject output and request re-generation with additional context"
            return "Flag for human review; provide agent output as draft"

        if reason == EscalationReason.COMPLIANCE_REQUIRED:
            return "Route to compliance team for mandatory review"

        if reason == EscalationReason.CONTRADICTORY_EVIDENCE:
            return "Present conflicting evidence to reviewer for resolution"

        if reason == EscalationReason.NOVEL_SCENARIO:
            return "Route to domain expert for guidance on novel scenario"

        if reason == EscalationReason.TRUST_INSUFFICIENT:
            return "Require supervised execution until trust improves"

        if reason == EscalationReason.EXPLICIT_REQUEST:
            return "Route to requested reviewer"

        return "Require human review"
