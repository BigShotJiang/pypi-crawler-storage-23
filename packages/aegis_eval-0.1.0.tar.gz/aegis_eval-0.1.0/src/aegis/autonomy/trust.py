"""Progressive trust scoring for autonomous agents.

Agents earn higher trust levels as they demonstrate consistent competence
across interactions.  Trust levels gate the autonomy an agent is granted
and determine when human escalation is required.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import IntEnum
from typing import Any

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class TrustLevel(IntEnum):
    """Progressive trust levels from fully supervised to expert autonomy."""

    SUPERVISED = 1
    GUIDED = 2
    SEMI_AUTONOMOUS = 3
    AUTONOMOUS = 4
    EXPERT = 5


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class TrustScore:
    """Current trust state for an agent."""

    agent_id: str = ""
    level: TrustLevel = TrustLevel.SUPERVISED
    score: float = 0.0  # 0.0 - 1.0
    eval_history: list[float] = field(default_factory=list)
    escalation_count: int = 0
    total_interactions: int = 0
    domain_scores: dict[str, float] = field(default_factory=dict)
    last_evaluated: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TrustConfig:
    """Configuration for trust level thresholds and progression rules."""

    thresholds: dict[TrustLevel, float] = field(
        default_factory=lambda: {
            TrustLevel.SUPERVISED: 0.0,
            TrustLevel.GUIDED: 0.3,
            TrustLevel.SEMI_AUTONOMOUS: 0.5,
            TrustLevel.AUTONOMOUS: 0.7,
            TrustLevel.EXPERT: 0.85,
        }
    )
    min_interactions_per_level: int = 50
    decay_on_failure: float = 0.05


# ---------------------------------------------------------------------------
# TrustEngine
# ---------------------------------------------------------------------------


class TrustEngine:
    """Manages progressive trust scoring for agents.

    Tracks interaction outcomes, computes exponentially-weighted moving
    average trust scores, and determines trust levels based on configurable
    thresholds.
    """

    def __init__(self, config: TrustConfig | None = None) -> None:
        self._config = config or TrustConfig()
        self._agents: dict[str, TrustScore] = {}

    @property
    def config(self) -> TrustConfig:
        return self._config

    # -- Registration -------------------------------------------------------

    def register_agent(self, agent_id: str) -> TrustScore:
        """Register a new agent with baseline trust.

        If already registered the existing score is returned unchanged.
        """
        if agent_id in self._agents:
            return self._agents[agent_id]

        ts = TrustScore(
            agent_id=agent_id,
            level=TrustLevel.SUPERVISED,
            score=0.0,
        )
        self._agents[agent_id] = ts
        return ts

    # -- Interaction recording ----------------------------------------------

    def record_interaction(
        self,
        agent_id: str,
        success: bool,
        score: float,
        domain: str | None = None,
    ) -> TrustScore:
        """Update trust based on an interaction outcome.

        *score* should be in [0, 1].  The trust score is updated using an
        exponentially-weighted moving average so that recent interactions
        have a larger effect.  Failed interactions additionally apply a
        configurable decay penalty.

        Raises ``KeyError`` if the agent is not registered.
        """
        ts = self._require_agent(agent_id)

        # Clamp score
        score = max(0.0, min(1.0, score))

        # Record in history
        ts.eval_history.append(score)
        ts.total_interactions += 1

        # EWMA update (alpha adapts based on interaction count for stability)
        alpha = min(0.3, 2.0 / (ts.total_interactions + 1))
        ts.score = ts.score * (1 - alpha) + score * alpha

        # Failure decay
        if not success:
            ts.score = max(0.0, ts.score - self._config.decay_on_failure)

        # Domain-level tracking
        if domain is not None:
            prev_domain = ts.domain_scores.get(domain, 0.0)
            ts.domain_scores[domain] = prev_domain * (1 - alpha) + score * alpha

        # Re-evaluate level
        ts.level = self._compute_level(ts)
        ts.last_evaluated = datetime.now(tz=UTC)

        return ts

    # -- Trust evaluation ---------------------------------------------------

    def evaluate_trust(self, agent_id: str) -> TrustLevel:
        """Determine the current trust level for an agent.

        Raises ``KeyError`` if the agent is not registered.
        """
        ts = self._require_agent(agent_id)
        ts.level = self._compute_level(ts)
        ts.last_evaluated = datetime.now(tz=UTC)
        return ts.level

    def can_act_autonomously(self, agent_id: str, action_risk: float) -> bool:
        """Whether the agent can perform an action without human approval.

        Higher risk actions require higher trust.  The effective threshold
        is the AUTONOMOUS level threshold scaled by the action risk.

        ``action_risk`` should be in [0, 1].
        """
        ts = self._require_agent(agent_id)
        # Scale threshold: risk=0 uses GUIDED threshold, risk=1 uses EXPERT
        guided_threshold = self._config.thresholds[TrustLevel.GUIDED]
        expert_threshold = self._config.thresholds[TrustLevel.EXPERT]
        effective_threshold = guided_threshold + action_risk * (expert_threshold - guided_threshold)
        return ts.score >= effective_threshold

    def escalation_required(self, agent_id: str, task_complexity: float) -> bool:
        """Whether human review is needed for a given task complexity.

        ``task_complexity`` should be in [0, 1].  Escalation is required
        when the agent's trust score is insufficient for the complexity or
        when the agent is still at a supervised level.
        """
        ts = self._require_agent(agent_id)
        if ts.level == TrustLevel.SUPERVISED:
            return True
        # Higher complexity requires higher trust
        required = self._config.thresholds[TrustLevel.SEMI_AUTONOMOUS] + task_complexity * 0.3
        return ts.score < required

    # -- Escalation ---------------------------------------------------------

    def record_escalation(self, agent_id: str, reason: str) -> None:
        """Record that an escalation happened for this agent.

        Escalations apply a small trust penalty (half the failure decay)
        because they indicate the agent's output required human review.
        """
        ts = self._require_agent(agent_id)
        ts.escalation_count += 1
        ts.score = max(0.0, ts.score - self._config.decay_on_failure * 0.5)
        ts.level = self._compute_level(ts)
        ts.metadata.setdefault("escalation_reasons", []).append(
            {
                "reason": reason,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

    # -- Lookup -------------------------------------------------------------

    def get_trust(self, agent_id: str) -> TrustScore | None:
        """Return the trust score for an agent, or ``None``."""
        return self._agents.get(agent_id)

    # -- Summary ------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return aggregate trust engine statistics."""
        agents = list(self._agents.values())
        if not agents:
            return {"total_agents": 0}

        level_dist: dict[str, int] = {}
        for a in agents:
            level_name = a.level.name
            level_dist[level_name] = level_dist.get(level_name, 0) + 1

        scores = [a.score for a in agents]
        mean_score = sum(scores) / len(scores) if scores else 0.0

        return {
            "total_agents": len(agents),
            "level_distribution": level_dist,
            "mean_trust_score": round(mean_score, 4),
            "total_interactions": sum(a.total_interactions for a in agents),
            "total_escalations": sum(a.escalation_count for a in agents),
        }

    # -- Internal -----------------------------------------------------------

    def _require_agent(self, agent_id: str) -> TrustScore:
        ts = self._agents.get(agent_id)
        if ts is None:
            raise KeyError(f"Agent '{agent_id}' is not registered with the trust engine")
        return ts

    def _compute_level(self, ts: TrustScore) -> TrustLevel:
        """Determine trust level from score and interaction count.

        An agent must meet both the score threshold and the minimum
        interaction count for a level.
        """
        determined = TrustLevel.SUPERVISED

        # Walk from highest to lowest level
        for level in sorted(self._config.thresholds.keys(), reverse=True):
            threshold = self._config.thresholds[level]
            # Interaction gate: need min_interactions * level_index interactions
            min_interactions = self._config.min_interactions_per_level * (level.value - 1)
            if ts.score >= threshold and ts.total_interactions >= min_interactions:
                determined = level
                break

        return determined
