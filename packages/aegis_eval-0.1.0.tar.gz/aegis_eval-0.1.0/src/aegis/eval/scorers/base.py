"""Abstract base class for all Aegis scoring backends.

Every scorer converts raw agent output and ground truth into a normalised
``[0.0, 1.0]`` float score.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Scorer(ABC):
    """Base scorer interface.

    Subclasses implement :meth:`score` to produce a float in ``[0.0, 1.0]``.
    """

    @abstractmethod
    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        **kwargs: Any,
    ) -> float:
        """Compute a normalised score.

        Args:
            agent_output: The raw output produced by the agent.
            ground_truth: The expected/reference answer.
            **kwargs: Scorer-specific extra parameters (e.g. rubric,
                retrieval trace).

        Returns:
            A float in ``[0.0, 1.0]`` where 1.0 is a perfect score.
        """
        ...
