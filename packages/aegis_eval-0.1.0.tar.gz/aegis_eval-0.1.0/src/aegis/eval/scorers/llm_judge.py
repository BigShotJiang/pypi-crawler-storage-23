"""LLM-judge scorer — model-based evaluation via structured prompting.

Sends the agent output and ground truth to one or more LLM judges with a
scoring rubric and parses a normalised score from the response.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from typing import Any

from aegis.core.settings import AegisSettings
from aegis.eval.scorers.base import Scorer
from aegis.eval.scorers.llm_backend import (
    AggregateUsageStats,
    AnthropicLLMBackend,
    HTTPLLMBackend,
    LLMBackend,
    MockLLMBackend,
)

logger = logging.getLogger(__name__)

JUDGE_PROMPT_TEMPLATE = """\
You are an expert evaluation judge. Score how well the agent output matches \
the expected answer according to the rubric below.

Return a JSON object with two fields:
- "score": a float between 0.0 and 1.0
- "reasoning": a brief explanation of your score

## Rubric
{rubric}

## Agent Output
{agent_output}

## Expected Answer
{ground_truth}
"""


def _detect_provider(model: str) -> str:
    """Infer the LLM provider from the model name."""
    lower = model.lower()
    if any(lower.startswith(p) for p in ("gpt-", "o1-", "o3-", "o4-")):
        return "openai"
    if lower.startswith("claude-"):
        return "anthropic"
    return "unknown"


class LLMJudgeScorer(Scorer):
    """Score agent outputs using an LLM as a judge.

    Args:
        model: The model identifier for the judge LLM (e.g.
            ``"gpt-4o"``, ``"claude-3-opus-20240229"``).
        rubric: A textual scoring rubric that the judge will follow.
        temperature: Sampling temperature for the judge call.
        max_retries: Number of retries on transient API failures.
        backend: An optional :class:`LLMBackend` instance. If not
            provided, one is chosen automatically based on environment.

    The judge is prompted with a structured template containing the agent
    output, ground truth, and rubric, and is asked to return a JSON object
    with a ``score`` field in ``[0.0, 1.0]`` and a ``reasoning`` field.
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        rubric: str = "",
        temperature: float = 0.0,
        max_retries: int = 2,
        backend: LLMBackend | None = None,
        max_cost_usd: float | None = None,
        budget_fallback_score: float = 0.5,
    ) -> None:
        self.model = model
        self.rubric = rubric
        self.temperature = temperature
        self.max_retries = max_retries
        self._backend = backend
        self._cache: dict[str, float] = {}
        self._max_cost_usd = max_cost_usd if max_cost_usd is None else max(0.0, float(max_cost_usd))
        self._budget_fallback_score = max(0.0, min(1.0, float(budget_fallback_score)))
        self._spent_cost_usd = 0.0
        self._budget_exhausted = False
        self._blocked_calls = 0

    @property
    def usage_stats(self) -> AggregateUsageStats | None:
        """Return accumulated usage stats from the underlying backend.

        Returns ``None`` if no backend has been initialised yet.
        """
        if self._backend is not None:
            return self._backend.total_usage
        return None

    @property
    def max_cost_usd(self) -> float | None:
        """Configured spend cap for this scorer run."""
        return self._max_cost_usd

    @property
    def spent_cost_usd(self) -> float:
        """Accumulated estimated spend recorded by this scorer."""
        return self._spent_cost_usd

    @property
    def remaining_budget_usd(self) -> float | None:
        """Remaining budget in USD, or ``None`` when uncapped."""
        if self._max_cost_usd is None:
            return None
        return max(0.0, self._max_cost_usd - self._spent_cost_usd)

    @property
    def budget_exhausted(self) -> bool:
        """Whether the scorer has exhausted its configured budget."""
        return self._budget_exhausted

    @property
    def blocked_calls(self) -> int:
        """Number of judge calls skipped due to budget exhaustion."""
        return self._blocked_calls

    def configure_budget(
        self,
        max_cost_usd: float | None,
        *,
        fallback_score: float | None = None,
    ) -> None:
        """Configure (or disable) per-run LLM budget limits."""
        self._max_cost_usd = max(0.0, float(max_cost_usd)) if max_cost_usd is not None else None
        if fallback_score is not None:
            self._budget_fallback_score = max(0.0, min(1.0, float(fallback_score)))
        self._budget_exhausted = (
            self._max_cost_usd is not None and self._spent_cost_usd >= self._max_cost_usd
        )

    def reset_budget_tracking(self, *, clear_cache: bool = False) -> None:
        """Reset spend/guardrail counters between evaluation runs."""
        self._spent_cost_usd = 0.0
        self._budget_exhausted = False
        self._blocked_calls = 0
        if clear_cache:
            self._cache.clear()

    def budget_summary(self) -> dict[str, float | int | bool | None]:
        """Return budget telemetry for diagnostics/observability."""
        return {
            "max_cost_usd": self._max_cost_usd,
            "spent_cost_usd": round(self._spent_cost_usd, 8),
            "remaining_budget_usd": (
                round(self.remaining_budget_usd, 8)
                if self.remaining_budget_usd is not None
                else None
            ),
            "budget_exhausted": self._budget_exhausted,
            "blocked_calls": self._blocked_calls,
        }

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        **kwargs: Any,
    ) -> float:
        """Call the LLM judge and parse the returned score.

        Returns:
            A float in ``[0.0, 1.0]``.
        """
        rubric = (
            kwargs.get("rubric", self.rubric)
            or "Score the agent output based on correctness and completeness."
        )
        gt_formatted = self._format_ground_truth(ground_truth)

        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric=rubric,
            agent_output=str(agent_output),
            ground_truth=gt_formatted,
        )

        # Cache key via SHA-256 hash of the full prompt
        cache_key = hashlib.sha256(prompt.encode()).hexdigest()
        if cache_key in self._cache:
            return self._cache[cache_key]

        if self._max_cost_usd is not None and self._spent_cost_usd >= self._max_cost_usd:
            self._budget_exhausted = True
            self._blocked_calls += 1
            fallback = kwargs.get("budget_fallback_score", self._budget_fallback_score)
            try:
                fallback_score = float(fallback)
            except (TypeError, ValueError):
                fallback_score = self._budget_fallback_score
            fallback_score = max(0.0, min(1.0, fallback_score))
            self._cache[cache_key] = fallback_score
            return fallback_score

        if self._backend is None:
            self._backend = self._get_default_backend()
        backend = self._backend
        raw_response = backend.complete(prompt, self.model, self.temperature)

        score = self._parse_score(raw_response)
        score = max(0.0, min(1.0, score))

        last_usage = getattr(backend, "last_usage", None)
        if last_usage is not None:
            try:
                call_cost = float(getattr(last_usage, "estimated_cost_usd", 0.0))
            except (TypeError, ValueError):
                call_cost = 0.0
            if call_cost > 0:
                self._spent_cost_usd += call_cost
            if self._max_cost_usd is not None and self._spent_cost_usd >= self._max_cost_usd:
                self._budget_exhausted = True

        self._cache[cache_key] = score
        return score

    def _get_default_backend(self) -> LLMBackend:
        """Select a backend based on env vars and model name.

        Resolution order:
        1. ``AEGIS_LLM_PROVIDER`` explicit override (openai / anthropic / mock)
        2. ``AEGIS_LLM_MODEL`` overrides ``self.model``
        3. Auto-detect provider from model name
        4. Resolve API key: provider-specific first, then generic fallback
        5. No key found → ``MockLLMBackend()``
        """
        settings = AegisSettings()

        # Model override
        model_override = settings.llm.model
        if model_override:
            self.model = model_override

        # Explicit provider override
        provider = settings.llm.provider.lower()
        if provider == "mock":
            return MockLLMBackend()

        # Auto-detect from model name when no explicit provider
        if not provider:
            provider = _detect_provider(self.model)

        # Resolve API key (aegis-specific → standard env var → generic fallback)
        if provider == "anthropic":
            api_key = settings.llm.anthropic_api_key or settings.llm.generic_api_key
            if api_key:
                return AnthropicLLMBackend(api_key=api_key)
        elif provider == "openai":
            api_key = settings.llm.openai_api_key or settings.llm.generic_api_key
            if api_key:
                return HTTPLLMBackend(api_key=api_key)
        else:
            # Unknown provider — try generic key with OpenAI-compatible backend
            api_key = settings.llm.generic_api_key
            if api_key:
                return HTTPLLMBackend(api_key=api_key)

        return MockLLMBackend()

    @staticmethod
    def _format_ground_truth(ground_truth: Any) -> str:
        """Convert ground_truth to a readable string for the prompt."""
        if isinstance(ground_truth, dict):
            lines = [f"- {k}: {v}" for k, v in ground_truth.items()]
            return "\n".join(lines)
        return str(ground_truth)

    @staticmethod
    def _parse_score(response: str) -> float:
        """Extract a score float from the LLM response.

        Tries JSON parsing first, then falls back to regex extraction.
        Logs a warning if both methods fail.
        """
        # Try JSON parsing
        try:
            data = json.loads(response)
            if isinstance(data, dict) and "score" in data:
                return float(data["score"])
        except (json.JSONDecodeError, TypeError, ValueError):
            pass

        # Fallback: regex for a decimal number
        match = re.search(r"\b([01](?:\.\d+)?)\b", response)
        if match:
            return float(match.group(1))

        logger.warning(
            "Failed to parse score from LLM response (JSON and regex both failed). "
            "Raw response: %.500s",
            response,
        )
        return 0.0
