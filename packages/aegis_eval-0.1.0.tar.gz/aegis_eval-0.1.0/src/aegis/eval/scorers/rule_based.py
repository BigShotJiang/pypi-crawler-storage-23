"""Rule-based scorer — deterministic scoring via configurable rules.

Supports exact match, substring containment, regex patterns, numeric-range
checks, fuzzy matching, JSON field checks, and composite rules (all_of /
any_of).  New rule types can be added by extending :data:`RULE_HANDLERS`.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from difflib import SequenceMatcher
from typing import Any

from aegis.eval.scorers.base import Scorer

# ---------------------------------------------------------------------------
# Rule handler type and registry
# ---------------------------------------------------------------------------

RuleHandler = Callable[[str, Any, dict[str, Any]], float]


def _exact_match(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if agent_output matches ground_truth exactly (case-insensitive by default)."""
    case_sensitive: bool = config.get("case_sensitive", False)
    a = agent_output.strip()
    b = str(ground_truth).strip()
    if not case_sensitive:
        a = a.lower()
        b = b.lower()
    return 1.0 if a == b else 0.0


def _contains(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the configured substring appears in agent_output (case-insensitive)."""
    substring = str(config.get("substring", str(ground_truth)))
    return 1.0 if substring.lower() in agent_output.lower() else 0.0


def _not_contains(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the configured substring does NOT appear in agent_output."""
    substring = str(config.get("substring", str(ground_truth)))
    return 1.0 if substring.lower() not in agent_output.lower() else 0.0


def _regex(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the pattern matches somewhere in agent_output."""
    pattern = config.get("pattern", "")
    if not pattern:
        return 0.0
    try:
        return 1.0 if re.search(pattern, agent_output) else 0.0
    except re.error:
        return 0.0


def _json_field_match(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if ground_truth[field] value appears in agent_output."""
    field = config.get("field", "")
    if not field or not isinstance(ground_truth, dict):
        return 0.0
    expected_value = str(ground_truth.get(field, ""))
    if not expected_value:
        return 0.0
    return 1.0 if expected_value.lower() in agent_output.lower() else 0.0


def _json_field_present(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the field string appears in agent_output."""
    field = config.get("field", "")
    if not field:
        return 0.0
    return 1.0 if field.lower() in agent_output.lower() else 0.0


def _numeric_range(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the first number found in agent_output is within [min, max]."""
    match = re.search(r"-?\d+(?:\.\d+)?", agent_output)
    if not match:
        return 0.0
    value = float(match.group())
    lo = float(config.get("min", float("-inf")))
    hi = float(config.get("max", float("inf")))
    return 1.0 if lo <= value <= hi else 0.0


def _length_range(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if len(agent_output) is within [min, max]."""
    length = len(agent_output)
    lo = int(config.get("min", 0))
    hi = float(config.get("max", float("inf")))
    return 1.0 if lo <= length <= hi else 0.0


def _fuzzy_match(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """Return SequenceMatcher ratio between agent_output and ground_truth."""
    return SequenceMatcher(
        None,
        agent_output.lower().strip(),
        str(ground_truth).lower().strip(),
    ).ratio()


def _ngram_overlap(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """Compute n-gram overlap (BLEU-like) between agent output and ground truth.

    Config keys:
        ``n`` (default 2): The n-gram size.
        ``threshold`` (default 0.0): Minimum overlap to return 1.0 (binary mode).
            When 0.0, the raw overlap ratio is returned.
    """
    n = int(config.get("n", 2))
    threshold = float(config.get("threshold", 0.0))
    output_tokens = agent_output.lower().split()
    truth_tokens = str(ground_truth).lower().split()

    if len(truth_tokens) < n or len(output_tokens) < n:
        return 1.0 if output_tokens == truth_tokens else 0.0

    def _get_ngrams(tokens: list[str], size: int) -> list[tuple[str, ...]]:
        return [tuple(tokens[i : i + size]) for i in range(len(tokens) - size + 1)]

    truth_ngrams = _get_ngrams(truth_tokens, n)
    output_ngrams = _get_ngrams(output_tokens, n)
    if not truth_ngrams:
        return 0.0

    truth_set = set(truth_ngrams)
    matches = sum(1 for ng in output_ngrams if ng in truth_set)
    overlap = matches / len(truth_ngrams)

    if threshold > 0:
        return 1.0 if overlap >= threshold else 0.0
    return min(1.0, overlap)


def _contains_all(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if ALL configured substrings appear in agent_output."""
    substrings = config.get("substrings", [])
    if not substrings:
        return 0.0
    lower = agent_output.lower()
    found = sum(1 for s in substrings if str(s).lower() in lower)
    return found / len(substrings)


def _word_count_range(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if word count of agent_output is within [min, max]."""
    words = len(agent_output.split())
    lo = int(config.get("min", 0))
    hi = float(config.get("max", float("inf")))
    return 1.0 if lo <= words <= hi else 0.0


def _regex_match(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the pattern matches somewhere in agent_output. Alias for regex."""
    return _regex(agent_output, ground_truth, config)


def _json_valid(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if the agent_output is valid JSON."""
    import json as _json

    try:
        _json.loads(agent_output)
        return 1.0
    except (ValueError, TypeError):
        return 0.0


def _sentence_count_range(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """1.0 if sentence count is within [min, max]."""
    sentences = [s.strip() for s in agent_output.split(".") if s.strip()]
    lo = int(config.get("min", 0))
    hi = float(config.get("max", float("inf")))
    return 1.0 if lo <= len(sentences) <= hi else 0.0


def _apply_rules(agent_output: str, ground_truth: Any, rules: list[dict[str, Any]]) -> list[float]:
    """Apply a list of rule configs and return individual scores."""
    results: list[float] = []
    for rule in rules:
        rule_type = rule.get("type", "")
        handler = RULE_HANDLERS.get(rule_type)
        if handler is None:
            continue
        score = handler(agent_output, ground_truth, rule)
        results.append(score)
    return results


def _all_of(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """Average of recursively applying sub-rules."""
    sub_rules: list[dict[str, Any]] = config.get("rules", [])
    if not sub_rules:
        return 0.0
    scores = _apply_rules(agent_output, ground_truth, sub_rules)
    return sum(scores) / len(scores) if scores else 0.0


def _any_of(agent_output: str, ground_truth: Any, config: dict[str, Any]) -> float:
    """Max of recursively applying sub-rules.

    Supports two config forms:
    - ``{"rules": [{...}, {...}]}`` (canonical)
    - ``{"substrings": ["foo", "bar"]}`` (shorthand)
    """
    sub_rules: list[dict[str, Any]] = config.get("rules", [])
    if not sub_rules:
        substrings = config.get("substrings", [])
        if isinstance(substrings, list) and substrings:
            sub_rules = [{"type": "contains", "substring": str(s)} for s in substrings]
        else:
            return 0.0

    scores = _apply_rules(agent_output, ground_truth, sub_rules)
    return max(scores) if scores else 0.0


RULE_HANDLERS: dict[str, RuleHandler] = {
    "exact_match": _exact_match,
    "contains": _contains,
    "not_contains": _not_contains,
    "regex": _regex,
    "regex_match": _regex_match,
    "json_field_match": _json_field_match,
    "json_field_present": _json_field_present,
    "json_valid": _json_valid,
    "numeric_range": _numeric_range,
    "length_range": _length_range,
    "word_count_range": _word_count_range,
    "sentence_count_range": _sentence_count_range,
    "fuzzy_match": _fuzzy_match,
    "ngram_overlap": _ngram_overlap,
    "contains_all": _contains_all,
    "all_of": _all_of,
    "any_of": _any_of,
}


class RuleBasedScorer(Scorer):
    """Deterministic scoring via a bank of configurable rules.

    Args:
        rules: A list of rule specifications, each a dict with at
            minimum a ``"type"`` key (e.g. ``"exact_match"``,
            ``"contains"``, ``"regex"``).  Additional keys are
            rule-type-specific.

    Example::

        scorer = RuleBasedScorer(rules=[
            {"type": "exact_match"},
            {"type": "contains", "substring": "expected_phrase"},
        ])
        score = scorer.score(agent_output="...", ground_truth="...")
    """

    def __init__(self, rules: list[dict[str, Any]] | None = None) -> None:
        self.rules = rules or []

    def _auto_rules(self, ground_truth: Any) -> list[dict[str, Any]]:
        """Infer rules automatically from ground_truth structure."""
        if isinstance(ground_truth, dict):
            # Adversarial resistance: resisted + should_not_contain
            if ground_truth.get("resisted") is True and "should_not_contain" in ground_truth:
                items = ground_truth["should_not_contain"]
                if isinstance(items, list):
                    return [{"type": "not_contains", "substring": s} for s in items]
                return [{"type": "not_contains", "substring": str(items)}]

            # Regex-based negation patterns
            if "should_not_contain_patterns" in ground_truth:
                patterns = ground_truth["should_not_contain_patterns"]
                if isinstance(patterns, list):
                    # For negated regex: we want 1.0 if the pattern does NOT match.
                    # We use not_contains with the pattern check done via all_of wrapping.
                    # Actually, we generate regex rules with negation handled by inverting.
                    # But the spec says "generate regex rules (negated)". We'll wrap
                    # each regex in an any_of that returns 1.0 - regex_score.
                    # Simpler: just generate not_contains rules from patterns.
                    rules: list[dict[str, Any]] = []
                    for p in patterns:
                        rules.append({"type": "regex", "pattern": p, "_negate": True})
                    return rules

            # Dict with string values -> contains rules for each value
            string_values = {k: v for k, v in ground_truth.items() if isinstance(v, str)}
            if string_values:
                return [{"type": "contains", "substring": v} for v in string_values.values()]

            # Fallback for dict
            return [{"type": "exact_match"}]

        if isinstance(ground_truth, str):
            return [{"type": "fuzzy_match"}]

        # Fallback
        return [{"type": "exact_match"}]

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        **kwargs: Any,
    ) -> float:
        """Apply configured rules and return the average pass rate.

        Rules are resolved in order: kwargs["rules"] > self.rules > auto_rules.

        Returns:
            A float in ``[0.0, 1.0]`` — the average score across all rules.
        """
        rules_override = kwargs.get("rules")
        if isinstance(rules_override, list):
            rules = rules_override
        elif self.rules:
            rules = self.rules
        else:
            rules = self._auto_rules(ground_truth)

        output_str = str(agent_output)

        scores: list[float] = []
        for rule in rules:
            rule_type = rule.get("type", "")
            handler = RULE_HANDLERS.get(rule_type)
            if handler is None:
                continue

            # Handle negated regex rules from auto_rules
            if rule.get("_negate"):
                raw = handler(output_str, ground_truth, rule)
                scores.append(1.0 - raw)
            else:
                scores.append(handler(output_str, ground_truth, rule))

        if not scores:
            return 0.0

        avg = sum(scores) / len(scores)
        return max(0.0, min(1.0, avg))
