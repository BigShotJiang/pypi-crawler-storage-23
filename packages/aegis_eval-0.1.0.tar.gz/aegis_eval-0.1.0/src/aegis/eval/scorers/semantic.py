"""Semantic scorer — embedding-based similarity scoring.

Uses sentence-transformer embeddings to compute cosine similarity between
the agent output and the ground-truth reference.  Falls back to ``0.0``
when the ``sentence-transformers`` package is not installed.
"""

from __future__ import annotations

from typing import Any

from aegis.eval.scorers.base import Scorer


class SemanticScorer(Scorer):
    """Embedding-based cosine-similarity scorer.

    Args:
        model_name: The sentence-transformers model identifier to load.
            Defaults to ``"all-MiniLM-L6-v2"`` for fast local inference.

    Note:
        Requires the optional ``sentence-transformers`` dependency.
        Install via ``pip install aegis[eval-semantic]`` or
        ``pip install sentence-transformers``.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self.model_name = model_name
        self._model: Any = None

    def _load_model(self) -> Any:
        """Lazy-load the sentence-transformer model on first use."""
        if self._model is None:
            try:
                import sentence_transformers as st

                self._model = st.SentenceTransformer(self.model_name)
            except ImportError:
                self._model = None
        return self._model

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        **kwargs: Any,
    ) -> float:
        """Compute cosine similarity between output and ground truth.

        Returns:
            A float in ``[0.0, 1.0]``.  Returns ``0.0`` if the
            ``sentence-transformers`` package is not available.
        """
        # Convert inputs to strings
        if isinstance(agent_output, dict):
            output_text = " ".join(str(v) for v in agent_output.values())
        else:
            output_text = str(agent_output)

        if isinstance(ground_truth, dict):
            truth_text = " ".join(str(v) for v in ground_truth.values())
        else:
            truth_text = str(ground_truth)

        if not output_text.strip() or not truth_text.strip():
            return 0.0

        model = self._load_model()
        if model is None:
            return 0.0

        # Encode both texts with normalized embeddings (cosine sim = dot product)
        embeddings = model.encode(
            [output_text, truth_text],
            normalize_embeddings=True,
            show_progress_bar=False,
        )

        emb_a = embeddings[0]
        emb_b = embeddings[1]

        # Compute dot product (= cosine similarity since embeddings are normalized)
        try:
            import numpy as np

            similarity = float(np.dot(emb_a, emb_b))
        except ImportError:
            # Manual dot product fallback
            similarity = sum(float(a) * float(b) for a, b in zip(emb_a, emb_b, strict=False))

        # Clamp to [0, 1]
        return max(0.0, min(1.0, similarity))
