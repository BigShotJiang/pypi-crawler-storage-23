"""Aegis eval scorers — rule-based, semantic, and LLM-judge scoring backends."""
