"""Pluggable LLM backends for the judge scorer."""

from __future__ import annotations

import json
import logging
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_RETRYABLE_EXCEPTIONS = (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout)

# ---------------------------------------------------------------------------
# Pricing dictionaries (per 1M tokens)
# ---------------------------------------------------------------------------

_OPENAI_PRICING: dict[str, tuple[float, float]] = {
    # (input_cost_per_1M, output_cost_per_1M)
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
}

_ANTHROPIC_PRICING: dict[str, tuple[float, float]] = {
    "claude-3.5-sonnet": (3.00, 15.00),
    "claude-3-haiku": (0.25, 1.25),
}


# ---------------------------------------------------------------------------
# UsageStats dataclass
# ---------------------------------------------------------------------------


@dataclass
class UsageStats:
    """Token usage and cost statistics for a single LLM call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    latency_seconds: float = 0.0
    model: str = ""


@dataclass
class AggregateUsageStats:
    """Accumulated usage statistics across multiple LLM calls."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
    total_latency_seconds: float = 0.0
    call_count: int = 0
    calls: list[UsageStats] = field(default_factory=list)

    def add(self, stats: UsageStats) -> None:
        """Accumulate a single call's stats into the aggregate."""
        self.prompt_tokens += stats.prompt_tokens
        self.completion_tokens += stats.completion_tokens
        self.total_tokens += stats.total_tokens
        self.estimated_cost_usd += stats.estimated_cost_usd
        self.total_latency_seconds += stats.latency_seconds
        self.call_count += 1
        self.calls.append(stats)


# ---------------------------------------------------------------------------
# Helper: estimate cost from token counts
# ---------------------------------------------------------------------------


def _estimate_cost(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    pricing: dict[str, tuple[float, float]],
) -> float:
    """Return estimated cost in USD given a pricing table.

    Matches model names by prefix so that e.g. ``"gpt-4o-2024-08-06"``
    matches the ``"gpt-4o"`` pricing entry.  When multiple keys match,
    the longest (most specific) prefix wins.
    """
    lower = model.lower()
    best_key: str | None = None
    best_len = 0
    for key in pricing:
        if lower.startswith(key) and len(key) > best_len:
            best_key = key
            best_len = len(key)
    if best_key is not None:
        input_price, output_price = pricing[best_key]
        return (prompt_tokens * input_price + completion_tokens * output_price) / 1_000_000
    return 0.0


# ---------------------------------------------------------------------------
# Response validation helpers
# ---------------------------------------------------------------------------


def _validate_openai_response(data: Any) -> str:
    """Validate an OpenAI-compatible chat completion response structure.

    Raises :class:`ValueError` if required fields are missing.
    Returns the message content string.
    """
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict response, got {type(data).__name__}")
    choices = data.get("choices")
    if not isinstance(choices, list) or len(choices) == 0:
        raise ValueError("Response missing 'choices' array or it is empty")
    first = choices[0]
    if not isinstance(first, dict):
        raise ValueError(f"Expected dict for choices[0], got {type(first).__name__}")
    message = first.get("message")
    if not isinstance(message, dict) or "content" not in message:
        raise ValueError("Response choices[0] missing 'message.content'")
    return str(message["content"])


def _validate_anthropic_response(data: Any) -> str:
    """Validate an Anthropic Messages API response structure.

    Raises :class:`ValueError` if required fields are missing.
    Returns the text content string.
    """
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict response, got {type(data).__name__}")
    content = data.get("content")
    if not isinstance(content, list) or len(content) == 0:
        raise ValueError("Response missing 'content' array or it is empty")
    first = content[0]
    if not isinstance(first, dict) or "text" not in first:
        raise ValueError("Response content[0] missing 'text' field")
    return str(first["text"])


def _retry_with_backoff(
    fn: object,
    *args: object,
    max_retries: int = 3,
    base_delay: float = 1.0,
    **kwargs: object,
) -> object:
    """Call *fn* with exponential backoff on transient failures.

    Retries on HTTP status codes 429/5xx and on connection/timeout errors.
    Raises the last exception after *max_retries* attempts.
    """
    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            return fn(*args, **kwargs)  # type: ignore[operator]
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code not in _RETRYABLE_STATUS_CODES:
                raise
            last_exc = exc
        except _RETRYABLE_EXCEPTIONS as exc:
            last_exc = exc

        if attempt < max_retries:
            delay = base_delay * (2**attempt)
            logger.warning("LLM backend retry %d/%d after %.1fs", attempt + 1, max_retries, delay)
            time.sleep(delay)

    raise last_exc  # type: ignore[misc]


class LLMBackend(ABC):
    """Abstract base for LLM completion backends."""

    def __init__(self) -> None:
        self._last_usage: UsageStats | None = None
        self._total_usage: AggregateUsageStats = AggregateUsageStats()

    @abstractmethod
    def complete(self, prompt: str, model: str, temperature: float) -> str:
        """Send prompt to the model and return the raw text response."""
        ...

    @property
    def last_usage(self) -> UsageStats | None:
        """Return usage stats from the most recent ``complete()`` call."""
        return self._last_usage

    @property
    def total_usage(self) -> AggregateUsageStats:
        """Return accumulated usage stats across all ``complete()`` calls."""
        return self._total_usage

    def _record_usage(self, stats: UsageStats) -> None:
        """Store usage stats for last-call and aggregate tracking."""
        self._last_usage = stats
        self._total_usage.add(stats)


class MockLLMBackend(LLMBackend):
    """Deterministic mock backend for offline testing.

    Uses text similarity heuristics to produce scores without an API call.
    Fully deterministic — same inputs always produce same outputs.
    """

    def __init__(self) -> None:
        super().__init__()

    def complete(self, prompt: str, model: str, temperature: float) -> str:
        # Extract agent_output and ground_truth from the structured prompt
        agent_output = self._extract_section(prompt, "Agent Output")
        ground_truth = self._extract_section(prompt, "Expected Answer")

        if not agent_output or not ground_truth:
            return json.dumps({"score": 0.0, "reasoning": "Could not parse prompt sections."})

        # Compute deterministic score using multiple signals
        scores = []

        # 1. Text overlap via SequenceMatcher
        similarity = SequenceMatcher(None, agent_output.lower(), ground_truth.lower()).ratio()
        scores.append(similarity)

        # 2. Key term overlap
        gt_terms = set(ground_truth.lower().split())
        ao_terms = set(agent_output.lower().split())
        if gt_terms:
            term_overlap = len(gt_terms & ao_terms) / len(gt_terms)
            scores.append(term_overlap)

        # 3. Length ratio penalty (penalize very short or very long responses)
        if len(ground_truth) > 0:
            ratio = len(agent_output) / len(ground_truth)
            length_score = max(0.0, 1.0 - abs(1.0 - ratio) * 0.5)
            scores.append(length_score)

        final_score = sum(scores) / len(scores) if scores else 0.0
        final_score = max(0.0, min(1.0, final_score))

        return json.dumps(
            {
                "score": round(final_score, 4),
                "reasoning": f"Mock evaluation: text_similarity={similarity:.3f}, term_overlap={term_overlap if gt_terms else 0:.3f}",
            }
        )

    @staticmethod
    def _extract_section(prompt: str, section_name: str) -> str:
        """Extract content between ## Section Name and the next ## or end."""
        pattern = rf"## {re.escape(section_name)}\s*\n(.*?)(?=\n## |\Z)"
        match = re.search(pattern, prompt, re.DOTALL)
        return match.group(1).strip() if match else ""


class HTTPLLMBackend(LLMBackend):
    """Real HTTP backend for OpenAI-compatible APIs."""

    def __init__(self, api_key: str, base_url: str = "https://api.openai.com/v1") -> None:
        super().__init__()
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

    def complete(self, prompt: str, model: str, temperature: float) -> str:
        return str(_retry_with_backoff(self._do_complete, prompt, model, temperature))

    def _do_complete(self, prompt: str, model: str, temperature: float) -> str:
        start = time.monotonic()
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{self._base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": temperature,
                    "max_tokens": 1024,
                },
            )
            response.raise_for_status()
            data = response.json()

        latency = time.monotonic() - start

        # Validate response structure
        text = _validate_openai_response(data)

        # Parse usage stats
        usage = data.get("usage") or {}
        prompt_tokens = int(usage.get("prompt_tokens", 0))
        completion_tokens = int(usage.get("completion_tokens", 0))
        total_tokens = int(usage.get("total_tokens", prompt_tokens + completion_tokens))

        stats = UsageStats(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            estimated_cost_usd=_estimate_cost(
                model,
                prompt_tokens,
                completion_tokens,
                _OPENAI_PRICING,
            ),
            latency_seconds=latency,
            model=model,
        )
        self._record_usage(stats)

        return text


class AnthropicLLMBackend(LLMBackend):
    """HTTP backend for the Anthropic Messages API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.anthropic.com",
    ) -> None:
        super().__init__()
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")

    def complete(self, prompt: str, model: str, temperature: float) -> str:
        return str(_retry_with_backoff(self._do_complete, prompt, model, temperature))

    def _do_complete(self, prompt: str, model: str, temperature: float) -> str:
        start = time.monotonic()
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{self._base_url}/v1/messages",
                headers={
                    "x-api-key": self._api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": temperature,
                    "max_tokens": 1024,
                },
            )
            response.raise_for_status()
            data = response.json()

        latency = time.monotonic() - start

        # Validate response structure
        text = _validate_anthropic_response(data)

        # Parse usage stats
        usage = data.get("usage") or {}
        prompt_tokens = int(usage.get("input_tokens", 0))
        completion_tokens = int(usage.get("output_tokens", 0))
        total_tokens = prompt_tokens + completion_tokens

        stats = UsageStats(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            estimated_cost_usd=_estimate_cost(
                model,
                prompt_tokens,
                completion_tokens,
                _ANTHROPIC_PRICING,
            ),
            latency_seconds=latency,
            model=model,
        )
        self._record_usage(stats)

        return text
