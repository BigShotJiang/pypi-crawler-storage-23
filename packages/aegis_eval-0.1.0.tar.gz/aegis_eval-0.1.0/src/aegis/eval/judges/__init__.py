"""Aegis eval judges — triangulated judgment pipeline."""
