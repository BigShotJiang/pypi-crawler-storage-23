"""Abstract base class for Aegis judges.

A judge aggregates scores from one or more :class:`Scorer` backends and
produces a :class:`JudgePacketV1`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from aegis.core.types import JudgePacketV1


class Judge(ABC):
    """Base judge interface.

    Subclasses combine scorer outputs into a single
    :class:`JudgePacketV1` with an ensemble score and disagreement signal.
    """

    @abstractmethod
    def judge(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        """Produce a triangulated judgment.

        Args:
            agent_output: The raw output produced by the agent.
            ground_truth: The expected/reference answer.
            context: Optional additional context for the scorers.

        Returns:
            A :class:`JudgePacketV1` with ensemble score, component
            scores, disagreement, and explanation.
        """
        ...
