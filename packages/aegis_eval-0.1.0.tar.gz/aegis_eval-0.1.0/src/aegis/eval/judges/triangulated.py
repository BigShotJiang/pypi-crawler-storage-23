"""Triangulated judge — combines rule, semantic, and LLM-judge scores.

The triangulated judge is the default scoring strategy in Aegis.  It runs
three independent scoring backends and combines their outputs into a single
:class:`JudgePacketV1` with a disagreement signal.
"""

from __future__ import annotations

import statistics
from typing import Any

from aegis.core.types import JudgePacketV1
from aegis.eval.judges.base import Judge
from aegis.eval.scorers.llm_judge import LLMJudgeScorer
from aegis.eval.scorers.rule_based import RuleBasedScorer
from aegis.eval.scorers.semantic import SemanticScorer


class TriangulatedJudge(Judge):
    """Combine rule-based, semantic, and LLM-judge scores.

    The ensemble score is a weighted average of the three component scores.
    The disagreement signal captures how much the scorers diverge, which is
    useful for flagging ambiguous or adversarial cases that need human review.

    Args:
        rule_scorer: A :class:`RuleBasedScorer` instance (or ``None`` to
            skip rule scoring).
        semantic_scorer: A :class:`SemanticScorer` instance (or ``None``).
        llm_scorer: A :class:`LLMJudgeScorer` instance (or ``None``).
        weights: A 3-tuple of floats ``(rule, semantic, llm)`` that sum
            to ``1.0``.  Defaults to equal weighting.
    """

    def __init__(
        self,
        rule_scorer: RuleBasedScorer | None = None,
        semantic_scorer: SemanticScorer | None = None,
        llm_scorer: LLMJudgeScorer | None = None,
        weights: tuple[float, float, float] = (1 / 3, 1 / 3, 1 / 3),
        adaptive_weighting: bool = True,
    ) -> None:
        self.rule_scorer = rule_scorer or RuleBasedScorer()
        self.semantic_scorer = semantic_scorer or SemanticScorer()
        self.llm_scorer = llm_scorer or LLMJudgeScorer()
        self.weights = self._normalise_weights(weights)
        self.adaptive_weighting = adaptive_weighting

    @staticmethod
    def _normalise_weights(weights: tuple[float, float, float]) -> tuple[float, float, float]:
        clamped = [max(0.0, float(weight)) for weight in weights]
        total = sum(clamped)
        if total <= 0:
            return (1 / 3, 1 / 3, 1 / 3)
        return (clamped[0] / total, clamped[1] / total, clamped[2] / total)

    def _resolve_weights(
        self,
        rule_score: float,
        semantic_score: float,
        llm_score: float,
        context: dict[str, Any] | None = None,
    ) -> tuple[float, float, float]:
        # Explicit override in context wins.
        raw_override = (context or {}).get("weights")
        if isinstance(raw_override, (list, tuple)) and len(raw_override) == 3:
            try:
                override = (
                    float(raw_override[0]),
                    float(raw_override[1]),
                    float(raw_override[2]),
                )
                return self._normalise_weights(override)
            except (TypeError, ValueError):
                pass

        resolved = self.weights
        if not self.adaptive_weighting:
            return resolved

        if self.llm_scorer.budget_exhausted:
            return self._normalise_weights((resolved[0], resolved[1], 0.0))

        disagreement = abs(rule_score - semantic_score)
        if disagreement <= 0.05:
            return resolved

        # When rule and semantic diverge, rely slightly more on the LLM judge.
        llm_boost = min(0.2, disagreement * 0.5)
        adjusted = (
            max(0.0, resolved[0] - llm_boost / 2),
            max(0.0, resolved[1] - llm_boost / 2),
            max(0.0, resolved[2] + llm_boost),
        )
        return self._normalise_weights(adjusted)

    def judge(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        """Run all three scorers and produce a triangulated packet.

        Args:
            agent_output: The raw agent response.
            ground_truth: The expected answer or behaviour.
            context: Optional extra context forwarded to scorers.

        Returns:
            A :class:`JudgePacketV1` with component scores, ensemble
            average, and disagreement metric.
        """
        kwargs: dict[str, Any] = {}
        if context:
            kwargs.update(context)

        rule_score = self.rule_scorer.score(agent_output, ground_truth, **kwargs)
        semantic_score = self.semantic_scorer.score(agent_output, ground_truth, **kwargs)
        llm_score = self.llm_scorer.score(agent_output, ground_truth, **kwargs)

        scores = [rule_score, semantic_score, llm_score]
        w_rule, w_semantic, w_llm = self._resolve_weights(
            rule_score,
            semantic_score,
            llm_score,
            context,
        )

        ensemble = w_rule * rule_score + w_semantic * semantic_score + w_llm * llm_score
        # Clamp to [0, 1] in case weights don't perfectly normalise
        ensemble = max(0.0, min(1.0, ensemble))

        # Disagreement: normalised standard deviation (0 = unanimous)
        disagreement = min(1.0, statistics.stdev(scores)) if len(scores) >= 2 else 0.0

        return JudgePacketV1(
            eval_case_id=context.get("eval_case_id", "") if context else "",
            dimension_id=context.get("dimension_id", "") if context else "",
            rule_score=rule_score,
            semantic_score=semantic_score,
            judge_scores={"llm_judge": llm_score},
            ensemble_score=ensemble,
            disagreement=disagreement,
            explanation=(
                f"Triangulated: rule={rule_score:.3f}, "
                f"semantic={semantic_score:.3f}, "
                f"llm={llm_score:.3f} "
                f"weights=({w_rule:.2f},{w_semantic:.2f},{w_llm:.2f}) "
                f"-> ensemble={ensemble:.3f}"
            ),
            evidence={
                "weights": {
                    "rule": round(w_rule, 6),
                    "semantic": round(w_semantic, 6),
                    "llm": round(w_llm, 6),
                },
                "adaptive_weighting": self.adaptive_weighting,
                "llm_budget": self.llm_scorer.budget_summary(),
            },
        )
