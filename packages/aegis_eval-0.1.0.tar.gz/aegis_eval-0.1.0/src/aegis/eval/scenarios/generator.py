"""Scenario generator — produces EvalCaseV1 instances for eval runs.

The generator synthesizes evaluation scenarios for a given set of
dimensions, difficulty levels, and optional domain constraints.  When
handcrafted templates exist for a dimension (see
:mod:`aegis.eval.scenarios.templates`), the generator cycles through
them; otherwise it synthesizes heuristic fallback scenarios derived from
the dimension metadata and requested difficulty.
"""

from __future__ import annotations

from aegis.core.types import EvalCaseV1
from aegis.eval.dimensions.base import Dimension
from aegis.eval.scenarios.templates import SCENARIO_TEMPLATES


class ScenarioGenerator:
    """Generate :class:`EvalCaseV1` test cases for evaluation runs.

    Args:
        suite_id: Identifier for the evaluation suite these cases
            belong to.
        default_difficulty: Default difficulty level (1-5) when not
            otherwise specified.

    Example::

        gen = ScenarioGenerator(suite_id="run-001")
        cases = gen.generate(
            dimensions=[dim],
            num_scenarios=10,
            difficulty="medium",
        )
    """

    DIFFICULTY_MAP: dict[str, int] = {
        "easy": 1,
        "medium": 3,
        "hard": 5,
    }

    def __init__(
        self,
        suite_id: str = "default",
        default_difficulty: int = 3,
    ) -> None:
        self.suite_id = suite_id
        self.default_difficulty = default_difficulty

    @staticmethod
    def _difficulty_focus(difficulty: int) -> str:
        if difficulty <= 1:
            return "single-step extraction with direct grounding"
        if difficulty == 2:
            return "short reasoning with one supporting citation"
        if difficulty == 3:
            return "multi-point reasoning with explicit justification"
        if difficulty == 4:
            return "cross-source reconciliation and contradiction handling"
        return "high-complexity synthesis under ambiguity and risk controls"

    def _heuristic_fallback_case(
        self,
        dimension: Dimension,
        difficulty: int,
        scenario_index: int,
        domain: str | None,
    ) -> EvalCaseV1:
        domain_name = domain or dimension.domain or "general"
        focus = dimension.description or f"Assess {dimension.name} performance."
        difficulty_focus = self._difficulty_focus(difficulty)
        prompt = (
            f"{domain_name.title()} evaluation scenario {scenario_index + 1}: "
            f"Assess '{dimension.name}' ({dimension.id}) for an agent response. "
            f"Priority: {focus} Operating mode: {difficulty_focus}."
        )
        context = {
            "dimension": dimension.id,
            "dimension_name": dimension.name,
            "domain": domain_name,
            "difficulty_focus": difficulty_focus,
            "scenario_index": scenario_index + 1,
        }
        expected = {
            "quality_goal": focus,
            "must_include": [
                "evidence-backed rationale",
                "clear final recommendation",
            ],
            "dimension_target": dimension.id,
            "difficulty_profile": difficulty_focus,
        }

        return EvalCaseV1(
            suite_id=self.suite_id,
            dimension_id=dimension.id,
            tier=dimension.tier,
            domain=domain_name,
            prompt=prompt,
            context=context,
            expected=expected,
            difficulty=difficulty,
            tags=[dimension.id, f"tier_{dimension.tier.value}", "heuristic_fallback"],
        )

    def generate(
        self,
        dimensions: list[Dimension],
        num_scenarios: int = 10,
        difficulty: str = "medium",
        domain: str | None = None,
    ) -> list[EvalCaseV1]:
        """Generate eval cases for the given dimensions.

        Args:
            dimensions: The dimensions to generate scenarios for.
            num_scenarios: Total number of scenarios to produce across
                all dimensions.
            difficulty: One of ``"easy"``, ``"medium"``, ``"hard"`` or
                an integer string.
            domain: Optional domain filter applied to generated cases.

        Returns:
            A list of :class:`EvalCaseV1` instances.  Dimensions that
            have handcrafted templates in :data:`SCENARIO_TEMPLATES`
            produce realistic prompts; the rest receive heuristic
            fallback scenarios generated from dimension metadata.
        """
        cases: list[EvalCaseV1] = []
        per_dimension = max(1, num_scenarios // max(1, len(dimensions)))
        if difficulty in self.DIFFICULTY_MAP:
            diff_int = self.DIFFICULTY_MAP[difficulty]
        elif difficulty.isdigit():
            diff_int = max(1, min(5, int(difficulty)))
        else:
            diff_int = self.default_difficulty

        for dim in dimensions:
            templates = SCENARIO_TEMPLATES.get(dim.id, [])

            if templates:
                for i in range(per_dimension):
                    template = templates[i % len(templates)]
                    case = EvalCaseV1(
                        suite_id=self.suite_id,
                        dimension_id=dim.id,
                        tier=dim.tier,
                        domain=domain or dim.domain,
                        prompt=template["prompt"],
                        expected=template.get("expected", {}),
                        difficulty=template.get("difficulty", diff_int),
                        tags=[dim.id, f"tier_{dim.tier.value}"],
                    )
                    cases.append(case)
            else:
                # Heuristic fallback for dimensions without handcrafted templates.
                for i in range(per_dimension):
                    case = self._heuristic_fallback_case(
                        dimension=dim,
                        difficulty=diff_int,
                        scenario_index=i,
                        domain=domain,
                    )
                    cases.append(case)

        return cases
