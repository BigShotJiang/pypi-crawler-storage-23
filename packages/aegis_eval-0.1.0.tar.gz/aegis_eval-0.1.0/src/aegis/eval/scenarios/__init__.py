"""Aegis eval scenarios — test case generation and management."""
