"""Aegis evaluation engine — orchestrates the full eval pipeline.

The :class:`Evaluator` is the primary entry-point for running evaluations.
It loads dimensions from the registry, generates scenarios, scores agent
outputs through the triangulated judge, and aggregates results into an
:class:`EvalResult`.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

# Ensure all tier modules are imported so dimensions self-register.
import aegis.eval.dimensions.tier1_memory as _t1  # noqa: F401
import aegis.eval.dimensions.tier2_context as _t2  # noqa: F401
import aegis.eval.dimensions.tier3_learning as _t3  # noqa: F401
import aegis.eval.dimensions.tier4_reasoning as _t4  # noqa: F401
import aegis.eval.dimensions.tier5_metacognition as _t5  # noqa: F401
import aegis.eval.dimensions.tier6_collaborative as _t6  # noqa: F401
import aegis.eval.dimensions.tier7_security as _t7  # noqa: F401
from aegis.core.settings import AegisSettings
from aegis.core.types import EvalCaseV1, JudgePacketV1
from aegis.eval.dimensions.base import Dimension
from aegis.eval.dimensions.registry import DimensionRegistry
from aegis.eval.dimensions.scoring import configure_judge, set_judge
from aegis.eval.judges.triangulated import TriangulatedJudge
from aegis.eval.reporting.diagnostic import generate_diagnostic
from aegis.eval.scenarios.generator import ScenarioGenerator
from aegis.eval.scorers.llm_backend import MockLLMBackend
from aegis.eval.scorers.llm_judge import LLMJudgeScorer
from aegis.eval.scorers.rule_based import RuleBasedScorer
from aegis.eval.scorers.semantic import SemanticScorer

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


class EvalConfig(BaseModel):
    """Configuration for an evaluation run.

    Attributes:
        dimensions: List of dimension IDs to evaluate, or ``"all"`` to
            evaluate every registered dimension.
        domain_plugins: Optional domain plugins to activate (e.g.
            ``["legal", "medical"]``).
        num_scenarios: Number of eval scenarios to generate per dimension.
        difficulty: Difficulty preset: ``"easy"``, ``"medium"``, or
            ``"hard"``.
        output_formats: List of export formats to produce (e.g.
            ``["json", "html"]``).
        seed: Optional seed for deterministic replay.
        scorer_mode: Scoring mode — ``"mock"`` uses deterministic mock
            scorers (fast, offline), ``"llm"`` uses real LLM backends
            for all three scorers, ``"hybrid"`` uses rule+semantic
            locally but calls the LLM for the third scorer.  Defaults
            to ``"auto"`` which uses LLM when API keys are set.
    """

    dimensions: list[str] | str = "all"
    domain_plugins: list[str] = Field(default_factory=list)
    num_scenarios: int = 10
    difficulty: str = "medium"
    output_formats: list[str] = Field(default_factory=lambda: ["json"])
    seed: int | None = None
    scorer_mode: str = "auto"
    llm_cost_budget_usd: float | None = Field(default=None, ge=0.0)
    llm_budget_fallback_score: float = Field(default=0.5, ge=0.0, le=1.0)
    judge_weights: tuple[float, float, float] | None = None
    adaptive_judge_weighting: bool = True


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------


class EvalResult(BaseModel):
    """Complete result of an evaluation run.

    Attributes:
        run_id: Unique identifier for this run.
        agent_id: The agent that was evaluated.
        overall_score: Composite score across all dimensions.
        dimension_scores: Per-dimension scores keyed by dimension ID.
        diagnostic: Structured diagnostic report.
        created_at: Timestamp of when the run completed.
        judge_packets: The raw :class:`JudgePacketV1` packets produced
            during scoring.
    """

    run_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = ""
    overall_score: float = 0.0
    dimension_scores: dict[str, float] = Field(default_factory=dict)
    diagnostic: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    judge_packets: list[JudgePacketV1] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Evaluator
# ---------------------------------------------------------------------------


class Evaluator:
    """Main evaluation engine for the Aegis platform.

    Orchestrates the end-to-end flow: dimension loading, scenario generation,
    agent execution, triangulated scoring, aggregation, and diagnostics.

    Args:
        custom_metrics: Optional mapping of metric name to callable scorer
            functions ``(agent_output, ground_truth) -> float``.
        config: An :class:`EvalConfig` instance.  If ``None``, a default
            config evaluating all dimensions is used.

    Example::

        evaluator = Evaluator()
        result = evaluator.run(agent=my_agent)
        print(result.overall_score)
    """

    def __init__(
        self,
        custom_metrics: dict[str, Callable[..., float]] | None = None,
        config: EvalConfig | None = None,
    ) -> None:
        self.config = config or EvalConfig()
        self.custom_metrics = custom_metrics or {}
        self._registry = DimensionRegistry.instance()
        self._generator = ScenarioGenerator()
        self._judge = self._build_judge(
            self.config.scorer_mode,
            weights=self.config.judge_weights,
            adaptive_weighting=self.config.adaptive_judge_weighting,
        )
        self._activate_judge(self.config, reset_usage=True)

    @staticmethod
    def _build_judge(
        scorer_mode: str,
        *,
        weights: tuple[float, float, float] | None = None,
        adaptive_weighting: bool = True,
    ) -> TriangulatedJudge:
        """Build a :class:`TriangulatedJudge` based on the scorer mode.

        Modes:
        - ``"mock"``: All three scorers use deterministic backends (fast, offline).
        - ``"llm"``: LLM judge uses real API backends (requires API keys).
        - ``"hybrid"``: Rule + semantic run locally, LLM judge calls real API.
        - ``"auto"``: Uses ``"hybrid"`` when API keys are present, else ``"mock"``.
        """
        if scorer_mode == "auto":
            settings = AegisSettings()
            has_keys = bool(
                settings.llm.openai_api_key
                or settings.llm.anthropic_api_key
                or settings.llm.generic_api_key
            )
            scorer_mode = "hybrid" if has_keys else "mock"

        if scorer_mode == "mock":
            return TriangulatedJudge(
                llm_scorer=LLMJudgeScorer(backend=MockLLMBackend()),
                weights=weights or (1 / 3, 1 / 3, 1 / 3),
                adaptive_weighting=adaptive_weighting,
            )
        elif scorer_mode == "llm":
            # All three use defaults; LLM backend auto-detects from env
            return TriangulatedJudge(
                weights=weights or (1 / 3, 1 / 3, 1 / 3),
                adaptive_weighting=adaptive_weighting,
            )
        else:
            # hybrid: rule + semantic local, LLM from env
            return TriangulatedJudge(
                rule_scorer=RuleBasedScorer(),
                semantic_scorer=SemanticScorer(),
                llm_scorer=LLMJudgeScorer(),  # auto-detects backend from env
                weights=weights or (1 / 3, 1 / 3, 1 / 3),
                adaptive_weighting=adaptive_weighting,
            )

    def _activate_judge(self, config: EvalConfig, *, reset_usage: bool) -> None:
        """Activate and configure the global judge used by all dimensions."""
        self._judge = self._build_judge(
            config.scorer_mode,
            weights=config.judge_weights,
            adaptive_weighting=config.adaptive_judge_weighting,
        )
        set_judge(self._judge)
        configure_judge(
            llm_cost_budget_usd=config.llm_cost_budget_usd,
            llm_budget_fallback_score=config.llm_budget_fallback_score,
            weights=config.judge_weights,
            adaptive_weighting=config.adaptive_judge_weighting,
            reset_usage=reset_usage,
        )

    def _llm_usage_summary(self) -> dict[str, Any]:
        """Collect judge LLM usage and budget telemetry for diagnostics."""
        usage = self._judge.llm_scorer.usage_stats
        payload: dict[str, Any] = self._judge.llm_scorer.budget_summary()
        if usage is not None:
            payload["usage"] = {
                "call_count": usage.call_count,
                "total_tokens": usage.total_tokens,
                "estimated_cost_usd": round(usage.estimated_cost_usd, 8),
            }
        return payload

    # -- helpers -------------------------------------------------------------

    def _resolve_dimensions(self, config: EvalConfig) -> list[Dimension]:
        """Resolve the list of dimensions to evaluate."""
        if config.dimensions == "all":
            return self._registry.all()

        dims: list[Dimension] = []
        if isinstance(config.dimensions, list):
            for dim_id in config.dimensions:
                dims.append(self._registry.get(dim_id))
        return dims

    @staticmethod
    def _invoke_agent(agent: Any, scenario: EvalCaseV1) -> str:
        """Invoke the agent adapter and extract the text output."""
        from aegis.adapters.base import AgentAdapter

        if isinstance(agent, AgentAdapter):
            trajectory = agent.evaluate(scenario)
            answer_steps = [s for s in trajectory.steps if s.kind.value == "answer"]
            if answer_steps:
                return answer_steps[-1].content
            return trajectory.steps[-1].content if trajectory.steps else ""

        if callable(agent):
            return str(agent(scenario.prompt))

        if hasattr(agent, "run"):
            return str(agent.run(scenario.prompt))
        if hasattr(agent, "invoke"):
            return str(agent.invoke(scenario.prompt))

        return ""

    @staticmethod
    def _fallback_case_score(agent_output: str, case: EvalCaseV1) -> float:
        """Heuristic fallback score for unregistered benchmark dimensions.

        Uses token overlap between the agent output and expected values.
        This keeps benchmark coverage intact even when a suite includes
        dimensions not yet in the evaluator registry.
        """
        expected = case.expected
        response = agent_output.lower().strip() if isinstance(agent_output, str) else ""
        if not expected:
            return 0.5 if response else 0.0
        if not response:
            return 0.0

        keywords: list[str] = []
        for value in expected.values():
            if isinstance(value, str):
                keywords.extend(value.lower().split())
            elif isinstance(value, list):
                for item in value:
                    keywords.extend(str(item).lower().split())
            elif isinstance(value, dict):
                for item in value.values():
                    keywords.extend(str(item).lower().split())
            else:
                keywords.extend(str(value).lower().split())

        # De-duplicate to avoid overweighting repeated tokens.
        unique_keywords = {kw.strip(".,;:()[]{}\"'") for kw in keywords if len(kw) > 2}
        unique_keywords.discard("")
        if not unique_keywords:
            return 0.5

        matches = sum(1 for kw in unique_keywords if kw in response)
        return max(0.0, min(1.0, matches / len(unique_keywords)))

    # -- public API ----------------------------------------------------------

    def run(
        self,
        agent: Any = None,
        config: EvalConfig | None = None,
    ) -> EvalResult:
        """Execute a full evaluation run.

        Args:
            agent: The agent under test.  If provided, each scenario is
                passed to the agent and the response is scored.  If
                ``None``, scoring uses empty agent output.
            config: Override the evaluator-level config for this run.

        Returns:
            An :class:`EvalResult` with per-dimension scores, judge
            packets, and a diagnostic summary.
        """
        cfg = config or self.config
        run_id = str(uuid.uuid4())
        agent_id = getattr(agent, "id", "unknown") if agent else "unknown"
        self._activate_judge(cfg, reset_usage=True)

        # 1. Resolve dimensions
        dimensions = self._resolve_dimensions(cfg)

        # 2. Generate scenarios
        scenarios = self._generator.generate(
            dimensions=dimensions,
            num_scenarios=cfg.num_scenarios,
            difficulty=cfg.difficulty,
        )

        # 3. Score each dimension via triangulated judge
        judge_packets: list[JudgePacketV1] = []
        dimension_scores: dict[str, float] = {}

        for dim in dimensions:
            # Collect scenarios for this dimension
            dim_scenarios = [s for s in scenarios if s.dimension_id == dim.id]

            dim_packet_scores: list[float] = []
            for scenario in dim_scenarios:
                agent_output = self._invoke_agent(agent, scenario) if agent is not None else ""
                ground_truth = scenario.expected

                packet = dim.score(
                    agent_output=agent_output,
                    ground_truth=ground_truth,
                    context={
                        "eval_case_id": scenario.id,
                        "dimension_id": dim.id,
                    },
                )
                judge_packets.append(packet)
                dim_packet_scores.append(packet.ensemble_score)

            # Average score for this dimension
            if dim_packet_scores:
                dimension_scores[dim.id] = sum(dim_packet_scores) / len(dim_packet_scores)
            else:
                dimension_scores[dim.id] = 0.0

        # 4. Compute overall score
        all_scores = list(dimension_scores.values())
        overall = sum(all_scores) / len(all_scores) if all_scores else 0.0

        # 5. Generate diagnostic
        diagnostic = generate_diagnostic(
            run_id=run_id,
            dimension_scores=dimension_scores,
        )
        diagnostic.setdefault("metadata", {})
        diagnostic["metadata"]["llm_judge"] = self._llm_usage_summary()

        return EvalResult(
            run_id=run_id,
            agent_id=agent_id,
            overall_score=overall,
            dimension_scores=dimension_scores,
            diagnostic=diagnostic,
            judge_packets=judge_packets,
        )

    def compare(
        self,
        run_a: EvalResult,
        run_b: EvalResult,
    ) -> dict[str, Any]:
        """Compare two evaluation results.

        Produces a delta report showing per-dimension score changes,
        overall improvement/regression, and newly-passing or newly-
        failing dimensions.

        Args:
            run_a: The baseline evaluation result.
            run_b: The candidate evaluation result.

        Returns:
            A dictionary with keys ``overall_delta``, ``dimension_deltas``,
            ``improved``, ``regressed``, and ``unchanged``.
        """
        all_dims = set(run_a.dimension_scores) | set(run_b.dimension_scores)

        dimension_deltas: dict[str, float] = {}
        improved: list[str] = []
        regressed: list[str] = []
        unchanged: list[str] = []

        for dim_id in sorted(all_dims):
            score_a = run_a.dimension_scores.get(dim_id, 0.0)
            score_b = run_b.dimension_scores.get(dim_id, 0.0)
            delta = round(score_b - score_a, 6)
            dimension_deltas[dim_id] = delta

            if delta > 0:
                improved.append(dim_id)
            elif delta < 0:
                regressed.append(dim_id)
            else:
                unchanged.append(dim_id)

        overall_delta = round(run_b.overall_score - run_a.overall_score, 6)

        return {
            "run_a_id": run_a.run_id,
            "run_b_id": run_b.run_id,
            "overall_delta": overall_delta,
            "dimension_deltas": dimension_deltas,
            "improved": improved,
            "regressed": regressed,
            "unchanged": unchanged,
        }

    def run_with_cases(
        self,
        cases: list[EvalCaseV1],
        agent: Any = None,
    ) -> EvalResult:
        """Execute evaluation using pre-defined cases (for benchmark suites).

        Unlike :meth:`run`, this method skips scenario generation and scores
        the provided cases directly.

        Args:
            cases: Pre-built evaluation cases to score.
            agent: The agent under test.

        Returns:
            An :class:`EvalResult` with per-dimension scores.
        """
        run_id = str(uuid.uuid4())
        agent_id = getattr(agent, "id", "unknown") if agent else "unknown"
        self._activate_judge(self.config, reset_usage=True)

        dim_ids = {case.dimension_id for case in cases}

        judge_packets: list[JudgePacketV1] = []
        dimension_scores: dict[str, float] = {}

        for dim_id in sorted(dim_ids):
            try:
                dim = self._registry.get(dim_id)
            except KeyError:
                dim = None

            dim_cases = [c for c in cases if c.dimension_id == dim_id]
            dim_packet_scores: list[float] = []

            for case in dim_cases:
                agent_output = self._invoke_agent(agent, case) if agent is not None else ""

                if dim is not None:
                    packet = dim.score(
                        agent_output=agent_output,
                        ground_truth=case.expected,
                        context={
                            "eval_case_id": case.id,
                            "dimension_id": dim_id,
                        },
                    )
                    judge_packets.append(packet)
                    dim_packet_scores.append(packet.ensemble_score)
                else:
                    dim_packet_scores.append(self._fallback_case_score(agent_output, case))

            if dim_packet_scores:
                dimension_scores[dim_id] = sum(dim_packet_scores) / len(dim_packet_scores)
            else:
                dimension_scores[dim_id] = 0.0

        all_scores = list(dimension_scores.values())
        overall = sum(all_scores) / len(all_scores) if all_scores else 0.0

        diagnostic = generate_diagnostic(
            run_id=run_id,
            dimension_scores=dimension_scores,
        )
        diagnostic.setdefault("metadata", {})
        diagnostic["metadata"]["llm_judge"] = self._llm_usage_summary()

        return EvalResult(
            run_id=run_id,
            agent_id=agent_id,
            overall_score=overall,
            dimension_scores=dimension_scores,
            diagnostic=diagnostic,
            judge_packets=judge_packets,
        )
