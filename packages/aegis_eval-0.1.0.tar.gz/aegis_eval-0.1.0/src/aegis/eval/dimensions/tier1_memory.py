"""Tier 1 — Memory Fidelity dimensions.

Six dimensions that evaluate an agent's ability to accurately store, update,
forget, cross-reference, temporally reason about, and track the provenance of
memory entries.
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalTier, JudgePacketV1, ScorerType
from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.dimensions.registry import register_dimension
from aegis.eval.dimensions.scoring import score_with_judge

_TIER = EvalTier.MEMORY_FIDELITY


@register_dimension
class RetentionAccuracy(Dimension):
    """Measures whether stored memories are faithfully retained without drift."""

    id: str = "retention_accuracy"
    name: str = "Retention Accuracy"
    tier: EvalTier = _TIER
    description: str = "Accuracy of verbatim and semantic retention of stored facts."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []
        output_str = str(agent_output).lower().strip()

        if isinstance(ground_truth, dict):
            # Exact-match check: if output matches ground truth verbatim for any value
            for key, value in ground_truth.items():
                val_str = str(value)
                rules.append({"type": "contains", "substring": val_str})
                # BLEU-like n-gram overlap: check bigram and trigram presence
                words = val_str.split()
                if len(words) >= 2:
                    bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": bigrams,
                            "threshold": 0.3,
                            "description": f"Bigram overlap for field '{key}'",
                        }
                    )
                if len(words) >= 3:
                    trigrams = [
                        f"{words[i]} {words[i + 1]} {words[i + 2]}" for i in range(len(words) - 2)
                    ]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 3,
                            "reference_ngrams": trigrams,
                            "threshold": 0.2,
                            "description": f"Trigram overlap for field '{key}'",
                        }
                    )

            # Exact match bonus rule
            all_values = [str(v) for v in ground_truth.values()]
            rules.append(
                {
                    "type": "contains_all",
                    "substrings": all_values,
                    "description": "All ground-truth values must appear in output",
                }
            )

            # Check output is not trivially short or suspiciously long
            total_gt_len = sum(len(str(v)) for v in ground_truth.values())
            rules.append(
                {
                    "type": "word_count_range",
                    "min": max(1, total_gt_len // 20),
                    "max": total_gt_len * 5,
                    "description": "Output length should be proportional to ground truth",
                }
            )
        else:
            gt_str = str(ground_truth)
            # Direct exact match check
            rules.append({"type": "fuzzy_match"})
            # N-gram overlap for non-dict ground truth
            words = gt_str.split()
            if len(words) >= 2:
                bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                rules.append(
                    {
                        "type": "ngram_overlap",
                        "n": 2,
                        "reference_ngrams": bigrams,
                        "threshold": 0.3,
                    }
                )
            # Check for verbatim substring match
            if output_str == gt_str.lower().strip():
                rules.append(
                    {
                        "type": "exact_match",
                        "value": gt_str,
                        "description": "Verbatim retention detected",
                    }
                )

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score how accurately the agent retained and recalled stored facts on "
                "a 0.0-1.0 scale.\n\n"
                "1.0 = Perfect verbatim recall of ALL stored facts with no omissions, "
                "additions, or paraphrasing drift.\n"
                "0.8 = All key facts present and correct, minor wording differences "
                "that do not alter meaning.\n"
                "0.6 = Most facts present but 1-2 minor factual details are imprecise "
                "or slightly altered.\n"
                "0.4 = Several facts recalled but notable omissions or inaccuracies in "
                "key details.\n"
                "0.2 = Only a minority of facts recalled correctly; significant drift "
                "or hallucination.\n"
                "0.0 = Complete failure to recall stored facts, or output is entirely "
                "fabricated.\n\n"
                "Pay special attention to: numerical values, proper nouns, dates, and "
                "causal relationships. Any alteration of these is a major penalty."
            ),
        )


@register_dimension
class UpdateCorrectness(Dimension):
    """Validates that memory updates replace only the intended fields."""

    id: str = "update_correctness"
    name: str = "Update Correctness"
    tier: EvalTier = _TIER
    description: str = "Correctness of in-place memory updates without side-effect corruption."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Field-level diff: current value MUST be present
            if "current_value" in ground_truth:
                current = str(ground_truth["current_value"])
                rules.append({"type": "contains", "substring": current})
                # Bigram check on new value for semantic similarity
                words = current.split()
                if len(words) >= 2:
                    bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": bigrams,
                            "threshold": 0.5,
                            "description": "Current value bigram match",
                        }
                    )

            # Old value MUST NOT be present (superseded data should be gone)
            if "old_value" in ground_truth:
                old = str(ground_truth["old_value"])
                rules.append({"type": "not_contains", "substring": old})
                # Also check partial fragments of old value don't linger
                old_words = old.split()
                if len(old_words) >= 3:
                    # Check that large chunks of old value are absent
                    mid = len(old_words) // 2
                    old_fragment = " ".join(old_words[mid - 1 : mid + 2])
                    rules.append(
                        {
                            "type": "not_contains",
                            "substring": old_fragment,
                            "description": "Old value fragment must not persist",
                        }
                    )

            # Unchanged fields must still be present (no collateral damage)
            unchanged = ground_truth.get("unchanged_fields", {})
            for field_name, field_value in unchanged.items():
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(field_value),
                        "description": f"Unchanged field '{field_name}' must be preserved",
                    }
                )

            # Check for structured output if expected
            if ground_truth.get("expect_json"):
                rules.append(
                    {
                        "type": "json_valid",
                        "description": "Output should be valid JSON representing updated record",
                    }
                )

            # Word count sanity: update responses should be concise
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 3,
                    "max": 2000,
                    "description": "Update response should be substantive but not excessively verbose",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score whether the agent correctly applies memory updates on a 0.0-1.0 "
                "scale.\n\n"
                "1.0 = Updated field reflects the new value exactly; all other fields "
                "are perfectly preserved; no residual old data.\n"
                "0.8 = Correct new value used; unchanged fields preserved; minor "
                "formatting differences only.\n"
                "0.6 = New value present but minor collateral changes to unrelated "
                "fields, or slight imprecision in the new value.\n"
                "0.4 = New value partially correct OR one unchanged field was "
                "inadvertently modified.\n"
                "0.2 = Old value still referenced alongside new, or multiple unchanged "
                "fields corrupted.\n"
                "0.0 = Old value still dominant, new value absent, or wholesale "
                "corruption of the record.\n\n"
                "Key checks: (1) Does the output use the current/new value? "
                "(2) Is the old/superseded value absent? (3) Are unrelated fields "
                "intact and unchanged?"
            ),
        )


@register_dimension
class SelectiveForgetting(Dimension):
    """Checks that the agent can surgically forget targeted memories."""

    id: str = "selective_forgetting"
    name: str = "Selective Forgetting"
    tier: EvalTier = _TIER
    description: str = "Ability to forget specific facts without collateral information loss."
    scorer_type: ScorerType = ScorerType.SEMANTIC
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            forgotten_items = ground_truth.get("forgotten", [])
            retained_items = ground_truth.get("retained", [])

            # Negative evidence: forgotten items MUST be absent
            for item in forgotten_items:
                item_str = str(item)
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": item_str,
                        "description": f"Forgotten item must be absent: '{item_str}'",
                    }
                )
                # Also check for synonyms/paraphrases of forgotten items
                item_words = item_str.lower().split()
                if len(item_words) >= 2:
                    for i in range(len(item_words) - 1):
                        bigram = f"{item_words[i]} {item_words[i + 1]}"
                        rules.append(
                            {
                                "type": "not_contains",
                                "substring": bigram,
                                "description": f"Forgotten item bigram must be absent: '{bigram}'",
                            }
                        )

            # Positive evidence: retained items MUST be present
            for item in retained_items:
                item_str = str(item)
                rules.append(
                    {
                        "type": "contains",
                        "substring": item_str,
                        "description": f"Retained item must be present: '{item_str}'",
                    }
                )

            # If the agent should acknowledge forgetting, check for acknowledgment
            if forgotten_items:
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "no information",
                            "don't have",
                            "no record",
                            "not available",
                            "unknown",
                            "no data",
                            "cannot recall",
                            "do not recall",
                            "no longer",
                            "removed",
                            "deleted",
                            "forgotten",
                        ],
                        "description": "Agent should indicate forgotten data is unavailable",
                    }
                )

            # Comprehensive check: all retained items must be present together
            if retained_items:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(item) for item in retained_items],
                        "description": "All retained items must appear in output",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score selective forgetting on a 0.0-1.0 scale.\n\n"
                "1.0 = All targeted items are completely absent from output; all "
                "non-targeted items are fully preserved; agent appropriately indicates "
                "lack of knowledge for forgotten items.\n"
                "0.8 = Targeted items absent; retained items present; minor phrasing "
                "suggests vague awareness of forgotten content without revealing it.\n"
                "0.6 = Most targeted items absent but one partially leaks (e.g., a "
                "related detail surfaces); retained items mostly intact.\n"
                "0.4 = Some targeted items still appear in output, or several retained "
                "items are missing (collateral forgetting).\n"
                "0.2 = Significant leakage of forgotten items, or major collateral "
                "loss of retained knowledge.\n"
                "0.0 = Forgotten items fully present (no forgetting occurred) or "
                "all retained items also lost (catastrophic forgetting).\n\n"
                "Critical: Even indirect references or paraphrases of forgotten items "
                "count as leakage. Check for synonyms and related phrases."
            ),
        )


@register_dimension
class CrossReferenceIntegrity(Dimension):
    """Evaluates consistency across linked memory entries."""

    id: str = "cross_reference_integrity"
    name: str = "Cross-Reference Integrity"
    tier: EvalTier = _TIER
    description: str = "Consistency and correctness of links between related memory entries."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Bidirectional link validation: both entities in a relationship must appear
            links = ground_truth.get("links", [])
            for link in links:
                if isinstance(link, dict):
                    source = str(link.get("source", ""))
                    target = str(link.get("target", ""))
                    relation = str(link.get("relation", ""))
                    if source:
                        rules.append(
                            {
                                "type": "contains",
                                "substring": source,
                                "description": f"Link source entity must be present: '{source}'",
                            }
                        )
                    if target:
                        rules.append(
                            {
                                "type": "contains",
                                "substring": target,
                                "description": f"Link target entity must be present: '{target}'",
                            }
                        )
                    if relation:
                        rules.append(
                            {
                                "type": "contains",
                                "substring": relation,
                                "description": f"Relationship type must be mentioned: '{relation}'",
                            }
                        )

            # Fallback: iterate dict values for simple key-value ground truth
            if not links:
                for key, value in ground_truth.items():
                    if key in ("links", "broken_links", "expect_json"):
                        continue
                    rules.append({"type": "contains", "substring": str(value)})

            # Broken links that should NOT be referenced
            for broken in ground_truth.get("broken_links", []):
                if isinstance(broken, dict):
                    broken_ref = str(broken.get("target", broken.get("source", "")))
                    if broken_ref:
                        rules.append(
                            {
                                "type": "not_contains",
                                "substring": broken_ref,
                                "description": f"Broken link target must not appear: '{broken_ref}'",
                            }
                        )
                else:
                    rules.append(
                        {
                            "type": "not_contains",
                            "substring": str(broken),
                            "description": f"Broken reference must not appear: '{broken}'",
                        }
                    )

            # All cross-referenced values should co-occur
            all_entities = []
            for link in links:
                if isinstance(link, dict):
                    for field in ("source", "target"):
                        val = link.get(field, "")
                        if val:
                            all_entities.append(str(val))
            if all_entities:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": all_entities,
                        "description": "All linked entities must co-occur in output",
                    }
                )

            # Check for structured output if expected
            if ground_truth.get("expect_json"):
                rules.append(
                    {
                        "type": "json_valid",
                        "description": "Cross-reference output should be valid JSON",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score cross-reference integrity on a 0.0-1.0 scale.\n\n"
                "1.0 = All bidirectional links are correctly represented; every "
                "entity in a relationship pair is mentioned with the correct "
                "relationship type; no broken or dangling references.\n"
                "0.8 = All links present and correct; minor omission of relationship "
                "type labels but entities are correctly paired.\n"
                "0.6 = Most links correct but one relationship is missing or "
                "incorrectly characterized.\n"
                "0.4 = Several links missing or entities incorrectly paired; some "
                "dangling references present.\n"
                "0.2 = Majority of cross-references broken or incorrectly linked.\n"
                "0.0 = No valid cross-references present, or all links are incorrect.\n\n"
                "Key checks: (1) Are both source and target entities present for each "
                "link? (2) Is the relationship type correct? (3) Are there any dangling "
                "or orphaned references?"
            ),
        )


@register_dimension
class TemporalReasoning(Dimension):
    """Tests the agent's ability to reason about time-bounded facts."""

    id: str = "temporal_reasoning"
    name: str = "Temporal Reasoning"
    tier: EvalTier = _TIER
    description: str = "Correct handling of time-sensitive facts and temporal validity windows."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Temporal conclusion must be present
            if "temporal_conclusion" in ground_truth:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["temporal_conclusion"]),
                        "description": "Correct temporal conclusion must appear",
                    }
                )

            # Temporal keyword detection: agent must use temporal language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "before",
                        "after",
                        "during",
                        "expired",
                        "valid",
                        "within",
                        "outside",
                        "prior to",
                        "following",
                        "earlier",
                        "later",
                        "since",
                        "until",
                        "between",
                        "concurrent",
                        "simultaneous",
                        "precedes",
                        "follows",
                        "overlaps",
                        "from",
                        "to",
                        "starting",
                        "ending",
                    ],
                    "description": "Output must contain temporal reasoning language",
                }
            )

            # Temporal ordering: if events are provided, check correct sequence
            events = ground_truth.get("events", [])
            if len(events) >= 2:
                # Check that events appear in the correct order in output
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(e) for e in events],
                        "description": "All temporal events must be referenced",
                    }
                )

            # Date/time pattern detection: output should contain date-like patterns
            if ground_truth.get("contains_dates", True):
                rules.append(
                    {
                        "type": "regex_match",
                        "pattern": r"\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2}",
                        "description": "Output should reference specific dates or date patterns",
                    }
                )

            # Temporal validity window check
            if "valid_from" in ground_truth and "valid_until" in ground_truth:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["valid_from"]),
                        "description": "Validity start date must be referenced",
                    }
                )
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["valid_until"]),
                        "description": "Validity end date must be referenced",
                    }
                )

            # Check for expired vs. active status reasoning
            if "status" in ground_truth:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["status"]),
                        "description": "Temporal status (expired/active/pending) must be stated",
                    }
                )

            # Word count: temporal reasoning needs substantive explanation
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 10,
                    "max": 5000,
                    "description": "Temporal reasoning should include explanation, not just a bare answer",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score temporal reasoning on a 0.0-1.0 scale.\n\n"
                "1.0 = Correct temporal conclusion reached; all events placed in "
                "the right chronological order; validity windows correctly computed; "
                "explicit temporal language used.\n"
                "0.8 = Correct conclusion with minor imprecision in date references "
                "or event ordering.\n"
                "0.6 = Generally correct temporal reasoning but one event misordered "
                "or one validity boundary off.\n"
                "0.4 = Temporal conclusion partially correct; notable errors in "
                "chronological ordering or validity assessment.\n"
                "0.2 = Major temporal errors; events significantly misordered or "
                "validity windows completely wrong.\n"
                "0.0 = No temporal reasoning attempted, or conclusion is the exact "
                "opposite of the correct answer.\n\n"
                "Evaluate: (1) Is the final temporal conclusion correct? "
                "(2) Are dates/times accurately referenced? (3) Is chronological "
                "ordering correct? (4) Are validity windows properly bounded?"
            ),
        )


@register_dimension
class ProvenanceTracking(Dimension):
    """Verifies that memory entries carry accurate source provenance."""

    id: str = "provenance_tracking"
    name: str = "Provenance Tracking"
    tier: EvalTier = _TIER
    description: str = "Accuracy and completeness of provenance metadata attached to memories."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Source citation validation: each claimed source must be cited
            sources = ground_truth.get("sources", [])
            for source in sources:
                source_str = str(source)
                rules.append(
                    {
                        "type": "contains",
                        "substring": source_str,
                        "description": f"Source must be cited: '{source_str}'",
                    }
                )

            # Fallback for flat dict structure
            if not sources:
                for key, value in ground_truth.items():
                    if key in ("citation_format", "expect_json", "invalid_sources"):
                        continue
                    rules.append({"type": "contains", "substring": str(value)})

            # All sources should co-occur for complete provenance
            if sources:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(s) for s in sources],
                        "description": "All sources must be cited together",
                    }
                )

            # Citation format validation: check for standard patterns
            citation_format = ground_truth.get("citation_format")
            if citation_format == "apa":
                rules.append(
                    {
                        "type": "regex_match",
                        "pattern": r"\(\d{4}\)|\b\d{4}\b.*et al\.",
                        "description": "APA-style citation pattern expected",
                    }
                )
            elif citation_format == "numbered":
                rules.append(
                    {
                        "type": "regex_match",
                        "pattern": r"\[\d+\]",
                        "description": "Numbered citation format expected (e.g., [1], [2])",
                    }
                )
            else:
                # Generic citation detection
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "source:",
                            "from:",
                            "according to",
                            "cited from",
                            "reference:",
                            "based on",
                            "per ",
                            "as stated in",
                            "[1]",
                            "[2]",
                            "(source",
                            "document:",
                            "retrieved from",
                        ],
                        "description": "Output should contain citation/attribution language",
                    }
                )

            # Invalid sources should NOT be referenced
            for invalid in ground_truth.get("invalid_sources", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(invalid),
                        "description": f"Invalid source must not be cited: '{invalid}'",
                    }
                )

            # Check for structured provenance output
            if ground_truth.get("expect_json"):
                rules.append(
                    {"type": "json_valid", "description": "Provenance output should be valid JSON"}
                )

            # Provenance responses should be detailed
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 5,
                    "max": 5000,
                    "description": "Provenance response must be substantive",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score provenance tracking on a 0.0-1.0 scale.\n\n"
                "1.0 = Every claim is attributed to the correct source document "
                "with specific location (section, page, paragraph); no fabricated "
                "sources; citation format is consistent.\n"
                "0.8 = All claims correctly attributed to the right sources; minor "
                "imprecision in location references (e.g., missing page number).\n"
                "0.6 = Most claims have correct provenance but one source is "
                "misattributed or one claim lacks a citation.\n"
                "0.4 = Multiple claims lack proper attribution, or some sources "
                "are fabricated.\n"
                "0.2 = Majority of claims unattributed or attributed to wrong "
                "sources.\n"
                "0.0 = No provenance information provided, or all attributions "
                "are fabricated.\n\n"
                "Evaluate: (1) Is every factual claim attributed to a source? "
                "(2) Are source identifiers accurate? (3) Is the citation format "
                "consistent? (4) Are there any fabricated references?"
            ),
        )
