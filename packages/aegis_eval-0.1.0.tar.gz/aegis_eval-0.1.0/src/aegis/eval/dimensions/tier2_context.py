"""Tier 2 — Context Intelligence dimensions.

Eight dimensions that evaluate the quality, precision, and robustness of
an agent's retrieval and context-assembly pipeline.
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalTier, JudgePacketV1, ScorerType
from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.dimensions.registry import register_dimension
from aegis.eval.dimensions.scoring import score_with_judge

_TIER = EvalTier.CONTEXT_INTELLIGENCE


@register_dimension
class RetrievalPrecision(Dimension):
    """Fraction of retrieved context blocks that are actually relevant."""

    id: str = "retrieval_precision"
    name: str = "Retrieval Precision"
    tier: EvalTier = _TIER
    description: str = "Precision of retrieved context relative to the query."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            relevant_items = ground_truth.get("relevant", [])
            irrelevant_items = ground_truth.get("irrelevant", [])

            # All relevant items must be present
            for item in relevant_items:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(item),
                        "description": f"Relevant item must be included: '{item}'",
                    }
                )

            # All irrelevant items must be absent
            for item in irrelevant_items:
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(item),
                        "description": f"Irrelevant item must be excluded: '{item}'",
                    }
                )

            # Comprehensive relevant item check
            if relevant_items:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(i) for i in relevant_items],
                        "description": "All relevant items must co-occur",
                    }
                )

            # Precision metric: output should not be padded with filler
            if relevant_items and irrelevant_items:
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": max(5, len(relevant_items) * 3),
                        "max": max(500, len(relevant_items) * 200),
                        "description": "Output length proportional to relevant content",
                    }
                )

            # Relevance scoring: check for relevance signal phrases
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "relevant",
                        "pertinent",
                        "related to",
                        "addresses",
                        "answers",
                        "matches",
                        "applicable",
                        "concerning",
                    ],
                    "description": "Output should signal relevance awareness",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score retrieval precision on a 0.0-1.0 scale.\n\n"
                "1.0 = Every retrieved context block is relevant to the query; no "
                "irrelevant or distracting material included; precision is 100%.\n"
                "0.8 = All relevant items included; at most one marginally irrelevant "
                "item present.\n"
                "0.6 = Most relevant items included but 1-2 irrelevant items also "
                "present, reducing precision.\n"
                "0.4 = Some relevant items present but significant noise from "
                "irrelevant retrievals.\n"
                "0.2 = Mostly irrelevant content with only incidental relevant items.\n"
                "0.0 = No relevant items retrieved, or exclusively irrelevant content.\n\n"
                "Evaluate precision = (relevant items retrieved) / (total items "
                "retrieved). Penalize inclusion of explicitly irrelevant distractors."
            ),
        )


@register_dimension
class RetrievalDepthCalibration(Dimension):
    """Evaluates whether retrieval depth matches query complexity."""

    id: str = "retrieval_depth_calibration"
    name: str = "Retrieval Depth Calibration"
    tier: EvalTier = _TIER
    description: str = "Appropriateness of retrieval depth relative to query complexity."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Required sources that MUST be consulted
            for source in ground_truth.get("required_sources", []):
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(source),
                        "description": f"Required source must be consulted: '{source}'",
                    }
                )

            # Depth indicator detection
            expected_depth = ground_truth.get("expected_depth", "moderate")
            if expected_depth == "shallow":
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 5,
                        "max": 300,
                        "description": "Shallow queries should yield concise responses",
                    }
                )
            elif expected_depth == "deep":
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 50,
                        "max": 10000,
                        "description": "Deep queries should yield comprehensive responses",
                    }
                )
                # Deep queries should cite multiple sources
                rules.append(
                    {
                        "type": "regex_match",
                        "pattern": r"(?:source|reference|from|according to|cited|document).*(?:source|reference|from|according to|cited|document)",
                        "description": "Deep retrieval should reference multiple sources",
                    }
                )

            # Depth calibration language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "shallow",
                        "deep",
                        "single source",
                        "multiple sources",
                        "comprehensive",
                        "brief",
                        "detailed",
                        "thorough",
                        "in-depth",
                        "surface-level",
                        "extensive",
                    ],
                    "description": "Output should reflect appropriate depth calibration",
                }
            )

            # Number of sources metric
            min_sources = ground_truth.get("min_sources")
            if min_sources and isinstance(min_sources, int):
                required_sources = ground_truth.get("required_sources", [])
                if len(required_sources) >= min_sources:
                    rules.append(
                        {
                            "type": "contains_all",
                            "substrings": [str(s) for s in required_sources[:min_sources]],
                            "description": f"At least {min_sources} sources must be referenced",
                        }
                    )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score retrieval depth calibration on a 0.0-1.0 scale.\n\n"
                "1.0 = Retrieval depth perfectly matches query complexity: simple "
                "queries get concise single-source answers; complex queries get "
                "multi-source comprehensive coverage.\n"
                "0.8 = Depth generally appropriate; minor over/under-retrieval that "
                "does not affect answer quality.\n"
                "0.6 = Slightly miscalibrated: simple query with excessive retrieval "
                "or complex query missing one key source.\n"
                "0.4 = Notably miscalibrated: wasted tokens on simple queries or "
                "incomplete coverage on complex ones.\n"
                "0.2 = Severely miscalibrated depth relative to complexity.\n"
                "0.0 = Completely inappropriate depth (trivial query causes exhaustive "
                "retrieval, or complex query gets single shallow lookup).\n\n"
                "Consider: query complexity, number of sources required, response "
                "detail level, and token efficiency."
            ),
        )


@register_dimension
class SourceRouting(Dimension):
    """Tests routing queries to the most appropriate knowledge source."""

    id: str = "source_routing"
    name: str = "Source Routing"
    tier: EvalTier = _TIER
    description: str = "Accuracy of routing queries to the correct retrieval backend."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Correct source must be identified
            if "correct_source" in ground_truth:
                correct = str(ground_truth["correct_source"])
                rules.append(
                    {
                        "type": "contains",
                        "substring": correct,
                        "description": f"Correct source must be selected: '{correct}'",
                    }
                )
                # N-gram check on source name
                words = correct.split()
                if len(words) >= 2:
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": [
                                f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)
                            ],
                            "threshold": 0.5,
                            "description": "Source name bigram match",
                        }
                    )

            # Incorrect sources must be avoided
            for wrong in ground_truth.get("incorrect_sources", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(wrong),
                        "description": f"Incorrect source must not be selected: '{wrong}'",
                    }
                )

            # Source type classification (e.g., vector DB, knowledge graph, SQL)
            source_type = ground_truth.get("source_type")
            if source_type:
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            str(source_type),
                            str(source_type).lower(),
                            str(source_type).upper(),
                        ],
                        "description": f"Correct source type '{source_type}' should be identified",
                    }
                )

            # Routing explanation: agent should explain why it chose this source
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "routed to",
                        "selected",
                        "queried",
                        "using",
                        "from",
                        "looked up in",
                        "searched",
                        "chose",
                        "appropriate source",
                        "best source",
                    ],
                    "description": "Agent should indicate source selection reasoning",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score source routing accuracy on a 0.0-1.0 scale.\n\n"
                "1.0 = Query routed to the exact correct backend (vector DB, "
                "knowledge graph, SQL, API, etc.); no unnecessary secondary "
                "lookups; routing rationale is clear.\n"
                "0.8 = Correct primary source selected; minor unnecessary secondary "
                "lookups that do not degrade quality.\n"
                "0.6 = Correct source consulted but alongside incorrect sources, "
                "wasting resources.\n"
                "0.4 = Partially correct routing: right source type but wrong "
                "specific instance.\n"
                "0.2 = Wrong source selected but by coincidence gets partial answer.\n"
                "0.0 = Completely wrong source; query sent to irrelevant backend.\n\n"
                "Consider: (1) Was the correct source selected? (2) Were incorrect "
                "sources avoided? (3) Is the routing rationale sound?"
            ),
        )


@register_dimension
class StalenessDetection(Dimension):
    """Ability to detect and deprioritize stale or outdated context."""

    id: str = "staleness_detection"
    name: str = "Staleness Detection"
    tier: EvalTier = _TIER
    description: str = "Detection and deprioritization of outdated context blocks."
    scorer_type: ScorerType = ScorerType.SEMANTIC
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Stale items must not appear in output
            for item in ground_truth.get("stale_items", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(item),
                        "description": f"Stale item must be excluded: '{item}'",
                    }
                )

            # Current items must be present
            for item in ground_truth.get("current_items", []):
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(item),
                        "description": f"Current item must be present: '{item}'",
                    }
                )

            # Staleness awareness language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "outdated",
                        "stale",
                        "superseded",
                        "old version",
                        "deprecated",
                        "no longer current",
                        "replaced by",
                        "updated to",
                        "previous version",
                        "newer",
                        "latest",
                        "most recent",
                        "current version",
                        "as of",
                    ],
                    "description": "Agent should use staleness-aware language",
                }
            )

            # Temporal recency check: agent should reference timestamps or versions
            if ground_truth.get("has_timestamps", False):
                rules.append(
                    {
                        "type": "regex_match",
                        "pattern": r"\d{4}[-/]\d{1,2}[-/]\d{1,2}|v\d+\.\d+|version\s+\d+",
                        "description": "Output should reference dates or version numbers",
                    }
                )

            # If both stale and current provided, output must prefer current
            stale = ground_truth.get("stale_items", [])
            current = ground_truth.get("current_items", [])
            if stale and current:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(c) for c in current],
                        "description": "All current items must be present (prioritized over stale)",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score staleness detection on a 0.0-1.0 scale.\n\n"
                "1.0 = All stale context correctly identified and excluded; only "
                "current information used; agent explicitly notes when data has "
                "been superseded.\n"
                "0.8 = Stale data excluded and current data used; minor lack of "
                "explicit staleness acknowledgment.\n"
                "0.6 = Most stale data deprioritized but one stale item included "
                "without flagging its age.\n"
                "0.4 = Mix of stale and current data without clear preference for "
                "current information.\n"
                "0.2 = Stale data treated as equally authoritative to current data.\n"
                "0.0 = Stale data preferred over current data, or staleness not "
                "detected at all.\n\n"
                "Evaluate: (1) Are stale items excluded or flagged? (2) Are current "
                "items prioritized? (3) Does the agent indicate data freshness?"
            ),
        )


@register_dimension
class AdversarialRobustness(Dimension):
    """Resilience of retrieval to adversarial or misleading queries."""

    id: str = "adversarial_robustness"
    name: str = "Adversarial Robustness"
    tier: EvalTier = _TIER
    description: str = "Robustness of retrieval pipeline against adversarial query perturbations."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.RESEARCH

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Correct answer must still appear despite adversarial input
            if "correct_answer" in ground_truth:
                answer = str(ground_truth["correct_answer"])
                rules.append(
                    {
                        "type": "contains",
                        "substring": answer,
                        "description": "Correct answer must appear despite adversarial perturbation",
                    }
                )
                # N-gram match for semantic robustness
                words = answer.split()
                if len(words) >= 2:
                    bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": bigrams,
                            "threshold": 0.4,
                            "description": "Answer bigram overlap despite adversarial input",
                        }
                    )

            # Adversarial distractors must NOT appear
            for distractor in ground_truth.get("adversarial_distractors", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(distractor),
                        "description": f"Adversarial distractor must be rejected: '{distractor}'",
                    }
                )

            # Check for injection pattern resistance
            injection_patterns = ground_truth.get("injection_patterns", [])
            for pattern in injection_patterns:
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(pattern),
                        "description": f"Injection pattern must not be echoed: '{pattern}'",
                    }
                )

            # Robustness indicator: agent should produce coherent output
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 5,
                    "max": 5000,
                    "description": "Output should be coherent and substantive despite adversarial input",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score adversarial robustness on a 0.0-1.0 scale.\n\n"
                "1.0 = Correct answer produced despite adversarial perturbation; "
                "all distractors rejected; output is coherent and accurate.\n"
                "0.8 = Correct answer with minor influence from adversarial content "
                "that does not affect factual accuracy.\n"
                "0.6 = Mostly correct but one adversarial distractor partially "
                "influenced the response.\n"
                "0.4 = Answer partially corrupted by adversarial input; key facts "
                "still present but mixed with distractors.\n"
                "0.2 = Answer significantly corrupted; adversarial content dominates.\n"
                "0.0 = Agent fully misled by adversarial input; output contains "
                "distractors instead of correct answer.\n\n"
                "Key: Does the agent ignore misleading context and produce the "
                "factually correct response?"
            ),
        )


@register_dimension
class AntiRetrievalJudgment(Dimension):
    """Evaluates the agent's ability to decide *not* to retrieve."""

    id: str = "anti_retrieval_judgment"
    name: str = "Anti-Retrieval Judgment"
    tier: EvalTier = _TIER
    description: str = "Correctness of the decision to skip retrieval when context is unnecessary."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            should_retrieve = ground_truth.get("should_retrieve", True)

            if not should_retrieve:
                # Agent should NOT retrieve and should indicate sufficiency
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "no retrieval needed",
                            "sufficient context",
                            "already know",
                            "no additional",
                            "without retrieval",
                            "from memory",
                            "directly",
                            "no lookup needed",
                            "no search necessary",
                            "parametric knowledge",
                        ],
                        "description": "Agent should indicate retrieval was unnecessary",
                    }
                )
                # Should still produce a correct answer from internal knowledge
                if "expected_answer" in ground_truth:
                    rules.append(
                        {
                            "type": "contains",
                            "substring": str(ground_truth["expected_answer"]),
                            "description": "Correct answer expected from internal knowledge",
                        }
                    )
                # Should NOT show retrieval artifacts
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "no retrieval needed",
                            "sufficient context",
                            "already know",
                            "no additional",
                            "without retrieval",
                            "from memory",
                        ],
                        "description": "Output indicates no retrieval was performed",
                    }
                )
            else:
                # Agent SHOULD retrieve
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "retrieved",
                            "searched",
                            "queried",
                            "looked up",
                            "found in",
                            "from database",
                            "from index",
                            "search results",
                            "retrieved context",
                        ],
                        "description": "Agent should indicate retrieval was performed",
                    }
                )
                if "expected_answer" in ground_truth:
                    rules.append(
                        {
                            "type": "contains",
                            "substring": str(ground_truth["expected_answer"]),
                            "description": "Correct answer expected after retrieval",
                        }
                    )

            # Token efficiency: anti-retrieval should yield shorter responses
            if not should_retrieve:
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 3,
                        "max": 500,
                        "description": "Non-retrieval answers should be concise",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score anti-retrieval judgment on a 0.0-1.0 scale.\n\n"
                "1.0 = Agent correctly decides whether to retrieve or not; when "
                "retrieval is unnecessary the agent answers from internal knowledge "
                "confidently and correctly; when retrieval is needed the agent "
                "performs it.\n"
                "0.8 = Correct retrieval decision with minor hesitation or "
                "unnecessary hedging.\n"
                "0.6 = Correct decision but execution is suboptimal (e.g., retrieves "
                "when not needed but still gets right answer).\n"
                "0.4 = Wrong retrieval decision but compensates partially.\n"
                "0.2 = Wrong decision causing significant inefficiency or quality "
                "degradation.\n"
                "0.0 = Completely wrong: retrieves when should not, or fails to "
                "retrieve when necessary, leading to incorrect output.\n\n"
                "Key: Is the retrieval/non-retrieval decision correct and does it "
                "lead to an efficient, accurate response?"
            ),
        )


@register_dimension
class IterativeRetrieval(Dimension):
    """Multi-turn retrieval refinement quality."""

    id: str = "iterative_retrieval"
    name: str = "Iterative Retrieval"
    tier: EvalTier = _TIER
    description: str = "Quality of iterative query refinement across multiple retrieval rounds."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Final answer must be correct
            if "final_answer" in ground_truth:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["final_answer"]),
                        "description": "Final converged answer must be present",
                    }
                )

            # Each refinement step should appear
            refinements = ground_truth.get("refinements", [])
            for refinement in refinements:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(refinement),
                        "description": f"Refinement step must appear: '{refinement}'",
                    }
                )

            # Iterative process indicators
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "refined",
                        "narrowed",
                        "updated query",
                        "second search",
                        "further",
                        "additional",
                        "follow-up",
                        "drilling down",
                        "more specific",
                        "broadened",
                        "rephrased",
                        "iteration",
                        "round 2",
                        "step 2",
                        "next query",
                    ],
                    "description": "Output should show iterative refinement language",
                }
            )

            # Convergence check: output should show progression
            if len(refinements) >= 2:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(r) for r in refinements],
                        "description": "All refinement steps must appear showing convergence",
                    }
                )

            # Multi-step responses should be substantive
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 20,
                    "max": 10000,
                    "description": "Iterative retrieval response should document the process",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score iterative retrieval quality on a 0.0-1.0 scale.\n\n"
                "1.0 = Agent demonstrates clear query refinement across rounds; each "
                "iteration narrows toward the correct answer; final answer is correct "
                "and well-supported; shows evidence of learning from initial results.\n"
                "0.8 = Good iterative process; correct final answer; one refinement "
                "step could have been more targeted.\n"
                "0.6 = Iterative approach attempted; final answer correct but process "
                "shows some unnecessary steps or missed refinements.\n"
                "0.4 = Some iteration shown but convergence is poor; final answer "
                "partially correct.\n"
                "0.2 = Minimal iteration; queries not meaningfully refined between "
                "rounds.\n"
                "0.0 = No iteration; single-shot query with no refinement despite "
                "incomplete results.\n\n"
                "Evaluate: (1) Does each round improve on the previous? "
                "(2) Does the agent use initial results to refine subsequent queries? "
                "(3) Does the process converge to the correct answer?"
            ),
        )


@register_dimension
class ContextLengthRobustness(Dimension):
    """Performance stability as context window length varies."""

    id: str = "context_length_robustness"
    name: str = "Context Length Robustness"
    tier: EvalTier = _TIER
    description: str = "Stability of answer quality across varying context window sizes."
    scorer_type: ScorerType = ScorerType.SEMANTIC
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # All key answers must be present regardless of context length
            for key, value in ground_truth.items():
                if key in (
                    "context_length",
                    "position",
                    "needle_position",
                    "distractor_count",
                    "expect_json",
                ):
                    continue
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(value),
                        "description": f"Key answer '{key}' must be present regardless of context size",
                    }
                )

            # Needle-in-haystack check: key info at specific positions
            needle_position = ground_truth.get("needle_position")
            if needle_position:
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [
                            "found",
                            "located",
                            "identified",
                            "extracted",
                        ],
                        "description": f"Agent should find information at {needle_position} position",
                    }
                )

            # Context utilization metric: response quality should not degrade
            context_length = ground_truth.get("context_length", "unknown")
            if context_length == "long":
                # Long context: ensure agent does not truncate important info
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 10,
                        "max": 10000,
                        "description": "Long-context response should be substantive",
                    }
                )
            elif context_length == "short":
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 3,
                        "max": 2000,
                        "description": "Short-context response should be proportional",
                    }
                )

            # Distractor resistance: many distractors should not degrade quality
            distractor_count = ground_truth.get("distractor_count", 0)
            if distractor_count > 5:
                # With many distractors, correct answer is even more important
                all_values = [
                    str(v)
                    for k, v in ground_truth.items()
                    if k
                    not in (
                        "context_length",
                        "position",
                        "needle_position",
                        "distractor_count",
                        "expect_json",
                    )
                ]
                if all_values:
                    rules.append(
                        {
                            "type": "contains_all",
                            "substrings": all_values,
                            "description": "All key answers must appear despite many distractors",
                        }
                    )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score context length robustness on a 0.0-1.0 scale.\n\n"
                "1.0 = Answer quality is identical whether context is 500 tokens or "
                "50,000 tokens; all key facts extracted accurately; no degradation "
                "from position effects (lost-in-the-middle).\n"
                "0.8 = Answer quality maintained; minor completeness difference "
                "between short and long context.\n"
                "0.6 = Mostly robust but one key fact missed in long-context "
                "scenario (position bias).\n"
                "0.4 = Noticeable quality degradation with long context; some facts "
                "missed or confused.\n"
                "0.2 = Significant quality drop; agent clearly struggles with longer "
                "context windows.\n"
                "0.0 = Complete failure on long-context: misses key facts, hallucinates, "
                "or produces incoherent output.\n\n"
                "Evaluate: (1) Are all key facts present? (2) Is there evidence of "
                "lost-in-the-middle effects? (3) Does response quality degrade "
                "proportionally to context length?"
            ),
        )
