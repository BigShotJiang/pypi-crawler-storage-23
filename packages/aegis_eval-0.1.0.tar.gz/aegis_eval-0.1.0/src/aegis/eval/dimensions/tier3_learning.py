"""Tier 3 — Learning Dynamics dimensions.

Six dimensions that measure an agent's ability to learn from feedback,
transfer knowledge, and maintain stability over time.
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalTier, JudgePacketV1, ScorerType
from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.dimensions.registry import register_dimension
from aegis.eval.dimensions.scoring import score_with_judge

_TIER = EvalTier.LEARNING_DYNAMICS


@register_dimension
class LearningCurve(Dimension):
    """Rate of performance improvement with increasing examples."""

    id: str = "learning_curve"
    name: str = "Learning Curve"
    tier: EvalTier = _TIER
    description: str = "Rate of performance improvement as more examples are provided."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            scores = ground_truth.get("scores", [])
            if scores:
                last_score = scores[-1]
                rules.append(
                    {
                        "type": "numeric_range",
                        "min": last_score,
                        "max": 1.0,
                        "description": f"Final score should be at least {last_score}",
                    }
                )
                # Check for monotonic improvement trend
                if len(scores) >= 2:
                    improvements = sum(
                        1 for i in range(1, len(scores)) if scores[i] >= scores[i - 1]
                    )
                    monotonicity = improvements / (len(scores) - 1)
                    if monotonicity >= 0.8:
                        rules.append(
                            {
                                "type": "any_of",
                                "substrings": [
                                    "improved",
                                    "better",
                                    "increased",
                                    "higher",
                                    "progress",
                                    "gain",
                                    "growth",
                                    "advancing",
                                ],
                                "description": "Monotonically improving: output should reflect improvement",
                            }
                        )

            # Correction detection: check if agent acknowledges learning from corrections
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "improved",
                        "learned",
                        "corrected",
                        "adjusted",
                        "adapted",
                        "refined",
                        "updated",
                        "better",
                        "incorporated feedback",
                        "after correction",
                    ],
                    "description": "Agent should indicate learning/improvement",
                }
            )

            # Expected answer at the end of learning
            if "expected_answer" in ground_truth:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["expected_answer"]),
                        "description": "Final learned answer must be correct",
                    }
                )

            # Improvement rate metric
            if len(scores) >= 3:
                early_avg = sum(scores[: len(scores) // 2]) / max(1, len(scores) // 2)
                late_avg = sum(scores[len(scores) // 2 :]) / max(1, len(scores) - len(scores) // 2)
                if late_avg > early_avg:
                    rules.append(
                        {
                            "type": "any_of",
                            "substrings": [
                                "improvement",
                                "trend",
                                "getting better",
                                "performance increased",
                                "accuracy rose",
                            ],
                            "description": "Learning curve trend is positive",
                        }
                    )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score learning curve quality on a 0.0-1.0 scale.\n\n"
                "1.0 = Clear monotonic improvement across examples; final performance "
                "reaches target threshold; agent explicitly demonstrates learning from "
                "each example.\n"
                "0.8 = Strong improvement trend with at most one minor regression; "
                "target performance achieved.\n"
                "0.6 = Overall upward trend but noticeable plateaus or regressions; "
                "near-target performance.\n"
                "0.4 = Modest improvement; significant variance between rounds; "
                "below-target final performance.\n"
                "0.2 = Minimal improvement despite multiple examples.\n"
                "0.0 = No improvement or performance degradation across examples.\n\n"
                "Evaluate: (1) Is there a clear improvement trend? (2) Are corrections "
                "incorporated? (3) Does final performance meet the target?"
            ),
        )


@register_dimension
class Transfer(Dimension):
    """Ability to apply learned patterns to novel but related tasks."""

    id: str = "transfer"
    name: str = "Transfer"
    tier: EvalTier = _TIER
    description: str = "Generalization of learned patterns to related but unseen tasks."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Expected answer from transfer learning
            if "expected_answer" in ground_truth:
                answer = str(ground_truth["expected_answer"])
                rules.append(
                    {
                        "type": "contains",
                        "substring": answer,
                        "description": "Transferred answer must be correct",
                    }
                )
                # N-gram check on transferred answer
                words = answer.split()
                if len(words) >= 2:
                    bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": bigrams,
                            "threshold": 0.4,
                            "description": "Transfer answer bigram overlap",
                        }
                    )

            # Transfer reasoning: agent should reference the source domain
            source_domain = ground_truth.get("source_domain")
            if source_domain:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(source_domain),
                        "description": f"Source domain '{source_domain}' should be referenced",
                    }
                )

            # Pattern recognition language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "applied",
                        "similar to",
                        "analogous",
                        "same pattern",
                        "transferred",
                        "generalized",
                        "like the previous",
                        "following the same",
                        "by analogy",
                        "extending",
                        "reusing",
                        "adapting from",
                        "based on the pattern",
                    ],
                    "description": "Agent should show transfer reasoning",
                }
            )

            # Target domain must be addressed
            target_domain = ground_truth.get("target_domain")
            if target_domain:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(target_domain),
                        "description": f"Target domain '{target_domain}' must be addressed",
                    }
                )

            # Anti-transfer: ensure agent does not blindly copy without adaptation
            if "should_not_transfer" in ground_truth:
                for item in ground_truth["should_not_transfer"]:
                    rules.append(
                        {
                            "type": "not_contains",
                            "substring": str(item),
                            "description": f"Should not blindly transfer: '{item}'",
                        }
                    )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score transfer learning on a 0.0-1.0 scale.\n\n"
                "1.0 = Agent correctly identifies the shared pattern between source "
                "and target domains; successfully applies the learned approach to the "
                "novel task; explicitly articulates the analogy.\n"
                "0.8 = Correct transfer with minor imprecision in the analogy or "
                "slight adaptation gap.\n"
                "0.6 = Partial transfer: agent recognizes similarity but application "
                "is incomplete or slightly incorrect.\n"
                "0.4 = Agent attempts transfer but misidentifies the shared pattern "
                "or makes significant adaptation errors.\n"
                "0.2 = Minimal transfer: solves the target task from scratch without "
                "leveraging prior learning.\n"
                "0.0 = No transfer: agent treats the task as entirely novel, or "
                "incorrectly transfers an irrelevant pattern.\n\n"
                "Key: Does the agent identify the structural analogy between domains "
                "and adapt the learned approach appropriately?"
            ),
        )


@register_dimension
class Stability(Dimension):
    """Resistance to catastrophic forgetting during continued learning."""

    id: str = "stability"
    name: str = "Stability"
    tier: EvalTier = _TIER
    description: str = "Resistance to catastrophic forgetting and performance degradation."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Retained answers must all be present
            retained = ground_truth.get("retained_answers", [])
            for item in retained:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(item),
                        "description": f"Retained knowledge must persist: '{item}'",
                    }
                )

            # Forgotten items should not reappear
            for item in ground_truth.get("forgotten_items", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(item),
                        "description": f"Incorrectly forgotten item should not appear: '{item}'",
                    }
                )

            # Comprehensive retention check
            if retained:
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": [str(item) for item in retained],
                        "description": "All retained answers must co-occur",
                    }
                )

            # New knowledge must also be present (plasticity)
            new_knowledge = ground_truth.get("new_knowledge", [])
            for item in new_knowledge:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(item),
                        "description": f"New knowledge must be learned: '{item}'",
                    }
                )

            # Preference drift detection: check if preferences shifted incorrectly
            original_preferences = ground_truth.get("original_preferences", {})
            for pref_key, pref_value in original_preferences.items():
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(pref_value),
                        "description": f"Original preference '{pref_key}' must be maintained",
                    }
                )

            # Stability indicator language
            if retained and new_knowledge:
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": max(5, (len(retained) + len(new_knowledge)) * 3),
                        "max": 10000,
                        "description": "Response must cover both retained and new knowledge",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score stability (catastrophic forgetting resistance) on a 0.0-1.0 "
                "scale.\n\n"
                "1.0 = All previously learned knowledge perfectly retained; new "
                "knowledge successfully integrated; no degradation of old skills; "
                "preferences unchanged.\n"
                "0.8 = All old knowledge retained; new knowledge integrated; minor "
                "precision loss on edge-case old facts.\n"
                "0.6 = Most old knowledge retained but one previously learned fact "
                "partially forgotten or altered.\n"
                "0.4 = Noticeable forgetting of 2-3 old facts; new knowledge partially "
                "integrated.\n"
                "0.2 = Significant catastrophic forgetting; most old knowledge lost "
                "while learning new material.\n"
                "0.0 = Complete catastrophic forgetting; old knowledge wiped out by "
                "new learning.\n\n"
                "Evaluate both stability (old knowledge retention) and plasticity "
                "(new knowledge integration). The ideal agent maintains both."
            ),
        )


@register_dimension
class AttributionAccuracy(Dimension):
    """Correctness of credit assignment when learning from feedback."""

    id: str = "attribution_accuracy"
    name: str = "Attribution Accuracy"
    tier: EvalTier = _TIER
    description: str = "Accuracy of credit assignment across contributing factors."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Correct causal attributions: cause-effect pairs
            correct_attributions = ground_truth.get("correct_attributions", {})
            for cause, effect in correct_attributions.items():
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(cause),
                        "description": f"Correct cause must be identified: '{cause}'",
                    }
                )
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(effect),
                        "description": f"Correct effect must be linked: '{effect}'",
                    }
                )

            # All correct attribution pairs should co-occur
            if correct_attributions:
                all_items = []
                for cause, effect in correct_attributions.items():
                    all_items.extend([str(cause), str(effect)])
                rules.append(
                    {
                        "type": "contains_all",
                        "substrings": all_items,
                        "description": "All cause-effect pairs must appear together",
                    }
                )

            # Incorrect attributions must be absent
            for item in ground_truth.get("incorrect_attributions", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(item),
                        "description": f"Incorrect attribution must be absent: '{item}'",
                    }
                )

            # Causal language detection
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "because",
                        "caused by",
                        "due to",
                        "resulted in",
                        "led to",
                        "contributed to",
                        "responsible for",
                        "attributed to",
                        "driven by",
                        "as a result of",
                        "the reason",
                        "explains why",
                    ],
                    "description": "Agent must use causal attribution language",
                }
            )

            # Magnitude/weight of attributions
            if ground_truth.get("primary_cause"):
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(ground_truth["primary_cause"]),
                        "description": "Primary cause must be identified",
                    }
                )

            # Spurious correlation rejection
            for spurious in ground_truth.get("spurious_correlations", []):
                rules.append(
                    {
                        "type": "not_contains",
                        "substring": str(spurious),
                        "description": f"Spurious correlation must be rejected: '{spurious}'",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score attribution accuracy on a 0.0-1.0 scale.\n\n"
                "1.0 = All cause-effect relationships correctly identified; primary "
                "cause distinguished from secondary; spurious correlations rejected; "
                "clear causal reasoning language used.\n"
                "0.8 = Correct attributions with minor imprecision in relative "
                "weighting of contributing factors.\n"
                "0.6 = Most attributions correct but one causal relationship "
                "misidentified or one spurious correlation accepted.\n"
                "0.4 = Several attribution errors; primary cause misidentified or "
                "confused with secondary factors.\n"
                "0.2 = Majority of attributions incorrect; significant confusion "
                "between correlation and causation.\n"
                "0.0 = Completely wrong attributions; causes and effects reversed "
                "or entirely fabricated.\n\n"
                "Key: (1) Are causal relationships correctly identified? (2) Is the "
                "primary cause distinguished from secondary factors? (3) Are spurious "
                "correlations rejected?"
            ),
        )


@register_dimension
class SampleEfficiency(Dimension):
    """Minimum number of examples needed to achieve target performance."""

    id: str = "sample_efficiency"
    name: str = "Sample Efficiency"
    tier: EvalTier = _TIER
    description: str = "Number of examples required to reach a target performance level."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Expected answer must be correct
            if "expected_answer" in ground_truth:
                answer = str(ground_truth["expected_answer"])
                rules.append(
                    {
                        "type": "contains",
                        "substring": answer,
                        "description": "Correct answer from few-shot learning",
                    }
                )
                # N-gram check for answer quality
                words = answer.split()
                if len(words) >= 2:
                    bigrams = [f"{words[i]} {words[i + 1]}" for i in range(len(words) - 1)]
                    rules.append(
                        {
                            "type": "ngram_overlap",
                            "n": 2,
                            "reference_ngrams": bigrams,
                            "threshold": 0.3,
                            "description": "Answer quality via bigram overlap",
                        }
                    )

            # Number of examples used should be tracked
            num_examples = ground_truth.get("num_examples_provided", 0)
            max_examples = ground_truth.get("max_acceptable_examples")
            if max_examples and isinstance(max_examples, int):
                rules.append(
                    {
                        "type": "any_of",
                        "substrings": [f"{i} example" for i in range(1, max_examples + 1)]
                        + [
                            "few examples",
                            "minimal examples",
                            "limited data",
                        ],
                        "description": f"Should achieve target within {max_examples} examples",
                    }
                )

            # Pattern extraction language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "pattern",
                        "rule",
                        "from the examples",
                        "generalized",
                        "extracted",
                        "inferred",
                        "learned",
                        "identified",
                        "based on",
                        "following the pattern",
                    ],
                    "description": "Agent should indicate pattern extraction from examples",
                }
            )

            # Efficiency metrics
            if num_examples and num_examples <= 3:
                rules.append(
                    {
                        "type": "word_count_range",
                        "min": 3,
                        "max": 2000,
                        "description": "Few-shot answer should be direct and efficient",
                    }
                )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score sample efficiency on a 0.0-1.0 scale.\n\n"
                "1.0 = Agent achieves correct answer with minimal examples (1-2 shot); "
                "demonstrates rapid pattern extraction; shows clear generalization "
                "from limited data.\n"
                "0.8 = Correct answer achieved with few examples; slight hesitation "
                "but ultimately efficient.\n"
                "0.6 = Correct answer but required more examples than optimal; "
                "pattern extraction is slow.\n"
                "0.4 = Partially correct answer; needs many examples; slow "
                "convergence.\n"
                "0.2 = Requires excessive examples with poor generalization.\n"
                "0.0 = Cannot learn the pattern regardless of number of examples.\n\n"
                "Evaluate: (1) How many examples were needed? (2) Was the pattern "
                "correctly identified? (3) Does the agent show evidence of efficient "
                "learning?"
            ),
        )


@register_dimension
class PlateauDetection(Dimension):
    """Ability to detect and respond to learning plateaus."""

    id: str = "plateau_detection"
    name: str = "Plateau Detection"
    tier: EvalTier = _TIER
    description: str = "Detection of and strategic response to learning plateaus."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.RESEARCH

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []

        if isinstance(ground_truth, dict):
            # Plateau recognition language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "plateau",
                        "no improvement",
                        "stalled",
                        "flat",
                        "diminishing returns",
                        "converged",
                        "saturated",
                        "not improving",
                        "stuck",
                        "leveled off",
                        "marginal gains",
                        "performance ceiling",
                    ],
                    "description": "Agent must recognize the learning plateau",
                }
            )

            # Strategy change detection
            strategy_change = ground_truth.get("strategy_change")
            if strategy_change:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(strategy_change),
                        "description": f"Strategy change must be proposed: '{strategy_change}'",
                    }
                )

            # Action items for breaking the plateau
            actions = ground_truth.get("recommended_actions", [])
            for action in actions:
                rules.append(
                    {
                        "type": "contains",
                        "substring": str(action),
                        "description": f"Recommended action: '{action}'",
                    }
                )

            # Strategy adaptation language
            rules.append(
                {
                    "type": "any_of",
                    "substrings": [
                        "change strategy",
                        "try different",
                        "alternative approach",
                        "switch to",
                        "adjust",
                        "modify",
                        "new technique",
                        "different method",
                        "increase complexity",
                        "reduce",
                        "explore",
                        "experiment",
                    ],
                    "description": "Agent should propose a strategy change",
                }
            )

            # Quantitative plateau detection
            scores = ground_truth.get("plateau_scores", [])
            if scores and len(scores) >= 3:
                # Detect if scores are flat
                score_range = max(scores) - min(scores)
                if score_range < 0.05:
                    rules.append(
                        {
                            "type": "any_of",
                            "substrings": [
                                "variance",
                                "flat",
                                "no change",
                                "constant",
                                "stable performance",
                                "no significant difference",
                            ],
                            "description": "Scores are flat - agent should detect this",
                        }
                    )

            # Response should be analytical
            rules.append(
                {
                    "type": "word_count_range",
                    "min": 15,
                    "max": 5000,
                    "description": "Plateau analysis should be substantive",
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})

        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric=(
                "Score plateau detection on a 0.0-1.0 scale.\n\n"
                "1.0 = Agent correctly identifies the learning plateau; proposes "
                "a concrete, appropriate strategy change; provides reasoning for "
                "why the current approach has stalled.\n"
                "0.8 = Plateau correctly detected; proposed strategy is reasonable "
                "but could be more specific.\n"
                "0.6 = Plateau detected but strategy change is vague or only "
                "partially appropriate.\n"
                "0.4 = Vague recognition of stalling without clear plateau "
                "identification or actionable strategy change.\n"
                "0.2 = Fails to recognize plateau; minor acknowledgment of slow "
                "progress.\n"
                "0.0 = No recognition of the plateau; continues with the same "
                "strategy expecting different results.\n\n"
                "Evaluate: (1) Is the plateau explicitly recognized? (2) Is the "
                "proposed strategy change appropriate? (3) Is there reasoning for "
                "why the current approach stalled?"
            ),
        )
