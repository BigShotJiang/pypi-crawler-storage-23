"""Shared scoring infrastructure for dimension implementations."""

from __future__ import annotations

from typing import Any

from aegis.core.types import JudgePacketV1
from aegis.eval.judges.triangulated import TriangulatedJudge
from aegis.eval.scorers.rubrics import get_rubric

_judge: TriangulatedJudge | None = None


def get_judge() -> TriangulatedJudge:
    """Return a module-level singleton TriangulatedJudge."""
    global _judge
    if _judge is None:
        _judge = TriangulatedJudge()
    return _judge


def set_judge(judge: TriangulatedJudge) -> None:
    """Set the singleton judge used by all dimension scorers."""
    global _judge
    _judge = judge


def configure_judge(
    *,
    llm_cost_budget_usd: float | None = None,
    llm_budget_fallback_score: float = 0.5,
    weights: tuple[float, float, float] | None = None,
    adaptive_weighting: bool | None = None,
    reset_usage: bool = False,
) -> TriangulatedJudge:
    """Configure the shared judge for a specific eval run."""
    judge = get_judge()
    if weights is not None:
        judge.weights = judge._normalise_weights(weights)
    if adaptive_weighting is not None:
        judge.adaptive_weighting = adaptive_weighting
    if reset_usage:
        judge.llm_scorer.reset_budget_tracking()
    judge.llm_scorer.configure_budget(
        llm_cost_budget_usd,
        fallback_score=llm_budget_fallback_score,
    )
    return judge


def score_with_judge(
    dimension_id: str,
    eval_case_id: str,
    agent_output: Any,
    ground_truth: Any,
    rules: list[dict[str, Any]] | None = None,
    rubric: str = "",
) -> JudgePacketV1:
    """Score via TriangulatedJudge with dimension-specific config.

    If no rubric is provided, the dimension-specific rubric template
    from :mod:`aegis.eval.scorers.rubrics` is used automatically.

    Args:
        dimension_id: The dimension being scored.
        eval_case_id: The eval case ID for tracking.
        agent_output: The agent's raw output.
        ground_truth: The expected answer.
        rules: Optional list of rule configs for the RuleBasedScorer.
        rubric: Optional rubric string for the LLMJudgeScorer. If empty,
            the dimension-specific rubric is used.

    Returns:
        A JudgePacketV1 with triangulated scores.
    """
    judge = get_judge()
    effective_rubric = rubric or get_rubric(dimension_id)
    context: dict[str, Any] = {
        "eval_case_id": eval_case_id,
        "dimension_id": dimension_id,
    }
    if rules:
        context["rules"] = rules
    context["rubric"] = effective_rubric
    return judge.judge(agent_output, ground_truth, context)
