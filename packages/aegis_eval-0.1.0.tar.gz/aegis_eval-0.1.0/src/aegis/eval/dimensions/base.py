"""Base dimension definition and phase enum for the Aegis eval taxonomy.

Every scoreable dimension inherits from :class:`Dimension` and implements
the :meth:`score` method that produces a :class:`JudgePacketV1`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

from pydantic import BaseModel

from aegis.core.types import EvalTier, JudgePacketV1, ScorerType


class Phase(str, Enum):
    """Rollout phase for a dimension.

    Dimensions are introduced in phases to allow incremental platform maturity:
    * CORE — shipped at launch, exercised on every eval run.
    * ADVANCED — enabled once baseline coverage is stable.
    * RESEARCH — experimental; scores are informational only.
    """

    CORE = "core"
    ADVANCED = "advanced"
    RESEARCH = "research"


class Dimension(BaseModel, ABC):
    """A single scoreable evaluation dimension.

    Each dimension maps to exactly one :class:`EvalTier` and declares a
    preferred :class:`ScorerType`.  Concrete subclasses implement :meth:`score`
    to produce a :class:`JudgePacketV1` given agent output and ground truth.

    Attributes:
        id: Unique slug identifier (e.g. ``"retention_accuracy"``).
        name: Human-readable display name.
        tier: Which of the 7 evaluation tiers this dimension belongs to.
        domain: Optional domain tag (e.g. ``"legal"``, ``"medical"``).
        description: One-line description used in reports and dashboards.
        scorer_type: The default scoring backend for this dimension.
        phase: Rollout phase governing when the dimension is active.
    """

    id: str
    name: str
    tier: EvalTier
    domain: str | None = None
    description: str = ""
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    model_config = {"arbitrary_types_allowed": True}

    @abstractmethod
    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        """Score an agent's output against ground truth.

        Args:
            agent_output: The raw output produced by the agent under test.
            ground_truth: The expected/reference answer or behaviour.
            context: Optional additional context (retrieval trace, memory
                state, etc.) that the scorer may use.

        Returns:
            A :class:`JudgePacketV1` containing the triangulated score,
            explanation, and evidence.
        """
        ...
