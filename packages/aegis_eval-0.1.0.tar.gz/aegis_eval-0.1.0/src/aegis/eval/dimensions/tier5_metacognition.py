"""Tier 5 — Meta-Cognition dimensions.

Five dimensions that evaluate an agent's self-awareness, calibration,
and ability to introspect on its own reasoning and limitations.
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalTier, JudgePacketV1, ScorerType
from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.dimensions.registry import register_dimension
from aegis.eval.dimensions.scoring import score_with_judge

_TIER = EvalTier.META_COGNITION


@register_dimension
class Calibration(Dimension):
    """Alignment between expressed confidence and actual accuracy."""

    id: str = "calibration"
    name: str = "Calibration"
    tier: EvalTier = _TIER
    description: str = "Alignment between the agent's expressed confidence and actual accuracy."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules = []
        if isinstance(ground_truth, dict):
            if "answer" in ground_truth:
                rules.append({"type": "contains", "substring": str(ground_truth["answer"])})
            if "expected_confidence" in ground_truth:
                rules.append(
                    {"type": "contains", "substring": str(ground_truth["expected_confidence"])}
                )
        else:
            rules.append({"type": "fuzzy_match"})
        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric="Score confidence calibration: the agent should express appropriate confidence levels — high for well-known facts, low for uncertain predictions.",
        )


@register_dimension
class Explainability(Dimension):
    """Quality of the agent's explanations for its own decisions."""

    id: str = "explainability"
    name: str = "Explainability"
    tier: EvalTier = _TIER
    description: str = "Quality and faithfulness of self-generated decision explanations."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.CORE

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules = []
        if isinstance(ground_truth, dict):
            if "classification" in ground_truth:
                rules.append({"type": "contains", "substring": str(ground_truth["classification"])})
            for term in ground_truth.get("explanation_should_mention", []):
                rules.append({"type": "contains", "substring": str(term)})
        else:
            rules.append({"type": "fuzzy_match"})
        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric="Score the quality and faithfulness of the agent's self-explanation. High scores require clear reasoning that accurately reflects the decision process.",
        )


@register_dimension
class FailurePrediction(Dimension):
    """Ability to predict when it is likely to fail or produce low-quality output."""

    id: str = "failure_prediction"
    name: str = "Failure Prediction"
    tier: EvalTier = _TIER
    description: str = "Accuracy of predicting when own output is likely to be incorrect."
    scorer_type: ScorerType = ScorerType.RULE_BASED
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []
        if isinstance(ground_truth, dict):
            if ground_truth.get("should_flag_risk"):
                rules.append(
                    {
                        "type": "any_of",
                        "rules": [
                            {"type": "contains", "substring": "uncertain"},
                            {"type": "contains", "substring": "may fail"},
                            {"type": "contains", "substring": "low confidence"},
                            {"type": "contains", "substring": "risk"},
                            {"type": "contains", "substring": "unreliable"},
                            {"type": "contains", "substring": "cannot guarantee"},
                        ],
                    }
                )
            for factor in ground_truth.get("risk_factors", []):
                rules.append({"type": "contains", "substring": str(factor)})
        else:
            rules.append({"type": "fuzzy_match"})
        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric="Score failure prediction: the agent must accurately predict when its output is likely incorrect.",
        )


@register_dimension
class StrategyAdaptation(Dimension):
    """Ability to change reasoning strategy based on task difficulty."""

    id: str = "strategy_adaptation"
    name: str = "Strategy Adaptation"
    tier: EvalTier = _TIER
    description: str = "Dynamic adaptation of reasoning strategy based on task characteristics."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.ADVANCED

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []
        if isinstance(ground_truth, dict):
            if "adapted_strategy" in ground_truth:
                rules.append(
                    {"type": "contains", "substring": str(ground_truth["adapted_strategy"])}
                )
            if "reason_for_change" in ground_truth:
                rules.append(
                    {"type": "contains", "substring": str(ground_truth["reason_for_change"])}
                )
            rules.append(
                {
                    "type": "any_of",
                    "rules": [
                        {"type": "contains", "substring": "switching"},
                        {"type": "contains", "substring": "adapting"},
                        {"type": "contains", "substring": "different approach"},
                        {"type": "contains", "substring": "alternative"},
                        {"type": "contains", "substring": "changing strategy"},
                    ],
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})
        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric="Score strategy adaptation: the agent must change its reasoning approach when the initial strategy fails.",
        )


@register_dimension
class SelfDiagnosis(Dimension):
    """Ability to diagnose root causes of its own errors."""

    id: str = "self_diagnosis"
    name: str = "Self-Diagnosis"
    tier: EvalTier = _TIER
    description: str = "Quality of self-diagnosis when the agent identifies its own errors."
    scorer_type: ScorerType = ScorerType.LLM_JUDGE
    phase: Phase = Phase.RESEARCH

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> JudgePacketV1:
        ctx = context or {}
        rules: list[dict[str, Any]] = []
        if isinstance(ground_truth, dict):
            if "error_type" in ground_truth:
                rules.append({"type": "contains", "substring": str(ground_truth["error_type"])})
            if "root_cause" in ground_truth:
                rules.append({"type": "contains", "substring": str(ground_truth["root_cause"])})
            rules.append(
                {
                    "type": "any_of",
                    "rules": [
                        {"type": "contains", "substring": "because"},
                        {"type": "contains", "substring": "root cause"},
                        {"type": "contains", "substring": "error was"},
                        {"type": "contains", "substring": "mistake"},
                        {"type": "contains", "substring": "incorrect due to"},
                        {"type": "contains", "substring": "diagnosis"},
                    ],
                }
            )
        else:
            rules.append({"type": "fuzzy_match"})
        return score_with_judge(
            self.id,
            ctx.get("eval_case_id", ""),
            agent_output,
            ground_truth,
            rules=rules,
            rubric="Score self-diagnosis: the agent must accurately diagnose the root cause of its own errors.",
        )
