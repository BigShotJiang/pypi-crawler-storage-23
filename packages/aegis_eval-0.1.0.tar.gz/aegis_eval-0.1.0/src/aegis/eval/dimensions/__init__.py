"""Aegis eval dimensions — the 51-dimension evaluation taxonomy."""
