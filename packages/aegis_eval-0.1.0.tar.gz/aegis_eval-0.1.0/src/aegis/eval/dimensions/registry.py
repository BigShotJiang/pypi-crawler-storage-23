"""Singleton dimension registry with decorator-based registration.

Usage::

    from aegis.eval.dimensions.registry import register_dimension, DimensionRegistry

    @register_dimension
    class MyDimension(Dimension):
        ...

    registry = DimensionRegistry.instance()
    dim = registry.get("my_dimension_id")
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, TypeVar

from aegis.core.types import EvalTier

if TYPE_CHECKING:
    from aegis.eval.dimensions.base import Dimension, Phase

TDimension = TypeVar("TDimension", bound="Dimension")


class DimensionRegistry:
    """Thread-safe singleton registry that stores dimensions by id.

    Access the global instance via :meth:`instance`.  Dimension classes are
    registered either programmatically with :meth:`register` or declaratively
    with the :func:`register_dimension` decorator.
    """

    _instance: DimensionRegistry | None = None
    _lock: threading.Lock = threading.Lock()

    def __init__(self) -> None:
        self._dimensions: dict[str, Dimension] = {}

    # -- singleton access ----------------------------------------------------

    @classmethod
    def instance(cls) -> DimensionRegistry:
        """Return the global singleton registry, creating it on first call."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton — intended for tests only."""
        with cls._lock:
            cls._instance = None

    # -- mutation ------------------------------------------------------------

    def register(self, dimension: Dimension) -> None:
        """Register a dimension instance by its ``id``.

        Args:
            dimension: A fully-constructed :class:`Dimension` instance.

        Raises:
            ValueError: If a dimension with the same ``id`` is already
                registered.
        """
        if dimension.id in self._dimensions:
            raise ValueError(f"Dimension '{dimension.id}' is already registered.")
        self._dimensions[dimension.id] = dimension

    # -- queries -------------------------------------------------------------

    def get(self, dimension_id: str) -> Dimension:
        """Retrieve a dimension by its unique id.

        Raises:
            KeyError: If no dimension with ``dimension_id`` exists.
        """
        try:
            return self._dimensions[dimension_id]
        except KeyError:
            raise KeyError(f"No dimension registered with id '{dimension_id}'.") from None

    def list_by_tier(self, tier: EvalTier) -> list[Dimension]:
        """Return all dimensions belonging to the given tier."""
        return [d for d in self._dimensions.values() if d.tier == tier]

    def list_by_domain(self, domain: str) -> list[Dimension]:
        """Return all dimensions tagged with the given domain."""
        return [d for d in self._dimensions.values() if d.domain == domain]

    def list_by_phase(self, phase: Phase) -> list[Dimension]:
        """Return all dimensions in the given rollout phase."""
        return [d for d in self._dimensions.values() if d.phase == phase]

    def all(self) -> list[Dimension]:
        """Return every registered dimension, ordered by insertion."""
        return list(self._dimensions.values())


# ---------------------------------------------------------------------------
# Convenience decorator
# ---------------------------------------------------------------------------


def register_dimension(cls: type[TDimension]) -> type[TDimension]:
    """Class decorator that instantiates *cls* and registers it.

    The class must be a concrete :class:`Dimension` subclass whose
    ``__init__`` / model fields provide all required defaults so that it can
    be constructed with zero arguments.

    Example::

        @register_dimension
        class RetentionAccuracy(Dimension):
            id: str = "retention_accuracy"
            name: str = "Retention Accuracy"
            ...
    """
    instance = cls()  # type: ignore[call-arg]
    DimensionRegistry.instance().register(instance)
    return cls
