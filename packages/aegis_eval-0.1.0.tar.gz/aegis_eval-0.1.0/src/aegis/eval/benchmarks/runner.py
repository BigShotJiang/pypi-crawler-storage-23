"""Benchmark suite runner framework.

Provides the core primitives for defining, running, and comparing
standardized benchmark suites against arbitrary agent implementations.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.core.types import EvalCaseV1, StepKind, TrajectoryV1


@dataclass
class BenchmarkConfig:
    """Configuration for a benchmark suite.

    Attributes:
        name: Machine-readable benchmark identifier.
        version: Semantic version string.
        description: Human-readable description.
        domain: Optional domain tag (e.g. ``"legal"``, ``"finance"``).
        num_cases: Expected number of cases in the suite.
        difficulty_distribution: Mapping of difficulty level to count.
        timeout_seconds: Per-case timeout in seconds.
    """

    name: str
    version: str
    description: str
    domain: str | None = None
    num_cases: int = 50
    difficulty_distribution: dict[int, int] = field(default_factory=dict)
    timeout_seconds: int = 300


@dataclass
class BenchmarkResult:
    """Result of running a benchmark suite against an agent.

    Attributes:
        benchmark_name: Name of the benchmark that was run.
        agent_id: Identifier of the agent evaluated.
        overall_score: Aggregate score across all cases in [0.0, 1.0].
        dimension_scores: Per-dimension score breakdown.
        case_results: Detailed results for each individual case.
        duration_seconds: Total wall-clock time of the run.
        timestamp: When the benchmark run completed.
        metadata: Arbitrary additional data.
    """

    benchmark_name: str
    agent_id: str
    overall_score: float
    dimension_scores: dict[str, float]
    case_results: list[dict[str, Any]]
    duration_seconds: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


class BenchmarkSuite:
    """A runnable benchmark suite composed of eval cases.

    Args:
        config: Suite configuration.
        cases: The evaluation cases that make up this benchmark.
    """

    def __init__(self, config: BenchmarkConfig, cases: list[EvalCaseV1]) -> None:
        self.config = config
        self.cases = cases

    # ------------------------------------------------------------------
    # Core execution
    # ------------------------------------------------------------------

    def run(
        self,
        agent: Any,
        evaluator: Any | None = None,
    ) -> BenchmarkResult:
        """Run all benchmark cases against an agent.

        Args:
            agent: An :class:`AgentAdapter` instance or any callable that
                accepts a string prompt and returns a string response.
            evaluator: Optional external scorer. If provided, it must
                expose a ``score(agent_output, ground_truth, **kw) -> float``
                method. When *None*, a built-in heuristic scorer is used.

        Returns:
            A :class:`BenchmarkResult` summarising the run.
        """
        return self._run_cases(self.cases, agent, evaluator)

    def run_subset(
        self,
        agent: Any,
        dimension_filter: str | None = None,
        difficulty_filter: int | None = None,
        evaluator: Any | None = None,
    ) -> BenchmarkResult:
        """Run a filtered subset of benchmark cases.

        Args:
            agent: Agent or callable.
            dimension_filter: If set, only include cases whose
                ``dimension_id`` matches this string.
            difficulty_filter: If set, only include cases at this
                difficulty level.
            evaluator: Optional scorer (same semantics as :meth:`run`).

        Returns:
            A :class:`BenchmarkResult` for the filtered subset.
        """
        filtered = self.cases
        if dimension_filter is not None:
            filtered = [c for c in filtered if c.dimension_id == dimension_filter]
        if difficulty_filter is not None:
            filtered = [c for c in filtered if c.difficulty == difficulty_filter]
        return self._run_cases(filtered, agent, evaluator)

    # ------------------------------------------------------------------
    # Comparison
    # ------------------------------------------------------------------

    @staticmethod
    def compare_results(
        result_a: BenchmarkResult,
        result_b: BenchmarkResult,
    ) -> dict[str, Any]:
        """Compare two benchmark results and return a diff summary.

        Returns:
            A dict with keys ``overall_delta``, ``dimension_deltas``,
            ``improvements``, ``regressions``, and ``unchanged``.
        """
        overall_delta = result_b.overall_score - result_a.overall_score

        all_dims = set(result_a.dimension_scores) | set(result_b.dimension_scores)
        dimension_deltas: dict[str, float] = {}
        improvements: list[str] = []
        regressions: list[str] = []
        unchanged: list[str] = []

        for dim in sorted(all_dims):
            score_a = result_a.dimension_scores.get(dim, 0.0)
            score_b = result_b.dimension_scores.get(dim, 0.0)
            delta = score_b - score_a
            dimension_deltas[dim] = round(delta, 4)

            if delta > 0.01:
                improvements.append(dim)
            elif delta < -0.01:
                regressions.append(dim)
            else:
                unchanged.append(dim)

        return {
            "benchmark": result_a.benchmark_name,
            "agent_a": result_a.agent_id,
            "agent_b": result_b.agent_id,
            "overall_delta": round(overall_delta, 4),
            "dimension_deltas": dimension_deltas,
            "improvements": improvements,
            "regressions": regressions,
            "unchanged": unchanged,
            "a_duration_seconds": result_a.duration_seconds,
            "b_duration_seconds": result_b.duration_seconds,
        }

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    @staticmethod
    def export(result: BenchmarkResult, format: str = "json") -> str:
        """Serialise a benchmark result to a string.

        Args:
            result: The result to export.
            format: ``"json"`` (default) or ``"csv"``.

        Returns:
            The serialised string.
        """
        if format == "csv":
            return _result_to_csv(result)
        return _result_to_json(result)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run_cases(
        self,
        cases: list[EvalCaseV1],
        agent: Any,
        evaluator: Any | None,
    ) -> BenchmarkResult:
        """Execute *cases* against *agent* and aggregate scores."""
        agent_id = _resolve_agent_id(agent)
        invoke = _resolve_invoke(agent)

        case_results: list[dict[str, Any]] = []
        dim_score_accum: dict[str, list[float]] = {}

        t0 = time.monotonic()

        for case in cases:
            case_t0 = time.monotonic()
            try:
                response = invoke(case)
            except Exception as exc:  # noqa: BLE001
                response = f"[ERROR] {exc}"
            case_duration = time.monotonic() - case_t0

            score = _heuristic_score(response, case, evaluator)

            case_results.append(
                {
                    "case_id": case.id,
                    "dimension_id": case.dimension_id,
                    "difficulty": case.difficulty,
                    "score": round(score, 4),
                    "duration_seconds": round(case_duration, 3),
                    "response_preview": response[:300]
                    if isinstance(response, str)
                    else str(response)[:300],
                    "tags": case.tags,
                }
            )

            dim_score_accum.setdefault(case.dimension_id, []).append(score)

        total_duration = time.monotonic() - t0

        # Aggregate dimension scores
        dimension_scores = {
            dim: round(sum(scores) / len(scores), 4) for dim, scores in dim_score_accum.items()
        }

        all_scores = [cr["score"] for cr in case_results]
        overall = sum(all_scores) / len(all_scores) if all_scores else 0.0

        return BenchmarkResult(
            benchmark_name=self.config.name,
            agent_id=agent_id,
            overall_score=round(overall, 4),
            dimension_scores=dimension_scores,
            case_results=case_results,
            duration_seconds=round(total_duration, 3),
            metadata={
                "config_version": self.config.version,
                "total_cases": len(cases),
                "domain": self.config.domain,
            },
        )


# ======================================================================
# Benchmark Registry (singleton)
# ======================================================================


class BenchmarkRegistry:
    """Global registry of named benchmark suites (singleton).

    Usage::

        registry = BenchmarkRegistry()
        registry.register("legal-memory-v1", suite)
        suite = registry.get("legal-memory-v1")
    """

    _instance: BenchmarkRegistry | None = None
    _suites: dict[str, BenchmarkSuite]

    def __new__(cls) -> BenchmarkRegistry:
        if cls._instance is None:
            inst = super().__new__(cls)
            inst._suites = {}
            cls._instance = inst
        return cls._instance

    def register(self, name: str, suite: BenchmarkSuite) -> None:
        """Register a benchmark suite under *name*."""
        self._suites[name] = suite

    def get(self, name: str) -> BenchmarkSuite | None:
        """Return the suite registered under *name*, or ``None``."""
        return self._suites.get(name)

    def list_benchmarks(self) -> list[str]:
        """Return a sorted list of all registered benchmark names."""
        return sorted(self._suites)

    def run_all(self, agent: Any) -> dict[str, BenchmarkResult]:
        """Run every registered benchmark against *agent*.

        Returns:
            A mapping of benchmark name to result.
        """
        results: dict[str, BenchmarkResult] = {}
        for name, suite in self._suites.items():
            results[name] = suite.run(agent)
        return results

    def clear(self) -> None:
        """Remove all registered suites (useful in tests)."""
        self._suites.clear()


# ======================================================================
# Private helpers
# ======================================================================


def _resolve_agent_id(agent: Any) -> str:
    """Extract a human-readable agent identifier."""
    if hasattr(agent, "name"):
        try:
            return str(agent.name)
        except Exception:  # noqa: BLE001
            pass
    if hasattr(agent, "_agent_id"):
        return str(agent._agent_id)
    return type(agent).__name__


def _resolve_invoke(agent: Any) -> Callable[[EvalCaseV1], str]:
    """Return a callable that takes an EvalCaseV1 and returns a string.

    Supports:
    - ``AgentAdapter`` instances (via ``.evaluate()``)
    - Plain callables ``(str) -> str``
    """
    # AgentAdapter — has .evaluate() returning TrajectoryV1
    if hasattr(agent, "evaluate"):

        def _via_adapter(case: EvalCaseV1) -> str:
            traj: TrajectoryV1 = agent.evaluate(case)
            # Return the last answer step, or all content concatenated
            answers = [s.content for s in traj.steps if s.kind == StepKind.ANSWER]
            return answers[-1] if answers else " ".join(s.content for s in traj.steps)

        return _via_adapter

    # Plain callable
    if callable(agent):

        def _via_callable(case: EvalCaseV1) -> str:
            return str(agent(case.prompt))

        return _via_callable

    raise TypeError(
        f"Agent must be an AgentAdapter or a callable(str)->str, got {type(agent).__name__}"
    )


def _heuristic_score(
    response: str,
    case: EvalCaseV1,
    evaluator: Any | None,
) -> float:
    """Score a response against a case.

    If an external evaluator is provided, delegates to it. Otherwise
    uses a keyword/similarity-based heuristic.
    """
    if evaluator is not None and hasattr(evaluator, "score"):
        try:
            return float(evaluator.score(response, case.expected))
        except Exception:  # noqa: BLE001
            pass

    # Built-in heuristic: keyword match against expected fields
    expected = case.expected
    if not expected:
        # No ground truth — give partial credit for non-empty responses
        return 0.5 if response and "[ERROR]" not in response else 0.0

    response_lower = response.lower() if isinstance(response, str) else ""

    # Collect expected keywords from all values in the expected dict
    keywords: list[str] = []
    for val in expected.values():
        if isinstance(val, str):
            keywords.extend(val.lower().split())
        elif isinstance(val, list):
            for item in val:
                keywords.extend(str(item).lower().split())
        else:
            keywords.extend(str(val).lower().split())

    # Filter out very short/common words
    keywords = [kw for kw in keywords if len(kw) > 2]

    if not keywords:
        return 0.5 if response and "[ERROR]" not in response else 0.0

    matched = sum(1 for kw in keywords if kw in response_lower)
    keyword_score = matched / len(keywords) if keywords else 0.0

    # Penalise errors
    if "[ERROR]" in response:
        keyword_score *= 0.1

    return max(0.0, min(1.0, keyword_score))


def _result_to_json(result: BenchmarkResult) -> str:
    """Serialise a BenchmarkResult to pretty-printed JSON."""
    payload = {
        "benchmark_name": result.benchmark_name,
        "agent_id": result.agent_id,
        "overall_score": result.overall_score,
        "dimension_scores": result.dimension_scores,
        "case_results": result.case_results,
        "duration_seconds": result.duration_seconds,
        "timestamp": result.timestamp.isoformat(),
        "metadata": result.metadata,
    }
    return json.dumps(payload, indent=2, default=str)


def _result_to_csv(result: BenchmarkResult) -> str:
    """Serialise a BenchmarkResult to CSV format."""
    lines = ["case_id,dimension_id,difficulty,score,duration_seconds,tags"]
    for cr in result.case_results:
        tags_str = "|".join(cr.get("tags", []))
        lines.append(
            f"{cr['case_id']},{cr['dimension_id']},{cr['difficulty']},"
            f"{cr['score']},{cr['duration_seconds']},{tags_str}"
        )
    return "\n".join(lines)
