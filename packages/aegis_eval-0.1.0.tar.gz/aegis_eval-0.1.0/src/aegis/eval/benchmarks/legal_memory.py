"""Legal memory benchmark — 50 case lifecycles testing memory across conversation turns.

Tests agent memory fidelity, temporal reasoning, cross-document
consistency, citation accuracy, and multi-session knowledge accumulation
in realistic legal scenarios with specific contract language, dates,
parties, and clause references.

Test categories:
  - Fact retention (contract review with supersession)
  - Temporal reasoning (statute of limitations, deadlines, priority dates)
  - Cross-case linking (cross-document consistency and reconciliation)
  - Privilege boundaries (citation verification and access controls)
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.eval.benchmarks.runner import BenchmarkConfig, BenchmarkSuite

_SUITE_ID = "aegis-legal-memory-v1"
_DOMAIN = "legal"

# Memory operations expected across different case types
_MEMORY_OPS = {
    "fact_retention": ["store", "retrieve", "update", "consolidate"],
    "temporal_reasoning": ["store", "retrieve", "temporal_query", "compare"],
    "cross_case_linking": ["store", "retrieve", "link", "graph_query"],
    "privilege_boundaries": ["store", "retrieve", "access_check", "redact"],
}


class LegalMemoryBenchmark:
    """Builder for the AegisLegal-Memory benchmark suite.

    Generates 50 realistic legal test cases spanning five categories:

    1. Contract review with supersession / fact retention (10 cases)
    2. Temporal reasoning (10 cases)
    3. Cross-document consistency / cross-case linking (10 cases)
    4. Citation verification / privilege boundaries (10 cases)
    5. Multi-session knowledge accumulation (10 cases)

    Each scenario includes:
      - ``prompt``: the natural-language question for the agent
      - ``expected_output``: the ground-truth answer fields
      - ``memory_operations_expected``: which memory ops should fire
      - ``difficulty``: integer 1-5
    """

    def __init__(self) -> None:
        self._config = BenchmarkConfig(
            name="aegis-legal-memory-v1",
            version="1.0.0",
            description=(
                "50 multi-session legal case lifecycles testing memory "
                "fidelity, temporal reasoning, and cross-document consistency."
            ),
            domain=_DOMAIN,
            num_cases=50,
            difficulty_distribution={1: 5, 2: 10, 3: 15, 4: 12, 5: 8},
            timeout_seconds=300,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_cases(self) -> list[dict[str, Any]]:
        """Generate 50 legal scenarios as plain dictionaries.

        Returns a list of dicts, each containing:
          - ``prompt`` (str): the scenario question
          - ``expected_output`` (dict): ground-truth answer fields
          - ``memory_operations_expected`` (list[str]): expected memory ops
          - ``difficulty`` (int): 1-5 scale
          - ``category`` (str): one of fact_retention, temporal_reasoning,
            cross_case_linking, privilege_boundaries, multi_session
          - ``tags`` (list[str]): descriptive tags
        """
        raw_cases = self._generate_eval_cases()
        return [
            {
                "prompt": c.prompt,
                "expected_output": c.expected,
                "memory_operations_expected": _MEMORY_OPS.get(
                    _category_from_dimension(c.dimension_id),
                    ["store", "retrieve"],
                ),
                "difficulty": c.difficulty,
                "category": _category_from_dimension(c.dimension_id),
                "tags": c.tags,
                "context": c.context,
            }
            for c in raw_cases
        ]

    def build_suite(self) -> BenchmarkSuite:
        """Build and return the complete benchmark suite."""
        cases = self._generate_eval_cases()
        return BenchmarkSuite(self._config, cases)

    # ------------------------------------------------------------------
    # Internal generation
    # ------------------------------------------------------------------

    def _generate_eval_cases(self) -> list[EvalCaseV1]:
        """Generate all 50 test cases as typed ``EvalCaseV1`` instances."""
        cases: list[EvalCaseV1] = []
        cases.extend(self._contract_supersession_cases())
        cases.extend(self._temporal_reasoning_cases())
        cases.extend(self._cross_document_consistency_cases())
        cases.extend(self._citation_verification_cases())
        cases.extend(self._multi_session_accumulation_cases())
        return cases

    # Convenience aliases matching the task specification
    _generate_cases = _generate_eval_cases

    # ------------------------------------------------------------------
    # Category 1: Contract review with supersession (10 cases)
    # ------------------------------------------------------------------

    def _contract_supersession_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Review the Master Services Agreement between Aldrin Corp and "
                    "Beacon Partners dated 2024-01-15, then review Amendment No. 1 "
                    "dated 2024-06-01. What is the current payment term?"
                ),
                context={
                    "session_1_doc": (
                        "MASTER SERVICES AGREEMENT\n"
                        "Parties: Aldrin Corp ('Client') and Beacon Partners ('Provider')\n"
                        "Effective Date: January 15, 2024\n"
                        "Section 5.1 Payment Terms: Provider shall invoice Client on a "
                        "monthly basis. Payment is due within thirty (30) days of receipt "
                        "of each invoice. Late payments shall accrue interest at 1.5% per month.\n"
                        "Section 5.2 Fee Schedule: Client shall pay Provider $15,000 per month "
                        "for the Base Services described in Exhibit A."
                    ),
                    "session_2_doc": (
                        "AMENDMENT NO. 1 TO MASTER SERVICES AGREEMENT\n"
                        "Effective Date: June 1, 2024\n"
                        "This Amendment supersedes and replaces Section 5.1 of the Agreement.\n"
                        "Section 5.1 (Amended): Provider shall invoice Client on a quarterly "
                        "basis. Payment is due within forty-five (45) days of receipt of each "
                        "invoice. Late payments shall accrue interest at 2.0% per month.\n"
                        "All other terms remain unchanged."
                    ),
                },
                expected={
                    "current_payment_frequency": "quarterly",
                    "current_payment_due": "45 days",
                    "current_late_interest": "2.0% per month",
                    "superseded_section": "Section 5.1",
                },
                difficulty=2,
                tags=["contract_supersession", "amendment", "payment_terms"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "You previously reviewed a software licence agreement between "
                    "Nexon Technologies and DataStream Inc. An addendum was later added "
                    "changing the licence scope. What is the current scope of the licence?"
                ),
                context={
                    "session_1_doc": (
                        "SOFTWARE LICENCE AGREEMENT\n"
                        "Licensor: Nexon Technologies, Inc.\nLicensee: DataStream Inc.\n"
                        "Effective Date: March 1, 2023\n"
                        "Section 2.1 Licence Grant: Licensor grants Licensee a non-exclusive, "
                        "non-transferable licence to use the Software for internal business "
                        "operations at Licensee's headquarters located at 500 Market St, "
                        "San Francisco, CA.\n"
                        "Section 2.2 Restrictions: Licensee shall not sublicence, modify, or "
                        "create derivative works of the Software."
                    ),
                    "session_2_doc": (
                        "ADDENDUM TO SOFTWARE LICENCE AGREEMENT\n"
                        "Effective Date: September 15, 2023\n"
                        "Section 2.1 is hereby deleted in its entirety and replaced with:\n"
                        "Section 2.1 (Revised): Licensor grants Licensee a non-exclusive, "
                        "non-transferable licence to use the Software for internal business "
                        "operations at any Licensee facility within the United States, up to "
                        "a maximum of five (5) locations.\n"
                        "Section 2.2 remains in full force and effect."
                    ),
                },
                expected={
                    "current_scope": "any Licensee facility within the United States, up to 5 locations",
                    "superseded": "single headquarters at 500 Market St",
                    "unchanged_restriction": "no sublicence, modification, or derivative works",
                },
                difficulty=2,
                tags=["contract_supersession", "licence", "scope_change"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A lease agreement between Franklin Realty and Greenleaf LLC was "
                    "amended twice. What is the current monthly rent and security deposit?"
                ),
                context={
                    "original_lease": (
                        "COMMERCIAL LEASE AGREEMENT\n"
                        "Landlord: Franklin Realty Group\nTenant: Greenleaf LLC\n"
                        "Premises: Suite 400, 1200 Commerce Dr, Austin, TX 78701\n"
                        "Term: 36 months commencing July 1, 2023\n"
                        "Section 3.1 Base Rent: Tenant shall pay monthly rent of $8,500.00 "
                        "due on the first day of each calendar month.\n"
                        "Section 3.2 Security Deposit: Tenant shall deposit $17,000.00 "
                        "(two months' rent) upon execution of this Lease."
                    ),
                    "amendment_1": (
                        "FIRST AMENDMENT TO LEASE\nEffective: January 1, 2024\n"
                        "Section 3.1 is amended: Monthly rent is increased to $9,200.00 "
                        "effective January 1, 2024.\n"
                        "Section 3.2 remains unchanged."
                    ),
                    "amendment_2": (
                        "SECOND AMENDMENT TO LEASE\nEffective: July 1, 2024\n"
                        "Section 3.1 is amended: Monthly rent is increased to $9,800.00 "
                        "effective July 1, 2024.\n"
                        "Section 3.2 is amended: Security deposit is increased to $19,600.00. "
                        "Tenant shall pay the additional $2,600.00 within 15 days."
                    ),
                },
                expected={
                    "current_monthly_rent": "$9,800.00",
                    "current_security_deposit": "$19,600.00",
                    "rent_history": ["$8,500.00", "$9,200.00", "$9,800.00"],
                },
                difficulty=3,
                tags=["contract_supersession", "lease", "rent_escalation"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "Review the non-compete clause in the Employment Agreement and its "
                    "subsequent amendment. Is the non-compete currently enforceable in "
                    "California? What changed?"
                ),
                context={
                    "employment_agreement": (
                        "EMPLOYMENT AGREEMENT\n"
                        "Employer: Pinnacle Consulting Group\nEmployee: Sarah J. Martinez\n"
                        "Effective Date: February 1, 2023\n"
                        "Section 8.1 Non-Competition: For a period of twenty-four (24) months "
                        "following termination, Employee shall not engage in any Competing "
                        "Business within a 100-mile radius of any office where Employee "
                        "was assigned.\n"
                        "Section 8.2 Non-Solicitation: For twelve (12) months following "
                        "termination, Employee shall not solicit any client of the Company."
                    ),
                    "amendment": (
                        "AMENDMENT TO EMPLOYMENT AGREEMENT\nEffective: August 1, 2024\n"
                        "Section 8.1 is amended to read:\n"
                        "Section 8.1 Non-Competition: For a period of twelve (12) months "
                        "following termination, Employee shall not engage in any Competing "
                        "Business within a 50-mile radius of the Employee's primary assigned "
                        "office. This clause shall not apply in jurisdictions where non-compete "
                        "agreements are unenforceable by law.\n"
                        "All other sections remain unchanged."
                    ),
                },
                expected={
                    "current_non_compete_duration": "12 months",
                    "current_radius": "50 miles",
                    "california_enforceable": "No, California generally prohibits non-compete agreements",
                    "key_changes": [
                        "duration reduced from 24 to 12 months",
                        "radius reduced from 100 to 50 miles",
                        "carve-out added for jurisdictions where unenforceable",
                    ],
                },
                difficulty=4,
                tags=["contract_supersession", "employment", "non_compete"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A supply agreement was signed, then a side letter modified the "
                    "pricing, and then a formal amendment superseded the side letter. "
                    "What is the current pricing structure?"
                ),
                context={
                    "supply_agreement": (
                        "SUPPLY AGREEMENT\n"
                        "Supplier: Orion Materials Ltd\nBuyer: Cascade Manufacturing Co.\n"
                        "Effective Date: April 1, 2023\n"
                        "Section 4.1 Pricing: Unit price for Standard Grade aluminum: $2.45/lb. "
                        "Unit price for Premium Grade aluminum: $3.80/lb.\n"
                        "Section 4.2 Volume Discounts: Orders exceeding 10,000 lbs receive "
                        "a 5% discount. Orders exceeding 50,000 lbs receive a 10% discount."
                    ),
                    "side_letter": (
                        "SIDE LETTER RE: PRICING\nDate: October 15, 2023\n"
                        "Dear Cascade Manufacturing,\n"
                        "Due to market conditions, we hereby agree to reduce the Standard "
                        "Grade unit price to $2.20/lb effective November 1, 2023. Premium "
                        "Grade pricing remains unchanged. This side letter supersedes "
                        "Section 4.1 with respect to Standard Grade pricing only."
                    ),
                    "formal_amendment": (
                        "AMENDMENT NO. 1\nEffective: February 1, 2024\n"
                        "This Amendment supersedes the Side Letter dated October 15, 2023 "
                        "and Section 4.1 of the Supply Agreement in their entirety.\n"
                        "Section 4.1 (Amended): Unit price for Standard Grade aluminum: "
                        "$2.30/lb. Unit price for Premium Grade aluminum: $3.65/lb.\n"
                        "Section 4.2 remains unchanged."
                    ),
                },
                expected={
                    "standard_grade_price": "$2.30/lb",
                    "premium_grade_price": "$3.65/lb",
                    "side_letter_status": "superseded by Amendment No. 1",
                    "volume_discounts_unchanged": "5% over 10,000 lbs, 10% over 50,000 lbs",
                },
                difficulty=4,
                tags=["contract_supersession", "supply", "pricing", "side_letter"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "The NDA between Kensington Labs and Vanguard Research was restated. "
                    "Compare the confidentiality obligations under the original and restated versions."
                ),
                context={
                    "original_nda": (
                        "MUTUAL NON-DISCLOSURE AGREEMENT\n"
                        "Parties: Kensington Labs Inc. and Vanguard Research Corp.\n"
                        "Effective: January 10, 2024\n"
                        "Section 3 Obligations: Each party shall hold Confidential Information "
                        "in strict confidence for five (5) years following disclosure. "
                        "Confidential Information may only be shared with employees who have "
                        "signed individual NDAs. Neither party shall reverse-engineer any "
                        "Confidential Information."
                    ),
                    "restated_nda": (
                        "AMENDED AND RESTATED MUTUAL NON-DISCLOSURE AGREEMENT\n"
                        "Effective: July 1, 2024\n"
                        "This Agreement supersedes the NDA dated January 10, 2024 in its entirety.\n"
                        "Section 3 Obligations: Each party shall hold Confidential Information "
                        "in strict confidence for three (3) years following disclosure. "
                        "Confidential Information may be shared with employees and approved "
                        "contractors who have signed confidentiality undertakings. Neither party "
                        "shall reverse-engineer any Confidential Information. Each party shall "
                        "implement commercially reasonable security measures to protect "
                        "Confidential Information."
                    ),
                },
                expected={
                    "duration_change": "reduced from 5 years to 3 years",
                    "sharing_change": "expanded from employees only to employees and approved contractors",
                    "new_obligation": "commercially reasonable security measures required",
                    "unchanged": "reverse-engineering prohibition",
                },
                difficulty=3,
                tags=["contract_supersession", "nda", "restatement"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A partnership agreement was amended to change profit-sharing "
                    "percentages. After the amendment, Partner B assigned their interest "
                    "to Partner C. What is the current ownership structure?"
                ),
                context={
                    "partnership_agreement": (
                        "PARTNERSHIP AGREEMENT\n"
                        "Partners: A (Alice Thornton, 60%), B (Benjamin Cross, 25%), "
                        "C (Carmen Delgado, 15%)\n"
                        "Effective: May 1, 2023\n"
                        "Section 6.1 Profit Sharing: Profits and losses shall be allocated "
                        "in proportion to each Partner's ownership percentage.\n"
                        "Section 6.2 Capital Contributions: Partner A: $600,000; "
                        "Partner B: $250,000; Partner C: $150,000."
                    ),
                    "amendment_1": (
                        "AMENDMENT NO. 1\nEffective: November 1, 2023\n"
                        "Section 6.1 is amended: Profit-sharing percentages are revised to "
                        "Partner A: 50%, Partner B: 30%, Partner C: 20%.\n"
                        "Partner B contributed additional capital of $50,000."
                    ),
                    "assignment_agreement": (
                        "ASSIGNMENT OF PARTNERSHIP INTEREST\nEffective: March 1, 2024\n"
                        "Benjamin Cross ('Assignor') hereby assigns their entire 30% "
                        "partnership interest to Carmen Delgado ('Assignee').\n"
                        "Following this assignment: Partner A: 50%, Partner C: 50%."
                    ),
                },
                expected={
                    "current_partner_a": "Alice Thornton, 50%",
                    "current_partner_c": "Carmen Delgado, 50%",
                    "partner_b_status": "no longer a partner (assigned interest to C)",
                    "c_total_interest": "50% (original 20% + assigned 30%)",
                },
                difficulty=4,
                tags=["contract_supersession", "partnership", "assignment"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "The warranty provisions in a product purchase agreement were "
                    "modified by a warranty extension letter. Summarise the current "
                    "warranty terms."
                ),
                context={
                    "purchase_agreement": (
                        "PRODUCT PURCHASE AGREEMENT\n"
                        "Seller: TechPrime Solutions\nBuyer: National Logistics Inc.\n"
                        "Product: Model XR-5000 Industrial Scanners (200 units)\n"
                        "Effective: August 15, 2023\n"
                        "Section 7.1 Warranty: Seller warrants that Products shall be free "
                        "from defects in materials and workmanship for a period of twelve "
                        "(12) months from delivery. Warranty does not cover damage from "
                        "misuse, unauthorized modification, or normal wear.\n"
                        "Section 7.2 Remedy: Seller shall repair or replace defective Products "
                        "at no charge. Seller's liability is limited to the purchase price."
                    ),
                    "warranty_extension": (
                        "WARRANTY EXTENSION LETTER\nDate: January 10, 2024\n"
                        "In consideration of Buyer's commitment to a second purchase order, "
                        "Seller hereby extends the warranty period in Section 7.1 from twelve "
                        "(12) months to twenty-four (24) months from delivery for all XR-5000 "
                        "units delivered under the Agreement.\n"
                        "Additionally, Seller shall provide on-site repair service within 48 "
                        "hours of a warranty claim.\n"
                        "Section 7.2 remains unchanged."
                    ),
                },
                expected={
                    "current_warranty_period": "24 months from delivery",
                    "warranty_coverage": "defects in materials and workmanship",
                    "exclusions": "misuse, unauthorized modification, normal wear",
                    "new_term": "on-site repair within 48 hours",
                    "remedy": "repair or replace at no charge, liability limited to purchase price",
                },
                difficulty=2,
                tags=["contract_supersession", "warranty", "product_purchase"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "A consulting engagement letter was superseded by a master services "
                    "agreement, which itself was partially superseded by individual SOWs. "
                    "For a dispute about hourly rates, which document controls?"
                ),
                context={
                    "engagement_letter": (
                        "ENGAGEMENT LETTER\nDated: February 5, 2023\n"
                        "Consultant: Hargrove Advisory LLC\nClient: Meridian Holdings\n"
                        "Hourly Rate: $350/hour for senior consultants, $200/hour for analysts.\n"
                        "This letter sets forth the terms of our engagement."
                    ),
                    "msa": (
                        "MASTER SERVICES AGREEMENT\nEffective: June 1, 2023\n"
                        "This MSA supersedes the Engagement Letter dated February 5, 2023.\n"
                        "Section 4 Fees: Unless otherwise specified in an applicable Statement "
                        "of Work, hourly rates shall be $375/hour for senior consultants and "
                        "$225/hour for analysts.\n"
                        "Section 12 Order of Precedence: In the event of conflict, the order "
                        "of precedence is: (1) applicable SOW, (2) this MSA, (3) any prior "
                        "engagement letters."
                    ),
                    "sow_3": (
                        "STATEMENT OF WORK #3\nEffective: October 1, 2023\n"
                        "Project: Data Migration Phase 2\n"
                        "Section 2 Fees: For this SOW only, the hourly rate for senior "
                        "consultants is $400/hour. Analyst rates follow the MSA."
                    ),
                },
                expected={
                    "controlling_document_sow3_work": "SOW #3 for senior rates ($400/hr), MSA for analyst rates ($225/hr)",
                    "controlling_document_non_sow3": "MSA rates ($375/hr senior, $225/hr analyst)",
                    "engagement_letter_status": "superseded by MSA",
                    "precedence_order": "SOW > MSA > Engagement Letter",
                },
                difficulty=5,
                tags=["contract_supersession", "precedence", "consulting"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="contract_supersession",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "The indemnification clause of an asset purchase agreement was "
                    "modified by a closing letter to cap the seller's indemnification "
                    "liability. What are the current indemnification terms?"
                ),
                context={
                    "apa": (
                        "ASSET PURCHASE AGREEMENT\n"
                        "Seller: Bridgewater Manufacturing LLC\n"
                        "Buyer: Consolidated Industrial Corp.\n"
                        "Closing Date: December 15, 2023\n"
                        "Purchase Price: $12,500,000\n"
                        "Section 9.1 Indemnification by Seller: Seller shall indemnify and hold "
                        "harmless Buyer from any and all losses arising from breach of "
                        "representations, warranties, or covenants.\n"
                        "Section 9.2 Survival: Representations and warranties survive for "
                        "eighteen (18) months following the Closing Date."
                    ),
                    "closing_letter": (
                        "CLOSING LETTER\nDate: December 15, 2023\n"
                        "The parties agree that Section 9.1 is modified as follows:\n"
                        "Seller's aggregate indemnification liability shall not exceed "
                        "$2,500,000 (20% of the Purchase Price). Individual claims below "
                        "$25,000 shall not be indemnifiable. The aggregate deductible before "
                        "Buyer may make claims is $125,000.\n"
                        "Section 9.2 remains unchanged."
                    ),
                },
                expected={
                    "indemnification_cap": "$2,500,000 (20% of purchase price)",
                    "individual_claim_threshold": "$25,000 minimum",
                    "aggregate_deductible": "$125,000",
                    "survival_period": "18 months from closing",
                    "closing_date": "December 15, 2023",
                },
                difficulty=3,
                tags=["contract_supersession", "indemnification", "asset_purchase"],
            )
        )

        return cases

    # ------------------------------------------------------------------
    # Category 2: Temporal reasoning (10 cases)
    # ------------------------------------------------------------------

    def _temporal_reasoning_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "Based on the timeline of events in the Henderson v. Municipal "
                    "Water Authority case, was the plaintiff's claim filed within the "
                    "applicable statute of limitations?"
                ),
                context={
                    "case_facts": (
                        "Henderson v. Municipal Water Authority\n"
                        "Contamination event discovered: March 12, 2021\n"
                        "Independent lab report confirmed contamination: June 5, 2021\n"
                        "Plaintiff first experienced health symptoms: September 2021\n"
                        "Plaintiff diagnosed with illness linked to contamination: January 8, 2022\n"
                        "Notice of claim filed: October 30, 2023\n"
                        "Formal complaint filed: February 15, 2024"
                    ),
                    "applicable_law": (
                        "State Environmental Tort Statute:\n"
                        "- Statute of limitations: 3 years from date of discovery\n"
                        "- Discovery rule: clock starts when plaintiff knew or should "
                        "have known of the injury and its cause\n"
                        "- Notice of claim against government entity: must be filed "
                        "within 180 days of discovery of injury"
                    ),
                },
                expected={
                    "discovery_date_analysis": "January 8, 2022 (diagnosis linked to contamination)",
                    "sol_deadline": "January 8, 2025 (3 years from discovery)",
                    "complaint_timely": "Yes, filed February 15, 2024, before January 8, 2025",
                    "notice_analysis": "Notice filed October 30, 2023 — 661 days after discovery, exceeds 180-day requirement",
                    "notice_timely": "No, notice of claim was untimely",
                },
                difficulty=4,
                tags=["temporal_reasoning", "statute_of_limitations", "discovery_rule"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "A restrictive covenant has different obligations at different time "
                    "periods. On September 1, 2024, which obligations are still in effect?"
                ),
                context={
                    "covenant": (
                        "RESTRICTIVE COVENANTS (effective March 1, 2024)\n"
                        "Employee: Dr. Lisa Park\n"
                        "Section A: Non-disclosure of trade secrets — permanent, no expiration.\n"
                        "Section B: Non-competition within cardiology practice — 12 months "
                        "from March 1, 2024 (expires March 1, 2025).\n"
                        "Section C: Non-solicitation of patients seen in last 6 months of "
                        "employment — 6 months from March 1, 2024 (expires September 1, 2024).\n"
                        "Section D: Return of hospital property — within 30 days of "
                        "March 1, 2024 (deadline March 31, 2024)."
                    ),
                },
                expected={
                    "section_a": "in effect (permanent)",
                    "section_b": "in effect (expires March 1, 2025)",
                    "section_c": "expired (expired September 1, 2024)",
                    "section_d": "obligation completed or breached (deadline was March 31, 2024)",
                },
                difficulty=3,
                tags=["temporal_reasoning", "restrictive_covenant", "expiration"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "The corporate bylaws were amended on three separate dates. "
                    "What was the quorum requirement on August 15, 2023?"
                ),
                context={
                    "bylaws_history": (
                        "BYLAWS OF RIVERTON TECHNOLOGIES INC.\n\n"
                        "Original Adoption: January 1, 2020\n"
                        "Article IV, Section 3 - Quorum: A majority of the directors then "
                        "in office shall constitute a quorum. Board size: 7 directors.\n\n"
                        "Amendment 1 (effective April 1, 2023):\n"
                        "Article IV, Section 3 is amended: A quorum shall consist of "
                        "two-thirds (2/3) of the directors then in office. Board increased "
                        "to 9 directors.\n\n"
                        "Amendment 2 (effective November 1, 2023):\n"
                        "Article IV, Section 3 is amended: A quorum shall consist of a "
                        "simple majority of the directors then in office. Board remains 9.\n\n"
                        "Amendment 3 (effective February 1, 2024):\n"
                        "Board size increased to 11 directors. Quorum provision unchanged."
                    ),
                },
                expected={
                    "quorum_on_aug_15_2023": "two-thirds (2/3) of 9 directors = 6 directors",
                    "applicable_amendment": "Amendment 1 (effective April 1, 2023)",
                    "reason": "Amendment 2 not yet effective on August 15, 2023",
                },
                difficulty=3,
                tags=["temporal_reasoning", "bylaws", "quorum"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "A regulatory compliance deadline was extended twice. The company "
                    "submitted its report on December 10, 2024. Was it on time?"
                ),
                context={
                    "original_notice": (
                        "REGULATORY NOTICE - Environmental Compliance Division\n"
                        "To: Hartfield Chemical Corp.\n"
                        "Date: March 1, 2024\n"
                        "Annual Environmental Impact Report due: September 30, 2024\n"
                        "Late filing penalty: $5,000 per day"
                    ),
                    "extension_1": (
                        "EXTENSION GRANTED\nDate: September 15, 2024\n"
                        "Hartfield Chemical Corp.'s request for extension is granted.\n"
                        "New deadline: November 15, 2024.\n"
                        "Late penalties begin November 16, 2024."
                    ),
                    "extension_2": (
                        "SECOND EXTENSION GRANTED\nDate: November 10, 2024\n"
                        "Due to facility damage from Hurricane Milton, a second extension "
                        "is granted. New deadline: December 15, 2024.\n"
                        "All penalties waived through December 15, 2024."
                    ),
                },
                expected={
                    "final_deadline": "December 15, 2024",
                    "submission_date": "December 10, 2024",
                    "timely": "Yes, submitted 5 days before the final deadline",
                    "penalty_status": "no penalty (waived through December 15, 2024)",
                },
                difficulty=2,
                tags=["temporal_reasoning", "regulatory", "deadline_extension"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "In a construction dispute, several change orders modified the "
                    "completion date. Calculate the total delay and determine whether "
                    "liquidated damages apply."
                ),
                context={
                    "contract": (
                        "CONSTRUCTION CONTRACT\n"
                        "Owner: Lakeside Development Corp.\n"
                        "Contractor: Atlas Builders Inc.\n"
                        "Original Completion Date: June 30, 2024\n"
                        "Section 8.3 Liquidated Damages: $2,500 per calendar day for each "
                        "day of delay beyond the Completion Date, unless delay is attributable "
                        "to Owner-directed changes or force majeure."
                    ),
                    "change_orders": (
                        "Change Order #1 (April 5, 2024): Owner-directed addition of "
                        "underground parking level. Completion date extended 45 days to "
                        "August 14, 2024.\n\n"
                        "Change Order #2 (July 20, 2024): Contractor-requested substitution "
                        "of materials. No time extension granted.\n\n"
                        "Change Order #3 (August 1, 2024): Force majeure — flooding. "
                        "Completion date extended 30 days to September 13, 2024."
                    ),
                    "actual_completion": "October 10, 2024",
                },
                expected={
                    "adjusted_completion_date": "September 13, 2024",
                    "actual_completion": "October 10, 2024",
                    "days_late": "27 calendar days",
                    "liquidated_damages": "$67,500 (27 days x $2,500)",
                    "excusable_delay_days": "75 (45 owner-directed + 30 force majeure)",
                },
                difficulty=4,
                tags=["temporal_reasoning", "construction", "liquidated_damages"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "An option to purchase real estate must be exercised within "
                    "specific windows. Evaluate whether the buyer's exercise notice "
                    "was timely."
                ),
                context={
                    "option_agreement": (
                        "OPTION TO PURCHASE AGREEMENT\n"
                        "Optionor: Elm Street Properties LLC\nOptionee: Urban Development Co.\n"
                        "Property: 2401-2415 Elm Street, Portland, OR\n"
                        "Option Period: Initial option window: January 1 - March 31, 2024.\n"
                        "Renewal: If not exercised, Optionee may renew for a second window "
                        "of July 1 - September 30, 2024, by paying an additional $50,000 "
                        "renewal fee on or before June 15, 2024.\n"
                        "Exercise: Written notice of exercise must be delivered by certified "
                        "mail. Effective date is date of postmark."
                    ),
                    "events": (
                        "June 10, 2024: Optionee wire-transfers $50,000 renewal fee.\n"
                        "August 22, 2024: Optionee sends exercise notice by certified mail "
                        "(postmark August 22, 2024).\n"
                        "August 26, 2024: Exercise notice received by Optionor."
                    ),
                },
                expected={
                    "renewal_valid": "Yes, renewal fee paid June 10, before June 15 deadline",
                    "exercise_window": "July 1 - September 30, 2024",
                    "exercise_date": "August 22, 2024 (postmark date controls)",
                    "exercise_timely": "Yes, within the renewed option window",
                },
                difficulty=3,
                tags=["temporal_reasoning", "real_estate", "option_exercise"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "An insurance policy had a retroactive date and a claims-made "
                    "provision. Determine coverage for incidents occurring on three "
                    "different dates."
                ),
                context={
                    "policy": (
                        "PROFESSIONAL LIABILITY INSURANCE POLICY\n"
                        "Insured: Maxwell & Associates LLP\n"
                        "Policy Period: January 1, 2024 to December 31, 2024\n"
                        "Retroactive Date: July 1, 2022\n"
                        "Claims-Made Basis: Covers claims first made during the policy "
                        "period for wrongful acts occurring on or after the Retroactive Date.\n"
                        "Extended Reporting Period: 60 days after policy expiration for "
                        "claims based on acts during the policy period."
                    ),
                    "incidents": (
                        "Incident A: Wrongful act on March 15, 2022; claim made August 5, 2024.\n"
                        "Incident B: Wrongful act on September 1, 2023; claim made May 20, 2024.\n"
                        "Incident C: Wrongful act on November 1, 2024; claim made February 10, 2025."
                    ),
                },
                expected={
                    "incident_a": "NOT covered — wrongful act (March 15, 2022) predates retroactive date (July 1, 2022)",
                    "incident_b": "COVERED — act after retroactive date, claim during policy period",
                    "incident_c": "COVERED — act during policy period, claim within 60-day extended reporting period",
                },
                difficulty=4,
                tags=["temporal_reasoning", "insurance", "claims_made"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "A trust instrument has provisions that activate at different "
                    "beneficiary ages. Which provisions are currently active for a "
                    "beneficiary born on May 15, 1999?"
                ),
                context={
                    "trust_instrument": (
                        "THE PEMBERTON FAMILY TRUST\n"
                        "Established: January 1, 2010\nTrustee: First National Bank\n"
                        "Beneficiary: James Pemberton (DOB: May 15, 1999)\n\n"
                        "Distribution Schedule:\n"
                        "- Age 18: Beneficiary may receive income distributions for "
                        "educational expenses, subject to Trustee approval.\n"
                        "- Age 21: Beneficiary receives first distribution of 10% of "
                        "trust corpus.\n"
                        "- Age 25: Beneficiary receives second distribution of 25% of "
                        "remaining trust corpus. Beneficiary may serve as co-trustee.\n"
                        "- Age 30: Beneficiary receives remaining trust corpus outright. "
                        "Trust terminates.\n"
                        "Current Date for analysis: February 22, 2026."
                    ),
                },
                expected={
                    "beneficiary_current_age": "26 years old",
                    "age_18_provision": "active (educational distributions available since May 2017)",
                    "age_21_provision": "triggered (10% distribution available since May 2020)",
                    "age_25_provision": "triggered (25% distribution and co-trustee since May 2024)",
                    "age_30_provision": "not yet active (activates May 2029)",
                    "trust_status": "still in existence, not yet terminated",
                },
                difficulty=3,
                tags=["temporal_reasoning", "trust", "distribution_schedule"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "A patent prosecution timeline involves multiple filing dates, "
                    "priority claims, and office action deadlines. Was the response "
                    "to the second office action timely filed?"
                ),
                context={
                    "prosecution_history": (
                        "US Patent Application No. 17/123,456\n"
                        "Applicant: NovaTech Innovations LLC\n"
                        "Provisional Filing Date: March 10, 2022\n"
                        "Non-Provisional Filing Date: March 8, 2023 (claiming priority "
                        "to provisional)\n"
                        "First Office Action (non-final rejection): Mailed October 15, 2023\n"
                        "Response deadline: 3 months (extendable up to 6 months with fees)\n"
                        "Response to First OA filed: January 12, 2024\n"
                        "Second Office Action (final rejection): Mailed April 5, 2024\n"
                        "Response deadline: 3 months (extendable up to 6 months with fees)\n"
                        "Response to Second OA filed: September 28, 2024\n"
                        "Extension fee paid: 3-month extension ($1,800)"
                    ),
                },
                expected={
                    "second_oa_mailed": "April 5, 2024",
                    "initial_deadline": "July 5, 2024 (3 months)",
                    "extended_deadline": "October 5, 2024 (6 months with extension)",
                    "response_filed": "September 28, 2024",
                    "timely": "Yes, within the 6-month extended deadline",
                    "extension_months_used": "3 months",
                },
                difficulty=3,
                tags=["temporal_reasoning", "patent", "prosecution"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="temporal_reasoning",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "An M&A transaction has multiple closing conditions with different "
                    "outside dates. As of January 15, 2025, which conditions remain "
                    "unsatisfied and is the deal still alive?"
                ),
                context={
                    "merger_agreement": (
                        "AGREEMENT AND PLAN OF MERGER\n"
                        "Acquiror: Summit Capital Partners\nTarget: Horizon Biotech Inc.\n"
                        "Signing Date: June 1, 2024\n"
                        "Outside Date: March 31, 2025\n\n"
                        "Closing Conditions:\n"
                        "1. HSR Antitrust Clearance — received August 20, 2024.\n"
                        "2. FDA Approval for lead drug candidate — must be received by "
                        "February 28, 2025 (condition-specific outside date).\n"
                        "3. Stockholder approval of Target — special meeting held November 12, "
                        "2024; approved by 78% vote.\n"
                        "4. No Material Adverse Effect — ongoing condition.\n"
                        "5. Minimum cash balance of Target: $50M at closing — as of "
                        "January 10, 2025, Target reports $62M cash.\n"
                        "6. Key employee retention agreements — 8 of 10 required employees "
                        "signed as of December 31, 2024."
                    ),
                },
                expected={
                    "satisfied_conditions": [
                        "HSR clearance (August 20, 2024)",
                        "Stockholder approval (November 12, 2024)",
                        "Minimum cash balance ($62M > $50M requirement)",
                    ],
                    "pending_conditions": [
                        "FDA approval (deadline February 28, 2025)",
                        "MAE condition (ongoing)",
                        "Key employee retention (8 of 10, need 2 more)",
                    ],
                    "deal_alive": "Yes, outside date is March 31, 2025",
                    "nearest_risk": "FDA approval deadline February 28, 2025",
                },
                difficulty=5,
                tags=["temporal_reasoning", "mergers", "closing_conditions"],
            )
        )

        return cases

    # ------------------------------------------------------------------
    # Category 3: Cross-document consistency (10 cases)
    # ------------------------------------------------------------------

    def _cross_document_consistency_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "Compare the representations in the Stock Purchase Agreement with "
                    "the disclosure schedules. Are there any inconsistencies?"
                ),
                context={
                    "spa_section": (
                        "STOCK PURCHASE AGREEMENT\n"
                        "Section 3.8 Litigation: Seller represents that there is no pending "
                        "or, to Seller's knowledge, threatened litigation against the Company "
                        "except as set forth in Schedule 3.8.\n"
                        "Section 3.12 Material Contracts: All material contracts are listed in "
                        "Schedule 3.12. The Company is not in default under any material contract."
                    ),
                    "schedule_3_8": (
                        "SCHEDULE 3.8 - LITIGATION\n"
                        "1. Smith v. Company — breach of contract, filed May 2024, "
                        "damages sought: $150,000. Status: pending.\n"
                        "2. State EPA investigation re: facility emissions. "
                        "Status: preliminary inquiry."
                    ),
                    "schedule_3_12": (
                        "SCHEDULE 3.12 - MATERIAL CONTRACTS\n"
                        "1. Supply Agreement with Apex Materials, dated Jan 2023\n"
                        "2. Office Lease with Harbor Properties, dated Mar 2022\n"
                        "3. Distribution Agreement with National Distributors, dated Sep 2023"
                    ),
                    "other_document": (
                        "COMPANY BOARD MINUTES - August 2024\n"
                        "Item 4: The Board discussed the Johnson class action filed July 2024 "
                        "seeking $2M in damages. Outside counsel to provide status update.\n"
                        "Item 7: CFO reported default notice received from Apex Materials "
                        "regarding late delivery under the Supply Agreement."
                    ),
                },
                expected={
                    "litigation_discrepancy": "Johnson class action ($2M) from July 2024 not listed in Schedule 3.8",
                    "contract_discrepancy": "Default notice from Apex Materials contradicts Section 3.12 representation of no defaults",
                    "risk_assessment": "Material omissions in disclosure schedules",
                },
                difficulty=5,
                tags=["cross_doc_consistency", "spa", "disclosure_schedules"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "The board resolution authorises a transaction on certain terms. "
                    "Does the executed agreement match the authorised terms?"
                ),
                context={
                    "board_resolution": (
                        "BOARD RESOLUTION - Approved October 1, 2024\n"
                        "RESOLVED, that the Company is authorised to enter into a Credit "
                        "Facility with Pacific National Bank on the following terms:\n"
                        "- Maximum borrowing: $5,000,000\n"
                        "- Interest rate: SOFR + 2.50%\n"
                        "- Maturity: 3 years\n"
                        "- Security: First lien on all Company assets\n"
                        "- Financial covenant: Debt-to-EBITDA not to exceed 3.5x\n"
                        "- CEO authorised to execute on behalf of the Company"
                    ),
                    "executed_agreement": (
                        "CREDIT AGREEMENT\nEffective: October 15, 2024\n"
                        "Borrower: The Company\nLender: Pacific National Bank\n"
                        "Maximum Commitment: $7,500,000\n"
                        "Interest Rate: SOFR + 3.00%\n"
                        "Maturity Date: October 15, 2027 (3 years)\n"
                        "Security: First lien on all Borrower assets\n"
                        "Financial Covenant: Debt-to-EBITDA not to exceed 4.0x\n"
                        "Executed by: CFO of the Company"
                    ),
                },
                expected={
                    "amount_discrepancy": "Authorised $5M but executed $7.5M",
                    "rate_discrepancy": "Authorised SOFR+2.50% but executed SOFR+3.00%",
                    "covenant_discrepancy": "Authorised 3.5x but executed 4.0x",
                    "signatory_discrepancy": "Board authorised CEO but CFO signed",
                    "consistent_terms": "Maturity (3 years) and security (first lien) match",
                },
                difficulty=4,
                tags=["cross_doc_consistency", "board_resolution", "credit_agreement"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A franchise agreement and the franchisee disclosure document (FDD) "
                    "should contain consistent territory descriptions. Do they?"
                ),
                context={
                    "fdd_item_12": (
                        "FDD ITEM 12 - TERRITORY\n"
                        "Each franchisee receives an exclusive territory defined as a 3-mile "
                        "radius from the franchised location. Franchisor will not operate or "
                        "licence another unit within the exclusive territory. Territory "
                        "protection is for the initial 5-year term only."
                    ),
                    "franchise_agreement": (
                        "FRANCHISE AGREEMENT\n"
                        "Franchisee: GreenBite Franchising LLC\n"
                        "Location: 1500 Oak Ave, Denver, CO 80202\n"
                        "Section 2.3 Territory: Franchisee is granted a protected territory "
                        "defined as a 2-mile radius from the Franchised Location. Franchisor "
                        "reserves the right to operate Company-owned units within the protected "
                        "territory. Territory protection continues for the full term of the "
                        "Agreement, including renewals."
                    ),
                },
                expected={
                    "radius_discrepancy": "FDD says 3 miles, Agreement says 2 miles",
                    "exclusivity_discrepancy": "FDD says exclusive (no other units), Agreement allows Company-owned units",
                    "duration_discrepancy": "FDD says initial 5-year term only, Agreement says full term including renewals",
                    "regulatory_risk": "FDD/Agreement inconsistencies may violate FTC Franchise Rule",
                },
                difficulty=4,
                tags=["cross_doc_consistency", "franchise", "territory"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "Compare the employee handbook's termination policy with the "
                    "employment agreement's termination clause for an executive. "
                    "Identify conflicts."
                ),
                context={
                    "handbook": (
                        "EMPLOYEE HANDBOOK (Rev. January 2024)\n"
                        "Section 9.1 Termination: Employment is at-will. Either party may "
                        "terminate the employment relationship at any time, with or without "
                        "cause, with or without notice.\n"
                        "Section 9.2 Severance: No employee is entitled to severance pay "
                        "unless approved by the Board of Directors.\n"
                        "Section 9.3 Final Pay: Final pay check issued within 72 hours of "
                        "termination per state law."
                    ),
                    "executive_agreement": (
                        "EXECUTIVE EMPLOYMENT AGREEMENT\n"
                        "Executive: Robert Chen, Chief Technology Officer\n"
                        "Effective: March 15, 2024\n"
                        "Section 6.2 Termination Without Cause: Company may terminate "
                        "Executive without cause upon 90 days' written notice.\n"
                        "Section 6.3 Severance: Upon termination without cause, Executive "
                        "shall receive 12 months' base salary, pro-rated bonus, and 12 months "
                        "COBRA coverage.\n"
                        "Section 6.4 Good Reason: Executive may resign for Good Reason "
                        "(defined as material diminution of duties, reduction in compensation, "
                        "or forced relocation) and receive the same severance as Section 6.3."
                    ),
                },
                expected={
                    "notice_conflict": "Handbook says no notice required; agreement requires 90 days' notice for without-cause termination",
                    "severance_conflict": "Handbook says no severance unless Board-approved; agreement guarantees 12 months severance",
                    "resolution": "Executive agreement typically controls for the specific executive (more specific governs)",
                    "additional_exec_rights": "Good Reason resignation not addressed in handbook",
                },
                difficulty=3,
                tags=["cross_doc_consistency", "employment", "termination"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A loan commitment letter and the final loan agreement have different "
                    "prepayment terms. Identify the discrepancies."
                ),
                context={
                    "commitment_letter": (
                        "COMMITMENT LETTER\nDate: July 1, 2024\n"
                        "Lender: First Commercial Bank\nBorrower: Westfield Enterprises LLC\n"
                        "Loan Amount: $10,000,000\n"
                        "Prepayment: Borrower may prepay the loan in whole or in part at any "
                        "time without penalty. Minimum prepayment amount: $100,000."
                    ),
                    "loan_agreement": (
                        "TERM LOAN AGREEMENT\nEffective: August 15, 2024\n"
                        "Section 2.5 Voluntary Prepayment: Borrower may prepay the Loan "
                        "subject to the following:\n"
                        "(a) Prepayment during the first 24 months: 2% prepayment premium "
                        "on the amount prepaid.\n"
                        "(b) Prepayment during months 25-36: 1% prepayment premium.\n"
                        "(c) Prepayment after month 36: no premium.\n"
                        "(d) Minimum prepayment: $250,000.\n"
                        "(e) 30 days' prior written notice required."
                    ),
                },
                expected={
                    "penalty_discrepancy": "Commitment says no penalty; Agreement imposes 2% and 1% premiums",
                    "minimum_discrepancy": "Commitment says $100,000 minimum; Agreement says $250,000",
                    "notice_added": "Agreement requires 30 days' notice not mentioned in commitment",
                    "borrower_impact": "Materially worse prepayment terms in final agreement",
                },
                difficulty=3,
                tags=["cross_doc_consistency", "loan", "prepayment"],
            )
        )

        # Cases 6-10 for cross-document consistency
        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A will and a trust instrument reference the same assets but contain "
                    "conflicting dispositions. Identify the conflicts and which controls."
                ),
                context={
                    "will": (
                        "LAST WILL AND TESTAMENT OF MARGARET R. THORNTON\n"
                        "Executed: February 14, 2023\n"
                        "Article III: I bequeath my residence at 47 Maple Lane, Greenwich, CT "
                        "to my daughter, Elizabeth Thornton.\n"
                        "Article IV: I bequeath my investment portfolio at Merrill Lynch "
                        "(Account #7829-4561) to be divided equally among my three children.\n"
                        "Article V: I bequeath my art collection to the Greenwich Museum of Art."
                    ),
                    "trust": (
                        "THE THORNTON FAMILY REVOCABLE TRUST\n"
                        "Executed: June 1, 2023 (four months after the Will)\n"
                        "Trustee: First National Trust Company\n"
                        "Schedule A (Trust Assets): The Greenwich residence at 47 Maple Lane "
                        "has been conveyed to the Trust by quitclaim deed recorded July 2023.\n"
                        "Section 4.1: Upon the Settlor's death, the Greenwich residence shall "
                        "be sold and proceeds distributed to the Settlor's grandchildren's "
                        "education fund.\n"
                        "Section 4.2: The art collection is held in trust for the benefit of "
                        "Elizabeth Thornton."
                    ),
                },
                expected={
                    "residence_conflict": "Will gives to Elizabeth; Trust says sell and give proceeds to grandchildren's education fund",
                    "residence_resolution": "Trust controls — property was conveyed to trust, so it passes outside the will",
                    "art_conflict": "Will gives to museum; Trust gives to Elizabeth",
                    "art_resolution": "Depends on whether art was transferred to trust — if in trust, trust controls",
                    "investment_account": "No conflict — only addressed in will",
                },
                difficulty=5,
                tags=["cross_doc_consistency", "estate_planning", "will_trust_conflict"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "An insurance policy's declarations page and the policy form define "
                    "coverage limits differently. What is the actual coverage?"
                ),
                context={
                    "declarations": (
                        "DECLARATIONS PAGE\n"
                        "Policy No: CGL-2024-78901\n"
                        "Named Insured: Pacific Coast Contractors Inc.\n"
                        "Policy Period: Jan 1 - Dec 31, 2024\n"
                        "Coverage A - Bodily Injury/Property Damage:\n"
                        "  Each Occurrence: $2,000,000\n"
                        "  General Aggregate: $4,000,000\n"
                        "Coverage B - Personal/Advertising Injury:\n"
                        "  Each Occurrence: $2,000,000\n"
                        "Products-Completed Operations Aggregate: $4,000,000"
                    ),
                    "policy_form": (
                        "COMMERCIAL GENERAL LIABILITY POLICY FORM CG 00 01\n"
                        "Section III - Limits of Insurance:\n"
                        "The most we will pay for all damages because of bodily injury and "
                        "property damage is the Each Occurrence Limit shown in the Declarations.\n"
                        "However, the Products-Completed Operations Aggregate is a sublimit "
                        "within the General Aggregate, not in addition to it."
                    ),
                    "endorsement": (
                        "ENDORSEMENT CG 25 04\nAmendment of Limits\n"
                        "The Products-Completed Operations Aggregate is amended to be "
                        "separate from and in addition to the General Aggregate.\n"
                        "Effective Date: January 1, 2024"
                    ),
                },
                expected={
                    "each_occurrence": "$2,000,000",
                    "general_aggregate": "$4,000,000",
                    "products_ops_aggregate": "$4,000,000 — separate from general aggregate (per endorsement)",
                    "endorsement_effect": "Endorsement overrides policy form's sublimit language",
                    "total_potential_coverage": "up to $8,000,000 (general + products-ops aggregates)",
                },
                difficulty=4,
                tags=["cross_doc_consistency", "insurance", "coverage_limits"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A joint venture agreement and its operating agreement have different "
                    "dispute resolution provisions. Which mechanism applies?"
                ),
                context={
                    "jv_agreement": (
                        "JOINT VENTURE AGREEMENT\n"
                        "Parties: Apex Development LLC (50%) and Horizon Realty Corp (50%)\n"
                        "Section 15 Dispute Resolution: All disputes shall be submitted to "
                        "binding arbitration under AAA Commercial Rules in New York, NY. "
                        "Each party bears its own arbitration costs."
                    ),
                    "operating_agreement": (
                        "OPERATING AGREEMENT OF THE JV ENTITY\n"
                        "Section 11 Dispute Resolution: Disputes between Members shall first "
                        "be submitted to mediation for 60 days. If mediation fails, disputes "
                        "shall be resolved by litigation in the state courts of Delaware. "
                        "Prevailing party entitled to attorney's fees.\n\n"
                        "Section 14 Governing Hierarchy: In the event of a conflict between "
                        "this Agreement and the Joint Venture Agreement, the Joint Venture "
                        "Agreement shall control."
                    ),
                },
                expected={
                    "jv_mechanism": "binding arbitration (AAA, New York)",
                    "oa_mechanism": "mediation then litigation (Delaware state courts)",
                    "controlling_provision": "JV Agreement controls (per Operating Agreement Section 14)",
                    "practical_note": "Mediation step from OA may still be advisable before triggering arbitration",
                },
                difficulty=3,
                tags=["cross_doc_consistency", "joint_venture", "dispute_resolution"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A vendor contract references compliance with the company's "
                    "privacy policy. The privacy policy was updated after the contract "
                    "was signed. Which version applies?"
                ),
                context={
                    "vendor_contract": (
                        "VENDOR DATA PROCESSING AGREEMENT\n"
                        "Effective: May 1, 2023\n"
                        "Section 7 Privacy: Vendor shall process personal data in accordance "
                        "with Company's Privacy Policy, as may be amended from time to time, "
                        "available at https://company.com/privacy.\n"
                        "Section 12 Amendments: Amendments to this Agreement require mutual "
                        "written consent, except that Company may update its Privacy Policy "
                        "unilaterally with 30 days' notice to Vendor."
                    ),
                    "privacy_v1": (
                        "PRIVACY POLICY v1.0 (Effective May 1, 2023)\n"
                        "Data Retention: Personal data retained for 24 months.\n"
                        "Data Transfer: No cross-border data transfers.\n"
                        "Breach Notification: Within 72 hours."
                    ),
                    "privacy_v2": (
                        "PRIVACY POLICY v2.0 (Effective January 15, 2024)\n"
                        "Data Retention: Personal data retained for 12 months.\n"
                        "Data Transfer: Cross-border transfers permitted under Standard "
                        "Contractual Clauses.\n"
                        "Breach Notification: Within 48 hours.\n"
                        "Notice sent to Vendor on December 15, 2023 (31 days before effective)."
                    ),
                },
                expected={
                    "applicable_version": "v2.0 (current version, properly noticed)",
                    "notice_compliant": "Yes, 31 days' notice exceeds 30-day requirement",
                    "key_changes": [
                        "Retention shortened from 24 to 12 months",
                        "Cross-border transfers now permitted under SCCs",
                        "Breach notification tightened from 72 to 48 hours",
                    ],
                    "vendor_impact": "Vendor must comply with stricter notification and retention requirements",
                },
                difficulty=4,
                tags=["cross_doc_consistency", "privacy", "vendor_contract"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_consistency",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A corporate charter and shareholder agreement both address "
                    "preemptive rights. Do they match?"
                ),
                context={
                    "charter": (
                        "AMENDED AND RESTATED CERTIFICATE OF INCORPORATION\n"
                        "Article 4.5 Preemptive Rights: Holders of Common Stock shall have "
                        "preemptive rights to subscribe for any new issuance of Common Stock "
                        "on a pro rata basis. This right does not extend to issuances under "
                        "employee stock option plans approved by the Board."
                    ),
                    "shareholder_agreement": (
                        "SHAREHOLDER AGREEMENT\nEffective: June 1, 2024\n"
                        "Section 5.1 Preemptive Rights: Each Shareholder shall have the right "
                        "to participate in any new issuance of equity securities (including "
                        "Common Stock, Preferred Stock, and convertible instruments) on a pro "
                        "rata basis. No exceptions for employee option plans.\n"
                        "Section 5.2 Exercise Period: Shareholders must exercise preemptive "
                        "rights within 20 business days of notice.\n"
                        "Section 12 Conflict: In the event of conflict between this Agreement "
                        "and the Charter, the Charter shall control to the extent required by law."
                    ),
                },
                expected={
                    "scope_discrepancy": "Charter covers Common Stock only; Agreement covers all equity securities",
                    "exception_discrepancy": "Charter excepts employee option plans; Agreement has no such exception",
                    "conflict_resolution": "Charter controls where required by law; Agreement provides broader contractual rights",
                    "practical_impact": "Shareholders may have contractual claim for preemptive rights on preferred stock issuances",
                },
                difficulty=5,
                tags=["cross_doc_consistency", "corporate", "preemptive_rights"],
            )
        )

        return cases

    # ------------------------------------------------------------------
    # Category 4: Citation verification (10 cases)
    # ------------------------------------------------------------------

    def _citation_verification_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Verify whether the following legal citations are correctly formatted "
                    "and refer to actual provisions in the supplied contract."
                ),
                context={
                    "contract_excerpt": (
                        "TECHNOLOGY LICENSING AGREEMENT\n"
                        "Section 2.1 Grant of Licence\n"
                        "Section 2.2 Sublicensing\n"
                        "Section 3.1 Royalty Payments\n"
                        "Section 3.2 Audit Rights\n"
                        "Section 4.1 Representations and Warranties\n"
                        "Section 5.1 Indemnification\n"
                        "Section 6.1 Term\n"
                        "Section 6.2 Termination for Cause\n"
                        "Section 7 Governing Law"
                    ),
                    "memo_with_citations": (
                        "MEMORANDUM\n"
                        "The licence is granted under Section 2.1. Sublicensing is permitted "
                        "per Section 2.3 with written consent. Royalties are calculated under "
                        "Section 3.1 at 5% of net revenue. Audit rights under Section 3.2 "
                        "allow annual audits. The indemnification in Section 5.2 covers IP "
                        "infringement claims. Termination for convenience is addressed in "
                        "Section 6.3. The agreement is governed by Delaware law per Section 7."
                    ),
                },
                expected={
                    "valid_citations": ["Section 2.1", "Section 3.1", "Section 3.2", "Section 7"],
                    "invalid_citations": [
                        "Section 2.3 — should be Section 2.2 (Sublicensing)",
                        "Section 5.2 — should be Section 5.1 (Indemnification)",
                        "Section 6.3 — does not exist; only 6.1 (Term) and 6.2 (Termination for Cause)",
                    ],
                },
                difficulty=2,
                tags=["citation_verification", "section_references"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A brief cites several court cases. Verify the case names, courts, "
                    "and years based on the provided information."
                ),
                context={
                    "brief_excerpt": (
                        "Plaintiff relies on Johnson v. State Farm, 5th Cir. 2019, holding that "
                        "insurers must provide written notice before cancellation. See also "
                        "Williams v. Hartford Ins. Co., S.D.N.Y. 2020, which extended this "
                        "requirement to commercial policies. Defendant's reliance on Parker v. "
                        "Nationwide Mutual, 3d Cir. 2018, is misplaced as that case addressed "
                        "automobile, not commercial liability, policies."
                    ),
                    "case_database": (
                        "VERIFIED CASE RECORDS:\n"
                        "1. Johnson v. State Farm Mutual, 5th Cir. 2019 — held written notice "
                        "required before cancellation of personal insurance policies.\n"
                        "2. Williams v. Hartford Insurance Co., S.D.N.Y. 2021 — extended "
                        "notice requirement to commercial policies.\n"
                        "3. Parker v. Nationwide Mutual Insurance Co., 3d Cir. 2017 — addressed "
                        "automobile insurance cancellation procedures."
                    ),
                },
                expected={
                    "johnson_v_state_farm": "Mostly correct — brief says 'State Farm' but full name is 'State Farm Mutual'; court and year correct",
                    "williams_v_hartford": "Year error — brief says 2020, actual year is 2021",
                    "parker_v_nationwide": "Year error — brief says 2018, actual year is 2017; otherwise correct",
                    "substantive_accuracy": "Holdings described in brief are substantively correct",
                },
                difficulty=3,
                tags=["citation_verification", "case_law"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A compliance officer's report cites several regulatory provisions. "
                    "Verify that the citations match the actual regulatory text."
                ),
                context={
                    "compliance_report": (
                        "COMPLIANCE REPORT - Q3 2024\n"
                        "1. Per HIPAA Section 164.512(a), covered entities may disclose PHI "
                        "without authorization for public health activities.\n"
                        "2. GDPR Article 17 grants data subjects the right to erasure.\n"
                        "3. SOX Section 302 requires CEO and CFO to certify financial statements.\n"
                        "4. CCPA Section 1798.120 establishes the right to opt out of data sales.\n"
                        "5. PCI DSS Requirement 6.2 mandates vulnerability scanning every 90 days."
                    ),
                    "regulatory_text": (
                        "ACTUAL PROVISIONS:\n"
                        "- 45 CFR 164.512(a): Permits disclosure for public health activities "
                        "(as required by law). [Correctly cited]\n"
                        "- GDPR Art. 17: Right to erasure ('right to be forgotten'). [Correct]\n"
                        "- SOX Section 302: CEO and CFO certification of quarterly and annual "
                        "reports. [Correct]\n"
                        "- CCPA 1798.120: Right to opt out of sale of personal information. "
                        "[Correct — note: CPRA amendments expanded this to 'sale or sharing']\n"
                        "- PCI DSS Requirement 6.2: Establish a process to identify security "
                        "vulnerabilities using reputable outside sources. Scanning frequency "
                        "is covered by Requirement 11.3 (quarterly ASV scans). [Misattributed]"
                    ),
                },
                expected={
                    "hipaa_164_512a": "correct citation",
                    "gdpr_art_17": "correct citation",
                    "sox_302": "correct citation",
                    "ccpa_1798_120": "substantially correct, note CPRA expanded scope to 'sharing'",
                    "pci_dss_req_6_2": "incorrect — quarterly scanning is Requirement 11.3, not 6.2",
                },
                difficulty=3,
                tags=["citation_verification", "regulatory"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "An internal memo quotes specific language from a contract. Verify "
                    "that the quoted language is accurate."
                ),
                context={
                    "memo": (
                        "INTERNAL MEMO\n"
                        "Re: Termination rights under Vendor Agreement\n\n"
                        "Section 8.2 of the Agreement states: 'Either party may terminate "
                        "this Agreement for convenience upon sixty (60) days' written notice.'\n\n"
                        "Section 8.3 states: 'In the event of a material breach, the "
                        "non-breaching party may terminate upon thirty (30) days' written "
                        "notice if the breach remains uncured.'"
                    ),
                    "actual_contract": (
                        "VENDOR SERVICES AGREEMENT\n"
                        "Section 8.2 Termination for Convenience: Either party may terminate "
                        "this Agreement for convenience upon ninety (90) days' prior written "
                        "notice to the other party.\n"
                        "Section 8.3 Termination for Cause: In the event of a material breach, "
                        "the non-breaching party may terminate this Agreement upon thirty (30) "
                        "days' written notice, provided the breaching party fails to cure such "
                        "breach within said thirty-day period."
                    ),
                },
                expected={
                    "section_8_2_accuracy": "INACCURATE — memo says 60 days, contract says 90 days",
                    "section_8_3_accuracy": "PARTIALLY ACCURATE — notice period correct (30 days) but memo omits the cure period language",
                    "risk": "Relying on 60-day termination notice could result in premature termination",
                },
                difficulty=2,
                tags=["citation_verification", "quotation_accuracy"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A legal research memorandum cites statutes with specific subsection "
                    "numbers. Verify the statutory structure."
                ),
                context={
                    "research_memo": (
                        "RESEARCH MEMORANDUM\n"
                        "Under the Uniform Commercial Code:\n"
                        "1. UCC 2-207 governs battle of the forms (additional terms in acceptance).\n"
                        "2. UCC 2-302 addresses unconscionable contracts.\n"
                        "3. UCC 2-615 covers commercial impracticability (force majeure excuse).\n"
                        "4. UCC 2-719 allows limitation of remedies.\n"
                        "5. UCC 2-316 governs exclusion of warranties.\n"
                        "6. UCC 2-725 provides a 4-year statute of limitations for sales contracts."
                    ),
                    "ucc_outline": (
                        "UCC ARTICLE 2 - SALES (Selected Sections):\n"
                        "2-207: Additional Terms in Acceptance or Confirmation [Correct]\n"
                        "2-302: Unconscionable Contract or Clause [Correct]\n"
                        "2-316: Exclusion or Modification of Warranties [Correct]\n"
                        "2-615: Excuse by Failure of Presupposed Conditions [Correct — "
                        "commercial impracticability]\n"
                        "2-719: Contractual Modification or Limitation of Remedy [Correct]\n"
                        "2-725: Statute of Limitations in Contracts for Sale [Correct — "
                        "4-year period]"
                    ),
                },
                expected={
                    "all_citations_valid": "Yes, all six UCC section citations are correct",
                    "descriptions_accurate": "All descriptions match the UCC provisions",
                    "note": "UCC 2-207 was substantially revised in the 2003 Amended Article 2, but few states adopted it",
                },
                difficulty=1,
                tags=["citation_verification", "statutory", "ucc"],
            )
        )

        # Cases 6-10 for citation verification
        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A due diligence report cross-references exhibits that should be "
                    "attached. Verify whether all referenced exhibits exist."
                ),
                context={
                    "dd_report": (
                        "DUE DILIGENCE REPORT\n"
                        "1. Financial statements are attached as Exhibit A.\n"
                        "2. Environmental reports are summarised in Exhibit B.\n"
                        "3. IP portfolio is detailed in Exhibit D.\n"
                        "4. Customer contracts are listed in Exhibit E.\n"
                        "5. Employee census data is in Exhibit F.\n"
                        "6. Tax returns for three years are in Exhibit G."
                    ),
                    "exhibit_list": (
                        "EXHIBITS ATTACHED:\n"
                        "Exhibit A: Audited Financial Statements (2021-2023)\n"
                        "Exhibit B: Phase I Environmental Site Assessment\n"
                        "Exhibit C: Title Insurance Commitment (not referenced in report)\n"
                        "Exhibit D: Intellectual Property Schedule\n"
                        "Exhibit E: Material Customer Contracts\n"
                        "Note: Exhibits F and G were requested but not yet received."
                    ),
                },
                expected={
                    "matched_exhibits": ["A", "B", "D", "E"],
                    "missing_exhibits": [
                        "F (employee census)",
                        "G (tax returns) — not yet received",
                    ],
                    "unreferenced_exhibit": "Exhibit C (Title Insurance) — attached but not referenced in report",
                    "risk": "Report references exhibits F and G as if attached, but they are missing",
                },
                difficulty=2,
                tags=["citation_verification", "due_diligence", "exhibits"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Verify that the legal opinion letter's assumptions match the "
                    "actual transaction documents."
                ),
                context={
                    "opinion_letter": (
                        "LEGAL OPINION LETTER\n"
                        "Assumptions:\n"
                        "1. The Borrower is a Delaware limited liability company in good standing.\n"
                        "2. The Credit Agreement has been duly authorized by the Borrower's "
                        "Board of Directors.\n"
                        "3. The guarantor has provided a continuing guaranty for obligations "
                        "up to $5,000,000.\n"
                        "4. All security interests have been properly perfected by UCC-1 filings."
                    ),
                    "actual_documents": (
                        "ACTUAL FACTS:\n"
                        "1. Certificate of Formation (Delaware): Borrower is a limited "
                        "liability company. Good standing certificate dated 6 months ago.\n"
                        "2. Borrower is an LLC — has a Manager, not a Board of Directors. "
                        "Manager's consent was obtained.\n"
                        "3. Guaranty Agreement: Guaranty is limited to $3,500,000.\n"
                        "4. UCC-1 Financing Statement filed with Delaware Secretary of State "
                        "on the closing date. Search report confirms first-priority position."
                    ),
                },
                expected={
                    "assumption_1": "Partially correct — LLC status correct, but good standing may be stale (6 months old)",
                    "assumption_2": "Incorrect — LLCs have Managers, not Board of Directors; authorization was by Manager",
                    "assumption_3": "Incorrect — opinion assumes $5M guaranty, actual is $3.5M",
                    "assumption_4": "Correct — UCC-1 properly filed, first priority confirmed",
                },
                difficulty=4,
                tags=["citation_verification", "legal_opinion", "assumptions"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A settlement agreement references a court order. Verify the "
                    "order's docket number, date, and substance."
                ),
                context={
                    "settlement": (
                        "SETTLEMENT AGREEMENT\n"
                        "Recital B: Pursuant to the Court's Order dated March 15, 2024 "
                        "(Docket No. 78), the Court certified a class of all purchasers "
                        "of Product X between January 2020 and December 2023.\n"
                        "Recital C: The Court's Order (Docket No. 92) appointed Lead "
                        "Counsel and approved the notice plan on May 1, 2024."
                    ),
                    "court_docket": (
                        "CASE DOCKET - Case No. 2023-CV-04521\n"
                        "Docket 78 (March 15, 2024): Order granting class certification. "
                        "Class defined as purchasers of Product X between January 2021 "
                        "and December 2023.\n"
                        "Docket 91 (April 28, 2024): Order appointing Lead Counsel.\n"
                        "Docket 92 (May 1, 2024): Order approving notice plan."
                    ),
                },
                expected={
                    "docket_78_date": "Correct (March 15, 2024)",
                    "docket_78_substance": "Discrepancy — settlement says 'January 2020' but order says 'January 2021'",
                    "docket_92_date": "Correct (May 1, 2024)",
                    "docket_92_substance": "Partially correct — Docket 92 approved notice plan but Lead Counsel appointed in Docket 91, not 92",
                    "combined_reference_error": "Settlement conflates two separate orders (91 and 92) into one",
                },
                difficulty=4,
                tags=["citation_verification", "settlement", "court_orders"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A contract's defined terms are used throughout. Check whether "
                    "they are used consistently with their definitions."
                ),
                context={
                    "definitions": (
                        "DEFINITIONS (Article 1):\n"
                        "'Affiliate' means any entity controlling, controlled by, or under "
                        "common control with a Party, where control means ownership of more "
                        "than 50% of voting securities.\n"
                        "'Confidential Information' means any non-public information disclosed "
                        "by a Party to the other Party, excluding information that is publicly "
                        "available or independently developed.\n"
                        "'Territory' means the United States and Canada."
                    ),
                    "contract_body": (
                        "Section 4.1: Licensee may sublicence the Software to its Affiliates, "
                        "including any entity in which Licensee holds at least a 30% ownership "
                        "interest.\n"
                        "Section 7.2: Each Party agrees not to disclose Confidential Information "
                        "to third parties, including information that becomes publicly known "
                        "after disclosure.\n"
                        "Section 9.1: Licensee's rights extend throughout the Territory, "
                        "including Mexico."
                    ),
                },
                expected={
                    "affiliate_misuse": "Section 4.1 expands Affiliate to 30% ownership, but definition requires >50%",
                    "confidential_info_misuse": "Section 7.2 protects info that becomes public, but definition excludes publicly available info",
                    "territory_misuse": "Section 9.1 includes Mexico, but Territory is defined as US and Canada only",
                    "risk": "Internal inconsistencies could create ambiguity or litigation risk",
                },
                difficulty=3,
                tags=["citation_verification", "defined_terms", "consistency"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="citation_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A closing checklist states that certain conditions have been "
                    "satisfied. Verify against the actual documents."
                ),
                context={
                    "closing_checklist": (
                        "CLOSING CHECKLIST - STATUS: ALL ITEMS COMPLETE\n"
                        "1. Certificate of Good Standing for Buyer - RECEIVED\n"
                        "2. Secretary's Certificate certifying board approval - RECEIVED\n"
                        "3. Legal Opinion of Seller's Counsel - RECEIVED\n"
                        "4. Estoppel Certificates from all tenants (10 total) - ALL RECEIVED\n"
                        "5. Title Insurance Policy - RECEIVED\n"
                        "6. Phase I Environmental Report - RECEIVED"
                    ),
                    "actual_status": (
                        "ACTUAL STATUS OF CLOSING ITEMS:\n"
                        "1. Good Standing Certificate — received but dated 45 days ago "
                        "(requirement says within 30 days of closing).\n"
                        "2. Secretary's Certificate — received, proper form.\n"
                        "3. Legal Opinion — received, but missing assumption regarding "
                        "environmental compliance.\n"
                        "4. Estoppel Certificates — only 8 of 10 tenants signed. "
                        "Tenants in Suites 201 and 305 have not returned certificates.\n"
                        "5. Title Insurance — commitment received, but final policy not "
                        "yet issued.\n"
                        "6. Phase I Environmental Report — completed and clean."
                    ),
                },
                expected={
                    "item_1": "ISSUE — certificate is stale (45 days vs 30-day requirement)",
                    "item_2": "correct",
                    "item_3": "ISSUE — opinion missing environmental compliance assumption",
                    "item_4": "INCORRECT — only 8 of 10 received, not all",
                    "item_5": "ISSUE — commitment received but not final policy",
                    "item_6": "correct",
                    "overall": "Checklist incorrectly states all items complete",
                },
                difficulty=3,
                tags=["citation_verification", "closing", "checklist"],
            )
        )

        return cases

    # ------------------------------------------------------------------
    # Category 5: Multi-session knowledge accumulation (10 cases)
    # ------------------------------------------------------------------

    def _multi_session_accumulation_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "Over three sessions, you reviewed a complex joint venture. In "
                    "Session 1 you learned the ownership structure. In Session 2, the "
                    "capital call provisions. In Session 3, a member defaulted. What "
                    "are the consequences of the default?"
                ),
                context={
                    "session_1": (
                        "JV STRUCTURE:\n"
                        "Members: Alpha LLC (40%), Beta Corp (35%), Gamma Partners (25%)\n"
                        "Capital Contributions: Alpha $4M, Beta $3.5M, Gamma $2.5M\n"
                        "Managing Member: Alpha LLC"
                    ),
                    "session_2": (
                        "CAPITAL CALL PROVISIONS:\n"
                        "Section 5.1: Managing Member may issue capital calls with 30 days' notice.\n"
                        "Section 5.2: Failure to fund within 30 days constitutes a default.\n"
                        "Section 5.3: Defaulting Member's interest is diluted by 50% of the "
                        "unfunded amount. Non-defaulting Members may fund the shortfall and "
                        "receive additional units proportionally.\n"
                        "Section 5.4: Defaulting Member loses voting rights until cured."
                    ),
                    "session_3": (
                        "CAPITAL CALL EVENT:\n"
                        "Date: November 1, 2024\n"
                        "Capital Call: $1,000,000 total ($400K Alpha, $350K Beta, $250K Gamma)\n"
                        "Alpha: Funded in full on November 20, 2024.\n"
                        "Beta: Funded in full on November 25, 2024.\n"
                        "Gamma: Failed to fund by December 1, 2024 deadline."
                    ),
                },
                expected={
                    "defaulting_member": "Gamma Partners",
                    "dilution": "Gamma's interest diluted by 50% of $250K unfunded = $125K dilution equivalent",
                    "voting_rights": "Gamma loses voting rights until default is cured",
                    "non_defaulting_remedy": "Alpha and Beta may fund Gamma's $250K shortfall and receive additional units",
                    "revised_ownership": "Gamma's 25% interest is diluted; exact new % depends on dilution formula",
                },
                difficulty=4,
                tags=["multi_session_accumulation", "joint_venture", "default"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "Across several sessions you built up knowledge about a patent "
                    "portfolio. Using all prior sessions, identify potential freedom-to-operate "
                    "risks for a new product."
                ),
                context={
                    "session_1_patents": (
                        "COMPETITOR PATENT PORTFOLIO:\n"
                        "US 10,123,456 — 'Method for real-time data compression using neural "
                        "networks' — Filed 2019, Granted 2021. Claims cover neural compression "
                        "with <10ms latency.\n"
                        "US 10,234,567 — 'Adaptive streaming protocol' — Filed 2020, Granted "
                        "2022. Claims cover adaptive bitrate with ML-based prediction."
                    ),
                    "session_2_analysis": (
                        "INITIAL FTO ANALYSIS:\n"
                        "Our proposed product 'StreamX' uses neural compression and adaptive "
                        "streaming. Engineer notes: our compression approach uses transformer "
                        "models (different architecture) but achieves sub-10ms latency. Our "
                        "adaptive streaming uses rule-based, not ML-based, prediction."
                    ),
                    "session_3_update": (
                        "PRODUCT CHANGE NOTICE:\n"
                        "StreamX v2 specification change: Engineering has switched from "
                        "rule-based to ML-based adaptive streaming prediction for better "
                        "performance. Neural compression architecture unchanged."
                    ),
                },
                expected={
                    "patent_456_risk": "Moderate — different architecture (transformer vs unspecified) but similar latency target (<10ms); design-around may be defensible",
                    "patent_567_risk": "HIGH after v2 change — StreamX v2 now uses ML-based prediction, directly reading on patent claims",
                    "v2_change_impact": "Product change significantly increased FTO risk for patent 567",
                    "recommendation": "Seek opinion of counsel on patent 567 before launching v2",
                },
                difficulty=5,
                tags=["multi_session_accumulation", "patent", "fto"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You tracked a regulatory investigation across multiple sessions. "
                    "Summarise the current status and recommend next steps."
                ),
                context={
                    "session_1": (
                        "REGULATORY INQUIRY (October 2024):\n"
                        "SEC informal inquiry letter received regarding revenue recognition "
                        "practices for Q1-Q3 2024. Company: Evergreen Solutions Inc.\n"
                        "Requesting: Revenue detail by customer segment, contract copies for "
                        "top 20 customers, and management's revenue recognition memo."
                    ),
                    "session_2": (
                        "RESPONSE AND ESCALATION (December 2024):\n"
                        "Company responded with requested documents on November 15, 2024.\n"
                        "SEC issued formal order of investigation on December 10, 2024.\n"
                        "Scope expanded to include related-party transactions.\n"
                        "Company engaged outside counsel (Morrison & Foerster) and forensic "
                        "accountants (Alvarez & Marsal)."
                    ),
                    "session_3": (
                        "LATEST DEVELOPMENTS (February 2026):\n"
                        "Forensic review identified two related-party transactions not "
                        "disclosed in 10-K filings: (1) $800K consulting contract with CEO's "
                        "brother-in-law, (2) $1.2M equipment lease from entity controlled by "
                        "Board member.\n"
                        "SEC staff indicated willingness to discuss settlement.\n"
                        "Board formed Special Committee of independent directors."
                    ),
                },
                expected={
                    "current_status": "Formal SEC investigation, settlement discussions possible",
                    "key_findings": "Two undisclosed related-party transactions totaling $2M",
                    "timeline": "Inquiry Oct 2024, escalated Dec 2024, findings Feb 2026",
                    "next_steps": [
                        "Special Committee should complete independent investigation",
                        "Engage settlement negotiations with SEC",
                        "Consider 10-K/A restatement for undisclosed related-party transactions",
                        "Evaluate potential liability of CEO and Board member",
                        "Assess D&O insurance coverage",
                    ],
                },
                difficulty=4,
                tags=["multi_session_accumulation", "regulatory", "sec_investigation"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You managed a contract negotiation across sessions. The other "
                    "side made concessions in each round. What is the current state "
                    "of each negotiation point?"
                ),
                context={
                    "session_1_initial_positions": (
                        "NEGOTIATION TRACKER - ROUND 1:\n"
                        "Issue 1 (Liability Cap): Our position: 1x contract value. "
                        "Their position: unlimited.\n"
                        "Issue 2 (IP Ownership): Our position: we own all work product. "
                        "Their position: joint ownership.\n"
                        "Issue 3 (Term): Our position: 1 year with renewals. "
                        "Their position: 3-year minimum.\n"
                        "Issue 4 (Governing Law): Our position: Delaware. "
                        "Their position: California."
                    ),
                    "session_2_round_2": (
                        "ROUND 2 UPDATE:\n"
                        "Issue 1: They moved to 5x contract value cap. We hold at 1x.\n"
                        "Issue 2: They agreed to our sole ownership. RESOLVED.\n"
                        "Issue 3: They moved to 2-year minimum. We moved to 1 year initial "
                        "with auto-renewal.\n"
                        "Issue 4: No movement from either side."
                    ),
                    "session_3_round_3": (
                        "ROUND 3 UPDATE:\n"
                        "Issue 1: They moved to 3x. We moved to 2x.\n"
                        "Issue 3: They accepted 1 year with auto-renewal, provided 6-month "
                        "notice required for non-renewal. We agree. RESOLVED.\n"
                        "Issue 4: They proposed New York as compromise. We considering."
                    ),
                },
                expected={
                    "issue_1_status": "Open — gap is 2x (ours) vs 3x (theirs)",
                    "issue_2_status": "Resolved — sole ownership by us (agreed Round 2)",
                    "issue_3_status": "Resolved — 1-year initial, auto-renewal, 6-month non-renewal notice (agreed Round 3)",
                    "issue_4_status": "Open — they proposed New York as compromise, we are considering",
                    "remaining_issues": 2,
                },
                difficulty=3,
                tags=["multi_session_accumulation", "negotiation", "tracking"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You reviewed a corporate restructuring across four sessions. "
                    "A subsidiary was incorporated, funded, and then merged into "
                    "another entity. Trace the complete lifecycle."
                ),
                context={
                    "session_1": (
                        "INCORPORATION:\n"
                        "NewCo LLC formed in Delaware on January 15, 2024.\n"
                        "Sole member: ParentCo Inc.\n"
                        "Authorised purpose: Acquisition and operation of the Target business."
                    ),
                    "session_2": (
                        "CAPITALISATION:\n"
                        "ParentCo contributed $20M cash and IP assets (valued at $5M) to NewCo.\n"
                        "NewCo obtained $30M term loan from Bank of America.\n"
                        "Total capitalisation: $55M."
                    ),
                    "session_3": (
                        "ACQUISITION:\n"
                        "NewCo acquired 100% of Target Corp for $50M on June 1, 2024.\n"
                        "Target Corp became a wholly-owned subsidiary of NewCo.\n"
                        "Post-acquisition org: ParentCo -> NewCo -> Target Corp."
                    ),
                    "session_4": (
                        "SIMPLIFICATION MERGER:\n"
                        "Effective December 1, 2024, Target Corp merged with and into NewCo.\n"
                        "NewCo is the surviving entity.\n"
                        "NewCo renamed to 'ParentCo Operations LLC'.\n"
                        "Final structure: ParentCo Inc. -> ParentCo Operations LLC."
                    ),
                },
                expected={
                    "entity_lifecycle": "NewCo formed Jan 2024, capitalised, acquired Target Jun 2024, merged with Target Dec 2024, renamed",
                    "current_structure": "ParentCo Inc. -> ParentCo Operations LLC (formerly NewCo)",
                    "target_status": "No longer exists as separate entity (merged into NewCo)",
                    "total_investment": "$55M (ParentCo equity $25M + $30M debt)",
                    "key_dates": [
                        "Jan 15, 2024 (formation)",
                        "Jun 1, 2024 (acquisition)",
                        "Dec 1, 2024 (merger)",
                    ],
                },
                difficulty=3,
                tags=["multi_session_accumulation", "restructuring", "entity_lifecycle"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You assisted with a multi-phase litigation. Using accumulated "
                    "knowledge from all sessions, assess the strength of the plaintiff's "
                    "case at the current stage."
                ),
                context={
                    "session_1_complaint": (
                        "CASE: Meridian Health v. OmniPharma Inc.\n"
                        "Filed: March 2024. Claim: breach of exclusive distribution agreement.\n"
                        "Meridian alleges OmniPharma sold products directly to Meridian's "
                        "customers in violation of Section 3.1 (Exclusive Territory).\n"
                        "Damages sought: $8.5M in lost profits."
                    ),
                    "session_2_discovery": (
                        "DISCOVERY UPDATE (August 2024):\n"
                        "Emails produced show OmniPharma sales team deliberately targeted "
                        "3 of Meridian's top 10 accounts.\n"
                        "OmniPharma's defence: Section 3.1 only covers 'retail' distribution, "
                        "not 'institutional' sales. The targeted accounts are hospitals.\n"
                        "Contract language: 'Distributor shall have exclusive rights to "
                        "distribute Products in the Territory to all customers.'"
                    ),
                    "session_3_expert_reports": (
                        "EXPERT REPORTS (January 2025):\n"
                        "Plaintiff's damages expert: Lost profits of $7.2M based on "
                        "historical sales to the 3 accounts.\n"
                        "Defendant's expert: Lost profits at most $2.1M; argues Meridian "
                        "would have lost accounts regardless due to service issues.\n"
                        "Defendant filed motion for summary judgment on contract interpretation."
                    ),
                },
                expected={
                    "liability_strength": "Strong — contract says 'all customers' without retail/institutional distinction; emails show deliberate targeting",
                    "damages_range": "$2.1M to $7.2M depending on which expert the jury credits",
                    "key_evidence": "Internal emails showing deliberate targeting of Meridian's accounts",
                    "defence_weakness": "OmniPharma's 'retail only' interpretation contradicted by 'all customers' language",
                    "msj_outlook": "Likely denied — factual disputes on contract interpretation and damages preclude summary judgment",
                },
                difficulty=5,
                tags=["multi_session_accumulation", "litigation", "case_assessment"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You tracked a real estate development project through zoning, "
                    "permitting, and construction phases. What approvals remain outstanding?"
                ),
                context={
                    "session_1_zoning": (
                        "PROJECT: Riverside Mixed-Use Development\n"
                        "Location: 200-220 River Road, Stamford, CT\n"
                        "Zoning Application filed: April 2024\n"
                        "Requested: Rezone from R-1 (residential) to MX-D (mixed-use district)\n"
                        "Zoning Board hearing: June 15, 2024\n"
                        "Outcome: APPROVED with conditions (traffic study required, max height "
                        "reduced from 12 to 10 stories)."
                    ),
                    "session_2_permits": (
                        "PERMITS STATUS (November 2024):\n"
                        "1. Site Plan Approval — APPROVED October 1, 2024\n"
                        "2. Building Permit — APPLICATION SUBMITTED November 15, 2024\n"
                        "3. Environmental Permit (wetlands setback) — PENDING; Army Corps review\n"
                        "4. Traffic Study — COMPLETED; recommends signal at River/Main intersection\n"
                        "5. Stormwater Management Plan — APPROVED"
                    ),
                    "session_3_construction": (
                        "CONSTRUCTION UPDATE (February 2026):\n"
                        "Building Permit issued January 2025.\n"
                        "Environmental Permit issued March 2025 with mitigation conditions.\n"
                        "Foundation complete.\n"
                        "Steel erection: 40% complete.\n"
                        "Outstanding: Certificate of Occupancy (at project completion), "
                        "traffic signal installation approval from DOT."
                    ),
                },
                expected={
                    "completed_approvals": [
                        "Zoning (approved June 2024 with conditions)",
                        "Site Plan (October 2024)",
                        "Building Permit (January 2025)",
                        "Environmental Permit (March 2025)",
                        "Stormwater Plan",
                        "Traffic Study",
                    ],
                    "outstanding_approvals": [
                        "Certificate of Occupancy (at completion)",
                        "DOT traffic signal installation approval",
                    ],
                    "conditions_to_monitor": [
                        "10-story height limit from zoning",
                        "Environmental mitigation conditions",
                    ],
                    "construction_progress": "Foundation complete, 40% steel erection",
                },
                difficulty=3,
                tags=["multi_session_accumulation", "real_estate", "permitting"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "Across sessions, you tracked employment law compliance issues at "
                    "a company. Which issues have been remediated and which remain open?"
                ),
                context={
                    "session_1_audit": (
                        "HR COMPLIANCE AUDIT FINDINGS (June 2024):\n"
                        "Finding 1: 23 employees misclassified as exempt under FLSA.\n"
                        "Finding 2: I-9 forms missing for 8 employees.\n"
                        "Finding 3: No written anti-harassment policy.\n"
                        "Finding 4: Overtime not properly calculated for tipped employees.\n"
                        "Finding 5: ADA interactive process not documented for 3 accommodation "
                        "requests."
                    ),
                    "session_2_remediation": (
                        "REMEDIATION STATUS (October 2024):\n"
                        "Finding 1: Reclassified 23 employees; back pay calculated ($145,000). "
                        "Payments issued September 2024. REMEDIATED.\n"
                        "Finding 2: I-9 audit completed; 5 of 8 forms now corrected. 3 employees "
                        "no longer with company; forms archived with explanatory memo. REMEDIATED.\n"
                        "Finding 3: Anti-harassment policy drafted, pending Board approval.\n"
                        "Finding 4: Payroll vendor updating calculation methodology. Target: "
                        "December 2024.\n"
                        "Finding 5: No action taken yet."
                    ),
                    "session_3_followup": (
                        "FOLLOW-UP (February 2026):\n"
                        "Finding 3: Policy approved by Board November 2024. All employees "
                        "signed acknowledgment by January 2025. REMEDIATED.\n"
                        "Finding 4: Payroll vendor completed update February 2025. Back pay "
                        "for tipped employees calculated at $32,000. Payments issued. REMEDIATED.\n"
                        "Finding 5: HR department purchased ADA compliance training. Interactive "
                        "process documentation template created. However, one new accommodation "
                        "request (December 2025) still lacks documentation."
                    ),
                },
                expected={
                    "remediated": [
                        "Finding 1 (FLSA misclassification, $145K back pay)",
                        "Finding 2 (I-9 forms corrected)",
                        "Finding 3 (anti-harassment policy adopted)",
                        "Finding 4 (overtime calculation fixed, $32K back pay)",
                    ],
                    "open": [
                        "Finding 5 (ADA process — template created but new Dec 2025 request undocumented)",
                    ],
                    "total_back_pay": "$177,000 ($145K + $32K)",
                },
                difficulty=3,
                tags=["multi_session_accumulation", "employment", "compliance"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You helped draft and negotiate a software licensing deal across "
                    "sessions. The counterparty's most recent markup changed a previously "
                    "agreed term. Flag the change."
                ),
                context={
                    "session_1_initial_draft": (
                        "OUR INITIAL DRAFT:\n"
                        "Section 4.1 Warranty: Licensor warrants that the Software will "
                        "perform materially in accordance with the Documentation for 12 months.\n"
                        "Section 6.1 Limitation of Liability: In no event shall either party's "
                        "aggregate liability exceed the fees paid in the prior 12 months."
                    ),
                    "session_2_agreed_terms": (
                        "NEGOTIATED AGREEMENT (confirmed by email October 2024):\n"
                        "Section 4.1: Warranty period agreed at 12 months. Both sides OK.\n"
                        "Section 6.1: Liability cap agreed at 12 months' fees. Both sides OK.\n"
                        "Both provisions marked as 'agreed and closed' in negotiation tracker."
                    ),
                    "session_3_latest_markup": (
                        "COUNTERPARTY MARKUP v4 (January 2026):\n"
                        "Section 4.1 (unchanged): 12-month warranty.\n"
                        "Section 6.1 (CHANGED): 'In no event shall either party's aggregate "
                        "liability exceed the fees paid in the prior 6 months.'\n"
                        "No redline or comment explaining the change."
                    ),
                },
                expected={
                    "flagged_change": "Section 6.1 — liability cap reduced from 12 months' to 6 months' fees",
                    "prior_agreement": "12 months' fees was agreed and closed in October 2024",
                    "concern": "Previously agreed term was changed without flagging — potential negotiation bad faith",
                    "recommendation": "Reject the change and revert to agreed 12-month cap",
                },
                difficulty=4,
                tags=["multi_session_accumulation", "licensing", "markup_tracking"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="multi_session_accumulation",
                tier=EvalTier.LEARNING_DYNAMICS,
                domain=_DOMAIN,
                prompt=(
                    "You tracked a bankruptcy proceeding. Using all session data, "
                    "what is the current priority of claims and estimated recovery "
                    "for each class?"
                ),
                context={
                    "session_1_filing": (
                        "CHAPTER 11 FILING:\n"
                        "Debtor: PeakRetail Inc.\nFiled: July 2024\n"
                        "Total Assets (book value): $45M\nTotal Liabilities: $80M\n"
                        "Secured Debt: $30M (Bank of America — first lien on all assets)\n"
                        "Priority Claims: $5M (employee wages, tax obligations)\n"
                        "Unsecured Claims: $45M"
                    ),
                    "session_2_plan": (
                        "PLAN OF REORGANISATION (proposed January 2025):\n"
                        "Asset liquidation value: $38M (updated appraisal)\n"
                        "Class 1 (Admin Claims): $3M — paid in full at confirmation.\n"
                        "Class 2 (Secured): $30M — paid in full from asset proceeds.\n"
                        "Class 3 (Priority): $5M — paid in full.\n"
                        "Class 4 (Unsecured): Pro rata distribution of remaining proceeds."
                    ),
                    "session_3_update": (
                        "PLAN UPDATE (February 2026):\n"
                        "Final asset sales yielded $42M (better than expected).\n"
                        "Admin claims: $3.5M (increased due to extended case).\n"
                        "Secured claims: $30M paid in full.\n"
                        "Priority claims: $5M paid in full.\n"
                        "Remaining for unsecured: $42M - $3.5M - $30M - $5M = $3.5M."
                    ),
                },
                expected={
                    "class_1_admin": "Paid in full ($3.5M)",
                    "class_2_secured": "Paid in full ($30M)",
                    "class_3_priority": "Paid in full ($5M)",
                    "class_4_unsecured": "$3.5M available for $45M in claims",
                    "unsecured_recovery": "approximately 7.8% ($3.5M / $45M)",
                    "total_distributed": "$42M",
                },
                difficulty=4,
                tags=["multi_session_accumulation", "bankruptcy", "claims_priority"],
            )
        )

        return cases


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _category_from_dimension(dimension_id: str) -> str:
    """Map internal dimension ids to public category names."""
    mapping: dict[str, str] = {
        "contract_supersession": "fact_retention",
        "temporal_reasoning": "temporal_reasoning",
        "cross_doc_consistency": "cross_case_linking",
        "citation_verification": "privilege_boundaries",
        "multi_session_accumulation": "multi_session",
    }
    return mapping.get(dimension_id, dimension_id)


def _generate_contract_review_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* contract-review fact-retention scenarios.

    Convenience helper that instantiates :class:`LegalMemoryBenchmark` and
    filters to the ``fact_retention`` category.

    Args:
        count: Maximum number of cases to return (default 10).

    Returns:
        A list of scenario dicts (see :meth:`LegalMemoryBenchmark.generate_cases`).
    """
    all_cases = LegalMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "fact_retention"][:count]


def _generate_temporal_reasoning_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* temporal-reasoning scenarios."""
    all_cases = LegalMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "temporal_reasoning"][:count]


def _generate_cross_case_linking_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* cross-case-linking scenarios."""
    all_cases = LegalMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "cross_case_linking"][:count]


def _generate_privilege_boundary_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* privilege-boundary / citation-verification scenarios."""
    all_cases = LegalMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "privilege_boundaries"][:count]
