"""Benchmark harness for the Aegis evaluation platform.

Provides a uniform interface for loading benchmark suites, running them
through an :class:`~aegis.eval.engine.Evaluator`, and comparing results
against stored baselines.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from aegis.core.types import EvalCaseV1
from aegis.eval.engine import EvalResult, Evaluator


def _load_core_suite() -> list[EvalCaseV1]:
    from benchmarks.suites.core import CoreBenchmarkSuite

    return CoreBenchmarkSuite().get_cases()


def _load_legal_suite() -> list[EvalCaseV1]:
    from benchmarks.suites.legal import LegalBenchmarkSuite

    return LegalBenchmarkSuite().get_cases()


def _load_finance_suite() -> list[EvalCaseV1]:
    from benchmarks.suites.finance import FinanceBenchmarkSuite

    return FinanceBenchmarkSuite().get_cases()


def _load_memory_suite() -> list[EvalCaseV1]:
    from benchmarks.suites.memory import MemoryBenchmarkSuite

    return MemoryBenchmarkSuite().get_cases()


def _load_legal_memory_suite() -> list[EvalCaseV1]:
    from aegis.eval.benchmarks import LegalMemoryBenchmark

    return LegalMemoryBenchmark().build_suite().cases


def _load_legal_memory_scale_suite() -> list[EvalCaseV1]:
    from aegis.eval.benchmarks import LegalMemoryScaleBenchmark

    return LegalMemoryScaleBenchmark().build_suite().cases


def _load_finance_memory_suite() -> list[EvalCaseV1]:
    from aegis.eval.benchmarks import FinanceMemoryBenchmark

    return FinanceMemoryBenchmark().build_suite().cases


def _load_reward_integrity_suite() -> list[EvalCaseV1]:
    from aegis.eval.benchmarks import RewardIntegrityBenchmark

    return RewardIntegrityBenchmark().build_suite().cases


def _load_retrieval_precision_depth_suite() -> list[EvalCaseV1]:
    from aegis.eval.benchmarks import RetrievalPrecisionDepthBenchmark

    return RetrievalPrecisionDepthBenchmark().build_suite().cases


_BUILTIN_SUITES: dict[str, Callable[[], list[EvalCaseV1]]] = {
    "core": _load_core_suite,
    "legal": _load_legal_suite,
    "finance": _load_finance_suite,
    "memory": _load_memory_suite,
    "legal-memory": _load_legal_memory_suite,
    "legal-memory-scale": _load_legal_memory_scale_suite,
    "finance-memory": _load_finance_memory_suite,
    "reward-integrity": _load_reward_integrity_suite,
    "retrieval-precision-depth": _load_retrieval_precision_depth_suite,
}

_SUITE_ALIASES: dict[str, str] = {
    "legal_memory": "legal-memory",
    "legal_memory_scale": "legal-memory-scale",
    "finance_memory": "finance-memory",
    "reward_integrity": "reward-integrity",
    "retrieval_precision_depth": "retrieval-precision-depth",
}

_LEGACY_SUITES = frozenset({"core", "legal", "finance", "memory"})


class BenchmarkHarness:
    """Orchestrates benchmark suite loading, execution, and baseline comparison."""

    _suite_registry: dict[str, Callable[[], list[EvalCaseV1]]] = {}

    def __init__(self) -> None:
        self._baselines: dict[str, dict[str, float]] = {}

    def load_suite(self, suite_name: str) -> list[EvalCaseV1]:
        """Load a named benchmark suite."""
        canonical_name = _SUITE_ALIASES.get(suite_name, suite_name)

        if canonical_name in _BUILTIN_SUITES:
            loader = _BUILTIN_SUITES[canonical_name]
            try:
                return loader()
            except ModuleNotFoundError as exc:
                if canonical_name in _LEGACY_SUITES:
                    raise KeyError(
                        f"Suite '{suite_name}' is not available in this environment. "
                        "Use one of: legal-memory, finance-memory, reward-integrity."
                    ) from exc
                raise

        if suite_name in self._suite_registry:
            loader = self._suite_registry[suite_name]
            return loader()

        available = self.list_suites()
        raise KeyError(f"Unknown benchmark suite '{suite_name}'. Available: {', '.join(available)}")

    def list_suites(self) -> list[str]:
        """Return all available suite names (built-in + custom)."""
        available: list[str] = []
        for name, loader in sorted(_BUILTIN_SUITES.items()):
            try:
                loader()
            except ModuleNotFoundError:
                continue
            available.append(name)

        custom = sorted(self._suite_registry)
        return sorted(set(available + custom))

    def run(
        self,
        evaluator: Evaluator,
        suite: list[EvalCaseV1],
        agent: Any = None,
    ) -> dict[str, Any]:
        """Run a benchmark suite through the evaluator."""
        result: EvalResult = evaluator.run_with_cases(cases=suite, agent=agent)

        return {
            "suite_size": len(suite),
            "run_id": result.run_id,
            "overall_score": result.overall_score,
            "dimension_scores": result.dimension_scores,
            "result": result.model_dump(),
        }

    def compare_to_baseline(
        self,
        results: dict[str, Any],
        baseline: dict[str, float],
    ) -> dict[str, float]:
        """Compare benchmark results against a stored baseline."""
        current_scores: dict[str, float] = results.get("dimension_scores", {})
        all_dims = set(current_scores) | set(baseline)

        deltas: dict[str, float] = {}
        for dim_id in sorted(all_dims):
            current = current_scores.get(dim_id, 0.0)
            base = baseline.get(dim_id, 0.0)
            deltas[dim_id] = round(current - base, 6)

        return deltas

    def register_suite(self, name: str, loader: Callable[[], list[EvalCaseV1]]) -> None:
        """Register a custom benchmark suite loader."""
        self._suite_registry[name] = loader

    def set_baseline(self, name: str, scores: dict[str, float]) -> None:
        """Store a baseline for future comparisons."""
        self._baselines[name] = dict(scores)

    def get_baseline(self, name: str) -> dict[str, float]:
        """Retrieve a stored baseline by name."""
        if name not in self._baselines:
            raise KeyError(f"No baseline stored with name '{name}'.")
        return dict(self._baselines[name])
