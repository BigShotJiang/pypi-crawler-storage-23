"""Finance memory benchmark — 50 deal lifecycles testing numerical accuracy retention.

Tests agent memory fidelity across numerical verification, cross-document
reconciliation, market data currency, restatement handling, and
multi-quarter analysis using realistic financial language, numbers,
and SEC filing references.

Focus areas:
  - Numerical precision (exact dollar amounts, percentages, ratios)
  - Formula consistency (DCF, leverage ratios, EPS calculations)
  - Temporal data updates (restatements, market price changes)
"""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.eval.benchmarks.runner import BenchmarkConfig, BenchmarkSuite

_SUITE_ID = "aegis-finance-memory-v1"
_DOMAIN = "finance"

# Maps public category names to expected memory operations
_FINANCE_MEMORY_OPS: dict[str, list[str]] = {
    "due_diligence": ["store", "retrieve", "cross_reference", "verify"],
    "model_building": ["store", "retrieve", "compute", "update"],
    "quarterly_reporting": ["store", "retrieve", "temporal_query", "compare"],
    "portfolio_analysis": ["store", "retrieve", "aggregate", "rank"],
}


class FinanceMemoryBenchmark:
    """Builder for the AegisFinance-Memory benchmark suite.

    Generates 50 realistic financial test cases spanning five categories:

    1. Numerical verification / due diligence (10 cases)
    2. Cross-document reconciliation / due diligence (10 cases)
    3. Market data currency / model building (10 cases)
    4. Restatement handling / quarterly reporting (10 cases)
    5. Multi-quarter analysis / portfolio analysis (10 cases)

    Each scenario includes:
      - ``prompt``: the natural-language question for the agent
      - ``expected_output``: ground-truth answer fields
      - ``memory_operations_expected``: which memory ops should fire
      - ``difficulty``: integer 1-5
    """

    def __init__(self) -> None:
        self._config = BenchmarkConfig(
            name="aegis-finance-memory-v1",
            version="1.0.0",
            description=(
                "50 multi-session financial deal lifecycles testing numerical "
                "accuracy, cross-document reconciliation, and temporal data tracking."
            ),
            domain=_DOMAIN,
            num_cases=50,
            difficulty_distribution={1: 5, 2: 10, 3: 15, 4: 12, 5: 8},
            timeout_seconds=300,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_cases(self) -> list[dict[str, Any]]:
        """Generate 50 finance scenarios as plain dictionaries.

        Returns a list of dicts, each containing:
          - ``prompt`` (str): the scenario question
          - ``expected_output`` (dict): ground-truth answer fields
          - ``memory_operations_expected`` (list[str]): expected memory ops
          - ``difficulty`` (int): 1-5 scale
          - ``category`` (str): one of due_diligence, model_building,
            quarterly_reporting, portfolio_analysis
          - ``tags`` (list[str]): descriptive tags
        """
        raw_cases = self._generate_eval_cases()
        return [
            {
                "prompt": c.prompt,
                "expected_output": c.expected,
                "memory_operations_expected": _FINANCE_MEMORY_OPS.get(
                    _finance_category(c.dimension_id),
                    ["store", "retrieve"],
                ),
                "difficulty": c.difficulty,
                "category": _finance_category(c.dimension_id),
                "tags": c.tags,
                "context": c.context,
            }
            for c in raw_cases
        ]

    def build_suite(self) -> BenchmarkSuite:
        """Build and return the complete benchmark suite."""
        cases = self._generate_eval_cases()
        return BenchmarkSuite(self._config, cases)

    # ------------------------------------------------------------------
    # Internal generation
    # ------------------------------------------------------------------

    def _generate_eval_cases(self) -> list[EvalCaseV1]:
        """Generate all 50 test cases as typed ``EvalCaseV1`` instances."""
        cases: list[EvalCaseV1] = []
        cases.extend(self._numerical_verification_cases())
        cases.extend(self._cross_document_reconciliation_cases())
        cases.extend(self._market_data_currency_cases())
        cases.extend(self._restatement_handling_cases())
        cases.extend(self._multi_quarter_analysis_cases())
        return cases

    # Convenience aliases matching the task specification
    _generate_cases = _generate_eval_cases

    # ------------------------------------------------------------------
    # Category 1: Numerical verification (10 cases)
    # ------------------------------------------------------------------

    def _numerical_verification_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Cross-check the revenue figures between the 10-K income statement, "
                    "the earnings press release, and the investor presentation for "
                    "TechVista Corp FY2024."
                ),
                context={
                    "10k_income_statement": (
                        "TECHVISTA CORP — CONSOLIDATED STATEMENTS OF INCOME (10-K)\n"
                        "Fiscal Year Ended December 31, 2024\n"
                        "Net Revenue: $4,287,000,000\n"
                        "Cost of Revenue: $2,572,200,000\n"
                        "Gross Profit: $1,714,800,000\n"
                        "Gross Margin: 40.0%\n"
                        "Operating Income: $856,400,000\n"
                        "Net Income: $643,050,000"
                    ),
                    "press_release": (
                        "TECHVISTA CORP Q4 AND FULL YEAR 2024 EARNINGS\n"
                        "Full Year 2024 Highlights:\n"
                        "- Revenue: $4.29 billion, up 12% YoY\n"
                        "- Gross Margin: 40.1%\n"
                        "- Operating Income: $856 million\n"
                        "- EPS: $3.22 (diluted)"
                    ),
                    "investor_presentation": (
                        "TECHVISTA CORP — INVESTOR DAY 2025 PRESENTATION\n"
                        "Slide 8: FY2024 Financial Summary\n"
                        "Revenue: $4,287M\n"
                        "Gross Margin: 40.0%\n"
                        "Operating Margin: 20.0%\n"
                        "Free Cash Flow: $720M"
                    ),
                },
                expected={
                    "revenue_10k": "$4,287,000,000",
                    "revenue_press_release": "$4.29B (rounded, consistent with $4,287M within rounding)",
                    "revenue_presentation": "$4,287M (matches 10-K exactly)",
                    "gross_margin_discrepancy": "10-K says 40.0%, press release says 40.1% — minor rounding difference",
                    "operating_margin_check": "Presentation says 20.0%, 10-K implies $856.4M/$4,287M = 19.98% — consistent within rounding",
                },
                difficulty=2,
                tags=["numerical_verification", "revenue", "cross_check"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Verify the balance sheet equation and check whether the debt "
                    "schedule reconciles to the balance sheet for Ironclad Industries."
                ),
                context={
                    "balance_sheet": (
                        "IRONCLAD INDUSTRIES — CONSOLIDATED BALANCE SHEET\n"
                        "As of December 31, 2024\n"
                        "Total Assets: $12,450,000,000\n"
                        "Current Liabilities: $2,100,000,000\n"
                        "Long-Term Debt: $4,800,000,000\n"
                        "Other Long-Term Liabilities: $1,200,000,000\n"
                        "Total Liabilities: $8,100,000,000\n"
                        "Stockholders' Equity: $4,350,000,000\n"
                        "Total Liabilities and Equity: $12,450,000,000"
                    ),
                    "debt_schedule": (
                        "NOTE 8 — LONG-TERM DEBT\n"
                        "Term Loan A (due 2027): $1,500,000,000\n"
                        "Term Loan B (due 2029): $2,000,000,000\n"
                        "Senior Notes 4.75% (due 2031): $1,000,000,000\n"
                        "Revolving Credit Facility: $500,000,000 drawn\n"
                        "Total Long-Term Debt: $5,000,000,000\n"
                        "Less: Current Portion: ($200,000,000)\n"
                        "Net Long-Term Debt: $4,800,000,000"
                    ),
                },
                expected={
                    "balance_sheet_balanced": "Yes, A ($12.45B) = L ($8.1B) + E ($4.35B)",
                    "debt_reconciliation": "Net LT Debt $4.8B matches balance sheet LT Debt",
                    "total_debt_note": "$5.0B gross, $200M current portion reduces to $4.8B net LT",
                    "current_liabilities_check": "Current liabilities ($2.1B) should include the $200M current portion of LT debt",
                },
                difficulty=2,
                tags=["numerical_verification", "balance_sheet", "debt_schedule"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "The cash flow statement shows operating cash flow of $1.2B. "
                    "Verify this against the net income and reconciling items."
                ),
                context={
                    "cash_flow_statement": (
                        "CONSOLIDATED STATEMENT OF CASH FLOWS — FY2024\n"
                        "Cash Flows from Operating Activities:\n"
                        "  Net Income: $643,050,000\n"
                        "  Depreciation & Amortization: $320,000,000\n"
                        "  Stock-Based Compensation: $95,000,000\n"
                        "  Deferred Taxes: ($28,000,000)\n"
                        "  Changes in Working Capital: $169,950,000\n"
                        "  Net Cash from Operations: $1,200,000,000"
                    ),
                },
                expected={
                    "sum_check": "$643.05M + $320M + $95M - $28M + $169.95M = $1,200,000,000",
                    "reconciles": "Yes, the items sum to exactly $1.2B",
                    "largest_non_cash": "D&A at $320M is the largest non-cash add-back",
                },
                difficulty=1,
                tags=["numerical_verification", "cash_flow"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A merger proxy states the exchange ratio implies a per-share value. "
                    "Verify the arithmetic."
                ),
                context={
                    "proxy_statement": (
                        "MERGER PROXY STATEMENT (Filed January 2025)\n"
                        "Acquiror: MegaCorp Inc. (current share price: $150.00)\n"
                        "Target: SmallTech Corp.\n"
                        "Exchange Ratio: 0.45 shares of MegaCorp per SmallTech share\n"
                        "Cash Consideration: $8.50 per SmallTech share\n"
                        "Implied Per-Share Value: $76.00 per SmallTech share\n"
                        "SmallTech Shares Outstanding: 50,000,000\n"
                        "Implied Equity Value: $3.8 billion"
                    ),
                },
                expected={
                    "implied_share_value_calc": "0.45 x $150.00 + $8.50 = $67.50 + $8.50 = $76.00",
                    "implied_share_value_correct": "Yes, $76.00 is correct",
                    "implied_equity_value_calc": "$76.00 x 50,000,000 = $3,800,000,000",
                    "implied_equity_value_correct": "Yes, $3.8B is correct",
                },
                difficulty=1,
                tags=["numerical_verification", "merger", "exchange_ratio"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "The segment reporting in the 10-K should sum to the consolidated "
                    "totals. Do the segment revenues reconcile?"
                ),
                context={
                    "segment_reporting": (
                        "NOTE 15 — SEGMENT INFORMATION\n"
                        "Revenue by Segment (FY2024):\n"
                        "  Enterprise Software: $1,850,000,000\n"
                        "  Cloud Services: $1,420,000,000\n"
                        "  Professional Services: $680,000,000\n"
                        "  Hardware: $350,000,000\n"
                        "  Intersegment Eliminations: ($15,000,000)\n"
                        "  Consolidated Revenue: $4,285,000,000"
                    ),
                    "consolidated_income_statement": (
                        "CONSOLIDATED STATEMENTS OF INCOME\nNet Revenue: $4,287,000,000"
                    ),
                },
                expected={
                    "segment_sum": "$1,850M + $1,420M + $680M + $350M - $15M = $4,285,000,000",
                    "consolidated_revenue": "$4,287,000,000",
                    "discrepancy": "$2,000,000 difference between segment sum and consolidated total",
                    "possible_explanations": "Rounding differences, unallocated corporate revenue, or reporting error",
                },
                difficulty=3,
                tags=["numerical_verification", "segment_reporting"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Verify the diluted EPS calculation in the earnings report against "
                    "the reported share counts."
                ),
                context={
                    "earnings_data": (
                        "EARNINGS REPORT — FY2024\n"
                        "Net Income Attributable to Common: $643,050,000\n"
                        "Basic Weighted Average Shares: 198,000,000\n"
                        "Dilutive Effect of Options: 3,500,000\n"
                        "Dilutive Effect of RSUs: 2,500,000\n"
                        "Diluted Weighted Average Shares: 204,000,000\n"
                        "Basic EPS: $3.25\n"
                        "Diluted EPS: $3.22"
                    ),
                },
                expected={
                    "basic_eps_check": "$643.05M / 198M = $3.2477 rounds to $3.25 — correct",
                    "diluted_shares_check": "198M + 3.5M + 2.5M = 204M — correct",
                    "diluted_eps_check": "$643.05M / 204M = $3.1522 rounds to $3.15, NOT $3.22",
                    "discrepancy": "Reported diluted EPS of $3.22 does not match calculation ($3.15)",
                },
                difficulty=3,
                tags=["numerical_verification", "eps", "dilution"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "A DCF valuation model assumes certain growth rates and discount "
                    "rate. Verify the terminal value calculation."
                ),
                context={
                    "dcf_model": (
                        "DCF VALUATION — STELLAR DYNAMICS INC.\n"
                        "Year 5 Free Cash Flow (projected): $500,000,000\n"
                        "Terminal Growth Rate: 2.5%\n"
                        "Weighted Average Cost of Capital (WACC): 9.0%\n"
                        "Terminal Value (Gordon Growth): $7,692,307,692\n"
                        "PV of Terminal Value (discounted 5 years at WACC): $5,000,000,000\n"
                        "Sum of PV of FCFs (Years 1-5): $1,600,000,000\n"
                        "Enterprise Value: $6,600,000,000"
                    ),
                },
                expected={
                    "gordon_growth_calc": "FCF5 * (1+g) / (WACC - g) = $500M * 1.025 / (0.09 - 0.025) = $512.5M / 0.065 = $7,884,615,385",
                    "reported_terminal_value": "$7,692,307,692",
                    "terminal_value_discrepancy": "Model likely used $500M / 0.065 = $7,692M (forgot to grow FCF by g)",
                    "pv_check": "$7,692M / (1.09)^5 = $7,692M / 1.5386 = $5,000M — consistent with reported PV",
                    "ev_check": "$5,000M + $1,600M = $6,600M — correct",
                },
                difficulty=4,
                tags=["numerical_verification", "dcf", "terminal_value"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "Verify the leverage ratios reported in the credit agreement "
                    "compliance certificate."
                ),
                context={
                    "compliance_certificate": (
                        "COMPLIANCE CERTIFICATE — Q4 2024\n"
                        "Borrower: Atlas Manufacturing Inc.\n\n"
                        "Financial Covenants:\n"
                        "1. Total Leverage Ratio (Total Debt / LTM EBITDA): 3.2x\n"
                        "   Covenant Maximum: 4.0x — IN COMPLIANCE\n"
                        "2. Interest Coverage Ratio (LTM EBITDA / Interest Expense): 5.5x\n"
                        "   Covenant Minimum: 3.0x — IN COMPLIANCE\n"
                        "3. Fixed Charge Coverage Ratio: 1.8x\n"
                        "   Covenant Minimum: 1.25x — IN COMPLIANCE"
                    ),
                    "underlying_financials": (
                        "Atlas Manufacturing — LTM Ended December 31, 2024:\n"
                        "Total Debt: $480,000,000\n"
                        "LTM EBITDA: $140,000,000\n"
                        "LTM Interest Expense: $28,000,000\n"
                        "LTM Fixed Charges (interest + scheduled principal + capex): $85,000,000"
                    ),
                },
                expected={
                    "leverage_calc": "$480M / $140M = 3.43x, NOT 3.2x as reported",
                    "leverage_discrepancy": "Reported 3.2x but actual is 3.43x — still in compliance but material error",
                    "interest_coverage_calc": "$140M / $28M = 5.0x, NOT 5.5x as reported",
                    "interest_coverage_discrepancy": "Reported 5.5x but actual is 5.0x — still in compliance",
                    "fccr_calc": "$140M / $85M = 1.65x, NOT 1.8x as reported",
                    "fccr_discrepancy": "Reported 1.8x but actual is 1.65x — still in compliance",
                    "overall": "All ratios overstated; may indicate EBITDA add-backs or definitional differences",
                },
                difficulty=3,
                tags=["numerical_verification", "covenants", "leverage"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.MEMORY_FIDELITY,
                domain=_DOMAIN,
                prompt=(
                    "The acquisition goodwill calculation in the purchase price "
                    "allocation should balance. Verify it."
                ),
                context={
                    "ppa": (
                        "PURCHASE PRICE ALLOCATION — ACQUISITION OF BRIGHTPATH INC.\n"
                        "Total Consideration: $2,800,000,000\n\n"
                        "Fair Value of Identifiable Assets Acquired:\n"
                        "  Cash and Equivalents: $180,000,000\n"
                        "  Accounts Receivable: $220,000,000\n"
                        "  Property and Equipment: $350,000,000\n"
                        "  Intangible Assets (customer relationships): $450,000,000\n"
                        "  Intangible Assets (developed technology): $380,000,000\n"
                        "  Other Assets: $120,000,000\n"
                        "  Total Identifiable Assets: $1,700,000,000\n\n"
                        "Fair Value of Liabilities Assumed:\n"
                        "  Accounts Payable: $95,000,000\n"
                        "  Deferred Revenue: $155,000,000\n"
                        "  Long-Term Debt: $300,000,000\n"
                        "  Deferred Tax Liabilities: $110,000,000\n"
                        "  Total Liabilities Assumed: $660,000,000\n\n"
                        "Net Identifiable Assets: $1,040,000,000\n"
                        "Goodwill: $1,660,000,000"
                    ),
                },
                expected={
                    "assets_sum": "$180M + $220M + $350M + $450M + $380M + $120M = $1,700M — correct",
                    "liabilities_sum": "$95M + $155M + $300M + $110M = $660M — correct",
                    "net_identifiable_assets": "$1,700M - $660M = $1,040M — correct",
                    "goodwill_calc": "$2,800M - $1,040M = $1,760M",
                    "goodwill_discrepancy": "Reported goodwill $1,660M but should be $1,760M — $100M difference",
                },
                difficulty=3,
                tags=["numerical_verification", "ppa", "goodwill"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="numerical_verification",
                tier=EvalTier.REASONING_QUALITY,
                domain=_DOMAIN,
                prompt=(
                    "An XBRL filing tags operating expenses at $2.85B. The 10-K text "
                    "shows individual line items. Do they match?"
                ),
                context={
                    "xbrl_tag": (
                        "XBRL Instance Document:\n"
                        "us-gaap:OperatingExpenses: $2,850,000,000\n"
                        "Period: FY2024"
                    ),
                    "10k_line_items": (
                        "10-K Income Statement — Operating Expenses:\n"
                        "  Research and Development: $680,000,000\n"
                        "  Sales and Marketing: $1,050,000,000\n"
                        "  General and Administrative: $420,000,000\n"
                        "  Depreciation and Amortization: $320,000,000\n"
                        "  Restructuring Charges: $95,000,000\n"
                        "  Total Operating Expenses: $2,565,000,000"
                    ),
                    "cogs_line": (
                        "Note: The 10-K separately reports Cost of Revenue of $2,572,200,000 "
                        "above the operating expense line items."
                    ),
                },
                expected={
                    "line_items_sum": "$680M + $1,050M + $420M + $320M + $95M = $2,565M",
                    "xbrl_value": "$2,850M",
                    "discrepancy": "$285M difference between XBRL tag and 10-K line items",
                    "likely_cause": "XBRL tag may include COGS or use a different operating expense definition",
                    "10k_total_matches_line_items": "Yes, $2,565M total matches the sum of individual items",
                },
                difficulty=4,
                tags=["numerical_verification", "xbrl", "operating_expenses"],
            )
        )

        return cases

    # ------------------------------------------------------------------
    # Category 2: Cross-document reconciliation (10 cases)
    # ------------------------------------------------------------------

    def _cross_document_reconciliation_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_reconciliation",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "The 10-K risk factors mention regulatory approval pending. "
                    "The 10-Q filed 3 months later does not mention it. What happened?"
                ),
                context={
                    "10k_risk_factors": (
                        "10-K (Filed March 2024) — Risk Factors:\n"
                        "'We are awaiting FDA approval for our lead product candidate, "
                        "AX-205. Failure to receive approval by Q3 2024 could result in "
                        "significant revenue shortfalls and potential impairment of $200M "
                        "in capitalised development costs.'"
                    ),
                    "10q_risk_factors": (
                        "10-Q (Filed August 2024) — Risk Factors:\n"
                        "No mention of AX-205 or FDA approval in risk factors section.\n"
                        "New risk factor added: 'We face increased competition in the "
                        "therapeutic area from generic alternatives.'"
                    ),
                    "8k_filing": (
                        "8-K (Filed June 15, 2024):\n"
                        "'The Company received FDA approval for AX-205 on June 12, 2024. "
                        "Commercial launch expected Q4 2024.'"
                    ),
                },
                expected={
                    "explanation": "FDA approval received June 12, 2024 (per 8-K), so risk factor was removed in 10-Q",
                    "risk_resolved": "AX-205 approval obtained before Q3 2024 deadline",
                    "new_risk_context": "Generic competition may affect AX-205 market opportunity",
                    "impairment_risk": "Resolved — $200M development costs no longer at risk of impairment",
                },
                difficulty=3,
                tags=["cross_doc_reconciliation", "risk_factors", "fda"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_reconciliation",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "The company's proxy statement reports executive compensation "
                    "differently than the 10-K notes. Reconcile the figures."
                ),
                context={
                    "proxy_compensation": (
                        "DEF 14A PROXY STATEMENT — Executive Compensation\n"
                        "CEO Compensation (FY2024):\n"
                        "  Base Salary: $1,200,000\n"
                        "  Annual Bonus: $1,800,000\n"
                        "  Stock Awards (grant date fair value): $5,500,000\n"
                        "  Option Awards: $2,000,000\n"
                        "  All Other Compensation: $150,000\n"
                        "  Total: $10,650,000"
                    ),
                    "10k_note": (
                        "NOTE 12 — STOCK-BASED COMPENSATION\n"
                        "Total stock-based compensation expense recognised in FY2024: "
                        "$95,000,000.\n"
                        "CEO stock-based compensation expense recognised: $3,200,000 "
                        "(reflects vesting of prior-year and current-year grants).\n"
                        "CEO total compensation expense per ASC 718: $6,350,000."
                    ),
                },
                expected={
                    "proxy_total": "$10,650,000 (SEC disclosure rules — grant date fair value)",
                    "10k_expense": "$6,350,000 (ASC 718 — expense recognised in period)",
                    "difference_explanation": "Proxy uses grant date fair value; 10-K uses expense recognised over vesting period",
                    "stock_comp_reconciliation": "Proxy stock awards $5.5M + options $2M = $7.5M at grant; 10-K recognises $3.2M expense in period",
                },
                difficulty=4,
                tags=["cross_doc_reconciliation", "compensation", "proxy"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_reconciliation",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "The offering memorandum for a bond issuance projects certain "
                    "coverage ratios. Do these match the historical ratios in the audited "
                    "financials?"
                ),
                context={
                    "offering_memo": (
                        "OFFERING MEMORANDUM — $500M Senior Unsecured Notes\n"
                        "Issuer: Meridian Industrial Holdings\n"
                        "Pro Forma Interest Coverage (LTM EBITDA / Pro Forma Interest): 4.8x\n"
                        "LTM EBITDA (as reported): $420,000,000\n"
                        "Pro Forma Interest Expense (including new notes at 5.5%): $87,500,000"
                    ),
                    "audited_financials": (
                        "AUDITED FINANCIAL STATEMENTS — FY2024\n"
                        "EBITDA Reconciliation:\n"
                        "  Operating Income: $280,000,000\n"
                        "  Add: D&A: $120,000,000\n"
                        "  Add: Non-recurring restructuring: $15,000,000\n"
                        "  Adjusted EBITDA: $415,000,000\n\n"
                        "Interest Expense (existing debt): $60,000,000"
                    ),
                },
                expected={
                    "ebitda_discrepancy": "Offering memo uses $420M; audited adjusted EBITDA is $415M — $5M difference",
                    "new_interest": "$500M x 5.5% = $27.5M annual interest on new notes",
                    "pro_forma_interest_check": "$60M existing + $27.5M new = $87.5M — matches offering memo",
                    "coverage_with_memo_ebitda": "$420M / $87.5M = 4.8x — matches offering memo",
                    "coverage_with_audited_ebitda": "$415M / $87.5M = 4.74x — slightly lower than stated",
                },
                difficulty=4,
                tags=["cross_doc_reconciliation", "debt_issuance", "coverage_ratios"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_reconciliation",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "The company's sustainability report and 10-K provide different "
                    "headcount numbers. Reconcile."
                ),
                context={
                    "sustainability_report": (
                        "2024 SUSTAINABILITY REPORT\n"
                        "'As of December 31, 2024, we employed approximately 28,500 "
                        "full-time employees globally. Our workforce is 45% female.'"
                    ),
                    "10k_filing": (
                        "10-K ANNUAL REPORT — Human Capital\n"
                        "'As of December 31, 2024, we had approximately 31,200 employees, "
                        "including 28,500 full-time employees and 2,700 part-time and "
                        "contract workers. Approximately 42% of our full-time employees "
                        "are female.'"
                    ),
                },
                expected={
                    "reconciliation": "Both report 28,500 full-time employees — consistent",
                    "total_workforce": "10-K includes 2,700 part-time/contract for 31,200 total; sustainability report covers FTE only",
                    "gender_discrepancy": "Sustainability says 45% female; 10-K says 42% female FTE — 3% gap",
                    "possible_explanation": "Sustainability report may include part-time/contract in gender calculation",
                },
                difficulty=2,
                tags=["cross_doc_reconciliation", "headcount", "esg"],
            )
        )

        cases.append(
            EvalCaseV1(
                suite_id=_SUITE_ID,
                dimension_id="cross_doc_reconciliation",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                domain=_DOMAIN,
                prompt=(
                    "A private placement memorandum cites customer retention rates. "
                    "The management presentation uses different figures. Which is correct?"
                ),
                context={
                    "ppm": (
                        "PRIVATE PLACEMENT MEMORANDUM (January 2025)\n"
                        "Key Metrics:\n"
                        "Net Revenue Retention Rate (NRR): 125%\n"
                        "Gross Revenue Retention Rate (GRR): 92%\n"
                        "Customer Count: 2,400 enterprise customers\n"
                        "Average Contract Value (ACV): $180,000"
                    ),
                    "management_presentation": (
                        "MANAGEMENT PRESENTATION (January 2025)\n"
                        "Slide 12: Customer Metrics\n"
                        "NRR: 118% (cohort-based, excluding top 5 customers)\n"
                        "GRR: 92%\n"
                        "Customer Count: 2,400 (including 150 in trial phase)\n"
                        "ACV: $180,000 (paying customers only)"
                    ),
                },
                expected={
                    "nrr_discrepancy": "PPM says 125%, management says 118% — PPM likely includes expansion from top 5 customers",
                    "grr_consistent": "Both report 92%",
                    "customer_count_nuance": "Both say 2,400 but management clarifies 150 are in trial (not paying)",
                    "acv_nuance": "Management clarifies ACV is for paying customers only (2,250), which could inflate the metric",
                    "investor_risk": "PPM metrics may be presented more favorably than management view",
                },
                difficulty=4,
                tags=["cross_doc_reconciliation", "saas_metrics", "retention"],
            )
        )

        # Cases 6-10 for cross-doc reconciliation
        for scenario in [
            {
                "prompt": "Reconcile the tax provision in the 10-K with the effective tax rate discussed in the earnings call transcript.",
                "context": {
                    "10k_tax_note": (
                        "NOTE 10 — INCOME TAXES\n"
                        "Income Before Taxes: $850,000,000\n"
                        "Income Tax Provision: $178,500,000\n"
                        "Effective Tax Rate: 21.0%\n"
                        "Rate Reconciliation:\n"
                        "  Statutory Rate (21%): $178,500,000\n"
                        "  State Taxes: $17,000,000\n"
                        "  R&D Credits: ($25,000,000)\n"
                        "  Foreign Rate Differential: ($12,000,000)\n"
                        "  Other: $2,000,000\n"
                        "  Effective Rate: 18.9%"
                    ),
                    "earnings_call": (
                        "CFO on Earnings Call:\n"
                        "'Our effective tax rate for the year was 21%, in line with the "
                        "statutory federal rate. We expect a similar rate next year.'"
                    ),
                },
                "expected": {
                    "provision_calc": "$178.5M / $850M = 21.0% as reported",
                    "rate_reconciliation": "Shows actual effective rate is 18.9% after adjustments",
                    "discrepancy": "10-K provision line says 21%, but rate reconciliation shows 18.9%",
                    "earnings_call_issue": "CFO stated 21% which matches provision line but not the rate reconciliation",
                    "likely_error": "Provision should be $160.65M at 18.9%, or rate reconciliation items are not reflected in provision",
                },
                "difficulty": 5,
                "tags": ["cross_doc_reconciliation", "tax", "effective_rate"],
            },
            {
                "prompt": "The 8-K and the 10-Q report different dates for a material event. Which filing is authoritative?",
                "context": {
                    "8k_filing": (
                        "8-K (Filed March 18, 2025)\n"
                        "Item 1.01 Entry into a Material Definitive Agreement\n"
                        "On March 15, 2025, the Company entered into a definitive agreement "
                        "to acquire CloudServe Inc. for $1.2 billion in cash."
                    ),
                    "10q_filing": (
                        "10-Q (Filed May 12, 2025)\n"
                        "Subsequent Events Note:\n"
                        "'On March 17, 2025, the Company entered into a definitive agreement "
                        "to acquire CloudServe Inc. for $1.2 billion in cash.'"
                    ),
                },
                "expected": {
                    "date_discrepancy": "8-K says March 15, 10-Q says March 17 — 2-day difference",
                    "authoritative_source": "8-K is more authoritative — filed contemporaneously within 4 business days",
                    "likely_explanation": "10-Q may have used signing date vs execution date, or typographical error",
                    "recommendation": "Use March 15 (8-K date) as the definitive date",
                },
                "difficulty": 2,
                "tags": ["cross_doc_reconciliation", "event_date", "sec_filings"],
            },
            {
                "prompt": "The investor presentation shows adjusted metrics. Reconcile to GAAP figures in the 10-K.",
                "context": {
                    "investor_deck": (
                        "INVESTOR PRESENTATION — FY2024\n"
                        "Adjusted EBITDA: $520M\n"
                        "Adjusted Net Income: $310M\n"
                        "Adjusted EPS: $1.55"
                    ),
                    "10k_gaap": (
                        "10-K — GAAP Results FY2024\n"
                        "Operating Income: $320M\n"
                        "D&A: $120M\n"
                        "Stock-Based Compensation: $45M\n"
                        "Restructuring: $28M\n"
                        "Litigation Settlement: $15M\n"
                        "Net Income: $215M\n"
                        "GAAP EPS: $1.08"
                    ),
                },
                "expected": {
                    "ebitda_bridge": "Operating Income $320M + D&A $120M = $440M EBITDA; add-backs of $45M SBC + $28M restructuring + $15M litigation = $528M adjusted EBITDA",
                    "ebitda_discrepancy": "Calculated $528M vs reported $520M — $8M gap",
                    "net_income_bridge": "GAAP NI $215M + SBC $45M + restructuring $28M + litigation $15M = $303M adjusted (pre-tax); $310M reported",
                    "eps_bridge": "$310M / 200M diluted shares = $1.55 — implies 200M diluted share count",
                },
                "difficulty": 3,
                "tags": ["cross_doc_reconciliation", "adjusted_metrics", "non_gaap"],
            },
            {
                "prompt": "Compare the going concern language in the auditor's report with management's discussion in the 10-K.",
                "context": {
                    "auditor_report": (
                        "INDEPENDENT AUDITOR'S REPORT\n"
                        "The accompanying financial statements have been prepared assuming "
                        "the Company will continue as a going concern. As discussed in "
                        "Note 2, the Company has incurred recurring losses, has negative "
                        "working capital of $45M, and its credit facility matures in 6 months. "
                        "These conditions raise substantial doubt about the Company's ability "
                        "to continue as a going concern."
                    ),
                    "md_and_a": (
                        "MD&A — LIQUIDITY AND CAPITAL RESOURCES\n"
                        "'We believe our existing cash and cash equivalents of $30M, together "
                        "with anticipated cash flows from operations, will be sufficient to "
                        "meet our working capital needs for the next twelve months. We are "
                        "in active discussions to refinance our credit facility.'"
                    ),
                },
                "expected": {
                    "auditor_concern": "Substantial doubt raised — negative working capital $45M, credit facility maturing in 6 months",
                    "management_view": "Believes liquidity sufficient for 12 months, refinancing discussions ongoing",
                    "inconsistency": "Auditor raises going concern doubt while management asserts sufficiency",
                    "key_risk": "Credit facility refinancing is critical — if unsuccessful, going concern doubt is justified",
                    "investor_note": "Auditor opinion is the more conservative and independent assessment",
                },
                "difficulty": 4,
                "tags": ["cross_doc_reconciliation", "going_concern", "audit"],
            },
            {
                "prompt": "The board minutes authorise a share repurchase programme. Do the Treasury stock changes in the balance sheet match?",
                "context": {
                    "board_minutes": (
                        "BOARD RESOLUTION (March 2024)\n"
                        "RESOLVED: The Company is authorised to repurchase up to $200M "
                        "of common stock over the next 12 months. 500,000 shares "
                        "repurchased in Q1 at an average of $80/share ($40M spent).\n"
                        "STATUS UPDATE (December 2024): Total repurchased YTD: "
                        "2,000,000 shares for $180M ($90/share average)."
                    ),
                    "balance_sheet": (
                        "BALANCE SHEET — Treasury Stock\n"
                        "December 31, 2023: (1,500,000 shares, $105M)\n"
                        "December 31, 2024: (3,200,000 shares, $270M)\n"
                        "Change: 1,700,000 shares, $165M"
                    ),
                },
                "expected": {
                    "board_repurchases": "2,000,000 shares for $180M",
                    "balance_sheet_change": "1,700,000 shares for $165M",
                    "shares_discrepancy": "300,000 share difference (2M authorised vs 1.7M on BS)",
                    "dollar_discrepancy": "$15M difference ($180M vs $165M)",
                    "possible_explanations": "Option exercises, RSU settlements, or re-issuances may offset repurchases",
                },
                "difficulty": 4,
                "tags": ["cross_doc_reconciliation", "buyback", "treasury_stock"],
            },
        ]:
            cases.append(
                EvalCaseV1(
                    suite_id=_SUITE_ID,
                    dimension_id="cross_doc_reconciliation",
                    tier=EvalTier.CONTEXT_INTELLIGENCE,
                    domain=_DOMAIN,
                    prompt=scenario["prompt"],
                    context=scenario["context"],
                    expected=scenario["expected"],
                    difficulty=scenario["difficulty"],
                    tags=scenario["tags"],
                )
            )

        return cases

    # ------------------------------------------------------------------
    # Category 3: Market data currency (10 cases)
    # ------------------------------------------------------------------

    def _market_data_currency_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        scenarios = [
            {
                "prompt": "The analyst report uses a share price from 30 days ago. How does this affect the valuation multiples?",
                "context": {
                    "analyst_report": (
                        "EQUITY RESEARCH REPORT (dated February 1, 2025)\n"
                        "Company: NovaTech Solutions\n"
                        "Share Price Used: $42.50 (as of January 2, 2025)\n"
                        "Shares Outstanding: 100M\n"
                        "Market Cap: $4,250M\n"
                        "Net Debt: $800M\n"
                        "Enterprise Value: $5,050M\n"
                        "LTM EBITDA: $500M\n"
                        "EV/EBITDA: 10.1x\n"
                        "P/E (LTM): 18.5x"
                    ),
                    "current_market_data": (
                        "CURRENT MARKET DATA (February 1, 2025)\n"
                        "NovaTech share price: $48.20 (up 13.4% since Jan 2)\n"
                        "Volume: above average since Q4 earnings beat"
                    ),
                },
                "expected": {
                    "stale_price": "$42.50 is 30 days old; current is $48.20",
                    "current_market_cap": "$48.20 x 100M = $4,820M (vs reported $4,250M)",
                    "current_ev": "$4,820M + $800M = $5,620M",
                    "current_ev_ebitda": "$5,620M / $500M = 11.24x (vs reported 10.1x)",
                    "impact": "All valuation multiples are understated by approximately 11%",
                },
                "difficulty": 2,
                "tags": ["market_data_currency", "stale_price", "valuation"],
            },
            {
                "prompt": "A risk model uses last quarter's volatility estimate. How might current market conditions change the assessment?",
                "context": {
                    "risk_report": (
                        "RISK ASSESSMENT (using Q3 2024 data)\n"
                        "Portfolio VaR (95%, 1-day): $2.5M\n"
                        "Portfolio Beta: 1.15\n"
                        "Implied Volatility (S&P 500): 14%\n"
                        "Assumed Correlation: 0.72"
                    ),
                    "current_conditions": (
                        "CURRENT MARKET DATA (February 2025)\n"
                        "VIX: 28 (doubled from Q3 2024 levels)\n"
                        "Recent 30-day realised volatility: 22%\n"
                        "Market in correction territory (down 10% from highs)"
                    ),
                },
                "expected": {
                    "volatility_outdated": "Q3 implied vol 14% vs current VIX 28 — doubled",
                    "var_impact": "VaR likely understated; rough estimate $2.5M x (28/14) = $5M under current conditions",
                    "beta_consideration": "Beta may have increased in risk-off environment",
                    "recommendation": "Re-run risk model with current volatility inputs",
                },
                "difficulty": 3,
                "tags": ["market_data_currency", "risk", "volatility"],
            },
            {
                "prompt": "A credit analysis uses interest rates from 6 months ago. How does this affect the company's debt service analysis?",
                "context": {
                    "credit_analysis": (
                        "CREDIT ANALYSIS (dated August 2024)\n"
                        "Borrower: Pacific Enterprises\n"
                        "Variable Rate Debt: $300M at SOFR + 2.50%\n"
                        "SOFR Used: 5.30% (August 2024)\n"
                        "All-in Rate: 7.80%\n"
                        "Annual Interest Cost (variable): $23,400,000\n"
                        "Fixed Rate Debt: $500M at 4.50%\n"
                        "Total Interest Expense: $45,900,000"
                    ),
                    "current_rates": (
                        "CURRENT RATE ENVIRONMENT (February 2025)\n"
                        "SOFR: 4.50% (80bps lower due to Fed rate cuts)\n"
                        "Credit spreads: widened 25bps for BBB-rated issuers"
                    ),
                },
                "expected": {
                    "current_variable_rate": "SOFR 4.50% + 2.50% + potential spread widening = 7.25% (vs 7.80%)",
                    "current_variable_interest": "$300M x 7.25% = $21,750,000 (down from $23.4M)",
                    "annual_savings": "approximately $1.65M in annual interest on variable debt",
                    "fixed_rate_unchanged": "$500M at 4.50% = $22,500,000 (unchanged)",
                    "updated_total_interest": "$21.75M + $22.5M = $44.25M (vs $45.9M in August analysis)",
                },
                "difficulty": 3,
                "tags": ["market_data_currency", "interest_rates", "debt_service"],
            },
            {
                "prompt": "A real estate appraisal uses cap rates from 12 months ago. How would current cap rates affect the property valuation?",
                "context": {
                    "appraisal": (
                        "PROPERTY APPRAISAL (dated February 2024)\n"
                        "Property: 500 Commerce Blvd, Dallas, TX (Class A Office)\n"
                        "Net Operating Income (NOI): $8,000,000\n"
                        "Cap Rate Applied: 5.50%\n"
                        "Indicated Value (Income Approach): $145,454,545\n"
                        "Rounded: $145,500,000"
                    ),
                    "current_market": (
                        "CURRENT OFFICE MARKET DATA (February 2025)\n"
                        "Dallas Class A Office Cap Rates: 7.00% - 7.50%\n"
                        "Vacancy rates have increased from 15% to 22%\n"
                        "Comparable sales indicate cap rate expansion of 150-200bps"
                    ),
                },
                "expected": {
                    "original_value": "$145.5M at 5.50% cap rate",
                    "current_cap_rate_range": "7.00% - 7.50%",
                    "revised_value_low": "$8M / 7.50% = $106.7M",
                    "revised_value_high": "$8M / 7.00% = $114.3M",
                    "value_decline": "22-27% decline ($31M - $39M) using current cap rates",
                    "additional_risk": "Rising vacancy may also reduce NOI below $8M",
                },
                "difficulty": 3,
                "tags": ["market_data_currency", "real_estate", "cap_rates"],
            },
            {
                "prompt": "FX rates used in the Q3 financial consolidation may have shifted materially by Q4 close. Assess the impact.",
                "context": {
                    "q3_fx": (
                        "Q3 2024 CONSOLIDATION — FX RATES USED\n"
                        "EUR/USD: 1.10 (period-end)\n"
                        "GBP/USD: 1.30\n"
                        "JPY/USD: 0.0067 (149 JPY/USD)\n"
                        "European Revenue (EUR): EUR 800M = $880M\n"
                        "UK Revenue (GBP): GBP 200M = $260M\n"
                        "Japan Revenue (JPY): JPY 30B = $201M"
                    ),
                    "q4_fx": (
                        "Q4 2024 PERIOD-END FX RATES\n"
                        "EUR/USD: 1.04 (5.5% USD strengthening)\n"
                        "GBP/USD: 1.24 (4.6% USD strengthening)\n"
                        "JPY/USD: 0.0063 (159 JPY/USD, 6.3% USD strengthening)"
                    ),
                },
                "expected": {
                    "eur_impact": "EUR 800M x 1.04 = $832M (was $880M) — $48M negative translation",
                    "gbp_impact": "GBP 200M x 1.24 = $248M (was $260M) — $12M negative translation",
                    "jpy_impact": "JPY 30B x 0.0063 = $189M (was $201M) — $12M negative translation",
                    "total_fx_headwind": "approximately $72M negative revenue translation impact",
                    "note": "These are translation effects only; transactional hedges may partially offset",
                },
                "difficulty": 4,
                "tags": ["market_data_currency", "fx_rates", "consolidation"],
            },
            {
                "prompt": "A portfolio manager's report uses commodity prices from last month. Update the commodity exposure calculation.",
                "context": {
                    "portfolio_report": (
                        "COMMODITY EXPOSURE REPORT (January 2025)\n"
                        "Oil (WTI) Price Used: $72/barrel\n"
                        "Company A (oil producer): Revenue sensitivity $50M per $10/bbl change\n"
                        "Gold Price Used: $2,050/oz\n"
                        "Company B (gold miner): Revenue sensitivity $30M per $100/oz change\n"
                        "Copper Price Used: $3.80/lb\n"
                        "Company C: Revenue sensitivity $20M per $0.50/lb change"
                    ),
                    "current_prices": (
                        "CURRENT COMMODITY PRICES (February 20, 2025)\n"
                        "WTI Crude: $78/barrel\n"
                        "Gold: $2,250/oz\n"
                        "Copper: $4.15/lb"
                    ),
                },
                "expected": {
                    "oil_change": "$78 - $72 = $6/bbl increase; Company A revenue impact: +$30M",
                    "gold_change": "$2,250 - $2,050 = $200/oz increase; Company B revenue impact: +$60M",
                    "copper_change": "$4.15 - $3.80 = $0.35/lb increase; Company C revenue impact: +$14M",
                    "total_portfolio_impact": "+$104M across three commodity exposures",
                    "note": "Sensitivities are linear approximations; actual impact may differ",
                },
                "difficulty": 2,
                "tags": ["market_data_currency", "commodities", "sensitivity"],
            },
            {
                "prompt": "An IPO prospectus was filed with financial data that is now 4 months old. What should investors note?",
                "context": {
                    "s1_filing": (
                        "S-1 REGISTRATION STATEMENT (Filed October 2024)\n"
                        "Financial Data Through: June 30, 2024 (Q2)\n"
                        "H1 2024 Revenue: $180M (up 35% YoY)\n"
                        "H1 2024 Net Loss: ($25M)\n"
                        "Cash and Equivalents: $150M\n"
                        "Monthly Cash Burn: $8M\n"
                        "IPO Expected: February 2025"
                    ),
                    "market_context": (
                        "MARKET CONTEXT (February 2025)\n"
                        "IPO window expected to open mid-February.\n"
                        "Comparable SaaS companies trading at 8-10x NTM revenue.\n"
                        "Note: Company has not filed an S-1/A with updated financials."
                    ),
                },
                "expected": {
                    "data_staleness": "Financial data is 8 months old (Q2 ended June 30, 2024)",
                    "cash_position_risk": "If $8M/month burn continued, cash may be $150M - (8 x $8M) = $86M by Feb 2025",
                    "missing_data": "Q3 and Q4 2024 results not reflected; growth trend unknown",
                    "s1a_needed": "Company should file S-1/A amendment with Q3 (and ideally Q4) financials before pricing",
                    "investor_caution": "Valuation based on stale data; request updated financials",
                },
                "difficulty": 3,
                "tags": ["market_data_currency", "ipo", "stale_financials"],
            },
            {
                "prompt": "A loan underwriting model uses a credit score from the application date. The borrower's credit profile has changed.",
                "context": {
                    "original_underwriting": (
                        "LOAN UNDERWRITING PACKAGE (Application: September 2024)\n"
                        "Borrower: Pinnacle Holdings LLC\n"
                        "FICO Score (guarantor): 780\n"
                        "Debt-Service Coverage Ratio: 1.45x\n"
                        "Loan-to-Value: 65%\n"
                        "Loan Amount: $5,000,000\n"
                        "Approved at Risk Rating: 3 (Satisfactory)"
                    ),
                    "updated_information": (
                        "UPDATED CREDIT INFORMATION (February 2025)\n"
                        "Guarantor FICO: 680 (dropped due to personal credit card defaults)\n"
                        "Borrower's primary tenant (40% of revenue) filed bankruptcy January 2025\n"
                        "Updated NOI projection: $600K (was $725K)\n"
                        "Property appraised value unchanged"
                    ),
                },
                "expected": {
                    "fico_change": "780 to 680 — 100-point decline, crosses key threshold",
                    "dscr_impact": "Updated NOI $600K / annual debt service ($345K estimated) = 1.74x; but if tenant revenue lost, could drop below 1.0x",
                    "tenant_risk": "40% revenue concentration with bankrupt tenant is material",
                    "risk_rating_change": "Should be downgraded from 3 (Satisfactory) to at least 5 (Watch) or 6 (Substandard)",
                    "recommendation": "Re-underwrite with current data; consider additional collateral or guaranty requirements",
                },
                "difficulty": 4,
                "tags": ["market_data_currency", "credit", "underwriting"],
            },
            {
                "prompt": "A benchmarking analysis compares performance to an index. The index composition changed since the analysis was prepared.",
                "context": {
                    "benchmark_analysis": (
                        "PORTFOLIO BENCHMARK ANALYSIS (dated November 2024)\n"
                        "Benchmark: Custom SaaS Index (15 companies)\n"
                        "Portfolio Return: +22%\n"
                        "Benchmark Return: +18%\n"
                        "Alpha: +4%\n"
                        "Top contributor to benchmark: CloudFirst Inc. (12% weight, +45% return)"
                    ),
                    "index_change": (
                        "INDEX REBALANCING (January 2025)\n"
                        "CloudFirst Inc. was acquired and removed from the index.\n"
                        "Replaced by: DataScale Corp. (assigned 12% weight).\n"
                        "DataScale YTD return: -8%.\n"
                        "If updated index had been used for November analysis, benchmark "
                        "return would have been approximately +12% (CloudFirst's +45% at "
                        "12% weight contributed roughly +5.4% to the benchmark)."
                    ),
                },
                "expected": {
                    "original_alpha": "+4% (22% - 18%)",
                    "cloudFirst_contribution": "+5.4% to benchmark (45% x 12% weight)",
                    "revised_benchmark": "approximately +12% without CloudFirst",
                    "revised_alpha": "+10% (22% - 12%) using revised benchmark",
                    "implication": "Portfolio alpha was understated because benchmark was inflated by a single outperformer now removed",
                },
                "difficulty": 4,
                "tags": ["market_data_currency", "benchmark", "index_rebalancing"],
            },
            {
                "prompt": "The company's hedging position was set up based on forward rates 3 months ago. Evaluate mark-to-market.",
                "context": {
                    "hedging_position": (
                        "FX HEDGING SUMMARY (Established November 2024)\n"
                        "Hedge: Sell EUR 50M forward at 1.0850 EUR/USD\n"
                        "Settlement Date: May 2025\n"
                        "Notional USD Value at Inception: $54,250,000\n"
                        "Purpose: Hedge anticipated EUR revenue from European operations"
                    ),
                    "current_market": (
                        "CURRENT MARKET (February 2025)\n"
                        "EUR/USD Spot: 1.0400\n"
                        "EUR/USD 3-Month Forward: 1.0420\n"
                        "Discount factor (3-month): 0.987"
                    ),
                },
                "expected": {
                    "hedge_rate": "1.0850 EUR/USD (sell EUR at this rate)",
                    "current_forward": "1.0420 EUR/USD",
                    "mtm_per_eur": "1.0850 - 1.0420 = 0.0430 USD/EUR gain per unit",
                    "mtm_value": "EUR 50M x 0.0430 x 0.987 discount = approximately $2,122,050 gain",
                    "hedge_is": "in-the-money — EUR weakened, forward sale at higher rate is profitable",
                },
                "difficulty": 5,
                "tags": ["market_data_currency", "hedging", "fx_forward"],
            },
        ]

        for scenario in scenarios:
            cases.append(
                EvalCaseV1(
                    suite_id=_SUITE_ID,
                    dimension_id="market_data_currency",
                    tier=EvalTier.CONTEXT_INTELLIGENCE,
                    domain=_DOMAIN,
                    prompt=scenario["prompt"],
                    context=scenario["context"],
                    expected=scenario["expected"],
                    difficulty=scenario["difficulty"],
                    tags=scenario["tags"],
                )
            )

        return cases

    # ------------------------------------------------------------------
    # Category 4: Restatement handling (10 cases)
    # ------------------------------------------------------------------

    def _restatement_handling_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        scenarios = [
            {
                "prompt": "The company restated Q1-Q3 2024 revenue due to an ASC 606 error. Compare original and restated figures.",
                "context": {
                    "original_filing": "10-Q Original (Q3 2024):\nQ1 Revenue: $320M\nQ2 Revenue: $345M\nQ3 Revenue: $360M\n9-Month Total: $1,025M",
                    "restatement": "10-K/A (Restatement filed February 2025):\nQ1 Revenue (restated): $305M\nQ2 Revenue (restated): $330M\nQ3 Revenue (restated): $348M\n9-Month Total (restated): $983M\nReason: Premature recognition of multi-year licence revenue that should have been recognised ratably over the licence term per ASC 606-10-55-54.",
                },
                "expected": {
                    "q1_impact": "-$15M (from $320M to $305M, -4.7%)",
                    "q2_impact": "-$15M (from $345M to $330M, -4.3%)",
                    "q3_impact": "-$12M (from $360M to $348M, -3.3%)",
                    "total_impact": "-$42M (from $1,025M to $983M, -4.1%)",
                    "root_cause": "Multi-year licence revenue recognised upfront instead of ratably",
                },
                "difficulty": 2,
                "tags": ["restatement", "revenue_recognition", "asc_606"],
            },
            {
                "prompt": "A bank restated its loan loss provision. How does this affect capital ratios?",
                "context": {
                    "original_capital": "ORIGINAL CALL REPORT (Q4 2024):\nAllowance for Loan Losses: $180M\nTier 1 Capital: $2,400M\nRisk-Weighted Assets: $18,000M\nTier 1 Capital Ratio: 13.33%\nTotal Capital Ratio: 14.33%",
                    "restated_capital": "RESTATED CALL REPORT:\nAllowance for Loan Losses: $280M (increased $100M)\nImpact on Net Income: -$100M pre-tax, -$75M after tax\nTier 1 Capital (restated): $2,325M (reduced by $75M after-tax impact)\nRisk-Weighted Assets: $18,000M (unchanged)\nNote: Allowance counts as Tier 2 capital up to 1.25% of RWA.",
                },
                "expected": {
                    "provision_increase": "$100M additional provision ($180M to $280M)",
                    "tier1_impact": "Reduced by $75M (after-tax) to $2,325M",
                    "tier1_ratio_restated": "$2,325M / $18,000M = 12.92% (was 13.33%)",
                    "tier2_allowance_cap": "1.25% x $18B = $225M cap; allowance of $280M exceeds cap",
                    "regulatory_impact": "Still above well-capitalised threshold (>10%) but significant decline",
                },
                "difficulty": 4,
                "tags": ["restatement", "bank", "capital_ratios"],
            },
            {
                "prompt": "An inventory write-down was restated across two periods. Track both the original and corrected inventory balances.",
                "context": {
                    "original": "ORIGINAL FILINGS:\nQ2 2024: Inventory $450M, COGS $280M\nQ3 2024: Inventory $420M, COGS $295M\nNo write-down recorded in either period.",
                    "restatement": "RESTATEMENT (January 2025):\nQ2 2024 (restated): Inventory $410M (write-down of $40M for obsolete product line)\nCOGS: $320M ($280M + $40M write-down)\nQ3 2024 (restated): Inventory $385M (additional $5M write-down for same product line)\nCOGS: $330M ($295M + $30M regular + $5M additional write-down)\nNote: Q3 inventory also reflects $30M of regular COGS increase.",
                },
                "expected": {
                    "q2_inventory_change": "$450M to $410M (-$40M write-down)",
                    "q3_inventory_change": "$420M to $385M (-$35M total: $30M flow-through from Q2 write-down + $5M new write-down)",
                    "total_write_down": "$45M ($40M in Q2 + $5M in Q3)",
                    "gross_margin_impact": "Both quarters' gross margins decreased due to higher COGS",
                },
                "difficulty": 3,
                "tags": ["restatement", "inventory", "write_down"],
            },
            {
                "prompt": "A company restated its goodwill impairment test results. What are the implications for the balance sheet?",
                "context": {
                    "original_10k": "10-K (Filed March 2025):\nGoodwill: $1,200M (no impairment recorded)\nAnnual impairment test: reporting unit fair value exceeded carrying value by 15%.",
                    "restated_10k": "10-K/A (Filed June 2025):\nGoodwill (restated): $850M\nImpairment charge: $350M\nReason: Discount rate used in original test was 8% but should have been 11% based on market conditions. Higher discount rate reduced estimated fair value of reporting unit below carrying value.\nTax impact: $70M deferred tax benefit (20% rate on $350M, but goodwill impairment is only partially deductible).",
                },
                "expected": {
                    "goodwill_reduction": "$1,200M to $850M (-$350M impairment)",
                    "pre_tax_impact": "-$350M charge to operating income",
                    "after_tax_impact": "-$280M net income impact ($350M - $70M tax benefit)",
                    "balance_sheet_impact": "Total assets reduced by $350M; equity reduced by $280M",
                    "root_cause": "Incorrect discount rate (8% vs correct 11%)",
                },
                "difficulty": 4,
                "tags": ["restatement", "goodwill", "impairment"],
            },
            {
                "prompt": "The company corrected its lease accounting under ASC 842. How do the restated financials compare?",
                "context": {
                    "original": "ORIGINAL BALANCE SHEET (Q4 2024):\nRight-of-Use Assets: $0\nLease Liabilities: $0\nRent Expense (income statement): $24M annually\nNote: Company had not adopted ASC 842 for certain embedded leases.",
                    "restated": "RESTATED BALANCE SHEET (Q4 2024):\nRight-of-Use Assets: $85M (8 embedded leases capitalised)\nCurrent Lease Liabilities: $12M\nNon-Current Lease Liabilities: $78M\nTotal Lease Liabilities: $90M\nIncome Statement Impact: Rent expense of $24M replaced by $10M depreciation + $5.4M interest = $15.4M; difference of $8.6M increases operating income.\nNote: Total expense lower in early years under ASC 842 (front-loaded interest + straight-line depreciation).",
                },
                "expected": {
                    "rou_asset_added": "$85M new right-of-use assets on balance sheet",
                    "liability_added": "$90M total lease liabilities ($12M current + $78M non-current)",
                    "income_statement_impact": "Operating income increases $8.6M ($24M rent replaced by $15.4M depreciation + interest)",
                    "debt_ratio_impact": "$90M additional liabilities increases leverage ratios",
                    "net_asset_difference": "ROU $85M - Liability $90M = -$5M reduction in equity",
                },
                "difficulty": 4,
                "tags": ["restatement", "lease_accounting", "asc_842"],
            },
            {
                "prompt": "Revenue was restated due to a channel-stuffing investigation. Compare quarterly patterns.",
                "context": {
                    "original_quarterly": "ORIGINAL QUARTERLY REVENUE (FY2024):\nQ1: $200M\nQ2: $210M\nQ3: $190M\nQ4: $310M\nTotal: $910M\nNote: Q4 revenue included $120M in quarter-end shipments to distributors.",
                    "restated_quarterly": "RESTATED QUARTERLY REVENUE:\nQ1: $195M (-$5M)\nQ2: $200M (-$10M)\nQ3: $185M (-$5M)\nQ4: $220M (-$90M)\nTotal: $800M (-$110M)\nReason: $110M of revenue was improperly recognised on shipments to distributors with undisclosed return rights and extended payment terms exceeding 120 days.",
                },
                "expected": {
                    "total_overstatement": "$110M (from $910M to $800M, -12.1%)",
                    "q4_largest_impact": "$90M reduction in Q4 (most aggressive channel stuffing at year-end)",
                    "pattern": "Channel stuffing accelerated toward year-end (Q4 had $90M of $110M total)",
                    "red_flags": "Q4 revenue was 163% of Q3 original ($310M vs $190M) — unusual seasonal spike",
                    "restated_q4_share": "Q4 now 27.5% of annual (down from 34.1%) — more normal pattern",
                },
                "difficulty": 3,
                "tags": ["restatement", "channel_stuffing", "revenue"],
            },
            {
                "prompt": "A SPAC's financial statements were restated to reclassify warrants from equity to liability. What changed?",
                "context": {
                    "original": "ORIGINAL BALANCE SHEET:\nWarrants classified as Equity: $45M (10M warrants at $4.50 fair value)\nTotal Equity: $350M\nTotal Liabilities: $200M",
                    "restated": "RESTATED BALANCE SHEET:\nWarrant Liability (current): $52M (remeasured at fair value)\nTotal Equity: $305M ($350M - $45M - $7M mark-to-market loss adjustment to retained earnings + $7M)\nTotal Liabilities: $252M ($200M + $52M)\nIncome Statement Impact: $7M loss from change in fair value of warrant liability recognised in Q4 2024.",
                },
                "expected": {
                    "reclassification": "Warrants moved from equity to liability",
                    "equity_reduction": "$350M to $305M (-$45M reclassification)",
                    "liability_increase": "$200M to $252M (+$52M warrant liability)",
                    "fair_value_change": "Warrants increased from $45M to $52M (+$7M loss)",
                    "eps_impact": "$7M additional loss reduces EPS",
                    "sec_context": "SEC Staff Statement on warrants (April 2021) required SPAC warrant reclassification",
                },
                "difficulty": 4,
                "tags": ["restatement", "spac", "warrants"],
            },
            {
                "prompt": "A company restated its segment reporting. How does reclassification affect segment profitability?",
                "context": {
                    "original_segments": "ORIGINAL SEGMENT REPORTING (FY2024):\nSegment A (Software): Revenue $600M, Operating Income $180M (30% margin)\nSegment B (Services): Revenue $400M, Operating Income $40M (10% margin)\nCorporate/Unallocated: ($20M)",
                    "restated_segments": "RESTATED SEGMENT REPORTING:\nSegment A (Software): Revenue $520M, Operating Income $195M (37.5% margin)\nSegment B (Services): Revenue $480M, Operating Income $25M (5.2% margin)\nCorporate/Unallocated: ($20M)\nReason: $80M of managed services revenue previously reported in Software was reclassified to Services to align with how management now evaluates segment performance.",
                },
                "expected": {
                    "software_revenue_change": "$600M to $520M (-$80M), margin improved from 30% to 37.5%",
                    "services_revenue_change": "$400M to $480M (+$80M), margin declined from 10% to 5.2%",
                    "total_revenue_unchanged": "$1,000M in both original and restated",
                    "total_operating_income_unchanged": "$200M in both ($180M+$40M-$20M = $195M+$25M-$20M)",
                    "key_insight": "Software is more profitable than originally appeared; services is less profitable",
                },
                "difficulty": 3,
                "tags": ["restatement", "segment_reporting", "reclassification"],
            },
            {
                "prompt": "The company issued an 8-K announcing it would restate prior periods. What financial periods are affected and what are the material weaknesses?",
                "context": {
                    "8k_restatement_notice": "8-K (Filed January 15, 2025)\nItem 4.02 Non-Reliance on Previously Issued Financial Statements\nThe Company's Audit Committee concluded that the financial statements for FY2023 and Q1-Q3 2024 should no longer be relied upon due to errors in:\n(1) Revenue recognition for long-term contracts (ASC 606 percentage of completion)\n(2) Capitalisation of internal-use software costs (ASC 350-40)\nEstimated impact: Revenue overstated by $60-80M cumulatively.\nSoftware assets overstated by $25-35M.\nMaterial Weakness: Insufficient controls over contract accounting estimates and software capitalisation policy application.",
                    "company_guidance": "Previous FY2024 revenue guidance: $950-980M\nNote: Guidance was issued November 2024 and has not been withdrawn but may need revision.",
                },
                "expected": {
                    "affected_periods": "FY2023 and Q1-Q3 2024",
                    "revenue_overstatement": "$60-80M cumulative",
                    "asset_overstatement": "$25-35M in capitalised software",
                    "material_weaknesses": "Contract accounting estimates and software capitalisation policy",
                    "guidance_risk": "$950-980M guidance likely needs downward revision of $20-30M+ for FY2024",
                    "investor_actions": "Prior financial statements should not be relied upon; await restated filings",
                },
                "difficulty": 3,
                "tags": ["restatement", "8k", "material_weakness"],
            },
            {
                "prompt": "After a restatement, compare the company's credit metrics under original and restated financials. Would covenant compliance change?",
                "context": {
                    "original_metrics": "ORIGINAL FINANCIAL METRICS (FY2024):\nEBITDA: $200M\nTotal Debt: $600M\nInterest Expense: $36M\nLeverage Ratio: 3.0x\nInterest Coverage: 5.6x\nCredit Agreement Covenants:\n- Max Leverage: 4.0x\n- Min Interest Coverage: 3.0x",
                    "restated_metrics": "RESTATED FINANCIAL METRICS (FY2024):\nEBITDA (restated): $165M (revenue and margin adjustments)\nTotal Debt: $600M (unchanged)\nInterest Expense: $36M (unchanged)\nNote: Restatement reduced revenue by $50M and operating margins by 200bps.",
                },
                "expected": {
                    "restated_leverage": "$600M / $165M = 3.64x (was 3.0x) — still below 4.0x covenant",
                    "restated_interest_coverage": "$165M / $36M = 4.58x (was 5.6x) — still above 3.0x covenant",
                    "covenant_compliance": "Still in compliance on both covenants, but significantly less headroom",
                    "leverage_headroom": "Only 0.36x headroom (was 1.0x) before covenant breach",
                    "risk": "Any further EBITDA deterioration (e.g., $15M) would breach leverage covenant",
                },
                "difficulty": 4,
                "tags": ["restatement", "covenants", "credit_metrics"],
            },
        ]

        for scenario in scenarios:
            cases.append(
                EvalCaseV1(
                    suite_id=_SUITE_ID,
                    dimension_id="restatement_handling",
                    tier=EvalTier.MEMORY_FIDELITY,
                    domain=_DOMAIN,
                    prompt=scenario["prompt"],
                    context=scenario["context"],
                    expected=scenario["expected"],
                    difficulty=scenario["difficulty"],
                    tags=scenario["tags"],
                )
            )

        return cases

    # ------------------------------------------------------------------
    # Category 5: Multi-quarter analysis (10 cases)
    # ------------------------------------------------------------------

    def _multi_quarter_analysis_cases(self) -> list[EvalCaseV1]:
        cases: list[EvalCaseV1] = []

        scenarios = [
            {
                "prompt": "Track quarterly revenue growth for four quarters and identify the trend. Is the company accelerating or decelerating?",
                "context": {
                    "quarterly_data": "QUARTERLY REVENUE — CLOUDNEXT INC.\nQ1 2024: $125M (YoY growth: +28%)\nQ2 2024: $138M (YoY growth: +25%)\nQ3 2024: $148M (YoY growth: +22%)\nQ4 2024: $155M (YoY growth: +18%)\nFY2024 Total: $566M",
                },
                "expected": {
                    "trend": "Decelerating growth — YoY growth declined each quarter (28%, 25%, 22%, 18%)",
                    "sequential_growth": "Q1->Q2: +10.4%, Q2->Q3: +7.2%, Q3->Q4: +4.7% — also decelerating sequentially",
                    "annual_growth": "FY2024 $566M; implied FY2023 roughly $453M; annual growth approximately 25%",
                    "concern": "Growth deceleration of 10 percentage points over 4 quarters is significant",
                    "run_rate": "Q4 annualised: $620M; at current deceleration, FY2025 growth may be 12-15%",
                },
                "difficulty": 2,
                "tags": ["multi_quarter", "revenue_growth", "deceleration"],
            },
            {
                "prompt": "Analyse the quarterly gross margin trend and identify the driver of margin compression.",
                "context": {
                    "quarterly_margins": "GROSS MARGIN ANALYSIS — PRECISION MANUFACTURING\nQ1 2024: Revenue $400M, COGS $260M, Gross Margin 35.0%\nQ2 2024: Revenue $420M, COGS $282M, Gross Margin 32.9%\nQ3 2024: Revenue $410M, COGS $283M, Gross Margin 31.0%\nQ4 2024: Revenue $440M, COGS $314M, Gross Margin 28.6%",
                    "driver_analysis": "MANAGEMENT COMMENTARY:\nQ2: 'Raw material costs increased 8% due to supply chain disruptions.'\nQ3: 'We absorbed $10M in unplanned maintenance costs. Raw materials stabilised.'\nQ4: 'New union contract added $12M in annual labour costs (effective October 1). Raw material costs increased another 5%.'",
                },
                "expected": {
                    "margin_decline": "35.0% to 28.6% — 640bps compression over 4 quarters",
                    "q1_q2_driver": "Raw material cost increase (+8%)",
                    "q3_driver": "Unplanned maintenance ($10M one-time)",
                    "q4_drivers": "Union labour costs ($12M annualised = $3M in Q4) plus raw material costs (+5%)",
                    "structural_vs_temporary": "Labour costs are structural (permanent); maintenance was temporary; raw materials may normalise",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "gross_margin", "cost_analysis"],
            },
            {
                "prompt": "Compare quarterly cash conversion cycles over a year. Is working capital management improving?",
                "context": {
                    "working_capital": "WORKING CAPITAL METRICS — SUMMIT DISTRIBUTORS\nQ1 2024: DSO 45 days, DIO 60 days, DPO 35 days, CCC 70 days\nQ2 2024: DSO 48 days, DIO 65 days, DPO 38 days, CCC 75 days\nQ3 2024: DSO 52 days, DIO 72 days, DPO 40 days, CCC 84 days\nQ4 2024: DSO 55 days, DIO 78 days, DPO 42 days, CCC 91 days",
                },
                "expected": {
                    "ccc_trend": "Deteriorating — CCC increased from 70 to 91 days (+21 days, +30%)",
                    "dso_trend": "Worsening — 45 to 55 days; customers paying slower",
                    "dio_trend": "Worsening — 60 to 78 days; inventory building up or turning slower",
                    "dpo_trend": "Improving slightly — 35 to 42 days; stretching vendor payments (partially offsetting)",
                    "cash_impact": "Longer CCC means more cash tied up in working capital; management is NOT improving",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "working_capital", "cash_conversion"],
            },
            {
                "prompt": "Track quarterly SaaS metrics (ARR, churn, NRR) and project forward run-rate.",
                "context": {
                    "saas_metrics": "QUARTERLY SAAS METRICS — ATLAS SOFTWARE\nQ1 2024: ARR $240M, Gross Churn 2.0%, NRR 118%, New ACV $15M\nQ2 2024: ARR $258M, Gross Churn 2.2%, NRR 116%, New ACV $12M\nQ3 2024: ARR $272M, Gross Churn 2.5%, NRR 114%, New ACV $10M\nQ4 2024: ARR $282M, Gross Churn 2.8%, NRR 112%, New ACV $8M",
                },
                "expected": {
                    "arr_growth": "$240M to $282M (+$42M, +17.5% annual)",
                    "churn_trend": "Increasing — 2.0% to 2.8% quarterly; annualised churn roughly 10.8%",
                    "nrr_trend": "Declining — 118% to 112%; expansion revenue slowing",
                    "new_acv_trend": "Declining — $15M to $8M; new sales pipeline weakening",
                    "q1_2025_projection": "At current trajectory: NRR ~110%, churn ~3.0%, new ACV ~$6-7M; ARR ~$289-292M",
                    "concern": "All leading indicators declining simultaneously — revenue growth will slow materially",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "saas", "arr", "churn"],
            },
            {
                "prompt": "Quarterly capex as a percentage of revenue changed significantly. What does this imply for free cash flow?",
                "context": {
                    "capex_data": "CAPITAL EXPENDITURE ANALYSIS — NEXGEN INFRASTRUCTURE\nQ1 2024: Revenue $500M, Capex $40M (8.0%), Maintenance Capex $25M, Growth Capex $15M\nQ2 2024: Revenue $520M, Capex $65M (12.5%), Maintenance $25M, Growth $40M\nQ3 2024: Revenue $510M, Capex $80M (15.7%), Maintenance $25M, Growth $55M\nQ4 2024: Revenue $530M, Capex $95M (17.9%), Maintenance $25M, Growth $70M\nManagement: 'We are investing heavily in new data centre capacity to support 2025-2026 growth.'",
                },
                "expected": {
                    "capex_trend": "Capex increased from $40M to $95M (+138%), ratio from 8% to 17.9%",
                    "maintenance_stable": "$25M per quarter (flat) — roughly 5% of revenue",
                    "growth_capex_surge": "$15M to $70M (+367%) — major capacity investment",
                    "fcf_impact": "Q1 OCF-Capex spread: $40M gap; Q4 gap: $95M; significant FCF compression",
                    "forward_view": "If capex normalises after build-out, FCF should recover; if not, structural concern",
                    "annual_capex": "$280M total FY2024 ($100M maintenance + $180M growth)",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "capex", "free_cash_flow"],
            },
            {
                "prompt": "The company's quarterly earnings consistently beat estimates but the stock has declined. Explain using the detailed metrics.",
                "context": {
                    "quarterly_beats": "EARNINGS VS ESTIMATES — VANGUARD TECH\nQ1 2024: EPS $1.20 vs $1.15 est (+4.3% beat), stock +5% post-earnings\nQ2 2024: EPS $1.25 vs $1.22 est (+2.5% beat), stock -2% post-earnings\nQ3 2024: EPS $1.28 vs $1.27 est (+0.8% beat), stock -8% post-earnings\nQ4 2024: EPS $1.30 vs $1.29 est (+0.8% beat), stock -12% post-earnings",
                    "forward_guidance": "FORWARD GUIDANCE HISTORY:\nQ1 call: FY2024 EPS $5.10-5.30 (consensus was $5.00)\nQ2 call: FY2024 EPS $5.00-5.15 (lowered)\nQ3 call: FY2024 EPS $4.95-5.05 (lowered again)\nQ4 call: FY2025 EPS $4.80-5.00 (below consensus of $5.40)",
                },
                "expected": {
                    "beat_shrinking": "EPS beats declining from 4.3% to 0.8% — quality of beats deteriorating",
                    "guidance_declining": "Full-year guidance cut twice during the year, and FY2025 guided below consensus",
                    "stock_reaction": "Market looks forward — declining guidance matters more than backward-looking beats",
                    "fy2025_gap": "Guided $4.80-5.00 vs consensus $5.40 — 7-11% below expectations",
                    "conclusion": "Stock declined because forward estimates are being revised down despite quarterly beats",
                },
                "difficulty": 4,
                "tags": ["multi_quarter", "earnings", "guidance"],
            },
            {
                "prompt": "Quarterly debt maturity schedule: are there refinancing risks in the next 12 months?",
                "context": {
                    "debt_maturities": "DEBT MATURITY SCHEDULE — APEX HOLDINGS (as of Dec 31, 2024)\nQ1 2025: $150M Term Loan A matures March 15\nQ2 2025: $50M Revolver draw due June 30 (renewable)\nQ3 2025: No maturities\nQ4 2025: $300M Senior Notes 5.25% mature November 1\n2026: $200M Convertible Notes mature March 2026\n2027: $500M Term Loan B\nTotal Debt: $1,200M\nCash on Hand: $180M\nUndrawn Revolver: $200M",
                    "credit_profile": "Current Credit Profile:\nCredit Rating: BB (stable outlook)\nLTM EBITDA: $250M\nLeverage: 4.8x (elevated)\nRecent market: BB-rated new issue spread: SOFR + 400bps",
                },
                "expected": {
                    "near_term_maturities": "$500M due within 12 months ($150M Q1 + $50M Q2 + $300M Q4)",
                    "liquidity": "$180M cash + $200M undrawn revolver = $380M available",
                    "gap": "$500M maturities vs $380M liquidity = $120M shortfall",
                    "refinancing_risk": "HIGH — must refinance $300M notes in Q4 2025 at elevated spreads",
                    "cost_impact": "BB spread of SOFR+400bps vs existing 5.25% coupon; refinancing may be more expensive",
                    "leverage_concern": "4.8x leverage may limit refinancing options",
                },
                "difficulty": 4,
                "tags": ["multi_quarter", "debt_maturity", "refinancing"],
            },
            {
                "prompt": "Track quarterly operating leverage by comparing revenue growth to operating expense growth.",
                "context": {
                    "quarterly_financials": "QUARTERLY P&L — NOVA SYSTEMS\nQ1 2024: Revenue $200M (+15% YoY), OpEx $170M (+18% YoY), Op Income $30M\nQ2 2024: Revenue $215M (+14% YoY), OpEx $186M (+16% YoY), Op Income $29M\nQ3 2024: Revenue $225M (+13% YoY), OpEx $198M (+15% YoY), Op Income $27M\nQ4 2024: Revenue $230M (+10% YoY), OpEx $207M (+14% YoY), Op Income $23M",
                },
                "expected": {
                    "operating_leverage": "NEGATIVE — OpEx growing faster than revenue every quarter",
                    "op_income_trend": "$30M, $29M, $27M, $23M — declining each quarter",
                    "op_margin_trend": "15.0%, 13.5%, 12.0%, 10.0% — 500bps compression",
                    "growth_spread": "Revenue growth slowing faster than OpEx growth — scissors are widening",
                    "concern": "Company lacks operating leverage; fixed costs preventing margin expansion",
                    "fy2024_totals": "Revenue $870M, OpEx $761M, Op Income $109M (12.5% margin)",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "operating_leverage", "margins"],
            },
            {
                "prompt": "A retailer's quarterly same-store sales and new store openings tell different stories. Analyse.",
                "context": {
                    "retail_data": "QUARTERLY RETAIL METRICS — BRIGHTWAY STORES\nQ1 2024: Total Revenue $800M, SSS +2.0%, Stores 500, New Opens 10\nQ2 2024: Total Revenue $850M, SSS +0.5%, Stores 510, New Opens 15\nQ3 2024: Total Revenue $870M, SSS -1.0%, Stores 525, New Opens 12\nQ4 2024: Total Revenue $920M, SSS -2.5%, Stores 537, New Opens 8\nNew store average revenue: $5M/quarter in year 1",
                },
                "expected": {
                    "total_revenue_growth": "$800M to $920M (+15% full year) — looks healthy",
                    "sss_trend": "+2.0% to -2.5% — existing stores deteriorating significantly",
                    "new_store_contribution": "45 new stores x $5M avg = ~$225M incremental revenue annually",
                    "organic_vs_new": "Total growth driven entirely by new stores; organic (SSS) is negative",
                    "unit_economics_risk": "If new stores cannibalise existing stores, SSS decline may accelerate",
                    "sustainable": "Growth model unsustainable if SSS continues declining; eventually run out of new store opportunities",
                },
                "difficulty": 4,
                "tags": ["multi_quarter", "retail", "same_store_sales"],
            },
            {
                "prompt": "Quarterly R&D spending patterns suggest a product launch cycle. When do you expect the product to launch?",
                "context": {
                    "rd_data": "R&D SPENDING — BIOMED INNOVATIONS\nQ1 2024: R&D $45M (18% of revenue), Clinical trials Phase 2 ongoing\nQ2 2024: R&D $52M (20% of revenue), Phase 2 data readout positive\nQ3 2024: R&D $68M (25% of revenue), Phase 3 trial initiated, manufacturing scale-up began\nQ4 2024: R&D $75M (27% of revenue), Phase 3 enrollment complete, pre-submission meetings with FDA\nQ1 2025: R&D projected $60M, NDA preparation\nManagement: 'We expect to submit our NDA in Q2 2025 with a standard 10-month review.'",
                },
                "expected": {
                    "rd_trend": "$45M to $75M (+67% increase) — typical pre-launch ramp",
                    "rd_peak": "Q4 2024 appears to be peak R&D spend ($75M, 27% of revenue)",
                    "clinical_timeline": "Phase 2 (Q1-Q2 2024) -> Phase 3 (Q3-Q4 2024) -> NDA (Q2 2025)",
                    "expected_fda_decision": "Q2 2025 submission + 10 months = Q4 2025 or Q1 2026",
                    "expected_launch": "If approved, commercial launch likely Q1-Q2 2026",
                    "rd_post_launch": "R&D likely normalises to 15-18% of revenue post-launch",
                },
                "difficulty": 3,
                "tags": ["multi_quarter", "rd_spending", "product_launch"],
            },
        ]

        for scenario in scenarios:
            cases.append(
                EvalCaseV1(
                    suite_id=_SUITE_ID,
                    dimension_id="multi_quarter_analysis",
                    tier=EvalTier.LEARNING_DYNAMICS,
                    domain=_DOMAIN,
                    prompt=scenario["prompt"],
                    context=scenario["context"],
                    expected=scenario["expected"],
                    difficulty=scenario["difficulty"],
                    tags=scenario["tags"],
                )
            )

        return cases


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _finance_category(dimension_id: str) -> str:
    """Map internal dimension ids to public category names."""
    mapping: dict[str, str] = {
        "numerical_verification": "due_diligence",
        "cross_doc_reconciliation": "due_diligence",
        "market_data_currency": "model_building",
        "restatement_handling": "quarterly_reporting",
        "multi_quarter_analysis": "portfolio_analysis",
    }
    return mapping.get(dimension_id, dimension_id)


def _generate_due_diligence_cases(count: int = 20) -> list[dict[str, Any]]:
    """Generate *count* due-diligence scenarios (numerical verification + cross-doc).

    Args:
        count: Maximum number of cases to return (default 20).

    Returns:
        A list of scenario dicts (see :meth:`FinanceMemoryBenchmark.generate_cases`).
    """
    all_cases = FinanceMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "due_diligence"][:count]


def _generate_model_building_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* model-building / market-data-currency scenarios."""
    all_cases = FinanceMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "model_building"][:count]


def _generate_quarterly_reporting_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* quarterly-reporting / restatement scenarios."""
    all_cases = FinanceMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "quarterly_reporting"][:count]


def _generate_portfolio_analysis_cases(count: int = 10) -> list[dict[str, Any]]:
    """Generate *count* portfolio-analysis / multi-quarter scenarios."""
    all_cases = FinanceMemoryBenchmark().generate_cases()
    return [c for c in all_cases if c["category"] == "portfolio_analysis"][:count]
