"""Aegis benchmark suites — standardized eval benchmarks for agent intelligence.

Re-exports the benchmark runner framework and built-in benchmark suites::

    from aegis.eval.benchmarks import BenchmarkSuite, BenchmarkRegistry
    from aegis.eval.benchmarks import LegalMemoryBenchmark, FinanceMemoryBenchmark
"""

from aegis.eval.benchmarks.finance_memory import FinanceMemoryBenchmark
from aegis.eval.benchmarks.harness import BenchmarkHarness
from aegis.eval.benchmarks.legal_memory import LegalMemoryBenchmark
from aegis.eval.benchmarks.legal_memory_scale import LegalMemoryScaleBenchmark
from aegis.eval.benchmarks.retrieval_precision_depth import RetrievalPrecisionDepthBenchmark
from aegis.eval.benchmarks.reward_integrity import RewardIntegrityBenchmark
from aegis.eval.benchmarks.runner import (
    BenchmarkConfig,
    BenchmarkRegistry,
    BenchmarkResult,
    BenchmarkSuite,
)

__all__ = [
    "BenchmarkConfig",
    "BenchmarkHarness",
    "BenchmarkRegistry",
    "BenchmarkResult",
    "BenchmarkSuite",
    "FinanceMemoryBenchmark",
    "LegalMemoryBenchmark",
    "LegalMemoryScaleBenchmark",
    "RetrievalPrecisionDepthBenchmark",
    "RewardIntegrityBenchmark",
]
