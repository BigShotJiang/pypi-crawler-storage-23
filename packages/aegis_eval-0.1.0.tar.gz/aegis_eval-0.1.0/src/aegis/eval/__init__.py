"""Aegis eval engine — 51-dimension agent intelligence evaluation.

Re-exports the primary public API surface:

* :class:`Evaluator` — the main orchestration engine.
* :class:`EvalConfig` — run configuration.
* :class:`EvalResult` — structured evaluation output.
* :class:`Dimension` — base class for evaluation dimensions.
* :class:`DimensionRegistry` — singleton dimension registry.
* :class:`TriangulatedJudge` — default triangulated scoring judge.
* :class:`ScenarioGenerator` — eval-case generation.
"""

from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.dimensions.registry import DimensionRegistry, register_dimension
from aegis.eval.engine import EvalConfig, EvalResult, Evaluator
from aegis.eval.judges.triangulated import TriangulatedJudge
from aegis.eval.scenarios.generator import ScenarioGenerator

__all__ = [
    "Evaluator",
    "EvalConfig",
    "EvalResult",
    "Dimension",
    "Phase",
    "DimensionRegistry",
    "register_dimension",
    "TriangulatedJudge",
    "ScenarioGenerator",
]
