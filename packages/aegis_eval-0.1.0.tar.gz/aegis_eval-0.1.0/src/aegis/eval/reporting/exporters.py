"""Export evaluation results to JSON, HTML, and CSV formats.

These exporters consume the structured output of an eval run and serialise
it for storage, dashboarding, or CI artifact upload.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any


class JSONExporter:
    """Export evaluation results as a JSON file.

    Args:
        indent: JSON indentation level for pretty-printing.
    """

    def __init__(self, indent: int = 2) -> None:
        self.indent = indent

    def export(self, data: dict[str, Any], output_path: str | Path) -> Path:
        """Write evaluation data to a JSON file.

        Args:
            data: The evaluation result dictionary to serialise.
            output_path: Destination file path.

        Returns:
            The resolved :class:`Path` that was written.
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=self.indent, default=str)
        return path


class HTMLExporter:
    """Export evaluation results as a standalone HTML report.

    Generates a minimal HTML page with a summary table.  A future version
    will integrate a richer template engine and interactive charts.
    """

    def export(self, data: dict[str, Any], output_path: str | Path) -> Path:
        """Write evaluation data to an HTML file.

        Args:
            data: The evaluation result dictionary to render.
            output_path: Destination file path.

        Returns:
            The resolved :class:`Path` that was written.
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        html = self._render(data)
        path.write_text(html, encoding="utf-8")
        return path

    def _render(self, data: dict[str, Any]) -> str:
        """Render evaluation data into an HTML string."""
        rows = ""
        dimension_scores: dict[str, float] = data.get("dimension_scores", {})
        for dim_id, score in dimension_scores.items():
            rows += f"<tr><td>{dim_id}</td><td>{score:.4f}</td></tr>\n"

        return f"""\
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Aegis Eval Report — {data.get("run_id", "unknown")}</title>
    <style>
        body {{ font-family: system-ui, sans-serif; margin: 2rem; }}
        table {{ border-collapse: collapse; width: 100%; max-width: 800px; }}
        th, td {{ border: 1px solid #ddd; padding: 0.5rem 1rem; text-align: left; }}
        th {{ background: #f5f5f5; }}
        .header {{ margin-bottom: 1.5rem; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Aegis Eval Report</h1>
        <p><strong>Run ID:</strong> {data.get("run_id", "N/A")}</p>
        <p><strong>Agent ID:</strong> {data.get("agent_id", "N/A")}</p>
        <p><strong>Overall Score:</strong> {data.get("overall_score", 0.0):.4f}</p>
    </div>
    <h2>Dimension Scores</h2>
    <table>
        <thead><tr><th>Dimension</th><th>Score</th></tr></thead>
        <tbody>
{rows}
        </tbody>
    </table>
</body>
</html>
"""


class CSVExporter:
    """Export evaluation results as a CSV file."""

    def export(self, data: dict[str, Any], output_path: str | Path) -> Path:
        """Write evaluation dimension scores to a CSV file.

        Args:
            data: The evaluation result dictionary. Expected keys:
                ``dimension_scores`` (dict of dimension_id -> score).
            output_path: Destination file path.

        Returns:
            The resolved :class:`Path` that was written.
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        dimension_scores: dict[str, float] = data.get("dimension_scores", {})

        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["dimension_id", "score"])
            for dim_id, score in sorted(dimension_scores.items()):
                writer.writerow([dim_id, f"{score:.6f}"])

        return path
