"""Diagnostic reporting for Aegis eval runs.

Produces structured diagnostic summaries from evaluation results, including
per-tier breakdowns, weak dimensions, overall health indicators, strengths,
weaknesses, root cause analysis, and training focus recommendations.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from pydantic import BaseModel, Field


class DiagnosticReport(BaseModel):
    """Structured diagnostic summary of an evaluation run.

    Attributes:
        run_id: The eval run this report describes.
        overall_score: Weighted composite score across all dimensions.
        tier_scores: Average score per :class:`EvalTier`.
        weak_dimensions: Dimension IDs that scored below the threshold.
        strong_dimensions: Dimension IDs that scored above the high-water mark.
        strengths: Human-readable list of strong areas.
        weaknesses: Human-readable list of weak areas.
        recommendations: Human-readable improvement suggestions.
        training_focus: Ordered list of dimension IDs to prioritize for training.
        root_causes: Analysis of failure patterns across dimensions.
        metadata: Arbitrary extra data for downstream consumers.
    """

    run_id: str
    overall_score: float = 0.0
    tier_scores: dict[str, float] = Field(default_factory=dict)
    weak_dimensions: list[str] = Field(default_factory=list)
    strong_dimensions: list[str] = Field(default_factory=list)
    strengths: list[str] = Field(default_factory=list)
    weaknesses: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    training_focus: list[str] = Field(default_factory=list)
    root_causes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Tier name mapping
# ---------------------------------------------------------------------------

_TIER_NAMES: dict[str, str] = {
    "1": "Memory Fidelity",
    "2": "Context Intelligence",
    "3": "Learning Dynamics",
    "4": "Reasoning Quality",
    "5": "Meta-Cognition",
    "6": "Collaborative Context",
    "7": "Security & Adversarial",
}


def _extract_tier(dim_id: str) -> str | None:
    """Extract a tier number from a dimension ID like 'tier1_foo' or '1.2_bar'."""
    m = re.match(r"tier[_\-]?(\d)", dim_id, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.match(r"(\d)\.", dim_id)
    if m:
        return m.group(1)
    return None


def _estimate_impact(score: float) -> str:
    """Estimate the improvement impact if a low-scoring dimension is trained."""
    gap = max(0.0, 0.8 - score)
    if gap >= 0.5:
        return "high"
    if gap >= 0.25:
        return "medium"
    return "low"


def generate_diagnostic(
    run_id: str,
    dimension_scores: dict[str, float],
    weakness_threshold: float = 0.5,
    strength_threshold: float = 0.8,
) -> dict[str, Any]:
    """Generate a diagnostic report dictionary from dimension scores.

    Args:
        run_id: Identifier of the evaluation run.
        dimension_scores: Mapping of ``dimension_id -> score``.
        weakness_threshold: Scores below this are flagged as weak.
        strength_threshold: Scores above this are flagged as strong.

    Returns:
        A dict representation of a :class:`DiagnosticReport`.
    """
    scores = list(dimension_scores.values())
    overall = sum(scores) / len(scores) if scores else 0.0

    # --- Tier aggregation ---------------------------------------------------
    tier_buckets: dict[str, list[float]] = defaultdict(list)
    for dim_id, score in dimension_scores.items():
        tier = _extract_tier(dim_id)
        if tier:
            tier_buckets[tier].append(score)

    tier_scores: dict[str, float] = {}
    for tier_num, bucket in sorted(tier_buckets.items()):
        tier_label = _TIER_NAMES.get(tier_num, f"Tier {tier_num}")
        tier_scores[tier_label] = round(sum(bucket) / len(bucket), 4) if bucket else 0.0

    # --- Weak / Strong dimensions -------------------------------------------
    weak = [dim_id for dim_id, score in dimension_scores.items() if score < weakness_threshold]
    strong = [dim_id for dim_id, score in dimension_scores.items() if score >= strength_threshold]

    # --- Strengths ----------------------------------------------------------
    strengths: list[str] = []
    if strong:
        strengths.append(
            f"Agent excels in {len(strong)} dimension(s): "
            + ", ".join(strong[:5])
            + ("..." if len(strong) > 5 else "")
        )
    for tier_label, avg in tier_scores.items():
        if avg >= strength_threshold:
            strengths.append(f"{tier_label} is strong with an average score of {avg:.1%}.")

    # --- Weaknesses ---------------------------------------------------------
    weaknesses: list[str] = []
    if weak:
        weaknesses.append(
            f"Agent underperforms in {len(weak)} dimension(s): "
            + ", ".join(weak[:5])
            + ("..." if len(weak) > 5 else "")
        )
    for tier_label, avg in tier_scores.items():
        if avg < weakness_threshold:
            weaknesses.append(f"{tier_label} needs attention with an average score of {avg:.1%}.")

    # --- Training focus (ordered by largest gap) ----------------------------
    sorted_by_gap = sorted(dimension_scores.items(), key=lambda x: x[1])
    training_focus = [dim_id for dim_id, score in sorted_by_gap if score < strength_threshold]

    # --- Recommendations (top 3 training focus areas with impact) -----------
    recommendations: list[str] = []
    for dim_id, score in sorted_by_gap[:3]:
        if score < strength_threshold:
            impact = _estimate_impact(score)
            recommendations.append(
                f"Train on '{dim_id}' (current: {score:.1%}, "
                f"gap to 80%: {max(0.0, 0.8 - score):.1%}, "
                f"expected impact: {impact})."
            )
    if overall < 0.5:
        recommendations.append(
            "Overall score is below 0.5 — consider reviewing agent "
            "architecture and training pipeline."
        )
    if not recommendations and weak:
        recommendations.append(
            f"Focus on improving {len(weak)} weak dimension(s): "
            + ", ".join(weak[:5])
            + ("..." if len(weak) > 5 else "")
        )

    # --- Root causes (failure pattern analysis) -----------------------------
    root_causes: list[str] = []
    weak_tiers: list[str] = [
        tier_label for tier_label, avg in tier_scores.items() if avg < weakness_threshold
    ]
    if weak_tiers:
        root_causes.append(
            "Systematic weakness detected across tier(s): "
            + ", ".join(weak_tiers)
            + ". This suggests a foundational capability gap rather than isolated failures."
        )

    # Check for adjacent-tier weakness patterns
    weak_tier_nums = sorted(
        tier_num
        for tier_num, bucket in tier_buckets.items()
        if (sum(bucket) / len(bucket) if bucket else 0) < weakness_threshold
    )
    for i in range(len(weak_tier_nums) - 1):
        if int(weak_tier_nums[i + 1]) - int(weak_tier_nums[i]) == 1:
            root_causes.append(
                f"Adjacent tiers {weak_tier_nums[i]} and {weak_tier_nums[i + 1]} "
                f"are both weak — lower-tier deficits may cascade upward."
            )
            break

    # Check for high variance within a tier (uneven capability)
    for tier_num, bucket in tier_buckets.items():
        if len(bucket) >= 2:
            tier_min = min(bucket)
            tier_max = max(bucket)
            if tier_max - tier_min > 0.4:
                tier_label = _TIER_NAMES.get(tier_num, f"Tier {tier_num}")
                root_causes.append(
                    f"{tier_label} has high internal variance "
                    f"(min: {tier_min:.1%}, max: {tier_max:.1%}). "
                    f"Some sub-capabilities are strong while others lag."
                )

    report = DiagnosticReport(
        run_id=run_id,
        overall_score=round(overall, 4),
        tier_scores=tier_scores,
        weak_dimensions=weak,
        strong_dimensions=strong,
        strengths=strengths,
        weaknesses=weaknesses,
        recommendations=recommendations,
        training_focus=training_focus,
        root_causes=root_causes,
    )
    return report.model_dump()
