"""Centralized environment configuration for Aegis backends."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Annotated, Any

from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

_DEFAULT_POSTGRES_DSN = "postgresql://aegis:aegis_dev@localhost:5432/aegis"


class PostgresSettings(BaseSettings):
    """PostgreSQL / pgvector connection settings."""

    model_config = SettingsConfigDict(env_prefix="POSTGRES_", env_file=".env", extra="ignore")

    host: str = "localhost"
    port: int = 5432
    user: str = "aegis"
    password: str = "aegis_dev"
    db: str = "aegis"

    @property
    def dsn(self) -> str:
        return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.db}"


class Neo4jSettings(BaseSettings):
    """Neo4j connection settings."""

    model_config = SettingsConfigDict(env_prefix="NEO4J_", env_file=".env", extra="ignore")

    uri: str = "bolt://localhost:7687"
    user: str = "neo4j"
    password: str = "aegis_dev"


class RedisSettings(BaseSettings):
    """Redis connection settings."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    redis_url: str = Field(default="redis://localhost:6379/0", alias="REDIS_URL")


class LLMSettings(BaseSettings):
    """LLM provider API key settings."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    provider: str = Field(default="", validation_alias=AliasChoices("AEGIS_LLM_PROVIDER"))
    model: str = Field(default="", validation_alias=AliasChoices("AEGIS_LLM_MODEL"))
    generic_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("AEGIS_LLM_API_KEY"),
    )
    openai_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("AEGIS_OPENAI_API_KEY", "OPENAI_API_KEY"),
    )
    anthropic_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("AEGIS_ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY"),
    )


class TrainingSettings(BaseSettings):
    """Training configuration."""

    model_config = SettingsConfigDict(env_prefix="AEGIS_TRAINING_", env_file=".env", extra="ignore")

    device: str = "auto"
    model: str = "Qwen/Qwen2.5-7B"
    precision: str = "bf16"


class AWSSettings(BaseSettings):
    """AWS credentials and config."""

    model_config = SettingsConfigDict(env_prefix="AWS_", env_file=".env", extra="ignore")

    access_key_id: str = ""
    secret_access_key: str = ""
    default_region: str = "us-east-1"


class ObservabilitySettings(BaseSettings):
    """W&B and observability settings."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    wandb_api_key: str = Field(default="", alias="WANDB_API_KEY")
    wandb_project: str = Field(default="aegis-training", alias="WANDB_PROJECT")


class AegisSettings(BaseSettings):
    """Top-level Aegis platform settings."""

    model_config = SettingsConfigDict(env_prefix="AEGIS_", env_file=".env", extra="ignore")

    environment: str = Field(
        default="development",
        validation_alias=AliasChoices("AEGIS_ENV", "ENVIRONMENT"),
    )
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: str = "info"
    cors_origins: Annotated[list[str], NoDecode] = Field(
        default_factory=lambda: ["http://localhost:3000"]
    )

    rate_limit_rpm: int = Field(default=100, description="Requests per minute per client")
    rate_limit_burst: int = Field(default=20, description="Burst allowance above sustained rate")
    rate_limit_anonymous: bool = Field(
        default=False,
        description="Apply rate limits to anonymous (no API key) traffic by IP",
    )
    max_request_size: int = Field(
        default=10 * 1024 * 1024,
        description="Maximum request body size in bytes (default 10 MB)",
    )

    postgres_dsn: str = Field(
        default=_DEFAULT_POSTGRES_DSN,
        validation_alias=AliasChoices("AEGIS_POSTGRES_DSN", "DATABASE_URL"),
    )
    neo4j_uri: str = Field(
        default="bolt://localhost:7687",
        validation_alias=AliasChoices("AEGIS_NEO4J_URI", "NEO4J_URI"),
    )
    neo4j_user: str = Field(
        default="neo4j",
        validation_alias=AliasChoices("AEGIS_NEO4J_USER", "NEO4J_USER"),
    )
    neo4j_password: str = Field(
        default="",
        validation_alias=AliasChoices("AEGIS_NEO4J_PASSWORD", "NEO4J_PASSWORD"),
    )
    db_path: str = Field(
        default_factory=lambda: str(Path.home() / ".aegis" / "aegis.db"),
        validation_alias=AliasChoices("AEGIS_DB_PATH"),
    )
    hf_token: str = Field(
        default="",
        validation_alias=AliasChoices("HF_TOKEN", "HUGGINGFACE_TOKEN"),
    )

    _postgres: PostgresSettings | None = None
    _neo4j: Neo4jSettings | None = None
    _redis: RedisSettings | None = None
    _llm: LLMSettings | None = None
    _training: TrainingSettings | None = None
    _aws: AWSSettings | None = None
    _observability: ObservabilitySettings | None = None

    @field_validator("cors_origins", mode="before")
    @classmethod
    def _parse_cors_origins(cls, value: Any) -> Any:
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return []
            if stripped.startswith("["):
                return value
            return [origin.strip() for origin in stripped.split(",") if origin.strip()]
        return value

    @field_validator("environment", mode="before")
    @classmethod
    def _normalize_environment(cls, value: Any) -> str:
        if value is None:
            return "development"
        return str(value).strip().lower()

    def model_post_init(self, __context: Any) -> None:
        """Enforce production-safe defaults."""
        if self.environment in {"prod", "production"} and "*" in self.cors_origins:
            raise ValueError("Wildcard CORS origins are not allowed in production.")

    @property
    def postgres(self) -> PostgresSettings:
        if self._postgres is None:
            self._postgres = PostgresSettings()
        return self._postgres

    @property
    def neo4j(self) -> Neo4jSettings:
        if self._neo4j is None:
            self._neo4j = Neo4jSettings()
        return self._neo4j

    @property
    def redis(self) -> RedisSettings:
        if self._redis is None:
            self._redis = RedisSettings()
        return self._redis

    @property
    def llm(self) -> LLMSettings:
        if self._llm is None:
            self._llm = LLMSettings()
        return self._llm

    @property
    def training(self) -> TrainingSettings:
        if self._training is None:
            self._training = TrainingSettings()
        return self._training

    @property
    def aws(self) -> AWSSettings:
        if self._aws is None:
            self._aws = AWSSettings()
        return self._aws

    @property
    def observability(self) -> ObservabilitySettings:
        if self._observability is None:
            self._observability = ObservabilitySettings()
        return self._observability

    @property
    def postgres_configured(self) -> bool:
        return "postgres_dsn" in self.model_fields_set

    @property
    def neo4j_configured(self) -> bool:
        return "neo4j_uri" in self.model_fields_set


@lru_cache(maxsize=1)
def get_settings() -> AegisSettings:
    """Return the cached singleton settings instance."""
    return AegisSettings()
