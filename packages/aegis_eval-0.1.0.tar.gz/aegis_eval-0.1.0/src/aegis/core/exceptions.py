"""Aegis exception hierarchy."""


class AegisError(Exception):
    """Base exception for all Aegis errors."""


class ConfigError(AegisError):
    """Configuration is invalid or missing."""


class AdapterError(AegisError):
    """Agent adapter failed to connect or communicate."""


class EvalError(AegisError):
    """Evaluation run failed."""


class ScoringError(AegisError):
    """Scoring pipeline failed."""


class DimensionNotFoundError(AegisError):
    """Requested dimension does not exist in the registry."""


class PluginError(AegisError):
    """Domain plugin failed to load or execute."""


class PromotionBlockedError(AegisError):
    """Promotion was blocked by a regression or safety gate."""


class MemoryError(AegisError):
    """Memory subsystem error."""


class EventLogImmutabilityError(MemoryError):
    """Attempted to mutate the immutable event log."""


class ProvenanceChainError(MemoryError):
    """Provenance chain is broken or invalid."""
