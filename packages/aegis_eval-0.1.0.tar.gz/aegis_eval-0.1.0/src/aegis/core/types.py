"""Aegis v1 public types — schema freeze.

These types form the stable API contract. Breaking changes only in v2.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class MemoryOperation(str, Enum):
    """The 12 RL-trained memory operations."""

    STORE = "STORE"
    UPDATE = "UPDATE"
    FORGET = "FORGET"
    RETRIEVE = "RETRIEVE"
    LINK = "LINK"
    COMPRESS = "COMPRESS"
    PROMOTE = "PROMOTE"
    DEMOTE = "DEMOTE"
    SPLIT = "SPLIT"
    MERGE = "MERGE"
    VERIFY = "VERIFY"
    ANNOTATE = "ANNOTATE"


class MemoryTier(str, Enum):
    """Temporal-hierarchical memory tiers."""

    WORKING = "working"
    SESSION = "session"
    PERMANENT = "permanent"


class EvalTier(int, Enum):
    """7-tier agent intelligence hierarchy."""

    MEMORY_FIDELITY = 1
    CONTEXT_INTELLIGENCE = 2
    LEARNING_DYNAMICS = 3
    REASONING_QUALITY = 4
    META_COGNITION = 5
    COLLABORATIVE_CONTEXT = 6
    SECURITY_ADVERSARIAL = 7


class StepKind(str, Enum):
    """Kinds of steps within a trajectory."""

    THINK = "think"
    MEMORY_OP = "memory_op"
    SEARCH = "search"
    TOOL_CALL = "tool_call"
    EVIDENCE = "evidence"
    REASON = "reason"
    ANSWER = "answer"


class PromotionStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    PENDING_HUMAN_GATE = "pending_human_gate"


class ScorerType(str, Enum):
    RULE_BASED = "rule_based"
    SEMANTIC = "semantic"
    LLM_JUDGE = "llm_judge"


# ---------------------------------------------------------------------------
# TrajectoryV1
# ---------------------------------------------------------------------------


class TrajectoryStep(BaseModel):
    """A single step in an agent trajectory."""

    kind: StepKind
    content: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = Field(default_factory=dict)
    latency_ms: int | None = None
    token_count: int | None = None


class TrajectoryV1(BaseModel):
    """Full execution trace of an agent interaction.

    Task metadata + ordered tool/memory/reasoning steps.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str
    task_id: str
    steps: list[TrajectoryStep]
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    total_latency_ms: int | None = None
    total_tokens: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# MemoryEventV1
# ---------------------------------------------------------------------------


class MemoryEventV1(BaseModel):
    """Immutable memory event log entry.

    Operation + provenance + temporal bounds.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    operation: MemoryOperation
    memory_tier: MemoryTier
    key: str
    value: Any
    provenance: dict[str, Any] = Field(
        default_factory=dict,
        description="Source document, page, extraction method, etc.",
    )
    temporal_bounds: TemporalBounds | None = None
    agent_id: str
    customer_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)
    metadata: dict[str, Any] = Field(default_factory=dict)


class TemporalBounds(BaseModel):
    """Time validity window for a memory entry."""

    valid_from: datetime
    valid_to: datetime | None = None


# Update forward ref
MemoryEventV1.model_rebuild()


# ---------------------------------------------------------------------------
# RetrievalTraceV1
# ---------------------------------------------------------------------------


class RetrievalSource(BaseModel):
    """A single source queried during retrieval."""

    source_type: str  # "vector", "kg", "sql", "web"
    query: str
    results_count: int
    latency_ms: int
    metadata: dict[str, Any] = Field(default_factory=dict)


class ContextBlock(BaseModel):
    """A block of context selected or dropped during context construction."""

    source_id: str
    content: str
    rerank_score: float
    selected: bool
    reason: str | None = None


class RetrievalTraceV1(BaseModel):
    """Full retrieval audit trail.

    Sources queried, rerank scores, selected/dropped context blocks.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    trajectory_id: str
    sources_queried: list[RetrievalSource]
    context_blocks: list[ContextBlock]
    total_retrieved: int
    total_selected: int
    total_dropped: int
    anti_retrieval_triggered: bool = False
    context_budget_tokens: int | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# RewardTraceV1
# ---------------------------------------------------------------------------


class StageReward(BaseModel):
    """Reward decomposition for a single stage."""

    stage: int
    stage_name: str
    rule_score: float = Field(ge=0.0, le=1.0)
    semantic_score: float = Field(ge=0.0, le=1.0)
    judge_score: float = Field(ge=0.0, le=1.0)
    weight: float = Field(ge=0.0, le=1.0)
    weighted_score: float = Field(ge=0.0, le=1.0)
    details: dict[str, Any] = Field(default_factory=dict)


class RewardTraceV1(BaseModel):
    """Training reward decomposition.

    Per-stage rewards + component scores + weighting profile.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    rollout_id: str
    stages: list[StageReward]
    total_reward: float
    weighting_profile: str = "dynamic"
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# EvalCaseV1
# ---------------------------------------------------------------------------


class EvalCaseV1(BaseModel):
    """Single eval test case definition.

    Prompt, context, expected behavior, scoring rubric references.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    suite_id: str
    dimension_id: str
    tier: EvalTier
    domain: str | None = None
    prompt: str
    context: dict[str, Any] = Field(default_factory=dict)
    expected: dict[str, Any] = Field(default_factory=dict)
    rubric_refs: list[str] = Field(default_factory=list)
    difficulty: int = Field(ge=1, le=5, default=3)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# JudgePacketV1
# ---------------------------------------------------------------------------


class JudgePacketV1(BaseModel):
    """Triangulated scoring output.

    Rule score + semantic score + model-judge ensemble + disagreement signal.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    eval_case_id: str
    dimension_id: str
    rule_score: float | None = Field(default=None, ge=0.0, le=1.0)
    semantic_score: float | None = Field(default=None, ge=0.0, le=1.0)
    judge_scores: dict[str, float] = Field(
        default_factory=dict,
        description="Model name -> score. Supports multi-judge ensemble.",
    )
    ensemble_score: float = Field(ge=0.0, le=1.0)
    disagreement: float = Field(
        ge=0.0,
        le=1.0,
        default=0.0,
        description="Disagreement signal across judges. 0 = unanimous, 1 = max divergence.",
    )
    explanation: str = ""
    evidence: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# PromotionDecisionV1
# ---------------------------------------------------------------------------


class BlockingRegression(BaseModel):
    """A regression that blocks promotion."""

    dimension_id: str
    tier: EvalTier
    baseline_score: float
    current_score: float
    delta: float
    severity: str  # "critical", "major", "minor"


class PromotionDecisionV1(BaseModel):
    """Deployment promotion verdict.

    Pass/fail, blocking regressions, human gate status, rollback pointer.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    adapter_id: str
    status: PromotionStatus
    composite_improvement: float
    blocking_regressions: list[BlockingRegression] = Field(default_factory=list)
    tier7_clear: bool = True
    human_gate_required: bool = False
    human_gate_approved: bool | None = None
    human_gate_approver: str | None = None
    rollback_pointer: str | None = Field(
        default=None,
        description="Adapter ID to rollback to if promotion fails in canary.",
    )
    canary_config: dict[str, Any] = Field(
        default_factory=lambda: {"traffic_pct": 5, "duration_hours": 24},
    )
    eval_run_before: str | None = None
    eval_run_after: str | None = None
    decided_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# SystemEfficiencyV1
# ---------------------------------------------------------------------------


class SystemEfficiencyV1(BaseModel):
    """System efficiency metrics tracked across eval runs.

    Operational metrics for production readiness assessment.
    """

    total_tokens: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
    latency_per_stage: dict[str, float] = Field(default_factory=dict)
    cost_estimate_usd: float = 0.0
    tool_calls_total: int = 0
    tool_calls_useful: int = 0
    retrieval_total: int = 0
    retrieval_relevant: int = 0
    context_utilization: float = 0.0
    redundancy_rate: float = 0.0
