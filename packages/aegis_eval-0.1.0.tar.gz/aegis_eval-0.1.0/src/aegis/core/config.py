"""Aegis configuration management."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, Field


class AgentConfig(BaseModel):
    """Agent connection configuration."""

    type: str = "rest"  # langchain, llamaindex, openai, anthropic, rest, custom
    config: dict[str, Any] = Field(default_factory=dict)


class ScoringConfig(BaseModel):
    """Scoring pipeline configuration."""

    programmatic: bool = True
    semantic: bool = True
    llm_judge: LLMJudgeConfig | None = None


class LLMJudgeConfig(BaseModel):
    """LLM-as-judge configuration."""

    model: str = "gpt-4o"
    provider: str = ""  # auto-detect from model name when empty
    rubric: str = "default"
    temperature: float = 0.0
    max_tokens: int = 2048


class ScenarioConfig(BaseModel):
    """Scenario generation configuration."""

    count: int = 200
    difficulty: str = "adaptive"  # or "fixed"
    fixed_level: int | None = None
    source: str = "generated"  # or path to custom test cases


class OutputConfig(BaseModel):
    """Output configuration."""

    formats: list[str] = Field(default_factory=lambda: ["json"])
    path: str = "./results/"
    include_traces: bool = True
    include_diagnostic: bool = True

    def __init__(self, **data: Any) -> None:
        # Accept ``format`` as an alias for ``formats`` (used in YAML configs).
        if "format" in data and "formats" not in data:
            fmt = data.pop("format")
            data["formats"] = fmt if isinstance(fmt, list) else [fmt]
        super().__init__(**data)


class CIConfig(BaseModel):
    """CI/CD gate configuration."""

    fail_under: float = 0.75
    fail_dimensions: dict[str, float] = Field(default_factory=dict)


class AegisConfig(BaseModel):
    """Top-level Aegis configuration (eval.yaml)."""

    agent: AgentConfig = Field(default_factory=AgentConfig)
    dimensions: list[str] | str = "all"
    domain_plugins: list[dict[str, Any] | str] = Field(default_factory=list)
    scoring: ScoringConfig = Field(default_factory=ScoringConfig)
    scenarios: ScenarioConfig = Field(default_factory=ScenarioConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    ci: CIConfig = Field(default_factory=CIConfig)

    @classmethod
    def from_yaml(cls, path: str | Path) -> AegisConfig:
        """Load configuration from a YAML file.

        Supports both flat configs (fields at the top level) and configs
        where eval settings are nested under an ``eval:`` key (as used
        in ``examples/eval.yaml``).
        """
        with open(path) as f:
            data = yaml.safe_load(f)
        if not data:
            return cls()
        # If the YAML uses an ``eval:`` top-level key, lift those values up.
        if "eval" in data and isinstance(data["eval"], dict):
            merged = dict(data["eval"])
            # Preserve top-level keys that live outside ``eval:`` (e.g. ``ci:``).
            for key in data:
                if key != "eval":
                    merged[key] = data[key]
            data = merged
        return cls.model_validate(data)


# Rebuild forward refs
ScoringConfig.model_rebuild()
