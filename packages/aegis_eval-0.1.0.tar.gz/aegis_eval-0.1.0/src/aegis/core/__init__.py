"""Core types and configuration for Aegis.

Re-exports the top-level config models, V1 schema types, and key enums.
"""

from aegis.core.config import AegisConfig, AgentConfig
from aegis.core.types import (
    EvalCaseV1,
    EvalTier,
    JudgePacketV1,
    MemoryEventV1,
    MemoryOperation,
    MemoryTier,
    PromotionDecisionV1,
    PromotionStatus,
    RetrievalTraceV1,
    RewardTraceV1,
    ScorerType,
    StepKind,
    TrajectoryV1,
)

__all__ = [
    # Config
    "AegisConfig",
    "AgentConfig",
    # V1 types
    "TrajectoryV1",
    "MemoryEventV1",
    "RetrievalTraceV1",
    "RewardTraceV1",
    "EvalCaseV1",
    "JudgePacketV1",
    "PromotionDecisionV1",
    # Enums
    "EvalTier",
    "MemoryOperation",
    "MemoryTier",
    "ScorerType",
    "PromotionStatus",
    "StepKind",
]
