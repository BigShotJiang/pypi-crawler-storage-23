"""Aegis Arena — agent submission, evaluation, and leaderboard system.

Re-exports the submission manager, leaderboard, and supporting data classes.
"""

from aegis.arena.leaderboard import (
    Leaderboard,
    LeaderboardEntry,
    RankingConfig,
)
from aegis.arena.submission import (
    AgentSubmission,
    SubmissionManager,
    SubmissionStatus,
)

__all__ = [
    "SubmissionStatus",
    "AgentSubmission",
    "SubmissionManager",
    "LeaderboardEntry",
    "RankingConfig",
    "Leaderboard",
]
