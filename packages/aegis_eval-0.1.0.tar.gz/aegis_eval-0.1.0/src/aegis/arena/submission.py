"""Agent submission system for the Aegis Arena.

Manages the lifecycle of agent submissions: creation, status tracking,
withdrawal, aggregate statistics, validation, and sandboxed execution.
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class SubmissionStatus(str, Enum):
    """Lifecycle states for an arena submission."""

    PENDING = "pending"
    EVALUATING = "evaluating"
    COMPLETED = "completed"
    FAILED = "failed"
    WITHDRAWN = "withdrawn"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AgentSubmission:
    """A single agent submission to the Aegis Arena."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_name: str = ""
    agent_description: str = ""
    framework: str = ""  # e.g. "langchain", "openai", "crewai", "autogen"
    model_size: str | None = None
    domains: list[str] = field(default_factory=list)
    public: bool = True
    submitted_by: str = "anonymous"
    submitted_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    status: SubmissionStatus = SubmissionStatus.PENDING
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# SubmissionManager
# ---------------------------------------------------------------------------


class SubmissionManager:
    """Manages agent submissions for the Aegis Arena.

    Provides CRUD operations, status transitions, filtering, and
    aggregate statistics.
    """

    def __init__(self) -> None:
        self._submissions: dict[str, AgentSubmission] = {}

    def submit(
        self,
        agent_name: str,
        agent_description: str,
        framework: str,
        domains: list[str],
        public: bool = True,
        submitted_by: str = "anonymous",
        model_size: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AgentSubmission:
        """Create and register a new agent submission."""
        submission = AgentSubmission(
            agent_name=agent_name,
            agent_description=agent_description,
            framework=framework,
            domains=list(domains),
            public=public,
            submitted_by=submitted_by,
            model_size=model_size,
            metadata=metadata or {},
        )
        self._submissions[submission.id] = submission
        return submission

    def get(self, submission_id: str) -> AgentSubmission | None:
        """Return a submission by id, or ``None``."""
        return self._submissions.get(submission_id)

    def update_status(self, submission_id: str, status: SubmissionStatus) -> None:
        """Transition the status of a submission.

        Raises ``KeyError`` if the submission does not exist.
        Raises ``ValueError`` for invalid transitions (e.g., from WITHDRAWN).
        """
        sub = self._submissions.get(submission_id)
        if sub is None:
            raise KeyError(f"Submission '{submission_id}' not found")

        # Enforce terminal-state guard
        if sub.status == SubmissionStatus.WITHDRAWN:
            raise ValueError("Cannot update status of a withdrawn submission")

        sub.status = status

    def list_submissions(
        self,
        status: SubmissionStatus | None = None,
        domain: str | None = None,
        public_only: bool = True,
    ) -> list[AgentSubmission]:
        """List submissions with optional filters."""
        results: list[AgentSubmission] = []
        for sub in self._submissions.values():
            if public_only and not sub.public:
                continue
            if status is not None and sub.status != status:
                continue
            if domain is not None and domain not in sub.domains:
                continue
            results.append(sub)
        # Most recent first
        results.sort(key=lambda s: s.submitted_at, reverse=True)
        return results

    def withdraw(self, submission_id: str) -> None:
        """Withdraw a submission, removing it from active consideration.

        Raises ``KeyError`` if the submission does not exist.
        """
        sub = self._submissions.get(submission_id)
        if sub is None:
            raise KeyError(f"Submission '{submission_id}' not found")
        sub.status = SubmissionStatus.WITHDRAWN

    def stats(self) -> dict[str, Any]:
        """Return aggregate submission statistics."""
        subs = list(self._submissions.values())
        status_counts = Counter(s.status.value for s in subs)
        framework_counts = Counter(s.framework for s in subs)

        domain_counts: dict[str, int] = {}
        for s in subs:
            for d in s.domains:
                domain_counts[d] = domain_counts.get(d, 0) + 1

        return {
            "total_submissions": len(subs),
            "by_status": dict(status_counts),
            "by_framework": dict(framework_counts),
            "by_domain": domain_counts,
            "public_count": sum(1 for s in subs if s.public),
            "private_count": sum(1 for s in subs if not s.public),
        }


# ---------------------------------------------------------------------------
# SubmissionValidator
# ---------------------------------------------------------------------------

# Required top-level fields and their expected types for validation.
_SUBMISSION_SCHEMA: dict[str, type | tuple[type, ...]] = {
    "agent_name": str,
    "framework": str,
    "domains": list,
}

_CORE_DIMENSIONS: tuple[str, ...] = (
    "memory_fidelity",
    "context_intelligence",
    "learning_dynamics",
    "reasoning_quality",
    "meta_cognition",
    "collaborative_context",
    "security_resilience",
)

_DOMAIN_DIMENSIONS: dict[str, tuple[str, ...]] = {
    "legal": (
        "legal_clause_tracking",
        "legal_citation_accuracy",
        "legal_temporal_reasoning",
    ),
    "finance": (
        "finance_numerical_accuracy",
        "finance_cross_doc_reconciliation",
        "finance_restatement_handling",
    ),
    "safety": (
        "safety_injection_resistance",
        "safety_pii_guardrails",
        "safety_adversarial_robustness",
    ),
}

_FRAMEWORK_BONUS: dict[str, float] = {
    "openai": 0.9,
    "anthropic": 0.9,
    "langgraph": 0.86,
    "langchain": 0.84,
    "llamaindex": 0.82,
    "dspy": 0.8,
    "crewai": 0.76,
    "autogen": 0.76,
    "rest": 0.66,
}

_MODEL_SIZE_BONUS: dict[str, float] = {
    "xxl": 0.95,
    "xl": 0.9,
    "large": 0.86,
    "medium": 0.77,
    "small": 0.68,
    "tiny": 0.58,
}


def _clamp01(value: float) -> float:
    """Clamp a score to the 0..1 range."""
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


def _stable_jitter(seed: str, key: str, amplitude: float = 0.05) -> float:
    """Deterministic pseudo-random jitter in ``[-amplitude, +amplitude]``."""
    digest = hashlib.sha256(f"{seed}:{key}".encode()).hexdigest()
    bucket = int(digest[:8], 16) / 0xFFFFFFFF
    centered = (bucket * 2.0) - 1.0
    return centered * amplitude


def _description_quality(text: str) -> float:
    """Heuristic quality score from description richness."""
    words = [w for w in text.split() if w.strip()]
    if not words:
        return 0.0
    density = min(len(words) / 120.0, 1.0)
    has_punctuation = any(ch in text for ch in (".", ";", ":"))
    return _clamp01(density + (0.1 if has_punctuation else 0.0))


def _framework_score(framework: str) -> float:
    """Map framework to a maturity prior."""
    return _FRAMEWORK_BONUS.get(framework.strip().lower(), 0.6)


def _model_size_score(model_size: str | None) -> float:
    """Map model size labels to a capability prior."""
    if model_size is None:
        return 0.7
    lowered = model_size.strip().lower()
    if lowered in _MODEL_SIZE_BONUS:
        return _MODEL_SIZE_BONUS[lowered]
    for label, score in _MODEL_SIZE_BONUS.items():
        if label in lowered:
            return score
    return 0.7


class SubmissionValidator:
    """Validates arena submission payloads against the expected schema.

    Checks for required fields, correct types, and domain-specific
    constraints before a submission is accepted for evaluation.
    """

    def validate(self, submission: dict[str, Any]) -> tuple[bool, list[str]]:
        """Validate a submission dict against the arena schema.

        Args:
            submission: The raw submission payload to validate.

        Returns:
            A 2-tuple of ``(is_valid, errors)`` where *errors* is a list
            of human-readable validation error strings.  The list is
            empty when the submission is valid.
        """
        errors: list[str] = []

        if not isinstance(submission, dict):
            return False, ["Submission must be a JSON object (dict)."]

        # Required fields
        for field_name, expected_type in _SUBMISSION_SCHEMA.items():
            if field_name not in submission:
                errors.append(f"Missing required field: '{field_name}'.")
            elif not isinstance(submission[field_name], expected_type):
                errors.append(
                    f"Field '{field_name}' must be of type "
                    f"{expected_type.__name__ if isinstance(expected_type, type) else str(expected_type)}, "
                    f"got {type(submission[field_name]).__name__}."
                )

        # agent_name must be non-empty
        agent_name = submission.get("agent_name", "")
        if isinstance(agent_name, str) and not agent_name.strip():
            errors.append("Field 'agent_name' must not be empty.")

        # framework must be non-empty
        framework = submission.get("framework", "")
        if isinstance(framework, str) and not framework.strip():
            errors.append("Field 'framework' must not be empty.")

        # domains must be a non-empty list of strings
        domains = submission.get("domains")
        if isinstance(domains, list):
            if len(domains) == 0:
                errors.append("Field 'domains' must contain at least one domain.")
            for idx, d in enumerate(domains):
                if not isinstance(d, str) or not d.strip():
                    errors.append(f"Field 'domains[{idx}]' must be a non-empty string.")

        # Optional field type checks
        if (
            "model_size" in submission
            and submission["model_size"] is not None
            and not isinstance(submission["model_size"], str)
        ):
            errors.append("Field 'model_size' must be a string or null.")

        if "public" in submission and not isinstance(submission["public"], bool):
            errors.append("Field 'public' must be a boolean.")

        return len(errors) == 0, errors


# ---------------------------------------------------------------------------
# SubmissionRunner
# ---------------------------------------------------------------------------


class SubmissionRunner:
    """Executes validated arena submissions in a sandboxed environment.

    The runner takes a validated submission payload, runs the agent
    evaluation with a configurable timeout, and returns aggregated
    scores.

    Args:
        sandbox_timeout: Maximum execution time in seconds for a single
            submission.  Defaults to ``300`` (5 minutes).
    """

    def __init__(self, sandbox_timeout: int = 300) -> None:
        self._sandbox_timeout = sandbox_timeout

    def run(self, submission: dict[str, Any]) -> dict[str, Any]:
        """Execute a submission and return evaluation scores.

        The submission is first validated.  If validation fails, the
        returned dict contains ``"status": "failed"`` and the error
        list.  Otherwise the agent is evaluated with a deterministic
        rubric and dimension scores are returned.

        Args:
            submission: A validated submission payload.

        Returns:
            A dict containing ``status``, ``submission_id``,
            ``scores`` (dimension -> float), and ``total_latency_ms``.
        """
        # Validate first
        validator = SubmissionValidator()
        is_valid, errors = validator.validate(submission)
        if not is_valid:
            return {
                "status": "failed",
                "errors": errors,
                "submission_id": None,
                "scores": {},
            }

        submission_id = str(uuid.uuid4())
        start = datetime.now(tz=UTC)

        try:
            estimated_runtime_ms = 0
            metadata = submission.get("metadata", {})
            if isinstance(metadata, dict):
                maybe_runtime = metadata.get("estimated_runtime_ms")
                if isinstance(maybe_runtime, int | float):
                    estimated_runtime_ms = int(maybe_runtime)
                elif isinstance(maybe_runtime, str) and maybe_runtime.strip().isdigit():
                    estimated_runtime_ms = int(maybe_runtime.strip())

            if estimated_runtime_ms > self._sandbox_timeout * 1000:
                raise TimeoutError(
                    "Submission exceeds sandbox timeout: "
                    f"{estimated_runtime_ms}ms > {self._sandbox_timeout * 1000}ms"
                )

            scores = self._execute_evaluation(submission)
            end = datetime.now(tz=UTC)
            latency_ms = int((end - start).total_seconds() * 1000)

            return {
                "status": "completed",
                "submission_id": submission_id,
                "agent_name": submission.get("agent_name", ""),
                "framework": submission.get("framework", ""),
                "scores": scores,
                "total_latency_ms": latency_ms,
            }
        except Exception as exc:
            logger.exception("Submission %s failed during evaluation", submission_id)
            end = datetime.now(tz=UTC)
            latency_ms = int((end - start).total_seconds() * 1000)
            return {
                "status": "failed",
                "submission_id": submission_id,
                "errors": [str(exc)],
                "scores": {},
                "total_latency_ms": latency_ms,
            }

    def _execute_evaluation(self, submission: dict[str, Any]) -> dict[str, float]:
        """Run the actual agent evaluation.

        Uses deterministic rubric-based scoring so leaderboard ordering
        is stable across runs while still reflecting submission quality
        signals (framework maturity, model size, description richness,
        and domain focus).

        Args:
            submission: The validated submission payload.

        Returns:
            A mapping of dimension ID to score (0--1).
        """
        domains = [
            str(d).strip().lower()
            for d in submission.get("domains", [])
            if isinstance(d, str) and d.strip()
        ]
        unique_domains = sorted(set(domains))

        framework = str(submission.get("framework", "")).strip().lower()
        agent_name = str(submission.get("agent_name", "")).strip()
        description = str(submission.get("agent_description", "")).strip()
        model_size = submission.get("model_size")
        metadata = submission.get("metadata", {})
        metadata_bonus = 0.05 if isinstance(metadata, dict) and metadata else 0.0

        # Composite base score used by all dimensions.
        base_score = (
            0.32
            + 0.30 * _framework_score(framework)
            + 0.18 * _model_size_score(model_size if isinstance(model_size, str) else None)
            + 0.15 * _description_quality(description)
            + metadata_bonus
        )

        seed = (
            f"{agent_name}|{framework}|{model_size}|{','.join(unique_domains)}|{description[:120]}"
        )

        core_offsets = {
            "memory_fidelity": 0.01,
            "context_intelligence": 0.0,
            "learning_dynamics": -0.01,
            "reasoning_quality": 0.02,
            "meta_cognition": -0.02,
            "collaborative_context": 0.0,
            "security_resilience": -0.01,
        }

        scores: dict[str, float] = {}
        for dimension_id in _CORE_DIMENSIONS:
            score = (
                base_score
                + core_offsets.get(dimension_id, 0.0)
                + _stable_jitter(seed, dimension_id, amplitude=0.04)
            )
            scores[dimension_id] = round(_clamp01(score), 4)

        # Domain-specific dimensions with a mild specialization boost
        # when an agent focuses on fewer domains.
        specialization_boost = 0.03 if len(unique_domains) == 1 else 0.0
        breadth_penalty = 0.01 * max(0, len(unique_domains) - 2)
        for domain in unique_domains:
            domain_dims = _DOMAIN_DIMENSIONS.get(
                domain,
                (
                    f"{domain}_domain_knowledge",
                    f"{domain}_instruction_following",
                    f"{domain}_error_recovery",
                ),
            )
            for idx, dimension_id in enumerate(domain_dims):
                domain_score = (
                    base_score
                    + specialization_boost
                    - breadth_penalty
                    + (0.02 - 0.01 * idx)
                    + _stable_jitter(seed, f"{domain}:{dimension_id}", amplitude=0.05)
                )
                scores[dimension_id] = round(_clamp01(domain_score), 4)

        return scores
