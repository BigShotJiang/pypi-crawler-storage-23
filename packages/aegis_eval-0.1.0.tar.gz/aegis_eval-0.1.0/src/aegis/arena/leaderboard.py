"""Ranking and leaderboard system for the Aegis Arena.

Tracks evaluation results, computes rankings across multiple axes
(overall, per-domain, per-dimension, cost-efficiency), provides
comparison and trend analysis, and supports ELO-based head-to-head
ratings.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class LeaderboardEntry:
    """A single entry on the arena leaderboard."""

    submission_id: str = ""
    agent_name: str = ""
    framework: str = ""
    overall_score: float = 0.0
    dimension_scores: dict[str, float] = field(default_factory=dict)
    domain_scores: dict[str, float] = field(default_factory=dict)
    model_size: str | None = None
    compute_cost_estimate: float | None = None
    eval_timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    rank: int = 0


@dataclass
class RankingConfig:
    """Configuration for ranking computation."""

    sort_by: str = "overall"  # "overall" | "domain" | "dimension" | "aggregate"
    domain_filter: str | None = None
    model_size_filter: str | None = None
    min_dimensions: int = 5


# ---------------------------------------------------------------------------
# ELO Rating System
# ---------------------------------------------------------------------------


class ELORating:
    """ELO rating system for head-to-head agent comparisons.

    Maintains ratings for agents and updates them after pairwise
    match outcomes using the standard ELO formula.

    Args:
        k_factor: The K-factor controlling rating volatility.
            Higher values mean ratings change more after each match.
            Defaults to ``32``.
        default_rating: The initial rating assigned to new agents.
            Defaults to ``1500``.
    """

    def __init__(self, k_factor: float = 32, default_rating: float = 1500) -> None:
        self._k_factor = k_factor
        self._default_rating = default_rating
        self._ratings: dict[str, float] = {}
        self._wins: dict[str, int] = {}
        self._losses: dict[str, int] = {}
        self._matches: dict[str, int] = {}

    def _ensure_agent(self, agent_id: str) -> None:
        """Register an agent with default stats if not already tracked."""
        if agent_id not in self._ratings:
            self._ratings[agent_id] = self._default_rating
            self._wins[agent_id] = 0
            self._losses[agent_id] = 0
            self._matches[agent_id] = 0

    def _expected_score(self, rating_a: float, rating_b: float) -> float:
        """Compute the expected score of player A against player B."""
        return 1.0 / (1.0 + math.pow(10, (rating_b - rating_a) / 400.0))

    def update(self, winner_id: str, loser_id: str) -> None:
        """Update ratings after a head-to-head match.

        Args:
            winner_id: The agent that won the comparison.
            loser_id: The agent that lost the comparison.
        """
        self._ensure_agent(winner_id)
        self._ensure_agent(loser_id)

        expected_winner = self._expected_score(self._ratings[winner_id], self._ratings[loser_id])
        expected_loser = self._expected_score(self._ratings[loser_id], self._ratings[winner_id])

        self._ratings[winner_id] += self._k_factor * (1.0 - expected_winner)
        self._ratings[loser_id] += self._k_factor * (0.0 - expected_loser)

        self._wins[winner_id] += 1
        self._losses[loser_id] += 1
        self._matches[winner_id] += 1
        self._matches[loser_id] += 1

    def get_rating(self, agent_id: str) -> float:
        """Return the current ELO rating for an agent.

        Returns the default rating if the agent has not been seen.
        """
        return self._ratings.get(agent_id, self._default_rating)

    def get_rankings(self) -> list[dict[str, Any]]:
        """Return all agents sorted by ELO rating (descending).

        Each entry includes ``agent_id``, ``rating``, ``wins``,
        ``losses``, and ``matches``.
        """
        rankings: list[dict[str, Any]] = []
        for agent_id in self._ratings:
            rankings.append(
                {
                    "agent_id": agent_id,
                    "rating": round(self._ratings[agent_id], 2),
                    "wins": self._wins.get(agent_id, 0),
                    "losses": self._losses.get(agent_id, 0),
                    "matches": self._matches.get(agent_id, 0),
                }
            )
        rankings.sort(key=lambda r: r["rating"], reverse=True)
        return rankings


# ---------------------------------------------------------------------------
# Leaderboard
# ---------------------------------------------------------------------------


class Leaderboard:
    """Arena leaderboard with multi-axis ranking, comparison, and trends.

    Stores evaluation results and computes on-the-fly rankings with
    support for domain, dimension, and cost-efficiency views.  Also
    provides a convenience method for submitting dimension scores and
    looking up per-agent detail.
    """

    def __init__(self) -> None:
        self._entries: dict[str, LeaderboardEntry] = {}
        # History tracks score snapshots over time for trend analysis
        self._history: list[dict[str, Any]] = []
        # Per-agent dimension score accumulator (keyed by agent_id)
        self._agent_scores: dict[str, dict[str, float]] = {}

    # -- Core operations ----------------------------------------------------

    def add_result(
        self,
        submission_id: str,
        agent_name: str,
        framework: str,
        scores: dict[str, Any],
        model_size: str | None = None,
        compute_cost: float | None = None,
    ) -> LeaderboardEntry:
        """Add or update evaluation results for a submission.

        *scores* should contain ``"overall"`` (float), and optionally
        ``"dimensions"`` (dict[str, float]) and ``"domains"`` (dict[str, float]).
        """
        overall = float(scores.get("overall", 0.0))
        dimension_scores: dict[str, float] = scores.get("dimensions", {})
        domain_scores: dict[str, float] = scores.get("domains", {})

        entry = LeaderboardEntry(
            submission_id=submission_id,
            agent_name=agent_name,
            framework=framework,
            overall_score=overall,
            dimension_scores=dict(dimension_scores),
            domain_scores=dict(domain_scores),
            model_size=model_size,
            compute_cost_estimate=compute_cost,
        )

        # Record history snapshot before overwriting
        prev = self._entries.get(submission_id)
        if prev is not None:
            self._history.append(
                {
                    "submission_id": submission_id,
                    "previous_score": prev.overall_score,
                    "new_score": overall,
                    "delta": round(overall - prev.overall_score, 4),
                    "timestamp": datetime.now(tz=UTC).isoformat(),
                }
            )
        else:
            self._history.append(
                {
                    "submission_id": submission_id,
                    "previous_score": None,
                    "new_score": overall,
                    "delta": 0.0,
                    "timestamp": datetime.now(tz=UTC).isoformat(),
                }
            )

        self._entries[submission_id] = entry

        # Update agent-level score tracking
        self._agent_scores[submission_id] = dict(dimension_scores)

        return entry

    def submit_result(self, agent_id: str, dimension_scores: dict[str, float]) -> None:
        """Record evaluation results for an agent using dimension scores.

        Computes the aggregate (mean of dimension scores) automatically
        and stores the dimension breakdown for later retrieval via
        :meth:`get_agent_details`.

        Args:
            agent_id: Unique identifier for the agent.
            dimension_scores: Mapping of dimension ID to score (0--1).
        """
        self._agent_scores[agent_id] = dict(dimension_scores)

        aggregate = (
            sum(dimension_scores.values()) / len(dimension_scores) if dimension_scores else 0.0
        )

        scores: dict[str, Any] = {
            "overall": aggregate,
            "dimensions": dimension_scores,
        }

        # Use agent_id as submission_id for convenience
        self.add_result(
            submission_id=agent_id,
            agent_name=agent_id,
            framework="",
            scores=scores,
        )

    # -- Ranking ------------------------------------------------------------

    def rank(self, config: RankingConfig | None = None) -> list[LeaderboardEntry]:
        """Return a ranked leaderboard.

        Supports filtering by domain, model size, and minimum dimension
        coverage.
        """
        cfg = config or RankingConfig()
        entries = list(self._entries.values())

        # Filters
        if cfg.domain_filter is not None:
            entries = [e for e in entries if cfg.domain_filter in e.domain_scores]

        if cfg.model_size_filter is not None:
            entries = [e for e in entries if e.model_size == cfg.model_size_filter]

        if cfg.min_dimensions > 0:
            entries = [e for e in entries if len(e.dimension_scores) >= cfg.min_dimensions]

        # Sort
        if cfg.sort_by == "domain" and cfg.domain_filter:
            domain = cfg.domain_filter
            entries.sort(
                key=lambda e: e.domain_scores.get(domain, 0.0),
                reverse=True,
            )
        elif cfg.sort_by == "dimension":
            # sort by average dimension score
            entries.sort(
                key=lambda e: (
                    sum(e.dimension_scores.values()) / len(e.dimension_scores)
                    if e.dimension_scores
                    else 0.0
                ),
                reverse=True,
            )
        else:
            # "overall" and "aggregate" both sort by overall_score
            entries.sort(key=lambda e: e.overall_score, reverse=True)

        # Assign ranks
        for idx, entry in enumerate(entries, start=1):
            entry.rank = idx

        return entries

    def get_leaderboard(self, sort_by: str = "aggregate") -> list[dict[str, Any]]:
        """Return ranked agents with scores as plain dicts.

        This is a convenience wrapper around :meth:`rank` that returns
        serialisable dictionaries rather than dataclass instances.

        Args:
            sort_by: Ranking axis -- ``"aggregate"``, ``"overall"``,
                ``"domain"``, or ``"dimension"``.
        """
        cfg = RankingConfig(sort_by=sort_by, min_dimensions=0)
        ranked = self.rank(config=cfg)
        return [
            {
                "agent_id": e.submission_id,
                "agent_name": e.agent_name,
                "framework": e.framework,
                "overall_score": round(e.overall_score, 4),
                "dimension_scores": e.dimension_scores,
                "rank": e.rank,
            }
            for e in ranked
        ]

    def get_agent_details(self, agent_id: str) -> dict[str, Any]:
        """Return detailed dimension breakdown for an agent.

        Args:
            agent_id: The agent (or submission) identifier.

        Returns:
            A dict with ``agent_id``, ``overall_score``,
            ``dimension_scores``, and ``rank``.  Returns an error dict
            if the agent is not found.
        """
        entry = self._entries.get(agent_id)
        if entry is None:
            return {"error": f"Agent '{agent_id}' not found"}

        # Get the rank by running a full ranking pass
        ranked = self.rank(config=RankingConfig(min_dimensions=0))
        agent_rank = 0
        for e in ranked:
            if e.submission_id == agent_id:
                agent_rank = e.rank
                break

        return {
            "agent_id": agent_id,
            "agent_name": entry.agent_name,
            "framework": entry.framework,
            "overall_score": round(entry.overall_score, 4),
            "dimension_scores": entry.dimension_scores,
            "domain_scores": entry.domain_scores,
            "model_size": entry.model_size,
            "compute_cost_estimate": entry.compute_cost_estimate,
            "rank": agent_rank,
            "eval_timestamp": entry.eval_timestamp.isoformat(),
        }

    def rank_by_dimension(self, dimension_id: str) -> list[LeaderboardEntry]:
        """Rank entries by score on a specific dimension."""
        entries = [e for e in self._entries.values() if dimension_id in e.dimension_scores]
        entries.sort(
            key=lambda e: e.dimension_scores.get(dimension_id, 0.0),
            reverse=True,
        )
        for idx, entry in enumerate(entries, start=1):
            entry.rank = idx
        return entries

    def rank_by_cost_efficiency(self) -> list[LeaderboardEntry]:
        """Rank entries by score-to-cost ratio.

        Entries without a compute cost estimate are excluded.
        """
        entries = [
            e
            for e in self._entries.values()
            if e.compute_cost_estimate is not None and e.compute_cost_estimate > 0
        ]
        entries.sort(
            key=lambda e: e.overall_score / (e.compute_cost_estimate or 1.0),
            reverse=True,
        )
        for idx, entry in enumerate(entries, start=1):
            entry.rank = idx
        return entries

    # -- Lookup -------------------------------------------------------------

    def get_entry(self, submission_id: str) -> LeaderboardEntry | None:
        """Return the leaderboard entry for a submission, or ``None``."""
        return self._entries.get(submission_id)

    # -- Comparison ---------------------------------------------------------

    def compare(
        self,
        submission_a: str,
        submission_b: str,
    ) -> dict[str, Any]:
        """Head-to-head comparison between two submissions.

        Returns overall and per-dimension deltas, plus a winner.
        """
        a = self._entries.get(submission_a)
        b = self._entries.get(submission_b)

        if a is None or b is None:
            missing = []
            if a is None:
                missing.append(submission_a)
            if b is None:
                missing.append(submission_b)
            return {"error": f"Submissions not found: {', '.join(missing)}"}

        # Dimension-level comparison
        all_dims = sorted(set(a.dimension_scores.keys()) | set(b.dimension_scores.keys()))
        dimension_deltas: dict[str, dict[str, Any]] = {}
        a_wins = 0
        b_wins = 0
        for dim in all_dims:
            score_a = a.dimension_scores.get(dim, 0.0)
            score_b = b.dimension_scores.get(dim, 0.0)
            delta = round(score_a - score_b, 4)
            if delta > 0:
                a_wins += 1
            elif delta < 0:
                b_wins += 1
            dimension_deltas[dim] = {
                "a": round(score_a, 4),
                "b": round(score_b, 4),
                "delta": delta,
                "winner": a.agent_name if delta > 0 else (b.agent_name if delta < 0 else "tie"),
            }

        overall_delta = round(a.overall_score - b.overall_score, 4)
        if overall_delta > 0:
            overall_winner = a.agent_name
        elif overall_delta < 0:
            overall_winner = b.agent_name
        else:
            overall_winner = "tie"

        return {
            "a": {"submission_id": a.submission_id, "agent_name": a.agent_name},
            "b": {"submission_id": b.submission_id, "agent_name": b.agent_name},
            "overall": {
                "a": round(a.overall_score, 4),
                "b": round(b.overall_score, 4),
                "delta": overall_delta,
                "winner": overall_winner,
            },
            "dimensions": dimension_deltas,
            "dimension_wins": {"a": a_wins, "b": b_wins},
        }

    # -- Trends -------------------------------------------------------------

    def trending(self, period_days: int = 7) -> list[dict[str, Any]]:
        """Return the biggest score improvements in the given period."""
        cutoff = datetime.now(tz=UTC) - timedelta(days=period_days)
        recent: list[dict[str, Any]] = []

        for h in self._history:
            ts = datetime.fromisoformat(h["timestamp"])
            if ts >= cutoff and h["previous_score"] is not None:
                recent.append(h)

        # Sort by largest positive delta
        recent.sort(key=lambda h: h["delta"], reverse=True)
        return recent

    # -- Domain leaders -----------------------------------------------------

    def domain_leaders(self, domain: str) -> list[LeaderboardEntry]:
        """Return entries ranked by score in a specific domain."""
        entries = [e for e in self._entries.values() if domain in e.domain_scores]
        entries.sort(
            key=lambda e: e.domain_scores.get(domain, 0.0),
            reverse=True,
        )
        for idx, entry in enumerate(entries, start=1):
            entry.rank = idx
        return entries

    # -- Stats & Export -----------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return aggregate leaderboard statistics."""
        entries = list(self._entries.values())
        if not entries:
            return {"total_entries": 0}

        scores = [e.overall_score for e in entries]
        mean_score = sum(scores) / len(scores)

        # Top by domain
        domain_tops: dict[str, dict[str, Any]] = {}
        all_domains: set[str] = set()
        for e in entries:
            all_domains.update(e.domain_scores.keys())
        for domain in sorted(all_domains):
            best = max(entries, key=lambda e: e.domain_scores.get(domain, 0.0))
            domain_tops[domain] = {
                "agent_name": best.agent_name,
                "score": round(best.domain_scores.get(domain, 0.0), 4),
            }

        # Framework distribution
        fw_counts: dict[str, int] = {}
        for e in entries:
            fw_counts[e.framework] = fw_counts.get(e.framework, 0) + 1

        return {
            "total_entries": len(entries),
            "mean_score": round(mean_score, 4),
            "min_score": round(min(scores), 4),
            "max_score": round(max(scores), 4),
            "score_std": round(_std(scores), 4),
            "top_by_domain": domain_tops,
            "by_framework": fw_counts,
        }

    def export(self, format: str = "json") -> dict[str, Any] | str:
        """Export the leaderboard.

        Supported formats: ``"json"`` (returns dict), ``"csv"`` (returns string).
        """
        ranked = self.rank()
        rows = [
            {
                "rank": e.rank,
                "submission_id": e.submission_id,
                "agent_name": e.agent_name,
                "framework": e.framework,
                "overall_score": round(e.overall_score, 4),
                "model_size": e.model_size,
                "compute_cost_estimate": e.compute_cost_estimate,
                "dimension_count": len(e.dimension_scores),
                "domain_count": len(e.domain_scores),
                "eval_timestamp": e.eval_timestamp.isoformat(),
            }
            for e in ranked
        ]

        if format == "csv":
            if not rows:
                return ""
            header = ",".join(rows[0].keys())
            lines = [header]
            for row in rows:
                lines.append(",".join(str(v) for v in row.values()))
            return "\n".join(lines)

        return {"leaderboard": rows, "exported_at": datetime.now(tz=UTC).isoformat()}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _std(values: list[float]) -> float:
    """Compute population standard deviation."""
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((v - mean) ** 2 for v in values) / len(values)
    return float(variance**0.5)
