"""Docling-powered document parser for PDF, DOCX, XLSX, and PPTX files.

Integrates with the `docling` library for high-fidelity document conversion
including table extraction, layout analysis, and OCR.  Falls back to basic
text extraction when docling is not installed.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from aegis.ingestion.parsers import DocumentParser, Modality, ParsedChunk

logger = logging.getLogger(__name__)

try:
    from docling.document_converter import DocumentConverter  # type: ignore[import-not-found]

    _HAS_DOCLING = True
except ImportError:
    _HAS_DOCLING = False


class DoclingParser(DocumentParser):
    """Document parser using the Docling library.

    Supports PDF, DOCX, XLSX, and PPTX with features like:
    - Layout-aware text extraction
    - Table structure recognition
    - OCR for scanned documents
    - Image caption extraction

    Falls back to raw text extraction when docling is not available.

    Args:
        ocr_enabled: Whether to enable OCR for scanned pages.
    """

    def __init__(self, ocr_enabled: bool = True) -> None:
        self._ocr_enabled = ocr_enabled
        self._converter: Any | None = None

        if _HAS_DOCLING:
            self._converter = DocumentConverter()

    @property
    def supported_modalities(self) -> list[Modality]:
        return [Modality.DOCUMENT, Modality.TABLE]

    @property
    def supported_extensions(self) -> list[str]:
        return [".pdf", ".docx", ".xlsx", ".pptx"]

    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        path = Path(source)

        if self._converter is not None:
            return self._parse_with_docling(path)

        return self._parse_fallback(path, content)

    def _parse_with_docling(self, path: Path) -> list[ParsedChunk]:
        """Parse using the Docling converter."""
        converter = self._converter
        if converter is None:
            return self._parse_fallback(path, content=None)

        result = converter.convert(str(path))
        doc = result.document

        chunks: list[ParsedChunk] = []
        chunk_idx = 0

        # Extract text content from document elements
        for item in doc.iterate_items():
            element = item[1] if isinstance(item, tuple) else item
            text = self._extract_text(element)
            if not text or len(text.strip()) < 5:
                continue

            modality = Modality.DOCUMENT
            metadata: dict[str, Any] = {"format": path.suffix.lstrip(".")}

            # Detect tables
            element_type = type(element).__name__.lower()
            if "table" in element_type:
                modality = Modality.TABLE
                metadata["element_type"] = "table"
            elif "heading" in element_type or "title" in element_type:
                metadata["element_type"] = "heading"
            else:
                metadata["element_type"] = "text"

            chunks.append(
                ParsedChunk(
                    content=text.strip(),
                    modality=modality,
                    source_path=str(path),
                    chunk_index=chunk_idx,
                    metadata=metadata,
                )
            )
            chunk_idx += 1

        if not chunks:
            # Fall back to markdown export
            md_text = doc.export_to_markdown()
            if md_text.strip():
                chunks.append(
                    ParsedChunk(
                        content=md_text.strip(),
                        modality=Modality.DOCUMENT,
                        source_path=str(path),
                        chunk_index=0,
                        metadata={"format": path.suffix.lstrip("."), "fallback": "markdown"},
                    )
                )

        return chunks

    def _parse_fallback(self, path: Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        """Basic fallback when docling is not available."""
        logger.warning(
            "Docling not installed; using basic text extraction for %s. "
            "Install with: pip install 'aegis-eval[ingestion]'",
            path.suffix,
        )

        if content is not None:
            text = (
                content.decode("utf-8", errors="replace") if isinstance(content, bytes) else content
            )
        elif path.exists():
            # For non-binary formats we can try reading directly
            if path.suffix in (".docx", ".pdf", ".xlsx", ".pptx"):
                return [
                    ParsedChunk(
                        content=f"[Binary file: {path.name} — install docling for full parsing]",
                        modality=Modality.DOCUMENT,
                        source_path=str(path),
                        chunk_index=0,
                        metadata={"format": path.suffix.lstrip("."), "fallback": True},
                        confidence=0.1,
                    )
                ]
            text = path.read_text(encoding="utf-8", errors="replace")
        else:
            return []

        return [
            ParsedChunk(
                content=text.strip(),
                modality=Modality.DOCUMENT,
                source_path=str(path),
                chunk_index=0,
                metadata={"format": path.suffix.lstrip("."), "fallback": True},
                confidence=0.5,
            )
        ]

    @staticmethod
    def _extract_text(element: Any) -> str:
        """Extract text from a docling document element."""
        if hasattr(element, "text"):
            return str(element.text)
        if hasattr(element, "export_to_markdown"):
            return str(element.export_to_markdown())
        return str(element)
