"""Browser automation client for JavaScript-rendered pages.

Extends :class:`WebIngester` with Playwright-based browser automation
for fetching dynamic (JS-rendered) web content, executing scripts,
waiting for selectors, and interacting with forms.

Playwright is an optional dependency — when unavailable the client
gracefully falls back to the parent :class:`WebIngester.fetch`.
"""

from __future__ import annotations

import asyncio
import logging
import warnings
from datetime import UTC, datetime
from typing import Any

from aegis.ingestion.web import WebIngester, WebPage, _extract_title

logger = logging.getLogger(__name__)

__all__ = [
    "BrowserAutomationClient",
]

# ---------------------------------------------------------------------------
# Optional dependency detection
# ---------------------------------------------------------------------------

_HAS_PLAYWRIGHT = False
try:
    from playwright.async_api import async_playwright  # type: ignore[import-not-found]

    _HAS_PLAYWRIGHT = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# BrowserAutomationClient
# ---------------------------------------------------------------------------


class BrowserAutomationClient(WebIngester):
    """Fetch and interact with JavaScript-rendered web pages.

    Uses Playwright for headless browser automation.  If Playwright is
    not installed, all browser-specific methods fall back to the parent
    :class:`WebIngester.fetch` with a warning.

    Inherits rate limiting and disk caching from :class:`WebIngester`.

    Args:
        browser_type: Browser engine — ``"chromium"``, ``"firefox"``, or ``"webkit"``.
        headless: Run the browser in headless mode.
        cache_dir: Directory for the disk cache.
        rate_limit_rpm: Maximum requests per minute.
    """

    def __init__(
        self,
        browser_type: str = "chromium",
        headless: bool = True,
        cache_dir: str = ".cache/browser",
        rate_limit_rpm: int = 30,
    ) -> None:
        super().__init__(cache_dir=cache_dir, rate_limit_rpm=rate_limit_rpm)
        self._browser_type = browser_type
        self._headless = headless
        self._playwright: Any = None
        self._browser: Any = None
        self._launched = False

    # -- lifecycle -----------------------------------------------------------

    async def _ensure_browser(self) -> None:
        """Lazily launch the browser on first use."""
        if self._launched:
            return

        if not _HAS_PLAYWRIGHT:
            return

        self._playwright = await async_playwright().start()
        launcher = getattr(self._playwright, self._browser_type, self._playwright.chromium)
        self._browser = await launcher.launch(headless=self._headless)
        self._launched = True

    async def _new_page(self) -> Any:
        """Create a new browser page (tab)."""
        await self._ensure_browser()
        if self._browser is None:
            return None
        return await self._browser.new_page()

    async def close(self) -> None:
        """Shut down the browser and Playwright instance.

        Safe to call multiple times.
        """
        if self._browser is not None:
            await self._browser.close()
            self._browser = None
        if self._playwright is not None:
            await self._playwright.stop()
            self._playwright = None
        self._launched = False

    # -- helpers -------------------------------------------------------------

    def _fallback_warning(self, method: str) -> None:
        """Issue a warning when falling back to non-browser fetch."""
        warnings.warn(
            f"Playwright not installed — {method}() falling back to "
            f"WebIngester.fetch(). Install with: pip install 'aegis-eval[browser]'",
            stacklevel=3,
        )

    def _make_page(self, url: str, html: str) -> WebPage:
        """Build a :class:`WebPage` from fetched HTML."""
        return WebPage(
            url=url,
            title=_extract_title(html),
            content=html,
            fetched_at=datetime.now(tz=UTC).isoformat(),
            metadata={"browser": True, "engine": self._browser_type},
        )

    # -- async API -----------------------------------------------------------

    async def fetch_dynamic(self, url: str, wait_time: int = 2000) -> WebPage:
        """Fetch a JavaScript-rendered page asynchronously.

        Navigates to the URL, waits for the network to settle plus an
        optional extra delay, then returns the rendered HTML.

        Args:
            url: The URL to fetch.
            wait_time: Extra wait time in milliseconds after load.

        Returns:
            A :class:`WebPage` with the fully-rendered HTML.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("fetch_dynamic")
            return self.fetch(url)

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return self.fetch(url)

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            if wait_time > 0:
                await page.wait_for_timeout(wait_time)
            html = await page.content()
            result = self._make_page(url, html)
            self._cache.put(url, html)
            return result
        finally:
            await page.close()

    async def execute_script(self, url: str, script: str) -> Any:
        """Navigate to a URL and execute JavaScript on the page.

        Args:
            url: The URL to navigate to.
            script: JavaScript code to execute via ``page.evaluate()``.

        Returns:
            The result of the JavaScript evaluation.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("execute_script")
            return None

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return None

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            return await page.evaluate(script)
        finally:
            await page.close()

    async def wait_for_selector(self, url: str, selector: str, timeout: int = 30_000) -> WebPage:
        """Navigate to a URL and wait for a CSS selector to appear.

        Args:
            url: The URL to navigate to.
            selector: CSS selector to wait for.
            timeout: Maximum wait time in milliseconds.

        Returns:
            A :class:`WebPage` captured after the selector is found.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("wait_for_selector")
            return self.fetch(url)

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return self.fetch(url)

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            await page.wait_for_selector(selector, timeout=timeout)
            html = await page.content()
            return self._make_page(url, html)
        finally:
            await page.close()

    async def take_screenshot(self, url: str, path: str, selector: str | None = None) -> str:
        """Navigate to a URL and capture a screenshot.

        Args:
            url: The URL to navigate to.
            path: File path for the screenshot image.
            selector: Optional CSS selector to screenshot a specific element.

        Returns:
            The file path of the saved screenshot.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("take_screenshot")
            return ""

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return ""

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            if selector:
                element = await page.query_selector(selector)
                if element:
                    await element.screenshot(path=path)
                else:
                    await page.screenshot(path=path)
            else:
                await page.screenshot(path=path)
            return path
        finally:
            await page.close()

    async def click(self, url: str, selector: str) -> WebPage:
        """Navigate to a URL, click an element, and return the updated page.

        Args:
            url: The URL to navigate to.
            selector: CSS selector of the element to click.

        Returns:
            A :class:`WebPage` captured after the click.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("click")
            return self.fetch(url)

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return self.fetch(url)

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            await page.click(selector)
            await page.wait_for_timeout(1000)
            html = await page.content()
            return self._make_page(url, html)
        finally:
            await page.close()

    async def fill_form(self, url: str, fields: dict[str, str]) -> WebPage:
        """Navigate to a URL and fill form fields by CSS selector.

        Args:
            url: The URL to navigate to.
            fields: Mapping of CSS selector to value to fill.

        Returns:
            A :class:`WebPage` captured after filling the form.
        """
        if not _HAS_PLAYWRIGHT:
            self._fallback_warning("fill_form")
            return self.fetch(url)

        self._limiter.wait()

        page = await self._new_page()
        if page is None:
            return self.fetch(url)

        try:
            await page.goto(url, wait_until="networkidle", timeout=60_000)
            for selector, value in fields.items():
                await page.fill(selector, value)
            html = await page.content()
            return self._make_page(url, html)
        finally:
            await page.close()

    # -- sync API (overrides) ------------------------------------------------

    def fetch(self, url: str) -> WebPage:
        """Fetch a URL using the browser if available, else fall back to HTTP.

        This synchronous override runs :meth:`fetch_dynamic` in an
        event loop when Playwright is installed.

        Args:
            url: The URL to fetch.

        Returns:
            A :class:`WebPage` instance.
        """
        if not _HAS_PLAYWRIGHT:
            return super().fetch(url)

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            # Already inside an async context — fall back to parent
            return super().fetch(url)

        return asyncio.run(self.fetch_dynamic(url))
