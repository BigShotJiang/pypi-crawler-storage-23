"""Video ingestion pipeline for regulatory hearings and depositions.

Extracts keyframes and transcribes audio track for multimodal memory.
"""

from __future__ import annotations

import logging
import tempfile
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "VideoFrame",
    "VideoIngestionResult",
    "VideoIngester",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class VideoFrame:
    """A representative frame extracted from a video.

    Attributes:
        timestamp: Time position of the frame in seconds.
        frame_index: Sequential frame index.
        description: Textual description of the frame content.
        objects_detected: List of object labels found in the frame.
        metadata: Arbitrary per-frame metadata.
    """

    timestamp: float
    frame_index: int
    description: str = ""
    objects_detected: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class VideoIngestionResult:
    """Complete result of a video ingestion.

    Attributes:
        frames: Extracted keyframes with descriptions.
        transcription: Transcription result from the audio track,
            or ``None`` if audio extraction failed.
        duration: Total video duration in seconds.
        metadata: Arbitrary metadata about the video.
    """

    frames: list[VideoFrame]
    transcription: Any | None  # TranscriptionResult when available
    duration: float
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_video_duration(path: str) -> float:
    """Attempt to determine video duration without heavy deps.

    Tries ``cv2`` first, then ``ffprobe`` via subprocess, and finally
    returns ``0.0`` as a fallback.
    """
    # Try OpenCV
    try:
        import cv2  # type: ignore[import-not-found]

        cap = cv2.VideoCapture(path)
        if cap.isOpened():
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT)
            cap.release()
            if fps > 0 and frame_count > 0:
                return float(frame_count / fps)
    except ImportError:
        pass

    # Try ffprobe
    try:
        import subprocess

        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                path,
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            return float(result.stdout.strip())
    except (FileNotFoundError, ValueError, subprocess.TimeoutExpired):
        pass

    return 0.0


def _extract_keyframes_cv2(path: str, interval: float) -> list[VideoFrame]:
    """Extract keyframes using OpenCV at the given interval."""
    try:
        import cv2
    except ImportError:
        return []

    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        logger.warning("OpenCV could not open video: %s", path)
        return []

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    _ = total_frames / fps if fps > 0 else 0.0  # duration available if needed
    frame_interval = int(fps * interval)

    frames: list[VideoFrame] = []
    frame_idx = 0
    keyframe_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_idx % frame_interval == 0:
            timestamp = frame_idx / fps
            height, width = frame.shape[:2]
            # Compute simple frame statistics for description
            mean_brightness = float(frame.mean())
            description = (
                f"Frame at {timestamp:.1f}s, "
                f"{width}x{height}, "
                f"mean brightness: {mean_brightness:.0f}"
            )

            frames.append(
                VideoFrame(
                    timestamp=timestamp,
                    frame_index=keyframe_count,
                    description=description,
                    metadata={
                        "width": width,
                        "height": height,
                        "source_frame": frame_idx,
                        "mean_brightness": round(mean_brightness, 1),
                    },
                )
            )
            keyframe_count += 1

        frame_idx += 1

    cap.release()
    return frames


def _extract_keyframes_ffmpeg(path: str, interval: float) -> list[VideoFrame]:
    """Extract keyframe timestamps using ffprobe scene detection."""
    import subprocess

    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "frame=pts_time",
                "-of",
                "csv=p=0",
                "-skip_frame",
                "nokey",
                path,
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []

    if result.returncode != 0:
        return []

    frames: list[VideoFrame] = []
    last_ts = -interval  # ensure first keyframe is included
    keyframe_count = 0

    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            ts = float(line)
        except ValueError:
            continue

        if ts - last_ts >= interval:
            frames.append(
                VideoFrame(
                    timestamp=ts,
                    frame_index=keyframe_count,
                    description=f"Keyframe at {ts:.1f}s",
                    metadata={"source": "ffprobe"},
                )
            )
            keyframe_count += 1
            last_ts = ts

    return frames


# ---------------------------------------------------------------------------
# VideoIngester
# ---------------------------------------------------------------------------


class VideoIngester:
    """Ingest video files by extracting keyframes and transcribing audio.

    Uses OpenCV or ffmpeg/ffprobe for frame extraction and delegates
    audio transcription to :class:`~aegis.ingestion.audio.AudioIngester`.

    Args:
        keyframe_interval: Seconds between extracted keyframes (default 5.0).
    """

    def __init__(self, keyframe_interval: float = 5.0) -> None:
        self._keyframe_interval = keyframe_interval

    def ingest(self, path: str) -> VideoIngestionResult:
        """Ingest a video file: extract keyframes and transcribe audio.

        Args:
            path: Path to the video file.

        Returns:
            A :class:`VideoIngestionResult` with frames and transcription.

        Raises:
            FileNotFoundError: If the video file does not exist.
        """
        filepath = Path(path)
        if not filepath.exists():
            raise FileNotFoundError(f"Video file not found: {path}")

        duration = _get_video_duration(path)
        frames = self.extract_keyframes(path)

        # Transcribe audio track
        transcription = None
        audio_path = self.extract_audio_track(path)
        if audio_path:
            try:
                from aegis.ingestion.audio import AudioIngester

                ingester = AudioIngester()
                transcription = ingester.transcribe(audio_path)
                if transcription.duration > duration:
                    duration = transcription.duration
            except Exception:
                logger.exception("Audio transcription failed for %s", path)

        if not duration and frames:
            duration = frames[-1].timestamp + self._keyframe_interval

        return VideoIngestionResult(
            frames=frames,
            transcription=transcription,
            duration=duration,
            metadata={
                "source": path,
                "num_keyframes": len(frames),
                "keyframe_interval": self._keyframe_interval,
            },
        )

    def extract_keyframes(self, path: str) -> list[VideoFrame]:
        """Extract representative keyframes from a video.

        Tries OpenCV first, falls back to ffprobe.

        Args:
            path: Path to the video file.

        Returns:
            A list of :class:`VideoFrame` instances.
        """
        # Try OpenCV first
        frames = _extract_keyframes_cv2(path, self._keyframe_interval)
        if frames:
            return frames

        # Fall back to ffprobe
        frames = _extract_keyframes_ffmpeg(path, self._keyframe_interval)
        if frames:
            return frames

        logger.warning(
            "Neither OpenCV nor ffprobe available; cannot extract keyframes. "
            "Install opencv-python or ffmpeg."
        )
        return []

    def extract_audio_track(self, path: str) -> str:
        """Extract the audio track from a video to a temporary WAV file.

        Uses ``ffmpeg`` command-line tool.  Returns an empty string if
        ffmpeg is not available.

        Args:
            path: Path to the video file.

        Returns:
            Path to the temporary WAV file, or an empty string on failure.
        """
        import subprocess

        tmp_dir = tempfile.gettempdir()
        audio_path = Path(tmp_dir) / f"aegis_audio_{uuid.uuid4().hex[:8]}.wav"

        try:
            result = subprocess.run(
                [
                    "ffmpeg",
                    "-i",
                    path,
                    "-vn",  # no video
                    "-acodec",
                    "pcm_s16le",
                    "-ar",
                    "16000",
                    "-ac",
                    "1",
                    "-y",
                    str(audio_path),
                ],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0 and audio_path.exists():
                return str(audio_path)
            logger.warning("ffmpeg audio extraction returned code %d", result.returncode)
        except FileNotFoundError:
            logger.warning(
                "ffmpeg not found; cannot extract audio track. Install ffmpeg for audio extraction."
            )
        except subprocess.TimeoutExpired:
            logger.warning("ffmpeg timed out extracting audio from %s", path)

        return ""

    def to_memory_entries(
        self, result: VideoIngestionResult, source_id: str
    ) -> list[dict[str, Any]]:
        """Convert a video ingestion result to Aegis memory entry dicts.

        Creates entries for keyframes and, if available, transcription
        segments.

        Args:
            result: A completed :class:`VideoIngestionResult`.
            source_id: Unique identifier for the source video.

        Returns:
            A list of dicts ready for memory storage.
        """
        entries: list[dict[str, Any]] = []

        # Frame entries
        for frame in result.frames:
            entries.append(
                {
                    "key": f"{source_id}:video:frame:{frame.frame_index}",
                    "value": frame.description,
                    "tier": "working",
                    "confidence": 0.7,
                    "provenance": {
                        "source_id": source_id,
                        "modality": "video",
                        "timestamp": frame.timestamp,
                        "frame_index": frame.frame_index,
                    },
                    "tags": [f"source:{source_id}", "modality:video", "type:keyframe"],
                    "metadata": frame.metadata,
                }
            )

        # Transcription entries
        if result.transcription is not None:
            from aegis.ingestion.audio import AudioIngester

            ingester = AudioIngester()
            audio_entries = ingester.to_memory_entries(result.transcription, source_id)
            # Re-tag as video-sourced
            for entry in audio_entries:
                entry["tags"].append("modality:video")
                entry["provenance"]["modality"] = "video_audio"
            entries.extend(audio_entries)

        return entries
