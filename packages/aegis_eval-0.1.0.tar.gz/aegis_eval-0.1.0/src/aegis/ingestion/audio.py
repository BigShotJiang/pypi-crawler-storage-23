"""Audio ingestion pipeline for earnings calls, depositions, and meetings.

Provides a Whisper-compatible interface for speech-to-text, with speaker
diarization and key-point extraction.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "AudioSegment",
    "TranscriptionResult",
    "AudioIngester",
    "EarningsCallProcessor",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AudioSegment:
    """A single segment of transcribed audio.

    Attributes:
        start_time: Start time in seconds.
        end_time: End time in seconds.
        text: Transcribed text for this segment.
        speaker: Identified speaker label (e.g. ``"SPEAKER_0"``).
        confidence: Transcription confidence in ``[0.0, 1.0]``.
    """

    start_time: float
    end_time: float
    text: str
    speaker: str = ""
    confidence: float = 1.0


@dataclass
class TranscriptionResult:
    """Complete result of an audio transcription.

    Attributes:
        segments: Ordered list of :class:`AudioSegment` instances.
        full_text: Concatenated text of all segments.
        duration: Total audio duration in seconds.
        language: Detected or specified language code.
        speakers: Set of unique speaker labels found.
        metadata: Arbitrary metadata about the transcription.
    """

    segments: list[AudioSegment]
    full_text: str
    duration: float
    language: str = "en"
    speakers: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Whisper wrapper helpers
# ---------------------------------------------------------------------------


def _load_whisper(model: str, device: str) -> Any | None:
    """Attempt to load OpenAI Whisper.  Returns the model or ``None``."""
    try:
        import whisper  # type: ignore[import-not-found]

        resolved_device = device
        if device == "auto":
            try:
                import torch

                resolved_device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                resolved_device = "cpu"
        return whisper.load_model(model, device=resolved_device)
    except ImportError:
        logger.warning(
            "openai-whisper is not installed; audio transcription unavailable. "
            "Install with: pip install openai-whisper"
        )
        return None
    except Exception:
        logger.exception("Failed to load Whisper model %s", model)
        return None


# ---------------------------------------------------------------------------
# AudioIngester
# ---------------------------------------------------------------------------


class AudioIngester:
    """Transcribe and analyse audio files.

    When ``openai-whisper`` is installed the real model is used; otherwise
    a stub interface is provided that returns empty results.

    Args:
        model: Whisper model name (default ``"whisper-v3"``). Falls back
            to ``"base"`` when the requested model is not available.
        device: Device to run inference on (``"auto"``, ``"cpu"``, or ``"cuda"``).
    """

    def __init__(self, model: str = "whisper-v3", device: str = "auto") -> None:
        self._model_name = model
        self._device = device
        self._whisper: Any | None = None  # Lazy-loaded

    def _ensure_model(self) -> Any | None:
        """Lazily load the Whisper model on first use."""
        if self._whisper is None:
            self._whisper = _load_whisper(self._model_name, self._device)
            # Fall back to the smaller model name if the requested one fails
            if self._whisper is None and self._model_name != "base":
                self._whisper = _load_whisper("base", self._device)
        return self._whisper

    def transcribe(self, path: str, language: str | None = None) -> TranscriptionResult:
        """Transcribe an audio file to text.

        Args:
            path: Path to the audio file (WAV, MP3, M4A, etc.).
            language: Optional ISO-639-1 language code.  If ``None``,
                Whisper auto-detects the language.

        Returns:
            A :class:`TranscriptionResult` with segments and full text.
        """
        filepath = Path(path)
        if not filepath.exists():
            raise FileNotFoundError(f"Audio file not found: {path}")

        model = self._ensure_model()
        if model is None:
            logger.warning("No Whisper model available; returning empty transcription.")
            return TranscriptionResult(
                segments=[],
                full_text="",
                duration=0.0,
                language=language or "en",
                metadata={"error": "whisper_not_installed"},
            )

        kwargs: dict[str, Any] = {"verbose": False}
        if language:
            kwargs["language"] = language

        raw = model.transcribe(str(filepath), **kwargs)

        segments: list[AudioSegment] = []
        for seg in raw.get("segments", []):
            segments.append(
                AudioSegment(
                    start_time=float(seg.get("start", 0.0)),
                    end_time=float(seg.get("end", 0.0)),
                    text=seg.get("text", "").strip(),
                    confidence=float(seg.get("avg_logprob", 0.0)),
                )
            )

        full_text = raw.get("text", "").strip()
        detected_lang = raw.get("language", language or "en")

        # Estimate duration from last segment
        duration = segments[-1].end_time if segments else 0.0

        return TranscriptionResult(
            segments=segments,
            full_text=full_text,
            duration=duration,
            language=detected_lang,
            metadata={"model": self._model_name, "source": path},
        )

    def extract_key_points(
        self, transcription: TranscriptionResult, max_points: int = 10
    ) -> list[dict[str, Any]]:
        """Extract key points from a transcription using extractive heuristics.

        Selects the most information-dense segments based on length,
        the presence of numbers/proper nouns, and positional cues
        (beginning/end of speech).

        Args:
            transcription: A completed transcription.
            max_points: Maximum number of key points to return.

        Returns:
            A list of dicts with ``"text"``, ``"start_time"``, ``"end_time"``,
            and ``"score"`` keys.
        """
        if not transcription.segments:
            return []

        scored: list[tuple[float, AudioSegment]] = []
        total = len(transcription.segments)

        for idx, seg in enumerate(transcription.segments):
            text = seg.text.strip()
            if len(text) < 10:
                continue

            score = 0.0
            # Length bonus (longer segments tend to carry more info)
            word_count = len(text.split())
            score += min(word_count / 30.0, 1.0)

            # Numbers/metrics signal importance
            num_count = len(re.findall(r"\d+(?:\.\d+)?%?", text))
            score += min(num_count * 0.3, 1.5)

            # Proper nouns (rough: capitalised words mid-sentence)
            proper = len(re.findall(r"(?<!\. )\b[A-Z][a-z]+\b", text))
            score += min(proper * 0.2, 1.0)

            # Positional bonus for opening and closing remarks
            relative_pos = idx / max(total - 1, 1)
            if relative_pos < 0.1 or relative_pos > 0.9:
                score += 0.5

            scored.append((score, seg))

        # Sort by score descending, pick top N
        scored.sort(key=lambda t: t[0], reverse=True)
        top = scored[:max_points]
        # Re-sort by time for natural order
        top.sort(key=lambda t: t[1].start_time)

        return [
            {
                "text": seg.text.strip(),
                "start_time": seg.start_time,
                "end_time": seg.end_time,
                "score": round(score, 3),
            }
            for score, seg in top
        ]

    def identify_speakers(
        self, transcription: TranscriptionResult
    ) -> dict[str, list[AudioSegment]]:
        """Group transcription segments by speaker label.

        If speaker labels are not already present (i.e. diarization was
        not performed), this assigns heuristic labels based on silence
        gaps between segments.

        Args:
            transcription: A completed transcription.

        Returns:
            A dict mapping speaker labels to their segments.
        """
        # Check if segments already have speaker labels
        has_labels = any(seg.speaker for seg in transcription.segments)

        if not has_labels:
            # Simple heuristic: alternate speakers on large gaps (>2s)
            current_speaker = "SPEAKER_0"
            speaker_idx = 0
            prev_end = 0.0
            for seg in transcription.segments:
                gap = seg.start_time - prev_end
                if gap > 2.0:
                    speaker_idx = (speaker_idx + 1) % 2
                    current_speaker = f"SPEAKER_{speaker_idx}"
                seg.speaker = current_speaker
                prev_end = seg.end_time

        groups: dict[str, list[AudioSegment]] = {}
        for seg in transcription.segments:
            groups.setdefault(seg.speaker or "UNKNOWN", []).append(seg)
        return groups

    def to_memory_entries(
        self, transcription: TranscriptionResult, source_id: str
    ) -> list[dict[str, Any]]:
        """Convert a transcription to Aegis memory entry dicts.

        Each segment becomes a memory entry with provenance metadata.

        Args:
            transcription: A completed transcription.
            source_id: Unique identifier for the source audio.

        Returns:
            A list of dicts ready for memory storage.
        """
        entries: list[dict[str, Any]] = []
        for idx, seg in enumerate(transcription.segments):
            text = seg.text.strip()
            if not text:
                continue
            entries.append(
                {
                    "key": f"{source_id}:audio:{idx}",
                    "value": text,
                    "tier": "working",
                    "confidence": max(0.0, min(1.0, seg.confidence)),
                    "provenance": {
                        "source_id": source_id,
                        "modality": "audio",
                        "start_time": seg.start_time,
                        "end_time": seg.end_time,
                        "speaker": seg.speaker,
                    },
                    "tags": [f"source:{source_id}", "modality:audio"],
                    "metadata": {
                        "language": transcription.language,
                        "segment_index": idx,
                        "duration": seg.end_time - seg.start_time,
                    },
                }
            )
        return entries


# ---------------------------------------------------------------------------
# EarningsCallProcessor
# ---------------------------------------------------------------------------


class EarningsCallProcessor(AudioIngester):
    """Specialised audio ingester for financial earnings calls.

    Extends :class:`AudioIngester` with methods for extracting financial
    mentions and separating Q&A sections.
    """

    # Patterns for financial numbers and metrics
    _FINANCIAL_MENTION_RE = re.compile(
        r"(?:"
        r"\$\s?\d[\d,]*(?:\.\d+)?\s*(?:million|billion|M|B|bn|mn)?"
        r"|"
        r"\d[\d,]*(?:\.\d+)?%"
        r"|"
        r"(?:revenue|earnings|profit|income|margin|growth|guidance|outlook|"
        r"EPS|EBITDA|cash flow|operating income|net income|gross margin|"
        r"free cash flow|dividend|capex|backlog)"
        r")",
        re.IGNORECASE,
    )

    _QA_START_RE = re.compile(
        r"(?:question|Q&A|Q and A|analyst|open.+(?:line|floor)|"
        r"take\s+(?:your|some)\s+questions)",
        re.IGNORECASE,
    )

    def extract_financial_mentions(
        self, transcription: TranscriptionResult
    ) -> list[dict[str, Any]]:
        """Find mentions of financial numbers, metrics, and guidance.

        Args:
            transcription: A completed transcription.

        Returns:
            A list of dicts with ``"text"``, ``"mention"``, ``"start_time"``,
            and ``"end_time"`` keys.
        """
        mentions: list[dict[str, Any]] = []
        for seg in transcription.segments:
            for m in self._FINANCIAL_MENTION_RE.finditer(seg.text):
                mentions.append(
                    {
                        "text": seg.text.strip(),
                        "mention": m.group(0).strip(),
                        "start_time": seg.start_time,
                        "end_time": seg.end_time,
                        "speaker": seg.speaker,
                    }
                )
        return mentions

    def extract_qa_pairs(self, transcription: TranscriptionResult) -> list[dict[str, Any]]:
        """Separate the Q&A section from prepared remarks.

        Detects the Q&A transition point and pairs consecutive
        question/answer speaker turns.

        Args:
            transcription: A completed transcription.

        Returns:
            A list of dicts with ``"question"`` and ``"answer"`` keys,
            each containing segment text and metadata.
        """
        # Find the Q&A start point
        qa_start_idx = None
        for idx, seg in enumerate(transcription.segments):
            if self._QA_START_RE.search(seg.text):
                qa_start_idx = idx
                break

        if qa_start_idx is None:
            return []

        qa_segments = transcription.segments[qa_start_idx + 1 :]
        if not qa_segments:
            return []

        # Ensure speaker labels exist
        self.identify_speakers(transcription)

        # Pair alternating speakers as Q/A
        pairs: list[dict[str, Any]] = []
        i = 0
        while i < len(qa_segments) - 1:
            q_seg = qa_segments[i]
            a_seg = qa_segments[i + 1]

            # Only pair if speakers differ
            if q_seg.speaker != a_seg.speaker:
                pairs.append(
                    {
                        "question": {
                            "text": q_seg.text.strip(),
                            "speaker": q_seg.speaker,
                            "start_time": q_seg.start_time,
                            "end_time": q_seg.end_time,
                        },
                        "answer": {
                            "text": a_seg.text.strip(),
                            "speaker": a_seg.speaker,
                            "start_time": a_seg.start_time,
                            "end_time": a_seg.end_time,
                        },
                    }
                )
                i += 2
            else:
                i += 1

        return pairs
