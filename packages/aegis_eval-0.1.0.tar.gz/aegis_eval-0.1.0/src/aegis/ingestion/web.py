"""Web ingestion pipeline for SEC EDGAR, court dockets, and regulatory databases.

Provides configurable web scraping with rate limiting, caching, and
structured data extraction from common legal/financial data sources.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "WebPage",
    "SECFiling",
    "WebIngester",
    "SECEdgarClient",
    "CourtDocketClient",
    "RegulatoryClient",
]

_DEFAULT_USER_AGENT = "Aegis/1.0 (https://github.com/metronis-space/aegis; research@metronis.space)"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class WebPage:
    """A fetched web page with extracted content.

    Attributes:
        url: The canonical URL of the page.
        title: Page title extracted from ``<title>`` tag.
        content: Raw HTML content.
        extracted_data: Structured data extracted from the page.
        fetched_at: ISO-8601 timestamp of when the page was fetched.
        metadata: Arbitrary metadata.
    """

    url: str
    title: str
    content: str
    extracted_data: dict[str, Any] = field(default_factory=dict)
    fetched_at: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SECFiling:
    """A filing retrieved from SEC EDGAR.

    Attributes:
        filing_type: Filing type code (e.g. ``"10-K"``, ``"10-Q"``, ``"8-K"``).
        company: Company name.
        cik: SEC Central Index Key.
        date: Filing date (YYYY-MM-DD).
        url: URL of the filing on EDGAR.
        content: Raw text content of the filing.
        exhibits: List of exhibit dicts.
    """

    filing_type: str
    company: str
    cik: str
    date: str
    url: str
    content: str = ""
    exhibits: list[dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Rate limiting / caching helpers
# ---------------------------------------------------------------------------


class _RateLimiter:
    """Simple token-bucket style rate limiter."""

    def __init__(self, rpm: int) -> None:
        self._min_interval = 60.0 / max(rpm, 1)
        self._last_request: float = 0.0

    def wait(self) -> None:
        """Block until the next request is allowed."""
        now = time.monotonic()
        elapsed = now - self._last_request
        if elapsed < self._min_interval:
            time.sleep(self._min_interval - elapsed)
        self._last_request = time.monotonic()


class _DiskCache:
    """Simple disk-based HTTP cache."""

    def __init__(self, cache_dir: str) -> None:
        self._dir = Path(cache_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def _key(self, url: str) -> str:
        return hashlib.sha256(url.encode()).hexdigest()

    def get(self, url: str) -> str | None:
        """Return cached content for *url* or ``None``."""
        path = self._dir / self._key(url)
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                # Cache entries older than 24 hours are stale
                fetched = data.get("fetched_at", "")
                if fetched:
                    ts = datetime.fromisoformat(fetched)
                    age = (datetime.now(UTC) - ts).total_seconds()
                    if age > 86400:
                        path.unlink(missing_ok=True)
                        return None
                return data.get("content", None)  # type: ignore[no-any-return]
            except (json.JSONDecodeError, OSError, ValueError):
                return None
        return None

    def put(self, url: str, content: str) -> None:
        """Store content for *url*."""
        path = self._dir / self._key(url)
        data = {
            "url": url,
            "content": content,
            "fetched_at": datetime.now(UTC).isoformat(),
        }
        try:
            path.write_text(json.dumps(data), encoding="utf-8")
        except OSError:
            logger.debug("Failed to cache %s", url)


# ---------------------------------------------------------------------------
# HTML helpers (pure Python)
# ---------------------------------------------------------------------------

_TAG_RE = re.compile(r"<[^>]+>")
_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.DOTALL | re.IGNORECASE)
_TABLE_RE = re.compile(r"<table[^>]*>(.*?)</table>", re.DOTALL | re.IGNORECASE)
_ROW_RE = re.compile(r"<tr[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
_CELL_RE = re.compile(r"<(?:td|th)[^>]*>(.*?)</(?:td|th)>", re.DOTALL | re.IGNORECASE)
_SCRIPT_STYLE_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.DOTALL | re.IGNORECASE)
_BLOCK_RE = re.compile(
    r"</(p|div|section|article|h[1-6]|li|tr|blockquote)>",
    re.IGNORECASE,
)


def _strip_html(html: str) -> str:
    """Convert HTML to plain text."""
    text = _SCRIPT_STYLE_RE.sub("", html)
    text = _BLOCK_RE.sub("\n\n", text)
    text = _TAG_RE.sub(" ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = (
        text.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&#39;", "'")
        .replace("&nbsp;", " ")
    )
    return text.strip()


def _extract_title(html: str) -> str:
    """Extract the <title> from HTML."""
    m = _TITLE_RE.search(html)
    if m:
        return _TAG_RE.sub("", m.group(1)).strip()
    return ""


def _extract_html_tables(html: str) -> list[dict[str, Any]]:
    """Extract tables from HTML into list-of-lists."""
    tables: list[dict[str, Any]] = []
    for table_match in _TABLE_RE.finditer(html):
        table_html = table_match.group(1)
        rows: list[list[str]] = []
        for row_match in _ROW_RE.finditer(table_html):
            cells = [
                _TAG_RE.sub("", c.group(1)).strip() for c in _CELL_RE.finditer(row_match.group(1))
            ]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(
                {
                    "headers": rows[0] if rows else [],
                    "rows": rows[1:] if len(rows) > 1 else [],
                    "num_rows": max(len(rows) - 1, 0),
                }
            )
    return tables


# ---------------------------------------------------------------------------
# WebIngester
# ---------------------------------------------------------------------------


class WebIngester:
    """Fetch and extract content from web pages.

    Provides rate-limited HTTP fetching with optional disk caching and
    content extraction utilities.

    Args:
        cache_dir: Directory for the HTTP cache (default ``".cache/web"``).
        rate_limit_rpm: Maximum requests per minute (default 30).
        user_agent: User-Agent header string.
    """

    def __init__(
        self,
        cache_dir: str = ".cache/web",
        rate_limit_rpm: int = 30,
        user_agent: str = _DEFAULT_USER_AGENT,
    ) -> None:
        self._cache = _DiskCache(cache_dir)
        self._limiter = _RateLimiter(rate_limit_rpm)
        self._user_agent = user_agent

    def fetch(self, url: str) -> WebPage:
        """Fetch a URL and return a :class:`WebPage`.

        Serves from cache when available.  Respects rate limiting.

        Args:
            url: The URL to fetch.

        Returns:
            A :class:`WebPage` with raw HTML content.
        """
        cached = self._cache.get(url)
        if cached is not None:
            return WebPage(
                url=url,
                title=_extract_title(cached),
                content=cached,
                fetched_at=datetime.now(UTC).isoformat(),
                metadata={"cached": True},
            )

        self._limiter.wait()

        req = urllib.request.Request(url, headers={"User-Agent": self._user_agent})
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
                charset = resp.headers.get_content_charset() or "utf-8"
                html = raw.decode(charset, errors="replace")
        except (urllib.error.URLError, urllib.error.HTTPError, OSError) as exc:
            logger.warning("Failed to fetch %s: %s", url, exc)
            return WebPage(
                url=url,
                title="",
                content="",
                fetched_at=datetime.now(UTC).isoformat(),
                metadata={"error": str(exc)},
            )

        self._cache.put(url, html)

        return WebPage(
            url=url,
            title=_extract_title(html),
            content=html,
            fetched_at=datetime.now(UTC).isoformat(),
        )

    def extract_text(self, page: WebPage) -> str:
        """Extract clean text from a :class:`WebPage`.

        Args:
            page: A fetched web page.

        Returns:
            Plain-text content with HTML tags removed.
        """
        return _strip_html(page.content)

    def extract_tables(self, page: WebPage) -> list[dict[str, Any]]:
        """Extract HTML tables from a :class:`WebPage`.

        Args:
            page: A fetched web page.

        Returns:
            A list of table dicts with ``"headers"`` and ``"rows"`` keys.
        """
        return _extract_html_tables(page.content)

    def to_memory_entries(self, page: WebPage, source_id: str) -> list[dict[str, Any]]:
        """Convert a :class:`WebPage` to Aegis memory entry dicts.

        Splits the page text into paragraph-level entries.

        Args:
            page: A fetched web page.
            source_id: Unique identifier for the source.

        Returns:
            A list of dicts ready for memory storage.
        """
        text = self.extract_text(page)
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]

        entries: list[dict[str, Any]] = []
        for idx, para in enumerate(paragraphs):
            if len(para) < 10:
                continue
            entries.append(
                {
                    "key": f"{source_id}:web:{idx}",
                    "value": para,
                    "tier": "working",
                    "confidence": 0.8,
                    "provenance": {
                        "source_id": source_id,
                        "modality": "web",
                        "url": page.url,
                        "fetched_at": page.fetched_at,
                    },
                    "tags": [f"source:{source_id}", "modality:web"],
                    "metadata": {
                        "title": page.title,
                        "paragraph_index": idx,
                    },
                }
            )
        return entries


# ---------------------------------------------------------------------------
# SECEdgarClient
# ---------------------------------------------------------------------------

_EDGAR_BASE = "https://efts.sec.gov/LATEST"
_EDGAR_FILING_BASE = "https://www.sec.gov/cgi-bin/browse-edgar"
_EDGAR_FULL_TEXT = "https://efts.sec.gov/LATEST/search-index"
_EDGAR_SUBMISSIONS = "https://data.sec.gov/submissions"


class SECEdgarClient(WebIngester):
    """Client for SEC EDGAR filings.

    Extends :class:`WebIngester` with EDGAR-specific search and retrieval.
    Respects the SEC's fair-access policy (10 requests per second max).
    """

    def __init__(
        self,
        cache_dir: str = ".cache/edgar",
        rate_limit_rpm: int = 10,
    ) -> None:
        super().__init__(
            cache_dir=cache_dir,
            rate_limit_rpm=rate_limit_rpm,
            user_agent=_DEFAULT_USER_AGENT,
        )

    def get_filing(
        self,
        cik: str,
        filing_type: str,
        date: str | None = None,
    ) -> SECFiling:
        """Retrieve a specific SEC filing.

        Args:
            cik: Central Index Key for the company.
            filing_type: Filing type code (e.g. ``"10-K"``).
            date: Optional filing date filter (``YYYY-MM-DD``).

        Returns:
            An :class:`SECFiling` instance.
        """
        # Normalize CIK to 10 digits
        cik_padded = cik.zfill(10)
        submissions_url = f"{_EDGAR_SUBMISSIONS}/CIK{cik_padded}.json"

        page = self.fetch(submissions_url)
        if not page.content:
            return SECFiling(
                filing_type=filing_type,
                company="",
                cik=cik,
                date=date or "",
                url=submissions_url,
            )

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            return SECFiling(
                filing_type=filing_type,
                company="",
                cik=cik,
                date=date or "",
                url=submissions_url,
            )

        company_name = data.get("name", "")
        recent = data.get("filings", {}).get("recent", {})
        forms = recent.get("form", [])
        dates = recent.get("filingDate", [])
        accessions = recent.get("accessionNumber", [])
        primary_docs = recent.get("primaryDocument", [])

        # Find matching filing
        for i, form in enumerate(forms):
            if form.upper() != filing_type.upper():
                continue
            if date and i < len(dates) and dates[i] != date:
                continue
            accession = accessions[i] if i < len(accessions) else ""
            doc = primary_docs[i] if i < len(primary_docs) else ""
            accession_clean = accession.replace("-", "")
            filing_url = (
                f"https://www.sec.gov/Archives/edgar/data/{cik_padded}/{accession_clean}/{doc}"
            )

            # Fetch the actual filing
            filing_page = self.fetch(filing_url)
            filing_content = self.extract_text(filing_page) if filing_page.content else ""

            return SECFiling(
                filing_type=form,
                company=company_name,
                cik=cik,
                date=dates[i] if i < len(dates) else "",
                url=filing_url,
                content=filing_content,
            )

        return SECFiling(
            filing_type=filing_type,
            company=company_name,
            cik=cik,
            date=date or "",
            url=submissions_url,
            content="",
        )

    def search_filings(
        self,
        company: str,
        filing_type: str | None = None,
        limit: int = 10,
    ) -> list[SECFiling]:
        """Search for SEC filings by company name.

        Uses the EDGAR full-text search API.

        Args:
            company: Company name or search term.
            filing_type: Optional filing type filter.
            limit: Maximum number of results.

        Returns:
            A list of :class:`SECFiling` instances.
        """
        params: dict[str, str] = {
            "q": company,
            "dateRange": "custom",
            "startdt": "2020-01-01",
            "enddt": datetime.now(UTC).strftime("%Y-%m-%d"),
        }
        if filing_type:
            params["forms"] = filing_type

        search_url = f"{_EDGAR_BASE}/search-index?{urllib.parse.urlencode(params)}"
        page = self.fetch(search_url)

        filings: list[SECFiling] = []
        if not page.content:
            return filings

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            return filings

        hits = data.get("hits", {}).get("hits", [])
        for hit in hits[:limit]:
            source = hit.get("_source", {})
            filings.append(
                SECFiling(
                    filing_type=source.get("forms", ""),
                    company=source.get("entity_name", company),
                    cik=source.get("entity_id", ""),
                    date=source.get("file_date", ""),
                    url=source.get("file_url", ""),
                )
            )

        return filings

    def get_xbrl_data(self, filing: SECFiling) -> dict[str, Any]:
        """Parse XBRL financial data from a filing.

        Attempts to locate and parse the XBRL/iXBRL document associated
        with the filing using :class:`~aegis.ingestion.xbrl.XBRLParser`.
        Falls back to regex extraction if the structured parser returns
        no results.

        Args:
            filing: An :class:`SECFiling` instance.

        Returns:
            A dict of XBRL facts keyed by concept name.
        """
        from aegis.ingestion.xbrl import XBRLParser

        if not filing.url:
            return {}

        parser = XBRLParser()

        # Look for XBRL companion files
        base_url = filing.url.rsplit("/", 1)[0]
        # Common XBRL filename patterns
        for suffix in ("_htm.xml", ".xml", "R1.htm"):
            xbrl_url = f"{base_url}/{suffix}"
            page = self.fetch(xbrl_url)
            if not page.content or "error" in page.metadata:
                continue

            # Try structured XBRL parser first
            structured_facts = parser.parse_xbrl(page.content)
            if not structured_facts:
                structured_facts = parser.parse_ixbrl(page.content)

            if structured_facts:
                facts: dict[str, Any] = {}
                for fact in structured_facts:
                    ctx_ref = fact.metadata.get("context_ref", "")
                    key = f"{fact.concept}:{ctx_ref}" if ctx_ref else fact.concept
                    facts[key] = {
                        "value": fact.value,
                        "label": fact.label,
                        "unit": fact.unit,
                        "period_type": fact.period_type,
                        "decimals": fact.decimals,
                    }
                return facts

            # Fallback: simple regex extraction
            regex_facts: dict[str, Any] = {}
            fact_pattern = re.compile(
                r"<(?:[\w]+:)?([\w]+)[^>]*contextRef=\"([^\"]+)\"[^>]*>"
                r"([^<]+)</",
                re.DOTALL,
            )
            for m in fact_pattern.finditer(page.content):
                concept = m.group(1)
                context = m.group(2)
                value = m.group(3).strip()
                key = f"{concept}:{context}"
                regex_facts[key] = value

            if regex_facts:
                return regex_facts

        return {}


# ---------------------------------------------------------------------------
# CourtDocketClient
# ---------------------------------------------------------------------------


class CourtDocketClient(WebIngester):
    """Client for searching court docket information.

    Provides a structured interface for querying court records.
    Designed to be extended with jurisdiction-specific backends.
    """

    def search_cases(
        self,
        query: str,
        jurisdiction: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search for court cases by keyword.

        Args:
            query: Search terms.
            jurisdiction: Optional jurisdiction filter (e.g. ``"federal"``,
                ``"ny"``, ``"ca"``).

        Returns:
            A list of case summary dicts.
        """
        # Use CourtListener as a public data source
        params: dict[str, str] = {"q": query}
        if jurisdiction:
            params["court"] = jurisdiction

        url = f"https://www.courtlistener.com/api/rest/v4/search/?{urllib.parse.urlencode(params)}"
        page = self.fetch(url)

        cases: list[dict[str, Any]] = []
        if not page.content:
            return cases

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            # Might be HTML; try to extract text
            return cases

        results = data.get("results", [])
        for result in results:
            cases.append(
                {
                    "case_name": result.get("caseName", ""),
                    "docket_number": result.get("docketNumber", ""),
                    "court": result.get("court", ""),
                    "date_filed": result.get("dateFiled", ""),
                    "url": result.get("absolute_url", ""),
                    "snippet": result.get("snippet", ""),
                }
            )

        return cases

    def get_docket(self, case_id: str) -> dict[str, Any]:
        """Retrieve a full docket by case ID.

        Args:
            case_id: The case identifier.

        Returns:
            A dict with docket entries and metadata.
        """
        url = f"https://www.courtlistener.com/api/rest/v4/dockets/{case_id}/"
        page = self.fetch(url)

        if not page.content:
            return {"case_id": case_id, "error": "fetch_failed"}

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            return {"case_id": case_id, "error": "parse_failed", "raw": page.content[:500]}

        return {
            "case_id": case_id,
            "case_name": data.get("case_name", ""),
            "court": data.get("court", ""),
            "date_filed": data.get("date_filed", ""),
            "date_terminated": data.get("date_terminated", ""),
            "docket_entries": data.get("docket_entries", []),
            "parties": data.get("parties", []),
            "url": data.get("absolute_url", ""),
        }


# ---------------------------------------------------------------------------
# RegulatoryClient
# ---------------------------------------------------------------------------


class RegulatoryClient(WebIngester):
    """Client for US federal regulatory data.

    Provides access to the Federal Register API and the Code of Federal
    Regulations (eCFR API).
    """

    _FR_BASE = "https://www.federalregister.gov/api/v1"
    _ECFR_BASE = "https://www.ecfr.gov/api/versioner/v1"

    def search_federal_register(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        """Search the Federal Register for documents.

        Args:
            query: Search terms.
            limit: Maximum number of results.

        Returns:
            A list of document summary dicts.
        """
        params = urllib.parse.urlencode({"conditions[term]": query, "per_page": str(limit)})
        url = f"{self._FR_BASE}/documents.json?{params}"
        page = self.fetch(url)

        results: list[dict[str, Any]] = []
        if not page.content:
            return results

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            return results

        for doc in data.get("results", []):
            results.append(
                {
                    "title": doc.get("title", ""),
                    "document_number": doc.get("document_number", ""),
                    "type": doc.get("type", ""),
                    "abstract": doc.get("abstract", ""),
                    "publication_date": doc.get("publication_date", ""),
                    "agencies": [a.get("name", "") for a in doc.get("agencies", [])],
                    "url": doc.get("html_url", ""),
                    "pdf_url": doc.get("pdf_url", ""),
                }
            )

        return results

    def get_cfr_section(self, title: int, part: int, section: int) -> dict[str, Any]:
        """Retrieve a specific section of the Code of Federal Regulations.

        Args:
            title: CFR title number.
            part: CFR part number.
            section: CFR section number within the part.

        Returns:
            A dict with the section content and metadata.
        """
        # eCFR API path
        url = (
            f"{self._ECFR_BASE}/full/{datetime.now(UTC).strftime('%Y-%m-%d')}"
            f"/title-{title}.json"
            f"?part={part}&section={section}"
        )
        page = self.fetch(url)

        if not page.content:
            return {
                "title": title,
                "part": part,
                "section": section,
                "error": "fetch_failed",
            }

        try:
            data = json.loads(page.content)
        except json.JSONDecodeError:
            # May have received HTML — extract text
            text = self.extract_text(page)
            return {
                "title": title,
                "part": part,
                "section": section,
                "content": text[:5000] if text else "",
                "url": url,
            }

        return {
            "title": title,
            "part": part,
            "section": section,
            "content": data,
            "url": url,
        }
