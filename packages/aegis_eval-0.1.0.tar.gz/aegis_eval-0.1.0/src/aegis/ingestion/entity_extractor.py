"""Simple entity and relation extraction for knowledge graph construction.

Uses rule-based NER patterns for common entity types (person, org,
location, date, money, legal terms) without requiring heavy ML models.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class Entity:
    """A named entity extracted from text.

    Attributes:
        text: The surface form of the entity.
        entity_type: Category (e.g. ``"ORG"``, ``"DATE"``, ``"MONEY"``).
        start: Character offset of the entity start in the source text.
        end: Character offset of the entity end in the source text.
    """

    text: str
    entity_type: str
    start: int
    end: int


@dataclass
class Relation:
    """A relation between two entities.

    Attributes:
        subject: The source entity text.
        predicate: The relation type (e.g. ``"filed_by"``, ``"revenue_of"``).
        object: The target entity text.
        confidence: Confidence score in [0.0, 1.0].
    """

    subject: str
    predicate: str
    object: str
    confidence: float = 1.0


@dataclass
class ExtractedEntities:
    """Result of entity and relation extraction.

    Attributes:
        entities: All named entities found.
        relations: Relations inferred between entities.
    """

    entities: list[Entity] = field(default_factory=list)
    relations: list[Relation] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# Organization suffixes
_ORG_PATTERN = re.compile(
    r"\b([A-Z][A-Za-z&.\-' ]*?"
    r"(?:\s+(?:Holdings|Group|Partners|Capital|Financial|Technologies|Systems|Solutions|Services))*"
    r")\s*"
    r"(?:Inc\.?|Corp\.?|Corporation|LLC|Ltd\.?|L\.P\.?|LP|PLC|Co\.?|Company)"
    r"\b",
)

# Date patterns (US-style and ISO)
_DATE_PATTERN = re.compile(
    r"\b("
    # ISO: 2024-01-15
    r"\d{4}-\d{1,2}-\d{1,2}"
    r"|"
    # US: January 15, 2024 or Jan 15, 2024
    r"(?:January|February|March|April|May|June|July|August|September|"
    r"October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
    r"\.?\s+\d{1,2},?\s+\d{4}"
    r"|"
    # Numeric US: 01/15/2024 or 1/15/2024
    r"\d{1,2}/\d{1,2}/\d{4}"
    r")\b",
)

# Monetary amounts
_MONEY_PATTERN = re.compile(
    r"(\$\s?\d[\d,]*(?:\.\d{1,2})?\s*(?:million|billion|trillion|M|B|T|k|K)?)"
    r"|"
    r"(\d[\d,]*(?:\.\d{1,2})?\s*(?:USD|EUR|GBP|JPY))",
)

# Legal terms
_LEGAL_TERMS = re.compile(
    r"\b(plaintiff|defendant|petitioner|respondent|appellant|appellee"
    r"|court|judge|jury|verdict|injunction|statute|regulation"
    r"|damages|liability|negligence|breach|contract|settlement"
    r"|jurisdiction|arbitration|mediation)\b",
    re.IGNORECASE,
)

# Financial terms
_FINANCIAL_TERMS = re.compile(
    r"\b(revenue|profit|net income|gross margin|EBITDA|EPS"
    r"|operating income|free cash flow|market cap|valuation"
    r"|dividend|earnings|fiscal year|quarter|annual report"
    r"|balance sheet|income statement|cash flow)\b",
    re.IGNORECASE,
)

# Percentage pattern
_PERCENT_PATTERN = re.compile(
    r"\b(\d+(?:\.\d+)?)\s*%",
)


class SimpleEntityExtractor:
    """Rule-based entity and relation extractor.

    Extracts entities using regex patterns for common types:
    organizations, dates, monetary amounts, legal terms, and
    financial terms.  Infers simple relations between co-occurring
    entities in the same text span.
    """

    def extract(self, text: str) -> ExtractedEntities:
        """Extract entities and relations from *text*.

        Args:
            text: The input text to analyse.

        Returns:
            An :class:`ExtractedEntities` instance with found entities
            and inferred relations.
        """
        entities: list[Entity] = []
        seen: set[tuple[str, str, int]] = set()  # (text, type, start)

        def _add(match_text: str, entity_type: str, start: int, end: int) -> None:
            key = (match_text.strip(), entity_type, start)
            if key not in seen:
                seen.add(key)
                entities.append(
                    Entity(
                        text=match_text.strip(),
                        entity_type=entity_type,
                        start=start,
                        end=end,
                    )
                )

        # Organizations
        for m in _ORG_PATTERN.finditer(text):
            _add(m.group(0), "ORG", m.start(), m.end())

        # Dates
        for m in _DATE_PATTERN.finditer(text):
            _add(m.group(0), "DATE", m.start(), m.end())

        # Monetary amounts
        for m in _MONEY_PATTERN.finditer(text):
            matched = m.group(0).strip()
            if matched:
                _add(matched, "MONEY", m.start(), m.end())

        # Legal terms
        for m in _LEGAL_TERMS.finditer(text):
            _add(m.group(0), "LEGAL_TERM", m.start(), m.end())

        # Financial terms
        for m in _FINANCIAL_TERMS.finditer(text):
            _add(m.group(0), "FINANCIAL_TERM", m.start(), m.end())

        # Percentages
        for m in _PERCENT_PATTERN.finditer(text):
            _add(m.group(0) + "%", "PERCENTAGE", m.start(), m.end())

        # Sort entities by position
        entities.sort(key=lambda e: e.start)

        # Infer relations between co-occurring entities
        relations = self._infer_relations(entities, text)

        return ExtractedEntities(entities=entities, relations=relations)

    def _infer_relations(
        self,
        entities: list[Entity],
        text: str,
    ) -> list[Relation]:
        """Infer relations between entities based on proximity and type.

        Uses simple heuristics: if an ORG appears near a MONEY or
        FINANCIAL_TERM entity, create a relation.  If a LEGAL_TERM like
        "plaintiff" or "defendant" appears near an ORG, link them.
        """
        relations: list[Relation] = []
        seen_relations: set[tuple[str, str, str]] = set()

        orgs = [e for e in entities if e.entity_type == "ORG"]
        money_entities = [e for e in entities if e.entity_type == "MONEY"]
        financial_entities = [e for e in entities if e.entity_type == "FINANCIAL_TERM"]
        legal_entities = [e for e in entities if e.entity_type == "LEGAL_TERM"]
        date_entities = [e for e in entities if e.entity_type == "DATE"]

        # ORG <-> MONEY relations
        for org in orgs:
            for money in money_entities:
                if abs(org.start - money.start) < 200:
                    key = (org.text, "has_value", money.text)
                    if key not in seen_relations:
                        seen_relations.add(key)
                        relations.append(
                            Relation(
                                subject=org.text,
                                predicate="has_value",
                                object=money.text,
                                confidence=0.7,
                            )
                        )

        # ORG <-> FINANCIAL_TERM relations
        for org in orgs:
            for fin in financial_entities:
                if abs(org.start - fin.start) < 200:
                    key = (org.text, "has_metric", fin.text)
                    if key not in seen_relations:
                        seen_relations.add(key)
                        relations.append(
                            Relation(
                                subject=org.text,
                                predicate="has_metric",
                                object=fin.text,
                                confidence=0.6,
                            )
                        )

        # LEGAL_TERM <-> ORG relations
        for legal in legal_entities:
            lower = legal.text.lower()
            for org in orgs:
                if abs(legal.start - org.start) < 200:
                    if lower in ("plaintiff", "petitioner", "appellant"):
                        predicate = "filed_by"
                    elif lower in ("defendant", "respondent", "appellee"):
                        predicate = "filed_against"
                    elif lower in ("court", "judge"):
                        predicate = "adjudicated_by"
                    else:
                        predicate = "involves"
                    key = (org.text, predicate, legal.text)
                    if key not in seen_relations:
                        seen_relations.add(key)
                        relations.append(
                            Relation(
                                subject=org.text,
                                predicate=predicate,
                                object=legal.text,
                                confidence=0.65,
                            )
                        )

        # ORG <-> DATE relations
        for org in orgs:
            for date in date_entities:
                if abs(org.start - date.start) < 200:
                    key = (org.text, "dated", date.text)
                    if key not in seen_relations:
                        seen_relations.add(key)
                        relations.append(
                            Relation(
                                subject=org.text,
                                predicate="dated",
                                object=date.text,
                                confidence=0.5,
                            )
                        )

        return relations
