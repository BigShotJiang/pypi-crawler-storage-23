"""XBRL and iXBRL parser for financial filing ingestion.

Parses XBRL (eXtensible Business Reporting Language) and inline XBRL
(iXBRL) documents into structured :class:`FinancialFact` records.
Includes US-GAAP and IFRS taxonomy lookup with unit normalisation.

Uses only stdlib ``xml.etree.ElementTree`` and regex — no external
dependencies required.
"""

from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "FinancialFact",
    "TaxonomyMapping",
    "TemporalContext",
    "XBRLParser",
]

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class FinancialFact:
    """A single XBRL fact extracted from a filing.

    Attributes:
        concept: Raw XBRL concept name (e.g. ``"us-gaap:Revenue"``).
        label: Human-readable label (e.g. ``"Revenue"``).
        value: Parsed value as a string.
        unit: Unit code (e.g. ``"USD"``, ``"shares"``).
        period_type: ``"instant"`` or ``"duration"``.
        period_start: Start date for duration periods.
        period_end: End date (or instant date).
        decimals: Decimal precision (``-6`` for millions, etc.).
        metadata: Arbitrary extra metadata.
    """

    concept: str
    label: str
    value: str
    unit: str = ""
    period_type: str = ""
    period_start: date | None = None
    period_end: date | None = None
    decimals: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def numeric_value(self) -> float | None:
        """Attempt to parse the value as a float."""
        try:
            return float(self.value.replace(",", ""))
        except (ValueError, AttributeError):
            return None


@dataclass
class TaxonomyMapping:
    """Maps a raw XBRL concept to a human-readable label and category.

    Attributes:
        raw_concept: Original XBRL concept string.
        label: Human-friendly display label.
        category: Grouping category (e.g. ``"income_statement"``, ``"balance_sheet"``).
    """

    raw_concept: str
    label: str
    category: str = ""


@dataclass
class TemporalContext:
    """An XBRL context reference with temporal bounds.

    Attributes:
        context_ref: The ``contextRef`` id in the XBRL document.
        period_type: ``"instant"`` or ``"duration"``.
        start_date: Start date for duration periods.
        end_date: End date (or the instant date for instant periods).
    """

    context_ref: str
    period_type: str = ""
    start_date: date | None = None
    end_date: date | None = None


# ---------------------------------------------------------------------------
# US-GAAP taxonomy (~200 most common concepts)
# ---------------------------------------------------------------------------

_US_GAAP_TAXONOMY: dict[str, TaxonomyMapping] = {
    # Income statement
    "Revenues": TaxonomyMapping("Revenues", "Revenue", "income_statement"),
    "RevenueFromContractWithCustomerExcludingAssessedTax": TaxonomyMapping(
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "Revenue from Contracts",
        "income_statement",
    ),
    "SalesRevenueNet": TaxonomyMapping("SalesRevenueNet", "Net Sales Revenue", "income_statement"),
    "CostOfRevenue": TaxonomyMapping("CostOfRevenue", "Cost of Revenue", "income_statement"),
    "CostOfGoodsAndServicesSold": TaxonomyMapping(
        "CostOfGoodsAndServicesSold", "Cost of Goods Sold", "income_statement"
    ),
    "GrossProfit": TaxonomyMapping("GrossProfit", "Gross Profit", "income_statement"),
    "OperatingExpenses": TaxonomyMapping(
        "OperatingExpenses", "Operating Expenses", "income_statement"
    ),
    "ResearchAndDevelopmentExpense": TaxonomyMapping(
        "ResearchAndDevelopmentExpense", "R&D Expense", "income_statement"
    ),
    "SellingGeneralAndAdministrativeExpense": TaxonomyMapping(
        "SellingGeneralAndAdministrativeExpense", "SG&A Expense", "income_statement"
    ),
    "OperatingIncomeLoss": TaxonomyMapping(
        "OperatingIncomeLoss", "Operating Income (Loss)", "income_statement"
    ),
    "InterestExpense": TaxonomyMapping("InterestExpense", "Interest Expense", "income_statement"),
    "InterestIncome": TaxonomyMapping("InterestIncome", "Interest Income", "income_statement"),
    "IncomeTaxExpenseBenefit": TaxonomyMapping(
        "IncomeTaxExpenseBenefit", "Income Tax Expense", "income_statement"
    ),
    "NetIncomeLoss": TaxonomyMapping("NetIncomeLoss", "Net Income (Loss)", "income_statement"),
    "EarningsPerShareBasic": TaxonomyMapping(
        "EarningsPerShareBasic", "EPS (Basic)", "income_statement"
    ),
    "EarningsPerShareDiluted": TaxonomyMapping(
        "EarningsPerShareDiluted", "EPS (Diluted)", "income_statement"
    ),
    "ComprehensiveIncomeNetOfTax": TaxonomyMapping(
        "ComprehensiveIncomeNetOfTax", "Comprehensive Income", "income_statement"
    ),
    "DepreciationAndAmortization": TaxonomyMapping(
        "DepreciationAndAmortization", "Depreciation & Amortization", "income_statement"
    ),
    "DepreciationDepletionAndAmortization": TaxonomyMapping(
        "DepreciationDepletionAndAmortization", "DD&A", "income_statement"
    ),
    # Balance sheet - assets
    "Assets": TaxonomyMapping("Assets", "Total Assets", "balance_sheet"),
    "AssetsCurrent": TaxonomyMapping("AssetsCurrent", "Current Assets", "balance_sheet"),
    "CashAndCashEquivalentsAtCarryingValue": TaxonomyMapping(
        "CashAndCashEquivalentsAtCarryingValue", "Cash and Cash Equivalents", "balance_sheet"
    ),
    "ShortTermInvestments": TaxonomyMapping(
        "ShortTermInvestments", "Short-Term Investments", "balance_sheet"
    ),
    "AccountsReceivableNetCurrent": TaxonomyMapping(
        "AccountsReceivableNetCurrent", "Accounts Receivable", "balance_sheet"
    ),
    "InventoryNet": TaxonomyMapping("InventoryNet", "Inventory", "balance_sheet"),
    "PropertyPlantAndEquipmentNet": TaxonomyMapping(
        "PropertyPlantAndEquipmentNet", "PP&E (Net)", "balance_sheet"
    ),
    "Goodwill": TaxonomyMapping("Goodwill", "Goodwill", "balance_sheet"),
    "IntangibleAssetsNetExcludingGoodwill": TaxonomyMapping(
        "IntangibleAssetsNetExcludingGoodwill", "Intangible Assets", "balance_sheet"
    ),
    "AssetsNoncurrent": TaxonomyMapping("AssetsNoncurrent", "Non-Current Assets", "balance_sheet"),
    "OtherAssetsNoncurrent": TaxonomyMapping(
        "OtherAssetsNoncurrent", "Other Non-Current Assets", "balance_sheet"
    ),
    "PrepaidExpenseAndOtherAssetsCurrent": TaxonomyMapping(
        "PrepaidExpenseAndOtherAssetsCurrent", "Prepaid Expenses", "balance_sheet"
    ),
    "MarketableSecuritiesCurrent": TaxonomyMapping(
        "MarketableSecuritiesCurrent", "Marketable Securities (Current)", "balance_sheet"
    ),
    # Balance sheet - liabilities
    "Liabilities": TaxonomyMapping("Liabilities", "Total Liabilities", "balance_sheet"),
    "LiabilitiesCurrent": TaxonomyMapping(
        "LiabilitiesCurrent", "Current Liabilities", "balance_sheet"
    ),
    "AccountsPayableCurrent": TaxonomyMapping(
        "AccountsPayableCurrent", "Accounts Payable", "balance_sheet"
    ),
    "LongTermDebtNoncurrent": TaxonomyMapping(
        "LongTermDebtNoncurrent", "Long-Term Debt", "balance_sheet"
    ),
    "LongTermDebt": TaxonomyMapping("LongTermDebt", "Long-Term Debt", "balance_sheet"),
    "ShortTermBorrowings": TaxonomyMapping(
        "ShortTermBorrowings", "Short-Term Borrowings", "balance_sheet"
    ),
    "AccruedLiabilitiesCurrent": TaxonomyMapping(
        "AccruedLiabilitiesCurrent", "Accrued Liabilities", "balance_sheet"
    ),
    "DeferredRevenueCurrent": TaxonomyMapping(
        "DeferredRevenueCurrent", "Deferred Revenue (Current)", "balance_sheet"
    ),
    "DeferredRevenueNoncurrent": TaxonomyMapping(
        "DeferredRevenueNoncurrent", "Deferred Revenue (Non-Current)", "balance_sheet"
    ),
    "LiabilitiesNoncurrent": TaxonomyMapping(
        "LiabilitiesNoncurrent", "Non-Current Liabilities", "balance_sheet"
    ),
    "OperatingLeaseLiabilityCurrent": TaxonomyMapping(
        "OperatingLeaseLiabilityCurrent", "Operating Lease Liability (Current)", "balance_sheet"
    ),
    "OperatingLeaseLiabilityNoncurrent": TaxonomyMapping(
        "OperatingLeaseLiabilityNoncurrent",
        "Operating Lease Liability (Non-Current)",
        "balance_sheet",
    ),
    # Equity
    "StockholdersEquity": TaxonomyMapping(
        "StockholdersEquity", "Stockholders' Equity", "balance_sheet"
    ),
    "RetainedEarningsAccumulatedDeficit": TaxonomyMapping(
        "RetainedEarningsAccumulatedDeficit", "Retained Earnings", "balance_sheet"
    ),
    "CommonStockValue": TaxonomyMapping("CommonStockValue", "Common Stock", "balance_sheet"),
    "AdditionalPaidInCapital": TaxonomyMapping(
        "AdditionalPaidInCapital", "Additional Paid-In Capital", "balance_sheet"
    ),
    "TreasuryStockValue": TaxonomyMapping("TreasuryStockValue", "Treasury Stock", "balance_sheet"),
    "AccumulatedOtherComprehensiveIncomeLossNetOfTax": TaxonomyMapping(
        "AccumulatedOtherComprehensiveIncomeLossNetOfTax", "AOCI", "balance_sheet"
    ),
    "CommonStockSharesOutstanding": TaxonomyMapping(
        "CommonStockSharesOutstanding", "Shares Outstanding", "balance_sheet"
    ),
    "CommonStockSharesAuthorized": TaxonomyMapping(
        "CommonStockSharesAuthorized", "Shares Authorized", "balance_sheet"
    ),
    "CommonStockSharesIssued": TaxonomyMapping(
        "CommonStockSharesIssued", "Shares Issued", "balance_sheet"
    ),
    "CommonStockParOrStatedValuePerShare": TaxonomyMapping(
        "CommonStockParOrStatedValuePerShare", "Par Value Per Share", "balance_sheet"
    ),
    "LiabilitiesAndStockholdersEquity": TaxonomyMapping(
        "LiabilitiesAndStockholdersEquity",
        "Total Liabilities & Stockholders' Equity",
        "balance_sheet",
    ),
    # Cash flow statement
    "NetCashProvidedByUsedInOperatingActivities": TaxonomyMapping(
        "NetCashProvidedByUsedInOperatingActivities",
        "Operating Cash Flow",
        "cash_flow",
    ),
    "NetCashProvidedByUsedInInvestingActivities": TaxonomyMapping(
        "NetCashProvidedByUsedInInvestingActivities",
        "Investing Cash Flow",
        "cash_flow",
    ),
    "NetCashProvidedByUsedInFinancingActivities": TaxonomyMapping(
        "NetCashProvidedByUsedInFinancingActivities",
        "Financing Cash Flow",
        "cash_flow",
    ),
    "PaymentsToAcquirePropertyPlantAndEquipment": TaxonomyMapping(
        "PaymentsToAcquirePropertyPlantAndEquipment", "Capital Expenditures", "cash_flow"
    ),
    "PaymentsOfDividends": TaxonomyMapping("PaymentsOfDividends", "Dividends Paid", "cash_flow"),
    "PaymentsForRepurchaseOfCommonStock": TaxonomyMapping(
        "PaymentsForRepurchaseOfCommonStock", "Stock Repurchases", "cash_flow"
    ),
    "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect": TaxonomyMapping(
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect",
        "Net Change in Cash",
        "cash_flow",
    ),
    "ShareBasedCompensation": TaxonomyMapping(
        "ShareBasedCompensation", "Stock-Based Compensation", "cash_flow"
    ),
    "ProceedsFromIssuanceOfLongTermDebt": TaxonomyMapping(
        "ProceedsFromIssuanceOfLongTermDebt", "Debt Issuance Proceeds", "cash_flow"
    ),
    "RepaymentsOfLongTermDebt": TaxonomyMapping(
        "RepaymentsOfLongTermDebt", "Debt Repayments", "cash_flow"
    ),
    # Other common
    "WeightedAverageNumberOfSharesOutstandingBasic": TaxonomyMapping(
        "WeightedAverageNumberOfSharesOutstandingBasic",
        "Weighted Avg Shares (Basic)",
        "per_share",
    ),
    "WeightedAverageNumberOfDilutedSharesOutstanding": TaxonomyMapping(
        "WeightedAverageNumberOfDilutedSharesOutstanding",
        "Weighted Avg Shares (Diluted)",
        "per_share",
    ),
    "DividendsCommonStockCash": TaxonomyMapping(
        "DividendsCommonStockCash", "Dividends Per Share", "per_share"
    ),
    "EntityCommonStockSharesOutstanding": TaxonomyMapping(
        "EntityCommonStockSharesOutstanding", "Shares Outstanding (Entity)", "entity"
    ),
    "EntityPublicFloat": TaxonomyMapping("EntityPublicFloat", "Public Float", "entity"),
}

# IFRS taxonomy subset
_IFRS_TAXONOMY: dict[str, TaxonomyMapping] = {
    "Revenue": TaxonomyMapping("Revenue", "Revenue", "income_statement"),
    "CostOfSales": TaxonomyMapping("CostOfSales", "Cost of Sales", "income_statement"),
    "GrossProfit": TaxonomyMapping("GrossProfit", "Gross Profit", "income_statement"),
    "ProfitLoss": TaxonomyMapping("ProfitLoss", "Profit (Loss)", "income_statement"),
    "ProfitLossAttributableToOwnersOfParent": TaxonomyMapping(
        "ProfitLossAttributableToOwnersOfParent",
        "Profit Attributable to Owners",
        "income_statement",
    ),
    "BasicEarningsLossPerShare": TaxonomyMapping(
        "BasicEarningsLossPerShare", "EPS (Basic)", "per_share"
    ),
    "DilutedEarningsLossPerShare": TaxonomyMapping(
        "DilutedEarningsLossPerShare", "EPS (Diluted)", "per_share"
    ),
    "Assets": TaxonomyMapping("Assets", "Total Assets", "balance_sheet"),
    "CurrentAssets": TaxonomyMapping("CurrentAssets", "Current Assets", "balance_sheet"),
    "NoncurrentAssets": TaxonomyMapping("NoncurrentAssets", "Non-Current Assets", "balance_sheet"),
    "Equity": TaxonomyMapping("Equity", "Total Equity", "balance_sheet"),
    "Liabilities": TaxonomyMapping("Liabilities", "Total Liabilities", "balance_sheet"),
    "CurrentLiabilities": TaxonomyMapping(
        "CurrentLiabilities", "Current Liabilities", "balance_sheet"
    ),
    "NoncurrentLiabilities": TaxonomyMapping(
        "NoncurrentLiabilities", "Non-Current Liabilities", "balance_sheet"
    ),
    "CashAndCashEquivalents": TaxonomyMapping(
        "CashAndCashEquivalents", "Cash and Cash Equivalents", "balance_sheet"
    ),
    "PropertyPlantAndEquipment": TaxonomyMapping(
        "PropertyPlantAndEquipment", "PP&E", "balance_sheet"
    ),
    "IncomeTaxExpenseContinuingOperations": TaxonomyMapping(
        "IncomeTaxExpenseContinuingOperations", "Income Tax", "income_statement"
    ),
}

# Common XBRL namespaces
_NS: dict[str, str] = {
    "xbrli": "http://www.xbrl.org/2003/instance",
    "us-gaap": "http://fasb.org/us-gaap/2023",
    "dei": "http://xbrl.sec.gov/dei/2023",
    "ifrs-full": "http://xbrl.ifrs.org/taxonomy/2023-03-23/ifrs-full",
    "link": "http://www.xbrl.org/2003/linkbase",
    "xlink": "http://www.w3.org/1999/xlink",
    "ix": "http://www.xbrl.org/2013/inlineXBRL",
}

# iXBRL tag patterns
_IXBRL_FACT_RE = re.compile(
    r"<ix:(?:nonFraction|nonNumeric|fraction)"
    r'[^>]*name="([^"]+)"'
    r'[^>]*contextRef="([^"]+)"'
    r"[^>]*>(.*?)</ix:",
    re.DOTALL | re.IGNORECASE,
)
_IXBRL_FACT_ALT_RE = re.compile(
    r"<ix:(?:nonFraction|nonNumeric|fraction)"
    r'[^>]*contextRef="([^"]+)"'
    r'[^>]*name="([^"]+)"'
    r"[^>]*>(.*?)</ix:",
    re.DOTALL | re.IGNORECASE,
)
_IXBRL_UNIT_RE = re.compile(
    r'unitRef="([^"]+)"',
    re.IGNORECASE,
)
_IXBRL_DECIMALS_RE = re.compile(
    r'decimals="([^"]+)"',
    re.IGNORECASE,
)

# Unit normalisation map
_UNIT_ALIASES: dict[str, str] = {
    "iso4217:USD": "USD",
    "iso4217:EUR": "EUR",
    "iso4217:GBP": "GBP",
    "iso4217:JPY": "JPY",
    "iso4217:CNY": "CNY",
    "iso4217:CAD": "CAD",
    "iso4217:AUD": "AUD",
    "iso4217:CHF": "CHF",
    "usd": "USD",
    "eur": "EUR",
    "gbp": "GBP",
    "jpy": "JPY",
    "shares": "shares",
    "pure": "pure",
    "xbrli:shares": "shares",
    "xbrli:pure": "pure",
    "usdpershare": "USD/share",
    "eurpershare": "EUR/share",
}


def _parse_date(text: str) -> date | None:
    """Parse an ISO date string to a :class:`date`."""
    text = text.strip()
    try:
        return datetime.strptime(text[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _strip_ns_prefix(tag: str) -> str:
    """Remove namespace URI prefix from an XML tag."""
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


# ---------------------------------------------------------------------------
# XBRLParser
# ---------------------------------------------------------------------------


class XBRLParser:
    """Parser for XBRL and inline XBRL (iXBRL) documents.

    Extracts structured :class:`FinancialFact` records from XBRL instance
    documents (XML) and iXBRL documents (HTML with embedded XBRL tags).

    Example::

        parser = XBRLParser()
        facts = parser.parse_xbrl(xml_content)
        for fact in facts:
            print(fact.label, fact.value, fact.unit)
    """

    def parse_xbrl(self, content: str) -> list[FinancialFact]:
        """Parse an XML-based XBRL instance document.

        Args:
            content: Raw XML content of the XBRL file.

        Returns:
            A list of :class:`FinancialFact` records.
        """
        try:
            root = ET.fromstring(content)
        except ET.ParseError as exc:
            logger.warning("Failed to parse XBRL XML: %s", exc)
            return []

        contexts = self._extract_contexts(root)
        units = self._extract_units(root)

        facts: list[FinancialFact] = []
        for elem in root.iter():
            tag = _strip_ns_prefix(elem.tag)
            context_ref = elem.get("contextRef")
            if context_ref is None:
                continue

            text = (elem.text or "").strip()
            if not text:
                continue

            taxonomy = self.resolve_taxonomy(tag)
            temporal = contexts.get(context_ref)

            unit_ref = elem.get("unitRef", "")
            unit_str = units.get(unit_ref, unit_ref)
            value, unit_normalised = self.normalize_units(text, unit_str)

            decimals_raw = elem.get("decimals")
            decimals: int | None = None
            if decimals_raw is not None and decimals_raw.lstrip("-").isdigit():
                decimals = int(decimals_raw)

            facts.append(
                FinancialFact(
                    concept=tag,
                    label=taxonomy.label,
                    value=text,
                    unit=unit_normalised,
                    period_type=temporal.period_type if temporal else "",
                    period_start=temporal.start_date if temporal else None,
                    period_end=temporal.end_date if temporal else None,
                    decimals=decimals,
                    metadata={
                        "context_ref": context_ref,
                        "unit_ref": unit_ref,
                        "category": taxonomy.category,
                    },
                )
            )

        return facts

    def parse_ixbrl(self, html_content: str) -> list[FinancialFact]:
        """Parse an inline XBRL (iXBRL) document embedded in HTML.

        Uses regex extraction since iXBRL is embedded in HTML that may
        not be well-formed XML.

        Args:
            html_content: Raw HTML content containing iXBRL tags.

        Returns:
            A list of :class:`FinancialFact` records.
        """
        facts: list[FinancialFact] = []

        for match in _IXBRL_FACT_RE.finditer(html_content):
            name = match.group(1)
            context_ref = match.group(2)
            value_raw = match.group(3).strip()
            facts.append(self._build_ixbrl_fact(name, context_ref, value_raw, match.group(0)))

        for match in _IXBRL_FACT_ALT_RE.finditer(html_content):
            context_ref = match.group(1)
            name = match.group(2)
            value_raw = match.group(3).strip()
            if not any(
                f.concept == name.split(":")[-1] and f.metadata.get("context_ref") == context_ref
                for f in facts
            ):
                facts.append(self._build_ixbrl_fact(name, context_ref, value_raw, match.group(0)))

        return facts

    def _build_ixbrl_fact(
        self, name: str, context_ref: str, value_raw: str, full_tag: str
    ) -> FinancialFact:
        """Build a FinancialFact from iXBRL regex match components."""
        concept = name.split(":")[-1] if ":" in name else name
        taxonomy = self.resolve_taxonomy(concept)

        unit_match = _IXBRL_UNIT_RE.search(full_tag)
        unit_ref = unit_match.group(1) if unit_match else ""
        _, unit_normalised = self.normalize_units(value_raw, unit_ref)

        decimals_match = _IXBRL_DECIMALS_RE.search(full_tag)
        decimals: int | None = None
        if decimals_match:
            dec_str = decimals_match.group(1)
            if dec_str.lstrip("-").isdigit():
                decimals = int(dec_str)

        # Strip HTML tags from value
        clean_value = re.sub(r"<[^>]+>", "", value_raw).strip()

        return FinancialFact(
            concept=concept,
            label=taxonomy.label,
            value=clean_value,
            unit=unit_normalised,
            decimals=decimals,
            metadata={
                "context_ref": context_ref,
                "unit_ref": unit_ref,
                "category": taxonomy.category,
                "source": "ixbrl",
            },
        )

    def resolve_taxonomy(self, concept: str) -> TaxonomyMapping:
        """Resolve a concept name to a human-readable taxonomy mapping.

        Looks up the concept in US-GAAP first, then IFRS. Falls back to
        a generated label from the concept name itself.

        Args:
            concept: The XBRL concept name (with or without namespace prefix).

        Returns:
            A :class:`TaxonomyMapping` with label and category.
        """
        clean = concept.split(":")[-1] if ":" in concept else concept

        if clean in _US_GAAP_TAXONOMY:
            return _US_GAAP_TAXONOMY[clean]

        if clean in _IFRS_TAXONOMY:
            return _IFRS_TAXONOMY[clean]

        # Auto-generate a readable label from CamelCase
        label = re.sub(r"([a-z])([A-Z])", r"\1 \2", clean)
        label = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", label)
        return TaxonomyMapping(raw_concept=clean, label=label, category="other")

    def normalize_units(self, value: str, unit: str) -> tuple[float, str]:
        """Normalise a value/unit pair to a standard form.

        Args:
            value: Raw string value from the XBRL fact.
            unit: Raw unit string (may be an ISO 4217 code, XBRL unit ref, etc.).

        Returns:
            A tuple of ``(numeric_value, normalised_unit_string)``.
            If the value cannot be parsed as a number, returns ``(0.0, unit)``.
        """
        # Normalise the unit string
        unit_lower = unit.lower().strip()
        normalised_unit = _UNIT_ALIASES.get(unit_lower, _UNIT_ALIASES.get(unit, unit))

        # Clean numeric value
        clean = value.replace(",", "").replace(" ", "").strip()
        # Handle parenthesised negatives: (123) → -123
        if clean.startswith("(") and clean.endswith(")"):
            clean = "-" + clean[1:-1]

        try:
            numeric = float(clean)
        except ValueError:
            return 0.0, normalised_unit

        return numeric, normalised_unit

    def _extract_contexts(self, root: ET.Element) -> dict[str, TemporalContext]:
        """Extract all XBRL context elements into :class:`TemporalContext` dicts.

        Args:
            root: The parsed XML root element.

        Returns:
            A mapping of context ID to :class:`TemporalContext`.
        """
        contexts: dict[str, TemporalContext] = {}

        for elem in root.iter():
            tag = _strip_ns_prefix(elem.tag)
            if tag != "context":
                continue

            ctx_id = elem.get("id", "")
            if not ctx_id:
                continue

            period_type = ""
            start_date: date | None = None
            end_date: date | None = None

            for child in elem.iter():
                child_tag = _strip_ns_prefix(child.tag)
                text = (child.text or "").strip()
                if child_tag == "instant" and text:
                    period_type = "instant"
                    end_date = _parse_date(text)
                elif child_tag == "startDate" and text:
                    period_type = "duration"
                    start_date = _parse_date(text)
                elif child_tag == "endDate" and text:
                    end_date = _parse_date(text)

            contexts[ctx_id] = TemporalContext(
                context_ref=ctx_id,
                period_type=period_type,
                start_date=start_date,
                end_date=end_date,
            )

        return contexts

    def _extract_units(self, root: ET.Element) -> dict[str, str]:
        """Extract all XBRL unit elements into a lookup dict.

        Args:
            root: The parsed XML root element.

        Returns:
            A mapping of unit ID to unit string.
        """
        units: dict[str, str] = {}

        for elem in root.iter():
            tag = _strip_ns_prefix(elem.tag)
            if tag != "unit":
                continue

            unit_id = elem.get("id", "")
            if not unit_id:
                continue

            # Check for <measure> child
            for child in elem.iter():
                child_tag = _strip_ns_prefix(child.tag)
                if child_tag == "measure" and child.text:
                    units[unit_id] = child.text.strip()
                    break
                elif child_tag == "divide":
                    # Handle divide (e.g., USD/share)
                    numerator = ""
                    denominator = ""
                    for div_child in child.iter():
                        div_tag = _strip_ns_prefix(div_child.tag)
                        if div_tag == "unitNumerator":
                            for m in div_child.iter():
                                if _strip_ns_prefix(m.tag) == "measure" and m.text:
                                    numerator = m.text.strip()
                        elif div_tag == "unitDenominator":
                            for m in div_child.iter():
                                if _strip_ns_prefix(m.tag) == "measure" and m.text:
                                    denominator = m.text.strip()
                    if numerator and denominator:
                        units[unit_id] = f"{numerator}/{denominator}"
                    break

        return units
