"""Storage sinks for the ingestion pipeline.

Sinks receive parsed chunks and persist them to various backends.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from aegis.ingestion.parsers import ParsedChunk

logger = logging.getLogger(__name__)

try:
    from sentence_transformers import SentenceTransformer

    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False


class Sink(ABC):
    """Abstract base class for ingestion storage sinks.

    Sinks receive parsed chunks from the ingestion pipeline and persist
    them to a storage backend (vector store, knowledge graph, etc.).
    """

    @property
    def name(self) -> str:
        """Human-readable name for this sink."""
        return type(self).__name__

    @abstractmethod
    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        """Write chunks to the storage backend.

        Args:
            chunks: Parsed chunks to persist.
            document_id: Unique identifier for the source document.
            metadata: Additional metadata for the write operation.

        Returns:
            Count of items written.
        """
        ...

    @abstractmethod
    def flush(self) -> None:
        """Flush any buffered writes."""
        ...


class PgVectorSink(Sink):
    """Sink that persists chunks as :class:`MemoryEntry` rows in pgvector.

    Each :class:`ParsedChunk` is converted to a :class:`MemoryEntry` and
    stored via :class:`PgVectorStore`.  When ``sentence-transformers`` is
    available, chunk contents are embedded before storage.

    Args:
        store: An existing :class:`PgVectorStore` instance, **or** ``None``
            to create one from *dsn*.
        dsn: PostgreSQL connection string.  Ignored when *store* is given.
        enable_embeddings: Whether to embed chunk content.
    """

    def __init__(
        self,
        store: Any | None = None,
        dsn: str | None = None,
        enable_embeddings: bool = True,
    ) -> None:
        if store is not None:
            self._store = store
        else:
            if dsn is None:
                raise ValueError("Either store or dsn must be provided")
            from aegis.store.postgres import PgVectorStore

            self._store = PgVectorStore(dsn=dsn, enable_embeddings=enable_embeddings)

        self._model: Any | None = None
        if enable_embeddings and _HAS_EMBEDDINGS:
            self._model = SentenceTransformer("all-MiniLM-L6-v2")

    @property
    def name(self) -> str:
        return "PgVectorSink"

    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        """Convert each chunk to a MemoryEntry and store it.

        Returns the count of entries stored.
        """
        from aegis.core.types import MemoryTier
        from aegis.memory.types import MemoryEntry

        count = 0
        for chunk in chunks:
            key = f"{document_id}:chunk:{chunk.chunk_index}"
            entry = MemoryEntry(
                key=key,
                value=chunk.content,
                tier=MemoryTier.WORKING,
                confidence=chunk.confidence,
                provenance={
                    "source_path": chunk.source_path,
                    "document_id": document_id,
                    "chunk_index": chunk.chunk_index,
                    "modality": chunk.modality.value,
                },
                tags=[f"doc:{document_id}", f"modality:{chunk.modality.value}"],
                metadata={
                    **chunk.metadata,
                    **metadata,
                    "document_id": document_id,
                    "chunk_index": chunk.chunk_index,
                },
            )
            try:
                self._store.store(entry)
                count += 1
            except Exception:
                logger.exception("Failed to store chunk %s", key)

        return count

    def flush(self) -> None:
        """No-op — PgVectorStore commits per write."""


class Neo4jSink(Sink):
    """Sink that builds a knowledge graph from ingested chunks.

    Uses :class:`SimpleEntityExtractor` to find entities and relations,
    then persists them via :class:`Neo4jGraph`.  A ``Document`` node is
    created for each ingestion and ``CONTAINS`` edges link it to every
    chunk's entity nodes.

    Args:
        graph: An existing :class:`Neo4jGraph` instance, **or** ``None``
            to create one from connection parameters.
        uri: Neo4j bolt URI.  Ignored when *graph* is given.
        user: Neo4j username.
        password: Neo4j password.
    """

    def __init__(
        self,
        graph: Any | None = None,
        uri: str | None = None,
        user: str = "neo4j",
        password: str = "",
    ) -> None:
        if graph is not None:
            self._graph = graph
        else:
            if uri is None:
                raise ValueError("Either graph or uri must be provided")
            from aegis.store.neo4j import Neo4jGraph

            self._graph = Neo4jGraph(uri=uri, user=user, password=password)

    @property
    def name(self) -> str:
        return "Neo4jSink"

    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        """Extract entities from each chunk and build a knowledge graph.

        Creates a document node, entity nodes, and edges.
        Returns the total count of nodes + edges created.
        """
        from aegis.ingestion.entity_extractor import SimpleEntityExtractor

        extractor = SimpleEntityExtractor()
        count = 0

        # Create document node
        doc_node_id = f"doc:{document_id}"
        try:
            self._graph.add_node(doc_node_id)
            count += 1
        except Exception:
            logger.exception("Failed to create document node %s", doc_node_id)

        for chunk in chunks:
            chunk_node_id = f"chunk:{document_id}:{chunk.chunk_index}"

            # Create chunk node and connect to document
            try:
                self._graph.add_node(chunk_node_id)
                count += 1
                self._graph.add_edge(
                    source=doc_node_id,
                    target=chunk_node_id,
                    relation="CONTAINS",
                    weight=1.0,
                    metadata={
                        "chunk_index": chunk.chunk_index,
                        "source_path": chunk.source_path,
                    },
                )
                count += 1
            except Exception:
                logger.exception("Failed to create chunk node %s", chunk_node_id)

            # Extract entities and relations
            try:
                extracted = extractor.extract(chunk.content)
            except Exception:
                logger.exception("Entity extraction failed for chunk %s", chunk_node_id)
                continue

            # Create entity nodes and link to chunk
            seen_entities: set[str] = set()
            for entity in extracted.entities:
                entity_node_id = f"entity:{entity.entity_type}:{entity.text}"
                if entity_node_id not in seen_entities:
                    seen_entities.add(entity_node_id)
                    try:
                        self._graph.add_node(entity_node_id)
                        count += 1
                        self._graph.add_edge(
                            source=chunk_node_id,
                            target=entity_node_id,
                            relation="MENTIONS",
                            weight=1.0,
                            metadata={"entity_type": entity.entity_type},
                        )
                        count += 1
                    except Exception:
                        logger.exception(
                            "Failed to create entity node %s",
                            entity_node_id,
                        )

            # Create relation edges between entities
            for relation in extracted.relations:
                subject_id = self._find_entity_node_id(relation.subject, extracted.entities)
                object_id = self._find_entity_node_id(relation.object, extracted.entities)
                if subject_id and object_id:
                    try:
                        self._graph.add_edge(
                            source=subject_id,
                            target=object_id,
                            relation=relation.predicate,
                            weight=relation.confidence,
                        )
                        count += 1
                    except Exception:
                        logger.exception(
                            "Failed to create relation edge %s -> %s",
                            subject_id,
                            object_id,
                        )

        return count

    def flush(self) -> None:
        """No-op — Neo4jGraph commits per operation."""

    @staticmethod
    def _find_entity_node_id(
        text: str,
        entities: list[Any],
    ) -> str | None:
        """Find the node ID for an entity by its text."""
        for entity in entities:
            if entity.text == text:
                return f"entity:{entity.entity_type}:{entity.text}"
        return None


class CompositeSink(Sink):
    """Sink that delegates writes to multiple child sinks.

    Writes to all sinks and returns the sum of items written across
    all backends.

    Args:
        sinks: Child sinks to write to.
    """

    def __init__(self, sinks: list[Sink]) -> None:
        self._sinks = list(sinks)

    @property
    def name(self) -> str:
        return "CompositeSink"

    @property
    def sinks(self) -> list[Sink]:
        """Return the list of child sinks."""
        return list(self._sinks)

    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        """Write chunks to all child sinks.

        Returns the total count across all sinks.
        """
        total = 0
        for sink in self._sinks:
            try:
                total += sink.write(chunks, document_id, metadata)
            except Exception:
                logger.exception("Sink %s failed during write", sink.name)
        return total

    def flush(self) -> None:
        """Flush all child sinks."""
        for sink in self._sinks:
            try:
                sink.flush()
            except Exception:
                logger.exception("Sink %s failed during flush", sink.name)
