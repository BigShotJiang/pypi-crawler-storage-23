"""Image ingestion pipeline for charts, diagrams, and scanned documents.

Provides OCR, chart understanding, and multimodal embedding generation.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "ImageAnalysis",
    "ImageIngester",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ImageAnalysis:
    """Result of analysing an image.

    Attributes:
        description: Human-readable description of the image content.
        text_content: Text extracted via OCR.
        objects: List of detected object labels.
        chart_data: Extracted chart data (if the image is a chart), or ``None``.
        metadata: Arbitrary metadata about the analysis.
    """

    description: str
    text_content: str = ""
    objects: list[str] = field(default_factory=list)
    chart_data: dict[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# OCR helpers
# ---------------------------------------------------------------------------


def _ocr_tesseract(path: str) -> str:
    """Run Tesseract OCR on an image file.

    Returns the extracted text, or an empty string if Tesseract is not
    available.
    """
    try:
        import pytesseract  # type: ignore[import-not-found]
        from PIL import Image

        img = Image.open(path)
        text: str = pytesseract.image_to_string(img)
        return text.strip()
    except ImportError:
        logger.debug("pytesseract/Pillow not installed; trying subprocess fallback.")
    except Exception:
        logger.exception("pytesseract OCR failed for %s", path)

    # Subprocess fallback
    try:
        import subprocess

        result = subprocess.run(
            ["tesseract", path, "stdout"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    logger.warning(
        "Tesseract OCR not available. "
        "Install with: pip install pytesseract Pillow  "
        "(and install tesseract-ocr system package)"
    )
    return ""


def _get_image_info(path: str) -> dict[str, Any]:
    """Extract basic image metadata (dimensions, format) without heavy deps."""
    info: dict[str, Any] = {"path": path}
    filepath = Path(path)
    info["extension"] = filepath.suffix.lower()
    info["file_size_bytes"] = filepath.stat().st_size if filepath.exists() else 0

    # Try Pillow
    try:
        from PIL import Image

        img = Image.open(path)
        info["width"] = img.width
        info["height"] = img.height
        info["format"] = img.format or filepath.suffix.lstrip(".")
        info["mode"] = img.mode
        img.close()
        return info
    except ImportError:
        pass
    except Exception:
        logger.debug("Pillow failed to read image %s", path)

    # Minimal header parsing for PNG/JPEG dimensions
    try:
        with open(path, "rb") as f:
            header = f.read(32)
            if header[:8] == b"\x89PNG\r\n\x1a\n":
                # PNG: width/height at offset 16 as 4-byte big-endian ints
                import struct

                info["width"] = struct.unpack(">I", header[16:20])[0]
                info["height"] = struct.unpack(">I", header[20:24])[0]
                info["format"] = "PNG"
            elif header[:2] == b"\xff\xd8":
                info["format"] = "JPEG"
    except (OSError, struct.error):
        pass

    return info


# ---------------------------------------------------------------------------
# Chart detection heuristics
# ---------------------------------------------------------------------------

_CHART_KEYWORDS = {
    "bar": ["bar", "histogram", "column"],
    "line": ["line", "trend", "series", "time series"],
    "pie": ["pie", "donut", "doughnut"],
    "table": ["table", "grid", "spreadsheet"],
    "diagram": ["flow", "diagram", "process", "architecture", "uml"],
    "scan": ["scan", "scanned", "photocopy"],
}


def _classify_by_text(text: str) -> str:
    """Classify an image by its OCR text content."""
    lower = text.lower()

    # High numeric density suggests a table or chart
    numeric_tokens = re.findall(r"\d+(?:\.\d+)?", lower)
    word_tokens = lower.split()
    numeric_ratio = len(numeric_tokens) / len(word_tokens) if word_tokens else 0.0

    # Check for axis labels common in charts
    has_axis = bool(re.search(r"(?:x[- ]?axis|y[- ]?axis|\baxis\b)", lower))

    if has_axis or numeric_ratio > 0.5:
        # Likely a chart — try to determine type from keywords
        for chart_type, keywords in _CHART_KEYWORDS.items():
            for kw in keywords:
                if kw in lower:
                    return chart_type
        return "bar"  # default chart type

    if numeric_ratio > 0.3:
        return "table"

    if len(text.strip()) > 200:
        return "scan"  # lots of text = probably scanned doc

    return "photo"


def _classify_by_pixels(path: str) -> str | None:
    """Classify image by pixel statistics (requires Pillow)."""
    try:
        from PIL import Image

        img = Image.open(path).convert("RGB")
        width, height = img.size

        # Sample pixels to determine content type
        pixels = list(img.getdata())
        total = len(pixels)
        if total == 0:
            return None

        # Count unique colours
        sample = pixels[:: max(1, total // 1000)]  # sample up to 1000
        unique_colors = len(set(sample))

        # Very few colours → chart/diagram
        if unique_colors < 20:
            return "diagram"
        if unique_colors < 50:
            return "bar"

        # Check white-background ratio (common in documents/charts)
        white_count = sum(1 for r, g, b in sample if r > 240 and g > 240 and b > 240)
        white_ratio = white_count / len(sample)

        if white_ratio > 0.7:
            return "scan"  # document/chart on white background

        return "photo"
    except ImportError:
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Chart data extraction
# ---------------------------------------------------------------------------


def _extract_chart_data_from_text(text: str, chart_type: str) -> dict[str, Any] | None:
    """Attempt to reconstruct chart data from OCR text.

    This is a best-effort heuristic that looks for label-value pairs.
    """
    if not text.strip():
        return None

    lines = [line.strip() for line in text.split("\n") if line.strip()]
    data_points: list[dict[str, str]] = []

    for line in lines:
        # Look for "Label  Value" or "Label: Value" patterns
        m = re.match(r"^(.+?)\s{2,}(\$?[\d,.]+%?)\s*$", line)
        if not m:
            m = re.match(r"^(.+?):\s*(\$?[\d,.]+%?)\s*$", line)
        if m:
            data_points.append({"label": m.group(1).strip(), "value": m.group(2).strip()})

    if not data_points:
        return None

    return {
        "chart_type": chart_type,
        "data_points": data_points,
        "num_points": len(data_points),
    }


# ---------------------------------------------------------------------------
# ImageIngester
# ---------------------------------------------------------------------------


class ImageIngester:
    """Analyse and extract information from images.

    Provides OCR, chart-type detection, chart data extraction, and
    conversion to Aegis memory entries.

    Args:
        ocr_engine: OCR engine to use (default ``"tesseract"``).
    """

    def __init__(self, ocr_engine: str = "tesseract") -> None:
        self._ocr_engine = ocr_engine

    def analyze(self, path: str) -> ImageAnalysis:
        """Analyse an image: run OCR, detect chart type, extract data.

        Args:
            path: Path to the image file.

        Returns:
            An :class:`ImageAnalysis` with description, text, and chart data.

        Raises:
            FileNotFoundError: If the image file does not exist.
        """
        filepath = Path(path)
        if not filepath.exists():
            raise FileNotFoundError(f"Image file not found: {path}")

        info = _get_image_info(path)
        text = self.ocr(path)
        chart_type = self.detect_chart_type(path)
        chart_data = self.extract_chart_data(path)

        # Build description
        dims = ""
        if "width" in info and "height" in info:
            dims = f"{info['width']}x{info['height']} "

        fmt = info.get("format", filepath.suffix.lstrip(".")).upper()
        desc_parts = [f"{dims}{fmt} image"]

        if chart_type not in ("photo", "scan"):
            desc_parts.append(f"detected as {chart_type} chart")
        elif chart_type == "scan":
            desc_parts.append("detected as scanned document")

        if text:
            preview = text[:120].replace("\n", " ")
            desc_parts.append(f'OCR text: "{preview}"')

        description = "; ".join(desc_parts)

        objects: list[str] = []
        if chart_type != "photo":
            objects.append(chart_type)

        return ImageAnalysis(
            description=description,
            text_content=text,
            objects=objects,
            chart_data=chart_data,
            metadata=info,
        )

    def ocr(self, path: str) -> str:
        """Extract text from an image via OCR.

        Uses Tesseract when available, otherwise returns an empty string.

        Args:
            path: Path to the image file.

        Returns:
            Extracted text content.
        """
        if self._ocr_engine == "tesseract":
            return _ocr_tesseract(path)
        logger.warning("Unsupported OCR engine: %s", self._ocr_engine)
        return ""

    def detect_chart_type(self, path: str) -> str:
        """Detect the type of visual content in an image.

        Returns one of: ``"bar"``, ``"line"``, ``"pie"``, ``"table"``,
        ``"diagram"``, ``"photo"``, or ``"scan"``.

        Uses a combination of pixel analysis and OCR text heuristics.

        Args:
            path: Path to the image file.

        Returns:
            A string label for the detected chart/image type.
        """
        # Try pixel-based classification first
        pixel_type = _classify_by_pixels(path)

        # Then use OCR text
        text = self.ocr(path)
        text_type = _classify_by_text(text) if text else "photo"

        # Merge: prefer text-based if it's specific, else use pixel
        if text_type in ("bar", "line", "pie", "table", "diagram"):
            return text_type
        if pixel_type and pixel_type != "photo":
            return pixel_type
        return text_type

    def extract_chart_data(self, path: str) -> dict[str, Any] | None:
        """Attempt to extract structured data from a chart image.

        Uses OCR to read labels and values, then structures them
        into data points.

        Args:
            path: Path to the image file.

        Returns:
            A dict with chart data, or ``None`` if extraction fails.
        """
        text = self.ocr(path)
        if not text:
            return None

        chart_type = self.detect_chart_type(path)
        if chart_type in ("photo", "scan"):
            return None

        return _extract_chart_data_from_text(text, chart_type)

    def to_memory_entries(self, analysis: ImageAnalysis, source_id: str) -> list[dict[str, Any]]:
        """Convert an image analysis to Aegis memory entry dicts.

        Creates one entry for the overall description, and additional
        entries for OCR text and chart data if present.

        Args:
            analysis: A completed :class:`ImageAnalysis`.
            source_id: Unique identifier for the source image.

        Returns:
            A list of dicts ready for memory storage.
        """
        entries: list[dict[str, Any]] = []

        # Primary description entry
        entries.append(
            {
                "key": f"{source_id}:image:description",
                "value": analysis.description,
                "tier": "working",
                "confidence": 0.7,
                "provenance": {
                    "source_id": source_id,
                    "modality": "image",
                },
                "tags": [f"source:{source_id}", "modality:image"],
                "metadata": analysis.metadata,
            }
        )

        # OCR text entry
        if analysis.text_content:
            entries.append(
                {
                    "key": f"{source_id}:image:ocr",
                    "value": analysis.text_content,
                    "tier": "working",
                    "confidence": 0.6,
                    "provenance": {
                        "source_id": source_id,
                        "modality": "image",
                        "extraction": "ocr",
                    },
                    "tags": [f"source:{source_id}", "modality:image", "type:ocr"],
                    "metadata": {"char_count": len(analysis.text_content)},
                }
            )

        # Chart data entry
        if analysis.chart_data:
            import json

            entries.append(
                {
                    "key": f"{source_id}:image:chart_data",
                    "value": json.dumps(analysis.chart_data),
                    "tier": "working",
                    "confidence": 0.5,
                    "provenance": {
                        "source_id": source_id,
                        "modality": "image",
                        "extraction": "chart",
                    },
                    "tags": [
                        f"source:{source_id}",
                        "modality:image",
                        "type:chart",
                        f"chart_type:{analysis.chart_data.get('chart_type', 'unknown')}",
                    ],
                    "metadata": analysis.chart_data,
                }
            )

        return entries
