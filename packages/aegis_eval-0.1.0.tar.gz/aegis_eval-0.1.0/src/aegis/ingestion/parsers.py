"""Document parsers for the Aegis data ingestion layer.

Provides a pluggable parser interface and built-in parsers for common
formats. External parsers (Docling, Tesseract, Whisper) are optional
dependencies that integrate via the same interface.
"""

from __future__ import annotations

import csv
import io
import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class Modality(str, Enum):
    """Supported input modalities."""

    TEXT = "text"
    TABLE = "table"
    DOCUMENT = "document"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    WEB = "web"


@dataclass
class ParsedChunk:
    """A single chunk produced by a parser.

    Attributes:
        content: The text content of the chunk.
        modality: The modality this chunk came from.
        source_path: Path or URL of the source.
        chunk_index: Position of this chunk in the document.
        metadata: Arbitrary parser-specific metadata.
        confidence: Parser confidence score in [0.0, 1.0].
    """

    content: str
    modality: Modality
    source_path: str = ""
    chunk_index: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0


class DocumentParser(ABC):
    """Abstract base class for document parsers.

    All parsers implement :meth:`parse` which takes raw input and
    produces a list of :class:`ParsedChunk` instances.
    """

    @property
    @abstractmethod
    def supported_modalities(self) -> list[Modality]:
        """Return the modalities this parser supports."""
        ...

    @property
    @abstractmethod
    def supported_extensions(self) -> list[str]:
        """Return file extensions this parser handles (e.g. ['.txt', '.md'])."""
        ...

    @abstractmethod
    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        """Parse a document into chunks.

        Args:
            source: File path, URL, or identifier of the source.
            content: Optional raw content. If None, reads from source path.

        Returns:
            A list of ParsedChunk instances.
        """
        ...

    def can_handle(self, source: str | Path) -> bool:
        """Check if this parser can handle the given source."""
        path = Path(source) if not isinstance(source, Path) else source
        return path.suffix.lower() in self.supported_extensions


class TextParser(DocumentParser):
    """Parser for plain text files (.txt, .md, .rst).

    Splits text into chunks by paragraph boundaries (double newline).
    """

    @property
    def supported_modalities(self) -> list[Modality]:
        return [Modality.TEXT]

    @property
    def supported_extensions(self) -> list[str]:
        return [".txt", ".md", ".rst", ".text"]

    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        if content is None:
            path = Path(source)
            if path.exists():
                content = path.read_text(encoding="utf-8")
            else:
                return []
        elif isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")

        # Split into paragraphs
        paragraphs = re.split(r"\n\s*\n", content.strip())
        chunks: list[ParsedChunk] = []
        for idx, para in enumerate(paragraphs):
            para = para.strip()
            if not para:
                continue
            chunks.append(
                ParsedChunk(
                    content=para,
                    modality=Modality.TEXT,
                    source_path=str(source),
                    chunk_index=idx,
                    metadata={"char_count": len(para), "word_count": len(para.split())},
                )
            )
        return chunks


class JSONParser(DocumentParser):
    """Parser for JSON files.

    Flattens JSON structures into key-value text chunks.
    """

    @property
    def supported_modalities(self) -> list[Modality]:
        return [Modality.TEXT]

    @property
    def supported_extensions(self) -> list[str]:
        return [".json", ".jsonl"]

    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        if content is None:
            path = Path(source)
            if path.exists():
                content = path.read_text(encoding="utf-8")
            else:
                return []
        elif isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")

        chunks: list[ParsedChunk] = []
        source_str = str(source)

        # Handle JSONL
        if source_str.endswith(".jsonl"):
            for idx, line in enumerate(content.strip().split("\n")):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    text = json.dumps(obj, indent=2, ensure_ascii=False)
                    chunks.append(
                        ParsedChunk(
                            content=text,
                            modality=Modality.TEXT,
                            source_path=source_str,
                            chunk_index=idx,
                            metadata={
                                "format": "jsonl",
                                "keys": list(obj.keys()) if isinstance(obj, dict) else [],
                            },
                        )
                    )
                except json.JSONDecodeError:
                    continue
            return chunks

        # Handle regular JSON
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            return []

        if isinstance(data, list):
            for idx, item in enumerate(data):
                text = json.dumps(item, indent=2, ensure_ascii=False)
                chunks.append(
                    ParsedChunk(
                        content=text,
                        modality=Modality.TEXT,
                        source_path=source_str,
                        chunk_index=idx,
                        metadata={
                            "format": "json_array",
                            "keys": list(item.keys()) if isinstance(item, dict) else [],
                        },
                    )
                )
        elif isinstance(data, dict):
            # Flatten top-level keys into separate chunks
            for idx, (key, value) in enumerate(data.items()):
                text = f"{key}: {json.dumps(value, indent=2, ensure_ascii=False)}"
                chunks.append(
                    ParsedChunk(
                        content=text,
                        modality=Modality.TEXT,
                        source_path=source_str,
                        chunk_index=idx,
                        metadata={"format": "json_object", "key": key},
                    )
                )
        else:
            chunks.append(
                ParsedChunk(
                    content=str(data),
                    modality=Modality.TEXT,
                    source_path=source_str,
                    chunk_index=0,
                    metadata={"format": "json_scalar"},
                )
            )

        return chunks


class CSVParser(DocumentParser):
    """Parser for CSV/TSV files.

    Each row becomes a chunk with headers as context.
    """

    @property
    def supported_modalities(self) -> list[Modality]:
        return [Modality.TABLE]

    @property
    def supported_extensions(self) -> list[str]:
        return [".csv", ".tsv"]

    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        if content is None:
            path = Path(source)
            if path.exists():
                content = path.read_text(encoding="utf-8")
            else:
                return []
        elif isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")

        source_str = str(source)
        delimiter = "\t" if source_str.endswith(".tsv") else ","

        reader = csv.DictReader(io.StringIO(content), delimiter=delimiter)
        headers = reader.fieldnames or []

        chunks: list[ParsedChunk] = []
        for idx, row in enumerate(reader):
            # Format row as key-value pairs
            pairs = [f"{k}: {v}" for k, v in row.items() if v]
            text = " | ".join(pairs)
            if not text.strip():
                continue
            chunks.append(
                ParsedChunk(
                    content=text,
                    modality=Modality.TABLE,
                    source_path=source_str,
                    chunk_index=idx,
                    metadata={
                        "format": "csv",
                        "headers": list(headers),
                        "row_index": idx,
                        "row_data": dict(row),
                    },
                )
            )

        return chunks


class HTMLParser(DocumentParser):
    """Parser for HTML content.

    Strips HTML tags and extracts text content, splitting by block elements.
    """

    @property
    def supported_modalities(self) -> list[Modality]:
        return [Modality.TEXT, Modality.WEB]

    @property
    def supported_extensions(self) -> list[str]:
        return [".html", ".htm"]

    def parse(self, source: str | Path, content: bytes | str | None = None) -> list[ParsedChunk]:
        if content is None:
            path = Path(source)
            if path.exists():
                content = path.read_text(encoding="utf-8")
            else:
                return []
        elif isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")

        # Remove script and style tags entirely
        cleaned = re.sub(
            r"<(script|style)[^>]*>.*?</\1>", "", content, flags=re.DOTALL | re.IGNORECASE
        )
        # Replace block elements with double newlines
        cleaned = re.sub(
            r"</(p|div|section|article|h[1-6]|li|tr|blockquote)>",
            "\n\n",
            cleaned,
            flags=re.IGNORECASE,
        )
        # Strip remaining tags
        cleaned = re.sub(r"<[^>]+>", " ", cleaned)
        # Normalize whitespace
        cleaned = re.sub(r"[ \t]+", " ", cleaned)
        # Decode common HTML entities
        cleaned = (
            cleaned.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", '"')
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
        )

        paragraphs = re.split(r"\n\s*\n", cleaned.strip())
        chunks: list[ParsedChunk] = []
        for idx, para in enumerate(paragraphs):
            para = para.strip()
            if not para or len(para) < 5:
                continue
            chunks.append(
                ParsedChunk(
                    content=para,
                    modality=Modality.WEB if str(source).startswith("http") else Modality.TEXT,
                    source_path=str(source),
                    chunk_index=idx,
                    metadata={"format": "html"},
                )
            )
        return chunks


# ---------------------------------------------------------------------------
# Parser registry
# ---------------------------------------------------------------------------


class ParserRegistry:
    """Registry for document parsers.

    Built-in parsers are registered automatically. External parsers
    (for PDF via Docling, OCR via Tesseract, audio via Whisper, etc.)
    can be registered at runtime.
    """

    def __init__(self) -> None:
        self._parsers: list[DocumentParser] = []
        # Register built-in parsers
        self._parsers.extend(
            [
                TextParser(),
                JSONParser(),
                CSVParser(),
                HTMLParser(),
            ]
        )
        # Register optional Docling parser for PDF/DOCX/XLSX/PPTX
        try:
            from aegis.ingestion.docling_parser import DoclingParser

            self._parsers.append(DoclingParser())
        except Exception:
            pass

    def register(self, parser: DocumentParser) -> None:
        """Register a custom parser."""
        self._parsers.append(parser)

    def get_parser(self, source: str | Path) -> DocumentParser | None:
        """Find the best parser for the given source."""
        for parser in reversed(self._parsers):  # Last registered wins
            if parser.can_handle(source):
                return parser
        return None

    def all_parsers(self) -> list[DocumentParser]:
        """Return all registered parsers."""
        return list(self._parsers)

    def supported_extensions(self) -> list[str]:
        """Return all supported file extensions."""
        exts: list[str] = []
        for parser in self._parsers:
            exts.extend(parser.supported_extensions)
        return sorted(set(exts))
