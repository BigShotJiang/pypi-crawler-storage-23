"""Table extraction pipeline for financial statements and contract tables.

Supports extraction from PDFs (via camelot/tabula interfaces), Excel/CSV,
and HTML tables. Outputs structured table data with cell-level metadata.
"""

from __future__ import annotations

import csv
import io
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Lazy-import flags for optional dependencies
_HAS_CAMELOT = False
_HAS_OPENPYXL = False

__all__ = [
    "ExtractedTable",
    "TableCell",
    "TableExtractor",
    "CrossTableReasoner",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class TableCell:
    """A single cell within an extracted table.

    Attributes:
        value: The raw string value of the cell.
        row_idx: Zero-based row index.
        col_idx: Zero-based column index.
        data_type: Detected data type (``"numeric"``, ``"text"``, ``"date"``, ``"currency"``).
        confidence: Confidence in the extraction, in ``[0.0, 1.0]``.
    """

    value: str
    row_idx: int
    col_idx: int
    data_type: str = "text"
    confidence: float = 1.0


@dataclass
class ExtractedTable:
    """A table extracted from a document.

    Attributes:
        rows: List of rows, each row is a list of :class:`TableCell`.
        columns: Number of columns.
        headers: Column header strings (if detected).
        source_page: Page number the table was extracted from (1-indexed), or 0 if N/A.
        confidence: Overall extraction confidence.
        metadata: Arbitrary extraction metadata.
    """

    rows: list[list[TableCell]]
    columns: int
    headers: list[str] = field(default_factory=list)
    source_page: int = 0
    confidence: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def num_rows(self) -> int:
        """Return the number of data rows (excluding header)."""
        return len(self.rows)

    def to_dicts(self) -> list[dict[str, str]]:
        """Convert the table to a list of row dicts keyed by header names."""
        headers = [f"col_{i}" for i in range(self.columns)] if not self.headers else self.headers
        result: list[dict[str, str]] = []
        for row in self.rows:
            d: dict[str, str] = {}
            for cell in row:
                idx = cell.col_idx
                key = headers[idx] if idx < len(headers) else f"col_{idx}"
                d[key] = cell.value
            result.append(d)
        return result


# ---------------------------------------------------------------------------
# Cell type detection helpers
# ---------------------------------------------------------------------------

_CURRENCY_RE = re.compile(
    r"^\s*[\$\u00a3\u20ac\u00a5]?\s*-?\s*\d[\d,]*(?:\.\d+)?\s*"
    r"(?:million|billion|M|B|k|K|mn|bn)?\s*$"
)
_DATE_RE = re.compile(r"^\s*(?:\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}|\d{4}[/\-]\d{1,2}[/\-]\d{1,2})\s*$")
_NUMERIC_RE = re.compile(r"^\s*-?\s*\d[\d,]*(?:\.\d+)?\s*%?\s*$")


def _detect_cell_type(value: str) -> str:
    """Detect the data type of a cell value.

    Returns one of ``"currency"``, ``"date"``, ``"numeric"``, or ``"text"``.
    """
    stripped = value.strip()
    if not stripped or stripped == "-":
        return "text"
    if _CURRENCY_RE.match(stripped):
        return "currency"
    if _DATE_RE.match(stripped):
        return "date"
    if _NUMERIC_RE.match(stripped):
        return "numeric"
    return "text"


def _parse_row(raw_values: list[str], row_idx: int) -> list[TableCell]:
    """Convert a list of raw string values into :class:`TableCell` objects."""
    cells: list[TableCell] = []
    for col_idx, val in enumerate(raw_values):
        dtype = _detect_cell_type(val)
        cells.append(
            TableCell(
                value=val.strip(),
                row_idx=row_idx,
                col_idx=col_idx,
                data_type=dtype,
            )
        )
    return cells


# ---------------------------------------------------------------------------
# TableExtractor
# ---------------------------------------------------------------------------


class TableExtractor:
    """Extract tables from various file formats.

    Supports PDF (via camelot if installed), CSV, Excel (via openpyxl if
    installed), and HTML (pure-Python regex parser).
    """

    def extract_from_pdf(self, path: str, pages: list[int] | None = None) -> list[ExtractedTable]:
        """Extract tables from a PDF file.

        Uses ``camelot`` when available with lattice detection first,
        falling back to stream detection.  Returns an empty list when
        camelot is not installed.

        Args:
            path: Path to the PDF file.
            pages: Optional list of 1-indexed page numbers to scan.

        Returns:
            A list of :class:`ExtractedTable` instances.
        """
        try:
            import camelot  # type: ignore[import-not-found]
        except ImportError:
            logger.warning(
                "camelot-py is not installed; PDF table extraction unavailable. "
                "Install with: pip install 'camelot-py[cv]'"
            )
            return []

        page_str = ",".join(str(p) for p in pages) if pages else "all"
        tables: list[ExtractedTable] = []

        # Try lattice (ruled lines) first, then stream (whitespace)
        for flavour in ("lattice", "stream"):
            try:
                raw_tables = camelot.read_pdf(str(path), pages=page_str, flavor=flavour)
            except Exception:
                logger.debug("camelot %s extraction failed for %s", flavour, path)
                continue

            for raw in raw_tables:
                df = raw.df
                if df.empty:
                    continue
                headers = [str(v) for v in df.iloc[0].tolist()]
                rows: list[list[TableCell]] = []
                for row_idx in range(1, len(df)):
                    raw_values = [str(v) for v in df.iloc[row_idx].tolist()]
                    rows.append(_parse_row(raw_values, row_idx - 1))

                accuracy = getattr(raw, "accuracy", 0.0)
                tables.append(
                    ExtractedTable(
                        rows=rows,
                        columns=len(headers),
                        headers=headers,
                        source_page=getattr(raw, "page", 0),
                        confidence=accuracy / 100.0 if accuracy else 0.5,
                        metadata={"extraction_method": flavour},
                    )
                )
            if tables:
                break  # lattice succeeded, skip stream

        return tables

    def extract_from_csv(self, path: str) -> ExtractedTable:
        """Extract a table from a CSV or TSV file.

        Args:
            path: Path to the CSV/TSV file.

        Returns:
            An :class:`ExtractedTable` representing the file contents.
        """
        filepath = Path(path)
        delimiter = "\t" if filepath.suffix.lower() == ".tsv" else ","
        text = filepath.read_text(encoding="utf-8")
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)
        all_rows = list(reader)

        if not all_rows:
            return ExtractedTable(rows=[], columns=0)

        headers = [v.strip() for v in all_rows[0]]
        rows: list[list[TableCell]] = []
        for row_idx, raw_row in enumerate(all_rows[1:]):
            rows.append(_parse_row(raw_row, row_idx))

        return ExtractedTable(
            rows=rows,
            columns=len(headers),
            headers=headers,
            metadata={"format": "csv", "source": path},
        )

    def extract_from_excel(self, path: str, sheet: str | None = None) -> list[ExtractedTable]:
        """Extract tables from an Excel workbook.

        Requires ``openpyxl``.  Each worksheet (or a single named sheet)
        becomes an :class:`ExtractedTable`.

        Args:
            path: Path to the ``.xlsx`` file.
            sheet: Optional worksheet name.  If ``None``, extracts all sheets.

        Returns:
            A list of :class:`ExtractedTable` instances.
        """
        try:
            import openpyxl  # type: ignore[import-untyped]
        except ImportError:
            logger.warning(
                "openpyxl is not installed; Excel extraction unavailable. "
                "Install with: pip install openpyxl"
            )
            return []

        wb = openpyxl.load_workbook(path, data_only=True)
        sheet_names = [sheet] if sheet else wb.sheetnames
        tables: list[ExtractedTable] = []

        for sname in sheet_names:
            ws = wb[sname]
            raw_rows: list[list[str]] = []
            for row in ws.iter_rows(values_only=True):
                raw_rows.append([str(v) if v is not None else "" for v in row])

            if not raw_rows:
                continue

            headers = [v.strip() for v in raw_rows[0]]
            rows: list[list[TableCell]] = []
            for row_idx, raw_row in enumerate(raw_rows[1:]):
                rows.append(_parse_row(raw_row, row_idx))

            tables.append(
                ExtractedTable(
                    rows=rows,
                    columns=len(headers),
                    headers=headers,
                    metadata={"format": "xlsx", "sheet": sname, "source": path},
                )
            )

        wb.close()
        return tables

    def extract_from_html(self, html: str) -> list[ExtractedTable]:
        """Extract tables from HTML markup.

        Uses a pure-Python regex approach to parse ``<table>`` elements.

        Args:
            html: Raw HTML string.

        Returns:
            A list of :class:`ExtractedTable` instances.
        """
        tables: list[ExtractedTable] = []
        table_pattern = re.compile(r"<table[^>]*>(.*?)</table>", re.DOTALL | re.IGNORECASE)
        row_pattern = re.compile(r"<tr[^>]*>(.*?)</tr>", re.DOTALL | re.IGNORECASE)
        cell_pattern = re.compile(r"<(?:td|th)[^>]*>(.*?)</(?:td|th)>", re.DOTALL | re.IGNORECASE)
        tag_strip = re.compile(r"<[^>]+>")

        for table_match in table_pattern.finditer(html):
            table_html = table_match.group(1)
            all_rows: list[list[str]] = []
            for row_match in row_pattern.finditer(table_html):
                row_html = row_match.group(1)
                cells = [
                    tag_strip.sub("", c.group(1)).strip() for c in cell_pattern.finditer(row_html)
                ]
                if cells:
                    all_rows.append(cells)

            if not all_rows:
                continue

            # First row as headers
            headers = all_rows[0]
            rows: list[list[TableCell]] = []
            for row_idx, raw_row in enumerate(all_rows[1:]):
                rows.append(_parse_row(raw_row, row_idx))

            tables.append(
                ExtractedTable(
                    rows=rows,
                    columns=len(headers),
                    headers=headers,
                    metadata={"format": "html"},
                )
            )

        return tables

    def detect_table_type(self, table: ExtractedTable) -> str:
        """Classify the table into a high-level type.

        Heuristics:
        - ``"financial_statement"`` if headers contain revenue/income/balance terms.
        - ``"comparison"`` if the first column has repeated labels and other
          columns are numeric.
        - ``"regulatory_matrix"`` if headers contain compliance/regulatory terms.
        - ``"data"`` otherwise.

        Args:
            table: The table to classify.

        Returns:
            One of ``"financial_statement"``, ``"comparison"``,
            ``"regulatory_matrix"``, or ``"data"``.
        """
        header_text = " ".join(h.lower() for h in table.headers)

        financial_keywords = {
            "revenue",
            "income",
            "profit",
            "loss",
            "assets",
            "liabilities",
            "equity",
            "cash flow",
            "ebitda",
            "earnings",
            "balance",
            "fiscal",
            "quarter",
            "annual",
        }
        regulatory_keywords = {
            "compliance",
            "regulation",
            "requirement",
            "section",
            "cfr",
            "rule",
            "penalty",
            "standard",
            "audit",
        }

        if any(kw in header_text for kw in financial_keywords):
            return "financial_statement"

        if any(kw in header_text for kw in regulatory_keywords):
            return "regulatory_matrix"

        # Comparison heuristic: many numeric columns
        if table.rows:
            numeric_cols = 0
            for cell in table.rows[0]:
                if cell.data_type in ("numeric", "currency"):
                    numeric_cols += 1
            if numeric_cols >= 2 and table.columns >= 3:
                return "comparison"

        return "data"

    def normalize_financials(self, table: ExtractedTable) -> ExtractedTable:
        """Normalize financial values in a table.

        - Strips currency symbols and normalizes thousand separators.
        - Converts percentage strings to decimal floats.
        - Normalizes date formats to ISO-8601 where possible.

        Args:
            table: The source table.

        Returns:
            A new :class:`ExtractedTable` with normalized cell values.
        """
        new_rows: list[list[TableCell]] = []
        for row in table.rows:
            new_cells: list[TableCell] = []
            for cell in row:
                new_val = cell.value
                new_type = cell.data_type

                if cell.data_type == "currency":
                    # Remove currency symbols and thousand separators
                    cleaned = re.sub(r"[\$\u00a3\u20ac\u00a5,]", "", cell.value).strip()
                    # Handle multiplier suffixes
                    multiplier = 1.0
                    lower = cleaned.lower()
                    for suffix, mult in [
                        ("billion", 1e9),
                        ("bn", 1e9),
                        ("b", 1e9),
                        ("million", 1e6),
                        ("mn", 1e6),
                        ("m", 1e6),
                        ("k", 1e3),
                    ]:
                        if lower.endswith(suffix):
                            multiplier = mult
                            cleaned = cleaned[: -len(suffix)].strip()
                            break
                    try:
                        numeric = float(cleaned) * multiplier
                        new_val = f"{numeric:.2f}"
                        new_type = "numeric"
                    except ValueError:
                        pass  # keep original

                elif cell.data_type == "numeric" and "%" in cell.value:
                    # Convert percentage to decimal
                    try:
                        pct = float(cell.value.replace("%", "").replace(",", "").strip())
                        new_val = f"{pct / 100.0:.6f}"
                        new_type = "numeric"
                    except ValueError:
                        pass

                elif cell.data_type == "date":
                    new_val = self._normalize_date(cell.value)

                new_cells.append(
                    TableCell(
                        value=new_val,
                        row_idx=cell.row_idx,
                        col_idx=cell.col_idx,
                        data_type=new_type,
                        confidence=cell.confidence,
                    )
                )
            new_rows.append(new_cells)

        return ExtractedTable(
            rows=new_rows,
            columns=table.columns,
            headers=list(table.headers),
            source_page=table.source_page,
            confidence=table.confidence,
            metadata={**table.metadata, "normalized": True},
        )

    @staticmethod
    def _normalize_date(value: str) -> str:
        """Attempt to normalize a date string to ISO-8601 (YYYY-MM-DD)."""
        stripped = value.strip()
        # Try MM/DD/YYYY
        m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", stripped)
        if m:
            return f"{m.group(3)}-{int(m.group(1)):02d}-{int(m.group(2)):02d}"
        # Try DD-MM-YYYY
        m = re.match(r"^(\d{1,2})-(\d{1,2})-(\d{4})$", stripped)
        if m:
            return f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
        # Already ISO
        m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", stripped)
        if m:
            return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
        return stripped


# ---------------------------------------------------------------------------
# CrossTableReasoner
# ---------------------------------------------------------------------------


class CrossTableReasoner:
    """Reason across multiple extracted tables.

    Provides reconciliation (checking that numbers agree) and
    cross-reference detection between tables.
    """

    def reconcile(self, tables: list[ExtractedTable]) -> dict[str, Any]:
        """Check whether numeric values agree across tables.

        For every numeric or currency cell that shares the same header
        label across two or more tables, this method collects the values
        and flags mismatches.

        Args:
            tables: Tables to reconcile.

        Returns:
            A dict with keys ``"matches"``, ``"mismatches"``, and ``"summary"``.
        """
        # Build a mapping: header_label -> list of (table_idx, row_idx, value)
        value_map: dict[str, list[tuple[int, int, str]]] = {}
        for t_idx, table in enumerate(tables):
            for row in table.rows:
                for cell in row:
                    if cell.data_type in ("numeric", "currency") and cell.col_idx < len(
                        table.headers
                    ):
                        header = table.headers[cell.col_idx].strip().lower()
                        if header:
                            value_map.setdefault(header, []).append(
                                (t_idx, cell.row_idx, cell.value)
                            )

        matches: list[dict[str, Any]] = []
        mismatches: list[dict[str, Any]] = []

        for header, entries in value_map.items():
            if len(entries) < 2:
                continue
            # Group by cleaned numeric value
            unique_vals: set[str] = set()
            for _, _, val in entries:
                cleaned = re.sub(r"[^\d.\-]", "", val)
                if cleaned:
                    unique_vals.add(cleaned)

            entry_dicts = [{"table": t, "row": r, "value": v} for t, r, v in entries]
            if len(unique_vals) <= 1:
                matches.append({"header": header, "entries": entry_dicts})
            else:
                mismatches.append(
                    {"header": header, "entries": entry_dicts, "unique_values": list(unique_vals)}
                )

        return {
            "matches": matches,
            "mismatches": mismatches,
            "summary": {
                "total_headers_checked": len(value_map),
                "matching": len(matches),
                "mismatching": len(mismatches),
            },
        }

    def find_references(
        self,
        table: ExtractedTable,
        other_tables: list[ExtractedTable],
    ) -> list[dict[str, Any]]:
        """Find cross-references from *table* to *other_tables*.

        A cross-reference is detected when a cell value in *table*
        exactly matches a cell value in another table (for non-trivial
        values) or when header labels overlap.

        Args:
            table: The source table.
            other_tables: Other tables to search for references.

        Returns:
            A list of dicts describing each cross-reference found.
        """
        references: list[dict[str, Any]] = []
        # Build a lookup from other tables
        other_values: dict[str, list[dict[str, Any]]] = {}
        for t_idx, other in enumerate(other_tables):
            for row in other.rows:
                for cell in row:
                    val = cell.value.strip()
                    # Skip trivial values
                    if not val or val in ("-", "0", "0.00", "N/A", ""):
                        continue
                    other_values.setdefault(val, []).append(
                        {"table_idx": t_idx, "row": cell.row_idx, "col": cell.col_idx}
                    )

        # Check source table cells
        for row in table.rows:
            for cell in row:
                val = cell.value.strip()
                if val in other_values and len(val) > 2:
                    references.append(
                        {
                            "value": val,
                            "source_row": cell.row_idx,
                            "source_col": cell.col_idx,
                            "targets": other_values[val],
                        }
                    )

        # Header overlap
        source_headers = {h.strip().lower() for h in table.headers if h.strip()}
        for t_idx, other in enumerate(other_tables):
            other_headers = {h.strip().lower() for h in other.headers if h.strip()}
            overlap = source_headers & other_headers
            if overlap:
                references.append(
                    {
                        "type": "header_overlap",
                        "shared_headers": sorted(overlap),
                        "target_table_idx": t_idx,
                    }
                )

        return references
