"""Data ingestion pipeline for the Aegis platform.

The :class:`IngestionPipeline` orchestrates document parsing, chunking,
and optional embedding into the memory/vector subsystem.
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from aegis.ingestion.parsers import Modality, ParsedChunk, ParserRegistry

if TYPE_CHECKING:
    from aegis.ingestion.sinks import Sink


@dataclass
class IngestionResult:
    """Result of a document ingestion operation.

    Attributes:
        source_path: The source that was ingested.
        num_chunks: Number of chunks produced.
        chunks: The parsed chunks.
        modality: Detected modality.
        document_id: Unique identifier for this ingestion.
        metadata: Additional metadata.
    """

    source_path: str
    num_chunks: int
    chunks: list[ParsedChunk]
    modality: Modality
    document_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class IngestionConfig:
    """Configuration for the ingestion pipeline.

    Attributes:
        max_chunk_words: Maximum words per chunk before splitting.
        overlap_words: Number of overlapping words between chunks.
        min_chunk_words: Minimum words for a chunk to be kept.
        compute_hashes: Whether to compute content hashes for dedup.
        deduplicate: Whether to remove duplicate chunks.
    """

    max_chunk_words: int = 512
    overlap_words: int = 50
    min_chunk_words: int = 5
    compute_hashes: bool = True
    deduplicate: bool = True


class IngestionPipeline:
    """Orchestrates document ingestion from raw input to parsed chunks.

    Handles parser selection, chunking, deduplication, and optional
    embedding/memory storage integration.

    Args:
        config: Ingestion configuration.
        parser_registry: Optional custom parser registry.
    """

    def __init__(
        self,
        config: IngestionConfig | None = None,
        parser_registry: ParserRegistry | None = None,
    ) -> None:
        self._config = config or IngestionConfig()
        self._registry = parser_registry or ParserRegistry()
        self._ingested: list[IngestionResult] = []

    @property
    def registry(self) -> ParserRegistry:
        """Return the parser registry."""
        return self._registry

    def ingest(
        self,
        source: str | Path,
        content: bytes | str | None = None,
        modality: Modality | None = None,
    ) -> IngestionResult:
        """Ingest a document from a file path or raw content.

        Args:
            source: File path, URL, or source identifier.
            content: Optional raw content to parse directly.
            modality: Override modality detection.

        Returns:
            An :class:`IngestionResult` with parsed chunks.

        Raises:
            ValueError: If no parser can handle the source.
        """
        parser = self._registry.get_parser(source)
        if parser is None:
            # Fall back to text parser for unknown types
            from aegis.ingestion.parsers import TextParser

            parser = TextParser()

        raw_chunks = parser.parse(source, content=content)

        # Apply chunking constraints (split large chunks)
        chunks = self._apply_chunking(raw_chunks)

        # Compute content hashes
        if self._config.compute_hashes:
            for chunk in chunks:
                chunk.metadata["content_hash"] = hashlib.sha256(
                    chunk.content.encode("utf-8")
                ).hexdigest()[:16]

        # Deduplicate
        if self._config.deduplicate:
            chunks = self._deduplicate(chunks)

        # Filter out tiny chunks
        chunks = [c for c in chunks if len(c.content.split()) >= self._config.min_chunk_words]

        detected_modality = modality or (chunks[0].modality if chunks else Modality.TEXT)

        result = IngestionResult(
            source_path=str(source),
            num_chunks=len(chunks),
            chunks=chunks,
            modality=detected_modality,
        )
        self._ingested.append(result)
        return result

    def ingest_batch(
        self,
        sources: list[str | Path],
    ) -> list[IngestionResult]:
        """Ingest multiple documents.

        Args:
            sources: List of file paths or URLs to ingest.

        Returns:
            List of ingestion results.
        """
        return [self.ingest(src) for src in sources]

    def ingest_directory(
        self,
        directory: str | Path,
        recursive: bool = True,
    ) -> list[IngestionResult]:
        """Ingest all supported files from a directory.

        Args:
            directory: Path to the directory.
            recursive: Whether to search recursively.

        Returns:
            List of ingestion results.
        """
        dir_path = Path(directory)
        if not dir_path.is_dir():
            return []

        supported = set(self._registry.supported_extensions())
        pattern = "**/*" if recursive else "*"
        files = [f for f in dir_path.glob(pattern) if f.is_file() and f.suffix.lower() in supported]

        return self.ingest_batch(sorted(files))

    def store_results(
        self,
        result: IngestionResult,
        sinks: list[Sink] | None = None,
    ) -> dict[str, int]:
        """Persist ingestion results to configured storage sinks.

        Writes the parsed chunks from *result* to each sink and returns
        a mapping of sink names to the count of items stored.

        Args:
            result: The :class:`IngestionResult` whose chunks should be stored.
            sinks: Storage sinks to write to.  If ``None``, returns an
                empty dict.

        Returns:
            A dict mapping sink names to counts of items stored.
        """
        if not sinks:
            return {}

        counts: dict[str, int] = {}
        metadata = {
            "source_path": result.source_path,
            "modality": result.modality.value,
        }
        metadata.update(result.metadata)

        for sink in sinks:
            count = sink.write(
                chunks=result.chunks,
                document_id=result.document_id,
                metadata=metadata,
            )
            counts[sink.name] = count

        # Flush all sinks
        for sink in sinks:
            sink.flush()

        return counts

    def history(self) -> list[IngestionResult]:
        """Return all ingestion results from this pipeline instance."""
        return list(self._ingested)

    def _apply_chunking(self, chunks: list[ParsedChunk]) -> list[ParsedChunk]:
        """Split chunks exceeding max_chunk_words."""
        result: list[ParsedChunk] = []
        max_words = self._config.max_chunk_words
        overlap = self._config.overlap_words

        for chunk in chunks:
            words = chunk.content.split()
            if len(words) <= max_words:
                result.append(chunk)
                continue

            # Split into overlapping windows
            idx = 0
            sub_idx = 0
            while idx < len(words):
                end = min(idx + max_words, len(words))
                sub_content = " ".join(words[idx:end])
                result.append(
                    ParsedChunk(
                        content=sub_content,
                        modality=chunk.modality,
                        source_path=chunk.source_path,
                        chunk_index=chunk.chunk_index * 1000 + sub_idx,
                        metadata={
                            **chunk.metadata,
                            "sub_chunk": True,
                            "parent_chunk": chunk.chunk_index,
                        },
                        confidence=chunk.confidence,
                    )
                )
                sub_idx += 1
                idx += max_words - overlap
                if idx >= len(words):
                    break

        return result

    def _deduplicate(self, chunks: list[ParsedChunk]) -> list[ParsedChunk]:
        """Remove duplicate chunks by content hash."""
        seen: set[str] = set()
        unique: list[ParsedChunk] = []
        for chunk in chunks:
            h = chunk.metadata.get("content_hash", chunk.content)
            if h not in seen:
                seen.add(h)
                unique.append(chunk)
        return unique
