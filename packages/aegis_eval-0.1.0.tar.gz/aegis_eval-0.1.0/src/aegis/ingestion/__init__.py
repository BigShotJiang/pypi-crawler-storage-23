"""Aegis data ingestion layer.

Provides document parsing, chunking, and ingestion pipeline for
converting raw documents into structured chunks ready for memory
storage and vector embedding.

Supports 7 input modalities: Text, Documents, Tables, Audio, Video,
Web, and Images.
"""

from aegis.ingestion.audio import (
    AudioIngester,
    AudioSegment,
    EarningsCallProcessor,
    TranscriptionResult,
)
from aegis.ingestion.browser import BrowserAutomationClient
from aegis.ingestion.docling_parser import DoclingParser
from aegis.ingestion.entity_extractor import (
    Entity,
    ExtractedEntities,
    Relation,
    SimpleEntityExtractor,
)
from aegis.ingestion.images import ImageAnalysis, ImageIngester
from aegis.ingestion.parsers import (
    CSVParser,
    DocumentParser,
    HTMLParser,
    JSONParser,
    Modality,
    ParsedChunk,
    ParserRegistry,
    TextParser,
)
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline, IngestionResult
from aegis.ingestion.sinks import CompositeSink, Neo4jSink, PgVectorSink, Sink
from aegis.ingestion.tables import (
    CrossTableReasoner,
    ExtractedTable,
    TableCell,
    TableExtractor,
)
from aegis.ingestion.video import VideoFrame, VideoIngester, VideoIngestionResult
from aegis.ingestion.web import (
    CourtDocketClient,
    RegulatoryClient,
    SECEdgarClient,
    SECFiling,
    WebIngester,
    WebPage,
)
from aegis.ingestion.xbrl import (
    FinancialFact,
    TaxonomyMapping,
    TemporalContext,
    XBRLParser,
)

__all__ = [
    # Audio
    "AudioIngester",
    "AudioSegment",
    "EarningsCallProcessor",
    "TranscriptionResult",
    # Parsers
    "CSVParser",
    "CompositeSink",
    "DoclingParser",
    "DocumentParser",
    "Entity",
    "ExtractedEntities",
    "HTMLParser",
    # Images
    "ImageAnalysis",
    "ImageIngester",
    # Pipeline
    "IngestionConfig",
    "IngestionPipeline",
    "IngestionResult",
    "JSONParser",
    "Modality",
    "Neo4jSink",
    "ParsedChunk",
    "ParserRegistry",
    "PgVectorSink",
    "Relation",
    # Tables
    "CrossTableReasoner",
    "ExtractedTable",
    "TableCell",
    "TableExtractor",
    # Sinks
    "SimpleEntityExtractor",
    "Sink",
    "TextParser",
    # Video
    "VideoFrame",
    "VideoIngester",
    "VideoIngestionResult",
    # Web
    "CourtDocketClient",
    "RegulatoryClient",
    "SECEdgarClient",
    "SECFiling",
    "WebIngester",
    "WebPage",
    # Browser
    "BrowserAutomationClient",
    # XBRL
    "FinancialFact",
    "TemporalContext",
    "TaxonomyMapping",
    "XBRLParser",
]
