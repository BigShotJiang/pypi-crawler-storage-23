"""Attribute-Based Access Control (ABAC) for fine-grained authorization.

Extends RBAC with attribute-based policies that evaluate dynamic conditions
(time of day, data classification, user department, resource sensitivity).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class Attribute:
    """A single attribute with typed value.

    Attributes:
        name: Attribute identifier (e.g. ``"department"``).
        value: The attribute value.
        data_type: One of ``"string"``, ``"int"``, ``"bool"``,
            ``"datetime"``, ``"list"``.
    """

    name: str
    value: Any
    data_type: str = "string"  # "string", "int", "bool", "datetime", "list"

    def __post_init__(self) -> None:
        valid_types = {"string", "int", "bool", "datetime", "list"}
        if self.data_type not in valid_types:
            raise ValueError(f"Invalid data_type '{self.data_type}', must be one of {valid_types}")


@dataclass
class AttributeSet:
    """Collection of attributes for an ABAC evaluation.

    Attributes:
        subject_attrs: Attributes describing the requesting entity (user/agent).
        resource_attrs: Attributes describing the target resource.
        action_attrs: Attributes describing the requested action.
        environment_attrs: Contextual attributes (time, IP, location).
    """

    subject_attrs: dict[str, Any] = field(default_factory=dict)
    resource_attrs: dict[str, Any] = field(default_factory=dict)
    action_attrs: dict[str, Any] = field(default_factory=dict)
    environment_attrs: dict[str, Any] = field(default_factory=dict)

    def get(self, attribute_path: str) -> Any:
        """Resolve a dotted attribute path like ``"subject.department"``.

        Args:
            attribute_path: Dotted path with category prefix
                (``subject``, ``resource``, ``action``, ``environment``).

        Returns:
            The resolved value or ``None`` if not found.
        """
        parts = attribute_path.split(".", 1)
        if len(parts) != 2:
            return None
        category, key = parts
        store = {
            "subject": self.subject_attrs,
            "resource": self.resource_attrs,
            "action": self.action_attrs,
            "environment": self.environment_attrs,
        }.get(category)
        if store is None:
            return None
        return store.get(key)


@dataclass
class PolicyCondition:
    """A single condition within an ABAC policy.

    Attributes:
        attribute_path: Dotted path to the attribute (e.g. ``"subject.clearance"``).
        operator: Comparison operator.
        value: The value to compare against.
    """

    attribute_path: str
    operator: str  # "eq", "neq", "gt", "lt", "in", "not_in", "contains", "matches"
    value: Any

    _VALID_OPERATORS = {
        "eq",
        "neq",
        "gt",
        "lt",
        "gte",
        "lte",
        "in",
        "not_in",
        "contains",
        "matches",
    }

    def evaluate(self, attributes: AttributeSet) -> bool:
        """Evaluate this condition against the given attributes.

        Args:
            attributes: The attribute set to evaluate against.

        Returns:
            ``True`` if the condition is satisfied.
        """
        actual = attributes.get(self.attribute_path)
        if actual is None:
            # Missing attribute fails open only for "neq" and "not_in"
            return self.operator in ("neq", "not_in")

        op = self.operator
        if op == "eq":
            return bool(actual == self.value)
        if op == "neq":
            return bool(actual != self.value)
        if op == "gt":
            return bool(actual > self.value)
        if op == "lt":
            return bool(actual < self.value)
        if op == "gte":
            return bool(actual >= self.value)
        if op == "lte":
            return bool(actual <= self.value)
        if op == "in":
            return actual in self.value
        if op == "not_in":
            return actual not in self.value
        if op == "contains":
            if isinstance(actual, (list, tuple, set)):
                return self.value in actual
            if isinstance(actual, str):
                return self.value in actual
            return False
        if op == "matches":
            if not isinstance(actual, str):
                return False
            return bool(re.search(str(self.value), actual))

        return False


@dataclass
class ABACPolicy:
    """An attribute-based access control policy.

    Attributes:
        id: Unique policy identifier.
        name: Human-readable policy name.
        effect: ``"allow"`` or ``"deny"``.
        conditions: List of conditions that must all be true for the policy to apply.
        priority: Higher priority policies are evaluated first.
        description: Optional description of the policy intent.
    """

    id: str
    name: str
    effect: str  # "allow" or "deny"
    conditions: list[PolicyCondition] = field(default_factory=list)
    priority: int = 0
    description: str = ""

    def matches(self, attributes: AttributeSet) -> bool:
        """Check if all conditions in this policy are satisfied.

        Args:
            attributes: The attribute set to evaluate.

        Returns:
            ``True`` if every condition evaluates to ``True``.
        """
        if not self.conditions:
            return False
        return all(cond.evaluate(attributes) for cond in self.conditions)


class ABACEngine:
    """Attribute-Based Access Control engine.

    Manages ABAC policies and evaluates access requests using a
    deny-override combining algorithm: if any matching policy has
    ``effect="deny"``, access is denied regardless of allow policies.
    """

    def __init__(self) -> None:
        self._policies: dict[str, ABACPolicy] = {}

    def add_policy(self, policy: ABACPolicy) -> None:
        """Register or update a policy.

        Args:
            policy: The ABAC policy to add.
        """
        self._policies[policy.id] = policy

    def remove_policy(self, policy_id: str) -> bool:
        """Remove a policy by ID.

        Args:
            policy_id: The identifier of the policy to remove.

        Returns:
            ``True`` if the policy was found and removed.
        """
        if policy_id in self._policies:
            del self._policies[policy_id]
            return True
        return False

    def list_policies(self) -> list[ABACPolicy]:
        """Return all registered policies sorted by priority (descending)."""
        return sorted(self._policies.values(), key=lambda p: p.priority, reverse=True)

    def evaluate(self, attributes: AttributeSet) -> bool:
        """Evaluate all policies against the given attributes.

        Uses deny-override: if any matching policy denies access, the
        result is ``False``. If at least one allow policy matches and
        no deny policy matches, the result is ``True``. If no policy
        matches, access is denied by default.

        Args:
            attributes: The attribute set describing the access request.

        Returns:
            ``True`` if access should be granted.
        """
        result = self.evaluate_detailed(attributes)
        return str(result["decision"]) == "allow"

    def evaluate_detailed(self, attributes: AttributeSet) -> dict[str, Any]:
        """Evaluate all policies and return detailed match information.

        Args:
            attributes: The attribute set describing the access request.

        Returns:
            Dict with ``decision``, ``matched_policies``, ``denied_by``,
            and ``allowed_by`` keys.
        """
        sorted_policies = sorted(self._policies.values(), key=lambda p: p.priority, reverse=True)

        matched: list[dict[str, Any]] = []
        denied_by: list[str] = []
        allowed_by: list[str] = []

        for policy in sorted_policies:
            if policy.matches(attributes):
                entry = {
                    "policy_id": policy.id,
                    "name": policy.name,
                    "effect": policy.effect,
                    "priority": policy.priority,
                }
                matched.append(entry)
                if policy.effect == "deny":
                    denied_by.append(policy.id)
                elif policy.effect == "allow":
                    allowed_by.append(policy.id)

        # Deny-override: any deny wins
        if denied_by:
            decision = "deny"
        elif allowed_by:
            decision = "allow"
        else:
            decision = "deny"  # default deny

        return {
            "decision": decision,
            "matched_policies": matched,
            "denied_by": denied_by,
            "allowed_by": allowed_by,
            "total_evaluated": len(sorted_policies),
        }

    def check_access(
        self,
        subject: dict[str, Any],
        resource: dict[str, Any],
        action: str,
        environment: dict[str, Any] | None = None,
    ) -> bool:
        """Convenience method to check access with raw dicts.

        Constructs an :class:`AttributeSet` from the provided dicts
        and evaluates all policies.

        Args:
            subject: Subject attributes (user/agent properties).
            resource: Resource attributes (data classification, owner, etc.).
            action: The action being requested (e.g. ``"read"``, ``"write"``).
            environment: Optional environment attributes (time, IP, etc.).

        Returns:
            ``True`` if access should be granted.
        """
        env = dict(environment or {})
        if "current_time" not in env:
            env["current_time"] = datetime.now(tz=UTC).hour

        attrs = AttributeSet(
            subject_attrs=dict(subject),
            resource_attrs=dict(resource),
            action_attrs={"type": action},
            environment_attrs=env,
        )
        return self.evaluate(attrs)


# ---------------------------------------------------------------------------
# Pre-built policy factories
# ---------------------------------------------------------------------------


def data_classification_policy() -> ABACPolicy:
    """Create a policy that restricts access based on data sensitivity.

    Denies access when the subject's clearance level is below the
    resource's classification level. Classification levels are:
    ``public=0``, ``internal=1``, ``confidential=2``, ``restricted=3``.

    Returns:
        An :class:`ABACPolicy` that denies access to resources with
        classification ``"restricted"`` unless the subject has
        ``clearance >= 3``.
    """
    return ABACPolicy(
        id="builtin_data_classification",
        name="Data Classification Restriction",
        effect="deny",
        conditions=[
            PolicyCondition("resource.classification", "eq", "restricted"),
            PolicyCondition("subject.clearance", "lt", 3),
        ],
        priority=100,
        description="Deny access to restricted data unless subject clearance >= 3",
    )


def time_based_policy() -> ABACPolicy:
    """Create a policy restricting access outside business hours (9-17).

    Denies access when ``environment.current_time`` is before 9 or
    after 17 and the resource requires business-hours-only access.

    Returns:
        An :class:`ABACPolicy` that denies off-hours access to
        resources marked ``business_hours_only``.
    """
    return ABACPolicy(
        id="builtin_time_restriction",
        name="Business Hours Only",
        effect="deny",
        conditions=[
            PolicyCondition("resource.business_hours_only", "eq", True),
            PolicyCondition("environment.current_time", "lt", 9),
        ],
        priority=90,
        description="Deny access to business-hours-only resources before 09:00",
    )


def department_policy() -> ABACPolicy:
    """Create a policy restricting cross-department data access.

    Denies access when the subject's department does not match the
    resource's owning department and the resource is not marked as
    ``cross_department_ok``.

    Returns:
        An :class:`ABACPolicy` denying cross-department access.
    """
    return ABACPolicy(
        id="builtin_department_restriction",
        name="Department Boundary",
        effect="deny",
        conditions=[
            PolicyCondition("resource.cross_department_ok", "eq", False),
            PolicyCondition("subject.department", "neq", "admin"),
        ],
        priority=80,
        description="Deny cross-department access unless resource allows it or subject is admin",
    )


def sensitivity_policy() -> ABACPolicy:
    """Create a policy requiring extra checks for PII/PHI data.

    Denies access to resources containing PII or PHI unless the
    subject has completed privacy training (``privacy_trained=True``).

    Returns:
        An :class:`ABACPolicy` enforcing privacy training for sensitive data.
    """
    return ABACPolicy(
        id="builtin_sensitivity_pii",
        name="PII/PHI Protection",
        effect="deny",
        conditions=[
            PolicyCondition("resource.contains_pii", "eq", True),
            PolicyCondition("subject.privacy_trained", "neq", True),
        ],
        priority=95,
        description="Deny access to PII/PHI data unless subject has privacy training",
    )
