"""Compliance reporting for Aegis.

Generates compliance reports for various regulatory frameworks
including SOC 2, FINRA, SEC, and EU AI Act requirements.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class ComplianceControl:
    """A single compliance control or requirement."""

    control_id: str
    framework: str  # "soc2", "finra", "sec", "eu_ai_act", "iso27001"
    category: str
    description: str
    status: str = (
        "not_assessed"  # "compliant", "non_compliant", "partial", "not_assessed", "not_applicable"
    )
    evidence: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    remediation: str = ""
    assessed_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ComplianceReport:
    """A compliance assessment report."""

    id: str = ""
    framework: str = ""
    generated_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    overall_status: str = "not_assessed"
    controls: list[ComplianceControl] = field(default_factory=list)
    summary: dict[str, int] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


# SOC 2 Trust Services Criteria relevant to AI agents
SOC2_CONTROLS: list[ComplianceControl] = [
    ComplianceControl(
        "CC6.1",
        "soc2",
        "Logical Access",
        "Logical access to information assets is restricted through access controls",
    ),
    ComplianceControl(
        "CC6.2",
        "soc2",
        "Logical Access",
        "Prior to issuing system credentials, registered authorized users are identified",
    ),
    ComplianceControl(
        "CC6.3",
        "soc2",
        "Logical Access",
        "Users are authenticated before access to systems, applications, or data",
    ),
    ComplianceControl(
        "CC7.1", "soc2", "System Operations", "Detection and monitoring of processing anomalies"
    ),
    ComplianceControl(
        "CC7.2", "soc2", "System Operations", "Monitoring of system components for anomalies"
    ),
    ComplianceControl(
        "CC8.1",
        "soc2",
        "Change Management",
        "Changes to infrastructure and software are authorized, tested, and approved",
    ),
    ComplianceControl(
        "CC9.1",
        "soc2",
        "Risk Mitigation",
        "Potential disruptions to operations are identified, reported, and acted upon",
    ),
    ComplianceControl(
        "A1.1", "soc2", "Availability", "Current processing capacity and future needs are monitored"
    ),
    ComplianceControl(
        "PI1.1",
        "soc2",
        "Processing Integrity",
        "Data processing is complete, valid, accurate, and timely",
    ),
    ComplianceControl(
        "C1.1", "soc2", "Confidentiality", "Confidential information is identified and protected"
    ),
]

# FINRA rules relevant to AI in finance
FINRA_CONTROLS: list[ComplianceControl] = [
    ComplianceControl(
        "FINRA-2210", "finra", "Communications", "Fair and balanced communications with the public"
    ),
    ComplianceControl(
        "FINRA-3110", "finra", "Supervision", "Supervisory system for AI-assisted activities"
    ),
    ComplianceControl("FINRA-4512", "finra", "Records", "Customer account information maintenance"),
    ComplianceControl(
        "FINRA-2111", "finra", "Suitability", "AI recommendations must be suitable for customers"
    ),
    ComplianceControl("FINRA-3310", "finra", "AML", "Anti-money laundering compliance"),
]

# EU AI Act requirements
EU_AI_ACT_CONTROLS: list[ComplianceControl] = [
    ComplianceControl(
        "EUAI-6", "eu_ai_act", "Risk Management", "Risk management system for high-risk AI"
    ),
    ComplianceControl(
        "EUAI-9", "eu_ai_act", "Data Governance", "Training data quality and governance"
    ),
    ComplianceControl(
        "EUAI-11", "eu_ai_act", "Technical Documentation", "AI system technical documentation"
    ),
    ComplianceControl("EUAI-12", "eu_ai_act", "Record-keeping", "Automatic logging of events"),
    ComplianceControl(
        "EUAI-13", "eu_ai_act", "Transparency", "Transparency to deployers and users"
    ),
    ComplianceControl("EUAI-14", "eu_ai_act", "Human Oversight", "Human oversight measures"),
    ComplianceControl(
        "EUAI-15", "eu_ai_act", "Accuracy", "Accuracy, robustness, and cybersecurity"
    ),
]


class ComplianceReporter:
    """Generates compliance reports for regulatory frameworks.

    Assesses Aegis platform capabilities against control requirements
    and produces structured compliance reports.
    """

    def __init__(self) -> None:
        self._frameworks: dict[str, list[ComplianceControl]] = {
            "soc2": [
                ComplianceControl(c.control_id, c.framework, c.category, c.description)
                for c in SOC2_CONTROLS
            ],
            "finra": [
                ComplianceControl(c.control_id, c.framework, c.category, c.description)
                for c in FINRA_CONTROLS
            ],
            "eu_ai_act": [
                ComplianceControl(c.control_id, c.framework, c.category, c.description)
                for c in EU_AI_ACT_CONTROLS
            ],
        }
        self._assessments: list[ComplianceReport] = []

    def assess(
        self,
        framework: str,
        capabilities: dict[str, bool] | None = None,
    ) -> ComplianceReport:
        """Run compliance assessment against a framework.

        Args:
            framework: Framework ID ("soc2", "finra", "eu_ai_act").
            capabilities: Dict of capability flags to check against controls.
                Example: {"rbac_enabled": True, "audit_logging": True, ...}
        """
        controls = self._frameworks.get(framework, [])
        if not controls:
            return ComplianceReport(framework=framework, overall_status="unknown")

        caps = capabilities or {}
        assessed_controls: list[ComplianceControl] = []

        # Capability-to-control mapping
        capability_map: dict[str, list[str]] = {
            "rbac_enabled": ["CC6.1", "CC6.2", "CC6.3", "EUAI-14"],
            "audit_logging": ["CC7.1", "CC7.2", "EUAI-12", "FINRA-4512"],
            "anomaly_detection": ["CC7.1", "CC7.2", "CC9.1"],
            "change_management": ["CC8.1"],
            "data_encryption": ["C1.1"],
            "data_governance": ["EUAI-9", "PI1.1"],
            "transparency": ["EUAI-13", "FINRA-2210"],
            "risk_management": ["EUAI-6", "CC9.1"],
            "human_oversight": ["EUAI-14", "FINRA-3110"],
            "accuracy_monitoring": ["EUAI-15", "PI1.1"],
            "capacity_monitoring": ["A1.1"],
            "aml_compliance": ["FINRA-3310"],
            "suitability_checks": ["FINRA-2111"],
            "technical_documentation": ["EUAI-11"],
        }

        # Determine which controls are satisfied
        satisfied_controls: set[str] = set()
        for cap, enabled in caps.items():
            if enabled and cap in capability_map:
                satisfied_controls.update(capability_map[cap])

        for control in controls:
            assessed = ComplianceControl(
                control_id=control.control_id,
                framework=control.framework,
                category=control.category,
                description=control.description,
                assessed_at=datetime.now(tz=UTC),
            )
            if control.control_id in satisfied_controls:
                assessed.status = "compliant"
                assessed.evidence.append("Capability verified via platform assessment")
            elif caps:
                assessed.status = "non_compliant"
                assessed.gaps.append("Required capability not enabled or verified")
            else:
                assessed.status = "not_assessed"
            assessed_controls.append(assessed)

        # Compute summary
        status_counts: dict[str, int] = defaultdict(int)
        for c in assessed_controls:
            status_counts[c.status] += 1

        # Overall status
        total = len(assessed_controls)
        compliant = status_counts.get("compliant", 0)
        if compliant == total:
            overall = "compliant"
        elif compliant > 0:
            overall = "partial"
        else:
            overall = "non_compliant"

        report = ComplianceReport(
            id=f"compliance_{framework}_{datetime.now(tz=UTC).strftime('%Y%m%d')}",
            framework=framework,
            overall_status=overall,
            controls=assessed_controls,
            summary=dict(status_counts),
        )
        self._assessments.append(report)
        return report

    def list_frameworks(self) -> list[str]:
        """Return available compliance frameworks."""
        return list(self._frameworks.keys())

    def assessment_history(
        self, framework: str | None = None, limit: int = 10
    ) -> list[ComplianceReport]:
        """Return past assessments."""
        reports = self._assessments
        if framework:
            reports = [r for r in reports if r.framework == framework]
        return reports[-limit:]

    def gap_analysis(self, framework: str) -> dict[str, Any]:
        """Return a gap analysis for the most recent assessment."""
        recent = [r for r in self._assessments if r.framework == framework]
        if not recent:
            return {"framework": framework, "error": "No assessments found"}

        report = recent[-1]
        non_compliant = [c for c in report.controls if c.status == "non_compliant"]
        partial = [c for c in report.controls if c.status == "partial"]

        return {
            "framework": framework,
            "total_controls": len(report.controls),
            "compliant": report.summary.get("compliant", 0),
            "non_compliant_controls": [
                {"id": c.control_id, "category": c.category, "description": c.description}
                for c in non_compliant
            ],
            "partial_controls": [
                {"id": c.control_id, "category": c.category, "description": c.description}
                for c in partial
            ],
        }
