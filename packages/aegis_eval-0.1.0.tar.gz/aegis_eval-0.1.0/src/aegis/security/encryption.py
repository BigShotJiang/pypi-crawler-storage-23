"""Encryption utilities for data at rest and in transit.

Provides AES-256 encryption for stored data and TLS configuration
helpers for secure communication.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import struct
from dataclasses import dataclass
from typing import Any


@dataclass
class EncryptionConfig:
    """Configuration for the data encryption layer.

    Attributes:
        algorithm: Symmetric encryption algorithm identifier.
        key_derivation: Key derivation function identifier.
        iterations: Number of PBKDF2 iterations for key derivation.
    """

    algorithm: str = "AES-256-GCM"
    key_derivation: str = "PBKDF2"
    iterations: int = 100_000


class DataEncryptor:
    """Pure-Python encryption using PBKDF2-derived keys and an XOR stream cipher.

    Uses HMAC-SHA256 in counter mode as a CSPRNG to generate a keystream,
    providing confidentiality and integrity (via an appended HMAC tag).
    This is a pure-Python fallback; for production use, prefer the
    ``cryptography`` library with real AES-256-GCM.

    Args:
        master_key: A master secret (string or bytes) from which
            encryption keys are derived.
        config: Optional encryption configuration.
    """

    # Internal constants
    _TAG_LEN = 32  # HMAC-SHA256 tag length
    _SALT_LEN = 16
    _NONCE_LEN = 16

    def __init__(self, master_key: str | bytes, config: EncryptionConfig | None = None) -> None:
        self._config = config or EncryptionConfig()
        if isinstance(master_key, str):
            master_key = master_key.encode("utf-8")
        self._master_key = master_key

    def derive_key(self, password: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
        """Derive a 256-bit key from a password using PBKDF2-HMAC-SHA256.

        Args:
            password: The password to derive from.
            salt: Optional salt bytes. If ``None``, a random salt is generated.

        Returns:
            Tuple of ``(derived_key, salt)``.
        """
        if salt is None:
            salt = os.urandom(self._SALT_LEN)
        dk = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            self._config.iterations,
            dklen=32,
        )
        return dk, salt

    def _derive_internal(self, salt: bytes) -> bytes:
        """Derive an encryption key from the master key and salt."""
        return hashlib.pbkdf2_hmac(
            "sha256",
            self._master_key,
            salt,
            self._config.iterations,
            dklen=32,
        )

    @staticmethod
    def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
        """Generate a keystream using HMAC-SHA256 in counter mode.

        Args:
            key: The encryption key.
            nonce: A unique nonce for this encryption.
            length: Number of keystream bytes to produce.

        Returns:
            Keystream bytes of the requested length.
        """
        blocks: list[bytes] = []
        counter = 0
        while len(b"".join(blocks)) < length:
            counter_bytes = struct.pack(">Q", counter)
            block = hmac.new(key, nonce + counter_bytes, hashlib.sha256).digest()
            blocks.append(block)
            counter += 1
        return b"".join(blocks)[:length]

    def encrypt(self, plaintext: str | bytes) -> bytes:
        """Encrypt plaintext data.

        Format: ``salt (16) || nonce (16) || ciphertext (N) || hmac_tag (32)``.

        Args:
            plaintext: Data to encrypt (string or bytes).

        Returns:
            Encrypted bytes including salt, nonce, ciphertext, and
            authentication tag.
        """
        if isinstance(plaintext, str):
            plaintext = plaintext.encode("utf-8")

        salt = os.urandom(self._SALT_LEN)
        nonce = os.urandom(self._NONCE_LEN)
        key = self._derive_internal(salt)

        # XOR stream cipher
        ks = self._keystream(key, nonce, len(plaintext))
        ciphertext = bytes(p ^ k for p, k in zip(plaintext, ks, strict=True))

        # Authentication tag over salt + nonce + ciphertext
        tag_input = salt + nonce + ciphertext
        tag = hmac.new(key, tag_input, hashlib.sha256).digest()

        return salt + nonce + ciphertext + tag

    def decrypt(self, ciphertext: bytes) -> bytes:
        """Decrypt ciphertext produced by :meth:`encrypt`.

        Args:
            ciphertext: The encrypted payload (salt + nonce + ct + tag).

        Returns:
            The decrypted bytes.

        Raises:
            ValueError: If the authentication tag does not verify.
        """
        min_len = self._SALT_LEN + self._NONCE_LEN + self._TAG_LEN
        if len(ciphertext) < min_len:
            raise ValueError("Ciphertext too short")

        salt = ciphertext[: self._SALT_LEN]
        nonce = ciphertext[self._SALT_LEN : self._SALT_LEN + self._NONCE_LEN]
        tag = ciphertext[-self._TAG_LEN :]
        ct = ciphertext[self._SALT_LEN + self._NONCE_LEN : -self._TAG_LEN]

        key = self._derive_internal(salt)

        # Verify tag
        tag_input = salt + nonce + ct
        expected_tag = hmac.new(key, tag_input, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected_tag):
            raise ValueError("Authentication tag verification failed — data may be tampered")

        # Decrypt
        ks = self._keystream(key, nonce, len(ct))
        return bytes(c ^ k for c, k in zip(ct, ks, strict=True))

    def encrypt_field(self, data: dict[str, Any], fields: list[str]) -> dict[str, Any]:
        """Encrypt specific fields within a dictionary.

        Encrypted values are stored as hex-encoded strings with an
        ``"__encrypted__:"`` prefix for identification.

        Args:
            data: The dictionary containing fields to encrypt.
            fields: List of top-level keys whose values should be encrypted.

        Returns:
            A new dictionary with specified fields encrypted.
        """
        result = dict(data)
        for f in fields:
            if f in result:
                raw = (
                    json.dumps(result[f]).encode("utf-8")
                    if not isinstance(result[f], (str, bytes))
                    else (result[f].encode("utf-8") if isinstance(result[f], str) else result[f])
                )
                encrypted = self.encrypt(raw)
                result[f] = "__encrypted__:" + encrypted.hex()
        return result

    def decrypt_field(self, data: dict[str, Any], fields: list[str]) -> dict[str, Any]:
        """Decrypt specific fields within a dictionary.

        Only processes fields that carry the ``"__encrypted__:"`` prefix.

        Args:
            data: The dictionary with encrypted fields.
            fields: List of top-level keys whose values should be decrypted.

        Returns:
            A new dictionary with specified fields decrypted.
        """
        result = dict(data)
        for f in fields:
            if (
                f in result
                and isinstance(result[f], str)
                and result[f].startswith("__encrypted__:")
            ):
                hex_data = result[f][len("__encrypted__:") :]
                decrypted = self.decrypt(bytes.fromhex(hex_data))
                decoded = decrypted.decode("utf-8")
                # Try to restore JSON-encoded values
                try:
                    result[f] = json.loads(decoded)
                except (json.JSONDecodeError, ValueError):
                    result[f] = decoded
        return result


class TLSConfig:
    """TLS configuration helpers for secure communication.

    Provides configuration dictionaries for TLS setup rather than
    managing actual certificates (which require OS-level operations).
    """

    @staticmethod
    def generate_self_signed_cert_config() -> dict[str, Any]:
        """Generate a configuration dict for creating a self-signed certificate.

        Returns:
            Dict with subject, key parameters, validity, and OpenSSL
            command hint.
        """
        return {
            "subject": {
                "CN": "aegis-local",
                "O": "Metronis",
                "OU": "Aegis Platform",
            },
            "key": {
                "algorithm": "RSA",
                "size": 4096,
            },
            "validity_days": 365,
            "extensions": ["subjectAltName=DNS:localhost,IP:127.0.0.1"],
            "openssl_command": (
                "openssl req -x509 -newkey rsa:4096 -keyout key.pem "
                "-out cert.pem -days 365 -nodes "
                '-subj "/CN=aegis-local/O=Metronis/OU=Aegis Platform"'
            ),
        }

    @staticmethod
    def get_tls_context_config(cert_path: str, key_path: str) -> dict[str, Any]:
        """Build a TLS context configuration dictionary.

        Args:
            cert_path: Path to the PEM-encoded certificate file.
            key_path: Path to the PEM-encoded private key file.

        Returns:
            Dict suitable for configuring ``ssl.SSLContext`` or
            uvicorn/gunicorn TLS settings.
        """
        return {
            "certfile": cert_path,
            "keyfile": key_path,
            "ssl_version": "TLSv1.2+",
            "ciphers": ("ECDHE+AESGCM:ECDHE+CHACHA20:DHE+AESGCM:DHE+CHACHA20:!aNULL:!MD5:!DSS"),
            "minimum_version": "TLSv1.2",
            "honor_cipher_order": True,
        }

    @staticmethod
    def validate_certificate(cert_path: str) -> dict[str, Any]:
        """Perform basic validation checks on a certificate file.

        Checks file existence and PEM format markers. Does not
        perform cryptographic validation (that requires ``ssl`` or
        ``cryptography``).

        Args:
            cert_path: Path to the certificate file.

        Returns:
            Dict with ``valid`` flag and any ``errors`` found.
        """
        errors: list[str] = []
        try:
            with open(cert_path) as f:
                content = f.read()
        except FileNotFoundError:
            return {"valid": False, "errors": ["Certificate file not found"], "path": cert_path}
        except OSError as exc:
            return {"valid": False, "errors": [f"Cannot read file: {exc}"], "path": cert_path}

        if "-----BEGIN CERTIFICATE-----" not in content:
            errors.append("Missing PEM BEGIN CERTIFICATE marker")
        if "-----END CERTIFICATE-----" not in content:
            errors.append("Missing PEM END CERTIFICATE marker")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "path": cert_path,
            "format": "PEM" if not errors else "unknown",
        }


class SecretDetector:
    """Detects and redacts potential secrets in text.

    Scans for common secret patterns including AWS keys, API tokens,
    JWTs, passwords in connection strings, and generic high-entropy
    strings.
    """

    # Patterns: (name, compiled regex, description)
    _PATTERNS: list[tuple[str, re.Pattern[str], str]] = [
        (
            "aws_access_key",
            re.compile(r"(?<![A-Z0-9])(AKIA[0-9A-Z]{16})(?![A-Z0-9])"),
            "AWS Access Key ID",
        ),
        (
            "aws_secret_key",
            re.compile(r"(?<![A-Za-z0-9/+=])([A-Za-z0-9/+=]{40})(?![A-Za-z0-9/+=])"),
            "Potential AWS Secret Access Key",
        ),
        (
            "openai_api_key",
            re.compile(r"(sk-[A-Za-z0-9]{20,})"),
            "OpenAI/Generic API Key (sk-...)",
        ),
        (
            "jwt_token",
            re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})"),
            "JWT Token",
        ),
        (
            "generic_api_key",
            re.compile(
                r"(?i)(?:api[_-]?key|apikey|api_secret)['\"]?\s*[:=]\s*['\"]?([A-Za-z0-9_\-]{20,})['\"]?"
            ),
            "Generic API Key in assignment",
        ),
        (
            "password_in_url",
            re.compile(r"://[^:]+:([^@]{8,})@"),
            "Password in connection string",
        ),
        (
            "password_assignment",
            re.compile(r"(?i)(?:password|passwd|pwd)['\"]?\s*[:=]\s*['\"]?([^\s'\"]{8,})['\"]?"),
            "Password in assignment",
        ),
        (
            "private_key",
            re.compile(r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----"),
            "Private key PEM block",
        ),
        (
            "bearer_token",
            re.compile(r"(?i)Bearer\s+([A-Za-z0-9_\-.]{20,})"),
            "Bearer token",
        ),
    ]

    def scan(self, text: str) -> list[dict[str, Any]]:
        """Scan text for potential secrets.

        Args:
            text: The text to scan.

        Returns:
            List of dicts with ``type``, ``description``, ``location``
            (character offset), and ``matched`` (redacted preview).
        """
        findings: list[dict[str, Any]] = []
        seen_positions: set[tuple[int, int]] = set()

        for name, pattern, description in self._PATTERNS:
            for match in pattern.finditer(text):
                pos = (match.start(), match.end())
                if pos in seen_positions:
                    continue
                seen_positions.add(pos)

                matched_text = match.group(0)
                # Show first 4 and last 4 chars, redact the rest
                if len(matched_text) > 12:
                    preview = matched_text[:4] + "..." + matched_text[-4:]
                else:
                    preview = matched_text[:2] + "***"

                findings.append(
                    {
                        "type": name,
                        "description": description,
                        "location": match.start(),
                        "length": len(matched_text),
                        "preview": preview,
                    }
                )

        # Sort by location
        findings.sort(key=lambda f: f["location"])
        return findings

    def redact(self, text: str) -> str:
        """Redact all detected secrets in text.

        Replaces detected secret values with ``[REDACTED:<type>]``
        placeholders.

        Args:
            text: The text containing potential secrets.

        Returns:
            Text with secrets replaced by redaction markers.
        """
        # Collect all matches with their positions
        replacements: list[tuple[int, int, str]] = []

        for name, pattern, _description in self._PATTERNS:
            for match in pattern.finditer(text):
                # For patterns with a capture group, replace the group;
                # for patterns without (like private_key marker), replace the full match.
                if match.lastindex and match.lastindex >= 1:
                    start, end = match.start(1), match.end(1)
                else:
                    start, end = match.start(), match.end()
                replacements.append((start, end, f"[REDACTED:{name}]"))

        if not replacements:
            return text

        # Sort by position descending so replacements don't shift offsets
        replacements.sort(key=lambda r: r[0], reverse=True)

        # Remove overlapping replacements (keep the one starting earlier)
        filtered: list[tuple[int, int, str]] = []
        min_start = float("inf")
        for start, end, repl in replacements:
            if end <= min_start:
                filtered.append((start, end, repl))
                min_start = start

        result = text
        for start, end, repl in filtered:
            result = result[:start] + repl + result[end:]

        return result
