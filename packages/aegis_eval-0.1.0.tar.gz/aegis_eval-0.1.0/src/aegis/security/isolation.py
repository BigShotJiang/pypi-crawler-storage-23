"""Customer data isolation for multi-tenant deployments.

Provides schema-level isolation for PostgreSQL, namespace-level
isolation for Neo4j knowledge graphs, and cross-tenant access
validation to ensure strict data boundaries between tenants.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)

# Allowed characters for tenant identifiers (alphanumeric + hyphens).
_TENANT_ID_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,62}[a-zA-Z0-9]$")


@dataclass
class TenantInfo:
    """Metadata about a provisioned tenant.

    Attributes:
        tenant_id: Unique tenant identifier.
        schema_name: Postgres schema used for this tenant.
        kg_namespace: Neo4j namespace used for this tenant.
        created_at: When the tenant was provisioned.
        metadata: Arbitrary extra metadata.
    """

    tenant_id: str
    schema_name: str = ""
    kg_namespace: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


class TenantIsolation:
    """Manages customer data isolation across storage backends.

    Every tenant is assigned a dedicated Postgres schema and a Neo4j
    namespace.  All data access must go through the isolation layer to
    ensure that one tenant can never read or write another tenant's data.

    Args:
        schema_prefix: Prefix prepended to tenant IDs when deriving
            Postgres schema names.  Defaults to ``"tenant_"``.
        kg_prefix: Prefix prepended to tenant IDs when deriving Neo4j
            namespace labels.  Defaults to ``"ns_"``.
    """

    def __init__(
        self,
        schema_prefix: str = "tenant_",
        kg_prefix: str = "ns_",
    ) -> None:
        self._schema_prefix = schema_prefix
        self._kg_prefix = kg_prefix
        self._tenants: dict[str, TenantInfo] = {}

    # ------------------------------------------------------------------
    # Name derivation
    # ------------------------------------------------------------------

    @staticmethod
    def _sanitize_id(tenant_id: str) -> str:
        """Return a sanitised tenant identifier safe for SQL/Cypher names.

        Raises:
            ValueError: If *tenant_id* contains invalid characters.
        """
        if not _TENANT_ID_RE.match(tenant_id):
            raise ValueError(
                f"Invalid tenant_id '{tenant_id}': must be 2-64 chars, "
                "alphanumeric/hyphens/underscores, starting and ending with "
                "an alphanumeric character."
            )
        return tenant_id.lower().replace("-", "_")

    def get_schema_name(self, tenant_id: str) -> str:
        """Return the Postgres schema name for *tenant_id*.

        Args:
            tenant_id: Unique tenant identifier.

        Returns:
            The fully-qualified Postgres schema name (e.g.
            ``tenant_acme_corp``).

        Raises:
            ValueError: If *tenant_id* is invalid.
        """
        safe = self._sanitize_id(tenant_id)
        return f"{self._schema_prefix}{safe}"

    def get_kg_namespace(self, tenant_id: str) -> str:
        """Return the Neo4j namespace for *tenant_id*.

        Args:
            tenant_id: Unique tenant identifier.

        Returns:
            The Neo4j namespace label (e.g. ``ns_acme_corp``).

        Raises:
            ValueError: If *tenant_id* is invalid.
        """
        safe = self._sanitize_id(tenant_id)
        return f"{self._kg_prefix}{safe}"

    # ------------------------------------------------------------------
    # Access validation
    # ------------------------------------------------------------------

    def validate_access(self, tenant_id: str, resource_tenant_id: str) -> bool:
        """Check whether *tenant_id* may access a resource owned by *resource_tenant_id*.

        Cross-tenant access is **always** denied.  This is the
        fundamental invariant of the isolation layer.

        Args:
            tenant_id: The tenant requesting access.
            resource_tenant_id: The tenant that owns the resource.

        Returns:
            ``True`` if and only if both tenant identifiers resolve to the
            same sanitised form.
        """
        try:
            return self._sanitize_id(tenant_id) == self._sanitize_id(resource_tenant_id)
        except ValueError:
            logger.warning(
                "Cross-tenant access check failed: invalid tenant ID(s) (%s, %s)",
                tenant_id,
                resource_tenant_id,
            )
            return False

    # ------------------------------------------------------------------
    # Tenant provisioning
    # ------------------------------------------------------------------

    def create_tenant_schema(self, tenant_id: str) -> TenantInfo:
        """Provision an isolated schema and namespace for a new tenant.

        This method records the tenant in the internal registry and
        returns the computed :class:`TenantInfo`.  Actual DDL execution
        against Postgres/Neo4j is left to the caller (or a higher-level
        orchestration layer) because this module is intentionally
        database-driver-agnostic.

        Args:
            tenant_id: Unique tenant identifier.

        Returns:
            A :class:`TenantInfo` with the derived schema and namespace
            names.

        Raises:
            ValueError: If *tenant_id* is invalid or already exists.
        """
        safe = self._sanitize_id(tenant_id)
        if safe in self._tenants:
            raise ValueError(f"Tenant '{tenant_id}' already exists.")

        schema_name = self.get_schema_name(tenant_id)
        kg_namespace = self.get_kg_namespace(tenant_id)

        info = TenantInfo(
            tenant_id=tenant_id,
            schema_name=schema_name,
            kg_namespace=kg_namespace,
        )
        self._tenants[safe] = info
        logger.info(
            "Provisioned tenant '%s': schema=%s, namespace=%s",
            tenant_id,
            schema_name,
            kg_namespace,
        )
        return info

    # ------------------------------------------------------------------
    # Lookup helpers
    # ------------------------------------------------------------------

    def get_tenant(self, tenant_id: str) -> TenantInfo | None:
        """Look up a provisioned tenant by ID.

        Args:
            tenant_id: The tenant identifier to look up.

        Returns:
            The :class:`TenantInfo` if found, otherwise ``None``.
        """
        try:
            safe = self._sanitize_id(tenant_id)
        except ValueError:
            return None
        return self._tenants.get(safe)

    def list_tenants(self) -> list[TenantInfo]:
        """Return all provisioned tenants.

        Returns:
            A list of :class:`TenantInfo` instances.
        """
        return list(self._tenants.values())

    def delete_tenant(self, tenant_id: str) -> bool:
        """Remove a tenant from the internal registry.

        This does **not** drop the underlying Postgres schema or Neo4j
        data.  The caller is responsible for executing the appropriate
        DDL / Cypher cleanup.

        Args:
            tenant_id: The tenant identifier to remove.

        Returns:
            ``True`` if the tenant was found and removed, ``False``
            otherwise.
        """
        try:
            safe = self._sanitize_id(tenant_id)
        except ValueError:
            return False
        if safe in self._tenants:
            del self._tenants[safe]
            logger.info("Removed tenant '%s' from registry", tenant_id)
            return True
        return False
