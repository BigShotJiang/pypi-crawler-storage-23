"""Compliance report generators for SOC 2, FINRA, and EU AI Act.

Generates structured audit reports from governance data, covering
data handling, access control, privacy, and AI transparency requirements.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


def _assess_control(
    control_id: str,
    description: str,
    audit_data: dict[str, Any],
    required_keys: list[str],
    category: str,
) -> dict[str, Any]:
    """Assess a single control against audit data.

    Args:
        control_id: The control identifier.
        description: Human-readable description.
        audit_data: The audit data to check.
        required_keys: Keys that must be present and truthy in
            ``audit_data`` for the control to pass.
        category: The control category.

    Returns:
        Dict with control assessment details.
    """
    present = [k for k in required_keys if audit_data.get(k)]
    missing = [k for k in required_keys if not audit_data.get(k)]

    if not missing:
        status = "compliant"
    elif present:
        status = "partial"
    else:
        status = "non_compliant"

    result: dict[str, Any] = {
        "control_id": control_id,
        "category": category,
        "description": description,
        "status": status,
        "evidence": [f"{k}: verified" for k in present],
        "gaps": [f"{k}: not found or disabled" for k in missing],
    }
    if missing:
        result["recommendations"] = [
            f"Enable or configure '{k}' to satisfy {control_id}" for k in missing
        ]
    return result


def _build_report_summary(controls: list[dict[str, Any]]) -> dict[str, Any]:
    """Build summary statistics from assessed controls.

    Args:
        controls: List of control assessment dicts.

    Returns:
        Summary dict with counts and overall status.
    """
    total = len(controls)
    compliant = sum(1 for c in controls if c["status"] == "compliant")
    partial = sum(1 for c in controls if c["status"] == "partial")
    non_compliant = sum(1 for c in controls if c["status"] == "non_compliant")

    if compliant == total:
        overall = "compliant"
    elif non_compliant == total:
        overall = "non_compliant"
    elif compliant > 0 or partial > 0:
        overall = "partial"
    else:
        overall = "not_assessed"

    return {
        "total_controls": total,
        "compliant": compliant,
        "partial": partial,
        "non_compliant": non_compliant,
        "overall_status": overall,
        "compliance_pct": round(compliant / total * 100, 1) if total else 0.0,
    }


class ComplianceReportGenerator:
    """Generates detailed compliance reports for regulatory frameworks.

    Each report method accepts audit data (a dict of capability flags
    and evidence) and returns a structured report with controls,
    findings, gaps, recommendations, and evidence references.
    """

    def generate_soc2_report(self, audit_data: dict[str, Any]) -> dict[str, Any]:
        """Generate a SOC 2 Type II readiness report.

        Assesses controls across the five Trust Services Criteria:
        Security, Availability, Processing Integrity, Confidentiality,
        and Privacy.

        Args:
            audit_data: Dict with keys such as ``rbac_enabled``,
                ``audit_logging``, ``encryption_at_rest``,
                ``anomaly_detection``, ``change_management``,
                ``incident_response``, ``data_classification``,
                ``backup_enabled``, ``capacity_monitoring``,
                ``data_validation``.

        Returns:
            Structured SOC 2 compliance report dict.
        """
        controls = [
            _assess_control(
                "CC6.1",
                "Logical access security controls",
                audit_data,
                ["rbac_enabled", "abac_enabled"],
                "Security",
            ),
            _assess_control(
                "CC6.2",
                "System credentials and identity management",
                audit_data,
                ["rbac_enabled", "identity_management"],
                "Security",
            ),
            _assess_control(
                "CC6.3",
                "Authentication before access",
                audit_data,
                ["authentication_enabled", "mfa_enabled"],
                "Security",
            ),
            _assess_control(
                "CC6.6",
                "Encryption of data in transit and at rest",
                audit_data,
                ["encryption_at_rest", "encryption_in_transit"],
                "Security",
            ),
            _assess_control(
                "CC7.1",
                "Detection of processing anomalies",
                audit_data,
                ["anomaly_detection", "audit_logging"],
                "Operations",
            ),
            _assess_control(
                "CC7.2",
                "Monitoring of system components",
                audit_data,
                ["monitoring_enabled", "alerting_enabled"],
                "Operations",
            ),
            _assess_control(
                "CC8.1",
                "Authorized and tested changes",
                audit_data,
                ["change_management", "ci_cd_pipeline"],
                "Change Management",
            ),
            _assess_control(
                "CC9.1",
                "Risk identification and mitigation",
                audit_data,
                ["risk_assessment", "incident_response"],
                "Risk Mitigation",
            ),
            _assess_control(
                "A1.1",
                "Processing capacity monitoring",
                audit_data,
                ["capacity_monitoring", "auto_scaling"],
                "Availability",
            ),
            _assess_control(
                "A1.2",
                "Recovery and continuity",
                audit_data,
                ["backup_enabled", "disaster_recovery"],
                "Availability",
            ),
            _assess_control(
                "PI1.1",
                "Complete and accurate data processing",
                audit_data,
                ["data_validation", "audit_logging"],
                "Processing Integrity",
            ),
            _assess_control(
                "C1.1",
                "Confidential information protection",
                audit_data,
                ["data_classification", "encryption_at_rest"],
                "Confidentiality",
            ),
        ]

        summary = _build_report_summary(controls)

        return {
            "report_type": "SOC 2 Type II Readiness",
            "framework": "soc2",
            "generated_at": datetime.now(tz=UTC).isoformat(),
            "summary": summary,
            "controls": controls,
            "findings": [c for c in controls if c["status"] != "compliant"],
            "recommendations": _collect_recommendations(controls),
            "evidence_references": _collect_evidence(controls),
        }

    def generate_finra_report(self, audit_data: dict[str, Any]) -> dict[str, Any]:
        """Generate a FINRA compliance report.

        Assesses controls relevant to FINRA rules for AI-assisted
        financial services including communications, supervision,
        record-keeping, suitability, and AML.

        Args:
            audit_data: Dict with keys such as ``communication_review``,
                ``supervisory_system``, ``record_retention``,
                ``suitability_checks``, ``aml_monitoring``,
                ``audit_trail``, ``model_governance``.

        Returns:
            Structured FINRA compliance report dict.
        """
        controls = [
            _assess_control(
                "FINRA-2210",
                "Fair and balanced communications",
                audit_data,
                ["communication_review", "content_filtering"],
                "Communications",
            ),
            _assess_control(
                "FINRA-3110",
                "Supervisory system for AI activities",
                audit_data,
                ["supervisory_system", "model_governance", "human_oversight"],
                "Supervision",
            ),
            _assess_control(
                "FINRA-4512",
                "Customer account information maintenance",
                audit_data,
                ["record_retention", "data_integrity", "audit_trail"],
                "Records",
            ),
            _assess_control(
                "FINRA-2111",
                "Suitability of AI recommendations",
                audit_data,
                ["suitability_checks", "model_validation"],
                "Suitability",
            ),
            _assess_control(
                "FINRA-3310",
                "Anti-money laundering program",
                audit_data,
                ["aml_monitoring", "suspicious_activity_reporting"],
                "AML",
            ),
            _assess_control(
                "FINRA-4370",
                "Business continuity planning",
                audit_data,
                ["business_continuity", "disaster_recovery"],
                "Business Continuity",
            ),
        ]

        summary = _build_report_summary(controls)

        return {
            "report_type": "FINRA Compliance Assessment",
            "framework": "finra",
            "generated_at": datetime.now(tz=UTC).isoformat(),
            "summary": summary,
            "controls": controls,
            "findings": [c for c in controls if c["status"] != "compliant"],
            "recommendations": _collect_recommendations(controls),
            "evidence_references": _collect_evidence(controls),
        }

    def generate_eu_ai_act_report(self, audit_data: dict[str, Any]) -> dict[str, Any]:
        """Generate an EU AI Act transparency and compliance report.

        Assesses controls for Articles 6-15 of the EU AI Act covering
        risk management, data governance, documentation, transparency,
        human oversight, and accuracy requirements.

        Args:
            audit_data: Dict with keys such as ``risk_management``,
                ``data_governance``, ``technical_documentation``,
                ``event_logging``, ``transparency_info``,
                ``human_oversight``, ``accuracy_monitoring``,
                ``bias_detection``, ``robustness_testing``.

        Returns:
            Structured EU AI Act compliance report dict.
        """
        controls = [
            _assess_control(
                "EUAI-6",
                "Risk management system for high-risk AI",
                audit_data,
                ["risk_management", "risk_assessment", "risk_mitigation"],
                "Risk Management",
            ),
            _assess_control(
                "EUAI-9",
                "Training data quality and governance",
                audit_data,
                ["data_governance", "data_quality_checks", "bias_detection"],
                "Data Governance",
            ),
            _assess_control(
                "EUAI-10",
                "Data and record-keeping",
                audit_data,
                ["event_logging", "data_lineage"],
                "Record-keeping",
            ),
            _assess_control(
                "EUAI-11",
                "Technical documentation",
                audit_data,
                ["technical_documentation", "model_cards"],
                "Documentation",
            ),
            _assess_control(
                "EUAI-12",
                "Automatic logging of events",
                audit_data,
                ["event_logging", "audit_trail", "provenance_tracking"],
                "Transparency",
            ),
            _assess_control(
                "EUAI-13",
                "Transparency to deployers and users",
                audit_data,
                ["transparency_info", "user_notification", "explainability"],
                "Transparency",
            ),
            _assess_control(
                "EUAI-14",
                "Human oversight measures",
                audit_data,
                ["human_oversight", "override_capability", "alert_system"],
                "Human Oversight",
            ),
            _assess_control(
                "EUAI-15",
                "Accuracy, robustness, and cybersecurity",
                audit_data,
                ["accuracy_monitoring", "robustness_testing", "security_testing"],
                "Accuracy",
            ),
        ]

        summary = _build_report_summary(controls)

        return {
            "report_type": "EU AI Act Compliance Assessment",
            "framework": "eu_ai_act",
            "generated_at": datetime.now(tz=UTC).isoformat(),
            "summary": summary,
            "controls": controls,
            "findings": [c for c in controls if c["status"] != "compliant"],
            "recommendations": _collect_recommendations(controls),
            "evidence_references": _collect_evidence(controls),
            "risk_classification": _classify_ai_risk(audit_data),
        }

    def generate_privacy_report(self, privacy_data: dict[str, Any]) -> dict[str, Any]:
        """Generate a privacy and differential privacy compliance report.

        Assesses data privacy controls including DP budget tracking,
        consent management, data minimization, and breach readiness.

        Args:
            privacy_data: Dict with keys such as ``dp_enabled``,
                ``epsilon_budget``, ``consumed_epsilon``,
                ``consent_management``, ``data_minimization``,
                ``retention_policy``, ``breach_notification``,
                ``anonymization``, ``access_logging``.

        Returns:
            Structured privacy compliance report dict.
        """
        controls = [
            _assess_control(
                "PRIV-1",
                "Differential privacy for training data",
                privacy_data,
                ["dp_enabled", "epsilon_budget"],
                "Differential Privacy",
            ),
            _assess_control(
                "PRIV-2",
                "Privacy budget management",
                privacy_data,
                ["budget_tracking", "budget_enforcement"],
                "Differential Privacy",
            ),
            _assess_control(
                "PRIV-3",
                "Consent management",
                privacy_data,
                ["consent_management", "consent_records"],
                "Consent",
            ),
            _assess_control(
                "PRIV-4",
                "Data minimization",
                privacy_data,
                ["data_minimization", "purpose_limitation"],
                "Data Minimization",
            ),
            _assess_control(
                "PRIV-5",
                "Data retention and deletion",
                privacy_data,
                ["retention_policy", "deletion_capability"],
                "Retention",
            ),
            _assess_control(
                "PRIV-6",
                "Breach notification readiness",
                privacy_data,
                ["breach_notification", "incident_response"],
                "Breach Response",
            ),
            _assess_control(
                "PRIV-7",
                "Data anonymization and pseudonymization",
                privacy_data,
                ["anonymization", "pseudonymization"],
                "Anonymization",
            ),
            _assess_control(
                "PRIV-8",
                "Access logging and monitoring",
                privacy_data,
                ["access_logging", "audit_trail"],
                "Monitoring",
            ),
        ]

        summary = _build_report_summary(controls)

        # DP-specific metrics
        dp_metrics: dict[str, Any] = {}
        if privacy_data.get("dp_enabled"):
            max_eps = privacy_data.get("epsilon_budget", 0)
            consumed = privacy_data.get("consumed_epsilon", 0)
            dp_metrics = {
                "epsilon_budget": max_eps,
                "consumed_epsilon": consumed,
                "remaining_epsilon": max(0, max_eps - consumed) if max_eps else 0,
                "utilization_pct": round(consumed / max_eps * 100, 1) if max_eps else 0,
                "delta": privacy_data.get("delta", 1e-5),
                "noise_multiplier": privacy_data.get("noise_multiplier"),
            }

        return {
            "report_type": "Privacy Compliance Assessment",
            "framework": "privacy",
            "generated_at": datetime.now(tz=UTC).isoformat(),
            "summary": summary,
            "controls": controls,
            "findings": [c for c in controls if c["status"] != "compliant"],
            "recommendations": _collect_recommendations(controls),
            "evidence_references": _collect_evidence(controls),
            "dp_metrics": dp_metrics,
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _collect_recommendations(controls: list[dict[str, Any]]) -> list[str]:
    """Gather all recommendations from non-compliant controls.

    Args:
        controls: List of assessed control dicts.

    Returns:
        Deduplicated list of recommendation strings.
    """
    recs: list[str] = []
    seen: set[str] = set()
    for c in controls:
        for r in c.get("recommendations", []):
            if r not in seen:
                recs.append(r)
                seen.add(r)
    return recs


def _collect_evidence(controls: list[dict[str, Any]]) -> list[str]:
    """Gather all evidence references from compliant controls.

    Args:
        controls: List of assessed control dicts.

    Returns:
        Deduplicated list of evidence strings.
    """
    evidence: list[str] = []
    seen: set[str] = set()
    for c in controls:
        for e in c.get("evidence", []):
            if e not in seen:
                evidence.append(e)
                seen.add(e)
    return evidence


def _classify_ai_risk(audit_data: dict[str, Any]) -> dict[str, Any]:
    """Classify AI system risk level per EU AI Act categories.

    Args:
        audit_data: Audit data with risk-relevant flags.

    Returns:
        Dict with ``level``, ``rationale``, and ``requirements``.
    """
    # Determine risk level based on use-case flags
    if audit_data.get("biometric_identification") or audit_data.get("critical_infrastructure"):
        level = "unacceptable"
        rationale = "System involves prohibited AI practices"
        requirements = [
            "System may not be deployed under current configuration",
            "Review Article 5 prohibited practices",
        ]
    elif audit_data.get("financial_scoring") or audit_data.get("employment_decisions"):
        level = "high"
        rationale = "System is used in high-risk domain (Annex III)"
        requirements = [
            "Full conformity assessment required (Article 43)",
            "Register in EU database (Article 60)",
            "Implement all Articles 6-15 requirements",
            "Appoint authorized representative if outside EU",
        ]
    elif audit_data.get("customer_interaction") or audit_data.get("content_generation"):
        level = "limited"
        rationale = "System interacts with users or generates content"
        requirements = [
            "Transparency obligations (Article 52)",
            "Users must be informed they interact with AI",
            "Generated content must be labelled as AI-generated",
        ]
    else:
        level = "minimal"
        rationale = "No high-risk indicators detected"
        requirements = [
            "Voluntary codes of conduct encouraged (Article 69)",
        ]

    return {
        "level": level,
        "rationale": rationale,
        "requirements": requirements,
    }
