"""Differential privacy integration for private LoRA adapter training.

Implements DP-SGD style noise addition and privacy budget tracking
compatible with Opacus (lazy import) or standalone noise mechanisms.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


@dataclass
class PrivacyBudget:
    """Tracks consumed and remaining privacy budget.

    Attributes:
        epsilon: Current cumulative epsilon spent.
        delta: Current cumulative delta spent.
        consumed_epsilon: Alias tracking total epsilon consumed so far.
        consumed_delta: Alias tracking total delta consumed so far.
        max_epsilon: Maximum allowable epsilon before exhaustion.
        max_delta: Maximum allowable delta before exhaustion.
    """

    epsilon: float = 0.0
    delta: float = 0.0
    consumed_epsilon: float = 0.0
    consumed_delta: float = 0.0
    max_epsilon: float = 10.0
    max_delta: float = 1e-5


@dataclass
class PrivacyConfig:
    """Configuration for differentially private training.

    Attributes:
        target_epsilon: Target privacy budget epsilon.
        target_delta: Target privacy budget delta.
        max_grad_norm: Maximum L2 norm for per-sample gradient clipping.
        noise_multiplier: Ratio of noise standard deviation to sensitivity.
        lot_size: Number of samples per DP-SGD lot (mini-batch).
        sample_rate: Fraction of the dataset sampled per step.
    """

    target_epsilon: float = 1.0
    target_delta: float = 1e-5
    max_grad_norm: float = 1.0
    noise_multiplier: float = 1.1
    lot_size: int = 256
    sample_rate: float = 0.01


class GaussianMechanism:
    """Gaussian noise mechanism for differential privacy.

    Adds calibrated Gaussian noise to query outputs to achieve
    (epsilon, delta)-differential privacy.
    """

    def add_noise(self, value: float, sensitivity: float, epsilon: float) -> float:
        """Add Gaussian noise to a scalar value.

        The noise standard deviation is calibrated as
        ``sensitivity * sqrt(2 * ln(1.25 / delta)) / epsilon`` with a
        default delta of 1e-5.

        Args:
            value: The true query result.
            sensitivity: The L2 sensitivity of the query.
            epsilon: The privacy budget for this query.

        Returns:
            The noised value.
        """
        sigma = self._compute_sigma(sensitivity, epsilon)
        noise = random.gauss(0.0, sigma)
        return value + noise

    def add_noise_vector(
        self, values: list[float], sensitivity: float, epsilon: float
    ) -> list[float]:
        """Add independent Gaussian noise to each element of a vector.

        Args:
            values: List of true query results.
            sensitivity: The L2 sensitivity of the vector-valued query.
            epsilon: The privacy budget for this query.

        Returns:
            List of noised values.
        """
        sigma = self._compute_sigma(sensitivity, epsilon)
        return [v + random.gauss(0.0, sigma) for v in values]

    @staticmethod
    def _compute_sigma(sensitivity: float, epsilon: float, delta: float = 1e-5) -> float:
        """Compute the Gaussian noise standard deviation.

        Uses the analytic Gaussian mechanism formula:
        ``sigma = sensitivity * sqrt(2 * ln(1.25/delta)) / epsilon``.

        Args:
            sensitivity: Query sensitivity.
            epsilon: Privacy parameter.
            delta: Failure probability parameter.

        Returns:
            The noise standard deviation.
        """
        if epsilon <= 0:
            raise ValueError("Epsilon must be positive")
        if delta <= 0 or delta >= 1:
            raise ValueError("Delta must be in (0, 1)")
        return sensitivity * math.sqrt(2.0 * math.log(1.25 / delta)) / epsilon

    @staticmethod
    def compute_noise_multiplier(
        epsilon: float, delta: float, sample_rate: float, steps: int
    ) -> float:
        """Estimate the noise multiplier needed to achieve target (epsilon, delta).

        Uses a simplified analysis based on the moments accountant:
        ``sigma >= sqrt(2 * steps * sample_rate^2 * ln(1/delta)) / epsilon``.

        Args:
            epsilon: Target privacy budget.
            delta: Target failure probability.
            sample_rate: Fraction of dataset sampled per step.
            steps: Total number of training steps.

        Returns:
            The estimated noise multiplier (sigma / sensitivity).
        """
        if epsilon <= 0 or delta <= 0 or sample_rate <= 0 or steps <= 0:
            raise ValueError("All parameters must be positive")
        return math.sqrt(2.0 * steps * (sample_rate**2) * math.log(1.0 / delta)) / epsilon


class PrivacyAccountant:
    """Tracks cumulative privacy loss across multiple DP mechanisms.

    Supports basic composition and Renyi Differential Privacy (RDP)
    composition for tighter privacy accounting.
    """

    def __init__(self, budget: PrivacyBudget | None = None) -> None:
        self._budget = budget or PrivacyBudget()
        self._history: list[dict[str, Any]] = []

    @property
    def budget(self) -> PrivacyBudget:
        """Return the current privacy budget state."""
        return self._budget

    def consume(self, epsilon_spent: float, delta_spent: float) -> bool:
        """Record privacy expenditure and check budget.

        Args:
            epsilon_spent: Epsilon consumed by this operation.
            delta_spent: Delta consumed by this operation.

        Returns:
            ``True`` if the expenditure is within budget, ``False`` if it
            would exceed the maximum (the expenditure is still recorded).
        """
        self._budget.consumed_epsilon += epsilon_spent
        self._budget.consumed_delta += delta_spent
        self._budget.epsilon = self._budget.consumed_epsilon
        self._budget.delta = self._budget.consumed_delta

        self._history.append(
            {
                "epsilon_spent": epsilon_spent,
                "delta_spent": delta_spent,
                "cumulative_epsilon": self._budget.consumed_epsilon,
                "cumulative_delta": self._budget.consumed_delta,
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        )

        return not self.is_exhausted()

    def remaining(self) -> tuple[float, float]:
        """Return remaining (epsilon, delta) budget.

        Returns:
            Tuple of (remaining_epsilon, remaining_delta).
        """
        eps_remaining = max(0.0, self._budget.max_epsilon - self._budget.consumed_epsilon)
        delta_remaining = max(0.0, self._budget.max_delta - self._budget.consumed_delta)
        return eps_remaining, delta_remaining

    def is_exhausted(self) -> bool:
        """Check whether the privacy budget has been exceeded.

        Returns:
            ``True`` if either epsilon or delta exceeds the maximum.
        """
        return (
            self._budget.consumed_epsilon > self._budget.max_epsilon
            or self._budget.consumed_delta > self._budget.max_delta
        )

    def compose_rdp(self, alpha: float, steps: int, noise_multiplier: float) -> float:
        """Compute RDP epsilon at a given order using Renyi DP composition.

        For the Gaussian mechanism, the RDP guarantee at order ``alpha`` for
        a single step is ``alpha / (2 * sigma^2)``. Over ``steps`` steps
        with Poisson subsampling at rate ``q``, composition is linear.

        Args:
            alpha: The Renyi divergence order (must be > 1).
            steps: Number of composed mechanism invocations.
            noise_multiplier: The noise multiplier (sigma / sensitivity).

        Returns:
            The composed RDP epsilon at order ``alpha``.
        """
        if alpha <= 1:
            raise ValueError("Alpha must be > 1 for RDP")
        if noise_multiplier <= 0:
            raise ValueError("Noise multiplier must be positive")
        # Single-step RDP for Gaussian mechanism
        rdp_single = alpha / (2.0 * noise_multiplier**2)
        return steps * rdp_single

    def rdp_to_dp(self, rdp_epsilon: float, alpha: float, delta: float) -> float:
        """Convert RDP guarantee to (epsilon, delta)-DP.

        Uses the standard conversion:
        ``epsilon = rdp_epsilon - ln(delta) / (alpha - 1)``.

        Args:
            rdp_epsilon: The RDP epsilon at order ``alpha``.
            alpha: The Renyi divergence order.
            delta: The target delta for (epsilon, delta)-DP.

        Returns:
            The converted epsilon for (epsilon, delta)-DP.
        """
        if alpha <= 1:
            raise ValueError("Alpha must be > 1")
        if delta <= 0:
            raise ValueError("Delta must be positive")
        return rdp_epsilon - math.log(delta) / (alpha - 1.0)

    def generate_report(self) -> dict[str, Any]:
        """Generate a privacy compliance report.

        Returns:
            Dict containing budget status, history, and compliance assessment.
        """
        eps_remaining, delta_remaining = self.remaining()
        utilization = (
            self._budget.consumed_epsilon / self._budget.max_epsilon
            if self._budget.max_epsilon > 0
            else 0.0
        )

        return {
            "budget": {
                "max_epsilon": self._budget.max_epsilon,
                "max_delta": self._budget.max_delta,
                "consumed_epsilon": self._budget.consumed_epsilon,
                "consumed_delta": self._budget.consumed_delta,
                "remaining_epsilon": eps_remaining,
                "remaining_delta": delta_remaining,
                "utilization_pct": round(utilization * 100, 2),
            },
            "is_exhausted": self.is_exhausted(),
            "total_operations": len(self._history),
            "history": self._history[-20:],
            "generated_at": datetime.now(tz=UTC).isoformat(),
        }


class DPTrainingWrapper:
    """Wraps a training loop with differential privacy guarantees.

    Provides per-sample gradient clipping, noise addition, and privacy
    budget tracking for DP-SGD style training of LoRA adapters.
    """

    def __init__(self, config: PrivacyConfig | None = None) -> None:
        self._config = config or PrivacyConfig()
        self._budget = PrivacyBudget(
            max_epsilon=self._config.target_epsilon,
            max_delta=self._config.target_delta,
        )
        self._accountant = PrivacyAccountant(self._budget)
        self._mechanism = GaussianMechanism()
        self._steps: int = 0

    @property
    def accountant(self) -> PrivacyAccountant:
        """Return the privacy accountant."""
        return self._accountant

    def clip_gradients(self, gradients: list[float], max_norm: float | None = None) -> list[float]:
        """Clip a gradient vector to a maximum L2 norm.

        Args:
            gradients: Per-sample gradient vector.
            max_norm: Maximum L2 norm. Defaults to ``config.max_grad_norm``.

        Returns:
            Clipped gradient vector.
        """
        norm_bound = max_norm if max_norm is not None else self._config.max_grad_norm
        grad_norm = math.sqrt(sum(g * g for g in gradients))
        if grad_norm <= norm_bound:
            return list(gradients)
        scale = norm_bound / grad_norm
        return [g * scale for g in gradients]

    def add_gradient_noise(self, clipped_gradients: list[float]) -> list[float]:
        """Add calibrated Gaussian noise to clipped gradients.

        The noise standard deviation is ``noise_multiplier * max_grad_norm``.

        Args:
            clipped_gradients: Already-clipped gradient vector.

        Returns:
            Noised gradient vector.
        """
        sigma = self._config.noise_multiplier * self._config.max_grad_norm
        return [g + random.gauss(0.0, sigma) for g in clipped_gradients]

    def private_update(
        self, gradients: list[list[float]], lot_size: int | None = None
    ) -> list[float]:
        """Perform a full DP-SGD update step.

        1. Clip each per-sample gradient.
        2. Average the clipped gradients.
        3. Add calibrated noise to the average.
        4. Track privacy expenditure.

        Args:
            gradients: List of per-sample gradient vectors.
            lot_size: Lot size for averaging. Defaults to ``config.lot_size``
                or the number of gradients provided.

        Returns:
            The privatized average gradient vector.
        """
        batch = lot_size or self._config.lot_size or len(gradients)
        if not gradients:
            return []

        dim = len(gradients[0])

        # Step 1: Clip each gradient
        clipped = [self.clip_gradients(g) for g in gradients]

        # Step 2: Sum clipped gradients
        summed = [0.0] * dim
        for grad in clipped:
            for i in range(dim):
                summed[i] += grad[i]

        # Step 3: Average
        averaged = [s / batch for s in summed]

        # Step 4: Add noise (scaled to lot size)
        sigma = self._config.noise_multiplier * self._config.max_grad_norm / batch
        noised = [g + random.gauss(0.0, sigma) for g in averaged]

        # Step 5: Track privacy cost using RDP at alpha=10
        self._steps += 1
        alpha = 10.0
        rdp_eps = self._accountant.compose_rdp(
            alpha=alpha, steps=1, noise_multiplier=self._config.noise_multiplier
        )
        dp_eps = self._accountant.rdp_to_dp(rdp_eps, alpha, self._config.target_delta)
        self._accountant.consume(dp_eps, self._config.target_delta / (self._steps + 1))

        return noised

    def privacy_spent(self) -> dict[str, Any]:
        """Return current privacy expenditure summary.

        Returns:
            Dict with consumed epsilon/delta and budget status.
        """
        eps_remaining, delta_remaining = self._accountant.remaining()
        return {
            "steps_completed": self._steps,
            "consumed_epsilon": self._budget.consumed_epsilon,
            "consumed_delta": self._budget.consumed_delta,
            "remaining_epsilon": eps_remaining,
            "remaining_delta": delta_remaining,
            "target_epsilon": self._config.target_epsilon,
            "target_delta": self._config.target_delta,
            "noise_multiplier": self._config.noise_multiplier,
            "max_grad_norm": self._config.max_grad_norm,
        }

    def can_continue(self) -> bool:
        """Check whether the privacy budget allows more training steps.

        Returns:
            ``True`` if the budget is not exhausted.
        """
        return not self._accountant.is_exhausted()
