"""Governance engine for the Aegis security module.

:class:`GovernanceEngine` enforces organisational policies, maintains
audit logs, and tracks provenance chains for all agent actions.

Standalone helper functions :func:`check_data_residency`,
:func:`create_audit_trail`, and :func:`get_audit_trail` provide a
convenience layer for common governance checks outside the engine.
"""

from __future__ import annotations

import logging
import re
import uuid
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PolicyCheckResult:
    """Result of a governance policy check.

    Attributes:
        policy_id: Identifier of the policy that was checked.
        passed: Whether the action satisfies the policy.
        violations: List of specific policy violations found.
        severity: Maximum severity of violations (``"none"``,
            ``"low"``, ``"medium"``, ``"high"``, ``"critical"``).
        metadata: Additional check details.
    """

    policy_id: str
    passed: bool
    violations: list[str] = field(default_factory=list)
    severity: str = "none"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditEntry:
    """A single entry in the governance audit log.

    Attributes:
        timestamp: When the auditable event occurred.
        actor: Identifier of the actor (agent, user, system).
        action: Description of the action taken.
        resource: The resource that was acted upon.
        outcome: The result of the action (``"allowed"``, ``"denied"``).
        policy_checks: Results of any policy checks applied.
        metadata: Additional audit metadata.
    """

    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    actor: str = ""
    action: str = ""
    resource: str = ""
    outcome: str = "allowed"
    policy_checks: list[PolicyCheckResult] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProvenanceNode:
    """A node in the provenance chain.

    Attributes:
        node_id: Unique identifier for this provenance node.
        source: The origin (document, API call, user input, etc.).
        transformation: Description of how the data was transformed.
        timestamp: When this transformation occurred.
        parent_ids: IDs of parent nodes in the provenance DAG.
        metadata: Additional provenance metadata.
    """

    node_id: str = ""
    source: str = ""
    transformation: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    parent_ids: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


def _severity_for_violations(count: int) -> str:
    """Map a violation count to a normalized severity label."""
    if count <= 0:
        return "none"
    if count == 1:
        return "low"
    if count == 2:
        return "medium"
    if count <= 4:
        return "high"
    return "critical"


class GovernanceEngine:
    """Enforces governance policies and maintains audit/provenance records.

    The governance engine sits at the boundary of every agent action,
    checking policies before execution and logging results after.

    Args:
        policies: A list of policy definitions (dictionaries with at
            minimum an ``"id"`` and ``"rules"`` key).
    """

    def __init__(self, policies: list[dict[str, Any]] | None = None) -> None:
        self._policies = policies or []
        self._audit_log: list[AuditEntry] = []
        self._provenance_chain: list[ProvenanceNode] = []

    def check_policy(
        self,
        action: str,
        context: dict[str, Any] | None = None,
    ) -> list[PolicyCheckResult]:
        """Check an action against all configured governance policies.

        Args:
            action: Description of the action to be performed.
            context: Optional context for the policy evaluation
                (user identity, resource metadata, etc.).

        Returns:
            A list of :class:`PolicyCheckResult` instances, one per
            policy.  The action should only proceed if all results
            have ``passed == True``.
        """
        ctx = context or {}
        results: list[PolicyCheckResult] = []

        for policy in self._policies:
            policy_id = policy.get("id", "unknown")
            violations: list[str] = []

            for rule in policy.get("rules", []):
                rule_type = rule.get("type", "")

                if rule_type == "deny_keywords":
                    for keyword in rule.get("keywords", []):
                        if keyword.lower() in action.lower():
                            violations.append(f"Denied keyword found: '{keyword}'")

                elif rule_type == "require_keywords":
                    required = rule.get("keywords", [])
                    if required and not any(kw.lower() in action.lower() for kw in required):
                        violations.append(f"None of the required keywords found: {required}")

                elif rule_type == "max_length":
                    max_len = rule.get("max", 0)
                    if len(action) > max_len:
                        violations.append(f"Action length {len(action)} exceeds maximum {max_len}")

                elif rule_type == "regex_deny":
                    pattern = rule.get("pattern", "")
                    if pattern:
                        try:
                            if re.search(pattern, action, re.IGNORECASE):
                                violations.append(
                                    f"Action matches denied regex pattern: '{pattern}'"
                                )
                        except re.error:
                            violations.append(f"Invalid denied regex pattern: '{pattern}'")

                elif rule_type == "allow_actions":
                    allowed = rule.get("actions", [])
                    action_type = ctx.get("action_type", "")
                    if allowed and action_type not in allowed:
                        violations.append(
                            f"Action type '{action_type}' is not in allowed list: {allowed}"
                        )

            num_violations = len(violations)
            severity = _severity_for_violations(num_violations)

            results.append(
                PolicyCheckResult(
                    policy_id=policy_id,
                    passed=num_violations == 0,
                    violations=violations,
                    severity=severity,
                    metadata={"action": action, "context": ctx},
                )
            )

        return results

    def audit_log(
        self,
        actor: str,
        action: str,
        resource: str,
        outcome: str = "allowed",
        policy_checks: list[PolicyCheckResult] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Record an auditable event in the governance log.

        Args:
            actor: Who performed the action.
            action: What was done.
            resource: What was acted upon.
            outcome: Result of the action (``"allowed"`` or ``"denied"``).
            metadata: Additional metadata.

        Returns:
            The recorded :class:`AuditEntry`.
        """
        entry = AuditEntry(
            actor=actor,
            action=action,
            resource=resource,
            outcome=outcome,
            policy_checks=policy_checks or [],
            metadata=metadata or {},
        )
        self._audit_log.append(entry)
        return entry

    def check_compliance(
        self,
        framework: str,
        context: dict[str, Any] | None = None,
    ) -> list[PolicyCheckResult]:
        """Evaluate governance controls for a compliance framework.

        Currently supports SOC 2 style controls around audit logging,
        residency tagging, and audit-trail continuity.
        """
        normalized = framework.strip().lower()
        ctx = context or {}

        if normalized not in {"soc2", "soc_2"}:
            return [
                PolicyCheckResult(
                    policy_id=f"{framework}-unsupported",
                    passed=False,
                    violations=[f"Unsupported compliance framework: '{framework}'"],
                    severity="medium",
                )
            ]

        audit_event: AuditEntry | Mapping[str, Any] | None = None
        raw_event = ctx.get("audit_event")
        if isinstance(raw_event, AuditEntry | dict):
            audit_event = raw_event
        elif isinstance(raw_event, Mapping):
            audit_event = dict(raw_event)
        else:
            audit_event = {
                "timestamp": datetime.now(tz=UTC),
                "actor": str(ctx.get("actor", "")),
                "action": str(ctx.get("action", "")),
                "resource": str(ctx.get("resource", "")),
                "outcome": "allowed",
                "metadata": ctx.get("audit_metadata", {}),
            }

        results = [check_soc2_audit_logging(audit_event)]

        expected_region = ctx.get("expected_region")
        data_payload = ctx.get("data")
        if expected_region:
            if isinstance(data_payload, Mapping):
                results.append(check_data_residency(dict(data_payload), str(expected_region)))
            else:
                results.append(
                    PolicyCheckResult(
                        policy_id="data-residency",
                        passed=False,
                        violations=[
                            "No data payload provided for residency verification.",
                        ],
                        severity="medium",
                        metadata={"expected_region": str(expected_region)},
                    )
                )
        else:
            results.append(
                PolicyCheckResult(
                    policy_id="data-residency",
                    passed=True,
                    severity="none",
                    metadata={"skipped": True, "reason": "No expected_region supplied"},
                )
            )

        trail_ok = len(self._audit_log) > 0 or bool(ctx.get("audit_trail_enabled", True))
        results.append(
            PolicyCheckResult(
                policy_id="audit-trail",
                passed=trail_ok,
                violations=[] if trail_ok else ["Audit trail is not enabled."],
                severity="none" if trail_ok else "high",
                metadata={"entries": len(self._audit_log)},
            )
        )
        return results

    def enforce_action(
        self,
        actor: str,
        action: str,
        resource: str,
        framework: str = "soc2",
        context: dict[str, Any] | None = None,
    ) -> tuple[bool, list[PolicyCheckResult], AuditEntry]:
        """Run policy + compliance checks and emit an audited decision."""
        ctx = dict(context or {})
        ctx.setdefault("actor", actor)
        ctx.setdefault("action", action)
        ctx.setdefault("resource", resource)

        policy_results = self.check_policy(action, ctx)
        compliance_results = self.check_compliance(framework=framework, context=ctx)
        all_results = [*policy_results, *compliance_results]
        allowed = all(result.passed for result in all_results)

        meta = dict(ctx.get("audit_metadata", {}))
        if "request_id" in ctx and "request_id" not in meta:
            meta["request_id"] = str(ctx["request_id"])
        meta.setdefault("framework", framework)

        entry = self.audit_log(
            actor=actor,
            action=action,
            resource=resource,
            outcome="allowed" if allowed else "denied",
            policy_checks=all_results,
            metadata=meta,
        )
        return allowed, all_results, entry

    def provenance_chain(
        self,
        node_id: str,
        source: str,
        transformation: str = "",
        parent_ids: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ProvenanceNode:
        """Add a node to the provenance chain.

        The provenance chain records the full lineage of data as it
        flows through the system — from source documents, through
        retrieval and processing, to the final agent output.

        Args:
            node_id: Unique identifier for this node.
            source: Origin of the data.
            transformation: How the data was transformed at this step.
            parent_ids: IDs of upstream provenance nodes.
            metadata: Additional provenance metadata.

        Returns:
            The recorded :class:`ProvenanceNode`.
        """
        node = ProvenanceNode(
            node_id=node_id,
            source=source,
            transformation=transformation,
            parent_ids=parent_ids or [],
            metadata=metadata or {},
        )
        self._provenance_chain.append(node)
        return node

    def get_audit_log(self) -> list[AuditEntry]:
        """Return the full audit log.

        Returns:
            All recorded :class:`AuditEntry` instances.
        """
        return list(self._audit_log)

    def get_provenance_chain(self) -> list[ProvenanceNode]:
        """Return the full provenance chain.

        Returns:
            All recorded :class:`ProvenanceNode` instances.
        """
        return list(self._provenance_chain)


# ---------------------------------------------------------------------------
# Standalone governance helpers
# ---------------------------------------------------------------------------

# Module-level audit trail store shared by the helper functions.
_audit_store: list[AuditEntry] = []

# Valid data residency regions.
VALID_REGIONS = frozenset(
    {
        "us-east-1",
        "us-west-2",
        "eu-west-1",
        "eu-central-1",
        "ap-southeast-1",
        "ap-northeast-1",
    }
)
VALID_AUDIT_OUTCOMES = frozenset({"allowed", "denied", "recorded"})
SOC2_AUDIT_REQUIRED_FIELDS = frozenset({"actor", "action", "resource", "outcome"})


def check_soc2_audit_logging(
    event: AuditEntry | Mapping[str, Any],
) -> PolicyCheckResult:
    """Validate that an audit event satisfies SOC2 traceability controls."""
    if isinstance(event, AuditEntry):
        payload: dict[str, Any] = {
            "timestamp": event.timestamp,
            "actor": event.actor,
            "action": event.action,
            "resource": event.resource,
            "outcome": event.outcome,
            "metadata": event.metadata,
        }
    else:
        payload = dict(event)

    metadata = payload.get("metadata", {})
    if not isinstance(metadata, Mapping):
        metadata = {}

    violations: list[str] = []

    for field_name in SOC2_AUDIT_REQUIRED_FIELDS:
        value = payload.get(field_name)
        if not isinstance(value, str) or not value.strip():
            violations.append(f"Missing required audit field: '{field_name}'")

    timestamp = payload.get("timestamp")
    if not isinstance(timestamp, datetime):
        violations.append("Missing or invalid audit timestamp.")

    outcome = str(payload.get("outcome", "")).strip().lower()
    if outcome and outcome not in VALID_AUDIT_OUTCOMES:
        violations.append(
            f"Invalid audit outcome '{outcome}'. Must be one of {sorted(VALID_AUDIT_OUTCOMES)}."
        )

    has_trace_id = bool(
        payload.get("request_id")
        or payload.get("trace_id")
        or metadata.get("request_id")
        or metadata.get("trace_id")
        or metadata.get("entry_id")
    )
    if not has_trace_id:
        violations.append(
            "Audit record is missing trace identifier (request_id/trace_id/entry_id)."
        )

    passed = len(violations) == 0
    return PolicyCheckResult(
        policy_id="soc2-audit-logging",
        passed=passed,
        violations=violations,
        severity=_severity_for_violations(len(violations)),
        metadata={"traceable": has_trace_id, "outcome": outcome or None},
    )


def check_data_residency(
    data: dict[str, Any],
    region: str,
) -> PolicyCheckResult:
    """Verify that *data* is tagged for the correct residency *region*.

    The check inspects the ``"region"`` key inside *data*.  If it
    matches *region* the check passes; otherwise a violation is
    recorded.

    Args:
        data: A dictionary that should contain a ``"region"`` key.
        region: The expected data residency region (e.g.
            ``"eu-west-1"``).

    Returns:
        A :class:`PolicyCheckResult` indicating pass or fail.
    """
    violations: list[str] = []

    if region not in VALID_REGIONS:
        violations.append(f"Unknown target region: '{region}'")

    data_region = data.get("region")
    if data_region is None:
        violations.append("Data has no 'region' tag; residency cannot be verified.")
    elif data_region != region:
        violations.append(
            f"Data residency mismatch: data is tagged '{data_region}' but expected '{region}'."
        )

    passed = len(violations) == 0
    severity = _severity_for_violations(len(violations))

    return PolicyCheckResult(
        policy_id="data-residency",
        passed=passed,
        violations=violations,
        severity=severity,
        metadata={"expected_region": region, "data_region": data_region},
    )


def create_audit_trail(
    action: str,
    actor: str,
    resource: str,
    details: dict[str, Any] | None = None,
) -> AuditEntry:
    """Create a structured audit log entry and append it to the module store.

    This is a convenience wrapper around :class:`AuditEntry` that
    auto-generates a unique entry ID and timestamp.

    Args:
        action: The action that was performed (e.g. ``"eval.run"``).
        actor: Who performed the action (user, agent, or service ID).
        resource: The resource that was acted upon.
        details: Optional additional metadata to attach.

    Returns:
        The created :class:`AuditEntry`.
    """
    entry_id = str(uuid.uuid4())
    meta = dict(details) if details else {}
    meta["entry_id"] = entry_id

    entry = AuditEntry(
        actor=actor,
        action=action,
        resource=resource,
        outcome="recorded",
        metadata=meta,
    )
    _audit_store.append(entry)
    logger.debug(
        "Audit trail entry %s: actor=%s action=%s resource=%s",
        entry_id,
        actor,
        action,
        resource,
    )
    return entry


def get_audit_trail(
    filters: dict[str, str] | None = None,
) -> list[AuditEntry]:
    """Query the module-level audit trail store.

    Args:
        filters: Optional key/value pairs to match against entry
            attributes.  Supported keys: ``"actor"``, ``"action"``,
            ``"resource"``, ``"outcome"``.  Only entries matching
            **all** supplied filters are returned.

    Returns:
        A (possibly empty) list of matching :class:`AuditEntry`
        instances.
    """
    if not filters:
        return list(_audit_store)

    results: list[AuditEntry] = []
    for entry in _audit_store:
        match = True
        for key, value in filters.items():
            entry_value = getattr(entry, key, None)
            if entry_value is None:
                # Fall back to metadata lookup.
                entry_value = entry.metadata.get(key)
            if entry_value != value:
                match = False
                break
        if match:
            results.append(entry)
    return results
