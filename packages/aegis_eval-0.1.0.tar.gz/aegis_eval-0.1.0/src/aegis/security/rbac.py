"""Role-Based Access Control (RBAC) with Attribute-Based extensions.

Provides fine-grained access control for Aegis resources including
memory entries, eval runs, training jobs, and API endpoints.

Includes a :class:`PermissionType` enum of well-known platform
permissions, pre-defined roles (``ADMIN``, ``EVALUATOR``, ``VIEWER``),
and convenience functions :func:`check_permission` and
:func:`assign_role`.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Permission enum
# ---------------------------------------------------------------------------


class PermissionType(enum.Enum):
    """Well-known Aegis platform permissions.

    These symbolic names map to ``(resource, action)`` tuples used by
    :class:`Permission` dataclasses internally.
    """

    EVAL_RUN = ("eval", "execute")
    EVAL_READ = ("eval", "read")
    TRAIN_START = ("training", "execute")
    TRAIN_READ = ("training", "read")
    MEMORY_WRITE = ("memory", "write")
    MEMORY_READ = ("memory", "read")
    ADMIN_FULL = ("*", "*")


@dataclass
class Permission:
    """A single permission granting access to a resource action."""

    resource: str  # "memory", "eval", "training", "api", "*"
    action: str  # "read", "write", "delete", "execute", "admin", "*"
    conditions: dict[str, Any] = field(default_factory=dict)  # e.g. {"tier": "working"}

    @classmethod
    def from_type(cls, ptype: PermissionType, **conditions: Any) -> Permission:
        """Create a :class:`Permission` from a :class:`PermissionType` enum value.

        Args:
            ptype: The well-known permission type.
            **conditions: Optional attribute-based conditions.

        Returns:
            A new :class:`Permission` instance.
        """
        resource, action = ptype.value
        return cls(resource=resource, action=action, conditions=conditions)


@dataclass
class Role:
    """A named role with a set of permissions."""

    name: str
    description: str = ""
    permissions: list[Permission] = field(default_factory=list)
    parent_roles: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Principal:
    """An entity (user, agent, service) that can be granted roles."""

    id: str
    principal_type: str = "agent"  # "user", "agent", "service"
    roles: list[str] = field(default_factory=list)
    attributes: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


@dataclass
class AccessDecision:
    """Result of an access control check."""

    allowed: bool
    principal_id: str
    resource: str
    action: str
    reason: str = ""
    matched_role: str | None = None
    matched_permission: Permission | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# Built-in role definitions
# ---------------------------------------------------------------------------

#: Pre-defined VIEWER role with read-only access.
VIEWER = Role(
    name="viewer",
    description="Read-only access to eval, memory, and training state",
    permissions=[
        Permission.from_type(PermissionType.EVAL_READ),
        Permission.from_type(PermissionType.MEMORY_READ),
        Permission.from_type(PermissionType.TRAIN_READ),
    ],
)

#: Pre-defined EVALUATOR role — can run evaluations but not mutate memory.
EVALUATOR = Role(
    name="evaluator",
    description="Can read and run evaluations, and read memory",
    permissions=[
        Permission.from_type(PermissionType.EVAL_RUN),
    ],
    parent_roles=["viewer"],
)

#: Pre-defined OPERATOR role — evaluator + memory write.
OPERATOR = Role(
    name="operator",
    description="Can run evals and manage memory, but not configure training",
    permissions=[
        Permission.from_type(PermissionType.MEMORY_WRITE),
    ],
    parent_roles=["evaluator"],
)

#: Pre-defined TRAINER role — operator + training write/execute.
TRAINER = Role(
    name="trainer",
    description="Can configure and run training jobs",
    permissions=[
        Permission(resource="training", action="write"),
        Permission.from_type(PermissionType.TRAIN_START),
    ],
    parent_roles=["operator"],
)

#: Pre-defined ADMIN role with full access.
ADMIN = Role(
    name="admin",
    description="Full access to all resources",
    permissions=[Permission.from_type(PermissionType.ADMIN_FULL)],
)

# Default roles loaded by :class:`RBACEngine`.
DEFAULT_ROLES: list[Role] = [VIEWER, EVALUATOR, OPERATOR, TRAINER, ADMIN]


class RBACEngine:
    """Role-Based Access Control engine with attribute-based extensions.

    Manages roles, principals, and access decisions. Supports
    role inheritance and attribute-based conditions.
    """

    def __init__(self, roles: list[Role] | None = None) -> None:
        self._roles: dict[str, Role] = {}
        self._principals: dict[str, Principal] = {}
        self._access_log: list[AccessDecision] = []

        for role in roles or DEFAULT_ROLES:
            self._roles[role.name] = role

    def add_role(self, role: Role) -> None:
        """Add or update a role."""
        self._roles[role.name] = role

    def remove_role(self, role_name: str) -> bool:
        """Remove a role."""
        if role_name in self._roles:
            del self._roles[role_name]
            return True
        return False

    def get_role(self, role_name: str) -> Role | None:
        """Get a role by name."""
        return self._roles.get(role_name)

    def list_roles(self) -> list[Role]:
        """List all roles."""
        return list(self._roles.values())

    def register_principal(
        self,
        principal_id: str,
        principal_type: str = "agent",
        roles: list[str] | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> Principal:
        """Register a principal (user, agent, service)."""
        principal = Principal(
            id=principal_id,
            principal_type=principal_type,
            roles=roles or [],
            attributes=attributes or {},
        )
        self._principals[principal_id] = principal
        return principal

    def assign_role(self, principal_id: str, role_name: str) -> bool:
        """Assign a role to a principal."""
        principal = self._principals.get(principal_id)
        if not principal:
            return False
        if role_name not in self._roles:
            return False
        if role_name not in principal.roles:
            principal.roles.append(role_name)
        return True

    def revoke_role(self, principal_id: str, role_name: str) -> bool:
        """Revoke a role from a principal."""
        principal = self._principals.get(principal_id)
        if not principal or role_name not in principal.roles:
            return False
        principal.roles.remove(role_name)
        return True

    def check_access(
        self,
        principal_id: str,
        resource: str,
        action: str,
        context: dict[str, Any] | None = None,
    ) -> AccessDecision:
        """Check if a principal has access to perform an action on a resource."""
        principal = self._principals.get(principal_id)
        if not principal:
            decision = AccessDecision(
                allowed=False,
                principal_id=principal_id,
                resource=resource,
                action=action,
                reason="Principal not found",
            )
            self._access_log.append(decision)
            return decision

        # Collect all permissions from roles (including inherited)
        all_permissions: list[tuple[str, Permission]] = []
        visited_roles: set[str] = set()

        def collect_permissions(role_name: str) -> None:
            if role_name in visited_roles:
                return
            visited_roles.add(role_name)
            role = self._roles.get(role_name)
            if not role:
                return
            for perm in role.permissions:
                all_permissions.append((role_name, perm))
            for parent in role.parent_roles:
                collect_permissions(parent)

        for role_name in principal.roles:
            collect_permissions(role_name)

        # Check permissions
        for role_name, perm in all_permissions:
            if self._permission_matches(perm, resource, action, context):
                decision = AccessDecision(
                    allowed=True,
                    principal_id=principal_id,
                    resource=resource,
                    action=action,
                    reason=f"Granted by role '{role_name}'",
                    matched_role=role_name,
                    matched_permission=perm,
                )
                self._access_log.append(decision)
                return decision

        decision = AccessDecision(
            allowed=False,
            principal_id=principal_id,
            resource=resource,
            action=action,
            reason="No matching permission found",
        )
        self._access_log.append(decision)
        return decision

    @staticmethod
    def _permission_matches(
        perm: Permission,
        resource: str,
        action: str,
        context: dict[str, Any] | None = None,
    ) -> bool:
        """Check if a permission matches the requested resource/action."""
        # Resource match
        if perm.resource != "*" and perm.resource != resource:
            return False
        # Action match
        if perm.action != "*" and perm.action != action:
            return False
        # Condition match (attribute-based)
        if perm.conditions:
            if context is None:
                return False
            for key, expected in perm.conditions.items():
                if context.get(key) != expected:
                    return False
        return True

    def access_log(self, limit: int = 100) -> list[AccessDecision]:
        """Return recent access decisions."""
        return self._access_log[-limit:]

    def summary(self) -> dict[str, Any]:
        """Return RBAC summary."""
        total_checks = len(self._access_log)
        allowed = sum(1 for d in self._access_log if d.allowed)
        denied = total_checks - allowed
        return {
            "total_roles": len(self._roles),
            "total_principals": len(self._principals),
            "total_access_checks": total_checks,
            "allowed": allowed,
            "denied": denied,
        }


# ---------------------------------------------------------------------------
# Module-level convenience functions
# ---------------------------------------------------------------------------

# Shared engine instance used by the convenience helpers.
_default_engine = RBACEngine()


def check_permission(
    principal: str | Principal,
    permission: PermissionType,
    context: dict[str, Any] | None = None,
) -> AccessDecision:
    """Check whether *principal* holds *permission* on the default engine.

    This is a convenience wrapper around :meth:`RBACEngine.check_access`
    that accepts a :class:`PermissionType` enum value.

    Args:
        principal: A :class:`Principal` instance or a principal ID string.
        permission: The :class:`PermissionType` to check.
        context: Optional attribute-based context for conditional
            permissions.

    Returns:
        An :class:`AccessDecision` indicating whether access is granted.
    """
    principal_id = principal.id if isinstance(principal, Principal) else principal
    resource, action = permission.value
    return _default_engine.check_access(principal_id, resource, action, context)


def assign_role(principal_id: str, role: str | Role) -> bool:
    """Assign *role* to a principal on the default engine.

    If the principal is not yet registered it will be auto-registered as
    an ``"agent"`` type.

    Args:
        principal_id: Identifier of the principal to modify.
        role: A :class:`Role` instance or the role name as a string.

    Returns:
        ``True`` if the role was successfully assigned, ``False`` if the
        role does not exist in the engine.
    """
    role_name = role.name if isinstance(role, Role) else role

    # Auto-register if the principal is unknown.
    if principal_id not in _default_engine._principals:
        _default_engine.register_principal(principal_id, principal_type="agent")

    # If the role is a Role object not yet in the engine, add it.
    if isinstance(role, Role) and role_name not in _default_engine._roles:
        _default_engine.add_role(role)

    return _default_engine.assign_role(principal_id, role_name)
