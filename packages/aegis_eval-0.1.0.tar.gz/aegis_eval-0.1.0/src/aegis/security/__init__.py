"""Aegis Security — governance, RBAC, ABAC, compliance, encryption, DP, and tenant isolation.

Re-exports the governance engine, RBAC/ABAC engines, compliance reporters,
encryption utilities, differential privacy, tenant isolation, and their
supporting data classes and helpers.
"""

from aegis.security.abac import (
    ABACEngine,
    ABACPolicy,
    Attribute,
    AttributeSet,
    PolicyCondition,
    data_classification_policy,
    department_policy,
    sensitivity_policy,
    time_based_policy,
)
from aegis.security.compliance import (
    ComplianceControl,
    ComplianceReport,
    ComplianceReporter,
)
from aegis.security.compliance_reports import (
    ComplianceReportGenerator,
)
from aegis.security.differential_privacy import (
    DPTrainingWrapper,
    GaussianMechanism,
    PrivacyAccountant,
    PrivacyBudget,
    PrivacyConfig,
)
from aegis.security.encryption import (
    DataEncryptor,
    EncryptionConfig,
    SecretDetector,
    TLSConfig,
)
from aegis.security.governance import (
    AuditEntry,
    GovernanceEngine,
    PolicyCheckResult,
    ProvenanceNode,
    check_data_residency,
    check_soc2_audit_logging,
    create_audit_trail,
    get_audit_trail,
)
from aegis.security.isolation import (
    TenantInfo,
    TenantIsolation,
)
from aegis.security.rbac import (
    ADMIN,
    EVALUATOR,
    VIEWER,
    AccessDecision,
    Permission,
    PermissionType,
    Principal,
    RBACEngine,
    Role,
    assign_role,
    check_permission,
)

__all__ = [
    # Governance
    "GovernanceEngine",
    "PolicyCheckResult",
    "AuditEntry",
    "ProvenanceNode",
    "check_soc2_audit_logging",
    "check_data_residency",
    "create_audit_trail",
    "get_audit_trail",
    # RBAC
    "RBACEngine",
    "Role",
    "Permission",
    "PermissionType",
    "Principal",
    "AccessDecision",
    "ADMIN",
    "EVALUATOR",
    "VIEWER",
    "check_permission",
    "assign_role",
    # ABAC
    "ABACEngine",
    "ABACPolicy",
    "PolicyCondition",
    "Attribute",
    "AttributeSet",
    "data_classification_policy",
    "time_based_policy",
    "department_policy",
    "sensitivity_policy",
    # Compliance
    "ComplianceReporter",
    "ComplianceReport",
    "ComplianceControl",
    "ComplianceReportGenerator",
    # Differential Privacy
    "PrivacyBudget",
    "PrivacyConfig",
    "GaussianMechanism",
    "PrivacyAccountant",
    "DPTrainingWrapper",
    # Encryption
    "DataEncryptor",
    "EncryptionConfig",
    "TLSConfig",
    "SecretDetector",
    # Isolation
    "TenantIsolation",
    "TenantInfo",
]
