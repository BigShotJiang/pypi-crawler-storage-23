"""LlamaIndex agent adapter.

Wraps a LlamaIndex query engine or agent so that Aegis can drive it
through the evaluation pipeline.  Captures retrieval source nodes as
trajectory steps when the response includes them.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class LlamaIndexAdapter(AgentAdapter):
    """Adapter for LlamaIndex query engines and agents.

    Args:
        query_engine: A LlamaIndex query engine or agent with a
            ``.query()`` method.
        agent_id: Optional identifier; defaults to ``"llamaindex"``.
    """

    def __init__(self, query_engine: Any, *, agent_id: str = "llamaindex") -> None:
        self._engine = query_engine
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "llamaindex"

    # -- Internal helpers ---------------------------------------------------

    @staticmethod
    def _node_text(node: Any) -> str:
        """Extract text content from a LlamaIndex node-like object."""
        text = getattr(node, "text", None)
        if text is not None:
            return str(text)
        get_content = getattr(node, "get_content", None)
        if callable(get_content):
            return str(get_content())
        return str(node)

    @staticmethod
    def _extract_source_nodes(response: Any) -> list[dict[str, Any]]:
        """Extract source node information from a LlamaIndex response.

        LlamaIndex ``Response`` objects carry a ``source_nodes`` list of
        ``NodeWithScore`` objects.  Each has ``.node.text``, ``.score``,
        and optional ``.node.metadata``.  Returns a plain-dict
        representation for each.
        """
        source_nodes: list[Any] = getattr(response, "source_nodes", None) or []
        extracted: list[dict[str, Any]] = []
        for sn in source_nodes:
            node = getattr(sn, "node", sn)
            text = LlamaIndexAdapter._node_text(node)
            score = getattr(sn, "score", None)
            metadata = getattr(node, "metadata", {}) or {}
            node_id = getattr(node, "node_id", None) or getattr(node, "id_", None)
            extracted.append(
                {
                    "node_id": str(node_id) if node_id else None,
                    "text": str(text),
                    "score": float(score) if score is not None else None,
                    "metadata": dict(metadata) if isinstance(metadata, dict) else {},
                }
            )
        return extracted

    @staticmethod
    def _extract_token_usage(response: Any) -> int | None:
        """Try to pull total token usage from a LlamaIndex response.

        LlamaIndex stores token counts in ``response.metadata`` under
        keys like ``"token_usage"`` or directly as
        ``"prompt_tokens"`` / ``"completion_tokens"``.
        """
        metadata: dict[str, Any] = getattr(response, "metadata", None) or {}
        if not isinstance(metadata, dict):
            return None

        # Direct total_tokens key
        if "total_tokens" in metadata:
            return int(metadata["total_tokens"])

        # Nested token_usage dict
        token_usage = metadata.get("token_usage")
        if isinstance(token_usage, dict) and "total_tokens" in token_usage:
            return int(token_usage["total_tokens"])

        # Sum of prompt + completion tokens
        prompt_tokens = metadata.get("prompt_tokens")
        completion_tokens = metadata.get("completion_tokens")
        if prompt_tokens is not None and completion_tokens is not None:
            return int(prompt_tokens) + int(completion_tokens)

        return None

    # -- Core evaluate ------------------------------------------------------

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the LlamaIndex query engine.

        If the response includes ``source_nodes``, each retrieved node is
        recorded as a ``SEARCH`` step before the final ``ANSWER`` step.
        Token usage is tracked from response metadata when available.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` recording retrieval and answer steps.
        """
        start = datetime.now(tz=UTC)
        response = self._engine.query(task.prompt)
        end = datetime.now(tz=UTC)
        total_latency_ms = int((end - start).total_seconds() * 1000)

        steps: list[TrajectoryStep] = []
        total_tokens = self._extract_token_usage(response)

        # --- Retrieval steps from source nodes -----------------------------
        source_nodes = self._extract_source_nodes(response)
        if source_nodes:
            retrieval_ms = total_latency_ms // (len(source_nodes) + 1)
            for sn in source_nodes:
                metadata: dict[str, Any] = {"source": "llamaindex_retrieval"}
                if sn.get("node_id"):
                    metadata["node_id"] = sn["node_id"]
                if sn.get("score") is not None:
                    metadata["relevance_score"] = sn["score"]
                if sn.get("metadata"):
                    metadata["node_metadata"] = sn["metadata"]

                steps.append(
                    TrajectoryStep(
                        kind=StepKind.SEARCH,
                        content=sn["text"],
                        timestamp=start,
                        latency_ms=retrieval_ms,
                        metadata=metadata,
                    )
                )

        # --- Final answer --------------------------------------------------
        output_text = str(response)

        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=total_latency_ms // (len(source_nodes) + 1)
                if source_nodes
                else total_latency_ms,
                token_count=total_tokens,
            ),
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=total_latency_ms,
            total_tokens=total_tokens,
        )
