"""Aegis agent adapters — bridge the eval engine to agent frameworks.

Re-exports all built-in adapter classes for convenience::

    from aegis.adapters import LangChainAdapter, OpenAIAdapter, RESTAdapter
"""

from aegis.adapters.anthropic import AnthropicAdapter
from aegis.adapters.autogen import AutoGenAdapter
from aegis.adapters.base import AgentAdapter
from aegis.adapters.crewai import CrewAIAdapter
from aegis.adapters.dspy import DSPyAdapter
from aegis.adapters.langchain import LangChainAdapter
from aegis.adapters.langgraph import LangGraphAdapter
from aegis.adapters.letta import LettaAdapter
from aegis.adapters.llamaindex import LlamaIndexAdapter
from aegis.adapters.openai import OpenAIAdapter
from aegis.adapters.rest import RESTAdapter

__all__ = [
    "AgentAdapter",
    "AnthropicAdapter",
    "AutoGenAdapter",
    "CrewAIAdapter",
    "DSPyAdapter",
    "LangChainAdapter",
    "LangGraphAdapter",
    "LettaAdapter",
    "LlamaIndexAdapter",
    "OpenAIAdapter",
    "RESTAdapter",
]
