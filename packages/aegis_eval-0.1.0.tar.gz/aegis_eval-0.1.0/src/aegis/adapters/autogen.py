"""Microsoft AutoGen agent adapter.

Wraps an AutoGen agent (e.g. ``AssistantAgent`` or ``ConversableAgent``)
so that Aegis can drive it through the evaluation pipeline.  AutoGen is
an optional dependency — the adapter gracefully handles the case where
it is not installed.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class AutoGenAdapter(AgentAdapter):
    """Adapter for Microsoft AutoGen agents.

    Args:
        agent: An AutoGen agent instance (e.g. ``AssistantAgent``,
            ``ConversableAgent``) that exposes a ``.generate_reply()``
            method.  Typed as ``Any`` because ``autogen`` / ``pyautogen``
            is an optional dependency.
        agent_id: Optional identifier for the agent; defaults to
            ``"autogen"``.
    """

    def __init__(self, agent: Any, *, agent_id: str = "autogen") -> None:
        self._agent = agent
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "autogen"

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the AutoGen agent.

        Calls ``agent.generate_reply(messages=...)`` with the task prompt,
        then wraps the result into a :class:`TrajectoryV1`.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` containing the agent's output.

        Raises:
            ImportError: If neither ``autogen`` nor ``pyautogen`` is installed.
            RuntimeError: If the agent execution fails.
        """
        try:
            import autogen as _autogen  # type: ignore[import-not-found]  # noqa: F401
        except ImportError:
            try:
                import pyautogen as _autogen  # type: ignore[import-not-found]  # noqa: F401
            except ImportError as exc:
                raise ImportError(
                    "The 'pyautogen' package is required for AutoGenAdapter. "
                    "Install it with: pip install pyautogen"
                ) from exc

        start = datetime.now(tz=UTC)

        messages = [{"role": "user", "content": task.prompt}]
        if task.context:
            # Prepend context as a system message if available
            context_text = " ".join(f"{k}: {v}" for k, v in task.context.items())
            messages.insert(0, {"role": "system", "content": context_text})

        result = self._agent.generate_reply(messages=messages)

        end = datetime.now(tz=UTC)
        latency_ms = int((end - start).total_seconds() * 1000)

        output_text = result if isinstance(result, str) else str(result)

        steps = [
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=latency_ms,
            ),
        ]

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=latency_ms,
        )
