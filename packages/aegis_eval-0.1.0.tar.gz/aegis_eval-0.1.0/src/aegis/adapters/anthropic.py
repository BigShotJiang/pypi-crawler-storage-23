"""Anthropic Messages API adapter.

Wraps the Anthropic Python client so that Aegis can evaluate a Claude
model through the evaluation pipeline.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.exceptions import AdapterError
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class AnthropicAdapter(AgentAdapter):
    """Adapter for the Anthropic Messages API.

    Args:
        client: An ``anthropic.Anthropic`` client instance.
        model: Model identifier (e.g. ``"claude-sonnet-4-20250514"``).
        agent_id: Optional identifier; defaults to ``"anthropic"``.
    """

    def __init__(
        self,
        client: Any,
        model: str = "claude-sonnet-4-20250514",
        *,
        agent_id: str = "anthropic",
    ) -> None:
        self._client = client
        self._model = model
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "anthropic"

    @staticmethod
    def _extract_tool_steps(message: Any, timestamp: datetime) -> list[TrajectoryStep]:
        """Extract tool-use blocks as TOOL_CALL steps."""
        steps: list[TrajectoryStep] = []
        for block in getattr(message, "content", []) or []:
            if getattr(block, "type", "") != "tool_use":
                continue
            tool_name = getattr(block, "name", "tool")
            tool_input = getattr(block, "input", {})
            content = f"Tool call requested: {tool_name}"
            if tool_input:
                content = f"{content} with input {json.dumps(tool_input, sort_keys=True)}"
            steps.append(
                TrajectoryStep(
                    kind=StepKind.TOOL_CALL,
                    content=content,
                    timestamp=timestamp,
                    metadata={
                        "tool_name": str(tool_name),
                        "tool_use_id": str(getattr(block, "id", "")),
                    },
                )
            )
        return steps

    @staticmethod
    def _extract_text_response(message: Any) -> str:
        """Extract textual content from Anthropic response blocks."""
        texts = [
            str(getattr(block, "text", ""))
            for block in getattr(message, "content", []) or []
            if getattr(block, "type", "") == "text" and getattr(block, "text", "")
        ]
        if texts:
            return " ".join(texts)
        return ""

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the Anthropic Messages API.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` containing the model's response.
        """
        start = datetime.now(tz=UTC)

        try:
            message = self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=[{"role": "user", "content": task.prompt}],
            )
        except Exception as exc:
            raise AdapterError(f"Anthropic adapter request failed: {exc}") from exc

        end = datetime.now(tz=UTC)
        latency_ms = int((end - start).total_seconds() * 1000)

        output_text = self._extract_text_response(message)
        steps = self._extract_tool_steps(message, timestamp=end)

        token_count = None
        if hasattr(message, "usage") and message.usage:
            token_count = getattr(message.usage, "input_tokens", 0) + getattr(
                message.usage, "output_tokens", 0
            )

        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=latency_ms,
                token_count=token_count,
                metadata={
                    "model": self._model,
                    "message_id": message.id,
                    "stop_reason": str(getattr(message, "stop_reason", "")),
                },
            )
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=latency_ms,
            total_tokens=token_count,
            metadata={
                "model": self._model,
                "message_id": str(getattr(message, "id", "")),
                "stop_reason": str(getattr(message, "stop_reason", "")),
            },
        )
