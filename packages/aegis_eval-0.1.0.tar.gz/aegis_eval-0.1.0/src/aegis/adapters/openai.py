"""OpenAI Assistants API adapter.

Wraps the OpenAI Python client to evaluate an assistant through the
Aegis evaluation pipeline.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.exceptions import AdapterError
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class OpenAIAdapter(AgentAdapter):
    """Adapter for OpenAI Assistants API.

    Args:
        client: An ``openai.OpenAI`` client instance.
        assistant_id: The ID of the OpenAI assistant to invoke.
        agent_id: Optional identifier; defaults to ``"openai"``.
    """

    def __init__(
        self,
        client: Any,
        assistant_id: str,
        *,
        agent_id: str = "openai",
    ) -> None:
        self._client = client
        self._assistant_id = assistant_id
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "openai"

    @staticmethod
    def _extract_token_usage(run: Any) -> int | None:
        """Extract total token usage from an OpenAI run object."""
        usage = getattr(run, "usage", None)
        if usage is None:
            return None

        total = getattr(usage, "total_tokens", None)
        if total is not None:
            return int(total)

        prompt = getattr(usage, "prompt_tokens", None)
        completion = getattr(usage, "completion_tokens", None)
        if prompt is not None and completion is not None:
            return int(prompt) + int(completion)

        input_tokens = getattr(usage, "input_tokens", None)
        output_tokens = getattr(usage, "output_tokens", None)
        if input_tokens is not None and output_tokens is not None:
            return int(input_tokens) + int(output_tokens)

        return None

    def _extract_tool_steps(
        self, thread_id: str, run_id: str, timestamp: datetime
    ) -> list[TrajectoryStep]:
        """Extract tool-call steps from run-step metadata when available."""
        steps_api = getattr(self._client.beta.threads.runs, "steps", None)
        if steps_api is None or not hasattr(steps_api, "list"):
            return []

        try:
            run_steps = steps_api.list(thread_id=thread_id, run_id=run_id)
        except Exception:
            return []

        steps: list[TrajectoryStep] = []
        for run_step in getattr(run_steps, "data", []) or []:
            details = getattr(run_step, "step_details", None)
            if getattr(details, "type", "") != "tool_calls":
                continue
            for tool_call in getattr(details, "tool_calls", []) or []:
                tool_type = getattr(tool_call, "type", "tool")
                label = str(tool_type)
                if tool_type == "function":
                    function = getattr(tool_call, "function", None)
                    function_name = getattr(function, "name", None)
                    if function_name:
                        label = f"function:{function_name}"
                steps.append(
                    TrajectoryStep(
                        kind=StepKind.TOOL_CALL,
                        content=f"Tool call executed: {label}",
                        timestamp=timestamp,
                        metadata={
                            "tool_type": str(tool_type),
                            "run_step_id": str(getattr(run_step, "id", "")),
                        },
                    )
                )
        return steps

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the OpenAI Assistants API.

        Creates a thread, posts the task prompt as a message, triggers a
        run, and polls for completion.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` containing the assistant's response.
        """
        start = datetime.now(tz=UTC)

        try:
            # Create thread and message
            thread = self._client.beta.threads.create()
            self._client.beta.threads.messages.create(
                thread_id=thread.id,
                role="user",
                content=task.prompt,
            )

            # Trigger a run and poll for completion
            run = self._client.beta.threads.runs.create_and_poll(
                thread_id=thread.id,
                assistant_id=self._assistant_id,
            )
        except Exception as exc:
            raise AdapterError(f"OpenAI adapter request failed: {exc}") from exc

        if getattr(run, "status", None) not in (None, "completed"):
            raise AdapterError(
                f"OpenAI run did not complete successfully (status={getattr(run, 'status', 'unknown')})"
            )

        end = datetime.now(tz=UTC)
        latency_ms = int((end - start).total_seconds() * 1000)
        total_tokens = self._extract_token_usage(run)

        try:
            messages = self._client.beta.threads.messages.list(thread_id=thread.id)
        except Exception as exc:
            raise AdapterError(f"OpenAI adapter failed to fetch thread messages: {exc}") from exc
        assistant_messages = [m for m in messages.data if m.role == "assistant"]
        output_text = ""
        if assistant_messages:
            content_blocks = assistant_messages[0].content
            output_text = " ".join(
                block.text.value for block in content_blocks if hasattr(block, "text")
            )

        steps = self._extract_tool_steps(thread_id=thread.id, run_id=run.id, timestamp=end)
        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=latency_ms,
                token_count=total_tokens,
                metadata={"run_id": run.id, "thread_id": thread.id},
            )
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=latency_ms,
            total_tokens=total_tokens,
            metadata={
                "assistant_id": self._assistant_id,
                "run_id": run.id,
                "thread_id": thread.id,
                "status": getattr(run, "status", "unknown"),
            },
        )
