"""Letta (MemGPT) agent adapter.

Wraps a Letta agent's memory operations and conversations so Aegis can
evaluate and train its memory behavior. Captures memory reads/writes,
inner monologue, and conversation state.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)

# ---------------------------------------------------------------------------
# Memory operation classification
# ---------------------------------------------------------------------------

_WRITE_KEYWORDS = {
    "core_memory_append",
    "core_memory_replace",
    "archival_memory_insert",
    "memory_insert",
    "memory_update",
    "memory_replace",
    "memory_append",
    "memory_delete",
}

_READ_KEYWORDS = {
    "core_memory_search",
    "archival_memory_search",
    "memory_search",
    "memory_retrieve",
    "memory_query",
    "recall_memory_search",
    "conversation_search",
}


def _classify_memory_op(function_name: str) -> str:
    """Classify a Letta function call as a memory read, write, or other.

    Args:
        function_name: The name of the function called by the Letta agent.

    Returns:
        One of ``"memory_read"``, ``"memory_write"``, or ``"tool_call"``.
    """
    lower = function_name.lower()
    for keyword in _WRITE_KEYWORDS:
        if keyword in lower:
            return "memory_write"
    for keyword in _READ_KEYWORDS:
        if keyword in lower:
            return "memory_read"
    return "tool_call"


class LettaAdapter(AgentAdapter):
    """Adapter for Letta (MemGPT) agents.

    Letta agents use a structured memory system with core memory (persona
    and human blocks), archival memory (long-term vector store), and recall
    memory (conversation history search).  This adapter captures all memory
    operations, inner monologue, and function calls so that Aegis can
    evaluate and train the agent's memory behavior.

    Args:
        agent: A Letta agent instance or client that exposes a
            ``.send_message()`` or ``.user_message()`` method.
        agent_id: Optional identifier for the agent; defaults to
            ``"letta"``.
    """

    def __init__(self, agent: Any, *, agent_id: str = "letta") -> None:
        self._agent = agent
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "letta"

    # -- Internal helpers ---------------------------------------------------

    def _extract_memory_ops(self, agent_response: Any) -> list[TrajectoryStep]:
        """Extract memory reads and writes from a Letta agent response.

        Letta responses contain a list of messages, each of which may be a
        function call.  Memory-related function calls (core_memory_append,
        archival_memory_search, etc.) are extracted as ``MEMORY_OP`` steps.

        Args:
            agent_response: The raw response object returned by the Letta
                agent.  Expected to have a ``messages`` attribute or be a
                list of message dicts.

        Returns:
            A list of :class:`TrajectoryStep` instances for each memory
            operation found.
        """
        steps: list[TrajectoryStep] = []
        messages = self._get_messages(agent_response)

        for msg in messages:
            func_call = self._get_function_call(msg)
            if func_call is None:
                continue

            function_name = self._safe_str(
                func_call.get("name")
                if isinstance(func_call, dict)
                else getattr(func_call, "name", None),
                "unknown",
            )
            function_args = self._safe_str(
                func_call.get("arguments")
                if isinstance(func_call, dict)
                else getattr(func_call, "arguments", None),
                "",
            )

            op_type = _classify_memory_op(function_name)
            if op_type in ("memory_read", "memory_write"):
                # Extract the function return value if available
                func_return = ""
                if isinstance(msg, dict):
                    func_return = self._safe_str(msg.get("function_return"), "")
                else:
                    func_return = self._safe_str(getattr(msg, "function_return", None), "")

                content = (
                    f"{function_name}({function_args})"
                    if not func_return
                    else f"{function_name}({function_args}) -> {func_return}"
                )

                steps.append(
                    TrajectoryStep(
                        kind=StepKind.MEMORY_OP,
                        content=content,
                        timestamp=datetime.now(tz=UTC),
                        metadata={
                            "function_name": function_name,
                            "function_args": function_args,
                            "op_type": op_type,
                            "function_return": func_return,
                        },
                    )
                )

        return steps

    def _extract_inner_monologue(self, agent_response: Any) -> list[TrajectoryStep]:
        """Capture inner monologue (thinking) steps from the Letta response.

        Letta agents produce ``internal_monologue`` messages that represent
        the agent's reasoning before taking action.  These are mapped to
        ``THINK`` steps so evaluators can assess reasoning quality.

        Args:
            agent_response: The raw response object from the Letta agent.

        Returns:
            A list of :class:`TrajectoryStep` instances for each inner
            monologue message found.
        """
        steps: list[TrajectoryStep] = []
        messages = self._get_messages(agent_response)

        for msg in messages:
            monologue = None

            if isinstance(msg, dict):
                # Letta SDK v1+ uses "internal_monologue" key
                monologue = msg.get("internal_monologue") or msg.get("inner_thoughts")
                # Also check for a "reasoning" field in some Letta versions
                if monologue is None and msg.get("message_type") == "internal_monologue":
                    monologue = msg.get("content") or msg.get("text")
            else:
                # Object-style response
                monologue = getattr(msg, "internal_monologue", None) or getattr(
                    msg, "inner_thoughts", None
                )
                msg_type = getattr(msg, "message_type", None)
                if monologue is None and msg_type == "internal_monologue":
                    monologue = getattr(msg, "content", None) or getattr(msg, "text", None)

            if monologue and str(monologue).strip():
                steps.append(
                    TrajectoryStep(
                        kind=StepKind.THINK,
                        content=str(monologue).strip(),
                        timestamp=datetime.now(tz=UTC),
                        metadata={"source": "letta_inner_monologue"},
                    )
                )

        return steps

    @staticmethod
    def _extract_token_usage(result: Any) -> int | None:
        """Try to pull total token usage from a Letta response.

        Letta may attach usage information in the response metadata or in
        a ``usage`` attribute.  Returns ``None`` if unavailable.

        Args:
            result: The raw response from the Letta agent.

        Returns:
            Total token count as an integer, or ``None``.
        """
        # Check for usage attribute on the response object
        usage = getattr(result, "usage", None)
        if usage is not None:
            total = getattr(usage, "total_tokens", None)
            if total is not None:
                return int(total)
            # Some versions nest it in a dict
            if isinstance(usage, dict):
                total = usage.get("total_tokens")
                if total is not None:
                    return int(total)

        # Check for dict-style response
        if isinstance(result, dict):
            usage = result.get("usage", {})
            if isinstance(usage, dict):
                total = usage.get("total_tokens")
                if total is not None:
                    return int(total)
            # Some Letta versions put it at top level
            total = result.get("total_tokens")
            if total is not None:
                return int(total)

        return None

    # -- Message extraction helpers -----------------------------------------

    @staticmethod
    def _get_messages(agent_response: Any) -> list[Any]:
        """Extract the message list from a Letta response.

        Handles both dict-style and object-style responses, as well as
        responses that are already lists.

        Args:
            agent_response: The raw response from the Letta agent.

        Returns:
            A list of message objects or dicts.
        """
        if isinstance(agent_response, list):
            return agent_response
        if isinstance(agent_response, dict):
            messages = agent_response.get("messages", [])
            if isinstance(messages, list):
                return messages
            return []
        messages = getattr(agent_response, "messages", None)
        if messages is not None:
            return list(messages)
        return []

    @staticmethod
    def _get_function_call(msg: Any) -> dict[str, Any] | Any | None:
        """Extract a function call from a single message, if present.

        Args:
            msg: A single message from the Letta response.

        Returns:
            The function call dict/object, or ``None``.
        """
        if isinstance(msg, dict):
            func_call = msg.get("function_call")
            if func_call is not None:
                return func_call
            # Some Letta versions use "tool_call" as the message type
            if msg.get("message_type") == "function_call":
                return msg
            return None
        func_call = getattr(msg, "function_call", None)
        if func_call is not None:
            return func_call
        msg_type = getattr(msg, "message_type", None)
        if msg_type == "function_call":
            return msg
        return None

    @staticmethod
    def _safe_str(value: Any, default: str = "") -> str:
        """Convert a value to string, returning *default* if ``None``.

        Args:
            value: The value to convert.
            default: Fallback if *value* is ``None``.

        Returns:
            String representation of *value* or *default*.
        """
        if value is None:
            return default
        return str(value)

    # -- Core evaluate ------------------------------------------------------

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the Letta agent and capture its trajectory.

        The adapter sends the task prompt to the Letta agent and records
        all inner monologue, memory operations (reads and writes), tool
        calls, and the final assistant response.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` recording every step the agent took,
            including memory operations and inner monologue.
        """
        start = datetime.now(tz=UTC)

        # Letta agents support send_message (SDK v1+) or user_message (legacy)
        send_fn = getattr(self._agent, "send_message", None) or getattr(
            self._agent, "user_message", None
        )
        if send_fn is None:
            msg = "Letta agent must expose a .send_message() or .user_message() method"
            raise TypeError(msg)

        # Build message payload — pass context as additional metadata
        message = task.prompt
        if task.context:
            context_str = "\n".join(f"{k}: {v}" for k, v in task.context.items())
            message = f"{message}\n\nContext:\n{context_str}"

        result = send_fn(message)
        end = datetime.now(tz=UTC)
        total_latency_ms = int((end - start).total_seconds() * 1000)

        # -- Build trajectory steps -----------------------------------------
        steps: list[TrajectoryStep] = []
        total_tokens = self._extract_token_usage(result)

        # 1. Inner monologue (reasoning/thinking)
        monologue_steps = self._extract_inner_monologue(result)
        steps.extend(monologue_steps)

        # 2. Memory operations
        memory_steps = self._extract_memory_ops(result)
        steps.extend(memory_steps)

        # 3. Non-memory function calls (tool calls)
        tool_steps = self._extract_tool_calls(result)
        steps.extend(tool_steps)

        # 4. Final assistant message
        final_message = self._extract_final_response(result)

        # Distribute latency across steps
        num_steps = len(steps) + 1  # +1 for the final answer
        per_step_ms = total_latency_ms // max(num_steps, 1)
        for step in steps:
            step.latency_ms = per_step_ms

        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=final_message,
                timestamp=end,
                latency_ms=total_latency_ms - per_step_ms * len(steps)
                if steps
                else total_latency_ms,
                token_count=total_tokens,
            )
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=total_latency_ms,
            total_tokens=total_tokens,
        )

    def _extract_tool_calls(self, agent_response: Any) -> list[TrajectoryStep]:
        """Extract non-memory tool/function calls from the response.

        Any function call that is not classified as a memory read or write
        is recorded as a ``TOOL_CALL`` step.

        Args:
            agent_response: The raw response from the Letta agent.

        Returns:
            A list of :class:`TrajectoryStep` for non-memory tool calls.
        """
        steps: list[TrajectoryStep] = []
        messages = self._get_messages(agent_response)

        for msg in messages:
            func_call = self._get_function_call(msg)
            if func_call is None:
                continue

            function_name = self._safe_str(
                func_call.get("name")
                if isinstance(func_call, dict)
                else getattr(func_call, "name", None),
                "unknown",
            )
            function_args = self._safe_str(
                func_call.get("arguments")
                if isinstance(func_call, dict)
                else getattr(func_call, "arguments", None),
                "",
            )

            op_type = _classify_memory_op(function_name)
            if op_type == "tool_call":
                func_return = ""
                if isinstance(msg, dict):
                    func_return = self._safe_str(msg.get("function_return"), "")
                else:
                    func_return = self._safe_str(getattr(msg, "function_return", None), "")

                content = (
                    f"{function_name}({function_args})"
                    if not func_return
                    else f"{function_name}({function_args}) -> {func_return}"
                )

                steps.append(
                    TrajectoryStep(
                        kind=StepKind.TOOL_CALL,
                        content=content,
                        timestamp=datetime.now(tz=UTC),
                        metadata={
                            "tool": function_name,
                            "tool_input": function_args,
                            "function_return": func_return,
                        },
                    )
                )

        return steps

    def _extract_final_response(self, agent_response: Any) -> str:
        """Extract the final user-facing assistant message.

        Scans the messages for the last assistant-type message that
        is not inner monologue or a function call.

        Args:
            agent_response: The raw response from the Letta agent.

        Returns:
            The final assistant response text, or a fallback string.
        """
        messages = self._get_messages(agent_response)
        final_text = ""

        for msg in reversed(messages):
            if isinstance(msg, dict):
                msg_type = msg.get("message_type", "")
                role = msg.get("role", "")
                # Letta SDK: assistant_message type or role=assistant
                if msg_type == "assistant_message" or (
                    role == "assistant" and msg_type not in ("internal_monologue", "function_call")
                ):
                    final_text = self._safe_str(
                        msg.get("content") or msg.get("text") or msg.get("message"),
                        "",
                    )
                    if final_text:
                        break
            else:
                msg_type = getattr(msg, "message_type", "")
                role = getattr(msg, "role", "")
                if msg_type == "assistant_message" or (
                    role == "assistant" and msg_type not in ("internal_monologue", "function_call")
                ):
                    final_text = self._safe_str(
                        getattr(msg, "content", None)
                        or getattr(msg, "text", None)
                        or getattr(msg, "message", None),
                        "",
                    )
                    if final_text:
                        break

        if not final_text:
            # Fallback: use the string representation of the whole response
            if isinstance(agent_response, dict):
                final_text = self._safe_str(
                    agent_response.get("output")
                    or agent_response.get("response")
                    or agent_response.get("content"),
                    str(agent_response),
                )
            else:
                final_text = self._safe_str(
                    getattr(agent_response, "output", None)
                    or getattr(agent_response, "response", None),
                    str(agent_response),
                )

        return final_text
