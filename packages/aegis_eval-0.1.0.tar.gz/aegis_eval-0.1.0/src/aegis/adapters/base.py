"""Abstract base class for agent adapters.

Every adapter bridges the Aegis evaluation engine to a specific agent
framework or deployment target.  Concrete subclasses implement
:meth:`evaluate` to execute an :class:`EvalCaseV1` against the agent
and return the resulting :class:`TrajectoryV1`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from aegis.core.types import EvalCaseV1, TrajectoryV1


class AgentAdapter(ABC):
    """Base class that all Aegis agent adapters must inherit from.

    Subclasses must implement:
      * :meth:`evaluate` — run a single eval case and return a trajectory.
      * :attr:`name` — a human-readable adapter name.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this adapter (e.g. ``'langchain'``)."""
        ...

    @abstractmethod
    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Execute *task* against the wrapped agent and capture a trajectory.

        Args:
            task: The evaluation case to run.

        Returns:
            A :class:`TrajectoryV1` recording every step the agent took.

        Raises:
            aegis.core.exceptions.AdapterError: If communication with the
                agent fails.
        """
        ...
