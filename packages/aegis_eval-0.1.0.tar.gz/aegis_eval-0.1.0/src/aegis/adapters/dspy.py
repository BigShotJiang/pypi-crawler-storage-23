"""DSPy module adapter.

Wraps a DSPy module or program so that Aegis can drive it through the
evaluation pipeline.  Captures chain-of-thought reasoning and retrieval
steps as trajectory entries.

DSPy is an optional dependency -- the adapter gracefully handles the
case where it is not installed.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class DSPyAdapter(AgentAdapter):
    """Adapter for DSPy modules and programs.

    A DSPy module is a callable that takes keyword arguments (or a
    single positional ``question``/``query`` string) and returns a
    ``Prediction`` object.  This adapter records:

    * Chain-of-thought ``rationale`` as a :attr:`StepKind.REASON` step.
    * Retrieved ``passages`` / ``context`` as :attr:`StepKind.SEARCH`
      steps.
    * The final ``answer`` as a :attr:`StepKind.ANSWER` step.

    Args:
        module: A DSPy module (e.g. ``dspy.ChainOfThought``,
            ``dspy.ReAct``, or a custom ``dspy.Module`` subclass).
            Typed as ``Any`` because ``dspy`` is an optional dependency.
        agent_id: Optional identifier for the agent; defaults to
            ``"dspy"``.
    """

    def __init__(self, module: Any, *, agent_id: str = "dspy") -> None:
        self._module = module
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "dspy"

    # -- Internal helpers ---------------------------------------------------

    @staticmethod
    def _extract_passages(prediction: Any) -> list[str]:
        """Pull retrieval passages from a DSPy Prediction.

        DSPy retrieval modules attach passages under ``passages`` or
        ``context`` attributes, which may be a list of strings or a
        list of ``dspy.Example`` objects.
        """
        passages: list[str] = []
        for attr in ("passages", "context", "contexts", "retrieved_passages"):
            raw = getattr(prediction, attr, None)
            if raw is None:
                continue
            if isinstance(raw, list):
                for item in raw:
                    text = item if isinstance(item, str) else str(item)
                    if text.strip():
                        passages.append(text.strip())
            elif isinstance(raw, str) and raw.strip():
                passages.append(raw.strip())
        return passages

    @staticmethod
    def _extract_rationale(prediction: Any) -> str | None:
        """Pull chain-of-thought rationale from a DSPy Prediction."""
        for attr in ("rationale", "reasoning", "chain_of_thought", "thought"):
            val = getattr(prediction, attr, None)
            if val is not None and str(val).strip():
                return str(val).strip()
        return None

    @staticmethod
    def _extract_answer(prediction: Any) -> str:
        """Best-effort extraction of the final answer from a Prediction."""
        for attr in ("answer", "output", "response", "result"):
            val = getattr(prediction, attr, None)
            if val is not None and str(val).strip():
                return str(val).strip()
        # Fallback: stringify the entire prediction
        return str(prediction)

    @staticmethod
    def _extract_history(prediction: Any) -> list[dict[str, Any]]:
        """Try to extract a step-level trace history from the prediction.

        Some DSPy modules (e.g. ``dspy.ReAct``) store a ``history`` or
        ``trace`` attribute with per-action records.
        """
        for attr in ("history", "trace", "actions"):
            val = getattr(prediction, attr, None)
            if isinstance(val, list) and val:
                return [
                    dict(item) if isinstance(item, dict) else {"content": str(item)} for item in val
                ]
        return []

    # -- Core evaluate ------------------------------------------------------

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the DSPy module.

        The adapter calls the module with the task prompt, extracts
        retrieval passages, chain-of-thought rationale, and history
        (when available), and assembles them into a trajectory.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` capturing reasoning, retrieval, and
            the final answer.

        Raises:
            ImportError: If the ``dspy`` package is not installed.
        """
        try:
            import dspy  # type: ignore[import-not-found]  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "The 'dspy' package is required for DSPyAdapter. "
                "Install it with: pip install dspy-ai"
            ) from exc

        start = datetime.now(tz=UTC)

        # DSPy modules accept keyword args; try common conventions.
        try:
            prediction = self._module(question=task.prompt)
        except TypeError:
            try:
                prediction = self._module(query=task.prompt)
            except TypeError:
                prediction = self._module(task.prompt)

        end = datetime.now(tz=UTC)
        total_latency_ms = int((end - start).total_seconds() * 1000)

        steps: list[TrajectoryStep] = []

        # --- History / trace steps -----------------------------------------
        history = self._extract_history(prediction)
        if history:
            per_history_ms = total_latency_ms // (len(history) + 1)
            for entry in history:
                content = entry.get("content") or entry.get("observation") or str(entry)
                action_type = str(entry.get("action", entry.get("tool", ""))).lower()

                if "search" in action_type or "retriev" in action_type:
                    kind = StepKind.SEARCH
                elif "tool" in action_type or "action" in action_type:
                    kind = StepKind.TOOL_CALL
                else:
                    kind = StepKind.THINK

                steps.append(
                    TrajectoryStep(
                        kind=kind,
                        content=str(content),
                        timestamp=start,
                        latency_ms=per_history_ms,
                        metadata={"source": "dspy_trace", "raw": entry},
                    )
                )

        # --- Retrieval passages --------------------------------------------
        passages = self._extract_passages(prediction)
        if passages:
            retrieval_ms = total_latency_ms // (len(passages) + len(steps) + 1)
            for passage in passages:
                steps.append(
                    TrajectoryStep(
                        kind=StepKind.SEARCH,
                        content=passage,
                        timestamp=start,
                        latency_ms=retrieval_ms,
                        metadata={"source": "dspy_retrieval"},
                    )
                )

        # --- Chain-of-thought rationale ------------------------------------
        rationale = self._extract_rationale(prediction)
        if rationale:
            steps.append(
                TrajectoryStep(
                    kind=StepKind.REASON,
                    content=rationale,
                    timestamp=start,
                    latency_ms=total_latency_ms // (len(steps) + 2),
                    metadata={"source": "dspy_rationale"},
                )
            )

        # --- Final answer --------------------------------------------------
        answer = self._extract_answer(prediction)
        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=answer,
                timestamp=end,
                latency_ms=total_latency_ms // max(len(steps) + 1, 1),
            )
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=total_latency_ms,
        )
