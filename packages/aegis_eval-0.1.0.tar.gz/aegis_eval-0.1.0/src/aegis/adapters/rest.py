"""Generic REST adapter.

Sends evaluation tasks as HTTP POST requests to any agent endpoint and
parses the response into an Aegis :class:`TrajectoryV1`.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import httpx

from aegis.adapters.base import AgentAdapter
from aegis.core.exceptions import AdapterError
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class RESTAdapter(AgentAdapter):
    """Adapter that communicates with an agent over a REST API.

    The adapter POSTs the serialised :class:`EvalCaseV1` to the
    configured URL and expects a JSON response with at minimum an
    ``"output"`` field containing the agent's answer.

    Args:
        url: The agent's HTTP endpoint URL.
        headers: Optional HTTP headers (e.g. authentication tokens).
        timeout: Request timeout in seconds. Defaults to ``120``.
        agent_id: Optional identifier; defaults to ``"rest"``.
    """

    def __init__(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        *,
        timeout: float = 120.0,
        agent_id: str = "rest",
    ) -> None:
        self._url = url
        self._headers = headers or {}
        self._timeout = timeout
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "rest"

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """POST *task* to the REST endpoint and parse the response.

        The request body is the JSON-serialised :class:`EvalCaseV1`.  The
        expected response schema::

            {
                "output": "agent answer text",
                "steps": [...]           // optional trajectory steps
                "metadata": {...}        // optional metadata
            }

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` constructed from the response.

        Raises:
            aegis.core.exceptions.AdapterError: On HTTP or parsing errors.
        """
        start = datetime.now(tz=UTC)

        try:
            with httpx.Client(timeout=self._timeout) as client:
                response = client.post(
                    self._url,
                    json=task.model_dump(mode="json"),
                    headers={
                        "Content-Type": "application/json",
                        **self._headers,
                    },
                )
                response.raise_for_status()
        except httpx.HTTPError as exc:
            raise AdapterError(f"REST adapter request to {self._url} failed: {exc}") from exc

        end = datetime.now(tz=UTC)
        latency_ms = int((end - start).total_seconds() * 1000)

        try:
            data: dict[str, Any] = response.json()
        except (ValueError, TypeError) as exc:
            raise AdapterError(f"Failed to parse JSON response from {self._url}: {exc}") from exc

        output_text = data.get("output", "")
        response_steps = data.get("steps", [])
        response_metadata = data.get("metadata", {})

        # Build trajectory steps from response, or fall back to a single answer step
        steps: list[TrajectoryStep] = []
        if response_steps:
            for raw_step in response_steps:
                steps.append(
                    TrajectoryStep(
                        kind=StepKind(raw_step.get("kind", "answer")),
                        content=raw_step.get("content", ""),
                        timestamp=end,
                        metadata=raw_step.get("metadata", {}),
                    )
                )
        else:
            steps.append(
                TrajectoryStep(
                    kind=StepKind.ANSWER,
                    content=str(output_text),
                    timestamp=end,
                    latency_ms=latency_ms,
                )
            )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=latency_ms,
            metadata=response_metadata,
        )
