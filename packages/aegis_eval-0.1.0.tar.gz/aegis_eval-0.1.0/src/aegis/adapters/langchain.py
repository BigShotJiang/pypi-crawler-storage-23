"""LangChain agent adapter.

Wraps a LangChain ``AgentExecutor`` (or any runnable with ``.invoke()``)
so that Aegis can drive it through the evaluation pipeline.  Captures
intermediate steps (tool calls, reasoning) when the executor provides them.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class LangChainAdapter(AgentAdapter):
    """Adapter for LangChain agent executors.

    Args:
        agent_executor: A LangChain ``AgentExecutor`` or compatible runnable
            that exposes an ``.invoke()`` method.
        agent_id: Optional identifier for the agent; defaults to
            ``"langchain"``.
    """

    def __init__(self, agent_executor: Any, *, agent_id: str = "langchain") -> None:
        self._executor = agent_executor
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "langchain"

    # -- Internal helpers ---------------------------------------------------

    @staticmethod
    def _step_kind_for_tool(tool_name: str) -> StepKind:
        """Map a LangChain tool name to an Aegis :class:`StepKind`.

        Search/retrieval-oriented tools are mapped to ``SEARCH``; everything
        else becomes ``TOOL_CALL``.
        """
        search_keywords = {"search", "retriev", "lookup", "query", "fetch"}
        lower = tool_name.lower()
        for kw in search_keywords:
            if kw in lower:
                return StepKind.SEARCH
        return StepKind.TOOL_CALL

    @staticmethod
    def _extract_token_usage(result: Any) -> int | None:
        """Try to pull total token usage out of a LangChain result.

        LangChain's ``AgentExecutor`` may attach ``llm_output`` with
        ``token_usage`` when callbacks are enabled.  Returns ``None`` if
        unavailable.
        """
        # result dict may carry a top-level key from callback handlers
        if isinstance(result, dict):
            token_usage = result.get("token_usage") or result.get("llm_output", {}).get(
                "token_usage", {}
            )
            if isinstance(token_usage, dict):
                total = token_usage.get("total_tokens")
                if total is not None:
                    return int(total)
        return None

    # -- Core evaluate ------------------------------------------------------

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the LangChain agent executor.

        If the result contains ``intermediate_steps`` (provided by
        ``AgentExecutor`` when ``return_intermediate_steps=True``), each
        step is converted to a :class:`TrajectoryStep` with the
        appropriate :class:`StepKind`.  Token usage is tracked when
        available via callback metadata.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` recording every step the agent took.
        """
        start = datetime.now(tz=UTC)
        result = self._executor.invoke({"input": task.prompt, **task.context})
        end = datetime.now(tz=UTC)
        total_latency_ms = int((end - start).total_seconds() * 1000)

        steps: list[TrajectoryStep] = []
        total_tokens: int | None = self._extract_token_usage(result)

        # --- Intermediate steps (AgentExecutor) ----------------------------
        intermediate_steps: list[Any] = []
        if isinstance(result, dict):
            intermediate_steps = result.get("intermediate_steps", [])

        if intermediate_steps:
            # Each intermediate step is a tuple of (AgentAction, observation).
            per_step_ms = total_latency_ms // (len(intermediate_steps) + 1)
            for _idx, step in enumerate(intermediate_steps):
                # Unpack (action, observation)
                if isinstance(step, list | tuple) and len(step) >= 2:
                    action, observation = step[0], step[1]
                else:
                    # Unexpected shape — record as-is
                    steps.append(
                        TrajectoryStep(
                            kind=StepKind.TOOL_CALL,
                            content=str(step),
                            timestamp=start,
                            latency_ms=per_step_ms,
                        )
                    )
                    continue

                # Action may be an AgentAction with .tool / .tool_input / .log
                tool_name = getattr(action, "tool", "unknown_tool")
                tool_input = getattr(action, "tool_input", "")
                action_log = getattr(action, "log", "")

                # If the action carries a reasoning log, emit a REASON step
                if action_log and str(action_log).strip():
                    steps.append(
                        TrajectoryStep(
                            kind=StepKind.REASON,
                            content=str(action_log).strip(),
                            timestamp=start,
                            latency_ms=per_step_ms,
                            metadata={"source": "agent_action_log"},
                        )
                    )

                # Tool invocation step
                kind = self._step_kind_for_tool(str(tool_name))
                steps.append(
                    TrajectoryStep(
                        kind=kind,
                        content=str(observation),
                        timestamp=start,
                        latency_ms=per_step_ms,
                        metadata={
                            "tool": str(tool_name),
                            "tool_input": str(tool_input),
                        },
                    )
                )

        # --- Final answer --------------------------------------------------
        if isinstance(result, str):
            output_text = result
        elif isinstance(result, dict):
            output_text = str(result.get("output", result))
        else:
            output_text = str(result)

        steps.append(
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=total_latency_ms // (len(intermediate_steps) + 1)
                if intermediate_steps
                else total_latency_ms,
                token_count=total_tokens,
            ),
        )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=total_latency_ms,
            total_tokens=total_tokens,
        )
