"""CrewAI agent adapter.

Wraps a CrewAI ``Crew`` instance so that Aegis can drive it through
the evaluation pipeline.  CrewAI is an optional dependency — the adapter
gracefully handles the case where it is not installed.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class CrewAIAdapter(AgentAdapter):
    """Adapter for CrewAI crews.

    Args:
        crew: A CrewAI ``Crew`` instance that exposes a ``.kickoff()``
            method.  Typed as ``Any`` because ``crewai`` is an optional
            dependency.
        agent_id: Optional identifier for the agent; defaults to
            ``"crewai"``.
    """

    def __init__(self, crew: Any, *, agent_id: str = "crewai") -> None:
        self._crew = crew
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "crewai"

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the CrewAI crew.

        Calls ``crew.kickoff(inputs=...)`` with the task prompt and context,
        then wraps the result into a :class:`TrajectoryV1`.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` containing the crew's output.

        Raises:
            ImportError: If the ``crewai`` package is not installed.
            RuntimeError: If the crew execution fails.
        """
        try:
            import crewai as _crewai  # type: ignore[import-not-found]  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "The 'crewai' package is required for CrewAIAdapter. "
                "Install it with: pip install crewai"
            ) from exc

        start = datetime.now(tz=UTC)

        inputs = {"input": task.prompt, **task.context}
        result = self._crew.kickoff(inputs=inputs)

        end = datetime.now(tz=UTC)
        latency_ms = int((end - start).total_seconds() * 1000)

        # CrewAI returns a CrewOutput object or a string depending on version
        if isinstance(result, str):
            output_text = result
        elif hasattr(result, "raw"):
            output_text = str(result.raw)
        else:
            output_text = str(result)

        steps = [
            TrajectoryStep(
                kind=StepKind.ANSWER,
                content=output_text,
                timestamp=end,
                latency_ms=latency_ms,
            ),
        ]

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=latency_ms,
        )
