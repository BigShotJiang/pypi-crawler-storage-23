"""LangGraph state machine adapter.

Wraps a LangGraph compiled graph so that Aegis can drive it through the
evaluation pipeline.  Captures state transitions as trajectory steps,
mapping each node execution to an appropriate :class:`StepKind`.

LangGraph is an optional dependency -- the adapter gracefully handles
the case where it is not installed.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.adapters.base import AgentAdapter
from aegis.core.types import (
    EvalCaseV1,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


class LangGraphAdapter(AgentAdapter):
    """Adapter for LangGraph compiled state-machine graphs.

    Each node execution in the graph produces a :class:`TrajectoryStep`.
    Node names are mapped to step kinds using the following heuristic:

    * Names containing ``tool`` -> :attr:`StepKind.TOOL_CALL`
    * Names containing ``llm``, ``model``, ``chat``, or ``agent`` ->
      :attr:`StepKind.REASON`
    * The final output -> :attr:`StepKind.ANSWER`
    * Everything else -> :attr:`StepKind.THINK`

    Args:
        graph: A LangGraph compiled graph that supports ``.invoke()``
            or ``.stream()``.  Typed as ``Any`` because ``langgraph``
            is an optional dependency.
        agent_id: Optional identifier for the agent; defaults to
            ``"langgraph"``.
    """

    def __init__(self, graph: Any, *, agent_id: str = "langgraph") -> None:
        self._graph = graph
        self._agent_id = agent_id

    @property
    def name(self) -> str:
        """Return the adapter name."""
        return "langgraph"

    # -- Internal helpers ---------------------------------------------------

    @staticmethod
    def _step_kind_for_node(node_name: str) -> StepKind:
        """Map a LangGraph node name to an Aegis :class:`StepKind`."""
        lower = node_name.lower()

        tool_keywords = {"tool", "action", "execute", "function"}
        for kw in tool_keywords:
            if kw in lower:
                return StepKind.TOOL_CALL

        llm_keywords = {"llm", "model", "chat", "agent", "generate", "reason"}
        for kw in llm_keywords:
            if kw in lower:
                return StepKind.REASON

        return StepKind.THINK

    @staticmethod
    def _extract_content(state: Any) -> str:
        """Best-effort extraction of human-readable content from a graph state."""
        if isinstance(state, str):
            return state
        if isinstance(state, dict):
            # Common LangGraph state keys
            for key in ("output", "response", "result", "messages", "content"):
                if key in state:
                    val = state[key]
                    if isinstance(val, list) and val:
                        # Messages list -- take the last message
                        last = val[-1]
                        if hasattr(last, "content"):
                            return str(last.content)
                        return str(last)
                    return str(val)
            return str(state)
        return str(state)

    # -- Core evaluate ------------------------------------------------------

    def evaluate(self, task: EvalCaseV1) -> TrajectoryV1:
        """Run *task* through the LangGraph compiled graph.

        The adapter first attempts to use ``.stream()`` to capture
        per-node state transitions.  If streaming is not available it
        falls back to ``.invoke()`` and records a single answer step.

        Args:
            task: The evaluation case to execute.

        Returns:
            A :class:`TrajectoryV1` recording each node's output as a
            step.

        Raises:
            ImportError: If the ``langgraph`` package is not installed.
        """
        try:
            import langgraph  # type: ignore[import-not-found]  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "The 'langgraph' package is required for LangGraphAdapter. "
                "Install it with: pip install langgraph"
            ) from exc

        input_payload: dict[str, Any] = {"input": task.prompt, **task.context}

        start = datetime.now(tz=UTC)
        steps: list[TrajectoryStep] = []
        final_output: str | None = None

        # Prefer streaming to capture per-node transitions
        stream_fn = getattr(self._graph, "stream", None)
        if callable(stream_fn):
            try:
                for event in stream_fn(input_payload):
                    now = datetime.now(tz=UTC)
                    # LangGraph stream events are dicts of {node_name: state}
                    if isinstance(event, dict):
                        for node_name, node_state in event.items():
                            # Skip internal/private nodes
                            if node_name.startswith("__"):
                                continue
                            kind = self._step_kind_for_node(node_name)
                            content = self._extract_content(node_state)
                            steps.append(
                                TrajectoryStep(
                                    kind=kind,
                                    content=content,
                                    timestamp=now,
                                    metadata={
                                        "node": node_name,
                                        "source": "langgraph_stream",
                                    },
                                )
                            )
                            final_output = content
                    else:
                        # Fallback: event is not a dict
                        content = self._extract_content(event)
                        steps.append(
                            TrajectoryStep(
                                kind=StepKind.THINK,
                                content=content,
                                timestamp=now,
                                metadata={"source": "langgraph_stream"},
                            )
                        )
                        final_output = content
            except Exception:
                # Streaming failed -- fall through to invoke
                steps = []
                final_output = None

        # Fallback to invoke if streaming produced no steps
        if not steps:
            result = self._graph.invoke(input_payload)
            end = datetime.now(tz=UTC)
            final_output = self._extract_content(result)
            steps.append(
                TrajectoryStep(
                    kind=StepKind.ANSWER,
                    content=final_output,
                    timestamp=end,
                    metadata={"source": "langgraph_invoke"},
                )
            )

        end = datetime.now(tz=UTC)
        total_latency_ms = int((end - start).total_seconds() * 1000)

        # Distribute latency evenly across steps
        per_step_ms = total_latency_ms // max(len(steps), 1)
        for step in steps:
            step.latency_ms = per_step_ms

        # Ensure the last step is marked as ANSWER
        if steps and steps[-1].kind != StepKind.ANSWER:
            steps.append(
                TrajectoryStep(
                    kind=StepKind.ANSWER,
                    content=final_output or "",
                    timestamp=end,
                    latency_ms=per_step_ms,
                    metadata={"source": "langgraph_final"},
                )
            )

        return TrajectoryV1(
            agent_id=self._agent_id,
            task_id=task.id,
            steps=steps,
            total_latency_ms=total_latency_ms,
        )
