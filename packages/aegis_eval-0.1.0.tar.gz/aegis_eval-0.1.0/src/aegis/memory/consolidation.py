"""Sleep-time memory consolidation engine.

During idle periods, consolidates memory by:
- Pattern abstraction from specific episodes (TF-IDF scored)
- Memory compression (reduce footprint, preserve critical info)
- Link discovery (find connections not obvious at storage time)
- Decay application (reduce confidence for unaccessed memories)
- Consistency checking (detect/flag contradictions)
- Scheduled consolidation based on idle detection
- Multi-strategy consolidation (full, decay-only, compress-only, etc.)
- Semantic clustering for entry grouping
- Consolidation metrics for effectiveness tracking
"""

from __future__ import annotations

import enum
import math
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from difflib import SequenceMatcher
from typing import Any

from aegis.core.types import MemoryTier
from aegis.memory.types import MemoryEntry, MemoryStore


@dataclass
class ConsolidationResult:
    """Result of a memory consolidation run."""

    entries_processed: int = 0
    entries_compressed: int = 0
    entries_decayed: int = 0
    links_discovered: int = 0
    contradictions_found: int = 0
    patterns_abstracted: int = 0
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None
    details: dict[str, Any] = field(default_factory=dict)


class ConsolidationEngine:
    """Runs sleep-time memory consolidation on a memory store."""

    def __init__(
        self,
        decay_rate: float = 0.05,
        similarity_threshold: float = 0.7,
        min_access_count: int = 0,
    ) -> None:
        self._decay_rate = decay_rate
        self._similarity_threshold = similarity_threshold
        self._min_access_count = min_access_count

    def consolidate(self, store: MemoryStore) -> ConsolidationResult:
        """Run full consolidation on all entries in the store."""
        result = ConsolidationResult()
        all_entries = self._load_all(store)
        result.entries_processed = len(all_entries)
        result.entries_decayed = self._apply_decay(all_entries, store)
        result.entries_compressed = self._compress_entries(all_entries, store)
        result.links_discovered = self._discover_links(all_entries)
        result.contradictions_found = self._detect_contradictions(all_entries)
        result.patterns_abstracted = self._abstract_patterns(all_entries, store)
        result.completed_at = datetime.now(UTC)
        return result

    def consolidate_with_strategy(
        self, store: MemoryStore, strategy: ConsolidationStrategy
    ) -> ConsolidationResult:
        """Run consolidation with a specific strategy subset."""
        if strategy == ConsolidationStrategy.FULL:
            return self.consolidate(store)
        result = ConsolidationResult()
        all_entries = self._load_all(store)
        result.entries_processed = len(all_entries)
        if strategy == ConsolidationStrategy.DECAY_ONLY:
            result.entries_decayed = self._apply_decay(all_entries, store)
        elif strategy == ConsolidationStrategy.COMPRESS_ONLY:
            result.entries_compressed = self._compress_entries(all_entries, store)
        elif strategy == ConsolidationStrategy.LINKS_ONLY:
            result.links_discovered = self._discover_links(all_entries)
        elif strategy == ConsolidationStrategy.PATTERNS_ONLY:
            result.patterns_abstracted = self._abstract_patterns(all_entries, store)
        result.completed_at = datetime.now(UTC)
        return result

    @staticmethod
    def _load_all(store: MemoryStore) -> list[MemoryEntry]:
        """Load all entries across every memory tier."""
        entries: list[MemoryEntry] = []
        for tier in MemoryTier:
            entries.extend(store.list_by_tier(tier))
        return entries

    def _apply_decay(self, entries: list[MemoryEntry], store: MemoryStore) -> int:
        """Reduce confidence of entries that haven't been accessed recently."""
        decayed = 0
        for entry in entries:
            access_count = entry.metadata.get("access_count", 0)
            if access_count <= self._min_access_count and entry.confidence > 0.1:
                new_confidence = max(0.1, entry.confidence - self._decay_rate)
                if new_confidence < entry.confidence:
                    entry.confidence = new_confidence
                    entry.metadata["decayed"] = True
                    store.store(entry)
                    decayed += 1
        return decayed

    def _compress_entries(self, entries: list[MemoryEntry], store: MemoryStore) -> int:
        """Compress entries with long text values."""
        compressed = 0
        for entry in entries:
            value = str(entry.value)
            words = value.split()
            if len(words) > 200:
                shortened = " ".join(words[:100]) + " [...] " + " ".join(words[-50:])
                entry.value = shortened
                entry.metadata["compressed"] = True
                entry.metadata["original_word_count"] = len(words)
                store.store(entry)
                compressed += 1
        return compressed

    def _discover_links(self, entries: list[MemoryEntry]) -> int:
        """Find semantically similar entries that could be linked."""
        links = 0
        for i in range(len(entries)):
            for j in range(i + 1, min(i + 50, len(entries))):
                val_i = str(entries[i].value).lower()
                val_j = str(entries[j].value).lower()
                if len(val_i) < 10 or len(val_j) < 10:
                    continue
                similarity = SequenceMatcher(None, val_i[:200], val_j[:200]).ratio()
                if similarity >= self._similarity_threshold:
                    entries[i].metadata.setdefault("discovered_links", []).append(entries[j].key)
                    entries[j].metadata.setdefault("discovered_links", []).append(entries[i].key)
                    links += 1
        return links

    def _detect_contradictions(self, entries: list[MemoryEntry]) -> int:
        """Detect potential contradictions between entries with similar keys."""
        contradictions = 0
        key_groups: dict[str, list[MemoryEntry]] = {}
        for entry in entries:
            prefix = entry.key.rsplit("_", 1)[0] if "_" in entry.key else entry.key[:10]
            key_groups.setdefault(prefix, []).append(entry)
        for _prefix, group in key_groups.items():
            if len(group) < 2:
                continue
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    val_i = str(group[i].value).lower()
                    val_j = str(group[j].value).lower()
                    if self._has_negation_conflict(val_i, val_j):
                        group[i].metadata["potential_contradiction"] = group[j].key
                        group[j].metadata["potential_contradiction"] = group[i].key
                        contradictions += 1
        return contradictions

    @staticmethod
    def _has_negation_conflict(text_a: str, text_b: str) -> bool:
        """Check if two texts have a simple negation-based conflict."""
        negation_words = {
            "not",
            "no",
            "never",
            "none",
            "neither",
            "nor",
            "false",
            "invalid",
            "incorrect",
        }
        words_a = set(text_a.split())
        words_b = set(text_b.split())
        neg_a = bool(words_a & negation_words)
        neg_b = bool(words_b & negation_words)
        if neg_a == neg_b:
            return False
        clean_a = words_a - negation_words
        clean_b = words_b - negation_words
        if not clean_a or not clean_b:
            return False
        overlap = len(clean_a & clean_b) / min(len(clean_a), len(clean_b))
        return overlap > 0.5

    def _abstract_patterns(self, entries: list[MemoryEntry], store: MemoryStore) -> int:
        """Abstract common patterns using TF-IDF-like term frequency scoring."""
        patterns = 0
        tag_groups: dict[str, list[MemoryEntry]] = {}
        for entry in entries:
            for tag in entry.tags:
                tag_groups.setdefault(tag, []).append(entry)

        all_texts = [str(e.value).lower() for e in entries]
        doc_freq = _compute_document_frequency(all_texts)
        total_docs = max(len(all_texts), 1)

        for tag, group in tag_groups.items():
            if len(group) >= 3:
                word_sets = [set(str(e.value).lower().split()) for e in group]
                common = word_sets[0]
                for ws in word_sets[1:]:
                    common &= ws
                if len(common) >= 5:
                    group_texts = [str(e.value).lower() for e in group]
                    scored = _score_terms_tfidf(common, group_texts, doc_freq, total_docs)
                    top_terms = [
                        t for t, _ in sorted(scored.items(), key=lambda x: x[1], reverse=True)
                    ][:20]
                    group[0].metadata.setdefault("abstracted_patterns", []).append(
                        {
                            "tag": tag,
                            "common_terms": top_terms,
                            "source_count": len(group),
                            "tfidf_scored": True,
                        }
                    )
                    patterns += 1
        return patterns

    def _extract_semantic_clusters(
        self, entries: list[MemoryEntry], min_cluster_size: int = 3
    ) -> list[dict[str, Any]]:
        """Group entries by content similarity and create cluster summaries.

        Uses greedy single-pass clustering with Jaccard token overlap.
        """
        clusters: list[tuple[set[str], list[MemoryEntry]]] = []
        for entry in entries:
            tokens = set(str(entry.value).lower().split())
            if not tokens:
                continue
            best_idx, best_sim = -1, 0.0
            for idx, (centroid, _members) in enumerate(clusters):
                sim = _jaccard(tokens, centroid)
                if sim > best_sim:
                    best_sim, best_idx = sim, idx
            if best_sim >= self._similarity_threshold and best_idx >= 0:
                centroid, members = clusters[best_idx]
                members.append(entry)
                clusters[best_idx] = (centroid & tokens, members)
            else:
                clusters.append((tokens, [entry]))
        return [
            {
                "entry_keys": [m.key for m in members],
                "common_terms": sorted(centroid)[:30],
                "cluster_size": len(members),
                "mean_confidence": round(sum(m.confidence for m in members) / len(members), 4),
            }
            for centroid, members in clusters
            if len(members) >= min_cluster_size
        ]


# ---------------------------------------------------------------------------
# Consolidation Strategy Enum
# ---------------------------------------------------------------------------


class ConsolidationStrategy(enum.Enum):
    """Strategy options for targeted consolidation runs."""

    FULL = "full"
    DECAY_ONLY = "decay_only"
    COMPRESS_ONLY = "compress_only"
    LINKS_ONLY = "links_only"
    PATTERNS_ONLY = "patterns_only"


# ---------------------------------------------------------------------------
# TF-IDF Helpers
# ---------------------------------------------------------------------------


def _compute_document_frequency(documents: list[str]) -> dict[str, int]:
    """Compute document frequency for each term across a corpus."""
    df: dict[str, int] = Counter()
    for doc in documents:
        for word in set(doc.split()):
            if len(word) > 1:
                df[word] += 1
    return dict(df)


def _score_terms_tfidf(
    terms: set[str],
    group_texts: list[str],
    doc_freq: dict[str, int],
    total_docs: int,
) -> dict[str, float]:
    """Score terms using TF-IDF within a group against the full corpus."""
    group_counts: Counter[str] = Counter()
    for text in group_texts:
        group_counts.update(text.split())
    total_words = max(sum(group_counts.values()), 1)
    scored: dict[str, float] = {}
    for term in terms:
        if len(term) <= 1:
            continue
        tf = group_counts.get(term, 0) / total_words
        idf = math.log((total_docs + 1) / (doc_freq.get(term, 1) + 1)) + 1.0
        scored[term] = round(tf * idf, 6)
    return scored


def _jaccard(set_a: set[str], set_b: set[str]) -> float:
    """Compute Jaccard similarity between two sets."""
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


# ---------------------------------------------------------------------------
# Consolidation Scheduler
# ---------------------------------------------------------------------------


class ConsolidationScheduler:
    """Schedules consolidation runs based on system idle time.

    Triggers consolidation when the system has been idle longer than a
    configurable threshold, with rate-limiting between consecutive runs.
    """

    def __init__(
        self,
        engine: ConsolidationEngine,
        idle_threshold_seconds: float = 300.0,
    ) -> None:
        self._engine = engine
        self._idle_threshold = idle_threshold_seconds
        self._last_run: datetime | None = None
        self._run_count: int = 0

    def should_consolidate(self, last_interaction_time: datetime) -> bool:
        """Determine whether consolidation should run based on idle time."""
        now = datetime.now(UTC)
        if (now - last_interaction_time).total_seconds() < self._idle_threshold:
            return False
        return not (
            self._last_run is not None
            and (now - self._last_run).total_seconds() < self._idle_threshold * 0.5
        )

    def run_if_idle(
        self,
        store: MemoryStore,
        last_interaction_time: datetime,
        strategy: ConsolidationStrategy = ConsolidationStrategy.FULL,
    ) -> ConsolidationResult | None:
        """Run consolidation if the system is idle, otherwise return None."""
        if not self.should_consolidate(last_interaction_time):
            return None
        result = self._engine.consolidate_with_strategy(store, strategy)
        self._last_run = datetime.now(UTC)
        self._run_count += 1
        return result

    @property
    def run_count(self) -> int:
        """Number of consolidation runs completed by this scheduler."""
        return self._run_count

    @property
    def last_run(self) -> datetime | None:
        """Timestamp of the last consolidation run."""
        return self._last_run


# ---------------------------------------------------------------------------
# Consolidation Metrics
# ---------------------------------------------------------------------------


@dataclass
class _ConsolidationRunRecord:
    """Internal record of a single consolidation run."""

    memory_size_before: int
    memory_size_after: int
    compression_ratio: float
    time_taken_seconds: float
    entries_affected: int
    strategy: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))


class ConsolidationMetrics:
    """Tracks consolidation effectiveness over time."""

    def __init__(self) -> None:
        self._history: list[_ConsolidationRunRecord] = []

    def record_run(
        self,
        result: ConsolidationResult,
        memory_size_before: int,
        memory_size_after: int,
        strategy: str = "full",
    ) -> _ConsolidationRunRecord:
        """Record metrics from a completed consolidation run."""
        time_taken = 0.0
        if result.completed_at and result.started_at:
            time_taken = (result.completed_at - result.started_at).total_seconds()
        compression_ratio = (
            round(memory_size_after / memory_size_before, 4) if memory_size_before > 0 else 1.0
        )
        entries_affected = (
            result.entries_compressed
            + result.entries_decayed
            + result.links_discovered
            + result.patterns_abstracted
        )
        record = _ConsolidationRunRecord(
            memory_size_before=memory_size_before,
            memory_size_after=memory_size_after,
            compression_ratio=compression_ratio,
            time_taken_seconds=round(time_taken, 4),
            entries_affected=entries_affected,
            strategy=strategy,
        )
        self._history.append(record)
        return record

    def get_history(self, limit: int = 50) -> list[dict[str, Any]]:
        """Return recent consolidation run records as dictionaries."""
        return [
            {
                "memory_size_before": r.memory_size_before,
                "memory_size_after": r.memory_size_after,
                "compression_ratio": r.compression_ratio,
                "time_taken_seconds": r.time_taken_seconds,
                "entries_affected": r.entries_affected,
                "strategy": r.strategy,
                "timestamp": r.timestamp.isoformat(),
            }
            for r in self._history[-limit:]
        ]

    def mean_compression_ratio(self) -> float:
        """Average compression ratio across all recorded runs."""
        if not self._history:
            return 1.0
        return round(sum(r.compression_ratio for r in self._history) / len(self._history), 4)

    def total_entries_affected(self) -> int:
        """Total entries affected across all consolidation runs."""
        return sum(r.entries_affected for r in self._history)

    def total_time_spent(self) -> float:
        """Total time spent on consolidation across all runs (seconds)."""
        return round(sum(r.time_taken_seconds for r in self._history), 4)

    def summary(self) -> dict[str, Any]:
        """Return aggregate metrics summary."""
        n = len(self._history)
        return {
            "total_runs": n,
            "mean_compression_ratio": self.mean_compression_ratio(),
            "total_entries_affected": self.total_entries_affected(),
            "total_time_spent_seconds": self.total_time_spent(),
            "mean_time_per_run": round(self.total_time_spent() / n, 4) if n else 0.0,
            "strategies_used": list({r.strategy for r in self._history}),
        }
