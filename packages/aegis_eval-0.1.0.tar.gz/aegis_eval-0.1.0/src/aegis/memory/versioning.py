"""Git-like memory versioning for point-in-time reconstruction.

Provides commits, branches, tags, diffs, and merge with conflict resolution
so agents can explore hypotheses on branches and reconstruct any prior
memory state by replaying operations from the root commit.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class MemoryCommit:
    """An immutable record of memory operations at a point in time.

    Attributes:
        id: SHA-256 hash uniquely identifying this commit.
        parent_id: ID of the parent commit (``None`` for the root).
        message: Human-readable commit message.
        operations: List of dicts describing what changed (each must have
            at minimum ``"op"`` and ``"key"`` fields).
        timestamp: When the commit was created.
        author: Who (or what agent) authored the commit.
        snapshot_hash: SHA-256 of the cumulative state after this commit.
    """

    id: str
    parent_id: str | None
    message: str
    operations: list[dict[str, Any]]
    timestamp: datetime
    author: str
    snapshot_hash: str


@dataclass
class MemoryBranch:
    """A named pointer to a commit, analogous to a Git branch.

    Attributes:
        name: Branch name.
        head_commit_id: The commit this branch currently points to.
        created_at: When the branch was created.
        metadata: Arbitrary metadata (e.g. purpose, hypothesis description).
    """

    name: str
    head_commit_id: str
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Hashing helpers
# ---------------------------------------------------------------------------


def _sha256(data: str) -> str:
    """Return the hex SHA-256 digest of *data*."""
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _commit_hash(
    parent_id: str | None, operations: list[dict[str, Any]], timestamp: datetime
) -> str:
    """Derive a deterministic commit ID from its content."""
    payload = json.dumps(
        {"parent": parent_id, "ops": operations, "ts": timestamp.isoformat()},
        sort_keys=True,
        default=str,
    )
    return _sha256(payload)


def _snapshot_hash(state: dict[str, Any]) -> str:
    """Derive a hash over the full reconstructed state."""
    payload = json.dumps(state, sort_keys=True, default=str)
    return _sha256(payload)


# ---------------------------------------------------------------------------
# Version control
# ---------------------------------------------------------------------------


class MemoryVersionControl:
    """Git-like version control for memory state.

    Supports commits, branches, tags, log traversal, diff, merge, and
    point-in-time reconstruction via ``checkout``.
    """

    def __init__(self) -> None:
        # commit_id -> MemoryCommit
        self._commits: dict[str, MemoryCommit] = {}
        # branch_name -> MemoryBranch
        self._branches: dict[str, MemoryBranch] = {}
        # tag_name -> commit_id
        self._tags: dict[str, str] = {}
        # Active branch name.
        self._current_branch: str = "main"

        # Bootstrap with an empty main branch pointing at a root commit.
        root_ops: list[dict[str, Any]] = [{"op": "init", "key": "__root__"}]
        now = datetime.now(tz=UTC)
        root_id = _commit_hash(None, root_ops, now)
        root_snap = _snapshot_hash({})
        root_commit = MemoryCommit(
            id=root_id,
            parent_id=None,
            message="Initial commit",
            operations=root_ops,
            timestamp=now,
            author="system",
            snapshot_hash=root_snap,
        )
        self._commits[root_id] = root_commit
        self._branches["main"] = MemoryBranch(
            name="main",
            head_commit_id=root_id,
            created_at=now,
        )

    # -- commit --------------------------------------------------------------

    def commit(
        self,
        operations: list[dict[str, Any]],
        message: str,
        author: str = "system",
    ) -> MemoryCommit:
        """Create a new commit on the current branch.

        Each operation dict should have at minimum ``"op"`` (the operation
        name) and ``"key"`` (the affected memory key).

        Args:
            operations: List of operation dicts.
            message: Commit message.
            author: Author identifier.

        Returns:
            The newly created :class:`MemoryCommit`.
        """
        branch = self._branches[self._current_branch]
        parent_id = branch.head_commit_id
        now = datetime.now(tz=UTC)

        commit_id = _commit_hash(parent_id, operations, now)

        # Compute snapshot hash by replaying from root.
        state = self._replay_to(parent_id)
        self._apply_ops(state, operations)
        snap_hash = _snapshot_hash(state)

        new_commit = MemoryCommit(
            id=commit_id,
            parent_id=parent_id,
            message=message,
            operations=operations,
            timestamp=now,
            author=author,
            snapshot_hash=snap_hash,
        )
        self._commits[commit_id] = new_commit

        # Advance branch head.
        branch.head_commit_id = commit_id
        return new_commit

    # -- checkout (reconstruction) -------------------------------------------

    def checkout(self, commit_id: str) -> dict[str, Any]:
        """Reconstruct the memory state at a specific commit.

        Replays all operations from the root commit up to and including
        *commit_id*.

        Args:
            commit_id: The commit to reconstruct.

        Returns:
            A dict mapping memory keys to their values at that point.

        Raises:
            KeyError: If the commit does not exist.
        """
        if commit_id not in self._commits:
            raise KeyError(f"Commit {commit_id!r} not found")
        return self._replay_to(commit_id)

    # -- branching -----------------------------------------------------------

    def branch(
        self,
        name: str,
        from_commit_id: str | None = None,
    ) -> MemoryBranch:
        """Create a new branch.

        Args:
            name: Branch name.
            from_commit_id: Commit to branch from.  Defaults to the
                current branch's HEAD.

        Returns:
            The newly created :class:`MemoryBranch`.

        Raises:
            ValueError: If a branch with *name* already exists.
            KeyError: If *from_commit_id* does not exist.
        """
        if name in self._branches:
            raise ValueError(f"Branch {name!r} already exists")

        if from_commit_id is None:
            from_commit_id = self._branches[self._current_branch].head_commit_id
        if from_commit_id not in self._commits:
            raise KeyError(f"Commit {from_commit_id!r} not found")

        new_branch = MemoryBranch(
            name=name,
            head_commit_id=from_commit_id,
        )
        self._branches[name] = new_branch
        return new_branch

    def switch_branch(self, name: str) -> None:
        """Switch the active branch.

        Args:
            name: Branch name to switch to.

        Raises:
            KeyError: If the branch does not exist.
        """
        if name not in self._branches:
            raise KeyError(f"Branch {name!r} not found")
        self._current_branch = name

    def current_branch(self) -> str:
        """Return the name of the currently active branch."""
        return self._current_branch

    # -- merge ---------------------------------------------------------------

    def merge(
        self,
        source_branch: str,
        target_branch: str,
        strategy: str = "latest",
    ) -> MemoryCommit:
        """Merge *source_branch* into *target_branch*.

        Conflict resolution strategies:

        * ``"latest"`` -- on conflict, the more recent operation wins.
        * ``"source_wins"`` -- source branch values take precedence.
        * ``"target_wins"`` -- target branch values take precedence.

        Args:
            source_branch: Name of the branch to merge from.
            target_branch: Name of the branch to merge into.
            strategy: Conflict resolution strategy.

        Returns:
            A new merge :class:`MemoryCommit` on the target branch.

        Raises:
            KeyError: If either branch does not exist.
            ValueError: If the strategy is unknown.
        """
        if source_branch not in self._branches:
            raise KeyError(f"Branch {source_branch!r} not found")
        if target_branch not in self._branches:
            raise KeyError(f"Branch {target_branch!r} not found")
        if strategy not in ("latest", "source_wins", "target_wins"):
            raise ValueError(f"Unknown merge strategy: {strategy!r}")

        src_head = self._branches[source_branch].head_commit_id
        tgt_head = self._branches[target_branch].head_commit_id

        src_state = self._replay_to(src_head)
        tgt_state = self._replay_to(tgt_head)

        # Merge states.
        merged = dict(tgt_state)  # start with target
        all_keys = set(src_state.keys()) | set(tgt_state.keys())

        for key in all_keys:
            in_src = key in src_state
            in_tgt = key in tgt_state

            if in_src and not in_tgt:
                merged[key] = src_state[key]
            elif in_src and in_tgt and src_state[key] != tgt_state[key]:
                # Conflict.
                if strategy == "source_wins":
                    merged[key] = src_state[key]
                elif strategy == "target_wins":
                    merged[key] = tgt_state[key]
                else:  # latest
                    # Use source (it's the "newer" change being merged in).
                    merged[key] = src_state[key]

        # Determine the operations needed to go from tgt_state -> merged.
        merge_ops: list[dict[str, Any]] = []
        for key in all_keys:
            if key not in tgt_state and key in merged:
                merge_ops.append({"op": "store", "key": key, "value": merged[key]})
            elif key in tgt_state and key in merged and tgt_state[key] != merged[key]:
                merge_ops.append({"op": "update", "key": key, "value": merged[key]})
            elif key in tgt_state and key not in merged:
                merge_ops.append({"op": "forget", "key": key})

        if not merge_ops:
            merge_ops = [{"op": "noop", "key": "__merge__", "note": "no conflicts"}]

        # Save current branch, switch to target, commit, then restore.
        old_branch = self._current_branch
        self._current_branch = target_branch

        merge_commit = self.commit(
            operations=merge_ops,
            message=f"Merge {source_branch} into {target_branch} (strategy={strategy})",
            author="system",
        )

        self._current_branch = old_branch
        return merge_commit

    # -- log -----------------------------------------------------------------

    def log(
        self,
        branch_name: str = "main",
        limit: int = 50,
    ) -> list[MemoryCommit]:
        """Return the commit history for a branch, newest first.

        Args:
            branch_name: Branch to traverse.
            limit: Maximum commits to return.

        Returns:
            List of :class:`MemoryCommit` instances.

        Raises:
            KeyError: If the branch does not exist.
        """
        if branch_name not in self._branches:
            raise KeyError(f"Branch {branch_name!r} not found")

        commits: list[MemoryCommit] = []
        current_id: str | None = self._branches[branch_name].head_commit_id
        while current_id is not None and len(commits) < limit:
            commit = self._commits.get(current_id)
            if commit is None:
                break
            commits.append(commit)
            current_id = commit.parent_id

        return commits

    # -- diff ----------------------------------------------------------------

    def diff(self, commit_a: str, commit_b: str) -> dict[str, Any]:
        """Compute the diff between two commits.

        Args:
            commit_a: First commit ID (the "before" state).
            commit_b: Second commit ID (the "after" state).

        Returns:
            Dict with keys ``added`` (keys in B but not A), ``removed``
            (keys in A but not B), ``changed`` (keys in both but with
            different values).

        Raises:
            KeyError: If either commit does not exist.
        """
        state_a = self.checkout(commit_a)
        state_b = self.checkout(commit_b)

        all_keys = set(state_a.keys()) | set(state_b.keys())

        added: dict[str, Any] = {}
        removed: dict[str, Any] = {}
        changed: dict[str, dict[str, Any]] = {}

        for key in all_keys:
            in_a = key in state_a
            in_b = key in state_b

            if in_b and not in_a:
                added[key] = state_b[key]
            elif in_a and not in_b:
                removed[key] = state_a[key]
            elif in_a and in_b and state_a[key] != state_b[key]:
                changed[key] = {"before": state_a[key], "after": state_b[key]}

        return {"added": added, "removed": removed, "changed": changed}

    # -- tags ----------------------------------------------------------------

    def tag(self, commit_id: str, tag_name: str) -> None:
        """Tag a commit with a human-readable name.

        Args:
            commit_id: The commit to tag.
            tag_name: The tag name (e.g. ``"pre-training"``).

        Raises:
            KeyError: If the commit does not exist.
            ValueError: If the tag already exists.
        """
        if commit_id not in self._commits:
            raise KeyError(f"Commit {commit_id!r} not found")
        if tag_name in self._tags:
            raise ValueError(f"Tag {tag_name!r} already exists")
        self._tags[tag_name] = commit_id

    def tags(self) -> dict[str, str]:
        """Return all tags as ``{tag_name: commit_id}``.

        Returns:
            Mapping from tag names to commit IDs.
        """
        return dict(self._tags)

    # -- summary -------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return an overview of the version-control state.

        Returns:
            Dict with commit count, branch names, tag count, and
            current branch.
        """
        return {
            "total_commits": len(self._commits),
            "branches": list(self._branches.keys()),
            "tags": len(self._tags),
            "current_branch": self._current_branch,
        }

    # -- internal replay engine ----------------------------------------------

    def _ancestry(self, commit_id: str) -> list[str]:
        """Return the ancestry chain from root to *commit_id* (inclusive)."""
        chain: list[str] = []
        current: str | None = commit_id
        while current is not None:
            chain.append(current)
            commit = self._commits.get(current)
            if commit is None:
                break
            current = commit.parent_id
        chain.reverse()
        return chain

    def _replay_to(self, commit_id: str) -> dict[str, Any]:
        """Replay all operations from root to *commit_id* and return state."""
        chain = self._ancestry(commit_id)
        state: dict[str, Any] = {}
        for cid in chain:
            commit = self._commits.get(cid)
            if commit is None:
                continue
            self._apply_ops(state, commit.operations)
        return state

    @staticmethod
    def _apply_ops(state: dict[str, Any], operations: list[dict[str, Any]]) -> None:
        """Apply a list of operations to *state* in-place."""
        for op in operations:
            kind = op.get("op", "")
            key = op.get("key", "")

            if kind in ("store", "update"):
                state[key] = op.get("value")
            elif kind == "forget":
                state.pop(key, None)
            # "init", "noop", and unknown ops are silently ignored.
