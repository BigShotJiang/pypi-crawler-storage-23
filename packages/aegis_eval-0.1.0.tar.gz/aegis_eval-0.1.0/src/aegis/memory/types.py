"""Memory module types and protocols.

Defines the :class:`MemoryEntry` data model and the :class:`MemoryStore`
protocol that all memory backends must implement.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field

from aegis.core.types import MemoryTier, TemporalBounds


class MemoryEntry(BaseModel):
    """A single entry in the Aegis memory store.

    Attributes:
        key: Unique identifier for this memory entry.
        value: The stored content (text, structured data, etc.).
        tier: Which memory tier this entry resides in.
        confidence: Confidence score in the range [0.0, 1.0].
        provenance: Source attribution metadata.
        temporal_bounds: Optional time-validity window.
        tags: Free-form tags for categorisation and retrieval.
        created_at: Timestamp of initial storage.
        updated_at: Timestamp of last update.
        access_count: Number of times this entry has been retrieved.
        metadata: Additional arbitrary metadata.
    """

    key: str
    value: Any
    tier: MemoryTier = MemoryTier.WORKING
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)
    provenance: dict[str, Any] = Field(default_factory=dict)
    temporal_bounds: TemporalBounds | None = None
    tags: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    access_count: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


@runtime_checkable
class MemoryStore(Protocol):
    """Protocol that all memory store backends must satisfy.

    Implementations include in-memory stores (for testing), Redis-backed
    stores, and persistent vector stores.
    """

    def store(self, entry: MemoryEntry) -> None:
        """Persist a memory entry.

        Args:
            entry: The :class:`MemoryEntry` to store.
        """
        ...

    def retrieve(self, key: str) -> MemoryEntry | None:
        """Retrieve a memory entry by key.

        Args:
            key: The unique key of the entry to retrieve.

        Returns:
            The :class:`MemoryEntry` if found, otherwise ``None``.
        """
        ...

    def update(self, key: str, value: Any) -> bool:
        """Update the value of an existing memory entry.

        Args:
            key: The key of the entry to update.
            value: The new value to store.

        Returns:
            ``True`` if the entry was found and updated, ``False`` otherwise.
        """
        ...

    def delete(self, key: str) -> bool:
        """Delete a memory entry by key.

        Args:
            key: The key of the entry to delete.

        Returns:
            ``True`` if the entry was found and deleted, ``False`` otherwise.
        """
        ...

    def search(self, query: str, top_k: int = 10) -> list[MemoryEntry]:
        """Search for memory entries matching a query.

        Args:
            query: The search query string.
            top_k: Maximum number of results to return.

        Returns:
            A list of matching :class:`MemoryEntry` instances, ranked by
            relevance.
        """
        ...

    def list_by_tier(self, tier: MemoryTier) -> list[MemoryEntry]:
        """List all entries in a given memory tier.

        Args:
            tier: The :class:`MemoryTier` to filter by.

        Returns:
            All entries belonging to the specified tier.
        """
        ...
