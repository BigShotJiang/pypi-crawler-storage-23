"""In-memory store implementation for testing and development.

:class:`InMemoryStore` implements the :class:`MemoryStore` protocol using
a plain Python dictionary.  Not suitable for production workloads but
useful for unit tests, local development, and benchmarking.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from aegis.core.types import MemoryTier
from aegis.memory.types import MemoryEntry, MemoryStore


class InMemoryStore:
    """Dictionary-backed :class:`MemoryStore` implementation.

    All data is held in-process and lost on interpreter exit.  Thread
    safety is **not** guaranteed; wrap in a lock for concurrent access.
    """

    def __init__(self) -> None:
        self._entries: dict[str, MemoryEntry] = {}

    # -- MemoryStore protocol ------------------------------------------------

    def store(self, entry: MemoryEntry) -> None:
        """Persist a memory entry in the in-memory dictionary.

        Overwrites any existing entry with the same key.

        Args:
            entry: The :class:`MemoryEntry` to store.
        """
        self._entries[entry.key] = entry

    def retrieve(self, key: str) -> MemoryEntry | None:
        """Retrieve a memory entry by key.

        Increments the entry's ``access_count`` on successful retrieval.

        Args:
            key: The unique key of the entry to retrieve.

        Returns:
            The :class:`MemoryEntry` if found, otherwise ``None``.
        """
        entry = self._entries.get(key)
        if entry is not None:
            entry.access_count += 1
            entry.updated_at = datetime.now(tz=UTC)
        return entry

    def update(self, key: str, value: Any) -> bool:
        """Update the value of an existing memory entry.

        Args:
            key: The key of the entry to update.
            value: The new value to store.

        Returns:
            ``True`` if the entry existed and was updated, ``False`` otherwise.
        """
        entry = self._entries.get(key)
        if entry is None:
            return False
        entry.value = value
        entry.updated_at = datetime.now(tz=UTC)
        return True

    def delete(self, key: str) -> bool:
        """Delete a memory entry by key.

        Args:
            key: The key of the entry to delete.

        Returns:
            ``True`` if the entry existed and was deleted, ``False`` otherwise.
        """
        if key in self._entries:
            del self._entries[key]
            return True
        return False

    def search(self, query: str, top_k: int = 10) -> list[MemoryEntry]:
        """Naive substring search across entry values.

        For testing only. Production stores should use vector similarity
        or full-text search.

        Args:
            query: The search query string.
            top_k: Maximum number of results to return.

        Returns:
            Entries whose string-serialised value contains the query.
        """
        results: list[MemoryEntry] = []
        for entry in self._entries.values():
            if query.lower() in str(entry.value).lower():
                results.append(entry)
                if len(results) >= top_k:
                    break
        return results

    def list_by_tier(self, tier: MemoryTier) -> list[MemoryEntry]:
        """List all entries in a given memory tier.

        Args:
            tier: The :class:`MemoryTier` to filter by.

        Returns:
            All entries belonging to the specified tier.
        """
        return [e for e in self._entries.values() if e.tier == tier]

    # -- additional helpers --------------------------------------------------

    def count(self) -> int:
        """Return the total number of stored entries."""
        return len(self._entries)

    def clear(self) -> None:
        """Remove all entries from the store."""
        self._entries.clear()


# Runtime protocol check
assert isinstance(InMemoryStore, type)
_store_check: MemoryStore = InMemoryStore()
