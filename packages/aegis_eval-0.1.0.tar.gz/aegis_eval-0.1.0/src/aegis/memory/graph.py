"""In-memory knowledge graph for the Aegis memory subsystem.

Provides a directed graph with weighted, typed edges for representing
relationships between memory entries.  Supports bidirectional traversal,
shortest-path search, and neighbourhood extraction.
"""

from __future__ import annotations

from collections import defaultdict, deque
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field


class Edge(BaseModel):
    """A directed, weighted edge in the knowledge graph.

    Attributes:
        source: Identifier of the source node.
        target: Identifier of the target node.
        relation: Semantic label describing the relationship.
        weight: Edge weight in the range [0.0, 1.0].
        metadata: Additional arbitrary metadata for the edge.
        created_at: Timestamp of edge creation.
    """

    source: str
    target: str
    relation: str
    weight: float = Field(ge=0.0, le=1.0, default=1.0)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))


class KnowledgeGraph:
    """In-memory directed knowledge graph.

    Edges are stored in both forward (source -> [edges]) and reverse
    (target -> [edges]) adjacency lists so that bidirectional queries
    are efficient.

    All mutating methods automatically register referenced nodes.
    """

    def __init__(self) -> None:
        self._forward: dict[str, list[Edge]] = defaultdict(list)
        self._reverse: dict[str, list[Edge]] = defaultdict(list)
        self._nodes: set[str] = set()

    # -- node operations -----------------------------------------------------

    def add_node(self, node_id: str) -> None:
        """Register a node in the graph.

        Args:
            node_id: Unique identifier for the node.
        """
        self._nodes.add(node_id)

    def has_node(self, node_id: str) -> bool:
        """Check whether a node is registered.

        Args:
            node_id: Identifier to look up.

        Returns:
            ``True`` if the node exists in the graph.
        """
        return node_id in self._nodes

    # -- edge operations -----------------------------------------------------

    def add_edge(
        self,
        source: str,
        target: str,
        relation: str,
        weight: float = 1.0,
        metadata: dict[str, Any] | None = None,
    ) -> Edge:
        """Add a directed edge between two nodes.

        Both *source* and *target* are automatically registered as nodes
        if they are not already present.

        Args:
            source: Source node identifier.
            target: Target node identifier.
            relation: Semantic label for the edge.
            weight: Edge weight in [0.0, 1.0].
            metadata: Optional extra metadata.

        Returns:
            The newly created :class:`Edge`.
        """
        self.add_node(source)
        self.add_node(target)

        edge = Edge(
            source=source,
            target=target,
            relation=relation,
            weight=weight,
            metadata=metadata or {},
        )
        self._forward[source].append(edge)
        self._reverse[target].append(edge)
        return edge

    def remove_edge(
        self,
        source: str,
        target: str,
        relation: str | None = None,
    ) -> bool:
        """Remove edges between *source* and *target*.

        If *relation* is ``None``, all edges between the pair are removed.
        Otherwise only edges with the matching relation are removed.

        Args:
            source: Source node identifier.
            target: Target node identifier.
            relation: Optional relation filter.

        Returns:
            ``True`` if at least one edge was removed.
        """
        removed = False

        def _matches(edge: Edge) -> bool:
            if edge.source != source or edge.target != target:
                return False
            return not (relation is not None and edge.relation != relation)

        original_fwd = self._forward.get(source, [])
        filtered_fwd = [e for e in original_fwd if not _matches(e)]
        if len(filtered_fwd) != len(original_fwd):
            removed = True
            self._forward[source] = filtered_fwd

        original_rev = self._reverse.get(target, [])
        filtered_rev = [e for e in original_rev if not _matches(e)]
        if len(filtered_rev) != len(original_rev):
            removed = True
            self._reverse[target] = filtered_rev

        return removed

    def has_edge(
        self,
        source: str,
        target: str,
        relation: str | None = None,
    ) -> bool:
        """Check whether an edge exists between *source* and *target*.

        Args:
            source: Source node identifier.
            target: Target node identifier.
            relation: Optional relation filter.

        Returns:
            ``True`` if a matching edge exists.
        """
        for edge in self._forward.get(source, []):
            if edge.target == target and (relation is None or edge.relation == relation):
                return True
        return False

    # -- traversal -----------------------------------------------------------

    def neighbors(
        self,
        node_id: str,
        relation: str | None = None,
        direction: str = "both",
    ) -> list[str]:
        """Return the neighbouring nodes of *node_id*.

        Args:
            node_id: The node whose neighbours to retrieve.
            relation: Optional relation filter.
            direction: ``"outgoing"`` for successors, ``"incoming"`` for
                predecessors, or ``"both"`` for the union.

        Returns:
            A deduplicated list of neighbouring node identifiers.
        """
        result: set[str] = set()

        if direction in ("outgoing", "both"):
            for edge in self._forward.get(node_id, []):
                if relation is None or edge.relation == relation:
                    result.add(edge.target)

        if direction in ("incoming", "both"):
            for edge in self._reverse.get(node_id, []):
                if relation is None or edge.relation == relation:
                    result.add(edge.source)

        return list(result)

    def edges(self, node_id: str, direction: str = "outgoing") -> list[Edge]:
        """Return all edges for a node in the given direction.

        Args:
            node_id: The node whose edges to retrieve.
            direction: ``"outgoing"`` for edges where *node_id* is the
                source, ``"incoming"`` for edges where it is the target.

        Returns:
            A list of :class:`Edge` instances.
        """
        if direction == "outgoing":
            return list(self._forward.get(node_id, []))
        if direction == "incoming":
            return list(self._reverse.get(node_id, []))
        return list(self._forward.get(node_id, [])) + list(self._reverse.get(node_id, []))

    # -- path finding --------------------------------------------------------

    def shortest_path(
        self,
        source: str,
        target: str,
        max_hops: int = 5,
    ) -> list[str] | None:
        """Find the shortest path between *source* and *target* using BFS.

        Args:
            source: Starting node.
            target: Destination node.
            max_hops: Maximum number of edges to traverse.

        Returns:
            An ordered list of node IDs forming the path (including both
            endpoints), or ``None`` if no path exists within *max_hops*.
        """
        if source not in self._nodes or target not in self._nodes:
            return None
        if source == target:
            return [source]

        visited: set[str] = {source}
        queue: deque[list[str]] = deque([[source]])

        while queue:
            path = queue.popleft()
            if len(path) - 1 >= max_hops:
                continue

            current = path[-1]
            for edge in self._forward.get(current, []):
                if edge.target in visited:
                    continue
                new_path = path + [edge.target]
                if edge.target == target:
                    return new_path
                visited.add(edge.target)
                queue.append(new_path)

        return None

    def all_paths(
        self,
        source: str,
        target: str,
        max_hops: int = 3,
    ) -> list[list[str]]:
        """Find all paths between *source* and *target* using DFS.

        Detects cycles to avoid infinite recursion.

        Args:
            source: Starting node.
            target: Destination node.
            max_hops: Maximum number of edges to traverse.

        Returns:
            A list of paths, where each path is an ordered list of node
            IDs (including both endpoints).
        """
        if source not in self._nodes or target not in self._nodes:
            return []

        results: list[list[str]] = []
        stack: list[tuple[str, list[str], set[str]]] = [
            (source, [source], {source}),
        ]

        while stack:
            current, path, visited = stack.pop()

            if current == target and len(path) > 1:
                results.append(path)
                continue

            if len(path) - 1 >= max_hops:
                continue

            for edge in self._forward.get(current, []):
                if edge.target not in visited:
                    stack.append(
                        (edge.target, path + [edge.target], visited | {edge.target}),
                    )

        return results

    # -- subgraph extraction -------------------------------------------------

    def subgraph(
        self,
        center: str,
        depth: int = 2,
    ) -> dict[str, list[Edge]]:
        """Extract the local subgraph around *center* up to *depth* hops.

        Uses BFS from *center*, following outgoing edges.

        Args:
            center: The central node of the subgraph.
            depth: Maximum number of hops from *center*.

        Returns:
            An adjacency dict mapping source node IDs to their outgoing
            edges within the subgraph.
        """
        if center not in self._nodes:
            return {}

        visited: set[str] = {center}
        queue: deque[tuple[str, int]] = deque([(center, 0)])
        result: dict[str, list[Edge]] = defaultdict(list)

        while queue:
            node, current_depth = queue.popleft()

            for edge in self._forward.get(node, []):
                result[node].append(edge)
                if edge.target not in visited and current_depth < depth:
                    visited.add(edge.target)
                    queue.append((edge.target, current_depth + 1))

        return dict(result)

    # -- statistics ----------------------------------------------------------

    def node_count(self) -> int:
        """Return the number of registered nodes."""
        return len(self._nodes)

    def edge_count(self) -> int:
        """Return the total number of edges in the graph."""
        return sum(len(edges) for edges in self._forward.values())

    # -- housekeeping --------------------------------------------------------

    def clear(self) -> None:
        """Remove all nodes and edges from the graph."""
        self._forward.clear()
        self._reverse.clear()
        self._nodes.clear()
