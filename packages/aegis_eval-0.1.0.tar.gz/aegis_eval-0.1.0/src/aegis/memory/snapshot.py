"""Point-in-time memory state reconstruction.

Replays the :class:`~aegis.memory.event_log.EventLog` up to a given
timestamp and rebuilds the full memory state -- entries, tier counts,
and graph edges -- as they would have appeared at that moment.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from aegis.core.types import MemoryEventV1, MemoryOperation
from aegis.memory.event_log import EventLog
from aegis.memory.graph import Edge
from aegis.memory.types import MemoryEntry


class MemorySnapshotData(BaseModel):
    """A frozen snapshot of the memory subsystem at a point in time.

    Attributes:
        timestamp: The point in time this snapshot represents.
        entries: All live memory entries keyed by their entry key.
        tier_counts: Number of entries in each :class:`MemoryTier`.
        total_entries: Total number of live entries.
        graph_edges: Knowledge-graph edges that existed at *timestamp*.
    """

    timestamp: datetime
    entries: dict[str, MemoryEntry] = Field(default_factory=dict)
    tier_counts: dict[str, int] = Field(default_factory=dict)
    total_entries: int = 0
    graph_edges: list[Edge] = Field(default_factory=list)


class SnapshotReconstructor:
    """Rebuilds memory state by replaying events from an :class:`EventLog`.

    The reconstructor processes every event between the epoch and the
    requested timestamp, applying each operation in order to derive the
    entries, edges, and tier distribution that would have existed at that
    instant.

    Args:
        event_log: The :class:`EventLog` to replay events from.
    """

    def __init__(self, event_log: EventLog) -> None:
        self._event_log = event_log

    # -- public API ----------------------------------------------------------

    def reconstruct_at(self, timestamp: datetime) -> MemorySnapshotData:
        """Reconstruct the memory state as it existed at *timestamp*.

        Replays all events from the beginning of time through *timestamp*
        (inclusive) and applies each operation to build up the entries dict
        and edges list.

        Args:
            timestamp: The point in time to reconstruct.

        Returns:
            A :class:`MemorySnapshotData` containing the reconstructed
            state.
        """
        events = self._event_log.replay_range(datetime(1970, 1, 1, tzinfo=UTC), timestamp)

        entries: dict[str, MemoryEntry] = {}
        edges: list[Edge] = []

        for event in events:
            self._apply_event(event, entries, edges)

        tier_counts = self._compute_tier_counts(entries)

        return MemorySnapshotData(
            timestamp=timestamp,
            entries=entries,
            tier_counts=tier_counts,
            total_entries=len(entries),
            graph_edges=edges,
        )

    # -- internal event application ------------------------------------------

    def _apply_event(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
        edges: list[Edge],
    ) -> None:
        """Apply a single event to the in-progress state.

        Args:
            event: The event to apply.
            entries: The mutable entries dict being built up.
            edges: The mutable edges list being built up.
        """
        op = event.operation

        if op == MemoryOperation.STORE:
            self._apply_store(event, entries)
        elif op == MemoryOperation.UPDATE:
            self._apply_update(event, entries)
        elif op == MemoryOperation.FORGET:
            self._apply_forget(event, entries)
        elif op == MemoryOperation.RETRIEVE:
            self._apply_retrieve(event, entries)
        elif op == MemoryOperation.LINK:
            self._apply_link(event, edges)
        elif op == MemoryOperation.COMPRESS:
            self._apply_compress(event, entries)
        elif op == MemoryOperation.PROMOTE:
            self._apply_promote(event, entries)
        elif op == MemoryOperation.DEMOTE:
            self._apply_demote(event, entries)
        elif op == MemoryOperation.SPLIT:
            self._apply_split(event, entries)
        elif op == MemoryOperation.MERGE:
            self._apply_merge(event, entries)
        elif op == MemoryOperation.VERIFY:
            self._apply_verify(event, entries)
        elif op == MemoryOperation.ANNOTATE:
            self._apply_annotate(event, entries)

    # -- per-operation handlers ----------------------------------------------

    def _apply_store(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Create a new memory entry from a STORE event."""
        entries[event.key] = MemoryEntry(
            key=event.key,
            value=event.value,
            tier=event.memory_tier,
            confidence=event.confidence,
            provenance=event.provenance,
            temporal_bounds=event.temporal_bounds,
            created_at=event.timestamp,
            updated_at=event.timestamp,
        )

    def _apply_update(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Update an existing entry's value and optionally its confidence."""
        entry = entries.get(event.key)
        if entry is None:
            return
        entry.value = event.value
        entry.updated_at = event.timestamp
        if event.confidence is not None:
            entry.confidence = event.confidence

    def _apply_forget(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Remove an entry from the state."""
        entries.pop(event.key, None)

    def _apply_retrieve(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Increment the access count of an entry."""
        entry = entries.get(event.key)
        if entry is not None:
            entry.access_count += 1

    def _apply_link(
        self,
        event: MemoryEventV1,
        edges: list[Edge],
    ) -> None:
        """Create a graph edge from a LINK event."""
        target_key = event.metadata.get("target_key", "")
        relation = event.metadata.get("relation", "related")
        edge = Edge(
            source=event.key,
            target=target_key,
            relation=relation,
            created_at=event.timestamp,
        )
        edges.append(edge)

    def _apply_compress(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Replace entry value with compressed version and mark metadata."""
        entry = entries.get(event.key)
        if entry is None:
            return
        entry.value = event.value
        entry.metadata["compressed"] = True
        entry.updated_at = event.timestamp

    def _apply_promote(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Change an entry's tier to the promoted tier."""
        entry = entries.get(event.key)
        if entry is not None:
            entry.tier = event.memory_tier
            entry.updated_at = event.timestamp

    def _apply_demote(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Change an entry's tier to the demoted tier."""
        entry = entries.get(event.key)
        if entry is not None:
            entry.tier = event.memory_tier
            entry.updated_at = event.timestamp

    def _apply_split(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Remove the original entry and add split parts.

        Parts are expected in ``event.metadata["parts"]`` as a list of
        dicts, each containing at least ``"key"`` and ``"value"``.
        """
        entries.pop(event.key, None)

        parts: list[dict[str, Any]] = event.metadata.get("parts", [])
        for part in parts:
            part_key = part.get("key", "")
            part_value = part.get("value", "")
            entries[part_key] = MemoryEntry(
                key=part_key,
                value=part_value,
                tier=event.memory_tier,
                confidence=event.confidence,
                provenance=event.provenance,
                temporal_bounds=event.temporal_bounds,
                created_at=event.timestamp,
                updated_at=event.timestamp,
            )

    def _apply_merge(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Remove source entries and add the merged entry.

        Source keys are expected in ``event.metadata["merge_sources"]``.
        """
        merge_sources: list[str] = event.metadata.get("merge_sources", [])
        for source_key in merge_sources:
            entries.pop(source_key, None)

        entries[event.key] = MemoryEntry(
            key=event.key,
            value=event.value,
            tier=event.memory_tier,
            confidence=event.confidence,
            provenance=event.provenance,
            temporal_bounds=event.temporal_bounds,
            created_at=event.timestamp,
            updated_at=event.timestamp,
            metadata={"merge_sources": merge_sources},
        )

    def _apply_verify(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Update entry metadata with verification information."""
        entry = entries.get(event.key)
        if entry is not None:
            entry.metadata["verified"] = True
            entry.metadata.update(event.metadata)
            entry.updated_at = event.timestamp

    def _apply_annotate(
        self,
        event: MemoryEventV1,
        entries: dict[str, MemoryEntry],
    ) -> None:
        """Add annotation to entry metadata."""
        entry = entries.get(event.key)
        if entry is not None:
            entry.metadata.setdefault("annotations", []).append(event.metadata)
            entry.updated_at = event.timestamp

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _compute_tier_counts(entries: dict[str, MemoryEntry]) -> dict[str, int]:
        """Compute the number of entries in each memory tier.

        Args:
            entries: The current entries dict.

        Returns:
            A mapping from tier value strings to entry counts.
        """
        counts: dict[str, int] = {}
        for entry in entries.values():
            tier_value = entry.tier.value
            counts[tier_value] = counts.get(tier_value, 0) + 1
        return counts
