"""Multi-agent shared memory protocol.

Provides agent registration, shared namespaces with access control,
relevance-filtered sharing, conflict resolution (latest, highest-confidence,
consensus, trust-weighted), and trust management.
"""

from __future__ import annotations

import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from aegis.core.types import MemoryOperation

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class AgentProfile:
    """Profile describing a participating agent.

    Attributes:
        agent_id: Unique identifier.
        name: Human-readable name.
        domain: Primary domain of expertise.
        trust_score: Trust score in [0.0, 1.0].
        capabilities: List of capability tags.
        metadata: Additional metadata.
    """

    agent_id: str
    name: str
    domain: str = "general"
    trust_score: float = 0.5
    capabilities: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SharedMemoryNamespace:
    """A shared namespace scoping memory visibility among agents.

    Attributes:
        namespace_id: Unique identifier.
        name: Human-readable namespace label.
        agents: List of agent IDs with access.
        access_policy: One of ``"read_write"``, ``"read_only"``,
            ``"write_only"``.
        created_at: Creation timestamp.
    """

    namespace_id: str
    name: str
    agents: list[str] = field(default_factory=list)
    access_policy: str = "read_write"  # "read_write" | "read_only" | "write_only"
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


@dataclass
class ShareEvent:
    """Record of a single memory-share action.

    Attributes:
        from_agent: ID of the agent that initiated the share.
        to_namespace: Namespace the memory was shared into.
        key: Key of the memory entry.
        operation: The memory operation being shared.
        timestamp: When the share occurred.
        accepted: Whether the share was accepted (passes policy + relevance).
    """

    from_agent: str
    to_namespace: str
    key: str
    operation: MemoryOperation
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    accepted: bool = True


# ---------------------------------------------------------------------------
# Multi-agent memory
# ---------------------------------------------------------------------------


class MultiAgentMemory:
    """Coordination layer for shared memory across multiple agents.

    Manages agent profiles, shared namespaces, access policies,
    relevance-filtered sharing, conflict resolution, and trust updates.
    """

    def __init__(self) -> None:
        self._agents: dict[str, AgentProfile] = {}
        self._namespaces: dict[str, SharedMemoryNamespace] = {}
        # namespace_id -> list of (key, value, metadata-dict) tuples.
        self._namespace_entries: dict[str, list[dict[str, Any]]] = {}
        self._share_history: dict[str, list[ShareEvent]] = {}

    # -- agent management ----------------------------------------------------

    def register_agent(self, profile: AgentProfile) -> None:
        """Register an agent.

        Args:
            profile: The :class:`AgentProfile` to register.

        Raises:
            ValueError: If an agent with the same ID is already registered.
        """
        if profile.agent_id in self._agents:
            raise ValueError(f"Agent {profile.agent_id!r} already registered")
        self._agents[profile.agent_id] = profile

    # -- namespace management ------------------------------------------------

    def create_namespace(
        self,
        name: str,
        agents: list[str],
        access_policy: str = "read_write",
    ) -> SharedMemoryNamespace:
        """Create a shared namespace.

        Args:
            name: Namespace label.
            agents: List of agent IDs that should have access.
            access_policy: One of ``"read_write"``, ``"read_only"``,
                ``"write_only"``.

        Returns:
            The newly created :class:`SharedMemoryNamespace`.

        Raises:
            ValueError: If any agent in *agents* is not registered, or if
                the access policy is invalid.
        """
        valid_policies = {"read_write", "read_only", "write_only"}
        if access_policy not in valid_policies:
            raise ValueError(
                f"Invalid access_policy {access_policy!r}; must be one of {valid_policies}"
            )
        for aid in agents:
            if aid not in self._agents:
                raise ValueError(f"Agent {aid!r} is not registered")

        ns = SharedMemoryNamespace(
            namespace_id=str(uuid.uuid4()),
            name=name,
            agents=list(agents),
            access_policy=access_policy,
        )
        self._namespaces[ns.namespace_id] = ns
        self._namespace_entries[ns.namespace_id] = []
        self._share_history[ns.namespace_id] = []
        return ns

    def get_namespace(self, namespace_id: str) -> SharedMemoryNamespace | None:
        """Retrieve a namespace by ID."""
        return self._namespaces.get(namespace_id)

    def agent_namespaces(self, agent_id: str) -> list[SharedMemoryNamespace]:
        """Return all namespaces an agent belongs to.

        Args:
            agent_id: The agent to look up.

        Returns:
            List of :class:`SharedMemoryNamespace` instances.
        """
        return [ns for ns in self._namespaces.values() if agent_id in ns.agents]

    # -- sharing -------------------------------------------------------------

    def share(
        self,
        from_agent: str,
        namespace_id: str,
        key: str,
        value: Any,
        operation: MemoryOperation = MemoryOperation.STORE,
    ) -> ShareEvent:
        """Share a memory entry into a namespace.

        Checks that the agent belongs to the namespace and the namespace's
        access policy permits writes.  Applies a basic relevance filter:
        empty or trivially short values are rejected.

        Args:
            from_agent: ID of the sharing agent.
            namespace_id: Target namespace.
            key: Memory entry key.
            value: Memory entry value.
            operation: The memory operation being shared.

        Returns:
            A :class:`ShareEvent` recording the outcome.

        Raises:
            KeyError: If the namespace does not exist.
            PermissionError: If the agent is not in the namespace or the
                policy forbids writes.
        """
        ns = self._namespaces.get(namespace_id)
        if ns is None:
            raise KeyError(f"Namespace {namespace_id!r} not found")

        # Access checks.
        if from_agent not in ns.agents:
            raise PermissionError(
                f"Agent {from_agent!r} is not a member of namespace {namespace_id!r}"
            )
        if ns.access_policy == "read_only":
            event = ShareEvent(
                from_agent=from_agent,
                to_namespace=namespace_id,
                key=key,
                operation=operation,
                accepted=False,
            )
            self._share_history.setdefault(namespace_id, []).append(event)
            return event

        # Relevance filter: reject trivially empty content.
        accepted = self._relevance_check(key, value)

        if accepted:
            entry_record: dict[str, Any] = {
                "key": key,
                "value": value,
                "from_agent": from_agent,
                "operation": operation.value,
                "timestamp": datetime.now(tz=UTC),
                "confidence": self._agents[from_agent].trust_score
                if from_agent in self._agents
                else 0.5,
            }
            self._namespace_entries.setdefault(namespace_id, []).append(entry_record)

        event = ShareEvent(
            from_agent=from_agent,
            to_namespace=namespace_id,
            key=key,
            operation=operation,
            accepted=accepted,
        )
        self._share_history.setdefault(namespace_id, []).append(event)
        return event

    # -- retrieval -----------------------------------------------------------

    def retrieve_shared(
        self,
        agent_id: str,
        namespace_id: str,
        query: str | None = None,
    ) -> list[dict[str, Any]]:
        """Retrieve entries from a shared namespace.

        Optionally filters by a simple substring query on key and value.

        Args:
            agent_id: The requesting agent.
            namespace_id: Namespace to search.
            query: Optional substring query.

        Returns:
            List of matching entry dicts with keys ``key``, ``value``,
            ``from_agent``, ``timestamp``, ``confidence``.

        Raises:
            KeyError: If the namespace does not exist.
            PermissionError: If the agent cannot read from this namespace.
        """
        ns = self._namespaces.get(namespace_id)
        if ns is None:
            raise KeyError(f"Namespace {namespace_id!r} not found")
        if agent_id not in ns.agents:
            raise PermissionError(
                f"Agent {agent_id!r} is not a member of namespace {namespace_id!r}"
            )
        if ns.access_policy == "write_only":
            raise PermissionError(f"Namespace {namespace_id!r} is write-only; reads are forbidden")

        entries = self._namespace_entries.get(namespace_id, [])
        if query is None:
            return list(entries)

        q_lower = query.lower()
        return [
            e
            for e in entries
            if q_lower in str(e.get("key", "")).lower()
            or q_lower in str(e.get("value", "")).lower()
        ]

    # -- conflict resolution -------------------------------------------------

    def resolve_conflict(
        self,
        entries: list[dict[str, Any]],
        strategy: str = "latest",
    ) -> Any:
        """Resolve conflicting information from multiple agents.

        Strategies:

        * ``"latest"`` -- most recent entry wins.
        * ``"highest_confidence"`` -- entry with highest confidence wins.
        * ``"consensus"`` -- majority value wins (if tie, falls back to latest).
        * ``"trust_weighted"`` -- weighted average of confidences, highest
          trust-score entry wins.

        Args:
            entries: List of entry dicts.  Each should have at minimum
                ``value``, ``timestamp``, ``confidence``, and ``from_agent``.
            strategy: Resolution strategy name.

        Returns:
            The winning value.

        Raises:
            ValueError: If *entries* is empty or strategy is unknown.
        """
        if not entries:
            raise ValueError("Cannot resolve conflict with no entries")

        if strategy == "latest":
            return self._resolve_latest(entries)
        if strategy == "highest_confidence":
            return self._resolve_highest_confidence(entries)
        if strategy == "consensus":
            return self._resolve_consensus(entries)
        if strategy == "trust_weighted":
            return self._resolve_trust_weighted(entries)

        raise ValueError(f"Unknown conflict resolution strategy: {strategy!r}")

    # -- trust management ----------------------------------------------------

    def update_trust(self, agent_id: str, delta: float) -> None:
        """Adjust an agent's trust score.

        The score is clamped to [0.0, 1.0].

        Args:
            agent_id: The agent to update.
            delta: Amount to add (positive) or subtract (negative).

        Raises:
            KeyError: If the agent is not registered.
        """
        if agent_id not in self._agents:
            raise KeyError(f"Agent {agent_id!r} is not registered")
        agent = self._agents[agent_id]
        agent.trust_score = max(0.0, min(1.0, agent.trust_score + delta))

    # -- history & summary ---------------------------------------------------

    def share_history(
        self,
        namespace_id: str,
        limit: int = 50,
    ) -> list[ShareEvent]:
        """Return the sharing history for a namespace.

        Args:
            namespace_id: The namespace to query.
            limit: Maximum number of events to return (most recent first).

        Returns:
            List of :class:`ShareEvent` instances.
        """
        events = self._share_history.get(namespace_id, [])
        return list(reversed(events[-limit:]))

    def summary(self) -> dict[str, Any]:
        """Return an overview of the multi-agent memory state.

        Returns:
            Dict with counts of agents, namespaces, total shared entries,
            and total share events.
        """
        total_entries = sum(len(v) for v in self._namespace_entries.values())
        total_events = sum(len(v) for v in self._share_history.values())
        return {
            "agents": len(self._agents),
            "namespaces": len(self._namespaces),
            "total_shared_entries": total_entries,
            "total_share_events": total_events,
            "agent_ids": list(self._agents.keys()),
            "namespace_ids": list(self._namespaces.keys()),
        }

    # -- internal helpers ----------------------------------------------------

    @staticmethod
    def _relevance_check(key: str, value: Any) -> bool:
        """Basic relevance gate: reject trivially empty content."""
        if value is None:
            return False
        val_str = str(value).strip()
        if len(val_str) == 0:
            return False
        # Reject extremely short values that carry no information.
        return not (len(val_str) < 2 and len(str(key).strip()) < 2)

    @staticmethod
    def _resolve_latest(entries: list[dict[str, Any]]) -> Any:
        """Pick the most recent entry's value."""
        best = max(
            entries,
            key=lambda e: e.get("timestamp", datetime.min.replace(tzinfo=UTC)),
        )
        return best.get("value")

    @staticmethod
    def _resolve_highest_confidence(entries: list[dict[str, Any]]) -> Any:
        """Pick the entry with the highest confidence."""
        best = max(entries, key=lambda e: e.get("confidence", 0.0))
        return best.get("value")

    def _resolve_consensus(self, entries: list[dict[str, Any]]) -> Any:
        """Pick the value held by the majority of entries.

        On tie, fall back to the most recent entry.
        """
        # Stringify values for counting (handles unhashable types).
        value_strings: list[str] = [str(e.get("value", "")) for e in entries]
        counter = Counter(value_strings)
        most_common = counter.most_common()

        if len(most_common) >= 2 and most_common[0][1] == most_common[1][1]:
            # Tie -- fall back to latest.
            return self._resolve_latest(entries)

        winning_str = most_common[0][0]
        # Return the original value (not the stringified version).
        for entry in entries:
            if str(entry.get("value", "")) == winning_str:
                return entry.get("value")
        return entries[0].get("value")

    def _resolve_trust_weighted(self, entries: list[dict[str, Any]]) -> Any:
        """Pick the entry with the highest trust-weighted confidence.

        Score = confidence * trust_score.
        """

        def _score(entry: dict[str, Any]) -> float:
            conf = float(entry.get("confidence", 0.5))
            agent_id = entry.get("from_agent", "")
            agent = self._agents.get(agent_id)
            trust = agent.trust_score if agent else 0.5
            return conf * trust

        best = max(entries, key=_score)
        return best.get("value")
