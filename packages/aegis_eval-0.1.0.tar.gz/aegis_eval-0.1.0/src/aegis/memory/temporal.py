"""Temporal index with record supersession support.

The :class:`TemporalIndex` tracks :class:`TemporalRecord` entries ordered by
``valid_from`` timestamp, supporting point-in-time queries, version history,
and explicit supersession of one record by another.
"""

from __future__ import annotations

import bisect
from datetime import datetime

from pydantic import BaseModel


class TemporalRecord(BaseModel):
    """A temporally-bounded record in the index.

    Attributes:
        key: Unique identifier for this record.
        valid_from: Timestamp from which this record is valid.
        valid_to: Timestamp at which this record ceases to be valid, or
            ``None`` if the record is open-ended (still current).
        superseded_by: Key of the record that supersedes this one, or
            ``None`` if this record has not been superseded.
        version: Monotonically increasing version number for records
            sharing the same key.
    """

    key: str
    valid_from: datetime
    valid_to: datetime | None = None
    superseded_by: str | None = None
    version: int = 1


class TemporalIndex:
    """Sorted temporal index supporting point-in-time queries and supersession.

    Records are maintained in ascending ``valid_from`` order using
    :func:`bisect.insort` for efficient insertion.  Each key may have
    multiple versions; supersession explicitly links an old key to its
    replacement.

    Attributes:
        _records: All records sorted by ``valid_from``.
        _by_key: Mapping from key to all versions of that key's records.
    """

    def __init__(self) -> None:
        self._records: list[TemporalRecord] = []
        self._by_key: dict[str, list[TemporalRecord]] = {}

    def add(
        self,
        key: str,
        valid_from: datetime,
        valid_to: datetime | None = None,
    ) -> TemporalRecord:
        """Insert a new temporal record into the index.

        The record is inserted into :attr:`_records` in sorted order by
        ``valid_from`` using binary search.  If the key already exists,
        the version number is automatically incremented.

        Args:
            key: Unique identifier for the record.
            valid_from: Start of the validity window.
            valid_to: End of the validity window, or ``None`` for open-ended.

        Returns:
            The newly created :class:`TemporalRecord`.
        """
        existing = self._by_key.get(key, [])
        version = len(existing) + 1

        record = TemporalRecord(
            key=key,
            valid_from=valid_from,
            valid_to=valid_to,
            version=version,
        )

        # Use bisect to find the correct insertion position based on valid_from.
        # We extract the insertion point manually since bisect.insort does not
        # accept a key function on all supported Python versions.
        timestamps = [r.valid_from for r in self._records]
        pos = bisect.bisect_right(timestamps, valid_from)
        self._records.insert(pos, record)

        self._by_key.setdefault(key, []).append(record)

        return record

    def query_at(self, timestamp: datetime) -> list[TemporalRecord]:
        """Return all records valid at the given point in time.

        A record is considered valid when ``valid_from <= timestamp`` and
        either ``valid_to`` is ``None`` or ``valid_to > timestamp``.

        Args:
            timestamp: The point in time to query.

        Returns:
            All records valid at *timestamp*, in insertion order.
        """
        return [
            r
            for r in self._records
            if r.valid_from <= timestamp and (r.valid_to is None or r.valid_to > timestamp)
        ]

    def supersede(
        self,
        old_key: str,
        new_key: str,
        supersession_time: datetime,
    ) -> None:
        """Mark the latest version of *old_key* as superseded by *new_key*.

        Sets ``valid_to`` to *supersession_time* and ``superseded_by`` to
        *new_key* on the most recent record for *old_key*.

        Args:
            old_key: Key of the record to supersede.
            new_key: Key of the record that replaces it.
            supersession_time: Timestamp at which the supersession takes effect.

        Raises:
            KeyError: If *old_key* has no records in the index.
        """
        versions = self._by_key.get(old_key)
        if not versions:
            raise KeyError(f"No records found for key: {old_key!r}")

        latest = versions[-1]
        latest.valid_to = supersession_time
        latest.superseded_by = new_key

    def is_superseded(self, key: str) -> bool:
        """Check whether the latest version of *key* has been superseded.

        Args:
            key: The key to check.

        Returns:
            ``True`` if the latest record for *key* has a non-``None``
            ``superseded_by`` field, ``False`` otherwise or if the key
            does not exist.
        """
        versions = self._by_key.get(key)
        if not versions:
            return False
        return versions[-1].superseded_by is not None

    def get_current(self, key: str) -> TemporalRecord | None:
        """Return the latest non-superseded version for *key*.

        Args:
            key: The key to look up.

        Returns:
            The latest :class:`TemporalRecord` that has not been superseded,
            or ``None`` if the key does not exist or all versions are
            superseded.
        """
        versions = self._by_key.get(key)
        if not versions:
            return None
        # Walk backwards to find the latest non-superseded version.
        for record in reversed(versions):
            if record.superseded_by is None:
                return record
        return None

    def history(self, key: str) -> list[TemporalRecord]:
        """Return all versions of *key* ordered by ``valid_from``.

        Args:
            key: The key whose history to retrieve.

        Returns:
            All :class:`TemporalRecord` instances for *key*, sorted by
            ``valid_from``.
        """
        versions = self._by_key.get(key, [])
        return sorted(versions, key=lambda r: r.valid_from)

    def count(self) -> int:
        """Return the total number of records in the index."""
        return len(self._records)

    def all_records(self) -> list[TemporalRecord]:
        """Return all records in sorted order.

        Returns:
            A copy of the internal records list.
        """
        return list(self._records)
