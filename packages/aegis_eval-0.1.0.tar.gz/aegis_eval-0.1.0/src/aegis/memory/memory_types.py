"""The 7 Aegis memory types with classification engine.

Provides a taxonomy of memory entries -- factual, experiential, procedural,
semantic, strategic, social, and working -- along with a keyword/pattern-based
classifier that routes incoming entries to the correct type.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from aegis.core.types import MemoryTier

# ---------------------------------------------------------------------------
# Enum
# ---------------------------------------------------------------------------


class MemoryType(str, Enum):
    """The 7 Aegis memory types drawn from cognitive science analogues."""

    FACTUAL = "factual"
    EXPERIENTIAL = "experiential"
    PROCEDURAL = "procedural"
    SEMANTIC = "semantic"
    STRATEGIC = "strategic"
    SOCIAL = "social"
    WORKING_MEMORY = "working_memory"


# ---------------------------------------------------------------------------
# Typed entry
# ---------------------------------------------------------------------------


@dataclass
class TypedMemoryEntry:
    """A memory entry annotated with one of the 7 memory types.

    Extends the core MemoryEntry concept with type classification, temporal
    scoping, source attribution, access tracking, and utility scoring.

    Attributes:
        key: Unique identifier for this memory entry.
        value: The stored content.
        memory_type: Which of the 7 memory types this entry belongs to.
        tier: Temporal-hierarchical tier (working / session / permanent).
        confidence: Confidence score in [0.0, 1.0].
        temporal_scope: Tuple of (valid_from, valid_to) datetimes; either
            element may be ``None`` to indicate an open boundary.
        source: Where this memory originated (e.g. "user_input", "inference").
        access_count: Number of times this entry has been retrieved.
        utility_score: RL-derived utility estimate in [0.0, 1.0].
        tags: Free-form categorisation tags.
        metadata: Additional arbitrary metadata.
        created_at: When this entry was first stored.
        last_accessed: When this entry was last retrieved.
    """

    key: str
    value: Any
    memory_type: MemoryType
    tier: MemoryTier = MemoryTier.WORKING
    confidence: float = 1.0
    temporal_scope: tuple[datetime | None, datetime | None] = (None, None)
    source: str = "unknown"
    access_count: int = 0
    utility_score: float = 0.5
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    last_accessed: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# Keyword / pattern rule sets
# ---------------------------------------------------------------------------

# Each rule set maps a MemoryType to (keyword_list, regex_patterns).
# The classifier scores each type by counting keyword matches and regex hits,
# then picks the highest-scoring type (ties broken by enum declaration order).

_FACTUAL_KEYWORDS: list[str] = [
    "fact",
    "date",
    "number",
    "entity",
    "name",
    "location",
    "amount",
    "percentage",
    "statistic",
    "record",
    "measurement",
    "quantity",
    "address",
    "phone",
    "email",
    "id",
    "identifier",
    "born",
    "founded",
    "population",
    "revenue",
    "capital",
    "coordinates",
]
_FACTUAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b"),  # dates
    re.compile(r"\b\d+(\.\d+)?%\b"),  # percentages
    re.compile(r"\$\s?\d[\d,]*(\.\d{1,2})?"),  # currency
    re.compile(r"\b\d{3,}\b"),  # large numbers
    re.compile(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b"),  # proper nouns
]

_EXPERIENTIAL_KEYWORDS: list[str] = [
    "tried",
    "worked",
    "failed",
    "succeeded",
    "attempted",
    "outcome",
    "result",
    "experience",
    "lesson",
    "learned",
    "mistake",
    "success",
    "approach",
    "strategy",
    "tactic",
    "observed",
    "noticed",
    "discovered",
    "encountered",
    "resolved",
    "struggled",
    "improved",
]
_EXPERIENTIAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(tried|attempted)\s+(to|and)\b", re.IGNORECASE),
    re.compile(r"\b(worked|failed)\s+(well|badly|perfectly)\b", re.IGNORECASE),
    re.compile(r"\blast\s+time\b", re.IGNORECASE),
    re.compile(r"\b(in my experience|from experience)\b", re.IGNORECASE),
]

_PROCEDURAL_KEYWORDS: list[str] = [
    "how to",
    "steps",
    "process",
    "procedure",
    "recipe",
    "algorithm",
    "instruction",
    "method",
    "guide",
    "workflow",
    "protocol",
    "sequence",
    "first",
    "then",
    "next",
    "finally",
    "step 1",
    "step 2",
]
_PROCEDURAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\bhow\s+to\b", re.IGNORECASE),
    re.compile(r"\bstep\s+\d+\b", re.IGNORECASE),
    re.compile(r"\b(first|then|next|finally|afterwards)\b", re.IGNORECASE),
    re.compile(r"\b(procedure|protocol|workflow)\b", re.IGNORECASE),
]

_SEMANTIC_KEYWORDS: list[str] = [
    "concept",
    "principle",
    "definition",
    "meaning",
    "typically",
    "generally",
    "usually",
    "abstract",
    "theory",
    "framework",
    "category",
    "classification",
    "taxonomy",
    "ontology",
    "relation",
    "implies",
    "represents",
    "symbolises",
    "refers to",
    "denotes",
]
_SEMANTIC_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(typically|generally|usually|often)\b", re.IGNORECASE),
    re.compile(r"\bis\s+(a|an)\s+type\s+of\b", re.IGNORECASE),
    re.compile(r"\b(means|implies|represents|refers\s+to)\b", re.IGNORECASE),
    re.compile(r"\b(concept|principle|definition)\b", re.IGNORECASE),
]

_STRATEGIC_KEYWORDS: list[str] = [
    "plan",
    "priority",
    "focus on",
    "objective",
    "goal",
    "target",
    "strategy",
    "roadmap",
    "milestone",
    "deadline",
    "allocate",
    "optimise",
    "optimize",
    "trade-off",
    "tradeoff",
    "decision",
    "should",
    "must",
    "prioritise",
    "prioritize",
    "budget",
]
_STRATEGIC_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(focus\s+on|prioriti[sz]e)\b", re.IGNORECASE),
    re.compile(r"\b(plan|strategy|roadmap)\b", re.IGNORECASE),
    re.compile(r"\b(objective|goal|target)\s+(is|:)", re.IGNORECASE),
    re.compile(r"\bshould\s+(we|I|the\s+team)\b", re.IGNORECASE),
]

_SOCIAL_KEYWORDS: list[str] = [
    "agent",
    "trust",
    "collaboration",
    "team",
    "partner",
    "delegate",
    "reputation",
    "preference",
    "personality",
    "role",
    "relationship",
    "communicated",
    "agreed",
    "disagreed",
    "negotiated",
    "cooperated",
    "competing",
    "alliance",
    "consensus",
]
_SOCIAL_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\bagent[_\s]?\w+\b", re.IGNORECASE),
    re.compile(r"\btrust\s*(score|level|rating)\b", re.IGNORECASE),
    re.compile(r"\b(collaborat|cooperat|negotiat)\w+\b", re.IGNORECASE),
    re.compile(r"\b(reputation|preference|relationship)\b", re.IGNORECASE),
]

_WORKING_KEYWORDS: list[str] = [
    "current goal",
    "hypothesis",
    "testing whether",
    "active",
    "in progress",
    "pending",
    "scratch",
    "temp",
    "buffer",
    "intermediate",
    "draft",
    "tentative",
    "exploring",
    "investigating",
    "considering",
    "evaluating",
]
_WORKING_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\btesting\s+whether\b", re.IGNORECASE),
    re.compile(r"\b(hypothesis|conjecture|assumption)\b", re.IGNORECASE),
    re.compile(r"\b(current|active)\s+(goal|task|objective)\b", re.IGNORECASE),
    re.compile(r"\b(in\s+progress|pending|draft)\b", re.IGNORECASE),
]

# Consolidated lookup table for the classifier.
_RULES: dict[MemoryType, tuple[list[str], list[re.Pattern[str]]]] = {
    MemoryType.FACTUAL: (_FACTUAL_KEYWORDS, _FACTUAL_PATTERNS),
    MemoryType.EXPERIENTIAL: (_EXPERIENTIAL_KEYWORDS, _EXPERIENTIAL_PATTERNS),
    MemoryType.PROCEDURAL: (_PROCEDURAL_KEYWORDS, _PROCEDURAL_PATTERNS),
    MemoryType.SEMANTIC: (_SEMANTIC_KEYWORDS, _SEMANTIC_PATTERNS),
    MemoryType.STRATEGIC: (_STRATEGIC_KEYWORDS, _STRATEGIC_PATTERNS),
    MemoryType.SOCIAL: (_SOCIAL_KEYWORDS, _SOCIAL_PATTERNS),
    MemoryType.WORKING_MEMORY: (_WORKING_KEYWORDS, _WORKING_PATTERNS),
}


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------


class MemoryTypeClassifier:
    """Rule-based classifier that routes memory entries into one of the 7 types.

    Scoring works by counting keyword hits (1 point each) and regex pattern
    matches (2 points each) against the entry's key, value, and optional
    context.  The highest-scoring type wins; ties are broken by enum
    declaration order (factual > experiential > ... > working).

    Additional context hints (e.g. ``{"type_hint": "procedural"}``) can
    override the heuristic when confidence is low.
    """

    # -- public API ----------------------------------------------------------

    def classify(
        self,
        key: str,
        value: Any,
        context: dict[str, Any] | None = None,
    ) -> MemoryType:
        """Classify a single memory entry.

        Args:
            key: The entry key.
            value: The entry value (will be cast to ``str`` for analysis).
            context: Optional context dict.  Recognised keys:

                * ``type_hint`` -- explicit type name (used when heuristic
                  confidence is low).
                * ``source`` -- where the memory came from.
                * ``tags`` -- list of tags to include in the text corpus.

        Returns:
            The most likely :class:`MemoryType`.
        """
        context = context or {}
        text = self._build_corpus(key, value, context)
        scores = self._score_all(text)

        # If caller supplied an explicit hint and the heuristic is weak, honour it.
        hint = context.get("type_hint")
        if hint is not None:
            try:
                hinted = MemoryType(hint)
            except ValueError:
                hinted = None
            if hinted is not None:
                best_score = max(scores.values()) if scores else 0
                if best_score < 3:
                    return hinted

        # Pick highest-scoring type.
        if not scores or max(scores.values()) == 0:
            return MemoryType.FACTUAL  # safe default

        best_type = max(scores, key=lambda t: scores[t])
        return best_type

    def classify_batch(
        self,
        entries: list[tuple[str, Any, dict[str, Any] | None]],
    ) -> dict[str, MemoryType]:
        """Classify multiple entries at once.

        Args:
            entries: List of ``(key, value, context)`` tuples.

        Returns:
            Mapping of key to classified :class:`MemoryType`.
        """
        return {key: self.classify(key, value, ctx) for key, value, ctx in entries}

    def type_distribution(
        self,
        entries: list[tuple[str, Any, dict[str, Any] | None]],
    ) -> dict[MemoryType, int]:
        """Compute the distribution of memory types across a set of entries.

        Args:
            entries: List of ``(key, value, context)`` tuples.

        Returns:
            Count of entries per :class:`MemoryType`.
        """
        dist: dict[MemoryType, int] = {mt: 0 for mt in MemoryType}
        classified = self.classify_batch(entries)
        for mtype in classified.values():
            dist[mtype] += 1
        return dist

    # -- internals -----------------------------------------------------------

    @staticmethod
    def _build_corpus(key: str, value: Any, context: dict[str, Any]) -> str:
        """Concatenate all textual material into a single lowercase corpus."""
        parts: list[str] = [str(key), str(value)]
        if "tags" in context and isinstance(context["tags"], list):
            parts.extend(str(t) for t in context["tags"])
        if "source" in context:
            parts.append(str(context["source"]))
        return " ".join(parts).lower()

    @staticmethod
    def _score_all(text: str) -> dict[MemoryType, int]:
        """Score every memory type against *text*."""
        scores: dict[MemoryType, int] = {}
        for mtype, (keywords, patterns) in _RULES.items():
            score = 0
            # Keyword matches (1 point each).
            for kw in keywords:
                if kw in text:
                    score += 1
            # Regex pattern matches (2 points each, heavier signal).
            for pat in patterns:
                if pat.search(text):
                    score += 2
            scores[mtype] = score
        return scores
