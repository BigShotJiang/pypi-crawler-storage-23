"""Memory policy engine implementing the 12 RL-trained memory operations.

The :class:`MemoryPolicyEngine` orchestrates every operation defined in
:class:`aegis.core.types.MemoryOperation`.  When optional subsystems
(knowledge graph, provenance tracker) are provided, the five previously
stubbed operations (LINK, COMPRESS, SPLIT, MERGE, VERIFY) use them for
real logic; otherwise they fall back to basic behaviour.
"""

from __future__ import annotations

from datetime import UTC, datetime

# Avoid hard import cycles — these are optional at runtime.
from typing import TYPE_CHECKING, Any, cast

from aegis.core.types import MemoryOperation, MemoryTier
from aegis.memory.types import MemoryEntry, MemoryStore

if TYPE_CHECKING:
    from aegis.memory.graph import KnowledgeGraph
    from aegis.memory.provenance import ProvenanceTracker


class MemoryPolicyEngine:
    """Orchestrates the 12 memory operations against a :class:`MemoryStore`.

    Each method corresponds to one :class:`MemoryOperation` enum value.
    In production, the decision logic (when to promote, compress, forget,
    etc.) is driven by an RL-trained policy network.

    Args:
        store: The backing :class:`MemoryStore` implementation.
        graph: Optional :class:`KnowledgeGraph` for the LINK operation.
        provenance: Optional :class:`ProvenanceTracker` for provenance
            recording across operations.
    """

    def __init__(
        self,
        store: MemoryStore,
        graph: KnowledgeGraph | None = None,
        provenance: ProvenanceTracker | None = None,
    ) -> None:
        self._store = store
        self._graph = graph
        self._provenance = provenance

    # -- STORE ---------------------------------------------------------------

    def store(self, key: str, value: Any, tier: MemoryTier = MemoryTier.WORKING) -> MemoryEntry:
        """Store a new memory entry.

        Args:
            key: Unique key for the entry.
            value: Content to store.
            tier: Initial memory tier.

        Returns:
            The newly created :class:`MemoryEntry`.
        """
        entry = MemoryEntry(key=key, value=value, tier=tier)
        self._store.store(entry)
        return entry

    # -- UPDATE --------------------------------------------------------------

    def update(self, key: str, value: Any) -> bool:
        """Update an existing memory entry's value.

        Args:
            key: Key of the entry to update.
            value: New value.

        Returns:
            ``True`` if the entry was updated, ``False`` if not found.
        """
        return self._store.update(key, value)

    # -- FORGET --------------------------------------------------------------

    def forget(self, key: str) -> bool:
        """Remove a memory entry (the FORGET operation).

        Args:
            key: Key of the entry to forget.

        Returns:
            ``True`` if the entry was deleted, ``False`` if not found.
        """
        return self._store.delete(key)

    # -- RETRIEVE ------------------------------------------------------------

    def retrieve(self, key: str) -> MemoryEntry | None:
        """Retrieve a memory entry by key.

        Increments the access count on the retrieved entry to support
        access-frequency-based promotion/demotion heuristics.

        Args:
            key: Key of the entry to retrieve.

        Returns:
            The :class:`MemoryEntry` if found, otherwise ``None``.
        """
        entry = self._store.retrieve(key)
        if entry is not None:
            entry.access_count += 1
            entry.updated_at = datetime.now(tz=UTC)
        return entry

    # -- LINK ----------------------------------------------------------------

    def link(self, key_a: str, key_b: str, relation: str = "related") -> bool:
        """Create a semantic link between two memory entries.

        When a :class:`KnowledgeGraph` is attached, a real bidirectional
        edge is created.  Backward-compatible link metadata is always
        written to both entries.

        Args:
            key_a: Key of the first entry.
            key_b: Key of the second entry.
            relation: Type of relationship (e.g. ``"related"``, ``"causes"``).

        Returns:
            ``True`` if both entries exist and the link was created.
        """
        entry_a = self._store.retrieve(key_a)
        entry_b = self._store.retrieve(key_b)
        if entry_a is None or entry_b is None:
            return False

        # Real KG edge when available.
        if self._graph is not None:
            self._graph.add_node(key_a)
            self._graph.add_node(key_b)
            self._graph.add_edge(key_a, key_b, relation)

        # Backward-compatible link metadata on both entries.
        entry_a.metadata.setdefault("links", []).append({"target": key_b, "relation": relation})
        entry_b.metadata.setdefault("links", []).append({"target": key_a, "relation": relation})
        return True

    # -- COMPRESS ------------------------------------------------------------

    def compress(self, key: str, *, keep_ratio: float = 0.4) -> bool:
        """Compress a memory entry using extractive summarization.

        Ranks sentences by importance (position, keyword density, length)
        and keeps the top ``keep_ratio`` fraction. Short values or those
        with ≤3 sentences are marked as compressed without modification.

        Args:
            key: Key of the entry to compress.
            keep_ratio: Fraction of sentences to keep (default 0.4).

        Returns:
            ``True`` if the entry was compressed.
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return False

        value_str = str(entry.value)
        original_length = len(value_str)

        if original_length <= 100:
            entry.metadata["compressed"] = True
            return True

        sentences = [s.strip() for s in value_str.split(". ") if s.strip()]
        if len(sentences) <= 3:
            entry.metadata["compressed"] = True
            return True

        # Extractive summarization: score each sentence by importance
        scored: list[tuple[float, int, str]] = []
        total = len(sentences)
        for idx, sentence in enumerate(sentences):
            score = 0.0
            # Position bias: first and last sentences are important
            if idx == 0 or idx == total - 1:
                score += 1.0
            elif idx < total * 0.2:
                score += 0.5  # Early sentences often contain key info

            # Length heuristic: very short sentences are likely less informative
            words = sentence.split()
            if len(words) >= 5:
                score += 0.3
            if len(words) >= 10:
                score += 0.2

            # Keyword density: presence of informational markers
            markers = {
                "important",
                "key",
                "note",
                "critical",
                "however",
                "therefore",
                "because",
                "result",
                "conclusion",
                "summary",
            }
            if markers & set(w.lower().strip(".,;:") for w in words):
                score += 0.5

            scored.append((score, idx, sentence))

        # Keep top-k by score, preserving original order
        keep_count = max(2, int(total * keep_ratio))
        top_sentences = sorted(scored, key=lambda x: -x[0])[:keep_count]
        top_sentences.sort(key=lambda x: x[1])  # Restore original order

        compressed = ". ".join(s[2] for s in top_sentences)
        if not compressed.endswith("."):
            compressed += "."

        entry.value = compressed
        entry.metadata["compressed"] = True
        entry.metadata["original_length"] = original_length
        entry.metadata["compressed_length"] = len(compressed)
        entry.metadata["sentences_kept"] = keep_count
        entry.metadata["sentences_total"] = total

        if self._provenance is not None:
            self._provenance.record(
                key,
                "derived",
                key,
                MemoryOperation.COMPRESS,
                confidence=entry.confidence,
            )
        return True

    # -- PROMOTE -------------------------------------------------------------

    # Tier ordering for promotion/demotion validation.
    _TIER_ORDER = [MemoryTier.WORKING, MemoryTier.SESSION, MemoryTier.PERMANENT]

    def _tier_rank(self, tier: MemoryTier) -> int:
        """Return the numeric rank of a tier (higher = more persistent)."""
        try:
            return self._TIER_ORDER.index(tier)
        except ValueError:
            return 0

    def should_promote(self, entry: MemoryEntry) -> MemoryTier | None:
        """Determine if an entry should be promoted based on heuristics.

        Considers access frequency, confidence, age, and tag importance.
        Returns the recommended target tier or ``None`` if no promotion needed.
        """
        current_rank = self._tier_rank(entry.tier)
        if current_rank >= len(self._TIER_ORDER) - 1:
            return None  # Already at highest tier

        score = 0.0
        # High access count suggests importance
        if entry.access_count >= 10:
            score += 0.4
        elif entry.access_count >= 5:
            score += 0.2

        # High confidence means reliable information
        if entry.confidence >= 0.9:
            score += 0.3
        elif entry.confidence >= 0.7:
            score += 0.15

        # Important tags boost promotion
        important_tags = {"critical", "verified", "pinned", "core"}
        if important_tags & set(entry.tags):
            score += 0.3

        if score >= 0.5:
            return self._TIER_ORDER[current_rank + 1]
        return None

    def should_demote(self, entry: MemoryEntry) -> MemoryTier | None:
        """Determine if an entry should be demoted based on decay heuristics.

        Considers access recency, confidence decay, and temporal expiry.
        Returns the recommended target tier or ``None`` if no demotion needed.
        """
        current_rank = self._tier_rank(entry.tier)
        if current_rank <= 0:
            return None  # Already at lowest tier

        now = datetime.now(tz=UTC)
        score = 0.0

        # Low access count relative to age
        age_hours = max((now - entry.created_at).total_seconds() / 3600, 1.0)
        access_rate = entry.access_count / age_hours
        if access_rate < 0.01:  # Less than 1 access per 100 hours
            score += 0.3

        # Low confidence
        if entry.confidence < 0.3:
            score += 0.4
        elif entry.confidence < 0.5:
            score += 0.2

        # Expired temporal bounds
        if (
            entry.temporal_bounds is not None
            and entry.temporal_bounds.valid_to is not None
            and entry.temporal_bounds.valid_to < now
        ):
            score += 0.3

        if score >= 0.5:
            return self._TIER_ORDER[current_rank - 1]
        return None

    def promote(self, key: str, target_tier: MemoryTier) -> bool:
        """Promote a memory entry to a higher (more persistent) tier.

        Validates that the target tier is actually higher than the current
        tier and records the promotion in metadata.

        Args:
            key: Key of the entry to promote.
            target_tier: The tier to promote to.

        Returns:
            ``True`` if the entry was promoted.
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return False

        old_tier = entry.tier
        entry.tier = target_tier
        entry.metadata["last_promotion"] = {
            "from": old_tier.value,
            "to": target_tier.value,
            "at": datetime.now(tz=UTC).isoformat(),
            "access_count_at_promotion": entry.access_count,
        }

        if self._provenance is not None:
            self._provenance.record(
                key,
                "promoted",
                key,
                MemoryOperation.PROMOTE,
                confidence=entry.confidence,
            )
        return True

    # -- DEMOTE --------------------------------------------------------------

    def demote(self, key: str, target_tier: MemoryTier) -> bool:
        """Demote a memory entry to a lower (less persistent) tier.

        Records the demotion reason in metadata.

        Args:
            key: Key of the entry to demote.
            target_tier: The tier to demote to.

        Returns:
            ``True`` if the entry was demoted.
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return False

        old_tier = entry.tier
        entry.tier = target_tier
        entry.metadata["last_demotion"] = {
            "from": old_tier.value,
            "to": target_tier.value,
            "at": datetime.now(tz=UTC).isoformat(),
            "access_count_at_demotion": entry.access_count,
        }

        if self._provenance is not None:
            self._provenance.record(
                key,
                "demoted",
                key,
                MemoryOperation.DEMOTE,
                confidence=entry.confidence,
            )
        return True

    # -- SPLIT ---------------------------------------------------------------

    def split(self, key: str) -> list[MemoryEntry]:
        """Split a memory entry into independent entries per sentence.

        Each sentence becomes a separate entry keyed as
        ``{original_key}_part_{i}``, inheriting the parent's tier,
        confidence, tags, and provenance.

        Args:
            key: Key of the entry to split.

        Returns:
            The list of newly created entries (empty if the source was
            not found or contains only one sentence).
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return []

        value_str = str(entry.value)
        sentences = [s.strip() for s in value_str.split(". ") if s.strip()]
        if len(sentences) <= 1:
            return []

        parts: list[MemoryEntry] = []
        for i, sentence in enumerate(sentences):
            part_key = f"{key}_part_{i}"
            part = MemoryEntry(
                key=part_key,
                value=sentence,
                tier=entry.tier,
                confidence=entry.confidence,
                provenance={**entry.provenance, "split_from": key, "part_index": i},
                tags=[*entry.tags, "split"],
            )
            self._store.store(part)
            parts.append(part)

            if self._provenance is not None:
                self._provenance.record(
                    part_key,
                    "split",
                    key,
                    MemoryOperation.SPLIT,
                    confidence=entry.confidence,
                    parent_keys=[key],
                )

        return parts

    # -- MERGE ---------------------------------------------------------------

    def merge(self, key_a: str, key_b: str) -> MemoryEntry | None:
        """Merge two memory entries into a single consolidated entry.

        The merged entry combines both values, unions their tags, merges
        provenance dicts, and computes confidence as the geometric mean
        of the two sources.  The higher tier is chosen.

        Args:
            key_a: Key of the first entry.
            key_b: Key of the second entry.

        Returns:
            The merged :class:`MemoryEntry`, or ``None`` if either source
            entry was not found.
        """
        entry_a = self._store.retrieve(key_a)
        entry_b = self._store.retrieve(key_b)
        if entry_a is None or entry_b is None:
            return None

        merged_value = f"{entry_a.value}\n---\n{entry_b.value}"

        merged_provenance = {**entry_a.provenance, **entry_b.provenance}
        merged_provenance["merge_sources"] = [key_a, key_b]

        merged_confidence = (entry_a.confidence * entry_b.confidence) ** 0.5

        merged_tags = list(set(entry_a.tags + entry_b.tags + ["merged"]))

        tier_order = [MemoryTier.WORKING, MemoryTier.SESSION, MemoryTier.PERMANENT]
        higher_tier = max(
            entry_a.tier,
            entry_b.tier,
            key=lambda t: tier_order.index(t),
        )

        merged = MemoryEntry(
            key=f"{key_a}+{key_b}",
            value=merged_value,
            tier=higher_tier,
            confidence=merged_confidence,
            provenance=merged_provenance,
            tags=merged_tags,
            metadata={"merge_sources": [key_a, key_b]},
        )
        self._store.store(merged)

        if self._provenance is not None:
            self._provenance.record(
                merged.key,
                "merged",
                f"{key_a},{key_b}",
                MemoryOperation.MERGE,
                confidence=merged_confidence,
                parent_keys=[key_a, key_b],
            )

        return merged

    # -- VERIFY --------------------------------------------------------------

    def verify(self, key: str) -> bool:
        """Verify the integrity and currency of a memory entry.

        Checks temporal bounds validity, confidence threshold, and
        provenance chain integrity (when a tracker is available).

        Args:
            key: Key of the entry to verify.

        Returns:
            ``True`` if the entry passes all verification checks.
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return False

        issues: list[str] = []
        now = datetime.now(tz=UTC)

        # Check 1: temporal bounds validity.
        if entry.temporal_bounds is not None:
            if entry.temporal_bounds.valid_to is not None and entry.temporal_bounds.valid_to < now:
                issues.append("expired_temporal_bounds")
            if entry.temporal_bounds.valid_from > now:
                issues.append("future_valid_from")

        # Check 2: confidence threshold.
        if entry.confidence < 0.1:
            issues.append("very_low_confidence")

        # Check 3: provenance chain (when tracker available).
        if self._provenance is not None and not self._provenance.validate_chain(key):
            issues.append("broken_provenance_chain")

        entry.metadata["verified"] = len(issues) == 0
        entry.metadata["verification_issues"] = issues
        entry.metadata["verified_at"] = now.isoformat()
        return len(issues) == 0

    # -- ANNOTATE ------------------------------------------------------------

    def annotate(self, key: str, annotation: dict[str, Any]) -> bool:
        """Add an annotation to a memory entry.

        Annotations enrich entries with metadata from downstream
        processing stages (e.g. scoring feedback, user corrections).

        Args:
            key: Key of the entry to annotate.
            annotation: The annotation payload.

        Returns:
            ``True`` if the entry was annotated.
        """
        entry = self._store.retrieve(key)
        if entry is None:
            return False
        entry.metadata.setdefault("annotations", []).append(annotation)
        return True

    # -- dispatch helper -----------------------------------------------------

    def execute(self, operation: MemoryOperation, **kwargs: Any) -> Any:
        """Dispatch a :class:`MemoryOperation` to the corresponding method.

        Args:
            operation: The memory operation to execute.
            **kwargs: Arguments forwarded to the operation method.

        Returns:
            The result of the operation method.

        Raises:
            ValueError: If the operation is unrecognised.
        """
        dispatch = {
            MemoryOperation.STORE: self.store,
            MemoryOperation.UPDATE: self.update,
            MemoryOperation.FORGET: self.forget,
            MemoryOperation.RETRIEVE: self.retrieve,
            MemoryOperation.LINK: self.link,
            MemoryOperation.COMPRESS: self.compress,
            MemoryOperation.PROMOTE: self.promote,
            MemoryOperation.DEMOTE: self.demote,
            MemoryOperation.SPLIT: self.split,
            MemoryOperation.MERGE: self.merge,
            MemoryOperation.VERIFY: self.verify,
            MemoryOperation.ANNOTATE: self.annotate,
        }
        handler = dispatch.get(operation)
        if handler is None:
            raise ValueError(f"Unknown memory operation: {operation}")
        typed_handler = cast("Any", handler)
        return typed_handler(**kwargs)
