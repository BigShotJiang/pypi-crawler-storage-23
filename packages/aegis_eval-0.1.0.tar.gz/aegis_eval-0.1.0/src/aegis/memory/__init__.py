"""Aegis Memory Subsystem.

Provides temporal-hierarchical memory with event logging, knowledge graph,
vector search, provenance tracking, snapshot reconstruction, 7 memory types,
7 time horizons, multi-agent sharing, decay policies, versioning, and
architecture search.
"""

from aegis.memory.aegis_memory import AegisMemory
from aegis.memory.architecture_search import (
    ArchitectureCandidate,
    ArchitectureSearchEngine,
    MemoryArchitecture,
)
from aegis.memory.consolidation import ConsolidationEngine, ConsolidationResult
from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction
from aegis.memory.event_log import EventLog
from aegis.memory.graph import Edge, KnowledgeGraph
from aegis.memory.interference import InterferenceDetector, InterferenceResult
from aegis.memory.manager import MemoryManager
from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier, TypedMemoryEntry
from aegis.memory.memrl import FeedbackRecord, MemoryUtility, MemRLUpdater
from aegis.memory.multi_agent import (
    AgentProfile,
    MultiAgentMemory,
    SharedMemoryNamespace,
    ShareEvent,
)
from aegis.memory.operations import MemoryPolicyEngine
from aegis.memory.provenance import ProvenanceRecord, ProvenanceTracker
from aegis.memory.snapshot import MemorySnapshotData, SnapshotReconstructor
from aegis.memory.store import InMemoryStore
from aegis.memory.temporal import TemporalIndex, TemporalRecord
from aegis.memory.time_horizons import RetentionPolicy, TimeHorizon, TimeHorizonManager
from aegis.memory.types import MemoryEntry, MemoryStore
from aegis.memory.vector import VectorStore
from aegis.memory.versioning import MemoryBranch, MemoryCommit, MemoryVersionControl

__all__ = [
    # Core
    "AegisMemory",
    "ConsolidationEngine",
    "ConsolidationResult",
    "Edge",
    "EventLog",
    "FeedbackRecord",
    "InMemoryStore",
    "InterferenceDetector",
    "InterferenceResult",
    "KnowledgeGraph",
    "MemoryEntry",
    "MemoryManager",
    "MemoryPolicyEngine",
    "MemorySnapshotData",
    "MemoryStore",
    "MemoryUtility",
    "MemRLUpdater",
    "ProvenanceRecord",
    "ProvenanceTracker",
    "SnapshotReconstructor",
    "TemporalIndex",
    "TemporalRecord",
    "VectorStore",
    # Memory types (7 types)
    "MemoryType",
    "MemoryTypeClassifier",
    "TypedMemoryEntry",
    # Time horizons (7 horizons)
    "RetentionPolicy",
    "TimeHorizon",
    "TimeHorizonManager",
    # Multi-agent
    "AgentProfile",
    "MultiAgentMemory",
    "ShareEvent",
    "SharedMemoryNamespace",
    # Decay
    "DecayConfig",
    "DecayEngine",
    "DecayFunction",
    # Versioning
    "MemoryBranch",
    "MemoryCommit",
    "MemoryVersionControl",
    # Architecture search
    "ArchitectureCandidate",
    "ArchitectureSearchEngine",
    "MemoryArchitecture",
]
