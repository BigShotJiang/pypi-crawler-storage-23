"""Factory for creating MemoryManager with appropriate backends.

Reads environment variables to determine whether to use in-memory
stores or real database backends (pgvector, Neo4j).
"""

from __future__ import annotations

import logging
from typing import Any, cast

from aegis.core.settings import get_settings
from aegis.memory.manager import MemoryManager

logger = logging.getLogger(__name__)


def create_memory_manager() -> MemoryManager:
    """Create a MemoryManager with backends based on environment config.

    If postgres is configured, uses :class:`PgVectorStore` for the memory
    store.  If Neo4j is configured, uses :class:`Neo4jGraph` for the
    knowledge graph.  Otherwise falls back to in-memory implementations.

    Returns:
        A configured :class:`MemoryManager` instance.
    """
    store = None
    graph = None
    settings = get_settings()

    # Try pgvector backend
    if settings.postgres_configured:
        try:
            from aegis.store.postgres import PgVectorStore

            store = PgVectorStore(dsn=settings.postgres_dsn, enable_embeddings=False)
            logger.info("Memory store: PgVectorStore (%s)", settings.postgres_dsn.split("@")[-1])
        except Exception as exc:
            logger.warning("Failed to initialize PgVectorStore, using in-memory: %s", exc)

    # Try Neo4j backend
    if settings.neo4j_configured:
        try:
            from aegis.store.neo4j import Neo4jGraph

            graph = Neo4jGraph(
                uri=settings.neo4j_uri,
                user=settings.neo4j_user,
                password=settings.neo4j_password,
            )
            logger.info("Knowledge graph: Neo4jGraph (%s)", settings.neo4j_uri)
        except Exception as exc:
            logger.warning("Failed to initialize Neo4jGraph, using in-memory: %s", exc)

    return MemoryManager(
        store=store,
        graph=cast("Any", graph),
        enable_vectors=False,
    )
