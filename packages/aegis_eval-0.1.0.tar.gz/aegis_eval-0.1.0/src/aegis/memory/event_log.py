"""Append-only immutable event log with SHA-256 hash chain.

The :class:`EventLog` stores :class:`~aegis.core.types.MemoryEventV1` entries
in strict append-only order.  A SHA-256 hash chain links every entry to its
predecessor, enabling tamper detection via :meth:`EventLog.verify_integrity`.

No mutation (update, delete, reorder) is permitted after an event has been
appended.  Attempting to use ``__setitem__`` or ``__delitem__`` raises
:class:`~aegis.core.exceptions.EventLogImmutabilityError`.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterator
from datetime import datetime

from aegis.core.exceptions import EventLogImmutabilityError
from aegis.core.types import MemoryEventV1


class EventLog:
    """Append-only, hash-chained event log for :class:`MemoryEventV1` entries.

    The log supports only a single write operation -- :meth:`append` -- which
    adds an event and extends the internal SHA-256 hash chain.  All other
    access is strictly read-only.

    Attributes:
        _log: Internal list of appended events.
        _hash_chain: SHA-256 hash chain where each entry depends on its
            predecessor, providing tamper detection.
    """

    def __init__(self) -> None:
        self._log: list[MemoryEventV1] = []
        self._hash_chain: list[str] = []

    # -- write ---------------------------------------------------------------

    def append(self, event: MemoryEventV1) -> None:
        """Append an event to the log and extend the hash chain.

        This is the **only** write operation on the event log.  A deep
        copy of the event is stored so that external mutations cannot
        alter the immutable log.

        Args:
            event: The :class:`MemoryEventV1` to append.
        """
        event_copy = event.model_copy(deep=True)
        previous_hash = self._hash_chain[-1] if self._hash_chain else ""
        new_hash = self._compute_hash(event_copy, previous_hash)
        self._log.append(event_copy)
        self._hash_chain.append(new_hash)

    # -- read ----------------------------------------------------------------

    def get(self, index: int) -> MemoryEventV1:
        """Retrieve an event by its position in the log.

        Args:
            index: Zero-based position of the event.

        Returns:
            The :class:`MemoryEventV1` at the given index.

        Raises:
            IndexError: If the index is out of range.
        """
        return self._log[index]

    def replay_from(self, timestamp: datetime) -> list[MemoryEventV1]:
        """Return all events from *timestamp* forward (inclusive).

        Args:
            timestamp: The earliest timestamp to include.

        Returns:
            A list of events whose ``timestamp`` is >= *timestamp*,
            in log order.
        """
        return [e for e in self._log if e.timestamp >= timestamp]

    def replay_range(self, start: datetime, end: datetime) -> list[MemoryEventV1]:
        """Return all events within a time window (inclusive on both ends).

        Args:
            start: The earliest timestamp to include.
            end: The latest timestamp to include.

        Returns:
            A list of events whose ``timestamp`` falls within
            [*start*, *end*], in log order.
        """
        return [e for e in self._log if start <= e.timestamp <= end]

    def all_events(self) -> list[MemoryEventV1]:
        """Return a shallow copy of all events in the log.

        Returns:
            A **copy** of the internal event list.  Callers may mutate the
            returned list without affecting the log.
        """
        return list(self._log)

    # -- integrity -----------------------------------------------------------

    def verify_integrity(self) -> bool:
        """Walk the hash chain and verify that no event has been tampered with.

        Recomputes the SHA-256 hash for each event using its predecessor's
        hash and compares against the stored hash chain.

        Returns:
            ``True`` if the entire chain is intact, ``False`` otherwise.
        """
        previous_hash = ""
        for i, event in enumerate(self._log):
            expected = self._compute_hash(event, previous_hash)
            if expected != self._hash_chain[i]:
                return False
            previous_hash = self._hash_chain[i]
        return True

    # -- dunder read-only access ---------------------------------------------

    def __len__(self) -> int:
        """Return the number of events in the log."""
        return len(self._log)

    def __iter__(self) -> Iterator[MemoryEventV1]:
        """Iterate over the events in the log."""
        return iter(self._log)

    def __getitem__(self, index: int) -> MemoryEventV1:
        """Retrieve an event by index (supports ``log[i]`` syntax).

        Args:
            index: Zero-based position of the event.

        Returns:
            The :class:`MemoryEventV1` at the given index.

        Raises:
            IndexError: If the index is out of range.
        """
        return self._log[index]

    def __setitem__(self, index: int, value: MemoryEventV1) -> None:
        """Block item assignment -- the event log is immutable.

        Raises:
            EventLogImmutabilityError: Always.
        """
        raise EventLogImmutabilityError("Cannot set items on an immutable event log.")

    def __delitem__(self, index: int) -> None:
        """Block item deletion -- the event log is immutable.

        Raises:
            EventLogImmutabilityError: Always.
        """
        raise EventLogImmutabilityError("Cannot delete items from an immutable event log.")

    # -- internal ------------------------------------------------------------

    def _compute_hash(self, event: MemoryEventV1, previous_hash: str) -> str:
        """Compute the SHA-256 hash for an event given its predecessor hash.

        Args:
            event: The event to hash.
            previous_hash: The hash of the preceding event (empty string for
                the first event).

        Returns:
            The hex-encoded SHA-256 digest.
        """
        payload = event.model_dump_json() + previous_hash
        return hashlib.sha256(payload.encode()).hexdigest()
