"""The 7 Aegis time horizons with retention policies and lifecycle management.

Maps every memory entry to a temporal horizon -- from sub-second scratch
buffers to permanent meta-level knowledge -- and enforces retention limits,
automatic promotion, and confidence decay per horizon.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from typing import Any, cast

# ---------------------------------------------------------------------------
# Enum
# ---------------------------------------------------------------------------


class TimeHorizon(str, Enum):
    """The 7 temporal horizons in the Aegis memory model.

    Ordered from shortest to longest retention.
    """

    SUB_SECOND = "sub_second"
    TURN_LEVEL = "turn_level"
    SESSION_LEVEL = "session_level"
    ENGAGEMENT_LEVEL = "engagement_level"
    CLIENT_LEVEL = "client_level"
    DOMAIN_LEVEL = "domain_level"
    META_LEVEL = "meta_level"


# Ordered list for promotion chain (index = level).
_HORIZON_ORDER: list[TimeHorizon] = list(TimeHorizon)


def _next_horizon(h: TimeHorizon) -> TimeHorizon | None:
    """Return the next longer-lived horizon, or ``None`` if already meta."""
    idx = _HORIZON_ORDER.index(h)
    if idx + 1 < len(_HORIZON_ORDER):
        return _HORIZON_ORDER[idx + 1]
    return None


# ---------------------------------------------------------------------------
# Retention policy
# ---------------------------------------------------------------------------


@dataclass
class RetentionPolicy:
    """Retention and lifecycle configuration for a single time horizon.

    Attributes:
        horizon: Which horizon this policy governs.
        max_age_seconds: Maximum age (in seconds) before expiry.  ``None``
            means unlimited.
        max_entries: Maximum number of entries allowed in this horizon.
            ``None`` means unlimited.
        auto_promote_after: Seconds of survival after which the entry is
            eligible for promotion to the next horizon.  ``None`` disables
            automatic promotion.
        decay_rate: Per-second confidence decay rate (applied as
            ``confidence *= (1 - decay_rate)^age``).
        priority: Numeric priority for eviction ordering (lower = evicted
            first when ``max_entries`` is exceeded).
    """

    horizon: TimeHorizon
    max_age_seconds: int | None = None
    max_entries: int | None = None
    auto_promote_after: int | None = None
    decay_rate: float = 0.0
    priority: int = 0


# ---------------------------------------------------------------------------
# Default policies
# ---------------------------------------------------------------------------


def _default_policies() -> list[RetentionPolicy]:
    """Return the default retention policy for each of the 7 horizons."""
    return [
        RetentionPolicy(
            horizon=TimeHorizon.SUB_SECOND,
            max_age_seconds=5,
            max_entries=100,
            auto_promote_after=3,
            decay_rate=0.20,
            priority=0,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.TURN_LEVEL,
            max_age_seconds=3_600,  # 1 hour
            max_entries=500,
            auto_promote_after=1_800,  # 30 minutes
            decay_rate=0.05,
            priority=1,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.SESSION_LEVEL,
            max_age_seconds=28_800,  # 8 hours
            max_entries=2_000,
            auto_promote_after=14_400,  # 4 hours
            decay_rate=0.01,
            priority=2,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.ENGAGEMENT_LEVEL,
            max_age_seconds=2_592_000,  # 30 days
            max_entries=10_000,
            auto_promote_after=1_296_000,  # 15 days
            decay_rate=0.001,
            priority=3,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.CLIENT_LEVEL,
            max_age_seconds=31_536_000,  # 365 days
            max_entries=50_000,
            auto_promote_after=15_768_000,  # ~6 months
            decay_rate=0.0001,
            priority=4,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.DOMAIN_LEVEL,
            max_age_seconds=None,  # unlimited
            max_entries=100_000,
            auto_promote_after=None,  # manual only
            decay_rate=0.00001,
            priority=5,
        ),
        RetentionPolicy(
            horizon=TimeHorizon.META_LEVEL,
            max_age_seconds=None,  # unlimited
            max_entries=10_000,
            auto_promote_after=None,  # terminal horizon
            decay_rate=0.0,
            priority=6,
        ),
    ]


# ---------------------------------------------------------------------------
# Lightweight entry protocol
# ---------------------------------------------------------------------------
# TimeHorizonManager operates on dicts (or dataclasses duck-typed as dicts)
# so it stays decoupled from MemoryEntry / TypedMemoryEntry.  The minimal
# contract: each entry must have "key", "created_at" (datetime), "confidence"
# (float), "horizon" (TimeHorizon), and optionally "memory_type" (str).
# ---------------------------------------------------------------------------


def _entry_age(entry: dict[str, Any], now: datetime) -> float:
    """Return the age of *entry* in seconds."""
    created = entry.get("created_at")
    if created is None:
        return 0.0
    created = cast("datetime", created)
    if created.tzinfo is None:
        created = created.replace(tzinfo=UTC)
    if now.tzinfo is None:
        now = now.replace(tzinfo=UTC)
    return max((now - created).total_seconds(), 0.0)


# ---------------------------------------------------------------------------
# Manager
# ---------------------------------------------------------------------------


class TimeHorizonManager:
    """Manages entry assignment, retention enforcement, promotion, and decay
    across the 7 time horizons.

    Args:
        policies: Custom retention policies.  When ``None`` the built-in
            defaults are used.
    """

    def __init__(self, policies: list[RetentionPolicy] | None = None) -> None:
        raw = policies if policies is not None else _default_policies()
        self._policies: dict[TimeHorizon, RetentionPolicy] = {p.horizon: p for p in raw}

    # -- assignment ----------------------------------------------------------

    def assign_horizon(
        self,
        entry_age_seconds: float,
        entry_type: str = "factual",
        context: dict[str, Any] | None = None,
    ) -> TimeHorizon:
        """Determine the appropriate time horizon for an entry.

        The assignment is based on the entry's age, its semantic type, and
        optional context hints (e.g. ``{"force_horizon": "client_level"}``).

        Args:
            entry_age_seconds: How old the entry is in seconds.
            entry_type: The memory type name (e.g. "procedural", "strategic").
            context: Optional context dict.

        Returns:
            The :class:`TimeHorizon` the entry should reside in.
        """
        context = context or {}

        # Honour explicit override.
        forced = context.get("force_horizon")
        if forced is not None:
            try:
                return TimeHorizon(forced)
            except ValueError:
                pass

        # Type-based bias: strategic and procedural knowledge tends to be
        # longer-lived; working memory is short.
        _long_lived_types = {"strategic", "procedural", "semantic"}
        _short_lived_types = {"working_memory"}

        # Long-lived types get a minimum floor horizon regardless of age,
        # because strategic/procedural/semantic knowledge should persist.
        _min_horizon_for_long_lived = TimeHorizon.ENGAGEMENT_LEVEL

        # Short-lived types are clamped to session level at most.
        _max_horizon_for_short_lived = TimeHorizon.SESSION_LEVEL

        # Walk horizons from shortest to longest; pick the first whose
        # max_age accommodates the entry.
        age_based: TimeHorizon | None = None
        for horizon in _HORIZON_ORDER:
            policy = self._policies.get(horizon)
            if policy is None:
                continue
            max_age = policy.max_age_seconds
            if max_age is None:
                # Unlimited horizon -- accept if the entry is old enough
                # to have graduated past all bounded horizons.
                if entry_age_seconds > 31_536_000:
                    age_based = horizon
                    break
                continue
            if entry_age_seconds <= max_age:
                age_based = horizon
                break

        if age_based is None:
            age_based = TimeHorizon.DOMAIN_LEVEL

        # Apply type biases.
        if entry_type in _long_lived_types:
            min_idx = _HORIZON_ORDER.index(_min_horizon_for_long_lived)
            cur_idx = _HORIZON_ORDER.index(age_based)
            if cur_idx < min_idx:
                return _min_horizon_for_long_lived
        elif entry_type in _short_lived_types:
            max_idx = _HORIZON_ORDER.index(_max_horizon_for_short_lived)
            cur_idx = _HORIZON_ORDER.index(age_based)
            if cur_idx > max_idx:
                return _max_horizon_for_short_lived

        return age_based

    # -- retention enforcement -----------------------------------------------

    def enforce_retention(
        self,
        entries: list[dict[str, Any]],
        current_time: datetime | None = None,
    ) -> dict[str, list[dict[str, Any]]]:
        """Apply retention policies to all entries.

        Returns:
            Dict with three lists:

            * ``expired`` -- entries that exceeded their horizon's max_age.
            * ``promoted`` -- entries eligible for promotion.
            * ``decayed`` -- entries whose confidence was reduced.
        """
        now = current_time or datetime.now(tz=UTC)
        expired: list[dict[str, Any]] = []
        promoted: list[dict[str, Any]] = []
        decayed: list[dict[str, Any]] = []

        for entry in entries:
            horizon: TimeHorizon = entry.get("horizon", TimeHorizon.TURN_LEVEL)
            policy = self._policies.get(horizon)
            if policy is None:
                continue

            age = _entry_age(entry, now)

            # Check expiry.
            if policy.max_age_seconds is not None and age > policy.max_age_seconds:
                expired.append(entry)
                continue

            # Check promotion eligibility.
            if (
                policy.auto_promote_after is not None
                and age > policy.auto_promote_after
                and _next_horizon(horizon) is not None
            ):
                promoted.append(entry)

            # Apply decay.
            if policy.decay_rate > 0:
                old_conf = entry.get("confidence", 1.0)
                new_conf = old_conf * math.exp(-policy.decay_rate * age)
                new_conf = max(new_conf, 0.0)
                if abs(new_conf - old_conf) > 1e-9:
                    entry["confidence"] = round(new_conf, 6)
                    decayed.append(entry)

        return {"expired": expired, "promoted": promoted, "decayed": decayed}

    # -- promotion -----------------------------------------------------------

    def promote_eligible(
        self,
        entries: list[dict[str, Any]],
        current_time: datetime | None = None,
    ) -> list[dict[str, Any]]:
        """Find entries eligible for promotion and promote them in-place.

        Promotion means moving the entry to the next horizon in the chain.

        Args:
            entries: List of entry dicts (mutated in-place on promotion).
            current_time: Reference time.

        Returns:
            The list of entries that were promoted.
        """
        now = current_time or datetime.now(tz=UTC)
        promoted: list[dict[str, Any]] = []

        for entry in entries:
            horizon: TimeHorizon = entry.get("horizon", TimeHorizon.TURN_LEVEL)
            policy = self._policies.get(horizon)
            if policy is None:
                continue
            if policy.auto_promote_after is None:
                continue

            age = _entry_age(entry, now)
            if age > policy.auto_promote_after:
                nxt = _next_horizon(horizon)
                if nxt is not None:
                    entry["horizon"] = nxt
                    promoted.append(entry)

        return promoted

    # -- decay ---------------------------------------------------------------

    def apply_decay(
        self,
        entries: list[dict[str, Any]],
        current_time: datetime | None = None,
    ) -> int:
        """Apply confidence decay to entries based on their horizon's rate.

        Decay uses the formula ``confidence * e^(-rate * age_seconds)``.

        Args:
            entries: List of entry dicts (mutated in-place).
            current_time: Reference time.

        Returns:
            Number of entries whose confidence was changed.
        """
        now = current_time or datetime.now(tz=UTC)
        count = 0

        for entry in entries:
            horizon: TimeHorizon = entry.get("horizon", TimeHorizon.TURN_LEVEL)
            policy = self._policies.get(horizon)
            if policy is None or policy.decay_rate <= 0:
                continue

            age = _entry_age(entry, now)
            old_conf = entry.get("confidence", 1.0)
            new_conf = old_conf * math.exp(-policy.decay_rate * age)
            new_conf = max(new_conf, 0.0)
            if abs(new_conf - old_conf) > 1e-9:
                entry["confidence"] = round(new_conf, 6)
                count += 1

        return count

    # -- statistics ----------------------------------------------------------

    def stats(self, entries: list[dict[str, Any]]) -> dict[str, int]:
        """Entry count per horizon.

        Args:
            entries: List of entry dicts.

        Returns:
            Mapping from horizon value (str) to count.
        """
        counts: dict[str, int] = {h.value: 0 for h in TimeHorizon}
        for entry in entries:
            h: TimeHorizon = entry.get("horizon", TimeHorizon.TURN_LEVEL)
            counts[h.value] = counts.get(h.value, 0) + 1
        return counts

    def summary(self) -> dict[str, Any]:
        """Return a human-readable summary of all configured policies.

        Returns:
            Dict keyed by horizon value, each containing the policy fields.
        """
        result: dict[str, Any] = {}
        for horizon in TimeHorizon:
            policy = self._policies.get(horizon)
            if policy is None:
                result[horizon.value] = {"configured": False}
            else:
                result[horizon.value] = {
                    "max_age_seconds": policy.max_age_seconds,
                    "max_entries": policy.max_entries,
                    "auto_promote_after": policy.auto_promote_after,
                    "decay_rate": policy.decay_rate,
                    "priority": policy.priority,
                }
        return result
