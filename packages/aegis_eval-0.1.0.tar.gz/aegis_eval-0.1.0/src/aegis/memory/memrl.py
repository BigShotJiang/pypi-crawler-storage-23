"""MemRL: Memory Reinforcement Learning module.

Implements runtime Q-value updates for memory operations based on
production feedback.  Extends base Q-learning with Two-Speed Learning
(MemRL, Jan 2026): two-phase retrieval, experience bank, runtime
learning loop, and strategy learner.
"""

from __future__ import annotations

import hashlib
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class MemoryUtility:
    """Utility tracking for a memory entry."""

    key: str
    q_value: float = 0.5
    access_count: int = 0
    useful_count: int = 0
    last_accessed: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    last_feedback: float = 0.0
    history: list[float] = field(default_factory=list)


@dataclass
class FeedbackRecord:
    """Record of production feedback for a memory interaction."""

    id: str = ""
    memory_key: str = ""
    operation: str = ""
    feedback_score: float = 0.0
    context: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


class MemRLUpdater:
    """Updates memory utility Q-values from production feedback.

    Uses exponential moving average (EMA) to update Q-values:
    Q(s,a) = Q(s,a) + alpha * (reward - Q(s,a))
    """

    def __init__(
        self,
        learning_rate: float = 0.1,
        discount_factor: float = 0.95,
        min_q: float = 0.0,
        max_q: float = 1.0,
    ) -> None:
        self._lr = learning_rate
        self._gamma = discount_factor
        self._min_q = min_q
        self._max_q = max_q
        self._utilities: dict[str, MemoryUtility] = {}
        self._feedback_log: list[FeedbackRecord] = []
        self._operation_stats: dict[str, dict[str, int]] = defaultdict(
            lambda: {"total": 0, "useful": 0}
        )

    def get_utility(self, key: str) -> MemoryUtility:
        """Get or create utility tracking for a memory key."""
        if key not in self._utilities:
            self._utilities[key] = MemoryUtility(key=key)
        return self._utilities[key]

    def record_access(self, key: str, operation: str = "RETRIEVE") -> MemoryUtility:
        """Record that a memory entry was accessed."""
        util = self.get_utility(key)
        util.access_count += 1
        util.last_accessed = datetime.now(tz=UTC)
        self._operation_stats[operation]["total"] += 1
        return util

    def update(
        self,
        key: str,
        feedback_score: float,
        operation: str = "RETRIEVE",
        context: dict[str, Any] | None = None,
    ) -> MemoryUtility:
        """Update Q-value for a memory entry based on feedback."""
        util = self.get_utility(key)
        old_q = util.q_value
        util.q_value = old_q + self._lr * (feedback_score - old_q)
        util.q_value = max(self._min_q, min(self._max_q, util.q_value))
        util.last_feedback = feedback_score
        util.history.append(feedback_score)
        if feedback_score >= 0.5:
            util.useful_count += 1
            self._operation_stats[operation]["useful"] += 1
        self._feedback_log.append(
            FeedbackRecord(
                memory_key=key,
                operation=operation,
                feedback_score=feedback_score,
                context=context or {},
            )
        )
        return util

    def batch_update(self, feedbacks: list[dict[str, Any]]) -> list[MemoryUtility]:
        """Batch update Q-values from multiple feedback records."""
        results = []
        for fb in feedbacks:
            util = self.update(
                key=fb["key"],
                feedback_score=fb.get("score", 0.5),
                operation=fb.get("operation", "RETRIEVE"),
                context=fb.get("context"),
            )
            results.append(util)
        return results

    def top_k(self, k: int = 10) -> list[MemoryUtility]:
        """Return the top-k highest utility memory entries."""
        sorted_utils = sorted(self._utilities.values(), key=lambda u: u.q_value, reverse=True)
        return sorted_utils[:k]

    def low_utility(self, threshold: float = 0.2) -> list[MemoryUtility]:
        """Return entries with Q-value below threshold (candidates for forgetting)."""
        return [u for u in self._utilities.values() if u.q_value < threshold]

    def decay_unused(self, decay_rate: float = 0.01, min_idle_accesses: int = 0) -> int:
        """Decay Q-values for entries that haven't been accessed recently."""
        decayed = 0
        for util in self._utilities.values():
            if util.access_count <= min_idle_accesses:
                old_q = util.q_value
                util.q_value = max(self._min_q, util.q_value - decay_rate)
                if util.q_value < old_q:
                    decayed += 1
        return decayed

    def feedback_log(self, limit: int = 100) -> list[FeedbackRecord]:
        """Return recent feedback records."""
        return self._feedback_log[-limit:]

    def operation_stats(self) -> dict[str, dict[str, Any]]:
        """Return per-operation effectiveness statistics."""
        stats: dict[str, dict[str, Any]] = {}
        for op, counts in self._operation_stats.items():
            total = counts["total"]
            useful = counts["useful"]
            stats[op] = {
                "total": total,
                "useful": useful,
                "effectiveness": round(useful / total, 4) if total > 0 else 0.0,
            }
        return stats

    def summary(self) -> dict[str, Any]:
        """Return MemRL summary statistics."""
        all_q = [u.q_value for u in self._utilities.values()]
        return {
            "total_entries": len(self._utilities),
            "total_feedback": len(self._feedback_log),
            "mean_q_value": round(sum(all_q) / len(all_q), 4) if all_q else 0.0,
            "min_q_value": round(min(all_q), 4) if all_q else 0.0,
            "max_q_value": round(max(all_q), 4) if all_q else 0.0,
            "operation_stats": self.operation_stats(),
        }


# ---------------------------------------------------------------------------
# Two-Phase Retrieval (MemRL Two-Speed Learning)
# ---------------------------------------------------------------------------


def _tokenize(text: str) -> set[str]:
    """Tokenize text into lowercase word tokens (length > 1)."""
    return {w for w in text.lower().split() if len(w) > 1}


def _jaccard_similarity(set_a: set[str], set_b: set[str]) -> float:
    """Compute Jaccard similarity between two token sets."""
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


class TwoPhaseRetriever:
    """Two-phase retrieval: semantic filter then utility-based selection.

    Phase 1 filters by Jaccard word overlap (proxy for embedding similarity).
    Phase 2 ranks the filtered set by learned Q-value utility scores.
    """

    def semantic_filter(
        self, query: str, candidates: list[MemoryUtility], top_k: int = 50
    ) -> list[MemoryUtility]:
        """Filter candidates by word-overlap relevance to *query*."""
        query_tokens = _tokenize(query)
        scored: list[tuple[float, MemoryUtility]] = []
        for c in candidates:
            sim = _jaccard_similarity(query_tokens, _tokenize(c.key))
            scored.append((sim + min(len(c.history) * 0.01, 0.1), c))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [s[1] for s in scored[:top_k]]

    def utility_select(self, filtered: list[MemoryUtility], top_k: int = 10) -> list[MemoryUtility]:
        """Select top candidates from a pre-filtered list by Q-value."""
        return sorted(filtered, key=lambda u: u.q_value, reverse=True)[:top_k]

    def retrieve(
        self, query: str, candidates: list[MemoryUtility], top_k: int = 10
    ) -> list[MemoryUtility]:
        """Combined two-phase retrieval: semantic filter then utility select."""
        pool = min(max(top_k * 5, 50), len(candidates))
        filtered = self.semantic_filter(query, candidates, top_k=pool)
        return self.utility_select(filtered, top_k=top_k)


# ---------------------------------------------------------------------------
# Experience Bank
# ---------------------------------------------------------------------------


@dataclass
class InteractionExperience:
    """A single interaction experience with outcome tracking."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    query: str = ""
    retrieved_keys: list[str] = field(default_factory=list)
    outcome_score: float = 0.0
    memory_ops_performed: list[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    context: dict[str, Any] = field(default_factory=dict)


class ExperienceBank:
    """Stores interaction experiences with outcomes for runtime learning.

    Accumulates records of past interactions — queries, retrieved memories,
    and success scores — to drive batch learning updates.
    """

    def __init__(self, max_size: int = 10_000) -> None:
        self._experiences: list[InteractionExperience] = []
        self._max_size = max_size

    def add(self, experience: InteractionExperience) -> None:
        """Add an interaction experience to the bank."""
        self._experiences.append(experience)
        if len(self._experiences) > self._max_size:
            self._experiences = self._experiences[-self._max_size :]

    def get_recent(self, limit: int = 100) -> list[InteractionExperience]:
        """Get the most recent interaction experiences."""
        return self._experiences[-limit:]

    def get_by_query_similarity(self, query: str, top_k: int = 5) -> list[InteractionExperience]:
        """Find past experiences with queries similar to *query*."""
        qt = _tokenize(query)
        scored = [(_jaccard_similarity(qt, _tokenize(e.query)), e) for e in self._experiences]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [s[1] for s in scored[:top_k]]

    def compute_operation_effectiveness(self) -> dict[str, float]:
        """Compute per-operation average outcome scores."""
        op_scores: dict[str, list[float]] = defaultdict(list)
        for exp in self._experiences:
            for op in exp.memory_ops_performed:
                op_scores[op].append(exp.outcome_score)
        return {op: round(sum(s) / len(s), 4) if s else 0.0 for op, s in op_scores.items()}

    def summary(self) -> dict[str, Any]:
        """Return summary statistics for the experience bank."""
        total = len(self._experiences)
        scores = [e.outcome_score for e in self._experiences]
        return {
            "total_experiences": total,
            "mean_outcome": round(sum(scores) / total, 4) if total else 0.0,
            "min_outcome": round(min(scores), 4) if scores else 0.0,
            "max_outcome": round(max(scores), 4) if scores else 0.0,
            "operation_effectiveness": self.compute_operation_effectiveness(),
        }


# ---------------------------------------------------------------------------
# Runtime Learning Loop
# ---------------------------------------------------------------------------


class RuntimeLearner:
    """Automatically updates Q-values after each production interaction.

    Bridges the experience bank and the MemRL updater so that every
    completed interaction feeds back into utility scores.
    """

    def __init__(
        self,
        updater: MemRLUpdater,
        experience_bank: ExperienceBank,
        retriever: TwoPhaseRetriever,
    ) -> None:
        self._updater = updater
        self._bank = experience_bank
        self._retriever = retriever
        self._interaction_count: int = 0
        self._total_outcome: float = 0.0

    def on_interaction_complete(
        self,
        query: str,
        retrieved_keys: list[str],
        outcome_score: float,
        ops_performed: list[str],
    ) -> InteractionExperience:
        """Main hook called after each production interaction completes."""
        experience = InteractionExperience(
            query=query,
            retrieved_keys=retrieved_keys,
            outcome_score=outcome_score,
            memory_ops_performed=ops_performed,
        )
        self._bank.add(experience)
        for key in retrieved_keys:
            for op in ops_performed:
                self._updater.record_access(key, operation=op)
            self._updater.update(
                key=key,
                feedback_score=outcome_score,
                operation=ops_performed[0] if ops_performed else "RETRIEVE",
            )
        self._interaction_count += 1
        self._total_outcome += outcome_score
        return experience

    def on_user_feedback(self, memory_key: str, feedback: str, score: float) -> MemoryUtility:
        """Process explicit user feedback for a specific memory entry."""
        return self._updater.update(
            key=memory_key,
            feedback_score=score,
            operation="USER_FEEDBACK",
            context={"feedback_text": feedback, "explicit": True},
        )

    def update_from_experience_bank(self, batch_size: int = 32) -> int:
        """Batch update Q-values from accumulated experiences (experience replay)."""
        recent = self._bank.get_recent(limit=batch_size)
        count = 0
        for exp in recent:
            for key in exp.retrieved_keys:
                self._updater.update(
                    key=key,
                    feedback_score=exp.outcome_score,
                    operation=exp.memory_ops_performed[0]
                    if exp.memory_ops_performed
                    else "RETRIEVE",
                    context={"replay": True, "original_query": exp.query},
                )
                count += 1
        return count

    def get_memory_recommendations(
        self, top_promote: int = 5, top_forget: int = 5
    ) -> dict[str, list[MemoryUtility]]:
        """Recommend memories for promotion or forgetting based on utility."""
        promote = self._updater.top_k(k=top_promote)
        forget = sorted(self._updater.low_utility(threshold=0.2), key=lambda u: u.q_value)[
            :top_forget
        ]
        return {"promote": promote, "forget": forget}

    def summary(self) -> dict[str, Any]:
        """Return runtime learner summary statistics."""
        return {
            "interaction_count": self._interaction_count,
            "mean_outcome": (
                round(self._total_outcome / self._interaction_count, 4)
                if self._interaction_count
                else 0.0
            ),
            "experience_bank": self._bank.summary(),
            "updater": self._updater.summary(),
        }


# ---------------------------------------------------------------------------
# Strategy Learner
# ---------------------------------------------------------------------------


def _context_hash(context: dict[str, Any]) -> str:
    """Produce a stable hash from a context dict for bucketing."""
    raw = str(sorted(context.items()))
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


class StrategyLearner:
    """Learns which memory operation strategies work best per context.

    Tracks strategy-outcome pairs bucketed by context hash so the system
    can recommend the most effective strategy for a given situation.
    """

    def __init__(self) -> None:
        self._strategy_outcomes: dict[str, list[float]] = defaultdict(list)
        self._context_strategy_outcomes: dict[str, dict[str, list[float]]] = defaultdict(
            lambda: defaultdict(list)
        )

    def record_strategy(self, context: dict[str, Any], strategy: str, outcome: float) -> None:
        """Record the outcome of a strategy applied in a given context."""
        self._strategy_outcomes[strategy].append(outcome)
        self._context_strategy_outcomes[_context_hash(context)][strategy].append(outcome)

    def recommend_strategy(self, context: dict[str, Any]) -> str:
        """Recommend the best strategy for a given context."""
        ctx_key = _context_hash(context)
        if ctx_key in self._context_strategy_outcomes:
            best, best_score = "", -1.0
            for strat, scores in self._context_strategy_outcomes[ctx_key].items():
                if len(scores) >= 2:
                    mean = sum(scores) / len(scores)
                    if mean > best_score:
                        best_score, best = mean, strat
            if best:
                return best
        return self._global_best_strategy()

    def _global_best_strategy(self) -> str:
        """Return the globally best-performing strategy."""
        if not self._strategy_outcomes:
            return "default"
        best, best_score = "default", -1.0
        for strat, scores in self._strategy_outcomes.items():
            mean = sum(scores) / len(scores) if scores else 0.0
            if mean > best_score:
                best_score, best = mean, strat
        return best

    def strategy_effectiveness(self) -> dict[str, float]:
        """Compute mean outcome score per strategy across all contexts."""
        return {
            s: round(sum(sc) / len(sc), 4) if sc else 0.0
            for s, sc in self._strategy_outcomes.items()
        }
