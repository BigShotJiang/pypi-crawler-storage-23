"""Memory decay engine -- sophisticated forgetting with real math.

Implements exponential, linear, power-law (Ebbinghaus-inspired), and step
decay functions.  Access frequency provides a natural counter-force to
forgetting: more-accessed entries decay slower.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from aegis.core.types import MemoryTier

# ---------------------------------------------------------------------------
# Enum
# ---------------------------------------------------------------------------


class DecayFunction(str, Enum):
    """Available decay curve shapes."""

    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    STEP = "step"
    POWER_LAW = "power_law"
    NONE = "none"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class DecayConfig:
    """Configuration for the decay engine.

    Attributes:
        function: Which decay function to use.
        rate: The primary decay rate parameter (interpretation varies by
            function).
        half_life_seconds: For :attr:`DecayFunction.STEP`, the interval
            between discrete decay steps.  Also used by exponential as an
            alternative parameterisation (when *rate* is ``0``).
        min_confidence: Floor below which an entry is considered expired.
        exempt_tiers: Memory tiers exempt from decay (e.g. permanent
            knowledge should not be forgotten).
    """

    function: DecayFunction = DecayFunction.EXPONENTIAL
    rate: float = 0.0001
    half_life_seconds: int | None = None
    min_confidence: float = 0.05
    exempt_tiers: list[MemoryTier] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


class DecayEngine:
    """Applies configurable decay to memory entries.

    Access frequency slows decay: each retrieval adds a logarithmic bonus
    that stretches the effective half-life, modelling the spacing effect
    from cognitive psychology.

    Args:
        config: Decay configuration.  When ``None``, a sensible default
            (exponential with rate 0.0001) is used.
    """

    def __init__(self, config: DecayConfig | None = None) -> None:
        self._config = config or DecayConfig()

    # -- public API ----------------------------------------------------------

    def compute_decay(
        self,
        entry_age_seconds: float,
        access_count: int,
        current_confidence: float,
    ) -> float:
        """Compute the new confidence for a single entry after decay.

        The access bonus is ``log2(1 + access_count)`` and acts as a
        multiplier on the effective half-life (or divisor on rate),
        meaning more-accessed memories decay slower.

        Args:
            entry_age_seconds: Age of the entry in seconds.
            access_count: Number of times the entry has been retrieved.
            current_confidence: The entry's confidence before this decay
                application.

        Returns:
            The new confidence, floored at :attr:`DecayConfig.min_confidence`
            (or ``0.0`` if decay function is :attr:`DecayFunction.NONE`).
        """
        cfg = self._config

        if cfg.function == DecayFunction.NONE:
            return current_confidence

        access_bonus = math.log2(1 + max(access_count, 0))

        if cfg.function == DecayFunction.EXPONENTIAL:
            rate = self._effective_rate(cfg.rate, cfg.half_life_seconds)
            new = self._exponential_decay(entry_age_seconds, rate, access_bonus)
        elif cfg.function == DecayFunction.LINEAR:
            rate = self._effective_rate(cfg.rate, cfg.half_life_seconds)
            new = self._linear_decay(entry_age_seconds, rate, access_bonus)
        elif cfg.function == DecayFunction.POWER_LAW:
            rate = self._effective_rate(cfg.rate, cfg.half_life_seconds)
            new = self._power_law_decay(entry_age_seconds, rate, access_bonus)
        elif cfg.function == DecayFunction.STEP:
            half_life = cfg.half_life_seconds or 3600
            new = self._step_decay(entry_age_seconds, half_life)
        else:
            new = current_confidence

        # Scale by current confidence.
        result = current_confidence * new
        return max(result, cfg.min_confidence)

    def apply_decay_batch(
        self,
        entries: list[dict[str, Any]],
        current_time: datetime | None = None,
    ) -> dict[str, int]:
        """Apply decay to all entries in-place.

        Each entry dict must contain at minimum ``created_at`` (datetime),
        ``access_count`` (int), ``confidence`` (float), and optionally
        ``tier`` (:class:`MemoryTier`).

        Args:
            entries: List of entry dicts.
            current_time: Reference time.

        Returns:
            Dict with counts: ``decayed``, ``expired`` (below
            min_confidence), ``exempt`` (in exempt tiers).
        """
        now = current_time or datetime.now(tz=UTC)
        decayed = 0
        expired = 0
        exempt = 0

        for entry in entries:
            # Check tier exemption.
            tier = entry.get("tier")
            if tier is not None and tier in self._config.exempt_tiers:
                exempt += 1
                continue

            created = entry.get("created_at")
            if created is None:
                continue
            if created.tzinfo is None:
                created = created.replace(tzinfo=UTC)
            if now.tzinfo is None:
                now = now.replace(tzinfo=UTC)

            age = max((now - created).total_seconds(), 0.0)
            access_count = entry.get("access_count", 0)
            old_conf = entry.get("confidence", 1.0)

            new_conf = self.compute_decay(age, access_count, old_conf)

            if abs(new_conf - old_conf) > 1e-9:
                entry["confidence"] = round(new_conf, 6)
                decayed += 1

            if new_conf <= self._config.min_confidence:
                expired += 1

        return {"decayed": decayed, "expired": expired, "exempt": exempt}

    def predict_expiry(
        self,
        current_confidence: float,
        access_count: int,
    ) -> float | None:
        """Predict seconds until an entry reaches min_confidence.

        Only works for exponential and linear functions; returns ``None``
        for step and power-law (where analytical inversion is non-trivial
        or the entry may never technically expire).

        Args:
            current_confidence: The entry's current confidence.
            access_count: Number of accesses.

        Returns:
            Estimated seconds to expiry, or ``None`` if not computable.
        """
        cfg = self._config

        if cfg.function == DecayFunction.NONE:
            return None

        if current_confidence <= cfg.min_confidence:
            return 0.0

        access_bonus = math.log2(1 + max(access_count, 0))
        rate = self._effective_rate(cfg.rate, cfg.half_life_seconds)

        if cfg.function == DecayFunction.EXPONENTIAL:
            # confidence * e^(-rate / (1 + bonus) * t) = min_confidence
            # => t = -ln(min / confidence) * (1 + bonus) / rate
            effective_rate = rate / (1.0 + access_bonus)
            if effective_rate <= 0:
                return None
            ratio = cfg.min_confidence / current_confidence
            if ratio >= 1.0:
                return 0.0
            return -math.log(ratio) / effective_rate

        if cfg.function == DecayFunction.LINEAR:
            # confidence * max(0, 1 - rate / (1 + bonus) * t) = min_confidence
            # => t = (1 - min / confidence) * (1 + bonus) / rate
            effective_rate = rate / (1.0 + access_bonus)
            if effective_rate <= 0:
                return None
            ratio = cfg.min_confidence / current_confidence
            if ratio >= 1.0:
                return 0.0
            return (1.0 - ratio) / effective_rate

        # Power-law and step don't have clean inversions in closed form.
        return None

    def summary(self) -> dict[str, Any]:
        """Return a summary of the decay configuration.

        Returns:
            Dict with all configuration parameters.
        """
        return {
            "function": self._config.function.value,
            "rate": self._config.rate,
            "half_life_seconds": self._config.half_life_seconds,
            "min_confidence": self._config.min_confidence,
            "exempt_tiers": [t.value for t in self._config.exempt_tiers],
        }

    # -- decay functions (static) --------------------------------------------

    @staticmethod
    def _exponential_decay(age: float, rate: float, access_bonus: float) -> float:
        """Exponential decay: ``e^(-rate * t / (1 + bonus))``.

        More accesses slow the effective rate by stretching the exponent.
        """
        effective_rate = rate / (1.0 + access_bonus)
        return math.exp(-effective_rate * age)

    @staticmethod
    def _linear_decay(age: float, rate: float, access_bonus: float) -> float:
        """Linear decay: ``max(0, 1 - rate * t / (1 + bonus))``.

        Confidence drops linearly to zero; access bonus stretches the
        timeline.
        """
        effective_rate = rate / (1.0 + access_bonus)
        return max(0.0, 1.0 - effective_rate * age)

    @staticmethod
    def _power_law_decay(age: float, rate: float, access_bonus: float) -> float:
        """Power-law (Ebbinghaus) decay: ``(1 + t)^(-alpha / (1 + bonus))``.

        This approximates the Ebbinghaus forgetting curve ``R = e^(-t/S)``
        using a power-law form that produces the characteristic rapid initial
        forgetting followed by a long tail.  The ``rate`` parameter acts as
        the exponent alpha.
        """
        alpha = rate / (1.0 + access_bonus)
        # Guard against negative or zero age.
        t = max(age, 0.0)
        return math.pow(1.0 + t, -alpha)

    @staticmethod
    def _step_decay(age: float, half_life: float) -> float:
        """Step decay: discrete halving at each half-life interval.

        After *n* half-lives the retained fraction is ``0.5^n``.
        """
        if half_life <= 0:
            return 1.0
        n_half_lives = age / half_life
        return math.pow(0.5, n_half_lives)

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _effective_rate(rate: float, half_life: int | None) -> float:
        """Derive rate from half_life if rate is zero and half_life is given."""
        if rate > 0:
            return rate
        if half_life is not None and half_life > 0:
            # For exponential: rate = ln(2) / half_life
            return math.log(2) / half_life
        return 0.0001  # safe fallback
