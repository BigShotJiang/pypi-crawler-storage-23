"""Memory interference detection.

Detects when memories from different domains or contexts interfere
with each other, causing confusion or incorrect retrieval.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any

from aegis.memory.types import MemoryEntry


@dataclass
class InterferenceResult:
    """Result of an interference detection check."""

    pair: tuple[str, str]  # (key_a, key_b)
    interference_type: (
        str  # "key_collision", "semantic_overlap", "temporal_conflict", "domain_cross"
    )
    severity: str = "low"  # "low", "medium", "high"
    score: float = 0.0  # 0-1, how severe
    details: dict[str, Any] = field(default_factory=dict)


class InterferenceDetector:
    """Detects memory interference patterns.

    Checks for:
    - Key collision: Different entries with similar keys storing different values
    - Semantic overlap: Entries with high content similarity but different metadata
    - Temporal conflict: Entries valid in overlapping time periods with conflicting values
    - Cross-domain interference: Entries from different domains that may confuse retrieval
    """

    def __init__(
        self,
        similarity_threshold: float = 0.7,
        key_similarity_threshold: float = 0.8,
    ) -> None:
        self._similarity_threshold = similarity_threshold
        self._key_threshold = key_similarity_threshold

    def detect(self, entries: list[MemoryEntry]) -> list[InterferenceResult]:
        """Run all interference checks on a list of memory entries."""
        results: list[InterferenceResult] = []
        results.extend(self._check_key_collisions(entries))
        results.extend(self._check_semantic_overlap(entries))
        results.extend(self._check_temporal_conflicts(entries))
        results.extend(self._check_domain_cross(entries))
        return results

    def _check_key_collisions(self, entries: list[MemoryEntry]) -> list[InterferenceResult]:
        """Detect entries with similar keys but different values."""
        results: list[InterferenceResult] = []
        for i in range(len(entries)):
            for j in range(i + 1, min(i + 30, len(entries))):
                key_sim = SequenceMatcher(None, entries[i].key, entries[j].key).ratio()
                if key_sim >= self._key_threshold and entries[i].key != entries[j].key:
                    val_sim = SequenceMatcher(
                        None, str(entries[i].value)[:200], str(entries[j].value)[:200]
                    ).ratio()
                    if val_sim < 0.5:  # Different values with similar keys
                        severity = "high" if key_sim > 0.9 else "medium"
                        results.append(
                            InterferenceResult(
                                pair=(entries[i].key, entries[j].key),
                                interference_type="key_collision",
                                severity=severity,
                                score=round(key_sim, 4),
                                details={
                                    "key_similarity": round(key_sim, 4),
                                    "value_similarity": round(val_sim, 4),
                                },
                            )
                        )
        return results

    def _check_semantic_overlap(self, entries: list[MemoryEntry]) -> list[InterferenceResult]:
        """Detect entries with high content similarity but different tiers/tags."""
        results: list[InterferenceResult] = []
        for i in range(len(entries)):
            for j in range(i + 1, min(i + 30, len(entries))):
                val_i = str(entries[i].value).lower()[:200]
                val_j = str(entries[j].value).lower()[:200]
                if len(val_i) < 20 or len(val_j) < 20:
                    continue
                sim = SequenceMatcher(None, val_i, val_j).ratio()
                if sim >= self._similarity_threshold:
                    # Check if they have different tiers or tags
                    diff_tier = entries[i].tier != entries[j].tier
                    diff_tags = set(entries[i].tags) != set(entries[j].tags)
                    if diff_tier or diff_tags:
                        results.append(
                            InterferenceResult(
                                pair=(entries[i].key, entries[j].key),
                                interference_type="semantic_overlap",
                                severity="medium",
                                score=round(sim, 4),
                                details={
                                    "similarity": round(sim, 4),
                                    "tier_mismatch": diff_tier,
                                    "tag_mismatch": diff_tags,
                                },
                            )
                        )
        return results

    def _check_temporal_conflicts(self, entries: list[MemoryEntry]) -> list[InterferenceResult]:
        """Detect entries with overlapping temporal bounds and conflicting values."""
        results: list[InterferenceResult] = []
        temporal_entries = [e for e in entries if e.temporal_bounds is not None]

        for i in range(len(temporal_entries)):
            for j in range(i + 1, len(temporal_entries)):
                a, b = temporal_entries[i], temporal_entries[j]
                tb_a, tb_b = a.temporal_bounds, b.temporal_bounds
                if tb_a is None or tb_b is None:
                    continue

                # Check temporal overlap
                a_end = tb_a.valid_to or tb_a.valid_from
                b_end = tb_b.valid_to or tb_b.valid_from
                overlaps = tb_a.valid_from <= b_end and tb_b.valid_from <= a_end

                if overlaps:
                    val_sim = SequenceMatcher(None, str(a.value)[:200], str(b.value)[:200]).ratio()
                    if val_sim < 0.5:  # Different values in overlapping period
                        results.append(
                            InterferenceResult(
                                pair=(a.key, b.key),
                                interference_type="temporal_conflict",
                                severity="high",
                                score=round(1.0 - val_sim, 4),
                                details={"value_divergence": round(1.0 - val_sim, 4)},
                            )
                        )
        return results

    def _check_domain_cross(self, entries: list[MemoryEntry]) -> list[InterferenceResult]:
        """Detect cross-domain interference via tag-based domain grouping."""
        results: list[InterferenceResult] = []

        # Group by first tag as domain proxy
        domain_groups: dict[str, list[MemoryEntry]] = defaultdict(list)
        for entry in entries:
            domain = entry.tags[0] if entry.tags else "general"
            domain_groups[domain].append(entry)

        domains = list(domain_groups.keys())
        for i in range(len(domains)):
            for j in range(i + 1, len(domains)):
                group_a = domain_groups[domains[i]]
                group_b = domain_groups[domains[j]]
                # Check if any entries across domains have high similarity
                for a in group_a[:10]:
                    for b in group_b[:10]:
                        sim = SequenceMatcher(
                            None, str(a.value).lower()[:200], str(b.value).lower()[:200]
                        ).ratio()
                        if sim >= self._similarity_threshold:
                            results.append(
                                InterferenceResult(
                                    pair=(a.key, b.key),
                                    interference_type="domain_cross",
                                    severity="low",
                                    score=round(sim, 4),
                                    details={
                                        "domain_a": domains[i],
                                        "domain_b": domains[j],
                                        "similarity": round(sim, 4),
                                    },
                                )
                            )
        return results

    def summary(self, results: list[InterferenceResult]) -> dict[str, Any]:
        """Summarize interference detection results."""
        by_type: dict[str, int] = defaultdict(int)
        by_severity: dict[str, int] = defaultdict(int)
        for r in results:
            by_type[r.interference_type] += 1
            by_severity[r.severity] += 1

        return {
            "total_interferences": len(results),
            "by_type": dict(by_type),
            "by_severity": dict(by_severity),
            "highest_severity": max(
                (r.severity for r in results),
                key=lambda s: {"low": 0, "medium": 1, "high": 2}.get(s, 0),
                default="none",
            )
            if results
            else "none",
        }
