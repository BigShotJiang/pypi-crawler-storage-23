"""Unified MemoryManager facade for the Aegis memory subsystem.

Composes all subsystems -- event log, temporal index, knowledge graph,
vector store, provenance tracker, snapshot reconstructor, and policy
engine -- into a single entry point with cross-cutting concerns
(event logging, temporal indexing, vector indexing, provenance tracking).
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from aegis.core.types import MemoryEventV1, MemoryOperation, MemoryTier, TemporalBounds
from aegis.memory.event_log import EventLog
from aegis.memory.graph import KnowledgeGraph
from aegis.memory.operations import MemoryPolicyEngine
from aegis.memory.provenance import ProvenanceTracker
from aegis.memory.snapshot import MemorySnapshotData, SnapshotReconstructor
from aegis.memory.store import InMemoryStore
from aegis.memory.temporal import TemporalIndex
from aegis.memory.types import MemoryEntry, MemoryStore
from aegis.memory.vector import VectorStore

# ---------------------------------------------------------------------------
# Poison-detection patterns
# ---------------------------------------------------------------------------

_POISON_PATTERNS = [
    r"ignore\s+(previous|all)\s+instructions",
    r"system\s*prompt",
    r"<script\b",
    r";\s*DROP\s+TABLE",
    r"override\s+(safety|policy|rules)",
]


class MemoryManager:
    """Unified facade over all Aegis memory subsystems.

    Wraps every operation with cross-cutting concerns: event-log
    recording, temporal-index updates, vector-store indexing, and
    provenance tracking.

    Args:
        store: Optional :class:`MemoryStore` backend.  When ``None``
            (the default), an :class:`InMemoryStore` is created.
        enable_vectors: Whether to enable vector embeddings in the
            :class:`VectorStore`.
    """

    def __init__(
        self,
        store: MemoryStore | None = None,
        graph: KnowledgeGraph | None = None,
        enable_vectors: bool = True,
    ) -> None:
        self._store: MemoryStore = store if store is not None else InMemoryStore()
        self._event_log = EventLog()
        self._temporal = TemporalIndex()
        self._graph = graph if graph is not None else KnowledgeGraph()
        self._vector = VectorStore(enable_embeddings=enable_vectors)
        self._provenance = ProvenanceTracker()
        self._snapshot = SnapshotReconstructor(self._event_log)
        self._policy = MemoryPolicyEngine(
            self._store,
            graph=self._graph,
            provenance=self._provenance,
        )

    # -- helpers -------------------------------------------------------------

    def _make_event(
        self,
        operation: MemoryOperation,
        key: str,
        value: Any = None,
        tier: MemoryTier = MemoryTier.WORKING,
        agent_id: str = "",
        customer_id: str = "",
        confidence: float = 1.0,
        provenance: dict[str, Any] | None = None,
        temporal_bounds: TemporalBounds | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEventV1:
        """Create a :class:`MemoryEventV1` with sensible defaults."""
        return MemoryEventV1(
            operation=operation,
            memory_tier=tier,
            key=key,
            value=value,
            provenance=provenance or {},
            temporal_bounds=temporal_bounds,
            agent_id=agent_id,
            customer_id=customer_id,
            confidence=confidence,
            metadata=metadata or {},
        )

    def _detect_poison(self, value: Any) -> tuple[bool, str]:
        """Check *value* against known prompt-injection patterns.

        Returns:
            A ``(detected, reason)`` tuple.
        """
        text = str(value).lower()
        for pattern in _POISON_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return True, f"Matched poison pattern: {pattern}"
        return False, ""

    # -- 12 operations -------------------------------------------------------

    def store(
        self,
        key: str,
        value: Any,
        tier: MemoryTier = MemoryTier.WORKING,
        provenance: dict[str, Any] | None = None,
        temporal_bounds: TemporalBounds | None = None,
        confidence: float = 1.0,
        tags: list[str] | None = None,
        agent_id: str = "",
        customer_id: str = "",
    ) -> MemoryEntry:
        """Store a new memory entry with full cross-cutting concerns.

        Poison detection is applied to *value*: if a match is found the
        entry is still stored but with ``confidence`` lowered to ``0.1``
        and poison metadata attached.

        Args:
            key: Unique key for the entry.
            value: Content to store.
            tier: Initial memory tier.
            provenance: Source-attribution metadata.
            temporal_bounds: Optional time-validity window.
            confidence: Confidence score in [0.0, 1.0].
            tags: Free-form tags.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            The newly created :class:`MemoryEntry`.
        """
        # Poison detection.
        poisoned, reason = self._detect_poison(value)
        meta: dict[str, Any] = {}
        if poisoned:
            meta["poisoned"] = True
            meta["poison_reason"] = reason
            confidence = 0.1

        # Delegate to policy engine for storage.
        entry = self._policy.store(key, value, tier)

        # Apply additional fields the policy engine doesn't set.
        entry.confidence = confidence
        entry.provenance = provenance or {}
        entry.temporal_bounds = temporal_bounds
        entry.tags = tags or []
        entry.metadata.update(meta)

        # Vector-store indexing.
        self._vector.add(entry)

        # Temporal index.
        if temporal_bounds is not None:
            self._temporal.add(
                key,
                valid_from=temporal_bounds.valid_from,
                valid_to=temporal_bounds.valid_to,
            )

        # Provenance tracking.
        self._provenance.record(
            entry_key=key,
            source_type=provenance.get("source_type", "unknown") if provenance else "unknown",
            source_ref=provenance.get("source_ref", "") if provenance else "",
            operation=MemoryOperation.STORE,
            confidence=confidence,
        )

        # Event log.
        event = self._make_event(
            operation=MemoryOperation.STORE,
            key=key,
            value=value,
            tier=tier,
            agent_id=agent_id,
            customer_id=customer_id,
            confidence=confidence,
            provenance=provenance,
            temporal_bounds=temporal_bounds,
            metadata=meta,
        )
        self._event_log.append(event)

        return entry

    def retrieve(self, key: str, agent_id: str = "", customer_id: str = "") -> MemoryEntry | None:
        """Retrieve a memory entry by key.

        Args:
            key: The unique key of the entry to retrieve.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            The :class:`MemoryEntry` if found, otherwise ``None``.
        """
        result = self._policy.retrieve(key)

        event = self._make_event(
            operation=MemoryOperation.RETRIEVE,
            key=key,
            value=result.value if result else None,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def update(self, key: str, value: Any, agent_id: str = "", customer_id: str = "") -> bool:
        """Update an existing memory entry's value.

        Args:
            key: Key of the entry to update.
            value: The new value.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was updated, ``False`` if not found.
        """
        result = self._policy.update(key, value)

        event = self._make_event(
            operation=MemoryOperation.UPDATE,
            key=key,
            value=value,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def forget(self, key: str, agent_id: str = "", customer_id: str = "") -> bool:
        """Remove a memory entry (the FORGET operation).

        Also removes the entry from the vector store.

        Args:
            key: Key of the entry to forget.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was deleted, ``False`` if not found.
        """
        result = self._policy.forget(key)

        # Remove from vector store.
        self._vector.remove(key)

        event = self._make_event(
            operation=MemoryOperation.FORGET,
            key=key,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def link(
        self,
        key_a: str,
        key_b: str,
        relation: str = "related",
        agent_id: str = "",
        customer_id: str = "",
    ) -> bool:
        """Create a semantic link between two memory entries.

        Args:
            key_a: Key of the first entry.
            key_b: Key of the second entry.
            relation: Type of relationship.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if both entries exist and the link was created.
        """
        result = self._policy.link(key_a, key_b, relation)

        event = self._make_event(
            operation=MemoryOperation.LINK,
            key=key_a,
            agent_id=agent_id,
            customer_id=customer_id,
            metadata={"target_key": key_b, "relation": relation},
        )
        self._event_log.append(event)

        return result

    def promote(
        self,
        key: str,
        target_tier: MemoryTier,
        agent_id: str = "",
        customer_id: str = "",
    ) -> bool:
        """Promote a memory entry to a higher (more persistent) tier.

        Args:
            key: Key of the entry to promote.
            target_tier: The tier to promote to.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was promoted.
        """
        result = self._policy.promote(key, target_tier)

        event = self._make_event(
            operation=MemoryOperation.PROMOTE,
            key=key,
            tier=target_tier,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def demote(
        self,
        key: str,
        target_tier: MemoryTier,
        agent_id: str = "",
        customer_id: str = "",
    ) -> bool:
        """Demote a memory entry to a lower (less persistent) tier.

        Args:
            key: Key of the entry to demote.
            target_tier: The tier to demote to.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was demoted.
        """
        result = self._policy.demote(key, target_tier)

        event = self._make_event(
            operation=MemoryOperation.DEMOTE,
            key=key,
            tier=target_tier,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def compress(self, key: str, agent_id: str = "", customer_id: str = "") -> bool:
        """Compress a memory entry by condensing its text value.

        Args:
            key: Key of the entry to compress.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was compressed.
        """
        result = self._policy.compress(key)

        # Get the updated entry with compressed value.
        updated = self._policy.retrieve(key)

        event = self._make_event(
            operation=MemoryOperation.COMPRESS,
            key=key,
            value=updated.value if updated else None,
            tier=updated.tier if updated else MemoryTier.WORKING,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def split(self, key: str, agent_id: str = "", customer_id: str = "") -> list[MemoryEntry]:
        """Split a memory entry into independent entries per sentence.

        Args:
            key: Key of the entry to split.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            The list of newly created entries.
        """
        # Get the entry BEFORE splitting to capture its tier.
        entry = self._policy.retrieve(key)
        entry_tier = entry.tier if entry else MemoryTier.WORKING
        entry_confidence = entry.confidence if entry else 1.0

        parts = self._policy.split(key)

        parts_meta = [{"key": p.key, "value": p.value} for p in parts]
        event = self._make_event(
            operation=MemoryOperation.SPLIT,
            key=key,
            tier=entry_tier,
            confidence=entry_confidence,
            agent_id=agent_id,
            customer_id=customer_id,
            metadata={"parts": parts_meta},
        )
        self._event_log.append(event)

        return parts

    def merge(
        self,
        key_a: str,
        key_b: str,
        agent_id: str = "",
        customer_id: str = "",
    ) -> MemoryEntry | None:
        """Merge two memory entries into a single consolidated entry.

        Args:
            key_a: Key of the first entry.
            key_b: Key of the second entry.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            The merged :class:`MemoryEntry`, or ``None`` if either source
            entry was not found.
        """
        result = self._policy.merge(key_a, key_b)

        event = self._make_event(
            operation=MemoryOperation.MERGE,
            key=f"{key_a}+{key_b}" if result else key_a,
            value=result.value if result else None,
            tier=result.tier if result else MemoryTier.WORKING,
            confidence=result.confidence if result else 1.0,
            agent_id=agent_id,
            customer_id=customer_id,
            metadata={"merge_sources": [key_a, key_b]},
        )
        self._event_log.append(event)

        return result

    def verify(self, key: str, agent_id: str = "", customer_id: str = "") -> bool:
        """Verify the integrity and currency of a memory entry.

        Args:
            key: Key of the entry to verify.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry passes all verification checks.
        """
        result = self._policy.verify(key)

        event = self._make_event(
            operation=MemoryOperation.VERIFY,
            key=key,
            agent_id=agent_id,
            customer_id=customer_id,
        )
        self._event_log.append(event)

        return result

    def annotate(
        self,
        key: str,
        annotation: dict[str, Any],
        agent_id: str = "",
        customer_id: str = "",
    ) -> bool:
        """Add an annotation to a memory entry.

        Args:
            key: Key of the entry to annotate.
            annotation: The annotation payload.
            agent_id: Identifier of the acting agent.
            customer_id: Identifier of the customer.

        Returns:
            ``True`` if the entry was annotated.
        """
        result = self._policy.annotate(key, annotation)

        event = self._make_event(
            operation=MemoryOperation.ANNOTATE,
            key=key,
            agent_id=agent_id,
            customer_id=customer_id,
            metadata=annotation,
        )
        self._event_log.append(event)

        return result

    # -- higher-level queries ------------------------------------------------

    def semantic_search(self, query: str, top_k: int = 10) -> list[MemoryEntry]:
        """Search for entries most similar to *query*.

        Delegates to the :class:`VectorStore` and returns entries only
        (without scores).

        Args:
            query: The search query string.
            top_k: Maximum number of results to return.

        Returns:
            A list of matching :class:`MemoryEntry` instances.
        """
        results = self._vector.search(query, top_k=top_k)
        return [entry for entry, _score in results]

    def snapshot_at(self, timestamp: datetime) -> MemorySnapshotData:
        """Reconstruct the memory state as it existed at *timestamp*.

        Args:
            timestamp: The point in time to reconstruct.

        Returns:
            A :class:`MemorySnapshotData` containing the reconstructed state.
        """
        return self._snapshot.reconstruct_at(timestamp)

    def audit_trail(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[MemoryEventV1]:
        """Return events from the event log, optionally filtered by time.

        Args:
            start: If given, only include events from this time forward.
            end: If given (with *start*), only include events in the
                [start, end] window.

        Returns:
            A list of :class:`MemoryEventV1` instances.
        """
        if start is not None and end is not None:
            return self._event_log.replay_range(start, end)
        if start is not None:
            return self._event_log.replay_from(start)
        return self._event_log.all_events()

    def consolidate(self, **kwargs: Any) -> dict[str, Any]:
        """Run sleep-time memory consolidation.

        Delegates to :class:`ConsolidationEngine` to decay, compress,
        discover links, detect contradictions, and abstract patterns.

        Args:
            **kwargs: Forwarded to :class:`ConsolidationEngine` constructor
                (e.g. ``decay_rate``, ``similarity_threshold``,
                ``min_access_count``).

        Returns:
            A summary dict with counts of entries processed, compressed,
            decayed, links discovered, contradictions found, and patterns
            abstracted.
        """
        from aegis.memory.consolidation import ConsolidationEngine

        engine = ConsolidationEngine(**kwargs)
        result = engine.consolidate(self._store)
        return {
            "entries_processed": result.entries_processed,
            "entries_compressed": result.entries_compressed,
            "entries_decayed": result.entries_decayed,
            "links_discovered": result.links_discovered,
            "contradictions_found": result.contradictions_found,
            "patterns_abstracted": result.patterns_abstracted,
        }

    def detect_interference(self) -> dict[str, Any]:
        """Run interference detection across all memory entries.

        Checks for key collisions, semantic overlap, temporal conflicts,
        and cross-domain interference.

        Returns:
            A summary dict with total interferences, breakdowns by type
            and severity, and the highest severity found.
        """
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()

        all_entries: list[MemoryEntry] = []
        for tier in MemoryTier:
            all_entries.extend(self._store.list_by_tier(tier))

        results = detector.detect(all_entries)
        return detector.summary(results)

    def health(self) -> dict[str, Any]:
        """Return a health dashboard for the memory subsystem.

        Returns:
            A dict containing ``total_entries``, ``tier_counts``,
            ``event_log_size``, and ``integrity_ok``.
        """
        # Total entries: prefer InMemoryStore.count(), fall back to
        # iterating tiers.
        if isinstance(self._store, InMemoryStore):
            total = self._store.count()
        else:
            total = sum(len(self._store.list_by_tier(t)) for t in MemoryTier)

        # Tier counts.
        tier_counts: dict[str, int] = {}
        for t in MemoryTier:
            count = len(self._store.list_by_tier(t))
            tier_counts[t.value] = count

        return {
            "total_entries": total,
            "tier_counts": tier_counts,
            "event_log_size": len(self._event_log),
            "integrity_ok": self._event_log.verify_integrity(),
        }
