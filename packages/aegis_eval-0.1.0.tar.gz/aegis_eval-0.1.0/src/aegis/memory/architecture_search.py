"""ALMA-inspired memory architecture search.

Uses evolutionary optimisation (selection, crossover, mutation) to discover
high-performing memory configurations for specific domains.  Seed
architectures encode domain priors (e.g. temporal-edge-heavy KG for legal,
table-aware hierarchical stores for finance); the search engine refines
them over generations using task-performance fitness scores.
"""

from __future__ import annotations

import copy
import random
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class MemoryArchitecture:
    """A concrete memory architecture specification.

    Attributes:
        id: Unique identifier.
        name: Human-readable name.
        description: Free-text description.
        tiers: List of tier configuration dicts.  Each tier dict should
            contain at minimum ``"name"``, ``"max_entries"``, and
            ``"decay_rate"``.
        retrieval_strategy: Name of the retrieval strategy (e.g.
            ``"vector_first"``, ``"kg_first"``, ``"hybrid"``).
        update_rules: List of rule names governing memory updates.
        compression_strategy: Compression approach name (e.g.
            ``"summarise"``, ``"prune"``, ``"none"``).
        fitness_score: Aggregate fitness from evaluation.
        domain: Domain this architecture was discovered for.
        discovered_at: When this architecture was generated or last mutated.
        metadata: Extra key-value metadata.
    """

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = "unnamed"
    description: str = ""
    tiers: list[dict[str, Any]] = field(default_factory=list)
    retrieval_strategy: str = "hybrid"
    update_rules: list[str] = field(default_factory=list)
    compression_strategy: str = "summarise"
    fitness_score: float = 0.0
    domain: str = "general"
    discovered_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ArchitectureCandidate:
    """A candidate in the evolutionary population.

    Attributes:
        architecture: The architecture specification.
        eval_scores: Per-task evaluation scores.
        generation: Which evolutionary generation produced this candidate.
    """

    architecture: MemoryArchitecture
    eval_scores: dict[str, float] = field(default_factory=dict)
    generation: int = 0


# ---------------------------------------------------------------------------
# Seed templates
# ---------------------------------------------------------------------------

_RETRIEVAL_STRATEGIES: list[str] = [
    "vector_first",
    "kg_first",
    "hybrid",
    "temporal_first",
    "recency_biased",
]

_UPDATE_RULES: list[str] = [
    "overwrite",
    "append",
    "version",
    "merge",
    "promote_on_access",
    "decay_on_idle",
    "compress_on_promote",
]

_COMPRESSION_STRATEGIES: list[str] = [
    "summarise",
    "prune",
    "quantise",
    "deduplicate",
    "none",
]


def _legal_temporal_seed() -> MemoryArchitecture:
    """Temporal-edge-heavy KG for legal domain."""
    return MemoryArchitecture(
        name="legal_temporal",
        description=(
            "Temporal-edge-heavy knowledge graph optimised for legal "
            "document analysis.  Prioritises temporal validity, provenance "
            "tracking, and precedent chains."
        ),
        tiers=[
            {"name": "working", "max_entries": 200, "decay_rate": 0.1},
            {"name": "session", "max_entries": 2000, "decay_rate": 0.01},
            {"name": "case", "max_entries": 20000, "decay_rate": 0.001},
            {"name": "permanent", "max_entries": 100000, "decay_rate": 0.0},
        ],
        retrieval_strategy="temporal_first",
        update_rules=["version", "promote_on_access", "compress_on_promote"],
        compression_strategy="summarise",
        fitness_score=0.0,
        domain="legal",
        metadata={"source": "seed", "variant": "temporal_kg"},
    )


def _finance_tabular_seed() -> MemoryArchitecture:
    """Table-aware hierarchical store for finance domain."""
    return MemoryArchitecture(
        name="finance_tabular",
        description=(
            "Table-aware hierarchical memory for financial data.  "
            "Optimised for numerical precision, time-series retrieval, "
            "and regulatory compliance tracking."
        ),
        tiers=[
            {"name": "working", "max_entries": 500, "decay_rate": 0.05},
            {"name": "session", "max_entries": 5000, "decay_rate": 0.005},
            {"name": "client", "max_entries": 50000, "decay_rate": 0.0005},
            {"name": "permanent", "max_entries": 200000, "decay_rate": 0.0},
        ],
        retrieval_strategy="hybrid",
        update_rules=["overwrite", "version", "decay_on_idle"],
        compression_strategy="quantise",
        fitness_score=0.0,
        domain="finance",
        metadata={"source": "seed", "variant": "tabular_hierarchical"},
    )


def _general_balanced_seed() -> MemoryArchitecture:
    """Even-tier-distribution general-purpose architecture."""
    return MemoryArchitecture(
        name="general_balanced",
        description=(
            "Balanced general-purpose memory architecture.  Even tier "
            "distribution with moderate decay and hybrid retrieval."
        ),
        tiers=[
            {"name": "working", "max_entries": 300, "decay_rate": 0.08},
            {"name": "session", "max_entries": 3000, "decay_rate": 0.008},
            {"name": "long_term", "max_entries": 30000, "decay_rate": 0.0008},
            {"name": "permanent", "max_entries": 100000, "decay_rate": 0.0},
        ],
        retrieval_strategy="hybrid",
        update_rules=["merge", "promote_on_access", "decay_on_idle"],
        compression_strategy="summarise",
        fitness_score=0.0,
        domain="general",
        metadata={"source": "seed", "variant": "balanced"},
    )


_SEED_FACTORIES: dict[str, Any] = {
    "legal_temporal": _legal_temporal_seed,
    "finance_tabular": _finance_tabular_seed,
    "general_balanced": _general_balanced_seed,
}


# ---------------------------------------------------------------------------
# Search engine
# ---------------------------------------------------------------------------


class ArchitectureSearchEngine:
    """Evolutionary search engine for memory architectures.

    Maintains a population of candidate architectures, evaluates their
    fitness against task-performance scores, and evolves them through
    selection, crossover, and mutation.

    Args:
        population_size: Target population size per generation.
        mutation_rate: Probability that any given gene is mutated during
            mutation (in [0, 1]).
    """

    def __init__(
        self,
        population_size: int = 20,
        mutation_rate: float = 0.1,
    ) -> None:
        self._population_size = max(population_size, 4)
        self._mutation_rate = max(0.0, min(1.0, mutation_rate))
        # domain -> list of architectures (the library).
        self._library: dict[str, list[MemoryArchitecture]] = {}
        self._generation: int = 0

    # -- seeding -------------------------------------------------------------

    def seed_architectures(self, domain: str) -> list[MemoryArchitecture]:
        """Generate the initial population for a domain.

        Uses pre-built seed templates and fills the rest of the population
        with random perturbations of those seeds.

        Args:
            domain: Domain identifier (e.g. ``"legal"``, ``"finance"``,
                ``"general"``).

        Returns:
            List of :class:`MemoryArchitecture` instances forming the
            initial population.
        """
        seeds: list[MemoryArchitecture] = []

        # Include the matching domain seed if available.
        for _seed_name, factory in _SEED_FACTORIES.items():
            arch: MemoryArchitecture = factory()
            if arch.domain == domain or domain == "general":
                arch_copy = copy.deepcopy(arch)
                arch_copy.id = str(uuid.uuid4())
                arch_copy.domain = domain
                seeds.append(arch_copy)

        # Always include the general balanced seed.
        if not any(s.name == "general_balanced" for s in seeds):
            balanced = _general_balanced_seed()
            balanced.id = str(uuid.uuid4())
            balanced.domain = domain
            seeds.append(balanced)

        # Fill remaining population slots with mutated variants.
        while len(seeds) < self._population_size:
            base = random.choice(seeds)
            variant = self.mutate(copy.deepcopy(base))
            variant.id = str(uuid.uuid4())
            variant.domain = domain
            variant.name = f"{base.name}_var{len(seeds)}"
            seeds.append(variant)

        # Register in library.
        self._library.setdefault(domain, []).extend(seeds)
        return seeds

    # -- evaluation ----------------------------------------------------------

    def evaluate_architecture(
        self,
        arch: MemoryArchitecture,
        task_scores: dict[str, float],
    ) -> float:
        """Compute fitness for an architecture based on task performance.

        Fitness is the weighted harmonic mean of task scores, with a bonus
        for architectures that have fewer tiers (simplicity bias) and a
        penalty for very high total entry capacity (efficiency bias).

        Args:
            arch: The architecture to evaluate.
            task_scores: Mapping of task name to score in [0, 1].

        Returns:
            The fitness score (higher is better).
        """
        if not task_scores:
            return 0.0

        scores = list(task_scores.values())

        # Harmonic mean of task scores (rewards consistency).
        denom = sum(1.0 / max(s, 1e-9) for s in scores)
        harmonic = len(scores) / denom if denom > 0 else 0.0

        # Simplicity bonus: fewer tiers = simpler to operate.
        tier_count = len(arch.tiers) if arch.tiers else 1
        simplicity_bonus = 1.0 / (1.0 + 0.05 * max(tier_count - 3, 0))

        # Efficiency penalty: very large total capacity is expensive.
        total_capacity = sum(t.get("max_entries", 0) for t in arch.tiers)
        efficiency = 1.0 / (1.0 + total_capacity / 500_000)

        fitness = harmonic * 0.7 + simplicity_bonus * 0.15 + efficiency * 0.15
        arch.fitness_score = round(fitness, 6)
        return arch.fitness_score

    # -- evolution -----------------------------------------------------------

    def evolve(
        self,
        candidates: list[ArchitectureCandidate],
    ) -> list[ArchitectureCandidate]:
        """Run one generation of evolution.

        Steps:

        1. **Selection**: top 50 % survive (elitism).
        2. **Crossover**: pairs from top 50 % produce offspring.
        3. **Mutation**: each offspring is mutated with probability
           :attr:`mutation_rate`.

        Args:
            candidates: Current population of candidates.

        Returns:
            The new generation of candidates (same size as input, or
            ``population_size`` if larger).
        """
        if len(candidates) < 2:
            return candidates

        self._generation += 1

        # Sort by fitness descending.
        ranked = sorted(
            candidates,
            key=lambda c: c.architecture.fitness_score,
            reverse=True,
        )

        # Elitism: top half survives.
        cutoff = max(len(ranked) // 2, 1)
        survivors = ranked[:cutoff]

        # Crossover to fill the population.
        offspring: list[ArchitectureCandidate] = []
        target = max(self._population_size, len(candidates))
        while len(survivors) + len(offspring) < target:
            parent_a = random.choice(survivors)
            parent_b = random.choice(survivors)
            child_arch = self.crossover(
                copy.deepcopy(parent_a.architecture),
                copy.deepcopy(parent_b.architecture),
            )
            # Mutate with configured probability.
            if random.random() < self._mutation_rate:
                child_arch = self.mutate(child_arch)
            child_arch.id = str(uuid.uuid4())
            offspring.append(
                ArchitectureCandidate(
                    architecture=child_arch,
                    eval_scores={},
                    generation=self._generation,
                )
            )

        new_pop = [
            ArchitectureCandidate(
                architecture=s.architecture,
                eval_scores=s.eval_scores,
                generation=self._generation,
            )
            for s in survivors
        ] + offspring

        # Update library.
        for cand in new_pop:
            domain = cand.architecture.domain
            self._library.setdefault(domain, []).append(cand.architecture)

        return new_pop

    # -- mutation ------------------------------------------------------------

    def mutate(self, arch: MemoryArchitecture) -> MemoryArchitecture:
        """Apply random mutations to an architecture.

        Possible mutations (each applied independently with probability
        ``mutation_rate``):

        * Change a tier's ``max_entries`` by +/- 30 %.
        * Change a tier's ``decay_rate`` by +/- 50 %.
        * Swap retrieval strategy to a random alternative.
        * Add or remove an update rule.
        * Swap compression strategy.

        Args:
            arch: The architecture to mutate (mutated in-place and returned).

        Returns:
            The mutated architecture.
        """
        arch.discovered_at = datetime.now(tz=UTC)

        # Tier mutations.
        for tier in arch.tiers:
            if random.random() < self._mutation_rate:
                old_max = tier.get("max_entries", 1000)
                factor = random.uniform(0.7, 1.3)
                tier["max_entries"] = max(10, int(old_max * factor))

            if random.random() < self._mutation_rate:
                old_decay = tier.get("decay_rate", 0.01)
                factor = random.uniform(0.5, 1.5)
                tier["decay_rate"] = round(max(0.0, old_decay * factor), 6)

        # Retrieval strategy.
        if random.random() < self._mutation_rate:
            arch.retrieval_strategy = random.choice(_RETRIEVAL_STRATEGIES)

        # Update rules.
        if random.random() < self._mutation_rate:
            if arch.update_rules and random.random() < 0.5:
                # Remove a random rule.
                arch.update_rules.pop(random.randrange(len(arch.update_rules)))
            else:
                # Add a random rule.
                candidate_rule = random.choice(_UPDATE_RULES)
                if candidate_rule not in arch.update_rules:
                    arch.update_rules.append(candidate_rule)

        # Compression strategy.
        if random.random() < self._mutation_rate:
            arch.compression_strategy = random.choice(_COMPRESSION_STRATEGIES)

        return arch

    # -- crossover -----------------------------------------------------------

    def crossover(
        self,
        arch_a: MemoryArchitecture,
        arch_b: MemoryArchitecture,
    ) -> MemoryArchitecture:
        """Combine features from two parent architectures.

        The child inherits tiers from one parent (randomly chosen),
        retrieval strategy from the other, update rules merged, and
        compression strategy chosen at random from either parent.

        Args:
            arch_a: First parent.
            arch_b: Second parent.

        Returns:
            A new child :class:`MemoryArchitecture`.
        """
        # Tiers: pick from one parent, or interleave.
        if random.random() < 0.5:
            child_tiers = copy.deepcopy(arch_a.tiers)
        else:
            child_tiers = copy.deepcopy(arch_b.tiers)

        # Retrieval strategy from the other parent.
        if random.random() < 0.5:
            retrieval = arch_b.retrieval_strategy
        else:
            retrieval = arch_a.retrieval_strategy

        # Merge update rules (union, then randomly thin to max 5).
        merged_rules = list(set(arch_a.update_rules) | set(arch_b.update_rules))
        if len(merged_rules) > 5:
            merged_rules = random.sample(merged_rules, 5)

        # Compression from either parent.
        compression = random.choice([arch_a.compression_strategy, arch_b.compression_strategy])

        child = MemoryArchitecture(
            id=str(uuid.uuid4()),
            name=f"{arch_a.name}x{arch_b.name}",
            description=f"Crossover of {arch_a.name} and {arch_b.name}",
            tiers=child_tiers,
            retrieval_strategy=retrieval,
            update_rules=merged_rules,
            compression_strategy=compression,
            fitness_score=0.0,
            domain=arch_a.domain or arch_b.domain,
            metadata={"parents": [arch_a.id, arch_b.id]},
        )
        return child

    # -- queries -------------------------------------------------------------

    def best_for_domain(self, domain: str) -> MemoryArchitecture | None:
        """Return the highest-fitness architecture discovered for a domain.

        Args:
            domain: Domain identifier.

        Returns:
            The best :class:`MemoryArchitecture`, or ``None`` if no
            architectures exist for the domain.
        """
        archs = self._library.get(domain, [])
        if not archs:
            return None
        return max(archs, key=lambda a: a.fitness_score)

    def library(self) -> dict[str, list[MemoryArchitecture]]:
        """Return the full architecture library grouped by domain.

        Returns:
            Dict mapping domain names to lists of architectures.
        """
        return dict(self._library)

    def summary(self) -> dict[str, Any]:
        """Return an overview of the search engine state.

        Returns:
            Dict with generation count, domains, and architecture counts.
        """
        domain_counts = {d: len(archs) for d, archs in self._library.items()}
        best_per_domain: dict[str, float] = {}
        for domain, archs in self._library.items():
            if archs:
                best_per_domain[domain] = max(a.fitness_score for a in archs)

        return {
            "generation": self._generation,
            "population_size": self._population_size,
            "mutation_rate": self._mutation_rate,
            "domains": list(self._library.keys()),
            "architectures_per_domain": domain_counts,
            "best_fitness_per_domain": best_per_domain,
        }
