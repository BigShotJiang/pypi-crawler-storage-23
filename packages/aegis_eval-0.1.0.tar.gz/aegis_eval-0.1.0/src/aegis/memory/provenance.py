"""Provenance chain tracking for memory entries.

Tracks the full lineage of each memory entry -- where it came from, how it
was derived, and how confidence propagates through derivation chains.  Every
mutation recorded by the event log can be annotated with a
:class:`ProvenanceRecord` so that downstream consumers can audit the origin
of any piece of stored knowledge.
"""

from __future__ import annotations

from collections import deque
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from aegis.core.types import MemoryOperation


class ProvenanceRecord(BaseModel):
    """A single provenance record for a memory entry.

    Attributes:
        entry_key: The key of the memory entry this record belongs to.
        source_type: Kind of source that produced the entry.  One of
            ``"document"``, ``"conversation"``, ``"derived"``,
            ``"merged"``, ``"split"``, or ``"unknown"``.
        source_ref: Reference to the originating artefact (document ID,
            conversation ID, parent entry key, etc.).
        operation: The memory operation that created or modified the entry.
        confidence: Confidence score in the range [0.0, 1.0].
        timestamp: When this provenance record was created.
        parent_keys: Keys of parent entries (for derived / merged / split
            entries).
        metadata: Additional arbitrary provenance metadata.
    """

    entry_key: str
    source_type: str  # "document", "conversation", "derived", "merged", "split", "unknown"
    source_ref: str  # document ID, conversation ID, parent entry key
    operation: MemoryOperation
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    parent_keys: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProvenanceTracker:
    """Maintains provenance chains for all tracked memory entries.

    For each entry key the tracker stores an ordered list of
    :class:`ProvenanceRecord` instances (the *chain*).  A reverse index
    (``_derived_from``) maps parent keys to entries that were derived from
    them, enabling forward lineage queries.
    """

    def __init__(self) -> None:
        self._chains: dict[str, list[ProvenanceRecord]] = {}
        self._derived_from: dict[str, list[str]] = {}

    # -- recording -----------------------------------------------------------

    def record(
        self,
        entry_key: str,
        source_type: str,
        source_ref: str,
        operation: MemoryOperation,
        confidence: float = 1.0,
        parent_keys: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ProvenanceRecord:
        """Create and store a provenance record for *entry_key*.

        The record is appended to the entry's provenance chain.  If
        *parent_keys* are provided, the reverse derivation index is updated
        so that each parent maps to this entry.

        Args:
            entry_key: The memory entry key to record provenance for.
            source_type: Kind of source (e.g. ``"document"``).
            source_ref: Identifier of the originating artefact.
            operation: The memory operation that caused this record.
            confidence: Confidence score in [0.0, 1.0].
            parent_keys: Optional list of parent entry keys.
            metadata: Optional extra metadata.

        Returns:
            The newly created :class:`ProvenanceRecord`.
        """
        rec = ProvenanceRecord(
            entry_key=entry_key,
            source_type=source_type,
            source_ref=source_ref,
            operation=operation,
            confidence=confidence,
            parent_keys=parent_keys or [],
            metadata=metadata or {},
        )

        if entry_key not in self._chains:
            self._chains[entry_key] = []
        self._chains[entry_key].append(rec)

        # Update the reverse derivation index.
        for parent in rec.parent_keys:
            if parent not in self._derived_from:
                self._derived_from[parent] = []
            if entry_key not in self._derived_from[parent]:
                self._derived_from[parent].append(entry_key)

        return rec

    # -- querying ------------------------------------------------------------

    def chain(self, entry_key: str) -> list[ProvenanceRecord]:
        """Return the full provenance chain for *entry_key*.

        Args:
            entry_key: The memory entry key to look up.

        Returns:
            An ordered list of :class:`ProvenanceRecord` instances (oldest
            first).  Returns an empty list if no records exist.
        """
        return list(self._chains.get(entry_key, []))

    def root_sources(self, entry_key: str) -> list[ProvenanceRecord]:
        """Trace back to the original (root) sources of *entry_key*.

        Performs a breadth-first search through ``parent_keys`` until it
        reaches records that have no parents (i.e. root sources such as
        documents or conversations).

        Args:
            entry_key: The memory entry key to trace.

        Returns:
            A list of :class:`ProvenanceRecord` instances representing the
            root sources.  Returns an empty list if no chain exists.
        """
        roots: list[ProvenanceRecord] = []
        visited: set[str] = set()
        queue: deque[str] = deque([entry_key])

        while queue:
            current_key = queue.popleft()
            if current_key in visited:
                continue
            visited.add(current_key)

            chain = self._chains.get(current_key, [])
            if not chain:
                continue

            # Inspect the first record in the chain (the origin record).
            first_record = chain[0]
            if not first_record.parent_keys:
                roots.append(first_record)
            else:
                for parent_key in first_record.parent_keys:
                    if parent_key not in visited:
                        queue.append(parent_key)

        return roots

    def derived_entries(self, entry_key: str) -> list[str]:
        """Return the keys of entries derived from *entry_key*.

        Args:
            entry_key: The parent entry key.

        Returns:
            A list of derived entry keys.  Returns an empty list if none
            exist.
        """
        return list(self._derived_from.get(entry_key, []))

    # -- confidence ----------------------------------------------------------

    def propagate_confidence(self, parent_keys: list[str]) -> float:
        """Compute propagated confidence as the geometric mean of parents.

        For each parent key, the latest confidence value from its provenance
        chain is used.  If a parent has no chain, a confidence of ``1.0`` is
        assumed.

        Args:
            parent_keys: The keys of the parent entries.

        Returns:
            The geometric mean of the parent confidence values.  Returns
            ``1.0`` if *parent_keys* is empty.
        """
        if not parent_keys:
            return 1.0

        confidences: list[float] = []
        for key in parent_keys:
            chain = self._chains.get(key, [])
            if chain:
                confidences.append(float(chain[-1].confidence))
            else:
                confidences.append(1.0)

        product = 1.0
        for c in confidences:
            product *= float(c)
        return float(product ** (1.0 / len(confidences)))

    # -- validation ----------------------------------------------------------

    def validate_chain(self, entry_key: str) -> bool:
        """Verify that the provenance chain for *entry_key* has no gaps.

        A valid chain satisfies:
        - The first record should have ``source_type != "derived"`` or
          empty ``parent_keys`` (it is a root source).
        - Subsequent records should reference existing entries (i.e. any
          ``parent_keys`` should have known provenance chains).

        Args:
            entry_key: The memory entry key to validate.

        Returns:
            ``True`` if the chain is valid, ``False`` otherwise (including
            when no chain exists).
        """
        chain = self._chains.get(entry_key, [])
        if not chain:
            return False

        # First record: must be a root source or have no parent keys.
        first = chain[0]
        if first.source_type == "derived" and first.parent_keys:
            # All parent keys must have known chains.
            for parent_key in first.parent_keys:
                if parent_key not in self._chains:
                    return False

        # Subsequent records: any referenced parent keys must exist.
        for record in chain[1:]:
            for parent_key in record.parent_keys:
                if parent_key not in self._chains:
                    return False

        return True

    # -- presence / cleanup --------------------------------------------------

    def has_provenance(self, entry_key: str) -> bool:
        """Check whether any provenance records exist for *entry_key*.

        Args:
            entry_key: The memory entry key to check.

        Returns:
            ``True`` if at least one record exists.
        """
        return bool(self._chains.get(entry_key))

    def remove(self, entry_key: str) -> bool:
        """Remove all provenance records for *entry_key*.

        Also cleans up the reverse derivation index.

        Args:
            entry_key: The memory entry key whose provenance to remove.

        Returns:
            ``True`` if records were removed, ``False`` if none existed.
        """
        chain = self._chains.pop(entry_key, None)
        if chain is None:
            return False

        # Clean up reverse derivation index: remove entry_key from each
        # parent's derived list.
        for record in chain:
            for parent_key in record.parent_keys:
                derived = self._derived_from.get(parent_key, [])
                if entry_key in derived:
                    derived.remove(entry_key)
                    if not derived:
                        del self._derived_from[parent_key]

        # Also remove the forward derivation entry if this key was a parent.
        self._derived_from.pop(entry_key, None)

        return True
