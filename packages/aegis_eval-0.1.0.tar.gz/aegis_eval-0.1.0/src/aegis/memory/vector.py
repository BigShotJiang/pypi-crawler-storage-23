"""Vector store with sentence-transformers fallback for the Aegis memory subsystem.

Provides semantic search over :class:`MemoryEntry` instances using
``sentence-transformers`` embeddings when available, falling back to
``difflib.SequenceMatcher`` fuzzy matching when the ML dependencies
are not installed.
"""

from __future__ import annotations

import difflib
from typing import Any

from aegis.memory.types import MemoryEntry

try:
    import numpy as np
    from sentence_transformers import SentenceTransformer

    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False


class VectorStore:
    """Searchable vector store for :class:`MemoryEntry` instances.

    When ``sentence-transformers`` and ``numpy`` are available the store
    encodes entries as dense vectors and performs cosine-similarity
    search.  Otherwise it falls back to token-level fuzzy matching via
    :class:`difflib.SequenceMatcher`.

    Args:
        enable_embeddings: Set to ``False`` to force fallback mode even
            when ML dependencies are present.
    """

    def __init__(self, enable_embeddings: bool = True) -> None:
        self._entries: dict[str, MemoryEntry] = {}
        self._text_cache: dict[str, str] = {}
        self._vectors: dict[str, Any] | None = None
        self._model: Any | None = None
        self._fallback_mode: bool = True

        if enable_embeddings and _HAS_EMBEDDINGS:
            self._model = SentenceTransformer("all-MiniLM-L6-v2")
            self._vectors = {}
            self._fallback_mode = False

    # -- public API ----------------------------------------------------------

    def add(self, entry: MemoryEntry) -> None:
        """Index a memory entry for later search.

        Computes a text representation of the entry's value and, when
        not in fallback mode, encodes it as a dense vector.

        Args:
            entry: The :class:`MemoryEntry` to index.
        """
        self._entries[entry.key] = entry
        text = self._to_text(entry.value)
        self._text_cache[entry.key] = text

        if not self._fallback_mode and self._model is not None and self._vectors is not None:
            self._vectors[entry.key] = self._model.encode(text, convert_to_numpy=True)

    def remove(self, key: str) -> bool:
        """Remove an entry from the store.

        Args:
            key: Key of the entry to remove.

        Returns:
            ``True`` if the entry existed and was removed, ``False``
            otherwise.
        """
        if key not in self._entries:
            return False

        del self._entries[key]
        self._text_cache.pop(key, None)
        if self._vectors is not None:
            self._vectors.pop(key, None)
        return True

    def search(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryEntry, float]]:
        """Search for entries most similar to *query*.

        Dispatches to semantic search (cosine similarity) or fuzzy
        search (SequenceMatcher) depending on the current mode.

        Args:
            query: The search query string.
            top_k: Maximum number of results to return.
            min_score: Minimum similarity score threshold.

        Returns:
            A list of ``(entry, score)`` tuples sorted by descending
            similarity score.
        """
        if self._fallback_mode:
            return self._fuzzy_search(query, top_k, min_score)
        return self._semantic_search(query, top_k, min_score)

    def reindex(self, entries: dict[str, MemoryEntry]) -> None:
        """Clear the store and re-index all provided entries.

        Args:
            entries: A mapping of key -> :class:`MemoryEntry` to index.
        """
        self._entries.clear()
        self._text_cache.clear()
        if self._vectors is not None:
            self._vectors.clear()

        for entry in entries.values():
            self.add(entry)

    def count(self) -> int:
        """Return the number of indexed entries."""
        return len(self._entries)

    # -- private search implementations --------------------------------------

    def _semantic_search(
        self,
        query: str,
        top_k: int,
        min_score: float,
    ) -> list[tuple[MemoryEntry, float]]:
        """Search using cosine similarity against stored vectors.

        Args:
            query: The search query string.
            top_k: Maximum number of results.
            min_score: Minimum cosine similarity threshold.

        Returns:
            Scored results sorted by descending similarity.
        """
        if self._model is None or self._vectors is None or not self._vectors:
            return []

        query_vec = self._model.encode(query, convert_to_numpy=True)

        scored: list[tuple[MemoryEntry, float]] = []
        for key, vec in self._vectors.items():
            similarity = float(
                np.dot(query_vec, vec) / (np.linalg.norm(query_vec) * np.linalg.norm(vec) + 1e-10)
            )
            if similarity >= min_score:
                scored.append((self._entries[key], similarity))

        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored[:top_k]

    def _fuzzy_search(
        self,
        query: str,
        top_k: int,
        min_score: float,
    ) -> list[tuple[MemoryEntry, float]]:
        """Search using :class:`difflib.SequenceMatcher` text similarity.

        Args:
            query: The search query string.
            top_k: Maximum number of results.
            min_score: Minimum similarity ratio threshold.

        Returns:
            Scored results sorted by descending similarity.
        """
        scored: list[tuple[MemoryEntry, float]] = []
        for key, text in self._text_cache.items():
            ratio = difflib.SequenceMatcher(None, query.lower(), text.lower()).ratio()
            if ratio >= min_score:
                scored.append((self._entries[key], ratio))

        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored[:top_k]

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _to_text(value: Any) -> str:
        """Convert an entry value to a plain text string for matching.

        Args:
            value: The value to convert.

        Returns:
            A string representation of *value*.
        """
        return str(value)
