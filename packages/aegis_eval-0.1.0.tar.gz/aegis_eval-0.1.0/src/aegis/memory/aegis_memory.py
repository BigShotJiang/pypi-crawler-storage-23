"""AegisMemory — drop-in memory replacement for any agent framework.

Provides a simple interface that wraps the full Aegis memory subsystem
(event log, temporal index, knowledge graph, vector store, provenance)
behind a minimal API suitable for one-line integration.

Usage::

    from aegis import AegisMemory

    agent.memory = AegisMemory(domain="legal", customer_id="sterling")
    agent.memory.store("key", "value")
    result = agent.memory.retrieve("key")
    results = agent.memory.search("contract clause about liability")
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from aegis.core.types import MemoryTier, TemporalBounds
from aegis.memory.manager import MemoryManager
from aegis.memory.types import MemoryEntry


class AegisMemory:
    """Drop-in memory layer for any AI agent framework.

    Wraps the full Aegis memory subsystem behind a simple dict-like
    interface.  All operations flow through the MemoryManager which
    provides event logging, provenance tracking, vector indexing,
    knowledge graph linking, and temporal indexing.

    Args:
        domain: Domain identifier (e.g. "legal", "finance").
        customer_id: Customer isolation identifier.
        agent_id: Agent identifier for audit trail.
        tier: Default memory tier for new entries.
        enable_vectors: Whether to enable vector embeddings.
    """

    def __init__(
        self,
        domain: str = "general",
        customer_id: str = "default",
        agent_id: str = "default",
        tier: str = "managed",
        enable_vectors: bool = True,
    ) -> None:
        self._domain = domain
        self._customer_id = customer_id
        self._agent_id = agent_id
        self._tier = tier
        self._manager = MemoryManager(enable_vectors=enable_vectors)

    @property
    def domain(self) -> str:
        """Return the domain identifier."""
        return self._domain

    @property
    def customer_id(self) -> str:
        """Return the customer identifier."""
        return self._customer_id

    def store(
        self,
        key: str,
        value: Any,
        *,
        tier: MemoryTier = MemoryTier.SESSION,
        confidence: float = 1.0,
        provenance: dict[str, Any] | None = None,
        temporal_bounds: TemporalBounds | None = None,
        tags: list[str] | None = None,
    ) -> MemoryEntry:
        """Store a value in memory.

        Args:
            key: Unique key for the entry.
            value: Content to store.
            tier: Memory tier.
            confidence: Confidence score.
            provenance: Source attribution metadata.
            temporal_bounds: Time validity window.
            tags: Free-form tags.

        Returns:
            The created MemoryEntry.
        """
        return self._manager.store(
            key=key,
            value=value,
            tier=tier,
            confidence=confidence,
            provenance=provenance,
            temporal_bounds=temporal_bounds,
            tags=tags,
            agent_id=self._agent_id,
            customer_id=self._customer_id,
        )

    def retrieve(self, key: str) -> Any | None:
        """Retrieve a value by key.

        Args:
            key: The key to look up.

        Returns:
            The stored value, or None if not found.
        """
        entry = self._manager.retrieve(key, agent_id=self._agent_id, customer_id=self._customer_id)
        return entry.value if entry is not None else None

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a value with a default fallback.

        Args:
            key: The key to look up.
            default: Value to return if key not found.

        Returns:
            The stored value or the default.
        """
        result = self.retrieve(key)
        return result if result is not None else default

    def update(self, key: str, value: Any) -> bool:
        """Update an existing memory entry.

        Args:
            key: Key of the entry to update.
            value: New value.

        Returns:
            True if updated, False if not found.
        """
        return self._manager.update(
            key, value, agent_id=self._agent_id, customer_id=self._customer_id
        )

    def forget(self, key: str) -> bool:
        """Remove a memory entry.

        Args:
            key: Key of the entry to forget.

        Returns:
            True if removed, False if not found.
        """
        return self._manager.forget(key, agent_id=self._agent_id, customer_id=self._customer_id)

    def search(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        """Semantic search across all memory entries.

        Args:
            query: Search query string.
            top_k: Maximum number of results.

        Returns:
            List of dicts with 'key', 'value', 'tier', 'confidence' fields.
        """
        entries = self._manager.semantic_search(query, top_k=top_k)
        return [
            {
                "key": e.key,
                "value": e.value,
                "tier": e.tier.value,
                "confidence": e.confidence,
            }
            for e in entries
        ]

    def link(self, key_a: str, key_b: str, relation: str = "related") -> bool:
        """Create a semantic link between two entries.

        Args:
            key_a: First entry key.
            key_b: Second entry key.
            relation: Relationship type.

        Returns:
            True if linked successfully.
        """
        return self._manager.link(
            key_a, key_b, relation, agent_id=self._agent_id, customer_id=self._customer_id
        )

    def promote(self, key: str, target_tier: MemoryTier = MemoryTier.PERMANENT) -> bool:
        """Promote an entry to a higher tier.

        Args:
            key: Entry key.
            target_tier: Target tier.

        Returns:
            True if promoted.
        """
        return self._manager.promote(
            key, target_tier, agent_id=self._agent_id, customer_id=self._customer_id
        )

    def health(self) -> dict[str, Any]:
        """Return memory subsystem health dashboard.

        Returns:
            Dict with total_entries, tier_counts, event_log_size, integrity_ok.
        """
        return self._manager.health()

    def audit_trail(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[dict[str, Any]]:
        """Return the audit trail as simple dicts.

        Args:
            start: Optional start time filter.
            end: Optional end time filter.

        Returns:
            List of event dicts.
        """
        events = self._manager.audit_trail(start=start, end=end)
        return [
            {
                "event_id": e.id,
                "operation": e.operation.value,
                "key": e.key,
                "timestamp": e.timestamp.isoformat(),
                "agent_id": e.agent_id,
                "customer_id": e.customer_id,
            }
            for e in events
        ]

    def snapshot_at(self, timestamp: datetime) -> dict[str, Any]:
        """Reconstruct memory state at a point in time.

        Args:
            timestamp: The point in time.

        Returns:
            Dict with 'entries' key containing reconstructed state.
        """
        snap = self._manager.snapshot_at(timestamp)
        return {
            "timestamp": snap.timestamp.isoformat(),
            "entries": {k: v for k, v in snap.entries.items()},
            "num_entries": len(snap.entries),
        }

    def __contains__(self, key: str) -> bool:
        """Check if a key exists in memory."""
        return self._manager.retrieve(key) is not None

    def __repr__(self) -> str:
        return f"AegisMemory(domain={self._domain!r}, customer_id={self._customer_id!r})"
