"""Neo4j-based retrieval backend.

Wraps :class:`Neo4jGraph` to implement graph traversal retrieval,
converting subgraph neighbourhoods into :class:`ContextBlock` objects.
"""

from __future__ import annotations

import logging
from typing import Any

from aegis.core.settings import get_settings
from aegis.core.types import ContextBlock

logger = logging.getLogger(__name__)

try:
    from aegis.store.neo4j import Neo4jGraph

    _HAS_NEO4J = True
except Exception:
    _HAS_NEO4J = False


class Neo4jRetriever:
    """Retrieve context blocks by traversing a Neo4j knowledge graph.

    Finds nodes related to query entities and converts subgraph
    neighbourhoods into context blocks.

    Args:
        uri: Neo4j bolt URI.
        user: Neo4j username.
        password: Neo4j password.
        graph: An existing :class:`Neo4jGraph` instance to reuse.
    """

    def __init__(
        self,
        uri: str | None = None,
        user: str | None = None,
        password: str | None = None,
        graph: Any | None = None,
    ) -> None:
        if graph is not None:
            self._graph = graph
        else:
            if not _HAS_NEO4J:
                raise RuntimeError(
                    "neo4j driver required. Install with: pip install 'aegis-eval[db]'"
                )
            settings = get_settings()
            resolved_uri = uri or settings.neo4j_uri
            resolved_user = user or settings.neo4j_user
            resolved_password = password or settings.neo4j_password
            self._graph = Neo4jGraph(
                uri=resolved_uri,
                user=resolved_user,
                password=resolved_password,
            )

    def query(
        self,
        query: str,
        top_k: int = 10,
        depth: int = 2,
    ) -> list[ContextBlock]:
        """Search the knowledge graph for relevant subgraphs.

        Extracts key terms from the query, finds matching nodes, then
        expands their neighbourhoods into context blocks.

        Args:
            query: Natural language query.
            top_k: Maximum number of results.
            depth: Graph traversal depth.

        Returns:
            Context blocks derived from graph traversal.
        """
        # Extract potential entity terms from the query
        terms = self._extract_terms(query)
        blocks: list[ContextBlock] = []
        seen_nodes: set[str] = set()

        for term in terms:
            if len(blocks) >= top_k:
                break

            # Check if node exists
            if not self._graph.has_node(term):
                continue

            if term in seen_nodes:
                continue
            seen_nodes.add(term)

            # Get subgraph around this node
            subgraph = self._graph.subgraph(term, depth=depth)
            for _source_id, edges in subgraph.items():
                if len(blocks) >= top_k:
                    break
                for edge in edges:
                    if len(blocks) >= top_k:
                        break
                    content = f"{edge.source} --[{edge.relation}]--> {edge.target}"
                    blocks.append(
                        ContextBlock(
                            source_id=f"kg:{edge.source}:{edge.target}",
                            content=content,
                            rerank_score=edge.weight,
                            selected=False,
                        )
                    )

            # Also add the node's direct neighbours as context
            neighbours = self._graph.neighbors(term)
            for neighbour in neighbours:
                if len(blocks) >= top_k:
                    break
                if neighbour not in seen_nodes:
                    blocks.append(
                        ContextBlock(
                            source_id=f"kg:{term}:{neighbour}",
                            content=f"{term} is connected to {neighbour}",
                            rerank_score=0.5,
                            selected=False,
                        )
                    )

        return blocks[:top_k]

    @staticmethod
    def _extract_terms(query: str) -> list[str]:
        """Extract potential entity references from a query.

        Uses simple heuristics: capitalised words and multi-word spans.
        """
        import re

        words = query.split()
        terms: list[str] = []

        # Capitalised words (likely proper nouns / entities)
        for word in words:
            cleaned = re.sub(r"[^\w]", "", word)
            if cleaned and cleaned[0].isupper() and len(cleaned) > 1:
                terms.append(cleaned)

        # Also try the full query as a potential node ID
        terms.append(query.strip())

        # Normalised lowercase versions
        terms.extend(t.lower() for t in terms if t.lower() not in terms)

        return terms
