"""PgVector-based retrieval backend.

Wraps :class:`PgVectorStore` to implement the :class:`RetrievalBackend`
protocol, translating semantic search results into :class:`ContextBlock`
objects for the context constructor.
"""

from __future__ import annotations

import logging
from typing import Any

from aegis.core.settings import get_settings
from aegis.core.types import ContextBlock

logger = logging.getLogger(__name__)

try:
    from aegis.store.postgres import PgVectorStore

    _HAS_PG = True
except Exception:
    _HAS_PG = False


class PgVectorRetriever:
    """Retrieve context blocks via pgvector semantic search.

    Args:
        dsn: PostgreSQL connection string.  Falls back to
            ``AEGIS_POSTGRES_DSN`` env-var.
        store: An existing :class:`PgVectorStore` instance to reuse.
    """

    def __init__(
        self,
        dsn: str | None = None,
        store: Any | None = None,
    ) -> None:
        if store is not None:
            self._store = store
        else:
            if not _HAS_PG:
                raise RuntimeError(
                    "psycopg and pgvector required. Install with: pip install 'aegis-eval[db]'"
                )
            resolved_dsn = dsn or get_settings().postgres_dsn
            self._store = PgVectorStore(dsn=resolved_dsn)

    def query(
        self,
        query: str,
        top_k: int = 10,
    ) -> list[ContextBlock]:
        """Search pgvector for the most relevant entries.

        Args:
            query: Natural language query.
            top_k: Maximum number of results.

        Returns:
            Context blocks sorted by descending relevance.
        """
        entries = self._store.search(query, top_k=top_k)
        blocks: list[ContextBlock] = []
        for entry in entries:
            content = entry.value if isinstance(entry.value, str) else str(entry.value)
            blocks.append(
                ContextBlock(
                    source_id=entry.key,
                    content=content,
                    rerank_score=entry.confidence,
                    selected=False,
                )
            )
        return blocks
