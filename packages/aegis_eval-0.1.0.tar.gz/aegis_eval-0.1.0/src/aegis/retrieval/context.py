"""Retrieval context construction and policy engine.

:class:`RetrievalPolicy` defines which sources to query and how to
rank/select context blocks.  :class:`ContextConstructor` builds the
final context window from retrieved results, applying budget
constraints and anti-retrieval filters.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Protocol, runtime_checkable

from aegis.core.types import ContextBlock, RetrievalSource, RetrievalTraceV1

logger = logging.getLogger(__name__)

try:
    from sentence_transformers import CrossEncoder

    _HAS_CROSS_ENCODER = True
except ImportError:
    _HAS_CROSS_ENCODER = False


@runtime_checkable
class RetrievalBackend(Protocol):
    """Protocol for pluggable retrieval backends.

    Any object with a ``query(query, top_k)`` method returning a list of
    :class:`ContextBlock` can serve as a retrieval backend.
    """

    def query(self, query: str, top_k: int = 10) -> list[ContextBlock]: ...


@dataclass
class RetrievalPolicy:
    """Configuration governing retrieval behaviour.

    Attributes:
        source_types: Ordered list of source types to query
            (e.g. ``["vector", "kg", "sql"]``).
        top_k: Maximum number of candidates to retrieve per source.
        rerank: Whether to apply a reranking stage.
        rerank_model: Model identifier for the reranker.
        context_budget_tokens: Maximum token budget for the assembled
            context window.
        anti_retrieval_enabled: Whether to activate the anti-retrieval
            filter that removes irrelevant or misleading context.
        min_relevance_score: Minimum rerank score for a block to be
            selected.
    """

    source_types: list[str] = field(default_factory=lambda: ["vector"])
    top_k: int = 20
    rerank: bool = True
    rerank_model: str = "cross-encoder/ms-marco-MiniLM-L-12-v2"
    context_budget_tokens: int = 4096
    anti_retrieval_enabled: bool = True
    min_relevance_score: float = 0.3
    enable_compression: bool = True
    compression_floor_tokens: int = 24


class ContextConstructor:
    """Builds the context window from retrieval results.

    Applies the :class:`RetrievalPolicy` to select, order, and truncate
    context blocks within the token budget.

    Args:
        policy: The :class:`RetrievalPolicy` governing retrieval.
        backends: Optional list of :class:`RetrievalBackend` instances
            to query. When provided, ``retrieve_and_construct`` will
            query these backends instead of relying on pre-supplied
            source blocks.
    """

    def __init__(
        self,
        policy: RetrievalPolicy | None = None,
        backends: list[RetrievalBackend] | None = None,
    ) -> None:
        self._policy = policy or RetrievalPolicy()
        self._backends = backends or []
        self._cross_encoder: Any | None = None

    @property
    def policy(self) -> RetrievalPolicy:
        """Return the current retrieval policy."""
        return self._policy

    def retrieve_and_construct(
        self,
        query: str,
        sources: list[Any] | None = None,
    ) -> RetrievalTraceV1:
        """Execute retrieval and construct the context window.

        This is the main entry point.  It queries configured sources,
        reranks candidates, applies the context budget, and produces a
        full :class:`RetrievalTraceV1` audit trail.

        Args:
            query: The user or agent query to retrieve context for.
            sources: Optional list of pre-configured source connectors.
                If ``None``, uses the source types from the policy.

        Returns:
            A :class:`RetrievalTraceV1` containing the full audit trail
            of sources queried, blocks selected, and blocks dropped.
        """
        # 1. Build context blocks from backends, provided sources, or fallback
        blocks: list[ContextBlock] = []
        source_type_map: dict[str, str] = {}  # source_id -> source_type

        # Query pluggable backends first
        if self._backends:
            for backend in self._backends:
                try:
                    backend_blocks = backend.query(query, top_k=self._policy.top_k)
                    blocks.extend(backend_blocks)
                except Exception:
                    logger.warning(
                        "Retrieval backend %s failed", type(backend).__name__, exc_info=True
                    )

        if sources:
            for src in sources:
                if isinstance(src, ContextBlock):
                    blocks.append(src)
                elif isinstance(src, dict):
                    src_id = src.get("source_id", "")
                    source_type_map[src_id] = src.get("source_type", "unknown")
                    blocks.append(
                        ContextBlock(
                            source_id=src_id,
                            content=src.get("content", ""),
                            rerank_score=0.0,
                            selected=False,
                        )
                    )

        if not blocks:
            blocks.append(
                ContextBlock(
                    source_id="query_fallback",
                    content=query,
                    rerank_score=0.0,
                    selected=False,
                )
            )

        # 2. Deduplicate by source_id
        seen_ids: set[str] = set()
        unique_blocks: list[ContextBlock] = []
        for block in blocks:
            if block.source_id not in seen_ids:
                seen_ids.add(block.source_id)
                unique_blocks.append(block)
        blocks = unique_blocks

        total_retrieved = len(blocks)

        # 3. Rerank
        blocks = self.rerank(query, blocks)

        # 4. Anti-retrieval filter
        anti_retrieval_triggered = False
        anti_retrieval_removed = 0
        if self._policy.anti_retrieval_enabled:
            before_count = len(blocks)
            blocks = self.anti_retrieval_filter(blocks)
            anti_retrieval_removed = before_count - len(blocks)
            anti_retrieval_triggered = anti_retrieval_removed > 0

        # 5. Apply budget
        selected, dropped = self.apply_budget(blocks)

        # Mark blocks
        for block in selected:
            block.selected = True
        for block in dropped:
            block.selected = False
            block.reason = block.reason or "budget_exceeded_or_low_relevance"

        all_blocks = selected + dropped

        # Build retrieval sources summary
        sources_queried = [
            RetrievalSource(
                source_type=st,
                query=query,
                results_count=sum(1 for b in all_blocks if source_type_map.get(b.source_id) == st),
                latency_ms=0,
            )
            for st in self._policy.source_types
        ]

        return RetrievalTraceV1(
            trajectory_id="",
            sources_queried=sources_queried,
            context_blocks=all_blocks,
            total_retrieved=total_retrieved,
            total_selected=len(selected),
            total_dropped=len(dropped) + anti_retrieval_removed,
            anti_retrieval_triggered=anti_retrieval_triggered,
            context_budget_tokens=self._policy.context_budget_tokens,
        )

    def rerank(
        self,
        query: str,
        blocks: list[ContextBlock],
    ) -> list[ContextBlock]:
        """Rerank context blocks by relevance to the query.

        Uses a cross-encoder model (ms-marco-MiniLM) when
        ``sentence-transformers`` is installed, otherwise falls back
        to ``SequenceMatcher`` text similarity.

        Args:
            query: The query to rank against.
            blocks: Candidate context blocks.

        Returns:
            Blocks sorted by descending rerank score.
        """
        if not blocks:
            return blocks

        if self._policy.rerank and _HAS_CROSS_ENCODER:
            return self._rerank_cross_encoder(query, blocks)

        return self._rerank_sequence_matcher(query, blocks)

    def _rerank_cross_encoder(
        self,
        query: str,
        blocks: list[ContextBlock],
    ) -> list[ContextBlock]:
        """Rerank using a cross-encoder model for high-quality relevance scores."""
        try:
            if self._cross_encoder is None:
                self._cross_encoder = CrossEncoder(self._policy.rerank_model)

            pairs = [[query, block.content] for block in blocks]
            scores = self._cross_encoder.predict(pairs)

            for block, score in zip(blocks, scores, strict=False):
                # Cross-encoder scores can be negative; normalise to [0, 1]
                block.rerank_score = float(1.0 / (1.0 + __import__("math").exp(-float(score))))

            return sorted(blocks, key=lambda b: b.rerank_score, reverse=True)
        except Exception:
            logger.warning(
                "Cross-encoder reranking failed, falling back to SequenceMatcher", exc_info=True
            )
            return self._rerank_sequence_matcher(query, blocks)

    @staticmethod
    def _rerank_sequence_matcher(
        query: str,
        blocks: list[ContextBlock],
    ) -> list[ContextBlock]:
        """Fallback reranker using difflib SequenceMatcher."""
        for block in blocks:
            block.rerank_score = SequenceMatcher(None, query.lower(), block.content.lower()).ratio()
        return sorted(blocks, key=lambda b: b.rerank_score, reverse=True)

    def apply_budget(
        self,
        blocks: list[ContextBlock],
    ) -> tuple[list[ContextBlock], list[ContextBlock]]:
        """Apply token budget constraints, splitting into selected and dropped.

        Args:
            blocks: Ranked context blocks.

        Returns:
            A tuple of (selected_blocks, dropped_blocks).
        """
        selected: list[ContextBlock] = []
        dropped: list[ContextBlock] = []
        accumulated_tokens = 0

        for block in blocks:
            # Filter out blocks below minimum relevance score
            if block.rerank_score < self._policy.min_relevance_score:
                block.reason = "below_min_relevance_score"
                dropped.append(block)
                continue

            token_count = self._estimate_tokens(block.content)

            if accumulated_tokens + token_count <= self._policy.context_budget_tokens:
                accumulated_tokens += token_count
                selected.append(block)
            else:
                remaining_tokens = self._policy.context_budget_tokens - accumulated_tokens
                compressed_block = self._compress_block_to_budget(
                    block,
                    remaining_tokens,
                )
                if compressed_block is not None:
                    compressed_tokens = self._estimate_tokens(compressed_block.content)
                    accumulated_tokens += compressed_tokens
                    selected.append(compressed_block)
                else:
                    block.reason = "budget_exceeded"
                    dropped.append(block)

        return selected, dropped

    @staticmethod
    def _estimate_tokens(content: str) -> int:
        """Approximate token count from whitespace-delimited words."""
        return int(len(content.split()) * 1.3)

    def _compress_block_to_budget(
        self,
        block: ContextBlock,
        remaining_tokens: int,
    ) -> ContextBlock | None:
        """Return a compressed block that fits remaining budget, else None."""
        if not self._policy.enable_compression:
            return None
        if remaining_tokens < self._policy.compression_floor_tokens:
            return None

        # Inverse the 1.3 token approximation.
        max_words = int(remaining_tokens / 1.3)
        if max_words < 3:
            return None

        words = block.content.split()
        if len(words) <= max_words:
            return block

        compressed = " ".join(words[:max_words])
        if not compressed:
            return None

        return block.model_copy(
            update={
                "content": compressed,
                "reason": "compressed_to_fit_budget",
            }
        )

    def anti_retrieval_filter(
        self,
        blocks: list[ContextBlock],
    ) -> list[ContextBlock]:
        """Filter out context blocks flagged by the anti-retrieval module.

        Anti-retrieval prevents the agent from being misled by
        irrelevant, adversarial, or outdated context.

        Args:
            blocks: Candidate context blocks.

        Returns:
            Blocks that pass the anti-retrieval filter.
        """
        if not self._policy.anti_retrieval_enabled:
            return blocks

        adversarial_pattern = re.compile(
            r"ignore previous|forget all|override|system prompt|<script",
            re.IGNORECASE,
        )

        passing: list[ContextBlock] = []
        for block in blocks:
            # Filter trivial/noise content
            if len(block.content) < 10:
                continue
            # Filter very low relevance
            if block.rerank_score < 0.1:
                continue
            # Filter adversarial patterns
            if adversarial_pattern.search(block.content):
                continue
            passing.append(block)

        return passing
