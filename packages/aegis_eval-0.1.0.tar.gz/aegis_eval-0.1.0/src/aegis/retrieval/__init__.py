"""Aegis Retrieval — context construction, policy, and local indexing.

Re-exports :class:`ContextConstructor`, :class:`RetrievalPolicy`, and
:class:`LocalSourceIndex`.
"""

from aegis.retrieval.context import ContextConstructor, RetrievalPolicy
from aegis.retrieval.local_index import LocalSourceIndex

__all__ = [
    "ContextConstructor",
    "RetrievalPolicy",
    "LocalSourceIndex",
]
