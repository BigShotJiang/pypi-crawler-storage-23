"""Deterministic local retrieval index backed by in-repo fixtures."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_VALID_SOURCE_TYPES = ("vector", "kg", "sql", "web")
_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
_DEFAULT_FIXTURE_PATH = Path(__file__).with_name("fixtures") / "local_sources.json"


@dataclass(frozen=True)
class _LocalDocument:
    source_id: str
    source_type: str
    content: str
    metadata: dict[str, Any]


class LocalSourceIndex:
    """Local lexical retrieval index for deterministic offline runs."""

    def __init__(self, fixture_path: str | Path | None = None) -> None:
        self._fixture_path = (
            Path(fixture_path) if fixture_path is not None else _DEFAULT_FIXTURE_PATH
        )
        self._documents_by_source = self._load_fixture_documents(self._fixture_path)

    def query(
        self,
        query: str,
        source_types: list[str],
        top_k_per_source: int = 5,
    ) -> list[dict[str, Any]]:
        """Query the local index using lexical overlap scoring.

        Args:
            query: User query text.
            source_types: Source types requested by the caller.
            top_k_per_source: Max candidates returned per source.

        Returns:
            Ordered retrieval candidates with deterministic scores and tie-breaks.
        """
        clean_query = query.strip()
        if not clean_query:
            raise ValueError("Query must be non-empty for local retrieval indexing.")

        sources = self._normalize_source_types(source_types)
        query_terms = self._tokenize(clean_query)

        candidates: list[dict[str, Any]] = []
        for source_type in sources:
            source_docs = self._documents_by_source.get(source_type, [])
            if not source_docs:
                continue

            scored: list[tuple[float, _LocalDocument]] = []
            for doc in source_docs:
                score = self._lexical_score(query_terms, self._tokenize(doc.content))
                scored.append((score, doc))

            ranked = sorted(
                scored,
                key=lambda item: (-item[0], item[1].source_id),
            )
            for score, doc in ranked[: max(1, top_k_per_source)]:
                metadata = dict(doc.metadata)
                metadata["lexical_score"] = round(score, 6)
                candidates.append(
                    {
                        "source_id": doc.source_id,
                        "source_type": doc.source_type,
                        "content": doc.content,
                        "metadata": metadata,
                    }
                )

        return candidates

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        return set(_TOKEN_PATTERN.findall(text.lower()))

    @staticmethod
    def _lexical_score(query_terms: set[str], doc_terms: set[str]) -> float:
        if not query_terms or not doc_terms:
            return 0.0

        overlap = len(query_terms & doc_terms)
        if overlap == 0:
            return 0.0

        query_coverage = overlap / len(query_terms)
        doc_density = overlap / len(doc_terms)
        exact_bonus = 0.05 if query_terms.issubset(doc_terms) else 0.0
        return (0.75 * query_coverage) + (0.25 * doc_density) + exact_bonus

    @staticmethod
    def _normalize_source_types(source_types: list[str]) -> list[str]:
        requested = [source.strip().lower() for source in source_types if source.strip()]
        deduped: list[str] = []
        seen: set[str] = set()
        for source in requested:
            if source in _VALID_SOURCE_TYPES and source not in seen:
                deduped.append(source)
                seen.add(source)

        if deduped:
            return deduped
        return ["vector"]

    @staticmethod
    def _load_fixture_documents(path: Path) -> dict[str, list[_LocalDocument]]:
        if not path.exists():
            raise ValueError(
                f"Local retrieval fixture '{path}' was not found. "
                "Ensure src/aegis/retrieval/fixtures/local_sources.json exists."
            )

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except OSError as exc:
            raise ValueError(f"Unable to read local retrieval fixture '{path}': {exc}") from exc
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Invalid JSON in local retrieval fixture '{path}': {exc.msg}"
            ) from exc

        if not isinstance(payload, dict):
            raise ValueError(
                f"Local retrieval fixture '{path}' must contain a JSON object keyed by source type."
            )

        docs_by_source: dict[str, list[_LocalDocument]] = {
            source: [] for source in _VALID_SOURCE_TYPES
        }

        for source_type, rows in payload.items():
            if source_type not in docs_by_source:
                continue
            if not isinstance(rows, list):
                raise ValueError(
                    f"Fixture entries for source '{source_type}' must be a list, got {type(rows).__name__}."
                )

            for idx, row in enumerate(rows):
                if not isinstance(row, dict):
                    raise ValueError(
                        f"Fixture row {idx} for source '{source_type}' must be an object."
                    )

                source_id = str(row.get("source_id") or f"{source_type}-{idx:03d}")
                content = str(row.get("content") or "").strip()
                if not content:
                    raise ValueError(
                        f"Fixture row {idx} for source '{source_type}' has empty content."
                    )

                metadata = row.get("metadata")
                metadata_dict: dict[str, Any]
                if isinstance(metadata, dict):
                    metadata_dict = {str(k): v for k, v in metadata.items()}
                else:
                    metadata_dict = {}

                docs_by_source[source_type].append(
                    _LocalDocument(
                        source_id=source_id,
                        source_type=source_type,
                        content=content,
                        metadata=metadata_dict,
                    )
                )

        if all(not docs for docs in docs_by_source.values()):
            raise ValueError(
                f"Local retrieval fixture '{path}' contains no usable source documents."
            )

        for source_type, docs in docs_by_source.items():
            docs.sort(key=lambda doc: doc.source_id)
            docs_by_source[source_type] = docs

        return docs_by_source
