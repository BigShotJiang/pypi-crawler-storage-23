"""No-code rubric definition system for domain experts.

Provides a builder API for creating evaluation rubrics, attaching weighted
criteria with type-specific parameters, calibrating against expert judgments,
and exporting rubrics as reward-engine configurations.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class CriterionType(str, Enum):
    """Types of evaluation criteria supported by the rubric system."""

    MUST_INCLUDE = "must_include"
    MUST_NOT_INCLUDE = "must_not_include"
    QUALITY_RANGE = "quality_range"
    PRESENCE_CHECK = "presence_check"
    CITATION_REQUIRED = "citation_required"
    NUMERICAL_ACCURACY = "numerical_accuracy"
    TEMPORAL_CONSISTENCY = "temporal_consistency"
    COMPLETENESS = "completeness"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class EvalCriterion:
    """A single evaluation criterion within a rubric."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    criterion_type: CriterionType = CriterionType.PRESENCE_CHECK
    parameters: dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0
    domain: str | None = None
    examples_good: list[str] = field(default_factory=list)
    examples_bad: list[str] = field(default_factory=list)


@dataclass
class Rubric:
    """A complete evaluation rubric composed of weighted criteria."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    domain: str = ""
    criteria: list[EvalCriterion] = field(default_factory=list)
    version: int = 1
    created_by: str = "system"
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CalibrationSample:
    """A sample used to calibrate a rubric against expert judgment."""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    input_text: str = ""
    agent_output: str = ""
    expert_judgment: str = "acceptable"  # "acceptable" | "unacceptable"
    expert_notes: str = ""
    rubric_id: str = ""


# ---------------------------------------------------------------------------
# Criterion evaluation helpers
# ---------------------------------------------------------------------------


def _score_criterion(criterion: EvalCriterion, text: str) -> float:
    """Score a single criterion against *text*.  Returns 0.0-1.0."""
    ct = criterion.criterion_type
    params = criterion.parameters

    if ct == CriterionType.MUST_INCLUDE:
        # params: {"terms": ["term1", "term2"]}
        terms: list[str] = params.get("terms", [])
        if not terms:
            return 1.0
        matches = sum(1 for t in terms if t.lower() in text.lower())
        return matches / len(terms)

    if ct == CriterionType.MUST_NOT_INCLUDE:
        # params: {"terms": ["banned1", "banned2"]}
        terms = params.get("terms", [])
        if not terms:
            return 1.0
        violations = sum(1 for t in terms if t.lower() in text.lower())
        return 1.0 - (violations / len(terms))

    if ct == CriterionType.QUALITY_RANGE:
        # params: {"min_length": 100, "max_length": 5000}
        min_len = params.get("min_length", 0)
        max_len = params.get("max_length", float("inf"))
        length = len(text)
        if min_len <= length <= max_len:
            return 1.0
        if length < min_len:
            return max(0.0, length / min_len) if min_len > 0 else 0.0
        # length > max_len
        return max(0.0, 1.0 - (length - max_len) / max_len) if max_len > 0 else 0.0

    if ct == CriterionType.PRESENCE_CHECK:
        # params: {"patterns": ["regex_pattern1", ...]}
        patterns: list[str] = params.get("patterns", [])
        if not patterns:
            return 1.0
        matches = sum(1 for p in patterns if re.search(p, text, re.IGNORECASE))
        return matches / len(patterns)

    if ct == CriterionType.CITATION_REQUIRED:
        # params: {"min_citations": 2, "citation_pattern": r"\[\d+\]"}
        pattern = params.get("citation_pattern", r"\[\d+\]")
        min_cites = params.get("min_citations", 1)
        found = len(re.findall(pattern, text))
        if found >= min_cites:
            return 1.0
        return found / min_cites if min_cites > 0 else 0.0

    if ct == CriterionType.NUMERICAL_ACCURACY:
        # params: {"expected_numbers": {"revenue": 1000.0}, "tolerance": 0.05}
        expected: dict[str, float] = params.get("expected_numbers", {})
        tolerance: float = params.get("tolerance", 0.05)
        if not expected:
            return 1.0
        found_numbers = re.findall(r"[\d,]+\.?\d*", text)
        parsed = []
        for n in found_numbers:
            try:
                parsed.append(float(n.replace(",", "")))
            except ValueError:
                continue
        if not parsed:
            return 0.0
        matches = 0
        for _label, exp_val in expected.items():
            for p in parsed:
                if abs(p - exp_val) <= abs(exp_val * tolerance):
                    matches += 1
                    break
        return matches / len(expected)

    if ct == CriterionType.TEMPORAL_CONSISTENCY:
        # params: {"reference_date": "2025-01-01", "must_be_after": true}
        ref_str = params.get("reference_date", "")
        date_pattern = r"\d{4}-\d{2}-\d{2}"
        dates_found = re.findall(date_pattern, text)
        if not dates_found or not ref_str:
            return 0.5  # indeterminate
        must_be_after = params.get("must_be_after", True)
        consistent = 0
        for d in dates_found:
            if must_be_after and d >= ref_str or not must_be_after and d <= ref_str:
                consistent += 1
        return consistent / len(dates_found)

    if ct == CriterionType.COMPLETENESS:
        # params: {"required_sections": ["Introduction", "Conclusion", ...]}
        sections: list[str] = params.get("required_sections", [])
        if not sections:
            return 1.0
        found = sum(1 for s in sections if s.lower() in text.lower())
        return found / len(sections)

    return 0.5  # fallback for unknown types


# ---------------------------------------------------------------------------
# RubricBuilder
# ---------------------------------------------------------------------------


class RubricBuilder:
    """Builder for creating, editing, calibrating, and exporting rubrics.

    Maintains an in-memory registry of rubrics and provides methods to
    convert rubric criteria into reward-engine configurations.
    """

    def __init__(self) -> None:
        self._rubrics: dict[str, Rubric] = {}

    # -- CRUD ---------------------------------------------------------------

    def create_rubric(
        self,
        name: str,
        description: str,
        domain: str,
        created_by: str = "system",
    ) -> Rubric:
        """Create an empty rubric and register it."""
        rubric = Rubric(
            name=name,
            description=description,
            domain=domain,
            created_by=created_by,
        )
        self._rubrics[rubric.id] = rubric
        return rubric

    def add_criterion(self, rubric_id: str, criterion: EvalCriterion) -> Rubric:
        """Add a criterion to an existing rubric.

        Raises ``KeyError`` if the rubric does not exist.
        """
        rubric = self._require_rubric(rubric_id)
        rubric.criteria.append(criterion)
        rubric.version += 1
        return rubric

    def remove_criterion(self, rubric_id: str, criterion_id: str) -> Rubric:
        """Remove a criterion by id from a rubric.

        Raises ``KeyError`` if the rubric is not found.
        Raises ``ValueError`` if the criterion is not found in the rubric.
        """
        rubric = self._require_rubric(rubric_id)
        original_len = len(rubric.criteria)
        rubric.criteria = [c for c in rubric.criteria if c.id != criterion_id]
        if len(rubric.criteria) == original_len:
            raise ValueError(f"Criterion '{criterion_id}' not found in rubric '{rubric_id}'")
        rubric.version += 1
        return rubric

    def update_criterion(
        self,
        rubric_id: str,
        criterion_id: str,
        updates: dict[str, Any],
    ) -> Rubric:
        """Patch fields on an existing criterion.

        Raises ``KeyError`` if the rubric is not found.
        Raises ``ValueError`` if the criterion is not found.
        """
        rubric = self._require_rubric(rubric_id)
        target: EvalCriterion | None = None
        for c in rubric.criteria:
            if c.id == criterion_id:
                target = c
                break
        if target is None:
            raise ValueError(f"Criterion '{criterion_id}' not found in rubric '{rubric_id}'")

        for key, value in updates.items():
            if hasattr(target, key):
                setattr(target, key, value)

        rubric.version += 1
        return rubric

    def get_rubric(self, rubric_id: str) -> Rubric | None:
        """Return rubric by id or ``None``."""
        return self._rubrics.get(rubric_id)

    def list_rubrics(self, domain: str | None = None) -> list[Rubric]:
        """List all rubrics, optionally filtered by domain."""
        rubrics = list(self._rubrics.values())
        if domain is not None:
            rubrics = [r for r in rubrics if r.domain == domain]
        return rubrics

    # -- Validation ---------------------------------------------------------

    def validate_rubric(self, rubric: Rubric) -> dict[str, Any]:
        """Check rubric completeness and consistency.

        Returns a dict with ``valid`` (bool), ``issues`` (list[str]),
        and ``stats`` (dict) fields.
        """
        issues: list[str] = []

        if not rubric.criteria:
            issues.append("Rubric has no criteria")

        # Weight sanity: total weight should be positive
        total_weight = sum(c.weight for c in rubric.criteria)
        if rubric.criteria and total_weight <= 0:
            issues.append("Total criterion weight is not positive")

        if rubric.criteria and not (0.5 <= total_weight <= 100.0):
            issues.append(
                f"Total criterion weight ({total_weight:.2f}) is outside reasonable range [0.5, 100]"
            )

        # Examples check
        criteria_without_good = [c.name for c in rubric.criteria if not c.examples_good]
        criteria_without_bad = [c.name for c in rubric.criteria if not c.examples_bad]
        if criteria_without_good:
            issues.append(f"Criteria missing good examples: {', '.join(criteria_without_good)}")
        if criteria_without_bad:
            issues.append(f"Criteria missing bad examples: {', '.join(criteria_without_bad)}")

        # Description check
        if not rubric.description:
            issues.append("Rubric has no description")

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "stats": {
                "criteria_count": len(rubric.criteria),
                "total_weight": round(total_weight, 4),
                "types_used": list({c.criterion_type.value for c in rubric.criteria}),
                "has_domain": bool(rubric.domain),
            },
        }

    # -- Reward config conversion -------------------------------------------

    def to_reward_config(self, rubric: Rubric) -> list[dict[str, Any]]:
        """Convert rubric criteria into reward function configuration.

        Each criterion becomes a reward stage config dict with fields
        compatible with the ``RewardStageConfig`` / ``RewardEngine`` API.
        """
        configs: list[dict[str, Any]] = []
        total_weight = sum(c.weight for c in rubric.criteria) or 1.0

        for idx, criterion in enumerate(rubric.criteria):
            normalized_weight = criterion.weight / total_weight

            # Map criterion type to a rule-based check descriptor
            check = _criterion_to_check(criterion)

            configs.append(
                {
                    "stage": idx,
                    "stage_name": criterion.name.lower().replace(" ", "_"),
                    "weight": round(normalized_weight, 4),
                    "criterion_type": criterion.criterion_type.value,
                    "rule_check": check,
                    "rule_weight": 0.5,
                    "semantic_weight": 0.3,
                    "judge_weight": 0.2,
                    "domain": criterion.domain or rubric.domain,
                    "criterion_id": criterion.id,
                }
            )

        return configs

    # -- Calibration --------------------------------------------------------

    def calibrate(
        self,
        rubric_id: str,
        samples: list[CalibrationSample],
    ) -> dict[str, Any]:
        """Run calibration against expert-judged samples.

        For each sample the rubric criteria are scored against the agent
        output, a verdict is computed, and compared against the expert
        judgment.  Returns agreement statistics and per-sample details.
        """
        rubric = self._require_rubric(rubric_id)

        if not samples:
            return {
                "rubric_id": rubric_id,
                "samples_evaluated": 0,
                "agreement_rate": 0.0,
                "details": [],
            }

        agreements = 0
        details: list[dict[str, Any]] = []

        for sample in samples:
            # Score each criterion
            criterion_scores: dict[str, float] = {}
            for criterion in rubric.criteria:
                criterion_scores[criterion.name] = _score_criterion(criterion, sample.agent_output)

            # Weighted aggregate
            total_weight = sum(c.weight for c in rubric.criteria) or 1.0
            aggregate = (
                sum(criterion_scores[c.name] * c.weight for c in rubric.criteria) / total_weight
            )

            # Determine predicted verdict (threshold = 0.5)
            predicted = "acceptable" if aggregate >= 0.5 else "unacceptable"
            agrees = predicted == sample.expert_judgment
            if agrees:
                agreements += 1

            details.append(
                {
                    "sample_id": sample.id,
                    "criterion_scores": criterion_scores,
                    "aggregate_score": round(aggregate, 4),
                    "predicted": predicted,
                    "expert": sample.expert_judgment,
                    "agrees": agrees,
                }
            )

        agreement_rate = agreements / len(samples)

        # Disagreement analysis: find criteria that contribute most to
        # disagreements with expert judgment
        disagreement_samples = [d for d in details if not d["agrees"]]
        criterion_disagreement_counts: dict[str, int] = {}
        for d in disagreement_samples:
            for cname, cscore in d["criterion_scores"].items():
                # A criterion "disagrees" if its score direction opposes the
                # expert verdict (high score but expert says unacceptable,
                # or low score but expert says acceptable)
                expert_accepts = d["expert"] == "acceptable"
                criterion_accepts = cscore >= 0.5
                if expert_accepts != criterion_accepts:
                    criterion_disagreement_counts[cname] = (
                        criterion_disagreement_counts.get(cname, 0) + 1
                    )

        return {
            "rubric_id": rubric_id,
            "samples_evaluated": len(samples),
            "agreement_rate": round(agreement_rate, 4),
            "disagreements": len(disagreement_samples),
            "criterion_disagreement_counts": criterion_disagreement_counts,
            "details": details,
        }

    # -- Export / Import ----------------------------------------------------

    def export_rubric(self, rubric_id: str) -> dict[str, Any]:
        """Export a rubric as a JSON-serializable dict."""
        rubric = self._require_rubric(rubric_id)
        return {
            "id": rubric.id,
            "name": rubric.name,
            "description": rubric.description,
            "domain": rubric.domain,
            "version": rubric.version,
            "created_by": rubric.created_by,
            "created_at": rubric.created_at.isoformat(),
            "metadata": rubric.metadata,
            "criteria": [
                {
                    "id": c.id,
                    "name": c.name,
                    "description": c.description,
                    "criterion_type": c.criterion_type.value,
                    "parameters": c.parameters,
                    "weight": c.weight,
                    "domain": c.domain,
                    "examples_good": c.examples_good,
                    "examples_bad": c.examples_bad,
                }
                for c in rubric.criteria
            ],
        }

    def import_rubric(self, data: dict[str, Any]) -> Rubric:
        """Import a rubric from a dict (e.g., previously exported JSON)."""
        criteria = [
            EvalCriterion(
                id=c.get("id", str(uuid.uuid4())),
                name=c.get("name", ""),
                description=c.get("description", ""),
                criterion_type=CriterionType(c["criterion_type"]),
                parameters=c.get("parameters", {}),
                weight=c.get("weight", 1.0),
                domain=c.get("domain"),
                examples_good=c.get("examples_good", []),
                examples_bad=c.get("examples_bad", []),
            )
            for c in data.get("criteria", [])
        ]

        created_at_raw = data.get("created_at")
        if isinstance(created_at_raw, str):
            created_at = datetime.fromisoformat(created_at_raw)
        else:
            created_at = datetime.now(tz=UTC)

        rubric = Rubric(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            domain=data.get("domain", ""),
            criteria=criteria,
            version=data.get("version", 1),
            created_by=data.get("created_by", "import"),
            created_at=created_at,
            metadata=data.get("metadata", {}),
        )
        self._rubrics[rubric.id] = rubric
        return rubric

    # -- Summary ------------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return an overview of all rubrics managed by this builder."""
        domains: dict[str, int] = {}
        total_criteria = 0
        for r in self._rubrics.values():
            domains[r.domain] = domains.get(r.domain, 0) + 1
            total_criteria += len(r.criteria)

        return {
            "total_rubrics": len(self._rubrics),
            "total_criteria": total_criteria,
            "domains": domains,
            "criterion_types_used": sorted(
                {c.criterion_type.value for r in self._rubrics.values() for c in r.criteria}
            ),
        }

    # -- Internal helpers ---------------------------------------------------

    def _require_rubric(self, rubric_id: str) -> Rubric:
        rubric = self._rubrics.get(rubric_id)
        if rubric is None:
            raise KeyError(f"Rubric '{rubric_id}' not found")
        return rubric


# ---------------------------------------------------------------------------
# Module-private helpers
# ---------------------------------------------------------------------------


def _criterion_to_check(criterion: EvalCriterion) -> dict[str, Any]:
    """Convert a criterion into a rule-based check descriptor.

    The returned dict can be passed to a reward engine's rule-based
    scorer as its configuration.
    """
    ct = criterion.criterion_type
    params = criterion.parameters

    if ct == CriterionType.MUST_INCLUDE:
        return {
            "type": "substring_match",
            "terms": params.get("terms", []),
            "mode": "all",
        }

    if ct == CriterionType.MUST_NOT_INCLUDE:
        return {
            "type": "substring_absent",
            "terms": params.get("terms", []),
            "mode": "none",
        }

    if ct == CriterionType.QUALITY_RANGE:
        return {
            "type": "length_range",
            "min_length": params.get("min_length", 0),
            "max_length": params.get("max_length", 100000),
        }

    if ct == CriterionType.PRESENCE_CHECK:
        return {
            "type": "regex_match",
            "patterns": params.get("patterns", []),
        }

    if ct == CriterionType.CITATION_REQUIRED:
        return {
            "type": "citation_count",
            "min_citations": params.get("min_citations", 1),
            "citation_pattern": params.get("citation_pattern", r"\[\d+\]"),
        }

    if ct == CriterionType.NUMERICAL_ACCURACY:
        return {
            "type": "numerical_check",
            "expected_numbers": params.get("expected_numbers", {}),
            "tolerance": params.get("tolerance", 0.05),
        }

    if ct == CriterionType.TEMPORAL_CONSISTENCY:
        return {
            "type": "temporal_check",
            "reference_date": params.get("reference_date", ""),
            "must_be_after": params.get("must_be_after", True),
        }

    if ct == CriterionType.COMPLETENESS:
        return {
            "type": "section_check",
            "required_sections": params.get("required_sections", []),
        }

    return {"type": "noop"}
