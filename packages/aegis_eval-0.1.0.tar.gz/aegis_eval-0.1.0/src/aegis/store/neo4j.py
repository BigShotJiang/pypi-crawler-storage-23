"""Neo4j-backed knowledge graph for the Aegis memory subsystem.

Provides :class:`Neo4jGraph` which mirrors the :class:`KnowledgeGraph` API
but stores nodes and edges in Neo4j for persistent, scalable graph queries.
"""

from __future__ import annotations

import logging
from typing import Any

from aegis.memory.graph import Edge

logger = logging.getLogger(__name__)

try:
    from neo4j import GraphDatabase  # type: ignore[import-not-found]

    _HAS_NEO4J = True
except ImportError:
    _HAS_NEO4J = False


class Neo4jGraph:
    """Neo4j-backed knowledge graph.

    Provides the same interface as :class:`KnowledgeGraph` but persists
    all nodes and edges in Neo4j.

    Args:
        uri: Neo4j bolt URI.
        user: Neo4j username.
        password: Neo4j password.
    """

    def __init__(self, uri: str, user: str, password: str) -> None:
        if not _HAS_NEO4J:
            raise RuntimeError(
                "neo4j driver is required. Install with: pip install 'aegis-eval[db]'"
            )
        self._driver = GraphDatabase.driver(uri, auth=(user, password))
        self._ensure_constraints()

    def close(self) -> None:
        self._driver.close()

    def _ensure_constraints(self) -> None:
        with self._driver.session() as session:
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (n:Node) REQUIRE n.node_id IS UNIQUE")

    # -- node operations -----------------------------------------------------

    def add_node(self, node_id: str) -> None:
        with self._driver.session() as session:
            session.run("MERGE (n:Node {node_id: $nid})", nid=node_id)

    def has_node(self, node_id: str) -> bool:
        with self._driver.session() as session:
            result = session.run(
                "MATCH (n:Node {node_id: $nid}) RETURN count(n) AS cnt",
                nid=node_id,
            )
            record = result.single()
            return record is not None and record["cnt"] > 0

    # -- edge operations -----------------------------------------------------

    def add_edge(
        self,
        source: str,
        target: str,
        relation: str,
        weight: float = 1.0,
        metadata: dict[str, Any] | None = None,
    ) -> Edge:
        edge = Edge(
            source=source,
            target=target,
            relation=relation,
            weight=weight,
            metadata=metadata or {},
        )
        with self._driver.session() as session:
            session.run(
                """
                MERGE (s:Node {node_id: $src})
                MERGE (t:Node {node_id: $tgt})
                CREATE (s)-[r:RELATES {
                    relation: $rel,
                    weight: $w,
                    metadata: $meta,
                    created_at: $cat
                }]->(t)
                """,
                src=source,
                tgt=target,
                rel=relation,
                w=weight,
                meta=str(metadata or {}),
                cat=edge.created_at.isoformat(),
            )
        return edge

    def remove_edge(
        self,
        source: str,
        target: str,
        relation: str | None = None,
    ) -> bool:
        with self._driver.session() as session:
            if relation is not None:
                result = session.run(
                    """
                    MATCH (s:Node {node_id: $src})-[r:RELATES {relation: $rel}]->(t:Node {node_id: $tgt})
                    DELETE r
                    RETURN count(r) AS cnt
                    """,
                    src=source,
                    tgt=target,
                    rel=relation,
                )
            else:
                result = session.run(
                    """
                    MATCH (s:Node {node_id: $src})-[r:RELATES]->(t:Node {node_id: $tgt})
                    DELETE r
                    RETURN count(r) AS cnt
                    """,
                    src=source,
                    tgt=target,
                )
            record = result.single()
            return record is not None and record["cnt"] > 0

    def has_edge(
        self,
        source: str,
        target: str,
        relation: str | None = None,
    ) -> bool:
        with self._driver.session() as session:
            if relation is not None:
                result = session.run(
                    """
                    MATCH (s:Node {node_id: $src})-[r:RELATES {relation: $rel}]->(t:Node {node_id: $tgt})
                    RETURN count(r) AS cnt
                    """,
                    src=source,
                    tgt=target,
                    rel=relation,
                )
            else:
                result = session.run(
                    """
                    MATCH (s:Node {node_id: $src})-[r:RELATES]->(t:Node {node_id: $tgt})
                    RETURN count(r) AS cnt
                    """,
                    src=source,
                    tgt=target,
                )
            record = result.single()
            return record is not None and record["cnt"] > 0

    # -- traversal -----------------------------------------------------------

    def neighbors(
        self,
        node_id: str,
        relation: str | None = None,
        direction: str = "both",
    ) -> list[str]:
        clauses = []
        if direction in ("outgoing", "both"):
            if relation:
                clauses.append(
                    "MATCH (n:Node {node_id: $nid})-[r:RELATES {relation: $rel}]->(m) RETURN m.node_id AS nid"
                )
            else:
                clauses.append(
                    "MATCH (n:Node {node_id: $nid})-[:RELATES]->(m) RETURN m.node_id AS nid"
                )
        if direction in ("incoming", "both"):
            if relation:
                clauses.append(
                    "MATCH (n:Node {node_id: $nid})<-[r:RELATES {relation: $rel}]-(m) RETURN m.node_id AS nid"
                )
            else:
                clauses.append(
                    "MATCH (n:Node {node_id: $nid})<-[:RELATES]-(m) RETURN m.node_id AS nid"
                )

        query = " UNION ".join(clauses)
        result_ids: set[str] = set()
        with self._driver.session() as session:
            params: dict[str, Any] = {"nid": node_id}
            if relation:
                params["rel"] = relation
            result = session.run(query, **params)
            for record in result:
                result_ids.add(record["nid"])
        return list(result_ids)

    def edges(self, node_id: str, direction: str = "outgoing") -> list[Edge]:
        if direction == "outgoing":
            cypher = """
                MATCH (s:Node {node_id: $nid})-[r:RELATES]->(t)
                RETURN s.node_id AS src, t.node_id AS tgt,
                       r.relation AS rel, r.weight AS w,
                       r.metadata AS meta, r.created_at AS cat
            """
        elif direction == "incoming":
            cypher = """
                MATCH (s)-[r:RELATES]->(t:Node {node_id: $nid})
                RETURN s.node_id AS src, t.node_id AS tgt,
                       r.relation AS rel, r.weight AS w,
                       r.metadata AS meta, r.created_at AS cat
            """
        else:
            cypher = """
                MATCH (s:Node {node_id: $nid})-[r:RELATES]->(t)
                RETURN s.node_id AS src, t.node_id AS tgt,
                       r.relation AS rel, r.weight AS w,
                       r.metadata AS meta, r.created_at AS cat
                UNION
                MATCH (s)-[r:RELATES]->(t:Node {node_id: $nid})
                RETURN s.node_id AS src, t.node_id AS tgt,
                       r.relation AS rel, r.weight AS w,
                       r.metadata AS meta, r.created_at AS cat
            """

        edges: list[Edge] = []
        with self._driver.session() as session:
            result = session.run(cypher, nid=node_id)
            for record in result:
                edges.append(
                    Edge(
                        source=record["src"],
                        target=record["tgt"],
                        relation=record["rel"],
                        weight=record["w"],
                    )
                )
        return edges

    # -- path finding --------------------------------------------------------

    def shortest_path(
        self,
        source: str,
        target: str,
        max_hops: int = 5,
    ) -> list[str] | None:
        with self._driver.session() as session:
            result = session.run(
                f"""
                MATCH path = shortestPath(
                    (s:Node {{node_id: $src}})-[:RELATES*1..{max_hops}]->(t:Node {{node_id: $tgt}})
                )
                RETURN [n IN nodes(path) | n.node_id] AS node_ids
                """,
                src=source,
                tgt=target,
            )
            record = result.single()
            if record is None:
                return None
            return list(record["node_ids"])

    def all_paths(
        self,
        source: str,
        target: str,
        max_hops: int = 3,
    ) -> list[list[str]]:
        with self._driver.session() as session:
            result = session.run(
                f"""
                MATCH path = (s:Node {{node_id: $src}})-[:RELATES*1..{max_hops}]->(t:Node {{node_id: $tgt}})
                RETURN [n IN nodes(path) | n.node_id] AS node_ids
                """,
                src=source,
                tgt=target,
            )
            return [list(record["node_ids"]) for record in result]

    # -- subgraph extraction -------------------------------------------------

    def subgraph(
        self,
        center: str,
        depth: int = 2,
    ) -> dict[str, list[Edge]]:
        result_dict: dict[str, list[Edge]] = {}
        with self._driver.session() as session:
            result = session.run(
                f"""
                MATCH path = (c:Node {{node_id: $center}})-[:RELATES*1..{depth}]->(t)
                UNWIND relationships(path) AS r
                WITH startNode(r) AS s, endNode(r) AS t, r
                RETURN s.node_id AS src, t.node_id AS tgt,
                       r.relation AS rel, r.weight AS w
                """,
                center=center,
            )
            for record in result:
                edge = Edge(
                    source=record["src"],
                    target=record["tgt"],
                    relation=record["rel"],
                    weight=record["w"],
                )
                result_dict.setdefault(record["src"], []).append(edge)
        return result_dict

    # -- statistics ----------------------------------------------------------

    def node_count(self) -> int:
        with self._driver.session() as session:
            result = session.run("MATCH (n:Node) RETURN count(n) AS cnt")
            record = result.single()
            return record["cnt"] if record else 0

    def edge_count(self) -> int:
        with self._driver.session() as session:
            result = session.run("MATCH ()-[r:RELATES]->() RETURN count(r) AS cnt")
            record = result.single()
            return record["cnt"] if record else 0

    def clear(self) -> None:
        with self._driver.session() as session:
            session.run("MATCH (n:Node) DETACH DELETE n")
