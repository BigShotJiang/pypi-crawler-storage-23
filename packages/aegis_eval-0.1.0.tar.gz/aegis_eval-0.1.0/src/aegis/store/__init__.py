"""Aegis persistence store.

Provides SQLite, PostgreSQL/pgvector, and Neo4j backends.
Falls back gracefully when optional database drivers are not installed.
"""

from aegis.store.sqlite import EvalRunRow, SQLiteStore, TrainingJobRow

__all__ = [
    "EvalRunRow",
    "SQLiteStore",
    "TrainingJobRow",
    "PgVectorStore",
    "PostgresEvalStore",
    "Neo4jGraph",
    "RedisCache",
]


def __getattr__(name: str) -> object:
    """Lazy import for optional backends to avoid import errors."""
    if name == "PgVectorStore":
        from aegis.store.postgres import PgVectorStore

        return PgVectorStore
    if name == "Neo4jGraph":
        from aegis.store.neo4j import Neo4jGraph

        return Neo4jGraph
    if name == "PostgresEvalStore":
        from aegis.store.postgres_eval import PostgresEvalStore

        return PostgresEvalStore
    if name == "RedisCache":
        from aegis.store.redis import RedisCache

        return RedisCache
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
