"""Redis-backed cache layer for the Aegis platform.

Provides :class:`RedisCache` for caching memory entries, eval results,
and other frequently-accessed data with TTL-based expiry.
"""

from __future__ import annotations

import json
import logging
from datetime import timedelta
from typing import Any

logger = logging.getLogger(__name__)

try:
    import redis  # type: ignore[import-not-found]

    _HAS_REDIS = True
except ImportError:
    _HAS_REDIS = False


class RedisCache:
    """Redis-backed cache with JSON serialization.

    Used as a read-through cache for hot memory entries and recent eval
    results.  Gracefully degrades to no-op when Redis is unavailable.

    Args:
        url: Redis connection URL.
        prefix: Key prefix for all cached entries.
        default_ttl: Default time-to-live for cache entries.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379/0",
        prefix: str = "aegis",
        default_ttl: timedelta = timedelta(hours=1),
    ) -> None:
        if not _HAS_REDIS:
            raise RuntimeError("redis is required. Install with: pip install 'aegis-eval[db]'")
        self._client: Any = redis.from_url(url, decode_responses=True)
        self._prefix = prefix
        self._default_ttl = default_ttl

    def _key(self, namespace: str, key: str) -> str:
        return f"{self._prefix}:{namespace}:{key}"

    # -- basic operations ----------------------------------------------------

    def get(self, namespace: str, key: str) -> Any | None:
        """Get a cached value.

        Args:
            namespace: Cache namespace (e.g. "memory", "eval").
            key: Cache key.

        Returns:
            The cached value deserialized from JSON, or None if not found.
        """
        raw = self._client.get(self._key(namespace, key))
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return raw

    def set(
        self,
        namespace: str,
        key: str,
        value: Any,
        ttl: timedelta | None = None,
    ) -> None:
        """Set a cached value with optional TTL.

        Args:
            namespace: Cache namespace.
            key: Cache key.
            value: Value to cache (must be JSON-serializable).
            ttl: Time-to-live override. Uses default if not specified.
        """
        serialized = json.dumps(value, default=str)
        self._client.setex(
            self._key(namespace, key),
            ttl or self._default_ttl,
            serialized,
        )

    def delete(self, namespace: str, key: str) -> bool:
        """Delete a cached entry.

        Args:
            namespace: Cache namespace.
            key: Cache key.

        Returns:
            True if the key existed and was deleted.
        """
        return bool(self._client.delete(self._key(namespace, key)))

    def invalidate_namespace(self, namespace: str) -> int:
        """Delete all keys in a namespace.

        Args:
            namespace: Cache namespace to clear.

        Returns:
            Number of keys deleted.
        """
        pattern = f"{self._prefix}:{namespace}:*"
        keys = list(self._client.scan_iter(match=pattern, count=100))
        if not keys:
            return 0
        deleted = self._client.delete(*keys)
        return int(deleted) if isinstance(deleted, int) else 0

    def exists(self, namespace: str, key: str) -> bool:
        """Check if a key exists in the cache."""
        return bool(self._client.exists(self._key(namespace, key)))

    def ping(self) -> bool:
        """Check Redis connectivity."""
        try:
            return bool(self._client.ping())
        except Exception:
            return False

    def close(self) -> None:
        """Close the Redis connection."""
        self._client.close()
