"""PostgreSQL + pgvector persistence backend for Aegis.

Provides :class:`PgVectorStore` which implements the :class:`MemoryStore`
protocol using PostgreSQL with the ``pgvector`` extension for semantic search.

Falls back to the in-memory store when ``psycopg`` is not installed.
"""

from __future__ import annotations

import json
import logging
from contextlib import suppress
from typing import Any

from aegis.core.types import MemoryTier
from aegis.memory.types import MemoryEntry

logger = logging.getLogger(__name__)

try:
    import psycopg  # type: ignore[import-not-found]
    from pgvector.psycopg import register_vector  # type: ignore[import-not-found]

    _HAS_PG = True
except ImportError:
    _HAS_PG = False

try:
    from sentence_transformers import SentenceTransformer

    _HAS_EMBEDDINGS = True
except ImportError:
    _HAS_EMBEDDINGS = False

_EMBEDDING_DIM = 384  # all-MiniLM-L6-v2 produces 384-d vectors


class PgVectorStore:
    """PostgreSQL + pgvector implementation of the MemoryStore protocol.

    Stores memory entries in a ``memory_entries`` table with a pgvector
    column for semantic search.  When ``sentence-transformers`` is available,
    entries are embedded on insert and searched via cosine distance.

    Args:
        dsn: PostgreSQL connection string.
        table: Table name to use.
        enable_embeddings: Whether to compute and store embeddings.
    """

    def __init__(
        self,
        dsn: str,
        table: str = "memory_entries",
        enable_embeddings: bool = True,
    ) -> None:
        if not _HAS_PG:
            raise RuntimeError(
                "psycopg and pgvector are required. Install with: pip install 'aegis-eval[db]'"
            )
        self._dsn = dsn
        self._table = table
        self._model: Any | None = None

        if enable_embeddings and _HAS_EMBEDDINGS:
            self._model = SentenceTransformer("all-MiniLM-L6-v2")

        self._ensure_schema()

    # -- connection helpers ---------------------------------------------------

    def _connect(self) -> Any:
        conn = psycopg.connect(self._dsn)
        register_vector(conn)
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
            conn.execute(f"""
                CREATE TABLE IF NOT EXISTS {self._table} (
                    key          TEXT PRIMARY KEY,
                    value        JSONB NOT NULL,
                    tier         TEXT NOT NULL DEFAULT 'working',
                    confidence   REAL NOT NULL DEFAULT 1.0,
                    provenance   JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                    tags         JSONB NOT NULL DEFAULT '[]'::jsonb,
                    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
                    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
                    access_count INTEGER NOT NULL DEFAULT 0,
                    metadata     JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                    embedding    vector({_EMBEDDING_DIM})
                )
            """)
            conn.execute(f"""
                CREATE INDEX IF NOT EXISTS idx_{self._table}_tier
                ON {self._table}(tier)
            """)
            conn.execute(f"""
                CREATE INDEX IF NOT EXISTS idx_{self._table}_embedding
                ON {self._table}
                USING ivfflat (embedding vector_cosine_ops)
                WITH (lists = 100)
            """)
            conn.commit()

    # -- MemoryStore protocol ------------------------------------------------

    def store(self, entry: MemoryEntry) -> None:
        embedding = self._embed(str(entry.value))
        with self._connect() as conn:
            conn.execute(
                f"""
                INSERT INTO {self._table}
                    (key, value, tier, confidence, provenance, tags,
                     created_at, updated_at, access_count, metadata, embedding)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (key) DO UPDATE SET
                    value = EXCLUDED.value,
                    tier = EXCLUDED.tier,
                    confidence = EXCLUDED.confidence,
                    provenance = EXCLUDED.provenance,
                    tags = EXCLUDED.tags,
                    updated_at = EXCLUDED.updated_at,
                    metadata = EXCLUDED.metadata,
                    embedding = EXCLUDED.embedding
                """,
                (
                    entry.key,
                    json.dumps(entry.value, default=str),
                    entry.tier.value,
                    entry.confidence,
                    json.dumps(entry.provenance, default=str),
                    json.dumps(entry.tags),
                    entry.created_at,
                    entry.updated_at,
                    entry.access_count,
                    json.dumps(entry.metadata, default=str),
                    embedding,
                ),
            )
            conn.commit()

    def retrieve(self, key: str) -> MemoryEntry | None:
        with self._connect() as conn:
            row = conn.execute(
                f"""
                UPDATE {self._table}
                SET access_count = access_count + 1, updated_at = now()
                WHERE key = %s
                RETURNING key, value, tier, confidence, provenance, tags,
                          created_at, updated_at, access_count, metadata
                """,
                (key,),
            ).fetchone()
            conn.commit()
        if row is None:
            return None
        return self._row_to_entry(row)

    def update(self, key: str, value: Any) -> bool:
        embedding = self._embed(str(value))
        with self._connect() as conn:
            cur = conn.execute(
                f"""
                UPDATE {self._table}
                SET value = %s, embedding = %s, updated_at = now()
                WHERE key = %s
                """,
                (json.dumps(value, default=str), embedding, key),
            )
            conn.commit()
            rowcount = getattr(cur, "rowcount", 0)
            return isinstance(rowcount, int) and rowcount > 0

    def delete(self, key: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute(f"DELETE FROM {self._table} WHERE key = %s", (key,))
            conn.commit()
            rowcount = getattr(cur, "rowcount", 0)
            return isinstance(rowcount, int) and rowcount > 0

    def search(self, query: str, top_k: int = 10) -> list[MemoryEntry]:
        embedding = self._embed(query)
        if embedding is not None:
            return self._vector_search(embedding, top_k)
        return self._text_search(query, top_k)

    def list_by_tier(self, tier: MemoryTier) -> list[MemoryEntry]:
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT key, value, tier, confidence, provenance, tags,
                       created_at, updated_at, access_count, metadata
                FROM {self._table}
                WHERE tier = %s
                ORDER BY updated_at DESC
                """,
                (tier.value,),
            ).fetchall()
        return [self._row_to_entry(r) for r in rows]

    # -- search implementations ----------------------------------------------

    def _vector_search(self, embedding: Any, top_k: int) -> list[MemoryEntry]:
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT key, value, tier, confidence, provenance, tags,
                       created_at, updated_at, access_count, metadata,
                       embedding <=> %s::vector AS distance
                FROM {self._table}
                WHERE embedding IS NOT NULL
                ORDER BY distance ASC
                LIMIT %s
                """,
                (embedding, top_k),
            ).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def _text_search(self, query: str, top_k: int) -> list[MemoryEntry]:
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT key, value, tier, confidence, provenance, tags,
                       created_at, updated_at, access_count, metadata
                FROM {self._table}
                WHERE value::text ILIKE %s
                LIMIT %s
                """,
                (f"%{query}%", top_k),
            ).fetchall()
        return [self._row_to_entry(r) for r in rows]

    # -- helpers -------------------------------------------------------------

    def _embed(self, text: str) -> Any:
        if self._model is None:
            return None
        vec = self._model.encode(text, convert_to_numpy=True)
        return vec.tolist()

    @staticmethod
    def _row_to_entry(row: Any) -> MemoryEntry:
        value = row[1]
        if isinstance(value, str):
            with suppress(json.JSONDecodeError):
                value = json.loads(value)

        provenance = row[4]
        if isinstance(provenance, str):
            provenance = json.loads(provenance)

        tags = row[5]
        if isinstance(tags, str):
            tags = json.loads(tags)

        metadata = row[9]
        if isinstance(metadata, str):
            metadata = json.loads(metadata)

        return MemoryEntry(
            key=row[0],
            value=value,
            tier=MemoryTier(row[2]),
            confidence=row[3],
            provenance=provenance,
            tags=tags,
            created_at=row[6],
            updated_at=row[7],
            access_count=row[8],
            metadata=metadata,
        )

    def count(self) -> int:
        with self._connect() as conn:
            row = conn.execute(f"SELECT count(*) FROM {self._table}").fetchone()
        return row[0] if row else 0

    def clear(self) -> None:
        with self._connect() as conn:
            conn.execute(f"TRUNCATE {self._table}")
            conn.commit()
