"""SQLite-backed persistence for Aegis eval runs and training jobs.

Uses Python's stdlib ``sqlite3`` — zero extra dependencies.  Each public
method opens its own connection for thread-safety (no shared connection).
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, cast

from pydantic import BaseModel

from aegis.core.settings import AegisSettings
from aegis.eval.engine import EvalResult

# ---------------------------------------------------------------------------
# Row models (lightweight summaries for listing endpoints)
# ---------------------------------------------------------------------------


class EvalRunRow(BaseModel):
    """Lightweight summary of a persisted eval run."""

    run_id: str
    agent_id: str = ""
    overall_score: float = 0.0
    num_dimensions: int = 0
    created_at: datetime
    result_json: str = ""


class TrainingJobRow(BaseModel):
    """Lightweight summary of a persisted training job."""

    job_id: str
    customer_id: str = ""
    domain: str = ""
    optimizer: str = ""
    status: str = "created"
    created_at: datetime
    updated_at: datetime
    job_json: str = ""


class BenchmarkRunRow(BaseModel):
    """Lightweight summary of a persisted benchmark run."""

    run_id: str
    suite: str = ""
    overall_score: float = 0.0
    suite_size: int = 0
    passed: bool = False
    created_at: datetime
    run_json: str = ""


# ---------------------------------------------------------------------------
# SQLiteStore
# ---------------------------------------------------------------------------

_DEFAULT_DIR = Path.home() / ".aegis"
_DEFAULT_DB = _DEFAULT_DIR / "aegis.db"


class SQLiteStore:
    """Zero-dependency SQLite persistence store for Aegis.

    Parameters
    ----------
    db_path:
        Path to the SQLite database file.  ``":memory:"`` creates an
        in-memory database (useful for tests).  *None* reads the
        ``AEGIS_DB_PATH`` env-var, falling back to ``~/.aegis/aegis.db``.
    """

    def __init__(self, db_path: str | Path | None = None) -> None:
        if db_path is None:
            db_path = AegisSettings().db_path or str(_DEFAULT_DB)
        self.db_path = str(db_path)
        # For :memory: databases, keep a persistent connection so the schema
        # survives across calls (each new :memory: connection is a fresh DB).
        self._shared_conn: sqlite3.Connection | None = None
        if self.db_path == ":memory:":
            self._shared_conn = sqlite3.connect(":memory:")
            self._shared_conn.row_factory = sqlite3.Row
        self._ensure_tables()

    # -- internal helpers ---------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        """Open a new connection (per-call for thread safety).

        For ``:memory:`` databases a shared connection is reused so the
        schema persists across calls.
        """
        if self._shared_conn is not None:
            return self._shared_conn
        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _release(self, conn: sqlite3.Connection) -> None:
        """Close *conn* unless it is the shared in-memory connection."""
        if conn is not self._shared_conn:
            conn.close()

    def _ensure_tables(self) -> None:
        conn = self._connect()
        try:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS eval_runs (
                    run_id       TEXT PRIMARY KEY,
                    agent_id     TEXT NOT NULL DEFAULT '',
                    overall_score REAL NOT NULL DEFAULT 0.0,
                    num_dimensions INTEGER NOT NULL DEFAULT 0,
                    created_at   TEXT NOT NULL,
                    result_json  TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_eval_runs_agent_id
                    ON eval_runs(agent_id);
                CREATE INDEX IF NOT EXISTS idx_eval_runs_created_at
                    ON eval_runs(created_at);

                CREATE TABLE IF NOT EXISTS training_jobs (
                    job_id       TEXT PRIMARY KEY,
                    customer_id  TEXT NOT NULL DEFAULT '',
                    domain       TEXT NOT NULL DEFAULT '',
                    optimizer    TEXT NOT NULL DEFAULT '',
                    status       TEXT NOT NULL DEFAULT 'created',
                    created_at   TEXT NOT NULL,
                    updated_at   TEXT NOT NULL,
                    job_json     TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_training_jobs_customer_id
                    ON training_jobs(customer_id);

                CREATE TABLE IF NOT EXISTS benchmark_runs (
                    run_id       TEXT PRIMARY KEY,
                    suite        TEXT NOT NULL DEFAULT '',
                    overall_score REAL NOT NULL DEFAULT 0.0,
                    suite_size   INTEGER NOT NULL DEFAULT 0,
                    passed       INTEGER NOT NULL DEFAULT 0,
                    created_at   TEXT NOT NULL,
                    run_json     TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_benchmark_runs_suite
                    ON benchmark_runs(suite);
                CREATE INDEX IF NOT EXISTS idx_benchmark_runs_created_at
                    ON benchmark_runs(created_at);
                """
            )
            conn.commit()
        finally:
            self._release(conn)

    # -- eval runs ----------------------------------------------------------

    def save_eval_run(self, result: EvalResult) -> None:
        """Persist an :class:`EvalResult` (upsert by ``run_id``)."""
        conn = self._connect()
        try:
            conn.execute(
                """
                INSERT OR REPLACE INTO eval_runs
                    (run_id, agent_id, overall_score, num_dimensions, created_at, result_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    result.run_id,
                    result.agent_id,
                    result.overall_score,
                    len(result.dimension_scores),
                    result.created_at.isoformat(),
                    result.model_dump_json(),
                ),
            )
            conn.commit()
        finally:
            self._release(conn)

    def get_eval_run(self, run_id: str) -> EvalResult | None:
        """Load a single eval run by ID, or *None* if not found."""
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT result_json FROM eval_runs WHERE run_id = ?",
                (run_id,),
            ).fetchone()
        finally:
            self._release(conn)
        if row is None:
            return None
        return EvalResult.model_validate_json(row["result_json"])

    def list_eval_runs(
        self,
        limit: int = 20,
        offset: int = 0,
        agent_id: str | None = None,
    ) -> list[EvalRunRow]:
        """List eval runs, newest first, with optional agent filter."""
        conn = self._connect()
        try:
            if agent_id is not None:
                rows = conn.execute(
                    """
                    SELECT run_id, agent_id, overall_score, num_dimensions, created_at
                    FROM eval_runs
                    WHERE agent_id = ?
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (agent_id, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT run_id, agent_id, overall_score, num_dimensions, created_at
                    FROM eval_runs
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset),
                ).fetchall()
        finally:
            self._release(conn)
        return [
            EvalRunRow(
                run_id=r["run_id"],
                agent_id=r["agent_id"],
                overall_score=r["overall_score"],
                num_dimensions=r["num_dimensions"],
                created_at=datetime.fromisoformat(r["created_at"]),
            )
            for r in rows
        ]

    def delete_eval_run(self, run_id: str) -> bool:
        """Delete a single eval run by ID. Returns *True* if a row was removed."""
        conn = self._connect()
        try:
            cur = conn.execute("DELETE FROM eval_runs WHERE run_id = ?", (run_id,))
            conn.commit()
            return cur.rowcount > 0
        finally:
            self._release(conn)

    def count_eval_runs(self, agent_id: str | None = None) -> int:
        """Return the total number of persisted eval runs."""
        conn = self._connect()
        try:
            if agent_id is not None:
                row = conn.execute(
                    "SELECT count(*) FROM eval_runs WHERE agent_id = ?",
                    (agent_id,),
                ).fetchone()
            else:
                row = conn.execute("SELECT count(*) FROM eval_runs").fetchone()
        finally:
            self._release(conn)
        return row[0] if row else 0

    # -- training jobs ------------------------------------------------------

    def save_training_job(self, job_id: str, job_data: dict[str, Any]) -> None:
        """Persist a training job dict (upsert by ``job_id``)."""
        conn = self._connect()
        try:
            conn.execute(
                """
                INSERT OR REPLACE INTO training_jobs
                    (job_id, customer_id, domain, optimizer, status,
                     created_at, updated_at, job_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    job_id,
                    str(job_data.get("customer_id", "")),
                    str(job_data.get("domain", "")),
                    str(job_data.get("optimizer", "")),
                    str(job_data.get("status", "created")),
                    _dt_to_iso(job_data.get("created_at")),
                    _dt_to_iso(job_data.get("updated_at")),
                    _safe_json(job_data),
                ),
            )
            conn.commit()
        finally:
            self._release(conn)

    def get_training_job(self, job_id: str) -> dict[str, Any] | None:
        """Load a training job dict by ID, or *None* if not found."""
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT job_json FROM training_jobs WHERE job_id = ?",
                (job_id,),
            ).fetchone()
        finally:
            self._release(conn)
        if row is None:
            return None
        payload = json.loads(str(row["job_json"]))
        if isinstance(payload, dict):
            return cast("dict[str, Any]", payload)
        return None

    def update_training_job(self, job_id: str, updates: dict[str, Any]) -> None:
        """Merge *updates* into a persisted training job."""
        existing = self.get_training_job(job_id)
        if existing is None:
            return
        existing.update(updates)
        self.save_training_job(job_id, existing)

    def list_training_jobs(
        self,
        limit: int = 20,
        offset: int = 0,
        customer_id: str | None = None,
    ) -> list[TrainingJobRow]:
        """List training jobs, newest first."""
        conn = self._connect()
        try:
            if customer_id is not None:
                rows = conn.execute(
                    """
                    SELECT job_id, customer_id, domain, optimizer, status,
                           created_at, updated_at
                    FROM training_jobs
                    WHERE customer_id = ?
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (customer_id, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT job_id, customer_id, domain, optimizer, status,
                           created_at, updated_at
                    FROM training_jobs
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset),
                ).fetchall()
        finally:
            self._release(conn)
        return [
            TrainingJobRow(
                job_id=r["job_id"],
                customer_id=r["customer_id"],
                domain=r["domain"],
                optimizer=r["optimizer"],
                status=r["status"],
                created_at=datetime.fromisoformat(r["created_at"]),
                updated_at=datetime.fromisoformat(r["updated_at"]),
            )
            for r in rows
        ]

    # -- benchmark runs ----------------------------------------------------

    def save_benchmark_run(self, run_id: str, run_data: dict[str, Any]) -> None:
        """Persist a benchmark run dict (upsert by ``run_id``)."""
        conn = self._connect()
        try:
            conn.execute(
                """
                INSERT OR REPLACE INTO benchmark_runs
                    (run_id, suite, overall_score, suite_size, passed, created_at, run_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    str(run_data.get("suite", "")),
                    float(run_data.get("overall_score", 0.0)),
                    int(run_data.get("suite_size", 0)),
                    1 if bool(run_data.get("passed", False)) else 0,
                    _dt_to_iso(run_data.get("created_at")),
                    _safe_json(run_data),
                ),
            )
            conn.commit()
        finally:
            self._release(conn)

    def get_benchmark_run(self, run_id: str) -> dict[str, Any] | None:
        """Load a benchmark run dict by ID, or *None* if not found."""
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT run_json FROM benchmark_runs WHERE run_id = ?",
                (run_id,),
            ).fetchone()
        finally:
            self._release(conn)
        if row is None:
            return None
        payload = json.loads(str(row["run_json"]))
        if isinstance(payload, dict):
            return cast("dict[str, Any]", payload)
        return None

    def list_benchmark_runs(
        self,
        limit: int = 50,
        offset: int = 0,
        suite: str | None = None,
    ) -> list[BenchmarkRunRow]:
        """List benchmark runs, newest first, with optional suite filter."""
        conn = self._connect()
        try:
            if suite is not None:
                rows = conn.execute(
                    """
                    SELECT run_id, suite, overall_score, suite_size, passed, created_at
                    FROM benchmark_runs
                    WHERE suite = ?
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (suite, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT run_id, suite, overall_score, suite_size, passed, created_at
                    FROM benchmark_runs
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset),
                ).fetchall()
        finally:
            self._release(conn)

        return [
            BenchmarkRunRow(
                run_id=r["run_id"],
                suite=r["suite"],
                overall_score=r["overall_score"],
                suite_size=r["suite_size"],
                passed=bool(r["passed"]),
                created_at=datetime.fromisoformat(r["created_at"]),
            )
            for r in rows
        ]


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _dt_to_iso(val: Any) -> str:
    """Convert a datetime (or string) to ISO-8601, with a sane fallback."""
    if isinstance(val, datetime):
        return val.isoformat()
    if isinstance(val, str):
        return val
    return datetime.min.isoformat()


def _safe_json(data: dict[str, Any]) -> str:
    """Serialise *data* to JSON, skipping non-serialisable values."""

    def _default(obj: Any) -> Any:
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, BaseModel):
            return obj.model_dump(mode="json")
        if hasattr(obj, "__dict__"):
            return str(obj)
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

    return json.dumps(data, default=_default)
