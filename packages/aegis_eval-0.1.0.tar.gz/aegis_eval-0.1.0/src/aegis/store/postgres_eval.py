"""PostgreSQL persistence backend for Aegis eval runs and training jobs.

Mirrors the :class:`SQLiteStore` API but uses PostgreSQL, enabling shared
persistence across API replicas and higher-concurrency workloads.

Falls back gracefully when ``psycopg`` is not installed.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from types import ModuleType
from typing import Any, cast

from pydantic import BaseModel

from aegis.core.settings import get_settings
from aegis.eval.engine import EvalResult
from aegis.store.sqlite import BenchmarkRunRow, EvalRunRow, TrainingJobRow

logger = logging.getLogger(__name__)

psycopg_module: ModuleType | None
try:
    import psycopg as _psycopg  # type: ignore[import-not-found]

    psycopg_module = cast("ModuleType", _psycopg)
    _HAS_PG = True
except ImportError:
    psycopg_module = None
    _HAS_PG = False

_DEFAULT_DSN = "postgresql://aegis:aegis@localhost:5432/aegis"


class PostgresEvalStore:
    """PostgreSQL persistence store for eval runs and training jobs.

    Parameters
    ----------
    dsn:
        PostgreSQL connection string.  *None* reads the
        ``AEGIS_POSTGRES_DSN`` env-var, falling back to the default
        local development DSN.
    """

    def __init__(self, dsn: str | None = None) -> None:
        if not _HAS_PG:
            raise RuntimeError("psycopg is required. Install with: pip install 'aegis-eval[db]'")
        self._dsn = dsn or get_settings().postgres_dsn or _DEFAULT_DSN
        self._ensure_tables()

    # -- internal helpers ---------------------------------------------------

    def _connect(self) -> Any:
        if psycopg_module is None:
            raise RuntimeError("psycopg is required. Install with: pip install 'aegis-eval[db]'")
        return psycopg_module.connect(self._dsn)

    def _ensure_tables(self) -> None:
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS eval_runs (
                    run_id         TEXT PRIMARY KEY,
                    agent_id       TEXT NOT NULL DEFAULT '',
                    overall_score  DOUBLE PRECISION NOT NULL DEFAULT 0.0,
                    num_dimensions INTEGER NOT NULL DEFAULT 0,
                    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
                    result_json    JSONB NOT NULL DEFAULT '{}'::jsonb
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_eval_runs_agent_id
                    ON eval_runs(agent_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_eval_runs_created_at
                    ON eval_runs(created_at DESC)
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS training_jobs (
                    job_id       TEXT PRIMARY KEY,
                    customer_id  TEXT NOT NULL DEFAULT '',
                    domain       TEXT NOT NULL DEFAULT '',
                    optimizer    TEXT NOT NULL DEFAULT '',
                    status       TEXT NOT NULL DEFAULT 'created',
                    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
                    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
                    job_json     JSONB NOT NULL DEFAULT '{}'::jsonb
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_training_jobs_customer_id
                    ON training_jobs(customer_id)
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS benchmark_runs (
                    run_id        TEXT PRIMARY KEY,
                    suite         TEXT NOT NULL DEFAULT '',
                    overall_score DOUBLE PRECISION NOT NULL DEFAULT 0.0,
                    suite_size    INTEGER NOT NULL DEFAULT 0,
                    passed        BOOLEAN NOT NULL DEFAULT FALSE,
                    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
                    run_json      JSONB NOT NULL DEFAULT '{}'::jsonb
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_benchmark_runs_suite
                    ON benchmark_runs(suite)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_benchmark_runs_created_at
                    ON benchmark_runs(created_at DESC)
            """)
            conn.commit()

    # -- eval runs ----------------------------------------------------------

    def save_eval_run(self, result: EvalResult) -> None:
        """Persist an :class:`EvalResult` (upsert by ``run_id``)."""
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO eval_runs
                    (run_id, agent_id, overall_score, num_dimensions, created_at, result_json)
                VALUES (%s, %s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (run_id) DO UPDATE SET
                    agent_id = EXCLUDED.agent_id,
                    overall_score = EXCLUDED.overall_score,
                    num_dimensions = EXCLUDED.num_dimensions,
                    created_at = EXCLUDED.created_at,
                    result_json = EXCLUDED.result_json
                """,
                (
                    result.run_id,
                    result.agent_id,
                    result.overall_score,
                    len(result.dimension_scores),
                    result.created_at,
                    result.model_dump_json(),
                ),
            )
            conn.commit()

    def get_eval_run(self, run_id: str) -> EvalResult | None:
        """Load a single eval run by ID, or *None* if not found."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT result_json FROM eval_runs WHERE run_id = %s",
                (run_id,),
            ).fetchone()
        if row is None:
            return None
        data = row[0]
        if isinstance(data, str):
            return EvalResult.model_validate_json(data)
        return EvalResult.model_validate(data)

    def list_eval_runs(
        self,
        limit: int = 20,
        offset: int = 0,
        agent_id: str | None = None,
    ) -> list[EvalRunRow]:
        """List eval runs, newest first, with optional agent filter."""
        with self._connect() as conn:
            if agent_id is not None:
                rows = conn.execute(
                    """
                    SELECT run_id, agent_id, overall_score, num_dimensions, created_at
                    FROM eval_runs
                    WHERE agent_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (agent_id, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT run_id, agent_id, overall_score, num_dimensions, created_at
                    FROM eval_runs
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (limit, offset),
                ).fetchall()
        return [
            EvalRunRow(
                run_id=r[0],
                agent_id=r[1],
                overall_score=r[2],
                num_dimensions=r[3],
                created_at=r[4]
                if isinstance(r[4], datetime)
                else datetime.fromisoformat(str(r[4])),
            )
            for r in rows
        ]

    def delete_eval_run(self, run_id: str) -> bool:
        """Delete a single eval run by ID. Returns *True* if a row was removed."""
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM eval_runs WHERE run_id = %s", (run_id,))
            conn.commit()
            rowcount = getattr(cur, "rowcount", 0)
            return isinstance(rowcount, int) and rowcount > 0

    def count_eval_runs(self, agent_id: str | None = None) -> int:
        """Return the total number of persisted eval runs."""
        with self._connect() as conn:
            if agent_id is not None:
                row = conn.execute(
                    "SELECT count(*) FROM eval_runs WHERE agent_id = %s",
                    (agent_id,),
                ).fetchone()
            else:
                row = conn.execute("SELECT count(*) FROM eval_runs").fetchone()
        return row[0] if row else 0

    # -- training jobs ------------------------------------------------------

    def save_training_job(self, job_id: str, job_data: dict[str, Any]) -> None:
        """Persist a training job dict (upsert by ``job_id``)."""
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO training_jobs
                    (job_id, customer_id, domain, optimizer, status,
                     created_at, updated_at, job_json)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (job_id) DO UPDATE SET
                    customer_id = EXCLUDED.customer_id,
                    domain = EXCLUDED.domain,
                    optimizer = EXCLUDED.optimizer,
                    status = EXCLUDED.status,
                    updated_at = EXCLUDED.updated_at,
                    job_json = EXCLUDED.job_json
                """,
                (
                    job_id,
                    str(job_data.get("customer_id", "")),
                    str(job_data.get("domain", "")),
                    str(job_data.get("optimizer", "")),
                    str(job_data.get("status", "created")),
                    _dt_to_pg(job_data.get("created_at")),
                    _dt_to_pg(job_data.get("updated_at")),
                    _safe_json(job_data),
                ),
            )
            conn.commit()

    def get_training_job(self, job_id: str) -> dict[str, Any] | None:
        """Load a training job dict by ID, or *None* if not found."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT job_json FROM training_jobs WHERE job_id = %s",
                (job_id,),
            ).fetchone()
        if row is None:
            return None
        return _decode_payload(row[0])

    def update_training_job(self, job_id: str, updates: dict[str, Any]) -> None:
        """Merge *updates* into a persisted training job."""
        existing = self.get_training_job(job_id)
        if existing is None:
            return
        existing.update(updates)
        self.save_training_job(job_id, existing)

    def list_training_jobs(
        self,
        limit: int = 20,
        offset: int = 0,
        customer_id: str | None = None,
    ) -> list[TrainingJobRow]:
        """List training jobs, newest first."""
        with self._connect() as conn:
            if customer_id is not None:
                rows = conn.execute(
                    """
                    SELECT job_id, customer_id, domain, optimizer, status,
                           created_at, updated_at
                    FROM training_jobs
                    WHERE customer_id = %s
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (customer_id, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT job_id, customer_id, domain, optimizer, status,
                           created_at, updated_at
                    FROM training_jobs
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (limit, offset),
                ).fetchall()
        return [
            TrainingJobRow(
                job_id=r[0],
                customer_id=r[1],
                domain=r[2],
                optimizer=r[3],
                status=r[4],
                created_at=r[5]
                if isinstance(r[5], datetime)
                else datetime.fromisoformat(str(r[5])),
                updated_at=r[6]
                if isinstance(r[6], datetime)
                else datetime.fromisoformat(str(r[6])),
            )
            for r in rows
        ]

    # -- benchmark runs ----------------------------------------------------

    def save_benchmark_run(self, run_id: str, run_data: dict[str, Any]) -> None:
        """Persist a benchmark run dict (upsert by ``run_id``)."""
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO benchmark_runs
                    (run_id, suite, overall_score, suite_size, passed, created_at, run_json)
                VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb)
                ON CONFLICT (run_id) DO UPDATE SET
                    suite = EXCLUDED.suite,
                    overall_score = EXCLUDED.overall_score,
                    suite_size = EXCLUDED.suite_size,
                    passed = EXCLUDED.passed,
                    created_at = EXCLUDED.created_at,
                    run_json = EXCLUDED.run_json
                """,
                (
                    run_id,
                    str(run_data.get("suite", "")),
                    float(run_data.get("overall_score", 0.0)),
                    int(run_data.get("suite_size", 0)),
                    bool(run_data.get("passed", False)),
                    _dt_to_pg(run_data.get("created_at")),
                    _safe_json(run_data),
                ),
            )
            conn.commit()

    def get_benchmark_run(self, run_id: str) -> dict[str, Any] | None:
        """Load a benchmark run dict by ID, or *None* if not found."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT run_json FROM benchmark_runs WHERE run_id = %s",
                (run_id,),
            ).fetchone()
        if row is None:
            return None
        return _decode_payload(row[0])

    def list_benchmark_runs(
        self,
        limit: int = 50,
        offset: int = 0,
        suite: str | None = None,
    ) -> list[BenchmarkRunRow]:
        """List benchmark runs, newest first, with optional suite filter."""
        with self._connect() as conn:
            if suite is not None:
                rows = conn.execute(
                    """
                    SELECT run_id, suite, overall_score, suite_size, passed, created_at
                    FROM benchmark_runs
                    WHERE suite = %s
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (suite, limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT run_id, suite, overall_score, suite_size, passed, created_at
                    FROM benchmark_runs
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (limit, offset),
                ).fetchall()

        return [
            BenchmarkRunRow(
                run_id=r[0],
                suite=r[1],
                overall_score=r[2],
                suite_size=r[3],
                passed=bool(r[4]),
                created_at=r[5]
                if isinstance(r[5], datetime)
                else datetime.fromisoformat(str(r[5])),
            )
            for r in rows
        ]


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _dt_to_pg(val: Any) -> datetime:
    """Convert a datetime (or string) to a datetime for PostgreSQL."""
    if isinstance(val, datetime):
        return val
    if isinstance(val, str):
        return datetime.fromisoformat(val)
    return datetime.min


def _safe_json(data: dict[str, Any]) -> str:
    """Serialise *data* to JSON, skipping non-serialisable values."""

    def _default(obj: Any) -> Any:
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, BaseModel):
            return obj.model_dump(mode="json")
        if hasattr(obj, "__dict__"):
            return str(obj)
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

    return json.dumps(data, default=_default)


def _decode_payload(payload: Any) -> dict[str, Any] | None:
    """Decode JSON/JSONB payloads into a dict."""
    if isinstance(payload, str):
        decoded = json.loads(payload)
        if isinstance(decoded, dict):
            return cast("dict[str, Any]", decoded)
        return None
    if isinstance(payload, dict):
        return cast("dict[str, Any]", payload)
    return None
