"""Deterministic test-case generation utilities for domain plugins."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier

_TEXT_KEYS = (
    "prompt",
    "query",
    "question",
    "instruction",
    "task",
    "text",
    "content",
    "body",
    "input",
)
_EXPECTED_KEYS = ("expected", "ground_truth", "answer", "label", "target", "response")
_DIFFICULTY_KEYS = ("difficulty", "level", "severity")
_TAG_KEYS = ("tags", "labels", "categories")

_TIER_BY_DOMAIN: dict[str, EvalTier] = {
    "legal": EvalTier.REASONING_QUALITY,
    "finance": EvalTier.REASONING_QUALITY,
    "safety": EvalTier.SECURITY_ADVERSARIAL,
}

_SUPPORTED_FILE_SUFFIXES = (".jsonl", ".json", ".csv")
_SUPPORTED_TEXT_SUFFIXES = (".txt", ".md", ".rst", ".log", ".text")


def load_records(data_path: str | Path) -> list[dict[str, Any]]:
    """Load structured records from JSONL, JSON, CSV, or directory text files.

    Args:
        data_path: Input path to a file or directory.

    Returns:
        A deterministic list of mapping-like records.

    Raises:
        ValueError: If path is missing, unreadable, unsupported, or empty.
    """
    path = Path(data_path)
    if not path.exists():
        raise ValueError(
            f"Data path '{path}' does not exist. Provide a .jsonl/.json/.csv file "
            "or a directory containing text files."
        )

    records: list[dict[str, Any]]
    if path.is_dir():
        records = _load_directory_records(path)
    elif path.suffix.lower() == ".jsonl":
        records = _load_jsonl_records(path)
    elif path.suffix.lower() == ".json":
        records = _load_json_records(path)
    elif path.suffix.lower() == ".csv":
        records = _load_csv_records(path)
    else:
        raise ValueError(
            f"Unsupported data format for '{path}'. Supported formats: "
            f"{', '.join(_SUPPORTED_FILE_SUFFIXES)} or directory-of-text files."
        )

    if not records:
        raise ValueError(
            f"Data path '{path}' contains no usable records. "
            "Ensure the file contains rows/objects or the directory has readable text files."
        )

    return records


def build_cases(
    domain: str,
    dimension_ids: list[str],
    records: list[dict[str, Any]],
    count: int,
) -> list[EvalCaseV1]:
    """Build deterministic ``EvalCaseV1`` records for plugin evaluation suites.

    Args:
        domain: Domain name (e.g. ``"legal"``).
        dimension_ids: Ordered dimension IDs provided by the plugin.
        records: Loaded input records.
        count: Number of cases to generate.

    Returns:
        Deterministic list of ``EvalCaseV1`` objects.

    Raises:
        ValueError: If arguments are invalid or records are empty.
    """
    if count <= 0:
        raise ValueError(f"'count' must be greater than 0, received {count}.")
    if not dimension_ids:
        raise ValueError("At least one dimension ID is required to build eval cases.")
    if not records:
        raise ValueError("No records were provided to build eval cases.")

    tier = _TIER_BY_DOMAIN.get(domain, EvalTier.REASONING_QUALITY)
    normalized_dimension_ids = [dim_id.strip() for dim_id in dimension_ids if dim_id.strip()]
    if not normalized_dimension_ids:
        raise ValueError("Dimension IDs cannot be empty after normalization.")

    cases: list[EvalCaseV1] = []
    for case_idx in range(count):
        record = records[case_idx % len(records)]
        dimension_id = normalized_dimension_ids[case_idx % len(normalized_dimension_ids)]
        difficulty = _extract_difficulty(record, default=((case_idx % 5) + 1))
        record_fingerprint = _record_fingerprint(record)

        prompt = _synthesise_prompt(
            domain=domain,
            dimension_id=dimension_id,
            record=record,
            case_index=case_idx,
            difficulty=difficulty,
        )
        context = _build_context(record)
        expected = _build_expected_scaffold(record, dimension_id)
        tags = _build_tags(domain, dimension_id, difficulty, record)

        case_id = f"{domain}-{dimension_id}-{case_idx:04d}-{record_fingerprint[:10]}"
        metadata = {
            "domain": domain,
            "record_index": int(record.get("__aegis_record_index", 0)),
            "record_source": str(record.get("__aegis_source", "")),
            "record_fingerprint": record_fingerprint,
            "generator": "plugin.casegen.v1",
        }

        cases.append(
            EvalCaseV1(
                id=case_id,
                suite_id=f"{domain}-plugin-generated",
                dimension_id=dimension_id,
                tier=tier,
                domain=domain,
                prompt=prompt,
                context=context,
                expected=expected,
                difficulty=difficulty,
                tags=tags,
                metadata=metadata,
            )
        )

    return cases


def _load_jsonl_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"Unable to read JSONL file '{path}': {exc}") from exc

    for idx, raw_line in enumerate(lines):
        line = raw_line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSONL in '{path}' at line {idx + 1}: {exc.msg}.") from exc

        record = _as_record(payload)
        record["__aegis_source"] = str(path)
        record["__aegis_record_index"] = idx
        records.append(record)

    return records


def _load_json_records(path: Path) -> list[dict[str, Any]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ValueError(f"Unable to read JSON file '{path}': {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in '{path}': {exc.msg}.") from exc

    rows: list[Any]
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict):
        for key in ("records", "items", "data"):
            value = payload.get(key)
            if isinstance(value, list):
                rows = value
                break
        else:
            rows = [payload]
    else:
        rows = [payload]

    records: list[dict[str, Any]] = []
    for idx, row in enumerate(rows):
        record = _as_record(row)
        record["__aegis_source"] = str(path)
        record["__aegis_record_index"] = idx
        records.append(record)

    return records


def _load_csv_records(path: Path) -> list[dict[str, Any]]:
    try:
        handle = path.open("r", encoding="utf-8", newline="")
    except OSError as exc:
        raise ValueError(f"Unable to read CSV file '{path}': {exc}") from exc

    records: list[dict[str, Any]] = []
    with handle:
        reader = csv.DictReader(handle)
        for idx, row in enumerate(reader):
            record = {str(k): (v if v is not None else "") for k, v in row.items()}
            record["__aegis_source"] = str(path)
            record["__aegis_record_index"] = idx
            records.append(record)

    return records


def _load_directory_records(path: Path) -> list[dict[str, Any]]:
    files = sorted(p for p in path.rglob("*") if p.is_file())
    text_files = [p for p in files if p.suffix.lower() in _SUPPORTED_TEXT_SUFFIXES or not p.suffix]
    if not text_files:
        raise ValueError(
            f"Directory '{path}' has no readable text files. "
            f"Supported suffixes: {', '.join(_SUPPORTED_TEXT_SUFFIXES)}."
        )

    records: list[dict[str, Any]] = []
    for idx, file_path in enumerate(text_files):
        try:
            content = file_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"Unable to read text file '{file_path}': {exc}") from exc

        text = content.strip()
        if not text:
            continue

        records.append(
            {
                "content": text,
                "file_name": file_path.name,
                "relative_path": str(file_path.relative_to(path)),
                "__aegis_source": str(file_path),
                "__aegis_record_index": idx,
            }
        )

    return records


def _as_record(payload: Any) -> dict[str, Any]:
    if isinstance(payload, dict):
        return {str(k): v for k, v in payload.items()}
    return {"value": payload}


def _record_fingerprint(record: dict[str, Any]) -> str:
    payload = {k: v for k, v in record.items() if not k.startswith("__aegis_")}
    canonical = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _extract_difficulty(record: dict[str, Any], default: int) -> int:
    for key in _DIFFICULTY_KEYS:
        value = record.get(key)
        if value is None:
            continue
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            continue
        return max(1, min(5, parsed))
    return max(1, min(5, default))


def _synthesise_prompt(
    domain: str,
    dimension_id: str,
    record: dict[str, Any],
    case_index: int,
    difficulty: int,
) -> str:
    text_value = _first_text_value(record, _TEXT_KEYS)
    dimension_label = dimension_id.replace("_", " ")

    if text_value:
        base = text_value
    else:
        facts = _facts_from_record(record)
        base = facts if facts else "No explicit text content was provided."

    return (
        f"[{domain}] Case {case_index + 1} (difficulty {difficulty}/5). "
        f"Evaluate {dimension_label}: {base}"
    )


def _build_context(record: dict[str, Any]) -> dict[str, Any]:
    raw_context = record.get("context")
    if isinstance(raw_context, dict):
        return raw_context

    facts = _facts_from_record(record)
    context: dict[str, Any] = {
        "record_source": str(record.get("__aegis_source", "")),
        "record_index": int(record.get("__aegis_record_index", 0)),
    }
    if facts:
        context["facts"] = facts
    return context


def _build_expected_scaffold(record: dict[str, Any], dimension_id: str) -> dict[str, Any]:
    for key in _EXPECTED_KEYS:
        value = record.get(key)
        if value is None:
            continue
        if isinstance(value, dict):
            return value
        if isinstance(value, list):
            return {"expected_items": [str(item) for item in value]}
        return {"expected_answer": str(value)}

    return {
        "evaluation_dimension": dimension_id,
        "must_address": [dimension_id.replace("_", " ")],
        "grounding_required": True,
    }


def _build_tags(
    domain: str,
    dimension_id: str,
    difficulty: int,
    record: dict[str, Any],
) -> list[str]:
    tags: list[str] = [domain, dimension_id, f"difficulty_{difficulty}"]

    for key in _TAG_KEYS:
        value = record.get(key)
        if value is None:
            continue
        if isinstance(value, str) and value.strip():
            tags.append(value.strip())
        elif isinstance(value, list):
            tags.extend(str(item).strip() for item in value if str(item).strip())

    deduped: list[str] = []
    seen: set[str] = set()
    for tag in tags:
        if tag not in seen:
            seen.add(tag)
            deduped.append(tag)
    return deduped


def _first_text_value(record: dict[str, Any], keys: tuple[str, ...]) -> str:
    for key in keys:
        value = record.get(key)
        if value is None:
            continue
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _facts_from_record(record: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in sorted(record.keys()):
        if key.startswith("__aegis_"):
            continue
        value = record[key]
        if value is None:
            continue
        if isinstance(value, dict):
            continue
        rendered = ", ".join(str(item) for item in value) if isinstance(value, list) else str(value)
        rendered = rendered.strip()
        if rendered:
            parts.append(f"{key}: {rendered}")
        if len(parts) >= 5:
            break
    return " ; ".join(parts)
