"""Aegis domain plugins — extend the evaluation framework with domain-specific dimensions.

Re-exports all built-in plugin classes::

    from aegis.plugins import LegalPlugin, FinancePlugin, SafetyPlugin
"""

from aegis.plugins.base import DomainPlugin
from aegis.plugins.finance import FinancePlugin
from aegis.plugins.legal import LegalPlugin
from aegis.plugins.safety import SafetyPlugin

__all__ = [
    "DomainPlugin",
    "FinancePlugin",
    "LegalPlugin",
    "SafetyPlugin",
]
