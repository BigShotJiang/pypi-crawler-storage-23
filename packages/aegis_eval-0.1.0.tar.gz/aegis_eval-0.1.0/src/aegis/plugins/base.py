"""Abstract base class for Aegis domain plugins.

Domain plugins extend the evaluation framework with domain-specific
dimensions and test-case generators.  Every plugin must declare its
:attr:`name`, :attr:`version`, and implement :meth:`get_dimensions`
and :meth:`generate_test_cases`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from aegis.core.types import EvalCaseV1
from aegis.eval.dimensions.base import Dimension


class DomainPlugin(ABC):
    """Base class for all Aegis domain plugins.

    A domain plugin provides:
      * A set of :class:`Dimension` instances specific to the domain.
      * A test-case generator that can create :class:`EvalCaseV1` instances
        from domain-specific data sources.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique slug identifier for this plugin (e.g. ``'legal'``)."""
        ...

    @property
    @abstractmethod
    def version(self) -> str:
        """Semantic version string for this plugin (e.g. ``'0.1.0'``)."""
        ...

    @abstractmethod
    def get_dimensions(self) -> list[Dimension]:
        """Return all evaluation dimensions provided by this plugin.

        Returns:
            A list of fully-constructed :class:`Dimension` instances.
        """
        ...

    @abstractmethod
    def generate_test_cases(
        self,
        data_path: str | Path,
        count: int = 100,
    ) -> list[EvalCaseV1]:
        """Generate domain-specific evaluation test cases.

        Args:
            data_path: Path to the domain data source (e.g. a corpus
                directory or a structured dataset file).
            count: Number of test cases to generate.

        Returns:
            A list of :class:`EvalCaseV1` instances.
        """
        ...
