# Contributing to Aegis

Thank you for your interest in contributing to Aegis. This guide covers the essentials for getting started.

## Dev Setup

```bash
git clone https://github.com/metronis-space/aegis.git
cd aegis
python -m venv .venv
source .venv/bin/activate
make install
```

For infrastructure services (PostgreSQL, Neo4j, Redis):

```bash
docker compose up -d
```

## Running Tests

```bash
make test          # Run all tests
make coverage      # Run with coverage (≥80% required)
make lint          # Ruff lint check
make typecheck     # mypy strict mode
make benchmark     # Run legal/finance/memory benchmark suites
```

## Code Style

All code is formatted and linted with [Ruff](https://docs.astral.sh/ruff/). These checks are enforced in CI.

```bash
make lint      # check for lint errors
make format    # auto-format code
```

We target Python 3.11+ and use strict mypy for all source code.

## PR Workflow

1. Fork the repository and create a feature branch from `main`.
2. Make your changes and add tests for any new functionality.
3. Run `make lint`, `make typecheck`, and `make test` before pushing.
4. Open a pull request against `main` with a clear description of the change.

## Commit Messages

- Use a short imperative subject line (e.g., "Add memory compression policy").
- Keep the subject under 72 characters.
- Optionally add a blank line followed by a longer description body.

## Adding Eval Dimensions

Dimensions live in `src/aegis/eval/dimensions/` organized by tier. To add a new dimension:

1. Choose the appropriate tier directory (e.g., `tier1_memory/` for memory fidelity).
2. Create a new file (e.g., `my_dimension.py`) with a class extending `DimensionDefinition`.
3. Define the dimension ID, name, description, tier, and scoring rubric.
4. Register it in the tier's `__init__.py` and the dimension registry.
5. Add test cases in `tests/test_dimensions.py`.

Each dimension must include:
- A unique string ID (e.g., `"temporal_ordering"`)
- Scoring rubric with clear criteria for scores 0.0-1.0
- At least 3 test cases covering low, medium, and high scoring scenarios

## Creating Domain Plugins

Plugins extend Aegis with industry-specific dimensions. To create a custom plugin:

1. Create a package with a class extending `aegis.plugins.base.DomainPlugin`.
2. Implement `get_dimensions()` returning your domain-specific dimension definitions.
3. Implement `get_cases()` returning evaluation cases for your dimensions.
4. Register as an entry point in your `pyproject.toml`:

```toml
[project.entry-points."aegis.plugins"]
my_domain = "my_package.plugin:MyDomainPlugin"
```

See `src/aegis/plugins/legal.py` and `src/aegis/plugins/finance.py` for reference implementations.

## Docker Development

Build and run the full stack locally:

```bash
make docker-build   # Build API server image
make docker-up      # Start all services (API, dashboard, Postgres, Neo4j, Redis)
make docker-down    # Stop all services
```

## Project Layout

```
src/aegis/
├── adapters/      # Agent framework adapters
├── api/           # FastAPI routes and middleware
├── cli/           # Typer CLI application
├── core/          # Config, types, schemas
├── data/          # Dataset downloaders (CUAD, LegalBench, FinanceBench)
├── eval/          # Evaluation engine, dimensions, scorers, judges
├── ingestion/     # Document ingestion pipeline
├── memory/        # Memory subsystem (7 types, 12 ops)
├── observatory/   # Training health monitoring
├── plugins/       # Domain plugins (legal, finance, safety)
├── retrieval/     # Context retrieval (pgvector, Neo4j, cross-encoder)
├── store/         # Persistence (SQLite, PostgreSQL)
└── training/      # RL engine (AMIR-GRPO, GRPO-SG, curriculum, verl)
```
