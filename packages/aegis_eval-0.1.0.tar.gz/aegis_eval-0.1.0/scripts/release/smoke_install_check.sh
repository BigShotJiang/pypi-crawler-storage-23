#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="python"
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="$ROOT_DIR/.venv/bin/python"
fi

WHEEL_PATH="${1:-}"
if [[ -z "$WHEEL_PATH" ]]; then
  WHEEL_PATH="$(ls -1 dist/*.whl | head -n 1)"
fi

if [[ ! -f "$WHEEL_PATH" ]]; then
  echo "Wheel not found: $WHEEL_PATH" >&2
  exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

"$PYTHON_BIN" -m venv "$TMP_DIR/venv"
"$TMP_DIR/venv/bin/pip" install --upgrade pip >/dev/null
"$TMP_DIR/venv/bin/pip" install "$WHEEL_PATH" >/dev/null

"$TMP_DIR/venv/bin/python" - <<'PY'
import aegis
print(f"Imported aegis version: {aegis.__version__}")
PY

"$TMP_DIR/venv/bin/aegis" version >/dev/null

echo "Smoke install check passed: $WHEEL_PATH"
