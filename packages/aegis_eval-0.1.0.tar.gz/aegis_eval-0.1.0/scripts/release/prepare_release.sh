#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="python"
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="$ROOT_DIR/.venv/bin/python"
fi

TWINE_BIN="twine"
if [[ -x "$ROOT_DIR/.venv/bin/twine" ]]; then
  TWINE_BIN="$ROOT_DIR/.venv/bin/twine"
fi

echo "[release] Building source + wheel distributions"
rm -rf dist build
"$PYTHON_BIN" -m build

echo "[release] Validating package metadata"
"$TWINE_BIN" check dist/*

echo "[release] Running wheel smoke check"
bash scripts/release/smoke_install_check.sh

echo "[release] SHA256 checksums"
shasum -a 256 dist/*

echo
ls -lh dist
echo
echo "Release preparation complete (no live publish executed)."
echo "Next: follow docs/runbooks/publish_pypi_github_ghcr.md"
