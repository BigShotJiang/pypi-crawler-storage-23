#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="python"
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="$ROOT_DIR/.venv/bin/python"
fi

AEGIS_BIN="aegis"
if [[ -x "$ROOT_DIR/.venv/bin/aegis" ]]; then
  AEGIS_BIN="$ROOT_DIR/.venv/bin/aegis"
fi

TRAINING_CONFIG="configs/training/legal_gpu_smoke.yaml"
BASELINE_CONFIG="configs/eval/legal_baseline.yaml"
TRAINED_CONFIG="configs/eval/legal_trained.yaml"
OUTPUT_DIR="results/proof"
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --training-config)
      TRAINING_CONFIG="${2:-}"
      shift 2
      ;;
    --baseline-config)
      BASELINE_CONFIG="${2:-}"
      shift 2
      ;;
    --trained-config)
      TRAINED_CONFIG="${2:-}"
      shift 2
      ;;
    --output-dir)
      OUTPUT_DIR="${2:-}"
      shift 2
      ;;
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

mkdir -p "$OUTPUT_DIR/baseline" "$OUTPUT_DIR/trained"

bash scripts/training/validate_gpu_env.sh --json "$OUTPUT_DIR/gpu_env.json"

if [[ "$DRY_RUN" -eq 1 ]]; then
  echo "Dry run enabled. Commands prepared but not executed:"
  echo "  $AEGIS_BIN eval run --config $BASELINE_CONFIG --output $OUTPUT_DIR/baseline"
  echo "  $PYTHON_BIN scripts/training/collect_proof.py --baseline $OUTPUT_DIR/baseline --trained $OUTPUT_DIR/trained --training-result $OUTPUT_DIR/training_result.json --config $TRAINING_CONFIG --output-dir $OUTPUT_DIR"
  exit 0
fi

# 1) Baseline eval
"$AEGIS_BIN" eval run --config "$BASELINE_CONFIG" --output "$OUTPUT_DIR/baseline"

# 2) Training step (real if verl+cuda available, simulated fallback otherwise)
"$PYTHON_BIN" - "$TRAINING_CONFIG" "$OUTPUT_DIR" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

from aegis.training.verl_bridge import VerlTrainer, VerlTrainingConfig

config_path = Path(sys.argv[1])
output_dir = Path(sys.argv[2])

raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
training = raw.get("training", {}) if isinstance(raw, dict) else {}

cfg = VerlTrainingConfig(
    model_name=str(training.get("model_name", "Qwen/Qwen2.5-7B")),
    output_dir=str(training.get("output_dir", output_dir / "adapter")),
    num_episodes=int(training.get("num_episodes", 20)),
    rollouts_per_prompt=int(training.get("rollouts_per_prompt", 4)),
    max_seq_length=int(training.get("max_seq_length", 2048)),
    learning_rate=float(training.get("learning_rate", 1e-5)),
    kl_coeff=float(training.get("kl_coeff", 0.05)),
    use_lora=bool(training.get("use_lora", True)),
    lora_rank=int(training.get("lora_rank", 16)),
    lora_alpha=int(training.get("lora_alpha", 32)),
    precision=str(training.get("precision", "bf16")),
    gradient_accumulation_steps=int(training.get("gradient_accumulation_steps", 4)),
    reward_stages=int(training.get("reward_stages", 5)),
    domain=str(training.get("domain", "legal")),
)

prompts_obj = training.get("prompts", [])
if isinstance(prompts_obj, list) and prompts_obj:
    prompts = [str(p) for p in prompts_obj]
else:
    prompts = [
        "Review indemnification and liability limits in this agreement.",
        "Summarize key payment and termination obligations.",
        "Identify superseded clauses and current enforceable terms.",
    ]

trainer = VerlTrainer(cfg)
result = trainer.train(prompts)

output_dir.mkdir(parents=True, exist_ok=True)
(output_dir / "training_result.json").write_text(
    json.dumps(result, indent=2, sort_keys=True),
    encoding="utf-8",
)
PY

# 3) Trained eval
"$AEGIS_BIN" eval run --config "$TRAINED_CONFIG" --output "$OUTPUT_DIR/trained"

# 4) Collect canonical proof artifacts
"$PYTHON_BIN" scripts/training/collect_proof.py \
  --baseline "$OUTPUT_DIR/baseline" \
  --trained "$OUTPUT_DIR/trained" \
  --training-result "$OUTPUT_DIR/training_result.json" \
  --config "$TRAINING_CONFIG" \
  --output-dir "$OUTPUT_DIR"

echo "GPU proof pipeline complete. Artifacts available under $OUTPUT_DIR"
