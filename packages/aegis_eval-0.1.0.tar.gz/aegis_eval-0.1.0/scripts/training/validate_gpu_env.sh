#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="python"
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="$ROOT_DIR/.venv/bin/python"
fi

OUTPUT_JSON=""
STRICT=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --json)
      OUTPUT_JSON="${2:-}"
      shift 2
      ;;
    --strict)
      STRICT=1
      shift
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

"$PYTHON_BIN" - "$OUTPUT_JSON" "$STRICT" <<'PY'
from __future__ import annotations

import importlib
import json
import os
import platform
import shutil
import sys
from pathlib import Path

output_json = sys.argv[1]
strict = bool(int(sys.argv[2]))


def _pkg_version(name: str) -> str | None:
    try:
        module = importlib.import_module(name)
    except Exception:
        return None
    return getattr(module, "__version__", "unknown")


torch_version = _pkg_version("torch")
verl_version = _pkg_version("verl")
cuda_available = False
gpu_count = 0
gpu_name = ""

if torch_version is not None:
    import torch  # type: ignore[import-not-found]

    cuda_available = bool(torch.cuda.is_available())
    gpu_count = int(torch.cuda.device_count()) if cuda_available else 0
    if gpu_count > 0:
        gpu_name = str(torch.cuda.get_device_name(0))

nvidia_smi = shutil.which("nvidia-smi") is not None
hf_token_set = bool(os.getenv("HF_TOKEN"))

ready = bool(torch_version and verl_version and cuda_available and gpu_count > 0)
result = {
    "python": {
        "version": platform.python_version(),
        "executable": sys.executable,
        "platform": platform.platform(),
    },
    "checks": {
        "torch_installed": torch_version is not None,
        "torch_version": torch_version,
        "verl_installed": verl_version is not None,
        "verl_version": verl_version,
        "cuda_available": cuda_available,
        "gpu_count": gpu_count,
        "gpu_name": gpu_name,
        "nvidia_smi": nvidia_smi,
        "hf_token_set": hf_token_set,
    },
    "ready_for_real_training": ready,
    "recommended_action": "run_gpu_proof"
    if ready
    else "install torch+verl on CUDA host and set HF_TOKEN",
}

print(json.dumps(result, indent=2, sort_keys=True))

if output_json:
    out = Path(output_json)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")

if strict and not ready:
    raise SystemExit(1)
PY
