#!/usr/bin/env python3
"""Collect proof artifacts from baseline/trained eval outputs.

Expected outputs in ``results/proof``:
- baseline_eval.json
- trained_eval.json
- delta_report.json
- adapter_manifest.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from aegis.training.proof_artifacts import (
    build_adapter_manifest,
    build_delta_report,
    load_eval_artifact,
    write_json,
)


def _latest_json(path: Path) -> Path:
    if path.is_file():
        return path
    if not path.exists():
        msg = f"Path not found: {path}"
        raise FileNotFoundError(msg)

    candidates = sorted(path.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not candidates:
        msg = f"No JSON files found under: {path}"
        raise FileNotFoundError(msg)
    return candidates[0]


def _load_training_result(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.exists():
        return None
    raw = json.loads(path.read_text(encoding="utf-8"))
    return raw if isinstance(raw, dict) else None


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect GPU proof artifacts for Aegis.")
    parser.add_argument(
        "--baseline", type=Path, required=True, help="Baseline eval JSON or directory."
    )
    parser.add_argument(
        "--trained", type=Path, required=True, help="Trained eval JSON or directory."
    )
    parser.add_argument(
        "--training-result",
        type=Path,
        default=None,
        help="Optional JSON from the training step (contains backend + adapter metadata).",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Optional training config path to include in adapter_manifest.json.",
    )
    parser.add_argument(
        "--adapter-path",
        type=str,
        default="",
        help="Optional adapter path override for adapter_manifest.json.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/proof"),
        help="Output directory for proof artifacts.",
    )
    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    baseline_path = _latest_json(args.baseline)
    trained_path = _latest_json(args.trained)

    baseline_summary = load_eval_artifact(baseline_path)
    trained_summary = load_eval_artifact(trained_path)

    delta_report = build_delta_report(baseline_summary, trained_summary)
    training_result = _load_training_result(args.training_result)
    adapter_manifest = build_adapter_manifest(
        training_result=training_result,
        adapter_path=args.adapter_path or None,
        config_path=str(args.config) if args.config is not None else None,
    )

    output_dir = args.output_dir
    write_json(output_dir / "baseline_eval.json", baseline_summary.to_dict())
    write_json(output_dir / "trained_eval.json", trained_summary.to_dict())
    write_json(output_dir / "delta_report.json", delta_report)
    write_json(output_dir / "adapter_manifest.json", adapter_manifest)

    print("Proof artifacts written:")
    print(f"- {output_dir / 'baseline_eval.json'}")
    print(f"- {output_dir / 'trained_eval.json'}")
    print(f"- {output_dir / 'delta_report.json'}")
    print(f"- {output_dir / 'adapter_manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
