#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PY_BIN="python"
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PY_BIN="$ROOT_DIR/.venv/bin/python"
fi

OUTPUT_PATH="${1:-tmp-download/closed_loop_demo.json}"
BACKEND="${2:-sim}"

if [[ "$BACKEND" == "real" ]]; then
  "${PY_BIN}" examples/closed_loop_demo.py \
    --backend real \
    --real-baseline "${REAL_BASELINE:-results/proof/baseline_eval.json}" \
    --real-trained "${REAL_TRAINED:-results/proof/trained_eval.json}" \
    --output "$OUTPUT_PATH"
else
  "${PY_BIN}" examples/closed_loop_demo.py --backend sim --output "$OUTPUT_PATH"
fi
