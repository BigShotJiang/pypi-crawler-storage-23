#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PYTEST_BIN="${PYTEST_BIN:-./.venv/bin/pytest}"
RUFF_BIN="${RUFF_BIN:-./.venv/bin/ruff}"
MYPY_BIN="${MYPY_BIN:-./.venv/bin/mypy}"
PYTHON_BIN="${PYTHON_BIN:-./.venv/bin/python}"

"$RUFF_BIN" check src/aegis tests
"$MYPY_BIN" --strict src/aegis
"$PYTEST_BIN" --cov=src/aegis --cov-fail-under=80 -q

"$PYTHON_BIN" - <<'PY'
from aegis.eval.benchmarks import LegalMemoryScaleBenchmark

suite = LegalMemoryScaleBenchmark().build_suite()
count = len(suite.cases)
if count < 200:
    raise SystemExit(f"Expected >=200 legal-memory-scale cases, got {count}")
print(f"legal-memory-scale cases: {count}")
PY

MATRIX_CSV="docs/comparison/original-plan-capability-matrix.csv"
MATRIX_MD="docs/comparison/original-plan-capability-matrix.md"

[[ -f "$MATRIX_CSV" ]] || {
  echo "Missing required comparison artifact: $MATRIX_CSV" >&2
  exit 1
}
[[ -f "$MATRIX_MD" ]] || {
  echo "Missing required comparison artifact: $MATRIX_MD" >&2
  exit 1
}

"$PYTHON_BIN" - "$MATRIX_CSV" <<'PY'
from __future__ import annotations

import csv
import sys
from collections import Counter
from pathlib import Path

matrix_path = Path(sys.argv[1])
allowed_status = {
    "implemented",
    "partial",
    "missing",
    "deferred_by_plan",
    "non_codable_ignored",
}
required_columns = {
    "capability_id",
    "source_doc",
    "phase",
    "codable",
    "repo_status",
    "evidence_code",
    "evidence_test",
    "gap_action",
    "deferred_by_plan",
}

with matrix_path.open(newline="", encoding="utf-8") as handle:
    reader = csv.DictReader(handle)
    columns = set(reader.fieldnames or [])
    missing_columns = sorted(required_columns - columns)
    if missing_columns:
        raise SystemExit(
            "Capability matrix missing required columns: "
            + ", ".join(missing_columns)
        )
    rows = list(reader)

if not rows:
    raise SystemExit("Capability matrix has no data rows.")

errors: list[str] = []
status_counts: Counter[str] = Counter()

for idx, row in enumerate(rows, start=2):
    cap_id = row.get("capability_id", "").strip()
    status = row.get("repo_status", "").strip()
    evidence_code = row.get("evidence_code", "").strip()
    evidence_test = row.get("evidence_test", "").strip()
    deferred = row.get("deferred_by_plan", "").strip().lower()

    if not cap_id:
        errors.append(f"line {idx}: capability_id is empty")

    if status not in allowed_status:
        errors.append(f"line {idx}: invalid repo_status '{status}'")
    else:
        status_counts[status] += 1

    if not evidence_code and not evidence_test:
        errors.append(f"line {idx}: missing both evidence_code and evidence_test")

    if deferred not in {"true", "false"}:
        errors.append(f"line {idx}: deferred_by_plan must be true|false, got '{deferred}'")

    if status == "deferred_by_plan" and deferred != "true":
        errors.append(f"line {idx}: repo_status deferred_by_plan requires deferred_by_plan=true")
    if status != "deferred_by_plan" and deferred == "true":
        errors.append(f"line {idx}: deferred_by_plan=true requires repo_status=deferred_by_plan")

if errors:
    preview = "\n".join(f"- {msg}" for msg in errors[:20])
    extra = f"\n... and {len(errors) - 20} more" if len(errors) > 20 else ""
    raise SystemExit("Capability matrix validation failed:\n" + preview + extra)

summary = ", ".join(f"{k}={status_counts[k]}" for k in sorted(status_counts))
print(f"capability-matrix rows: {len(rows)} ({summary})")
PY

printf "\nAll completion-plan acceptance checks passed.\n"
