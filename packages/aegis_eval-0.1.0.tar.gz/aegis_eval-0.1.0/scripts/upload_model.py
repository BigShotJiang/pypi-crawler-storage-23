#!/usr/bin/env python3
"""Upload an Aegis-trained LoRA adapter to HuggingFace Hub.

Usage::

    python scripts/upload_model.py \\
        --model-path checkpoints/legal-v1 \\
        --repo metronis/aegis-legal-v1

    python scripts/upload_model.py \\
        --model-path checkpoints/legal-v1 \\
        --repo metronis/aegis-legal-v1 \\
        --base-model Qwen/Qwen2.5-7B \\
        --private \\
        --token hf_xxx
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Upload an Aegis-trained LoRA adapter to HuggingFace Hub.",
    )
    parser.add_argument(
        "--model-path",
        type=str,
        required=True,
        help="Path to the local directory containing the adapter weights.",
    )
    parser.add_argument(
        "--repo",
        type=str,
        required=True,
        help="Target HuggingFace repo ID (e.g. metronis/aegis-legal-v1).",
    )
    parser.add_argument(
        "--base-model",
        type=str,
        default="Qwen/Qwen2.5-7B",
        help="Name of the base model the adapter was trained on (default: Qwen/Qwen2.5-7B).",
    )
    parser.add_argument(
        "--description",
        type=str,
        default="LoRA adapter trained with Aegis RL training engine.",
        help="Short description for the model card.",
    )
    parser.add_argument(
        "--private",
        action="store_true",
        default=False,
        help="Create the repository as private.",
    )
    parser.add_argument(
        "--token",
        type=str,
        default=None,
        help="HuggingFace API token (defaults to HF_TOKEN env var).",
    )
    parser.add_argument(
        "--commit-message",
        type=str,
        default="Upload Aegis LoRA adapter",
        help="Commit message for the upload.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Entry point for the upload script."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    model_path = Path(args.model_path)
    if not model_path.is_dir():
        print(f"Error: Model directory not found: {model_path}", file=sys.stderr)
        return 1

    # Lazy import to provide a clear error if huggingface_hub is missing
    try:
        from aegis.training.hf_upload import HFUploader
    except ImportError:
        print(
            "Error: Could not import aegis.training.hf_upload. "
            "Make sure aegis is installed: pip install -e '.[training]'",
            file=sys.stderr,
        )
        return 1

    model_card_data = {
        "base_model": args.base_model,
        "repo_id": args.repo,
        "description": args.description,
    }

    uploader = HFUploader(token=args.token)

    try:
        url = uploader.upload_model(
            local_path=model_path,
            repo_id=args.repo,
            model_card_data=model_card_data,
            private=args.private,
            commit_message=args.commit_message,
        )
        print(f"Successfully uploaded model to: {url}")
    except Exception as exc:
        print(f"Error uploading model: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
