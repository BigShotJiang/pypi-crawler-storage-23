#!/usr/bin/env python3
"""Download benchmark datasets for Aegis evaluation.

Usage::

    python scripts/download_datasets.py
    python scripts/download_datasets.py --dataset cuad
    python scripts/download_datasets.py --dataset legalbench --cache-dir /tmp/aegis-data

This script downloads benchmark datasets used by the Aegis evaluation
framework.  By default all supported datasets are downloaded.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from rich.console import Console

console = Console()

DATASETS = ["cuad", "legalbench", "financebench"]


def _download_cuad(cache_dir: Path | None) -> int:
    """Download and convert the CUAD dataset."""
    from aegis.data.cuad import load_cuad

    console.print("\n[bold cyan]Downloading CUAD...[/bold cyan]")
    try:
        cases = load_cuad(cache_dir=cache_dir)
        console.print(f"  [green]Loaded {len(cases)} eval cases from CUAD.[/green]")
        return 0
    except Exception as exc:
        console.print(f"  [red]Failed to download CUAD: {exc}[/red]")
        return 1


def _download_legalbench(cache_dir: Path | None) -> int:
    """Download and convert the LegalBench dataset."""
    from aegis.data.legalbench import load_legalbench

    console.print("\n[bold cyan]Downloading LegalBench...[/bold cyan]")
    try:
        cases = load_legalbench(cache_dir=cache_dir)
        console.print(f"  [green]Loaded {len(cases)} eval cases from LegalBench.[/green]")
        return 0
    except Exception as exc:
        console.print(f"  [red]Failed to download LegalBench: {exc}[/red]")
        return 1


def _download_financebench(cache_dir: Path | None) -> int:
    """Download and convert the FinanceBench dataset."""
    from aegis.data.financebench import load_financebench

    console.print("\n[bold cyan]Downloading FinanceBench...[/bold cyan]")
    try:
        cases = load_financebench(cache_dir=cache_dir)
        console.print(f"  [green]Loaded {len(cases)} eval cases from FinanceBench.[/green]")
        return 0
    except Exception as exc:
        console.print(f"  [red]Failed to download FinanceBench: {exc}[/red]")
        return 1


_DOWNLOADERS = {
    "cuad": _download_cuad,
    "legalbench": _download_legalbench,
    "financebench": _download_financebench,
}


def main() -> int:
    parser = argparse.ArgumentParser(description="Download benchmark datasets for Aegis.")
    parser.add_argument(
        "--dataset",
        choices=DATASETS + ["all"],
        default="all",
        help="Which dataset to download (default: all).",
    )
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=None,
        help="Cache directory for downloaded data (default: ~/.aegis/datasets/).",
    )
    args = parser.parse_args()

    console.print("[bold]Aegis Dataset Downloader[/bold]")
    console.print("=" * 40)

    targets = DATASETS if args.dataset == "all" else [args.dataset]
    failures = 0

    for name in targets:
        downloader_fn = _DOWNLOADERS[name]
        failures += downloader_fn(args.cache_dir)

    console.print()
    if failures:
        console.print(f"[red]Completed with {failures} failure(s).[/red]")
    else:
        console.print("[green]All datasets downloaded successfully.[/green]")

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
