#!/usr/bin/env bash
# Aegis Legal Domain Training Launch Script
#
# Trains a Qwen2.5-7B model with LoRA on legal domain tasks using
# GRPO with Aegis multi-stage process rewards.
#
# Supports local GPU training or cloud-based training via AWS SageMaker.
#
# Prerequisites:
#   pip install 'aegis-eval[gpu]'  # torch, transformers, peft, verl
#   CUDA-capable GPU with >= 24GB VRAM (A100/H100 recommended)
#
# For cloud training:
#   pip install boto3 sagemaker
#   Set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, SAGEMAKER_ROLE_ARN
#
# Usage:
#   ./scripts/train_legal.sh                         # Local GPU training
#   ./scripts/train_legal.sh --cloud aws             # AWS SageMaker training
#   ./scripts/train_legal.sh --episodes 200          # Override episodes
#   ./scripts/train_legal.sh --cloud aws --spot      # Spot instances (default)
#   AEGIS_MODEL=Qwen/Qwen2.5-3B ./scripts/train_legal.sh  # Smaller model

set -euo pipefail

# Defaults (overridable via environment)
MODEL="${AEGIS_MODEL:-Qwen/Qwen2.5-7B}"
DOMAIN="legal"
OUTPUT_DIR="${AEGIS_OUTPUT_DIR:-./checkpoints/legal-lora}"
EPISODES="${AEGIS_EPISODES:-100}"
ROLLOUTS_PER_PROMPT="${AEGIS_ROLLOUTS:-8}"
LEARNING_RATE="${AEGIS_LR:-1e-5}"
LORA_RANK="${AEGIS_LORA_RANK:-16}"
LORA_ALPHA="${AEGIS_LORA_ALPHA:-32}"
PRECISION="${AEGIS_PRECISION:-bf16}"
GPU_IDS="${AEGIS_GPU_IDS:-0}"
MAX_SEQ_LENGTH="${AEGIS_MAX_SEQ:-4096}"
CLOUD=""
INSTANCE_TYPE="${AEGIS_INSTANCE_TYPE:-ml.g5.xlarge}"
USE_SPOT="True"
S3_BUCKET="${AEGIS_S3_BUCKET:-aegis-training-checkpoints}"
DATASET_PATH="${AEGIS_DATASET_PATH:-}"

# Parse any CLI overrides
while [[ $# -gt 0 ]]; do
    case "$1" in
        --episodes)  EPISODES="$2"; shift 2 ;;
        --model)     MODEL="$2"; shift 2 ;;
        --output)    OUTPUT_DIR="$2"; shift 2 ;;
        --lr)        LEARNING_RATE="$2"; shift 2 ;;
        --gpus)      GPU_IDS="$2"; shift 2 ;;
        --cloud)     CLOUD="$2"; shift 2 ;;
        --instance)  INSTANCE_TYPE="$2"; shift 2 ;;
        --spot)      USE_SPOT="True"; shift ;;
        --no-spot)   USE_SPOT="False"; shift ;;
        --s3-bucket) S3_BUCKET="$2"; shift 2 ;;
        --dataset)   DATASET_PATH="$2"; shift 2 ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

echo "========================================"
echo "  Aegis Legal Domain Training"
echo "========================================"
echo "  Model:          ${MODEL}"
echo "  Domain:         ${DOMAIN}"
echo "  Episodes:       ${EPISODES}"
echo "  LoRA:           rank=${LORA_RANK}, alpha=${LORA_ALPHA}"
echo "  Precision:      ${PRECISION}"
if [[ -n "${CLOUD}" ]]; then
    echo "  Cloud:          ${CLOUD}"
    echo "  Instance:       ${INSTANCE_TYPE}"
    echo "  Spot:           ${USE_SPOT}"
    echo "  S3 Bucket:      ${S3_BUCKET}"
else
    echo "  GPU IDs:        ${GPU_IDS}"
fi
echo "  Output:         ${OUTPUT_DIR}"
echo "========================================"

# Ensure output directory exists (local mode)
mkdir -p "${OUTPUT_DIR}"

if [[ "${CLOUD}" == "aws" ]]; then
    # Cloud training via AWS SageMaker
    exec python -c "
from aegis.training.cloud_launcher import AWSLauncher, AWSLauncherConfig
import os, json

launcher_config = AWSLauncherConfig(
    role_arn=os.environ.get('SAGEMAKER_ROLE_ARN', ''),
    s3_bucket='${S3_BUCKET}',
    region=os.environ.get('AWS_DEFAULT_REGION', 'us-east-1'),
    instance_type='${INSTANCE_TYPE}',
    use_spot=${USE_SPOT},
)

launcher = AWSLauncher(launcher_config)

job_config = {
    'model_name': '${MODEL}',
    'domain': '${DOMAIN}',
    'dataset_path': '${DATASET_PATH}',
    'instance_type': '${INSTANCE_TYPE}',
    'use_spot': ${USE_SPOT},
    'use_lora': True,
    'lora_rank': ${LORA_RANK},
    'learning_rate': ${LEARNING_RATE},
    'num_episodes': ${EPISODES},
}

result = launcher.launch(job_config)
print(json.dumps(result, indent=2, default=str))
print(f'Job ID: {result[\"job_id\"]}')
print(f'Status: {result[\"status\"]}')

if result['status'] not in ('dry_run', 'failed'):
    print(f'Monitor with: python -c \"from aegis.training.cloud_launcher import AWSLauncher; print(AWSLauncher().status(\\\"{result[\"job_id\"]}\\\"))\"')
"
else
    # Local training via verl bridge
    exec python -c "
from aegis.training.verl_bridge import VerlTrainer, VerlTrainingConfig
from aegis.training.tracking import ExperimentTracker

config = VerlTrainingConfig(
    model_name='${MODEL}',
    output_dir='${OUTPUT_DIR}',
    num_episodes=${EPISODES},
    rollouts_per_prompt=${ROLLOUTS_PER_PROMPT},
    max_seq_length=${MAX_SEQ_LENGTH},
    learning_rate=${LEARNING_RATE},
    use_lora=True,
    lora_rank=${LORA_RANK},
    lora_alpha=${LORA_ALPHA},
    precision='${PRECISION}',
    domain='${DOMAIN}',
    gpu_ids=[int(x) for x in '${GPU_IDS}'.split(',')],
)

# Initialise experiment tracking
tracker = ExperimentTracker(
    project='aegis-training',
    run_name='legal-${MODEL##*/}-ep${EPISODES}',
    config=config.to_dict(),
)

trainer = VerlTrainer(config)
print(f'Device info: {trainer.device_info}')
print(f'Real training: {trainer.is_real_training}')

# Legal domain training prompts
prompts = [
    'Analyze the enforceability of the non-compete clause in this employment agreement.',
    'Identify potential liability exposure under Section 402A for the manufacturer.',
    'Draft a summary of contractual obligations under the services agreement.',
    'Review the indemnification clause for breadth and potential gaps.',
    'Assess the force majeure provision applicability to pandemic-related disruptions.',
    'Compare the warranty provisions across the three vendor agreements.',
    'Evaluate the intellectual property assignment clause for completeness.',
    'Identify conflicts between the master agreement and the attached SOW.',
    'Analyze the termination for convenience clause and its implications.',
    'Review the data protection addendum for GDPR compliance.',
]

result = trainer.train(prompts)

# Log final metrics
tracker.log_metrics(step=0, metrics={
    'mean_reward': result['mean_reward'],
    'best_reward': result['best_reward'],
    'final_loss': result.get('final_loss', 0.0),
})
tracker.finish()

print(f'Status: {result[\"status\"]}')
print(f'Mean reward: {result[\"mean_reward\"]:.4f}')
print(f'Best reward: {result[\"best_reward\"]:.4f}')
print(f'Backend: {result.get(\"backend\", \"unknown\")}')
"
fi
