#!/usr/bin/env python3
"""Aegis Quickstart — run an eval and inspect the results.

Usage::

    python examples/quickstart.py
"""

from aegis import EvalConfig, Evaluator

# Run a full evaluation across all 101 dimensions
evaluator = Evaluator(config=EvalConfig(dimensions="all"))
result = evaluator.run()

# Overall composite score
print(f"Overall score: {result.overall_score:.2%}")
print(f"Run ID:        {result.run_id}")
print(f"Dimensions:    {len(result.dimension_scores)}")
print()

# Top 5 dimensions
sorted_dims = sorted(result.dimension_scores.items(), key=lambda kv: kv[1], reverse=True)
print("Top 5 dimensions:")
for dim_id, score in sorted_dims[:5]:
    print(f"  {dim_id:<40s} {score:.4f}")

print()

# Bottom 5 dimensions
print("Bottom 5 dimensions:")
for dim_id, score in sorted_dims[-5:]:
    print(f"  {dim_id:<40s} {score:.4f}")
