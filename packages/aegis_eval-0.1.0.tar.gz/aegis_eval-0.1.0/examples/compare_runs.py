#!/usr/bin/env python3
"""Compare two eval runs with different seeds and print deltas.

Usage::

    python examples/compare_runs.py
"""

from aegis import EvalConfig, Evaluator

# Run two evaluations with different seeds
config_a = EvalConfig(dimensions="all", seed=1)
config_b = EvalConfig(dimensions="all", seed=2)

evaluator = Evaluator()

print("Running eval A (seed=1) ...")
result_a = evaluator.run(config=config_a)
print(f"  Score: {result_a.overall_score:.4f}")

print("Running eval B (seed=2) ...")
result_b = evaluator.run(config=config_b)
print(f"  Score: {result_b.overall_score:.4f}")

# Compare
comparison = evaluator.compare(result_a, result_b)

print(f"\nOverall delta: {comparison['overall_delta']:+.4f}")
print(f"Improved:  {len(comparison['improved'])} dimensions")
print(f"Regressed: {len(comparison['regressed'])} dimensions")
print(f"Unchanged: {len(comparison['unchanged'])} dimensions")

# Show top 5 biggest changes
deltas = sorted(comparison["dimension_deltas"].items(), key=lambda kv: abs(kv[1]), reverse=True)
print("\nBiggest changes:")
for dim_id, delta in deltas[:5]:
    direction = "+" if delta > 0 else ""
    print(f"  {dim_id:<40s} {direction}{delta:.4f}")
