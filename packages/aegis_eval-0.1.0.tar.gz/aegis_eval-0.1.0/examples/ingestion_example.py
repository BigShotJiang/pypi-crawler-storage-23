#!/usr/bin/env python3
"""Aegis Ingestion Example -- parse, chunk, and store documents.

Demonstrates the IngestionPipeline for document processing,
including parsing, chunking, deduplication, and storage sink integration.

Usage::
    python examples/ingestion_example.py
"""

from pathlib import Path

from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline


def main() -> None:
    print("=" * 60)
    print("  Aegis Ingestion Example")
    print("=" * 60)

    # Resolve paths to sample data relative to this script
    examples_dir = Path(__file__).resolve().parent
    sample_dir = examples_dir / "sample_data"
    contract_path = sample_dir / "contract_excerpt.txt"
    filing_path = sample_dir / "financial_filing.txt"

    # ------------------------------------------------------------------
    # 1. Create an IngestionPipeline with custom config
    # ------------------------------------------------------------------
    print("\n--- Step 1: Create Ingestion Pipeline ---")
    config = IngestionConfig(
        max_chunk_words=200,       # Smaller chunks for demonstration
        overlap_words=20,          # 20-word overlap between chunks
        min_chunk_words=5,         # Drop chunks shorter than 5 words
        compute_hashes=True,       # Enable content hashing for dedup
        deduplicate=True,          # Remove duplicate chunks
    )
    pipeline = IngestionPipeline(config=config)
    print(f"  Max chunk words: {config.max_chunk_words}")
    print(f"  Overlap words:   {config.overlap_words}")
    print(f"  Deduplication:   {config.deduplicate}")

    # Show registered parsers
    print(f"\n  Supported extensions: {pipeline.registry.supported_extensions()}")

    # ------------------------------------------------------------------
    # 2. Ingest the legal contract excerpt
    # ------------------------------------------------------------------
    print("\n--- Step 2: Ingest Legal Contract ---")
    contract_result = pipeline.ingest(contract_path)
    print(f"  Source:    {contract_result.source_path}")
    print(f"  Modality:  {contract_result.modality.value}")
    print(f"  Chunks:    {contract_result.num_chunks}")
    print(f"  Doc ID:    {contract_result.document_id[:16]}...")

    print("\n  Chunk details:")
    for i, chunk in enumerate(contract_result.chunks):
        preview = chunk.content[:80].replace("\n", " ")
        word_count = chunk.metadata.get("word_count", len(chunk.content.split()))
        content_hash = chunk.metadata.get("content_hash", "n/a")
        print(f"    [{i}] words={word_count:>3}, hash={content_hash}, preview: {preview}...")

    # ------------------------------------------------------------------
    # 3. Ingest the financial filing excerpt
    # ------------------------------------------------------------------
    print("\n--- Step 3: Ingest Financial Filing ---")
    filing_result = pipeline.ingest(filing_path)
    print(f"  Source:    {filing_result.source_path}")
    print(f"  Modality:  {filing_result.modality.value}")
    print(f"  Chunks:    {filing_result.num_chunks}")
    print(f"  Doc ID:    {filing_result.document_id[:16]}...")

    print("\n  Chunk details:")
    for i, chunk in enumerate(filing_result.chunks):
        preview = chunk.content[:80].replace("\n", " ")
        word_count = chunk.metadata.get("word_count", len(chunk.content.split()))
        content_hash = chunk.metadata.get("content_hash", "n/a")
        print(f"    [{i}] words={word_count:>3}, hash={content_hash}, preview: {preview}...")

    # ------------------------------------------------------------------
    # 4. Show batch ingestion
    # ------------------------------------------------------------------
    print("\n--- Step 4: Batch Ingestion ---")
    # Ingest both files in a single batch call
    batch_results = pipeline.ingest_batch([contract_path, filing_path])
    print(f"  Documents ingested: {len(batch_results)}")
    for br in batch_results:
        print(f"    - {Path(br.source_path).name}: {br.num_chunks} chunks ({br.modality.value})")

    # ------------------------------------------------------------------
    # 5. Show ingestion history
    # ------------------------------------------------------------------
    print("\n--- Step 5: Ingestion History ---")
    history = pipeline.history()
    print(f"  Total ingestions: {len(history)}")
    for h in history:
        print(
            f"    [{h.document_id[:8]}...] "
            f"{Path(h.source_path).name}: "
            f"{h.num_chunks} chunks, "
            f"modality={h.modality.value}"
        )

    # ------------------------------------------------------------------
    # 6. Demonstrate store_results (no sinks configured)
    # ------------------------------------------------------------------
    print("\n--- Step 6: Store Results (no sinks) ---")
    # store_results writes chunks to configured storage sinks.
    # With no sinks, it returns an empty dict -- this just shows the API.
    store_counts = pipeline.store_results(contract_result, sinks=None)
    print(f"  Sink results: {store_counts}")
    print("  (No sinks configured -- in production, sinks write to vector DB, memory store, etc.)")

    # ------------------------------------------------------------------
    # 7. Inspect raw content from a chunk
    # ------------------------------------------------------------------
    print("\n--- Step 7: Full Chunk Inspection ---")
    if contract_result.chunks:
        chunk = contract_result.chunks[0]
        print(f"  Chunk index:   {chunk.chunk_index}")
        print(f"  Modality:      {chunk.modality.value}")
        print(f"  Source:        {chunk.source_path}")
        print(f"  Confidence:    {chunk.confidence}")
        print(f"  Metadata:      {chunk.metadata}")
        print(f"  Content:\n    {chunk.content[:200]}...")

    print("\n" + "=" * 60)
    print("  Ingestion example complete.")
    print("=" * 60)


if __name__ == "__main__":
    main()
