#!/usr/bin/env python3
"""Closed-loop demo: eval -> diagnose -> improve -> re-eval.

This script provides a deterministic proof artifact for the Aegis closed-loop
thesis across two backends:

- ``sim``: deterministic simulation with built-in benchmark cases.
- ``real``: comparison mode over real proof artifacts produced by
  ``scripts/training/run_gpu_proof.sh``.

Usage:
    python examples/closed_loop_demo.py
    python examples/closed_loop_demo.py --output /tmp/closed_loop_demo.json
    python examples/closed_loop_demo.py --backend real \
        --real-baseline results/proof/baseline_eval.json \
        --real-trained results/proof/trained_eval.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from aegis import EvalConfig, Evaluator
from aegis.core.types import EvalCaseV1
from aegis.eval.benchmarks import LegalMemoryBenchmark
from aegis.training.proof_artifacts import build_delta_report, load_eval_artifact


def _expected_to_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(_expected_to_text(item) for item in value)
    if isinstance(value, dict):
        return "\n".join(f"{k}: {_expected_to_text(v)}" for k, v in value.items())
    return str(value)


def _build_training_corpus(cases: list[EvalCaseV1], weak_dimensions: set[str]) -> dict[str, str]:
    corpus: dict[str, str] = {}
    for case in cases:
        if case.dimension_id in weak_dimensions:
            corpus[case.prompt] = _expected_to_text(case.expected)
    return corpus


def _run_sim_demo(cases: list[EvalCaseV1]) -> dict[str, Any]:
    evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))

    def baseline_agent(_: str) -> str:
        return "Unable to provide a reliable answer at this time."

    baseline = evaluator.run_with_cases(cases=cases, agent=baseline_agent)

    weakest = sorted(baseline.dimension_scores.items(), key=lambda item: item[1])[:5]
    weakest_dimensions = {dim for dim, _ in weakest}
    training_corpus = _build_training_corpus(cases, weakest_dimensions)

    def improved_agent(prompt: str) -> str:
        return training_corpus.get(
            prompt,
            "Escalate to reviewer: additional context required for high-confidence answer.",
        )

    improved = evaluator.run_with_cases(cases=cases, agent=improved_agent)
    comparison = evaluator.compare(baseline, improved)

    top_gains = sorted(
        comparison["dimension_deltas"].items(),
        key=lambda item: item[1],
        reverse=True,
    )[:10]

    return {
        "backend": "sim",
        "baseline_run_id": baseline.run_id,
        "improved_run_id": improved.run_id,
        "cases_evaluated": len(cases),
        "weak_dimensions_selected": [dim for dim, _ in weakest],
        "training_examples": len(training_corpus),
        "baseline_overall_score": round(baseline.overall_score, 4),
        "improved_overall_score": round(improved.overall_score, 4),
        "overall_delta": round(comparison["overall_delta"], 4),
        "top_dimension_gains": [{"dimension": d, "delta": round(v, 4)} for d, v in top_gains],
        "comparison": comparison,
    }


def _run_real_demo(*, baseline_path: Path, trained_path: Path) -> dict[str, Any]:
    baseline = load_eval_artifact(baseline_path)
    trained = load_eval_artifact(trained_path)
    comparison = build_delta_report(baseline, trained)

    return {
        "backend": "real",
        "baseline_run_id": baseline.run_id,
        "improved_run_id": trained.run_id,
        "cases_evaluated": 0,
        "weak_dimensions_selected": [],
        "training_examples": 0,
        "baseline_overall_score": round(baseline.overall_score, 4),
        "improved_overall_score": round(trained.overall_score, 4),
        "overall_delta": round(comparison["overall_delta"], 4),
        "top_dimension_gains": comparison["top_dimension_gains"],
        "comparison": comparison,
        "source_artifacts": {
            "baseline": str(baseline_path),
            "trained": str(trained_path),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("tmp-download/closed_loop_demo.json"),
        help="Where to write the demo report JSON.",
    )
    parser.add_argument(
        "--backend",
        choices=("sim", "real"),
        default="sim",
        help="Execution backend: deterministic simulation (`sim`) or real artifact comparison (`real`).",
    )
    parser.add_argument(
        "--cases",
        type=int,
        default=50,
        help="Number of legal benchmark cases to include (max 50).",
    )
    parser.add_argument(
        "--real-baseline",
        type=Path,
        default=Path("results/proof/baseline_eval.json"),
        help="Path to baseline proof artifact JSON (used when --backend real).",
    )
    parser.add_argument(
        "--real-trained",
        type=Path,
        default=Path("results/proof/trained_eval.json"),
        help="Path to trained proof artifact JSON (used when --backend real).",
    )
    args = parser.parse_args()

    if args.backend == "real":
        if not args.real_baseline.exists():
            parser.error(f"Baseline artifact not found: {args.real_baseline}")
        if not args.real_trained.exists():
            parser.error(f"Trained artifact not found: {args.real_trained}")
        report = _run_real_demo(
            baseline_path=args.real_baseline,
            trained_path=args.real_trained,
        )
    else:
        cases = LegalMemoryBenchmark().build_suite().cases[: max(1, min(args.cases, 50))]
        report = _run_sim_demo(cases)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("Closed-loop demo complete")
    print(f"Backend:        {report['backend']}")
    print(f"Baseline score: {report['baseline_overall_score']:.4f}")
    print(f"Improved score: {report['improved_overall_score']:.4f}")
    print(f"Overall delta:   {report['overall_delta']:.4f}")
    print(f"Report written:  {args.output}")


if __name__ == "__main__":
    main()
