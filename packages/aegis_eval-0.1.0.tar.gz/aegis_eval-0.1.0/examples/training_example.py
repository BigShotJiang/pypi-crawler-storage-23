#!/usr/bin/env python3
"""Aegis Training Example -- configure and run RL training.

Demonstrates VerlTrainer setup, config generation, simulated training,
metrics inspection, and checkpoint management.

Usage::
    python examples/training_example.py
"""

import yaml

from aegis.training.curriculum import CurriculumEngine
from aegis.training.rewards import RewardEngine
from aegis.training.verl_bridge import VerlTrainer, VerlTrainingConfig


def main() -> None:
    print("=" * 60)
    print("  Aegis Training Example")
    print("=" * 60)

    # ------------------------------------------------------------------
    # 1. Create a VerlTrainingConfig for the legal domain
    # ------------------------------------------------------------------
    print("\n--- Step 1: Create Training Config ---")
    config = VerlTrainingConfig(
        model_name="Qwen/Qwen2.5-7B",
        output_dir="./checkpoints/legal-lora",
        num_episodes=100,
        rollouts_per_prompt=8,
        max_seq_length=4096,
        learning_rate=1e-5,
        kl_coeff=0.05,
        use_lora=True,
        lora_rank=16,
        lora_alpha=32,
        precision="bf16",
        gradient_accumulation_steps=4,
        reward_stages=5,
        domain="legal",
        gpu_ids=[0],
    )
    print(f"  Model:            {config.model_name}")
    print(f"  Domain:           {config.domain}")
    print(f"  Episodes:         {config.num_episodes}")
    print(f"  LoRA enabled:     {config.use_lora} (rank={config.lora_rank})")
    print(f"  Precision:        {config.precision}")
    print(f"  Reward stages:    {config.reward_stages}")

    # ------------------------------------------------------------------
    # 2. Create a VerlTrainer and check device info
    # ------------------------------------------------------------------
    print("\n--- Step 2: Initialize Trainer ---")
    trainer = VerlTrainer(config)
    print(f"  Real GPU training: {trainer.is_real_training}")
    device_info = trainer.device_info
    print(f"  Backend:           {device_info['backend']}")
    print(f"  CUDA available:    {device_info['cuda_available']}")

    # ------------------------------------------------------------------
    # 3. Run a simulated training pass
    # ------------------------------------------------------------------
    print("\n--- Step 3: Run Training (simulated) ---")
    # When torch/verl are not installed, training falls back to
    # the simulated AMIRGRPOTrainer automatically.
    prompts = [
        "Analyze the enforceability of the non-compete clause in this employment agreement.",
        "Identify potential liability exposure under Section 402A for the manufacturer.",
        "Draft a summary of the contractual obligations under the services agreement.",
    ]
    result = trainer.train(prompts)
    print(f"  Status:        {result['status']}")
    print(f"  Backend:       {result.get('backend', 'real')}")
    print(f"  Mean reward:   {result['mean_reward']:.4f}")
    print(f"  Best reward:   {result['best_reward']:.4f}")
    print(f"  Final loss:    {result['final_loss']:.4f}")
    print(f"  KL divergence: {result['kl_divergence']:.4f}")
    print(f"  Total steps:   {result['total_steps']}")

    # ------------------------------------------------------------------
    # 4. Inspect per-stage training metrics
    # ------------------------------------------------------------------
    print("\n--- Step 4: Per-Stage Metrics ---")
    for sm in result["stage_metrics"]:
        print(
            f"  Stage {sm['stage']}: "
            f"reward={sm['reward']:.4f}  "
            f"loss={sm['loss']:.4f}  "
            f"steps={sm['steps']}"
        )

    # ------------------------------------------------------------------
    # 5. Generate verl-compatible YAML config
    # ------------------------------------------------------------------
    print("\n--- Step 5: Generated verl YAML Config ---")
    verl_config = trainer.generate_verl_config()
    yaml_str = yaml.dump(verl_config, default_flow_style=False, sort_keys=False)
    print(yaml_str)

    # ------------------------------------------------------------------
    # 6. Curriculum manager setup
    # ------------------------------------------------------------------
    print("--- Step 6: Curriculum Engine ---")
    curriculum = CurriculumEngine()

    # Register an agent and show initial level
    progress = curriculum.register_agent("legal-agent-v1", start_level=1)
    level = curriculum.current_level("legal-agent-v1")
    print(f"  Agent:         {progress.agent_id}")
    print(f"  Current level: {level.level} ({level.name})")
    print(f"  Operations:    {level.operations_unlocked}")
    print(f"  Difficulty:    {level.difficulty_range}")

    # Simulate scoring to show advancement
    print("\n  Simulating training scores...")
    for i in range(6):
        score = 0.5 + i * 0.05
        result_cur = curriculum.record_score("legal-agent-v1", score)
        print(
            f"    Score {score:.2f} -> "
            f"Level {result_cur['current_level']} ({result_cur['level_name']}), "
            f"mean={result_cur['recent_mean']:.2f}, "
            f"advanced={result_cur['advanced']}"
        )

    # Show all curriculum levels
    print("\n  All curriculum levels:")
    for level_info in curriculum.all_levels():
        print(
            f"    Level {level_info['level']}: {level_info['name']} "
            f"(min_score={level_info['min_score']}, "
            f"ops={len(level_info['operations'])})"
        )

    # ------------------------------------------------------------------
    # 7. Reward engine configuration
    # ------------------------------------------------------------------
    print("\n--- Step 7: Reward Engine ---")

    # Create a legal domain reward engine
    reward_engine = RewardEngine.for_domain("legal", weighting_profile="dynamic")
    print("  Domain:   legal")
    print(f"  Stages:   {len(reward_engine.stages)}")
    for stage in reward_engine.stages:
        print(
            f"    {stage.stage}: {stage.stage_name} "
            f"(weight={stage.weight}, "
            f"rule={stage.rule_weight}, "
            f"semantic={stage.semantic_weight}, "
            f"judge={stage.judge_weight})"
        )

    # Compute a reward trace
    print("\n  Computing reward trace for a sample rollout...")
    trace = reward_engine.compute_reward(
        rollout_id="example-rollout-001",
        prompt="Analyze the non-compete clause enforceability.",
    )
    print(f"  Total reward: {trace.total_reward:.4f}")
    for sr in trace.stages:
        print(
            f"    {sr.stage_name}: "
            f"rule={sr.rule_score:.3f} "
            f"semantic={sr.semantic_score:.3f} "
            f"judge={sr.judge_score:.3f} "
            f"weighted={sr.weighted_score:.4f}"
        )

    # Show summary after multiple traces
    for i in range(5):
        reward_engine.compute_reward(
            rollout_id=f"batch-rollout-{i:03d}",
            prompt=f"Legal analysis prompt {i}",
        )
    summary = reward_engine.summary()
    print("\n  Reward engine summary:")
    print(f"    Total traces: {summary['total_traces']}")
    print(f"    Mean reward:  {summary['mean_reward']:.4f}")
    print(f"    Min reward:   {summary['min_reward']:.4f}")
    print(f"    Max reward:   {summary['max_reward']:.4f}")

    print("\n" + "=" * 60)
    print("  Training example complete.")
    print("=" * 60)


if __name__ == "__main__":
    main()
