#!/usr/bin/env python3
"""Aegis Memory Example -- all 12 memory operations.

Demonstrates the AegisMemory drop-in replacement covering store, retrieve,
update, forget, search, link, promote, demote, compress, verify, annotate,
and merge operations.

Usage::
    python examples/memory_example.py
"""

from datetime import UTC, datetime

from aegis import AegisMemory
from aegis.core.types import MemoryTier, TemporalBounds


def main() -> None:
    print("=" * 60)
    print("  Aegis Memory Example -- 12 Operations")
    print("=" * 60)

    # Create an AegisMemory instance configured for the legal domain.
    # All data is stored in-memory -- no external services required.
    # We disable vector embeddings for fast startup (uses fuzzy matching
    # fallback instead of loading a sentence-transformer model).
    memory = AegisMemory(
        domain="legal",
        customer_id="sterling-associates",
        agent_id="legal-analyst-v1",
        enable_vectors=False,
    )
    print(f"\n  Memory instance: {memory}")

    # We also get a reference to the underlying MemoryManager for
    # operations (8-12) that are available at the manager level.
    manager = memory._manager

    # ==================================================================
    # Operation 1: STORE
    # ==================================================================
    print("\n--- Operation 1: STORE ---")
    # Store a legal contract fact with full provenance and temporal bounds
    contract_entry = memory.store(
        key="contract:parties",
        value="Sterling & Associates LLP and Meridian Consulting Group Inc.",
        tier=MemoryTier.SESSION,
        confidence=0.95,
        provenance={
            "source_type": "document",
            "source_ref": "services-agreement-2026-01.pdf",
            "page": 1,
            "extraction_method": "structured_parse",
        },
        temporal_bounds=TemporalBounds(
            valid_from=datetime(2026, 2, 1, tzinfo=UTC),
            valid_to=datetime(2026, 7, 31, tzinfo=UTC),
        ),
        tags=["contract", "parties", "legal"],
    )
    print(f"  Stored: key={contract_entry.key}")
    print(f"  Value:  {contract_entry.value}")
    print(f"  Tier:   {contract_entry.tier.value}")
    print(f"  Confidence: {contract_entry.confidence}")
    print(f"  Tags:   {contract_entry.tags}")

    # Store additional entries for a richer demo
    memory.store(
        key="contract:effective_date",
        value="January 15, 2026",
        tier=MemoryTier.SESSION,
        confidence=0.99,
        provenance={"source_type": "document", "source_ref": "services-agreement-2026-01.pdf"},
        tags=["contract", "date"],
    )
    memory.store(
        key="contract:payment_terms",
        value="Monthly retainer of $45,000 USD, payable within 30 days. Performance bonus up to $25,000/quarter.",
        tier=MemoryTier.SESSION,
        confidence=0.97,
        tags=["contract", "payment", "financial"],
    )
    memory.store(
        key="contract:confidentiality",
        value="3-year confidentiality obligation following termination for all proprietary information.",
        tier=MemoryTier.SESSION,
        confidence=0.98,
        tags=["contract", "confidentiality", "obligation"],
    )
    memory.store(
        key="temp:draft_note",
        value="Need to review indemnification clause -- may be missing.",
        tier=MemoryTier.WORKING,
        confidence=0.5,
        tags=["draft", "temporary"],
    )
    print("  (Stored 5 entries total)")

    # ==================================================================
    # Operation 2: RETRIEVE
    # ==================================================================
    print("\n--- Operation 2: RETRIEVE ---")
    parties = memory.retrieve("contract:parties")
    print(f"  Retrieved 'contract:parties': {parties}")

    # Using the dict-like get() with default
    missing = memory.get("nonexistent:key", default="<not found>")
    print(f"  Get with default: {missing}")

    # Check containment
    print(f"  'contract:parties' in memory: {'contract:parties' in memory}")

    # ==================================================================
    # Operation 3: UPDATE
    # ==================================================================
    print("\n--- Operation 3: UPDATE ---")
    updated = memory.update(
        "contract:payment_terms",
        "Monthly retainer of $45,000 USD, payable within 30 days. "
        "Performance bonus up to $25,000/quarter. Late payments accrue 1.5% monthly interest.",
    )
    print(f"  Updated 'contract:payment_terms': {updated}")
    print(f"  New value: {memory.retrieve('contract:payment_terms')}")

    # ==================================================================
    # Operation 4: FORGET
    # ==================================================================
    print("\n--- Operation 4: FORGET ---")
    forgotten = memory.forget("temp:draft_note")
    print(f"  Forgot 'temp:draft_note': {forgotten}")
    print(f"  Retrieve after forget: {memory.retrieve('temp:draft_note')}")

    # ==================================================================
    # Operation 5: SEARCH
    # ==================================================================
    print("\n--- Operation 5: SEARCH ---")
    # Semantic search across all stored entries
    results = memory.search("payment obligations and financial terms", top_k=5)
    print("  Search results for 'payment obligations and financial terms':")
    for r in results:
        print(
            f"    key={r['key']}, "
            f"tier={r['tier']}, "
            f"confidence={r['confidence']:.2f}, "
            f"value={str(r['value'])[:60]}..."
        )

    # ==================================================================
    # Operation 6: LINK
    # ==================================================================
    print("\n--- Operation 6: LINK ---")
    linked = memory.link(
        "contract:parties",
        "contract:payment_terms",
        relation="has_obligation",
    )
    print(f"  Linked 'contract:parties' -> 'contract:payment_terms' (has_obligation): {linked}")

    linked2 = memory.link(
        "contract:parties",
        "contract:confidentiality",
        relation="subject_to",
    )
    print(f"  Linked 'contract:parties' -> 'contract:confidentiality' (subject_to): {linked2}")

    # ==================================================================
    # Operation 7: PROMOTE
    # ==================================================================
    print("\n--- Operation 7: PROMOTE ---")
    # Promote the contract parties entry to permanent tier
    promoted = memory.promote("contract:parties", target_tier=MemoryTier.PERMANENT)
    print(f"  Promoted 'contract:parties' to PERMANENT: {promoted}")

    # Verify the promotion via the manager
    entry = manager.retrieve("contract:parties")
    if entry:
        print(f"  Verified tier: {entry.tier.value}")

    # ==================================================================
    # Operation 8: DEMOTE (via MemoryManager)
    # ==================================================================
    print("\n--- Operation 8: DEMOTE (via MemoryManager) ---")
    # AegisMemory does not expose demote() directly, so we use the
    # underlying MemoryManager which has all 12 operations.
    demoted = manager.demote(
        "contract:effective_date",
        target_tier=MemoryTier.WORKING,
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    print(f"  Demoted 'contract:effective_date' to WORKING: {demoted}")
    entry = manager.retrieve("contract:effective_date")
    if entry:
        print(f"  Verified tier: {entry.tier.value}")

    # ==================================================================
    # Operation 9: COMPRESS (via MemoryManager)
    # ==================================================================
    print("\n--- Operation 9: COMPRESS (via MemoryManager) ---")
    # Compress condenses the text content of a memory entry
    compressed = manager.compress(
        "contract:payment_terms",
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    print(f"  Compressed 'contract:payment_terms': {compressed}")
    entry = manager.retrieve("contract:payment_terms")
    if entry:
        print(f"  Value after compress: {entry.value[:80]}...")

    # ==================================================================
    # Operation 10: VERIFY (via MemoryManager)
    # ==================================================================
    print("\n--- Operation 10: VERIFY (via MemoryManager) ---")
    # Verify checks integrity and currency of a memory entry
    verified = manager.verify(
        "contract:parties",
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    print(f"  Verified 'contract:parties': {verified}")

    # ==================================================================
    # Operation 11: ANNOTATE (via MemoryManager)
    # ==================================================================
    print("\n--- Operation 11: ANNOTATE (via MemoryManager) ---")
    annotated = manager.annotate(
        "contract:confidentiality",
        annotation={
            "reviewer": "senior-counsel",
            "review_date": "2026-02-20",
            "risk_level": "low",
            "notes": "Standard 3-year NDA clause. No unusual provisions.",
        },
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    print(f"  Annotated 'contract:confidentiality': {annotated}")

    # ==================================================================
    # Operation 12: MERGE (via MemoryManager)
    # ==================================================================
    print("\n--- Operation 12: MERGE (via MemoryManager) ---")
    # First, store two related entries to merge
    manager.store(
        key="clause:termination_a",
        value="Either party may terminate with 30 days written notice.",
        tier=MemoryTier.SESSION,
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    manager.store(
        key="clause:termination_b",
        value="Immediate termination for material breach after 10-day cure period.",
        tier=MemoryTier.SESSION,
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    merged = manager.merge(
        "clause:termination_a",
        "clause:termination_b",
        agent_id="legal-analyst-v1",
        customer_id="sterling-associates",
    )
    if merged:
        print(f"  Merged key:   {merged.key}")
        print(f"  Merged value: {merged.value}")
        print(f"  Merged tier:  {merged.tier.value}")
    else:
        print("  Merge returned None (entries may not exist)")

    # ==================================================================
    # Bonus: Health dashboard and audit trail
    # ==================================================================
    print("\n--- Bonus: Health Dashboard ---")
    health = memory.health()
    print(f"  Total entries:   {health['total_entries']}")
    print(f"  Tier counts:     {health['tier_counts']}")
    print(f"  Event log size:  {health['event_log_size']}")
    print(f"  Integrity OK:    {health['integrity_ok']}")

    print("\n--- Bonus: Audit Trail (last 5 events) ---")
    trail = memory.audit_trail()
    for event in trail[-5:]:
        print(
            f"  [{event['timestamp'][:19]}] "
            f"{event['operation']:>10s}  "
            f"key={event['key']}"
        )

    print("\n" + "=" * 60)
    print("  Memory example complete -- all 12 operations demonstrated.")
    print("=" * 60)


if __name__ == "__main__":
    main()
