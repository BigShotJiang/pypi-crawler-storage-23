#!/usr/bin/env python3
"""Custom evaluation — select specific dimensions and write a JSON report.

Usage::

    python examples/custom_eval.py
"""

from pathlib import Path

from aegis import EvalConfig, Evaluator

# Evaluate only a handful of memory-related dimensions with a fixed seed
config = EvalConfig(
    dimensions=[
        "retention_accuracy",
        "temporal_reasoning",
        "contradiction_detection",
        "update_correctness",
    ],
    seed=42,
    difficulty="medium",
)

evaluator = Evaluator(config=config)
result = evaluator.run()

print(f"Overall score: {result.overall_score:.2%}")
for dim_id, score in result.dimension_scores.items():
    print(f"  {dim_id}: {score:.4f}")

# Write JSON report
output = Path("custom_eval_report.json")
output.write_text(result.model_dump_json(indent=2), encoding="utf-8")
print(f"\nReport written to {output}")
