# Aegis Agent Guide

This file defines conventions for AI coding agents operating in this repository.

## Scope

- Treat `src/aegis/` as the source of truth.
- Keep generated artifacts out of git (`site/`, caches, local build outputs).
- Prefer additive, backward-compatible changes unless a breaking change is explicitly requested.

## Engineering Standards

- Python 3.11+ with strict typing.
- Use `ruff format` and `ruff check`.
- Keep `mypy --strict` clean for `src/aegis/`.
- Add or update tests for behavior changes.

## Configuration

- Route runtime configuration through `src/aegis/core/settings.py`.
- Use `.env` for local development and keep `.env.example` in sync.
- Do not hardcode secrets or cloud credentials.

## Design Principles

- Keep module boundaries clear:
  - `eval/` for scoring and evaluation orchestration
  - `training/` for optimization and rollout loops
  - `memory/` for memory operations and persistence
  - `api/` for FastAPI routes and middleware
- Prefer interfaces/protocols over framework-specific coupling.

## Safety

- Never commit real API keys, tokens, or private data.
- Preserve auditability for memory and training flows.
- For security-sensitive behavior (auth, RBAC, rate limiting), include tests with explicit failure modes.
