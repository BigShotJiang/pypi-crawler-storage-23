"""EC2 GPU instance launcher for Aegis training.

Provides helper functions to launch, configure, and manage EC2 GPU
instances for running Aegis RL training jobs outside of SageMaker.

Supported instance types:
- **g5.xlarge** -- 1x NVIDIA A10G (24 GB), cost-effective for dev/test
- **p4d.24xlarge** -- 8x NVIDIA A100 (40 GB each), production training

All boto3 imports are guarded behind ``try/except`` so that the module
can be imported in environments without AWS dependencies.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy AWS imports
# ---------------------------------------------------------------------------

try:
    import boto3  # type: ignore[import-not-found]

    _HAS_BOTO3 = True
except ImportError:
    boto3 = None  # type: ignore[assignment]
    _HAS_BOTO3 = False


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_REGION = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

# Deep Learning AMI (Ubuntu 22.04) -- update to the latest for your region
DEFAULT_AMI_ID = os.environ.get(
    "AEGIS_EC2_AMI",
    "",  # set AEGIS_EC2_AMI to your region-appropriate Deep Learning AMI
)

# GPU instance presets
INSTANCE_PRESETS: dict[str, dict[str, Any]] = {
    "g5.xlarge": {
        "gpu": "1x NVIDIA A10G (24 GB)",
        "vcpus": 4,
        "memory_gb": 16,
        "use_case": "Development, fine-tuning small models",
    },
    "p4d.24xlarge": {
        "gpu": "8x NVIDIA A100 (40 GB)",
        "vcpus": 96,
        "memory_gb": 1152,
        "use_case": "Production training, large-scale RL",
    },
    "g5.2xlarge": {
        "gpu": "1x NVIDIA A10G (24 GB)",
        "vcpus": 8,
        "memory_gb": 32,
        "use_case": "Fine-tuning with larger batch sizes",
    },
    "g5.12xlarge": {
        "gpu": "4x NVIDIA A10G (24 GB each)",
        "vcpus": 48,
        "memory_gb": 192,
        "use_case": "Multi-GPU training, medium models",
    },
}

# User-data script template to bootstrap a training instance
_SETUP_SCRIPT_TEMPLATE = """#!/bin/bash
set -euo pipefail

# Log all output for debugging
exec > /var/log/aegis-setup.log 2>&1

echo "=== Aegis EC2 Setup ==="
echo "Instance ID: $(curl -s http://169.254.169.254/latest/meta-data/instance-id)"
echo "Instance Type: $(curl -s http://169.254.169.254/latest/meta-data/instance-type)"

# Update system
apt-get update -y
apt-get install -y git python3-pip python3-venv

# Create workspace
mkdir -p /opt/aegis
cd /opt/aegis

# Clone repository
git clone https://github.com/metronis-space/aegis.git repo
cd repo

# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install Aegis with GPU dependencies
pip install --upgrade pip
pip install -e '.[gpu]'

# Install additional training dependencies
pip install wandb boto3

echo "=== Aegis EC2 Setup Complete ==="
echo "Activate with: source /opt/aegis/repo/.venv/bin/activate"
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def launch_instance(
    instance_type: str = "g5.xlarge",
    ami_id: str = DEFAULT_AMI_ID,
    key_name: str = "",
    *,
    region: str = DEFAULT_REGION,
    security_group_ids: list[str] | None = None,
    subnet_id: str = "",
    iam_instance_profile: str = "",
    volume_size_gb: int = 200,
    tags: dict[str, str] | None = None,
    user_data: str = "",
) -> dict[str, Any]:
    """Launch an EC2 GPU instance for training.

    Args:
        instance_type: EC2 instance type (see :data:`INSTANCE_PRESETS`).
        ami_id: AMI ID to launch (should be a Deep Learning AMI).
        key_name: EC2 key-pair name for SSH access.
        region: AWS region.
        security_group_ids: Security group IDs to attach.
        subnet_id: VPC subnet ID.
        iam_instance_profile: IAM instance profile name or ARN.
        volume_size_gb: Root EBS volume size in GB.
        tags: Additional EC2 tags (``Name`` is set automatically).
        user_data: Custom user-data script.  If empty, uses the
            default Aegis bootstrap script.

    Returns:
        Dictionary with ``instance_id``, ``status``, and launch metadata.

    Raises:
        RuntimeError: If boto3 is not installed.
        ValueError: If key_name is not provided.
    """
    if not _HAS_BOTO3:
        raise RuntimeError(
            "boto3 required for EC2 operations. Install with: pip install boto3"
        )

    if not key_name:
        raise ValueError(
            "key_name is required to launch an EC2 instance (for SSH access)"
        )

    ec2 = boto3.resource("ec2", region_name=region)

    instance_tags = {"Name": f"aegis-training-{instance_type}"}
    if tags:
        instance_tags.update(tags)

    tag_specs = [
        {
            "ResourceType": "instance",
            "Tags": [{"Key": k, "Value": v} for k, v in instance_tags.items()],
        }
    ]

    run_kwargs: dict[str, Any] = {
        "ImageId": ami_id,
        "InstanceType": instance_type,
        "KeyName": key_name,
        "MinCount": 1,
        "MaxCount": 1,
        "TagSpecifications": tag_specs,
        "BlockDeviceMappings": [
            {
                "DeviceName": "/dev/sda1",
                "Ebs": {
                    "VolumeSize": volume_size_gb,
                    "VolumeType": "gp3",
                    "DeleteOnTermination": True,
                },
            }
        ],
        "UserData": user_data or _SETUP_SCRIPT_TEMPLATE,
    }

    if security_group_ids:
        run_kwargs["SecurityGroupIds"] = security_group_ids
    if subnet_id:
        run_kwargs["SubnetId"] = subnet_id
    if iam_instance_profile:
        if iam_instance_profile.startswith("arn:"):
            run_kwargs["IamInstanceProfile"] = {"Arn": iam_instance_profile}
        else:
            run_kwargs["IamInstanceProfile"] = {"Name": iam_instance_profile}

    instances = ec2.create_instances(**run_kwargs)
    instance = instances[0]

    logger.info(
        "Launched EC2 instance: %s (type=%s, ami=%s)",
        instance.id,
        instance_type,
        ami_id,
    )

    preset = INSTANCE_PRESETS.get(instance_type, {})

    return {
        "instance_id": instance.id,
        "instance_type": instance_type,
        "ami_id": ami_id,
        "status": "pending",
        "region": region,
        "gpu_info": preset.get("gpu", "unknown"),
        "use_case": preset.get("use_case", ""),
    }


def setup_instance(
    instance_id: str,
    *,
    region: str = DEFAULT_REGION,
    wait_for_running: bool = True,
    wait_timeout_seconds: int = 300,
) -> dict[str, Any]:
    """Wait for an instance to be running and return connection info.

    The actual software setup is performed by the user-data script at
    launch time.  This function waits for the instance to reach the
    ``running`` state and retrieves its public IP / DNS.

    Args:
        instance_id: EC2 instance ID.
        region: AWS region.
        wait_for_running: Whether to block until the instance is running.
        wait_timeout_seconds: Max seconds to wait for the running state.

    Returns:
        Dictionary with connection info (IP, DNS, status).

    Raises:
        RuntimeError: If boto3 is not installed.
        TimeoutError: If the instance does not reach ``running`` in time.
    """
    if not _HAS_BOTO3:
        raise RuntimeError(
            "boto3 required for EC2 operations. Install with: pip install boto3"
        )

    ec2 = boto3.resource("ec2", region_name=region)
    instance = ec2.Instance(instance_id)

    if wait_for_running:
        logger.info("Waiting for instance %s to reach 'running' state...", instance_id)
        deadline = time.time() + wait_timeout_seconds
        while time.time() < deadline:
            instance.reload()
            if instance.state["Name"] == "running":
                break
            time.sleep(10)
        else:
            raise TimeoutError(
                f"Instance {instance_id} did not reach 'running' within "
                f"{wait_timeout_seconds}s (current state: {instance.state['Name']})"
            )

    instance.reload()

    return {
        "instance_id": instance_id,
        "status": instance.state["Name"],
        "public_ip": instance.public_ip_address or "",
        "public_dns": instance.public_dns_name or "",
        "private_ip": instance.private_ip_address or "",
        "instance_type": instance.instance_type,
        "launch_time": str(instance.launch_time),
        "ssh_command": (
            f"ssh -i <key>.pem ubuntu@{instance.public_ip_address}"
            if instance.public_ip_address
            else ""
        ),
        "setup_log": "sudo cat /var/log/aegis-setup.log",
    }


def terminate_instance(
    instance_id: str,
    *,
    region: str = DEFAULT_REGION,
) -> dict[str, Any]:
    """Terminate an EC2 instance.

    Args:
        instance_id: EC2 instance ID to terminate.
        region: AWS region.

    Returns:
        Termination result dictionary.

    Raises:
        RuntimeError: If boto3 is not installed.
    """
    if not _HAS_BOTO3:
        raise RuntimeError(
            "boto3 required for EC2 operations. Install with: pip install boto3"
        )

    ec2 = boto3.resource("ec2", region_name=region)
    instance = ec2.Instance(instance_id)
    response = instance.terminate()

    logger.info("Terminated EC2 instance: %s", instance_id)

    return {
        "instance_id": instance_id,
        "status": "shutting-down",
        "previous_state": response.get("TerminatingInstances", [{}])[0].get(
            "PreviousState", {}
        ).get("Name", "unknown")
        if isinstance(response, dict)
        else "unknown",
    }


def list_gpu_presets() -> dict[str, dict[str, Any]]:
    """Return the available GPU instance presets.

    Returns:
        Dictionary mapping instance type to hardware / use-case info.
    """
    return dict(INSTANCE_PRESETS)
