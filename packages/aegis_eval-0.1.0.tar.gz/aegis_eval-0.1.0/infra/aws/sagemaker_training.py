"""Helper functions for AWS SageMaker training job configuration.

Provides convenience wrappers around boto3 for creating, monitoring,
and managing SageMaker training jobs used by the Aegis training pipeline.

All boto3 / sagemaker imports are guarded behind ``try/except`` so that
the module can be imported in environments without AWS dependencies.
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy AWS imports
# ---------------------------------------------------------------------------

try:
    import boto3  # type: ignore[import-not-found]

    _HAS_BOTO3 = True
except ImportError:
    boto3 = None  # type: ignore[assignment]
    _HAS_BOTO3 = False

try:
    import sagemaker  # type: ignore[import-not-found]
    from sagemaker.pytorch import PyTorch as SageMakerPyTorch  # type: ignore[import-not-found]

    _HAS_SAGEMAKER = True
except ImportError:
    sagemaker = None  # type: ignore[assignment]
    SageMakerPyTorch = None  # type: ignore[assignment]
    _HAS_SAGEMAKER = False


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_REGION = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
DEFAULT_S3_BUCKET = "aegis-training-checkpoints"
DEFAULT_INSTANCE_TYPE = "ml.g5.xlarge"
DEFAULT_ROLE_ARN = os.environ.get("SAGEMAKER_ROLE_ARN", "")


# ---------------------------------------------------------------------------
# SageMaker training helpers
# ---------------------------------------------------------------------------


def create_training_job(
    model_name: str,
    dataset_path: str,
    output_path: str,
    instance_type: str = DEFAULT_INSTANCE_TYPE,
    spot: bool = True,
    *,
    role_arn: str = DEFAULT_ROLE_ARN,
    region: str = DEFAULT_REGION,
    s3_bucket: str = DEFAULT_S3_BUCKET,
    entry_point: str = "train.py",
    source_dir: str = "./src",
    framework_version: str = "2.2",
    py_version: str = "py310",
    volume_size_gb: int = 100,
    max_run_seconds: int = 86400,
    max_wait_seconds: int = 7200,
    base_job_name: str = "aegis-train",
    hyperparameters: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Create and launch a SageMaker PyTorch training job.

    Args:
        model_name: HuggingFace model identifier (e.g. ``"Qwen/Qwen2.5-7B"``).
        dataset_path: S3 URI to the training dataset.
        output_path: S3 URI for training output / model artefacts.
        instance_type: SageMaker instance type (default ``ml.g5.xlarge``).
        spot: Whether to use managed spot training for cost savings.
        role_arn: IAM role ARN with SageMaker execution permissions.
        region: AWS region.
        s3_bucket: S3 bucket for checkpoints.
        entry_point: Training script filename.
        source_dir: Directory containing the training script.
        framework_version: PyTorch framework version.
        py_version: Python version identifier.
        volume_size_gb: EBS volume size in GB.
        max_run_seconds: Max training runtime in seconds.
        max_wait_seconds: Max wait for spot capacity in seconds.
        base_job_name: Prefix for the SageMaker job name.
        hyperparameters: Extra hyperparameters to pass to the training script.

    Returns:
        Dictionary with ``job_name``, ``status``, and job metadata.

    Raises:
        RuntimeError: If boto3 or sagemaker is not installed.
    """
    if not _HAS_BOTO3 or not _HAS_SAGEMAKER:
        missing = []
        if not _HAS_BOTO3:
            missing.append("boto3")
        if not _HAS_SAGEMAKER:
            missing.append("sagemaker")
        raise RuntimeError(
            f"AWS dependencies required: {', '.join(missing)}. "
            "Install with: pip install boto3 sagemaker"
        )

    if not role_arn:
        raise ValueError(
            "SageMaker role ARN is required. Set SAGEMAKER_ROLE_ARN env var "
            "or pass role_arn explicitly."
        )

    hp: dict[str, str] = {
        "model-name": model_name,
        "output-dir": "/opt/ml/model",
    }
    if hyperparameters:
        hp.update(hyperparameters)

    sess = sagemaker.Session(
        boto_session=boto3.Session(region_name=region),
    )

    estimator_kwargs: dict[str, Any] = {
        "entry_point": entry_point,
        "source_dir": source_dir,
        "role": role_arn,
        "instance_type": instance_type,
        "instance_count": 1,
        "framework_version": framework_version,
        "py_version": py_version,
        "hyperparameters": hp,
        "output_path": output_path,
        "checkpoint_s3_uri": f"s3://{s3_bucket}/checkpoints",
        "volume_size": volume_size_gb,
        "max_run": max_run_seconds,
        "sagemaker_session": sess,
        "base_job_name": base_job_name,
    }

    if spot:
        estimator_kwargs["use_spot_instances"] = True
        estimator_kwargs["max_wait"] = max_wait_seconds

    estimator = SageMakerPyTorch(**estimator_kwargs)

    inputs = {"training": dataset_path} if dataset_path else None
    estimator.fit(inputs=inputs, wait=False)

    job_name = estimator.latest_training_job.name
    logger.info(
        "Created SageMaker job: %s (instance=%s, spot=%s)",
        job_name,
        instance_type,
        spot,
    )

    return {
        "job_name": job_name,
        "status": "InProgress",
        "instance_type": instance_type,
        "spot": spot,
        "output_path": output_path,
        "model_name": model_name,
    }


def get_job_status(
    job_name: str,
    *,
    region: str = DEFAULT_REGION,
) -> dict[str, Any]:
    """Get the status of a SageMaker training job.

    Args:
        job_name: SageMaker training job name.
        region: AWS region.

    Returns:
        Dictionary with job status, timing, and failure info.

    Raises:
        RuntimeError: If boto3 is not installed.
    """
    if not _HAS_BOTO3:
        raise RuntimeError(
            "boto3 required for SageMaker status checks. "
            "Install with: pip install boto3"
        )

    client = boto3.client("sagemaker", region_name=region)
    response = client.describe_training_job(TrainingJobName=job_name)

    return {
        "job_name": job_name,
        "status": response.get("TrainingJobStatus", "Unknown"),
        "secondary_status": response.get("SecondaryStatus", ""),
        "creation_time": str(response.get("CreationTime", "")),
        "training_start_time": str(response.get("TrainingStartTime", "")),
        "training_end_time": str(response.get("TrainingEndTime", "")),
        "last_modified": str(response.get("LastModifiedTime", "")),
        "failure_reason": response.get("FailureReason", ""),
        "billable_seconds": response.get("BillableTimeInSeconds", 0),
        "instance_type": (
            response.get("ResourceConfig", {}).get("InstanceType", "")
        ),
        "output_path": (
            response.get("OutputDataConfig", {}).get("S3OutputPath", "")
        ),
    }
