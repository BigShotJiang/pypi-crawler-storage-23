# BYOC Reference Environment

This folder contains a minimal Bring-Your-Own-Compute reference setup for
local staging parity.

## Contents

- `docker-compose.yml`: local staging stack (API + Postgres/pgvector)

## Quick Start

```bash
cd infra/byoc-reference
docker compose up --build
```

The API will be reachable at `http://localhost:8000`.

## Notes

- This environment is intentionally minimal and developer-oriented.
- For production BYOC, pin image digests, add secrets management, and enforce
  network policies and RBAC in your orchestrator.
