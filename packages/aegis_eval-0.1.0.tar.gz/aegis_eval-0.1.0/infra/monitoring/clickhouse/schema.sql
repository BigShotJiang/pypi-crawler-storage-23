-- ClickHouse schema for Aegis training logs and observatory data.
--
-- Uses MergeTree engines with time-based partitioning for efficient
-- storage and querying of high-volume training telemetry.

CREATE DATABASE IF NOT EXISTS aegis;

-- ---------------------------------------------------------------------------
-- training_events: per-step training metrics
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS aegis.training_events
(
    event_id        UUID DEFAULT generateUUIDv4(),
    run_id          String,
    step            UInt64,
    reward          Float64,
    loss            Float64,
    kl_divergence   Float64,
    entropy         Float64,
    grad_norm       Float64,
    learning_rate   Float64,
    batch_size      UInt32,
    epoch           UInt32,
    metadata        String DEFAULT '{}',
    created_at      DateTime64(3) DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (run_id, step, created_at)
TTL toDateTime(created_at) + INTERVAL 365 DAY
SETTINGS index_granularity = 8192;

-- ---------------------------------------------------------------------------
-- memory_operations: individual memory operation logs
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS aegis.memory_operations
(
    event_id        UUID DEFAULT generateUUIDv4(),
    run_id          String,
    step            UInt64,
    agent_id        String,
    operation       LowCardinality(String),
    memory_tier     LowCardinality(String),
    memory_key      String,
    duration_ms     Float64,
    success         UInt8,
    bank_size       UInt32 DEFAULT 0,
    dead_memory_pct Float32 DEFAULT 0.0,
    metadata        String DEFAULT '{}',
    created_at      DateTime64(3) DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (run_id, agent_id, operation, created_at)
TTL toDateTime(created_at) + INTERVAL 365 DAY
SETTINGS index_granularity = 8192;

-- ---------------------------------------------------------------------------
-- reward_signals: decomposed reward traces for training analysis
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS aegis.reward_signals
(
    event_id          UUID DEFAULT generateUUIDv4(),
    run_id            String,
    rollout_id        String,
    step              UInt64,
    stage             UInt32,
    stage_name        LowCardinality(String),
    rule_score        Float64,
    semantic_score    Float64,
    judge_score       Float64,
    weight            Float64,
    weighted_score    Float64,
    total_reward      Float64,
    proxy_reward      Float64 DEFAULT 0.0,
    gold_reward       Float64 DEFAULT 0.0,
    goodhart_delta    Float64 DEFAULT 0.0,
    metadata          String DEFAULT '{}',
    created_at        DateTime64(3) DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (run_id, rollout_id, step, stage, created_at)
TTL toDateTime(created_at) + INTERVAL 365 DAY
SETTINGS index_granularity = 8192;

-- ---------------------------------------------------------------------------
-- observatory_alerts: alerts and anomaly detection events
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS aegis.observatory_alerts
(
    alert_id        UUID DEFAULT generateUUIDv4(),
    run_id          String,
    step            UInt64 DEFAULT 0,
    alert_type      LowCardinality(String),
    severity        LowCardinality(String),
    message         String,
    metric_name     String DEFAULT '',
    metric_value    Float64 DEFAULT 0.0,
    threshold       Float64 DEFAULT 0.0,
    intervention    LowCardinality(String) DEFAULT '',
    resolved        UInt8 DEFAULT 0,
    resolved_at     Nullable(DateTime64(3)),
    metadata        String DEFAULT '{}',
    created_at      DateTime64(3) DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (run_id, alert_type, severity, created_at)
TTL toDateTime(created_at) + INTERVAL 730 DAY
SETTINGS index_granularity = 8192;

-- ---------------------------------------------------------------------------
-- audit_log: immutable audit trail for all system actions
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS aegis.audit_log
(
    log_id          UUID DEFAULT generateUUIDv4(),
    actor_id        String,
    actor_type      LowCardinality(String),
    action          LowCardinality(String),
    resource_type   LowCardinality(String),
    resource_id     String,
    details         String DEFAULT '{}',
    ip_address      String DEFAULT '',
    user_agent      String DEFAULT '',
    created_at      DateTime64(3) DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (actor_id, action, resource_type, created_at)
TTL toDateTime(created_at) + INTERVAL 1095 DAY
SETTINGS index_granularity = 8192;

-- ---------------------------------------------------------------------------
-- Materialized views for common aggregations
-- ---------------------------------------------------------------------------

-- Hourly training metrics summary
CREATE MATERIALIZED VIEW IF NOT EXISTS aegis.training_hourly_mv
ENGINE = SummingMergeTree()
PARTITION BY toYYYYMM(hour)
ORDER BY (run_id, hour)
AS SELECT
    run_id,
    toStartOfHour(created_at) AS hour,
    count()                   AS step_count,
    avg(reward)               AS avg_reward,
    avg(loss)                 AS avg_loss,
    avg(kl_divergence)        AS avg_kl_divergence,
    avg(entropy)              AS avg_entropy,
    max(grad_norm)            AS max_grad_norm
FROM aegis.training_events
GROUP BY run_id, hour;

-- Memory operation counts per hour
CREATE MATERIALIZED VIEW IF NOT EXISTS aegis.memory_ops_hourly_mv
ENGINE = SummingMergeTree()
PARTITION BY toYYYYMM(hour)
ORDER BY (run_id, agent_id, operation, hour)
AS SELECT
    run_id,
    agent_id,
    operation,
    toStartOfHour(created_at) AS hour,
    count()                   AS op_count,
    sum(success)              AS success_count,
    avg(duration_ms)          AS avg_duration_ms
FROM aegis.memory_operations
GROUP BY run_id, agent_id, operation, hour;
