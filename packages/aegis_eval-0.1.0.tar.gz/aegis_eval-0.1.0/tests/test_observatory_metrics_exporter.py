"""Coverage tests for observatory metrics exporter."""

from __future__ import annotations

from aegis.observatory.metrics_exporter import MetricsExporter, _Counter, _Gauge, _Histogram


def test_counter_gauge_histogram_primitives() -> None:
    counter = _Counter("c", "counter")
    counter.inc()
    counter.inc("x", 2.5)
    assert counter.get() == 1.0
    assert counter.get("x") == 2.5

    gauge = _Gauge("g", "gauge")
    gauge.set(3.2)
    gauge.set(4.5, "x")
    assert gauge.get() == 3.2
    assert gauge.get("x") == 4.5

    hist = _Histogram("h", "hist", buckets=(1.0, 2.0))
    hist.observe(0.5)
    hist.observe(1.5)
    hist.observe(3.0)
    assert hist.count() == 3
    assert hist.total() == 5.0
    assert hist.bucket_counts() == [(1.0, 1), (2.0, 2), (float("inf"), 3)]


def test_exporter_records_and_exports_metrics() -> None:
    exporter = MetricsExporter()

    exporter.record_training_step(
        {
            "step": 42,
            "reward": 0.8,
            "loss": 0.2,
            "kl_divergence": 0.1,
            "entropy": 0.7,
            "grad_norm": 1.2,
            "learning_rate": 5e-5,
            "memory_bank_size": 128,
            "dead_memory_pct": 0.03,
            "goodhart_divergence": 0.04,
        }
    )
    exporter.record_memory_operation("STORE", duration_ms=12.0, success=True)
    exporter.record_memory_operation("STORE", duration_ms=15.0, success=False)
    exporter.record_observatory_alert("auto_intervention", "critical")
    exporter.record_observatory_alert("goodhart_warning", "warning")
    exporter.record_eval_score("memory_fidelity", 0.91)

    data = exporter.export_json()
    assert data["training"]["steps_total"] == 1.0
    assert data["training"]["reward"]["42"] == 0.8
    assert data["memory"]["operations_total"]["STORE"] == 2.0
    assert data["memory"]["operation_errors"]["STORE"] == 1.0
    assert data["observatory"]["interventions_total"]["critical"] == 1.0
    assert data["eval"]["scores"]["memory_fidelity"] == 0.91

    prometheus = exporter.export_prometheus()
    assert "# HELP aegis_training_steps_total" in prometheus
    assert "aegis_training_steps_total 1.0" in prometheus
    assert 'aegis_memory_operations_total{label="STORE"} 2.0' in prometheus
    assert "aegis_memory_operation_duration_ms_bucket" in prometheus
    assert 'aegis_eval_score{label="memory_fidelity"} 0.91' in prometheus


def test_exporter_handles_empty_metrics() -> None:
    exporter = MetricsExporter()

    prometheus = exporter.export_prometheus()
    assert "aegis_memory_operation_duration_ms_count 0" in prometheus
    assert 'aegis_memory_operation_duration_ms_bucket{le="+Inf"} 0' in prometheus

    data = exporter.export_json()
    assert data["training"]["steps_total"] == 0.0
    assert data["memory"]["operations_total"] == {}
    assert data["eval"]["runs_total"] == {}
