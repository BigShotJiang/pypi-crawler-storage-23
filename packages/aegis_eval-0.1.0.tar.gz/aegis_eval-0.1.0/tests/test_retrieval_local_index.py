"""Tests for deterministic local retrieval indexing."""

from __future__ import annotations

from aegis.retrieval.context import ContextConstructor, RetrievalPolicy
from aegis.retrieval.local_index import LocalSourceIndex


def test_local_index_returns_multi_source_candidates_deterministically() -> None:
    index = LocalSourceIndex()
    query = "sec 10-k filing deadline for large accelerated filer"

    first = index.query(query=query, source_types=["vector", "kg", "sql"], top_k_per_source=3)
    second = index.query(query=query, source_types=["vector", "kg", "sql"], top_k_per_source=3)

    assert len(first) == 9
    assert [item["source_id"] for item in first] == [item["source_id"] for item in second]
    source_types = {item["source_type"] for item in first}
    assert source_types == {"vector", "kg", "sql"}


def test_local_index_lexical_ranking_prioritizes_relevant_record() -> None:
    index = LocalSourceIndex()
    candidates = index.query(
        query="sec 10-k deadline",
        source_types=["vector"],
        top_k_per_source=3,
    )

    assert candidates[0]["source_id"] == "vector-sec-10k-deadline"


def test_anti_retrieval_filter_remains_active_with_local_index() -> None:
    index = LocalSourceIndex()
    candidates = index.query(
        query="prompt injection detection and security controls",
        source_types=["web"],
        top_k_per_source=5,
    )

    constructor = ContextConstructor(
        RetrievalPolicy(
            source_types=["web"],
            min_relevance_score=0.0,
            context_budget_tokens=2048,
            anti_retrieval_enabled=True,
        )
    )
    trace = constructor.retrieve_and_construct(
        query="prompt injection detection and security controls",
        sources=candidates,
    )

    assert trace.total_retrieved == 5
    assert trace.anti_retrieval_triggered is True
    assert all("<script>" not in block.content.lower() for block in trace.context_blocks)
