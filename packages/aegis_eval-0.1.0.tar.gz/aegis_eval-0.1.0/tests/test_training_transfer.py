"""Coverage tests for transfer learning graph and manager."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from aegis.training.transfer import (
    CrossDomainTransferManager,
    TransferConfig,
    TransferLearningGraph,
    TransferProtocol,
)


@dataclass
class _Exp:
    id: str
    prompt: str
    difficulty: int
    reward: float


class _Replay:
    def __init__(self, exps: list[_Exp]) -> None:
        self._exps = exps

    def maintenance_sample(self, _domain: str, ratio: float) -> list[_Exp]:  # noqa: ARG002
        return list(self._exps)


def test_transfer_protocol_preparation_monitoring_and_summary() -> None:
    replay = _Replay([_Exp("e1", "maint-1", 2, 0.9), _Exp("e2", "maint-2", 3, 0.8)])
    config = TransferConfig(
        source_domain="legal",
        target_domain="finance",
        maintenance_ratio=0.2,
        interference_threshold=0.05,
        separate_adapter_threshold=0.1,
        monitor_interval=50,
    )
    protocol = TransferProtocol(config=config, replay_buffer=replay)
    protocol.graph.add_edge("legal", "finance", transfer_score=0.75, interference_score=0.15)

    plan = protocol.prepare_transfer("legal", "finance")
    assert plan["known_transfer_score"] == 0.75
    assert plan["maintenance_sample_count"] == 2
    assert plan["recommendation"] == "separate_adapter"

    no_scores = protocol.monitor_interference([], baseline_score=0.9)
    assert no_scores["interference_detected"] is False

    moderate = protocol.monitor_interference([0.84], baseline_score=0.9)
    assert moderate["interference_detected"] is True

    severe = protocol.monitor_interference([0.7], baseline_score=0.9)
    assert "Severe interference" in severe["recommendation"]

    improving_1 = protocol.monitor_interference([0.82], baseline_score=0.9)
    protocol.monitor_interference([0.85], baseline_score=0.9)
    improving_3 = protocol.monitor_interference([0.88], baseline_score=0.9)
    assert improving_3["trend"] in {"improving", "stable", "worsening"}
    assert improving_1["baseline_score"] == 0.9

    assert protocol.build_mixed_curriculum("legal", "finance", []) == []
    assert protocol.should_separate_adapter([]) is False
    assert protocol.should_separate_adapter([0.12, 0.13]) is True
    assert protocol.should_separate_adapter([0.06, 0.07, 0.08, 0.09, 0.1]) is True

    summary = protocol.summary()
    assert summary["transfer_runs"] >= 1
    assert summary["has_replay_buffer"] is True


def test_transfer_learning_graph_affinity_risk_strategy_and_overrides() -> None:
    graph = TransferLearningGraph()

    assert graph.get_transfer_affinity("a", "b") == 0.0
    assert graph.get_interference_risk("a", "b") == 0.0

    graph.record_transfer("legal", "finance", transfer_score=0.7, interference_score=0.1)
    graph.record_transfer("legal", "finance", transfer_score=0.75, interference_score=0.2)
    graph.record_transfer("legal", "finance", transfer_score=0.8, interference_score=0.25)
    graph.record_transfer("legal", "finance", transfer_score=1.7, interference_score=-0.5)  # bounds

    affinity = graph.get_transfer_affinity("legal", "finance")
    risk = graph.get_interference_risk("legal", "finance")
    assert 0.0 <= affinity <= 1.0
    assert 0.0 <= risk <= 1.0

    strategy = graph.recommend_strategy("legal", "finance")
    assert strategy in {"joint", "ewc", "separate_adapter"}

    graph.set_strategy_override("legal", "finance", "joint")
    assert graph.recommend_strategy("legal", "finance") == "joint"

    with pytest.raises(ValueError):
        graph.set_strategy_override("legal", "finance", "invalid")

    history = graph.get_history("legal", "finance")
    assert len(history) == 4
    assert ("legal", "finance") in graph.get_all_pairs()

    summary = graph.summary()
    assert summary["total_pairs"] == 1
    assert summary["total_measurements"] == 4


def test_cross_domain_transfer_manager_curriculum_halt_batches_and_summary() -> None:
    mgr = CrossDomainTransferManager(
        TransferConfig(
            source_domain="legal",
            target_domain="finance",
            maintenance_ratio=0.25,
            performance_threshold=0.95,
            interference_threshold=0.05,
            use_separate_adapter=False,
        )
    )

    mgr.set_baseline("legal", 0.9)
    assert mgr.get_baseline("legal") == 0.9
    assert mgr.get_baseline("missing") == 0.0

    source_tasks: list[Any] = [{"id": "s1"}, {"id": "s2"}]
    target_tasks: list[Any] = [{"id": "t1"}, {"id": "t2"}, {"id": "t3"}]

    mixed = mgr.create_maintenance_curriculum(source_tasks, target_tasks)
    assert mixed
    assert any(isinstance(x, dict) and x.get("_is_maintenance") for x in mixed)

    # No source tasks -> returns target as-is.
    only_target = mgr.create_maintenance_curriculum([], target_tasks)
    assert only_target == target_tasks

    assert mgr.check_source_performance({"source_score": 0.88}) is True
    assert mgr.check_source_performance({"legal": 0.7}) is False
    assert mgr.check_source_performance({"other": 0.2}) is True

    # Halt with source-domain config.
    halted = mgr.should_halt({"legal": 0.7}, {"legal": 0.9})
    assert halted is True
    assert mgr.is_halted is True
    mgr.reset_halt()
    assert mgr.is_halted is False

    # Halt path with empty source_domain checks all baselines.
    all_domain_mgr = CrossDomainTransferManager(
        TransferConfig(source_domain="", target_domain="", performance_threshold=0.95)
    )
    assert all_domain_mgr.should_halt({"a": 0.8}, {"a": 0.9}) is True
    assert all_domain_mgr.should_halt({"a": 0.9}, {"a": 0.9}) is True  # already halted

    # Adapter recommendations.
    assert mgr.should_use_separate_adapter([]) is False
    assert mgr.should_use_separate_adapter([0.07, 0.08]) is True
    assert mgr.should_use_separate_adapter([0.03, 0.04, 0.06, 0.07, 0.08]) is True

    assert mgr.get_mixed_batch([], [], 4) == []
    assert mgr.get_mixed_batch([1, 2, 3], [], 2) == [1, 2]
    assert mgr.get_mixed_batch([], [1, 2, 3], 2) == [1, 2]

    batch = mgr.get_mixed_batch(["s1", "s2"], ["t1", "t2", "t3"], 4)
    assert len(batch) == 4

    summary = mgr.summary()
    assert summary["config"]["source_domain"] == "legal"
    assert "interference" in summary
