"""Tests for the recursive reward refinement module."""

from __future__ import annotations

import pytest

from aegis.core.types import RewardTraceV1, StageReward
from aegis.training.reward_refinement import (
    RecursiveRewardRefiner,
    RefinementAnalysis,
    RefinementRecord,
)
from aegis.training.rewards import RewardEngine, RewardStageConfig

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_trace(
    rollout_id: str = "r1",
    stage_scores: list[tuple[str, float]] | None = None,
) -> RewardTraceV1:
    """Build a RewardTraceV1 with given stage scores."""
    if stage_scores is None:
        stage_scores = [
            ("comprehension", 0.15),
            ("retrieval", 0.12),
            ("reasoning", 0.20),
            ("synthesis", 0.10),
            ("quality", 0.08),
        ]
    stages = [
        StageReward(
            stage=i,
            stage_name=name,
            rule_score=score * 2,
            semantic_score=score * 1.5,
            judge_score=score,
            weight=1.0 / len(stage_scores),
            weighted_score=score,
        )
        for i, (name, score) in enumerate(stage_scores)
    ]
    total = sum(s.weighted_score for s in stages)
    return RewardTraceV1(
        rollout_id=rollout_id,
        stages=stages,
        total_reward=round(total, 4),
    )


def _make_many_traces(count: int, variance: float = 0.0) -> list[RewardTraceV1]:
    """Generate multiple traces with optional variance."""
    traces: list[RewardTraceV1] = []
    base_scores = [0.15, 0.12, 0.20, 0.10, 0.08]
    names = ["comprehension", "retrieval", "reasoning", "synthesis", "quality"]
    for i in range(count):
        offset = (i % 5 - 2) * variance
        scores = [(names[j], max(0.01, base_scores[j] + offset * (j + 1) / 5)) for j in range(5)]
        traces.append(_make_trace(rollout_id=f"r{i}", stage_scores=scores))
    return traces


# ---------------------------------------------------------------------------
# RefinementAnalysis tests
# ---------------------------------------------------------------------------


class TestRefinementAnalysis:
    """Tests for the RefinementAnalysis dataclass."""

    def test_defaults(self) -> None:
        analysis = RefinementAnalysis()
        assert analysis.stage_variances == {}
        assert analysis.stage_mean_scores == {}
        assert analysis.suggested_weights == {}
        assert analysis.convergence_score == 1.0


# ---------------------------------------------------------------------------
# RefinementRecord tests
# ---------------------------------------------------------------------------


class TestRefinementRecord:
    """Tests for the RefinementRecord dataclass."""

    def test_creation(self) -> None:
        record = RefinementRecord(
            iteration=1,
            adjustments={"comprehension": 0.01},
            convergence_score=0.05,
        )
        assert record.iteration == 1
        assert record.convergence_score == 0.05
        assert "comprehension" in record.adjustments


# ---------------------------------------------------------------------------
# RecursiveRewardRefiner tests
# ---------------------------------------------------------------------------


class TestRecursiveRewardRefinerInit:
    """Tests for RecursiveRewardRefiner construction."""

    def test_defaults(self) -> None:
        refiner = RecursiveRewardRefiner()
        assert refiner._max_iterations == 5
        assert refiner._convergence_threshold == 0.01
        assert refiner._blend_weight == 0.3
        assert refiner._min_traces == 50

    def test_custom_params(self) -> None:
        refiner = RecursiveRewardRefiner(
            max_iterations=10,
            convergence_threshold=0.005,
            blend_weight=0.5,
            min_traces=20,
        )
        assert refiner._max_iterations == 10
        assert refiner._min_traces == 20


class TestAnalyzeTraces:
    """Tests for RecursiveRewardRefiner.analyze_traces()."""

    def test_single_trace(self) -> None:
        refiner = RecursiveRewardRefiner()
        traces = [_make_trace()]
        analysis = refiner.analyze_traces(traces)
        assert len(analysis.stage_mean_scores) == 5
        assert "comprehension" in analysis.stage_mean_scores
        # With one trace, variance should be 0
        for v in analysis.stage_variances.values():
            assert v == pytest.approx(0.0)

    def test_multiple_traces(self) -> None:
        refiner = RecursiveRewardRefiner()
        traces = _make_many_traces(10, variance=0.02)
        analysis = refiner.analyze_traces(traces)
        assert len(analysis.stage_mean_scores) == 5
        # With variance, at least some stages should have non-zero variance
        assert any(v > 0 for v in analysis.stage_variances.values())

    def test_empty_traces(self) -> None:
        refiner = RecursiveRewardRefiner()
        analysis = refiner.analyze_traces([])
        assert analysis.stage_variances == {}
        assert analysis.stage_mean_scores == {}


class TestComputeAdjustments:
    """Tests for RecursiveRewardRefiner.compute_adjustments()."""

    def test_basic_adjustment(self) -> None:
        refiner = RecursiveRewardRefiner()
        configs = [
            RewardStageConfig(0, "comprehension", weight=0.2),
            RewardStageConfig(1, "retrieval", weight=0.2),
            RewardStageConfig(2, "reasoning", weight=0.25),
            RewardStageConfig(3, "synthesis", weight=0.2),
            RewardStageConfig(4, "quality", weight=0.15),
        ]
        analysis = RefinementAnalysis(
            stage_variances={
                "comprehension": 0.1,
                "retrieval": 0.05,
                "reasoning": 0.02,
                "synthesis": 0.08,
                "quality": 0.03,
            },
            stage_mean_scores={
                "comprehension": 0.3,
                "retrieval": 0.5,
                "reasoning": 0.7,
                "synthesis": 0.2,
                "quality": 0.6,
            },
        )
        new_weights = refiner.compute_adjustments(analysis, configs)

        assert len(new_weights) == 5
        # Weights should sum to approximately 1.0
        assert sum(new_weights.values()) == pytest.approx(1.0, abs=0.01)

    def test_weak_stages_upweighted(self) -> None:
        refiner = RecursiveRewardRefiner(blend_weight=1.0)  # Full new weights
        configs = [
            RewardStageConfig(0, "strong", weight=0.5),
            RewardStageConfig(1, "weak", weight=0.5),
        ]
        analysis = RefinementAnalysis(
            stage_variances={"strong": 0.0, "weak": 0.0},
            stage_mean_scores={"strong": 0.9, "weak": 0.2},
        )
        new_weights = refiner.compute_adjustments(analysis, configs)

        # Weak stage should get a higher weight than strong
        assert new_weights["weak"] > new_weights["strong"]

    def test_empty_configs(self) -> None:
        refiner = RecursiveRewardRefiner()
        analysis = RefinementAnalysis()
        result = refiner.compute_adjustments(analysis, [])
        assert result == {}

    def test_blending(self) -> None:
        refiner = RecursiveRewardRefiner(blend_weight=0.0)  # Keep old weights
        configs = [
            RewardStageConfig(0, "a", weight=0.6),
            RewardStageConfig(1, "b", weight=0.4),
        ]
        analysis = RefinementAnalysis(
            stage_variances={"a": 0.0, "b": 0.0},
            stage_mean_scores={"a": 0.5, "b": 0.5},
        )
        new_weights = refiner.compute_adjustments(analysis, configs)
        # With blend_weight=0, should closely match original weights
        assert new_weights["a"] == pytest.approx(0.6, abs=0.01)
        assert new_weights["b"] == pytest.approx(0.4, abs=0.01)


class TestApplyRefinement:
    """Tests for RecursiveRewardRefiner.apply_refinement()."""

    def test_skips_when_too_few_traces(self) -> None:
        refiner = RecursiveRewardRefiner(min_traces=100)
        engine = RewardEngine.for_domain("general")

        # Engine has no history, refiner has no traces
        result = refiner.apply_refinement(engine)
        assert result is engine
        assert refiner._iteration == 0

    def test_applies_with_enough_traces(self) -> None:
        refiner = RecursiveRewardRefiner(min_traces=5)
        engine = RewardEngine.for_domain("general")

        # Feed traces manually
        traces = _make_many_traces(10, variance=0.05)
        refiner.collect_traces(traces)

        refiner.apply_refinement(engine)

        assert refiner._iteration == 1
        assert len(refiner._history) == 1

    def test_records_history(self) -> None:
        refiner = RecursiveRewardRefiner(min_traces=5)
        engine = RewardEngine.for_domain("general")
        refiner.collect_traces(_make_many_traces(20, variance=0.03))

        refiner.apply_refinement(engine)
        refiner.apply_refinement(engine)

        history = refiner.get_refinement_history()
        assert len(history) == 2
        assert history[0].iteration == 1
        assert history[1].iteration == 2


class TestRefineAfterStage:
    """Tests for RecursiveRewardRefiner.refine_after_stage()."""

    def test_returns_false_when_not_converged(self) -> None:
        refiner = RecursiveRewardRefiner(min_traces=5)
        engine = RewardEngine.for_domain("general")
        refiner.collect_traces(_make_many_traces(10, variance=0.1))

        converged = refiner.refine_after_stage(engine)
        # First iteration usually not converged
        assert isinstance(converged, bool)

    def test_max_iterations_stop(self) -> None:
        refiner = RecursiveRewardRefiner(max_iterations=2, min_traces=5)
        engine = RewardEngine.for_domain("general")
        refiner.collect_traces(_make_many_traces(20, variance=0.05))

        refiner.refine_after_stage(engine)
        refiner.refine_after_stage(engine)
        converged = refiner.refine_after_stage(engine)

        assert converged is True  # Max iterations reached


class TestShouldConverge:
    """Tests for convergence checking."""

    def test_no_history(self) -> None:
        refiner = RecursiveRewardRefiner()
        assert refiner.should_converge() is False

    def test_below_threshold(self) -> None:
        refiner = RecursiveRewardRefiner(convergence_threshold=0.1)
        refiner._history.append(RefinementRecord(iteration=1, convergence_score=0.05))
        assert refiner.should_converge() is True

    def test_above_threshold(self) -> None:
        refiner = RecursiveRewardRefiner(convergence_threshold=0.01)
        refiner._history.append(RefinementRecord(iteration=1, convergence_score=0.05))
        assert refiner.should_converge() is False


class TestSummary:
    """Tests for RecursiveRewardRefiner.summary()."""

    def test_initial_summary(self) -> None:
        refiner = RecursiveRewardRefiner()
        summary = refiner.summary()
        assert summary["iterations"] == 0
        assert summary["converged"] is False
        assert summary["collected_traces"] == 0

    def test_summary_after_refinement(self) -> None:
        refiner = RecursiveRewardRefiner(min_traces=5)
        engine = RewardEngine.for_domain("general")
        refiner.collect_traces(_make_many_traces(10))
        refiner.apply_refinement(engine)

        summary = refiner.summary()
        assert summary["iterations"] == 1
        assert summary["collected_traces"] == 10
        assert len(summary["history"]) == 1


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------


class TestExports:
    """Test exports from training __init__."""

    def test_import_from_training(self) -> None:
        from aegis.training import RecursiveRewardRefiner as RewardRefiner

        assert RewardRefiner is RecursiveRewardRefiner
