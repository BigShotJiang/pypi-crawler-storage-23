"""Comprehensive tests for new API routes and config/YAML loading.

Covers:
- Eval API routes: report, cancel, history, diagnostic, dimension lookup
- Memory API routes: store, retrieve, update, delete, link, audit, snapshot, health
- AegisConfig: defaults, from_yaml, OutputConfig format alias, domain_plugins types

~45 tests total.
"""

from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import aegis.api.routes.eval as eval_module
import aegis.api.routes.memory as memory_module
from aegis.api.app import app
from aegis.core.config import (
    AegisConfig,
    AgentConfig,
    CIConfig,
    LLMJudgeConfig,
    OutputConfig,
    ScenarioConfig,
    ScoringConfig,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

EXAMPLE_YAML = str(Path(__file__).resolve().parent.parent / "examples" / "eval.yaml")


@pytest.fixture(autouse=True)
def _reset_singletons():
    """Reset module-level singletons between tests to ensure isolation."""
    eval_module._eval_runs.clear()
    memory_module._manager = None
    yield
    eval_module._eval_runs.clear()
    memory_module._manager = None


@pytest.fixture()
def client() -> TestClient:
    """Create a synchronous test client for the FastAPI app."""
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture()
def _create_eval_run(client: TestClient) -> str:
    """Create an eval run and return its run_id."""
    resp = client.post(
        "/v1/evals/runs",
        json={
            "agent_config": {"type": "rest", "config": {}},
            "dimensions": "all",
            "num_scenarios": 1,
            "difficulty": 3,
        },
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["run_id"]


# ===================================================================
# EVAL ROUTE TESTS
# ===================================================================


class TestEvalReport:
    """GET /v1/evals/runs/{run_id}/report"""

    def test_report_json_default(self, client: TestClient, _create_eval_run: str):
        """Default format returns JSON content."""
        run_id = _create_eval_run
        resp = client.get(f"/v1/evals/runs/{run_id}/report")
        assert resp.status_code == 200
        assert resp.headers["content-type"] == "application/json"
        data = json.loads(resp.text)
        assert "run_id" in data
        assert "overall_score" in data

    def test_report_html(self, client: TestClient, _create_eval_run: str):
        """format=html returns HTML content."""
        run_id = _create_eval_run
        resp = client.get(f"/v1/evals/runs/{run_id}/report?format=html")
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
        assert "<!DOCTYPE html>" in resp.text
        assert "Aegis Eval Report" in resp.text

    def test_report_nonexistent_run(self, client: TestClient):
        """Nonexistent run returns 404."""
        resp = client.get("/v1/evals/runs/nonexistent/report")
        assert resp.status_code == 404


class TestEvalCancel:
    """POST /v1/evals/runs/{run_id}/cancel"""

    def test_cancel_existing_run(self, client: TestClient, _create_eval_run: str):
        """Cancelling an existing run returns cancelled status."""
        run_id = _create_eval_run
        resp = client.post(f"/v1/evals/runs/{run_id}/cancel")
        assert resp.status_code == 200
        body = resp.json()
        assert body["run_id"] == run_id
        assert body["status"] == "cancelled"
        assert "cancelled_at" in body

    def test_cancel_nonexistent_run(self, client: TestClient):
        """Cancelling a nonexistent run returns 404."""
        resp = client.post("/v1/evals/runs/nonexistent/cancel")
        assert resp.status_code == 404


class TestEvalHistory:
    """GET /v1/evals/history"""

    def test_history_returns_list(self, client: TestClient):
        """History with no runs returns empty list."""
        resp = client.get("/v1/evals/history")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_history_with_runs(self, client: TestClient, _create_eval_run: str):
        """History after creating a run returns that run."""
        resp = client.get("/v1/evals/history")
        assert resp.status_code == 200
        items = resp.json()
        assert len(items) >= 1
        assert items[0]["run_id"] == _create_eval_run

    def test_history_filter_agent_id(self, client: TestClient, _create_eval_run: str):
        """Filtering by a non-matching agent_id returns empty."""
        resp = client.get("/v1/evals/history?agent_id=does-not-exist")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_history_limit(self, client: TestClient):
        """limit=1 returns at most 1 result."""
        # Create two runs
        for _ in range(2):
            client.post(
                "/v1/evals/runs",
                json={
                    "agent_config": {"type": "rest", "config": {}},
                    "dimensions": "all",
                    "num_scenarios": 1,
                    "difficulty": 3,
                },
            )
        resp = client.get("/v1/evals/history?limit=1")
        assert resp.status_code == 200
        assert len(resp.json()) == 1


class TestEvalDiagnostic:
    """POST /v1/evals/diagnostic"""

    def test_diagnostic_valid_run(self, client: TestClient, _create_eval_run: str):
        """Diagnostic for a valid run returns expected keys."""
        run_id = _create_eval_run
        resp = client.post("/v1/evals/diagnostic", json={"run_id": run_id})
        assert resp.status_code == 200
        body = resp.json()
        assert body["run_id"] == run_id
        assert "overall_score" in body
        assert "tier_scores" in body
        assert "weak_dimensions" in body
        assert "strong_dimensions" in body
        assert "recommendations" in body
        assert "metadata" in body

    def test_diagnostic_missing_run(self, client: TestClient):
        """Diagnostic for a nonexistent run returns 404."""
        resp = client.post("/v1/evals/diagnostic", json={"run_id": "nonexistent"})
        assert resp.status_code == 404


class TestEvalDimensionLookup:
    """GET /v1/evals/dimensions/{dimension_id}"""

    def test_get_valid_dimension(self, client: TestClient):
        """Fetching a known dimension returns its info."""
        # First list all dimensions to get a valid ID
        list_resp = client.get("/v1/evals/dimensions")
        assert list_resp.status_code == 200
        dims = list_resp.json()
        assert len(dims) > 0, "Expected at least one registered dimension"

        dim_id = dims[0]["dimension_id"]
        resp = client.get(f"/v1/evals/dimensions/{dim_id}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["dimension_id"] == dim_id
        assert "name" in body
        assert "tier" in body
        assert "description" in body

    def test_get_nonexistent_dimension(self, client: TestClient):
        """Fetching a nonexistent dimension returns 404."""
        resp = client.get("/v1/evals/dimensions/nonexistent")
        assert resp.status_code == 404


# ===================================================================
# MEMORY ROUTE TESTS
# ===================================================================


class TestMemoryStore:
    """POST /v1/memory/store"""

    def test_store_creates_entry(self, client: TestClient):
        """Storing a memory entry returns 201 with expected fields."""
        resp = client.post(
            "/v1/memory/store",
            json={"key": "greeting", "value": "hello world", "tier": "working"},
        )
        assert resp.status_code == 201
        body = resp.json()
        assert body["key"] == "greeting"
        assert body["tier"] == "working"
        assert body["confidence"] == 1.0
        assert body["status"] == "stored"


class TestMemoryRetrieve:
    """POST /v1/memory/retrieve"""

    def test_retrieve_by_key(self, client: TestClient):
        """Retrieve mode=key finds a previously stored entry."""
        client.post(
            "/v1/memory/store",
            json={"key": "fruit", "value": "apple"},
        )
        resp = client.post(
            "/v1/memory/retrieve",
            json={"query": "fruit", "mode": "key"},
        )
        assert resp.status_code == 200
        entries = resp.json()
        assert len(entries) == 1
        assert entries[0]["key"] == "fruit"
        assert entries[0]["value"] == "apple"

    def test_retrieve_unknown_key(self, client: TestClient):
        """Retrieve with an unknown key returns empty list."""
        resp = client.post(
            "/v1/memory/retrieve",
            json={"query": "nonexistent_key_xyz", "mode": "key"},
        )
        assert resp.status_code == 200
        assert resp.json() == []


class TestMemoryUpdate:
    """PUT /v1/memory/{key}"""

    def test_update_existing_entry(self, client: TestClient):
        """Updating an existing entry returns updated=true."""
        client.post(
            "/v1/memory/store",
            json={"key": "color", "value": "blue"},
        )
        resp = client.put("/v1/memory/color", json={"value": "red"})
        assert resp.status_code == 200
        body = resp.json()
        assert body["key"] == "color"
        assert body["updated"] is True

    def test_update_nonexistent_entry(self, client: TestClient):
        """Updating a nonexistent entry returns updated=false."""
        resp = client.put("/v1/memory/no_such_key", json={"value": "anything"})
        assert resp.status_code == 200
        body = resp.json()
        assert body["updated"] is False


class TestMemoryDelete:
    """DELETE /v1/memory/{key}"""

    def test_delete_existing_entry(self, client: TestClient):
        """Deleting an existing entry returns deleted=true."""
        client.post(
            "/v1/memory/store",
            json={"key": "temp", "value": "ephemeral"},
        )
        resp = client.delete("/v1/memory/temp")
        assert resp.status_code == 200
        body = resp.json()
        assert body["key"] == "temp"
        assert body["deleted"] is True

    def test_delete_nonexistent_entry(self, client: TestClient):
        """Deleting a nonexistent entry returns deleted=false."""
        resp = client.delete("/v1/memory/nonexistent")
        assert resp.status_code == 200
        body = resp.json()
        assert body["deleted"] is False


class TestMemoryLink:
    """POST /v1/memory/link"""

    def test_link_two_entries(self, client: TestClient):
        """Linking two stored entries returns linked status."""
        client.post("/v1/memory/store", json={"key": "a", "value": "alpha"})
        client.post("/v1/memory/store", json={"key": "b", "value": "beta"})
        resp = client.post(
            "/v1/memory/link",
            json={"key_a": "a", "key_b": "b", "relation": "related"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["key_a"] == "a"
        assert body["key_b"] == "b"
        assert "linked" in body


class TestMemoryAudit:
    """GET /v1/memory/audit"""

    def test_audit_initially_empty(self, client: TestClient):
        """Audit trail is a list (possibly empty) initially."""
        resp = client.get("/v1/memory/audit")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_audit_after_operations(self, client: TestClient):
        """Audit trail grows after store operations."""
        client.post("/v1/memory/store", json={"key": "x", "value": "1"})
        client.post("/v1/memory/store", json={"key": "y", "value": "2"})
        resp = client.get("/v1/memory/audit")
        assert resp.status_code == 200
        events = resp.json()
        assert len(events) >= 2


class TestMemorySnapshot:
    """GET /v1/memory/snapshot/{timestamp}"""

    def test_snapshot_returns_structure(self, client: TestClient):
        """Snapshot endpoint returns MemorySnapshot structure."""
        ts = datetime.now(tz=UTC).isoformat()
        resp = client.get(f"/v1/memory/snapshot/{ts}")
        assert resp.status_code == 200
        body = resp.json()
        assert "timestamp" in body
        assert "total_entries" in body
        assert "tier_counts" in body
        assert "entries" in body
        assert isinstance(body["entries"], list)

    def test_snapshot_after_store(self, client: TestClient):
        """Snapshot after storing entries contains them."""
        client.post("/v1/memory/store", json={"key": "snap_k", "value": "snap_v"})
        ts = datetime.now(tz=UTC).isoformat()
        resp = client.get(f"/v1/memory/snapshot/{ts}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["total_entries"] >= 1


class TestMemoryHealth:
    """GET /v1/memory/health"""

    def test_health_returns_dict(self, client: TestClient):
        """Health endpoint returns a dict with expected keys."""
        resp = client.get("/v1/memory/health")
        assert resp.status_code == 200
        body = resp.json()
        assert "total_entries" in body
        assert "tier_counts" in body
        assert "event_log_size" in body
        assert "integrity_ok" in body


# ===================================================================
# CONFIG TESTS
# ===================================================================


class TestAegisConfigDefaults:
    """AegisConfig default values."""

    def test_defaults(self):
        """Default AegisConfig has expected values."""
        cfg = AegisConfig()
        assert cfg.dimensions == "all"
        assert cfg.domain_plugins == []
        assert cfg.agent.type == "rest"
        assert cfg.scoring.programmatic is True
        assert cfg.scoring.semantic is True
        assert cfg.output.formats == ["json"]
        assert cfg.output.path == "./results/"
        assert cfg.output.include_traces is True
        assert cfg.output.include_diagnostic is True
        assert cfg.ci.fail_under == 0.75


class TestAegisConfigFromYaml:
    """AegisConfig.from_yaml loading."""

    def test_load_example_yaml(self):
        """Loading examples/eval.yaml produces valid config."""
        cfg = AegisConfig.from_yaml(EXAMPLE_YAML)
        assert cfg.dimensions == "all"
        assert "legal" in cfg.domain_plugins
        assert "finance" in cfg.domain_plugins
        assert cfg.scenarios.count == 10
        assert cfg.scoring.llm_judge is not None
        assert cfg.scoring.llm_judge.model == "gpt-4o"
        assert cfg.output.formats == ["json", "html"]
        assert cfg.ci.fail_under == 0.75

    def test_eval_nested_structure(self):
        """from_yaml handles eval: nested structure and lifts values."""
        content = """\
eval:
  dimensions:
    - retention_accuracy
  scenarios:
    count: 5
ci:
  fail_under: 0.9
"""
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
            f.write(content)
            f.flush()
            cfg = AegisConfig.from_yaml(f.name)

        assert cfg.dimensions == ["retention_accuracy"]
        assert cfg.scenarios.count == 5
        assert cfg.ci.fail_under == 0.9

    def test_flat_structure(self):
        """from_yaml handles flat structure (no eval: key)."""
        content = """\
dimensions:
  - citation_validity
scenarios:
  count: 50
"""
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
            f.write(content)
            f.flush()
            cfg = AegisConfig.from_yaml(f.name)

        assert cfg.dimensions == ["citation_validity"]
        assert cfg.scenarios.count == 50

    def test_empty_file_returns_defaults(self):
        """from_yaml with an empty file returns default config."""
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
            f.write("")
            f.flush()
            cfg = AegisConfig.from_yaml(f.name)

        assert cfg.dimensions == "all"
        assert cfg.domain_plugins == []


class TestOutputConfig:
    """OutputConfig format alias handling."""

    def test_format_singular_alias(self):
        """OutputConfig accepts 'format' (singular) as alias for 'formats'."""
        oc = OutputConfig(format="html")
        assert oc.formats == ["html"]

    def test_format_singular_list(self):
        """OutputConfig accepts 'format' as a list."""
        oc = OutputConfig(format=["json", "html"])
        assert oc.formats == ["json", "html"]

    def test_formats_direct(self):
        """OutputConfig accepts 'formats' directly."""
        oc = OutputConfig(formats=["csv", "json"])
        assert oc.formats == ["csv", "json"]


class TestDomainPluginsTypes:
    """domain_plugins accepts both strings and dicts."""

    def test_list_of_strings(self):
        """domain_plugins accepts a list of strings."""
        cfg = AegisConfig(domain_plugins=["legal", "finance"])
        assert cfg.domain_plugins == ["legal", "finance"]

    def test_list_of_dicts(self):
        """domain_plugins accepts a list of dicts."""
        plugins = [{"name": "legal", "config": {}}, {"name": "finance", "config": {}}]
        cfg = AegisConfig(domain_plugins=plugins)
        assert len(cfg.domain_plugins) == 2
        assert cfg.domain_plugins[0]["name"] == "legal"


class TestCIConfigDefaults:
    """CIConfig defaults."""

    def test_defaults(self):
        ci = CIConfig()
        assert ci.fail_under == 0.75
        assert ci.fail_dimensions == {}


class TestScenarioConfigDefaults:
    """ScenarioConfig defaults."""

    def test_defaults(self):
        sc = ScenarioConfig()
        assert sc.count == 200
        assert sc.difficulty == "adaptive"
        assert sc.fixed_level is None
        assert sc.source == "generated"


class TestLLMJudgeConfigDefaults:
    """LLMJudgeConfig defaults."""

    def test_defaults(self):
        lj = LLMJudgeConfig()
        assert lj.model == "gpt-4o"
        assert lj.rubric == "default"
        assert lj.temperature == 0.0
        assert lj.max_tokens == 2048


# ===================================================================
# ADDITIONAL EDGE-CASE TESTS
# ===================================================================


class TestEvalReportCancelInteraction:
    """Verify cancel updates are reflected in history."""

    def test_cancelled_run_shows_in_history(self, client: TestClient, _create_eval_run: str):
        """After cancellation the history shows cancelled status."""
        run_id = _create_eval_run
        client.post(f"/v1/evals/runs/{run_id}/cancel")
        resp = client.get("/v1/evals/history")
        assert resp.status_code == 200
        items = resp.json()
        matched = [i for i in items if i["run_id"] == run_id]
        assert len(matched) == 1
        assert matched[0]["status"] == "cancelled"


class TestMemoryStoreWithTier:
    """POST /v1/memory/store with explicit tier."""

    def test_store_session_tier(self, client: TestClient):
        """Storing with tier=session is reflected in the response."""
        resp = client.post(
            "/v1/memory/store",
            json={"key": "sess_key", "value": "sess_val", "tier": "session"},
        )
        assert resp.status_code == 201
        assert resp.json()["tier"] == "session"


class TestMemoryDeleteThenRetrieve:
    """Verify delete removes entry from retrieval."""

    def test_retrieve_after_delete_returns_empty(self, client: TestClient):
        """After deleting an entry, retrieve returns nothing."""
        client.post("/v1/memory/store", json={"key": "gone", "value": "bye"})
        client.delete("/v1/memory/gone")
        resp = client.post(
            "/v1/memory/retrieve",
            json={"query": "gone", "mode": "key"},
        )
        assert resp.status_code == 200
        assert resp.json() == []


class TestMemoryUpdateThenRetrieve:
    """Verify update changes the stored value."""

    def test_retrieve_after_update_returns_new_value(self, client: TestClient):
        """After update the retrieved value is the new one."""
        client.post("/v1/memory/store", json={"key": "mut", "value": "old"})
        client.put("/v1/memory/mut", json={"value": "new"})
        resp = client.post(
            "/v1/memory/retrieve",
            json={"query": "mut", "mode": "key"},
        )
        assert resp.status_code == 200
        entries = resp.json()
        assert len(entries) == 1
        assert entries[0]["value"] == "new"


class TestScoringConfigDefaults:
    """ScoringConfig defaults."""

    def test_defaults(self):
        sc = ScoringConfig()
        assert sc.programmatic is True
        assert sc.semantic is True
        assert sc.llm_judge is None


class TestAgentConfigDefaults:
    """AgentConfig defaults."""

    def test_defaults(self):
        ac = AgentConfig()
        assert ac.type == "rest"
        assert ac.config == {}
