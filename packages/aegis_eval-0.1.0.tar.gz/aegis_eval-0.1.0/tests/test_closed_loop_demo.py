"""Tests for closed-loop demo backend selection and artifact wiring."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

import pytest


def _load_demo_module() -> ModuleType:
    script_path = Path(__file__).resolve().parents[1] / "examples" / "closed_loop_demo.py"
    spec = importlib.util.spec_from_file_location("closed_loop_demo_test_module", script_path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _report(backend: str) -> dict[str, Any]:
    return {
        "backend": backend,
        "baseline_run_id": "run-a",
        "improved_run_id": "run-b",
        "cases_evaluated": 1,
        "weak_dimensions_selected": [],
        "training_examples": 1,
        "baseline_overall_score": 0.1,
        "improved_overall_score": 0.8,
        "overall_delta": 0.7,
        "top_dimension_gains": [],
        "comparison": {"overall_delta": 0.7},
    }


def test_run_real_demo_reads_artifacts(tmp_path: Path) -> None:
    module = _load_demo_module()
    baseline = tmp_path / "baseline_eval.json"
    trained = tmp_path / "trained_eval.json"

    baseline.write_text(
        json.dumps(
            {
                "run_id": "baseline-id",
                "overall_score": 0.33,
                "dimension_scores": {"d1": 0.2},
                "tier_scores": {"t1": 0.3},
            }
        ),
        encoding="utf-8",
    )
    trained.write_text(
        json.dumps(
            {
                "run_id": "trained-id",
                "overall_score": 0.61,
                "dimension_scores": {"d1": 0.8},
                "tier_scores": {"t1": 0.7},
            }
        ),
        encoding="utf-8",
    )

    report = module._run_real_demo(baseline_path=baseline, trained_path=trained)
    assert report["backend"] == "real"
    assert report["baseline_run_id"] == "baseline-id"
    assert report["improved_run_id"] == "trained-id"
    assert report["overall_delta"] == 0.28
    assert report["source_artifacts"]["baseline"] == str(baseline)


def test_main_selects_real_backend(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    module = _load_demo_module()
    output = tmp_path / "real_report.json"
    baseline = tmp_path / "baseline_eval.json"
    trained = tmp_path / "trained_eval.json"
    baseline.write_text("{}", encoding="utf-8")
    trained.write_text("{}", encoding="utf-8")

    def _fake_real_demo(*, baseline_path: Path, trained_path: Path) -> dict[str, Any]:
        assert baseline_path == baseline
        assert trained_path == trained
        return _report("real")

    monkeypatch.setattr(module, "_run_real_demo", _fake_real_demo)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "closed_loop_demo.py",
            "--backend",
            "real",
            "--real-baseline",
            str(baseline),
            "--real-trained",
            str(trained),
            "--output",
            str(output),
        ],
    )

    module.main()
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["backend"] == "real"
    assert payload["overall_delta"] == 0.7


def test_main_selects_sim_backend(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    module = _load_demo_module()
    output = tmp_path / "sim_report.json"

    class _Suite:
        cases = [object(), object(), object()]

    class _Benchmark:
        def build_suite(self) -> _Suite:
            return _Suite()

    def _fake_sim_demo(cases: list[object]) -> dict[str, Any]:
        assert len(cases) == 1
        return _report("sim")

    monkeypatch.setattr(module, "LegalMemoryBenchmark", _Benchmark)
    monkeypatch.setattr(module, "_run_sim_demo", _fake_sim_demo)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "closed_loop_demo.py",
            "--backend",
            "sim",
            "--cases",
            "1",
            "--output",
            str(output),
        ],
    )

    module.main()
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["backend"] == "sim"


def test_main_real_backend_rejects_missing_artifacts(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    module = _load_demo_module()
    output = tmp_path / "report.json"
    trained = tmp_path / "trained_eval.json"
    trained.write_text("{}", encoding="utf-8")

    monkeypatch.setattr(
        sys,
        "argv",
        [
            "closed_loop_demo.py",
            "--backend",
            "real",
            "--real-baseline",
            str(tmp_path / "missing.json"),
            "--real-trained",
            str(trained),
            "--output",
            str(output),
        ],
    )

    with pytest.raises(SystemExit):
        module.main()
