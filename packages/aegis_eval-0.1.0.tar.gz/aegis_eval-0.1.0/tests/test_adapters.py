"""Tests for agent adapters."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from aegis.adapters.base import AgentAdapter
from aegis.adapters.rest import RESTAdapter
from aegis.core.types import EvalCaseV1, EvalTier, TrajectoryV1


class TestAgentAdapterBase:
    def test_rest_adapter_create(self) -> None:
        adapter = RESTAdapter(
            url="http://localhost:8000/chat",
            headers={"Authorization": "Bearer test"},
        )
        assert adapter.name == "rest"
        assert isinstance(adapter, AgentAdapter)

    def test_rest_adapter_evaluate(self) -> None:
        adapter = RESTAdapter(url="http://localhost:8000/chat")
        case = EvalCaseV1(
            suite_id="test",
            dimension_id="test",
            tier=EvalTier.MEMORY_FIDELITY,
            prompt="test prompt",
        )

        mock_response = MagicMock()
        mock_response.json.return_value = {"output": "test answer"}
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            result = adapter.evaluate(case)
            assert isinstance(result, TrajectoryV1)
            assert result.steps[0].content == "test answer"
