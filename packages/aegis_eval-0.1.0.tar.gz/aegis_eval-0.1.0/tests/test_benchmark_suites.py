"""Tests for the domain benchmark suites (legal, finance, memory).

Verifies that each suite loads correctly, returns the expected number of
cases, and that all cases have valid fields.  Also tests the harness
integration and CLI benchmark command.
"""

from __future__ import annotations

import pytest
from benchmarks.harness import BenchmarkHarness
from benchmarks.suites.core import CoreBenchmarkSuite
from benchmarks.suites.finance import FinanceBenchmarkSuite
from benchmarks.suites.legal import LegalBenchmarkSuite
from benchmarks.suites.memory import MemoryBenchmarkSuite
from typer.testing import CliRunner

from aegis.cli.main import app
from aegis.core.types import EvalCaseV1, EvalTier
from aegis.eval.benchmarks.runner import BenchmarkConfig, BenchmarkSuite

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_TIERS = set(EvalTier)
VALID_DIFFICULTIES = {1, 2, 3, 4, 5}

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def harness() -> BenchmarkHarness:
    """Return a fresh BenchmarkHarness for each test."""
    return BenchmarkHarness()


@pytest.fixture
def runner() -> CliRunner:
    """Return a Typer CliRunner."""
    return CliRunner()


# ===================================================================
# 1. Suite loading tests — each suite loads without error
# ===================================================================


class TestSuiteLoading:
    """Each suite instantiates and returns cases without error."""

    def test_core_suite_loads(self) -> None:
        cases = CoreBenchmarkSuite().get_cases()
        assert isinstance(cases, list)
        assert len(cases) > 0

    def test_legal_suite_loads(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        assert isinstance(cases, list)
        assert len(cases) > 0

    def test_finance_suite_loads(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        assert isinstance(cases, list)
        assert len(cases) > 0

    def test_memory_suite_loads(self) -> None:
        cases = MemoryBenchmarkSuite().get_cases()
        assert isinstance(cases, list)
        assert len(cases) > 0


# ===================================================================
# 2. Expected case counts
# ===================================================================


class TestCaseCounts:
    """Each suite returns the expected number of cases."""

    def test_core_suite_has_20_cases(self) -> None:
        cases = CoreBenchmarkSuite().get_cases()
        assert len(cases) == 20

    def test_legal_suite_has_40_cases(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        assert len(cases) == 40

    def test_finance_suite_has_40_cases(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        assert len(cases) == 40

    def test_memory_suite_has_25_cases(self) -> None:
        cases = MemoryBenchmarkSuite().get_cases()
        assert len(cases) == 25


# ===================================================================
# 3. Case field validation
# ===================================================================


class TestCaseFieldValidation:
    """All cases have valid dimension_id, tier, prompt, and expected fields."""

    @pytest.mark.parametrize(
        "suite_cls",
        [CoreBenchmarkSuite, LegalBenchmarkSuite, FinanceBenchmarkSuite, MemoryBenchmarkSuite],
        ids=["core", "legal", "finance", "memory"],
    )
    def test_all_cases_have_required_fields(self, suite_cls: type) -> None:
        cases = suite_cls().get_cases()
        for case in cases:
            assert isinstance(case, EvalCaseV1), f"Case is not EvalCaseV1: {case}"
            assert case.dimension_id, f"Missing dimension_id: {case.id}"
            assert case.tier in VALID_TIERS, f"Invalid tier {case.tier} in {case.id}"
            assert case.prompt, f"Empty prompt in {case.id}"
            assert isinstance(case.expected, dict), f"Expected not a dict in {case.id}"
            assert len(case.expected) > 0, f"Empty expected in {case.id}"
            assert case.difficulty in VALID_DIFFICULTIES, (
                f"Invalid difficulty {case.difficulty} in {case.id}"
            )
            assert isinstance(case.tags, list), f"Tags not a list in {case.id}"
            assert len(case.tags) > 0, f"Empty tags in {case.id}"

    @pytest.mark.parametrize(
        "suite_cls",
        [CoreBenchmarkSuite, LegalBenchmarkSuite, FinanceBenchmarkSuite, MemoryBenchmarkSuite],
        ids=["core", "legal", "finance", "memory"],
    )
    def test_all_cases_have_suite_id(self, suite_cls: type) -> None:
        suite = suite_cls()
        cases = suite.get_cases()
        for case in cases:
            assert case.suite_id == suite.SUITE_ID, (
                f"Case {case.id} has suite_id '{case.suite_id}' but expected '{suite.SUITE_ID}'"
            )


# ===================================================================
# 4. Domain tag validation
# ===================================================================


class TestDomainTags:
    """Domain-specific suites have the correct domain tag on all cases."""

    def test_all_legal_cases_have_domain_legal(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        for case in cases:
            assert case.domain == "legal", (
                f"Legal case {case.id} (dim={case.dimension_id}) "
                f"has domain='{case.domain}' instead of 'legal'"
            )

    def test_all_finance_cases_have_domain_finance(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        for case in cases:
            assert case.domain == "finance", (
                f"Finance case {case.id} (dim={case.dimension_id}) "
                f"has domain='{case.domain}' instead of 'finance'"
            )

    def test_legal_cases_have_legal_tag(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        for case in cases:
            assert "legal" in case.tags, f"Legal case {case.id} missing 'legal' tag: {case.tags}"

    def test_finance_cases_have_finance_tag(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        for case in cases:
            assert "finance" in case.tags, (
                f"Finance case {case.id} missing 'finance' tag: {case.tags}"
            )

    def test_memory_cases_have_memory_tag(self) -> None:
        cases = MemoryBenchmarkSuite().get_cases()
        for case in cases:
            assert "memory" in case.tags, f"Memory case {case.id} missing 'memory' tag: {case.tags}"


# ===================================================================
# 5. Tier coverage
# ===================================================================


class TestTierCoverage:
    """Domain suites cover multiple tiers."""

    def test_legal_suite_covers_multiple_tiers(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        tiers = {case.tier for case in cases}
        # Legal should cover at least tiers 1, 2, 4, 5, 7
        assert len(tiers) >= 5, f"Legal suite only covers tiers: {tiers}"

    def test_finance_suite_covers_multiple_tiers(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        tiers = {case.tier for case in cases}
        # Finance should cover at least tiers 1, 2, 3, 4, 5, 7
        assert len(tiers) >= 5, f"Finance suite only covers tiers: {tiers}"

    def test_memory_suite_covers_multiple_tiers(self) -> None:
        cases = MemoryBenchmarkSuite().get_cases()
        tiers = {case.tier for case in cases}
        # Memory should cover at least tiers 1, 2, 3
        assert len(tiers) >= 3, f"Memory suite only covers tiers: {tiers}"


# ===================================================================
# 6. Dimension uniqueness within suites
# ===================================================================


class TestDimensionCoverage:
    """Each suite has a reasonable number of unique dimensions."""

    def test_legal_dimensions_are_diverse(self) -> None:
        cases = LegalBenchmarkSuite().get_cases()
        dims = {case.dimension_id for case in cases}
        # 40 cases across 18+ dimensions
        assert len(dims) >= 15, f"Legal suite has only {len(dims)} unique dimensions"

    def test_finance_dimensions_are_diverse(self) -> None:
        cases = FinanceBenchmarkSuite().get_cases()
        dims = {case.dimension_id for case in cases}
        # 40 cases across 20+ dimensions
        assert len(dims) >= 15, f"Finance suite has only {len(dims)} unique dimensions"

    def test_memory_dimensions_are_diverse(self) -> None:
        cases = MemoryBenchmarkSuite().get_cases()
        dims = {case.dimension_id for case in cases}
        # 25 cases across at least 15 dimensions
        assert len(dims) >= 15, f"Memory suite has only {len(dims)} unique dimensions"


# ===================================================================
# 7. Harness can load all suites by name
# ===================================================================


class TestHarnessLoading:
    """BenchmarkHarness.load_suite() works for all built-in suites."""

    @pytest.mark.parametrize(
        "suite_name,expected_count",
        [
            ("core", 20),
            ("legal", 40),
            ("finance", 40),
            ("memory", 25),
        ],
    )
    def test_harness_loads_suite_by_name(
        self,
        harness: BenchmarkHarness,
        suite_name: str,
        expected_count: int,
    ) -> None:
        cases = harness.load_suite(suite_name)
        assert isinstance(cases, list)
        assert len(cases) == expected_count
        for case in cases:
            assert isinstance(case, EvalCaseV1)

    def test_harness_rejects_unknown_suite(self, harness: BenchmarkHarness) -> None:
        with pytest.raises(KeyError, match="Unknown benchmark suite"):
            harness.load_suite("nonexistent-suite-xyz")


# ===================================================================
# 8. CLI benchmark command
# ===================================================================


class TestCLIBenchmarkCommand:
    """The `aegis eval benchmark` CLI command can be invoked."""

    def test_benchmark_command_core(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark", "--suite", "core"])
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert "Benchmark Results" in result.output

    def test_benchmark_command_legal(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark", "--suite", "legal"])
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert "Benchmark Results" in result.output

    def test_benchmark_command_finance(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark", "--suite", "finance"])
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert "Benchmark Results" in result.output

    def test_benchmark_command_memory(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark", "--suite", "memory"])
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert "Benchmark Results" in result.output

    def test_benchmark_command_invalid_suite(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark", "--suite", "invalid"])
        assert result.exit_code == 1
        assert "Unknown suite" in result.output

    def test_benchmark_command_output_file(self, runner: CliRunner, tmp_path) -> None:
        output_file = tmp_path / "results.json"
        result = runner.invoke(
            app,
            ["eval", "benchmark", "--suite", "core", "--output", str(output_file)],
        )
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert output_file.exists()
        import json

        data = json.loads(output_file.read_text())
        assert isinstance(data, dict)

    def test_benchmark_list_command(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["eval", "benchmark-list"])
        assert result.exit_code == 0, f"CLI failed: {result.output}"
        assert "Available Benchmark Suites" in result.output
        assert "legal-memory" in result.output
        assert "finance-memory" in result.output
        assert "reward-integrity" in result.output


# ===================================================================
# 9. BenchmarkSuite can run with a mock agent
# ===================================================================


class TestBenchmarkSuiteRunner:
    """BenchmarkSuite from runner.py can execute with a mock agent."""

    def _make_mock_agent(self) -> object:
        """Return a simple callable that echoes keywords from the prompt."""

        def mock_agent(prompt: str) -> str:
            return f"Mock response containing relevant keywords from: {prompt}"

        return mock_agent

    @pytest.mark.parametrize(
        "suite_cls,suite_name",
        [
            (CoreBenchmarkSuite, "core-benchmark-v1"),
            (LegalBenchmarkSuite, "legal-benchmark-v1"),
            (FinanceBenchmarkSuite, "finance-benchmark-v1"),
            (MemoryBenchmarkSuite, "memory-benchmark-v1"),
        ],
        ids=["core", "legal", "finance", "memory"],
    )
    def test_benchmark_suite_runs_with_mock_agent(
        self,
        suite_cls: type,
        suite_name: str,
    ) -> None:
        cases = suite_cls().get_cases()
        config = BenchmarkConfig(
            name=suite_name,
            version="1.0.0",
            description=f"Test run of {suite_name}",
            num_cases=len(cases),
        )
        benchmark = BenchmarkSuite(config=config, cases=cases)

        mock_agent = self._make_mock_agent()
        result = benchmark.run(agent=mock_agent)

        assert result.benchmark_name == suite_name
        assert result.overall_score >= 0.0
        assert result.overall_score <= 1.0
        assert len(result.case_results) == len(cases)
        assert isinstance(result.dimension_scores, dict)
        assert result.duration_seconds >= 0.0

    def test_mock_agent_lambda(self) -> None:
        """A simple lambda agent can be used with BenchmarkSuite."""
        cases = CoreBenchmarkSuite().get_cases()[:5]  # Use first 5 for speed
        config = BenchmarkConfig(
            name="lambda-test",
            version="1.0.0",
            description="Lambda agent test",
            num_cases=len(cases),
        )
        benchmark = BenchmarkSuite(config=config, cases=cases)

        result = benchmark.run(agent=lambda prompt: "test response")

        assert result.benchmark_name == "lambda-test"
        assert len(result.case_results) == 5
        for case_result in result.case_results:
            assert "score" in case_result
            assert "dimension_id" in case_result

    def test_benchmark_suite_run_subset(self) -> None:
        """BenchmarkSuite.run_subset filters correctly."""
        cases = LegalBenchmarkSuite().get_cases()
        config = BenchmarkConfig(
            name="legal-subset-test",
            version="1.0.0",
            description="Subset test",
            num_cases=len(cases),
        )
        benchmark = BenchmarkSuite(config=config, cases=cases)

        def mock_agent(prompt: str) -> str:
            return f"response: {prompt[:50]}"

        # Filter by difficulty
        result = benchmark.run_subset(
            agent=mock_agent,
            difficulty_filter=5,
        )
        assert len(result.case_results) > 0
        for cr in result.case_results:
            assert cr["difficulty"] == 5


# ===================================================================
# 10. Expected dict contains ground-truth keywords
# ===================================================================


class TestExpectedContainsGroundTruth:
    """Each case expected dict contains meaningful ground-truth values."""

    @pytest.mark.parametrize(
        "suite_cls",
        [CoreBenchmarkSuite, LegalBenchmarkSuite, FinanceBenchmarkSuite, MemoryBenchmarkSuite],
        ids=["core", "legal", "finance", "memory"],
    )
    def test_expected_values_are_non_trivial(self, suite_cls: type) -> None:
        cases = suite_cls().get_cases()
        for case in cases:
            for key, value in case.expected.items():
                # Values should not be None or empty strings
                if isinstance(value, str):
                    assert len(value) > 0, (
                        f"Case {case.id} has empty expected value for key '{key}'"
                    )
                elif isinstance(value, list):
                    # Lists can be empty only if they represent "nothing expected"
                    # but generally they should have content
                    pass
                elif isinstance(value, dict):
                    assert len(value) > 0, f"Case {case.id} has empty dict for key '{key}'"
