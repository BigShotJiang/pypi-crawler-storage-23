"""Coverage tests for audio, video, image, table, and web ingestion modules."""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

import aegis.ingestion.audio as audio_mod
import aegis.ingestion.images as images_mod
import aegis.ingestion.tables as tables_mod
import aegis.ingestion.video as video_mod
import aegis.ingestion.web as web_mod
from aegis.ingestion.audio import (
    AudioIngester,
    AudioSegment,
    EarningsCallProcessor,
    TranscriptionResult,
)
from aegis.ingestion.images import ImageAnalysis, ImageIngester
from aegis.ingestion.tables import CrossTableReasoner, ExtractedTable, TableCell, TableExtractor
from aegis.ingestion.video import VideoFrame, VideoIngester, VideoIngestionResult
from aegis.ingestion.web import (
    CourtDocketClient,
    RegulatoryClient,
    SECEdgarClient,
    WebIngester,
    WebPage,
)


class _RunResult:
    def __init__(self, *, code: int = 0, stdout: str = "", stderr: str = "") -> None:
        self.returncode = code
        self.stdout = stdout
        self.stderr = stderr


def _make_transcription() -> TranscriptionResult:
    return TranscriptionResult(
        segments=[
            AudioSegment(
                start_time=0.0,
                end_time=2.0,
                text="Intro remarks with Revenue up 10%.",
                confidence=0.9,
            ),
            AudioSegment(start_time=5.0, end_time=9.0, text="Q&A starts now", confidence=0.8),
            AudioSegment(
                start_time=9.1,
                end_time=10.2,
                text="Question about margin guidance?",
                confidence=0.7,
            ),
            AudioSegment(
                start_time=12.8,
                end_time=14.0,
                text="Answer: EBITDA improved by $12 million.",
                confidence=0.8,
            ),
        ],
        full_text="full",
        duration=14.0,
        language="en",
    )


def test_audio_load_whisper_success_and_fallbacks(monkeypatch: pytest.MonkeyPatch) -> None:
    fake_whisper = SimpleNamespace(
        load_model=lambda model, device: {"model": model, "device": device}
    )
    fake_torch = SimpleNamespace(cuda=SimpleNamespace(is_available=lambda: True))
    monkeypatch.setitem(__import__("sys").modules, "whisper", fake_whisper)
    monkeypatch.setitem(__import__("sys").modules, "torch", fake_torch)

    loaded = audio_mod._load_whisper("small", "auto")
    assert loaded == {"model": "small", "device": "cuda"}

    monkeypatch.delitem(__import__("sys").modules, "whisper", raising=False)
    missing = audio_mod._load_whisper("small", "cpu")
    assert missing is None


def test_audio_ingester_transcribe_and_helpers(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    audio_path = tmp_path / "sample.wav"
    audio_path.write_bytes(b"dummy")

    ingester = AudioIngester(model="whisper-v3")

    # ensure fallback path when model loading fails then base succeeds
    calls: list[tuple[str, str]] = []

    def fake_load(model: str, device: str) -> Any:
        calls.append((model, device))
        if model == "whisper-v3":
            return None

        class _Model:
            @staticmethod
            def transcribe(path: str, **kwargs: Any) -> dict[str, Any]:
                assert Path(path).exists()
                assert kwargs.get("language") == "en"
                return {
                    "text": " hello world from earnings call summary ",
                    "language": "en",
                    "segments": [
                        {
                            "start": 0.0,
                            "end": 1.2,
                            "text": " hello this is a longer segment ",
                            "avg_logprob": 0.8,
                        },
                        {
                            "start": 1.2,
                            "end": 2.8,
                            "text": " world revenue grew by 20 percent ",
                            "avg_logprob": 0.7,
                        },
                    ],
                }

        return _Model()

    monkeypatch.setattr(audio_mod, "_load_whisper", fake_load)

    result = ingester.transcribe(str(audio_path), language="en")
    assert result.full_text == "hello world from earnings call summary"
    assert result.duration == 2.8
    assert len(result.segments) == 2
    assert calls[0][0] == "whisper-v3"
    assert calls[1][0] == "base"

    key_points = ingester.extract_key_points(result, max_points=5)
    assert key_points

    grouped = ingester.identify_speakers(result)
    assert grouped

    entries = ingester.to_memory_entries(result, "src-1")
    assert entries
    assert entries[0]["provenance"]["modality"] == "audio"

    with pytest.raises(FileNotFoundError):
        ingester.transcribe(str(tmp_path / "missing.wav"))

    # No model available path.
    monkeypatch.setattr(audio_mod, "_load_whisper", lambda *_args: None)
    empty_result = AudioIngester().transcribe(str(audio_path))
    assert empty_result.full_text == ""
    assert empty_result.metadata["error"] == "whisper_not_installed"


def test_earnings_call_processor_extractors() -> None:
    proc = EarningsCallProcessor()
    transcription = _make_transcription()
    proc.identify_speakers(transcription)

    mentions = proc.extract_financial_mentions(transcription)
    assert any("10%" in m["mention"] or "$12" in m["mention"] for m in mentions)

    qa = proc.extract_qa_pairs(transcription)
    assert qa
    assert "question" in qa[0] and "answer" in qa[0]


def test_video_helpers_and_ingester(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    # _get_video_duration via ffprobe fallback.
    monkeypatch.setattr(
        "subprocess.run", lambda *args, **kwargs: _RunResult(code=0, stdout="12.5\n")
    )
    assert video_mod._get_video_duration("/tmp/x.mp4") == 12.5

    # _extract_keyframes_ffmpeg parsing.
    monkeypatch.setattr(
        "subprocess.run",
        lambda *args, **kwargs: _RunResult(code=0, stdout="0.0\n0.8\n2.1\n2.9\n"),
    )
    ff_frames = video_mod._extract_keyframes_ffmpeg("/tmp/x.mp4", interval=1.0)
    assert [f.timestamp for f in ff_frames] == [0.0, 2.1]

    ing = VideoIngester(keyframe_interval=2.0)
    video_path = tmp_path / "demo.mp4"
    video_path.write_bytes(b"video")

    # Keyframe extraction fallback chain.
    monkeypatch.setattr(video_mod, "_extract_keyframes_cv2", lambda *_args: [])
    monkeypatch.setattr(
        video_mod,
        "_extract_keyframes_ffmpeg",
        lambda *_args: [VideoFrame(timestamp=1.0, frame_index=0, description="k")],
    )
    frames = ing.extract_keyframes(str(video_path))
    assert len(frames) == 1

    # Audio extraction success path.
    def _run_ffmpeg(cmd: list[str], **kwargs: Any) -> _RunResult:
        out = Path(cmd[-1])
        out.write_bytes(b"audio")
        return _RunResult(code=0)

    monkeypatch.setattr("subprocess.run", _run_ffmpeg)
    extracted_audio = ing.extract_audio_track(str(video_path))
    assert extracted_audio.endswith(".wav")

    # Ingest with patched transcription.
    monkeypatch.setattr(video_mod, "_get_video_duration", lambda *_args: 0.0)
    monkeypatch.setattr(ing, "extract_keyframes", lambda *_args: [VideoFrame(4.0, 0, "desc")])
    monkeypatch.setattr(ing, "extract_audio_track", lambda *_args: "audio.wav")
    monkeypatch.setattr(
        "aegis.ingestion.audio.AudioIngester.transcribe",
        lambda self, _path: TranscriptionResult(segments=[], full_text="", duration=6.0),
    )
    ingest_result = ing.ingest(str(video_path))
    assert ingest_result.duration == 6.0
    assert ingest_result.metadata["num_keyframes"] == 1

    # to_memory_entries includes frame and audio-derived entries.
    def _to_mem(self: Any, _tx: Any, source_id: str) -> list[dict[str, Any]]:  # noqa: ARG001
        return [
            {
                "key": f"{source_id}:audio:0",
                "value": "speech",
                "tags": [],
                "provenance": {"modality": "audio"},
            }
        ]

    monkeypatch.setattr("aegis.ingestion.audio.AudioIngester.to_memory_entries", _to_mem)
    mem = ing.to_memory_entries(
        VideoIngestionResult(
            frames=[VideoFrame(0.5, 0, "frame")], transcription=SimpleNamespace(), duration=1.0
        ),
        source_id="v1",
    )
    assert len(mem) == 2
    assert mem[1]["provenance"]["modality"] == "video_audio"

    with pytest.raises(FileNotFoundError):
        ing.ingest(str(tmp_path / "missing.mp4"))


def test_image_helpers_and_ingester(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    # PNG header dimensions for _get_image_info fallback path.
    png = tmp_path / "img.png"
    png.write_bytes(
        b"\x89PNG\r\n\x1a\n" + b"\x00" * 8 + b"\x00\x00\x00\x10" + b"\x00\x00\x00\x20" + b"\x00" * 8
    )
    info = images_mod._get_image_info(str(png))
    assert info["extension"] == ".png"
    assert info["file_size_bytes"] > 0

    assert images_mod._classify_by_text("Revenue bar chart x-axis y-axis 10 20 30") in {
        "bar",
        "line",
        "pie",
        "table",
        "diagram",
    }
    assert images_mod._classify_by_text("Plain short text") in {"photo", "scan", "table", "bar"}

    chart_data = images_mod._extract_chart_data_from_text("Q1: 10\nQ2: 20", "bar")
    assert chart_data is not None
    assert chart_data["num_points"] == 2

    ing = ImageIngester(ocr_engine="tesseract")
    image_file = tmp_path / "x.jpg"
    image_file.write_bytes(b"jpg")

    monkeypatch.setattr(
        images_mod, "_get_image_info", lambda _p: {"format": "JPEG", "width": 10, "height": 20}
    )
    monkeypatch.setattr(ing, "ocr", lambda _p: "Revenue: 10\nCost: 5")
    monkeypatch.setattr(ing, "detect_chart_type", lambda _p: "bar")
    monkeypatch.setattr(
        ing, "extract_chart_data", lambda _p: {"chart_type": "bar", "num_points": 2}
    )

    analysis = ing.analyze(str(image_file))
    assert isinstance(analysis, ImageAnalysis)
    assert "JPEG image" in analysis.description
    assert analysis.chart_data is not None

    bad_ing = ImageIngester(ocr_engine="unsupported")
    assert bad_ing.ocr(str(image_file)) == ""

    # detect_chart_type precedence and extraction.
    monkeypatch.setattr(images_mod, "_classify_by_pixels", lambda _p: "diagram")
    monkeypatch.setattr(bad_ing, "ocr", lambda _p: "")
    assert bad_ing.detect_chart_type(str(image_file)) == "diagram"

    ing_for_extract = ImageIngester(ocr_engine="tesseract")
    monkeypatch.setattr(ing_for_extract, "ocr", lambda _p: "Sales: 100")
    monkeypatch.setattr(ing_for_extract, "detect_chart_type", lambda _p: "photo")
    assert ing_for_extract.extract_chart_data(str(image_file)) is None

    entries = ing.to_memory_entries(
        ImageAnalysis(
            description="desc",
            text_content="ocr",
            chart_data={"chart_type": "bar", "num_points": 1},
            metadata={"source": "unit"},
        ),
        source_id="img1",
    )
    assert len(entries) == 3

    with pytest.raises(FileNotFoundError):
        ing.analyze(str(tmp_path / "missing.png"))


def test_table_extractor_and_cross_table_reasoning(tmp_path: Path) -> None:
    assert tables_mod._detect_cell_type("$1,234.00") == "currency"
    assert tables_mod._detect_cell_type("2026-01-01") == "date"
    assert tables_mod._detect_cell_type("42") == "currency"
    assert tables_mod._detect_cell_type("n/a") == "text"

    row = tables_mod._parse_row([" $10 ", "abc"], 0)
    assert row[0].value == "$10"
    assert row[0].data_type in {"currency", "numeric"}

    extractor = TableExtractor()

    csv_file = tmp_path / "data.csv"
    csv_file.write_text("Name,Revenue,Margin\nA,$10,50%\n", encoding="utf-8")
    table = extractor.extract_from_csv(str(csv_file))
    assert table.columns == 3
    assert table.headers == ["Name", "Revenue", "Margin"]
    assert table.num_rows == 1
    assert table.to_dicts()[0]["Name"] == "A"

    html_tables = extractor.extract_from_html(
        "<table><tr><th>H1</th><th>H2</th></tr><tr><td>X</td><td>10</td></tr></table>"
    )
    assert len(html_tables) == 1

    # No camelot/openpyxl installed paths should return [] without raising.
    assert extractor.extract_from_pdf(str(csv_file)) == []
    assert extractor.extract_from_excel(str(csv_file)) == []

    classified = extractor.detect_table_type(table)
    assert classified in {"financial_statement", "comparison", "regulatory_matrix", "data"}

    normalized = extractor.normalize_financials(
        ExtractedTable(
            rows=[
                [
                    TableCell("$1.2 million", 0, 0, "currency"),
                    TableCell("25%", 0, 1, "numeric"),
                    TableCell("01/31/2026", 0, 2, "date"),
                ]
            ],
            columns=3,
            headers=["Revenue", "Margin", "Date"],
        )
    )
    assert normalized.metadata["normalized"] is True
    assert normalized.rows[0][0].data_type == "numeric"
    assert normalized.rows[0][1].value.startswith("0.")
    assert normalized.rows[0][2].value == "2026-01-31"

    assert extractor._normalize_date("31-01-2026") == "2026-01-31"
    assert extractor._normalize_date("2026-1-2") == "2026-01-02"

    reasoner = CrossTableReasoner()
    t1 = ExtractedTable(
        rows=[[TableCell("100", 0, 0, "numeric"), TableCell("A", 0, 1, "text")]],
        columns=2,
        headers=["Amount", "Label"],
    )
    t2 = ExtractedTable(
        rows=[[TableCell("100.00", 0, 0, "currency"), TableCell("A", 0, 1, "text")]],
        columns=2,
        headers=["Amount", "Label"],
    )

    recon = reasoner.reconcile([t1, t2])
    assert recon["summary"]["total_headers_checked"] >= 1

    refs = reasoner.find_references(t1, [t2])
    assert refs


def test_web_ingester_cache_fetch_and_clients(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    # Disk cache stale handling.
    cache = web_mod._DiskCache(str(tmp_path / "cache"))
    cache.put("https://example.com", "<html><title>X</title><body>hello</body></html>")
    assert cache.get("https://example.com") is not None

    stale_path = Path(str(tmp_path / "cache")) / cache._key("https://stale.example")
    stale_path.write_text(
        json.dumps(
            {
                "url": "https://stale.example",
                "content": "old",
                "fetched_at": "2000-01-01T00:00:00+00:00",
            }
        ),
        encoding="utf-8",
    )
    assert cache.get("https://stale.example") is None

    assert web_mod._extract_title("<html><title>Hello</title></html>") == "Hello"
    text = web_mod._strip_html("<html><body><p>A</p><p>B</p></body></html>")
    assert "A" in text and "B" in text
    tables = web_mod._extract_html_tables("<table><tr><th>A</th></tr><tr><td>1</td></tr></table>")
    assert tables[0]["headers"] == ["A"]

    ing = WebIngester(cache_dir=str(tmp_path / "web-cache"), rate_limit_rpm=1000)

    # fetch from cache.
    ing._cache.put("https://cached.local", "<html><title>Cached</title></html>")
    cached = ing.fetch("https://cached.local")
    assert cached.metadata["cached"] is True

    # fetch success/error using urlopen stub.
    class _Headers:
        @staticmethod
        def get_content_charset() -> str:
            return "utf-8"

    class _Resp:
        headers = _Headers()

        def __init__(self, data: bytes) -> None:
            self._data = data

        def read(self) -> bytes:
            return self._data

        def __enter__(self) -> _Resp:
            return self

        def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:  # noqa: ANN401
            return False

    monkeypatch.setattr(
        "urllib.request.urlopen",
        lambda req, timeout=30: _Resp(
            b"<html><title>Live</title><body><table><tr><th>H</th></tr><tr><td>X</td></tr></table><p>text paragraph here</p></body></html>"
        ),
    )
    live = ing.fetch("https://live.local")
    assert live.title == "Live"
    assert ing.extract_text(live)
    assert ing.extract_tables(live)

    mem = ing.to_memory_entries(live, "web1")
    assert mem

    def _raise_urlerror(*args: Any, **kwargs: Any) -> Any:
        raise web_mod.urllib.error.URLError("boom")

    monkeypatch.setattr("urllib.request.urlopen", _raise_urlerror)
    failed = ing.fetch("https://fail.local")
    assert failed.content == ""
    assert "error" in failed.metadata

    # SEC client with mocked fetch responses.
    sec = SECEdgarClient(cache_dir=str(tmp_path / "edgar-cache"), rate_limit_rpm=1000)

    def _sec_fetch(url: str) -> WebPage:
        if url.endswith(".json") and "submissions" in url:
            payload = {
                "name": "Acme Corp",
                "filings": {
                    "recent": {
                        "form": ["10-K", "8-K"],
                        "filingDate": ["2026-01-01", "2026-01-15"],
                        "accessionNumber": ["0000000000-26-000001", "0000000000-26-000002"],
                        "primaryDocument": ["a10k.htm", "a8k.htm"],
                    }
                },
            }
            return WebPage(url=url, title="", content=json.dumps(payload))
        if "Archives/edgar/data" in url:
            return WebPage(url=url, title="filing", content="<html><body>FILING BODY</body></html>")
        if "search-index" in url:
            return WebPage(
                url=url,
                title="",
                content=json.dumps(
                    {
                        "hits": {
                            "hits": [
                                {
                                    "_source": {
                                        "forms": "10-K",
                                        "entity_name": "Acme Corp",
                                        "entity_id": "0000123",
                                        "file_date": "2026-01-01",
                                        "file_url": "https://sec.example/doc",
                                    }
                                }
                            ]
                        }
                    }
                ),
            )
        if url.endswith("_htm.xml"):
            return WebPage(
                url=url,
                title="",
                content='<xbrli:xbrl><us-gaap:Revenue contextRef="c1">100</us-gaap:Revenue></xbrli:xbrl>',
            )
        return WebPage(url=url, title="", content="")

    monkeypatch.setattr(sec, "fetch", _sec_fetch)

    filing = sec.get_filing("123", "10-K", date="2026-01-01")
    assert filing.company == "Acme Corp"
    assert filing.content

    found = sec.search_filings("Acme", filing_type="10-K", limit=3)
    assert found

    class _FakeFact:
        def __init__(self) -> None:
            self.concept = "Revenue"
            self.value = "100"
            self.label = "Revenue"
            self.unit = "USD"
            self.period_type = "duration"
            self.decimals = "0"
            self.metadata = {"context_ref": "c1"}

    class _FakeXBRLParser:
        @staticmethod
        def parse_xbrl(_text: str) -> list[Any]:
            return [_FakeFact()]

        @staticmethod
        def parse_ixbrl(_text: str) -> list[Any]:
            return []

    monkeypatch.setattr("aegis.ingestion.xbrl.XBRLParser", _FakeXBRLParser)
    facts = sec.get_xbrl_data(filing)
    assert "Revenue:c1" in facts

    # Court docket client.
    court = CourtDocketClient(cache_dir=str(tmp_path / "court-cache"), rate_limit_rpm=1000)

    monkeypatch.setattr(
        court,
        "fetch",
        lambda url: WebPage(
            url=url,
            title="",
            content=json.dumps(
                {
                    "results": [
                        {
                            "caseName": "Acme v. State",
                            "docketNumber": "1",
                            "court": "ca",
                            "dateFiled": "2026-01-01",
                            "absolute_url": "https://court/case/1",
                            "snippet": "snippet",
                        }
                    ]
                }
            )
            if "search" in url
            else json.dumps(
                {
                    "case_name": "Acme v. State",
                    "court": "ca",
                    "date_filed": "2026-01-01",
                    "date_terminated": "",
                    "docket_entries": [],
                    "parties": [],
                    "absolute_url": "https://court/case/1",
                }
            ),
        ),
    )
    cases = court.search_cases("Acme", jurisdiction="ca")
    assert cases and cases[0]["case_name"] == "Acme v. State"

    docket = court.get_docket("123")
    assert docket["case_id"] == "123"

    # Parse failure path for docket.
    monkeypatch.setattr(
        court, "fetch", lambda url: WebPage(url=url, title="", content="<html>bad</html>")
    )
    bad_docket = court.get_docket("123")
    assert bad_docket["error"] == "parse_failed"

    # Regulatory client.
    reg = RegulatoryClient(cache_dir=str(tmp_path / "reg-cache"), rate_limit_rpm=1000)

    monkeypatch.setattr(
        reg,
        "fetch",
        lambda url: WebPage(
            url=url,
            title="",
            content=json.dumps(
                {
                    "results": [
                        {
                            "title": "Rule",
                            "document_number": "DOC-1",
                            "type": "RULE",
                            "abstract": "A",
                            "publication_date": "2026-01-01",
                            "agencies": [{"name": "Agency"}],
                            "html_url": "https://fr/doc",
                            "pdf_url": "https://fr/doc.pdf",
                        }
                    ]
                }
            )
            if "documents.json" in url
            else json.dumps({"part": 1}),
        ),
    )

    fr_docs = reg.search_federal_register("risk", limit=5)
    assert fr_docs and fr_docs[0]["document_number"] == "DOC-1"

    cfr = reg.get_cfr_section(12, 34, 56)
    assert cfr["title"] == 12

    monkeypatch.setattr(
        reg, "fetch", lambda url: WebPage(url=url, title="", content="<html>cfr text</html>")
    )
    cfr_html = reg.get_cfr_section(1, 2, 3)
    assert "content" in cfr_html


def test_rate_limiter_wait(monkeypatch: pytest.MonkeyPatch) -> None:
    limiter = web_mod._RateLimiter(rpm=60)
    times = iter([0.0, 0.0, 0.2, 1.1])
    slept: list[float] = []
    monkeypatch.setattr(web_mod.time, "monotonic", lambda: next(times))
    monkeypatch.setattr(web_mod.time, "sleep", lambda d: slept.append(d))

    limiter.wait()  # first call no sleep
    limiter.wait()  # should sleep because 0.2 elapsed < 1.0 interval
    assert slept and slept[0] > 0
