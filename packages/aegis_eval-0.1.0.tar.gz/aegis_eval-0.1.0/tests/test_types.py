"""Tests for Aegis v1 public types."""

from __future__ import annotations

from datetime import datetime

from aegis.core.types import (
    BlockingRegression,
    EvalCaseV1,
    EvalTier,
    JudgePacketV1,
    MemoryEventV1,
    MemoryOperation,
    MemoryTier,
    PromotionDecisionV1,
    PromotionStatus,
    RetrievalTraceV1,
    RewardTraceV1,
    ScorerType,
    StepKind,
    TemporalBounds,
    TrajectoryStep,
    TrajectoryV1,
)


class TestTrajectoryV1:
    def test_create_minimal(self) -> None:
        t = TrajectoryV1(
            agent_id="agent-1",
            task_id="task-1",
            steps=[],
        )
        assert t.agent_id == "agent-1"
        assert t.task_id == "task-1"
        assert t.steps == []
        assert t.id  # auto-generated UUID

    def test_create_with_steps(self, sample_trajectory: TrajectoryV1) -> None:
        assert len(sample_trajectory.steps) == 5
        assert sample_trajectory.steps[0].kind == StepKind.THINK
        assert sample_trajectory.total_latency_ms == 1250
        assert sample_trajectory.total_tokens == 450

    def test_step_kinds(self) -> None:
        for kind in StepKind:
            step = TrajectoryStep(kind=kind, content=f"test {kind.value}")
            assert step.kind == kind

    def test_serialization_roundtrip(self, sample_trajectory: TrajectoryV1) -> None:
        data = sample_trajectory.model_dump()
        restored = TrajectoryV1.model_validate(data)
        assert restored.agent_id == sample_trajectory.agent_id
        assert len(restored.steps) == len(sample_trajectory.steps)

    def test_json_roundtrip(self, sample_trajectory: TrajectoryV1) -> None:
        json_str = sample_trajectory.model_dump_json()
        restored = TrajectoryV1.model_validate_json(json_str)
        assert restored.id == sample_trajectory.id


class TestMemoryEventV1:
    def test_create(self, sample_memory_event: MemoryEventV1) -> None:
        assert sample_memory_event.operation == MemoryOperation.STORE
        assert sample_memory_event.memory_tier == MemoryTier.SESSION
        assert sample_memory_event.customer_id == "sterling"

    def test_all_operations(self) -> None:
        for op in MemoryOperation:
            event = MemoryEventV1(
                operation=op,
                memory_tier=MemoryTier.WORKING,
                key="test",
                value="test",
                agent_id="a",
                customer_id="c",
            )
            assert event.operation == op

    def test_temporal_bounds(self) -> None:
        event = MemoryEventV1(
            operation=MemoryOperation.STORE,
            memory_tier=MemoryTier.PERMANENT,
            key="regulation",
            value="SEC Rule 10b-5",
            temporal_bounds=TemporalBounds(
                valid_from=datetime(2026, 1, 1),
                valid_to=None,
            ),
            agent_id="a",
            customer_id="c",
        )
        assert event.temporal_bounds is not None
        assert event.temporal_bounds.valid_to is None

    def test_confidence_bounds(self) -> None:
        event = MemoryEventV1(
            operation=MemoryOperation.STORE,
            memory_tier=MemoryTier.WORKING,
            key="k",
            value="v",
            agent_id="a",
            customer_id="c",
            confidence=0.5,
        )
        assert event.confidence == 0.5


class TestRetrievalTraceV1:
    def test_create(self, sample_retrieval_trace: RetrievalTraceV1) -> None:
        assert len(sample_retrieval_trace.sources_queried) == 2
        assert sample_retrieval_trace.total_retrieved == 7
        assert sample_retrieval_trace.total_selected == 4
        assert sample_retrieval_trace.total_dropped == 3

    def test_context_blocks(self, sample_retrieval_trace: RetrievalTraceV1) -> None:
        selected = [b for b in sample_retrieval_trace.context_blocks if b.selected]
        dropped = [b for b in sample_retrieval_trace.context_blocks if not b.selected]
        assert len(selected) == 1
        assert len(dropped) == 1
        assert dropped[0].reason == "Below relevance threshold"


class TestRewardTraceV1:
    def test_create(self, sample_reward_trace: RewardTraceV1) -> None:
        assert len(sample_reward_trace.stages) == 2
        assert sample_reward_trace.total_reward == 0.73

    def test_stage_scores_bounded(self, sample_reward_trace: RewardTraceV1) -> None:
        for stage in sample_reward_trace.stages:
            assert 0.0 <= stage.rule_score <= 1.0
            assert 0.0 <= stage.semantic_score <= 1.0
            assert 0.0 <= stage.judge_score <= 1.0


class TestEvalCaseV1:
    def test_create(self, sample_eval_case: EvalCaseV1) -> None:
        assert sample_eval_case.tier == EvalTier.MEMORY_FIDELITY
        assert sample_eval_case.difficulty == 2
        assert "memory" in sample_eval_case.tags

    def test_all_tiers(self) -> None:
        for tier in EvalTier:
            case = EvalCaseV1(
                suite_id="test",
                dimension_id="test_dim",
                tier=tier,
                prompt="test prompt",
            )
            assert case.tier == tier


class TestJudgePacketV1:
    def test_create(self, sample_judge_packet: JudgePacketV1) -> None:
        assert sample_judge_packet.ensemble_score == 0.88
        assert sample_judge_packet.disagreement == 0.05
        assert len(sample_judge_packet.judge_scores) == 2

    def test_unanimous(self) -> None:
        packet = JudgePacketV1(
            eval_case_id="c1",
            dimension_id="d1",
            rule_score=0.9,
            semantic_score=0.9,
            judge_scores={"model_a": 0.9},
            ensemble_score=0.9,
            disagreement=0.0,
        )
        assert packet.disagreement == 0.0


class TestPromotionDecisionV1:
    def test_pass(self, sample_promotion_decision: PromotionDecisionV1) -> None:
        assert sample_promotion_decision.status == PromotionStatus.PASS
        assert sample_promotion_decision.composite_improvement == 4.2
        assert sample_promotion_decision.tier7_clear is True

    def test_fail_with_regressions(self) -> None:
        decision = PromotionDecisionV1(
            adapter_id="test-lora",
            status=PromotionStatus.FAIL,
            composite_improvement=1.5,
            blocking_regressions=[
                BlockingRegression(
                    dimension_id="prompt_injection_resistance",
                    tier=EvalTier.SECURITY_ADVERSARIAL,
                    baseline_score=0.95,
                    current_score=0.80,
                    delta=-0.15,
                    severity="critical",
                )
            ],
            tier7_clear=False,
        )
        assert decision.status == PromotionStatus.FAIL
        assert len(decision.blocking_regressions) == 1
        assert decision.tier7_clear is False

    def test_pending_human_gate(self) -> None:
        decision = PromotionDecisionV1(
            adapter_id="legal-lora",
            status=PromotionStatus.PENDING_HUMAN_GATE,
            composite_improvement=5.0,
            human_gate_required=True,
            human_gate_approved=None,
        )
        assert decision.status == PromotionStatus.PENDING_HUMAN_GATE
        assert decision.human_gate_approved is None

    def test_canary_config_defaults(self) -> None:
        decision = PromotionDecisionV1(
            adapter_id="test",
            status=PromotionStatus.PASS,
            composite_improvement=3.0,
        )
        assert decision.canary_config["traffic_pct"] == 5
        assert decision.canary_config["duration_hours"] == 24


class TestEnums:
    def test_memory_operations_count(self) -> None:
        assert len(MemoryOperation) == 12

    def test_eval_tiers_count(self) -> None:
        assert len(EvalTier) == 7

    def test_memory_tiers(self) -> None:
        assert MemoryTier.WORKING.value == "working"
        assert MemoryTier.SESSION.value == "session"
        assert MemoryTier.PERMANENT.value == "permanent"

    def test_scorer_types(self) -> None:
        assert len(ScorerType) == 3
