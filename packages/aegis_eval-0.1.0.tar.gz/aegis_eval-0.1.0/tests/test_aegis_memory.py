"""Comprehensive tests for AegisMemory drop-in and ConsolidationEngine.

Covers the full public API of:
- aegis.memory.aegis_memory.AegisMemory
- aegis.memory.consolidation.ConsolidationEngine / ConsolidationResult
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from aegis.core.types import MemoryTier
from aegis.memory.aegis_memory import AegisMemory
from aegis.memory.consolidation import ConsolidationEngine, ConsolidationResult
from aegis.memory.store import InMemoryStore
from aegis.memory.types import MemoryEntry

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def mem() -> AegisMemory:
    """Fresh AegisMemory with vectors disabled for fast tests."""
    return AegisMemory(
        domain="legal",
        customer_id="sterling",
        agent_id="agent-1",
        enable_vectors=False,
    )


@pytest.fixture()
def store() -> InMemoryStore:
    """Bare InMemoryStore for consolidation tests."""
    return InMemoryStore()


@pytest.fixture()
def engine() -> ConsolidationEngine:
    """ConsolidationEngine with sensible test defaults."""
    return ConsolidationEngine(
        decay_rate=0.05,
        similarity_threshold=0.7,
        min_access_count=0,
    )


# =====================================================================
# AegisMemory tests
# =====================================================================


class TestAegisMemoryConstructor:
    """Constructor and property tests."""

    def test_domain_set(self, mem: AegisMemory) -> None:
        assert mem.domain == "legal"

    def test_customer_id_set(self, mem: AegisMemory) -> None:
        assert mem.customer_id == "sterling"

    def test_agent_id_set(self, mem: AegisMemory) -> None:
        assert mem._agent_id == "agent-1"

    def test_defaults(self) -> None:
        m = AegisMemory(enable_vectors=False)
        assert m.domain == "general"
        assert m.customer_id == "default"
        assert m._agent_id == "default"


class TestAegisMemoryStore:
    """store() method."""

    def test_store_returns_memory_entry(self, mem: AegisMemory) -> None:
        entry = mem.store("k1", "hello world")
        assert isinstance(entry, MemoryEntry)

    def test_store_sets_key_and_value(self, mem: AegisMemory) -> None:
        entry = mem.store("k1", "hello world")
        assert entry.key == "k1"
        assert entry.value == "hello world"

    def test_store_respects_tier(self, mem: AegisMemory) -> None:
        entry = mem.store("k1", "v", tier=MemoryTier.PERMANENT)
        assert entry.tier == MemoryTier.PERMANENT

    def test_store_respects_confidence(self, mem: AegisMemory) -> None:
        entry = mem.store("k1", "v", confidence=0.8)
        assert entry.confidence == pytest.approx(0.8)

    def test_store_respects_tags(self, mem: AegisMemory) -> None:
        entry = mem.store("k1", "v", tags=["contract", "liability"])
        assert entry.tags == ["contract", "liability"]


class TestAegisMemoryRetrieve:
    """retrieve() method."""

    def test_retrieve_existing(self, mem: AegisMemory) -> None:
        mem.store("k1", "value-1")
        assert mem.retrieve("k1") == "value-1"

    def test_retrieve_missing_returns_none(self, mem: AegisMemory) -> None:
        assert mem.retrieve("nonexistent") is None


class TestAegisMemoryGet:
    """get() method with default fallback."""

    def test_get_existing(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        assert mem.get("k1") == "v1"

    def test_get_missing_returns_default(self, mem: AegisMemory) -> None:
        assert mem.get("nope", "fallback") == "fallback"

    def test_get_missing_returns_none_by_default(self, mem: AegisMemory) -> None:
        assert mem.get("nope") is None


class TestAegisMemoryUpdate:
    """update() method."""

    def test_update_existing_returns_true(self, mem: AegisMemory) -> None:
        mem.store("k1", "old")
        assert mem.update("k1", "new") is True

    def test_update_missing_returns_false(self, mem: AegisMemory) -> None:
        assert mem.update("missing", "v") is False


class TestAegisMemoryForget:
    """forget() method."""

    def test_forget_existing_returns_true(self, mem: AegisMemory) -> None:
        mem.store("k1", "val")
        assert mem.forget("k1") is True

    def test_forget_missing_returns_false(self, mem: AegisMemory) -> None:
        assert mem.forget("ghost") is False


class TestAegisMemorySearch:
    """search() method — returns list of dicts."""

    def test_search_returns_list(self, mem: AegisMemory) -> None:
        mem.store("k1", "contract clause about liability")
        results = mem.search("liability")
        assert isinstance(results, list)

    def test_search_result_has_correct_keys(self, mem: AegisMemory) -> None:
        mem.store("k1", "contract clause about liability")
        results = mem.search("liability")
        # search delegates to vector store; with vectors disabled the result
        # set may be empty, so we only assert structure when non-empty.
        for r in results:
            assert set(r.keys()) == {"key", "value", "tier", "confidence"}


class TestAegisMemoryLink:
    """link() method."""

    def test_link_existing_entries(self, mem: AegisMemory) -> None:
        mem.store("a", "first")
        mem.store("b", "second")
        result = mem.link("a", "b", relation="cites")
        assert isinstance(result, bool)


class TestAegisMemoryPromote:
    """promote() method."""

    def test_promote_existing_entry(self, mem: AegisMemory) -> None:
        mem.store("k1", "val", tier=MemoryTier.SESSION)
        result = mem.promote("k1", MemoryTier.PERMANENT)
        assert isinstance(result, bool)


class TestAegisMemoryHealth:
    """health() method."""

    def test_health_returns_dict_with_expected_keys(self, mem: AegisMemory) -> None:
        h = mem.health()
        assert "total_entries" in h
        assert "tier_counts" in h
        assert "event_log_size" in h
        assert "integrity_ok" in h

    def test_health_reflects_stored_entries(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        mem.store("k2", "v2")
        h = mem.health()
        assert h["total_entries"] >= 2


class TestAegisMemoryAuditTrail:
    """audit_trail() method."""

    def test_audit_trail_returns_list_of_dicts(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        trail = mem.audit_trail()
        assert isinstance(trail, list)
        assert len(trail) >= 1

    def test_audit_trail_dict_has_correct_keys(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        trail = mem.audit_trail()
        expected_keys = {"event_id", "operation", "key", "timestamp", "agent_id", "customer_id"}
        for event in trail:
            assert set(event.keys()) == expected_keys


class TestAegisMemorySnapshotAt:
    """snapshot_at() method."""

    def test_snapshot_returns_dict_with_expected_keys(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        snap = mem.snapshot_at(datetime.now(UTC) + timedelta(seconds=1))
        assert "timestamp" in snap
        assert "entries" in snap
        assert "num_entries" in snap


class TestAegisMemoryDunder:
    """__contains__ and __repr__."""

    def test_contains_true_after_store(self, mem: AegisMemory) -> None:
        mem.store("k1", "v1")
        assert "k1" in mem

    def test_contains_false_for_missing(self, mem: AegisMemory) -> None:
        assert "missing" not in mem

    def test_repr_includes_domain(self, mem: AegisMemory) -> None:
        r = repr(mem)
        assert "legal" in r

    def test_repr_includes_customer_id(self, mem: AegisMemory) -> None:
        r = repr(mem)
        assert "sterling" in r


class TestAegisMemoryRoundtrips:
    """End-to-end store/update/forget round-trip scenarios."""

    def test_store_then_retrieve(self, mem: AegisMemory) -> None:
        mem.store("round", "trip")
        assert mem.retrieve("round") == "trip"

    def test_store_update_retrieve(self, mem: AegisMemory) -> None:
        mem.store("k", "old")
        mem.update("k", "new")
        assert mem.retrieve("k") == "new"

    def test_store_forget_retrieve_returns_none(self, mem: AegisMemory) -> None:
        mem.store("k", "v")
        mem.forget("k")
        assert mem.retrieve("k") is None

    def test_multiple_stores_and_retrieves(self, mem: AegisMemory) -> None:
        for i in range(5):
            mem.store(f"key-{i}", f"value-{i}")
        for i in range(5):
            assert mem.retrieve(f"key-{i}") == f"value-{i}"


# =====================================================================
# ConsolidationResult tests
# =====================================================================


class TestConsolidationResult:
    """ConsolidationResult dataclass defaults."""

    def test_defaults(self) -> None:
        r = ConsolidationResult()
        assert r.entries_processed == 0
        assert r.entries_compressed == 0
        assert r.entries_decayed == 0
        assert r.links_discovered == 0
        assert r.contradictions_found == 0
        assert r.patterns_abstracted == 0
        assert r.completed_at is None
        assert isinstance(r.details, dict)
        assert isinstance(r.started_at, datetime)


# =====================================================================
# ConsolidationEngine tests
# =====================================================================


class TestConsolidationEmpty:
    """Consolidation on an empty store."""

    def test_consolidate_empty_store_returns_zeros(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        result = engine.consolidate(store)
        assert result.entries_processed == 0
        assert result.entries_compressed == 0
        assert result.entries_decayed == 0
        assert result.links_discovered == 0
        assert result.contradictions_found == 0
        assert result.patterns_abstracted == 0


class TestConsolidationDecay:
    """Decay step: confidence reduction for unaccessed entries."""

    def test_decay_lowers_confidence(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        entry = MemoryEntry(key="dec1", value="some text", confidence=0.9)
        store.store(entry)

        result = engine.consolidate(store)

        assert result.entries_decayed >= 1
        updated = store.retrieve("dec1")
        assert updated is not None
        assert updated.confidence < 0.9

    def test_decay_skips_frequently_accessed(self, store: InMemoryStore) -> None:
        """Entries with access_count above min_access_count are NOT decayed."""
        engine = ConsolidationEngine(
            decay_rate=0.05,
            similarity_threshold=0.7,
            min_access_count=2,
        )
        entry = MemoryEntry(
            key="active",
            value="important info",
            confidence=0.9,
            metadata={"access_count": 5},
        )
        store.store(entry)

        result = engine.consolidate(store)

        assert result.entries_decayed == 0
        updated = store.retrieve("active")
        assert updated is not None
        # Confidence should remain unchanged (store.retrieve increments
        # access_count but does not change confidence).
        assert updated.confidence == pytest.approx(0.9)


class TestConsolidationCompression:
    """Compression step: long entries get truncated."""

    def test_compress_long_entry(self, engine: ConsolidationEngine, store: InMemoryStore) -> None:
        long_text = " ".join(f"word{i}" for i in range(250))
        entry = MemoryEntry(key="long", value=long_text, confidence=0.5)
        store.store(entry)

        result = engine.consolidate(store)

        assert result.entries_compressed >= 1
        updated = store.retrieve("long")
        assert updated is not None
        assert "[...]" in str(updated.value)
        assert updated.metadata.get("compressed") is True
        assert updated.metadata.get("original_word_count") == 250

    def test_no_compress_short_entry(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        entry = MemoryEntry(key="short", value="brief text", confidence=0.5)
        store.store(entry)

        result = engine.consolidate(store)

        assert result.entries_compressed == 0
        updated = store.retrieve("short")
        assert updated is not None
        assert "[...]" not in str(updated.value)


class TestConsolidationLinkDiscovery:
    """Link discovery step: similar entries get discovered_links metadata."""

    def test_similar_entries_get_links(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        # Two entries with highly similar values (identical, in fact).
        common_text = "the contract liability clause specifies indemnification terms and conditions"
        entry_a = MemoryEntry(key="a", value=common_text, confidence=0.9)
        entry_b = MemoryEntry(key="b", value=common_text, confidence=0.9)
        store.store(entry_a)
        store.store(entry_b)

        result = engine.consolidate(store)

        assert result.links_discovered >= 1
        # At least one of the entries should have discovered_links in metadata.
        refreshed_a = store.retrieve("a")
        refreshed_b = store.retrieve("b")
        links_a = refreshed_a.metadata.get("discovered_links", []) if refreshed_a else []
        links_b = refreshed_b.metadata.get("discovered_links", []) if refreshed_b else []
        assert "b" in links_a or "a" in links_b

    def test_dissimilar_entries_get_no_links(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        entry_a = MemoryEntry(
            key="x",
            value="the weather today is very sunny and warm with clear skies",
            confidence=0.9,
        )
        entry_b = MemoryEntry(
            key="y",
            value="quantum computing leverages superposition and entanglement for parallel computation",
            confidence=0.9,
        )
        store.store(entry_a)
        store.store(entry_b)

        result = engine.consolidate(store)

        assert result.links_discovered == 0


class TestConsolidationContradiction:
    """Contradiction detection step."""

    def test_negation_conflict_flagged(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        # Two entries with the same key prefix, one positive and one negated.
        entry_pos = MemoryEntry(
            key="policy_active",
            value="the policy is currently active and enforceable in this jurisdiction",
            confidence=0.9,
        )
        entry_neg = MemoryEntry(
            key="policy_expired",
            value="the policy is not currently active and not enforceable in this jurisdiction",
            confidence=0.9,
        )
        store.store(entry_pos)
        store.store(entry_neg)

        result = engine.consolidate(store)

        assert result.contradictions_found >= 1
        refreshed_pos = store.retrieve("policy_active")
        refreshed_neg = store.retrieve("policy_expired")
        assert refreshed_pos is not None
        assert refreshed_neg is not None
        has_flag = (
            "potential_contradiction" in refreshed_pos.metadata
            or "potential_contradiction" in refreshed_neg.metadata
        )
        assert has_flag

    def test_non_conflicting_entries_not_flagged(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        entry_a = MemoryEntry(
            key="info_one",
            value="the company was founded in two thousand and ten",
            confidence=0.9,
        )
        entry_b = MemoryEntry(
            key="info_two",
            value="the company was founded in two thousand and ten",
            confidence=0.9,
        )
        store.store(entry_a)
        store.store(entry_b)

        result = engine.consolidate(store)

        assert result.contradictions_found == 0


class TestConsolidationPatternAbstraction:
    """Pattern abstraction step: 3+ entries with same tag and common words."""

    def test_pattern_abstraction_with_common_tag(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        # Three entries sharing a tag and at least 5 common words.
        common_phrase = "the standard contract clause requires written consent and formal approval from authorized representatives"
        for i in range(3):
            entry = MemoryEntry(
                key=f"clause_{i}",
                value=f"{common_phrase} variant {i}",
                tags=["contract"],
                confidence=0.9,
            )
            store.store(entry)

        result = engine.consolidate(store)

        assert result.patterns_abstracted >= 1
        # The first entry in the group should have abstracted_patterns metadata.
        first = store.retrieve("clause_0")
        assert first is not None
        patterns = first.metadata.get("abstracted_patterns", [])
        assert len(patterns) >= 1
        assert patterns[0]["tag"] == "contract"
        assert patterns[0]["source_count"] == 3

    def test_no_pattern_with_few_entries(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        """Fewer than 3 entries with the same tag should not produce patterns."""
        for i in range(2):
            entry = MemoryEntry(
                key=f"item_{i}",
                value="some shared common content here",
                tags=["rare"],
                confidence=0.9,
            )
            store.store(entry)

        result = engine.consolidate(store)

        assert result.patterns_abstracted == 0


class TestConsolidationFullPipeline:
    """Full consolidation pipeline runs all steps."""

    def test_full_pipeline_returns_complete_result(
        self, engine: ConsolidationEngine, store: InMemoryStore
    ) -> None:
        # Populate store with a mix of entries that exercise every step.
        # Long entry for compression.
        long_text = " ".join(f"word{i}" for i in range(250))
        store.store(MemoryEntry(key="long_entry", value=long_text, confidence=0.8))

        # Similar entries for link discovery.
        similar = "the contractual obligation requires compliance with regulatory standards across all jurisdictions"
        store.store(MemoryEntry(key="sim_a", value=similar, confidence=0.9))
        store.store(MemoryEntry(key="sim_b", value=similar, confidence=0.9))

        # Tagged entries for pattern abstraction.
        pattern_text = "the standard operating procedure mandates formal review and written approval before execution"
        for i in range(3):
            store.store(
                MemoryEntry(
                    key=f"sop_{i}",
                    value=f"{pattern_text} revision {i}",
                    tags=["sop"],
                    confidence=0.7,
                )
            )

        result = engine.consolidate(store)

        # All counters should be populated.
        assert result.entries_processed >= 6
        assert result.entries_compressed >= 1
        assert result.entries_decayed >= 1
        assert result.links_discovered >= 1
        assert result.patterns_abstracted >= 1
        assert isinstance(result.details, dict)

    def test_completed_at_is_set(self, engine: ConsolidationEngine, store: InMemoryStore) -> None:
        store.store(MemoryEntry(key="z", value="data", confidence=0.9))
        result = engine.consolidate(store)
        assert result.completed_at is not None
        assert isinstance(result.completed_at, datetime)
        assert result.completed_at >= result.started_at
