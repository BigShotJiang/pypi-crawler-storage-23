"""Repository-level guardrail against committing hardcoded secrets."""

from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCAN_ROOTS = [
    REPO_ROOT / "src",
    REPO_ROOT / "scripts",
    REPO_ROOT / "infra",
]
EXCLUDED_DIRS = {
    ".git",
    ".venv",
    ".mypy_cache",
    ".ruff_cache",
    "__pycache__",
    "node_modules",
    "site",
    "checkpoints",
}
MAX_FILE_SIZE_BYTES = 512 * 1024
TEXT_EXTENSIONS = {
    ".py",
    ".sh",
    ".yml",
    ".yaml",
    ".toml",
    ".json",
    ".md",
    ".txt",
}

SECRET_PATTERNS: dict[str, re.Pattern[str]] = {
    "aws_access_key": re.compile(r"AKIA[0-9A-Z]{16}"),
    "google_api_key": re.compile(r"AIza[0-9A-Za-z_\-]{35}"),
    "openai_like_key": re.compile(r"sk-[A-Za-z0-9]{20,}"),
    "slack_token": re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,}"),
    "private_key_header": re.compile(r"-----BEGIN (?:RSA|EC|OPENSSH) PRIVATE KEY-----"),
}

ALLOWLIST_SUBSTRINGS = {
    "example",
    "placeholder",
    "dummy",
    "test",
    "fake",
}


def _iter_text_files() -> list[Path]:
    files: list[Path] = []
    for root in SCAN_ROOTS:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in EXCLUDED_DIRS for part in path.parts):
                continue
            if path.suffix.lower() not in TEXT_EXTENSIONS:
                continue
            if path.stat().st_size > MAX_FILE_SIZE_BYTES:
                continue
            files.append(path)
    return files


def _is_allowed(match_text: str) -> bool:
    lowered = match_text.lower()
    return any(token in lowered for token in ALLOWLIST_SUBSTRINGS)


def test_no_hardcoded_secrets_in_repo_sources() -> None:
    findings: list[str] = []

    for path in _iter_text_files():
        text = path.read_text(encoding="utf-8", errors="ignore")
        for name, pattern in SECRET_PATTERNS.items():
            for match in pattern.finditer(text):
                matched_text = match.group(0)
                if _is_allowed(matched_text):
                    continue
                preview = matched_text[:12] + ("..." if len(matched_text) > 12 else "")
                findings.append(
                    f"{path.relative_to(REPO_ROOT)} [{name}] token={preview} line={text.count(chr(10), 0, match.start()) + 1}"
                )

    assert not findings, "Potential hardcoded secrets found:\n" + "\n".join(findings)
