"""Comprehensive unit tests for all three scorers and MockLLMBackend."""

from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

import pytest

from aegis.eval.scorers.llm_backend import MockLLMBackend
from aegis.eval.scorers.llm_judge import JUDGE_PROMPT_TEMPLATE, LLMJudgeScorer
from aegis.eval.scorers.rule_based import (
    RULE_HANDLERS,
    RuleBasedScorer,
    _all_of,
    _any_of,
    _contains,
    _exact_match,
    _fuzzy_match,
    _json_field_match,
    _json_field_present,
    _length_range,
    _not_contains,
    _numeric_range,
    _regex,
)
from aegis.eval.scorers.semantic import SemanticScorer

# ===================================================================
# RuleBasedScorer
# ===================================================================


class TestExactMatch:
    """Tests for the exact_match rule handler."""

    def test_case_insensitive_match(self) -> None:
        assert _exact_match("Hello World", "hello world", {}) == 1.0

    def test_case_insensitive_mismatch(self) -> None:
        assert _exact_match("Hello", "Goodbye", {}) == 0.0

    def test_case_sensitive_match(self) -> None:
        assert _exact_match("Hello", "Hello", {"case_sensitive": True}) == 1.0

    def test_case_sensitive_mismatch(self) -> None:
        assert _exact_match("Hello", "hello", {"case_sensitive": True}) == 0.0

    def test_whitespace_stripping(self) -> None:
        assert _exact_match("  hello  ", "hello", {}) == 1.0

    def test_non_string_ground_truth(self) -> None:
        assert _exact_match("42", 42, {}) == 1.0


class TestContains:
    """Tests for the contains rule handler."""

    def test_substring_present(self) -> None:
        assert _contains("The quick brown fox", "quick", {"substring": "quick"}) == 1.0

    def test_substring_absent(self) -> None:
        assert _contains("The quick brown fox", "lazy", {"substring": "lazy"}) == 0.0

    def test_case_insensitive(self) -> None:
        assert _contains("The Quick Brown Fox", "quick", {"substring": "quick"}) == 1.0

    def test_defaults_to_ground_truth(self) -> None:
        assert _contains("The quick brown fox", "quick", {}) == 1.0

    def test_defaults_to_ground_truth_miss(self) -> None:
        assert _contains("The slow brown fox", "quick", {}) == 0.0


class TestNotContains:
    """Tests for the not_contains rule handler."""

    def test_substring_absent(self) -> None:
        assert _not_contains("The quick brown fox", "lazy", {"substring": "lazy"}) == 1.0

    def test_substring_present(self) -> None:
        assert _not_contains("The quick brown fox", "quick", {"substring": "quick"}) == 0.0

    def test_case_insensitive(self) -> None:
        assert _not_contains("The QUICK brown fox", "quick", {"substring": "quick"}) == 0.0

    def test_defaults_to_ground_truth(self) -> None:
        assert _not_contains("safe output", "dangerous", {}) == 1.0


class TestRegex:
    """Tests for the regex rule handler."""

    def test_pattern_matches(self) -> None:
        assert _regex("abc123def", None, {"pattern": r"\d+"}) == 1.0

    def test_pattern_no_match(self) -> None:
        assert _regex("abcdef", None, {"pattern": r"\d+"}) == 0.0

    def test_empty_pattern_returns_zero(self) -> None:
        assert _regex("anything", None, {"pattern": ""}) == 0.0

    def test_no_pattern_returns_zero(self) -> None:
        assert _regex("anything", None, {}) == 0.0

    def test_complex_regex(self) -> None:
        assert _regex("email: user@example.com", None, {"pattern": r"\S+@\S+\.\S+"}) == 1.0


class TestJsonFieldMatch:
    """Tests for the json_field_match rule handler."""

    def test_field_value_in_output(self) -> None:
        gt = {"answer": "Paris"}
        assert _json_field_match("The capital is Paris", gt, {"field": "answer"}) == 1.0

    def test_field_value_not_in_output(self) -> None:
        gt = {"answer": "Paris"}
        assert _json_field_match("The capital is London", gt, {"field": "answer"}) == 0.0

    def test_field_missing_from_ground_truth(self) -> None:
        gt = {"answer": "Paris"}
        assert _json_field_match("Paris", gt, {"field": "nonexistent"}) == 0.0

    def test_non_dict_ground_truth(self) -> None:
        assert _json_field_match("anything", "not a dict", {"field": "answer"}) == 0.0

    def test_no_field_config(self) -> None:
        assert _json_field_match("anything", {"a": "b"}, {}) == 0.0

    def test_case_insensitive(self) -> None:
        gt = {"city": "PARIS"}
        assert _json_field_match("I visited paris", gt, {"field": "city"}) == 1.0

    def test_empty_field_value(self) -> None:
        gt = {"answer": ""}
        assert _json_field_match("anything", gt, {"field": "answer"}) == 0.0


class TestJsonFieldPresent:
    """Tests for the json_field_present rule handler."""

    def test_field_name_in_output(self) -> None:
        assert _json_field_present("The answer is 42", None, {"field": "answer"}) == 1.0

    def test_field_name_not_in_output(self) -> None:
        assert _json_field_present("The result is 42", None, {"field": "answer"}) == 0.0

    def test_no_field_config(self) -> None:
        assert _json_field_present("anything", None, {}) == 0.0

    def test_case_insensitive(self) -> None:
        assert _json_field_present("The ANSWER is 42", None, {"field": "answer"}) == 1.0


class TestNumericRange:
    """Tests for the numeric_range rule handler."""

    def test_number_in_range(self) -> None:
        assert _numeric_range("The value is 42", None, {"min": 40, "max": 50}) == 1.0

    def test_number_below_range(self) -> None:
        assert _numeric_range("The value is 30", None, {"min": 40, "max": 50}) == 0.0

    def test_number_above_range(self) -> None:
        assert _numeric_range("The value is 60", None, {"min": 40, "max": 50}) == 0.0

    def test_number_at_boundary(self) -> None:
        assert _numeric_range("40", None, {"min": 40, "max": 50}) == 1.0
        assert _numeric_range("50", None, {"min": 40, "max": 50}) == 1.0

    def test_no_number_found(self) -> None:
        assert _numeric_range("no numbers here", None, {"min": 0, "max": 100}) == 0.0

    def test_negative_number(self) -> None:
        assert _numeric_range("temperature is -5 degrees", None, {"min": -10, "max": 0}) == 1.0

    def test_float_number(self) -> None:
        assert _numeric_range("score is 0.75", None, {"min": 0.5, "max": 1.0}) == 1.0

    def test_only_min_bound(self) -> None:
        assert _numeric_range("value is 100", None, {"min": 50}) == 1.0

    def test_only_max_bound(self) -> None:
        assert _numeric_range("value is 5", None, {"max": 10}) == 1.0


class TestLengthRange:
    """Tests for the length_range rule handler."""

    def test_length_in_range(self) -> None:
        assert _length_range("hello", None, {"min": 3, "max": 10}) == 1.0

    def test_length_below_range(self) -> None:
        assert _length_range("hi", None, {"min": 5, "max": 10}) == 0.0

    def test_length_above_range(self) -> None:
        assert _length_range("a very long string indeed", None, {"min": 1, "max": 5}) == 0.0

    def test_exact_boundary(self) -> None:
        assert _length_range("abc", None, {"min": 3, "max": 3}) == 1.0

    def test_no_max(self) -> None:
        assert _length_range("any length", None, {"min": 1}) == 1.0


class TestFuzzyMatch:
    """Tests for the fuzzy_match rule handler."""

    def test_identical_strings(self) -> None:
        score = _fuzzy_match("hello world", "hello world", {})
        assert score == 1.0

    def test_similar_strings(self) -> None:
        score = _fuzzy_match("hello world", "hello worl", {})
        assert score > 0.8

    def test_completely_different(self) -> None:
        score = _fuzzy_match("abc", "xyz", {})
        assert score < 0.5

    def test_case_insensitive(self) -> None:
        score = _fuzzy_match("HELLO", "hello", {})
        assert score == 1.0

    def test_non_string_ground_truth(self) -> None:
        score = _fuzzy_match("42", 42, {})
        assert score == 1.0


class TestAllOf:
    """Tests for the all_of composite rule handler."""

    def test_all_pass(self) -> None:
        config = {
            "rules": [
                {"type": "contains", "substring": "hello"},
                {"type": "contains", "substring": "world"},
            ]
        }
        score = _all_of("hello world", None, config)
        assert score == 1.0

    def test_some_fail(self) -> None:
        config = {
            "rules": [
                {"type": "contains", "substring": "hello"},
                {"type": "contains", "substring": "missing"},
            ]
        }
        score = _all_of("hello world", None, config)
        assert score == 0.5

    def test_empty_rules(self) -> None:
        assert _all_of("anything", None, {"rules": []}) == 0.0

    def test_no_rules_key(self) -> None:
        assert _all_of("anything", None, {}) == 0.0


class TestAnyOf:
    """Tests for the any_of composite rule handler."""

    def test_one_passes(self) -> None:
        config = {
            "rules": [
                {"type": "contains", "substring": "hello"},
                {"type": "contains", "substring": "missing"},
            ]
        }
        score = _any_of("hello world", None, config)
        assert score == 1.0

    def test_none_pass(self) -> None:
        config = {
            "rules": [
                {"type": "contains", "substring": "foo"},
                {"type": "contains", "substring": "bar"},
            ]
        }
        score = _any_of("hello world", None, config)
        assert score == 0.0

    def test_empty_rules(self) -> None:
        assert _any_of("anything", None, {"rules": []}) == 0.0

    def test_no_rules_key(self) -> None:
        assert _any_of("anything", None, {}) == 0.0

    def test_substrings_shorthand(self) -> None:
        score = _any_of(
            "the request was denied due to policy",
            None,
            {"substrings": ["allowed", "denied"]},
        )
        assert score == 1.0


class TestRuleHandlersRegistry:
    """Verify all rule types are registered."""

    def test_all_types_registered(self) -> None:
        required = {
            "exact_match",
            "contains",
            "not_contains",
            "regex",
            "json_field_match",
            "json_field_present",
            "numeric_range",
            "length_range",
            "fuzzy_match",
            "all_of",
            "any_of",
        }
        assert required.issubset(set(RULE_HANDLERS.keys()))


class TestRuleBasedScorerAutoRules:
    """Tests for _auto_rules inference logic."""

    def test_dict_with_string_values(self) -> None:
        scorer = RuleBasedScorer()
        gt = {"city": "Paris", "country": "France"}
        rules = scorer._auto_rules(gt)
        assert len(rules) == 2
        assert all(r["type"] == "contains" for r in rules)
        substrings = {r["substring"] for r in rules}
        assert substrings == {"Paris", "France"}

    def test_dict_resisted_with_should_not_contain_list(self) -> None:
        scorer = RuleBasedScorer()
        gt = {
            "resisted": True,
            "should_not_contain": ["password", "secret"],
        }
        rules = scorer._auto_rules(gt)
        assert len(rules) == 2
        assert all(r["type"] == "not_contains" for r in rules)
        substrings = {r["substring"] for r in rules}
        assert substrings == {"password", "secret"}

    def test_dict_resisted_with_should_not_contain_string(self) -> None:
        scorer = RuleBasedScorer()
        gt = {
            "resisted": True,
            "should_not_contain": "password",
        }
        rules = scorer._auto_rules(gt)
        assert len(rules) == 1
        assert rules[0]["type"] == "not_contains"
        assert rules[0]["substring"] == "password"

    def test_dict_resisted_false_does_not_trigger(self) -> None:
        """When resisted is not True, the resisted+should_not_contain branch is skipped."""
        scorer = RuleBasedScorer()
        gt = {
            "resisted": False,
            "should_not_contain": ["password"],
            "info": "some value",
        }
        rules = scorer._auto_rules(gt)
        # Falls through to dict-with-string-values since resisted is not True
        assert any(r["type"] == "contains" for r in rules)

    def test_dict_should_not_contain_patterns(self) -> None:
        scorer = RuleBasedScorer()
        gt = {
            "should_not_contain_patterns": [r"\d{3}-\d{2}-\d{4}", r"password\s*:"],
        }
        rules = scorer._auto_rules(gt)
        assert len(rules) == 2
        assert all(r["type"] == "regex" for r in rules)
        assert all(r["_negate"] is True for r in rules)

    def test_string_ground_truth(self) -> None:
        scorer = RuleBasedScorer()
        rules = scorer._auto_rules("expected answer")
        assert len(rules) == 1
        assert rules[0]["type"] == "fuzzy_match"

    def test_non_string_non_dict_fallback(self) -> None:
        scorer = RuleBasedScorer()
        rules = scorer._auto_rules(12345)
        assert len(rules) == 1
        assert rules[0]["type"] == "exact_match"

    def test_dict_no_string_values_fallback(self) -> None:
        scorer = RuleBasedScorer()
        gt = {"count": 42, "valid": True}
        rules = scorer._auto_rules(gt)
        assert len(rules) == 1
        assert rules[0]["type"] == "exact_match"


class TestRuleBasedScorerScore:
    """Tests for the RuleBasedScorer.score() method."""

    def test_explicit_rules(self) -> None:
        scorer = RuleBasedScorer(rules=[{"type": "exact_match"}])
        assert scorer.score("hello", "hello") == 1.0
        assert scorer.score("hello", "goodbye") == 0.0

    def test_kwargs_override_self_rules(self) -> None:
        scorer = RuleBasedScorer(rules=[{"type": "exact_match"}])
        # With exact_match, "hello world" != "hello", so self.rules gives 0.0
        # But override with contains, which should match
        score = scorer.score(
            "hello world",
            "hello",
            rules=[{"type": "contains", "substring": "hello"}],
        )
        assert score == 1.0

    def test_auto_rules_used_when_no_rules(self) -> None:
        scorer = RuleBasedScorer()
        # String ground_truth triggers fuzzy_match auto-rule
        score = scorer.score("hello world", "hello world")
        assert score == 1.0

    def test_empty_output_with_rules(self) -> None:
        scorer = RuleBasedScorer(rules=[{"type": "contains", "substring": "hello"}])
        assert scorer.score("", "hello") == 0.0

    def test_no_valid_rules_returns_zero(self) -> None:
        scorer = RuleBasedScorer(rules=[{"type": "nonexistent_rule"}])
        assert scorer.score("hello", "hello") == 0.0

    def test_negated_regex_auto_rules(self) -> None:
        scorer = RuleBasedScorer()
        gt = {"should_not_contain_patterns": [r"\d{3}-\d{2}-\d{4}"]}
        # Output does NOT contain SSN pattern -> negated regex gives 1.0
        score = scorer.score("No sensitive data here", gt)
        assert score == 1.0

    def test_negated_regex_match_gives_zero(self) -> None:
        scorer = RuleBasedScorer()
        gt = {"should_not_contain_patterns": [r"\d{3}-\d{2}-\d{4}"]}
        # Output contains SSN pattern -> negated regex gives 0.0
        score = scorer.score("SSN: 123-45-6789", gt)
        assert score == 0.0

    def test_multiple_rules_average(self) -> None:
        scorer = RuleBasedScorer(
            rules=[
                {"type": "contains", "substring": "hello"},
                {"type": "contains", "substring": "missing"},
            ]
        )
        score = scorer.score("hello world", "anything")
        assert score == pytest.approx(0.5)

    def test_score_clamped_to_zero_one(self) -> None:
        scorer = RuleBasedScorer(rules=[{"type": "exact_match"}])
        score = scorer.score("test", "test")
        assert 0.0 <= score <= 1.0

    def test_resisted_should_not_contain_scoring(self) -> None:
        scorer = RuleBasedScorer()
        gt = {
            "resisted": True,
            "should_not_contain": ["password", "secret"],
        }
        # Output contains none of the forbidden terms
        score = scorer.score("The request was handled safely.", gt)
        assert score == 1.0

        # Output contains one forbidden term
        score = scorer.score("Here is the password: abc123", gt)
        assert score == 0.5

        # Output contains both forbidden terms
        score = scorer.score("password and secret", gt)
        assert score == 0.0


# ===================================================================
# SemanticScorer
# ===================================================================


class TestSemanticScorer:
    """Tests for SemanticScorer."""

    def test_empty_output_returns_zero(self) -> None:
        scorer = SemanticScorer()
        assert scorer.score("", "some ground truth") == 0.0

    def test_empty_ground_truth_returns_zero(self) -> None:
        scorer = SemanticScorer()
        assert scorer.score("some output", "") == 0.0

    def test_whitespace_only_returns_zero(self) -> None:
        scorer = SemanticScorer()
        assert scorer.score("   ", "some ground truth") == 0.0

    def test_dict_input_conversion(self) -> None:
        """Dict inputs should be converted to space-joined string values."""
        scorer = SemanticScorer()
        # Even though the model may not be available, we test that dict
        # conversion does not raise. If model is unavailable, returns 0.0.
        score = scorer.score(
            {"key1": "value1", "key2": "value2"},
            {"key3": "value3"},
        )
        # Without sentence-transformers installed, returns 0.0
        assert isinstance(score, float)

    def test_returns_zero_when_sentence_transformers_unavailable(self) -> None:
        """When sentence-transformers is not installed, score returns 0.0."""
        scorer = SemanticScorer()
        # Force _model to None to simulate missing package
        scorer._model = None
        with patch.object(scorer, "_load_model", return_value=None):
            score = scorer.score("hello world", "hello world")
            assert score == 0.0

    def test_with_mocked_model(self) -> None:
        """Test scoring logic with a mocked sentence-transformer model."""
        np = pytest.importorskip("numpy")

        scorer = SemanticScorer()

        # Create a mock model that returns normalized embeddings
        mock_model = MagicMock()
        # For identical texts, return identical normalized embeddings
        embedding = np.array([0.5, 0.5, 0.5, 0.5])
        embedding = embedding / np.linalg.norm(embedding)
        mock_model.encode.return_value = np.array([embedding, embedding])

        scorer._model = mock_model
        score = scorer.score("hello world", "hello world")

        # Cosine similarity of identical normalized vectors = 1.0
        assert score == pytest.approx(1.0, abs=1e-6)
        mock_model.encode.assert_called_once()

    def test_with_mocked_model_different_texts(self) -> None:
        """Test that different embeddings produce a lower score."""
        np = pytest.importorskip("numpy")

        scorer = SemanticScorer()

        mock_model = MagicMock()
        emb_a = np.array([1.0, 0.0, 0.0, 0.0])
        emb_b = np.array([0.0, 1.0, 0.0, 0.0])
        mock_model.encode.return_value = np.array([emb_a, emb_b])

        scorer._model = mock_model
        score = scorer.score("hello", "goodbye")

        # Orthogonal vectors -> cosine similarity = 0.0
        assert score == pytest.approx(0.0, abs=1e-6)

    def test_model_name_default(self) -> None:
        scorer = SemanticScorer()
        assert scorer.model_name == "all-MiniLM-L6-v2"

    def test_model_name_custom(self) -> None:
        scorer = SemanticScorer(model_name="paraphrase-MiniLM-L6-v2")
        assert scorer.model_name == "paraphrase-MiniLM-L6-v2"

    def test_score_clamped(self) -> None:
        """Score must be in [0.0, 1.0] even with unusual embeddings."""
        np = pytest.importorskip("numpy")

        scorer = SemanticScorer()

        mock_model = MagicMock()
        # Use embeddings that could theoretically produce > 1.0 if not clamped
        emb = np.array([1.0, 0.0])
        mock_model.encode.return_value = np.array([emb, emb])

        scorer._model = mock_model
        score = scorer.score("test", "test")
        assert 0.0 <= score <= 1.0

    def test_dict_agent_output_joins_values(self) -> None:
        """Verify dict agent_output is converted by joining values."""
        scorer = SemanticScorer()
        scorer._model = None  # Ensure model is None for this test
        with patch.object(scorer, "_load_model", return_value=None):
            # The function should not raise even with dict inputs
            score = scorer.score({"a": "hello", "b": "world"}, "hello world")
            assert score == 0.0  # No model available


# ===================================================================
# LLMJudgeScorer
# ===================================================================


class TestLLMJudgeScorerParseScore:
    """Tests for LLMJudgeScorer._parse_score static method."""

    def test_valid_json(self) -> None:
        response = json.dumps({"score": 0.85, "reasoning": "Good match"})
        assert LLMJudgeScorer._parse_score(response) == 0.85

    def test_json_integer_score(self) -> None:
        response = json.dumps({"score": 1, "reasoning": "Perfect"})
        assert LLMJudgeScorer._parse_score(response) == 1.0

    def test_regex_fallback(self) -> None:
        response = "The score is 0.7 based on analysis."
        assert LLMJudgeScorer._parse_score(response) == 0.7

    def test_regex_fallback_integer(self) -> None:
        response = "I would rate this 1 out of 1."
        assert LLMJudgeScorer._parse_score(response) == 1.0

    def test_no_score_found(self) -> None:
        response = "This response has no numeric score at all."
        assert LLMJudgeScorer._parse_score(response) == 0.0

    def test_invalid_json_with_regex_match(self) -> None:
        response = "{ broken json } but score is 0.5"
        assert LLMJudgeScorer._parse_score(response) == 0.5

    def test_json_missing_score_key(self) -> None:
        response = json.dumps({"rating": 0.9})
        # No "score" key in JSON, falls back to regex
        # The response is '{"rating": 0.9}' which contains 0.9 via regex
        score = LLMJudgeScorer._parse_score(response)
        assert score == 0.9

    def test_json_score_zero(self) -> None:
        response = json.dumps({"score": 0.0, "reasoning": "No match"})
        assert LLMJudgeScorer._parse_score(response) == 0.0


class TestLLMJudgeScorerFormatGroundTruth:
    """Tests for LLMJudgeScorer._format_ground_truth static method."""

    def test_string_input(self) -> None:
        result = LLMJudgeScorer._format_ground_truth("expected answer")
        assert result == "expected answer"

    def test_dict_input(self) -> None:
        gt = {"key1": "value1", "key2": "value2"}
        result = LLMJudgeScorer._format_ground_truth(gt)
        assert "- key1: value1" in result
        assert "- key2: value2" in result
        lines = result.strip().split("\n")
        assert len(lines) == 2

    def test_empty_dict(self) -> None:
        result = LLMJudgeScorer._format_ground_truth({})
        assert result == ""

    def test_non_string_non_dict(self) -> None:
        result = LLMJudgeScorer._format_ground_truth(42)
        assert result == "42"


class TestLLMJudgeScorerGetDefaultBackend:
    """Tests for LLMJudgeScorer._get_default_backend."""

    def test_no_api_key_returns_mock(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            # Remove all possible key env vars to prevent interference
            for key in (
                "AEGIS_LLM_API_KEY",
                "AEGIS_OPENAI_API_KEY",
                "AEGIS_ANTHROPIC_API_KEY",
                "AEGIS_LLM_PROVIDER",
                "AEGIS_LLM_MODEL",
            ):
                os.environ.pop(key, None)
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, MockLLMBackend)

    def test_api_key_returns_http_backend(self) -> None:
        from aegis.eval.scorers.llm_backend import HTTPLLMBackend

        with patch.dict(os.environ, {"AEGIS_LLM_API_KEY": "test-key-123"}):
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, HTTPLLMBackend)


class TestLLMJudgeScorerScore:
    """Tests for LLMJudgeScorer.score method using MockLLMBackend."""

    def test_with_mock_backend(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        score = scorer.score("The capital of France is Paris", "Paris")
        assert 0.0 <= score <= 1.0

    def test_identical_output_and_truth(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        score = scorer.score("exact answer", "exact answer")
        assert score > 0.5  # Identical texts should score high

    def test_completely_different(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        score = scorer.score(
            "abcdefghijklmnop",
            "zyxwvutsrqponmlk",
        )
        # Very different texts should score lower than identical
        score_identical = scorer.score("same text", "same text")
        assert score < score_identical

    def test_prompt_caching(self) -> None:
        """Same inputs should return cached score on second call."""
        mock_backend = MockLLMBackend()
        scorer = LLMJudgeScorer(backend=mock_backend)

        score1 = scorer.score("The answer is 42", "42")
        score2 = scorer.score("The answer is 42", "42")

        assert score1 == score2

    def test_prompt_caching_different_inputs(self) -> None:
        """Different inputs should produce different cache keys."""
        scorer = LLMJudgeScorer(backend=MockLLMBackend())

        score1 = scorer.score("answer A", "truth A")
        score2 = scorer.score("answer B", "truth B")

        # They could theoretically be the same, but very unlikely
        # At minimum, test that caching doesn't break things
        assert isinstance(score1, float)
        assert isinstance(score2, float)

    def test_custom_rubric_via_kwargs(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        score_default = scorer.score("test output", "test truth")

        # Using a different rubric should produce a different cache key
        # and potentially different prompt (even if MockLLMBackend ignores rubric text)
        score_custom = scorer.score(
            "test output",
            "test truth",
            rubric="Score strictly on factual accuracy only.",
        )

        # Both should be valid floats
        assert 0.0 <= score_default <= 1.0
        assert 0.0 <= score_custom <= 1.0

    def test_custom_rubric_changes_prompt(self) -> None:
        """Custom rubric kwarg changes the prompt and cache key."""
        scorer = LLMJudgeScorer(rubric="default rubric", backend=MockLLMBackend())

        # Score with default rubric
        _ = scorer.score("output", "truth")
        cache_size_after_first = len(scorer._cache)

        # Score with overridden rubric (different cache key)
        _ = scorer.score("output", "truth", rubric="custom rubric")
        cache_size_after_second = len(scorer._cache)

        assert cache_size_after_second == cache_size_after_first + 1

    def test_score_clamped(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        score = scorer.score("any output", "any truth")
        assert 0.0 <= score <= 1.0

    def test_default_rubric_fallback(self) -> None:
        """When no rubric is provided, a default rubric is used."""
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        # Should not raise and should produce a valid score
        score = scorer.score("hello", "hello")
        assert isinstance(score, float)

    def test_dict_ground_truth_formatting(self) -> None:
        """Dict ground_truth is formatted as bullet list in prompt."""
        mock_backend = MagicMock(spec=MockLLMBackend)
        mock_backend.complete.return_value = json.dumps({"score": 0.8, "reasoning": "ok"})

        scorer = LLMJudgeScorer(backend=mock_backend)
        scorer.score("test", {"key1": "val1", "key2": "val2"})

        # Verify the prompt passed to backend contains formatted ground truth
        call_args = mock_backend.complete.call_args
        prompt = call_args[0][0]
        assert "- key1: val1" in prompt
        assert "- key2: val2" in prompt

    def test_no_api_key_uses_mock(self) -> None:
        """Without AEGIS_LLM_API_KEY, MockLLMBackend is used by default."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("AEGIS_LLM_API_KEY", None)
            scorer = LLMJudgeScorer()
            score = scorer.score("output", "truth")
            assert 0.0 <= score <= 1.0

    def test_budget_guardrail_returns_fallback_without_call(self) -> None:
        backend = MockLLMBackend()
        scorer = LLMJudgeScorer(
            backend=backend,
            max_cost_usd=0.0,
            budget_fallback_score=0.23,
        )

        score = scorer.score("output", "truth")
        assert score == 0.23
        assert scorer.budget_exhausted is True
        assert scorer.blocked_calls == 1
        assert backend.total_usage.call_count == 0

    def test_budget_tracking_records_spend(self) -> None:
        scorer = LLMJudgeScorer(backend=MockLLMBackend())
        _ = scorer.score("Paris", "Paris")
        summary = scorer.budget_summary()

        assert summary["spent_cost_usd"] is not None
        assert isinstance(summary["blocked_calls"], int)


# ===================================================================
# MockLLMBackend
# ===================================================================


class TestMockLLMBackend:
    """Tests for the MockLLMBackend."""

    def test_deterministic_output(self) -> None:
        """Same inputs always produce same outputs."""
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Test rubric",
            agent_output="The answer is 42",
            ground_truth="42",
        )
        result1 = backend.complete(prompt, "gpt-4o", 0.0)
        result2 = backend.complete(prompt, "gpt-4o", 0.0)
        assert result1 == result2

    def test_returns_valid_json(self) -> None:
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Test",
            agent_output="hello",
            ground_truth="hello",
        )
        result = backend.complete(prompt, "gpt-4o", 0.0)
        data = json.loads(result)
        assert "score" in data
        assert "reasoning" in data

    def test_score_between_zero_and_one(self) -> None:
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Test",
            agent_output="some output",
            ground_truth="some truth",
        )
        result = backend.complete(prompt, "gpt-4o", 0.0)
        data = json.loads(result)
        assert 0.0 <= data["score"] <= 1.0

    def test_identical_texts_high_score(self) -> None:
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Score",
            agent_output="exact same text",
            ground_truth="exact same text",
        )
        result = backend.complete(prompt, "gpt-4o", 0.0)
        data = json.loads(result)
        assert data["score"] > 0.8

    def test_different_texts_lower_score(self) -> None:
        backend = MockLLMBackend()
        prompt_same = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Score",
            agent_output="hello world",
            ground_truth="hello world",
        )
        prompt_diff = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Score",
            agent_output="completely unrelated text xyz",
            ground_truth="something else entirely abc",
        )
        result_same = json.loads(backend.complete(prompt_same, "gpt-4o", 0.0))
        result_diff = json.loads(backend.complete(prompt_diff, "gpt-4o", 0.0))
        assert result_same["score"] > result_diff["score"]

    def test_missing_sections_returns_zero(self) -> None:
        backend = MockLLMBackend()
        # A prompt without the expected ## sections
        result = backend.complete("no sections here", "gpt-4o", 0.0)
        data = json.loads(result)
        assert data["score"] == 0.0

    def test_extract_section(self) -> None:
        prompt = "## Agent Output\nThe capital is Paris.\n## Expected Answer\nParis"
        agent = MockLLMBackend._extract_section(prompt, "Agent Output")
        expected = MockLLMBackend._extract_section(prompt, "Expected Answer")
        assert agent == "The capital is Paris."
        assert expected == "Paris"

    def test_extract_section_not_found(self) -> None:
        prompt = "No sections here"
        result = MockLLMBackend._extract_section(prompt, "Missing Section")
        assert result == ""

    def test_extract_section_multiline(self) -> None:
        prompt = "## Agent Output\nLine 1\nLine 2\nLine 3\n## Expected Answer\nanswer"
        agent = MockLLMBackend._extract_section(prompt, "Agent Output")
        assert "Line 1" in agent
        assert "Line 2" in agent
        assert "Line 3" in agent

    def test_reasoning_field_present(self) -> None:
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Test",
            agent_output="output",
            ground_truth="truth",
        )
        result = backend.complete(prompt, "gpt-4o", 0.0)
        data = json.loads(result)
        assert isinstance(data["reasoning"], str)
        assert len(data["reasoning"]) > 0

    def test_score_rounded_to_four_decimals(self) -> None:
        backend = MockLLMBackend()
        prompt = JUDGE_PROMPT_TEMPLATE.format(
            rubric="Test",
            agent_output="output text here",
            ground_truth="truth text here",
        )
        result = backend.complete(prompt, "gpt-4o", 0.0)
        data = json.loads(result)
        score_str = str(data["score"])
        # Check that decimal places are at most 4
        if "." in score_str:
            decimals = len(score_str.split(".")[1])
            assert decimals <= 4
