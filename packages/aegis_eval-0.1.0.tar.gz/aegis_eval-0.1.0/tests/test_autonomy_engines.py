"""Tests for autonomy trust and escalation engines."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, cast

import pytest

from aegis.autonomy.escalation import (
    EscalationEngine,
    EscalationEvent,
    EscalationPolicy,
    EscalationReason,
)
from aegis.autonomy.trust import TrustConfig, TrustEngine, TrustLevel


class TestTrustEngine:
    def test_register_agent_idempotent(self) -> None:
        engine = TrustEngine()
        first = engine.register_agent("agent-1")
        second = engine.register_agent("agent-1")

        assert first.agent_id == "agent-1"
        assert second is first
        assert first.level == TrustLevel.SUPERVISED

    def test_record_interaction_updates_score_and_domain_scores(self) -> None:
        engine = TrustEngine()
        engine.register_agent("agent-1")

        score = engine.record_interaction(
            "agent-1",
            success=True,
            score=0.9,
            domain="legal",
        )

        assert score.total_interactions == 1
        assert score.eval_history == [0.9]
        assert score.score > 0.0
        assert "legal" in score.domain_scores

    def test_record_interaction_applies_failure_decay(self) -> None:
        engine = TrustEngine(TrustConfig(decay_on_failure=0.2))
        engine.register_agent("agent-1")
        engine.record_interaction("agent-1", success=True, score=1.0)
        before = engine.get_trust("agent-1")
        assert before is not None
        before_score = before.score

        after = engine.record_interaction("agent-1", success=False, score=0.2)

        assert after.score < before_score
        assert after.total_interactions == 2

    def test_compute_level_progression_and_gates(self) -> None:
        config = TrustConfig(
            thresholds={
                TrustLevel.SUPERVISED: 0.0,
                TrustLevel.GUIDED: 0.2,
                TrustLevel.SEMI_AUTONOMOUS: 0.4,
                TrustLevel.AUTONOMOUS: 0.6,
                TrustLevel.EXPERT: 0.8,
            },
            min_interactions_per_level=1,
            decay_on_failure=0.01,
        )
        engine = TrustEngine(config=config)
        engine.register_agent("agent-1")

        engine.record_interaction("agent-1", success=True, score=0.9)
        level = engine.evaluate_trust("agent-1")

        # Requires interaction gates; with 1 interaction max practical level is GUIDED.
        assert level >= TrustLevel.GUIDED
        assert level <= TrustLevel.SEMI_AUTONOMOUS

    def test_can_act_autonomously_uses_risk_scaled_threshold(self) -> None:
        engine = TrustEngine(TrustConfig(min_interactions_per_level=1))
        engine.register_agent("agent-1")
        for _ in range(3):
            engine.record_interaction("agent-1", success=True, score=0.6)

        assert engine.can_act_autonomously("agent-1", action_risk=0.0)
        assert not engine.can_act_autonomously("agent-1", action_risk=1.0)

    def test_escalation_required_for_supervised_and_complex_tasks(self) -> None:
        engine = TrustEngine(TrustConfig(min_interactions_per_level=1))
        engine.register_agent("agent-1")

        assert engine.escalation_required("agent-1", task_complexity=0.1)

        for _ in range(10):
            engine.record_interaction("agent-1", success=True, score=0.7)

        assert not engine.escalation_required("agent-1", task_complexity=0.1)
        assert engine.escalation_required("agent-1", task_complexity=1.0)

    def test_record_escalation_updates_metadata(self) -> None:
        engine = TrustEngine(TrustConfig(min_interactions_per_level=1, decay_on_failure=0.1))
        engine.register_agent("agent-1")
        engine.record_interaction("agent-1", success=True, score=0.9)

        before = engine.get_trust("agent-1")
        assert before is not None
        before_score = before.score

        engine.record_escalation("agent-1", "policy_violation")
        after = engine.get_trust("agent-1")
        assert after is not None

        assert after.escalation_count == 1
        assert after.score < before_score
        reasons = cast("list[dict[str, Any]]", after.metadata["escalation_reasons"])
        assert reasons[0]["reason"] == "policy_violation"

    def test_missing_agent_paths_raise_key_error(self) -> None:
        engine = TrustEngine()

        assert engine.get_trust("missing") is None
        with pytest.raises(KeyError):
            engine.evaluate_trust("missing")
        with pytest.raises(KeyError):
            engine.record_interaction("missing", success=True, score=0.5)

    def test_summary_empty_and_populated(self) -> None:
        engine = TrustEngine()
        assert engine.summary() == {"total_agents": 0}

        engine.register_agent("a")
        engine.register_agent("b")
        for _ in range(3):
            engine.record_interaction("a", success=True, score=0.8)
        engine.record_interaction("b", success=False, score=0.2)
        engine.record_escalation("b", "manual_review")

        summary = engine.summary()
        assert summary["total_agents"] == 2
        assert summary["total_interactions"] == 4
        assert summary["total_escalations"] >= 1
        assert "SUPERVISED" in summary["level_distribution"]


class TestEscalationEngine:
    def test_default_policies_loaded(self) -> None:
        engine = EscalationEngine()
        names = {p.name for p in engine.policies}

        assert {"low_confidence", "high_risk", "compliance_required", "novel_scenario"} <= names

    def test_register_policy_replaces_existing_name(self) -> None:
        engine = EscalationEngine()
        replacement = EscalationPolicy(name="low_confidence", conditions={"max_confidence": 0.1})
        engine.register_policy(replacement)

        matches = [p for p in engine.policies if p.name == "low_confidence"]
        assert len(matches) == 1
        assert matches[0].conditions["max_confidence"] == 0.1

    def test_should_escalate_low_confidence_auto_records_event(self) -> None:
        engine = EscalationEngine()

        event = engine.should_escalate(agent_id="agent-1", confidence=0.2, risk=0.1)

        assert event is not None
        assert event.reason == EscalationReason.LOW_CONFIDENCE
        assert len(engine.pending_escalations("agent-1")) == 1

    def test_should_escalate_high_risk(self) -> None:
        engine = EscalationEngine()
        event = engine.should_escalate(agent_id="agent-1", confidence=0.9, risk=0.95)

        assert event is not None
        assert event.reason == EscalationReason.HIGH_RISK
        assert "senior reviewer" in event.recommended_action.lower()

    def test_should_escalate_compliance_required(self) -> None:
        engine = EscalationEngine()
        event = engine.should_escalate(
            agent_id="agent-1",
            confidence=0.9,
            risk=0.1,
            context={"requires_compliance": True},
        )

        assert event is not None
        assert event.reason == EscalationReason.COMPLIANCE_REQUIRED

    def test_should_escalate_novel_scenario_non_auto_policy(self) -> None:
        engine = EscalationEngine(
            policies=[
                EscalationPolicy(
                    name="novel",
                    conditions={"max_confidence": 0.5, "min_risk": 0.5},
                    auto_escalate=False,
                )
            ]
        )

        event = engine.should_escalate(agent_id="agent-1", confidence=0.5, risk=0.5)

        assert event is not None
        assert event.reason == EscalationReason.NOVEL_SCENARIO
        assert engine.pending_escalations() == []

    def test_should_escalate_contradiction_trust_and_explicit(self) -> None:
        engine = EscalationEngine(
            policies=[EscalationPolicy(name="context", conditions={}, auto_escalate=True)]
        )

        contradiction = engine.should_escalate(
            agent_id="agent-1",
            confidence=0.9,
            risk=0.1,
            context={"contradictory_evidence": True},
        )
        trust = engine.should_escalate(
            agent_id="agent-2",
            confidence=0.9,
            risk=0.1,
            context={"trust_insufficient": True},
        )
        explicit = engine.should_escalate(
            agent_id="agent-3",
            confidence=0.9,
            risk=0.1,
            context={"explicit_request": True},
        )

        assert (
            contradiction is not None
            and contradiction.reason == EscalationReason.CONTRADICTORY_EVIDENCE
        )
        assert trust is not None and trust.reason == EscalationReason.TRUST_INSUFFICIENT
        assert explicit is not None and explicit.reason == EscalationReason.EXPLICIT_REQUEST

    def test_should_not_escalate_returns_none(self) -> None:
        engine = EscalationEngine(
            policies=[EscalationPolicy(name="none", conditions={}, auto_escalate=True)]
        )
        event = engine.should_escalate(agent_id="agent-1", confidence=0.9, risk=0.1)
        assert event is None

    def test_escalate_and_resolve_lifecycle(self) -> None:
        engine = EscalationEngine(policies=[])
        event = EscalationEvent(
            agent_id="agent-1",
            reason=EscalationReason.EXPLICIT_REQUEST,
            task_summary="manual escalation",
            confidence=0.5,
            risk_level=0.5,
            timestamp=datetime.now(tz=UTC),
        )

        engine.escalate(event)
        assert len(engine.pending_escalations("agent-1")) == 1

        resolved = engine.resolve(event.id, resolution="approved", resolver="reviewer-1")
        assert resolved.resolved
        assert resolved.resolution == "approved"
        assert resolved.resolver == "reviewer-1"
        assert engine.pending_escalations("agent-1") == []

    def test_resolve_missing_event_raises(self) -> None:
        engine = EscalationEngine()
        with pytest.raises(KeyError):
            engine.resolve("missing", resolution="n/a", resolver="n/a")

    def test_escalation_rate_and_summary(self) -> None:
        engine = EscalationEngine()
        assert engine.escalation_rate() == 0.0

        engine.should_escalate("agent-1", confidence=0.2, risk=0.1)
        engine.should_escalate("agent-2", confidence=0.95, risk=0.95)
        engine.should_escalate("agent-3", confidence=0.95, risk=0.1)

        summary = engine.summary()
        assert summary["total_events"] == 2
        assert summary["pending"] == 2
        assert summary["total_evaluations"] == 3
        assert summary["escalation_rate"] > 0.0
        assert summary["by_reason"][EscalationReason.LOW_CONFIDENCE.value] >= 1

        assert engine.escalation_rate("agent-1") > 0.0

    def test_recommend_action_all_branches(self) -> None:
        engine = EscalationEngine(policies=[])

        assert "senior reviewer" in engine._recommend_action(EscalationReason.HIGH_RISK, 0.9, 0.95)
        assert "human review" in engine._recommend_action(EscalationReason.HIGH_RISK, 0.9, 0.8)
        assert "re-generation" in engine._recommend_action(
            EscalationReason.LOW_CONFIDENCE, 0.2, 0.2
        )
        assert "draft" in engine._recommend_action(EscalationReason.LOW_CONFIDENCE, 0.3, 0.2)
        assert "compliance" in engine._recommend_action(
            EscalationReason.COMPLIANCE_REQUIRED, 0.8, 0.1
        )
        assert "conflicting evidence" in engine._recommend_action(
            EscalationReason.CONTRADICTORY_EVIDENCE,
            0.8,
            0.1,
        )
        assert "novel scenario" in engine._recommend_action(
            EscalationReason.NOVEL_SCENARIO, 0.8, 0.1
        )
        assert "supervised" in engine._recommend_action(
            EscalationReason.TRUST_INSUFFICIENT, 0.8, 0.1
        )
        assert "requested reviewer" in engine._recommend_action(
            EscalationReason.EXPLICIT_REQUEST, 0.8, 0.1
        )

        fallback = engine._recommend_action(cast("Any", "other"), 0.5, 0.5)
        assert fallback == "Require human review"
