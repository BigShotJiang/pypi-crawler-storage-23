# ruff: noqa
"""Tests for aegis.api.auth — JWT, API keys, permissions."""

from __future__ import annotations

import time

import pytest

from aegis.api.auth import (
    APIKey,
    AuthConfig,
    AuthProvider,
    AuthUser,
    _b64url_decode,
    _b64url_encode,
    _create_jwt,
    _decode_jwt,
    _hash_api_key,
    _resolve_permissions,
    get_current_user,
    get_default_provider,
    require_auth,
    require_permission,
    set_default_provider,
)


# ---------------------------------------------------------------------------
# Base64url helpers
# ---------------------------------------------------------------------------


class TestBase64Url:
    def test_round_trip(self) -> None:
        data = b"hello world 123!!"
        encoded = _b64url_encode(data)
        assert isinstance(encoded, str)
        assert _b64url_decode(encoded) == data

    def test_no_padding(self) -> None:
        encoded = _b64url_encode(b"a")
        assert "=" not in encoded

    def test_empty(self) -> None:
        assert _b64url_decode(_b64url_encode(b"")) == b""


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------


class TestJWT:
    secret = "test-secret-key"

    def test_create_and_decode(self) -> None:
        payload = {"sub": "user1", "email": "u@example.com"}
        token = _create_jwt(payload, self.secret)
        decoded = _decode_jwt(token, self.secret)
        assert decoded is not None
        assert decoded["sub"] == "user1"

    def test_invalid_algorithm(self) -> None:
        with pytest.raises(ValueError, match="HS256"):
            _create_jwt({"sub": "x"}, self.secret, algorithm="RS256")

    def test_decode_bad_algorithm(self) -> None:
        assert _decode_jwt("a.b.c", self.secret, algorithm="RS256") is None

    def test_decode_wrong_secret(self) -> None:
        token = _create_jwt({"sub": "x"}, self.secret)
        assert _decode_jwt(token, "wrong-secret") is None

    def test_decode_malformed(self) -> None:
        assert _decode_jwt("not.a.valid.token.parts", self.secret) is None
        assert _decode_jwt("abc", self.secret) is None

    def test_expired_token(self) -> None:
        payload = {"sub": "x", "exp": int(time.time()) - 100}
        token = _create_jwt(payload, self.secret)
        assert _decode_jwt(token, self.secret) is None

    def test_valid_expiration(self) -> None:
        payload = {"sub": "x", "exp": int(time.time()) + 3600}
        token = _create_jwt(payload, self.secret)
        assert _decode_jwt(token, self.secret) is not None


# ---------------------------------------------------------------------------
# API key hashing
# ---------------------------------------------------------------------------


class TestAPIKeyHash:
    def test_deterministic(self) -> None:
        assert _hash_api_key("key1") == _hash_api_key("key1")

    def test_different_keys(self) -> None:
        assert _hash_api_key("key1") != _hash_api_key("key2")


# ---------------------------------------------------------------------------
# Permission resolution
# ---------------------------------------------------------------------------


class TestPermissions:
    def test_admin_role(self) -> None:
        perms = _resolve_permissions(["admin"], [])
        assert "eval:read" in perms
        assert "training:write" in perms

    def test_viewer_role(self) -> None:
        perms = _resolve_permissions(["viewer"], [])
        assert "eval:read" in perms
        assert "eval:write" not in perms

    def test_explicit_permissions(self) -> None:
        perms = _resolve_permissions([], ["custom:action"])
        assert "custom:action" in perms

    def test_combined(self) -> None:
        perms = _resolve_permissions(["viewer"], ["custom:action"])
        assert "eval:read" in perms
        assert "custom:action" in perms

    def test_unknown_role(self) -> None:
        perms = _resolve_permissions(["nonexistent"], [])
        assert perms == []


# ---------------------------------------------------------------------------
# AuthProvider
# ---------------------------------------------------------------------------


class TestAuthProvider:
    def _make_provider(self) -> AuthProvider:
        return AuthProvider(AuthConfig(jwt_secret="test-secret"))

    def test_jwt_flow(self) -> None:
        provider = self._make_provider()
        token = provider.create_jwt("user1", "u@ex.com", roles=["admin"])
        user = provider.verify_jwt(token)
        assert user is not None
        assert user.user_id == "user1"
        assert "eval:read" in user.permissions

    def test_jwt_no_secret(self) -> None:
        provider = AuthProvider(AuthConfig(jwt_secret=""))
        assert provider.verify_jwt("some.token.here") is None

    def test_create_jwt_no_secret_raises(self) -> None:
        provider = AuthProvider(AuthConfig(jwt_secret=""))
        with pytest.raises(ValueError, match="jwt_secret"):
            provider.create_jwt("u", "e")

    def test_jwt_wrong_issuer(self) -> None:
        provider = self._make_provider()
        payload = {
            "sub": "user1",
            "iss": "wrong-issuer",
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret")
        assert provider.verify_jwt(token) is None

    def test_jwt_wrong_audience(self) -> None:
        provider = self._make_provider()
        payload = {
            "sub": "user1",
            "aud": "wrong-audience",
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret")
        assert provider.verify_jwt(token) is None

    def test_jwt_audience_list(self) -> None:
        provider = self._make_provider()
        payload = {
            "sub": "user1",
            "aud": ["aegis-api", "other"],
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret")
        user = provider.verify_jwt(token)
        assert user is not None

    def test_api_key_flow(self) -> None:
        provider = self._make_provider()
        raw_key, api_key = provider.create_api_key("user1", scopes=["eval:read", "eval:write"])
        user = provider.verify_api_key(raw_key)
        assert user is not None
        assert user.user_id == "user1"
        assert "eval:read" in user.permissions

    def test_api_key_expired(self) -> None:
        provider = self._make_provider()
        raw_key, _ = provider.create_api_key("user1", scopes=[], expires_in_seconds=-1)
        assert provider.verify_api_key(raw_key) is None

    def test_api_key_revoked(self) -> None:
        provider = self._make_provider()
        raw_key, api_key = provider.create_api_key("user1", scopes=["eval:read"])
        assert provider.revoke_api_key(api_key.key_id) is True
        assert provider.verify_api_key(raw_key) is None

    def test_revoke_nonexistent(self) -> None:
        provider = self._make_provider()
        assert provider.revoke_api_key("nonexistent") is False

    def test_list_api_keys(self) -> None:
        provider = self._make_provider()
        provider.create_api_key("user1", scopes=["a"])
        provider.create_api_key("user1", scopes=["b"])
        provider.create_api_key("user2", scopes=["c"])
        assert len(provider.list_api_keys("user1")) == 2
        assert len(provider.list_api_keys("user2")) == 1
        assert len(provider.list_api_keys("user3")) == 0

    def test_authenticate_jwt(self) -> None:
        provider = self._make_provider()
        token = provider.create_jwt("u1", "e@e.com")
        user = provider.authenticate({"Authorization": f"Bearer {token}"})
        assert user is not None
        assert user.user_id == "u1"

    def test_authenticate_api_key(self) -> None:
        provider = self._make_provider()
        raw_key, _ = provider.create_api_key("u1", scopes=["eval:read"])
        user = provider.authenticate({"X-API-Key": raw_key})
        assert user is not None
        assert user.user_id == "u1"

    def test_authenticate_no_creds(self) -> None:
        provider = self._make_provider()
        assert provider.authenticate({}) is None

    def test_authenticate_case_insensitive(self) -> None:
        provider = self._make_provider()
        raw_key, _ = provider.create_api_key("u1", scopes=["eval:read"])
        user = provider.authenticate({"x-api-key": raw_key})
        assert user is not None

    def test_authorize_direct(self) -> None:
        provider = self._make_provider()
        user = AuthUser(user_id="u", email="", permissions=["eval:read"])
        assert provider.authorize(user, "eval", "read") is True
        assert provider.authorize(user, "eval", "write") is False

    def test_authorize_wildcard(self) -> None:
        provider = self._make_provider()
        user = AuthUser(user_id="u", email="", permissions=["eval:*"])
        assert provider.authorize(user, "eval", "read") is True
        assert provider.authorize(user, "eval", "delete") is True

    def test_authorize_global_admin(self) -> None:
        provider = self._make_provider()
        user = AuthUser(user_id="u", email="", permissions=["*:*"])
        assert provider.authorize(user, "training", "write") is True

    def test_jwt_with_extra_claims(self) -> None:
        provider = self._make_provider()
        token = provider.create_jwt("u1", "e@e.com", extra_claims={"org": "test-org"})
        decoded = _decode_jwt(token, "test-secret")
        assert decoded is not None
        assert decoded["org"] == "test-org"

    def test_jwt_with_permissions(self) -> None:
        provider = self._make_provider()
        token = provider.create_jwt("u1", "e@e.com", permissions=["custom:perm"])
        user = provider.verify_jwt(token)
        assert user is not None
        assert "custom:perm" in user.permissions


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


class TestModuleLevelHelpers:
    def test_get_default_provider(self) -> None:
        provider = get_default_provider()
        assert isinstance(provider, AuthProvider)

    def test_set_default_provider(self) -> None:
        custom = AuthProvider(AuthConfig(jwt_secret="custom"))
        set_default_provider(custom)
        assert get_default_provider() is custom
        # Reset
        set_default_provider(AuthProvider(AuthConfig()))

    def test_get_current_user_no_auth(self) -> None:
        assert get_current_user({}) is None

    def test_require_auth_fails(self) -> None:
        set_default_provider(AuthProvider(AuthConfig()))
        with pytest.raises(PermissionError, match="Authentication required"):
            require_auth({})

    def test_require_permission_fails(self) -> None:
        user = AuthUser(user_id="u", email="", permissions=[])
        with pytest.raises(PermissionError, match="Permission denied"):
            require_permission(user, "eval", "read")

    def test_require_permission_passes(self) -> None:
        user = AuthUser(user_id="u", email="", permissions=["eval:read"])
        require_permission(user, "eval", "read")  # no exception
