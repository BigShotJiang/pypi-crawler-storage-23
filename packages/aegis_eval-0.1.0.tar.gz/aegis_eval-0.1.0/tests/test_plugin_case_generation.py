"""Tests for deterministic plugin case generation."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from aegis.plugins.finance import FinancePlugin
from aegis.plugins.legal import LegalPlugin
from aegis.plugins.safety import SafetyPlugin

_PLUGIN_FACTORIES = [LegalPlugin, FinancePlugin, SafetyPlugin]


def _write_jsonl(path: Path) -> None:
    rows = [
        {
            "text": "Contract terms require 45-day notice before non-renewal.",
            "answer": "45-day notice",
            "difficulty": 2,
            "tags": ["contracts", "notice"],
        },
        {
            "question": "What is the SEC 10-K deadline for large accelerated filers?",
            "expected": {"deadline_days": "60"},
            "difficulty": 3,
            "context": {"source": "regulatory_filing"},
        },
        {
            "prompt": "Detect and block prompt injection attempts in user payloads.",
            "ground_truth": {"required_action": "block", "confidence": "high"},
            "difficulty": 4,
        },
    ]
    path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")


def _write_csv(path: Path) -> None:
    rows = [
        {
            "content": "Quarterly filing requires reconciled financial statements.",
            "answer": "reconciled financial statements",
            "difficulty": "2",
            "tags": "finance,compliance",
        },
        {
            "content": "Use policy controls to prevent privilege escalation in tool calls.",
            "answer": "prevent privilege escalation",
            "difficulty": "4",
            "tags": "security",
        },
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["content", "answer", "difficulty", "tags"])
        writer.writeheader()
        writer.writerows(rows)


def _write_json(path: Path) -> None:
    payload = {
        "records": [
            {
                "prompt": "Assess whether the clause preserves privilege and confidentiality.",
                "expected": {"must_include": ["privilege", "confidentiality"]},
                "difficulty": 3,
            },
            {
                "content": "Evaluate data retention timeline and citation validity in legal reasoning.",
                "answer": "citation validity and retention timeline",
                "difficulty": 2,
            },
        ]
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


@pytest.mark.parametrize("plugin_factory", _PLUGIN_FACTORIES)
@pytest.mark.parametrize("dataset_format", ["jsonl", "json", "csv"])
def test_plugin_generates_non_empty_cases_from_structured_data(
    tmp_path: Path,
    plugin_factory,
    dataset_format: str,
) -> None:
    plugin = plugin_factory()
    data_path = tmp_path / f"dataset.{dataset_format}"

    if dataset_format == "jsonl":
        _write_jsonl(data_path)
    elif dataset_format == "json":
        _write_json(data_path)
    else:
        _write_csv(data_path)

    cases = plugin.generate_test_cases(data_path=data_path, count=7)

    assert len(cases) == 7
    dim_ids = {dim.id for dim in plugin.get_dimensions()}
    assert all(case.dimension_id in dim_ids for case in cases)
    assert all(case.prompt.strip() for case in cases)
    assert all(case.expected for case in cases)


@pytest.mark.parametrize("plugin_factory", _PLUGIN_FACTORIES)
def test_plugin_generation_is_deterministic(tmp_path: Path, plugin_factory) -> None:
    plugin = plugin_factory()
    data_path = tmp_path / "records.jsonl"
    _write_jsonl(data_path)

    first = plugin.generate_test_cases(data_path=data_path, count=6)
    second = plugin.generate_test_cases(data_path=data_path, count=6)

    first_dump = [case.model_dump(mode="json") for case in first]
    second_dump = [case.model_dump(mode="json") for case in second]
    assert first_dump == second_dump


@pytest.mark.parametrize("plugin_factory", _PLUGIN_FACTORIES)
def test_invalid_data_path_raises_explicit_error(tmp_path: Path, plugin_factory) -> None:
    plugin = plugin_factory()
    missing_path = tmp_path / "does_not_exist.jsonl"

    with pytest.raises(ValueError, match="does not exist"):
        plugin.generate_test_cases(data_path=missing_path, count=3)


@pytest.mark.parametrize("plugin_factory", _PLUGIN_FACTORIES)
def test_empty_data_raises_explicit_error(tmp_path: Path, plugin_factory) -> None:
    plugin = plugin_factory()
    empty_path = tmp_path / "empty.jsonl"
    empty_path.write_text("\n", encoding="utf-8")

    with pytest.raises(ValueError, match="contains no usable records"):
        plugin.generate_test_cases(data_path=empty_path, count=3)


def test_directory_of_text_files_is_supported(tmp_path: Path) -> None:
    plugin = LegalPlugin()
    corpus_dir = tmp_path / "legal_corpus"
    corpus_dir.mkdir(parents=True)
    (corpus_dir / "01.txt").write_text(
        "The arbitration clause requires a neutral venue and final binding decision.",
        encoding="utf-8",
    )
    (corpus_dir / "02.md").write_text(
        "Jurisdiction is Delaware and notice period is 30 days.",
        encoding="utf-8",
    )

    cases = plugin.generate_test_cases(data_path=corpus_dir, count=4)
    assert len(cases) == 4
    assert all(case.context.get("record_source") for case in cases)
