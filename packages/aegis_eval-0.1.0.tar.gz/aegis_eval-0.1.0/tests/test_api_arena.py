"""Arena API route tests."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from aegis.api.app import app
from aegis.api.routes import arena as arena_routes

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_arena_state() -> None:
    """Reset in-memory arena state between tests."""
    arena_routes._submission_manager._submissions.clear()

    arena_routes._leaderboard._entries.clear()
    arena_routes._leaderboard._history.clear()
    arena_routes._leaderboard._agent_scores.clear()

    arena_routes._elo._ratings.clear()
    arena_routes._elo._wins.clear()
    arena_routes._elo._losses.clear()
    arena_routes._elo._matches.clear()


def _base_submission(
    *,
    name: str = "Agent Alpha",
    framework: str = "openai",
    domains: list[str] | None = None,
) -> dict[str, object]:
    return {
        "agent_name": name,
        "agent_description": "Legal assistant with retrieval, citation checks, and tool use.",
        "framework": framework,
        "domains": domains if domains is not None else ["legal"],
        "model_size": "large",
        "public": True,
        "submitted_by": "tests",
        "metadata": {"compute_cost_usd": 3.2},
    }


def test_submit_arena_agent_success() -> None:
    response = client.post("/v1/arena/submit", json=_base_submission())
    assert response.status_code == 201

    payload = response.json()
    assert payload["status"] == "completed"
    assert payload["submission_id"]
    assert 0.0 <= payload["scores"]["overall"] <= 1.0
    assert len(payload["scores"]["dimensions"]) >= 10
    assert payload["scores"]["domains"]["legal"] > 0.0


def test_submit_arena_agent_invalid_domains() -> None:
    invalid_payload = _base_submission(domains=[])
    response = client.post("/v1/arena/submit", json=invalid_payload)
    assert response.status_code == 422


def test_leaderboard_and_agent_routes() -> None:
    first = client.post(
        "/v1/arena/submit",
        json=_base_submission(name="Agent One", framework="openai", domains=["legal"]),
    )
    second = client.post(
        "/v1/arena/submit",
        json=_base_submission(name="Agent Two", framework="rest", domains=["finance"]),
    )
    assert first.status_code == 201
    assert second.status_code == 201

    leaderboard = client.get("/v1/arena/leaderboard")
    assert leaderboard.status_code == 200
    data = leaderboard.json()
    assert data["total_entries"] == 2
    assert len(data["entries"]) == 2

    first_id = first.json()["submission_id"]
    second_id = second.json()["submission_id"]

    details_one = client.get(f"/v1/arena/agent/{first_id}")
    details_two = client.get(f"/v1/arena/agent/{second_id}")
    assert details_one.status_code == 200
    assert details_two.status_code == 200
    assert details_one.json()["status"] == "completed"
    assert details_two.json()["status"] == "completed"

    elo_one = details_one.json()["elo_rating"]
    elo_two = details_two.json()["elo_rating"]
    assert elo_one != elo_two


def test_arena_agent_not_found() -> None:
    response = client.get("/v1/arena/agent/non-existent")
    assert response.status_code == 404
