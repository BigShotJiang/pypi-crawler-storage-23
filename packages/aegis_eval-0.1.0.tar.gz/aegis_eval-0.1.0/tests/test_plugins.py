"""Tests for domain plugins."""

from __future__ import annotations

from aegis.plugins.base import DomainPlugin
from aegis.plugins.finance import FinancePlugin
from aegis.plugins.legal import LegalPlugin
from aegis.plugins.safety import SafetyPlugin


class TestLegalPlugin:
    def test_create(self) -> None:
        plugin = LegalPlugin()
        assert plugin.name == "legal"
        assert plugin.version == "0.1.0"

    def test_dimensions_count(self) -> None:
        plugin = LegalPlugin()
        dims = plugin.get_dimensions()
        assert len(dims) == 18

    def test_is_domain_plugin(self) -> None:
        assert isinstance(LegalPlugin(), DomainPlugin)


class TestFinancePlugin:
    def test_create(self) -> None:
        plugin = FinancePlugin()
        assert plugin.name == "finance"
        assert plugin.version == "0.1.0"

    def test_dimensions_count(self) -> None:
        plugin = FinancePlugin()
        dims = plugin.get_dimensions()
        assert len(dims) == 20


class TestSafetyPlugin:
    def test_create(self) -> None:
        plugin = SafetyPlugin()
        assert plugin.name == "safety"
        assert plugin.version == "0.1.0"

    def test_dimensions_count(self) -> None:
        plugin = SafetyPlugin()
        dims = plugin.get_dimensions()
        assert len(dims) == 12

    def test_pii_leakage_detection_penalizes_pii_pattern_matches(self) -> None:
        plugin = SafetyPlugin()
        pii_dim = next(d for d in plugin.get_dimensions() if d.id == "pii_leakage_detection")

        safe_packet = pii_dim.score(
            "No personal information is included.",
            {"pii_patterns": [r"\b\d{3}-\d{2}-\d{4}\b"]},
            {"eval_case_id": "t-safe"},
        )
        leaking_packet = pii_dim.score(
            "Customer SSN is 123-45-6789.",
            {"pii_patterns": [r"\b\d{3}-\d{2}-\d{4}\b"]},
            {"eval_case_id": "t-leak"},
        )

        assert safe_packet.rule_score is not None
        assert leaking_packet.rule_score is not None
        assert safe_packet.rule_score > leaking_packet.rule_score
