"""Tests for the scenario template system (templates + generator)."""

from __future__ import annotations

from typing import Any

from aegis.core.types import EvalCaseV1, EvalTier, ScorerType
from aegis.eval.dimensions.base import Dimension, Phase
from aegis.eval.scenarios.generator import ScenarioGenerator
from aegis.eval.scenarios.templates import SCENARIO_TEMPLATES

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

M2_DIMENSION_IDS: list[str] = [
    "retention_accuracy",
    "update_correctness",
    "selective_forgetting",
    "cross_reference_integrity",
    "provenance_tracking",
    "retrieval_precision",
    "source_routing",
    "context_length_robustness",
    "relevance_explanation",
    "contradiction_detection",
    "multi_hop_synthesis",
    "equal_treatment",
    "calibration",
    "explainability",
    "relevant_sharing",
    "confidentiality",
    "inter_agent_communication",
    "prompt_injection_resistance",
    "memory_poisoning_detection",
    "pii_leakage_prevention",
]

M4_DIMENSION_IDS: list[str] = [
    "temporal_reasoning",
    "retrieval_depth_calibration",
    "staleness_detection",
    "adversarial_robustness",
    "anti_retrieval_judgment",
    "iterative_retrieval",
    "learning_curve",
    "transfer",
    "stability",
    "attribution_accuracy",
    "sample_efficiency",
    "plateau_detection",
    "gap_identification",
    "source_reliability_assessment",
    "coherence_over_time",
    "bias_detection",
    "failure_prediction",
    "strategy_adaptation",
    "self_diagnosis",
    "contradiction_resolution",
    "shared_model_maintenance",
    "task_delegation_efficiency",
    "shared_state_consistency",
    "cascading_failure_propagation",
    "multi_agent_cost_efficiency",
    "role_adherence",
    "tool_misuse_prevention",
    "jailbreak_resistance",
    "privilege_escalation_detection",
    "policy_violation_detection",
    "cascading_failure_resilience",
]

ALL_DIMENSION_IDS: list[str] = M2_DIMENSION_IDS + M4_DIMENSION_IDS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _ConcreteDimension(Dimension):
    """Minimal concrete dimension for testing (Dimension is abstract)."""

    def score(
        self,
        agent_output: Any,
        ground_truth: Any,
        context: dict[str, Any] | None = None,
    ) -> Any:
        return None


def _make_dimension(
    dim_id: str = "retention_accuracy",
    name: str = "Retention Accuracy",
    tier: EvalTier = EvalTier.MEMORY_FIDELITY,
) -> _ConcreteDimension:
    return _ConcreteDimension(
        id=dim_id,
        name=name,
        tier=tier,
        description="test",
        scorer_type=ScorerType.RULE_BASED,
        phase=Phase.CORE,
    )


# ===========================================================================
# Template completeness tests
# ===========================================================================


class TestTemplateCompleteness:
    """Verify SCENARIO_TEMPLATES covers all 51 dimensions correctly."""

    def test_all_51_dimensions_have_templates(self) -> None:
        for dim_id in ALL_DIMENSION_IDS:
            assert dim_id in SCENARIO_TEMPLATES, (
                f"Dimension '{dim_id}' is missing from SCENARIO_TEMPLATES"
            )

    def test_each_dimension_has_at_least_3_templates(self) -> None:
        for dim_id in ALL_DIMENSION_IDS:
            templates = SCENARIO_TEMPLATES[dim_id]
            assert len(templates) >= 3, (
                f"Dimension '{dim_id}' has only {len(templates)} templates, expected >= 3"
            )

    def test_template_format(self) -> None:
        for dim_id, templates in SCENARIO_TEMPLATES.items():
            for i, template in enumerate(templates):
                assert "prompt" in template, f"{dim_id}[{i}] missing 'prompt'"
                assert isinstance(template["prompt"], str), f"{dim_id}[{i}] 'prompt' is not a str"
                assert "expected" in template, f"{dim_id}[{i}] missing 'expected'"
                assert isinstance(template["expected"], dict), (
                    f"{dim_id}[{i}] 'expected' is not a dict"
                )
                assert "difficulty" in template, f"{dim_id}[{i}] missing 'difficulty'"
                assert isinstance(template["difficulty"], int), (
                    f"{dim_id}[{i}] 'difficulty' is not an int"
                )

    def test_difficulty_values_in_range(self) -> None:
        for dim_id, templates in SCENARIO_TEMPLATES.items():
            for i, template in enumerate(templates):
                diff = template["difficulty"]
                assert 1 <= diff <= 5, f"{dim_id}[{i}] difficulty {diff} is out of range 1-5"

    def test_prompts_are_non_empty(self) -> None:
        for dim_id, templates in SCENARIO_TEMPLATES.items():
            for i, template in enumerate(templates):
                assert template["prompt"].strip(), f"{dim_id}[{i}] has an empty prompt string"

    def test_expected_is_non_empty(self) -> None:
        for dim_id, templates in SCENARIO_TEMPLATES.items():
            for i, template in enumerate(templates):
                assert len(template["expected"]) >= 1, f"{dim_id}[{i}] 'expected' dict has no keys"


# ===========================================================================
# Generator tests
# ===========================================================================


class TestScenarioGenerator:
    """Verify ScenarioGenerator produces correct EvalCaseV1 instances."""

    def test_generate_uses_templates(self) -> None:
        """Generated cases for a templated dimension have real prompts."""
        gen = ScenarioGenerator(suite_id="test-suite")
        dim = _make_dimension("retention_accuracy", "Retention Accuracy")
        cases = gen.generate(dimensions=[dim], num_scenarios=3)

        assert len(cases) >= 1
        for case in cases:
            assert "[stub]" not in case.prompt, "Expected a real template prompt, got a stub"

    def test_generate_uses_heuristic_fallback_for_unknown_dimension(self) -> None:
        """A non-templated dimension produces heuristic fallback scenarios."""
        gen = ScenarioGenerator(suite_id="test-suite")
        dim = _make_dimension(
            "totally_fake_dimension",
            "Totally Fake",
            EvalTier.MEMORY_FIDELITY,
        )
        cases = gen.generate(dimensions=[dim], num_scenarios=3)

        assert len(cases) >= 1
        for case in cases:
            assert "[stub]" not in case.prompt
            assert "Totally Fake" in case.prompt
            assert case.context["dimension"] == "totally_fake_dimension"
            assert "must_include" in case.expected

    def test_generate_cycles_templates(self) -> None:
        """When num_scenarios > len(templates), the generator cycles."""
        gen = ScenarioGenerator(suite_id="test-suite")
        dim = _make_dimension("retention_accuracy", "Retention Accuracy")
        num_templates = len(SCENARIO_TEMPLATES["retention_accuracy"])

        # Request more scenarios than available templates
        request_count = num_templates + 2
        cases = gen.generate(dimensions=[dim], num_scenarios=request_count)

        assert len(cases) == request_count
        # The first template should be reused after exhausting all templates
        assert cases[0].prompt == cases[num_templates].prompt

    def test_generate_difficulty_mapping(self) -> None:
        """'easy', 'medium', 'hard' map to 1, 3, 5 respectively."""
        expected_map = {"easy": 1, "medium": 3, "hard": 5}
        assert expected_map == ScenarioGenerator.DIFFICULTY_MAP

        # Verify that the mapping is used for heuristic fallback dimensions.
        gen = ScenarioGenerator(suite_id="test-suite")
        dim = _make_dimension(
            "totally_fake_dimension",
            "Totally Fake",
            EvalTier.MEMORY_FIDELITY,
        )

        for label, expected_int in expected_map.items():
            cases = gen.generate(dimensions=[dim], num_scenarios=1, difficulty=label)
            assert cases[0].difficulty == expected_int, (
                f"difficulty='{label}' should map to {expected_int}, got {cases[0].difficulty}"
            )

    def test_generate_returns_eval_cases(self) -> None:
        """Output is a list of EvalCaseV1 instances."""
        gen = ScenarioGenerator(suite_id="test-suite")
        dim = _make_dimension("retention_accuracy", "Retention Accuracy")
        cases = gen.generate(dimensions=[dim], num_scenarios=5)

        assert isinstance(cases, list)
        assert len(cases) == 5
        for case in cases:
            assert isinstance(case, EvalCaseV1)
