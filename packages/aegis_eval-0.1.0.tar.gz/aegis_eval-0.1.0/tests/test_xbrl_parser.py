"""Tests for the XBRL and iXBRL parser."""

from __future__ import annotations

from datetime import date

import pytest

from aegis.ingestion.xbrl import (
    FinancialFact,
    TaxonomyMapping,
    TemporalContext,
    XBRLParser,
)

# ---------------------------------------------------------------------------
# Fixtures — sample XBRL documents
# ---------------------------------------------------------------------------

SAMPLE_XBRL = """\
<?xml version="1.0" encoding="utf-8"?>
<xbrli:xbrl
  xmlns:xbrli="http://www.xbrl.org/2003/instance"
  xmlns:us-gaap="http://fasb.org/us-gaap/2023"
  xmlns:dei="http://xbrl.sec.gov/dei/2023"
  xmlns:iso4217="http://www.xbrl.org/2003/iso4217">

  <xbrli:context id="FY2024">
    <xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0001234567</xbrli:identifier></xbrli:entity>
    <xbrli:period>
      <xbrli:startDate>2024-01-01</xbrli:startDate>
      <xbrli:endDate>2024-12-31</xbrli:endDate>
    </xbrli:period>
  </xbrli:context>

  <xbrli:context id="I2024Q4">
    <xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0001234567</xbrli:identifier></xbrli:entity>
    <xbrli:period>
      <xbrli:instant>2024-12-31</xbrli:instant>
    </xbrli:period>
  </xbrli:context>

  <xbrli:unit id="USD">
    <xbrli:measure>iso4217:USD</xbrli:measure>
  </xbrli:unit>

  <xbrli:unit id="shares">
    <xbrli:measure>xbrli:shares</xbrli:measure>
  </xbrli:unit>

  <xbrli:unit id="usdPerShare">
    <xbrli:divide>
      <xbrli:unitNumerator><xbrli:measure>iso4217:USD</xbrli:measure></xbrli:unitNumerator>
      <xbrli:unitDenominator><xbrli:measure>xbrli:shares</xbrli:measure></xbrli:unitDenominator>
    </xbrli:divide>
  </xbrli:unit>

  <us-gaap:Revenues contextRef="FY2024" unitRef="USD" decimals="-6">5000000000</us-gaap:Revenues>
  <us-gaap:NetIncomeLoss contextRef="FY2024" unitRef="USD" decimals="-6">1200000000</us-gaap:NetIncomeLoss>
  <us-gaap:Assets contextRef="I2024Q4" unitRef="USD" decimals="-6">25000000000</us-gaap:Assets>
  <us-gaap:EarningsPerShareBasic contextRef="FY2024" unitRef="usdPerShare" decimals="2">3.45</us-gaap:EarningsPerShareBasic>
  <us-gaap:CommonStockSharesOutstanding contextRef="I2024Q4" unitRef="shares" decimals="0">350000000</us-gaap:CommonStockSharesOutstanding>

</xbrli:xbrl>
"""

SAMPLE_IXBRL = """\
<!DOCTYPE html>
<html>
<head><title>Inline XBRL Filing</title></head>
<body>
<p>Revenue for the year was
<ix:nonFraction name="us-gaap:Revenues" contextRef="FY2024" unitRef="USD" decimals="-6">5,000,000,000</ix:nonFraction>
</p>
<p>Net income was
<ix:nonFraction name="us-gaap:NetIncomeLoss" contextRef="FY2024" unitRef="USD" decimals="-6">1,200,000,000</ix:nonFraction>
</p>
<p>Total assets:
<ix:nonFraction contextRef="I2024Q4" name="us-gaap:Assets" unitRef="USD" decimals="-6">25,000,000,000</ix:nonFraction>
</p>
<p>Company name:
<ix:nonNumeric name="dei:EntityRegistrantName" contextRef="FY2024">Acme Corporation</ix:nonNumeric>
</p>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# FinancialFact tests
# ---------------------------------------------------------------------------


class TestFinancialFact:
    """Tests for the FinancialFact dataclass."""

    def test_basic_creation(self) -> None:
        fact = FinancialFact(
            concept="Revenues",
            label="Revenue",
            value="5000000000",
            unit="USD",
        )
        assert fact.concept == "Revenues"
        assert fact.label == "Revenue"
        assert fact.value == "5000000000"
        assert fact.unit == "USD"

    def test_numeric_value_valid(self) -> None:
        fact = FinancialFact(concept="X", label="X", value="1,234,567.89")
        assert fact.numeric_value == pytest.approx(1234567.89)

    def test_numeric_value_invalid(self) -> None:
        fact = FinancialFact(concept="X", label="X", value="not-a-number")
        assert fact.numeric_value is None

    def test_numeric_value_empty(self) -> None:
        fact = FinancialFact(concept="X", label="X", value="")
        assert fact.numeric_value is None

    def test_default_fields(self) -> None:
        fact = FinancialFact(concept="X", label="X", value="100")
        assert fact.unit == ""
        assert fact.period_type == ""
        assert fact.period_start is None
        assert fact.period_end is None
        assert fact.decimals is None
        assert fact.metadata == {}


# ---------------------------------------------------------------------------
# TaxonomyMapping tests
# ---------------------------------------------------------------------------


class TestTaxonomyMapping:
    """Tests for TaxonomyMapping."""

    def test_creation(self) -> None:
        tm = TaxonomyMapping(raw_concept="Revenue", label="Revenue", category="income_statement")
        assert tm.raw_concept == "Revenue"
        assert tm.label == "Revenue"
        assert tm.category == "income_statement"


# ---------------------------------------------------------------------------
# TemporalContext tests
# ---------------------------------------------------------------------------


class TestTemporalContext:
    """Tests for TemporalContext."""

    def test_instant(self) -> None:
        ctx = TemporalContext(
            context_ref="I2024", period_type="instant", end_date=date(2024, 12, 31)
        )
        assert ctx.period_type == "instant"
        assert ctx.end_date == date(2024, 12, 31)
        assert ctx.start_date is None

    def test_duration(self) -> None:
        ctx = TemporalContext(
            context_ref="FY2024",
            period_type="duration",
            start_date=date(2024, 1, 1),
            end_date=date(2024, 12, 31),
        )
        assert ctx.period_type == "duration"
        assert ctx.start_date == date(2024, 1, 1)


# ---------------------------------------------------------------------------
# XBRLParser tests
# ---------------------------------------------------------------------------


class TestXBRLParserParseXBRL:
    """Tests for XBRLParser.parse_xbrl()."""

    def test_parse_sample(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        assert len(facts) >= 5

    def test_revenues_extracted(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        revenue_facts = [f for f in facts if f.concept == "Revenues"]
        assert len(revenue_facts) == 1
        assert revenue_facts[0].value == "5000000000"
        assert revenue_facts[0].label == "Revenue"

    def test_context_refs(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        ctx_refs = {f.metadata.get("context_ref") for f in facts}
        assert "FY2024" in ctx_refs
        assert "I2024Q4" in ctx_refs

    def test_duration_period(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        fy_facts = [f for f in facts if f.metadata.get("context_ref") == "FY2024"]
        assert all(f.period_type == "duration" for f in fy_facts)
        assert any(f.period_start == date(2024, 1, 1) for f in fy_facts)

    def test_instant_period(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        instant_facts = [f for f in facts if f.metadata.get("context_ref") == "I2024Q4"]
        assert all(f.period_type == "instant" for f in instant_facts)

    def test_decimals_parsed(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        revenue = [f for f in facts if f.concept == "Revenues"][0]
        assert revenue.decimals == -6

    def test_eps_unit(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl(SAMPLE_XBRL)
        eps_facts = [f for f in facts if f.concept == "EarningsPerShareBasic"]
        assert len(eps_facts) == 1
        # The divide unit should be resolved
        assert "USD" in eps_facts[0].unit or "/" in eps_facts[0].unit

    def test_invalid_xml(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl("<<<invalid xml>>>")
        assert facts == []

    def test_empty_content(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl("")
        assert facts == []

    def test_no_facts(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_xbrl('<?xml version="1.0"?><root></root>')
        assert facts == []


class TestXBRLParserParseIXBRL:
    """Tests for XBRLParser.parse_ixbrl()."""

    def test_parse_sample(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_ixbrl(SAMPLE_IXBRL)
        assert len(facts) >= 3

    def test_revenue_extracted(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_ixbrl(SAMPLE_IXBRL)
        revenue_facts = [f for f in facts if f.concept == "Revenues"]
        assert len(revenue_facts) >= 1
        assert "5,000,000,000" in revenue_facts[0].value or "5000000000" in revenue_facts[0].value

    def test_non_numeric_fact(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_ixbrl(SAMPLE_IXBRL)
        name_facts = [f for f in facts if f.concept == "EntityRegistrantName"]
        assert len(name_facts) >= 1
        assert "Acme" in name_facts[0].value

    def test_empty_html(self) -> None:
        parser = XBRLParser()
        facts = parser.parse_ixbrl("<html><body>No XBRL here</body></html>")
        assert facts == []

    def test_alt_attribute_order(self) -> None:
        """Test iXBRL where contextRef comes before name."""
        parser = XBRLParser()
        facts = parser.parse_ixbrl(SAMPLE_IXBRL)
        # The Assets fact uses contextRef before name
        asset_facts = [f for f in facts if f.concept == "Assets"]
        assert len(asset_facts) >= 1


class TestXBRLParserResolveTaxonomy:
    """Tests for XBRLParser.resolve_taxonomy()."""

    def test_us_gaap_concept(self) -> None:
        parser = XBRLParser()
        mapping = parser.resolve_taxonomy("Revenues")
        assert mapping.label == "Revenue"
        assert mapping.category == "income_statement"

    def test_us_gaap_with_prefix(self) -> None:
        parser = XBRLParser()
        mapping = parser.resolve_taxonomy("us-gaap:NetIncomeLoss")
        assert mapping.label == "Net Income (Loss)"

    def test_ifrs_concept(self) -> None:
        parser = XBRLParser()
        mapping = parser.resolve_taxonomy("CostOfSales")
        assert mapping.label == "Cost of Sales"
        assert mapping.category == "income_statement"

    def test_unknown_concept(self) -> None:
        parser = XBRLParser()
        mapping = parser.resolve_taxonomy("SomeCustomConcept")
        assert mapping.category == "other"
        assert "Custom" in mapping.label or "Some" in mapping.label

    def test_camel_case_split(self) -> None:
        parser = XBRLParser()
        mapping = parser.resolve_taxonomy("MyCustomMetric")
        assert " " in mapping.label  # Should be split


class TestXBRLParserNormalizeUnits:
    """Tests for XBRLParser.normalize_units()."""

    def test_usd(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("1000000", "iso4217:USD")
        assert val == pytest.approx(1000000.0)
        assert unit == "USD"

    def test_with_commas(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("1,234,567", "USD")
        assert val == pytest.approx(1234567.0)

    def test_parenthesised_negative(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("(500)", "USD")
        assert val == pytest.approx(-500.0)

    def test_shares(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("350000000", "xbrli:shares")
        assert val == pytest.approx(350000000.0)
        assert unit == "shares"

    def test_pure(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("0.95", "pure")
        assert val == pytest.approx(0.95)
        assert unit == "pure"

    def test_non_numeric(self) -> None:
        parser = XBRLParser()
        val, unit = parser.normalize_units("Acme Corp", "")
        assert val == 0.0


class TestXBRLParserContextExtraction:
    """Tests for _extract_contexts and _extract_units."""

    def test_contexts_extracted(self) -> None:
        import xml.etree.ElementTree as ET

        parser = XBRLParser()
        root = ET.fromstring(SAMPLE_XBRL)
        contexts = parser._extract_contexts(root)
        assert "FY2024" in contexts
        assert "I2024Q4" in contexts
        assert contexts["FY2024"].period_type == "duration"
        assert contexts["I2024Q4"].period_type == "instant"

    def test_units_extracted(self) -> None:
        import xml.etree.ElementTree as ET

        parser = XBRLParser()
        root = ET.fromstring(SAMPLE_XBRL)
        units = parser._extract_units(root)
        assert "USD" in units
        assert "shares" in units
        assert "usdPerShare" in units
        assert "/" in units["usdPerShare"]  # Should be a divide unit
