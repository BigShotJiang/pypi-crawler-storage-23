"""Coverage tests for multi-agent coordination training module."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from aegis.training.multi_agent import (
    AgentProfile,
    ConflictResolver,
    DeferencePolicy,
    DivisionOfLabor,
    MultiAgentCoordinator,
    RelevanceFilter,
    SharedKnowledge,
)


def _agent(
    agent_id: str,
    *,
    domains: list[str],
    expertise: dict[str, float],
    caps: list[str],
    trust: float = 0.6,
    success: float = 0.7,
    interactions: int = 0,
) -> AgentProfile:
    return AgentProfile(
        agent_id=agent_id,
        name=agent_id,
        domains=domains,
        expertise_scores=expertise,
        capabilities=caps,
        trust_score=trust,
        success_rate=success,
        interaction_count=interactions,
    )


def test_agent_profile_expertise_and_trust() -> None:
    profile = _agent(
        "a1",
        domains=["legal"],
        expertise={"legal": 0.9},
        caps=["retrieval"],
        trust=0.8,
        success=0.9,
        interactions=10,
    )
    assert profile.expertise_in("legal") == 0.9
    assert profile.expertise_in("finance") == 0.1
    effective = profile.effective_trust("legal")
    assert 0.0 <= effective <= 1.0
    as_dict = profile.to_dict()
    assert as_dict["agent_id"] == "a1"
    assert as_dict["trust_score"] == round(0.8, 4)


def test_shared_knowledge_conflict_detection_and_resolution() -> None:
    kb = SharedKnowledge(name="test-kb")

    first_id = kb.add_entry(
        {"fact": "value-a", "domain": "legal"},
        contributor_id="agent-1",
        confidence=0.9,
    )
    second_id = kb.add_entry(
        {"fact": "value-b", "domain": "legal"},
        contributor_id="agent-2",
        confidence=0.8,
    )

    conflicts = kb.get_unresolved_conflicts()
    assert conflicts

    resolution = {
        "winning_entry_id": first_id,
        "superseded_entry_id": second_id,
        "reason": "better_evidence",
    }
    assert kb.resolve_conflict(conflicts[0]["id"], resolution) is True
    assert kb.resolve_conflict("missing", resolution) is False
    assert len(kb.active_entries()) == 1

    summary = kb.to_dict()
    assert summary["total_entries"] == 2
    assert summary["unresolved_conflicts"] == 0


def test_relevance_filter_scoring_and_summary() -> None:
    target = _agent(
        "target",
        domains=["legal"],
        expertise={"legal": 0.8},
        caps=["retrieval", "compliance"],
    )
    entries = [
        {
            "id": "e1",
            "domain": "legal",
            "tags": ["retrieval", "analysis"],
            "confidence": 0.9,
            "content": {"a": 1, "b": 2},
            "timestamp": datetime.now(tz=UTC).isoformat(),
        },
        {
            "id": "e2",
            "domain": "finance",
            "tags": ["trading"],
            "confidence": "bad-number",
            "content": {},
        },
    ]

    filt = RelevanceFilter(relevance_threshold=0.1, max_share_ratio=1.0)
    selected = filt.filter(entries, target)
    assert selected
    assert "relevance_score" in selected[0]

    empty = filt.filter([], target)
    assert empty == []

    stats = filt.summary()
    assert stats["filter_events"] >= 1
    assert 0.0 <= stats["share_rate"] <= 1.0


def test_conflict_resolver_strategies_and_summary() -> None:
    resolver = ConflictResolver()

    claim_a = {
        "value": "alpha",
        "confidence": 0.85,
        "source": "doc-a",
        "timestamp": "2026-01-02T00:00:00+00:00",
        "evidence": [1, 2, 3],
        "agent_id": "a",
    }
    claim_b = {
        "value": "beta",
        "confidence": 0.6,
        "source": "doc-b",
        "timestamp": "2026-01-01T00:00:00+00:00",
        "evidence": [1],
        "agent_id": "b",
    }
    context = {
        "domain": "legal",
        "agent_profiles": {
            "a": _agent("a", domains=["legal"], expertise={"legal": 0.9}, caps=[]),
            "b": _agent("b", domains=["legal"], expertise={"legal": 0.4}, caps=[]),
        },
        "other_opinions": [{"value": "alpha", "confidence": 0.8}],
    }

    resolution = resolver.resolve(claim_a, claim_b, context)
    assert resolution["winner"] in {"a", "b"}
    assert "merged_value" in resolution
    assert resolution["strategy_used"] in {
        "confidence",
        "evidence",
        "recency",
        "expertise",
        "consensus",
    }

    override = dict(context)
    override["resolution_strategy"] = "consensus"
    forced = resolver.resolve(claim_a, claim_b, override)
    assert forced["strategy_used"] == "consensus"

    tie = resolver.resolve(
        {"value": "x", "confidence": 0.5, "agent_id": "a"},
        {"value": "y", "confidence": 0.5, "agent_id": "b"},
        {"domain": "general", "agent_profiles": {}, "other_opinions": []},
    )
    assert tie["winner"] in {"a", "b"}

    summary = resolver.summary()
    assert summary["total_resolutions"] == 3


def test_division_of_labor_assignments_and_subtasks() -> None:
    dol = DivisionOfLabor(load_balance_weight=0.25)
    a1 = _agent(
        "a1",
        domains=["legal"],
        expertise={"legal": 0.9},
        caps=["retrieval", "analysis"],
        trust=0.8,
    )
    a2 = _agent(
        "a2",
        domains=["finance"],
        expertise={"finance": 0.9},
        caps=["synthesis"],
        trust=0.5,
    )

    with pytest.raises(ValueError):
        dol.assign({"domain": "legal"}, [])

    selected = dol.assign(
        {
            "id": "t1",
            "type": "conflict_resolution",
            "domain": "legal",
            "required_capabilities": ["retrieval"],
            "difficulty": 5,
        },
        [a1, a2],
    )
    assert selected.agent_id == "a1"

    one_agent = dol.assign({"id": "t2", "domain": "legal", "type": "analysis"}, [a2])
    assert one_agent.agent_id == "a2"

    assignments = dol.assign_subtasks(
        {
            "id": "parent",
            "type": "multi_source_retrieval",
            "domain": "legal",
            "difficulty": 4,
            "required_capabilities": ["retrieval"],
        },
        [a1, a2],
    )
    assert len(assignments) >= 3
    assert all("id" in subtask for _, subtask in assignments)

    summary = dol.summary()
    assert summary["total_assignments"] >= 1
    assert "a1" in summary["agent_load"]


def test_deference_policy_branches() -> None:
    policy = DeferencePolicy(confidence_threshold=0.4, expertise_gap_threshold=0.2)
    experts = [
        _agent("e1", domains=["legal"], expertise={"legal": 0.95}, caps=[], trust=0.9),
        _agent("e2", domains=["legal"], expertise={"legal": 0.6}, caps=[], trust=0.6),
    ]

    # High confidence -> no deference.
    assert policy.should_defer({"domain": "legal", "difficulty": 2}, 0.8, experts) is None

    # Low confidence + strong expert -> deference.
    defer_to = policy.should_defer({"domain": "legal", "difficulty": 3}, 0.2, experts)
    assert defer_to is not None
    assert defer_to.agent_id == "e1"

    # Hard task branch.
    hard_defer = policy.should_defer({"domain": "legal", "difficulty": 5}, 0.45, experts)
    assert hard_defer is not None

    # No candidates.
    assert policy.should_defer({"domain": "legal"}, 0.1, []) is None

    summary = policy.summary()
    assert summary["total_decisions"] == 3
    assert summary["deferred_count"] >= 1


def test_multi_agent_coordinator_end_to_end() -> None:
    coord = MultiAgentCoordinator(
        relevance_threshold=0.1,
        confidence_threshold=0.4,
        expertise_gap_threshold=0.2,
        load_balance_weight=0.2,
    )
    a1 = _agent(
        "a1",
        domains=["legal"],
        expertise={"legal": 0.9},
        caps=["retrieval", "analysis"],
        trust=0.8,
    )
    a2 = _agent(
        "a2",
        domains=["finance", "legal"],
        expertise={"finance": 0.9, "legal": 0.4},
        caps=["synthesis", "compliance"],
        trust=0.7,
    )

    coord.register_agent(a1)
    coord.register_agent(a2)

    assert coord.get_agent("a1") is not None
    assert coord.update_agent("a1", {"success_rate": 0.95}) is True
    assert coord.update_agent("missing", {"success_rate": 0.95}) is False

    shared_count = coord.share_knowledge(
        "a1",
        [
            {
                "id": "k1",
                "domain": "legal",
                "tags": ["compliance"],
                "confidence": 0.8,
                "content": {"rule": "A"},
                "timestamp": datetime.now(tz=UTC).isoformat(),
            }
        ],
    )
    assert shared_count >= 1

    resolution = coord.resolve_conflict(
        ["a1", "a2"],
        {
            "domain": "legal",
            "claim_a": {
                "value": "approved",
                "agent_id": "a1",
                "confidence": 0.8,
                "evidence": ["policy"],
                "timestamp": "2026-01-02T00:00:00+00:00",
            },
            "claim_b": {
                "value": "rejected",
                "agent_id": "a2",
                "confidence": 0.7,
                "evidence": ["memo"],
                "timestamp": "2026-01-01T00:00:00+00:00",
            },
            "other_opinions": [{"value": "approved", "confidence": 0.6}],
        },
    )
    assert resolution["winner"] in {"a", "b"}

    assigned = coord.assign_task(
        {
            "id": "task-1",
            "type": "knowledge_sharing",
            "domain": "legal",
            "required_capabilities": ["analysis"],
            "difficulty": 4,
        }
    )
    assert assigned in {"a1", "a2"}

    defer_target = coord.check_deference(
        requesting_agent="a2",
        task={"domain": "legal", "difficulty": 5},
        self_confidence=0.2,
    )
    assert defer_target in {"a1", None}

    summary = coord.summary()
    assert summary["registered_agents"] == 2
    assert summary["coordination_events"] >= 4
    assert "share_knowledge" in summary["action_counts"]
