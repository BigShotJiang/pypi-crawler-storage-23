"""Tests for pgvector and Neo4j retrieval backends."""

from __future__ import annotations

from unittest.mock import MagicMock

from aegis.core.types import ContextBlock
from aegis.retrieval.context import ContextConstructor, RetrievalBackend, RetrievalPolicy

# ---------------------------------------------------------------------------
# Mock retrieval backend
# ---------------------------------------------------------------------------


class MockRetrievalBackend:
    """Simple in-memory retrieval backend for testing."""

    def __init__(self, blocks: list[ContextBlock] | None = None) -> None:
        self._blocks = blocks or []

    def query(self, query: str, top_k: int = 10) -> list[ContextBlock]:
        return self._blocks[:top_k]


class TestRetrievalBackendProtocol:
    def test_mock_backend_satisfies_protocol(self) -> None:
        backend = MockRetrievalBackend()
        assert isinstance(backend, RetrievalBackend)

    def test_mock_backend_returns_blocks(self) -> None:
        blocks = [
            ContextBlock(
                source_id="doc-1", content="Hello world", rerank_score=0.9, selected=False
            ),
            ContextBlock(source_id="doc-2", content="Foo bar", rerank_score=0.5, selected=False),
        ]
        backend = MockRetrievalBackend(blocks)
        results = backend.query("test", top_k=5)
        assert len(results) == 2
        assert results[0].source_id == "doc-1"


# ---------------------------------------------------------------------------
# ContextConstructor with pluggable backends
# ---------------------------------------------------------------------------


class TestContextConstructorWithBackends:
    def test_backends_queried(self) -> None:
        blocks = [
            ContextBlock(
                source_id="pg-1",
                content="This contract contains a legal indemnity clause for the test query about contracts",
                rerank_score=0.8,
                selected=False,
            ),
        ]
        backend = MockRetrievalBackend(blocks)
        policy = RetrievalPolicy(min_relevance_score=0.0, anti_retrieval_enabled=False)
        constructor = ContextConstructor(policy=policy, backends=[backend])
        trace = constructor.retrieve_and_construct("test query about contracts")

        assert trace.total_retrieved >= 1
        all_ids = {b.source_id for b in trace.context_blocks}
        assert "pg-1" in all_ids

    def test_multiple_backends_combined(self) -> None:
        pg_blocks = [
            ContextBlock(
                source_id="pg-1",
                content="PG result for legal query about contracts and clauses",
                rerank_score=0.8,
                selected=False,
            ),
        ]
        neo_blocks = [
            ContextBlock(
                source_id="neo-1",
                content="Neo result for legal query about contracts and clauses",
                rerank_score=0.7,
                selected=False,
            ),
        ]
        policy = RetrievalPolicy(min_relevance_score=0.0, anti_retrieval_enabled=False)
        constructor = ContextConstructor(
            policy=policy,
            backends=[MockRetrievalBackend(pg_blocks), MockRetrievalBackend(neo_blocks)],
        )
        trace = constructor.retrieve_and_construct("legal query about contracts")
        all_ids = {b.source_id for b in trace.context_blocks}
        assert "pg-1" in all_ids
        assert "neo-1" in all_ids

    def test_backend_failure_handled_gracefully(self) -> None:
        """A failing backend should not crash the constructor."""
        failing_backend = MagicMock()
        failing_backend.query.side_effect = RuntimeError("connection failed")

        good_blocks = [
            ContextBlock(
                source_id="good-1",
                content="Good result for test query about legal contracts and indemnity clauses",
                rerank_score=0.8,
                selected=False,
            ),
        ]
        good_backend = MockRetrievalBackend(good_blocks)

        policy = RetrievalPolicy(min_relevance_score=0.0, anti_retrieval_enabled=False)
        constructor = ContextConstructor(policy=policy, backends=[failing_backend, good_backend])
        trace = constructor.retrieve_and_construct("test query about legal contracts")
        all_ids = {b.source_id for b in trace.context_blocks}
        assert "good-1" in all_ids

    def test_backends_plus_sources(self) -> None:
        """Backends and explicit sources should be combined."""
        backend_blocks = [
            ContextBlock(
                source_id="backend-1",
                content="Backend result for test query about contracts",
                rerank_score=0.8,
                selected=False,
            ),
        ]
        explicit_sources = [
            {
                "source_id": "explicit-1",
                "content": "Explicit result for test query about contracts",
                "source_type": "vector",
            },
        ]
        policy = RetrievalPolicy(min_relevance_score=0.0, anti_retrieval_enabled=False)
        constructor = ContextConstructor(
            policy=policy, backends=[MockRetrievalBackend(backend_blocks)]
        )
        trace = constructor.retrieve_and_construct(
            "test query about contracts", sources=explicit_sources
        )
        all_ids = {b.source_id for b in trace.context_blocks}
        assert "backend-1" in all_ids
        assert "explicit-1" in all_ids


# ---------------------------------------------------------------------------
# Cross-encoder reranking
# ---------------------------------------------------------------------------


class TestCrossEncoderReranking:
    def test_fallback_to_sequence_matcher(self) -> None:
        """Without sentence-transformers, reranking should still work."""
        policy = RetrievalPolicy(rerank=True, min_relevance_score=0.0)
        constructor = ContextConstructor(policy=policy)
        blocks = [
            ContextBlock(
                source_id="a",
                content="The capital of France is Paris",
                rerank_score=0.0,
                selected=False,
            ),
            ContextBlock(
                source_id="b", content="Random unrelated text", rerank_score=0.0, selected=False
            ),
        ]
        reranked = constructor.rerank("What is the capital of France?", blocks)
        assert len(reranked) == 2
        # All blocks should have non-zero scores
        assert all(b.rerank_score > 0 for b in reranked)

    def test_rerank_empty_list(self) -> None:
        constructor = ContextConstructor()
        assert constructor.rerank("test", []) == []

    def test_sequence_matcher_ranking_quality(self) -> None:
        """SequenceMatcher should rank the more relevant block higher."""
        policy = RetrievalPolicy(rerank=False, min_relevance_score=0.0)
        constructor = ContextConstructor(policy=policy)
        blocks = [
            ContextBlock(
                source_id="irrelevant",
                content="bananas are yellow",
                rerank_score=0.0,
                selected=False,
            ),
            ContextBlock(
                source_id="relevant",
                content="contract clause about indemnity",
                rerank_score=0.0,
                selected=False,
            ),
        ]
        reranked = constructor._rerank_sequence_matcher("indemnity clause in contract", blocks)
        assert reranked[0].source_id == "relevant"


# ---------------------------------------------------------------------------
# PgVectorRetriever unit tests (mocked store)
# ---------------------------------------------------------------------------


class TestPgVectorRetriever:
    def test_query_with_mock_store(self) -> None:
        from aegis.retrieval.pgvector_backend import PgVectorRetriever

        mock_store = MagicMock()
        mock_entry = MagicMock()
        mock_entry.key = "entry-1"
        mock_entry.value = "Legal contract clause"
        mock_entry.confidence = 0.85
        mock_store.search.return_value = [mock_entry]

        retriever = PgVectorRetriever(store=mock_store)
        results = retriever.query("contract clause", top_k=5)

        assert len(results) == 1
        assert results[0].source_id == "entry-1"
        assert "Legal contract clause" in results[0].content
        assert results[0].rerank_score == 0.85
        mock_store.search.assert_called_once_with("contract clause", top_k=5)

    def test_empty_results(self) -> None:
        from aegis.retrieval.pgvector_backend import PgVectorRetriever

        mock_store = MagicMock()
        mock_store.search.return_value = []

        retriever = PgVectorRetriever(store=mock_store)
        results = retriever.query("nothing", top_k=10)
        assert results == []


# ---------------------------------------------------------------------------
# Neo4jRetriever unit tests (mocked graph)
# ---------------------------------------------------------------------------


class TestNeo4jRetriever:
    def test_query_with_mock_graph(self) -> None:
        from aegis.retrieval.neo4j_backend import Neo4jRetriever

        mock_graph = MagicMock()
        mock_graph.has_node.return_value = False

        retriever = Neo4jRetriever(graph=mock_graph)
        results = retriever.query("some query", top_k=5)

        # No matching nodes => empty results
        assert results == []

    def test_extract_terms(self) -> None:
        from aegis.retrieval.neo4j_backend import Neo4jRetriever

        terms = Neo4jRetriever._extract_terms("Find Acme Corp contracts")
        assert any("Acme" in t or "acme" in t for t in terms)
        assert any("Corp" in t or "corp" in t for t in terms)

    def test_query_with_matching_node(self) -> None:
        from aegis.retrieval.neo4j_backend import Neo4jRetriever

        mock_graph = MagicMock()

        # has_node returns True for "Acme"
        def has_node_side_effect(node_id: str) -> bool:
            return node_id == "Acme"

        mock_graph.has_node.side_effect = has_node_side_effect
        mock_graph.subgraph.return_value = {}
        mock_graph.neighbors.return_value = ["ContractA", "ContractB"]

        retriever = Neo4jRetriever(graph=mock_graph)
        results = retriever.query("Find Acme contracts", top_k=10)

        assert len(results) >= 1
        # Should contain connections from Acme
        assert any("Acme" in b.content for b in results)
