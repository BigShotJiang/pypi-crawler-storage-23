# ruff: noqa
"""Tests for aegis.observatory.metrics_exporter — Prometheus metrics."""

from __future__ import annotations

from aegis.observatory.metrics_exporter import MetricsExporter, _Counter, _Gauge, _Histogram


# ---------------------------------------------------------------------------
# Low-level metric types
# ---------------------------------------------------------------------------


class TestCounter:
    def test_inc_default(self) -> None:
        c = _Counter("test", "help")
        c.inc()
        assert c.get() == 1.0

    def test_inc_amount(self) -> None:
        c = _Counter("test", "help")
        c.inc(amount=5.0)
        assert c.get() == 5.0

    def test_inc_label(self) -> None:
        c = _Counter("test", "help")
        c.inc("a")
        c.inc("a")
        c.inc("b")
        assert c.get("a") == 2.0
        assert c.get("b") == 1.0

    def test_get_missing(self) -> None:
        c = _Counter("test", "help")
        assert c.get("missing") == 0.0


class TestGauge:
    def test_set_get(self) -> None:
        g = _Gauge("test", "help")
        g.set(42.0)
        assert g.get() == 42.0

    def test_label(self) -> None:
        g = _Gauge("test", "help")
        g.set(1.0, "a")
        g.set(2.0, "b")
        assert g.get("a") == 1.0
        assert g.get("b") == 2.0

    def test_get_missing(self) -> None:
        g = _Gauge("test", "help")
        assert g.get("x") == 0.0


class TestHistogram:
    def test_observe(self) -> None:
        h = _Histogram("test", "help")
        h.observe(10.0)
        h.observe(20.0)
        assert h.count() == 2
        assert h.total() == 30.0

    def test_bucket_counts(self) -> None:
        h = _Histogram("test", "help", buckets=(10.0, 50.0, 100.0))
        h.observe(5.0)
        h.observe(30.0)
        h.observe(99.0)
        h.observe(200.0)
        buckets = h.bucket_counts()
        # le=10: 1, le=50: 2, le=100: 3, le=+Inf: 4
        assert buckets[0] == (10.0, 1)
        assert buckets[1] == (50.0, 2)
        assert buckets[2] == (100.0, 3)
        assert buckets[3] == (float("inf"), 4)

    def test_label_isolation(self) -> None:
        h = _Histogram("test", "help")
        h.observe(1.0, "a")
        h.observe(2.0, "b")
        assert h.count("a") == 1
        assert h.count("b") == 1
        assert h.count("c") == 0


# ---------------------------------------------------------------------------
# MetricsExporter
# ---------------------------------------------------------------------------


class TestMetricsExporter:
    def test_record_training_step(self) -> None:
        exporter = MetricsExporter()
        exporter.record_training_step(
            {
                "step": 1,
                "reward": 0.5,
                "loss": 0.3,
                "kl_divergence": 0.01,
                "entropy": 4.2,
                "grad_norm": 1.5,
                "learning_rate": 0.001,
                "memory_bank_size": 100,
                "dead_memory_pct": 5.0,
                "goodhart_divergence": 0.02,
            }
        )
        data = exporter.export_json()
        assert data["training"]["steps_total"] == 1.0
        assert data["training"]["reward"]["1"] == 0.5
        assert data["training"]["loss"]["1"] == 0.3

    def test_record_memory_operation(self) -> None:
        exporter = MetricsExporter()
        exporter.record_memory_operation("STORE", 15.0, success=True)
        exporter.record_memory_operation("STORE", 20.0, success=False)
        exporter.record_memory_operation("RETRIEVE", 5.0, success=True)
        data = exporter.export_json()
        assert data["memory"]["operations_total"]["STORE"] == 2.0
        assert data["memory"]["operation_errors"]["STORE"] == 1.0
        assert data["memory"]["operations_total"]["RETRIEVE"] == 1.0

    def test_record_observatory_alert(self) -> None:
        exporter = MetricsExporter()
        exporter.record_observatory_alert("goodhart_warning", "warning")
        exporter.record_observatory_alert("auto_intervention", "critical")
        data = exporter.export_json()
        assert data["observatory"]["alerts_total"]["goodhart_warning:warning"] == 1.0
        assert data["observatory"]["interventions_total"]["critical"] == 1.0

    def test_record_eval_score(self) -> None:
        exporter = MetricsExporter()
        exporter.record_eval_score("memory_fidelity", 0.85)
        exporter.record_eval_score("reasoning_quality", 0.72)
        data = exporter.export_json()
        assert data["eval"]["scores"]["memory_fidelity"] == 0.85
        assert data["eval"]["runs_total"]["memory_fidelity"] == 1.0

    def test_export_prometheus(self) -> None:
        exporter = MetricsExporter()
        exporter.record_training_step({"step": 1, "reward": 0.5})
        exporter.record_memory_operation("STORE", 10.0, True)
        exporter.record_observatory_alert("test", "info")
        exporter.record_eval_score("dim1", 0.9)

        text = exporter.export_prometheus()
        assert "aegis_uptime_seconds" in text
        assert "aegis_training_steps_total" in text
        assert "aegis_training_reward" in text
        assert "aegis_memory_operations_total" in text
        assert "aegis_observatory_alerts_total" in text
        assert "aegis_eval_score" in text
        # Check Prometheus format
        assert "# HELP" in text
        assert "# TYPE" in text

    def test_export_json_structure(self) -> None:
        exporter = MetricsExporter()
        data = exporter.export_json()
        assert "uptime_seconds" in data
        assert "training" in data
        assert "memory" in data
        assert "observatory" in data
        assert "eval" in data

    def test_prometheus_empty(self) -> None:
        exporter = MetricsExporter()
        text = exporter.export_prometheus()
        # Should still produce valid output with zero values
        assert "aegis_training_steps_total 0" in text

    def test_multiple_steps(self) -> None:
        exporter = MetricsExporter()
        for i in range(5):
            exporter.record_training_step({"step": i, "reward": i * 0.1})
        data = exporter.export_json()
        assert data["training"]["steps_total"] == 5.0
