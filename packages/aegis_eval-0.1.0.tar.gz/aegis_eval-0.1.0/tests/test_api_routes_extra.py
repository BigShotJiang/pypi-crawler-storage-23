# ruff: noqa
"""Tests for API routes with low coverage: efficiency, observability, app lifespan."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from aegis.api.app import _build_local_runtime_state, create_app


# ---------------------------------------------------------------------------
# App factory and lifespan
# ---------------------------------------------------------------------------


class TestAppFactory:
    def test_create_app(self) -> None:
        app = create_app()
        assert app.title == "Aegis API"

    def test_health_check(self) -> None:
        app = create_app()
        client = TestClient(app)
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "timestamp" in data

    def test_build_local_runtime_state(self) -> None:
        state = _build_local_runtime_state()
        assert state["status"] == "initializing"
        assert "resource_registry" in state
        assert "shutdown_hooks" in state


# ---------------------------------------------------------------------------
# Efficiency routes
# ---------------------------------------------------------------------------


class TestEfficiencyRoutes:
    @pytest.fixture()
    def client(self) -> TestClient:
        return TestClient(create_app())

    def test_start_run(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/efficiency/start",
            json={"run_id": "test-run", "model_name": "qwen"},
        )
        assert resp.status_code == 201
        assert resp.json()["run_id"] == "test-run"

    def test_all_runs(self, client: TestClient) -> None:
        resp = client.get("/v1/efficiency/runs")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_end_run_not_found(self, client: TestClient) -> None:
        resp = client.post("/v1/efficiency/end?run_id=nonexistent")
        assert resp.status_code == 200

    def test_get_run_not_found(self, client: TestClient) -> None:
        resp = client.get("/v1/efficiency/runs/nonexistent")
        assert resp.status_code == 200

    def test_compare_runs(self, client: TestClient) -> None:
        resp = client.get("/v1/efficiency/compare?run_a=a&run_b=b")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Observability routes
# ---------------------------------------------------------------------------


class TestObservabilityRoutes:
    @pytest.fixture()
    def client(self) -> TestClient:
        return TestClient(create_app())

    def test_emit_event(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "agent.step",
                "agent_id": "test-agent",
                "payload": {"step": 1},
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "accepted"
        assert "id" in data

    def test_emit_health_check_reward(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.reward",
                "agent_id": "agent1",
                "payload": {
                    "reward_traces": [
                        {"reward": 0.5, "quality": 0.5},
                        {"reward": 0.6, "quality": 0.6},
                        {"reward": 0.7, "quality": 0.7},
                    ]
                },
            },
        )
        assert resp.status_code == 201

    def test_emit_health_check_gradient(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.gradient",
                "agent_id": "agent1",
                "payload": {"gradient_stats": {"norm": 1.5}},
            },
        )
        assert resp.status_code == 201

    def test_emit_health_check_memory(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.memory",
                "agent_id": "agent1",
                "payload": {"memory_stats": {"bank_size": 100}},
            },
        )
        assert resp.status_code == 201

    def test_emit_health_check_drift(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.drift",
                "agent_id": "agent1",
                "payload": {
                    "reference_distribution": {"mean": 0.5, "stdev": 0.1},
                    "current_distribution": {"mean": 0.55, "stdev": 0.12},
                },
            },
        )
        assert resp.status_code == 201

    def test_emit_health_check_generic(self, client: TestClient) -> None:
        resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check",
                "agent_id": "agent1",
                "payload": {},
            },
        )
        assert resp.status_code == 201
