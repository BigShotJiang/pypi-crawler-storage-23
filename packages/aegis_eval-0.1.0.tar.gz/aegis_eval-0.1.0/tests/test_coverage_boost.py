"""Coverage-boost tests for low-coverage modules.

Targets:
- training/tracking.py        (ExperimentTracker local fallback paths)
- training/replay_buffer.py   (ReplayBuffer all sampling strategies)
- training/cloud_launcher.py  (AWSLauncher dry-run + config)
- training/checkpoint.py      (CheckpointManager full lifecycle)
- observatory/auto_intervention.py (AutoInterventionEngine policies)
- observatory/efficiency.py   (EfficiencyTracker full API)
- observatory/interventions.py (InterventionEngine rules + cooldowns)
- security/compliance.py      (ComplianceReporter all frameworks)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest

import aegis.training.cloud_launcher as cloud_mod
import aegis.training.tracking as tracking_mod
from aegis.observatory.auto_intervention import (
    AutoInterventionEngine,
    InterventionPolicy,
    InterventionType,
    _default_policies,
    _matches_anomaly,
    _matches_goodhart,
    _matches_hacking,
)
from aegis.observatory.auto_intervention import (
    Intervention as AutoIntervention,
)
from aegis.observatory.efficiency import EfficiencyTracker
from aegis.observatory.interventions import (
    InterventionEngine,
    InterventionRule,
)
from aegis.observatory.monitor import HealthCheckResult
from aegis.security.compliance import (
    EU_AI_ACT_CONTROLS,
    FINRA_CONTROLS,
    SOC2_CONTROLS,
    ComplianceReporter,
)
from aegis.training.checkpoint import CheckpointManager
from aegis.training.cloud_launcher import AWSLauncher, AWSLauncherConfig
from aegis.training.replay_buffer import Experience, ReplayBuffer, _det_float
from aegis.training.tracking import ExperimentTracker

# =====================================================================
# training/tracking.py — ExperimentTracker
# =====================================================================


class TestExperimentTrackerDisabled:
    """Tracker with enabled=False should be a complete no-op."""

    def test_disabled_tracker_properties(self) -> None:
        tracker = ExperimentTracker(project="p", run_name="r", config={"k": "v"}, enabled=False)
        assert tracker.is_wandb is False
        assert tracker.local_path is None
        assert tracker.run_name == "r"

    def test_disabled_log_metrics_noop(self) -> None:
        tracker = ExperimentTracker(project="p", run_name="r", enabled=False)
        # Should not raise
        tracker.log_metrics(step=0, metrics={"loss": 1.0})

    def test_disabled_log_artifact_noop(self) -> None:
        tracker = ExperimentTracker(project="p", run_name="r", enabled=False)
        tracker.log_artifact(name="a", path="/tmp/x")

    def test_disabled_log_table_noop(self) -> None:
        tracker = ExperimentTracker(project="p", run_name="r", enabled=False)
        tracker.log_table(name="t", columns=["a"], data=[[1]])

    def test_disabled_finish_noop(self) -> None:
        tracker = ExperimentTracker(project="p", run_name="r", enabled=False)
        tracker.finish()


class TestExperimentTrackerLocalFallback:
    """Thorough tests for the local JSONL fallback path."""

    def test_local_init_creates_directory(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)
        monkeypatch.setattr(tracking_mod, "wandb", None)

        tracker = ExperimentTracker(project="proj", run_name="my-run", config={"lr": 0.001})
        assert tracker.local_path is not None
        assert tracker.local_path.parent.exists()
        # init record written
        lines = tracker.local_path.read_text().strip().splitlines()
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["type"] == "init"
        assert record["config"]["lr"] == 0.001

    def test_local_log_metrics_writes_record(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)

        tracker = ExperimentTracker(project="p", run_name="r")
        tracker.log_metrics(step=5, metrics={"reward": 0.8, "loss": 0.2})
        tracker.log_metrics(step=10, metrics={"reward": 0.9})

        assert tracker.local_path is not None
        lines = tracker.local_path.read_text().strip().splitlines()
        # init + 2 metrics
        assert len(lines) == 3
        m1 = json.loads(lines[1])
        assert m1["type"] == "metrics"
        assert m1["step"] == 5
        assert m1["metrics"]["reward"] == 0.8

    def test_local_log_artifact_writes_record(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)

        tracker = ExperimentTracker(project="p", run_name="r")
        tracker.log_artifact(name="model-v1", path="/models/v1", artifact_type="dataset")

        assert tracker.local_path is not None
        lines = tracker.local_path.read_text().strip().splitlines()
        art = json.loads(lines[1])
        assert art["type"] == "artifact"
        assert art["name"] == "model-v1"
        assert art["artifact_type"] == "dataset"

    def test_local_log_table_writes_record(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)

        tracker = ExperimentTracker(project="p", run_name="r")
        tracker.log_table(name="eval", columns=["dim", "score"], data=[["r", 0.9], ["c", 0.8]])

        assert tracker.local_path is not None
        lines = tracker.local_path.read_text().strip().splitlines()
        tbl = json.loads(lines[1])
        assert tbl["type"] == "table"
        assert tbl["columns"] == ["dim", "score"]
        assert len(tbl["data"]) == 2

    def test_local_finish_writes_marker(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)

        tracker = ExperimentTracker(project="p", run_name="r")
        tracker.finish()

        assert tracker.local_path is not None
        lines = tracker.local_path.read_text().strip().splitlines()
        last = json.loads(lines[-1])
        assert last["type"] == "finish"

    def test_write_local_with_none_path_noop(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """_write_local should silently return if _local_path is None."""
        tracker = ExperimentTracker(project="p", run_name="r", enabled=False)
        # _local_path is None when disabled
        tracker._write_local({"type": "test"})
        # No error raised

    def test_default_config_is_empty_dict(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)

        tracker = ExperimentTracker(project="p", run_name="r", config=None)
        assert tracker._config == {}


# =====================================================================
# training/replay_buffer.py — ReplayBuffer
# =====================================================================


class TestDetFloat:
    def test_deterministic(self) -> None:
        assert _det_float("seed") == _det_float("seed")

    def test_different_seeds_differ(self) -> None:
        assert _det_float("a") != _det_float("b")

    def test_range(self) -> None:
        for i in range(100):
            val = _det_float(f"test:{i}")
            assert 0.0 <= val < 1.0


class TestReplayBufferBasic:
    def test_add_and_len(self) -> None:
        buf = ReplayBuffer(capacity=10)
        assert len(buf) == 0
        exp = Experience(prompt="hello", reward=1.0)
        buf.add(exp)
        assert len(buf) == 1
        assert exp.id in buf

    def test_contains(self) -> None:
        buf = ReplayBuffer(capacity=5)
        exp = Experience(id="exp-1", prompt="p")
        buf.add(exp)
        assert "exp-1" in buf
        assert "nonexistent" not in buf

    def test_eviction_at_capacity(self) -> None:
        buf = ReplayBuffer(capacity=3)
        ids = []
        for i in range(5):
            exp = Experience(id=f"e{i}", reward=float(i), prompt=f"p{i}")
            buf.add(exp)
            ids.append(exp.id)
        assert len(buf) == 3
        # Lowest priority (reward=0) should be evicted first
        assert "e0" not in buf

    def test_evict_lowest_priority_empty_noop(self) -> None:
        buf = ReplayBuffer()
        buf._evict_lowest_priority()  # Should not raise

    def test_remove_by_id_nonexistent(self) -> None:
        buf = ReplayBuffer()
        buf._remove_by_id("no-such-id")  # Should not raise


class TestReplayBufferSampling:
    def _fill_buffer(self, n: int = 20, domains: list[str] | None = None) -> ReplayBuffer:
        buf = ReplayBuffer(capacity=100)
        domains = domains or ["legal", "finance", "general"]
        for i in range(n):
            buf.add(
                Experience(
                    id=f"exp-{i}",
                    prompt=f"prompt-{i}",
                    reward=float(i % 5),
                    domain=domains[i % len(domains)],
                    difficulty=(i % 3) + 1,
                )
            )
        return buf

    def test_sample_empty_buffer(self) -> None:
        buf = ReplayBuffer()
        result = buf.sample(5, strategy="uniform")
        assert result == []

    def test_sample_uniform(self) -> None:
        buf = self._fill_buffer(20)
        result = buf.sample(5, strategy="uniform")
        assert len(result) <= 5
        assert all(isinstance(e, Experience) for e in result)

    def test_sample_prioritized(self) -> None:
        buf = self._fill_buffer(20)
        result = buf.sample(5, strategy="prioritized")
        assert len(result) <= 5

    def test_sample_prioritized_default_strategy(self) -> None:
        buf = self._fill_buffer(20)
        result = buf.sample(5)  # default is prioritized
        assert len(result) <= 5

    def test_sample_stratified(self) -> None:
        buf = self._fill_buffer(30, domains=["legal", "finance", "medical"])
        result = buf.sample(9, strategy="stratified")
        assert len(result) <= 9

    def test_sample_stratified_single_domain(self) -> None:
        buf = self._fill_buffer(10, domains=["legal"])
        result = buf.sample(3, strategy="stratified")
        assert len(result) <= 3

    def test_sample_batch_clamped(self) -> None:
        buf = self._fill_buffer(5)
        result = buf.sample(100, strategy="uniform")
        assert len(result) <= 5

    def test_sample_for_domain(self) -> None:
        buf = self._fill_buffer(30)
        result = buf.sample_for_domain("legal", 3)
        assert len(result) <= 3
        assert all(e.domain == "legal" for e in result)

    def test_sample_for_domain_empty(self) -> None:
        buf = self._fill_buffer(10)
        result = buf.sample_for_domain("nonexistent-domain", 5)
        assert result == []

    def test_maintenance_sample(self) -> None:
        buf = self._fill_buffer(40, domains=["legal", "finance"])
        result = buf.maintenance_sample("legal", ratio=0.15)
        assert len(result) >= 1

    def test_maintenance_sample_empty_domain(self) -> None:
        buf = self._fill_buffer(10)
        result = buf.maintenance_sample("nonexistent")
        assert result == []


class TestReplayBufferPriorityAndMaintenance:
    def test_update_priority(self) -> None:
        buf = ReplayBuffer()
        exp = Experience(id="e1", reward=1.0)
        buf.add(exp)
        old_priority = buf._priorities["e1"]
        buf.update_priority("e1", 10.0)
        assert buf._priorities["e1"] == 10.0
        assert buf._priorities["e1"] != old_priority

    def test_update_priority_clamps_to_epsilon(self) -> None:
        buf = ReplayBuffer()
        exp = Experience(id="e1", reward=1.0)
        buf.add(exp)
        buf.update_priority("e1", -5.0)
        assert buf._priorities["e1"] == 1e-6

    def test_update_priority_nonexistent_noop(self) -> None:
        buf = ReplayBuffer()
        buf.update_priority("no-such-id", 5.0)  # Should not raise

    def test_remove_stale(self) -> None:
        buf = ReplayBuffer()
        old_exp = Experience(
            id="old",
            reward=1.0,
            timestamp=datetime.now(tz=UTC) - timedelta(hours=200),
        )
        recent_exp = Experience(id="recent", reward=2.0)
        buf.add(old_exp)
        buf.add(recent_exp)
        removed = buf.remove_stale(max_age_hours=168)
        assert removed == 1
        assert "old" not in buf
        assert "recent" in buf

    def test_remove_stale_none_removed(self) -> None:
        buf = ReplayBuffer()
        buf.add(Experience(id="fresh", reward=1.0))
        removed = buf.remove_stale(max_age_hours=168)
        assert removed == 0


class TestReplayBufferStats:
    def test_stats_empty(self) -> None:
        buf = ReplayBuffer(capacity=50)
        stats = buf.stats()
        assert stats["total"] == 0
        assert stats["capacity"] == 50
        assert stats["utilization"] == 0.0
        assert stats["domains"] == {}
        assert stats["reward_stats"] == {}

    def test_stats_with_data(self) -> None:
        buf = ReplayBuffer(capacity=100)
        for i in range(10):
            buf.add(
                Experience(
                    id=f"e{i}",
                    reward=float(i),
                    domain="legal" if i < 6 else "finance",
                    difficulty=i % 3 + 1,
                )
            )
        stats = buf.stats()
        assert stats["total"] == 10
        assert stats["utilization"] == 0.1
        assert "legal" in stats["domains"]
        assert "finance" in stats["domains"]
        assert stats["reward_stats"]["min"] == 0.0
        assert stats["reward_stats"]["max"] == 9.0


# =====================================================================
# training/cloud_launcher.py — AWSLauncher
# =====================================================================


class TestAWSLauncherConfig:
    def test_defaults(self) -> None:
        cfg = AWSLauncherConfig()
        assert cfg.role_arn == ""
        assert cfg.region == "us-east-1"
        assert cfg.instance_type == "ml.g5.xlarge"
        assert cfg.use_spot is True
        assert cfg.base_job_name == "aegis-train"

    def test_custom_config(self) -> None:
        cfg = AWSLauncherConfig(
            role_arn="arn:aws:iam::role/test",
            region="eu-west-1",
            instance_type="ml.p4d.24xlarge",
            instance_count=4,
            use_spot=False,
        )
        assert cfg.region == "eu-west-1"
        assert cfg.instance_count == 4


class TestAWSLauncherDryRun:
    @pytest.fixture(autouse=True)
    def _disable_aws(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(cloud_mod, "_HAS_BOTO3", False)
        monkeypatch.setattr(cloud_mod, "_HAS_SAGEMAKER", False)

    def test_launch_dry_run_no_boto3(self) -> None:
        launcher = AWSLauncher()
        result = launcher.launch({"model_name": "test-model", "domain": "finance"})
        assert result["status"] == "dry_run"
        assert "boto3 not installed" in result["dry_run_reason"]
        assert result["model_name"] == "test-model"
        assert result["domain"] == "finance"

    def test_launch_dry_run_no_role(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(cloud_mod, "_HAS_BOTO3", True)
        monkeypatch.setattr(cloud_mod, "_HAS_SAGEMAKER", True)
        launcher = AWSLauncher(AWSLauncherConfig(role_arn=""))
        result = launcher.launch({})
        assert result["status"] == "dry_run"
        assert "no role_arn" in result["dry_run_reason"]

    def test_launch_default_hyperparameters(self) -> None:
        launcher = AWSLauncher()
        result = launcher.launch({})
        assert result["hyperparameters"]["model-name"] == "Qwen/Qwen2.5-7B"
        assert result["hyperparameters"]["domain"] == "general"
        assert result["hyperparameters"]["use-lora"] == "True"

    def test_launch_custom_hyperparameters(self) -> None:
        launcher = AWSLauncher()
        result = launcher.launch(
            {
                "model_name": "meta-llama/Llama-3-8B",
                "domain": "legal",
                "use_lora": False,
                "lora_rank": 32,
                "learning_rate": 3e-4,
                "num_episodes": 200,
            }
        )
        assert result["hyperparameters"]["model-name"] == "meta-llama/Llama-3-8B"
        assert result["hyperparameters"]["use-lora"] == "False"
        assert result["hyperparameters"]["lora-rank"] == "32"
        assert result["hyperparameters"]["learning-rate"] == "0.0003"
        assert result["hyperparameters"]["num-episodes"] == "200"

    def test_status_cached(self) -> None:
        launcher = AWSLauncher()
        result = launcher.launch({})
        job_id = result["job_id"]
        status = launcher.status(job_id)
        assert status["job_id"] == job_id
        assert status["cached"] is True
        assert status["status"] == "dry_run"

    def test_status_not_found(self) -> None:
        launcher = AWSLauncher()
        status = launcher.status("nonexistent-job-id")
        assert status["status"] == "not_found"

    def test_stop_dry_run(self) -> None:
        launcher = AWSLauncher()
        result = launcher.launch({})
        job_id = result["job_id"]
        stopped = launcher.stop(job_id)
        assert stopped["status"] == "dry_run_stopped"

    def test_stop_unknown_job(self) -> None:
        launcher = AWSLauncher()
        stopped = launcher.stop("unknown-job")
        assert stopped["status"] == "dry_run_stopped"

    def test_download_artifacts_dry_run(self, tmp_path: Path) -> None:
        launcher = AWSLauncher(AWSLauncherConfig(s3_bucket="my-bucket"))
        result = launcher.launch({})
        job_id = result["job_id"]
        downloaded = launcher.download_artifacts(job_id, dest=str(tmp_path / "artifacts"))
        assert downloaded["status"] == "dry_run"
        assert "s3://my-bucket/" in downloaded["s3_prefix"]

    def test_dry_run_reason_all_missing(self) -> None:
        launcher = AWSLauncher()
        reason = launcher._dry_run_reason()
        assert "boto3 not installed" in reason
        assert "sagemaker SDK not installed" in reason
        assert "no role_arn" in reason

    def test_s3_output_paths(self) -> None:
        launcher = AWSLauncher(AWSLauncherConfig(s3_bucket="aegis-bucket"))
        result = launcher.launch({})
        job_id = result["job_id"]
        assert result["s3_output"] == f"s3://aegis-bucket/{job_id}"
        assert result["s3_checkpoint"] == f"s3://aegis-bucket/{job_id}/checkpoints"


# =====================================================================
# training/checkpoint.py — CheckpointManager
# =====================================================================


class TestCheckpointManager:
    def test_save_creates_file(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path / "ckpts"))
        ckpt = mgr.save(
            run_id="run-1",
            step=100,
            state={"weights": [1, 2, 3]},
            metrics={"loss": 0.5},
            metadata={"domain": "legal"},
        )
        assert ckpt.id == "run-1_step_100"
        assert ckpt.run_id == "run-1"
        assert ckpt.step == 100
        assert Path(ckpt.path).exists()
        data = json.loads(Path(ckpt.path).read_text())
        assert data["weights"] == [1, 2, 3]

    def test_save_metrics_and_metadata(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        ckpt = mgr.save("run-1", step=1, state={}, metrics={"acc": 0.9}, metadata={"v": 1})
        assert ckpt.metrics == {"acc": 0.9}
        assert ckpt.metadata == {"v": 1}

    def test_save_none_metrics_metadata(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        ckpt = mgr.save("run-1", step=1, state={})
        assert ckpt.metrics == {}
        assert ckpt.metadata == {}

    def test_restore_latest(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        mgr.save("r1", step=2, state={"v": 2})
        state = mgr.restore("r1")
        assert state is not None
        assert state["v"] == 2

    def test_restore_by_id(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        mgr.save("r1", step=2, state={"v": 2})
        state = mgr.restore("r1", checkpoint_id="r1_step_1")
        assert state is not None
        assert state["v"] == 1

    def test_restore_nonexistent_run(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        assert mgr.restore("nonexistent") is None

    def test_restore_nonexistent_checkpoint_id(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        assert mgr.restore("r1", checkpoint_id="r1_step_999") is None

    def test_restore_missing_file(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        # Delete the file
        Path(mgr._checkpoints["r1"][0].path).unlink()
        assert mgr.restore("r1") is None

    def test_rollback_to_step(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        mgr.save("r1", step=2, state={"v": 2})
        mgr.save("r1", step=3, state={"v": 3})
        target = mgr.rollback("r1", to_step=2)
        assert target is not None
        assert target.step == 2
        # Step 3 should be removed from the list
        assert len(mgr.list_checkpoints("r1")) == 2

    def test_rollback_to_previous(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        mgr.save("r1", step=2, state={"v": 2})
        target = mgr.rollback("r1")  # No step => second-to-last
        assert target is not None
        assert target.step == 1

    def test_rollback_only_one_checkpoint(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        assert mgr.rollback("r1") is None  # Can't rollback with only one

    def test_rollback_empty_run(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        assert mgr.rollback("nonexistent") is None

    def test_rollback_to_nonexistent_step(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=2, state={})
        assert mgr.rollback("r1", to_step=999) is None

    def test_list_checkpoints(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=2, state={})
        ckpts = mgr.list_checkpoints("r1")
        assert len(ckpts) == 2
        assert ckpts[0].step == 1
        assert ckpts[1].step == 2

    def test_list_checkpoints_empty(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        assert mgr.list_checkpoints("nonexistent") == []

    def test_latest(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=5, state={})
        latest = mgr.latest("r1")
        assert latest is not None
        assert latest.step == 5

    def test_latest_empty(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        assert mgr.latest("nonexistent") is None

    def test_active(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=2, state={})
        active = mgr.active("r1")
        assert active is not None
        assert active.step == 2  # Most recently saved

    def test_active_after_rollback(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=2, state={})
        mgr.rollback("r1", to_step=1)
        active = mgr.active("r1")
        assert active is not None
        assert active.step == 1

    def test_active_empty(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        assert mgr.active("nonexistent") is None

    def test_cleanup_keeps_last_n(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        for step in range(1, 11):
            mgr.save("r1", step=step, state={"step": step})
        removed = mgr.cleanup("r1", keep_last=3)
        assert removed == 7
        remaining = mgr.list_checkpoints("r1")
        assert len(remaining) == 3
        assert remaining[0].step == 8

    def test_cleanup_fewer_than_keep(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        removed = mgr.cleanup("r1", keep_last=5)
        assert removed == 0

    def test_cleanup_empty_run(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        removed = mgr.cleanup("nonexistent", keep_last=5)
        assert removed == 0

    def test_summary(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={})
        mgr.save("r1", step=2, state={})
        mgr.save("r2", step=1, state={})
        s = mgr.summary()
        assert s["total_runs"] == 2
        assert s["total_checkpoints"] == 3
        assert s["runs"]["r1"]["checkpoints"] == 2
        assert s["runs"]["r1"]["latest_step"] == 2
        assert s["runs"]["r2"]["checkpoints"] == 1

    def test_summary_empty(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        s = mgr.summary()
        assert s["total_runs"] == 0
        assert s["total_checkpoints"] == 0

    def test_restore_updates_active(self, tmp_path: Path) -> None:
        mgr = CheckpointManager(base_dir=str(tmp_path))
        mgr.save("r1", step=1, state={"v": 1})
        mgr.save("r1", step=2, state={"v": 2})
        mgr.restore("r1", checkpoint_id="r1_step_1")
        active = mgr.active("r1")
        assert active is not None
        assert active.step == 1


# =====================================================================
# observatory/auto_intervention.py — AutoInterventionEngine
# =====================================================================


@dataclass
class FakeAnomaly:
    type: Any = None
    severity: float = 0.0


@dataclass
class FakeAnomalyType:
    value: str = ""


@dataclass
class FakeHackingResult:
    pattern_id: str = ""
    detected: bool = False
    confidence: float = 0.0


@dataclass
class FakeGoodhartWarning:
    divergence: float = 0.0


class TestMatcherHelpers:
    def test_matches_anomaly_match(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.3},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
        )
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)
        assert _matches_anomaly(policy, anomaly) is True

    def test_matches_anomaly_no_match_type(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.3},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
        )
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="gradient_spike"), severity=0.5)
        assert _matches_anomaly(policy, anomaly) is False

    def test_matches_anomaly_low_severity(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.5},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
        )
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.2)
        assert _matches_anomaly(policy, anomaly) is False

    def test_matches_anomaly_no_anomaly_type_in_policy(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"pattern_id": "memory_gaming"},
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
        )
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="anything"), severity=1.0)
        assert _matches_anomaly(policy, anomaly) is False

    def test_matches_hacking_match(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"pattern_id": "memory_gaming", "min_confidence": 0.5},
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
        )
        result = FakeHackingResult(pattern_id="memory_gaming", detected=True, confidence=0.7)
        assert _matches_hacking(policy, result) is True

    def test_matches_hacking_not_detected(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"pattern_id": "memory_gaming", "min_confidence": 0.5},
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
        )
        result = FakeHackingResult(pattern_id="memory_gaming", detected=False, confidence=0.9)
        assert _matches_hacking(policy, result) is False

    def test_matches_hacking_low_confidence(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"pattern_id": "memory_gaming", "min_confidence": 0.8},
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
        )
        result = FakeHackingResult(pattern_id="memory_gaming", detected=True, confidence=0.3)
        assert _matches_hacking(policy, result) is False

    def test_matches_hacking_no_pattern_in_policy(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"anomaly_type": "entropy_collapse"},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
        )
        result = FakeHackingResult(pattern_id="memory_gaming", detected=True, confidence=0.9)
        assert _matches_hacking(policy, result) is False

    def test_matches_hacking_wrong_pattern(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"pattern_id": "memory_gaming", "min_confidence": 0.5},
            intervention_type=InterventionType.REDUCE_MEMORY_REWARD_WEIGHT,
        )
        result = FakeHackingResult(pattern_id="other_pattern", detected=True, confidence=0.9)
        assert _matches_hacking(policy, result) is False

    def test_matches_goodhart_match(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"goodhart_divergence": True, "min_divergence": 0.15},
            intervention_type=InterventionType.EARLY_STOP,
        )
        warning = FakeGoodhartWarning(divergence=0.3)
        assert _matches_goodhart(policy, warning) is True

    def test_matches_goodhart_low_divergence(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"goodhart_divergence": True, "min_divergence": 0.5},
            intervention_type=InterventionType.EARLY_STOP,
        )
        warning = FakeGoodhartWarning(divergence=0.1)
        assert _matches_goodhart(policy, warning) is False

    def test_matches_goodhart_none_warning(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"goodhart_divergence": True, "min_divergence": 0.1},
            intervention_type=InterventionType.EARLY_STOP,
        )
        assert _matches_goodhart(policy, None) is False

    def test_matches_goodhart_no_goodhart_in_policy(self) -> None:
        policy = InterventionPolicy(
            name="test",
            trigger_conditions={"anomaly_type": "entropy_collapse"},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
        )
        warning = FakeGoodhartWarning(divergence=1.0)
        assert _matches_goodhart(policy, warning) is False


class TestAutoInterventionEngine:
    def test_default_policies_loaded(self) -> None:
        engine = AutoInterventionEngine()
        assert len(engine._policies) == len(_default_policies())

    def test_custom_policies(self) -> None:
        custom = [
            InterventionPolicy(
                name="custom",
                trigger_conditions={"anomaly_type": "custom_type", "min_severity": 0.1},
                intervention_type=InterventionType.PAUSE_AND_EVAL,
            )
        ]
        engine = AutoInterventionEngine(policies=custom)
        assert len(engine._policies) == 1

    def test_evaluate_anomaly_trigger(self) -> None:
        engine = AutoInterventionEngine()
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)
        interventions = engine.evaluate(anomalies=[anomaly])
        assert len(interventions) >= 1
        assert any(i.type == InterventionType.INCREASE_ENTROPY_TEMP for i in interventions)

    def test_evaluate_hacking_trigger(self) -> None:
        engine = AutoInterventionEngine()
        result = FakeHackingResult(pattern_id="memory_gaming", detected=True, confidence=0.6)
        interventions = engine.evaluate(hacking_results=[result])
        assert len(interventions) >= 1

    def test_evaluate_goodhart_trigger(self) -> None:
        engine = AutoInterventionEngine()
        warning = FakeGoodhartWarning(divergence=0.5)
        interventions = engine.evaluate(goodhart_warning=warning)
        assert len(interventions) >= 1
        assert any(i.type == InterventionType.EARLY_STOP for i in interventions)

    def test_evaluate_no_triggers(self) -> None:
        engine = AutoInterventionEngine()
        interventions = engine.evaluate()
        assert interventions == []

    def test_cooldown_respected(self) -> None:
        policy = InterventionPolicy(
            name="cooldown_test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.1},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
            cooldown_seconds=9999,
            max_applications=10,
        )
        engine = AutoInterventionEngine(policies=[policy])
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)

        # First call should trigger
        first = engine.evaluate(anomalies=[anomaly])
        assert len(first) == 1

        # Second call should be blocked by cooldown
        second = engine.evaluate(anomalies=[anomaly])
        assert len(second) == 0

    def test_max_applications_respected(self) -> None:
        policy = InterventionPolicy(
            name="max_test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.1},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
            cooldown_seconds=0,  # No cooldown
            max_applications=2,
        )
        engine = AutoInterventionEngine(policies=[policy])
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)

        assert len(engine.evaluate(anomalies=[anomaly])) == 1
        assert len(engine.evaluate(anomalies=[anomaly])) == 1
        # Third should be blocked
        assert len(engine.evaluate(anomalies=[anomaly])) == 0

    def test_apply(self) -> None:
        engine = AutoInterventionEngine()
        intervention = AutoIntervention(
            type=InterventionType.REDUCE_LR,
            config_changes={"lr_factor": 0.5},
        )
        changes = engine.apply(intervention)
        assert changes == {"lr_factor": 0.5}
        assert intervention.applied is True
        assert intervention.result is not None
        assert intervention.result["status"] == "applied"

    def test_register_policy(self) -> None:
        engine = AutoInterventionEngine()
        initial_count = len(engine._policies)
        engine.register_policy(
            InterventionPolicy(
                name="new_policy",
                trigger_conditions={},
                intervention_type=InterventionType.PAUSE_AND_EVAL,
            )
        )
        assert len(engine._policies) == initial_count + 1

    def test_intervention_history(self) -> None:
        engine = AutoInterventionEngine()
        assert engine.intervention_history() == []
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)
        engine.evaluate(anomalies=[anomaly])
        assert len(engine.intervention_history()) >= 1

    def test_active_cooldowns(self) -> None:
        policy = InterventionPolicy(
            name="cd_test",
            trigger_conditions={"anomaly_type": "entropy_collapse", "min_severity": 0.1},
            intervention_type=InterventionType.INCREASE_ENTROPY_TEMP,
            cooldown_seconds=3600,
            max_applications=10,
        )
        engine = AutoInterventionEngine(policies=[policy])
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)
        engine.evaluate(anomalies=[anomaly])
        cooldowns = engine.active_cooldowns()
        assert "cd_test" in cooldowns
        assert cooldowns["cd_test"]["remaining_seconds"] > 0

    def test_summary(self) -> None:
        engine = AutoInterventionEngine()
        anomaly = FakeAnomaly(type=FakeAnomalyType(value="entropy_collapse"), severity=0.5)
        interventions = engine.evaluate(anomalies=[anomaly])
        for i in interventions:
            engine.apply(i)
        s = engine.summary()
        assert s["total_policies"] == len(_default_policies())
        assert s["total_interventions"] >= 1
        assert s["applied"] >= 1

    def test_summary_empty(self) -> None:
        engine = AutoInterventionEngine()
        s = engine.summary()
        assert s["total_interventions"] == 0
        assert s["applied"] == 0
        assert s["pending"] == 0


# =====================================================================
# observatory/efficiency.py — EfficiencyTracker
# =====================================================================


class TestEfficiencyTracker:
    def test_start_and_end_run(self) -> None:
        tracker = EfficiencyTracker()
        snap = tracker.start_run("r1")
        assert snap.run_id == "r1"
        result = tracker.end_run("r1")
        assert result is not None
        assert result.run_id == "r1"

    def test_end_run_active(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        result = tracker.end_run()  # No explicit run_id
        assert result is not None
        assert tracker._active_run is None

    def test_end_run_unknown(self) -> None:
        tracker = EfficiencyTracker()
        assert tracker.end_run("nonexistent") is None

    def test_end_run_no_active(self) -> None:
        tracker = EfficiencyTracker()
        assert tracker.end_run() is None

    def test_record_tokens(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=100, output_tokens=50)
        tracker.record_tokens(input_tokens=200, output_tokens=100)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.input_tokens == 300
        assert snap.efficiency.output_tokens == 150
        assert snap.efficiency.total_tokens == 450

    def test_record_tokens_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_tokens(input_tokens=100, output_tokens=50)  # No error

    def test_record_latency(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_latency("retrieval", 50.0)
        tracker.record_latency("scoring", 30.0)
        tracker.record_latency("retrieval", 20.0)  # Second call to same stage
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.latency_ms == 100.0
        assert snap.efficiency.latency_per_stage["retrieval"] == 70.0
        assert snap.efficiency.latency_per_stage["scoring"] == 30.0
        # Stage breakdown
        assert len(snap.stage_breakdown) == 2
        retrieval_stage = next(s for s in snap.stage_breakdown if s.stage_name == "retrieval")
        assert retrieval_stage.calls == 2
        assert retrieval_stage.latency_ms == 70.0

    def test_record_latency_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_latency("x", 10.0)  # No error

    def test_record_tool_call(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_tool_call(useful=True)
        tracker.record_tool_call(useful=True)
        tracker.record_tool_call(useful=False)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.tool_calls_total == 3
        assert snap.efficiency.tool_calls_useful == 2

    def test_record_tool_call_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_tool_call()  # No error

    def test_record_retrieval(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_retrieval(relevant=True)
        tracker.record_retrieval(relevant=False)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.retrieval_total == 2
        assert snap.efficiency.retrieval_relevant == 1

    def test_record_retrieval_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_retrieval()  # No error

    def test_record_context_utilization(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_context_utilization(total_context_tokens=1000, used_context_tokens=750)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.context_utilization == 0.75

    def test_record_context_utilization_zero_total(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_context_utilization(total_context_tokens=0, used_context_tokens=0)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.context_utilization == 0.0  # Unchanged from default

    def test_record_context_utilization_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_context_utilization(100, 50)  # No error

    def test_record_redundancy(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_redundancy(total_outputs=100, unique_outputs=80)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.redundancy_rate == 0.2

    def test_record_redundancy_zero_total(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_redundancy(total_outputs=0, unique_outputs=0)
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.redundancy_rate == 0.0

    def test_record_redundancy_no_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.record_redundancy(10, 5)  # No error

    def test_get_efficiency(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=500, output_tokens=200)
        eff = tracker.get_efficiency("r1")
        assert eff is not None
        assert eff.total_tokens == 700

    def test_get_efficiency_no_run(self) -> None:
        tracker = EfficiencyTracker()
        assert tracker.get_efficiency("nonexistent") is None

    def test_get_efficiency_active_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        eff = tracker.get_efficiency()  # Uses active run
        assert eff is not None

    def test_compare_runs(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=100, output_tokens=50)
        tracker.record_latency("s1", 200.0)
        tracker.end_run("r1")

        tracker.start_run("r2")
        tracker.record_tokens(input_tokens=200, output_tokens=100)
        tracker.record_latency("s1", 150.0)
        tracker.end_run("r2")

        comparison = tracker.compare_runs("r1", "r2")
        assert comparison["run_a"] == "r1"
        assert comparison["run_b"] == "r2"
        assert comparison["tokens"]["delta"] > 0  # r2 has more tokens
        assert comparison["latency_ms"]["delta"] < 0  # r2 is faster

    def test_compare_runs_missing(self) -> None:
        tracker = EfficiencyTracker()
        result = tracker.compare_runs("a", "b")
        assert "error" in result

    def test_compare_runs_one_missing(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        result = tracker.compare_runs("r1", "nonexistent")
        assert "error" in result

    def test_all_runs(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=100, output_tokens=50)
        tracker.end_run("r1")
        tracker.start_run("r2")
        tracker.end_run("r2")

        runs = tracker.all_runs()
        assert len(runs) == 2
        assert runs[0]["run_id"] == "r1"
        assert runs[0]["total_tokens"] == 150

    def test_all_runs_empty(self) -> None:
        tracker = EfficiencyTracker()
        assert tracker.all_runs() == []

    def test_cost_estimate_default_model(self) -> None:
        tracker = EfficiencyTracker(model_name="default")
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=1000, output_tokens=1000)
        tracker.end_run("r1")
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        assert snap.efficiency.cost_estimate_usd > 0

    def test_cost_estimate_known_model(self) -> None:
        tracker = EfficiencyTracker(model_name="gpt-4o")
        tracker.start_run("r1")
        tracker.record_tokens(input_tokens=1000, output_tokens=1000)
        tracker.end_run("r1")
        snap = tracker.get_snapshot("r1")
        assert snap is not None
        # gpt-4o: 1K input * 0.005 + 1K output * 0.015 = 0.02
        assert snap.efficiency.cost_estimate_usd == 0.02

    def test_cost_estimate_unknown_model_uses_default(self) -> None:
        tracker = EfficiencyTracker(model_name="some-unknown-model")
        cost = tracker._estimate_cost(1000, 1000)
        default_cost = EfficiencyTracker(model_name="default")._estimate_cost(1000, 1000)
        assert cost == default_cost

    def test_get_snapshot_active_run(self) -> None:
        tracker = EfficiencyTracker()
        tracker.start_run("r1")
        snap = tracker.get_snapshot()  # No run_id, uses active
        assert snap is not None
        assert snap.run_id == "r1"

    def test_get_snapshot_no_active(self) -> None:
        tracker = EfficiencyTracker()
        assert tracker.get_snapshot() is None


# =====================================================================
# observatory/interventions.py — InterventionEngine
# =====================================================================


class TestInterventionEngine:
    def test_default_rules_loaded(self) -> None:
        engine = InterventionEngine()
        assert len(engine._rules) > 0

    def test_evaluate_reward_inflation(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        interventions = engine.evaluate(check)
        assert len(interventions) >= 1
        assert any(i.intervention_type == "pause_training" for i in interventions)

    def test_evaluate_reward_oscillation(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_oscillation"]},
        )
        interventions = engine.evaluate(check)
        assert any(i.intervention_type == "lr_adjustment" for i in interventions)

    def test_evaluate_exploding_gradients(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="gradient_health",
            healthy=False,
            details={"issues": ["exploding_gradients"]},
        )
        interventions = engine.evaluate(check)
        assert any(i.intervention_type == "lr_adjustment" for i in interventions)
        critical = [i for i in interventions if i.severity == "critical"]
        assert len(critical) >= 1

    def test_evaluate_vanishing_gradients(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="gradient_health",
            healthy=False,
            details={"issues": ["vanishing_gradients"]},
        )
        interventions = engine.evaluate(check)
        assert any(
            i.intervention_type == "lr_adjustment" and i.parameters.get("factor") == 2.0
            for i in interventions
        )

    def test_evaluate_memory_capacity_pressure(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="memory_health",
            healthy=False,
            details={"issues": ["capacity_pressure"]},
        )
        interventions = engine.evaluate(check)
        assert any(i.intervention_type == "memory_gc" for i in interventions)

    def test_evaluate_memory_staleness(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="memory_health",
            healthy=False,
            details={"issues": ["high_staleness"]},
        )
        interventions = engine.evaluate(check)
        assert any(
            i.intervention_type == "memory_gc" and i.parameters.get("action") == "evict_stale"
            for i in interventions
        )

    def test_evaluate_drift_severe(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="drift",
            healthy=False,
            details={"z_score": 4.0, "issues": ["distribution_drift"]},
        )
        interventions = engine.evaluate(check)
        assert any(i.intervention_type == "alert_escalation" for i in interventions)

    def test_evaluate_drift_moderate(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="drift",
            healthy=False,
            details={"z_score": 1.0, "issues": ["distribution_drift"]},
        )
        interventions = engine.evaluate(check)
        assert any(i.intervention_type == "checkpoint_rollback" for i in interventions)

    def test_evaluate_healthy_check_no_interventions(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=True,
            details={"issues": []},
        )
        interventions = engine.evaluate(check)
        assert interventions == []

    def test_evaluate_unknown_check_no_interventions(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="unknown_check",
            healthy=False,
            details={"issues": ["something"]},
        )
        interventions = engine.evaluate(check)
        assert interventions == []

    def test_cooldown_prevents_repeat(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        first = engine.evaluate(check)
        assert len(first) >= 1
        # Immediately evaluate again — cooldown should block
        second = engine.evaluate(check)
        assert len(second) == 0

    def test_evaluate_all(self) -> None:
        engine = InterventionEngine()
        checks = [
            HealthCheckResult(
                check_name="reward_hacking",
                healthy=False,
                details={"issues": ["reward_inflation"]},
            ),
            HealthCheckResult(
                check_name="gradient_health",
                healthy=False,
                details={"issues": ["exploding_gradients"]},
            ),
        ]
        interventions = engine.evaluate_all(checks)
        assert len(interventions) >= 2

    def test_add_rule(self) -> None:
        engine = InterventionEngine()
        initial = len(engine._rules)
        engine.add_rule(
            InterventionRule(
                check_name="custom",
                condition=lambda r: not r.healthy,
                intervention_type="custom_action",
            )
        )
        assert len(engine._rules) == initial + 1

    def test_mark_executed(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        interventions = engine.evaluate(check)
        assert len(interventions) >= 1
        iid = interventions[0].id
        assert engine.mark_executed(iid, result={"ok": True}) is True
        assert interventions[0].executed is True
        assert interventions[0].result == {"ok": True}

    def test_mark_executed_nonexistent(self) -> None:
        engine = InterventionEngine()
        assert engine.mark_executed("nonexistent-id") is False

    def test_history(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        engine.evaluate(check)
        history = engine.history()
        assert len(history) >= 1

    def test_history_limit(self) -> None:
        engine = InterventionEngine()
        # Fill history with evaluations from different check types
        for name in ["reward_hacking", "gradient_health", "memory_health"]:
            issues_map = {
                "reward_hacking": ["reward_inflation"],
                "gradient_health": ["exploding_gradients"],
                "memory_health": ["capacity_pressure"],
            }
            engine.evaluate(
                HealthCheckResult(
                    check_name=name,
                    healthy=False,
                    details={"issues": issues_map[name]},
                )
            )
        history = engine.history(limit=2)
        assert len(history) <= 2

    def test_pending(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        interventions = engine.evaluate(check)
        assert len(engine.pending()) >= 1
        engine.mark_executed(interventions[0].id)
        # After marking executed, pending count should decrease
        pending_ids = {i.id for i in engine.pending()}
        assert interventions[0].id not in pending_ids

    def test_summary(self) -> None:
        engine = InterventionEngine()
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        interventions = engine.evaluate(check)
        if interventions:
            engine.mark_executed(interventions[0].id)
        s = engine.summary()
        assert "total_rules" in s
        assert "total_interventions" in s
        assert "pending" in s
        assert "executed" in s
        assert s["executed"] >= 1

    def test_disabled_rule_skipped(self) -> None:
        engine = InterventionEngine()
        # Disable all existing rules
        for rule in engine._rules:
            rule.enabled = False
        check = HealthCheckResult(
            check_name="reward_hacking",
            healthy=False,
            details={"issues": ["reward_inflation"]},
        )
        interventions = engine.evaluate(check)
        assert interventions == []


# =====================================================================
# security/compliance.py — ComplianceReporter
# =====================================================================


class TestComplianceControls:
    def test_soc2_controls_defined(self) -> None:
        assert len(SOC2_CONTROLS) == 10
        assert all(c.framework == "soc2" for c in SOC2_CONTROLS)

    def test_finra_controls_defined(self) -> None:
        assert len(FINRA_CONTROLS) == 5
        assert all(c.framework == "finra" for c in FINRA_CONTROLS)

    def test_eu_ai_act_controls_defined(self) -> None:
        assert len(EU_AI_ACT_CONTROLS) == 7
        assert all(c.framework == "eu_ai_act" for c in EU_AI_ACT_CONTROLS)


class TestComplianceReporter:
    def test_list_frameworks(self) -> None:
        reporter = ComplianceReporter()
        frameworks = reporter.list_frameworks()
        assert "soc2" in frameworks
        assert "finra" in frameworks
        assert "eu_ai_act" in frameworks

    def test_assess_soc2_no_capabilities(self) -> None:
        reporter = ComplianceReporter()
        report = reporter.assess("soc2")
        assert report.framework == "soc2"
        assert report.overall_status == "non_compliant"
        assert len(report.controls) == 10
        # All should be not_assessed when no capabilities provided
        assert all(c.status == "not_assessed" for c in report.controls)

    def test_assess_soc2_all_capabilities(self) -> None:
        reporter = ComplianceReporter()
        caps = {
            "rbac_enabled": True,
            "audit_logging": True,
            "anomaly_detection": True,
            "change_management": True,
            "data_encryption": True,
            "data_governance": True,
            "risk_management": True,
            "accuracy_monitoring": True,
            "capacity_monitoring": True,
        }
        report = reporter.assess("soc2", capabilities=caps)
        assert report.framework == "soc2"
        assert report.overall_status == "compliant"
        assert all(c.status == "compliant" for c in report.controls)

    def test_assess_soc2_partial_capabilities(self) -> None:
        reporter = ComplianceReporter()
        caps = {
            "rbac_enabled": True,
            "audit_logging": True,
        }
        report = reporter.assess("soc2", capabilities=caps)
        assert report.overall_status == "partial"
        compliant = [c for c in report.controls if c.status == "compliant"]
        non_compliant = [c for c in report.controls if c.status == "non_compliant"]
        assert len(compliant) > 0
        assert len(non_compliant) > 0

    def test_assess_finra(self) -> None:
        reporter = ComplianceReporter()
        caps = {
            "audit_logging": True,
            "transparency": True,
            "human_oversight": True,
            "aml_compliance": True,
            "suitability_checks": True,
        }
        report = reporter.assess("finra", capabilities=caps)
        assert report.framework == "finra"
        assert len(report.controls) == 5

    def test_assess_eu_ai_act(self) -> None:
        reporter = ComplianceReporter()
        caps = {
            "rbac_enabled": True,
            "audit_logging": True,
            "data_governance": True,
            "transparency": True,
            "human_oversight": True,
            "accuracy_monitoring": True,
            "risk_management": True,
            "technical_documentation": True,
        }
        report = reporter.assess("eu_ai_act", capabilities=caps)
        assert report.framework == "eu_ai_act"
        assert report.overall_status == "compliant"

    def test_assess_unknown_framework(self) -> None:
        reporter = ComplianceReporter()
        report = reporter.assess("unknown_framework")
        assert report.overall_status == "unknown"
        assert report.controls == []

    def test_assessment_history(self) -> None:
        reporter = ComplianceReporter()
        reporter.assess("soc2")
        reporter.assess("finra")
        reporter.assess("soc2", capabilities={"rbac_enabled": True})

        all_history = reporter.assessment_history()
        assert len(all_history) == 3

        soc2_history = reporter.assessment_history(framework="soc2")
        assert len(soc2_history) == 2
        assert all(r.framework == "soc2" for r in soc2_history)

    def test_assessment_history_limit(self) -> None:
        reporter = ComplianceReporter()
        for _ in range(5):
            reporter.assess("soc2")
        history = reporter.assessment_history(limit=3)
        assert len(history) == 3

    def test_gap_analysis(self) -> None:
        reporter = ComplianceReporter()
        reporter.assess("soc2", capabilities={"rbac_enabled": True})
        gaps = reporter.gap_analysis("soc2")
        assert gaps["framework"] == "soc2"
        assert gaps["total_controls"] == 10
        assert gaps["compliant"] > 0
        assert len(gaps["non_compliant_controls"]) > 0

    def test_gap_analysis_no_assessments(self) -> None:
        reporter = ComplianceReporter()
        result = reporter.gap_analysis("soc2")
        assert "error" in result

    def test_gap_analysis_with_partial(self) -> None:
        reporter = ComplianceReporter()
        reporter.assess("finra", capabilities={"audit_logging": True})
        gaps = reporter.gap_analysis("finra")
        assert gaps["framework"] == "finra"
        # Some controls are non-compliant
        assert len(gaps["non_compliant_controls"]) > 0

    def test_report_has_id(self) -> None:
        reporter = ComplianceReporter()
        report = reporter.assess("soc2")
        assert report.id.startswith("compliance_soc2_")

    def test_controls_have_evidence_and_gaps(self) -> None:
        reporter = ComplianceReporter()
        report = reporter.assess("soc2", capabilities={"rbac_enabled": True})
        compliant = [c for c in report.controls if c.status == "compliant"]
        non_compliant = [c for c in report.controls if c.status == "non_compliant"]
        assert all(len(c.evidence) > 0 for c in compliant)
        assert all(len(c.gaps) > 0 for c in non_compliant)

    def test_disabled_capability_not_counted(self) -> None:
        reporter = ComplianceReporter()
        caps = {"rbac_enabled": False, "audit_logging": False}
        report = reporter.assess("soc2", capabilities=caps)
        # Disabled capabilities shouldn't make controls compliant
        compliant = [c for c in report.controls if c.status == "compliant"]
        assert len(compliant) == 0
