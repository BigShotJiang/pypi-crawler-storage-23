"""Shared fixtures for integration tests."""

from __future__ import annotations

import pytest

from aegis.core.types import (
    EvalCaseV1,
    EvalTier,
)
from aegis.memory.graph import KnowledgeGraph
from aegis.memory.operations import MemoryPolicyEngine
from aegis.memory.provenance import ProvenanceTracker
from aegis.memory.store import InMemoryStore


@pytest.fixture
def sample_text() -> str:
    """Return a multi-paragraph test document for ingestion tests.

    The document contains four paragraphs covering different topics,
    giving the ingestion pipeline enough content to produce multiple
    chunks with meaningful text.
    """
    return (
        "The Aegis platform provides a comprehensive evaluation framework "
        "for AI agents. It measures agent intelligence across 40 dimensions "
        "organized into 6 tiers, from basic memory fidelity to advanced "
        "metacognitive reasoning.\n\n"
        "Memory operations form the foundation of the system. Aegis supports "
        "12 RL-trained memory operations including STORE, RETRIEVE, UPDATE, "
        "FORGET, LINK, COMPRESS, PROMOTE, DEMOTE, SPLIT, MERGE, VERIFY, and "
        "ANNOTATE. Each operation is governed by learned policies.\n\n"
        "The training engine uses Group Relative Policy Optimization (GRPO) "
        "with a 7-stage curriculum. The AMIR-GRPO variant adds adaptive "
        "memory-integrated rewards that align training signals with actual "
        "memory retrieval quality.\n\n"
        "The Observatory monitoring layer provides real-time health checks "
        "for reward hacking detection, gradient stability analysis, memory "
        "subsystem integrity, and distribution drift monitoring. All metrics "
        "are surfaced through a unified dashboard."
    )


@pytest.fixture
def sample_eval_case() -> EvalCaseV1:
    """Return a sample EvalCaseV1 for evaluation tests."""
    return EvalCaseV1(
        suite_id="integration-test-v1",
        dimension_id="retention_accuracy",
        tier=EvalTier.MEMORY_FIDELITY,
        prompt="What memory operations does the Aegis platform support?",
        context={"session_history": ["session_1", "session_2"]},
        expected={"answer_contains": "12 RL-trained memory operations"},
        difficulty=2,
        tags=["memory", "integration", "e2e"],
    )


@pytest.fixture
def memory_engine() -> MemoryPolicyEngine:
    """Return a MemoryPolicyEngine backed by InMemoryStore.

    Includes a KnowledgeGraph and ProvenanceTracker for full
    operation coverage in integration tests.
    """
    store = InMemoryStore()
    graph = KnowledgeGraph()
    provenance = ProvenanceTracker()
    return MemoryPolicyEngine(store=store, graph=graph, provenance=provenance)
