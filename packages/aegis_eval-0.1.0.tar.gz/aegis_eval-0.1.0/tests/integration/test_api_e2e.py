"""API server end-to-end integration test.

Starts the FastAPI app with TestClient and exercises key endpoints
including health, eval, memory, training, observatory, and ingestion.
"""

from __future__ import annotations

import io

import pytest
from fastapi.testclient import TestClient

from aegis.api.app import create_app

# Mark all tests in this module as integration tests.
pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# TestClient fixture scoped to this module
# ---------------------------------------------------------------------------


@pytest.fixture
def client() -> TestClient:
    """Create a fresh TestClient for each test using the app factory."""
    app = create_app()
    return TestClient(app)


# ---------------------------------------------------------------------------
# 1. Health Endpoint
# ---------------------------------------------------------------------------


class TestHealthEndpoint:
    """Verify the /health liveness probe."""

    def test_health_endpoint(self, client: TestClient) -> None:
        """GET /health should return 200 with status 'ok'."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "timestamp" in data


# ---------------------------------------------------------------------------
# 2. Eval Endpoints
# ---------------------------------------------------------------------------


class TestEvalCreateAndRun:
    """Verify eval run creation and retrieval via API."""

    def test_eval_create_and_run(self, client: TestClient) -> None:
        """POST /v1/evals/runs should create and complete an eval run."""
        response = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "run_id" in data
        assert data["status"] == "completed"

        # Verify we can retrieve the run
        run_id = data["run_id"]
        get_response = client.get(f"/v1/evals/runs/{run_id}")
        assert get_response.status_code == 200
        get_data = get_response.json()
        assert get_data["run_id"] == run_id
        assert get_data["status"] == "completed"
        assert "overall_score" in get_data
        assert "dimension_scores" in get_data

    def test_eval_list_dimensions(self, client: TestClient) -> None:
        """GET /v1/evals/dimensions should return registered dimensions."""
        response = client.get("/v1/evals/dimensions")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0

    def test_eval_compare_runs(self, client: TestClient) -> None:
        """POST /v1/evals/compare should compare two eval runs."""
        # Create two runs to compare
        resp_a = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 3,
            },
        )
        resp_b = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 3,
            },
        )
        run_id_a = resp_a.json()["run_id"]
        run_id_b = resp_b.json()["run_id"]

        compare_resp = client.post(
            "/v1/evals/compare",
            json={"run_id_a": run_id_a, "run_id_b": run_id_b},
        )
        assert compare_resp.status_code == 200
        data = compare_resp.json()
        assert data["run_id_a"] == run_id_a
        assert data["run_id_b"] == run_id_b
        assert "deltas" in data

    def test_eval_benchmark_routes(self, client: TestClient) -> None:
        """GET benchmark suite list and run one benchmark via eval routes."""
        list_resp = client.get("/v1/evals/benchmarks")
        assert list_resp.status_code == 200
        suites = list_resp.json()
        assert isinstance(suites, list)
        assert any(s["name"] == "legal-memory" for s in suites)

        run_resp = client.post(
            "/v1/evals/benchmarks/run",
            json={
                "suite": "finance-memory",
                "difficulty_filter": 2,
                "scorer_mode": "mock",
            },
        )
        assert run_resp.status_code == 200
        payload = run_resp.json()
        assert payload["suite"] == "finance-memory"
        assert payload["suite_size"] > 0
        assert 0.0 <= payload["overall_score"] <= 1.0
        assert isinstance(payload["dimension_scores"], dict)

        run_id = payload["run_id"]

        detail_resp = client.get(f"/v1/evals/benchmarks/runs/{run_id}")
        assert detail_resp.status_code == 200
        detail = detail_resp.json()
        assert detail["run_id"] == run_id
        assert detail["suite"] == "finance-memory"

        history_resp = client.get("/v1/evals/benchmarks/history")
        assert history_resp.status_code == 200
        history = history_resp.json()
        assert any(item["run_id"] == run_id for item in history)


# ---------------------------------------------------------------------------
# 3. Arena Endpoints
# ---------------------------------------------------------------------------


class TestArenaEndpoints:
    """Verify arena submission and leaderboard routes."""

    def test_arena_submit_and_fetch(self, client: TestClient) -> None:
        """POST /v1/arena/submit then GET leaderboard and agent detail."""
        submit_resp = client.post(
            "/v1/arena/submit",
            json={
                "agent_name": "integration-arena-agent",
                "agent_description": "Integration test submission for arena endpoints.",
                "framework": "openai",
                "domains": ["legal"],
                "model_size": "medium",
                "public": True,
                "submitted_by": "integration-test",
            },
        )
        assert submit_resp.status_code == 201
        submit_data = submit_resp.json()
        assert submit_data["status"] == "completed"
        assert "submission_id" in submit_data

        submission_id = submit_data["submission_id"]

        leaderboard_resp = client.get("/v1/arena/leaderboard")
        assert leaderboard_resp.status_code == 200
        leaderboard = leaderboard_resp.json()
        assert leaderboard["total_entries"] >= 1
        assert any(row["agent_id"] == submission_id for row in leaderboard["entries"])

        details_resp = client.get(f"/v1/arena/agent/{submission_id}")
        assert details_resp.status_code == 200
        details = details_resp.json()
        assert details["agent_id"] == submission_id
        assert details["status"] == "completed"
        assert 0.0 <= details["overall_score"] <= 1.0

    def test_arena_agent_not_found(self, client: TestClient) -> None:
        """GET /v1/arena/agent/{id} returns 404 for unknown IDs."""
        response = client.get("/v1/arena/agent/does-not-exist")
        assert response.status_code == 404


# ---------------------------------------------------------------------------
# 4. Memory Endpoints
# ---------------------------------------------------------------------------


class TestMemoryEndpoints:
    """Verify memory CRUD operations via the API."""

    def test_memory_store_and_retrieve(self, client: TestClient) -> None:
        """POST /v1/memory/store then POST /v1/memory/retrieve."""
        # Store an entry
        store_resp = client.post(
            "/v1/memory/store",
            json={
                "key": "client_preference",
                "value": "Client prefers bullet-point summaries",
                "tier": "session",
                "confidence": 0.95,
            },
        )
        assert store_resp.status_code == 201
        store_data = store_resp.json()
        assert store_data["key"] == "client_preference"
        assert store_data["status"] == "stored"

        # Retrieve by key
        retrieve_resp = client.post(
            "/v1/memory/retrieve",
            json={"query": "client_preference", "mode": "key"},
        )
        assert retrieve_resp.status_code == 200
        entries = retrieve_resp.json()
        assert len(entries) >= 1
        assert entries[0]["key"] == "client_preference"

    def test_memory_emit_event(self, client: TestClient) -> None:
        """POST /v1/memory/events should accept a memory event."""
        response = client.post(
            "/v1/memory/events",
            json={
                "operation": "STORE",
                "memory_tier": "session",
                "key": "meeting_notes",
                "value": "Discussed contract terms for Q2",
                "agent_id": "agent-integration",
                "customer_id": "acme-corp",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "id" in data
        assert data["status"] == "accepted"

    def test_memory_query(self, client: TestClient) -> None:
        """POST /v1/memory/query should return results."""
        response = client.post(
            "/v1/memory/query",
            json={"query": "contract terms", "customer_id": "acme-corp"},
        )
        assert response.status_code == 200
        # Response is a list (may be empty if no matching entries)
        assert isinstance(response.json(), list)

    def test_memory_update_and_delete(self, client: TestClient) -> None:
        """PUT /v1/memory/{key} and DELETE /v1/memory/{key}."""
        # Store an entry first
        client.post(
            "/v1/memory/store",
            json={
                "key": "temp_entry",
                "value": "Temporary value",
                "tier": "working",
            },
        )

        # Update
        update_resp = client.put(
            "/v1/memory/temp_entry",
            json={"value": "Updated temporary value"},
        )
        assert update_resp.status_code == 200
        assert update_resp.json()["key"] == "temp_entry"

        # Delete
        delete_resp = client.delete("/v1/memory/temp_entry")
        assert delete_resp.status_code == 200
        assert delete_resp.json()["key"] == "temp_entry"

    def test_memory_link(self, client: TestClient) -> None:
        """POST /v1/memory/link should create a semantic link."""
        # Store two entries
        client.post(
            "/v1/memory/store",
            json={"key": "link_a", "value": "Entry A", "tier": "working"},
        )
        client.post(
            "/v1/memory/store",
            json={"key": "link_b", "value": "Entry B", "tier": "working"},
        )

        # Link them
        link_resp = client.post(
            "/v1/memory/link",
            json={"key_a": "link_a", "key_b": "link_b", "relation": "related_to"},
        )
        assert link_resp.status_code == 200
        data = link_resp.json()
        assert data["key_a"] == "link_a"
        assert data["key_b"] == "link_b"

    def test_memory_health(self, client: TestClient) -> None:
        """GET /v1/memory/health should return subsystem health."""
        response = client.get("/v1/memory/health")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, dict)


# ---------------------------------------------------------------------------
# 5. Training Endpoints
# ---------------------------------------------------------------------------


class TestTrainingEndpoints:
    """Verify training job lifecycle via the API."""

    def test_training_create_and_run(self, client: TestClient) -> None:
        """POST /v1/train/jobs then POST /v1/train/jobs/{id}/run."""
        # Create a training job
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-cust",
                "domain": "legal",
                "optimizer": "AMIR-GRPO",
            },
        )
        assert create_resp.status_code == 201
        create_data = create_resp.json()
        assert "job_id" in create_data
        assert create_data["status"] == "created"

        job_id = create_data["job_id"]

        # Run the training job
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200
        run_data = run_resp.json()
        assert run_data["job_id"] == job_id
        assert run_data["status"] == "completed"
        assert run_data["metrics"]["mean_reward"] > 0
        assert run_data["metrics"]["episodes_completed"] > 0

    def test_training_job_metrics(self, client: TestClient) -> None:
        """GET /v1/train/jobs/{id}/metrics after a completed run."""
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-metrics",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        client.post(f"/v1/train/jobs/{job_id}/run")

        metrics_resp = client.get(f"/v1/train/jobs/{job_id}/metrics")
        assert metrics_resp.status_code == 200
        metrics = metrics_resp.json()
        assert metrics["total_stages"] >= 1
        assert metrics["mean_reward"] > 0

    def test_training_job_result(self, client: TestClient) -> None:
        """GET /v1/train/jobs/{id}/result after a completed run."""
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-result",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        client.post(f"/v1/train/jobs/{job_id}/run")

        result_resp = client.get(f"/v1/train/jobs/{job_id}/result")
        assert result_resp.status_code == 200
        payload = result_resp.json()
        assert payload["job_id"] == job_id
        assert payload["status"] == "completed"
        assert "result" in payload

    def test_training_list_jobs(self, client: TestClient) -> None:
        """GET /v1/train/jobs should list created jobs."""
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-list",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]

        list_resp = client.get("/v1/train/jobs")
        assert list_resp.status_code == 200
        jobs = list_resp.json()
        assert isinstance(jobs, list)
        assert any(job["job_id"] == job_id for job in jobs)

    def test_training_stop_job(self, client: TestClient) -> None:
        """POST /v1/train/jobs/{id}/stop should cancel a job."""
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-stop",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]

        stop_resp = client.post(
            f"/v1/train/jobs/{job_id}/stop",
            json={"reason": "integration test cancellation"},
        )
        assert stop_resp.status_code == 200
        assert stop_resp.json()["status"] == "cancelled"


# ---------------------------------------------------------------------------
# 6. Observatory Endpoints
# ---------------------------------------------------------------------------


class TestObservatoryEndpoints:
    """Verify observatory observability event ingestion."""

    def test_observatory_emit_event(self, client: TestClient) -> None:
        """POST /v1/observability/events should accept events."""
        response = client.post(
            "/v1/observability/events",
            json={
                "event_type": "agent.step",
                "agent_id": "integration-agent",
                "payload": {"step": 1, "action": "search", "reward": 0.75},
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "id" in data
        assert data["status"] == "accepted"

    def test_observatory_health_check_event(self, client: TestClient) -> None:
        """POST /v1/observability/events with health_check type should trigger checks."""
        response = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.reward",
                "agent_id": "integration-agent",
                "payload": {
                    "reward_traces": [{"reward": 0.5 + i * 0.02} for i in range(10)],
                },
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["status"] == "accepted"

    def test_observatory_training_job_health(self, client: TestClient) -> None:
        """GET /v1/train/jobs/{id}/observatory after a completed run."""
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "integration-obs",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        client.post(f"/v1/train/jobs/{job_id}/run")

        observ_resp = client.get(f"/v1/train/jobs/{job_id}/observatory")
        assert observ_resp.status_code == 200
        report = observ_resp.json()
        assert report["job_id"] == job_id
        assert "overall_healthy" in report
        assert "composite_score" in report
        assert "checks" in report
        assert "reward_hacking" in report["checks"]
        assert "gradient_health" in report["checks"]
        assert "memory_health" in report["checks"]
        assert "drift" in report["checks"]


# ---------------------------------------------------------------------------
# 6. Ingestion Endpoint
# ---------------------------------------------------------------------------


class TestIngestionEndpoint:
    """Verify document ingestion via the API."""

    def test_ingestion_upload(self, client: TestClient) -> None:
        """POST /v1/ingestion/upload should parse and return chunks."""
        content = (
            "The Aegis evaluation framework measures agent intelligence "
            "across multiple dimensions and tiers.\n\n"
            "Memory operations form the foundation of the platform, "
            "supporting 12 distinct operations with learned policies."
        )
        files = {"file": ("test_doc.txt", io.BytesIO(content.encode()), "text/plain")}
        response = client.post("/v1/ingestion/upload", files=files)
        assert response.status_code == 201
        data = response.json()
        assert "document_id" in data
        assert data["num_chunks"] >= 2
        assert len(data["chunks"]) >= 2
        assert data["source_path"] == "test_doc.txt"

    def test_ingestion_history(self, client: TestClient) -> None:
        """GET /v1/ingestion/history should return past ingestions."""
        response = client.get("/v1/ingestion/history")
        assert response.status_code == 200
        assert isinstance(response.json(), list)

    def test_ingestion_formats(self, client: TestClient) -> None:
        """GET /v1/ingestion/formats should list supported file formats."""
        response = client.get("/v1/ingestion/formats")
        assert response.status_code == 200
        data = response.json()
        assert "extensions" in data
        assert "parsers" in data
        assert ".txt" in data["extensions"]
        assert ".json" in data["extensions"]
        assert ".csv" in data["extensions"]


# ---------------------------------------------------------------------------
# 7. Full API Pipeline (chained operations)
# ---------------------------------------------------------------------------


class TestFullAPIPipeline:
    """Chain multiple API operations in a single test to verify cross-cutting concerns."""

    def test_full_api_pipeline(self, client: TestClient) -> None:
        """Exercise the full API pipeline: health -> ingest -> memory -> eval -> train."""
        # Step 1: Health check
        health_resp = client.get("/health")
        assert health_resp.status_code == 200
        assert health_resp.json()["status"] == "ok"

        # Step 2: Ingest a document
        doc_content = (
            "Contract clause 4.2 covers indemnification terms between parties.\n\n"
            "The liability cap is set at two times the annual contract value."
        )
        files = {"file": ("contract.txt", io.BytesIO(doc_content.encode()), "text/plain")}
        ingest_resp = client.post("/v1/ingestion/upload", files=files)
        assert ingest_resp.status_code == 201
        assert ingest_resp.json()["num_chunks"] >= 2

        # Step 3: Store in memory
        store_resp = client.post(
            "/v1/memory/store",
            json={
                "key": "contract_4_2",
                "value": "Indemnification clause from contract",
                "tier": "session",
                "confidence": 0.9,
            },
        )
        assert store_resp.status_code == 201

        # Step 4: Run eval
        eval_resp = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 3,
            },
        )
        assert eval_resp.status_code == 201
        assert eval_resp.json()["status"] == "completed"

        # Step 5: Create and run training job
        train_create = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "full-pipeline-cust",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        assert train_create.status_code == 201
        job_id = train_create.json()["job_id"]

        train_run = client.post(f"/v1/train/jobs/{job_id}/run")
        assert train_run.status_code == 200
        assert train_run.json()["status"] == "completed"

        # Step 6: Check Observatory report
        observ_resp = client.get(f"/v1/train/jobs/{job_id}/observatory")
        assert observ_resp.status_code == 200
        assert "checks" in observ_resp.json()

        # Step 7: Emit observability event
        event_resp = client.post(
            "/v1/observability/events",
            json={
                "event_type": "pipeline.complete",
                "agent_id": "full-pipeline-agent",
                "payload": {"pipeline": "integration_test", "status": "success"},
            },
        )
        assert event_resp.status_code == 201
        assert event_resp.json()["status"] == "accepted"
