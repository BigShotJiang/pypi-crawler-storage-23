"""End-to-end pipeline integration test.

Tests the full Aegis workflow:
1. Ingest a document
2. Run eval on an agent
3. Verify Observatory monitoring
4. Check memory operations
5. Run training pipeline
6. Chain all steps together
"""

from __future__ import annotations

import pytest

from aegis.core.types import (
    MemoryOperation,
    MemoryTier,
)
from aegis.eval.engine import EvalConfig, EvalResult, Evaluator
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline, IngestionResult
from aegis.memory.graph import KnowledgeGraph
from aegis.memory.operations import MemoryPolicyEngine
from aegis.memory.provenance import ProvenanceTracker
from aegis.memory.store import InMemoryStore
from aegis.memory.types import MemoryEntry
from aegis.observatory.monitor import HealthCheckResult, ObservatoryMonitor
from aegis.training.engine import AMIRGRPOTrainer

# Mark all tests in this module as integration tests.
pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# 1. Ingestion Pipeline
# ---------------------------------------------------------------------------


class TestIngestDocument:
    """Verify the ingestion pipeline parses and chunks documents correctly."""

    def test_ingest_document(self, sample_text: str) -> None:
        """Ingest a multi-paragraph text and verify chunking."""
        pipeline = IngestionPipeline(
            config=IngestionConfig(min_chunk_words=3, compute_hashes=True, deduplicate=True)
        )
        result = pipeline.ingest("integration_test.txt", content=sample_text)

        assert isinstance(result, IngestionResult)
        assert result.source_path == "integration_test.txt"
        assert result.num_chunks >= 4, "Expected at least 4 chunks from 4 paragraphs"
        assert result.document_id, "Expected a non-empty document_id"

        # Each chunk should have content and metadata
        for chunk in result.chunks:
            assert chunk.content.strip(), "Chunk content should not be empty"
            assert chunk.chunk_index >= 0

        # Hashes should be present when compute_hashes is enabled
        for chunk in result.chunks:
            assert "content_hash" in chunk.metadata, "Expected content_hash in metadata"

    def test_ingest_document_dedup(self) -> None:
        """Verify deduplication removes identical chunks."""
        pipeline = IngestionPipeline(
            config=IngestionConfig(min_chunk_words=1, compute_hashes=True, deduplicate=True)
        )
        content = "Duplicate paragraph content.\n\nDuplicate paragraph content."
        result = pipeline.ingest("dedup_test.txt", content=content)

        assert result.num_chunks == 1, "Identical paragraphs should be deduplicated"

    def test_ingest_tracks_history(self, sample_text: str) -> None:
        """Verify the pipeline tracks ingestion history."""
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        pipeline.ingest("doc_a.txt", content="First document content here and more.")
        pipeline.ingest("doc_b.txt", content=sample_text)

        history = pipeline.history()
        assert len(history) == 2
        assert history[0].source_path == "doc_a.txt"
        assert history[1].source_path == "doc_b.txt"


# ---------------------------------------------------------------------------
# 2. Evaluation Pipeline
# ---------------------------------------------------------------------------


class TestEvalPipeline:
    """Verify the eval engine produces structured results."""

    def test_eval_pipeline(self) -> None:
        """Run an evaluation and verify JudgePacketV1 results."""
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        config = EvalConfig(
            dimensions=["retention_accuracy"],
            num_scenarios=5,
            scorer_mode="mock",
        )
        result = evaluator.run(agent=None, config=config)

        assert isinstance(result, EvalResult)
        assert result.run_id, "Expected a non-empty run_id"
        assert result.overall_score >= 0.0
        assert result.overall_score <= 1.0
        assert len(result.dimension_scores) > 0
        assert "retention_accuracy" in result.dimension_scores

        # Judge packets should have been produced
        assert len(result.judge_packets) > 0
        for packet in result.judge_packets:
            assert packet.dimension_id, "Each packet must have a dimension_id"
            assert packet.ensemble_score >= 0.0
            assert packet.ensemble_score <= 1.0

    def test_eval_multiple_dimensions(self) -> None:
        """Run eval across all dimensions and verify aggregated results."""
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        config = EvalConfig(dimensions="all", num_scenarios=1, scorer_mode="mock")
        result = evaluator.run(agent=None, config=config)

        assert isinstance(result, EvalResult)
        assert len(result.dimension_scores) > 1, "Expected multiple dimension scores"
        assert result.overall_score > 0.0

    def test_eval_compare(self) -> None:
        """Compare two eval runs and verify the delta structure."""
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        config = EvalConfig(dimensions="all", num_scenarios=1, scorer_mode="mock")
        result_a = evaluator.run(agent=None, config=config)
        result_b = evaluator.run(agent=None, config=config)

        comparison = evaluator.compare(result_a, result_b)
        assert "dimension_deltas" in comparison
        assert "overall_delta" in comparison
        assert "improved" in comparison
        assert "regressed" in comparison
        assert "unchanged" in comparison


# ---------------------------------------------------------------------------
# 3. Observatory Monitoring
# ---------------------------------------------------------------------------


class TestObservatoryMonitoring:
    """Verify the Observatory monitoring engine processes metrics correctly."""

    def test_observatory_monitoring(self) -> None:
        """Feed metrics to ObservatoryMonitor and verify health checks."""
        monitor = ObservatoryMonitor()

        # Feed normal reward traces
        reward_traces = [{"reward": 0.5 + i * 0.02} for i in range(10)]
        reward_result = monitor.check_reward_hacking(reward_traces=reward_traces)
        assert isinstance(reward_result, HealthCheckResult)
        assert reward_result.healthy is True
        assert reward_result.check_name == "reward_hacking"

        # Feed normal gradient stats
        gradient_stats = {"norms": [0.1, 0.15, 0.12, 0.11, 0.13]}
        gradient_result = monitor.check_gradient_health(gradient_stats=gradient_stats)
        assert gradient_result.healthy is True
        assert gradient_result.check_name == "gradient_health"

        # Feed normal memory stats
        memory_stats = {"total_entries": 500, "capacity": 10000, "stale_count": 10}
        memory_result = monitor.check_memory_health(memory_stats=memory_stats)
        assert memory_result.healthy is True
        assert memory_result.check_name == "memory_health"

        # Feed distribution data for drift check
        reference = {"mean": 0.5, "variance": 0.04}
        current = {"mean": 0.52, "variance": 0.04}
        drift_result = monitor.check_drift(
            reference_distribution=reference, current_distribution=current
        )
        assert drift_result.healthy is True
        assert drift_result.check_name == "drift"

    def test_observatory_run_all_checks(self) -> None:
        """Verify run_all_checks returns results for all 4 health categories."""
        monitor = ObservatoryMonitor()
        results = monitor.run_all_checks()

        assert len(results) == 4
        check_names = {r.check_name for r in results}
        assert check_names == {"reward_hacking", "gradient_health", "memory_health", "drift"}
        assert all(isinstance(r, HealthCheckResult) for r in results)

    def test_observatory_detects_unhealthy_state(self) -> None:
        """Verify the monitor detects reward inflation as unhealthy."""
        monitor = ObservatoryMonitor()
        inflated_traces = [{"reward": 0.97} for _ in range(20)]
        result = monitor.check_reward_hacking(reward_traces=inflated_traces)

        assert result.healthy is False
        assert "reward_inflation" in result.details["issues"]


# ---------------------------------------------------------------------------
# 4. Memory Operations Pipeline
# ---------------------------------------------------------------------------


class TestMemoryOperationsPipeline:
    """Verify all 12 memory operations in an end-to-end pipeline."""

    def test_memory_operations_pipeline(self, memory_engine: MemoryPolicyEngine) -> None:
        """Test full CRUD cycle plus SPLIT, MERGE, VERIFY, COMPRESS, LINK."""
        engine = memory_engine

        # STORE
        entry = engine.store(
            "contract_clause", "Indemnification clause 4.2 states...", MemoryTier.WORKING
        )
        assert isinstance(entry, MemoryEntry)
        assert entry.key == "contract_clause"
        assert entry.tier == MemoryTier.WORKING

        # RETRIEVE
        retrieved = engine.retrieve("contract_clause")
        assert retrieved is not None
        assert retrieved.value == "Indemnification clause 4.2 states..."

        # UPDATE
        updated = engine.update("contract_clause", "Updated indemnification clause 4.2 states...")
        assert updated is True
        entry_after_update = engine.retrieve("contract_clause")
        assert entry_after_update is not None
        assert "Updated" in str(entry_after_update.value)

        # PROMOTE
        promoted = engine.promote("contract_clause", MemoryTier.PERMANENT)
        assert promoted is True
        entry_after_promote = engine.retrieve("contract_clause")
        assert entry_after_promote is not None
        assert entry_after_promote.tier == MemoryTier.PERMANENT

        # DEMOTE
        demoted = engine.demote("contract_clause", MemoryTier.SESSION)
        assert demoted is True
        entry_after_demote = engine.retrieve("contract_clause")
        assert entry_after_demote is not None
        assert entry_after_demote.tier == MemoryTier.SESSION

        # ANNOTATE
        annotated = engine.annotate("contract_clause", {"reviewed_by": "partner@firm.com"})
        assert annotated is True
        entry_after_annotate = engine.retrieve("contract_clause")
        assert entry_after_annotate is not None
        annotations = entry_after_annotate.metadata.get("annotations", [])
        assert len(annotations) >= 1

        # COMPRESS
        long_text = ". ".join([f"Sentence number {i} with supporting detail" for i in range(10)])
        engine.store("long_doc", long_text, MemoryTier.SESSION)
        compressed = engine.compress("long_doc")
        assert compressed is True
        entry_compressed = engine.retrieve("long_doc")
        assert entry_compressed is not None
        assert entry_compressed.metadata.get("compressed") is True

        # SPLIT
        engine.store(
            "multi_fact", "First legal precedent. Second legal precedent. Third legal precedent"
        )
        parts = engine.split("multi_fact")
        assert len(parts) == 3
        for part in parts:
            assert part.key.startswith("multi_fact_part_")

        # MERGE (store two entries, then merge them)
        engine.store("fact_a", "Clause 4.2 covers indemnification")
        engine.store("fact_b", "Clause 5.1 covers limitation of liability")
        merged = engine.merge("fact_a", "fact_b")
        assert merged is not None
        assert "indemnification" in str(merged.value)
        assert "liability" in str(merged.value)

        # LINK
        engine.store("client_pref", "Client prefers bullet points")
        linked = engine.link("contract_clause", "client_pref", "related_to")
        assert linked is True
        entry_linked = engine.retrieve("contract_clause")
        assert entry_linked is not None
        links = entry_linked.metadata.get("links", [])
        assert any(lnk["target"] == "client_pref" for lnk in links)

        # VERIFY
        engine._provenance.record("contract_clause", "document", "src", MemoryOperation.STORE)
        verified = engine.verify("contract_clause")
        assert verified is True

        # FORGET
        forgotten = engine.forget("contract_clause")
        assert forgotten is True
        assert engine.retrieve("contract_clause") is None

    def test_memory_execute_dispatch(self, memory_engine: MemoryPolicyEngine) -> None:
        """Verify the execute() dispatch method handles all 12 operations."""
        engine = memory_engine

        engine.store("x", "Data for x. Second sentence. Third sentence. Fourth. Fifth")
        engine.store("y", "Data for y")

        dispatch_args: dict[MemoryOperation, dict] = {
            MemoryOperation.STORE: {"key": "z", "value": "new entry", "tier": MemoryTier.WORKING},
            MemoryOperation.UPDATE: {"key": "x", "value": "updated x"},
            MemoryOperation.RETRIEVE: {"key": "x"},
            MemoryOperation.LINK: {"key_a": "x", "key_b": "y"},
            MemoryOperation.COMPRESS: {"key": "x"},
            MemoryOperation.PROMOTE: {"key": "x", "target_tier": MemoryTier.SESSION},
            MemoryOperation.DEMOTE: {"key": "x", "target_tier": MemoryTier.WORKING},
            MemoryOperation.SPLIT: {"key": "x"},
            MemoryOperation.MERGE: {"key_a": "x", "key_b": "y"},
            MemoryOperation.VERIFY: {"key": "x"},
            MemoryOperation.ANNOTATE: {"key": "x", "annotation": {"note": "ok"}},
            MemoryOperation.FORGET: {"key": "z"},
        }

        for op, kwargs in dispatch_args.items():
            # Re-store entries that prior ops may have removed/modified
            if engine.retrieve("x") is None:
                engine.store("x", "Data for x. Second. Third. Fourth. Fifth")
            if engine.retrieve("y") is None:
                engine.store("y", "Data for y")
            engine.execute(op, **kwargs)  # should not raise


# ---------------------------------------------------------------------------
# 5. Training Pipeline
# ---------------------------------------------------------------------------


class TestTrainingPipeline:
    """Verify the training engine produces correct metrics."""

    def test_training_pipeline(self) -> None:
        """Run AMIRGRPOTrainer.train() and verify the metrics structure."""
        trainer = AMIRGRPOTrainer(num_stages=3)
        result = trainer.train({"num_episodes": 10, "max_steps": 50})

        assert result["status"] == "completed"
        assert result["model"] == "base-agent-v1"
        assert result["num_stages"] == 3
        assert result["total_steps"] > 0
        assert result["mean_reward"] > 0
        assert result["best_reward"] >= result["mean_reward"]
        assert result["final_loss"] > 0

        # Stage metrics should exist for each stage
        assert len(result["stage_metrics"]) == 3
        for stage in result["stage_metrics"]:
            assert "reward" in stage
            assert "loss" in stage
            assert "steps" in stage

        # Rewards should be non-decreasing across stages
        rewards = [s["reward"] for s in result["stage_metrics"]]
        for i in range(1, len(rewards)):
            assert rewards[i] >= rewards[i - 1]

    def test_training_rollout(self) -> None:
        """Verify a single rollout produces a valid trajectory."""
        trainer = AMIRGRPOTrainer()
        result = trainer.rollout("What is the indemnification clause?")

        assert result["prompt"] == "What is the indemnification clause?"
        assert len(result["trajectory"]) >= 3
        for step in result["trajectory"]:
            assert "step_id" in step
            assert "action" in step
            assert "reward" in step
            assert 0.0 <= step["reward"] <= 1.0

        assert result["total_reward"] > 0

    def test_training_evaluate(self) -> None:
        """Verify the trainer's evaluate method scores test cases."""
        trainer = AMIRGRPOTrainer()
        cases = [
            {"prompt": "What is 2+2?", "expected": "4"},
            {"prompt": "Capital of France?", "expected": "Paris"},
            {"prompt": "Legal term for breach?", "expected": "breach of contract"},
        ]
        result = trainer.evaluate(cases)

        assert result["status"] == "completed"
        assert result["num_cases"] == 3
        assert result["metrics"]["mean_score"] >= 0.0
        assert result["metrics"]["max_score"] <= 1.0
        assert len(result["per_case_scores"]) == 3


# ---------------------------------------------------------------------------
# 6. Full Pipeline (chained end-to-end)
# ---------------------------------------------------------------------------


class TestFullPipeline:
    """Chain all pipeline stages: ingest -> eval -> memory -> train -> verify."""

    def test_full_pipeline(self, sample_text: str) -> None:
        """Run the complete Aegis pipeline end-to-end."""
        # Step 1: Ingest a document
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=3, compute_hashes=True))
        ingestion_result = pipeline.ingest("legal_contract.txt", content=sample_text)
        assert ingestion_result.num_chunks >= 4
        ingested_chunks = ingestion_result.chunks

        # Step 2: Store ingested chunks in memory
        store = InMemoryStore()
        graph = KnowledgeGraph()
        provenance = ProvenanceTracker()
        engine = MemoryPolicyEngine(store=store, graph=graph, provenance=provenance)

        stored_keys = []
        for i, chunk in enumerate(ingested_chunks):
            key = f"chunk_{i}"
            engine.store(key, chunk.content, MemoryTier.SESSION)
            stored_keys.append(key)

        # Verify all chunks are retrievable
        for key in stored_keys:
            entry = engine.retrieve(key)
            assert entry is not None, f"Failed to retrieve stored chunk: {key}"

        # Step 3: Run eval
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        eval_config = EvalConfig(
            dimensions=["retention_accuracy"],
            num_scenarios=3,
            scorer_mode="mock",
        )
        eval_result = evaluator.run(agent=None, config=eval_config)
        assert isinstance(eval_result, EvalResult)
        assert eval_result.overall_score >= 0.0

        # Step 4: Run Observatory health checks
        monitor = ObservatoryMonitor()
        health_results = monitor.run_all_checks()
        assert len(health_results) == 4
        all_healthy = all(r.healthy for r in health_results)
        # With no active training, all checks should pass
        assert all_healthy is True

        # Step 5: Run training
        trainer = AMIRGRPOTrainer(num_stages=2)
        train_result = trainer.train({"num_episodes": 5})
        assert train_result["status"] == "completed"
        assert train_result["mean_reward"] > 0

        # Step 6: Link related chunks in memory
        if len(stored_keys) >= 2:
            linked = engine.link(stored_keys[0], stored_keys[1], "follows")
            assert linked is True

        # Step 7: Verify a memory entry
        engine._provenance.record(
            stored_keys[0], "document", "legal_contract.txt", MemoryOperation.STORE
        )
        verified = engine.verify(stored_keys[0])
        assert verified is True

        # Step 8: Compress a stored chunk
        compressed = engine.compress(stored_keys[0])
        assert compressed is True
        entry = engine.retrieve(stored_keys[0])
        assert entry is not None
        assert entry.metadata.get("compressed") is True

        # Final verification: the pipeline completed without errors
        assert ingestion_result.num_chunks >= 4
        assert eval_result.run_id
        assert train_result["status"] == "completed"
