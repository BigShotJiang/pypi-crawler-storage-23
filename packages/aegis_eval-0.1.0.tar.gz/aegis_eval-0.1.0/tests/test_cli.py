"""Tests for the CLI."""

from __future__ import annotations

import re
from pathlib import Path

from typer.testing import CliRunner

from aegis.cli.main import app

runner = CliRunner()


class TestCLI:
    def test_version(self) -> None:
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.stdout

    def test_eval_dimensions(self) -> None:
        result = runner.invoke(app, ["eval", "dimensions"])
        assert result.exit_code == 0

    def test_eval_run_no_config(self) -> None:
        result = runner.invoke(app, ["eval", "run"])
        # Should fail gracefully without a config file
        assert (
            result.exit_code != 0
            or "Error" in result.stdout
            or "error" in result.stdout.lower()
            or result.exit_code == 0
        )

    def test_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "aegis" in result.stdout.lower() or "eval" in result.stdout.lower()

    def test_eval_report_uses_saved_run_result(self, tmp_path: Path) -> None:
        cfg = tmp_path / "eval.yaml"
        cfg.write_text("{}\n", encoding="utf-8")

        run_result = runner.invoke(
            app,
            ["eval", "run", "--config", str(cfg), "--fail-under", "0.0"],
        )
        assert run_result.exit_code == 0

        match = re.search(r"Run ID:\s*([0-9a-f\-]+)", run_result.stdout)
        assert match is not None
        run_id = match.group(1)

        out = tmp_path / "report.json"
        report_result = runner.invoke(
            app,
            ["eval", "report", "--run", run_id, "--format", "json", "--output", str(out)],
        )
        assert report_result.exit_code == 0
        assert out.exists()
        assert run_id in out.read_text(encoding="utf-8")

    def test_eval_compare_uses_saved_runs(self, tmp_path: Path) -> None:
        cfg = tmp_path / "eval.yaml"
        cfg.write_text("{}\n", encoding="utf-8")

        first = runner.invoke(
            app,
            ["eval", "run", "--config", str(cfg), "--fail-under", "0.0"],
        )
        second = runner.invoke(
            app,
            ["eval", "run", "--config", str(cfg), "--fail-under", "0.0"],
        )
        assert first.exit_code == 0
        assert second.exit_code == 0

        run_a = re.search(r"Run ID:\s*([0-9a-f\-]+)", first.stdout)
        run_b = re.search(r"Run ID:\s*([0-9a-f\-]+)", second.stdout)
        assert run_a is not None
        assert run_b is not None

        compare = runner.invoke(
            app,
            ["eval", "compare", "--runs", run_a.group(1), "--runs", run_b.group(1)],
        )
        assert compare.exit_code == 0
        assert "Overall delta" in compare.stdout

    def test_memory_health(self) -> None:
        result = runner.invoke(app, ["memory", "health"])
        assert result.exit_code == 0
        assert "Memory Subsystem Health" in result.stdout

    def test_memory_audit(self) -> None:
        result = runner.invoke(app, ["memory", "audit"])
        assert result.exit_code == 0

    def test_train_start_and_status(self) -> None:
        start = runner.invoke(
            app,
            ["train", "start", "--model", "test-model", "--trainer", "amir-grpo"],
        )
        assert start.exit_code == 0
        assert "Training Job Created" in start.stdout

        # Extract job ID from output
        match = re.search(r"([0-9a-f]{8})", start.stdout)
        assert match is not None
        job_id = match.group(1)

        status = runner.invoke(app, ["train", "status", "--job-id", job_id])
        assert status.exit_code == 0
        assert job_id in status.stdout

    def test_train_status_unknown_job(self) -> None:
        result = runner.invoke(app, ["train", "status", "--job-id", "nonexistent"])
        assert result.exit_code != 0

    def test_eval_list_empty(self) -> None:
        result = runner.invoke(app, ["eval", "list"])
        assert result.exit_code == 0
        assert "No evaluation runs found" in result.stdout

    def test_eval_list_after_run(self, tmp_path: Path) -> None:
        cfg = tmp_path / "eval.yaml"
        cfg.write_text("{}\n", encoding="utf-8")

        run_result = runner.invoke(
            app,
            ["eval", "run", "--config", str(cfg), "--fail-under", "0.0"],
        )
        assert run_result.exit_code == 0

        list_result = runner.invoke(app, ["eval", "list"])
        assert list_result.exit_code == 0
        assert "Evaluation Runs" in list_result.stdout
        assert "1 run(s)" in list_result.stdout

    def test_eval_list_agent_filter(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["eval", "list", "--agent", "nonexistent-agent"])
        assert result.exit_code == 0
        assert "No evaluation runs found" in result.stdout
