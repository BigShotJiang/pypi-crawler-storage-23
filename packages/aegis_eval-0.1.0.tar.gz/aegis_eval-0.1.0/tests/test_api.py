"""Tests for API routes."""

from __future__ import annotations

import base64
import hashlib

from fastapi.testclient import TestClient

from aegis.api.app import app

client = TestClient(app)


class TestHealth:
    def test_health_check(self) -> None:
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"


class TestEvalRoutes:
    def test_create_eval_run(self) -> None:
        response = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 10,
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "run_id" in data
        assert data["status"] == "completed"

    def test_get_eval_run(self) -> None:
        # Create a run first so it exists in the store.
        create_resp = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        run_id = create_resp.json()["run_id"]
        response = client.get(f"/v1/evals/runs/{run_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["run_id"] == run_id
        assert data["status"] == "completed"
        assert data["overall_score"] is not None
        assert len(data["dimension_scores"]) > 0

    def test_get_eval_run_not_found(self) -> None:
        response = client.get("/v1/evals/runs/nonexistent-run")
        assert response.status_code == 404

    def test_list_dimensions(self) -> None:
        response = client.get("/v1/evals/dimensions")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0

    def test_compare_runs(self) -> None:
        # Create two runs to compare
        resp_a = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        resp_b = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        run_id_a = resp_a.json()["run_id"]
        run_id_b = resp_b.json()["run_id"]

        response = client.post(
            "/v1/evals/compare",
            json={"run_id_a": run_id_a, "run_id_b": run_id_b},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["run_id_a"] == run_id_a
        assert data["run_id_b"] == run_id_b
        assert "deltas" in data

    def test_compare_runs_not_found(self) -> None:
        response = client.post(
            "/v1/evals/compare",
            json={"run_id_a": "nonexistent-a", "run_id_b": "nonexistent-b"},
        )
        assert response.status_code == 404

    def test_list_benchmark_suites(self) -> None:
        response = client.get("/v1/evals/benchmarks")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        suite_names = {suite["name"] for suite in data}
        assert "legal-memory" in suite_names
        assert "finance-memory" in suite_names
        assert "reward-integrity" in suite_names

    def test_run_benchmark_suite(self) -> None:
        response = client.post(
            "/v1/evals/benchmarks/run",
            json={
                "suite": "legal-memory",
                "difficulty_filter": 2,
                "scorer_mode": "mock",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["suite"] == "legal-memory"
        assert data["suite_size"] > 0
        assert isinstance(data["run_id"], str)
        assert 0.0 <= data["overall_score"] <= 1.0
        assert isinstance(data["dimension_scores"], dict)

    def test_run_benchmark_suite_not_found(self) -> None:
        response = client.post(
            "/v1/evals/benchmarks/run",
            json={"suite": "does-not-exist"},
        )
        assert response.status_code == 404

    def test_run_benchmark_suite_empty_filter(self) -> None:
        response = client.post(
            "/v1/evals/benchmarks/run",
            json={
                "suite": "legal-memory",
                "dimension_filter": "dimension-that-will-not-exist",
            },
        )
        assert response.status_code == 422

    def test_get_benchmark_run_and_history(self) -> None:
        run_resp = client.post(
            "/v1/evals/benchmarks/run",
            json={"suite": "legal-memory", "difficulty_filter": 2},
        )
        assert run_resp.status_code == 200
        run_id = run_resp.json()["run_id"]

        get_resp = client.get(f"/v1/evals/benchmarks/runs/{run_id}")
        assert get_resp.status_code == 200
        detail = get_resp.json()
        assert detail["run_id"] == run_id
        assert detail["suite"] == "legal-memory"

        history_resp = client.get("/v1/evals/benchmarks/history")
        assert history_resp.status_code == 200
        history = history_resp.json()
        assert isinstance(history, list)
        assert any(item["run_id"] == run_id for item in history)

    def test_get_benchmark_run_not_found(self) -> None:
        response = client.get("/v1/evals/benchmarks/runs/nonexistent-run")
        assert response.status_code == 404

    def test_benchmark_history_suite_filter(self) -> None:
        client.post(
            "/v1/evals/benchmarks/run",
            json={"suite": "legal-memory", "difficulty_filter": 2},
        )
        client.post(
            "/v1/evals/benchmarks/run",
            json={"suite": "finance-memory", "difficulty_filter": 2},
        )

        filtered = client.get("/v1/evals/benchmarks/history", params={"suite": "legal-memory"})
        assert filtered.status_code == 200
        items = filtered.json()
        assert isinstance(items, list)
        assert len(items) > 0
        assert all(item["suite"] == "legal-memory" for item in items)


class TestMemoryRoutes:
    def test_emit_memory_event(self) -> None:
        response = client.post(
            "/v1/memory/events",
            json={
                "operation": "STORE",
                "memory_tier": "session",
                "key": "test_key",
                "value": "test_value",
                "agent_id": "agent-1",
                "customer_id": "cust-1",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "id" in data

    def test_query_memory(self) -> None:
        response = client.post(
            "/v1/memory/query",
            json={"query": "test query", "customer_id": "cust-1"},
        )
        assert response.status_code == 200


class TestTrainingRoutes:
    def test_create_training_job(self) -> None:
        response = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-1",
                "domain": "legal",
                "optimizer": "AMIR-GRPO",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "job_id" in data
        assert data["status"] == "created"

    def test_create_training_run_alias(self) -> None:
        response = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-run",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "run_id" in data
        assert data["status"] == "created"

    def test_get_training_job(self) -> None:
        # First create a job so it exists in the in-memory store.
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-1",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        response = client.get(f"/v1/train/jobs/{job_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == job_id
        assert data["customer_id"] == "cust-1"
        assert data["domain"] == "legal"
        assert data["status"] == "created"

    def test_get_training_run_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-run",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]
        response = client.get(f"/v1/train/run/{run_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["job_id"] == run_id
        assert data["status"] == "created"

    def test_get_training_job_not_found(self) -> None:
        response = client.get("/v1/train/jobs/nonexistent-job")
        assert response.status_code == 404

    def test_get_training_job_metrics_default(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-metrics",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        response = client.get(f"/v1/train/jobs/{job_id}/metrics")
        assert response.status_code == 200
        data = response.json()
        assert data["current_stage"] == 0
        assert data["mean_reward"] == 0.0

    def test_list_training_jobs(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-list",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]

        response = client.get("/v1/train/jobs")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert any(job["job_id"] == job_id for job in data)

    def test_enqueue_and_tick_training_job(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-queue",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]

        enqueue_resp = client.post(f"/v1/train/jobs/{job_id}/enqueue")
        assert enqueue_resp.status_code == 200
        assert enqueue_resp.json()["status"] == "queued"

        get_resp = client.get(f"/v1/train/jobs/{job_id}")
        assert get_resp.status_code == 200
        assert get_resp.json()["status"] == "queued"

        tick_resp = client.post(f"/v1/train/jobs/{job_id}/tick")
        assert tick_resp.status_code == 200
        payload = tick_resp.json()
        assert payload["status"] == "completed"
        assert payload["metrics"]["mean_reward"] > 0

    def test_tick_training_job_not_queued_conflict(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-queue",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        tick_resp = client.post(f"/v1/train/jobs/{job_id}/tick")
        assert tick_resp.status_code == 409

    def test_run_training_job(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-1",
                "domain": "legal",
                "optimizer": "grpo",
                "curriculum": [
                    {"stage": 1, "name": "foundation", "difficulty": 2, "num_episodes": 20},
                    {"stage": 2, "name": "advanced", "difficulty": 3, "num_episodes": 30},
                ],
            },
        )
        job_id = create_resp.json()["job_id"]

        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200
        data = run_resp.json()
        assert data["job_id"] == job_id
        assert data["status"] == "completed"
        assert data["metrics"]["episodes_completed"] == 50
        assert data["metrics"]["total_stages"] >= 1
        assert data["metrics"]["mean_reward"] > 0

    def test_run_training_run_start_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-run",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]
        start_resp = client.post(f"/v1/train/run/{run_id}/start")
        assert start_resp.status_code == 200
        data = start_resp.json()
        assert data["job_id"] == run_id
        assert data["status"] == "completed"

        metrics_resp = client.get(f"/v1/train/run/{run_id}/metrics")
        assert metrics_resp.status_code == 200
        metrics = metrics_resp.json()
        assert metrics["total_stages"] >= 1
        assert metrics["mean_reward"] > 0

        result_resp = client.get(f"/v1/train/run/{run_id}/result")
        assert result_resp.status_code == 200
        result = result_resp.json()
        assert result["run_id"] == run_id
        assert result["status"] == "completed"

    def test_enqueue_and_tick_training_run_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-run-queue",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]

        enqueue_resp = client.post(f"/v1/train/run/{run_id}/enqueue")
        assert enqueue_resp.status_code == 200
        assert enqueue_resp.json()["status"] == "queued"

        tick_resp = client.post(f"/v1/train/run/{run_id}/tick")
        assert tick_resp.status_code == 200
        assert tick_resp.json()["status"] == "completed"

    def test_get_training_job_result(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-result",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        result_resp = client.get(f"/v1/train/jobs/{job_id}/result")
        assert result_resp.status_code == 200
        payload = result_resp.json()
        assert payload["job_id"] == job_id
        assert payload["status"] == "completed"
        assert "result" in payload
        assert payload["result"]["status"] == "completed"
        assert "transfer_plan" in payload["result"]
        assert "transfer_safeguards_applied" in payload["result"]
        assert "replay_mix_ratio_effective" in payload["result"]
        assert isinstance(payload["result"].get("stage_metrics"), list)
        assert len(payload["result"]["stage_metrics"]) >= 1
        first_stage = payload["result"]["stage_metrics"][0]
        assert "pods_selected" in first_stage
        assert "pods_dropped" in first_stage
        assert "pods_keep_ratio" in first_stage
        assert "pods_signal_mean" in first_stage

    def test_transfer_safeguards_are_applied_for_cross_domain_customer_history(self) -> None:
        base_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-transfer",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        base_job_id = base_resp.json()["job_id"]
        base_run = client.post(f"/v1/train/jobs/{base_job_id}/run")
        assert base_run.status_code == 200

        transfer_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-transfer",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        transfer_job_id = transfer_resp.json()["job_id"]
        transfer_run = client.post(f"/v1/train/jobs/{transfer_job_id}/run")
        assert transfer_run.status_code == 200

        result_resp = client.get(f"/v1/train/jobs/{transfer_job_id}/result")
        assert result_resp.status_code == 200
        payload = result_resp.json()["result"]
        assert payload["transfer_safeguards_applied"] is True
        plan = payload["transfer_plan"]
        assert plan["source_domain"] == "finance"
        assert plan["target_domain"] == "legal"
        assert plan["source_job_id"] == base_job_id
        assert plan["target_job_id"] == transfer_job_id
        assert "deterministic_transfer_score" in plan
        assert "deterministic_interference_estimate" in plan

    def test_transfer_safeguards_are_not_applied_without_cross_domain_history(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-transfer-none",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        result_resp = client.get(f"/v1/train/jobs/{job_id}/result")
        assert result_resp.status_code == 200
        payload = result_resp.json()["result"]
        assert payload["transfer_safeguards_applied"] is False
        plan = payload["transfer_plan"]
        assert plan["source_domain"] is None
        assert plan["target_domain"] == "legal"
        assert "reason" in plan

    def test_get_training_job_result_not_ready(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-result",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        response = client.get(f"/v1/train/jobs/{job_id}/result")
        assert response.status_code == 404

    def test_stop_training_job_created(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-stop",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]

        stop_resp = client.post(
            f"/v1/train/jobs/{job_id}/stop",
            json={"reason": "manual cancellation"},
        )
        assert stop_resp.status_code == 200
        stop_data = stop_resp.json()
        assert stop_data["job_id"] == job_id
        assert stop_data["status"] == "cancelled"

        get_resp = client.get(f"/v1/train/jobs/{job_id}")
        assert get_resp.status_code == 200
        assert get_resp.json()["status"] == "cancelled"

    def test_stop_training_run_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-run",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]
        stop_resp = client.post(
            f"/v1/train/run/{run_id}/stop",
            json={"reason": "cancel run alias"},
        )
        assert stop_resp.status_code == 200
        data = stop_resp.json()
        assert data["run_id"] == run_id
        assert data["status"] == "cancelled"

    def test_run_training_job_cancelled_conflict(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-stop",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        stop_resp = client.post(f"/v1/train/jobs/{job_id}/stop")
        assert stop_resp.status_code == 200

        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 409

    def test_run_training_job_not_found(self) -> None:
        response = client.post("/v1/train/jobs/nonexistent-job/run")
        assert response.status_code == 404

    def test_stop_training_job_not_found(self) -> None:
        response = client.post("/v1/train/jobs/nonexistent-job/stop")
        assert response.status_code == 404

    def test_get_training_job_metrics_after_run(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-metrics",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        metrics_resp = client.get(f"/v1/train/jobs/{job_id}/metrics")
        assert metrics_resp.status_code == 200
        metrics = metrics_resp.json()
        assert metrics["total_stages"] >= 1
        assert metrics["episodes_completed"] > 0
        assert metrics["mean_reward"] > 0

    def test_get_training_job_metrics_series(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-series",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        series_resp = client.get(f"/v1/train/jobs/{job_id}/metrics/series")
        assert series_resp.status_code == 200
        payload = series_resp.json()
        assert payload["job_id"] == job_id
        assert payload["status"] == "completed"
        assert isinstance(payload["series"], list)
        assert len(payload["series"]) >= 1
        first = payload["series"][0]
        assert "stage_index" in first
        assert "reward" in first
        assert "loss" in first

    def test_get_training_run_metrics_series_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-series",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]
        start_resp = client.post(f"/v1/train/run/{run_id}/start")
        assert start_resp.status_code == 200

        series_resp = client.get(f"/v1/train/run/{run_id}/metrics/series")
        assert series_resp.status_code == 200
        payload = series_resp.json()
        assert payload["job_id"] == run_id
        assert isinstance(payload["series"], list)
        assert len(payload["series"]) >= 1

    def test_get_training_job_observatory(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-observatory",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        observ_resp = client.get(f"/v1/train/jobs/{job_id}/observatory")
        assert observ_resp.status_code == 200
        report = observ_resp.json()
        assert report["job_id"] == job_id
        assert "overall_healthy" in report
        assert "composite_score" in report
        assert "checks" in report
        assert "reward_hacking" in report["checks"]
        assert "gradient_health" in report["checks"]
        assert "memory_health" in report["checks"]
        assert "drift" in report["checks"]

    def test_get_training_run_observatory_alias(self) -> None:
        create_resp = client.post(
            "/v1/train/run",
            json={
                "customer_id": "cust-observatory",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        run_id = create_resp.json()["run_id"]
        start_resp = client.post(f"/v1/train/run/{run_id}/start")
        assert start_resp.status_code == 200

        observ_resp = client.get(f"/v1/train/run/{run_id}/observatory")
        assert observ_resp.status_code == 200
        report = observ_resp.json()
        assert report["job_id"] == run_id
        assert "checks" in report

    def test_get_training_job_observatory_not_ready(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-observatory",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        response = client.get(f"/v1/train/jobs/{job_id}/observatory")
        assert response.status_code == 404

    def test_list_adapters_after_training_run(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-adapter",
                "domain": "legal",
                "optimizer": "grpo",
                "lora_config": {"rank": 8, "alpha": 16, "dropout": 0.05},
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        list_resp = client.get("/v1/train/adapters")
        assert list_resp.status_code == 200
        adapters = list_resp.json()
        assert isinstance(adapters, list)
        assert any(item["job_id"] == job_id for item in adapters)

    def test_get_adapter_by_id(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-adapter",
                "domain": "finance",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        adapters = client.get("/v1/train/adapters").json()
        adapter = next(item for item in adapters if item["job_id"] == job_id)

        get_resp = client.get(f"/v1/train/adapters/{adapter['adapter_id']}")
        assert get_resp.status_code == 200
        detail = get_resp.json()
        assert detail["adapter_id"] == adapter["adapter_id"]
        assert detail["job_id"] == job_id

    def test_get_adapter_not_found(self) -> None:
        response = client.get("/v1/train/adapters/nonexistent-adapter")
        assert response.status_code == 404

    def test_download_adapter(self) -> None:
        create_resp = client.post(
            "/v1/train/jobs",
            json={
                "customer_id": "cust-adapter",
                "domain": "legal",
                "optimizer": "grpo",
            },
        )
        job_id = create_resp.json()["job_id"]
        run_resp = client.post(f"/v1/train/jobs/{job_id}/run")
        assert run_resp.status_code == 200

        adapters = client.get("/v1/train/adapters").json()
        adapter = next(item for item in adapters if item["job_id"] == job_id)
        adapter_id = adapter["adapter_id"]

        download_resp = client.get(f"/v1/train/adapters/{adapter_id}/download")
        assert download_resp.status_code == 200
        payload = download_resp.json()
        assert payload["adapter_id"] == adapter_id
        assert payload["file_name"].endswith(".adapter.bin")
        assert payload["content_type"] == "application/octet-stream"
        assert payload["size_bytes"] > 0

        raw_bytes = base64.b64decode(payload["payload_base64"])
        assert len(raw_bytes) == payload["size_bytes"]
        digest = hashlib.sha256(raw_bytes).hexdigest()
        assert digest == payload["sha256"]

    def test_download_adapter_not_found(self) -> None:
        response = client.get("/v1/train/adapters/nonexistent-adapter/download")
        assert response.status_code == 404


class TestPromotionRoutes:
    def test_promotion_decide(self) -> None:
        # Create two eval runs first
        resp_before = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        resp_after = client.post(
            "/v1/evals/runs",
            json={
                "agent_config": {"type": "rest", "config": {}},
                "dimensions": ["retention_accuracy"],
                "num_scenarios": 5,
            },
        )
        run_before = resp_before.json()["run_id"]
        run_after = resp_after.json()["run_id"]

        response = client.post(
            "/v1/promotion/decide",
            json={
                "adapter_id": "test-lora",
                "eval_run_before": run_before,
                "eval_run_after": run_after,
                "domain": "legal",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert data["status"] in ("pass", "fail", "pending_human_gate")
        assert "composite_improvement" in data
        assert "blocking_regressions" in data
        assert "tier7_clear" in data

    def test_promotion_decide_not_found(self) -> None:
        response = client.post(
            "/v1/promotion/decide",
            json={
                "adapter_id": "test-lora",
                "eval_run_before": "nonexistent-before",
                "eval_run_after": "nonexistent-after",
                "domain": "legal",
            },
        )
        assert response.status_code == 404


class TestRetrievalRoutes:
    def test_execute_retrieval(self) -> None:
        response = client.post(
            "/v1/retrieval/query",
            json={
                "query": "What are the contract terms?",
                "sources": ["vector"],
                "context_budget": 4096,
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert "trajectory_id" in data
        assert "sources_queried" in data
        assert "context_blocks" in data
        assert "total_retrieved" in data
        assert "total_selected" in data
        assert "total_dropped" in data
        assert "context_budget_tokens" in data
        assert data["total_retrieved"] >= 3

    def test_execute_retrieval_with_multiple_sources(self) -> None:
        response = client.post(
            "/v1/retrieval/query",
            json={
                "query": "sec 10-k deadline",
                "sources": ["vector", "web", "kg"],
                "context_budget": 1024,
            },
        )
        assert response.status_code == 200
        data = response.json()
        source_types = {src["source_type"] for src in data["sources_queried"]}
        assert {"vector", "web", "kg"}.issubset(source_types)
        assert data["total_retrieved"] >= 9
        assert data["total_selected"] >= 1

    def test_retrieval_m4_benchmark(self) -> None:
        response = client.get("/v1/retrieval/benchmark/m4")
        assert response.status_code == 200
        data = response.json()
        assert data["benchmark"] == "aegis-retrieval-precision-depth-v1"
        assert data["total_cases"] == 2
        assert data["relative_improvement"] >= 0.10
        assert data["meets_target"] is True


class TestObservabilityRoutes:
    def test_emit_event(self) -> None:
        response = client.post(
            "/v1/observability/events",
            json={
                "event_type": "agent.step",
                "agent_id": "agent-1",
                "payload": {"step": 1},
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "id" in data
        assert data["status"] == "accepted"

    def test_emit_health_check_event(self) -> None:
        response = client.post(
            "/v1/observability/events",
            json={
                "event_type": "health_check.reward",
                "agent_id": "agent-1",
                "payload": {"reward_traces": []},
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["status"] == "accepted"
