"""Tests for M4 retrieval precision/depth benchmark."""

from __future__ import annotations

from aegis.eval.benchmarks import RetrievalPrecisionDepthBenchmark


def test_retrieval_precision_depth_suite_metadata() -> None:
    benchmark = RetrievalPrecisionDepthBenchmark()
    suite = benchmark.build_suite()

    assert suite.config.name == "aegis-retrieval-precision-depth-v1"
    assert len(suite.cases) == 2
    assert all(case.dimension_id == "retrieval_depth_calibration" for case in suite.cases)


def test_retrieval_precision_depth_meets_m4_target() -> None:
    benchmark = RetrievalPrecisionDepthBenchmark()
    report = benchmark.evaluate_improvement()

    assert report["total_cases"] == 2
    assert report["relative_improvement"] >= 0.10
    assert report["meets_target"] is True
