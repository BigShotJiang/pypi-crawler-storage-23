"""Security access tests for RBAC, isolation, and governance helpers."""

from __future__ import annotations

import uuid

import pytest

from aegis.security.governance import check_data_residency, create_audit_trail, get_audit_trail
from aegis.security.isolation import TenantIsolation
from aegis.security.rbac import (
    VIEWER,
    Permission,
    PermissionType,
    RBACEngine,
    Role,
    assign_role,
    check_permission,
)


def test_rbac_viewer_is_read_only() -> None:
    engine = RBACEngine()
    engine.register_principal("viewer-user", roles=["viewer"])

    assert engine.check_access("viewer-user", "eval", "read").allowed is True
    assert engine.check_access("viewer-user", "memory", "read").allowed is True
    assert engine.check_access("viewer-user", "training", "read").allowed is True

    assert engine.check_access("viewer-user", "eval", "execute").allowed is False
    assert engine.check_access("viewer-user", "memory", "write").allowed is False
    assert engine.check_access("viewer-user", "training", "execute").allowed is False


def test_rbac_admin_has_full_wildcard_access() -> None:
    engine = RBACEngine()
    engine.register_principal("admin-user", roles=["admin"])

    assert engine.check_access("admin-user", "eval", "execute").allowed is True
    assert engine.check_access("admin-user", "memory", "delete").allowed is True
    assert engine.check_access("admin-user", "arbitrary", "anything").allowed is True


def test_rbac_evaluator_role_is_available_by_default() -> None:
    engine = RBACEngine()
    engine.register_principal("eval-user", roles=["evaluator"])

    assert engine.check_access("eval-user", "eval", "execute").allowed is True
    assert engine.check_access("eval-user", "eval", "read").allowed is True
    assert engine.check_access("eval-user", "memory", "read").allowed is True
    assert engine.check_access("eval-user", "memory", "write").allowed is False


def test_rbac_permission_conditions_require_context() -> None:
    scoped_role = Role(
        name="scoped-writer",
        permissions=[
            Permission(resource="memory", action="write", conditions={"tier": "working"}),
        ],
    )
    engine = RBACEngine(roles=[scoped_role])
    engine.register_principal("scoped-user", roles=["scoped-writer"])

    assert engine.check_access("scoped-user", "memory", "write").allowed is False
    assert (
        engine.check_access("scoped-user", "memory", "write", context={"tier": "session"}).allowed
        is False
    )
    assert (
        engine.check_access("scoped-user", "memory", "write", context={"tier": "working"}).allowed
        is True
    )


def test_rbac_trainer_inherits_parent_permissions() -> None:
    engine = RBACEngine()
    engine.register_principal("trainer-user", roles=["trainer"])

    # Direct trainer permissions.
    assert engine.check_access("trainer-user", "training", "execute").allowed is True
    assert engine.check_access("trainer-user", "training", "write").allowed is True

    # Inherited from operator/viewer.
    assert engine.check_access("trainer-user", "eval", "execute").allowed is True
    assert engine.check_access("trainer-user", "memory", "read").allowed is True


def test_tenant_isolation_provisions_schema_and_namespace() -> None:
    isolation = TenantIsolation()
    info = isolation.create_tenant_schema("Acme-Co")

    assert info.schema_name == "tenant_acme_co"
    assert info.kg_namespace == "ns_acme_co"

    assert isolation.validate_access("acme-co", "acme_co") is True
    assert isolation.validate_access("acme-co", "other-tenant") is False

    with pytest.raises(ValueError):
        isolation.create_tenant_schema("Acme-Co")


def test_tenant_isolation_rejects_invalid_tenant_id() -> None:
    isolation = TenantIsolation()
    with pytest.raises(ValueError):
        isolation.get_schema_name("..bad..id")
    with pytest.raises(ValueError):
        isolation.get_kg_namespace("x")


def test_governance_helpers_data_residency_and_audit_filtering() -> None:
    ok = check_data_residency({"region": "eu-west-1"}, "eu-west-1")
    bad = check_data_residency({"region": "us-east-1"}, "eu-west-1")

    assert ok.passed is True
    assert bad.passed is False
    assert any("mismatch" in violation.lower() for violation in bad.violations)

    actor = f"actor-{uuid.uuid4()}"
    create_audit_trail(
        action="eval.run",
        actor=actor,
        resource="run-123",
        details={"framework": "soc2"},
    )
    filtered = get_audit_trail({"actor": actor, "action": "eval.run"})
    assert filtered
    assert all(entry.actor == actor for entry in filtered)


def test_default_rbac_helpers_assign_and_check() -> None:
    principal_id = f"principal-{uuid.uuid4()}"
    assert assign_role(principal_id, VIEWER) is True

    assert check_permission(principal_id, PermissionType.EVAL_READ).allowed is True
    assert check_permission(principal_id, PermissionType.EVAL_RUN).allowed is False
