"""Tests for the eval engine."""

from __future__ import annotations

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.eval.engine import EvalConfig, EvalResult, Evaluator


class TestEvalConfig:
    def test_defaults(self) -> None:
        config = EvalConfig()
        assert config.dimensions == "all"
        assert config.num_scenarios == 10
        assert config.difficulty == "medium"

    def test_custom(self) -> None:
        config = EvalConfig(
            dimensions=["retention_accuracy", "citation_validity"],
            domain_plugins=["legal"],
            num_scenarios=50,
            difficulty="fixed",
        )
        assert len(config.dimensions) == 2
        assert "legal" in config.domain_plugins

    def test_scorer_mode_default(self) -> None:
        config = EvalConfig()
        assert config.scorer_mode == "auto"

    def test_scorer_mode_mock(self) -> None:
        config = EvalConfig(scorer_mode="mock")
        assert config.scorer_mode == "mock"

    def test_llm_budget_defaults(self) -> None:
        config = EvalConfig()
        assert config.llm_cost_budget_usd is None
        assert config.llm_budget_fallback_score == 0.5


class TestEvaluator:
    def test_create(self) -> None:
        evaluator = Evaluator()
        assert evaluator is not None

    def test_run_returns_result(self) -> None:
        evaluator = Evaluator()
        config = EvalConfig(dimensions=["retention_accuracy"], num_scenarios=5)
        result = evaluator.run(agent=None, config=config)
        assert isinstance(result, EvalResult)
        assert result.run_id
        assert result.overall_score >= 0.0

    def test_run_all_dimensions(self) -> None:
        evaluator = Evaluator()
        config = EvalConfig(dimensions="all", num_scenarios=1)
        result = evaluator.run(agent=None, config=config)
        assert isinstance(result, EvalResult)
        assert len(result.dimension_scores) > 0

    def test_scorer_mode_mock_creates_evaluator(self) -> None:
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        assert evaluator is not None
        # The judge's LLM scorer should use MockLLMBackend
        from aegis.eval.scorers.llm_backend import MockLLMBackend

        assert isinstance(evaluator._judge.llm_scorer._backend, MockLLMBackend)

    def test_scorer_mode_hybrid_without_keys(self) -> None:
        import os

        # When no keys are set, "auto" should fall back to mock
        env = {
            k: v
            for k, v in os.environ.items()
            if k not in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "AEGIS_LLM_API_KEY")
        }
        import unittest.mock

        with unittest.mock.patch.dict(os.environ, env, clear=True):
            evaluator = Evaluator(config=EvalConfig(scorer_mode="auto"))
            from aegis.eval.scorers.llm_backend import MockLLMBackend

            assert isinstance(evaluator._judge.llm_scorer._backend, MockLLMBackend)

    def test_compare(self) -> None:
        evaluator = Evaluator()
        config = EvalConfig(dimensions="all", num_scenarios=1)
        result_a = evaluator.run(agent=None, config=config)
        result_b = evaluator.run(agent=None, config=config)
        comparison = evaluator.compare(result_a, result_b)
        assert "dimension_deltas" in comparison
        assert "overall_delta" in comparison
        assert "improved" in comparison
        assert "regressed" in comparison
        assert "unchanged" in comparison

    def test_run_with_cases_scores_unknown_dimension(self) -> None:
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        cases = [
            EvalCaseV1(
                suite_id="custom-suite",
                dimension_id="unknown_custom_dimension",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt="What is the approved budget?",
                expected={"budget": "$2M"},
                difficulty=2,
            ),
        ]

        result = evaluator.run_with_cases(cases=cases, agent=lambda _: "The approved budget is $2M")
        assert "unknown_custom_dimension" in result.dimension_scores
        assert 0.0 <= result.dimension_scores["unknown_custom_dimension"] <= 1.0
        assert result.dimension_scores["unknown_custom_dimension"] > 0.0
        # Unknown dimensions use fallback scoring and do not produce judge packets.
        assert len(result.judge_packets) == 0

    def test_run_with_cases_mixed_known_and_unknown_dimensions(self) -> None:
        evaluator = Evaluator(config=EvalConfig(scorer_mode="mock"))
        cases = [
            EvalCaseV1(
                suite_id="mixed-suite",
                dimension_id="retention_accuracy",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt="The project code is ORION-7. What is the project code?",
                expected={"project_code": "ORION-7"},
                difficulty=1,
            ),
            EvalCaseV1(
                suite_id="mixed-suite",
                dimension_id="custom_domain_metric",
                tier=EvalTier.REASONING_QUALITY,
                prompt="State the compliance control identifier.",
                expected={"control": "SOC2-CC6.1"},
                difficulty=2,
            ),
        ]

        result = evaluator.run_with_cases(
            cases=cases,
            agent=lambda prompt: "ORION-7 and SOC2-CC6.1 are confirmed.",
        )
        assert "retention_accuracy" in result.dimension_scores
        assert "custom_domain_metric" in result.dimension_scores
        assert 0.0 <= result.dimension_scores["custom_domain_metric"] <= 1.0

    def test_run_with_budget_guardrail_emits_budget_metadata(self) -> None:
        evaluator = Evaluator(
            config=EvalConfig(
                scorer_mode="mock",
                llm_cost_budget_usd=0.0,
                llm_budget_fallback_score=0.17,
            )
        )
        config = EvalConfig(
            dimensions=["retention_accuracy"],
            num_scenarios=1,
            scorer_mode="mock",
            llm_cost_budget_usd=0.0,
            llm_budget_fallback_score=0.17,
        )
        result = evaluator.run(agent=None, config=config)
        assert result.judge_packets
        assert result.judge_packets[0].judge_scores["llm_judge"] == 0.17
        llm_meta = result.diagnostic["metadata"]["llm_judge"]
        assert llm_meta["budget_exhausted"] is True
