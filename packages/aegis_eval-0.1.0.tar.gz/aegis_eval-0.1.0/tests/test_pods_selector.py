"""Tests for PODS rollout selection."""

from __future__ import annotations

from aegis.training.optimizers import PODSConfig, PODSSelector


def test_pods_keep_ratio_selects_top_k_rollouts() -> None:
    selector = PODSSelector(
        PODSConfig(
            keep_ratio=0.5,
            novelty_weight=0.2,
            reward_weight=0.8,
            length_penalty=0.0,
        )
    )
    rollouts = [
        {"rollout_id": "r1", "reward": 0.9, "novelty": 0.4, "length": 100},
        {"rollout_id": "r2", "reward": 0.5, "novelty": 0.9, "length": 100},
        {"rollout_id": "r3", "reward": 0.7, "novelty": 0.8, "length": 100},
        {"rollout_id": "r4", "reward": 0.3, "novelty": 0.2, "length": 100},
    ]

    selected = selector.select(rollouts)

    assert len(selected) == 2
    assert [rollout["rollout_id"] for rollout in selected] == ["r1", "r3"]


def test_pods_tie_break_is_deterministic_by_id_and_index() -> None:
    selector = PODSSelector(
        PODSConfig(
            keep_ratio=0.66,
            novelty_weight=0.5,
            reward_weight=0.5,
            length_penalty=0.0,
        )
    )
    rollouts = [
        {"rollout_id": "b", "reward": 0.6, "novelty": 0.6, "length": 50},
        {"rollout_id": "a", "reward": 0.6, "novelty": 0.6, "length": 50},
        {"rollout_id": "c", "reward": 0.6, "novelty": 0.6, "length": 50},
    ]

    first = selector.select(rollouts)
    second = selector.select(rollouts)

    assert [rollout["rollout_id"] for rollout in first] == ["b", "a"]
    assert [rollout["rollout_id"] for rollout in first] == [
        rollout["rollout_id"] for rollout in second
    ]


def test_pods_signal_penalizes_long_rollouts() -> None:
    selector = PODSSelector(
        PODSConfig(
            keep_ratio=1.0,
            novelty_weight=0.0,
            reward_weight=1.0,
            length_penalty=0.5,
        )
    )

    short_score = selector.signal_score(
        {"rollout_id": "short", "reward": 0.7, "novelty": 0.0, "length": 12}
    )
    long_score = selector.signal_score(
        {"rollout_id": "long", "reward": 0.7, "novelty": 0.0, "length": 300}
    )

    assert short_score > long_score
