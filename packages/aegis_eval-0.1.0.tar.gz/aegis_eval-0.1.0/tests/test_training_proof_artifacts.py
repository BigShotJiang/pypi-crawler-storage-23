"""Tests for proof artifact normalization and delta integrity."""

from __future__ import annotations

import json
from pathlib import Path

from aegis.training.proof_artifacts import (
    EvalArtifactSummary,
    build_adapter_manifest,
    build_delta_report,
    load_eval_artifact,
    write_json,
)


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_load_eval_artifact_supports_nested_result_payload(tmp_path: Path) -> None:
    payload = {
        "result": {
            "run_id": "baseline-run",
            "overall_score": 0.42,
            "dimension_scores": {"dim.a": 0.2, "dim.b": 0.6},
            "tier_scores": {"tier.1": 0.4},
        }
    }
    artifact = tmp_path / "baseline.json"
    _write_json(artifact, payload)

    summary = load_eval_artifact(artifact)
    assert summary.run_id == "baseline-run"
    assert summary.overall_score == 0.42
    assert summary.dimension_scores["dim.a"] == 0.2
    assert summary.tier_scores["tier.1"] == 0.4
    assert summary.source_file == str(artifact)


def test_load_eval_artifact_falls_back_to_filename_for_missing_ids(tmp_path: Path) -> None:
    artifact = tmp_path / "trained_eval.json"
    _write_json(artifact, {"overall_score": "0.8"})

    summary = load_eval_artifact(artifact)
    assert summary.run_id == "trained_eval"
    assert summary.overall_score == 0.8
    assert summary.dimension_scores == {}
    assert summary.tier_scores == {}


def test_build_delta_report_has_expected_deltas() -> None:
    baseline = EvalArtifactSummary(
        run_id="r1",
        overall_score=0.35,
        dimension_scores={"a": 0.2, "b": 0.5},
        tier_scores={"t1": 0.3},
        source_file="baseline.json",
    )
    trained = EvalArtifactSummary(
        run_id="r2",
        overall_score=0.55,
        dimension_scores={"a": 0.6, "b": 0.4, "c": 0.1},
        tier_scores={"t1": 0.5, "t2": 0.2},
        source_file="trained.json",
    )

    delta = build_delta_report(baseline, trained)
    assert delta["baseline_run_id"] == "r1"
    assert delta["trained_run_id"] == "r2"
    assert delta["overall_delta"] == 0.2
    assert delta["dimension_deltas"]["a"] == 0.4
    assert delta["dimension_deltas"]["b"] == -0.1
    assert delta["dimension_deltas"]["c"] == 0.1
    assert delta["tier_deltas"]["t1"] == 0.2
    assert delta["tier_deltas"]["t2"] == 0.2

    top = delta["top_dimension_gains"]
    assert top
    assert top[0]["dimension"] == "a"
    assert top[0]["delta"] == 0.4


def test_build_adapter_manifest_prefers_explicit_adapter_path() -> None:
    manifest = build_adapter_manifest(
        training_result={
            "run_id": "train-1",
            "backend": "real",
            "status": "completed",
            "adapter_path": "/tmp/from-result",
            "config": {"model_name": "Qwen/Qwen2.5-7B", "domain": "legal"},
            "mean_reward": 0.7,
            "best_reward": 0.9,
            "final_loss": 0.12,
            "kl_divergence": 0.04,
            "total_steps": 123,
        },
        adapter_path="/tmp/override",
        config_path="configs/training/legal_gpu_smoke.yaml",
    )

    assert manifest["run_id"] == "train-1"
    assert manifest["backend"] == "real"
    assert manifest["adapter_path"] == "/tmp/override"
    assert manifest["training_config"] == "configs/training/legal_gpu_smoke.yaml"
    assert manifest["metrics"]["total_steps"] == 123


def test_write_json_creates_parent_directories(tmp_path: Path) -> None:
    out = tmp_path / "nested" / "delta.json"
    payload = {"b": 2, "a": 1}
    write_json(out, payload)

    loaded = json.loads(out.read_text(encoding="utf-8"))
    assert loaded == {"a": 1, "b": 2}
