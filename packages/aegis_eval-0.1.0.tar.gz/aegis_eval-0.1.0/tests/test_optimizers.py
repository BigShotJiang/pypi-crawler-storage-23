"""Tests for training optimizer implementations."""

from __future__ import annotations

import math

from aegis.training.optimizers import (
    DAPOOptimizer,
    DrGRPOOptimizer,
    ForgeOptimizer,
    GiGPOOptimizer,
    GRPOUpdate,
    OptimizerConfig,
)


def test_drgrpo_optimize_uses_group_baselines() -> None:
    optimizer = DrGRPOOptimizer(OptimizerConfig(learning_rate=0.05, clip_range=0.2))
    advantages = [0.2, 0.8, 0.3, 0.9]
    old_log_probs = [-0.9, -0.8, -0.7, -0.6]
    new_log_probs = [-0.85, -0.75, -0.68, -0.57]
    groups = ["legal", "legal", "finance", "finance"]

    loss, metrics = optimizer.optimize(
        advantages=advantages,
        old_log_probs=old_log_probs,
        new_log_probs=new_log_probs,
        group_ids=groups,
        rewards=advantages,
    )

    assert isinstance(loss, float)
    assert metrics["algorithm"] == "drgrpo"
    assert metrics["group_count"] == 2.0
    assert "baseline_mean" in metrics

    normalised = metrics["normalized_advantages"]
    assert len(normalised) == 4
    legal_mean = (normalised[0] + normalised[1]) / 2
    finance_mean = (normalised[2] + normalised[3]) / 2
    assert abs(legal_mean) < 1e-6
    assert abs(finance_mean) < 1e-6


def test_dapo_optimize_clip_higher_and_entropy_bonus() -> None:
    optimizer = DAPOOptimizer(
        OptimizerConfig(learning_rate=0.02, clip_range=0.2, entropy_coeff=0.01)
    )
    advantages = [2.0, -1.2, 0.4, -0.3]
    old_log_probs = [-1.0, -1.0, -1.1, -0.9]
    new_log_probs = [-0.2, -1.2, -0.8, -1.1]

    loss, metrics = optimizer.optimize(
        advantages=advantages,
        old_log_probs=old_log_probs,
        new_log_probs=new_log_probs,
        entropy_history=[0.2, 0.3, 0.4],
    )

    assert isinstance(loss, float)
    assert metrics["algorithm"] == "dapo"
    assert metrics["clip_high"] > 1.2
    assert metrics["entropy_bonus"] > 0.0
    assert len(metrics["normalized_advantages"]) == 4


def test_gigpo_optimize_uses_token_level_and_importance_sampling() -> None:
    optimizer = GiGPOOptimizer(OptimizerConfig(learning_rate=0.01, clip_range=0.2))
    advantages = [0.2, -0.1, 0.3]
    old_log_probs = [-0.7, -0.8, -0.6]
    new_log_probs = [-0.68, -0.81, -0.55]
    reference_log_probs = [-0.75, -0.82, -0.63]
    token_advantages = [[0.1, 0.4], [-0.2, -0.1], [0.2, 0.3, 0.4]]

    loss, metrics = optimizer.optimize(
        advantages=advantages,
        old_log_probs=old_log_probs,
        new_log_probs=new_log_probs,
        group_ids=["g1", "g1", "g2"],
        token_advantages=token_advantages,
        reference_log_probs=reference_log_probs,
    )

    assert isinstance(loss, float)
    assert metrics["algorithm"] == "gigpo"
    assert metrics["group_count"] == 2.0
    assert metrics["is_ratio_mean"] > 0.0
    assert len(metrics["normalized_advantages"]) == 3


def test_forge_optimize_control_variate_metrics() -> None:
    optimizer = ForgeOptimizer(OptimizerConfig(learning_rate=0.03, clip_range=0.2))
    advantages = [1.2, -0.8, 0.4, -0.2]
    old_log_probs = [-1.1, -1.0, -0.9, -1.2]
    new_log_probs = [-1.0, -1.05, -0.85, -1.15]
    control_variate = [1.0, -0.6, 0.5, -0.1]

    loss, metrics = optimizer.optimize(
        advantages=advantages,
        old_log_probs=old_log_probs,
        new_log_probs=new_log_probs,
        rewards=[0.7, 0.2, 0.6, 0.3],
        control_variate=control_variate,
    )

    assert isinstance(loss, float)
    assert metrics["algorithm"] == "forge"
    assert metrics["variance_reduction"] >= 0.0
    assert len(metrics["normalized_advantages"]) == 4
    assert metrics["baseline"] != 0.0


def test_compute_update_compatibility_returns_grpo_update() -> None:
    rollouts = [
        {"log_prob": -0.8, "operation": "STORE"},
        {"log_prob": -0.6, "operation": "RETRIEVE"},
        {"log_prob": -0.7, "operation": "VERIFY"},
    ]
    rewards = [0.4, 0.9, 0.5]
    lengths = [48, 80, 64]

    dr_update = DrGRPOOptimizer().compute_update(rollouts, rewards, lengths)
    dapo_update = DAPOOptimizer().compute_update(rollouts, rewards, entropy_history=[1.0, 0.9])
    gigpo_update = GiGPOOptimizer().compute_update(
        rollouts, rewards, reference_log_probs=[-0.9, -0.7, -0.8]
    )
    forge_update = ForgeOptimizer().compute_update(rollouts, rewards)

    for update in [dr_update, dapo_update, gigpo_update, forge_update]:
        assert isinstance(update, GRPOUpdate)
        assert len(update.advantages) == 3
        assert math.isfinite(update.policy_loss)
        assert math.isfinite(update.kl_divergence)
        assert math.isfinite(update.entropy)
