"""Tests for the Aegis data ingestion layer (parsers + pipeline)."""

from __future__ import annotations

import json
from pathlib import Path

from aegis.ingestion.parsers import (
    CSVParser,
    DocumentParser,
    HTMLParser,
    JSONParser,
    Modality,
    ParsedChunk,
    ParserRegistry,
    TextParser,
)
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline, IngestionResult

# ---------------------------------------------------------------------------
# Modality enum
# ---------------------------------------------------------------------------


class TestModality:
    def test_has_all_seven_values(self) -> None:
        expected = {"TEXT", "TABLE", "DOCUMENT", "IMAGE", "AUDIO", "VIDEO", "WEB"}
        assert {m.name for m in Modality} == expected

    def test_string_values(self) -> None:
        assert Modality.TEXT.value == "text"
        assert Modality.TABLE.value == "table"
        assert Modality.DOCUMENT.value == "document"
        assert Modality.IMAGE.value == "image"
        assert Modality.AUDIO.value == "audio"
        assert Modality.VIDEO.value == "video"
        assert Modality.WEB.value == "web"

    def test_modality_count(self) -> None:
        assert len(Modality) == 7


# ---------------------------------------------------------------------------
# ParsedChunk dataclass
# ---------------------------------------------------------------------------


class TestParsedChunk:
    def test_create_with_all_fields(self) -> None:
        chunk = ParsedChunk(
            content="Hello world",
            modality=Modality.TEXT,
            source_path="/tmp/test.txt",
            chunk_index=3,
            metadata={"foo": "bar"},
            confidence=0.95,
        )
        assert chunk.content == "Hello world"
        assert chunk.modality == Modality.TEXT
        assert chunk.source_path == "/tmp/test.txt"
        assert chunk.chunk_index == 3
        assert chunk.metadata == {"foo": "bar"}
        assert chunk.confidence == 0.95

    def test_defaults(self) -> None:
        chunk = ParsedChunk(content="text", modality=Modality.TEXT)
        assert chunk.source_path == ""
        assert chunk.chunk_index == 0
        assert chunk.metadata == {}
        assert chunk.confidence == 1.0

    def test_metadata_independence(self) -> None:
        """Each chunk gets its own metadata dict by default."""
        a = ParsedChunk(content="a", modality=Modality.TEXT)
        b = ParsedChunk(content="b", modality=Modality.TEXT)
        a.metadata["key"] = "val"
        assert "key" not in b.metadata


# ---------------------------------------------------------------------------
# TextParser
# ---------------------------------------------------------------------------


class TestTextParser:
    def test_supported_extensions(self) -> None:
        parser = TextParser()
        assert ".txt" in parser.supported_extensions
        assert ".md" in parser.supported_extensions
        assert ".rst" in parser.supported_extensions
        assert ".text" in parser.supported_extensions

    def test_supported_modalities(self) -> None:
        parser = TextParser()
        assert parser.supported_modalities == [Modality.TEXT]

    def test_parse_from_content_string(self) -> None:
        parser = TextParser()
        chunks = parser.parse("doc.txt", content="Hello world.\n\nSecond paragraph.")
        assert len(chunks) == 2
        assert chunks[0].content == "Hello world."
        assert chunks[1].content == "Second paragraph."

    def test_splits_by_paragraphs(self) -> None:
        parser = TextParser()
        text = "Para one.\n\nPara two.\n\nPara three."
        chunks = parser.parse("doc.txt", content=text)
        assert len(chunks) == 3
        assert chunks[2].content == "Para three."
        assert chunks[2].chunk_index == 2

    def test_handles_bytes_input(self) -> None:
        parser = TextParser()
        raw = b"Bytes paragraph one.\n\nBytes paragraph two."
        chunks = parser.parse("doc.txt", content=raw)
        assert len(chunks) == 2
        assert chunks[0].content == "Bytes paragraph one."

    def test_empty_input_returns_empty(self) -> None:
        parser = TextParser()
        assert parser.parse("doc.txt", content="") == []
        assert parser.parse("doc.txt", content="   ") == []

    def test_metadata_has_char_and_word_count(self) -> None:
        parser = TextParser()
        chunks = parser.parse("doc.txt", content="Five words are right here.")
        assert len(chunks) == 1
        assert chunks[0].metadata["char_count"] == len("Five words are right here.")
        assert chunks[0].metadata["word_count"] == 5

    def test_source_path_preserved(self) -> None:
        parser = TextParser()
        chunks = parser.parse("/data/readme.md", content="Hello.")
        assert chunks[0].source_path == "/data/readme.md"

    def test_nonexistent_file_returns_empty(self) -> None:
        parser = TextParser()
        assert parser.parse("/nonexistent/path/missing.txt") == []

    def test_can_handle_matching_extensions(self) -> None:
        parser = TextParser()
        assert parser.can_handle("notes.txt") is True
        assert parser.can_handle("README.md") is True
        assert parser.can_handle("doc.rst") is True
        assert parser.can_handle("file.text") is True
        assert parser.can_handle("data.json") is False

    def test_parse_from_real_file(self, tmp_path: Path) -> None:
        f = tmp_path / "hello.txt"
        f.write_text("First para.\n\nSecond para.", encoding="utf-8")
        parser = TextParser()
        chunks = parser.parse(f)
        assert len(chunks) == 2
        assert chunks[0].modality == Modality.TEXT


# ---------------------------------------------------------------------------
# JSONParser
# ---------------------------------------------------------------------------


class TestJSONParser:
    def test_supported_extensions(self) -> None:
        parser = JSONParser()
        assert ".json" in parser.supported_extensions
        assert ".jsonl" in parser.supported_extensions

    def test_parse_json_object_flattens_keys(self) -> None:
        parser = JSONParser()
        obj = {"name": "Alice", "age": 30, "city": "NYC"}
        chunks = parser.parse("data.json", content=json.dumps(obj))
        assert len(chunks) == 3
        assert chunks[0].content.startswith("name:")
        assert chunks[0].metadata["format"] == "json_object"
        assert chunks[0].metadata["key"] == "name"

    def test_parse_json_array(self) -> None:
        parser = JSONParser()
        arr = [{"id": 1}, {"id": 2}, {"id": 3}]
        chunks = parser.parse("data.json", content=json.dumps(arr))
        assert len(chunks) == 3
        assert chunks[0].metadata["format"] == "json_array"
        assert chunks[0].chunk_index == 0
        assert chunks[2].chunk_index == 2

    def test_parse_jsonl(self) -> None:
        parser = JSONParser()
        lines = '{"a": 1}\n{"b": 2}\n{"c": 3}'
        chunks = parser.parse("data.jsonl", content=lines)
        assert len(chunks) == 3
        assert chunks[0].metadata["format"] == "jsonl"
        assert chunks[0].metadata["keys"] == ["a"]

    def test_invalid_json_returns_empty(self) -> None:
        parser = JSONParser()
        assert parser.parse("data.json", content="not valid json") == []

    def test_invalid_jsonl_lines_skipped(self) -> None:
        parser = JSONParser()
        lines = '{"ok": 1}\nnot-json\n{"ok": 2}'
        chunks = parser.parse("data.jsonl", content=lines)
        assert len(chunks) == 2

    def test_scalar_json(self) -> None:
        parser = JSONParser()
        chunks = parser.parse("val.json", content='"hello"')
        assert len(chunks) == 1
        assert chunks[0].content == "hello"
        assert chunks[0].metadata["format"] == "json_scalar"

    def test_scalar_json_number(self) -> None:
        parser = JSONParser()
        chunks = parser.parse("num.json", content="42")
        assert len(chunks) == 1
        assert chunks[0].content == "42"
        assert chunks[0].metadata["format"] == "json_scalar"

    def test_json_array_of_non_dicts(self) -> None:
        parser = JSONParser()
        chunks = parser.parse("data.json", content="[1, 2, 3]")
        assert len(chunks) == 3
        # Non-dict items produce empty keys list
        assert chunks[0].metadata["keys"] == []

    def test_nonexistent_file_returns_empty(self) -> None:
        parser = JSONParser()
        assert parser.parse("/missing/data.json") == []

    def test_bytes_input(self) -> None:
        parser = JSONParser()
        chunks = parser.parse("data.json", content=b'{"key": "value"}')
        assert len(chunks) == 1


# ---------------------------------------------------------------------------
# CSVParser
# ---------------------------------------------------------------------------


class TestCSVParser:
    def test_supported_extensions(self) -> None:
        parser = CSVParser()
        assert ".csv" in parser.supported_extensions
        assert ".tsv" in parser.supported_extensions

    def test_supported_modalities(self) -> None:
        parser = CSVParser()
        assert parser.supported_modalities == [Modality.TABLE]

    def test_parse_csv_rows_as_chunks(self) -> None:
        parser = CSVParser()
        csv_text = "name,age,city\nAlice,30,NYC\nBob,25,LA"
        chunks = parser.parse("data.csv", content=csv_text)
        assert len(chunks) == 2
        assert "name: Alice" in chunks[0].content
        assert "age: 30" in chunks[0].content

    def test_tsv_detection_by_extension(self) -> None:
        parser = CSVParser()
        tsv_text = "name\tage\tcity\nAlice\t30\tNYC\nBob\t25\tLA"
        chunks = parser.parse("data.tsv", content=tsv_text)
        assert len(chunks) == 2
        assert "name: Alice" in chunks[0].content

    def test_empty_rows_skipped(self) -> None:
        parser = CSVParser()
        # Two-column CSV with an empty row (both fields blank)
        csv_text = "name,age\nAlice,30\n,\nBob,25"
        chunks = parser.parse("data.csv", content=csv_text)
        # The empty row (,) should be skipped since all values are empty strings
        assert len(chunks) == 2

    def test_metadata_has_headers_and_row_data(self) -> None:
        parser = CSVParser()
        csv_text = "name,age\nAlice,30"
        chunks = parser.parse("data.csv", content=csv_text)
        assert len(chunks) == 1
        meta = chunks[0].metadata
        assert meta["headers"] == ["name", "age"]
        assert meta["row_data"] == {"name": "Alice", "age": "30"}
        assert meta["format"] == "csv"
        assert meta["row_index"] == 0

    def test_modality_is_table(self) -> None:
        parser = CSVParser()
        chunks = parser.parse("data.csv", content="h1,h2\nv1,v2")
        assert chunks[0].modality == Modality.TABLE

    def test_nonexistent_file_returns_empty(self) -> None:
        parser = CSVParser()
        assert parser.parse("/missing/data.csv") == []

    def test_parse_from_real_file(self, tmp_path: Path) -> None:
        f = tmp_path / "test.csv"
        f.write_text("x,y\n1,2\n3,4", encoding="utf-8")
        parser = CSVParser()
        chunks = parser.parse(f)
        assert len(chunks) == 2


# ---------------------------------------------------------------------------
# HTMLParser
# ---------------------------------------------------------------------------


class TestHTMLParser:
    def test_supported_extensions(self) -> None:
        parser = HTMLParser()
        assert ".html" in parser.supported_extensions
        assert ".htm" in parser.supported_extensions

    def test_supported_modalities(self) -> None:
        parser = HTMLParser()
        assert Modality.TEXT in parser.supported_modalities
        assert Modality.WEB in parser.supported_modalities

    def test_strips_script_and_style_tags(self) -> None:
        parser = HTMLParser()
        html = (
            "<html><head><style>body{color:red}</style></head>"
            "<body><p>Hello world</p>"
            "<script>alert('xss')</script></body></html>"
        )
        chunks = parser.parse("page.html", content=html)
        texts = " ".join(c.content for c in chunks)
        assert "color:red" not in texts
        assert "alert" not in texts
        assert "Hello world" in texts

    def test_decodes_html_entities(self) -> None:
        parser = HTMLParser()
        html = "<p>Apples &amp; Oranges &lt; Grapes &gt; Pears &quot;quoted&quot; it&#39;s</p>"
        chunks = parser.parse("page.html", content=html)
        assert len(chunks) >= 1
        text = chunks[0].content
        assert "&" in text
        assert "<" in text
        assert ">" in text
        assert '"' in text
        assert "'" in text

    def test_splits_by_block_elements(self) -> None:
        parser = HTMLParser()
        html = "<div>Block one content here</div><div>Block two content here</div>"
        chunks = parser.parse("page.html", content=html)
        assert len(chunks) >= 2

    def test_skips_tiny_fragments(self) -> None:
        parser = HTMLParser()
        html = "<p>OK</p><p>This is a normal length paragraph for testing.</p>"
        chunks = parser.parse("page.html", content=html)
        # "OK" is only 2 chars, below the 5-char threshold
        contents = [c.content for c in chunks]
        assert not any(c.strip() == "OK" for c in contents)

    def test_web_modality_for_http_source(self) -> None:
        parser = HTMLParser()
        html = "<p>Hello from the web page content.</p>"
        chunks = parser.parse("https://example.com/page.html", content=html)
        assert len(chunks) >= 1
        assert chunks[0].modality == Modality.WEB

    def test_text_modality_for_local_file(self) -> None:
        parser = HTMLParser()
        html = "<p>Hello from a local HTML file here.</p>"
        chunks = parser.parse("/tmp/page.html", content=html)
        assert len(chunks) >= 1
        assert chunks[0].modality == Modality.TEXT

    def test_nonexistent_file_returns_empty(self) -> None:
        parser = HTMLParser()
        assert parser.parse("/missing/page.html") == []


# ---------------------------------------------------------------------------
# ParserRegistry
# ---------------------------------------------------------------------------


class TestParserRegistry:
    def test_registers_builtins(self) -> None:
        registry = ParserRegistry()
        parsers = registry.all_parsers()
        types = {type(p) for p in parsers}
        assert TextParser in types
        assert JSONParser in types
        assert CSVParser in types
        assert HTMLParser in types

    def test_get_parser_finds_correct_parser_by_extension(self) -> None:
        registry = ParserRegistry()
        assert isinstance(registry.get_parser("notes.txt"), TextParser)
        assert isinstance(registry.get_parser("data.json"), JSONParser)
        assert isinstance(registry.get_parser("data.jsonl"), JSONParser)
        assert isinstance(registry.get_parser("sheet.csv"), CSVParser)
        assert isinstance(registry.get_parser("sheet.tsv"), CSVParser)
        assert isinstance(registry.get_parser("page.html"), HTMLParser)
        assert isinstance(registry.get_parser("page.htm"), HTMLParser)

    def test_get_parser_returns_none_for_unknown(self) -> None:
        registry = ParserRegistry()
        assert registry.get_parser("model.bin") is None
        assert registry.get_parser("archive.zip") is None

    def test_last_registered_wins(self) -> None:
        """When two parsers handle the same extension, the last one registered wins."""
        registry = ParserRegistry()

        class CustomTextParser(DocumentParser):
            @property
            def supported_modalities(self) -> list[Modality]:
                return [Modality.TEXT]

            @property
            def supported_extensions(self) -> list[str]:
                return [".txt"]

            def parse(self, source, content=None):
                return []

        custom = CustomTextParser()
        registry.register(custom)
        found = registry.get_parser("notes.txt")
        assert found is custom

    def test_supported_extensions_returns_all(self) -> None:
        registry = ParserRegistry()
        exts = registry.supported_extensions()
        for ext in [
            ".txt",
            ".md",
            ".rst",
            ".text",
            ".json",
            ".jsonl",
            ".csv",
            ".tsv",
            ".html",
            ".htm",
        ]:
            assert ext in exts

    def test_supported_extensions_sorted_and_unique(self) -> None:
        registry = ParserRegistry()
        exts = registry.supported_extensions()
        assert exts == sorted(set(exts))

    def test_custom_parser_registration(self) -> None:
        registry = ParserRegistry()

        class PDFParser(DocumentParser):
            @property
            def supported_modalities(self) -> list[Modality]:
                return [Modality.DOCUMENT]

            @property
            def supported_extensions(self) -> list[str]:
                return [".pdf"]

            def parse(self, source, content=None):
                return [ParsedChunk(content="pdf content", modality=Modality.DOCUMENT)]

        registry.register(PDFParser())
        assert ".pdf" in registry.supported_extensions()
        assert isinstance(registry.get_parser("report.pdf"), PDFParser)


# ---------------------------------------------------------------------------
# DocumentParser.can_handle
# ---------------------------------------------------------------------------


class TestDocumentParserCanHandle:
    def test_can_handle_with_matching_extension(self) -> None:
        parser = TextParser()
        assert parser.can_handle("notes.txt") is True
        assert parser.can_handle(Path("/data/notes.txt")) is True

    def test_can_handle_case_insensitive(self) -> None:
        parser = TextParser()
        assert parser.can_handle("NOTES.TXT") is True
        assert parser.can_handle("readme.MD") is True

    def test_can_handle_rejects_wrong_extension(self) -> None:
        parser = TextParser()
        assert parser.can_handle("data.csv") is False
        assert parser.can_handle("image.png") is False


# ---------------------------------------------------------------------------
# IngestionPipeline — basic ingestion
# ---------------------------------------------------------------------------


class TestIngestionPipelineIngest:
    def test_ingest_text_content(self) -> None:
        pipeline = IngestionPipeline()
        result = pipeline.ingest(
            "doc.txt", content="Hello world from paragraph one.\n\nParagraph two is here now."
        )
        assert isinstance(result, IngestionResult)
        assert result.num_chunks >= 1
        assert result.source_path == "doc.txt"
        assert result.modality == Modality.TEXT

    def test_ingest_result_has_document_id(self) -> None:
        pipeline = IngestionPipeline()
        result = pipeline.ingest("doc.txt", content="Some text content here.")
        assert result.document_id  # auto-generated UUID

    def test_ingest_with_modality_override(self) -> None:
        pipeline = IngestionPipeline()
        result = pipeline.ingest(
            "doc.txt", content="Content here please.", modality=Modality.DOCUMENT
        )
        assert result.modality == Modality.DOCUMENT

    def test_fallback_to_text_parser_for_unknown_extension(self) -> None:
        pipeline = IngestionPipeline()
        result = pipeline.ingest("data.xyz", content="Unknown format but still text content here.")
        assert result.num_chunks >= 1


# ---------------------------------------------------------------------------
# IngestionPipeline — chunking
# ---------------------------------------------------------------------------


class TestIngestionPipelineChunking:
    def test_large_chunk_gets_split(self) -> None:
        config = IngestionConfig(max_chunk_words=10, overlap_words=2, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        # Create a single paragraph with 25 words
        words = [f"word{i}" for i in range(25)]
        content = " ".join(words)
        result = pipeline.ingest("doc.txt", content=content)
        # 25 words with max 10 => at least 3 chunks (with overlap of 2, step = 8)
        assert result.num_chunks >= 3

    def test_overlap_creates_shared_words(self) -> None:
        config = IngestionConfig(
            max_chunk_words=10,
            overlap_words=3,
            min_chunk_words=1,
            compute_hashes=False,
            deduplicate=False,
        )
        pipeline = IngestionPipeline(config=config)
        words = [f"w{i}" for i in range(20)]
        content = " ".join(words)
        result = pipeline.ingest("doc.txt", content=content)
        # Check that there is word overlap between consecutive sub-chunks
        if result.num_chunks >= 2:
            first_words = result.chunks[0].content.split()
            second_words = result.chunks[1].content.split()
            # Last 3 words of first chunk should appear at start of second
            tail = set(first_words[-3:])
            head = set(second_words[:3])
            assert tail & head  # non-empty intersection

    def test_small_chunk_not_split(self) -> None:
        config = IngestionConfig(max_chunk_words=100, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        result = pipeline.ingest("doc.txt", content="Short paragraph with few words.")
        # Should not be split since word count < max_chunk_words
        assert result.num_chunks == 1

    def test_sub_chunk_metadata(self) -> None:
        config = IngestionConfig(
            max_chunk_words=5,
            overlap_words=1,
            min_chunk_words=1,
            compute_hashes=False,
            deduplicate=False,
        )
        pipeline = IngestionPipeline(config=config)
        content = "one two three four five six seven eight nine ten"
        result = pipeline.ingest("doc.txt", content=content)
        assert result.num_chunks >= 2
        for chunk in result.chunks:
            assert chunk.metadata.get("sub_chunk") is True


# ---------------------------------------------------------------------------
# IngestionPipeline — deduplication
# ---------------------------------------------------------------------------


class TestIngestionPipelineDedup:
    def test_identical_content_deduplicated(self) -> None:
        config = IngestionConfig(deduplicate=True, compute_hashes=True, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        content = "Duplicate paragraph here.\n\nDuplicate paragraph here."
        result = pipeline.ingest("doc.txt", content=content)
        assert result.num_chunks == 1

    def test_dedup_disabled_keeps_duplicates(self) -> None:
        config = IngestionConfig(deduplicate=False, compute_hashes=False, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        content = "Duplicate paragraph here.\n\nDuplicate paragraph here."
        result = pipeline.ingest("doc.txt", content=content)
        assert result.num_chunks == 2


# ---------------------------------------------------------------------------
# IngestionPipeline — content hashing
# ---------------------------------------------------------------------------


class TestIngestionPipelineHashing:
    def test_sha256_hashes_added(self) -> None:
        config = IngestionConfig(compute_hashes=True, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        result = pipeline.ingest("doc.txt", content="Some content for hashing test here.")
        assert result.num_chunks >= 1
        for chunk in result.chunks:
            h = chunk.metadata.get("content_hash")
            assert h is not None
            assert len(h) == 16  # truncated SHA-256 hex

    def test_hashes_not_added_when_disabled(self) -> None:
        config = IngestionConfig(compute_hashes=False, deduplicate=False, min_chunk_words=1)
        pipeline = IngestionPipeline(config=config)
        result = pipeline.ingest("doc.txt", content="Some content for no hashing test.")
        for chunk in result.chunks:
            assert "content_hash" not in chunk.metadata

    def test_hash_is_deterministic(self) -> None:
        config = IngestionConfig(compute_hashes=True, deduplicate=False, min_chunk_words=1)
        p1 = IngestionPipeline(config=config)
        p2 = IngestionPipeline(config=config)
        r1 = p1.ingest("doc.txt", content="Deterministic hash content test here.")
        r2 = p2.ingest("doc.txt", content="Deterministic hash content test here.")
        assert r1.chunks[0].metadata["content_hash"] == r2.chunks[0].metadata["content_hash"]


# ---------------------------------------------------------------------------
# IngestionPipeline — min chunk filtering
# ---------------------------------------------------------------------------


class TestIngestionPipelineMinChunk:
    def test_chunks_below_min_words_filtered(self) -> None:
        config = IngestionConfig(min_chunk_words=5, compute_hashes=False, deduplicate=False)
        pipeline = IngestionPipeline(config=config)
        content = "Hi.\n\nThis paragraph has more than five words in it."
        result = pipeline.ingest("doc.txt", content=content)
        # "Hi." has 1 word, should be filtered
        for chunk in result.chunks:
            assert len(chunk.content.split()) >= 5

    def test_min_chunk_words_zero_keeps_all(self) -> None:
        config = IngestionConfig(min_chunk_words=0, compute_hashes=False, deduplicate=False)
        pipeline = IngestionPipeline(config=config)
        content = "A.\n\nB.\n\nLonger paragraph with many words here."
        result = pipeline.ingest("doc.txt", content=content)
        assert result.num_chunks == 3


# ---------------------------------------------------------------------------
# IngestionPipeline — batch ingestion
# ---------------------------------------------------------------------------


class TestIngestionPipelineBatch:
    def test_ingest_batch(self, tmp_path: Path) -> None:
        f1 = tmp_path / "a.txt"
        f2 = tmp_path / "b.txt"
        f1.write_text(
            "File A paragraph one content here.\n\nFile A paragraph two content here.",
            encoding="utf-8",
        )
        f2.write_text("File B content is all in one paragraph here.", encoding="utf-8")
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        results = pipeline.ingest_batch([f1, f2])
        assert len(results) == 2
        assert results[0].source_path == str(f1)
        assert results[1].source_path == str(f2)


# ---------------------------------------------------------------------------
# IngestionPipeline — directory ingestion
# ---------------------------------------------------------------------------


class TestIngestionPipelineDirectory:
    def test_ingest_directory(self, tmp_path: Path) -> None:
        (tmp_path / "readme.txt").write_text("Hello from readme text file.", encoding="utf-8")
        (tmp_path / "data.csv").write_text("h1,h2\nv1,v2", encoding="utf-8")
        (tmp_path / "notes.md").write_text(
            "Markdown notes content here right now.", encoding="utf-8"
        )
        # Unsupported extension -- should be skipped
        (tmp_path / "image.png").write_bytes(b"\x89PNG")
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        results = pipeline.ingest_directory(tmp_path)
        sources = {r.source_path for r in results}
        assert str(tmp_path / "readme.txt") in sources
        assert str(tmp_path / "data.csv") in sources
        assert str(tmp_path / "notes.md") in sources
        # .png should NOT have been ingested
        assert not any("image.png" in s for s in sources)

    def test_ingest_directory_recursive(self, tmp_path: Path) -> None:
        sub = tmp_path / "sub"
        sub.mkdir()
        (tmp_path / "top.txt").write_text("Top level file content here.", encoding="utf-8")
        (sub / "nested.txt").write_text("Nested level file content here.", encoding="utf-8")
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        results = pipeline.ingest_directory(tmp_path, recursive=True)
        sources = {r.source_path for r in results}
        assert str(sub / "nested.txt") in sources
        assert str(tmp_path / "top.txt") in sources

    def test_ingest_directory_non_recursive(self, tmp_path: Path) -> None:
        sub = tmp_path / "sub"
        sub.mkdir()
        (tmp_path / "top.txt").write_text("Top level file content here.", encoding="utf-8")
        (sub / "nested.txt").write_text("Nested level file content here.", encoding="utf-8")
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        results = pipeline.ingest_directory(tmp_path, recursive=False)
        sources = {r.source_path for r in results}
        assert str(tmp_path / "top.txt") in sources
        assert str(sub / "nested.txt") not in sources

    def test_ingest_directory_nonexistent_returns_empty(self) -> None:
        pipeline = IngestionPipeline()
        assert pipeline.ingest_directory("/nonexistent/directory") == []


# ---------------------------------------------------------------------------
# IngestionPipeline — history
# ---------------------------------------------------------------------------


class TestIngestionPipelineHistory:
    def test_history_returns_all_past_results(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        assert pipeline.history() == []
        pipeline.ingest("a.txt", content="First document content here and more.")
        pipeline.ingest("b.txt", content="Second document content here and more.")
        history = pipeline.history()
        assert len(history) == 2
        assert history[0].source_path == "a.txt"
        assert history[1].source_path == "b.txt"

    def test_history_is_a_copy(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        pipeline.ingest("a.txt", content="Hello there world from Aegis platform.")
        h = pipeline.history()
        h.clear()
        assert len(pipeline.history()) == 1


# ---------------------------------------------------------------------------
# IngestionConfig defaults
# ---------------------------------------------------------------------------


class TestIngestionConfig:
    def test_defaults(self) -> None:
        cfg = IngestionConfig()
        assert cfg.max_chunk_words == 512
        assert cfg.overlap_words == 50
        assert cfg.min_chunk_words == 5
        assert cfg.compute_hashes is True
        assert cfg.deduplicate is True

    def test_custom_config(self) -> None:
        cfg = IngestionConfig(
            max_chunk_words=100,
            overlap_words=10,
            min_chunk_words=2,
            compute_hashes=False,
            deduplicate=False,
        )
        assert cfg.max_chunk_words == 100
        assert cfg.overlap_words == 10
        assert cfg.min_chunk_words == 2
        assert cfg.compute_hashes is False
        assert cfg.deduplicate is False


# ---------------------------------------------------------------------------
# IngestionPipeline — registry property
# ---------------------------------------------------------------------------


class TestIngestionPipelineRegistry:
    def test_pipeline_exposes_registry(self) -> None:
        pipeline = IngestionPipeline()
        assert isinstance(pipeline.registry, ParserRegistry)

    def test_pipeline_uses_custom_registry(self) -> None:
        reg = ParserRegistry()
        pipeline = IngestionPipeline(parser_registry=reg)
        assert pipeline.registry is reg
