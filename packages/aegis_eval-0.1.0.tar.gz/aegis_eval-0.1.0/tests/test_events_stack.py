"""Tests for event dispatcher/router/webhook stack."""

from __future__ import annotations

from typing import Any

from aegis.events.dispatcher import EventDispatcher
from aegis.events.router import EventRouter
from aegis.events.webhooks import WebhookManager


class _ClassHandler:
    def __init__(self, name: str, output: list[str]) -> None:
        self._name = name
        self._output = output

    def handle(self, event: dict[str, Any]) -> dict[str, Any] | None:
        self._output.append(self._name)
        return {"handler": self._name, "event_id": event["id"]}


def test_dispatcher_subscribe_publish_filter_and_dead_letters() -> None:
    dispatcher = EventDispatcher(max_history=2)
    received: list[str] = []

    def ok_callback(event: dict[str, Any]) -> None:
        received.append(event["event_type"])

    def failing_callback(event: dict[str, Any]) -> None:
        raise RuntimeError("boom")

    global_sub = dispatcher.subscribe(callback=ok_callback)
    typed_sub = dispatcher.subscribe(
        event_types=["memory.store"],
        callback=ok_callback,
        filter_fn=lambda e: e["payload"].get("allow", False),
    )
    dispatcher.subscribe(event_types=["memory.store"], callback=failing_callback)

    # Filter rejects typed delivery.
    first = dispatcher.publish("memory.store", {"allow": False}, source="tests")
    assert first["delivered_to"] == 1
    assert first["failed_deliveries"] == 1

    # Filter allows typed delivery.
    second = dispatcher.publish("memory.store", {"allow": True}, source="tests")
    assert second["delivered_to"] == 2
    assert second["failed_deliveries"] == 1

    # Another event to trigger max_history trim.
    dispatcher.publish("train.run", {}, source="tests")

    assert received.count("memory.store") == 3
    assert len(dispatcher.history()) == 2
    assert len(dispatcher.dead_letters()) == 2

    assert dispatcher.subscriber_count() == 3
    assert dispatcher.subscriber_count("memory.store") == 2

    # Unsubscribe both global + typed.
    assert dispatcher.unsubscribe(global_sub.id)
    assert dispatcher.unsubscribe(typed_sub.id)
    assert not dispatcher.unsubscribe("missing")

    cleared = dispatcher.clear_history()
    assert cleared == 2
    assert dispatcher.history() == []
    assert dispatcher.dead_letters() == []


def test_router_exact_wildcard_priority_and_results_log() -> None:
    router = EventRouter()
    call_order: list[str] = []

    high = _ClassHandler("high", call_order)
    low = _ClassHandler("low", call_order)

    def fn_handler(event: dict[str, Any]) -> dict[str, Any] | None:
        call_order.append("fn")
        return {"handler": "fn", "event_type": event["event_type"]}

    router.add_route("memory.*", low, priority=1)
    router.add_route("memory.store", high, priority=10)
    router.add_route("*", fn_handler, priority=0)

    results = router.route({"id": "evt-1", "event_type": "memory.store", "payload": {}})

    assert [r["handler"] for r in results] == ["high", "low", "fn"]
    assert call_order == ["high", "low", "fn"]

    route_defs = router.routes()
    assert route_defs[0]["pattern"] == "memory.store"

    assert router.remove_route("memory.*")
    assert not router.remove_route("does.not.exist")

    # Match helpers.
    assert router._matches("*", "anything")
    assert router._matches("memory.*", "memory.store")
    assert router._matches("memory.*", "memory")
    assert router._matches("memory.store", "memory.store")
    assert not router._matches("memory.*", "train.run")

    log = router.results_log(limit=10)
    assert len(log) == len(results)


def test_webhook_manager_lifecycle_queue_retry_and_stats() -> None:
    manager = WebhookManager()

    hook_a = manager.register(
        url="https://example.com/a",
        secret="secret-a",
        event_types=["memory.store"],
        max_retries=2,
    )
    hook_b = manager.register(
        url="https://example.com/b",
        secret="secret-b",
        event_types=[],
        max_retries=3,
    )

    # Active-only listing and get.
    hook_b.active = False
    active = manager.list_webhooks(active_only=True)
    assert [h.id for h in active] == [hook_a.id]
    assert manager.get(hook_a.id) is not None
    assert manager.get("missing") is None

    event = {"id": "evt-123", "event_type": "memory.store", "payload": {"k": "v"}}
    deliveries = manager.enqueue(event)
    assert len(deliveries) == 1  # hook_b inactive; only hook_a receives

    queue = manager.pending_deliveries()
    assert len(queue) == 1
    assert queue[0]["webhook_id"] == hook_a.id

    delivery_id = deliveries[0].id
    assert manager.mark_failed(delivery_id, error="timeout", response_code=504)
    hist = manager.delivery_history(webhook_id=hook_a.id)
    assert hist[0].status == "retrying"

    assert manager.mark_failed(delivery_id, error="timeout", response_code=504)
    hist = manager.delivery_history(webhook_id=hook_a.id)
    assert hist[0].status == "failed"
    assert hist[0].attempts == 2

    assert manager.mark_delivered(delivery_id, response_code=200)
    hist = manager.delivery_history(webhook_id=hook_a.id)
    assert hist[0].status == "delivered"
    assert hist[0].response_code == 200

    assert not manager.mark_delivered("missing")
    assert not manager.mark_failed("missing", error="n/a")

    drained = manager.drain_queue()
    assert len(drained) == 1
    assert manager.pending_deliveries() == []

    payload = '{"ok":true}'
    sig = manager.compute_signature(payload, "abc")
    assert isinstance(sig, str)
    assert len(sig) == 64

    stats = manager.stats()
    assert stats["total_webhooks"] == 2
    assert stats["active_webhooks"] == 1
    assert stats["total_deliveries"] == 1
    assert stats["delivered"] == 1

    assert manager.deregister(hook_b.id)
    assert not manager.deregister("missing")


def test_webhook_manager_process_queue_supports_success_failure_and_retry() -> None:
    manager = WebhookManager()
    hook = manager.register(
        url="https://example.com/retry",
        secret="s",
        event_types=["memory.store"],
        max_retries=2,
    )

    manager.enqueue({"id": "evt-1", "event_type": "memory.store", "payload": {}})
    first_pass = manager.process_queue(fail_webhook_ids={hook.id})
    assert first_pass["processed"] == 1
    assert first_pass["retried"] == 1
    assert first_pass["queue_size"] == 1

    retry_hist = manager.delivery_history(webhook_id=hook.id, limit=1)[0]
    assert retry_hist.status == "retrying"
    assert retry_hist.attempts == 1

    second_pass = manager.process_queue(fail_webhook_ids={hook.id})
    assert second_pass["processed"] == 1
    assert second_pass["failed"] == 1
    assert second_pass["queue_size"] == 0

    failed_hist = manager.delivery_history(webhook_id=hook.id, limit=1)[0]
    assert failed_hist.status == "failed"
    assert failed_hist.attempts == 2

    manager.enqueue({"id": "evt-2", "event_type": "memory.store", "payload": {}})
    success_pass = manager.process_queue()
    assert success_pass["processed"] == 1
    assert success_pass["delivered"] == 1
    assert success_pass["queue_size"] == 0
