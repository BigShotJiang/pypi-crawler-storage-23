"""Tests for temporal index, knowledge graph, and vector store."""

from __future__ import annotations

from datetime import datetime

import pytest

from aegis.core.types import MemoryTier
from aegis.memory.graph import Edge, KnowledgeGraph
from aegis.memory.temporal import TemporalIndex
from aegis.memory.types import MemoryEntry
from aegis.memory.vector import VectorStore

# ===========================================================================
# Temporal Index
# ===========================================================================


class TestTemporalAdd:
    """Adding records to the temporal index."""

    def test_add_single(self) -> None:
        idx = TemporalIndex()
        rec = idx.add("k1", valid_from=datetime(2025, 1, 1))
        assert rec.key == "k1"
        assert rec.version == 1
        assert idx.count() == 1

    def test_add_multiple_keys(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 1, 1))
        idx.add("k2", valid_from=datetime(2025, 1, 2))
        assert idx.count() == 2

    def test_version_increments(self) -> None:
        idx = TemporalIndex()
        r1 = idx.add("k1", valid_from=datetime(2025, 1, 1))
        r2 = idx.add("k1", valid_from=datetime(2025, 2, 1))
        assert r1.version == 1
        assert r2.version == 2

    def test_sorted_order(self) -> None:
        idx = TemporalIndex()
        idx.add("late", valid_from=datetime(2025, 6, 1))
        idx.add("early", valid_from=datetime(2025, 1, 1))
        idx.add("mid", valid_from=datetime(2025, 3, 1))
        records = idx.all_records()
        timestamps = [r.valid_from for r in records]
        assert timestamps == sorted(timestamps)


class TestTemporalQueryAt:
    """Point-in-time queries."""

    def test_query_active_entry(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 1, 1), valid_to=datetime(2025, 12, 31))
        results = idx.query_at(datetime(2025, 6, 1))
        assert len(results) == 1
        assert results[0].key == "k1"

    def test_query_expired_entry(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 1, 1), valid_to=datetime(2025, 3, 1))
        results = idx.query_at(datetime(2025, 6, 1))
        assert len(results) == 0

    def test_query_not_yet_valid(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 6, 1))
        results = idx.query_at(datetime(2025, 1, 1))
        assert len(results) == 0

    def test_open_ended_entry(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 1, 1))  # valid_to=None
        results = idx.query_at(datetime(2099, 12, 31))
        assert len(results) == 1


class TestTemporalSupersession:
    """Supersession of temporal records."""

    def test_supersede_marks_old(self) -> None:
        idx = TemporalIndex()
        idx.add("old", valid_from=datetime(2025, 1, 1))
        idx.add("new", valid_from=datetime(2025, 6, 1))
        idx.supersede("old", "new", datetime(2025, 6, 1))
        history = idx.history("old")
        assert history[-1].superseded_by == "new"
        assert history[-1].valid_to == datetime(2025, 6, 1)

    def test_is_superseded_true(self) -> None:
        idx = TemporalIndex()
        idx.add("old", valid_from=datetime(2025, 1, 1))
        idx.add("new", valid_from=datetime(2025, 6, 1))
        idx.supersede("old", "new", datetime(2025, 6, 1))
        assert idx.is_superseded("old") is True

    def test_is_superseded_false_for_unknown(self) -> None:
        idx = TemporalIndex()
        assert idx.is_superseded("nonexistent") is False

    def test_get_current_after_supersession(self) -> None:
        idx = TemporalIndex()
        idx.add("old", valid_from=datetime(2025, 1, 1))
        idx.add("new", valid_from=datetime(2025, 6, 1))
        idx.supersede("old", "new", datetime(2025, 6, 1))
        # "old" has no non-superseded version left.
        assert idx.get_current("old") is None
        # "new" was never superseded.
        current = idx.get_current("new")
        assert current is not None
        assert current.key == "new"

    def test_supersede_nonexistent_raises(self) -> None:
        idx = TemporalIndex()
        with pytest.raises(KeyError):
            idx.supersede("ghost", "new", datetime(2025, 6, 1))


class TestTemporalHistory:
    """History queries for temporal records."""

    def test_history_returns_all_versions(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 1, 1))
        idx.add("k1", valid_from=datetime(2025, 6, 1))
        idx.add("k1", valid_from=datetime(2025, 9, 1))
        assert len(idx.history("k1")) == 3

    def test_history_sorted_by_time(self) -> None:
        idx = TemporalIndex()
        idx.add("k1", valid_from=datetime(2025, 9, 1))
        idx.add("k1", valid_from=datetime(2025, 1, 1))
        history = idx.history("k1")
        timestamps = [r.valid_from for r in history]
        assert timestamps == sorted(timestamps)

    def test_history_empty_for_unknown(self) -> None:
        idx = TemporalIndex()
        assert idx.history("nonexistent") == []


# ===========================================================================
# Knowledge Graph
# ===========================================================================


class TestGraphNodes:
    """Node operations."""

    def test_add_node(self) -> None:
        g = KnowledgeGraph()
        g.add_node("A")
        assert g.has_node("A")

    def test_has_node(self) -> None:
        g = KnowledgeGraph()
        assert g.has_node("A") is False
        g.add_node("A")
        assert g.has_node("A") is True

    def test_node_count(self) -> None:
        g = KnowledgeGraph()
        g.add_node("A")
        g.add_node("B")
        g.add_node("C")
        assert g.node_count() == 3


class TestGraphEdges:
    """Edge CRUD operations."""

    def test_add_edge_auto_adds_nodes(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "related")
        assert g.has_node("A")
        assert g.has_node("B")

    def test_add_edge_returns_edge(self) -> None:
        g = KnowledgeGraph()
        edge = g.add_edge("A", "B", "related")
        assert isinstance(edge, Edge)
        assert edge.source == "A"
        assert edge.target == "B"
        assert edge.relation == "related"

    def test_has_edge(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "related")
        assert g.has_edge("A", "B") is True
        assert g.has_edge("B", "A") is False  # directed

    def test_has_edge_with_relation(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "causes")
        assert g.has_edge("A", "B", "causes") is True
        assert g.has_edge("A", "B", "related") is False

    def test_remove_edge(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "related")
        removed = g.remove_edge("A", "B")
        assert removed is True
        assert g.has_edge("A", "B") is False

    def test_remove_edge_by_relation(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "causes")
        g.add_edge("A", "B", "related")
        removed = g.remove_edge("A", "B", relation="causes")
        assert removed is True
        assert g.has_edge("A", "B", "causes") is False
        assert g.has_edge("A", "B", "related") is True

    def test_edge_count(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r1")
        g.add_edge("B", "C", "r2")
        g.add_edge("A", "C", "r3")
        assert g.edge_count() == 3


class TestGraphTraversal:
    """Neighbour and path traversal."""

    def test_neighbors_outgoing(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("A", "C", "r")
        neighbours = g.neighbors("A", direction="outgoing")
        assert set(neighbours) == {"B", "C"}

    def test_neighbors_incoming(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("B", "A", "r")
        g.add_edge("C", "A", "r")
        neighbours = g.neighbors("A", direction="incoming")
        assert set(neighbours) == {"B", "C"}

    def test_neighbors_both(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("C", "A", "r")
        neighbours = g.neighbors("A", direction="both")
        assert set(neighbours) == {"B", "C"}

    def test_neighbors_filtered_by_relation(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "causes")
        g.add_edge("A", "C", "related")
        neighbours = g.neighbors("A", relation="causes", direction="outgoing")
        assert neighbours == ["B"]

    def test_shortest_path(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("B", "C", "r")
        g.add_edge("A", "C", "r")
        path = g.shortest_path("A", "C")
        # Direct edge A->C is shorter than A->B->C.
        assert path == ["A", "C"]

    def test_shortest_path_no_path(self) -> None:
        g = KnowledgeGraph()
        g.add_node("A")
        g.add_node("B")
        assert g.shortest_path("A", "B") is None

    def test_all_paths(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("B", "C", "r")
        g.add_edge("A", "C", "r")
        paths = g.all_paths("A", "C")
        assert len(paths) >= 2  # direct + via B

    def test_subgraph(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("B", "C", "r")
        g.add_edge("C", "D", "r")
        sub = g.subgraph("A", depth=1)
        # depth=1 from A: visits A (edges A->B), then visits B (edges B->C).
        assert "A" in sub
        # B should also be in the subgraph because it was visited at depth 1.
        assert "B" in sub


class TestGraphClear:
    """Clearing the graph."""

    def test_clear_empties_all(self) -> None:
        g = KnowledgeGraph()
        g.add_edge("A", "B", "r")
        g.add_edge("C", "D", "r")
        g.clear()
        assert g.node_count() == 0
        assert g.edge_count() == 0


# ===========================================================================
# Vector Store (fallback / fuzzy mode)
# ===========================================================================


def _make_entry(key: str, value: str) -> MemoryEntry:
    return MemoryEntry(key=key, value=value, tier=MemoryTier.WORKING)


class TestVectorStoreFallback:
    """VectorStore in fallback (difflib) mode -- no ML dependencies needed."""

    def test_fallback_mode_active(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        assert vs._fallback_mode is True

    def test_add_and_search_fuzzy(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("k1", "the quick brown fox"))
        results = vs.search("quick brown fox")
        assert len(results) >= 1
        assert results[0][0].key == "k1"

    def test_search_ranking_by_similarity(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("exact", "hello world"))
        vs.add(_make_entry("partial", "hello there"))
        vs.add(_make_entry("unrelated", "python programming"))
        results = vs.search("hello world")
        # "exact" should rank highest.
        assert results[0][0].key == "exact"

    def test_min_score_filtering(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("k1", "abcdef"))
        vs.add(_make_entry("k2", "zzzzzzzzzzzzz"))
        results = vs.search("abcdef", min_score=0.8)
        keys = {entry.key for entry, _score in results}
        assert "k1" in keys
        # "k2" should be filtered out by min_score.
        assert "k2" not in keys

    def test_remove_entry(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("k1", "test data"))
        assert vs.remove("k1") is True
        assert vs.count() == 0
        assert vs.remove("k1") is False  # already gone

    def test_count(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        assert vs.count() == 0
        vs.add(_make_entry("a", "alpha"))
        vs.add(_make_entry("b", "beta"))
        assert vs.count() == 2

    def test_reindex(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("old", "old data"))
        new_entries = {
            "new1": _make_entry("new1", "new data 1"),
            "new2": _make_entry("new2", "new data 2"),
        }
        vs.reindex(new_entries)
        assert vs.count() == 2
        # Old entry should be gone.
        results = vs.search("old data", min_score=0.5)
        keys = {entry.key for entry, _score in results}
        assert "old" not in keys

    def test_search_empty_store(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        results = vs.search("anything")
        assert results == []

    def test_fuzzy_similar_terms(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("k1", "machine learning algorithms"))
        results = vs.search("machine learning algorithm", min_score=0.5)
        assert len(results) >= 1

    def test_search_no_match(self) -> None:
        vs = VectorStore(enable_embeddings=False)
        vs.add(_make_entry("k1", "aaaa"))
        results = vs.search("zzzzzzzzzzzzzzzzzzzzzzzzzz", min_score=0.9)
        assert len(results) == 0
