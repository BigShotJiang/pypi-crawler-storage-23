"""Integration tests for LLM judge backends.

These tests hit real APIs and require API keys to be set.
Run with: pytest -m integration tests/test_llm_judge_integration.py
"""

from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

import httpx
import pytest

from aegis.eval.scorers.llm_backend import (
    AnthropicLLMBackend,
    HTTPLLMBackend,
    _retry_with_backoff,
)
from aegis.eval.scorers.llm_judge import LLMJudgeScorer

pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SIMPLE_SCORING_PROMPT = (
    "Return a JSON object with two fields: "
    '"score" (a float 0.0-1.0) and "reasoning" (a string). '
    "Score how similar these are: "
    'agent said "The capital of France is Paris", '
    'expected answer is "Paris". '
    "Be generous; exact match is 1.0."
)


def _has_openai_key() -> bool:
    return bool(
        os.environ.get("AEGIS_OPENAI_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("AEGIS_LLM_API_KEY")
    )


def _has_anthropic_key() -> bool:
    return bool(os.environ.get("AEGIS_ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_API_KEY"))


def _get_openai_key() -> str:
    return (
        os.environ.get("AEGIS_OPENAI_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("AEGIS_LLM_API_KEY")
        or ""
    )


def _get_anthropic_key() -> str:
    return os.environ.get("AEGIS_ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_API_KEY") or ""


# ---------------------------------------------------------------------------
# Real API tests — OpenAI
# ---------------------------------------------------------------------------


class TestHTTPLLMBackendIntegration:
    """Integration tests that call the real OpenAI API."""

    @pytest.mark.skipif(not _has_openai_key(), reason="No OpenAI API key set")
    def test_complete_returns_valid_json(self) -> None:
        """HTTPLLMBackend.complete() returns a response containing a parseable score."""
        backend = HTTPLLMBackend(api_key=_get_openai_key())
        response = backend.complete(_SIMPLE_SCORING_PROMPT, "gpt-4o-mini", 0.0)

        # Should be parseable JSON with a score field
        data = json.loads(response)
        assert "score" in data
        assert 0.0 <= float(data["score"]) <= 1.0

    @pytest.mark.skipif(not _has_openai_key(), reason="No OpenAI API key set")
    def test_usage_stats_populated(self) -> None:
        """Usage stats contain non-zero token counts after a real call."""
        backend = HTTPLLMBackend(api_key=_get_openai_key())
        backend.complete(_SIMPLE_SCORING_PROMPT, "gpt-4o-mini", 0.0)

        assert backend.last_usage is not None
        assert backend.last_usage.prompt_tokens > 0
        assert backend.last_usage.completion_tokens > 0
        assert backend.last_usage.total_tokens > 0
        assert backend.last_usage.latency_seconds > 0.0
        assert backend.last_usage.model == "gpt-4o-mini"
        assert backend.last_usage.estimated_cost_usd > 0.0


# ---------------------------------------------------------------------------
# Real API tests — Anthropic
# ---------------------------------------------------------------------------


class TestAnthropicLLMBackendIntegration:
    """Integration tests that call the real Anthropic API."""

    @pytest.mark.skipif(not _has_anthropic_key(), reason="No Anthropic API key set")
    def test_complete_returns_valid_json(self) -> None:
        """AnthropicLLMBackend.complete() returns a response containing a parseable score."""
        backend = AnthropicLLMBackend(api_key=_get_anthropic_key())
        response = backend.complete(_SIMPLE_SCORING_PROMPT, "claude-3-haiku-20240307", 0.0)

        data = json.loads(response)
        assert "score" in data
        assert 0.0 <= float(data["score"]) <= 1.0

    @pytest.mark.skipif(not _has_anthropic_key(), reason="No Anthropic API key set")
    def test_usage_stats_populated(self) -> None:
        """Usage stats contain non-zero token counts after a real call."""
        backend = AnthropicLLMBackend(api_key=_get_anthropic_key())
        backend.complete(_SIMPLE_SCORING_PROMPT, "claude-3-haiku-20240307", 0.0)

        assert backend.last_usage is not None
        assert backend.last_usage.prompt_tokens > 0
        assert backend.last_usage.completion_tokens > 0
        assert backend.last_usage.total_tokens > 0
        assert backend.last_usage.latency_seconds > 0.0
        assert backend.last_usage.model == "claude-3-haiku-20240307"
        assert backend.last_usage.estimated_cost_usd > 0.0


# ---------------------------------------------------------------------------
# End-to-end LLMJudgeScorer
# ---------------------------------------------------------------------------


class TestLLMJudgeScorerIntegration:
    """End-to-end integration tests using LLMJudgeScorer with a real API."""

    @pytest.mark.skipif(not _has_openai_key(), reason="No OpenAI API key set")
    def test_score_end_to_end_openai(self) -> None:
        """LLMJudgeScorer produces a valid score with a real OpenAI backend."""
        backend = HTTPLLMBackend(api_key=_get_openai_key())
        scorer = LLMJudgeScorer(model="gpt-4o-mini", backend=backend)

        score = scorer.score(
            agent_output="The capital of France is Paris.",
            ground_truth="Paris",
        )

        assert 0.0 <= score <= 1.0
        # The answer is correct, so we expect a reasonably high score
        assert score >= 0.5

        # Usage stats should be available
        assert scorer.usage_stats is not None
        assert scorer.usage_stats.call_count == 1
        assert scorer.usage_stats.prompt_tokens > 0

    @pytest.mark.skipif(not _has_anthropic_key(), reason="No Anthropic API key set")
    def test_score_end_to_end_anthropic(self) -> None:
        """LLMJudgeScorer produces a valid score with a real Anthropic backend."""
        backend = AnthropicLLMBackend(api_key=_get_anthropic_key())
        scorer = LLMJudgeScorer(model="claude-3-haiku-20240307", backend=backend)

        score = scorer.score(
            agent_output="The capital of France is Paris.",
            ground_truth="Paris",
        )

        assert 0.0 <= score <= 1.0
        assert score >= 0.5

        assert scorer.usage_stats is not None
        assert scorer.usage_stats.call_count == 1


# ---------------------------------------------------------------------------
# Rate limit handling (mock-based, always runs)
# ---------------------------------------------------------------------------


class TestRateLimitHandling:
    """Verify retry logic handles 429 rate-limit responses correctly."""

    def test_retry_on_429_then_success(self) -> None:
        """A 429 followed by a successful response should return the success."""
        response_429 = MagicMock()
        response_429.status_code = 429
        exc_429 = httpx.HTTPStatusError(
            "rate limited",
            request=MagicMock(),
            response=response_429,
        )

        call_count = 0

        def mock_fn() -> str:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise exc_429
            return '{"score": 0.9, "reasoning": "good"}'

        result = _retry_with_backoff(mock_fn, max_retries=3, base_delay=0.0)
        assert result == '{"score": 0.9, "reasoning": "good"}'
        assert call_count == 2

    def test_retry_exhaustion_on_persistent_429(self) -> None:
        """Persistent 429s exhaust retries and raise the exception."""
        response_429 = MagicMock()
        response_429.status_code = 429
        exc_429 = httpx.HTTPStatusError(
            "rate limited",
            request=MagicMock(),
            response=response_429,
        )

        fn = MagicMock(side_effect=exc_429)
        with pytest.raises(httpx.HTTPStatusError):
            _retry_with_backoff(fn, max_retries=2, base_delay=0.0)
        assert fn.call_count == 3  # 1 initial + 2 retries

    def test_backend_complete_retries_on_429(self) -> None:
        """HTTPLLMBackend.complete() retries on a 429 then succeeds."""
        backend = HTTPLLMBackend(api_key="sk-test")

        response_429 = MagicMock()
        response_429.status_code = 429
        response_429.raise_for_status.side_effect = httpx.HTTPStatusError(
            "rate limited",
            request=MagicMock(),
            response=response_429,
        )

        response_ok = MagicMock()
        response_ok.status_code = 200
        response_ok.json.return_value = {
            "choices": [{"message": {"content": '{"score": 0.8}'}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        }
        response_ok.raise_for_status = MagicMock()

        call_count = 0

        def side_effect_post(*args: object, **kwargs: object) -> MagicMock:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return response_429
            return response_ok

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.side_effect = side_effect_post
            mock_client_cls.return_value = mock_client

            result = backend.complete("prompt", "gpt-4o", 0.0)

        assert result == '{"score": 0.8}'
        assert call_count == 2
