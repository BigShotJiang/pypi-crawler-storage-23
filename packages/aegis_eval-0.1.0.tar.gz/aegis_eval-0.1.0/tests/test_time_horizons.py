"""Tests for time horizon assignment and retention policies."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any, cast

from aegis.memory.time_horizons import (
    RetentionPolicy,
    TimeHorizon,
    TimeHorizonManager,
    _entry_age,
    _next_horizon,
)


def _entry(
    *,
    key: str,
    horizon: TimeHorizon,
    age_seconds: int,
    confidence: float = 1.0,
) -> dict[str, Any]:
    return {
        "key": key,
        "horizon": horizon,
        "created_at": datetime.now(tz=UTC) - timedelta(seconds=age_seconds),
        "confidence": confidence,
        "memory_type": "factual",
    }


def test_next_horizon_chain_and_terminal_none() -> None:
    assert _next_horizon(TimeHorizon.SUB_SECOND) == TimeHorizon.TURN_LEVEL
    assert _next_horizon(TimeHorizon.META_LEVEL) is None


def test_entry_age_handles_naive_datetimes() -> None:
    now = datetime.now()
    created = now - timedelta(seconds=12)
    age = _entry_age({"created_at": created}, now)

    assert age >= 11
    assert age <= 13


def test_assign_horizon_forced_override_and_invalid_override() -> None:
    manager = TimeHorizonManager()

    forced = manager.assign_horizon(
        entry_age_seconds=10,
        entry_type="factual",
        context={"force_horizon": TimeHorizon.CLIENT_LEVEL.value},
    )
    invalid_forced = manager.assign_horizon(
        entry_age_seconds=10,
        entry_type="factual",
        context={"force_horizon": "not-a-horizon"},
    )

    assert forced == TimeHorizon.CLIENT_LEVEL
    assert invalid_forced == TimeHorizon.TURN_LEVEL


def test_assign_horizon_age_and_type_biases() -> None:
    manager = TimeHorizonManager()

    long_lived = manager.assign_horizon(entry_age_seconds=30, entry_type="strategic")
    short_lived = manager.assign_horizon(entry_age_seconds=50_000_000, entry_type="working_memory")
    very_old = manager.assign_horizon(entry_age_seconds=50_000_000, entry_type="factual")

    assert long_lived == TimeHorizon.ENGAGEMENT_LEVEL
    assert short_lived == TimeHorizon.SESSION_LEVEL
    assert very_old in {TimeHorizon.DOMAIN_LEVEL, TimeHorizon.META_LEVEL}


def test_enforce_retention_tracks_expired_promoted_and_decayed() -> None:
    manager = TimeHorizonManager()
    now = datetime.now(tz=UTC)

    expired = _entry(key="expired", horizon=TimeHorizon.TURN_LEVEL, age_seconds=5000)
    promotable = _entry(key="promote", horizon=TimeHorizon.TURN_LEVEL, age_seconds=2000)
    stable = _entry(key="stable", horizon=TimeHorizon.META_LEVEL, age_seconds=2000)
    unknown = {
        "key": "unknown",
        "horizon": cast("Any", "unknown"),
        "created_at": now - timedelta(seconds=2000),
        "confidence": 1.0,
    }

    result = manager.enforce_retention([expired, promotable, stable, unknown], current_time=now)

    assert expired in result["expired"]
    assert promotable in result["promoted"]
    assert promotable in result["decayed"]
    assert stable not in result["expired"]
    assert unknown not in result["expired"]
    assert promotable["confidence"] < 1.0


def test_promote_eligible_updates_horizon_in_place() -> None:
    manager = TimeHorizonManager()
    now = datetime.now(tz=UTC)

    turn = _entry(key="turn", horizon=TimeHorizon.TURN_LEVEL, age_seconds=2000)
    meta = _entry(key="meta", horizon=TimeHorizon.META_LEVEL, age_seconds=2000)

    promoted = manager.promote_eligible([turn, meta], current_time=now)

    assert turn in promoted
    assert turn["horizon"] == TimeHorizon.SESSION_LEVEL
    assert meta not in promoted


def test_apply_decay_counts_only_changed_entries() -> None:
    manager = TimeHorizonManager()
    now = datetime.now(tz=UTC)

    with_decay = _entry(key="d1", horizon=TimeHorizon.TURN_LEVEL, age_seconds=1000)
    no_decay_rate = _entry(key="d2", horizon=TimeHorizon.META_LEVEL, age_seconds=1000)

    changed = manager.apply_decay([with_decay, no_decay_rate], current_time=now)

    assert changed == 1
    assert with_decay["confidence"] < 1.0
    assert no_decay_rate["confidence"] == 1.0


def test_stats_and_summary_with_partial_policy_configuration() -> None:
    partial = [
        RetentionPolicy(
            horizon=TimeHorizon.TURN_LEVEL,
            max_age_seconds=10,
            max_entries=2,
            auto_promote_after=5,
            decay_rate=0.1,
            priority=1,
        )
    ]
    manager = TimeHorizonManager(policies=partial)

    entries = [
        _entry(key="a", horizon=TimeHorizon.TURN_LEVEL, age_seconds=1),
        _entry(key="b", horizon=TimeHorizon.SESSION_LEVEL, age_seconds=1),
    ]

    counts = manager.stats(entries)
    summary = manager.summary()

    assert counts[TimeHorizon.TURN_LEVEL.value] == 1
    assert counts[TimeHorizon.SESSION_LEVEL.value] == 1
    assert "max_age_seconds" in summary[TimeHorizon.TURN_LEVEL.value]
    assert summary[TimeHorizon.SESSION_LEVEL.value]["configured"] is False
