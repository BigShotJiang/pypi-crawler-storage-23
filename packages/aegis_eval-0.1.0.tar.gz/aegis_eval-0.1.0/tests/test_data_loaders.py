"""Tests for dataset download and conversion.

All tests run offline using mocked data — no real downloads occur.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from aegis.cli.main import app
from aegis.core.types import EvalCaseV1, EvalTier
from aegis.data.downloader import DatasetDownloader

runner = CliRunner()

# ---------------------------------------------------------------------------
# Fixtures: mock dataset rows
# ---------------------------------------------------------------------------

CUAD_ROWS = [
    {
        "question": "What is the effective date of the agreement?",
        "context": "This Agreement is entered into as of January 1, 2024 between ...",
        "answers": {"text": ["January 1, 2024"], "answer_start": [45]},
    },
    {
        "question": "What is the governing law?",
        "context": "This Agreement shall be governed by the laws of the State of Delaware ...",
        "answers": {"text": ["the laws of the State of Delaware"], "answer_start": [42]},
    },
    {
        "question": "Is there an indemnification clause?",
        "context": "Section 8. Indemnification. Each party shall indemnify and hold harmless ...",
        "answers": {"text": ["Each party shall indemnify and hold harmless"], "answer_start": [28]},
    },
    {
        # Unanswerable — should be skipped
        "question": "What is the termination fee?",
        "context": "The contract does not specify any termination provisions.",
        "answers": {"text": [], "answer_start": []},
    },
]

LEGALBENCH_ROWS = [
    {
        "task": "contract_qa",
        "text": "Does the contract contain a non-compete clause?",
        "answer": "Yes",
    },
    {
        "task": "hearsay",
        "text": "Is the following statement hearsay: 'John told me that ...'",
        "answer": "Yes",
    },
    {
        "task": "statutory_reasoning_assessment",
        "text": "Under Section 230, is the platform liable?",
        "answer": "No",
    },
]

FINANCEBENCH_ROWS = [
    {
        "question": "What was Apple's revenue in Q4 2023?",
        "answer": "$119.6 billion",
        "question_type": "metrics-sourced",
        "company": "Apple Inc.",
        "doc_name": "AAPL-10Q-2023",
        "evidence": "Revenue for the quarter was $119.6 billion...",
    },
    {
        "question": "How did Microsoft's cloud margin change year-over-year?",
        "answer": "Cloud margin improved by 3 percentage points",
        "question_type": "metrics-generated",
        "company": "Microsoft",
        "doc_name": "MSFT-10K-2023",
        "evidence": "",
    },
    {
        # Missing answer — should be skipped
        "question": "What is the dividend yield?",
        "answer": "",
        "question_type": "metrics-sourced",
        "company": "Test Corp",
    },
]


def _write_jsonl(path: Path, rows: list[dict]) -> None:
    """Write rows as JSON Lines to a file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row) + "\n")
    # Also write the completion marker
    (path.parent / ".download_complete").write_text("ok", encoding="utf-8")
    # Write a checksum
    checksum = DatasetDownloader._sha256(path)
    (path.parent / "sha256.txt").write_text(checksum, encoding="utf-8")


# ---------------------------------------------------------------------------
# DatasetDownloader tests
# ---------------------------------------------------------------------------


class TestDatasetDownloader:
    """Test downloader caching logic (mock HTTP)."""

    def test_cache_dir_creation(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "test_cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)
        assert cache_dir.exists()
        assert downloader.cache_dir == cache_dir

    def test_download_returns_cached_path(self, tmp_path: Path) -> None:
        """If a dataset is already downloaded, return the cached path."""
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)

        # Pre-populate cache
        dataset_dir = cache_dir / "test__dataset"
        dataset_dir.mkdir(parents=True)
        _write_jsonl(dataset_dir / "data.jsonl", [{"test": "data"}])

        result = downloader.download("test/dataset")
        assert result == dataset_dir

    def test_list_cached_empty(self, tmp_path: Path) -> None:
        downloader = DatasetDownloader(cache_dir=tmp_path / "empty_cache")
        assert downloader.list_cached() == []

    def test_list_cached_with_datasets(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)

        # Create fake cached datasets
        for name in ["cuad", "nguha__legalbench"]:
            d = cache_dir / name
            d.mkdir(parents=True)
            (d / "data.jsonl").write_text('{"test": true}\n', encoding="utf-8")
            (d / ".download_complete").write_text("ok", encoding="utf-8")

        cached = downloader.list_cached()
        assert len(cached) == 2
        names = {entry["name"] for entry in cached}
        assert "cuad" in names
        assert "nguha/legalbench" in names
        assert all(entry["complete"] for entry in cached)

    def test_verify_checksum_valid(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)
        dataset_dir = cache_dir / "test"
        dataset_dir.mkdir(parents=True)
        _write_jsonl(dataset_dir / "data.jsonl", [{"test": "data"}])

        assert downloader.verify_checksum(dataset_dir) is True

    def test_verify_checksum_invalid(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)
        dataset_dir = cache_dir / "test"
        dataset_dir.mkdir(parents=True)
        data_file = dataset_dir / "data.jsonl"
        data_file.write_text('{"test": "data"}\n', encoding="utf-8")
        (dataset_dir / "sha256.txt").write_text("badhash", encoding="utf-8")

        assert downloader.verify_checksum(dataset_dir) is False

    def test_verify_checksum_missing_files(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)
        dataset_dir = cache_dir / "test"
        dataset_dir.mkdir(parents=True)

        assert downloader.verify_checksum(dataset_dir) is False

    def test_clear_cache_all(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)

        # Create fake datasets
        (cache_dir / "ds1").mkdir(parents=True)
        (cache_dir / "ds2").mkdir(parents=True)
        assert len(list(cache_dir.iterdir())) == 2

        downloader.clear_cache()
        # Cache dir should exist but be empty
        assert cache_dir.exists()
        assert len(list(cache_dir.iterdir())) == 0

    def test_clear_cache_specific(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        downloader = DatasetDownloader(cache_dir=cache_dir)

        (cache_dir / "test__dataset").mkdir(parents=True)
        (cache_dir / "other").mkdir(parents=True)

        downloader.clear_cache("test/dataset")
        assert not (cache_dir / "test__dataset").exists()
        assert (cache_dir / "other").exists()

    def test_sha256_deterministic(self, tmp_path: Path) -> None:
        f = tmp_path / "test.txt"
        f.write_text("hello world", encoding="utf-8")
        h1 = DatasetDownloader._sha256(f)
        h2 = DatasetDownloader._sha256(f)
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex digest


# ---------------------------------------------------------------------------
# CUAD loader tests
# ---------------------------------------------------------------------------


class TestCUADLoader:
    """Test CUAD conversion using mock data."""

    def test_load_cuad_converts_rows(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", CUAD_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            cases = load_cuad(cache_dir=cache_dir)

        # 4 rows, but one has no answers -> 3 cases
        assert len(cases) == 3
        for case in cases:
            assert isinstance(case, EvalCaseV1)
            assert case.domain == "legal"
            assert case.dimension_id == "contract_clause_extraction"
            assert case.suite_id == "cuad-legal-v1"
            assert "cuad" in case.tags

    def test_load_cuad_expected_fields(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", CUAD_ROWS[:1])

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            cases = load_cuad(cache_dir=cache_dir)

        assert len(cases) == 1
        case = cases[0]
        assert case.prompt == "What is the effective date of the agreement?"
        assert case.expected["answer"] == "January 1, 2024"
        assert "all_answers" in case.expected

    def test_load_cuad_respects_max_examples(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", CUAD_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            cases = load_cuad(cache_dir=cache_dir, max_examples=2)

        assert len(cases) == 2

    def test_load_cuad_skips_unanswerable(self, tmp_path: Path) -> None:
        """Unanswerable examples (empty answers) should be skipped."""
        unanswerable = [
            {
                "question": "What is the termination fee?",
                "context": "No termination provisions.",
                "answers": {"text": [], "answer_start": []},
            },
        ]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", unanswerable)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            cases = load_cuad(cache_dir=cache_dir)

        assert len(cases) == 0

    def test_load_cuad_difficulty_varies(self, tmp_path: Path) -> None:
        """Difficulty should vary based on answer length."""
        from aegis.data.cuad import _estimate_difficulty

        assert _estimate_difficulty("Yes") == 1  # Very short
        assert _estimate_difficulty("A" * 100) == 3  # Medium
        assert _estimate_difficulty("A" * 500) == 5  # Very long

    def test_load_cuad_file_not_found(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        dataset_dir.mkdir(parents=True)
        # No data.jsonl

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            with pytest.raises(FileNotFoundError, match="Expected data file"):
                load_cuad(cache_dir=cache_dir)


# ---------------------------------------------------------------------------
# LegalBench loader tests
# ---------------------------------------------------------------------------


class TestLegalBenchLoader:
    """Test LegalBench conversion using mock data."""

    def test_load_legalbench_converts_rows(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", LEGALBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir)

        assert len(cases) == 3
        for case in cases:
            assert isinstance(case, EvalCaseV1)
            assert case.domain == "legal"
            assert case.suite_id == "legalbench-v1"
            assert "legalbench" in case.tags

    def test_load_legalbench_dimension_mapping(self, tmp_path: Path) -> None:
        """Tasks should be mapped to appropriate dimension IDs."""
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", LEGALBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir)

        dim_ids = {c.dimension_id for c in cases}
        # contract_qa -> contract_interpretation, hearsay -> legal_rule_recall,
        # statutory_reasoning_assessment -> statutory_reasoning
        assert "contract_interpretation" in dim_ids
        assert "legal_rule_recall" in dim_ids
        assert "statutory_reasoning" in dim_ids

    def test_load_legalbench_task_filter(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", LEGALBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir, tasks=["hearsay"])

        assert len(cases) == 1
        assert cases[0].dimension_id == "legal_rule_recall"

    def test_load_legalbench_per_task_limit(self, tmp_path: Path) -> None:
        """max_per_task should cap examples per task."""
        rows = [
            {"task": "contract_qa", "text": f"Question {i}?", "answer": "Yes"} for i in range(20)
        ]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir, max_per_task=5)

        assert len(cases) == 5

    def test_load_legalbench_unknown_task_uses_default(self, tmp_path: Path) -> None:
        """Unknown task names should map to the default dimension."""
        rows = [{"task": "unknown_new_task", "text": "What?", "answer": "Nothing"}]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir)

        assert len(cases) == 1
        assert cases[0].dimension_id == "legal_reasoning"

    def test_load_legalbench_file_not_found(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        dataset_dir.mkdir(parents=True)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            with pytest.raises(FileNotFoundError, match="Expected data file"):
                load_legalbench(cache_dir=cache_dir)


# ---------------------------------------------------------------------------
# FinanceBench loader tests
# ---------------------------------------------------------------------------


class TestFinanceBenchLoader:
    """Test FinanceBench conversion using mock data."""

    def test_load_financebench_converts_rows(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", FINANCEBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        # 3 rows, but one has no answer -> 2 cases
        assert len(cases) == 2
        for case in cases:
            assert isinstance(case, EvalCaseV1)
            assert case.domain == "finance"
            assert case.suite_id == "financebench-v1"
            assert "financebench" in case.tags

    def test_load_financebench_dimension_mapping(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", FINANCEBENCH_ROWS[:2])

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        dim_ids = {c.dimension_id for c in cases}
        assert "financial_metric_extraction" in dim_ids
        assert "financial_metric_computation" in dim_ids

    def test_load_financebench_context_fields(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", FINANCEBENCH_ROWS[:1])

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        assert len(cases) == 1
        case = cases[0]
        assert case.context["company"] == "Apple Inc."
        assert case.context["document"] == "AAPL-10Q-2023"
        assert case.expected["answer"] == "$119.6 billion"

    def test_load_financebench_respects_max_examples(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", FINANCEBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir, max_examples=1)

        assert len(cases) == 1

    def test_load_financebench_skips_empty_answer(self, tmp_path: Path) -> None:
        empty_rows = [
            {"question": "Test?", "answer": "", "question_type": "metrics-sourced"},
        ]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", empty_rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        assert len(cases) == 0

    def test_load_financebench_difficulty_by_type(self, tmp_path: Path) -> None:
        """Different question types should produce different difficulty levels."""
        rows = [
            {"question": "Q1?", "answer": "A1", "question_type": "metrics-sourced"},
            {"question": "Q2?", "answer": "A2", "question_type": "novel-generated"},
        ]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        difficulties = {c.prompt: c.difficulty for c in cases}
        assert difficulties["Q1?"] == 2  # metrics-sourced
        assert difficulties["Q2?"] == 4  # novel-generated

    def test_load_financebench_file_not_found(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        dataset_dir.mkdir(parents=True)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            with pytest.raises(FileNotFoundError, match="Expected data file"):
                load_financebench(cache_dir=cache_dir)


# ---------------------------------------------------------------------------
# CLI `data` command tests
# ---------------------------------------------------------------------------


class TestDataCLI:
    """Test CLI data subcommands."""

    def test_data_help(self) -> None:
        result = runner.invoke(app, ["data", "--help"])
        assert result.exit_code == 0
        assert "download" in result.stdout.lower()
        assert "list" in result.stdout.lower()
        assert "info" in result.stdout.lower()

    def test_data_download_invalid_dataset(self) -> None:
        result = runner.invoke(app, ["data", "download", "--dataset", "nonexistent"])
        assert result.exit_code != 0
        assert "Unknown dataset" in result.stdout

    def test_data_download_cuad(self, tmp_path: Path) -> None:
        """Test downloading a dataset via the CLI (mocked)."""
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", CUAD_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            result = runner.invoke(
                app,
                ["data", "download", "--dataset", "cuad", "--cache-dir", str(cache_dir)],
            )

        assert result.exit_code == 0
        assert "Loaded" in result.stdout
        assert "cuad" in result.stdout.lower()

    def test_data_download_all(self, tmp_path: Path) -> None:
        """Test downloading all datasets via the CLI (mocked)."""
        cache_dir = tmp_path / "cache"

        def mock_download(dataset_name: str, **kwargs) -> Path:
            safe_name = dataset_name.replace("/", "__")
            d = cache_dir / safe_name
            _write_jsonl(d / "data.jsonl", CUAD_ROWS[:1])
            return d

        with patch.object(DatasetDownloader, "download", side_effect=mock_download):
            result = runner.invoke(
                app,
                ["data", "download", "--dataset", "all", "--cache-dir", str(cache_dir)],
            )

        assert result.exit_code == 0
        assert "All requested datasets downloaded successfully" in result.stdout

    def test_data_list_empty(self) -> None:
        with patch.object(DatasetDownloader, "list_cached", return_value=[]):
            result = runner.invoke(app, ["data", "list"])

        assert result.exit_code == 0
        assert "No datasets downloaded" in result.stdout

    def test_data_list_with_datasets(self) -> None:
        cached = [
            {
                "name": "cuad",
                "path": "/tmp/cache/cuad",
                "size_bytes": 1024 * 500,
                "complete": True,
            },
            {
                "name": "nguha/legalbench",
                "path": "/tmp/cache/nguha__legalbench",
                "size_bytes": 1024 * 1024 * 5,
                "complete": True,
            },
        ]
        with patch.object(DatasetDownloader, "list_cached", return_value=cached):
            result = runner.invoke(app, ["data", "list"])

        assert result.exit_code == 0
        assert "cuad" in result.stdout
        assert "legalbench" in result.stdout
        assert "complete" in result.stdout.lower()

    def test_data_info_not_found(self) -> None:
        with patch.object(DatasetDownloader, "list_cached", return_value=[]):
            result = runner.invoke(app, ["data", "info", "--dataset", "cuad"])

        assert result.exit_code != 0
        assert "not found" in result.stdout.lower()

    def test_data_info_shows_details(self, tmp_path: Path) -> None:
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", CUAD_ROWS)

        cached = [
            {
                "name": "cuad",
                "path": str(dataset_dir),
                "size_bytes": 1024 * 500,
                "complete": True,
            },
        ]
        with (
            patch.object(DatasetDownloader, "list_cached", return_value=cached),
            patch.object(DatasetDownloader, "verify_checksum", return_value=True),
        ):
            result = runner.invoke(app, ["data", "info", "--dataset", "cuad"])

        assert result.exit_code == 0
        assert "cuad" in result.stdout
        assert "Rows" in result.stdout
        assert "OK" in result.stdout


# ---------------------------------------------------------------------------
# Edge case and integration-style tests
# ---------------------------------------------------------------------------


class TestEdgeCases:
    """Additional edge cases for the data loaders."""

    def test_cuad_with_list_answers_format(self, tmp_path: Path) -> None:
        """Some CUAD variants may have answers as a plain list."""
        rows = [
            {
                "question": "What is the term?",
                "context": "The term is 5 years.",
                "answers": ["5 years"],
            },
        ]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "cuad"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.cuad import load_cuad

            cases = load_cuad(cache_dir=cache_dir)

        assert len(cases) == 1
        assert cases[0].expected["answer"] == "5 years"

    def test_legalbench_empty_prompt_skipped(self, tmp_path: Path) -> None:
        """Rows with empty prompts should be skipped."""
        rows = [{"task": "hearsay", "text": "", "answer": "Yes"}]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.legalbench import load_legalbench

            cases = load_legalbench(cache_dir=cache_dir)

        assert len(cases) == 0

    def test_financebench_missing_question_skipped(self, tmp_path: Path) -> None:
        """Rows with empty question should be skipped."""
        rows = [{"question": "", "answer": "Test", "question_type": "metrics-sourced"}]
        cache_dir = tmp_path / "cache"
        dataset_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(dataset_dir / "data.jsonl", rows)

        with patch.object(DatasetDownloader, "download", return_value=dataset_dir):
            from aegis.data.financebench import load_financebench

            cases = load_financebench(cache_dir=cache_dir)

        assert len(cases) == 0

    def test_all_cases_have_valid_eval_tiers(self, tmp_path: Path) -> None:
        """All generated cases should have valid EvalTier values."""
        cache_dir = tmp_path / "cache"

        # Test CUAD
        cuad_dir = cache_dir / "cuad"
        _write_jsonl(cuad_dir / "data.jsonl", CUAD_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=cuad_dir):
            from aegis.data.cuad import load_cuad

            cuad_cases = load_cuad(cache_dir=cache_dir)

        # Test LegalBench
        lb_dir = cache_dir / "nguha__legalbench"
        _write_jsonl(lb_dir / "data.jsonl", LEGALBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=lb_dir):
            from aegis.data.legalbench import load_legalbench

            lb_cases = load_legalbench(cache_dir=cache_dir)

        # Test FinanceBench
        fb_dir = cache_dir / "PatronusAI__financebench"
        _write_jsonl(fb_dir / "data.jsonl", FINANCEBENCH_ROWS)

        with patch.object(DatasetDownloader, "download", return_value=fb_dir):
            from aegis.data.financebench import load_financebench

            fb_cases = load_financebench(cache_dir=cache_dir)

        all_cases = cuad_cases + lb_cases + fb_cases
        for case in all_cases:
            assert isinstance(case.tier, EvalTier)
            assert 1 <= case.difficulty <= 5
            assert case.domain in ("legal", "finance")
            assert case.id  # Non-empty ID
            assert case.prompt  # Non-empty prompt
