# ruff: noqa
"""Tests for eval exporters and data downloader."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aegis.data.downloader import DatasetDownloader
from aegis.eval.reporting.exporters import CSVExporter, HTMLExporter, JSONExporter


# ---------------------------------------------------------------------------
# JSONExporter
# ---------------------------------------------------------------------------


class TestJSONExporter:
    def test_export(self, tmp_path: Path) -> None:
        exporter = JSONExporter()
        data: dict[str, Any] = {
            "run_id": "r1",
            "overall_score": 0.75,
            "dimension_scores": {"dim1": 0.8, "dim2": 0.7},
        }
        out = exporter.export(data, tmp_path / "report.json")
        assert out.exists()
        loaded = json.loads(out.read_text())
        assert loaded["run_id"] == "r1"

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        exporter = JSONExporter(indent=4)
        path = tmp_path / "deep" / "nested" / "report.json"
        exporter.export({"x": 1}, path)
        assert path.exists()


# ---------------------------------------------------------------------------
# HTMLExporter
# ---------------------------------------------------------------------------


class TestHTMLExporter:
    def test_export(self, tmp_path: Path) -> None:
        exporter = HTMLExporter()
        data: dict[str, Any] = {
            "run_id": "r1",
            "agent_id": "agent1",
            "overall_score": 0.85,
            "dimension_scores": {"memory": 0.9, "reasoning": 0.8},
        }
        out = exporter.export(data, tmp_path / "report.html")
        assert out.exists()
        content = out.read_text()
        assert "Aegis Eval Report" in content
        assert "r1" in content
        assert "memory" in content
        assert "0.9000" in content

    def test_empty_dimensions(self, tmp_path: Path) -> None:
        exporter = HTMLExporter()
        out = exporter.export({"run_id": "r1"}, tmp_path / "empty.html")
        assert out.exists()
        assert "<tbody>" in out.read_text()


# ---------------------------------------------------------------------------
# CSVExporter
# ---------------------------------------------------------------------------


class TestCSVExporter:
    def test_export(self, tmp_path: Path) -> None:
        exporter = CSVExporter()
        data: dict[str, Any] = {
            "dimension_scores": {"alpha": 0.1, "beta": 0.2, "gamma": 0.3},
        }
        out = exporter.export(data, tmp_path / "report.csv")
        assert out.exists()
        lines = out.read_text().strip().split("\n")
        assert lines[0] == "dimension_id,score"
        assert len(lines) == 4  # header + 3 rows
        # Should be sorted
        assert "alpha" in lines[1]

    def test_empty_scores(self, tmp_path: Path) -> None:
        exporter = CSVExporter()
        out = exporter.export({}, tmp_path / "empty.csv")
        lines = out.read_text().strip().split("\n")
        assert len(lines) == 1  # header only


# ---------------------------------------------------------------------------
# DatasetDownloader
# ---------------------------------------------------------------------------


class TestDatasetDownloader:
    def test_init_default_cache(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path / "cache")
        assert dl.cache_dir.exists()

    def test_sha256(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        f = tmp_path / "test.txt"
        f.write_text("hello", encoding="utf-8")
        checksum = dl._sha256(f)
        assert isinstance(checksum, str)
        assert len(checksum) == 64  # SHA-256 hex digest

    def test_verify_checksum(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        ds_dir = tmp_path / "test_ds"
        ds_dir.mkdir()
        data_file = ds_dir / "data.jsonl"
        data_file.write_text('{"a": 1}\n', encoding="utf-8")
        checksum = dl._sha256(data_file)
        (ds_dir / "sha256.txt").write_text(checksum, encoding="utf-8")
        assert dl.verify_checksum(ds_dir) is True

    def test_verify_checksum_bad(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        ds_dir = tmp_path / "bad_ds"
        ds_dir.mkdir()
        (ds_dir / "data.jsonl").write_text("x", encoding="utf-8")
        (ds_dir / "sha256.txt").write_text("wrong", encoding="utf-8")
        assert dl.verify_checksum(ds_dir) is False

    def test_verify_checksum_missing(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        assert dl.verify_checksum(tmp_path / "nonexistent") is False

    def test_list_cached(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        # Create a fake cached dataset
        ds = tmp_path / "test__dataset"
        ds.mkdir()
        (ds / "data.jsonl").write_text("{}\n", encoding="utf-8")
        (ds / ".download_complete").write_text("ok", encoding="utf-8")

        cached = dl.list_cached()
        assert len(cached) == 1
        assert cached[0]["name"] == "test/dataset"
        assert cached[0]["complete"] is True

    def test_list_cached_empty(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path / "nonexistent")
        assert dl.list_cached() == []

    def test_clear_cache_all(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        (tmp_path / "ds1").mkdir()
        (tmp_path / "ds2").mkdir()
        dl.clear_cache()
        assert dl.cache_dir.exists()
        assert list(dl.cache_dir.iterdir()) == []

    def test_clear_cache_specific(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        (tmp_path / "owner__ds1").mkdir()
        (tmp_path / "owner__ds2").mkdir()
        dl.clear_cache("owner/ds1")
        assert not (tmp_path / "owner__ds1").exists()
        assert (tmp_path / "owner__ds2").exists()

    def test_download_cached(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        ds = tmp_path / "org__name"
        ds.mkdir()
        (ds / ".download_complete").write_text("ok", encoding="utf-8")
        # Should return immediately without downloading
        result = dl.download("org/name")
        assert result == ds

    def test_download_with_subset(self, tmp_path: Path) -> None:
        dl = DatasetDownloader(cache_dir=tmp_path)
        ds = tmp_path / "org__name" / "sub"
        ds.mkdir(parents=True)
        (ds / ".download_complete").write_text("ok", encoding="utf-8")
        result = dl.download("org/name", subset="sub")
        assert result == ds
