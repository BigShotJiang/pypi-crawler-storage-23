"""Tests for the training engine (AMIRGRPOTrainer and GRPOSGTrainer)."""

from __future__ import annotations

import json
from pathlib import Path

from aegis.training.engine import AMIRGRPOTrainer, GRPOSGTrainer, RLTrainer

# ---------------------------------------------------------------------------
# Protocol conformance
# ---------------------------------------------------------------------------


class TestProtocolConformance:
    def test_amir_grpo_implements_protocol(self) -> None:
        assert isinstance(AMIRGRPOTrainer(), RLTrainer)

    def test_grpo_sg_implements_protocol(self) -> None:
        assert isinstance(GRPOSGTrainer(), RLTrainer)


# ---------------------------------------------------------------------------
# AMIRGRPOTrainer
# ---------------------------------------------------------------------------


class TestAMIRGRPOTrainer:
    def test_train_returns_completed(self) -> None:
        trainer = AMIRGRPOTrainer()
        result = trainer.train({"num_episodes": 10, "max_steps": 100})
        assert result["status"] == "completed"
        assert result["model"] == "base-agent-v1"
        assert result["num_stages"] == 5
        assert result["total_steps"] > 0

    def test_train_stage_metrics(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=3)
        result = trainer.train({})
        assert len(result["stage_metrics"]) == 3
        rewards = [s["reward"] for s in result["stage_metrics"]]
        # Rewards should increase with diminishing returns
        for i in range(1, len(rewards)):
            assert rewards[i] >= rewards[i - 1]

    def test_train_mean_and_best_reward(self) -> None:
        trainer = AMIRGRPOTrainer()
        result = trainer.train({})
        assert result["mean_reward"] > 0
        assert result["best_reward"] >= result["mean_reward"]
        assert result["final_loss"] > 0

    def test_train_uses_optimizer_and_replay_modules(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=3, group_size=4)
        result = trainer.train(
            {
                "optimizer_variant": "dapo",
                "replay_mix_ratio": 0.5,
                "domain": "legal",
            }
        )
        assert result["optimizer_variant"] == "dapo"
        assert "replay_buffer_stats" in result
        assert result["replay_buffer_stats"]["total"] > 0
        assert "ewc_summary" in result
        for stage in result["stage_metrics"]:
            assert "policy_loss" in stage
            assert "entropy" in stage
            assert "ewc_penalty" in stage

    def test_train_emits_pods_metrics(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=2, group_size=6)
        result = trainer.train({"pods_keep_ratio": 0.5})
        for stage in result["stage_metrics"]:
            assert "pods_selected" in stage
            assert "pods_dropped" in stage
            assert "pods_keep_ratio" in stage
            assert "pods_signal_mean" in stage
            assert stage["pods_selected"] > 0
            assert stage["pods_selected"] + stage["pods_dropped"] == trainer.group_size

    def test_rollout_produces_trajectory(self) -> None:
        trainer = AMIRGRPOTrainer()
        result = trainer.rollout("What is 2+2?")
        assert result["prompt"] == "What is 2+2?"
        assert len(result["trajectory"]) >= 3
        assert len(result["trajectory"]) <= 5
        for step in result["trajectory"]:
            assert "step_id" in step
            assert "action" in step
            assert "reward" in step
            assert 0.0 <= step["reward"] <= 1.0

    def test_rollout_has_stage_rewards(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=3)
        result = trainer.rollout("test prompt")
        assert len(result["rewards"]) == 3
        assert result["total_reward"] > 0

    def test_rollout_deterministic(self) -> None:
        trainer = AMIRGRPOTrainer()
        r1 = trainer.rollout("same prompt")
        r2 = trainer.rollout("same prompt")
        assert r1["trajectory"] == r2["trajectory"]
        assert r1["rewards"] == r2["rewards"]

    def test_checkpoint_writes_file(self, tmp_path: Path) -> None:
        trainer = AMIRGRPOTrainer(model_name="test-model")
        ckpt_path = tmp_path / "checkpoints" / "ckpt.json"
        trainer.checkpoint(str(ckpt_path))
        assert ckpt_path.exists()
        data = json.loads(ckpt_path.read_text())
        assert data["model_name"] == "test-model"
        assert "timestamp" in data

    def test_evaluate_returns_scores(self) -> None:
        trainer = AMIRGRPOTrainer()
        cases = [
            {"prompt": "What is 2+2?", "expected": "4"},
            {"prompt": "Capital of France?", "expected": "Paris"},
        ]
        result = trainer.evaluate(cases)
        assert result["status"] == "completed"
        assert result["num_cases"] == 2
        assert result["metrics"]["mean_score"] >= 0.4
        assert result["metrics"]["max_score"] <= 1.0
        assert len(result["per_case_scores"]) == 2

    def test_evaluate_per_dimension_breakdown(self) -> None:
        trainer = AMIRGRPOTrainer()
        cases = [
            {"prompt": "Q1", "expected": "A1", "dimension_id": "dim_a"},
            {"prompt": "Q2", "expected": "A2", "dimension_id": "dim_a"},
            {"prompt": "Q3", "expected": "A3", "dimension_id": "dim_b"},
        ]
        result = trainer.evaluate(cases)
        assert "per_dimension" in result["metrics"]
        assert "dim_a" in result["metrics"]["per_dimension"]
        assert "dim_b" in result["metrics"]["per_dimension"]

    def test_evaluate_empty_cases(self) -> None:
        trainer = AMIRGRPOTrainer()
        result = trainer.evaluate([])
        assert result["num_cases"] == 0
        assert result["metrics"]["mean_score"] == 0.0

    def test_train_emits_pipeline_artifacts(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=2, group_size=4)
        result = trainer.train(
            {
                "tasks_per_stage": 2,
                "checkpoint_interval": 1,
                "tracking_enabled": False,
            }
        )

        assert "rollout_engine_summary" in result
        assert result["rollout_engine_summary"]["rollout_count"] > 0

        assert "checkpoint_summary" in result
        assert result["checkpoint_summary"]["total_checkpoints"] >= 2
        assert result["latest_checkpoint"] is not None
        assert len(result["checkpoints"]) >= 2

        assert "observatory" in result
        assert "checks" in result["observatory"]
        assert "reward_hacking" in result["observatory"]["checks"]
        assert "gradient_health" in result["observatory"]["checks"]

        assert result["task_generator_summary"]["generated_count"] == 4

    def test_train_eval_callback_integration(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=3, group_size=3)
        eval_cases = [
            {"prompt": "Case A", "expected": "Answer A", "dimension_id": "dim_a"},
            {"prompt": "Case B", "expected": "Answer B", "dimension_id": "dim_b"},
        ]

        result = trainer.train(
            {
                "eval_cases": eval_cases,
                "eval_interval": 1,
                "tracking_enabled": False,
            }
        )

        assert result["eval_callback_summary"]["total_evals"] >= 1
        assert len(result["eval_events"]) >= 1
        assert any("eval" in stage for stage in result["stage_metrics"])

    def test_train_tracking_metadata(self) -> None:
        trainer = AMIRGRPOTrainer(num_stages=1, group_size=2)
        result = trainer.train({"run_name": "training-engine-tracking-test"})

        tracking = result["tracking"]
        assert tracking["run_name"] == "training-engine-tracking-test"
        assert tracking["backend"] in {"local", "wandb"}
        if tracking["backend"] == "local":
            assert tracking["local_path"] is not None
            assert Path(tracking["local_path"]).exists()


# ---------------------------------------------------------------------------
# GRPOSGTrainer
# ---------------------------------------------------------------------------


class TestGRPOSGTrainer:
    def test_train_returns_completed(self) -> None:
        trainer = GRPOSGTrainer()
        result = trainer.train({})
        assert result["status"] == "completed"
        assert result["model"] == "memory-policy-v1"
        assert result["gate_stages_completed"] == 4  # default has 4 gates

    def test_train_stage_metrics_have_ops(self) -> None:
        trainer = GRPOSGTrainer()
        result = trainer.train({})
        for sm in result["stage_metrics"]:
            assert "ops_unlocked" in sm
            assert len(sm["ops_unlocked"]) > 0
            assert "policy_loss" in sm
            assert "replay_batch_size" in sm
            assert "pods_selected" in sm
            assert "pods_dropped" in sm
            assert "pods_keep_ratio" in sm
            assert "pods_signal_mean" in sm
        # Ops should grow as gates unlock
        first_ops = len(result["stage_metrics"][0]["ops_unlocked"])
        last_ops = len(result["stage_metrics"][-1]["ops_unlocked"])
        assert last_ops >= first_ops

    def test_rollout_produces_operations(self) -> None:
        trainer = GRPOSGTrainer()
        result = trainer.rollout("Store the meeting notes")
        assert result["prompt"] == "Store the meeting notes"
        assert len(result["operations"]) >= 2
        assert len(result["operations"]) <= 4
        for op in result["operations"]:
            assert "operation" in op
            assert "key" in op
            assert "reward" in op

    def test_rollout_respects_gate_level(self) -> None:
        trainer = GRPOSGTrainer()
        # Gate level 0 only has STORE and RETRIEVE
        result = trainer.rollout("test", context={"gate_level": 0})
        for op in result["operations"]:
            assert op["operation"] in ["STORE", "RETRIEVE"]

    def test_rollout_deterministic(self) -> None:
        trainer = GRPOSGTrainer()
        r1 = trainer.rollout("same prompt")
        r2 = trainer.rollout("same prompt")
        assert r1["operations"] == r2["operations"]

    def test_checkpoint_writes_file(self, tmp_path: Path) -> None:
        trainer = GRPOSGTrainer(model_name="mem-test")
        ckpt_path = tmp_path / "sg_ckpt.json"
        trainer.checkpoint(str(ckpt_path))
        assert ckpt_path.exists()
        data = json.loads(ckpt_path.read_text())
        assert data["model_name"] == "mem-test"
        assert "gate_schedule" in data

    def test_evaluate_returns_scores(self) -> None:
        trainer = GRPOSGTrainer()
        cases = [
            {"prompt": "Store X", "expected": "ok", "operation": "STORE"},
            {"prompt": "Retrieve Y", "expected": "Y val", "operation": "RETRIEVE"},
        ]
        result = trainer.evaluate(cases)
        assert result["status"] == "completed"
        assert result["num_cases"] == 2
        assert result["overall_accuracy"] >= 0.4
        assert "STORE" in result["operation_metrics"]
        assert "RETRIEVE" in result["operation_metrics"]

    def test_evaluate_empty_cases(self) -> None:
        trainer = GRPOSGTrainer()
        result = trainer.evaluate([])
        assert result["num_cases"] == 0
        assert result["overall_accuracy"] == 0.0

    def test_train_emits_pipeline_artifacts(self) -> None:
        trainer = GRPOSGTrainer(group_size=3)
        result = trainer.train(
            {
                "tasks_per_stage": 2,
                "checkpoint_interval": 1,
                "tracking_enabled": False,
            }
        )

        assert "rollout_engine_summary" in result
        assert result["rollout_engine_summary"]["rollout_count"] > 0

        assert "checkpoint_summary" in result
        assert result["checkpoint_summary"]["total_checkpoints"] >= result["gate_stages_completed"]
        assert result["latest_checkpoint"] is not None
        assert len(result["checkpoints"]) >= result["gate_stages_completed"]

        assert "observatory" in result
        assert "checks" in result["observatory"]
        assert "reward_hacking" in result["observatory"]["checks"]
        assert "gradient_health" in result["observatory"]["checks"]

    def test_train_eval_callback_integration(self) -> None:
        trainer = GRPOSGTrainer(group_size=2)
        eval_cases = [
            {"prompt": "Store A", "expected": "ok", "operation": "STORE"},
            {"prompt": "Retrieve B", "expected": "ok", "operation": "RETRIEVE"},
        ]
        result = trainer.train(
            {
                "eval_cases": eval_cases,
                "eval_interval": 1,
                "tracking_enabled": False,
            }
        )

        assert result["eval_callback_summary"]["total_evals"] >= 1
        assert len(result["eval_events"]) >= 1
        assert any("eval" in stage for stage in result["stage_metrics"])


# ---------------------------------------------------------------------------
# EvalCallback
# ---------------------------------------------------------------------------


class TestEvalCallback:
    def test_should_eval_at_interval(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        cb = EvalCallback(eval_fn=lambda _: {}, eval_interval=5)
        assert cb.should_eval(0) is True
        assert cb.should_eval(1) is False
        assert cb.should_eval(5) is True
        assert cb.should_eval(10) is True

    def test_callback_runs_eval(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        def eval_fn(cases: list[dict[str, object]]) -> dict[str, object]:
            return {
                "mean_score": 0.75,
                "per_dimension": {"dim_a": 0.9, "dim_b": 0.4},
            }

        cases = [{"prompt": "test", "expected": "result"}]
        cb = EvalCallback(eval_fn=eval_fn, eval_cases=cases, eval_interval=1)

        result = cb(episode=0, metrics={})
        assert result is not None
        assert result.mean_score == 0.75
        assert "dim_b" in result.weak_dimensions
        assert "dim_a" in result.strong_dimensions

    def test_callback_skips_off_interval(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        cb = EvalCallback(eval_fn=lambda _: {}, eval_interval=10)
        result = cb(episode=3, metrics={})
        assert result is None

    def test_callback_skips_empty_cases(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        cb = EvalCallback(eval_fn=lambda _: {}, eval_cases=[], eval_interval=1)
        result = cb(episode=0, metrics={})
        assert result is None

    def test_weight_adjustments(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        def eval_fn(cases: list[dict[str, object]]) -> dict[str, object]:
            return {
                "mean_score": 0.6,
                "per_dimension": {"strong": 0.9, "weak": 0.3},
            }

        cb = EvalCallback(
            eval_fn=eval_fn,
            eval_cases=[{"prompt": "test"}],
            eval_interval=1,
        )
        cb(episode=0, metrics={})

        adjustments = cb.weight_adjustments
        assert "weak" in adjustments
        assert "strong" in adjustments
        # Weak dimension should get higher weight
        assert adjustments["weak"] > adjustments["strong"]

    def test_training_emphasis(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        def eval_fn(cases: list[dict[str, object]]) -> dict[str, object]:
            return {
                "mean_score": 0.5,
                "per_dimension": {"d1": 0.3, "d2": 0.8},
            }

        cb = EvalCallback(
            eval_fn=eval_fn,
            eval_cases=[{"prompt": "test"}],
            eval_interval=1,
        )
        cb(episode=0, metrics={})

        emphasis = cb.get_training_emphasis()
        assert emphasis["emphasis"] == "weakness_focused"
        assert "d1" in emphasis["weak_dimensions"]

    def test_summary(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        def eval_fn(cases: list[dict[str, object]]) -> dict[str, object]:
            return {"mean_score": 0.7}

        cb = EvalCallback(
            eval_fn=eval_fn,
            eval_cases=[{"prompt": "test"}],
            eval_interval=1,
        )
        cb(episode=0, metrics={})
        cb(episode=1, metrics={})

        summary = cb.summary()
        assert summary["total_evals"] == 2
        assert summary["latest_score"] == 0.7

    def test_callback_with_curriculum(self) -> None:
        from aegis.training.curriculum import CurriculumEngine
        from aegis.training.eval_callback import EvalCallback

        curriculum = CurriculumEngine()
        curriculum.register_agent("test-agent")

        def eval_fn(cases: list[dict[str, object]]) -> dict[str, object]:
            return {"mean_score": 0.8}

        cb = EvalCallback(
            eval_fn=eval_fn,
            eval_cases=[{"prompt": "test"}],
            eval_interval=1,
            curriculum_engine=curriculum,
            agent_id="test-agent",
        )
        cb(episode=0, metrics={})

        progress = curriculum.get_progress("test-agent")
        assert progress is not None
        assert progress.total_episodes == 1

    def test_eval_fn_failure_handled(self) -> None:
        from aegis.training.eval_callback import EvalCallback

        def failing_eval(cases: list) -> dict:
            raise RuntimeError("eval failed")

        cb = EvalCallback(
            eval_fn=failing_eval,
            eval_cases=[{"prompt": "test"}],
            eval_interval=1,
        )
        result = cb(episode=0, metrics={})
        assert result is None  # Graceful failure


# ---------------------------------------------------------------------------
# CurriculumEngine.update_from_eval
# ---------------------------------------------------------------------------


class TestCurriculumUpdateFromEval:
    def test_update_from_eval_basic(self) -> None:
        from aegis.training.curriculum import CurriculumEngine

        engine = CurriculumEngine()
        engine.register_agent("agent-1")

        result = engine.update_from_eval(
            "agent-1",
            {
                "mean_score": 0.6,
                "per_dimension": {"dim_a": 0.3, "dim_b": 0.9},
            },
        )

        assert result["agent_id"] == "agent-1"
        assert result["mean_score"] == 0.6
        assert "dim_a" in result["weak_dimensions"]
        assert "dim_b" in result["strong_dimensions"]

    def test_update_from_eval_triggers_advancement(self) -> None:
        from aegis.training.curriculum import CurriculumEngine

        engine = CurriculumEngine()
        engine.register_agent("agent-1", start_level=1)

        # Record enough high scores to trigger advancement
        for _ in range(5):
            engine.record_score("agent-1", 0.8)

        result = engine.update_from_eval("agent-1", {"mean_score": 0.9})
        # Should have advanced since we had 5+ high scores and mean >= 0.6
        assert result["current_level"] >= 2

    def test_update_from_eval_recommendations(self) -> None:
        from aegis.training.curriculum import CurriculumEngine

        engine = CurriculumEngine()
        engine.register_agent("agent-1")

        result = engine.update_from_eval(
            "agent-1",
            {
                "mean_score": 0.3,
                "per_dimension": {"d1": 0.2, "d2": 0.1},
            },
        )

        assert len(result["recommendations"]) > 0
        assert any("weak" in r.lower() or "reduce" in r.lower() for r in result["recommendations"])

    def test_update_from_eval_unregistered_agent(self) -> None:
        from aegis.training.curriculum import CurriculumEngine

        engine = CurriculumEngine()
        result = engine.update_from_eval("nonexistent", {"mean_score": 0.5})
        assert "error" in result
