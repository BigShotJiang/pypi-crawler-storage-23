"""Tests for the 12 memory operations with real implementations."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from aegis.core.types import MemoryOperation, MemoryTier, TemporalBounds
from aegis.memory.graph import KnowledgeGraph
from aegis.memory.operations import MemoryPolicyEngine
from aegis.memory.provenance import ProvenanceTracker
from aegis.memory.store import InMemoryStore
from aegis.memory.types import MemoryEntry


@pytest.fixture
def engine() -> MemoryPolicyEngine:
    store = InMemoryStore()
    graph = KnowledgeGraph()
    provenance = ProvenanceTracker()
    return MemoryPolicyEngine(store=store, graph=graph, provenance=provenance)


@pytest.fixture
def engine_with_data(engine: MemoryPolicyEngine) -> MemoryPolicyEngine:
    engine.store("alpha", "Alpha value", MemoryTier.WORKING)
    engine.store("beta", "Beta value", MemoryTier.SESSION)
    return engine


# ---------------------------------------------------------------------------
# TestStore
# ---------------------------------------------------------------------------


class TestStore:
    """STORE operation."""

    def test_store_returns_entry(self, engine: MemoryPolicyEngine) -> None:
        entry = engine.store("k1", "hello", MemoryTier.WORKING)
        assert isinstance(entry, MemoryEntry)
        assert entry.key == "k1"
        assert entry.value == "hello"
        assert entry.tier == MemoryTier.WORKING

    def test_store_retrievable(self, engine: MemoryPolicyEngine) -> None:
        engine.store("k1", "value1")
        retrieved = engine.retrieve("k1")
        assert retrieved is not None
        assert retrieved.value == "value1"


# ---------------------------------------------------------------------------
# TestUpdate
# ---------------------------------------------------------------------------


class TestUpdate:
    """UPDATE operation."""

    def test_update_existing(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.update("alpha", "New Alpha")
        assert result is True
        entry = engine_with_data.retrieve("alpha")
        assert entry is not None
        assert entry.value == "New Alpha"

    def test_update_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        result = engine.update("ghost", "nope")
        assert result is False


# ---------------------------------------------------------------------------
# TestForget
# ---------------------------------------------------------------------------


class TestForget:
    """FORGET operation."""

    def test_forget_existing(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.forget("alpha")
        assert result is True
        assert engine_with_data.retrieve("alpha") is None

    def test_forget_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        result = engine.forget("ghost")
        assert result is False


# ---------------------------------------------------------------------------
# TestRetrieve
# ---------------------------------------------------------------------------


class TestRetrieve:
    """RETRIEVE operation."""

    def test_retrieve_existing(self, engine_with_data: MemoryPolicyEngine) -> None:
        entry = engine_with_data.retrieve("alpha")
        assert entry is not None
        assert entry.key == "alpha"

    def test_retrieve_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        assert engine.retrieve("ghost") is None


# ---------------------------------------------------------------------------
# TestLink
# ---------------------------------------------------------------------------


class TestLink:
    """LINK operation."""

    def test_link_creates_metadata(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.link("alpha", "beta")
        assert result is True
        entry_a = engine_with_data.retrieve("alpha")
        assert entry_a is not None
        assert "links" in entry_a.metadata
        targets = [lnk["target"] for lnk in entry_a.metadata["links"]]
        assert "beta" in targets

    def test_link_creates_kg_edge(self, engine_with_data: MemoryPolicyEngine) -> None:
        engine_with_data.link("alpha", "beta", "causes")
        assert engine_with_data._graph is not None
        assert engine_with_data._graph.has_edge("alpha", "beta", "causes")

    def test_link_nonexistent_entry(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.link("alpha", "ghost")
        assert result is False


# ---------------------------------------------------------------------------
# TestCompress
# ---------------------------------------------------------------------------


class TestCompress:
    """COMPRESS operation."""

    def test_compress_long_text(self, engine: MemoryPolicyEngine) -> None:
        long_text = ". ".join([f"Sentence number {i} with some content" for i in range(10)])
        engine.store("doc", long_text)
        result = engine.compress("doc")
        assert result is True
        entry = engine.retrieve("doc")
        assert entry is not None
        assert entry.metadata.get("compressed") is True
        # Compressed text should be shorter.
        assert len(str(entry.value)) < len(long_text)

    def test_compress_short_text_noop(self, engine: MemoryPolicyEngine) -> None:
        engine.store("short", "Hello world")
        result = engine.compress("short")
        assert result is True
        entry = engine.retrieve("short")
        assert entry is not None
        # Value should be unchanged for short text.
        assert entry.value == "Hello world"
        assert entry.metadata.get("compressed") is True

    def test_compress_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        result = engine.compress("ghost")
        assert result is False

    def test_compress_records_provenance(self, engine: MemoryPolicyEngine) -> None:
        long_text = ". ".join(
            [f"Sentence {i} with long enough padding text here" for i in range(10)]
        )
        engine.store("doc", long_text)
        engine.compress("doc")
        assert engine._provenance is not None
        chain = engine._provenance.chain("doc")
        assert len(chain) >= 1
        ops = [r.operation for r in chain]
        assert MemoryOperation.COMPRESS in ops


# ---------------------------------------------------------------------------
# TestPromote
# ---------------------------------------------------------------------------


class TestPromote:
    """PROMOTE operation."""

    def test_promote_changes_tier(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.promote("alpha", MemoryTier.PERMANENT)
        assert result is True
        entry = engine_with_data.retrieve("alpha")
        assert entry is not None
        assert entry.tier == MemoryTier.PERMANENT

    def test_promote_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        result = engine.promote("ghost", MemoryTier.PERMANENT)
        assert result is False


# ---------------------------------------------------------------------------
# TestDemote
# ---------------------------------------------------------------------------


class TestDemote:
    """DEMOTE operation."""

    def test_demote_changes_tier(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.demote("beta", MemoryTier.WORKING)
        assert result is True
        entry = engine_with_data.retrieve("beta")
        assert entry is not None
        assert entry.tier == MemoryTier.WORKING


# ---------------------------------------------------------------------------
# TestSplit
# ---------------------------------------------------------------------------


class TestSplit:
    """SPLIT operation."""

    def test_split_multi_sentence(self, engine: MemoryPolicyEngine) -> None:
        engine.store("doc", "First sentence. Second sentence. Third sentence")
        parts = engine.split("doc")
        assert len(parts) == 3
        for p in parts:
            assert p.key.startswith("doc_part_")

    def test_split_single_sentence_noop(self, engine: MemoryPolicyEngine) -> None:
        engine.store("single", "Just one sentence")
        parts = engine.split("single")
        assert parts == []

    def test_split_records_provenance(self, engine: MemoryPolicyEngine) -> None:
        engine.store("doc", "Sentence one. Sentence two")
        parts = engine.split("doc")
        assert engine._provenance is not None
        for part in parts:
            chain = engine._provenance.chain(part.key)
            assert len(chain) >= 1
            assert chain[0].operation == MemoryOperation.SPLIT

    def test_split_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        parts = engine.split("ghost")
        assert parts == []


# ---------------------------------------------------------------------------
# TestMerge
# ---------------------------------------------------------------------------


class TestMerge:
    """MERGE operation."""

    def test_merge_combines_values(self, engine_with_data: MemoryPolicyEngine) -> None:
        merged = engine_with_data.merge("alpha", "beta")
        assert merged is not None
        assert "Alpha value" in str(merged.value)
        assert "Beta value" in str(merged.value)

    def test_merge_geometric_confidence(self, engine: MemoryPolicyEngine) -> None:
        e1 = engine.store("a", "value a")
        e2 = engine.store("b", "value b")
        e1.confidence = 0.8
        e2.confidence = 0.5
        merged = engine.merge("a", "b")
        assert merged is not None
        expected = (0.8 * 0.5) ** 0.5
        assert abs(merged.confidence - expected) < 1e-6

    def test_merge_union_tags(self, engine: MemoryPolicyEngine) -> None:
        e1 = engine.store("a", "val a")
        e2 = engine.store("b", "val b")
        e1.tags = ["finance"]
        e2.tags = ["legal"]
        merged = engine.merge("a", "b")
        assert merged is not None
        assert "finance" in merged.tags
        assert "legal" in merged.tags
        assert "merged" in merged.tags

    def test_merge_nonexistent(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.merge("alpha", "ghost")
        assert result is None

    def test_merge_records_provenance(self, engine_with_data: MemoryPolicyEngine) -> None:
        merged = engine_with_data.merge("alpha", "beta")
        assert merged is not None
        assert engine_with_data._provenance is not None
        chain = engine_with_data._provenance.chain(merged.key)
        assert len(chain) >= 1
        assert chain[-1].operation == MemoryOperation.MERGE
        assert "alpha" in chain[-1].parent_keys
        assert "beta" in chain[-1].parent_keys


# ---------------------------------------------------------------------------
# TestVerify
# ---------------------------------------------------------------------------


class TestVerify:
    """VERIFY operation."""

    def test_verify_valid_entry(self, engine: MemoryPolicyEngine) -> None:
        engine.store("k1", "good data")
        # Record provenance so the chain validates.
        assert engine._provenance is not None
        engine._provenance.record("k1", "document", "src", MemoryOperation.STORE)
        result = engine.verify("k1")
        assert result is True

    def test_verify_expired_bounds(self, engine: MemoryPolicyEngine) -> None:
        entry = engine.store("k1", "stale data")
        past = datetime.now(tz=UTC) - timedelta(days=30)
        entry.temporal_bounds = TemporalBounds(
            valid_from=past - timedelta(days=60),
            valid_to=past,
        )
        result = engine.verify("k1")
        assert result is False
        entry_after = engine.retrieve("k1")
        assert entry_after is not None
        assert "expired_temporal_bounds" in entry_after.metadata.get("verification_issues", [])

    def test_verify_low_confidence(self, engine: MemoryPolicyEngine) -> None:
        entry = engine.store("k1", "uncertain")
        entry.confidence = 0.05
        result = engine.verify("k1")
        assert result is False

    def test_verify_nonexistent(self, engine: MemoryPolicyEngine) -> None:
        result = engine.verify("ghost")
        assert result is False


# ---------------------------------------------------------------------------
# TestAnnotate
# ---------------------------------------------------------------------------


class TestAnnotate:
    """ANNOTATE operation."""

    def test_annotate_adds_metadata(self, engine_with_data: MemoryPolicyEngine) -> None:
        result = engine_with_data.annotate("alpha", {"note": "important"})
        assert result is True
        entry = engine_with_data.retrieve("alpha")
        assert entry is not None
        annotations = entry.metadata.get("annotations", [])
        assert any(a.get("note") == "important" for a in annotations)

    def test_annotate_multiple(self, engine_with_data: MemoryPolicyEngine) -> None:
        engine_with_data.annotate("alpha", {"note": "first"})
        engine_with_data.annotate("alpha", {"note": "second"})
        entry = engine_with_data.retrieve("alpha")
        assert entry is not None
        annotations = entry.metadata.get("annotations", [])
        assert len(annotations) == 2


# ---------------------------------------------------------------------------
# TestExecute
# ---------------------------------------------------------------------------


class TestExecute:
    """The execute() dispatch helper."""

    def test_dispatch_all_12_ops(self, engine: MemoryPolicyEngine) -> None:
        """Every MemoryOperation value should be dispatchable without crashing."""
        # Seed two entries so link/merge/verify/annotate/compress/split have targets.
        engine.store("x", "Data for x. Another sentence for x. Third one for x. Fourth. Fifth")
        engine.store("y", "Data for y")

        dispatch_args: dict[MemoryOperation, dict] = {
            MemoryOperation.STORE: {"key": "z", "value": "new", "tier": MemoryTier.WORKING},
            MemoryOperation.UPDATE: {"key": "x", "value": "updated"},
            MemoryOperation.FORGET: {"key": "z"},
            MemoryOperation.RETRIEVE: {"key": "x"},
            MemoryOperation.LINK: {"key_a": "x", "key_b": "y"},
            MemoryOperation.COMPRESS: {"key": "x"},
            MemoryOperation.PROMOTE: {"key": "x", "target_tier": MemoryTier.SESSION},
            MemoryOperation.DEMOTE: {"key": "x", "target_tier": MemoryTier.WORKING},
            MemoryOperation.SPLIT: {"key": "x"},
            MemoryOperation.MERGE: {"key_a": "x", "key_b": "y"},
            MemoryOperation.VERIFY: {"key": "x"},
            MemoryOperation.ANNOTATE: {"key": "x", "annotation": {"note": "ok"}},
        }

        for op, kwargs in dispatch_args.items():
            # Re-store entries that prior ops may have deleted/modified.
            if engine.retrieve("x") is None:
                engine.store("x", "Data for x. Second. Third. Fourth. Fifth")
            if engine.retrieve("y") is None:
                engine.store("y", "Data for y")
            engine.execute(op, **kwargs)  # should not raise

    def test_unknown_op_raises(self, engine: MemoryPolicyEngine) -> None:
        with pytest.raises(ValueError, match="Unknown memory operation"):
            engine.execute("NOT_A_REAL_OP")  # type: ignore[arg-type]
