"""Tests for the Neo4j-backed knowledge graph.

Tests cover the import guard and the API contract against mocked
Neo4j driver calls when a real instance is unavailable.
"""

from __future__ import annotations

import pytest

from aegis.memory.graph import Edge


class TestNeo4jGraphImport:
    """Test import guards and lazy loading."""

    def test_requires_neo4j_driver(self) -> None:
        """Neo4jGraph should raise RuntimeError if neo4j is not installed."""
        from aegis.store import neo4j as neo4j_mod

        original = neo4j_mod._HAS_NEO4J
        neo4j_mod._HAS_NEO4J = False
        try:
            with pytest.raises(RuntimeError, match="neo4j"):
                neo4j_mod.Neo4jGraph(
                    uri="bolt://fake:7687",
                    user="neo4j",
                    password="pass",
                )
        finally:
            neo4j_mod._HAS_NEO4J = original

    def test_lazy_import_from_store_package(self) -> None:
        """Importing Neo4jGraph from aegis.store should not crash."""
        from aegis.store import Neo4jGraph

        assert Neo4jGraph is not None


class TestEdgeModel:
    """Ensure the Edge model used in Neo4j responses is valid."""

    def test_edge_defaults(self) -> None:
        edge = Edge(source="a", target="b", relation="cites")
        assert edge.weight == 1.0
        assert edge.metadata == {}

    def test_edge_custom_weight(self) -> None:
        edge = Edge(source="a", target="b", relation="cites", weight=0.5)
        assert edge.weight == 0.5
