"""Tests for multi-provider LLM backends, retry logic, and provider detection."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import httpx
import pytest

from aegis.eval.scorers.llm_backend import (
    AggregateUsageStats,
    AnthropicLLMBackend,
    HTTPLLMBackend,
    MockLLMBackend,
    UsageStats,
    _estimate_cost,
    _retry_with_backoff,
    _validate_anthropic_response,
    _validate_openai_response,
)
from aegis.eval.scorers.llm_judge import LLMJudgeScorer, _detect_provider

# ---------------------------------------------------------------------------
# TestUsageStats
# ---------------------------------------------------------------------------


class TestUsageStats:
    """Verify UsageStats and AggregateUsageStats dataclasses."""

    def test_defaults(self) -> None:
        stats = UsageStats()
        assert stats.prompt_tokens == 0
        assert stats.completion_tokens == 0
        assert stats.total_tokens == 0
        assert stats.estimated_cost_usd == 0.0
        assert stats.latency_seconds == 0.0
        assert stats.model == ""

    def test_aggregate_add(self) -> None:
        agg = AggregateUsageStats()
        s1 = UsageStats(
            prompt_tokens=100,
            completion_tokens=50,
            total_tokens=150,
            estimated_cost_usd=0.001,
            latency_seconds=0.5,
            model="gpt-4o",
        )
        s2 = UsageStats(
            prompt_tokens=200,
            completion_tokens=80,
            total_tokens=280,
            estimated_cost_usd=0.002,
            latency_seconds=0.3,
            model="gpt-4o",
        )
        agg.add(s1)
        agg.add(s2)

        assert agg.prompt_tokens == 300
        assert agg.completion_tokens == 130
        assert agg.total_tokens == 430
        assert agg.estimated_cost_usd == pytest.approx(0.003)
        assert agg.total_latency_seconds == pytest.approx(0.8)
        assert agg.call_count == 2
        assert len(agg.calls) == 2


# ---------------------------------------------------------------------------
# TestCostEstimation
# ---------------------------------------------------------------------------


class TestCostEstimation:
    """Verify _estimate_cost for known models and unknown models."""

    def test_gpt_4o_cost(self) -> None:
        from aegis.eval.scorers.llm_backend import _OPENAI_PRICING

        cost = _estimate_cost("gpt-4o", 1_000_000, 1_000_000, _OPENAI_PRICING)
        # input: $2.50 + output: $10.00 = $12.50
        assert cost == pytest.approx(12.50)

    def test_gpt_4o_mini_cost(self) -> None:
        from aegis.eval.scorers.llm_backend import _OPENAI_PRICING

        cost = _estimate_cost("gpt-4o-mini", 1_000_000, 1_000_000, _OPENAI_PRICING)
        assert cost == pytest.approx(0.75)

    def test_claude_sonnet_cost(self) -> None:
        from aegis.eval.scorers.llm_backend import _ANTHROPIC_PRICING

        cost = _estimate_cost(
            "claude-3.5-sonnet-20241022", 1_000_000, 1_000_000, _ANTHROPIC_PRICING
        )
        assert cost == pytest.approx(18.00)

    def test_claude_haiku_cost(self) -> None:
        from aegis.eval.scorers.llm_backend import _ANTHROPIC_PRICING

        cost = _estimate_cost("claude-3-haiku-20240307", 1_000_000, 1_000_000, _ANTHROPIC_PRICING)
        assert cost == pytest.approx(1.50)

    def test_unknown_model_zero_cost(self) -> None:
        from aegis.eval.scorers.llm_backend import _OPENAI_PRICING

        cost = _estimate_cost("llama-3-70b", 1_000_000, 1_000_000, _OPENAI_PRICING)
        assert cost == 0.0


# ---------------------------------------------------------------------------
# TestResponseValidation
# ---------------------------------------------------------------------------


class TestResponseValidation:
    """Verify _validate_openai_response and _validate_anthropic_response."""

    def test_valid_openai_response(self) -> None:
        data = {"choices": [{"message": {"content": "hello"}}]}
        assert _validate_openai_response(data) == "hello"

    def test_openai_missing_choices(self) -> None:
        with pytest.raises(ValueError, match="choices"):
            _validate_openai_response({})

    def test_openai_empty_choices(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            _validate_openai_response({"choices": []})

    def test_openai_missing_message_content(self) -> None:
        with pytest.raises(ValueError, match="message.content"):
            _validate_openai_response({"choices": [{"message": {}}]})

    def test_openai_not_dict(self) -> None:
        with pytest.raises(ValueError, match="Expected dict"):
            _validate_openai_response("not a dict")

    def test_valid_anthropic_response(self) -> None:
        data = {"content": [{"text": "world"}]}
        assert _validate_anthropic_response(data) == "world"

    def test_anthropic_missing_content(self) -> None:
        with pytest.raises(ValueError, match="content"):
            _validate_anthropic_response({})

    def test_anthropic_empty_content(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            _validate_anthropic_response({"content": []})

    def test_anthropic_missing_text(self) -> None:
        with pytest.raises(ValueError, match="text"):
            _validate_anthropic_response({"content": [{"type": "image"}]})

    def test_anthropic_not_dict(self) -> None:
        with pytest.raises(ValueError, match="Expected dict"):
            _validate_anthropic_response([1, 2, 3])


# ---------------------------------------------------------------------------
# TestAnthropicLLMBackend
# ---------------------------------------------------------------------------


def _mock_httpx_client(mock_response: MagicMock) -> MagicMock:
    """Create a properly configured mock httpx.Client context manager."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.return_value = mock_response
    return mock_client


class TestAnthropicLLMBackend:
    """Verify Anthropic backend builds the right request and parses the response."""

    def test_headers_and_endpoint(self) -> None:
        backend = AnthropicLLMBackend(api_key="sk-ant-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "content": [{"text": '{"score": 0.85, "reasoning": "Good."}'}],
            "usage": {"input_tokens": 100, "output_tokens": 30},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            result = backend.complete("test prompt", "claude-sonnet-4-5-20250929", 0.0)

            # Verify endpoint
            call_args = mock_client.post.call_args
            assert call_args[0][0] == "https://api.anthropic.com/v1/messages"

            # Verify headers
            headers = call_args[1]["headers"]
            assert headers["x-api-key"] == "sk-ant-test"
            assert headers["anthropic-version"] == "2023-06-01"

            # Verify body
            body = call_args[1]["json"]
            assert body["model"] == "claude-sonnet-4-5-20250929"
            assert body["max_tokens"] == 1024
            assert body["messages"] == [{"role": "user", "content": "test prompt"}]

        assert result == '{"score": 0.85, "reasoning": "Good."}'

    def test_response_parsing(self) -> None:
        backend = AnthropicLLMBackend(api_key="sk-ant-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "content": [{"text": "Hello, world!"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            result = backend.complete("prompt", "claude-sonnet-4-5-20250929", 0.5)

        assert result == "Hello, world!"

    def test_custom_base_url(self) -> None:
        backend = AnthropicLLMBackend(
            api_key="sk-ant-test",
            base_url="https://custom.api.example.com/",
        )
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "content": [{"text": "ok"}],
            "usage": {"input_tokens": 5, "output_tokens": 2},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            backend.complete("prompt", "claude-sonnet-4-5-20250929", 0.0)

            call_args = mock_client.post.call_args
            assert call_args[0][0] == "https://custom.api.example.com/v1/messages"

    def test_usage_tracking(self) -> None:
        """Anthropic backend records token usage from the response."""
        backend = AnthropicLLMBackend(api_key="sk-ant-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "content": [{"text": '{"score": 0.9}'}],
            "usage": {"input_tokens": 150, "output_tokens": 40},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            backend.complete("prompt", "claude-3.5-sonnet-20241022", 0.0)

        assert backend.last_usage is not None
        assert backend.last_usage.prompt_tokens == 150
        assert backend.last_usage.completion_tokens == 40
        assert backend.last_usage.total_tokens == 190
        assert backend.last_usage.model == "claude-3.5-sonnet-20241022"
        assert backend.last_usage.latency_seconds > 0.0
        # Cost: 150 * $3/1M + 40 * $15/1M = $0.00045 + $0.0006 = $0.00105
        assert backend.last_usage.estimated_cost_usd == pytest.approx(0.00105, abs=1e-8)

        # Also check total_usage
        assert backend.total_usage.call_count == 1
        assert backend.total_usage.prompt_tokens == 150

    def test_usage_accumulates_across_calls(self) -> None:
        """Multiple calls accumulate in total_usage."""
        backend = AnthropicLLMBackend(api_key="sk-ant-test")

        for input_tokens in (100, 200):
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "content": [{"text": "ok"}],
                "usage": {"input_tokens": input_tokens, "output_tokens": 10},
            }
            mock_response.raise_for_status = MagicMock()

            with patch("httpx.Client") as mock_client_cls:
                mock_client_cls.return_value = _mock_httpx_client(mock_response)
                mock_client = mock_client_cls.return_value.__enter__()
                mock_client.post.return_value = mock_response

                backend.complete("prompt", "claude-3-haiku-20240307", 0.0)

        assert backend.total_usage.call_count == 2
        assert backend.total_usage.prompt_tokens == 300
        assert backend.total_usage.completion_tokens == 20

    def test_invalid_response_structure_raises(self) -> None:
        """Missing 'content' field in Anthropic response raises ValueError."""
        backend = AnthropicLLMBackend(api_key="sk-ant-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"error": "bad response"}
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            with pytest.raises(ValueError, match="content"):
                backend.complete("prompt", "claude-sonnet-4-5-20250929", 0.0)


# ---------------------------------------------------------------------------
# TestHTTPLLMBackend
# ---------------------------------------------------------------------------


class TestHTTPLLMBackend:
    """Verify OpenAI-compatible backend request structure and usage tracking."""

    def test_headers_and_endpoint(self) -> None:
        backend = HTTPLLMBackend(api_key="sk-test-123")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": '{"score": 0.7}'}}],
            "usage": {"prompt_tokens": 50, "completion_tokens": 20, "total_tokens": 70},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            result = backend.complete("test prompt", "gpt-4o", 0.0)

            call_args = mock_client.post.call_args
            assert call_args[0][0] == "https://api.openai.com/v1/chat/completions"
            headers = call_args[1]["headers"]
            assert headers["Authorization"] == "Bearer sk-test-123"

        assert result == '{"score": 0.7}'

    def test_usage_tracking(self) -> None:
        """OpenAI backend records token usage from the response."""
        backend = HTTPLLMBackend(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "answer"}}],
            "usage": {"prompt_tokens": 200, "completion_tokens": 60, "total_tokens": 260},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            backend.complete("prompt", "gpt-4o", 0.0)

        assert backend.last_usage is not None
        assert backend.last_usage.prompt_tokens == 200
        assert backend.last_usage.completion_tokens == 60
        assert backend.last_usage.total_tokens == 260
        assert backend.last_usage.model == "gpt-4o"
        assert backend.last_usage.latency_seconds > 0.0
        # Cost: 200 * $2.50/1M + 60 * $10/1M = $0.0005 + $0.0006 = $0.0011
        assert backend.last_usage.estimated_cost_usd == pytest.approx(0.0011, abs=1e-8)

    def test_usage_without_usage_field(self) -> None:
        """Backend handles responses that omit the 'usage' field gracefully."""
        backend = HTTPLLMBackend(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "answer"}}],
            # no "usage" field
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            result = backend.complete("prompt", "gpt-4o", 0.0)

        assert result == "answer"
        assert backend.last_usage is not None
        assert backend.last_usage.prompt_tokens == 0
        assert backend.last_usage.total_tokens == 0

    def test_usage_accumulates_across_calls(self) -> None:
        """Multiple calls accumulate in total_usage."""
        backend = HTTPLLMBackend(api_key="sk-test")

        for prompt_tokens in (100, 200):
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "choices": [{"message": {"content": "ok"}}],
                "usage": {
                    "prompt_tokens": prompt_tokens,
                    "completion_tokens": 10,
                    "total_tokens": prompt_tokens + 10,
                },
            }
            mock_response.raise_for_status = MagicMock()

            with patch("httpx.Client") as mock_client_cls:
                mock_client_cls.return_value = _mock_httpx_client(mock_response)
                mock_client = mock_client_cls.return_value.__enter__()
                mock_client.post.return_value = mock_response

                backend.complete("prompt", "gpt-4o-mini", 0.0)

        assert backend.total_usage.call_count == 2
        assert backend.total_usage.prompt_tokens == 300
        assert backend.total_usage.completion_tokens == 20
        assert backend.total_usage.total_tokens == 320

    def test_invalid_response_structure_raises(self) -> None:
        """Missing 'choices' field in OpenAI response raises ValueError."""
        backend = HTTPLLMBackend(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"error": "something wrong"}
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.Client") as mock_client_cls:
            mock_client_cls.return_value = _mock_httpx_client(mock_response)
            mock_client = mock_client_cls.return_value.__enter__()
            mock_client.post.return_value = mock_response

            with pytest.raises(ValueError, match="choices"):
                backend.complete("prompt", "gpt-4o", 0.0)


# ---------------------------------------------------------------------------
# TestMockLLMBackend
# ---------------------------------------------------------------------------


class TestMockLLMBackend:
    """Verify MockLLMBackend base-class properties."""

    def test_last_usage_is_none(self) -> None:
        """Mock backend never records usage — last_usage stays None."""
        backend = MockLLMBackend()
        assert backend.last_usage is None

    def test_total_usage_is_empty(self) -> None:
        """Mock backend total_usage has zero calls."""
        backend = MockLLMBackend()
        backend.complete(
            "## Agent Output\nhello\n## Expected Answer\nhello",
            "mock",
            0.0,
        )
        assert backend.total_usage.call_count == 0


# ---------------------------------------------------------------------------
# TestRetryLogic
# ---------------------------------------------------------------------------


class TestRetryLogic:
    """Verify retry behavior on transient failures."""

    def test_success_first_try(self) -> None:
        fn = MagicMock(return_value="ok")
        result = _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert result == "ok"
        assert fn.call_count == 1

    def test_retry_on_429(self) -> None:
        response_429 = MagicMock()
        response_429.status_code = 429
        exc = httpx.HTTPStatusError("rate limit", request=MagicMock(), response=response_429)

        fn = MagicMock(side_effect=[exc, "recovered"])
        result = _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert result == "recovered"
        assert fn.call_count == 2

    def test_retry_on_503(self) -> None:
        response_503 = MagicMock()
        response_503.status_code = 503
        exc = httpx.HTTPStatusError("unavailable", request=MagicMock(), response=response_503)

        fn = MagicMock(side_effect=[exc, "back"])
        result = _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert result == "back"
        assert fn.call_count == 2

    def test_no_retry_on_400(self) -> None:
        response_400 = MagicMock()
        response_400.status_code = 400
        exc = httpx.HTTPStatusError("bad request", request=MagicMock(), response=response_400)

        fn = MagicMock(side_effect=exc)
        with pytest.raises(httpx.HTTPStatusError):
            _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert fn.call_count == 1

    def test_exhaust_retries(self) -> None:
        response_500 = MagicMock()
        response_500.status_code = 500
        exc = httpx.HTTPStatusError("error", request=MagicMock(), response=response_500)

        fn = MagicMock(side_effect=exc)
        with pytest.raises(httpx.HTTPStatusError):
            _retry_with_backoff(fn, max_retries=2, base_delay=0.0)
        # 1 initial + 2 retries = 3 total
        assert fn.call_count == 3

    def test_retry_on_connect_error(self) -> None:
        exc = httpx.ConnectError("connection refused")
        fn = MagicMock(side_effect=[exc, "connected"])
        result = _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert result == "connected"
        assert fn.call_count == 2

    def test_retry_on_read_timeout(self) -> None:
        exc = httpx.ReadTimeout("timed out")
        fn = MagicMock(side_effect=[exc, "done"])
        result = _retry_with_backoff(fn, max_retries=3, base_delay=0.0)
        assert result == "done"
        assert fn.call_count == 2


# ---------------------------------------------------------------------------
# TestProviderDetection
# ---------------------------------------------------------------------------


class TestProviderDetection:
    """Verify _detect_provider maps model names correctly."""

    @pytest.mark.parametrize(
        ("model", "expected"),
        [
            ("gpt-4o", "openai"),
            ("gpt-3.5-turbo", "openai"),
            ("GPT-4o-mini", "openai"),
            ("o1-preview", "openai"),
            ("o3-mini", "openai"),
            ("o4-mini", "openai"),
            ("claude-3-opus-20240229", "anthropic"),
            ("claude-sonnet-4-5-20250929", "anthropic"),
            ("Claude-3-haiku-20240307", "anthropic"),
            ("llama-3-70b", "unknown"),
            ("mistral-large", "unknown"),
            ("", "unknown"),
        ],
    )
    def test_detect_provider(self, model: str, expected: str) -> None:
        assert _detect_provider(model) == expected


# ---------------------------------------------------------------------------
# TestMultiProviderSelection
# ---------------------------------------------------------------------------


class TestMultiProviderSelection:
    """Verify _get_default_backend picks the right backend for each env config."""

    def _clean_env(self) -> dict[str, str]:
        """Return a clear env dict with all AEGIS_* vars removed."""
        return {k: v for k, v in os.environ.items() if not k.startswith("AEGIS_")}

    def test_backward_compat_generic_key(self) -> None:
        """AEGIS_LLM_API_KEY with default gpt-4o model -> HTTPLLMBackend."""
        env = {**self._clean_env(), "AEGIS_LLM_API_KEY": "sk-test"}
        with patch.dict(os.environ, env, clear=True):
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, HTTPLLMBackend)

    def test_anthropic_key_with_claude_model(self) -> None:
        """AEGIS_ANTHROPIC_API_KEY + claude model -> AnthropicLLMBackend."""
        env = {**self._clean_env(), "AEGIS_ANTHROPIC_API_KEY": "sk-ant-test"}
        with patch.dict(os.environ, env, clear=True):
            scorer = LLMJudgeScorer(model="claude-sonnet-4-5-20250929")
            backend = scorer._get_default_backend()
            assert isinstance(backend, AnthropicLLMBackend)

    def test_explicit_provider_override(self) -> None:
        """AEGIS_LLM_PROVIDER=anthropic overrides model name detection."""
        env = {
            **self._clean_env(),
            "AEGIS_LLM_PROVIDER": "anthropic",
            "AEGIS_ANTHROPIC_API_KEY": "sk-ant-test",
        }
        with patch.dict(os.environ, env, clear=True):
            scorer = LLMJudgeScorer(model="gpt-4o")  # model says openai
            backend = scorer._get_default_backend()
            assert isinstance(backend, AnthropicLLMBackend)

    def test_mock_override(self) -> None:
        """AEGIS_LLM_PROVIDER=mock forces MockLLMBackend even with keys."""
        env = {
            **self._clean_env(),
            "AEGIS_LLM_PROVIDER": "mock",
            "AEGIS_LLM_API_KEY": "sk-test",
        }
        with patch.dict(os.environ, env, clear=True):
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, MockLLMBackend)

    def test_model_env_override(self) -> None:
        """AEGIS_LLM_MODEL overrides constructor model."""
        env = {
            **self._clean_env(),
            "AEGIS_LLM_MODEL": "claude-sonnet-4-5-20250929",
            "AEGIS_ANTHROPIC_API_KEY": "sk-ant-test",
        }
        with patch.dict(os.environ, env, clear=True):
            scorer = LLMJudgeScorer(model="gpt-4o")
            backend = scorer._get_default_backend()
            assert isinstance(backend, AnthropicLLMBackend)
            assert scorer.model == "claude-sonnet-4-5-20250929"

    def test_no_keys_returns_mock(self) -> None:
        """No API keys set -> MockLLMBackend."""
        env = self._clean_env()
        with patch.dict(os.environ, env, clear=True):
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, MockLLMBackend)

    def test_generic_key_with_claude_model(self) -> None:
        """AEGIS_LLM_API_KEY with claude model -> AnthropicLLMBackend."""
        env = {**self._clean_env(), "AEGIS_LLM_API_KEY": "sk-ant-test"}
        with patch.dict(os.environ, env, clear=True):
            scorer = LLMJudgeScorer(model="claude-3-opus-20240229")
            backend = scorer._get_default_backend()
            assert isinstance(backend, AnthropicLLMBackend)

    def test_openai_specific_key(self) -> None:
        """AEGIS_OPENAI_API_KEY takes priority over AEGIS_LLM_API_KEY."""
        env = {
            **self._clean_env(),
            "AEGIS_OPENAI_API_KEY": "sk-openai",
            "AEGIS_LLM_API_KEY": "sk-generic",
        }
        with patch.dict(os.environ, env, clear=True):
            backend = LLMJudgeScorer()._get_default_backend()
            assert isinstance(backend, HTTPLLMBackend)


# ---------------------------------------------------------------------------
# TestLLMJudgeScorerUsage
# ---------------------------------------------------------------------------


class TestLLMJudgeScorerUsage:
    """Verify LLMJudgeScorer exposes usage_stats from its backend."""

    def test_usage_stats_none_without_backend(self) -> None:
        """usage_stats is None when no backend has been set."""
        scorer = LLMJudgeScorer()
        assert scorer.usage_stats is None

    def test_usage_stats_exposed_after_score(self) -> None:
        """usage_stats returns backend total_usage after a score() call."""
        backend = MockLLMBackend()
        scorer = LLMJudgeScorer(backend=backend)
        assert scorer.usage_stats is not None
        assert scorer.usage_stats.call_count == 0

    def test_parse_score_logs_warning_on_failure(self, caplog: pytest.LogCaptureFixture) -> None:
        """_parse_score logs a warning when both JSON and regex fail."""
        import logging

        with caplog.at_level(logging.WARNING, logger="aegis.eval.scorers.llm_judge"):
            score = LLMJudgeScorer._parse_score("totally unparseable garbage")

        assert score == 0.0
        assert "Failed to parse score" in caplog.text
        assert "totally unparseable garbage" in caplog.text
