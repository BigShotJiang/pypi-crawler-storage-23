"""Tests for cloud launcher, experiment tracking, and HF upload helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

import aegis.training.cloud_launcher as cloud_mod
import aegis.training.tracking as tracking_mod
from aegis.training.cloud_launcher import AWSLauncher, AWSLauncherConfig
from aegis.training.hf_upload import HFUploader
from aegis.training.tracking import ExperimentTracker


def test_aws_launcher_dry_run_launch_status_stop_and_download(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(cloud_mod, "_HAS_BOTO3", False)
    monkeypatch.setattr(cloud_mod, "_HAS_SAGEMAKER", False)

    launcher = AWSLauncher(config=AWSLauncherConfig(role_arn="", s3_bucket="bucket-a"))
    launched = launcher.launch({"model_name": "Qwen/Qwen2.5-7B", "domain": "legal"})

    assert launched["status"] == "dry_run"
    assert "boto3 not installed" in launched["dry_run_reason"]
    job_id = str(launched["job_id"])

    status = launcher.status(job_id)
    assert status["status"] == "dry_run"
    assert status["cached"] is True

    stopped = launcher.stop(job_id)
    assert stopped["status"] == "dry_run_stopped"

    downloaded = launcher.download_artifacts(job_id, dest="./tmp-download")
    assert downloaded["status"] == "dry_run"
    assert str(downloaded["s3_prefix"]).startswith("s3://bucket-a/")


def test_experiment_tracker_local_jsonl_fallback(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("WANDB_API_KEY", "")
    monkeypatch.setattr(tracking_mod, "_HAS_WANDB", False)
    monkeypatch.setattr(tracking_mod, "wandb", None)

    tracker = ExperimentTracker(
        project="aegis-tests",
        run_name="unit-run",
        config={"lr": 1e-5},
        enabled=True,
    )
    assert tracker.is_wandb is False
    assert tracker.local_path is not None

    tracker.log_metrics(step=1, metrics={"loss": 0.42})
    tracker.log_artifact(name="ckpt", path=str(tmp_path / "artifact.bin"), artifact_type="model")
    tracker.log_table(name="scores", columns=["dim", "score"], data=[["retention", 0.9]])
    tracker.finish()

    assert tracker.local_path is not None
    lines = tracker.local_path.read_text(encoding="utf-8").strip().splitlines()
    records = [json.loads(line) for line in lines]
    assert records[0]["type"] == "init"
    assert any(record["type"] == "metrics" for record in records)
    assert any(record["type"] == "artifact" for record in records)
    assert any(record["type"] == "table" for record in records)
    assert records[-1]["type"] == "finish"


class _FakeHFAPI:
    def __init__(self) -> None:
        self.create_calls: list[dict[str, Any]] = []
        self.upload_calls: list[dict[str, Any]] = []

    def create_repo(self, **kwargs: Any) -> None:
        self.create_calls.append(kwargs)

    def upload_folder(self, **kwargs: Any) -> str:
        self.upload_calls.append(kwargs)
        repo_type = kwargs.get("repo_type", "model")
        repo_id = kwargs.get("repo_id", "org/repo")
        base = "https://huggingface.co"
        if repo_type == "dataset":
            base = "https://huggingface.co/datasets"
        return f"{base}/{repo_id}"


def test_hf_uploader_upload_model_and_dataset(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "adapter_model.safetensors").write_text("weights", encoding="utf-8")

    dataset_dir = tmp_path / "dataset"
    dataset_dir.mkdir()
    (dataset_dir / "data.jsonl").write_text('{"x": 1}\n', encoding="utf-8")

    uploader = HFUploader(token="hf_test")
    fake_api = _FakeHFAPI()
    monkeypatch.setattr(uploader, "_get_api", lambda: fake_api)

    model_url = uploader.upload_model(
        local_path=model_dir,
        repo_id="metronis/aegis-legal-v1",
        model_card_data={
            "repo_id": "metronis/aegis-legal-v1",
            "base_model": "Qwen/Qwen2.5-7B",
            "description": "Legal adapter.",
        },
        private=True,
    )
    assert model_url == "https://huggingface.co/metronis/aegis-legal-v1"
    assert (model_dir / "README.md").exists()
    assert fake_api.create_calls[0]["repo_type"] == "model"

    dataset_url = uploader.upload_dataset(
        local_path=dataset_dir,
        repo_id="metronis/aegis-legal-bench",
        dataset_card_data={
            "repo_id": "metronis/aegis-legal-bench",
            "description": "Legal benchmark dataset.",
        },
        private=False,
    )
    assert dataset_url == "https://huggingface.co/datasets/metronis/aegis-legal-bench"
    assert (dataset_dir / "README.md").exists()
    assert fake_api.create_calls[1]["repo_type"] == "dataset"
    assert len(fake_api.upload_calls) == 2


def test_hf_uploader_missing_path_raises() -> None:
    uploader = HFUploader(token="hf_test")
    with pytest.raises(FileNotFoundError):
        uploader.upload_model(local_path="/tmp/does-not-exist-aegis-model", repo_id="org/repo")
    with pytest.raises(FileNotFoundError):
        uploader.upload_dataset(local_path="/tmp/does-not-exist-aegis-data", repo_id="org/repo")
