"""Tests for the governance engine.

Covers all 5 rule types (deny_keywords, require_keywords, max_length,
regex_deny, allow_actions), severity scaling, audit log, and provenance
chain.
"""

from __future__ import annotations

from datetime import UTC, datetime

from aegis.security.governance import GovernanceEngine, check_soc2_audit_logging

# ---------------------------------------------------------------------------
# Policy check tests
# ---------------------------------------------------------------------------


class TestGovernancePolicyChecks:
    """Verify all policy rule types."""

    def test_deny_keywords_blocks_action(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "no-delete",
                    "rules": [{"type": "deny_keywords", "keywords": ["delete", "drop"]}],
                }
            ]
        )
        results = engine.check_policy("Please delete the database")
        assert len(results) == 1
        assert not results[0].passed
        assert any("delete" in v.lower() for v in results[0].violations)

    def test_deny_keywords_case_insensitive(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "no-delete",
                    "rules": [{"type": "deny_keywords", "keywords": ["DELETE"]}],
                }
            ]
        )
        results = engine.check_policy("delete this record")
        assert not results[0].passed

    def test_deny_keywords_passes_clean_action(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "no-delete",
                    "rules": [{"type": "deny_keywords", "keywords": ["delete", "drop"]}],
                }
            ]
        )
        results = engine.check_policy("read the document")
        assert results[0].passed
        assert results[0].severity == "none"

    def test_require_keywords_passes_when_present(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "must-approve",
                    "rules": [{"type": "require_keywords", "keywords": ["approved", "authorized"]}],
                }
            ]
        )
        results = engine.check_policy("This action is approved by management")
        assert results[0].passed

    def test_require_keywords_fails_when_absent(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "must-approve",
                    "rules": [{"type": "require_keywords", "keywords": ["approved", "authorized"]}],
                }
            ]
        )
        results = engine.check_policy("Execute the task now")
        assert not results[0].passed

    def test_max_length_passes_short_action(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "length-limit",
                    "rules": [{"type": "max_length", "max": 100}],
                }
            ]
        )
        results = engine.check_policy("short action")
        assert results[0].passed

    def test_max_length_fails_long_action(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "length-limit",
                    "rules": [{"type": "max_length", "max": 10}],
                }
            ]
        )
        results = engine.check_policy("this action is way too long")
        assert not results[0].passed
        assert any("exceeds" in v for v in results[0].violations)

    def test_regex_deny_blocks_matching_pattern(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "no-sql-injection",
                    "rules": [{"type": "regex_deny", "pattern": r"DROP\s+TABLE"}],
                }
            ]
        )
        results = engine.check_policy("DROP TABLE users")
        assert not results[0].passed

    def test_regex_deny_passes_non_matching(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "no-sql-injection",
                    "rules": [{"type": "regex_deny", "pattern": r"DROP\s+TABLE"}],
                }
            ]
        )
        results = engine.check_policy("SELECT * FROM users")
        assert results[0].passed

    def test_invalid_regex_deny_is_reported_as_violation(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "bad-regex",
                    "rules": [{"type": "regex_deny", "pattern": "("}],
                }
            ]
        )
        results = engine.check_policy("safe action")
        assert not results[0].passed
        assert any("Invalid denied regex pattern" in v for v in results[0].violations)

    def test_allow_actions_passes_allowed_type(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "action-whitelist",
                    "rules": [{"type": "allow_actions", "actions": ["read", "list"]}],
                }
            ]
        )
        results = engine.check_policy("fetch records", {"action_type": "read"})
        assert results[0].passed

    def test_allow_actions_fails_disallowed_type(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "action-whitelist",
                    "rules": [{"type": "allow_actions", "actions": ["read", "list"]}],
                }
            ]
        )
        results = engine.check_policy("remove item", {"action_type": "delete"})
        assert not results[0].passed

    def test_no_policies_returns_empty(self) -> None:
        engine = GovernanceEngine()
        results = engine.check_policy("anything")
        assert results == []

    def test_multiple_policies_checked(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "policy-a",
                    "rules": [{"type": "deny_keywords", "keywords": ["bad"]}],
                },
                {
                    "id": "policy-b",
                    "rules": [{"type": "max_length", "max": 1000}],
                },
            ]
        )
        results = engine.check_policy("do something bad")
        assert len(results) == 2
        assert not results[0].passed  # policy-a fails
        assert results[1].passed  # policy-b passes


# ---------------------------------------------------------------------------
# Severity scaling tests
# ---------------------------------------------------------------------------


class TestGovernanceSeverity:
    """Verify severity scales with violation count."""

    def test_zero_violations_severity_none(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "clean",
                    "rules": [{"type": "deny_keywords", "keywords": ["bad"]}],
                }
            ]
        )
        results = engine.check_policy("clean action")
        assert results[0].severity == "none"

    def test_one_violation_severity_low(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "one-rule",
                    "rules": [{"type": "deny_keywords", "keywords": ["bad"]}],
                }
            ]
        )
        results = engine.check_policy("bad action")
        assert results[0].severity == "low"

    def test_two_violations_severity_medium(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "two-rules",
                    "rules": [
                        {"type": "deny_keywords", "keywords": ["bad", "evil"]},
                    ],
                }
            ]
        )
        results = engine.check_policy("bad evil action")
        assert results[0].severity == "medium"

    def test_three_violations_severity_high(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {
                    "id": "multi",
                    "rules": [
                        {"type": "deny_keywords", "keywords": ["bad", "evil", "harmful"]},
                    ],
                }
            ]
        )
        results = engine.check_policy("bad evil harmful action")
        assert results[0].severity == "high"


class TestGovernanceCompliance:
    """Verify SOC2-style governance checks and enforced auditing."""

    def test_soc2_audit_logging_requires_datetime_timestamp(self) -> None:
        result = check_soc2_audit_logging(
            {
                "timestamp": "2026-02-23T00:00:00Z",
                "actor": "agent-1",
                "action": "eval.run",
                "resource": "run-1",
                "outcome": "allowed",
                "metadata": {"request_id": "req-123"},
            }
        )
        assert result.passed is False
        assert any("timestamp" in violation.lower() for violation in result.violations)

    def test_soc2_audit_logging_passes_for_traceable_entry(self) -> None:
        result = check_soc2_audit_logging(
            {
                "timestamp": datetime.now(tz=UTC),
                "actor": "agent-1",
                "action": "eval.run",
                "resource": "run-1",
                "outcome": "allowed",
                "metadata": {"request_id": "req-123"},
            }
        )
        assert result.passed is True

    def test_soc2_audit_logging_fails_missing_required_fields(self) -> None:
        result = check_soc2_audit_logging(
            {
                "metadata": {},
            }
        )
        assert result.passed is False
        assert any("Missing required audit field" in violation for violation in result.violations)
        assert any("trace identifier" in violation for violation in result.violations)

    def test_check_compliance_surfaces_residency_mismatch(self) -> None:
        engine = GovernanceEngine()
        results = engine.check_compliance(
            framework="soc2",
            context={
                "audit_event": {
                    "timestamp": datetime.now(tz=UTC),
                    "actor": "agent-1",
                    "action": "retrieve",
                    "resource": "doc-42",
                    "outcome": "allowed",
                    "metadata": {"trace_id": "trace-abc"},
                },
                "data": {"region": "us-east-1"},
                "expected_region": "eu-west-1",
            },
        )
        assert any(result.policy_id == "soc2-audit-logging" and result.passed for result in results)
        assert any(result.policy_id == "data-residency" and not result.passed for result in results)

    def test_enforce_action_denies_on_policy_violation_and_records_audit(self) -> None:
        engine = GovernanceEngine(
            policies=[
                {"id": "deny-delete", "rules": [{"type": "deny_keywords", "keywords": ["delete"]}]}
            ]
        )
        allowed, checks, audit = engine.enforce_action(
            actor="agent-1",
            action="delete record",
            resource="doc-1",
            context={
                "request_id": "req-xyz",
            },
        )
        assert allowed is False
        assert any(not check.passed for check in checks)
        assert audit.outcome == "denied"
        assert audit.policy_checks
        assert audit.metadata.get("request_id") == "req-xyz"


# ---------------------------------------------------------------------------
# Audit log and provenance tests
# ---------------------------------------------------------------------------


class TestGovernanceAuditLog:
    """Verify audit log recording and retrieval."""

    def test_audit_log_records_entry(self) -> None:
        engine = GovernanceEngine()
        entry = engine.audit_log("agent-1", "read", "document-42")
        assert entry.actor == "agent-1"
        assert entry.action == "read"
        assert entry.resource == "document-42"
        assert entry.outcome == "allowed"

    def test_audit_log_denied_outcome(self) -> None:
        engine = GovernanceEngine()
        entry = engine.audit_log("agent-1", "delete", "table-x", outcome="denied")
        assert entry.outcome == "denied"

    def test_get_audit_log_returns_all(self) -> None:
        engine = GovernanceEngine()
        engine.audit_log("a", "read", "r1")
        engine.audit_log("b", "write", "r2")
        log = engine.get_audit_log()
        assert len(log) == 2

    def test_audit_log_isolation(self) -> None:
        """Returned list is a copy."""
        engine = GovernanceEngine()
        engine.audit_log("a", "read", "r1")
        log = engine.get_audit_log()
        log.clear()
        assert len(engine.get_audit_log()) == 1


class TestGovernanceProvenance:
    """Verify provenance chain recording."""

    def test_provenance_chain_adds_node(self) -> None:
        engine = GovernanceEngine()
        node = engine.provenance_chain("n1", "document.pdf", "extracted text")
        assert node.node_id == "n1"
        assert node.source == "document.pdf"
        assert node.transformation == "extracted text"

    def test_provenance_chain_with_parents(self) -> None:
        engine = GovernanceEngine()
        engine.provenance_chain("n1", "source-a")
        node = engine.provenance_chain("n2", "source-b", parent_ids=["n1"])
        assert "n1" in node.parent_ids

    def test_get_provenance_chain(self) -> None:
        engine = GovernanceEngine()
        engine.provenance_chain("n1", "s1")
        engine.provenance_chain("n2", "s2")
        chain = engine.get_provenance_chain()
        assert len(chain) == 2
