"""Coverage tests for architecture discovery engine."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from aegis.training import architecture_discovery as arch_mod
from aegis.training.architecture_discovery import (
    ArchitectureDiscoveryEngine,
    ArchitectureLibrary,
    MemoryArchitecture,
)


def test_memory_architecture_serialization_and_fingerprint() -> None:
    arch = MemoryArchitecture(
        id="arch-1",
        name="test",
        domain="legal",
        schema_code="schema = {}",
        retrieval_code="def retrieve(): pass",
        update_rules_code="def update(): pass",
        fitness_score=0.55,
        generation=2,
        parent_ids=["p1"],
        created_at=datetime(2026, 1, 1, tzinfo=UTC),
    )

    as_dict = arch.to_dict()
    assert as_dict["id"] == "arch-1"
    assert as_dict["fitness_score"] == 0.55
    assert as_dict["created_at"].startswith("2026-01-01")

    fp1 = arch.code_fingerprint()
    arch.schema_code = "schema = {'x': 1}"
    fp2 = arch.code_fingerprint()
    assert fp1 != fp2


def test_architecture_library_search_closest_and_summary() -> None:
    lib = ArchitectureLibrary()

    a_general = MemoryArchitecture(
        id="g1",
        name="general",
        domain="general",
        schema_code="s",
        retrieval_code="r",
        update_rules_code="u",
        fitness_score=0.6,
        metadata={"emphasis": "general,flexibility", "operations": ["STORE"], "scale": "medium"},
    )
    a_legal = MemoryArchitecture(
        id="l1",
        name="legal",
        domain="legal",
        schema_code="s2",
        retrieval_code="r2",
        update_rules_code="u2",
        fitness_score=0.8,
        metadata={
            "emphasis": "document_versioning,temporal_ordering",
            "operations": ["STORE", "VERIFY", "MERGE"],
            "scale": "large",
        },
    )
    lib.add(a_general)
    lib.add(a_legal)

    results = lib.search("legal", top_k=5)
    assert results[0].id == "l1"
    assert lib.get("missing") is None
    assert set(a.id for a in lib.all_architectures()) == {"g1", "l1"}

    closest = lib.get_closest(
        "legal",
        {
            "emphasis": "document_versioning,temporal_ordering",
            "operations": ["MERGE"],
            "scale": "large",
        },
    )
    assert closest is not None
    assert closest.id == "l1"

    summary = lib.summary()
    assert summary["total_architectures"] == 2
    assert summary["domain_counts"]["legal"] == 1


def test_engine_propose_evaluate_cache_and_component_fitness() -> None:
    engine = ArchitectureDiscoveryEngine()

    proposed = engine.propose(
        "legal",
        {
            "retrieval_heavy": 0.8,
            "update_heavy": 0.7,
            "temporal_emphasis": 0.6,
            "multi_hop": 0.8,
            "conflict_prone": 0.5,
            "scale": "large",
        },
    )
    assert proposed.domain == "legal"
    assert proposed.metadata["proposed"] is True
    assert proposed.parent_ids

    tasks = [
        {
            "type": "multi_source_retrieval",
            "domain": "legal",
            "difficulty": 5,
            "operations_required": ["RETRIEVE", "MERGE", "LINK"],
        },
        {
            "type": "conflict_resolution",
            "domain": "legal",
            "difficulty": 4,
            "operations_required": ["UPDATE", "MERGE"],
        },
    ]

    score1 = engine.evaluate(proposed, tasks)
    score2 = engine.evaluate(proposed, tasks)
    assert 0.0 <= score1 <= 1.0
    assert score1 == score2
    assert proposed.eval_results["num_tasks"] == 2

    assert engine.evaluate(proposed, []) == 0.0

    schema_fit = engine._compute_schema_fitness(
        "graph_memory", "multi_step_reasoning", ["LINK", "MERGE"], "seed1"
    )
    retrieval_fit = engine._compute_retrieval_fitness(
        "iterative_deepening", "multi_source_retrieval", 5, "seed2"
    )
    update_fit = engine._compute_update_fitness(
        "merge_with_conflict", "conflict_resolution", ["UPDATE", "MERGE"], "seed3"
    )
    assert 0.0 <= schema_fit <= 1.0
    assert 0.0 <= retrieval_fit <= 1.0
    assert 0.0 <= update_fit <= 1.0


def test_engine_evolve_crossover_and_task_generation() -> None:
    engine = ArchitectureDiscoveryEngine()
    parent = engine.library.search("legal", top_k=1)[0]

    child_force_tweak = engine.evolve(parent, mutation_rate=0.0)
    assert child_force_tweak.generation == parent.generation + 1
    assert child_force_tweak.parent_ids == [parent.id]
    assert child_force_tweak.metadata["mutations"]

    child_mutated = engine.evolve(parent, mutation_rate=1.0)
    assert child_mutated.metadata["mutations"]

    other = engine.library.search("finance", top_k=1)[0]
    cross = engine._crossover(parent, other, seed="cross-seed")
    assert cross.generation == max(parent.generation, other.generation) + 1
    assert set(cross.parent_ids) == {parent.id, other.id}

    tasks = engine._generate_eval_tasks("legal", count=5)
    assert len(tasks) == 5
    assert all("operations_required" in t for t in tasks)


def test_engine_search_cross_domain_transfer_and_summary(monkeypatch: pytest.MonkeyPatch) -> None:
    engine = ArchitectureDiscoveryEngine()

    best = engine.search(domain="legal", generations=2, population_size=4)
    assert best.domain == "legal"
    assert 0.0 <= best.fitness_score <= 1.0

    transferred = engine.cross_domain_transfer("legal", "finance")
    assert transferred.domain == "finance"
    assert transferred.parent_ids
    assert 0.0 <= transferred.fitness_score <= 1.0

    # Force no-seed/no-source path.
    monkeypatch.setattr(
        ArchitectureDiscoveryEngine, "_seed_default_architectures", lambda self: None
    )
    empty_engine = ArchitectureDiscoveryEngine(library=ArchitectureLibrary())
    cold_transfer = empty_engine.cross_domain_transfer("unknown", "legal")
    assert cold_transfer.domain == "legal"
    assert cold_transfer.metadata["proposed"] is True

    assert engine._compute_domain_affinity("legal", "legal") == 1.0
    affinity = engine._compute_domain_affinity("unknown-a", "unknown-b")
    assert 0.2 <= affinity <= 0.5

    summary = engine.summary()
    assert summary["search_runs"] >= 1
    assert summary["library"]["total_architectures"] >= 1


def test_module_level_helpers_are_deterministic() -> None:
    assert arch_mod._det_float("x", 0.0, 1.0) == arch_mod._det_float("x", 0.0, 1.0)
    assert arch_mod._det_int("x", 1, 10) == arch_mod._det_int("x", 1, 10)
    assert arch_mod._det_choice("seed", ["a", "b", "c"]) in {"a", "b", "c"}
    sample = arch_mod._det_sample("seed", [1, 2, 3], 2)
    assert len(sample) == 2
    assert arch_mod._det_sample("seed", [], 2) == []
    assert arch_mod._arch_id().startswith("arch-")
