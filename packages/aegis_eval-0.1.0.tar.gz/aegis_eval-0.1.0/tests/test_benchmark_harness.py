"""Tests for the benchmark harness."""

from __future__ import annotations

import pytest
from benchmarks.harness import BenchmarkHarness

from aegis.core.types import EvalCaseV1, EvalTier
from aegis.eval.engine import Evaluator

# The 20 M2 dimension IDs that the core suite must cover.
M2_DIMENSIONS = {
    "retention_accuracy",
    "update_correctness",
    "selective_forgetting",
    "cross_reference_integrity",
    "provenance_tracking",
    "retrieval_precision",
    "source_routing",
    "context_length_robustness",
    "relevance_explanation",
    "contradiction_detection",
    "multi_hop_synthesis",
    "equal_treatment",
    "calibration",
    "explainability",
    "relevant_sharing",
    "confidentiality",
    "inter_agent_communication",
    "prompt_injection_resistance",
    "memory_poisoning_detection",
    "pii_leakage_prevention",
}


@pytest.fixture
def harness() -> BenchmarkHarness:
    """Return a fresh BenchmarkHarness for each test."""
    return BenchmarkHarness()


# ------------------------------------------------------------------
# 1. test_load_core_suite
# ------------------------------------------------------------------


def test_load_core_suite(harness: BenchmarkHarness) -> None:
    """Loading the 'core' suite returns a list of EvalCaseV1 instances."""
    suite = harness.load_suite("core")
    assert isinstance(suite, list)
    assert len(suite) > 0
    for case in suite:
        assert isinstance(case, EvalCaseV1)


# ------------------------------------------------------------------
# 2. test_core_suite_has_20_cases
# ------------------------------------------------------------------


def test_core_suite_has_20_cases(harness: BenchmarkHarness) -> None:
    """The core suite contains exactly 20 cases."""
    suite = harness.load_suite("core")
    assert len(suite) == 20


# ------------------------------------------------------------------
# 3. test_core_suite_covers_all_m2_dimensions
# ------------------------------------------------------------------


def test_core_suite_covers_all_m2_dimensions(harness: BenchmarkHarness) -> None:
    """Every one of the 20 M2 dimension IDs appears in the core suite."""
    suite = harness.load_suite("core")
    dimension_ids = {case.dimension_id for case in suite}
    assert dimension_ids == M2_DIMENSIONS


# ------------------------------------------------------------------
# 4. test_load_unknown_raises_key_error
# ------------------------------------------------------------------


def test_load_unknown_raises_key_error(harness: BenchmarkHarness) -> None:
    """Loading a suite name that does not exist raises KeyError."""
    with pytest.raises(KeyError, match="Unknown benchmark suite"):
        harness.load_suite("nonexistent-suite")


# ------------------------------------------------------------------
# 5. test_register_custom_suite
# ------------------------------------------------------------------


def test_register_custom_suite(harness: BenchmarkHarness) -> None:
    """A registered custom suite can be loaded by name."""
    custom_cases = [
        EvalCaseV1(
            suite_id="custom-v1",
            dimension_id="retention_accuracy",
            tier=EvalTier.MEMORY_FIDELITY,
            prompt="Test prompt",
            expected={"answer": "test"},
        ),
    ]
    harness.register_suite("my_custom", lambda: custom_cases)

    loaded = harness.load_suite("my_custom")
    assert loaded == custom_cases
    assert len(loaded) == 1
    assert loaded[0].suite_id == "custom-v1"

    # Clean up class-level registry to avoid polluting other tests.
    BenchmarkHarness._suite_registry.pop("my_custom", None)


# ------------------------------------------------------------------
# 6. test_run_returns_results
# ------------------------------------------------------------------


def test_run_returns_results(harness: BenchmarkHarness) -> None:
    """Running a suite through the evaluator returns a dict with the expected keys."""
    evaluator = Evaluator()
    suite = harness.load_suite("core")
    results = harness.run(evaluator, suite)

    assert isinstance(results, dict)
    assert "suite_size" in results
    assert "run_id" in results
    assert "overall_score" in results
    assert "dimension_scores" in results
    assert "result" in results

    assert results["suite_size"] == 20
    assert isinstance(results["run_id"], str)
    assert isinstance(results["overall_score"], float)
    assert isinstance(results["dimension_scores"], dict)
    assert isinstance(results["result"], dict)


# ------------------------------------------------------------------
# 7. test_compare_to_baseline
# ------------------------------------------------------------------


def test_compare_to_baseline(harness: BenchmarkHarness) -> None:
    """Deltas are computed correctly as current - baseline for each dimension."""
    results = {
        "dimension_scores": {
            "retention_accuracy": 0.9,
            "update_correctness": 0.7,
            "calibration": 0.5,
        },
    }
    baseline = {
        "retention_accuracy": 0.8,
        "update_correctness": 0.75,
        "calibration": 0.5,
    }

    deltas = harness.compare_to_baseline(results, baseline)

    assert isinstance(deltas, dict)
    assert deltas["retention_accuracy"] == pytest.approx(0.1)
    assert deltas["update_correctness"] == pytest.approx(-0.05)
    assert deltas["calibration"] == pytest.approx(0.0)


# ------------------------------------------------------------------
# 8. test_compare_to_baseline_new_dims
# ------------------------------------------------------------------


def test_compare_to_baseline_new_dims(harness: BenchmarkHarness) -> None:
    """When baseline and results have different dimensions, missing values default to 0."""
    results = {
        "dimension_scores": {
            "retention_accuracy": 0.9,
            "explainability": 0.6,
        },
    }
    baseline = {
        "retention_accuracy": 0.8,
        "calibration": 0.7,
    }

    deltas = harness.compare_to_baseline(results, baseline)

    # retention_accuracy: 0.9 - 0.8 = 0.1
    assert deltas["retention_accuracy"] == pytest.approx(0.1)
    # explainability: only in current -> 0.6 - 0.0 = 0.6
    assert deltas["explainability"] == pytest.approx(0.6)
    # calibration: only in baseline -> 0.0 - 0.7 = -0.7
    assert deltas["calibration"] == pytest.approx(-0.7)
    # All three keys must be present.
    assert set(deltas.keys()) == {"retention_accuracy", "explainability", "calibration"}


# ------------------------------------------------------------------
# 9. test_set_and_get_baseline
# ------------------------------------------------------------------


def test_set_and_get_baseline(harness: BenchmarkHarness) -> None:
    """A baseline that is set can be retrieved unchanged."""
    scores = {"retention_accuracy": 0.85, "calibration": 0.72}
    harness.set_baseline("v0.1.0", scores)

    retrieved = harness.get_baseline("v0.1.0")
    assert retrieved == scores
    # Verify it returns a copy, not the same dict.
    assert retrieved is not scores


# ------------------------------------------------------------------
# 10. test_get_nonexistent_baseline_raises
# ------------------------------------------------------------------


def test_get_nonexistent_baseline_raises(harness: BenchmarkHarness) -> None:
    """Getting a baseline that was never stored raises KeyError."""
    with pytest.raises(KeyError, match="No baseline stored"):
        harness.get_baseline("does-not-exist")


def test_load_legal_memory_suite(harness: BenchmarkHarness) -> None:
    """New legal-memory benchmark suite loads with expected size."""
    suite = harness.load_suite("legal-memory")
    assert len(suite) == 50
    assert all(case.domain == "legal" for case in suite)


def test_load_legal_memory_scale_suite(harness: BenchmarkHarness) -> None:
    """Scaled legal-memory benchmark suite loads with 200+ cases."""
    suite = harness.load_suite("legal-memory-scale")
    assert len(suite) >= 200
    assert all(case.domain == "legal" for case in suite)
    assert all(case.suite_id == "aegis-legal-memory-scale-v1" for case in suite)


def test_load_finance_memory_suite(harness: BenchmarkHarness) -> None:
    """New finance-memory benchmark suite loads with expected size."""
    suite = harness.load_suite("finance-memory")
    assert len(suite) == 50
    assert all(case.domain == "finance" for case in suite)


def test_load_reward_integrity_suite(harness: BenchmarkHarness) -> None:
    """Reward-integrity suite loads seeded safety scenarios."""
    suite = harness.load_suite("reward-integrity")
    assert len(suite) == 200
    assert all(case.domain == "safety" for case in suite)
    assert all("seeded_hacking" in case.tags for case in suite)


def test_load_suite_aliases(harness: BenchmarkHarness) -> None:
    """Underscore aliases resolve to canonical benchmark suite names."""
    legal_cases = harness.load_suite("legal_memory")
    legal_scaled_cases = harness.load_suite("legal_memory_scale")
    finance_cases = harness.load_suite("finance_memory")
    reward_cases = harness.load_suite("reward_integrity")
    assert len(legal_cases) == 50
    assert len(legal_scaled_cases) >= 200
    assert len(finance_cases) == 50
    assert len(reward_cases) == 200


def test_list_suites_includes_new_benchmarks(harness: BenchmarkHarness) -> None:
    """Harness listing includes new benchmark suite names."""
    suites = harness.list_suites()
    assert "legal-memory" in suites
    assert "legal-memory-scale" in suites
    assert "finance-memory" in suites
    assert "reward-integrity" in suites
