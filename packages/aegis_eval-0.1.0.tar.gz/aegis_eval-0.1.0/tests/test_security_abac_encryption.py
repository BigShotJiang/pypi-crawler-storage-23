"""Coverage tests for ABAC policy engine and encryption helpers."""

from __future__ import annotations

from pathlib import Path

import pytest

from aegis.security.abac import (
    ABACEngine,
    ABACPolicy,
    Attribute,
    AttributeSet,
    PolicyCondition,
    data_classification_policy,
    department_policy,
    sensitivity_policy,
    time_based_policy,
)
from aegis.security.encryption import DataEncryptor, SecretDetector, TLSConfig


def test_attribute_validation_and_attribute_set_lookup() -> None:
    Attribute(name="department", value="legal", data_type="string")
    with pytest.raises(ValueError):
        Attribute(name="x", value=1, data_type="invalid")

    attrs = AttributeSet(
        subject_attrs={"department": "legal", "clearance": 2, "roles": ["analyst"]},
        resource_attrs={"classification": "restricted", "contains_pii": True},
        action_attrs={"type": "read"},
        environment_attrs={"current_time": 8},
    )
    assert attrs.get("subject.department") == "legal"
    assert attrs.get("resource.classification") == "restricted"
    assert attrs.get("invalid") is None
    assert attrs.get("other.key") is None


def test_policy_condition_operators() -> None:
    attrs = AttributeSet(
        subject_attrs={"x": 5, "roles": ["admin"], "email": "user@example.com", "text": "abc"},
        resource_attrs={"y": 5},
    )

    assert PolicyCondition("subject.x", "eq", 5).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "neq", 6).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "gt", 4).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "lt", 6).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "gte", 5).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "lte", 5).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "in", [1, 5, 9]).evaluate(attrs) is True
    assert PolicyCondition("subject.x", "not_in", [1, 9]).evaluate(attrs) is True
    assert PolicyCondition("subject.roles", "contains", "admin").evaluate(attrs) is True
    assert PolicyCondition("subject.text", "contains", "ab").evaluate(attrs) is True
    assert PolicyCondition("subject.email", "matches", r"@example\.com$").evaluate(attrs) is True

    # Missing attribute: only neq/not_in pass.
    assert PolicyCondition("subject.missing", "neq", 1).evaluate(attrs) is True
    assert PolicyCondition("subject.missing", "not_in", [1]).evaluate(attrs) is True
    assert PolicyCondition("subject.missing", "eq", 1).evaluate(attrs) is False
    assert PolicyCondition("subject.x", "unknown", 1).evaluate(attrs) is False


def test_abac_engine_evaluation_and_builtins() -> None:
    engine = ABACEngine()

    allow = ABACPolicy(
        id="allow-legal",
        name="allow legal",
        effect="allow",
        conditions=[PolicyCondition("subject.department", "eq", "legal")],
        priority=10,
    )
    deny = ABACPolicy(
        id="deny-restricted",
        name="deny restricted",
        effect="deny",
        conditions=[PolicyCondition("resource.classification", "eq", "restricted")],
        priority=20,
    )

    engine.add_policy(allow)
    engine.add_policy(deny)
    assert engine.remove_policy("missing") is False

    attrs = AttributeSet(
        subject_attrs={"department": "legal", "clearance": 2, "privacy_trained": False},
        resource_attrs={
            "classification": "restricted",
            "business_hours_only": True,
            "cross_department_ok": False,
            "contains_pii": True,
        },
        environment_attrs={"current_time": 8},
    )

    detailed = engine.evaluate_detailed(attrs)
    assert detailed["decision"] == "deny"
    assert "deny-restricted" in detailed["denied_by"]
    assert engine.evaluate(attrs) is False

    assert engine.remove_policy("allow-legal") is True
    assert engine.list_policies()[0].id == "deny-restricted"

    builtin = ABACEngine()
    builtin.add_policy(data_classification_policy())
    builtin.add_policy(time_based_policy())
    builtin.add_policy(department_policy())
    builtin.add_policy(sensitivity_policy())

    denied = builtin.check_access(
        subject={"department": "legal", "clearance": 1, "privacy_trained": False},
        resource={
            "classification": "restricted",
            "business_hours_only": True,
            "cross_department_ok": False,
            "contains_pii": True,
        },
        action="read",
        environment={"current_time": 8},
    )
    assert denied is False

    # Default deny when no policy matches.
    empty = ABACEngine()
    assert empty.evaluate(AttributeSet()) is False


def test_data_encryptor_roundtrip_and_field_encryption() -> None:
    enc = DataEncryptor("master-key")
    key1, salt = enc.derive_key("pwd")
    key2, _ = enc.derive_key("pwd", salt=salt)
    assert key1 == key2

    ciphertext = enc.encrypt("secret-data")
    assert enc.decrypt(ciphertext) == b"secret-data"

    # Tamper with ciphertext.
    tampered = bytearray(ciphertext)
    tampered[-1] ^= 0x01
    with pytest.raises(ValueError):
        enc.decrypt(bytes(tampered))

    with pytest.raises(ValueError):
        enc.decrypt(b"short")

    payload = {"name": "alice", "pii": {"ssn": "123-45-6789"}, "count": 3}
    encrypted_payload = enc.encrypt_field(payload, ["pii", "count"])
    assert isinstance(encrypted_payload["pii"], str)
    assert encrypted_payload["pii"].startswith("__encrypted__:")

    decrypted_payload = enc.decrypt_field(encrypted_payload, ["pii", "count"])
    assert decrypted_payload["pii"] == {"ssn": "123-45-6789"}
    assert decrypted_payload["count"] == 3


def test_tls_config_and_secret_detector(tmp_path: Path) -> None:
    cfg = TLSConfig.generate_self_signed_cert_config()
    assert cfg["key"]["algorithm"] == "RSA"

    ctx = TLSConfig.get_tls_context_config("cert.pem", "key.pem")
    assert ctx["certfile"] == "cert.pem"
    assert ctx["keyfile"] == "key.pem"

    missing = TLSConfig.validate_certificate(str(tmp_path / "missing.pem"))
    assert missing["valid"] is False

    bad_cert = tmp_path / "bad.pem"
    bad_cert.write_text("no pem markers", encoding="utf-8")
    invalid = TLSConfig.validate_certificate(str(bad_cert))
    assert invalid["valid"] is False

    good_cert = tmp_path / "good.pem"
    good_cert.write_text(
        "-----BEGIN CERTIFICATE-----\nabc\n-----END CERTIFICATE-----\n",
        encoding="utf-8",
    )
    valid = TLSConfig.validate_certificate(str(good_cert))
    assert valid["valid"] is True

    detector = SecretDetector()
    sample = (
        "Bearer token Bearer abcdefghijklmnopqrstuvwxyz123456\n"
        "api_key=sk-abcdefghijklmnopqrstuvwxyz123456\n"
        "password=supersecret123\n"
        "aws=AKIA1234567890ABCD12\n"
    )
    findings = detector.scan(sample)
    assert findings
    redacted = detector.redact(sample)
    assert "[REDACTED:" in redacted
    assert "supersecret123" not in redacted
