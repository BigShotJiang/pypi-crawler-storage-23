"""Tests for the scaled legal-memory benchmark suite."""

from __future__ import annotations

import pytest

from aegis.eval.benchmarks import LegalMemoryScaleBenchmark


def test_legal_memory_scale_default_suite_has_250_cases() -> None:
    benchmark = LegalMemoryScaleBenchmark()
    suite = benchmark.build_suite()

    assert suite.config.name == "aegis-legal-memory-scale-v1"
    assert len(suite.cases) == 250
    assert suite.config.num_cases == 250
    assert all(case.domain == "legal" for case in suite.cases)
    assert all("legal_memory_scale" in case.tags for case in suite.cases)


def test_legal_memory_scale_cases_have_unique_ids() -> None:
    benchmark = LegalMemoryScaleBenchmark(num_cases=220)
    suite = benchmark.build_suite()

    ids = [case.id for case in suite.cases]
    assert len(ids) == len(set(ids))
    assert min(case.difficulty for case in suite.cases) >= 1
    assert max(case.difficulty for case in suite.cases) <= 5


def test_legal_memory_scale_generate_cases_shape() -> None:
    benchmark = LegalMemoryScaleBenchmark(num_cases=200)
    cases = benchmark.generate_cases()

    assert len(cases) == 200
    first = cases[0]
    assert "prompt" in first
    assert "expected_output" in first
    assert "memory_operations_expected" in first
    assert "category" in first


def test_legal_memory_scale_rejects_under_200_cases() -> None:
    with pytest.raises(ValueError, match=">= 200"):
        LegalMemoryScaleBenchmark(num_cases=150)
