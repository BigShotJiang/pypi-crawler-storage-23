"""Tests for the append-only event log."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from aegis.core.exceptions import EventLogImmutabilityError
from aegis.core.types import MemoryEventV1, MemoryOperation, MemoryTier
from aegis.memory.event_log import EventLog


def _make_event(
    op: MemoryOperation = MemoryOperation.STORE,
    key: str = "k",
    ts: datetime | None = None,
) -> MemoryEventV1:
    return MemoryEventV1(
        operation=op,
        memory_tier=MemoryTier.WORKING,
        key=key,
        value=f"value for {key}",
        agent_id="agent-1",
        customer_id="cust-1",
        timestamp=ts or datetime.now(tz=UTC),
    )


# ---------------------------------------------------------------------------
# TestEventLogAppend
# ---------------------------------------------------------------------------


class TestEventLogAppend:
    """Basic append and read-back behaviour."""

    def test_append_single(self) -> None:
        log = EventLog()
        event = _make_event()
        log.append(event)
        assert len(log) == 1
        # Deep copy on append: stored event is equal but not identical.
        assert log[0] is not event
        assert log[0].key == event.key

    def test_append_multiple(self) -> None:
        log = EventLog()
        events = [_make_event(key=f"k{i}") for i in range(5)]
        for e in events:
            log.append(e)
        assert len(log) == 5
        for i, e in enumerate(events):
            # Deep copy on append: stored event is equal but not identical.
            assert log[i] is not e
            assert log[i].key == e.key

    def test_len(self) -> None:
        log = EventLog()
        assert len(log) == 0
        log.append(_make_event())
        assert len(log) == 1
        log.append(_make_event(key="k2"))
        assert len(log) == 2

    def test_iter(self) -> None:
        log = EventLog()
        events = [_make_event(key=f"k{i}") for i in range(3)]
        for e in events:
            log.append(e)
        collected = list(log)
        assert collected == events

    def test_getitem(self) -> None:
        log = EventLog()
        e0 = _make_event(key="first")
        e1 = _make_event(key="second")
        log.append(e0)
        log.append(e1)
        assert log[0].key == "first"
        assert log[1].key == "second"


# ---------------------------------------------------------------------------
# TestEventLogImmutability
# ---------------------------------------------------------------------------


class TestEventLogImmutability:
    """Mutation attempts must raise EventLogImmutabilityError."""

    def test_setitem_raises(self) -> None:
        log = EventLog()
        log.append(_make_event())
        with pytest.raises(EventLogImmutabilityError):
            log[0] = _make_event(key="replaced")

    def test_delitem_raises(self) -> None:
        log = EventLog()
        log.append(_make_event())
        with pytest.raises(EventLogImmutabilityError):
            del log[0]

    def test_error_type(self) -> None:
        log = EventLog()
        log.append(_make_event())
        with pytest.raises(EventLogImmutabilityError) as exc_info:
            log[0] = _make_event()
        assert "immutable" in str(exc_info.value).lower()


# ---------------------------------------------------------------------------
# TestEventLogReplay
# ---------------------------------------------------------------------------


class TestEventLogReplay:
    """Temporal replay queries."""

    def test_replay_from_includes_matching(self) -> None:
        log = EventLog()
        t1 = datetime(2025, 1, 1, 12, 0, 0)
        t2 = datetime(2025, 1, 2, 12, 0, 0)
        log.append(_make_event(key="a", ts=t1))
        log.append(_make_event(key="b", ts=t2))
        result = log.replay_from(t1)
        assert len(result) == 2

    def test_replay_from_excludes_earlier(self) -> None:
        log = EventLog()
        t1 = datetime(2025, 1, 1)
        t2 = datetime(2025, 1, 2)
        t3 = datetime(2025, 1, 3)
        log.append(_make_event(key="a", ts=t1))
        log.append(_make_event(key="b", ts=t2))
        log.append(_make_event(key="c", ts=t3))
        result = log.replay_from(t2)
        assert len(result) == 2
        assert result[0].key == "b"
        assert result[1].key == "c"

    def test_replay_range_both_bounds(self) -> None:
        log = EventLog()
        t1 = datetime(2025, 1, 1)
        t2 = datetime(2025, 1, 2)
        t3 = datetime(2025, 1, 3)
        t4 = datetime(2025, 1, 4)
        for i, ts in enumerate([t1, t2, t3, t4]):
            log.append(_make_event(key=f"k{i}", ts=ts))
        result = log.replay_range(t2, t3)
        assert len(result) == 2
        assert {e.key for e in result} == {"k1", "k2"}

    def test_replay_range_empty(self) -> None:
        log = EventLog()
        log.append(_make_event(ts=datetime(2025, 6, 1)))
        result = log.replay_range(datetime(2025, 1, 1), datetime(2025, 2, 1))
        assert result == []

    def test_replay_from_empty_log(self) -> None:
        log = EventLog()
        result = log.replay_from(datetime(2025, 1, 1))
        assert result == []


# ---------------------------------------------------------------------------
# TestEventLogHashChain
# ---------------------------------------------------------------------------


class TestEventLogHashChain:
    """SHA-256 hash chain integrity."""

    def test_verify_integrity_valid(self) -> None:
        log = EventLog()
        for i in range(5):
            log.append(_make_event(key=f"k{i}"))
        assert log.verify_integrity() is True

    def test_verify_integrity_detects_tamper(self) -> None:
        log = EventLog()
        for i in range(3):
            log.append(_make_event(key=f"k{i}"))
        # Tamper with the hash chain directly.
        log._hash_chain[1] = "bad_hash"
        assert log.verify_integrity() is False

    def test_verify_empty_log(self) -> None:
        log = EventLog()
        assert log.verify_integrity() is True

    def test_hashes_differ_per_event(self) -> None:
        log = EventLog()
        log.append(_make_event(key="a"))
        log.append(_make_event(key="b"))
        assert log._hash_chain[0] != log._hash_chain[1]


# ---------------------------------------------------------------------------
# TestEventLogAllEvents
# ---------------------------------------------------------------------------


class TestEventLogAllEvents:
    """The all_events() method returns a copy."""

    def test_returns_copy(self) -> None:
        log = EventLog()
        log.append(_make_event(key="x"))
        events = log.all_events()
        assert len(events) == 1
        assert events[0].key == "x"

    def test_copy_is_independent(self) -> None:
        log = EventLog()
        log.append(_make_event(key="x"))
        events = log.all_events()
        events.clear()
        assert len(log) == 1  # original unaffected


# ---------------------------------------------------------------------------
# TestEventLogGet
# ---------------------------------------------------------------------------


class TestEventLogGet:
    """The get() method for index-based access."""

    def test_get_valid_index(self) -> None:
        log = EventLog()
        e = _make_event(key="target")
        log.append(e)
        # Deep copy on append: stored event is equal but not identical.
        assert log.get(0) is not e
        assert log.get(0).key == e.key

    def test_get_invalid_index_raises(self) -> None:
        log = EventLog()
        with pytest.raises(IndexError):
            log.get(0)
