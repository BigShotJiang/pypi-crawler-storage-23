"""Tests for the Redis cache layer."""

from __future__ import annotations

import pytest


class TestRedisCacheImport:
    """Test import guards and lazy loading."""

    def test_requires_redis(self) -> None:
        """RedisCache should raise RuntimeError if redis is not installed."""
        from aegis.store import redis as redis_mod

        original = redis_mod._HAS_REDIS
        redis_mod._HAS_REDIS = False
        try:
            with pytest.raises(RuntimeError, match="redis"):
                redis_mod.RedisCache(url="redis://fake:6379/0")
        finally:
            redis_mod._HAS_REDIS = original

    def test_lazy_import_from_store_package(self) -> None:
        """Importing RedisCache from aegis.store should not crash."""
        from aegis.store import RedisCache

        assert RedisCache is not None

    def test_key_generation(self) -> None:
        """Verify the key format used by RedisCache."""
        from aegis.store.redis import RedisCache

        # Test the _key method by instantiating with a mock
        # Since we can't connect to Redis in tests, just verify the class exists
        assert hasattr(RedisCache, "_key")
