"""Tests for online evaluation pipeline and drift/alert subsystems."""

from __future__ import annotations

from datetime import datetime

from aegis.eval.online import AlertManager, DriftDetector, OnlineEvalPipeline


def test_alert_manager_cooldown_acknowledge_and_clear() -> None:
    manager = AlertManager(cooldown_seconds=300)

    first = manager.fire(
        alert_type="threshold",
        dimension_id="retrieval_quality",
        severity="warning",
        message="low score",
        current_value=0.2,
        threshold=0.5,
    )
    assert first is not None

    # Same key within cooldown should be suppressed.
    suppressed = manager.fire(
        alert_type="threshold",
        dimension_id="retrieval_quality",
        severity="warning",
        message="low score",
    )
    assert suppressed is None

    assert manager.acknowledge(first.id)
    assert not manager.acknowledge("missing")
    assert manager.active_alerts() == []

    total = manager.clear()
    assert total == 1
    assert manager.all_alerts() == []


def test_drift_detector_baseline_record_and_reset() -> None:
    detector = DriftDetector(z_threshold=1.0, window_size=3)

    no_data = detector.check_drift("confidence_calibration")
    assert not no_data.drifted
    assert no_data.details["reason"] == "insufficient_data"

    detector.set_baseline("confidence_calibration", mean=0.9, std=0.05)
    for score in [0.2, 0.25, 0.15]:
        detector.record_score("confidence_calibration", score)

    drift = detector.check_drift("confidence_calibration")
    assert drift.drifted
    assert drift.window_size == 3
    assert drift.current_mean < drift.baseline_mean

    all_results = detector.check_all()
    assert len(all_results) == 1

    detector.reset("confidence_calibration")
    after_reset = detector.check_drift("confidence_calibration")
    assert not after_reset.drifted

    detector.reset()


def test_set_baselines_from_scores_populates_defaults() -> None:
    detector = DriftDetector()
    detector.set_baselines_from_scores({"a": 0.8, "b": 0.2})

    assert detector.check_all()[0].dimension_id in {"a", "b"}


def test_online_pipeline_scoring_alerting_and_summary() -> None:
    drift = DriftDetector(z_threshold=0.5, window_size=3)
    pipeline = OnlineEvalPipeline(
        drift_detector=drift,
        score_threshold=0.7,
    )

    baseline = {signal: 0.95 for signal in pipeline.SIGNAL_TYPES}
    pipeline.set_baselines(baseline)

    interaction = {
        "response": "Sample answer",
        "confidence": 0.9,
        "quality": 0.2,
        "retrieved_context": [{"relevant": False}, {"relevant": False}],
        "claims": [{"supported": False}, {"supported": False}],
        "latency_ms": 9_000,
        "memory_ops": 10,
        "memory_ops_useful": 1,
        "user_feedback": 0.1,
        "tokens_used": 5_000,
    }

    # Score enough interactions to fill drift windows.
    for _ in range(3):
        records = pipeline.score_interaction("agent-1", interaction)
        assert len(records) == len(pipeline.SIGNAL_TYPES)

    summary = pipeline.summary()
    assert summary["total_scored"] == len(pipeline.SIGNAL_TYPES) * 3
    assert summary["active_alerts"] >= 1
    assert isinstance(summary["drifted_signals"], list)

    scores = pipeline.recent_scores(limit=5)
    assert len(scores) == 5
    assert scores[-1]["agent_id"] == "agent-1"


def test_online_pipeline_signal_computation_paths() -> None:
    pipeline = OnlineEvalPipeline(enabled_signals=["confidence_calibration"])

    # Unknown signal path defaults to neutral score.
    assert pipeline._compute_signal("unknown", {}) == 0.5

    assert pipeline._score_confidence_calibration({"confidence": 0.8, "quality": 0.8}) == 1.0
    assert pipeline._score_confidence_calibration({"confidence": 1.0, "quality": 0.0}) == 0.0

    assert pipeline._score_retrieval_quality({"retrieved_context": []}) == 0.5
    assert (
        pipeline._score_retrieval_quality(
            {"retrieved_context": [{"relevant": True}, {"relevant": False}]}
        )
        == 0.5
    )

    assert pipeline._score_hallucination_rate({"claims": []}) == 1.0
    assert (
        pipeline._score_hallucination_rate({"claims": [{"supported": True}, {"supported": False}]})
        == 0.5
    )

    assert pipeline._score_latency({"latency_ms": 100}) == 1.0
    assert pipeline._score_latency({"latency_ms": 20_000}) == 0.0
    mid = pipeline._score_latency({"latency_ms": 5_000})
    assert 0.0 < mid < 1.0

    assert pipeline._score_memory_utilization({"memory_ops": 0, "memory_ops_useful": 0}) == 0.5
    assert pipeline._score_memory_utilization({"memory_ops": 5, "memory_ops_useful": 10}) == 1.0

    assert pipeline._score_user_satisfaction({"user_feedback": 0.4}) == 0.4
    assert pipeline._score_cost_efficiency({"tokens_used": 1000, "quality": 0.5}) == 0.5
    assert pipeline._score_cost_efficiency({"tokens_used": 1, "quality": 10.0}) == 1.0


def test_recent_scores_empty_and_iso_timestamp() -> None:
    pipeline = OnlineEvalPipeline()
    assert pipeline.recent_scores(limit=10) == []

    pipeline.score_interaction(
        "agent-1",
        {
            "confidence": 0.5,
            "quality": 0.5,
            "retrieved_context": [],
            "claims": [],
            "latency_ms": 500,
            "memory_ops": 0,
            "memory_ops_useful": 0,
            "user_feedback": 0.5,
            "tokens_used": 100,
        },
    )
    record = pipeline.recent_scores(limit=1)[0]
    # ISO-8601 timestamp parseable with Z offset support.
    datetime.fromisoformat(record["timestamp"].replace("Z", "+00:00"))
    assert record["dimension_id"] in pipeline.SIGNAL_TYPES
