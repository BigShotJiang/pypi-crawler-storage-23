"""API coverage for online-eval and events routes."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from aegis.api.app import app
from aegis.eval.online import OnlineEvalPipeline
from aegis.events.dispatcher import EventDispatcher
from aegis.events.router import EventRouter
from aegis.events.webhooks import WebhookManager

client = TestClient(app)


@pytest.fixture(autouse=True)
def _reset_route_singletons() -> None:
    import aegis.api.routes.events as events_routes
    import aegis.api.routes.online_eval as online_routes

    events_routes._dispatcher = EventDispatcher()
    events_routes._router = EventRouter()
    events_routes._webhook_manager = WebhookManager()
    online_routes._pipeline = OnlineEvalPipeline()


def test_online_eval_route_flow() -> None:
    baseline_resp = client.post(
        "/v1/online-eval/baselines",
        json={
            "dimension_scores": {
                "confidence_calibration": 0.9,
                "retrieval_quality": 0.9,
                "hallucination_rate": 0.9,
            }
        },
    )
    assert baseline_resp.status_code == 200
    assert baseline_resp.json()["dimensions"] == 3

    score_resp = client.post(
        "/v1/online-eval/score",
        json={
            "agent_id": "agent-online-1",
            "interaction": {
                "confidence": 0.8,
                "quality": 0.2,
                "retrieved_context": [{"relevant": False}],
                "claims": [{"supported": False}],
                "latency_ms": 8000,
                "memory_ops": 3,
                "memory_ops_useful": 1,
                "user_feedback": 0.2,
                "tokens_used": 4000,
            },
        },
    )
    assert score_resp.status_code == 201
    score_data = score_resp.json()
    assert len(score_data["scores"]) >= 1

    summary_resp = client.get("/v1/online-eval/summary")
    assert summary_resp.status_code == 200
    summary = summary_resp.json()
    assert summary["total_scored"] >= 1

    alerts_resp = client.get("/v1/online-eval/alerts")
    assert alerts_resp.status_code == 200
    alerts = alerts_resp.json()

    if alerts:
        alert_id = alerts[0]["id"]
        ack_resp = client.post(f"/v1/online-eval/alerts/{alert_id}/acknowledge")
        assert ack_resp.status_code == 200
        assert ack_resp.json()["acknowledged"] in {True, False}

    drift_resp = client.get("/v1/online-eval/drift")
    assert drift_resp.status_code == 200
    assert isinstance(drift_resp.json(), list)

    scores_resp = client.get("/v1/online-eval/scores?limit=5")
    assert scores_resp.status_code == 200
    assert isinstance(scores_resp.json(), list)


def test_events_route_flow_with_webhook_lifecycle() -> None:
    register_resp = client.post(
        "/v1/events/webhooks",
        json={
            "url": "https://example.com/webhook",
            "secret": "test-secret",
            "event_types": ["memory.store"],
            "max_retries": 2,
        },
    )
    assert register_resp.status_code == 201
    webhook_id = register_resp.json()["id"]

    list_resp = client.get("/v1/events/webhooks")
    assert list_resp.status_code == 200
    hooks = list_resp.json()
    assert any(h["id"] == webhook_id for h in hooks)

    publish_resp = client.post(
        "/v1/events/publish",
        json={
            "event_type": "memory.store",
            "payload": {"key": "k1", "value": "v1"},
            "source": "tests",
        },
    )
    assert publish_resp.status_code == 201
    event = publish_resp.json()
    assert event["event_type"] == "memory.store"

    history_resp = client.get("/v1/events/history?event_type=memory.store")
    assert history_resp.status_code == 200
    history = history_resp.json()
    assert len(history) >= 1

    stats_resp = client.get("/v1/events/webhooks/stats")
    assert stats_resp.status_code == 200
    stats = stats_resp.json()
    assert stats["total_webhooks"] >= 1
    assert stats["queue_size"] >= 1

    queue_resp = client.get("/v1/events/webhooks/queue")
    assert queue_resp.status_code == 200
    assert len(queue_resp.json()) >= 1

    first_process = client.post(
        "/v1/events/webhooks/process",
        json={"fail_webhook_ids": [webhook_id]},
    )
    assert first_process.status_code == 200
    first_summary = first_process.json()
    assert first_summary["processed"] >= 1
    assert first_summary["retried"] >= 1
    assert first_summary["queue_size"] >= 1

    deliveries_retry = client.get(f"/v1/events/webhooks/deliveries?webhook_id={webhook_id}")
    assert deliveries_retry.status_code == 200
    assert deliveries_retry.json()[0]["status"] in {"retrying", "failed"}

    second_process = client.post(
        "/v1/events/webhooks/process",
        json={"fail_webhook_ids": [webhook_id]},
    )
    assert second_process.status_code == 200
    second_summary = second_process.json()
    assert second_summary["processed"] >= 1
    assert second_summary["failed"] >= 1
    assert second_summary["queue_size"] == 0

    publish_again = client.post(
        "/v1/events/publish",
        json={
            "event_type": "memory.store",
            "payload": {"key": "k2", "value": "v2"},
            "source": "tests",
        },
    )
    assert publish_again.status_code == 201

    success_process = client.post("/v1/events/webhooks/process", json={})
    assert success_process.status_code == 200
    success_summary = success_process.json()
    assert success_summary["processed"] >= 1
    assert success_summary["delivered"] >= 1

    deliveries_done = client.get(f"/v1/events/webhooks/deliveries?webhook_id={webhook_id}")
    assert deliveries_done.status_code == 200
    statuses = [d["status"] for d in deliveries_done.json()]
    assert "delivered" in statuses

    dead_letters_resp = client.get("/v1/events/dead-letters")
    assert dead_letters_resp.status_code == 200
    assert isinstance(dead_letters_resp.json(), list)

    delete_resp = client.delete(f"/v1/events/webhooks/{webhook_id}")
    assert delete_resp.status_code == 200
    assert delete_resp.json()["deregistered"] is True

    delete_missing_resp = client.delete("/v1/events/webhooks/missing")
    assert delete_missing_resp.status_code == 200
    assert delete_missing_resp.json()["deregistered"] is False
