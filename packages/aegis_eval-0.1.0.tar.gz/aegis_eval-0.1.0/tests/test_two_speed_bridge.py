"""Tests for the two-speed learning bridge."""

from __future__ import annotations

from aegis.core.types import MemoryOperation, RewardTraceV1, StageReward, StepKind
from aegis.training.rollout import Rollout, RolloutStep
from aegis.training.task_generator import TaskGenerator
from aegis.training.two_speed_bridge import TwoSpeedBridge

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_rollout(
    rollout_id: str = "test-rollout-1",
    steps: list[RolloutStep] | None = None,
) -> Rollout:
    """Build a test rollout with memory operations."""
    if steps is None:
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.MEMORY_OP,
                content="STORE key=client_name value=Acme Corp",
                memory_op=MemoryOperation.STORE,
                metadata={"key": "client_name"},
            ),
            RolloutStep(
                step_idx=1,
                kind=StepKind.MEMORY_OP,
                content="RETRIEVE key=client_name for context",
                memory_op=MemoryOperation.RETRIEVE,
                metadata={"memory_key": "client_name"},
            ),
            RolloutStep(
                step_idx=2,
                kind=StepKind.REASON,
                content="Reasoning about the client based on retrieved data",
            ),
            RolloutStep(
                step_idx=3,
                kind=StepKind.ANSWER,
                content="The client Acme Corp is based in Boston.",
            ),
        ]
    return Rollout(
        id=rollout_id,
        prompt="Tell me about the client",
        steps=steps,
        total_reward=0.75,
    )


def _make_reward_trace(
    rollout_id: str = "test-rollout-1",
    total_reward: float = 0.65,
) -> RewardTraceV1:
    """Build a test reward trace."""
    return RewardTraceV1(
        rollout_id=rollout_id,
        stages=[
            StageReward(
                stage=0,
                stage_name="comprehension",
                rule_score=0.7,
                semantic_score=0.6,
                judge_score=0.8,
                weight=0.2,
                weighted_score=0.14,
            ),
            StageReward(
                stage=1,
                stage_name="retrieval",
                rule_score=0.8,
                semantic_score=0.7,
                judge_score=0.75,
                weight=0.3,
                weighted_score=0.225,
            ),
            StageReward(
                stage=2,
                stage_name="reasoning",
                rule_score=0.6,
                semantic_score=0.65,
                judge_score=0.7,
                weight=0.3,
                weighted_score=0.195,
            ),
            StageReward(
                stage=3,
                stage_name="quality",
                rule_score=0.5,
                semantic_score=0.55,
                judge_score=0.6,
                weight=0.2,
                weighted_score=0.11,
            ),
        ],
        total_reward=total_reward,
    )


# ---------------------------------------------------------------------------
# Init tests
# ---------------------------------------------------------------------------


class TestTwoSpeedBridgeInit:
    """Tests for TwoSpeedBridge construction."""

    def test_defaults(self) -> None:
        bridge = TwoSpeedBridge()
        assert bridge._sync_interval == 10
        assert bridge._feedback_blend == 0.7
        assert bridge._rollout_count == 0

    def test_custom_params(self) -> None:
        bridge = TwoSpeedBridge(
            learning_rate=0.05,
            discount_factor=0.9,
            sync_interval=5,
            feedback_blend=0.5,
        )
        assert bridge._sync_interval == 5
        assert bridge._feedback_blend == 0.5

    def test_feedback_blend_clamped(self) -> None:
        bridge = TwoSpeedBridge(feedback_blend=2.0)
        assert bridge._feedback_blend == 1.0

        bridge2 = TwoSpeedBridge(feedback_blend=-0.5)
        assert bridge2._feedback_blend == 0.0


# ---------------------------------------------------------------------------
# Key extraction tests
# ---------------------------------------------------------------------------


class TestExtractMemoryKeys:
    """Tests for TwoSpeedBridge._extract_memory_keys()."""

    def test_extracts_from_metadata(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        keys = bridge._extract_memory_keys(rollout)
        assert "client_name" in keys

    def test_extracts_from_content_regex(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.MEMORY_OP,
                content="Storing key=revenue_2024 with value $5B",
            ),
        ]
        rollout = _make_rollout(steps=steps)
        keys = bridge._extract_memory_keys(rollout)
        assert "revenue_2024" in keys

    def test_deduplicates_keys(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.MEMORY_OP,
                content="STORE key=dup_key",
                metadata={"memory_key": "dup_key"},
            ),
            RolloutStep(
                step_idx=1,
                kind=StepKind.MEMORY_OP,
                content="RETRIEVE key=dup_key",
                metadata={"memory_key": "dup_key"},
            ),
        ]
        rollout = _make_rollout(steps=steps)
        keys = bridge._extract_memory_keys(rollout)
        assert keys.count("dup_key") == 1

    def test_no_keys_found(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.REASON,
                content="Just thinking about stuff",
            ),
        ]
        rollout = _make_rollout(steps=steps)
        keys = bridge._extract_memory_keys(rollout)
        assert keys == []


# ---------------------------------------------------------------------------
# Operation extraction tests
# ---------------------------------------------------------------------------


class TestExtractOperations:
    """Tests for TwoSpeedBridge._extract_operations()."""

    def test_extracts_from_memory_op(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        ops = bridge._extract_operations(rollout)
        assert "STORE" in ops
        assert "RETRIEVE" in ops

    def test_extracts_from_content_regex(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.REASON,
                content="Need to VERIFY the stored facts before LINK them",
            ),
        ]
        rollout = _make_rollout(steps=steps)
        ops = bridge._extract_operations(rollout)
        assert "VERIFY" in ops
        assert "LINK" in ops

    def test_deduplicates_ops(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.MEMORY_OP,
                content="STORE data",
                memory_op=MemoryOperation.STORE,
            ),
            RolloutStep(
                step_idx=1,
                kind=StepKind.MEMORY_OP,
                content="Another STORE",
                memory_op=MemoryOperation.STORE,
            ),
        ]
        rollout = _make_rollout(steps=steps)
        ops = bridge._extract_operations(rollout)
        assert ops.count("STORE") == 1


# ---------------------------------------------------------------------------
# Feedback computation
# ---------------------------------------------------------------------------


class TestComputeFeedback:
    """Tests for TwoSpeedBridge._compute_feedback()."""

    def test_basic_feedback(self) -> None:
        bridge = TwoSpeedBridge(feedback_blend=0.7)
        trace = _make_reward_trace(total_reward=0.65)
        feedback = bridge._compute_feedback(trace)
        assert 0.0 <= feedback <= 1.0

    def test_clamped_to_range(self) -> None:
        bridge = TwoSpeedBridge()
        trace = _make_reward_trace(total_reward=2.0)
        feedback = bridge._compute_feedback(trace)
        assert feedback <= 1.0

    def test_zero_reward(self) -> None:
        bridge = TwoSpeedBridge()
        trace = RewardTraceV1(
            rollout_id="zero",
            stages=[],
            total_reward=0.0,
        )
        feedback = bridge._compute_feedback(trace)
        assert feedback == 0.0


# ---------------------------------------------------------------------------
# on_rollout_scored
# ---------------------------------------------------------------------------


class TestOnRolloutScored:
    """Tests for TwoSpeedBridge.on_rollout_scored()."""

    def test_increments_rollout_count(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        trace = _make_reward_trace()

        bridge.on_rollout_scored(rollout, trace)
        assert bridge._rollout_count == 1

    def test_updates_op_stats(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        trace = _make_reward_trace()

        bridge.on_rollout_scored(rollout, trace)
        assert bridge._op_totals["STORE"] >= 1
        assert bridge._op_totals["RETRIEVE"] >= 1

    def test_updates_q_values(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        trace = _make_reward_trace(total_reward=0.8)

        bridge.on_rollout_scored(rollout, trace)

        # Check that the updater has entries
        summary = bridge._updater.summary()
        assert summary["total_entries"] > 0

    def test_handles_no_keys(self) -> None:
        bridge = TwoSpeedBridge()
        steps = [
            RolloutStep(
                step_idx=0,
                kind=StepKind.MEMORY_OP,
                content="STORE some data",
                memory_op=MemoryOperation.STORE,
            ),
        ]
        rollout = _make_rollout(steps=steps)
        trace = _make_reward_trace()

        # Should not raise
        bridge.on_rollout_scored(rollout, trace)
        assert bridge._rollout_count == 1


# ---------------------------------------------------------------------------
# sync_discoveries_to_tasks
# ---------------------------------------------------------------------------


class TestSyncDiscoveries:
    """Tests for TwoSpeedBridge.sync_discoveries_to_tasks()."""

    def test_sync_at_interval(self) -> None:
        bridge = TwoSpeedBridge(sync_interval=2)
        task_gen = TaskGenerator(domain="memory")
        rollout = _make_rollout()
        # Use low reward to make ops "weak"
        trace = _make_reward_trace(total_reward=0.2)

        # First rollout — not at sync interval
        bridge.on_rollout_scored(rollout, trace)
        bridge.sync_discoveries_to_tasks(task_gen)

        # Second rollout — at sync interval
        bridge.on_rollout_scored(rollout, trace)
        bridge.on_rollout_scored(rollout, trace)  # count = 3, not multiple of 2
        # Force count to match interval
        bridge._rollout_count = 4
        bridge.sync_discoveries_to_tasks(task_gen)
        # May or may not inject — depends on whether ops are "weak" enough

    def test_no_sync_without_weak_ops(self) -> None:
        bridge = TwoSpeedBridge(sync_interval=1)
        task_gen = TaskGenerator(domain="memory")
        rollout = _make_rollout()
        trace = _make_reward_trace(total_reward=0.9)

        # High reward — ops won't be considered weak
        bridge.on_rollout_scored(rollout, trace)
        # Need at least 3 samples for an op to be evaluated
        bridge.on_rollout_scored(rollout, trace)
        bridge.on_rollout_scored(rollout, trace)
        injected = bridge.sync_discoveries_to_tasks(task_gen)
        # With high reward, should not inject
        assert injected == 0


# ---------------------------------------------------------------------------
# identify_weak_operations
# ---------------------------------------------------------------------------


class TestIdentifyWeakOperations:
    """Tests for TwoSpeedBridge._identify_weak_operations()."""

    def test_no_ops_no_weak(self) -> None:
        bridge = TwoSpeedBridge()
        assert bridge._identify_weak_operations() == []

    def test_identifies_low_success_rate(self) -> None:
        bridge = TwoSpeedBridge()
        bridge._op_totals["STORE"] = 10
        bridge._op_successes["STORE"] = 2  # 20% success rate
        bridge._op_reward_sums["STORE"] = 3.0  # 0.3 mean reward
        weak = bridge._identify_weak_operations()
        assert "STORE" in weak

    def test_skips_ops_with_few_attempts(self) -> None:
        bridge = TwoSpeedBridge()
        bridge._op_totals["MERGE"] = 2  # Below threshold of 3
        bridge._op_successes["MERGE"] = 0
        bridge._op_reward_sums["MERGE"] = 0.0
        weak = bridge._identify_weak_operations()
        assert "MERGE" not in weak


# ---------------------------------------------------------------------------
# get_runtime_statistics
# ---------------------------------------------------------------------------


class TestRuntimeStatistics:
    """Tests for TwoSpeedBridge.get_runtime_statistics()."""

    def test_initial_stats(self) -> None:
        bridge = TwoSpeedBridge()
        stats = bridge.get_runtime_statistics()
        assert stats["rollout_count"] == 0
        assert stats["sync_count"] == 0
        assert stats["operation_stats"] == {}

    def test_stats_after_processing(self) -> None:
        bridge = TwoSpeedBridge()
        rollout = _make_rollout()
        trace = _make_reward_trace()
        bridge.on_rollout_scored(rollout, trace)

        stats = bridge.get_runtime_statistics()
        assert stats["rollout_count"] == 1
        assert len(stats["operation_stats"]) > 0
        assert "memrl_summary" in stats


# ---------------------------------------------------------------------------
# Integration: engine hook
# ---------------------------------------------------------------------------


class TestEngineIntegration:
    """Test that the bridge can be wired into the training engine."""

    def test_bridge_in_engine_config(self) -> None:
        from aegis.training.engine import AMIRGRPOTrainer

        trainer = AMIRGRPOTrainer(model_name="test-model", num_stages=2)
        result = trainer.train(
            {
                "num_episodes": 1,
                "max_steps": 10,
                "reward_stages": 2,
                "tasks_per_stage": 1,
                "rollout_group_size": 1,
                "two_speed_bridge": True,
                "bridge_sync_interval": 1,
                "tracking_enabled": False,
            }
        )

        assert result["status"] == "completed"
        # Check that bridge metrics are recorded in stage_metrics
        for sm in result["stage_metrics"]:
            assert "two_speed_bridge" in sm
            assert "rollout_count" in sm["two_speed_bridge"]


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------


class TestExports:
    """Test exports from training __init__."""

    def test_import_from_training(self) -> None:
        from aegis.training import TwoSpeedBridge as TwoSpeed

        assert TwoSpeed is TwoSpeedBridge
