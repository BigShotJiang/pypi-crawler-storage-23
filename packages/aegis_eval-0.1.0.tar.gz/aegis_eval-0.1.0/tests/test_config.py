"""Tests for Aegis configuration."""

from __future__ import annotations

from pathlib import Path

from aegis.core.config import AegisConfig, OutputConfig


class TestAegisConfig:
    def test_defaults(self) -> None:
        config = AegisConfig()
        assert config.dimensions == "all"
        assert config.agent.type == "rest"
        assert config.scoring.programmatic is True
        assert config.scoring.semantic is True
        assert config.scenarios.count == 200
        assert config.ci.fail_under == 0.75

    def test_from_yaml(self, tmp_path: Path) -> None:
        yaml_content = """
agent:
  type: langchain
  config:
    chain_type: stuff

dimensions:
  - retention_accuracy
  - citation_validity

scoring:
  programmatic: true
  semantic: true
  llm_judge:
    model: gpt-4o
    rubric: default

scenarios:
  count: 100
  difficulty: adaptive

output:
  formats:
    - json
    - html
  path: ./my-results/

ci:
  fail_under: 0.80
  fail_dimensions:
    citation_validity: 0.90
"""
        config_path = tmp_path / "eval.yaml"
        config_path.write_text(yaml_content)

        config = AegisConfig.from_yaml(config_path)
        assert config.agent.type == "langchain"
        assert config.dimensions == ["retention_accuracy", "citation_validity"]
        assert config.scoring.llm_judge is not None
        assert config.scoring.llm_judge.model == "gpt-4o"
        assert config.scenarios.count == 100
        assert config.output.formats == ["json", "html"]
        assert config.ci.fail_under == 0.80
        assert config.ci.fail_dimensions["citation_validity"] == 0.90

    def test_empty_yaml(self, tmp_path: Path) -> None:
        config_path = tmp_path / "empty.yaml"
        config_path.write_text("")
        config = AegisConfig.from_yaml(config_path)
        assert config.dimensions == "all"

    def test_output_config(self) -> None:
        output = OutputConfig(formats=["json", "pdf"], path="/reports/", include_traces=False)
        assert output.include_traces is False
        assert "pdf" in output.formats
