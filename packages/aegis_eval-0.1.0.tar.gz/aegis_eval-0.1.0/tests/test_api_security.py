"""Security-focused API middleware tests."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from aegis.api.app import create_app
from aegis.core.settings import get_settings


def _build_client(monkeypatch: pytest.MonkeyPatch, **env: str) -> TestClient:
    """Create a fresh app/client pair with isolated env settings."""
    get_settings.cache_clear()
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    app = create_app()
    return TestClient(app)


def test_rate_limit_enforced_per_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    client = _build_client(
        monkeypatch,
        AEGIS_RATE_LIMIT_RPM="1",
        AEGIS_RATE_LIMIT_BURST="0",
    )

    first = client.get("/health", headers={"X-API-Key": "alpha"})
    second = client.get("/health", headers={"X-API-Key": "alpha"})
    other = client.get("/health", headers={"X-API-Key": "beta"})

    assert first.status_code == 200
    assert second.status_code == 429
    assert "Retry-After" in second.headers
    assert other.status_code == 200


def test_request_size_limit_blocks_large_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    client = _build_client(
        monkeypatch,
        AEGIS_MAX_REQUEST_SIZE="128",
    )

    payload = {
        "agent_config": {"type": "rest", "config": {}},
        "dimensions": ["retention_accuracy"],
        "num_scenarios": 1,
        "padding": "x" * 5000,
    }
    response = client.post("/v1/evals/runs", json=payload)

    assert response.status_code == 413
    body = response.json()
    assert body["detail"] == "Payload too large."
    assert body["max_bytes"] == 128
    assert body["received_bytes"] > body["max_bytes"]


def test_cors_allows_configured_origin(monkeypatch: pytest.MonkeyPatch) -> None:
    allowed_origin = "https://allowed.example.com"
    client = _build_client(
        monkeypatch,
        AEGIS_CORS_ORIGINS=allowed_origin,
    )

    response = client.options(
        "/health",
        headers={
            "Origin": allowed_origin,
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 200
    assert response.headers.get("access-control-allow-origin") == allowed_origin


def test_cors_blocks_unconfigured_origin(monkeypatch: pytest.MonkeyPatch) -> None:
    client = _build_client(
        monkeypatch,
        AEGIS_CORS_ORIGINS="https://allowed.example.com",
    )

    response = client.options(
        "/health",
        headers={
            "Origin": "https://blocked.example.com",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 400
    assert "access-control-allow-origin" not in response.headers


def test_production_disallows_wildcard_cors(monkeypatch: pytest.MonkeyPatch) -> None:
    get_settings.cache_clear()
    monkeypatch.setenv("AEGIS_ENV", "production")
    monkeypatch.setenv("AEGIS_CORS_ORIGINS", "*")

    with pytest.raises(ValidationError):
        create_app()
