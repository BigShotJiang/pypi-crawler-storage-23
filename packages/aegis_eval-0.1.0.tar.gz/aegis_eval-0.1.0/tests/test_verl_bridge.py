"""Tests for the verl training bridge and model loader modules."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aegis.training.verl_bridge import VerlTrainer, VerlTrainingConfig

# ---------------------------------------------------------------------------
# VerlTrainingConfig tests
# ---------------------------------------------------------------------------


class TestVerlTrainingConfig:
    """Test training configuration."""

    def test_default_config(self) -> None:
        config = VerlTrainingConfig()
        assert config.model_name == "Qwen/Qwen2.5-7B"
        assert config.use_lora is True
        assert config.domain == "legal"

    def test_custom_config(self) -> None:
        config = VerlTrainingConfig(
            model_name="Qwen/Qwen2.5-3B",
            domain="finance",
            num_episodes=50,
            lora_rank=8,
        )
        assert config.model_name == "Qwen/Qwen2.5-3B"
        assert config.domain == "finance"
        assert config.num_episodes == 50
        assert config.lora_rank == 8

    def test_to_dict(self) -> None:
        config = VerlTrainingConfig()
        d = config.to_dict()
        assert d["model_name"] == "Qwen/Qwen2.5-7B"
        assert "learning_rate" in d
        assert "gpu_ids" in d

    def test_to_dict_roundtrip(self) -> None:
        config = VerlTrainingConfig(domain="finance", num_episodes=42)
        d = config.to_dict()
        restored = VerlTrainingConfig(**d)
        assert restored.domain == "finance"
        assert restored.num_episodes == 42

    def test_save_and_load(self, tmp_path: Path) -> None:
        config = VerlTrainingConfig(domain="finance", num_episodes=42)
        config_path = tmp_path / "config.json"
        config.save(config_path)

        loaded = VerlTrainingConfig.load(config_path)
        assert loaded.domain == "finance"
        assert loaded.num_episodes == 42

    def test_all_fields_in_dict(self) -> None:
        config = VerlTrainingConfig()
        d = config.to_dict()
        expected_keys = {
            "model_name",
            "output_dir",
            "num_episodes",
            "rollouts_per_prompt",
            "max_seq_length",
            "learning_rate",
            "kl_coeff",
            "use_lora",
            "lora_rank",
            "lora_alpha",
            "precision",
            "gradient_accumulation_steps",
            "reward_stages",
            "domain",
            "gpu_ids",
        }
        assert set(d.keys()) == expected_keys


# ---------------------------------------------------------------------------
# VerlTrainer tests
# ---------------------------------------------------------------------------


class TestVerlTrainer:
    """Test the verl trainer bridge."""

    def test_device_info(self) -> None:
        config = VerlTrainingConfig()
        trainer = VerlTrainer(config)
        info = trainer.device_info
        assert "backend" in info
        assert "cuda_available" in info or info["backend"] == "simulated"

    def test_train_returns_completed(self) -> None:
        config = VerlTrainingConfig(num_episodes=1, domain="legal")
        trainer = VerlTrainer(config)
        result = trainer.train(prompts=["Test legal prompt"])
        assert result["status"] == "completed"
        assert "config" in result

    def test_train_returns_metrics(self) -> None:
        config = VerlTrainingConfig(num_episodes=1, domain="legal")
        trainer = VerlTrainer(config)
        result = trainer.train(prompts=["Test legal prompt"])
        assert "mean_reward" in result
        assert "best_reward" in result
        assert "final_loss" in result

    def test_train_finance_domain(self) -> None:
        config = VerlTrainingConfig(num_episodes=1, domain="finance")
        trainer = VerlTrainer(config)
        result = trainer.train(prompts=["Test finance prompt"])
        assert result["status"] == "completed"

    def test_train_multiple_prompts(self) -> None:
        config = VerlTrainingConfig(num_episodes=1)
        trainer = VerlTrainer(config)
        result = trainer.train(
            prompts=[
                "Prompt 1: Analyze the contract",
                "Prompt 2: Review the filing",
                "Prompt 3: Assess the risk",
            ]
        )
        assert result["status"] == "completed"

    def test_train_with_eval_fn(self) -> None:
        config = VerlTrainingConfig(num_episodes=1)
        trainer = VerlTrainer(config)
        eval_calls = []

        def mock_eval(episode: int, metrics: dict) -> None:
            eval_calls.append({"episode": episode, "metrics": metrics})

        result = trainer.train(prompts=["Test"], eval_fn=mock_eval)
        assert result["status"] == "completed"

    def test_generate_verl_config(self) -> None:
        config = VerlTrainingConfig(
            model_name="Qwen/Qwen2.5-7B",
            domain="legal",
            use_lora=True,
            lora_rank=16,
        )
        trainer = VerlTrainer(config)
        verl_cfg = trainer.generate_verl_config()

        assert verl_cfg["model"]["name"] == "Qwen/Qwen2.5-7B"
        assert verl_cfg["training"]["algorithm"] == "grpo"
        assert verl_cfg["lora"]["enabled"] is True
        assert verl_cfg["lora"]["rank"] == 16
        assert verl_cfg["reward"]["domain"] == "legal"

    def test_generate_verl_config_structure(self) -> None:
        config = VerlTrainingConfig()
        trainer = VerlTrainer(config)
        verl_cfg = trainer.generate_verl_config()

        assert "model" in verl_cfg
        assert "training" in verl_cfg
        assert "lora" in verl_cfg
        assert "reward" in verl_cfg
        assert "resources" in verl_cfg
        assert "output" in verl_cfg

    def test_is_real_training_property(self) -> None:
        config = VerlTrainingConfig()
        trainer = VerlTrainer(config)
        # Should return bool
        assert isinstance(trainer.is_real_training, bool)

    def test_simulated_fallback(self) -> None:
        """Without torch/verl, training should fall back to simulated."""
        config = VerlTrainingConfig(num_episodes=1)
        trainer = VerlTrainer(config)
        # Force simulated mode
        trainer._is_real = False
        result = trainer.train(prompts=["Test"])
        assert result["status"] == "completed"
        assert result.get("backend") == "simulated"


# ---------------------------------------------------------------------------
# ModelConfig tests
# ---------------------------------------------------------------------------


class TestModelConfig:
    """Test the model configuration dataclass."""

    def test_default_config(self) -> None:
        from aegis.training.model_loader import ModelConfig

        config = ModelConfig()
        assert config.model_name == "Qwen/Qwen2.5-7B"
        assert config.precision == "bf16"
        assert config.use_lora is True
        assert config.lora_rank == 16
        assert config.device == "auto"

    def test_custom_config(self) -> None:
        from aegis.training.model_loader import ModelConfig

        config = ModelConfig(
            model_name="meta-llama/Llama-3-8B",
            precision="fp16",
            lora_rank=8,
            quantize="4bit",
        )
        assert config.model_name == "meta-llama/Llama-3-8B"
        assert config.quantize == "4bit"

    def test_lora_target_modules_default(self) -> None:
        from aegis.training.model_loader import ModelConfig

        config = ModelConfig()
        assert "q_proj" in config.lora_target_modules
        assert "v_proj" in config.lora_target_modules


# ---------------------------------------------------------------------------
# Model loader utility tests
# ---------------------------------------------------------------------------


class TestModelLoaderUtilities:
    """Test model loader utility functions."""

    def test_resolve_device_cpu(self) -> None:
        from aegis.training.model_loader import resolve_device

        assert resolve_device("cpu") == "cpu"

    def test_resolve_device_explicit(self) -> None:
        from aegis.training.model_loader import resolve_device

        assert resolve_device("cuda:0") == "cuda:0"
        assert resolve_device("mps") == "mps"

    def test_resolve_device_auto(self) -> None:
        from aegis.training.model_loader import resolve_device

        # On CI without GPU, should resolve to "cpu" or "mps"
        device = resolve_device("auto")
        assert device in ("cpu", "cuda", "mps")

    def test_get_torch_dtype_without_torch(self) -> None:
        from aegis.training.model_loader import _HAS_TORCH, get_torch_dtype

        if not _HAS_TORCH:
            assert get_torch_dtype("bf16") is None
        else:
            import torch

            assert get_torch_dtype("bf16") == torch.bfloat16
            assert get_torch_dtype("fp16") == torch.float16
            assert get_torch_dtype("fp32") == torch.float32

    def test_load_tokenizer_without_transformers(self) -> None:
        from aegis.training.model_loader import _HAS_TRANSFORMERS, load_tokenizer

        if not _HAS_TRANSFORMERS:
            with pytest.raises(RuntimeError, match="transformers required"):
                load_tokenizer("test-model")

    def test_load_model_without_transformers(self) -> None:
        from aegis.training.model_loader import _HAS_TRANSFORMERS, ModelConfig, load_model

        if not _HAS_TRANSFORMERS:
            with pytest.raises(RuntimeError, match="transformers required"):
                load_model(ModelConfig())


# ---------------------------------------------------------------------------
# Real training path tests (with mocked GPU/model)
# ---------------------------------------------------------------------------


class TestRealTrainingPath:
    """Test the real training path with mocked dependencies."""

    def test_train_real_falls_back_on_model_load_failure(self) -> None:
        """If model loading fails, should fall back to simulated."""
        config = VerlTrainingConfig(num_episodes=1)
        trainer = VerlTrainer(config)
        trainer._is_real = True  # Force real path

        with patch(
            "aegis.training.model_loader.load_model_and_tokenizer",
            side_effect=RuntimeError("No GPU"),
        ):
            result = trainer._train_real(["Test prompt"])

        # Should fall back to simulated
        assert result["status"] == "completed"
        assert result.get("backend") == "simulated"

    def test_train_real_with_mocked_model(self, tmp_path: Path) -> None:
        """Test the real training path with mocked model.

        Without verl installed and with a mock model, the fallback chain is:
        verl GRPOTrainer -> manual training -> simulated training.
        The important thing is that it completes successfully.
        """
        config = VerlTrainingConfig(
            num_episodes=1,
            output_dir=str(tmp_path / "checkpoints"),
        )
        trainer = VerlTrainer(config)
        trainer._is_real = True

        mock_model = MagicMock()
        mock_model.parameters.return_value = iter([])
        mock_model.device = "cpu"
        mock_tokenizer = MagicMock()

        with patch(
            "aegis.training.model_loader.load_model_and_tokenizer",
            return_value=(mock_model, mock_tokenizer),
        ):
            result = trainer._train_real(["Test prompt"])

        assert result["status"] == "completed"
        assert "run_id" in result
        # Backend depends on available dependencies
        assert result.get("backend") in ("verl", "simulated")

    def test_config_saved_on_real_train(self, tmp_path: Path) -> None:
        """Real training should save config for reproducibility."""
        config = VerlTrainingConfig(
            num_episodes=1,
            output_dir=str(tmp_path / "checkpoints"),
        )
        trainer = VerlTrainer(config)
        trainer._is_real = True

        mock_model = MagicMock()
        mock_model.parameters.return_value = iter([])
        mock_model.device = "cpu"
        mock_tokenizer = MagicMock()

        with patch(
            "aegis.training.model_loader.load_model_and_tokenizer",
            return_value=(mock_model, mock_tokenizer),
        ):
            trainer._train_real(["Test prompt"])

        config_path = tmp_path / "checkpoints" / "training_config.json"
        assert config_path.exists()

    def test_reward_engine_wired_in_real_train(self, tmp_path: Path) -> None:
        """Real training should create a domain-specific reward engine."""
        config = VerlTrainingConfig(
            num_episodes=1,
            domain="legal",
            output_dir=str(tmp_path / "checkpoints"),
        )
        trainer = VerlTrainer(config)
        trainer._is_real = True

        mock_model = MagicMock()
        mock_model.parameters.return_value = iter([])
        mock_model.device = "cpu"
        mock_tokenizer = MagicMock()

        with patch(
            "aegis.training.model_loader.load_model_and_tokenizer",
            return_value=(mock_model, mock_tokenizer),
        ):
            result = trainer._train_real(["Analyze the contract clause"])

        assert result["status"] == "completed"
        # Should have reward summary from reward engine
        if "reward_summary" in result:
            assert "stages" in result["reward_summary"]
