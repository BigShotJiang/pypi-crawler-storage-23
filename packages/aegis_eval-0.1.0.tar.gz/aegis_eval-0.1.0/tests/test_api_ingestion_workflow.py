"""API tests for ingestion status and retry workflow."""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from aegis.api.app import app
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline

client = TestClient(app)


@pytest.fixture(autouse=True)
def _reset_ingestion_singletons() -> None:
    import aegis.api.routes.ingestion as ingestion_routes

    ingestion_routes._pipeline = IngestionPipeline(IngestionConfig())
    ingestion_routes._sinks = []


def test_ingestion_status_and_retry_for_local_path(tmp_path: Path) -> None:
    doc = tmp_path / "sample_contract.txt"
    doc.write_text(
        "Service Agreement\n\nThis is a sample contract body used for ingestion testing.",
        encoding="utf-8",
    )

    ingest_resp = client.post("/v1/ingestion/ingest", params={"source": str(doc)})
    assert ingest_resp.status_code == 201
    ingested = ingest_resp.json()
    doc_id = ingested["document_id"]

    status_resp = client.get(f"/v1/ingestion/{doc_id}")
    assert status_resp.status_code == 200
    status_data = status_resp.json()
    assert status_data["document_id"] == doc_id
    assert status_data["source_path"] == str(doc)
    assert status_data["num_chunks"] >= 1

    retry_resp = client.post(f"/v1/ingestion/{doc_id}/retry")
    assert retry_resp.status_code == 201
    retried = retry_resp.json()
    assert retried["document_id"] != doc_id
    assert retried["source_path"] == str(doc)
    assert retried["num_chunks"] >= 1


def test_ingestion_status_not_found() -> None:
    response = client.get("/v1/ingestion/does-not-exist")
    assert response.status_code == 404


def test_ingestion_retry_rejects_unavailable_upload_source() -> None:
    files = {
        "file": (
            "ephemeral_upload.txt",
            b"This file exists only in request payload",
            "text/plain",
        )
    }
    upload_resp = client.post("/v1/ingestion/upload", files=files)
    assert upload_resp.status_code == 201
    doc_id = upload_resp.json()["document_id"]

    retry_resp = client.post(f"/v1/ingestion/{doc_id}/retry")
    assert retry_resp.status_code == 400
    assert "Retry requires a readable local source file" in retry_resp.json()["detail"]
