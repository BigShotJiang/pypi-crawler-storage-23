# ruff: noqa
"""Comprehensive tests for advanced memory modules.

Covers interference detection, decay engine, architecture search,
multi-agent memory, MemRL Q-learning, memory types, snapshot
reconstruction, provenance tracking, and memory factory.
"""

from __future__ import annotations

import math
import random
from datetime import UTC, datetime, timedelta
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aegis.core.types import (
    MemoryEventV1,
    MemoryOperation,
    MemoryTier,
    TemporalBounds,
)
from aegis.memory.types import MemoryEntry


# ============================================================================
# 1. Interference Detection
# ============================================================================


class TestInterferenceDetector:
    """Tests for aegis.memory.interference.InterferenceDetector."""

    def _make_entry(
        self,
        key: str,
        value: Any = "default value that is longer than twenty characters for testing",
        tier: MemoryTier = MemoryTier.WORKING,
        tags: list[str] | None = None,
        temporal_bounds: TemporalBounds | None = None,
    ) -> MemoryEntry:
        return MemoryEntry(
            key=key,
            value=value,
            tier=tier,
            tags=tags or [],
            temporal_bounds=temporal_bounds,
        )

    def test_no_interference_on_empty_list(self) -> None:
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()
        results = detector.detect([])
        assert results == []

    def test_no_interference_on_single_entry(self) -> None:
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()
        entries = [self._make_entry("key_alpha")]
        results = detector.detect(entries)
        assert results == []

    def test_key_collision_high_severity(self) -> None:
        """Similar keys with different values should flag key_collision."""
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector(key_similarity_threshold=0.7)
        entries = [
            self._make_entry("user_preference_style", "bullet point summaries preferred"),
            self._make_entry(
                "user_preference_styls", "completely different information about the weather today"
            ),
        ]
        results = detector.detect(entries)
        key_collisions = [r for r in results if r.interference_type == "key_collision"]
        assert len(key_collisions) >= 1
        assert key_collisions[0].pair == ("user_preference_style", "user_preference_styls")
        assert key_collisions[0].severity in ("medium", "high")
        assert 0 < key_collisions[0].score <= 1.0
        assert "key_similarity" in key_collisions[0].details

    def test_key_collision_not_triggered_for_identical_keys(self) -> None:
        """Identical keys should NOT trigger key_collision (it requires similar but different)."""
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()
        entries = [
            self._make_entry("same_key", "value A is quite a bit longer than twenty chars"),
            self._make_entry("same_key", "value B is also much longer than twenty chars"),
        ]
        results = detector.detect(entries)
        key_collisions = [r for r in results if r.interference_type == "key_collision"]
        assert len(key_collisions) == 0

    def test_key_collision_not_triggered_for_very_different_keys(self) -> None:
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector(key_similarity_threshold=0.8)
        entries = [
            self._make_entry("alpha_one", "some value that is long enough here"),
            self._make_entry("zulu_ninety", "another completely different value here"),
        ]
        results = detector.detect(entries)
        key_collisions = [r for r in results if r.interference_type == "key_collision"]
        assert len(key_collisions) == 0

    def test_semantic_overlap_detected(self) -> None:
        """Entries with very similar values but different tiers should flag semantic_overlap."""
        from aegis.memory.interference import InterferenceDetector

        long_text = "This is a detailed description of the contract terms and legal obligations that the parties agreed to sign and uphold"
        detector = InterferenceDetector(similarity_threshold=0.6)
        entries = [
            self._make_entry("entry_a", long_text, tier=MemoryTier.WORKING, tags=["legal"]),
            self._make_entry("entry_b", long_text, tier=MemoryTier.SESSION, tags=["finance"]),
        ]
        results = detector.detect(entries)
        sem = [r for r in results if r.interference_type == "semantic_overlap"]
        assert len(sem) >= 1
        assert sem[0].severity == "medium"
        assert sem[0].details.get("tier_mismatch") is True

    def test_semantic_overlap_skipped_for_short_values(self) -> None:
        """Values shorter than 20 characters should be skipped in semantic overlap check."""
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector(similarity_threshold=0.1)
        entries = [
            self._make_entry("a", "short", tier=MemoryTier.WORKING),
            self._make_entry("b", "short", tier=MemoryTier.SESSION),
        ]
        results = detector.detect(entries)
        sem = [r for r in results if r.interference_type == "semantic_overlap"]
        assert len(sem) == 0

    def test_temporal_conflict_detected(self) -> None:
        """Overlapping temporal bounds with different values should flag temporal_conflict."""
        from aegis.memory.interference import InterferenceDetector

        now = datetime.now(tz=UTC)
        tb1 = TemporalBounds(valid_from=now - timedelta(days=10), valid_to=now + timedelta(days=5))
        tb2 = TemporalBounds(valid_from=now - timedelta(days=3), valid_to=now + timedelta(days=10))
        detector = InterferenceDetector()
        entries = [
            self._make_entry(
                "rule_X", "The rule says you must file within 30 days", temporal_bounds=tb1
            ),
            self._make_entry(
                "rule_Y",
                "Completely different text about weather forecasting patterns",
                temporal_bounds=tb2,
            ),
        ]
        results = detector.detect(entries)
        temporal = [r for r in results if r.interference_type == "temporal_conflict"]
        assert len(temporal) >= 1
        assert temporal[0].severity == "high"

    def test_temporal_conflict_no_overlap(self) -> None:
        """Non-overlapping temporal bounds should not flag temporal_conflict."""
        from aegis.memory.interference import InterferenceDetector

        now = datetime.now(tz=UTC)
        tb1 = TemporalBounds(valid_from=now - timedelta(days=20), valid_to=now - timedelta(days=10))
        tb2 = TemporalBounds(valid_from=now - timedelta(days=5), valid_to=now + timedelta(days=10))
        detector = InterferenceDetector()
        entries = [
            self._make_entry(
                "rule_A", "old rule about filing deadlines that is long enough", temporal_bounds=tb1
            ),
            self._make_entry(
                "rule_B",
                "new completely unrelated rule about something else entirely",
                temporal_bounds=tb2,
            ),
        ]
        results = detector.detect(entries)
        temporal = [r for r in results if r.interference_type == "temporal_conflict"]
        assert len(temporal) == 0

    def test_domain_cross_interference_detected(self) -> None:
        """Similar entries in different domains (by first tag) should flag domain_cross."""
        from aegis.memory.interference import InterferenceDetector

        shared_text = "This is a long description about compliance requirements and regulatory standards for filing"
        detector = InterferenceDetector(similarity_threshold=0.6)
        entries = [
            self._make_entry("entry_legal", shared_text, tags=["legal", "compliance"]),
            self._make_entry("entry_finance", shared_text, tags=["finance", "compliance"]),
        ]
        results = detector.detect(entries)
        cross = [r for r in results if r.interference_type == "domain_cross"]
        assert len(cross) >= 1
        assert cross[0].details.get("domain_a") in ("legal", "finance")
        assert cross[0].details.get("domain_b") in ("legal", "finance")

    def test_domain_cross_not_triggered_same_domain(self) -> None:
        """Same-domain entries should not flag domain_cross even if similar."""
        from aegis.memory.interference import InterferenceDetector

        shared_text = "A really long identical text string that describes legal compliance rules in great detail"
        detector = InterferenceDetector(similarity_threshold=0.5)
        entries = [
            self._make_entry("e1", shared_text, tags=["legal"]),
            self._make_entry("e2", shared_text, tags=["legal"]),
        ]
        results = detector.detect(entries)
        cross = [r for r in results if r.interference_type == "domain_cross"]
        assert len(cross) == 0

    def test_summary_with_results(self) -> None:
        from aegis.memory.interference import InterferenceDetector, InterferenceResult

        detector = InterferenceDetector()
        results = [
            InterferenceResult(
                pair=("a", "b"),
                interference_type="key_collision",
                severity="high",
                score=0.9,
            ),
            InterferenceResult(
                pair=("c", "d"),
                interference_type="semantic_overlap",
                severity="medium",
                score=0.8,
            ),
            InterferenceResult(
                pair=("e", "f"),
                interference_type="key_collision",
                severity="low",
                score=0.7,
            ),
        ]
        summary = detector.summary(results)
        assert summary["total_interferences"] == 3
        assert summary["by_type"]["key_collision"] == 2
        assert summary["by_type"]["semantic_overlap"] == 1
        assert summary["by_severity"]["high"] == 1
        assert summary["by_severity"]["medium"] == 1
        assert summary["by_severity"]["low"] == 1
        assert summary["highest_severity"] == "high"

    def test_summary_empty_results(self) -> None:
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()
        summary = detector.summary([])
        assert summary["total_interferences"] == 0
        assert summary["by_type"] == {}
        assert summary["by_severity"] == {}
        assert summary["highest_severity"] == "none"

    def test_detect_runs_all_checks(self) -> None:
        """The detect method should call all four check methods."""
        from aegis.memory.interference import InterferenceDetector

        detector = InterferenceDetector()
        entries = [self._make_entry("x")]
        # Just verify it runs without error and returns a list
        results = detector.detect(entries)
        assert isinstance(results, list)


# ============================================================================
# 2. Decay Engine
# ============================================================================


class TestDecayEngine:
    """Tests for aegis.memory.decay.DecayEngine."""

    def test_default_config(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        engine = DecayEngine()
        summary = engine.summary()
        assert summary["function"] == "exponential"
        assert summary["rate"] == 0.0001
        assert summary["min_confidence"] == 0.05

    def test_none_decay_returns_same_confidence(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.NONE)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(10000, 5, 0.8)
        assert result == 0.8

    def test_exponential_decay_decreases_confidence(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(3600, 0, 1.0)
        assert result < 1.0
        assert result > 0.0

    def test_exponential_decay_higher_access_slows_decay(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        low_access = engine.compute_decay(3600, 0, 1.0)
        high_access = engine.compute_decay(3600, 100, 1.0)
        # More access => slower decay => higher confidence remaining
        assert high_access > low_access

    def test_linear_decay(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.LINEAR, rate=0.001)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(500, 0, 1.0)
        assert result < 1.0
        assert result >= cfg.min_confidence

    def test_linear_decay_floors_at_zero_then_min_confidence(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.LINEAR, rate=0.01, min_confidence=0.05)
        engine = DecayEngine(cfg)
        # Very large age should floor at min_confidence
        result = engine.compute_decay(100000, 0, 1.0)
        assert result == cfg.min_confidence

    def test_power_law_decay(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.POWER_LAW, rate=0.5)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(3600, 0, 1.0)
        assert result < 1.0
        assert result > 0.0

    def test_power_law_access_bonus(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.POWER_LAW, rate=0.5)
        engine = DecayEngine(cfg)
        no_access = engine.compute_decay(3600, 0, 1.0)
        with_access = engine.compute_decay(3600, 50, 1.0)
        assert with_access > no_access

    def test_step_decay(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.STEP, half_life_seconds=3600)
        engine = DecayEngine(cfg)
        # After 1 half-life, should be about 0.5
        result = engine.compute_decay(3600, 0, 1.0)
        assert abs(result - 0.5) < 0.01

    def test_step_decay_two_half_lives(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.STEP, half_life_seconds=3600)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(7200, 0, 1.0)
        assert abs(result - 0.25) < 0.01

    def test_step_decay_zero_half_life_defaults_to_3600(self) -> None:
        """If half_life_seconds=0, it falls back to 3600 via the `or` operator."""
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.STEP, half_life_seconds=0)
        engine = DecayEngine(cfg)
        # half_life_seconds=0 => `cfg.half_life_seconds or 3600` => 3600
        # After one default half-life (3600s), should be ~0.5
        result = engine.compute_decay(3600, 0, 1.0)
        assert abs(result - 0.5) < 0.01

    def test_step_decay_static_zero_half_life_returns_one(self) -> None:
        """The static _step_decay method guards against half_life <= 0."""
        from aegis.memory.decay import DecayEngine

        assert DecayEngine._step_decay(3600, 0) == 1.0
        assert DecayEngine._step_decay(3600, -100) == 1.0

    def test_min_confidence_floor(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=1.0, min_confidence=0.1)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(1_000_000, 0, 1.0)
        assert result == 0.1

    def test_effective_rate_from_half_life(self) -> None:
        """When rate=0 and half_life is provided, rate is derived from half_life."""
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0, half_life_seconds=3600)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(3600, 0, 1.0)
        # After one half-life, exponential decay should give ~0.5
        assert abs(result - 0.5) < 0.05

    def test_effective_rate_fallback(self) -> None:
        """When both rate=0 and half_life=None, a fallback rate of 0.0001 is used."""
        from aegis.memory.decay import DecayEngine

        rate = DecayEngine._effective_rate(0.0, None)
        assert rate == 0.0001

    def test_apply_decay_batch(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        now = datetime.now(tz=UTC)
        entries = [
            {
                "created_at": now - timedelta(hours=2),
                "access_count": 0,
                "confidence": 1.0,
            },
            {
                "created_at": now - timedelta(hours=1),
                "access_count": 10,
                "confidence": 0.9,
            },
        ]
        result = engine.apply_decay_batch(entries, current_time=now)
        assert result["decayed"] >= 1
        assert isinstance(result["expired"], int)
        assert isinstance(result["exempt"], int)
        # Confidence should have been modified
        assert entries[0]["confidence"] < 1.0

    def test_apply_decay_batch_exempt_tier(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(
            function=DecayFunction.EXPONENTIAL,
            rate=0.001,
            exempt_tiers=[MemoryTier.PERMANENT],
        )
        engine = DecayEngine(cfg)
        now = datetime.now(tz=UTC)
        entries = [
            {
                "created_at": now - timedelta(hours=5),
                "access_count": 0,
                "confidence": 1.0,
                "tier": MemoryTier.PERMANENT,
            },
        ]
        result = engine.apply_decay_batch(entries, current_time=now)
        assert result["exempt"] == 1
        assert result["decayed"] == 0
        # Confidence should be unchanged
        assert entries[0]["confidence"] == 1.0

    def test_apply_decay_batch_no_created_at_skipped(self) -> None:
        from aegis.memory.decay import DecayEngine

        engine = DecayEngine()
        entries: list[dict[str, Any]] = [{"access_count": 0, "confidence": 1.0}]
        result = engine.apply_decay_batch(entries)
        assert result["decayed"] == 0

    def test_apply_decay_batch_naive_datetime_handled(self) -> None:
        """Naive datetimes (no tzinfo) should be handled by adding UTC."""
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        # Use naive datetime
        now = datetime(2026, 1, 1, 12, 0, 0)
        entries = [
            {
                "created_at": datetime(2026, 1, 1, 10, 0, 0),  # naive
                "access_count": 0,
                "confidence": 1.0,
            },
        ]
        result = engine.apply_decay_batch(entries, current_time=now)
        assert result["decayed"] >= 0  # no error thrown

    def test_apply_decay_batch_expired_tracking(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=1.0, min_confidence=0.05)
        engine = DecayEngine(cfg)
        now = datetime.now(tz=UTC)
        entries = [
            {
                "created_at": now - timedelta(days=365),
                "access_count": 0,
                "confidence": 0.06,
            },
        ]
        result = engine.apply_decay_batch(entries, current_time=now)
        assert result["expired"] >= 1

    def test_predict_expiry_exponential(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001, min_confidence=0.05)
        engine = DecayEngine(cfg)
        ttl = engine.predict_expiry(current_confidence=1.0, access_count=0)
        assert ttl is not None
        assert ttl > 0

    def test_predict_expiry_linear(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.LINEAR, rate=0.001, min_confidence=0.05)
        engine = DecayEngine(cfg)
        ttl = engine.predict_expiry(current_confidence=1.0, access_count=0)
        assert ttl is not None
        assert ttl > 0

    def test_predict_expiry_with_access_increases_ttl(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001, min_confidence=0.05)
        engine = DecayEngine(cfg)
        ttl_no_access = engine.predict_expiry(1.0, 0)
        ttl_with_access = engine.predict_expiry(1.0, 100)
        assert ttl_no_access is not None and ttl_with_access is not None
        assert ttl_with_access > ttl_no_access

    def test_predict_expiry_already_below_min(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001, min_confidence=0.05)
        engine = DecayEngine(cfg)
        ttl = engine.predict_expiry(0.01, 0)
        assert ttl == 0.0

    def test_predict_expiry_none_function(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.NONE)
        engine = DecayEngine(cfg)
        assert engine.predict_expiry(1.0, 0) is None

    def test_predict_expiry_power_law_returns_none(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.POWER_LAW, rate=0.5)
        engine = DecayEngine(cfg)
        assert engine.predict_expiry(1.0, 0) is None

    def test_predict_expiry_step_returns_none(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.STEP, half_life_seconds=3600)
        engine = DecayEngine(cfg)
        assert engine.predict_expiry(1.0, 0) is None

    def test_summary_includes_exempt_tiers(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(
            function=DecayFunction.EXPONENTIAL,
            exempt_tiers=[MemoryTier.PERMANENT, MemoryTier.SESSION],
        )
        engine = DecayEngine(cfg)
        s = engine.summary()
        assert "permanent" in s["exempt_tiers"]
        assert "session" in s["exempt_tiers"]


# ============================================================================
# 3. Architecture Search
# ============================================================================


class TestArchitectureSearch:
    """Tests for aegis.memory.architecture_search."""

    def test_memory_architecture_defaults(self) -> None:
        from aegis.memory.architecture_search import MemoryArchitecture

        arch = MemoryArchitecture()
        assert arch.name == "unnamed"
        assert arch.retrieval_strategy == "hybrid"
        assert arch.compression_strategy == "summarise"
        assert arch.fitness_score == 0.0
        assert arch.domain == "general"
        assert len(arch.id) > 0

    def test_seed_architectures_legal(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=6)
        seeds = engine.seed_architectures("legal")
        assert len(seeds) == 6
        assert all(s.domain == "legal" for s in seeds)
        # Should have the legal_temporal seed
        names = [s.name for s in seeds]
        assert any("legal_temporal" in n for n in names)

    def test_seed_architectures_finance(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=6)
        seeds = engine.seed_architectures("finance")
        assert len(seeds) == 6
        assert all(s.domain == "finance" for s in seeds)

    def test_seed_architectures_general_includes_balanced(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=6)
        seeds = engine.seed_architectures("general")
        assert len(seeds) == 6
        names = [s.name for s in seeds]
        assert any("general_balanced" in n for n in names)

    def test_seed_architectures_unknown_domain_includes_balanced(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=5)
        seeds = engine.seed_architectures("healthcare")
        assert len(seeds) == 5
        names = [s.name for s in seeds]
        assert any("general_balanced" in n for n in names)

    def test_evaluate_architecture_empty_scores(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine, MemoryArchitecture

        engine = ArchitectureSearchEngine()
        arch = MemoryArchitecture()
        fitness = engine.evaluate_architecture(arch, {})
        assert fitness == 0.0

    def test_evaluate_architecture_with_scores(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine, MemoryArchitecture

        engine = ArchitectureSearchEngine()
        arch = MemoryArchitecture(
            tiers=[
                {"name": "working", "max_entries": 200, "decay_rate": 0.1},
                {"name": "session", "max_entries": 2000, "decay_rate": 0.01},
            ]
        )
        scores = {"retention": 0.8, "recall": 0.9, "precision": 0.85}
        fitness = engine.evaluate_architecture(arch, scores)
        assert 0.0 < fitness <= 1.0
        assert arch.fitness_score == fitness

    def test_evaluate_architecture_simplicity_bonus(self) -> None:
        """Fewer tiers should get a simplicity bonus."""
        from aegis.memory.architecture_search import ArchitectureSearchEngine, MemoryArchitecture

        engine = ArchitectureSearchEngine()
        few_tiers = MemoryArchitecture(tiers=[{"name": "w", "max_entries": 100, "decay_rate": 0.1}])
        many_tiers = MemoryArchitecture(
            tiers=[{"name": f"t{i}", "max_entries": 100, "decay_rate": 0.1} for i in range(8)]
        )
        scores = {"task": 0.8}
        f1 = engine.evaluate_architecture(few_tiers, scores)
        f2 = engine.evaluate_architecture(many_tiers, scores)
        assert f1 > f2  # simplicity bonus gives higher fitness

    def test_mutate_changes_architecture(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine, MemoryArchitecture

        random.seed(42)
        engine = ArchitectureSearchEngine(mutation_rate=1.0)  # always mutate
        arch = MemoryArchitecture(
            name="base",
            tiers=[
                {"name": "working", "max_entries": 1000, "decay_rate": 0.05},
                {"name": "session", "max_entries": 5000, "decay_rate": 0.005},
            ],
            retrieval_strategy="hybrid",
            update_rules=["merge", "version"],
            compression_strategy="summarise",
        )
        mutated = engine.mutate(arch)
        assert mutated is arch  # mutated in-place
        # With mutation_rate=1.0, something should have changed
        # (can't guarantee specific change due to randomness, but the method runs)

    def test_crossover_produces_child(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine, MemoryArchitecture

        engine = ArchitectureSearchEngine()
        parent_a = MemoryArchitecture(
            name="parent_a",
            tiers=[{"name": "w", "max_entries": 100, "decay_rate": 0.1}],
            retrieval_strategy="vector_first",
            update_rules=["overwrite"],
            compression_strategy="prune",
            domain="legal",
        )
        parent_b = MemoryArchitecture(
            name="parent_b",
            tiers=[{"name": "s", "max_entries": 5000, "decay_rate": 0.01}],
            retrieval_strategy="kg_first",
            update_rules=["merge", "version"],
            compression_strategy="summarise",
            domain="finance",
        )
        child = engine.crossover(parent_a, parent_b)
        assert child.name == "parent_axparent_b"
        assert "parents" in child.metadata
        assert child.fitness_score == 0.0

    def test_evolve_single_generation(self) -> None:
        from aegis.memory.architecture_search import (
            ArchitectureCandidate,
            ArchitectureSearchEngine,
            MemoryArchitecture,
        )

        random.seed(42)
        engine = ArchitectureSearchEngine(population_size=6, mutation_rate=0.3)
        candidates = []
        for i in range(6):
            arch = MemoryArchitecture(
                name=f"arch_{i}",
                tiers=[{"name": "w", "max_entries": 100 * (i + 1), "decay_rate": 0.01}],
                fitness_score=0.1 * (i + 1),
                domain="test",
            )
            candidates.append(
                ArchitectureCandidate(architecture=arch, eval_scores={"task": 0.1 * (i + 1)})
            )
        new_gen = engine.evolve(candidates)
        assert len(new_gen) >= 6
        assert all(c.generation == 1 for c in new_gen)

    def test_evolve_with_fewer_than_two_candidates(self) -> None:
        from aegis.memory.architecture_search import (
            ArchitectureCandidate,
            ArchitectureSearchEngine,
            MemoryArchitecture,
        )

        engine = ArchitectureSearchEngine()
        single = [
            ArchitectureCandidate(
                architecture=MemoryArchitecture(name="only_one"),
            )
        ]
        result = engine.evolve(single)
        assert result == single  # returned unchanged

    def test_best_for_domain(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=4)
        seeds = engine.seed_architectures("legal")
        # Give one a high fitness score
        seeds[0].fitness_score = 0.99
        best = engine.best_for_domain("legal")
        assert best is not None
        assert best.fitness_score == 0.99

    def test_best_for_domain_empty(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine()
        assert engine.best_for_domain("nonexistent") is None

    def test_library_and_summary(self) -> None:
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=4)
        engine.seed_architectures("legal")
        engine.seed_architectures("finance")
        lib = engine.library()
        assert "legal" in lib
        assert "finance" in lib
        s = engine.summary()
        assert s["population_size"] == 4
        assert "legal" in s["domains"]
        assert "finance" in s["domains"]


# ============================================================================
# 4. Multi-Agent Memory
# ============================================================================


class TestMultiAgentMemory:
    """Tests for aegis.memory.multi_agent.MultiAgentMemory."""

    def _make_agents(self) -> tuple[Any, Any]:
        from aegis.memory.multi_agent import AgentProfile

        agent_a = AgentProfile(agent_id="agent-a", name="Agent A", domain="legal", trust_score=0.8)
        agent_b = AgentProfile(
            agent_id="agent-b", name="Agent B", domain="finance", trust_score=0.6
        )
        return agent_a, agent_b

    def test_register_agent(self) -> None:
        from aegis.memory.multi_agent import AgentProfile, MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        assert mam.summary()["agents"] == 1

    def test_register_duplicate_agent_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        with pytest.raises(ValueError, match="already registered"):
            mam.register_agent(a)

    def test_create_namespace(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns = mam.create_namespace("shared", [a.agent_id, b.agent_id])
        assert ns.name == "shared"
        assert ns.access_policy == "read_write"
        assert a.agent_id in ns.agents

    def test_create_namespace_invalid_policy_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        with pytest.raises(ValueError, match="Invalid access_policy"):
            mam.create_namespace("bad", [a.agent_id], access_policy="admin")

    def test_create_namespace_unregistered_agent_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        with pytest.raises(ValueError, match="not registered"):
            mam.create_namespace("bad", ["unknown-agent"])

    def test_get_namespace(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("ns", [a.agent_id])
        assert mam.get_namespace(ns.namespace_id) is ns
        assert mam.get_namespace("nonexistent") is None

    def test_agent_namespaces(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns1 = mam.create_namespace("ns1", [a.agent_id, b.agent_id])
        ns2 = mam.create_namespace("ns2", [a.agent_id])
        a_nss = mam.agent_namespaces(a.agent_id)
        assert len(a_nss) == 2
        b_nss = mam.agent_namespaces(b.agent_id)
        assert len(b_nss) == 1

    def test_share_and_retrieve(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns = mam.create_namespace("shared", [a.agent_id, b.agent_id])
        event = mam.share(a.agent_id, ns.namespace_id, "fact_1", "Important legal finding")
        assert event.accepted is True
        # Now agent B retrieves
        entries = mam.retrieve_shared(b.agent_id, ns.namespace_id)
        assert len(entries) == 1
        assert entries[0]["key"] == "fact_1"
        assert entries[0]["value"] == "Important legal finding"

    def test_share_rejected_for_empty_value(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("shared", [a.agent_id])
        event = mam.share(a.agent_id, ns.namespace_id, "empty_key", None)
        assert event.accepted is False

    def test_share_rejected_for_short_value(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("shared", [a.agent_id])
        # Single char key + single char value
        event = mam.share(a.agent_id, ns.namespace_id, "x", "y")
        assert event.accepted is False

    def test_share_to_nonexistent_namespace_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        with pytest.raises(KeyError, match="not found"):
            mam.share(a.agent_id, "fake-ns", "key", "value")

    def test_share_by_non_member_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns = mam.create_namespace("private", [a.agent_id])
        with pytest.raises(PermissionError, match="not a member"):
            mam.share(b.agent_id, ns.namespace_id, "key", "value")

    def test_share_read_only_namespace_rejected(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("readonly", [a.agent_id], access_policy="read_only")
        event = mam.share(a.agent_id, ns.namespace_id, "key", "value")
        assert event.accepted is False

    def test_retrieve_from_write_only_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("writeonly", [a.agent_id], access_policy="write_only")
        with pytest.raises(PermissionError, match="write-only"):
            mam.retrieve_shared(a.agent_id, ns.namespace_id)

    def test_retrieve_nonexistent_namespace_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        with pytest.raises(KeyError, match="not found"):
            mam.retrieve_shared(a.agent_id, "fake-ns")

    def test_retrieve_non_member_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns = mam.create_namespace("private", [a.agent_id])
        with pytest.raises(PermissionError, match="not a member"):
            mam.retrieve_shared(b.agent_id, ns.namespace_id)

    def test_retrieve_with_query_filter(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("shared", [a.agent_id])
        mam.share(a.agent_id, ns.namespace_id, "legal_fact", "Indemnification clause details")
        mam.share(a.agent_id, ns.namespace_id, "finance_fact", "Revenue growth 15 percent")
        results = mam.retrieve_shared(a.agent_id, ns.namespace_id, query="legal")
        assert len(results) == 1
        assert results[0]["key"] == "legal_fact"

    def test_resolve_conflict_latest(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        now = datetime.now(tz=UTC)
        entries = [
            {"value": "old", "timestamp": now - timedelta(hours=2), "confidence": 0.9},
            {"value": "new", "timestamp": now, "confidence": 0.7},
        ]
        result = mam.resolve_conflict(entries, strategy="latest")
        assert result == "new"

    def test_resolve_conflict_highest_confidence(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        now = datetime.now(tz=UTC)
        entries = [
            {"value": "low_conf", "timestamp": now, "confidence": 0.3},
            {"value": "high_conf", "timestamp": now - timedelta(hours=1), "confidence": 0.95},
        ]
        result = mam.resolve_conflict(entries, strategy="highest_confidence")
        assert result == "high_conf"

    def test_resolve_conflict_consensus(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        now = datetime.now(tz=UTC)
        entries = [
            {"value": "A", "timestamp": now, "confidence": 0.5},
            {"value": "A", "timestamp": now, "confidence": 0.6},
            {"value": "B", "timestamp": now, "confidence": 0.9},
        ]
        result = mam.resolve_conflict(entries, strategy="consensus")
        assert result == "A"

    def test_resolve_conflict_consensus_tie_falls_back_to_latest(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        now = datetime.now(tz=UTC)
        entries = [
            {"value": "A", "timestamp": now - timedelta(hours=1), "confidence": 0.5},
            {"value": "B", "timestamp": now, "confidence": 0.6},
        ]
        result = mam.resolve_conflict(entries, strategy="consensus")
        # Tie: each value appears once, falls back to latest
        assert result == "B"

    def test_resolve_conflict_trust_weighted(self) -> None:
        from aegis.memory.multi_agent import AgentProfile, MultiAgentMemory

        mam = MultiAgentMemory()
        trusted = AgentProfile(agent_id="trusted", name="Trusted", trust_score=0.95)
        untrusted = AgentProfile(agent_id="untrusted", name="Untrusted", trust_score=0.1)
        mam.register_agent(trusted)
        mam.register_agent(untrusted)
        now = datetime.now(tz=UTC)
        entries = [
            {
                "value": "trusted_answer",
                "timestamp": now,
                "confidence": 0.8,
                "from_agent": "trusted",
            },
            {
                "value": "untrusted_answer",
                "timestamp": now,
                "confidence": 0.8,
                "from_agent": "untrusted",
            },
        ]
        result = mam.resolve_conflict(entries, strategy="trust_weighted")
        assert result == "trusted_answer"

    def test_resolve_conflict_empty_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        with pytest.raises(ValueError, match="no entries"):
            mam.resolve_conflict([], strategy="latest")

    def test_resolve_conflict_unknown_strategy_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        with pytest.raises(ValueError, match="Unknown"):
            mam.resolve_conflict([{"value": "x"}], strategy="random_pick")

    def test_update_trust(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        mam.update_trust(a.agent_id, 0.15)
        assert a.trust_score == pytest.approx(0.95)
        mam.update_trust(a.agent_id, 0.1)
        assert a.trust_score == 1.0  # clamped
        mam.update_trust(a.agent_id, -1.5)
        assert a.trust_score == 0.0  # clamped

    def test_update_trust_unknown_agent_raises(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        with pytest.raises(KeyError, match="not registered"):
            mam.update_trust("ghost", 0.1)

    def test_share_history(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, _ = self._make_agents()
        mam.register_agent(a)
        ns = mam.create_namespace("ns", [a.agent_id])
        mam.share(a.agent_id, ns.namespace_id, "k1", "value one here")
        mam.share(a.agent_id, ns.namespace_id, "k2", "value two here")
        history = mam.share_history(ns.namespace_id)
        assert len(history) == 2
        # Most recent first
        assert history[0].key == "k2"

    def test_summary(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        mam = MultiAgentMemory()
        a, b = self._make_agents()
        mam.register_agent(a)
        mam.register_agent(b)
        ns = mam.create_namespace("ns", [a.agent_id, b.agent_id])
        mam.share(a.agent_id, ns.namespace_id, "k", "some actual value here")
        s = mam.summary()
        assert s["agents"] == 2
        assert s["namespaces"] == 1
        assert s["total_shared_entries"] == 1
        assert s["total_share_events"] == 1


# ============================================================================
# 5. MemRL Q-Learning & Two-Speed Learning
# ============================================================================


class TestMemRLUpdater:
    """Tests for aegis.memory.memrl.MemRLUpdater."""

    def test_get_utility_creates_default(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        util = updater.get_utility("key_1")
        assert util.key == "key_1"
        assert util.q_value == 0.5
        assert util.access_count == 0

    def test_record_access(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        util = updater.record_access("key_1", "RETRIEVE")
        assert util.access_count == 1

    def test_update_positive_feedback(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater(learning_rate=0.1)
        util = updater.update("key_1", feedback_score=0.9)
        # Q was 0.5, feedback 0.9 => Q = 0.5 + 0.1 * (0.9 - 0.5) = 0.54
        assert util.q_value == pytest.approx(0.54)
        assert util.last_feedback == 0.9
        assert len(util.history) == 1
        assert util.useful_count == 1

    def test_update_negative_feedback(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater(learning_rate=0.1)
        util = updater.update("key_1", feedback_score=0.1)
        # Q was 0.5, feedback 0.1 => Q = 0.5 + 0.1 * (0.1 - 0.5) = 0.46
        assert util.q_value == pytest.approx(0.46)
        assert util.useful_count == 0

    def test_update_clamped_to_bounds(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater(learning_rate=1.0, min_q=0.0, max_q=1.0)
        updater.update("key_1", feedback_score=2.0)  # way above max
        util = updater.get_utility("key_1")
        assert util.q_value <= 1.0

    def test_batch_update(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        feedbacks = [
            {"key": "k1", "score": 0.8},
            {"key": "k2", "score": 0.3},
            {"key": "k3", "score": 0.95, "operation": "STORE"},
        ]
        results = updater.batch_update(feedbacks)
        assert len(results) == 3
        # k1 should have higher Q than k2
        q1 = updater.get_utility("k1").q_value
        q2 = updater.get_utility("k2").q_value
        assert q1 > q2

    def test_top_k(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater(learning_rate=1.0)
        updater.update("low", feedback_score=0.1)
        updater.update("mid", feedback_score=0.5)
        updater.update("high", feedback_score=0.9)
        top = updater.top_k(k=2)
        assert len(top) == 2
        assert top[0].key == "high"
        assert top[1].key == "mid"

    def test_low_utility(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater(learning_rate=1.0)
        updater.update("very_low", feedback_score=0.05)
        updater.update("high", feedback_score=0.9)
        low = updater.low_utility(threshold=0.2)
        assert len(low) == 1
        assert low[0].key == "very_low"

    def test_decay_unused(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        updater.get_utility("idle_key")  # access_count=0, q_value=0.5
        updater.record_access("active_key")  # access_count=1
        decayed = updater.decay_unused(decay_rate=0.1, min_idle_accesses=0)
        assert decayed == 1  # Only idle_key should be decayed
        assert updater.get_utility("idle_key").q_value < 0.5

    def test_feedback_log(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        updater.update("k1", 0.8)
        updater.update("k2", 0.3)
        log = updater.feedback_log(limit=10)
        assert len(log) == 2
        assert log[0].memory_key == "k1"

    def test_operation_stats(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        updater.record_access("k1", "RETRIEVE")
        updater.update("k1", 0.8, operation="RETRIEVE")
        updater.update("k2", 0.3, operation="STORE")
        stats = updater.operation_stats()
        assert "RETRIEVE" in stats
        assert stats["RETRIEVE"]["total"] >= 1

    def test_summary(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        updater.update("k1", 0.8)
        updater.update("k2", 0.3)
        s = updater.summary()
        assert s["total_entries"] == 2
        assert s["total_feedback"] == 2
        assert 0.0 <= s["mean_q_value"] <= 1.0

    def test_summary_empty(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        updater = MemRLUpdater()
        s = updater.summary()
        assert s["total_entries"] == 0
        assert s["mean_q_value"] == 0.0


class TestTwoPhaseRetriever:
    """Tests for aegis.memory.memrl.TwoPhaseRetriever."""

    def test_semantic_filter(self) -> None:
        from aegis.memory.memrl import MemoryUtility, TwoPhaseRetriever

        retriever = TwoPhaseRetriever()
        candidates = [
            MemoryUtility(key="legal contract analysis", q_value=0.5),
            MemoryUtility(key="weather forecast today", q_value=0.9),
            MemoryUtility(key="legal precedent case law", q_value=0.3),
        ]
        filtered = retriever.semantic_filter("legal contract", candidates, top_k=2)
        assert len(filtered) == 2
        # Legal-related entries should be first
        keys = [f.key for f in filtered]
        assert "weather forecast today" not in keys or keys.index(
            "weather forecast today"
        ) > keys.index("legal contract analysis")

    def test_utility_select(self) -> None:
        from aegis.memory.memrl import MemoryUtility, TwoPhaseRetriever

        retriever = TwoPhaseRetriever()
        candidates = [
            MemoryUtility(key="low", q_value=0.1),
            MemoryUtility(key="high", q_value=0.9),
            MemoryUtility(key="mid", q_value=0.5),
        ]
        selected = retriever.utility_select(candidates, top_k=2)
        assert len(selected) == 2
        assert selected[0].key == "high"
        assert selected[1].key == "mid"

    def test_retrieve_combined(self) -> None:
        from aegis.memory.memrl import MemoryUtility, TwoPhaseRetriever

        retriever = TwoPhaseRetriever()
        candidates = [
            MemoryUtility(key="legal contract analysis", q_value=0.8),
            MemoryUtility(key="weather forecast tomorrow", q_value=0.9),
            MemoryUtility(key="legal brief preparation", q_value=0.7),
            MemoryUtility(key="financial report quarterly", q_value=0.6),
        ]
        results = retriever.retrieve("legal contract", candidates, top_k=2)
        assert len(results) <= 2


class TestExperienceBank:
    """Tests for aegis.memory.memrl.ExperienceBank."""

    def test_add_and_get_recent(self) -> None:
        from aegis.memory.memrl import ExperienceBank, InteractionExperience

        bank = ExperienceBank(max_size=100)
        exp = InteractionExperience(
            query="find legal precedent",
            retrieved_keys=["k1", "k2"],
            outcome_score=0.85,
            memory_ops_performed=["RETRIEVE"],
        )
        bank.add(exp)
        recent = bank.get_recent(limit=10)
        assert len(recent) == 1
        assert recent[0].query == "find legal precedent"

    def test_max_size_enforcement(self) -> None:
        from aegis.memory.memrl import ExperienceBank, InteractionExperience

        bank = ExperienceBank(max_size=5)
        for i in range(10):
            bank.add(InteractionExperience(query=f"query_{i}", outcome_score=float(i) / 10))
        assert len(bank._experiences) == 5
        # Should keep the last 5
        assert bank._experiences[0].query == "query_5"

    def test_get_by_query_similarity(self) -> None:
        from aegis.memory.memrl import ExperienceBank, InteractionExperience

        bank = ExperienceBank()
        bank.add(InteractionExperience(query="legal contract analysis", outcome_score=0.9))
        bank.add(InteractionExperience(query="weather forecast today", outcome_score=0.5))
        bank.add(InteractionExperience(query="legal precedent research", outcome_score=0.8))
        similar = bank.get_by_query_similarity("legal contract", top_k=2)
        assert len(similar) == 2
        queries = [s.query for s in similar]
        assert "legal contract analysis" in queries

    def test_compute_operation_effectiveness(self) -> None:
        from aegis.memory.memrl import ExperienceBank, InteractionExperience

        bank = ExperienceBank()
        bank.add(
            InteractionExperience(query="q1", outcome_score=0.8, memory_ops_performed=["RETRIEVE"])
        )
        bank.add(
            InteractionExperience(
                query="q2", outcome_score=0.4, memory_ops_performed=["RETRIEVE", "STORE"]
            )
        )
        effectiveness = bank.compute_operation_effectiveness()
        assert "RETRIEVE" in effectiveness
        assert "STORE" in effectiveness
        # RETRIEVE average = (0.8 + 0.4) / 2 = 0.6
        assert effectiveness["RETRIEVE"] == pytest.approx(0.6)

    def test_summary(self) -> None:
        from aegis.memory.memrl import ExperienceBank, InteractionExperience

        bank = ExperienceBank()
        bank.add(InteractionExperience(query="q1", outcome_score=0.9))
        bank.add(InteractionExperience(query="q2", outcome_score=0.5))
        s = bank.summary()
        assert s["total_experiences"] == 2
        assert s["mean_outcome"] == pytest.approx(0.7)
        assert s["min_outcome"] == pytest.approx(0.5)
        assert s["max_outcome"] == pytest.approx(0.9)

    def test_summary_empty(self) -> None:
        from aegis.memory.memrl import ExperienceBank

        bank = ExperienceBank()
        s = bank.summary()
        assert s["total_experiences"] == 0
        assert s["mean_outcome"] == 0.0


class TestRuntimeLearner:
    """Tests for aegis.memory.memrl.RuntimeLearner."""

    def _make_learner(self) -> Any:
        from aegis.memory.memrl import (
            ExperienceBank,
            MemRLUpdater,
            RuntimeLearner,
            TwoPhaseRetriever,
        )

        updater = MemRLUpdater(learning_rate=0.1)
        bank = ExperienceBank()
        retriever = TwoPhaseRetriever()
        return RuntimeLearner(updater, bank, retriever)

    def test_on_interaction_complete(self) -> None:
        learner = self._make_learner()
        exp = learner.on_interaction_complete(
            query="find contract clause",
            retrieved_keys=["k1", "k2"],
            outcome_score=0.85,
            ops_performed=["RETRIEVE"],
        )
        assert exp.query == "find contract clause"
        assert exp.outcome_score == 0.85
        s = learner.summary()
        assert s["interaction_count"] == 1
        assert s["mean_outcome"] == pytest.approx(0.85)

    def test_on_user_feedback(self) -> None:
        learner = self._make_learner()
        util = learner.on_user_feedback("key_1", "Great memory!", 0.95)
        assert util.last_feedback == 0.95

    def test_update_from_experience_bank(self) -> None:
        learner = self._make_learner()
        learner.on_interaction_complete("q1", ["k1"], 0.9, ["RETRIEVE"])
        learner.on_interaction_complete("q2", ["k2", "k3"], 0.6, ["STORE"])
        count = learner.update_from_experience_bank(batch_size=10)
        assert count >= 2  # at least one key per experience

    def test_get_memory_recommendations(self) -> None:
        from aegis.memory.memrl import MemRLUpdater

        learner = self._make_learner()
        # Add some entries with various utilities
        learner.on_interaction_complete("q", ["high_util"], 0.95, ["RETRIEVE"])
        learner.on_interaction_complete("q", ["low_util"], 0.05, ["RETRIEVE"])
        recs = learner.get_memory_recommendations(top_promote=2, top_forget=2)
        assert "promote" in recs
        assert "forget" in recs

    def test_summary(self) -> None:
        learner = self._make_learner()
        s = learner.summary()
        assert s["interaction_count"] == 0
        assert s["mean_outcome"] == 0.0
        assert "experience_bank" in s
        assert "updater" in s


class TestStrategyLearner:
    """Tests for aegis.memory.memrl.StrategyLearner."""

    def test_record_and_recommend(self) -> None:
        from aegis.memory.memrl import StrategyLearner

        learner = StrategyLearner()
        ctx = {"domain": "legal", "task": "retrieval"}
        # Record multiple outcomes
        learner.record_strategy(ctx, "vector_first", 0.9)
        learner.record_strategy(ctx, "vector_first", 0.85)
        learner.record_strategy(ctx, "kg_first", 0.6)
        learner.record_strategy(ctx, "kg_first", 0.5)
        recommended = learner.recommend_strategy(ctx)
        assert recommended == "vector_first"

    def test_recommend_falls_back_to_global_best(self) -> None:
        from aegis.memory.memrl import StrategyLearner

        learner = StrategyLearner()
        ctx1 = {"domain": "legal"}
        learner.record_strategy(ctx1, "hybrid", 0.9)
        learner.record_strategy(ctx1, "hybrid", 0.8)
        # Query with different context
        ctx2 = {"domain": "finance"}
        recommended = learner.recommend_strategy(ctx2)
        assert recommended == "hybrid"

    def test_recommend_default_when_empty(self) -> None:
        from aegis.memory.memrl import StrategyLearner

        learner = StrategyLearner()
        assert learner.recommend_strategy({"domain": "x"}) == "default"

    def test_recommend_needs_min_samples(self) -> None:
        """Context-level recommendation needs >= 2 samples per strategy."""
        from aegis.memory.memrl import StrategyLearner

        learner = StrategyLearner()
        ctx = {"domain": "legal"}
        learner.record_strategy(ctx, "vector_first", 0.9)  # only 1 sample
        # Falls back to global
        recommended = learner.recommend_strategy(ctx)
        assert recommended == "vector_first"  # global best (only strategy)

    def test_strategy_effectiveness(self) -> None:
        from aegis.memory.memrl import StrategyLearner

        learner = StrategyLearner()
        learner.record_strategy({}, "A", 0.8)
        learner.record_strategy({}, "A", 0.6)
        learner.record_strategy({}, "B", 0.9)
        eff = learner.strategy_effectiveness()
        assert eff["A"] == pytest.approx(0.7)
        assert eff["B"] == pytest.approx(0.9)


# ============================================================================
# 6. Memory Types & Classifier
# ============================================================================


class TestMemoryTypes:
    """Tests for aegis.memory.memory_types."""

    def test_memory_type_enum_values(self) -> None:
        from aegis.memory.memory_types import MemoryType

        assert MemoryType.FACTUAL.value == "factual"
        assert MemoryType.EXPERIENTIAL.value == "experiential"
        assert MemoryType.PROCEDURAL.value == "procedural"
        assert MemoryType.SEMANTIC.value == "semantic"
        assert MemoryType.STRATEGIC.value == "strategic"
        assert MemoryType.SOCIAL.value == "social"
        assert MemoryType.WORKING_MEMORY.value == "working_memory"
        assert len(MemoryType) == 7

    def test_typed_memory_entry_defaults(self) -> None:
        from aegis.memory.memory_types import MemoryType, TypedMemoryEntry

        entry = TypedMemoryEntry(key="test", value="hello", memory_type=MemoryType.FACTUAL)
        assert entry.tier == MemoryTier.WORKING
        assert entry.confidence == 1.0
        assert entry.source == "unknown"
        assert entry.access_count == 0
        assert entry.utility_score == 0.5
        assert entry.tags == []
        assert entry.metadata == {}

    def test_classify_factual(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "client_revenue",
            "Revenue was $5,000,000 in 2025-01-15 representing 15.3% growth",
        )
        assert result == MemoryType.FACTUAL

    def test_classify_experiential(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "lesson_learned",
            "We tried to implement the new approach and it worked well. Last time we failed badly.",
        )
        assert result == MemoryType.EXPERIENTIAL

    def test_classify_procedural(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "how_to_deploy",
            "How to deploy: Step 1 configure the server. Then run the procedure. Next verify.",
        )
        assert result == MemoryType.PROCEDURAL

    def test_classify_semantic(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "definition_of_concept",
            "A concept is a type of abstract principle. It typically represents a general framework and implies a definition.",
        )
        assert result == MemoryType.SEMANTIC

    def test_classify_strategic(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "quarterly_plan",
            "Our plan is to focus on the objective and prioritize the roadmap. We should optimize the budget.",
        )
        assert result == MemoryType.STRATEGIC

    def test_classify_social(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "agent_collaboration",
            "The agent_alpha has a trust score of 0.9. They collaborated and negotiated with the team partner.",
        )
        assert result == MemoryType.SOCIAL

    def test_classify_working_memory(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "current_task",
            "Testing whether the hypothesis about the current goal is correct. This is a draft in progress.",
        )
        assert result == MemoryType.WORKING_MEMORY

    def test_classify_default_to_factual(self) -> None:
        """When no rules match, default to FACTUAL."""
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify("xyz", "zzz")
        assert result == MemoryType.FACTUAL

    def test_classify_with_type_hint(self) -> None:
        """When heuristic is weak and type_hint is provided, use the hint."""
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        # This text has no strong signals
        result = classifier.classify(
            "note", "something generic", context={"type_hint": "procedural"}
        )
        assert result == MemoryType.PROCEDURAL

    def test_classify_with_invalid_type_hint(self) -> None:
        """Invalid type_hint should be ignored gracefully."""
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "note", "something generic", context={"type_hint": "nonexistent_type"}
        )
        assert isinstance(result, MemoryType)

    def test_classify_with_tags_and_source(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        result = classifier.classify(
            "entry",
            "some text",
            context={"tags": ["plan", "strategy", "roadmap"], "source": "planning_tool"},
        )
        assert result == MemoryType.STRATEGIC

    def test_classify_batch(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        entries = [
            ("revenue", "$5,000,000 revenue recorded on 2025-01-15", None),
            ("plan", "We should focus on the objective and prioritize our strategy", None),
        ]
        results = classifier.classify_batch(entries)
        assert "revenue" in results
        assert "plan" in results
        assert results["revenue"] == MemoryType.FACTUAL
        assert results["plan"] == MemoryType.STRATEGIC

    def test_type_distribution(self) -> None:
        from aegis.memory.memory_types import MemoryType, MemoryTypeClassifier

        classifier = MemoryTypeClassifier()
        entries = [
            ("rev", "$5,000,000 revenue on 2025-01-15", None),
            ("plan", "We should focus on objective and prioritize strategy roadmap", None),
            ("lesson", "We tried and it worked well. Last time we failed.", None),
        ]
        dist = classifier.type_distribution(entries)
        assert isinstance(dist, dict)
        assert sum(dist.values()) == 3
        # All MemoryType keys should be present
        assert len(dist) == 7


# ============================================================================
# 7. Snapshot Reconstruction
# ============================================================================


class TestSnapshotReconstructor:
    """Tests for aegis.memory.snapshot.SnapshotReconstructor."""

    def _make_event(
        self,
        op: MemoryOperation,
        key: str,
        value: Any = "test_value",
        tier: MemoryTier = MemoryTier.WORKING,
        ts: datetime | None = None,
        confidence: float = 1.0,
        metadata: dict[str, Any] | None = None,
    ) -> MemoryEventV1:
        return MemoryEventV1(
            operation=op,
            memory_tier=tier,
            key=key,
            value=value,
            agent_id="agent-test",
            customer_id="cust-test",
            timestamp=ts or datetime.now(tz=UTC),
            confidence=confidence,
            metadata=metadata or {},
        )

    def test_reconstruct_store(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        now = datetime.now(tz=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val1", ts=now))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(now + timedelta(seconds=1))
        assert "k1" in snap.entries
        assert snap.entries["k1"].value == "val1"
        assert snap.total_entries == 1
        assert snap.tier_counts.get("working", 0) == 1

    def test_reconstruct_store_and_update(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "original", ts=t1))
        log.append(self._make_event(MemoryOperation.UPDATE, "k1", "updated", ts=t2, confidence=0.9))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].value == "updated"
        assert snap.entries["k1"].confidence == 0.9

    def test_reconstruct_store_and_forget(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val", ts=t1))
        log.append(self._make_event(MemoryOperation.FORGET, "k1", ts=t2))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert "k1" not in snap.entries
        assert snap.total_entries == 0

    def test_reconstruct_retrieve_increments_access_count(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 12, 30, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val", ts=t1))
        log.append(self._make_event(MemoryOperation.RETRIEVE, "k1", ts=t2))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].access_count == 1

    def test_reconstruct_link_creates_edge(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 12, 5, 0, tzinfo=UTC)
        t3 = datetime(2026, 1, 1, 12, 10, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val1", ts=t1))
        log.append(self._make_event(MemoryOperation.STORE, "k2", "val2", ts=t2))
        log.append(
            self._make_event(
                MemoryOperation.LINK,
                "k1",
                ts=t3,
                metadata={"target_key": "k2", "relation": "cites"},
            )
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t3 + timedelta(seconds=1))
        assert len(snap.graph_edges) == 1
        assert snap.graph_edges[0].source == "k1"
        assert snap.graph_edges[0].target == "k2"
        assert snap.graph_edges[0].relation == "cites"

    def test_reconstruct_compress(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "long original text", ts=t1))
        log.append(self._make_event(MemoryOperation.COMPRESS, "k1", "short", ts=t2))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].value == "short"
        assert snap.entries["k1"].metadata.get("compressed") is True

    def test_reconstruct_promote(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(
            self._make_event(MemoryOperation.STORE, "k1", "val", tier=MemoryTier.WORKING, ts=t1)
        )
        log.append(
            self._make_event(MemoryOperation.PROMOTE, "k1", tier=MemoryTier.PERMANENT, ts=t2)
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].tier == MemoryTier.PERMANENT
        assert snap.tier_counts.get("permanent", 0) == 1

    def test_reconstruct_demote(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(
            self._make_event(MemoryOperation.STORE, "k1", "val", tier=MemoryTier.SESSION, ts=t1)
        )
        log.append(self._make_event(MemoryOperation.DEMOTE, "k1", tier=MemoryTier.WORKING, ts=t2))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].tier == MemoryTier.WORKING

    def test_reconstruct_split(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(
            self._make_event(MemoryOperation.STORE, "k1", "sentence one. sentence two.", ts=t1)
        )
        log.append(
            self._make_event(
                MemoryOperation.SPLIT,
                "k1",
                ts=t2,
                metadata={
                    "parts": [
                        {"key": "k1_p1", "value": "sentence one."},
                        {"key": "k1_p2", "value": "sentence two."},
                    ]
                },
            )
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert "k1" not in snap.entries
        assert "k1_p1" in snap.entries
        assert "k1_p2" in snap.entries
        assert snap.total_entries == 2

    def test_reconstruct_merge(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 12, 5, 0, tzinfo=UTC)
        t3 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val1", ts=t1))
        log.append(self._make_event(MemoryOperation.STORE, "k2", "val2", ts=t2))
        log.append(
            self._make_event(
                MemoryOperation.MERGE,
                "k1+k2",
                "merged_val",
                ts=t3,
                metadata={"merge_sources": ["k1", "k2"]},
            )
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t3 + timedelta(seconds=1))
        assert "k1" not in snap.entries
        assert "k2" not in snap.entries
        assert "k1+k2" in snap.entries
        assert snap.entries["k1+k2"].value == "merged_val"

    def test_reconstruct_verify(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val", ts=t1))
        log.append(
            self._make_event(
                MemoryOperation.VERIFY,
                "k1",
                ts=t2,
                metadata={"verified_by": "judge_model"},
            )
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        assert snap.entries["k1"].metadata.get("verified") is True
        assert snap.entries["k1"].metadata.get("verified_by") == "judge_model"

    def test_reconstruct_annotate(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val", ts=t1))
        log.append(
            self._make_event(
                MemoryOperation.ANNOTATE,
                "k1",
                ts=t2,
                metadata={"note": "This is important"},
            )
        )

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t2 + timedelta(seconds=1))
        annotations = snap.entries["k1"].metadata.get("annotations", [])
        assert len(annotations) == 1
        assert annotations[0]["note"] == "This is important"

    def test_reconstruct_at_earlier_time_excludes_later_events(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        t2 = datetime(2026, 1, 1, 14, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.STORE, "k1", "val", ts=t1))
        log.append(self._make_event(MemoryOperation.FORGET, "k1", ts=t2))

        recon = SnapshotReconstructor(log)
        # Reconstruct at a time between t1 and t2
        mid = datetime(2026, 1, 1, 13, 0, 0, tzinfo=UTC)
        snap = recon.reconstruct_at(mid)
        assert "k1" in snap.entries  # FORGET hasn't happened yet

    def test_reconstruct_update_on_nonexistent_entry_no_op(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)
        log.append(self._make_event(MemoryOperation.UPDATE, "nonexistent", "val", ts=t1))

        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(t1 + timedelta(seconds=1))
        assert snap.total_entries == 0

    def test_reconstruct_empty_log(self) -> None:
        from aegis.memory.event_log import EventLog
        from aegis.memory.snapshot import SnapshotReconstructor

        log = EventLog()
        recon = SnapshotReconstructor(log)
        snap = recon.reconstruct_at(datetime.now(tz=UTC))
        assert snap.total_entries == 0
        assert snap.entries == {}


# ============================================================================
# 8. Provenance Tracking
# ============================================================================


class TestProvenanceTracker:
    """Tests for aegis.memory.provenance.ProvenanceTracker."""

    def test_record_basic(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        rec = tracker.record(
            entry_key="k1",
            source_type="document",
            source_ref="doc-001",
            operation=MemoryOperation.STORE,
            confidence=0.95,
        )
        assert rec.entry_key == "k1"
        assert rec.source_type == "document"
        assert rec.confidence == 0.95

    def test_chain_returns_ordered_records(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("k1", "document", "doc-1", MemoryOperation.STORE)
        tracker.record("k1", "derived", "k1", MemoryOperation.UPDATE, confidence=0.8)
        chain = tracker.chain("k1")
        assert len(chain) == 2
        assert chain[0].source_type == "document"
        assert chain[1].source_type == "derived"

    def test_chain_empty_for_unknown_key(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.chain("nonexistent") == []

    def test_root_sources(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        # k1 is a root source (from document)
        tracker.record("k1", "document", "doc-1", MemoryOperation.STORE)
        # k2 is derived from k1
        tracker.record("k2", "derived", "k1", MemoryOperation.STORE, parent_keys=["k1"])
        # k3 is derived from k2
        tracker.record("k3", "derived", "k2", MemoryOperation.STORE, parent_keys=["k2"])
        roots = tracker.root_sources("k3")
        assert len(roots) == 1
        assert roots[0].entry_key == "k1"
        assert roots[0].source_type == "document"

    def test_root_sources_with_multiple_parents(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("doc_a", "document", "doc-a", MemoryOperation.STORE)
        tracker.record("doc_b", "document", "doc-b", MemoryOperation.STORE)
        tracker.record(
            "merged",
            "merged",
            "doc_a+doc_b",
            MemoryOperation.MERGE,
            parent_keys=["doc_a", "doc_b"],
        )
        roots = tracker.root_sources("merged")
        assert len(roots) == 2
        root_keys = {r.entry_key for r in roots}
        assert root_keys == {"doc_a", "doc_b"}

    def test_root_sources_empty_for_unknown_key(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.root_sources("unknown") == []

    def test_derived_entries(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("parent", "document", "doc-1", MemoryOperation.STORE)
        tracker.record("child1", "derived", "parent", MemoryOperation.STORE, parent_keys=["parent"])
        tracker.record("child2", "derived", "parent", MemoryOperation.STORE, parent_keys=["parent"])
        derived = tracker.derived_entries("parent")
        assert set(derived) == {"child1", "child2"}

    def test_derived_entries_empty(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.derived_entries("nothing") == []

    def test_propagate_confidence(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("p1", "document", "doc", MemoryOperation.STORE, confidence=0.8)
        tracker.record("p2", "document", "doc", MemoryOperation.STORE, confidence=0.6)
        conf = tracker.propagate_confidence(["p1", "p2"])
        # Geometric mean of 0.8 and 0.6 = sqrt(0.48) ~= 0.6928
        expected = math.sqrt(0.8 * 0.6)
        assert abs(conf - expected) < 0.001

    def test_propagate_confidence_empty_parents(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.propagate_confidence([]) == 1.0

    def test_propagate_confidence_missing_parent_chain(self) -> None:
        """Parents with no chain get confidence 1.0."""
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("p1", "document", "doc", MemoryOperation.STORE, confidence=0.5)
        conf = tracker.propagate_confidence(["p1", "unknown"])
        # geometric mean of 0.5 and 1.0 = sqrt(0.5) ~= 0.707
        expected = math.sqrt(0.5)
        assert abs(conf - expected) < 0.001

    def test_validate_chain_valid(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("k1", "document", "doc", MemoryOperation.STORE)
        tracker.record("k1", "document", "doc", MemoryOperation.UPDATE)
        assert tracker.validate_chain("k1") is True

    def test_validate_chain_no_chain(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.validate_chain("nonexistent") is False

    def test_validate_chain_derived_with_known_parents(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("parent", "document", "doc", MemoryOperation.STORE)
        tracker.record("child", "derived", "parent", MemoryOperation.STORE, parent_keys=["parent"])
        assert tracker.validate_chain("child") is True

    def test_validate_chain_derived_with_unknown_parents(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record(
            "child",
            "derived",
            "unknown_parent",
            MemoryOperation.STORE,
            parent_keys=["unknown_parent"],
        )
        assert tracker.validate_chain("child") is False

    def test_validate_chain_subsequent_records_unknown_parents(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("k1", "document", "doc", MemoryOperation.STORE)
        tracker.record("k1", "derived", "ghost", MemoryOperation.UPDATE, parent_keys=["ghost"])
        assert tracker.validate_chain("k1") is False

    def test_has_provenance(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.has_provenance("k1") is False
        tracker.record("k1", "document", "doc", MemoryOperation.STORE)
        assert tracker.has_provenance("k1") is True

    def test_remove(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("parent", "document", "doc", MemoryOperation.STORE)
        tracker.record("child", "derived", "parent", MemoryOperation.STORE, parent_keys=["parent"])
        assert tracker.remove("child") is True
        assert tracker.has_provenance("child") is False
        # Reverse index should be cleaned up
        assert tracker.derived_entries("parent") == []

    def test_remove_nonexistent(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        assert tracker.remove("ghost") is False

    def test_remove_also_clears_forward_derivation(self) -> None:
        from aegis.memory.provenance import ProvenanceTracker

        tracker = ProvenanceTracker()
        tracker.record("parent", "document", "doc", MemoryOperation.STORE)
        tracker.record("child", "derived", "parent", MemoryOperation.STORE, parent_keys=["parent"])
        # Remove parent also removes its entry from _derived_from
        assert tracker.remove("parent") is True
        assert tracker.has_provenance("parent") is False


# ============================================================================
# 9. Memory Factory
# ============================================================================


class TestMemoryFactory:
    """Tests for aegis.memory.factory.create_memory_manager."""

    def test_create_memory_manager_default_in_memory(self) -> None:
        """Without postgres/neo4j configured, should return in-memory manager."""
        from aegis.memory.factory import create_memory_manager

        with patch("aegis.memory.factory.get_settings") as mock_settings:
            settings = MagicMock()
            settings.postgres_configured = False
            settings.neo4j_configured = False
            mock_settings.return_value = settings
            mgr = create_memory_manager()
            assert mgr is not None

    def test_create_memory_manager_postgres_configured_but_fails(self) -> None:
        """When postgres is configured but connection fails, should fall back to in-memory."""
        from aegis.memory.factory import create_memory_manager

        with patch("aegis.memory.factory.get_settings") as mock_settings:
            settings = MagicMock()
            settings.postgres_configured = True
            settings.neo4j_configured = False
            settings.postgres_dsn = "postgresql://bad:bad@localhost:1/bad"
            mock_settings.return_value = settings
            # The PgVectorStore import and init may fail
            with patch.dict(
                "sys.modules",
                {
                    "aegis.store.postgres": MagicMock(
                        PgVectorStore=MagicMock(side_effect=Exception("conn fail"))
                    )
                },
            ):
                mgr = create_memory_manager()
                assert mgr is not None

    def test_create_memory_manager_neo4j_configured_but_fails(self) -> None:
        """When neo4j is configured but connection fails, should fall back to in-memory."""
        from aegis.memory.factory import create_memory_manager

        with patch("aegis.memory.factory.get_settings") as mock_settings:
            settings = MagicMock()
            settings.postgres_configured = False
            settings.neo4j_configured = True
            settings.neo4j_uri = "bolt://localhost:9999"
            settings.neo4j_user = "neo4j"
            settings.neo4j_password = "bad"
            mock_settings.return_value = settings
            with patch.dict(
                "sys.modules",
                {
                    "aegis.store.neo4j": MagicMock(
                        Neo4jGraph=MagicMock(side_effect=Exception("conn fail"))
                    )
                },
            ):
                mgr = create_memory_manager()
                assert mgr is not None


# ============================================================================
# Helper function tests (memrl internal)
# ============================================================================


class TestMemRLHelpers:
    """Tests for helper functions in memrl module."""

    def test_tokenize(self) -> None:
        from aegis.memory.memrl import _tokenize

        tokens = _tokenize("Hello World this is a test")
        assert "hello" in tokens
        assert "world" in tokens
        assert "this" in tokens
        # Single-char words like "a" are excluded (len > 1)
        assert "a" not in tokens

    def test_tokenize_empty(self) -> None:
        from aegis.memory.memrl import _tokenize

        assert _tokenize("") == set()

    def test_jaccard_similarity_identical(self) -> None:
        from aegis.memory.memrl import _jaccard_similarity

        s = {"a", "b", "c"}
        assert _jaccard_similarity(s, s) == 1.0

    def test_jaccard_similarity_disjoint(self) -> None:
        from aegis.memory.memrl import _jaccard_similarity

        assert _jaccard_similarity({"a", "b"}, {"c", "d"}) == 0.0

    def test_jaccard_similarity_partial(self) -> None:
        from aegis.memory.memrl import _jaccard_similarity

        # {"a", "b"} & {"b", "c"} = {"b"}, union = {"a","b","c"}, sim = 1/3
        assert _jaccard_similarity({"a", "b"}, {"b", "c"}) == pytest.approx(1.0 / 3.0)

    def test_jaccard_similarity_empty(self) -> None:
        from aegis.memory.memrl import _jaccard_similarity

        assert _jaccard_similarity(set(), {"a"}) == 0.0
        assert _jaccard_similarity({"a"}, set()) == 0.0

    def test_context_hash_deterministic(self) -> None:
        from aegis.memory.memrl import _context_hash

        ctx = {"domain": "legal", "task": "retrieval"}
        h1 = _context_hash(ctx)
        h2 = _context_hash(ctx)
        assert h1 == h2
        assert len(h1) == 16

    def test_context_hash_different_for_different_contexts(self) -> None:
        from aegis.memory.memrl import _context_hash

        h1 = _context_hash({"a": 1})
        h2 = _context_hash({"b": 2})
        assert h1 != h2


# ============================================================================
# InterferenceResult dataclass tests
# ============================================================================


class TestInterferenceResult:
    """Tests for InterferenceResult dataclass."""

    def test_defaults(self) -> None:
        from aegis.memory.interference import InterferenceResult

        r = InterferenceResult(pair=("a", "b"), interference_type="key_collision")
        assert r.severity == "low"
        assert r.score == 0.0
        assert r.details == {}


# ============================================================================
# DecayFunction enum tests
# ============================================================================


class TestDecayFunctionEnum:
    """Tests for DecayFunction enum."""

    def test_all_values(self) -> None:
        from aegis.memory.decay import DecayFunction

        assert DecayFunction.EXPONENTIAL.value == "exponential"
        assert DecayFunction.LINEAR.value == "linear"
        assert DecayFunction.STEP.value == "step"
        assert DecayFunction.POWER_LAW.value == "power_law"
        assert DecayFunction.NONE.value == "none"


# ============================================================================
# MemorySnapshotData model tests
# ============================================================================


class TestMemorySnapshotData:
    """Tests for MemorySnapshotData pydantic model."""

    def test_creation(self) -> None:
        from aegis.memory.snapshot import MemorySnapshotData

        snap = MemorySnapshotData(
            timestamp=datetime.now(tz=UTC),
            entries={},
            tier_counts={},
            total_entries=0,
            graph_edges=[],
        )
        assert snap.total_entries == 0
        assert snap.entries == {}


# ============================================================================
# ProvenanceRecord model tests
# ============================================================================


class TestProvenanceRecord:
    """Tests for ProvenanceRecord pydantic model."""

    def test_creation_with_defaults(self) -> None:
        from aegis.memory.provenance import ProvenanceRecord

        rec = ProvenanceRecord(
            entry_key="test",
            source_type="document",
            source_ref="doc-1",
            operation=MemoryOperation.STORE,
        )
        assert rec.confidence == 1.0
        assert rec.parent_keys == []
        assert rec.metadata == {}

    def test_creation_with_all_fields(self) -> None:
        from aegis.memory.provenance import ProvenanceRecord

        rec = ProvenanceRecord(
            entry_key="test",
            source_type="derived",
            source_ref="parent-1",
            operation=MemoryOperation.MERGE,
            confidence=0.7,
            parent_keys=["p1", "p2"],
            metadata={"note": "merged entry"},
        )
        assert rec.confidence == 0.7
        assert rec.parent_keys == ["p1", "p2"]
        assert rec.metadata["note"] == "merged entry"


# ============================================================================
# Edge cases and integration-style tests
# ============================================================================


class TestEdgeCases:
    """Additional edge case tests for various modules."""

    def test_decay_compute_with_zero_age(self) -> None:
        """Zero age should give confidence ~1.0 (no time passed)."""
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        result = engine.compute_decay(0.0, 0, 1.0)
        assert result == pytest.approx(1.0)

    def test_decay_compute_negative_access_count_treated_as_zero(self) -> None:
        from aegis.memory.decay import DecayConfig, DecayEngine, DecayFunction

        cfg = DecayConfig(function=DecayFunction.EXPONENTIAL, rate=0.001)
        engine = DecayEngine(cfg)
        # Negative access count is clamped to 0 via max(access_count, 0)
        result = engine.compute_decay(3600, -5, 1.0)
        result_zero = engine.compute_decay(3600, 0, 1.0)
        assert result == pytest.approx(result_zero)

    def test_architecture_search_min_population_size(self) -> None:
        """Population size is clamped to minimum 4."""
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(population_size=1)
        assert engine._population_size == 4

    def test_architecture_search_mutation_rate_clamped(self) -> None:
        """Mutation rate is clamped to [0, 1]."""
        from aegis.memory.architecture_search import ArchitectureSearchEngine

        engine = ArchitectureSearchEngine(mutation_rate=2.0)
        assert engine._mutation_rate == 1.0
        engine2 = ArchitectureSearchEngine(mutation_rate=-0.5)
        assert engine2._mutation_rate == 0.0

    def test_multi_agent_relevance_check_edge_cases(self) -> None:
        from aegis.memory.multi_agent import MultiAgentMemory

        assert MultiAgentMemory._relevance_check("key", None) is False
        assert MultiAgentMemory._relevance_check("key", "") is False
        assert MultiAgentMemory._relevance_check("key", "   ") is False
        assert MultiAgentMemory._relevance_check("key", "valid content") is True
        # Short key and short value
        assert MultiAgentMemory._relevance_check("k", "v") is False
        # Short key but longer value
        assert MultiAgentMemory._relevance_check("k", "valid") is True

    def test_memory_utility_dataclass(self) -> None:
        from aegis.memory.memrl import MemoryUtility

        util = MemoryUtility(key="test")
        assert util.q_value == 0.5
        assert util.access_count == 0
        assert util.useful_count == 0
        assert util.last_feedback == 0.0
        assert util.history == []

    def test_feedback_record_dataclass(self) -> None:
        from aegis.memory.memrl import FeedbackRecord

        rec = FeedbackRecord()
        assert rec.id == ""
        assert rec.memory_key == ""
        assert rec.operation == ""
        assert rec.feedback_score == 0.0
        assert rec.context == {}

    def test_interaction_experience_dataclass(self) -> None:
        from aegis.memory.memrl import InteractionExperience

        exp = InteractionExperience()
        assert exp.query == ""
        assert exp.retrieved_keys == []
        assert exp.outcome_score == 0.0
        assert exp.memory_ops_performed == []
        assert exp.context == {}
        assert len(exp.id) > 0  # UUID generated

    def test_share_event_dataclass(self) -> None:
        from aegis.memory.multi_agent import ShareEvent

        event = ShareEvent(
            from_agent="agent-a",
            to_namespace="ns-1",
            key="k1",
            operation=MemoryOperation.STORE,
        )
        assert event.accepted is True
        assert event.from_agent == "agent-a"

    def test_shared_memory_namespace_dataclass(self) -> None:
        from aegis.memory.multi_agent import SharedMemoryNamespace

        ns = SharedMemoryNamespace(namespace_id="ns-1", name="test")
        assert ns.access_policy == "read_write"
        assert ns.agents == []

    def test_agent_profile_dataclass(self) -> None:
        from aegis.memory.multi_agent import AgentProfile

        profile = AgentProfile(agent_id="a1", name="Agent 1")
        assert profile.domain == "general"
        assert profile.trust_score == 0.5
        assert profile.capabilities == []
        assert profile.metadata == {}

    def test_architecture_candidate_dataclass(self) -> None:
        from aegis.memory.architecture_search import ArchitectureCandidate, MemoryArchitecture

        cand = ArchitectureCandidate(architecture=MemoryArchitecture())
        assert cand.eval_scores == {}
        assert cand.generation == 0
