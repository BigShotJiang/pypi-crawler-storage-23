# ruff: noqa
"""Comprehensive tests for advanced training modules.

Covers:
- architecture_discovery.py: MemoryArchitecture, ArchitectureLibrary, ArchitectureDiscoveryEngine
- multi_agent.py: AgentProfile, SharedKnowledge, RelevanceFilter, ConflictResolver,
                  DivisionOfLabor, DeferencePolicy, MultiAgentCoordinator
- levels.py: TrainingLevel, TrainingLevelManager, TRAINING_LEVELS
- transfer.py: TransferEdge, TransferGraph, TransferConfig, TransferProtocol,
               TransferLearningGraph, CrossDomainTransferManager

All tests avoid importing torch, verl, transformers, or any GPU libraries.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest


# ============================================================================
# architecture_discovery.py tests
# ============================================================================


class TestHelperFunctions:
    """Test helper functions in architecture_discovery module."""

    def test_det_float_deterministic(self) -> None:
        from aegis.training.architecture_discovery import _det_float

        result1 = _det_float("test-seed")
        result2 = _det_float("test-seed")
        assert result1 == result2

    def test_det_float_range(self) -> None:
        from aegis.training.architecture_discovery import _det_float

        for seed in ["a", "b", "c", "xyz", "hello"]:
            val = _det_float(seed, 0.0, 1.0)
            assert 0.0 <= val <= 1.0

        val = _det_float("something", 5.0, 10.0)
        assert 5.0 <= val <= 10.0

    def test_det_int_deterministic(self) -> None:
        from aegis.training.architecture_discovery import _det_int

        result1 = _det_int("test-seed", 0, 10)
        result2 = _det_int("test-seed", 0, 10)
        assert result1 == result2
        assert 0 <= result1 <= 10

    def test_det_choice_deterministic(self) -> None:
        from aegis.training.architecture_discovery import _det_choice

        options = ["a", "b", "c", "d"]
        result1 = _det_choice("seed", options)
        result2 = _det_choice("seed", options)
        assert result1 == result2
        assert result1 in options

    def test_det_choice_empty(self) -> None:
        from aegis.training.architecture_discovery import _det_choice

        assert _det_choice("seed", []) is None

    def test_det_sample_deterministic(self) -> None:
        from aegis.training.architecture_discovery import _det_sample

        options = ["a", "b", "c", "d", "e"]
        result1 = _det_sample("seed", options, 3)
        result2 = _det_sample("seed", options, 3)
        assert result1 == result2
        assert len(result1) == 3
        assert all(r in options for r in result1)
        # No duplicates
        assert len(set(result1)) == 3

    def test_det_sample_empty(self) -> None:
        from aegis.training.architecture_discovery import _det_sample

        assert _det_sample("seed", [], 3) == []
        assert _det_sample("seed", ["a"], 0) == []
        assert _det_sample("seed", ["a"], -1) == []

    def test_det_sample_k_exceeds_options(self) -> None:
        from aegis.training.architecture_discovery import _det_sample

        result = _det_sample("seed", ["a", "b"], 5)
        assert len(result) == 2
        assert set(result) == {"a", "b"}


class TestMemoryArchitecture:
    """Test the MemoryArchitecture dataclass."""

    def test_default_construction(self) -> None:
        from aegis.training.architecture_discovery import MemoryArchitecture

        arch = MemoryArchitecture()
        assert arch.id.startswith("arch-")
        assert arch.name == ""
        assert arch.domain == "general"
        assert arch.fitness_score == 0.0
        assert arch.generation == 0
        assert arch.parent_ids == []
        assert isinstance(arch.created_at, datetime)

    def test_custom_construction(self) -> None:
        from aegis.training.architecture_discovery import MemoryArchitecture

        arch = MemoryArchitecture(
            id="arch-test",
            name="test-arch",
            domain="legal",
            schema_code="schema = {}",
            retrieval_code="def retrieve(): pass",
            update_rules_code="def update(): pass",
            fitness_score=0.85,
            generation=3,
            parent_ids=["arch-parent1"],
            metadata={"key": "val"},
        )
        assert arch.id == "arch-test"
        assert arch.domain == "legal"
        assert arch.fitness_score == 0.85
        assert arch.generation == 3

    def test_to_dict(self) -> None:
        from aegis.training.architecture_discovery import MemoryArchitecture

        arch = MemoryArchitecture(
            id="arch-001",
            name="test",
            domain="finance",
            schema_code="s",
            retrieval_code="r",
            update_rules_code="u",
            fitness_score=0.7123456789,
            generation=2,
            parent_ids=["p1"],
            metadata={"emphasis": "numerical_precision"},
        )
        d = arch.to_dict()
        assert d["id"] == "arch-001"
        assert d["domain"] == "finance"
        assert d["fitness_score"] == 0.712346  # rounded to 6 decimals
        assert d["generation"] == 2
        assert d["parent_ids"] == ["p1"]
        assert isinstance(d["created_at"], str)

    def test_code_fingerprint_deterministic(self) -> None:
        from aegis.training.architecture_discovery import MemoryArchitecture

        arch = MemoryArchitecture(
            schema_code="schema1",
            retrieval_code="retrieval1",
            update_rules_code="update1",
        )
        fp1 = arch.code_fingerprint()
        fp2 = arch.code_fingerprint()
        assert fp1 == fp2
        assert len(fp1) == 16

    def test_code_fingerprint_differs(self) -> None:
        from aegis.training.architecture_discovery import MemoryArchitecture

        arch1 = MemoryArchitecture(schema_code="a", retrieval_code="b", update_rules_code="c")
        arch2 = MemoryArchitecture(schema_code="x", retrieval_code="y", update_rules_code="z")
        assert arch1.code_fingerprint() != arch2.code_fingerprint()


class TestArchitectureLibrary:
    """Test the ArchitectureLibrary class."""

    def test_add_and_get(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        arch = MemoryArchitecture(id="arch-1", domain="legal", fitness_score=0.7)
        lib.add(arch)
        assert lib.get("arch-1") is arch
        assert lib.get("nonexistent") is None

    def test_search_by_domain(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(MemoryArchitecture(id="a1", domain="legal", fitness_score=0.5))
        lib.add(MemoryArchitecture(id="a2", domain="legal", fitness_score=0.9))
        lib.add(MemoryArchitecture(id="a3", domain="finance", fitness_score=0.8))

        results = lib.search("legal", top_k=5)
        assert len(results) == 2
        # Should be sorted by fitness descending
        assert results[0].id == "a2"
        assert results[1].id == "a1"

    def test_search_includes_general_fallback(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(MemoryArchitecture(id="g1", domain="general", fitness_score=0.6))
        lib.add(MemoryArchitecture(id="l1", domain="legal", fitness_score=0.5))

        results = lib.search("legal", top_k=5)
        ids = [r.id for r in results]
        assert "g1" in ids
        assert "l1" in ids

    def test_search_general_domain_no_double_inclusion(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(MemoryArchitecture(id="g1", domain="general", fitness_score=0.6))

        results = lib.search("general", top_k=5)
        assert len(results) == 1

    def test_search_empty_domain(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureLibrary

        lib = ArchitectureLibrary()
        results = lib.search("nonexistent")
        assert results == []

    def test_get_closest(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(
            MemoryArchitecture(
                id="a1",
                domain="legal",
                fitness_score=0.8,
                metadata={"emphasis": "doc_versioning", "scale": "large"},
            )
        )
        lib.add(
            MemoryArchitecture(
                id="a2",
                domain="legal",
                fitness_score=0.6,
                metadata={"emphasis": "temporal_ordering", "scale": "small"},
            )
        )

        result = lib.get_closest("legal", {"emphasis": "doc_versioning", "scale": "large"})
        assert result is not None

    def test_get_closest_empty(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureLibrary

        lib = ArchitectureLibrary()
        result = lib.get_closest("legal", {"emphasis": "anything"})
        assert result is None

    def test_all_architectures(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(MemoryArchitecture(id="a1"))
        lib.add(MemoryArchitecture(id="a2"))
        assert len(lib.all_architectures()) == 2

    def test_summary(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureLibrary,
            MemoryArchitecture,
        )

        lib = ArchitectureLibrary()
        lib.add(MemoryArchitecture(id="a1", domain="legal", fitness_score=0.8, generation=1))
        lib.add(MemoryArchitecture(id="a2", domain="legal", fitness_score=0.6, generation=2))
        lib.add(MemoryArchitecture(id="a3", domain="finance", fitness_score=0.7, generation=0))

        summary = lib.summary()
        assert summary["total_architectures"] == 3
        assert "legal" in summary["domains"]
        assert "finance" in summary["domains"]
        assert summary["domain_counts"]["legal"] == 2
        assert summary["max_generation"] == 2
        assert summary["generation_log_entries"] == 3


class TestArchitectureDiscoveryEngine:
    """Test the ArchitectureDiscoveryEngine class."""

    def test_default_init_seeds_library(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        lib = engine.library
        all_archs = lib.all_architectures()
        assert len(all_archs) >= 4  # At least one per domain pattern

    def test_custom_seed_architectures(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureDiscoveryEngine,
            MemoryArchitecture,
        )

        seeds = [MemoryArchitecture(id="seed1", domain="test", fitness_score=0.5)]
        engine = ArchitectureDiscoveryEngine(seed_architectures=seeds)
        assert engine.library.get("seed1") is not None
        # Should NOT have default seeded archs
        assert len(engine.library.all_architectures()) == 1

    def test_propose_basic(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("legal", {"retrieval_heavy": 0.5, "update_heavy": 0.3})
        assert arch.domain == "legal"
        assert arch.fitness_score == 0.0  # Not yet evaluated
        assert "proposed" in arch.name

    def test_propose_multi_hop(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("finance", {"multi_hop": 0.7, "scale": "large"})
        assert arch.metadata["schema_type"] == "graph_memory"

    def test_propose_temporal_emphasis(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("general", {"temporal_emphasis": 0.8, "multi_hop": 0.1})
        assert arch.metadata["schema_type"] == "temporal_buffer"

    def test_propose_retrieval_heavy(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose(
            "general",
            {"retrieval_heavy": 0.75, "temporal_emphasis": 0.1, "multi_hop": 0.1},
        )
        assert arch.metadata["retrieval_type"] == "iterative_deepening"

    def test_propose_update_heavy(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("general", {"update_heavy": 0.7})
        assert arch.metadata["update_type"] == "versioned_append"

    def test_propose_conflict_prone(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("general", {"conflict_prone": 0.5, "update_heavy": 0.3})
        assert arch.metadata["update_type"] == "merge_with_conflict"

    def test_propose_multi_source(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("general", {"multi_source": 0.6, "update_heavy": 0.3})
        assert arch.metadata["update_type"] == "consensus_based"

    def test_evaluate_empty_tasks(self) -> None:
        from aegis.training.architecture_discovery import (
            ArchitectureDiscoveryEngine,
            MemoryArchitecture,
        )

        engine = ArchitectureDiscoveryEngine()
        arch = MemoryArchitecture()
        assert engine.evaluate(arch, []) == 0.0

    def test_evaluate_basic(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("legal", {"retrieval_heavy": 0.5})
        tasks = [
            {
                "type": "contract_review",
                "difficulty": 3,
                "domain": "legal",
                "operations_required": ["STORE", "RETRIEVE"],
            },
            {
                "type": "citation_verification",
                "difficulty": 2,
                "domain": "legal",
                "operations_required": ["VERIFY"],
            },
        ]
        fitness = engine.evaluate(arch, tasks)
        assert 0.0 <= fitness <= 1.0
        assert arch.fitness_score == fitness
        assert "num_tasks" in arch.eval_results

    def test_evaluate_caching(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("legal", {"retrieval_heavy": 0.5})
        tasks = [{"type": "general", "difficulty": 2, "operations_required": []}]
        fitness1 = engine.evaluate(arch, tasks)
        fitness2 = engine.evaluate(arch, tasks)
        assert fitness1 == fitness2

    def test_evaluate_with_domain_bonus(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("legal", {"retrieval_heavy": 0.5})
        tasks = [
            {"type": "general", "difficulty": 3, "domain": "legal", "operations_required": []},
        ]
        engine.evaluate(arch, tasks)
        assert arch.eval_results["num_tasks"] == 1

    def test_evaluate_complex_ops(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        arch = engine.propose("legal", {"retrieval_heavy": 0.5})
        arch.metadata["schema_type"] = "graph_memory"
        tasks = [
            {
                "type": "multi_step_reasoning",
                "difficulty": 4,
                "domain": "legal",
                "operations_required": ["SPLIT", "MERGE", "LINK"],
            },
        ]
        fitness = engine.evaluate(arch, tasks)
        assert 0.0 <= fitness <= 1.0

    def test_evolve(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        parent = engine.propose("legal", {"retrieval_heavy": 0.5})
        parent.fitness_score = 0.7

        child = engine.evolve(parent, mutation_rate=1.0)
        assert child.domain == parent.domain
        assert child.generation == parent.generation + 1
        assert parent.id in child.parent_ids
        assert "mutations" in child.metadata

    def test_evolve_low_mutation_rate_forces_tweak(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        parent = engine.propose("legal", {"retrieval_heavy": 0.5})
        # Mutation rate of 0.0 means nothing will mutate, but a tweak is forced
        child = engine.evolve(parent, mutation_rate=0.0)
        mutations = child.metadata.get("mutations", [])
        assert len(mutations) >= 1
        assert any("tuned" in m for m in mutations)

    def test_crossover(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        parent_a = engine.propose("legal", {"retrieval_heavy": 0.5})
        parent_a.fitness_score = 0.7
        parent_a.eval_results = {
            "schema_quality": 0.8,
            "retrieval_quality": 0.6,
            "update_quality": 0.7,
        }

        parent_b = engine.propose("legal", {"retrieval_heavy": 0.3})
        parent_b.fitness_score = 0.6
        parent_b.eval_results = {
            "schema_quality": 0.5,
            "retrieval_quality": 0.9,
            "update_quality": 0.4,
        }

        child = engine._crossover(parent_a, parent_b, "test-seed")
        assert child.domain == parent_a.domain
        assert child.generation == max(parent_a.generation, parent_b.generation) + 1
        assert len(child.parent_ids) == 2
        assert child.metadata.get("crossover") is True

    def test_search_returns_best(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        best = engine.search("legal", generations=2, population_size=4)
        assert best.fitness_score > 0.0
        assert best.domain == "legal" or best.domain == "general"

    def test_search_logs_run(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        engine.search("finance", generations=1, population_size=4)
        summary = engine.summary()
        assert summary["search_runs"] >= 1
        assert len(summary["search_history"]) >= 1

    def test_generate_eval_tasks(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        tasks = engine._generate_eval_tasks("legal", count=10)
        assert len(tasks) == 10
        for task in tasks:
            assert "type" in task
            assert "domain" in task
            assert "difficulty" in task
            assert "operations_required" in task
            assert task["domain"] == "legal"

    def test_generate_eval_tasks_unknown_domain(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        tasks = engine._generate_eval_tasks("unknown_domain", count=5)
        assert len(tasks) == 5

    def test_cross_domain_transfer(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        transferred = engine.cross_domain_transfer("legal", "finance")
        assert transferred.domain == "finance"
        assert transferred.fitness_score > 0.0
        assert transferred.metadata.get("transfer_source") == "legal"
        assert transferred.metadata.get("transfer_target") == "finance"

    def test_cross_domain_transfer_same_domain(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        result = engine.cross_domain_transfer("legal", "legal")
        assert result.domain == "legal"
        # Same domain affinity is 1.0 -> high affinity path

    def test_compute_domain_affinity_same(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        assert engine._compute_domain_affinity("legal", "legal") == 1.0

    def test_compute_domain_affinity_known_pair(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        assert engine._compute_domain_affinity("legal", "finance") == 0.55

    def test_compute_domain_affinity_unknown_pair(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        result = engine._compute_domain_affinity("xyzzy", "plugh")
        assert 0.2 <= result <= 0.5

    def test_summary(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        summary = engine.summary()
        assert "library" in summary
        assert "search_runs" in summary
        assert "evaluation_cache_size" in summary

    def test_compute_schema_fitness_bonuses(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        # Test graph_memory bonus for multi_step_reasoning
        score = engine._compute_schema_fitness("graph_memory", "multi_step_reasoning", [], "seed1")
        assert score > 0.7  # base 0.70 + 0.15 bonus

    def test_compute_retrieval_fitness_bonuses(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        # High difficulty + iterative_deepening
        score = engine._compute_retrieval_fitness("iterative_deepening", "general", 5, "seed1")
        assert score > 0.7

        # Low difficulty + simple_lookup
        score = engine._compute_retrieval_fitness("simple_lookup", "general", 1, "seed1")
        assert score > 0.5

    def test_compute_update_fitness_bonuses(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        # conflict_resolution + merge_with_conflict
        score = engine._compute_update_fitness(
            "merge_with_conflict", "conflict_resolution", ["UPDATE", "MERGE"], "seed1"
        )
        assert score > 0.7


# ============================================================================
# multi_agent.py tests
# ============================================================================


class TestAgentProfile:
    """Test the AgentProfile dataclass."""

    def test_default_construction(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile()
        assert profile.trust_score == 0.5
        assert profile.success_rate == 0.5
        assert profile.interaction_count == 0
        assert isinstance(profile.agent_id, str)

    def test_expertise_in_known_domain(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(
            expertise_scores={"legal": 0.9, "finance": 0.7},
            domains=["legal", "finance"],
        )
        assert profile.expertise_in("legal") == 0.9
        assert profile.expertise_in("finance") == 0.7

    def test_expertise_in_listed_domain_no_score(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(domains=["healthcare"])
        assert profile.expertise_in("healthcare") == 0.5

    def test_expertise_in_unknown_domain(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile()
        assert profile.expertise_in("unknown") == 0.1

    def test_effective_trust_no_history(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(
            trust_score=0.8,
            expertise_scores={"legal": 0.9},
            interaction_count=3,
        )
        # 0.6 * 0.8 + 0.4 * 0.9 = 0.48 + 0.36 = 0.84
        trust = profile.effective_trust("legal")
        assert abs(trust - 0.84) < 1e-6

    def test_effective_trust_with_history(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(
            trust_score=0.8,
            expertise_scores={"legal": 0.9},
            interaction_count=10,
            success_rate=0.95,
        )
        # base = 0.6 * 0.8 + 0.4 * 0.9 = 0.84
        # adjusted = 0.84 * 0.7 + 0.95 * 0.3 = 0.588 + 0.285 = 0.873
        trust = profile.effective_trust("legal")
        assert abs(trust - 0.873) < 1e-6

    def test_effective_trust_clamped(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(
            trust_score=1.0, expertise_scores={"x": 1.0}, interaction_count=10, success_rate=1.0
        )
        trust = profile.effective_trust("x")
        assert 0.0 <= trust <= 1.0

    def test_to_dict(self) -> None:
        from aegis.training.multi_agent import AgentProfile

        profile = AgentProfile(
            agent_id="agent-1",
            name="Agent One",
            domains=["legal"],
            trust_score=0.75,
        )
        d = profile.to_dict()
        assert d["agent_id"] == "agent-1"
        assert d["name"] == "Agent One"
        assert d["trust_score"] == 0.75
        assert isinstance(d["last_active"], str)


class TestSharedKnowledge:
    """Test the SharedKnowledge dataclass and methods."""

    def test_add_entry(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        entry_id = sk.add_entry({"fact": "test"}, "agent-1", confidence=0.9)
        assert isinstance(entry_id, str)
        assert len(sk.entries) == 1
        assert "agent-1" in sk.contributors

    def test_add_entry_confidence_clamped(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"fact": "over"}, "a1", confidence=1.5)
        sk.add_entry({"fact": "under"}, "a2", confidence=-0.5)
        assert sk.entries[0]["confidence"] == 1.0
        assert sk.entries[1]["confidence"] == 0.0

    def test_conflict_detection(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"revenue": "$100M", "year": "2024"}, "agent-1")
        sk.add_entry({"revenue": "$110M", "year": "2024"}, "agent-2")

        conflicts = sk.get_unresolved_conflicts()
        assert len(conflicts) == 1
        assert "revenue" in conflicts[0]["conflicting_keys"]

    def test_no_conflict_for_same_values(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"revenue": "$100M"}, "agent-1")
        sk.add_entry({"revenue": "$100M"}, "agent-2")
        assert len(sk.get_unresolved_conflicts()) == 0

    def test_no_conflict_for_different_keys(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"revenue": "$100M"}, "agent-1")
        sk.add_entry({"profit": "$50M"}, "agent-2")
        assert len(sk.get_unresolved_conflicts()) == 0

    def test_resolve_conflict(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"revenue": "$100M"}, "agent-1")
        sk.add_entry({"revenue": "$110M"}, "agent-2")

        conflicts = sk.get_unresolved_conflicts()
        assert len(conflicts) == 1

        conflict_id = conflicts[0]["id"]
        entry_a_id = conflicts[0]["entry_a_id"]
        entry_b_id = conflicts[0]["entry_b_id"]

        result = sk.resolve_conflict(
            conflict_id,
            {
                "winning_entry_id": entry_b_id,
                "superseded_entry_id": entry_a_id,
                "reason": "More recent data",
            },
        )
        assert result is True
        assert len(sk.get_unresolved_conflicts()) == 0

        # Check that the losing entry is superseded
        for entry in sk.entries:
            if entry["id"] == entry_a_id:
                assert entry["superseded_by"] == entry_b_id

    def test_resolve_conflict_nonexistent(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        result = sk.resolve_conflict("nonexistent", {})
        assert result is False

    def test_active_entries(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"revenue": "$100M"}, "agent-1")
        sk.add_entry({"revenue": "$110M"}, "agent-2")

        # Resolve to supersede first entry
        conflicts = sk.get_unresolved_conflicts()
        if conflicts:
            sk.resolve_conflict(
                conflicts[0]["id"],
                {
                    "winning_entry_id": conflicts[0]["entry_b_id"],
                    "superseded_entry_id": conflicts[0]["entry_a_id"],
                },
            )

        active = sk.active_entries()
        assert len(active) == 1  # One superseded

    def test_to_dict(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge(name="test_kb")
        sk.add_entry({"fact": "val"}, "agent-1")
        d = sk.to_dict()
        assert d["name"] == "test_kb"
        assert d["total_entries"] == 1
        assert d["active_entries"] == 1
        assert "agent-1" in d["contributors"]

    def test_conflict_with_superseded_entries_skipped(self) -> None:
        from aegis.training.multi_agent import SharedKnowledge

        sk = SharedKnowledge()
        sk.add_entry({"key": "v1"}, "a1")
        sk.add_entry({"key": "v2"}, "a2")

        conflicts = sk.get_unresolved_conflicts()
        if conflicts:
            sk.resolve_conflict(
                conflicts[0]["id"],
                {
                    "winning_entry_id": conflicts[0]["entry_b_id"],
                    "superseded_entry_id": conflicts[0]["entry_a_id"],
                },
            )

        # Adding another entry should not conflict with superseded entry
        sk.add_entry({"key": "v3"}, "a3")
        new_conflicts = sk.get_unresolved_conflicts()
        # Should only conflict with the non-superseded entry (entry_b)
        assert len(new_conflicts) <= 1


class TestRelevanceFilter:
    """Test the RelevanceFilter class."""

    def test_filter_empty_knowledge(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter()
        target = AgentProfile(domains=["legal"], expertise_scores={"legal": 0.8})
        result = rf.filter([], target)
        assert result == []

    def test_filter_domain_match(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter(relevance_threshold=0.1)
        target = AgentProfile(
            domains=["legal"],
            expertise_scores={"legal": 0.8},
            capabilities=["analysis"],
        )
        knowledge = [
            {"id": "k1", "domain": "legal", "content": {"fact": "test"}, "confidence": 0.9},
            {"id": "k2", "domain": "finance", "content": {"fact": "test2"}, "confidence": 0.5},
        ]
        result = rf.filter(knowledge, target)
        assert len(result) >= 1
        # Legal entry should have higher relevance
        for entry in result:
            assert "relevance_score" in entry

    def test_filter_caps_at_max_share_ratio(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter(relevance_threshold=0.0, max_share_ratio=0.5)
        target = AgentProfile(domains=["legal"], expertise_scores={"legal": 0.8})
        knowledge = [
            {"id": f"k{i}", "domain": "legal", "content": {"fact": f"test{i}"}, "confidence": 0.9}
            for i in range(10)
        ]
        result = rf.filter(knowledge, target)
        assert len(result) <= 5  # max_share_ratio=0.5 of 10

    def test_filter_with_tags_and_capabilities(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter(relevance_threshold=0.1)
        target = AgentProfile(
            capabilities=["contract_review", "analysis"],
            expertise_scores={"legal": 0.9},
        )
        knowledge = [
            {
                "id": "k1",
                "domain": "legal",
                "tags": ["contract_review", "compliance"],
                "content": {"fact": "test"},
                "confidence": 0.8,
                "timestamp": "2024-01-01T00:00:00Z",
            },
        ]
        result = rf.filter(knowledge, target)
        assert len(result) >= 1

    def test_filter_confidence_non_numeric(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter(relevance_threshold=0.0)
        target = AgentProfile()
        knowledge = [
            {"id": "k1", "content": {"a": "b"}, "confidence": "not-a-number"},
        ]
        result = rf.filter(knowledge, target)
        # Should not crash; falls back to 0.5
        assert len(result) >= 0

    def test_summary(self) -> None:
        from aegis.training.multi_agent import AgentProfile, RelevanceFilter

        rf = RelevanceFilter()
        target = AgentProfile(domains=["legal"], expertise_scores={"legal": 0.8})
        rf.filter(
            [{"id": "k1", "domain": "legal", "content": {"f": "v"}, "confidence": 0.9}],
            target,
        )
        summary = rf.summary()
        assert summary["filter_events"] == 1
        assert "total_knowledge_evaluated" in summary


class TestConflictResolver:
    """Test the ConflictResolver class."""

    def test_resolve_by_confidence(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.9,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "confidence"}
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"
        assert result["confidence"] > 0.5

    def test_resolve_by_evidence(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": ["e1", "e2", "e3"],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": ["e1"],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "evidence"}
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_recency(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "2024-06-01T00:00:00Z",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "2024-01-01T00:00:00Z",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "recency"}
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_recency_only_one_has_timestamp(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "2024-06-01",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "recency"}
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_recency_no_timestamps(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "recency"}
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "tie" or result["winner"] in ("a", "b")

    def test_resolve_by_expertise(self) -> None:
        from aegis.training.multi_agent import AgentProfile, ConflictResolver

        resolver = ConflictResolver()
        profile_a = AgentProfile(agent_id="a1", expertise_scores={"legal": 0.9})
        profile_b = AgentProfile(agent_id="a2", expertise_scores={"legal": 0.3})

        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {
            "domain": "legal",
            "agent_profiles": {"a1": profile_a, "a2": profile_b},
            "resolution_strategy": "expertise",
        }
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_expertise_dict_profiles(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {
            "domain": "legal",
            "agent_profiles": {
                "a1": {"expertise_scores": {"legal": 0.9}},
                "a2": {"expertise_scores": {"legal": 0.3}},
            },
            "resolution_strategy": "expertise",
        }
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_consensus(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {
            "domain": "general",
            "agent_profiles": {},
            "resolution_strategy": "consensus",
            "other_opinions": [
                {"value": "A", "confidence": 0.8},
                {"value": "A", "confidence": 0.7},
                {"value": "B", "confidence": 0.6},
            ],
        }
        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] == "a"

    def test_resolve_by_consensus_no_opinions(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.5,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}, "resolution_strategy": "consensus"}
        result = resolver.resolve(claim_a, claim_b, context)
        # With no opinions, result is tie
        assert result["winner"] == "tie" or result["winner"] in ("a", "b")

    def test_resolve_aggregated_all_strategies(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.9,
            "evidence": ["e1", "e2"],
            "timestamp": "2024-06-01",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.3,
            "evidence": [],
            "timestamp": "2024-01-01",
            "agent_id": "a2",
        }
        context = {"domain": "general", "agent_profiles": {}}

        result = resolver.resolve(claim_a, claim_b, context)
        assert result["winner"] in ("a", "b", "tie")
        assert "vote_details" in result
        assert "merged_value" in result
        assert result["merged_value"]["conflict_noted"] is True

    def test_summary(self) -> None:
        from aegis.training.multi_agent import ConflictResolver

        resolver = ConflictResolver()
        claim_a = {
            "value": "A",
            "confidence": 0.9,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a1",
        }
        claim_b = {
            "value": "B",
            "confidence": 0.3,
            "evidence": [],
            "timestamp": "",
            "agent_id": "a2",
        }
        resolver.resolve(claim_a, claim_b, {"domain": "general", "agent_profiles": {}})

        summary = resolver.summary()
        assert summary["total_resolutions"] == 1
        assert "winner_distribution" in summary
        assert summary["mean_confidence"] > 0


class TestDivisionOfLabor:
    """Test the DivisionOfLabor class."""

    def test_assign_empty_agents_raises(self) -> None:
        from aegis.training.multi_agent import DivisionOfLabor

        dol = DivisionOfLabor()
        with pytest.raises(ValueError, match="no agents available"):
            dol.assign({"domain": "legal"}, [])

    def test_assign_single_agent(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agent = AgentProfile(agent_id="a1", domains=["legal"])
        result = dol.assign({"domain": "legal"}, [agent])
        assert result.agent_id == "a1"

    def test_assign_best_expertise(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agent_a = AgentProfile(agent_id="a1", expertise_scores={"legal": 0.9}, trust_score=0.8)
        agent_b = AgentProfile(agent_id="a2", expertise_scores={"legal": 0.3}, trust_score=0.8)

        result = dol.assign(
            {"domain": "legal", "required_capabilities": [], "difficulty": 3},
            [agent_a, agent_b],
        )
        assert result.agent_id == "a1"

    def test_assign_capability_matching(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agent_a = AgentProfile(
            agent_id="a1",
            expertise_scores={"legal": 0.5},
            capabilities=["contract_review"],
        )
        agent_b = AgentProfile(
            agent_id="a2",
            expertise_scores={"legal": 0.5},
            capabilities=["document_search", "analysis"],
        )

        result = dol.assign(
            {"domain": "legal", "required_capabilities": ["contract_review"], "difficulty": 3},
            [agent_a, agent_b],
        )
        assert result.agent_id == "a1"

    def test_assign_subtasks_empty_agents_raises(self) -> None:
        from aegis.training.multi_agent import DivisionOfLabor

        dol = DivisionOfLabor()
        with pytest.raises(ValueError, match="no agents available"):
            dol.assign_subtasks({"domain": "legal"}, [])

    def test_assign_subtasks_with_explicit_subtasks(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agents = [
            AgentProfile(agent_id="a1", expertise_scores={"legal": 0.8}),
            AgentProfile(agent_id="a2", expertise_scores={"legal": 0.5}),
        ]
        task = {
            "domain": "legal",
            "subtasks": [
                {
                    "domain": "legal",
                    "type": "analysis",
                    "difficulty": 2,
                    "required_capabilities": [],
                },
                {
                    "domain": "legal",
                    "type": "retrieval",
                    "difficulty": 2,
                    "required_capabilities": [],
                },
            ],
        }
        result = dol.assign_subtasks(task, agents)
        assert len(result) == 2
        assert all(isinstance(r, tuple) for r in result)

    def test_assign_subtasks_decompose(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agents = [AgentProfile(agent_id="a1", expertise_scores={"legal": 0.8})]
        task = {"domain": "legal", "type": "multi_source_retrieval", "difficulty": 3}
        result = dol.assign_subtasks(task, agents)
        assert len(result) == 3  # multi_source_retrieval decomposes into 3

    def test_decompose_unknown_type(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agents = [AgentProfile(agent_id="a1")]
        task = {"domain": "legal", "type": "unknown_type", "difficulty": 2}
        result = dol.assign_subtasks(task, agents)
        assert len(result) == 3  # Falls back to default 3 subtasks

    def test_summary(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        agent = AgentProfile(agent_id="a1")
        dol.assign({"domain": "legal", "type": "analysis"}, [agent])
        summary = dol.summary()
        assert summary["total_assignments"] == 1
        assert summary["agent_load"]["a1"] == 1

    def test_difficulty_penalty_low_expertise(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DivisionOfLabor

        dol = DivisionOfLabor()
        # Low-expertise agent on hard task
        agent_low = AgentProfile(agent_id="low", expertise_scores={"legal": 0.2}, trust_score=0.5)
        agent_high = AgentProfile(agent_id="high", expertise_scores={"legal": 0.8}, trust_score=0.5)
        result = dol.assign(
            {"domain": "legal", "difficulty": 5, "required_capabilities": []},
            [agent_low, agent_high],
        )
        assert result.agent_id == "high"


class TestDeferencePolicy:
    """Test the DeferencePolicy class."""

    def test_no_deference_high_confidence(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DeferencePolicy

        dp = DeferencePolicy(confidence_threshold=0.4, expertise_gap_threshold=0.25)
        agents = [AgentProfile(agent_id="expert", expertise_scores={"legal": 0.9})]
        result = dp.should_defer({"domain": "legal"}, 0.8, agents)
        assert result is None

    def test_no_deference_no_agents(self) -> None:
        from aegis.training.multi_agent import DeferencePolicy

        dp = DeferencePolicy()
        result = dp.should_defer({"domain": "legal"}, 0.2, [])
        assert result is None

    def test_deference_low_confidence_high_gap(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DeferencePolicy

        dp = DeferencePolicy(confidence_threshold=0.4, expertise_gap_threshold=0.2)
        expert = AgentProfile(
            agent_id="expert",
            expertise_scores={"legal": 0.95},
            trust_score=0.9,
        )
        result = dp.should_defer({"domain": "legal", "difficulty": 3}, 0.2, [expert])
        assert result is not None
        assert result.agent_id == "expert"

    def test_deference_very_large_gap(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DeferencePolicy

        dp = DeferencePolicy(confidence_threshold=0.4, expertise_gap_threshold=0.2)
        expert = AgentProfile(
            agent_id="expert",
            expertise_scores={"legal": 0.95},
            trust_score=0.9,
        )
        # Moderate confidence but very large gap (gap >= threshold * 2)
        result = dp.should_defer({"domain": "legal", "difficulty": 3}, 0.45, [expert])
        # The gap has to be >= 0.4 (threshold * 2) which depends on effective score
        if result is not None:
            assert result.agent_id == "expert"

    def test_deference_hard_task(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DeferencePolicy

        dp = DeferencePolicy(confidence_threshold=0.4, expertise_gap_threshold=0.25)
        expert = AgentProfile(
            agent_id="expert",
            expertise_scores={"legal": 0.9},
            trust_score=0.8,
        )
        result = dp.should_defer({"domain": "legal", "difficulty": 5}, 0.3, [expert])
        assert result is not None
        assert result.agent_id == "expert"

    def test_summary(self) -> None:
        from aegis.training.multi_agent import AgentProfile, DeferencePolicy

        dp = DeferencePolicy()
        expert = AgentProfile(agent_id="expert", expertise_scores={"legal": 0.9})
        dp.should_defer({"domain": "legal"}, 0.2, [expert])
        summary = dp.summary()
        assert summary["total_decisions"] >= 1
        assert "reasons" in summary


class TestMultiAgentCoordinator:
    """Test the MultiAgentCoordinator class."""

    def test_register_and_get_agent(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        profile = AgentProfile(agent_id="a1", name="Agent One")
        coord.register_agent(profile)
        assert coord.get_agent("a1") is profile
        assert coord.get_agent("nonexistent") is None

    def test_update_agent(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        profile = AgentProfile(agent_id="a1", name="Agent One", trust_score=0.5)
        coord.register_agent(profile)
        result = coord.update_agent("a1", {"trust_score": 0.9, "name": "Updated Agent"})
        assert result is True
        agent = coord.get_agent("a1")
        assert agent is not None
        assert agent.trust_score == 0.9
        assert agent.name == "Updated Agent"

    def test_update_agent_nonexistent(self) -> None:
        from aegis.training.multi_agent import MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        assert coord.update_agent("nonexistent", {"trust_score": 0.9}) is False

    def test_share_knowledge(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator(relevance_threshold=0.0)
        coord.register_agent(
            AgentProfile(
                agent_id="a1",
                domains=["legal"],
                expertise_scores={"legal": 0.8},
            )
        )
        coord.register_agent(
            AgentProfile(
                agent_id="a2",
                domains=["legal"],
                expertise_scores={"legal": 0.7},
            )
        )

        knowledge = [
            {"id": "k1", "domain": "legal", "content": {"fact": "test"}, "confidence": 0.9},
        ]
        total = coord.share_knowledge("a1", knowledge)
        assert total >= 1

    def test_share_knowledge_unregistered_agent(self) -> None:
        from aegis.training.multi_agent import MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        assert coord.share_knowledge("nonexistent", [{"content": "test"}]) == 0

    def test_resolve_conflict(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        coord.register_agent(AgentProfile(agent_id="a1", expertise_scores={"legal": 0.9}))
        coord.register_agent(AgentProfile(agent_id="a2", expertise_scores={"legal": 0.3}))

        claim = {
            "domain": "legal",
            "claim_a": {
                "value": "A",
                "confidence": 0.9,
                "evidence": ["e1"],
                "timestamp": "2024-06-01",
                "agent_id": "a1",
            },
            "claim_b": {
                "value": "B",
                "confidence": 0.5,
                "evidence": [],
                "timestamp": "2024-01-01",
                "agent_id": "a2",
            },
        }
        result = coord.resolve_conflict(["a1", "a2"], claim)
        assert result["winner"] in ("a", "b", "tie")
        assert "merged_value" in result

    def test_assign_task(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        coord.register_agent(
            AgentProfile(
                agent_id="a1",
                expertise_scores={"legal": 0.9},
                trust_score=0.8,
            )
        )
        coord.register_agent(
            AgentProfile(
                agent_id="a2",
                expertise_scores={"legal": 0.3},
                trust_score=0.8,
            )
        )

        assigned = coord.assign_task({"domain": "legal", "type": "analysis", "difficulty": 3})
        assert assigned == "a1"

    def test_assign_task_no_agents_raises(self) -> None:
        from aegis.training.multi_agent import MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        with pytest.raises(ValueError, match="No agents registered"):
            coord.assign_task({"domain": "legal"})

    def test_check_deference(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator(confidence_threshold=0.4, expertise_gap_threshold=0.2)
        coord.register_agent(
            AgentProfile(
                agent_id="a1",
                expertise_scores={"legal": 0.3},
            )
        )
        coord.register_agent(
            AgentProfile(
                agent_id="expert",
                expertise_scores={"legal": 0.95},
                trust_score=0.9,
            )
        )

        result = coord.check_deference("a1", {"domain": "legal", "difficulty": 3}, 0.2)
        # Should defer to expert
        if result is not None:
            assert result == "expert"

    def test_summary(self) -> None:
        from aegis.training.multi_agent import AgentProfile, MultiAgentCoordinator

        coord = MultiAgentCoordinator()
        coord.register_agent(AgentProfile(agent_id="a1", name="Agent One"))
        summary = coord.summary()
        assert summary["registered_agents"] == 1
        assert "a1" in summary["agents"]
        assert "shared_knowledge" in summary


# ============================================================================
# levels.py tests
# ============================================================================


class TestTrainingLevel:
    """Test the TrainingLevel dataclass."""

    def test_training_levels_count(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        assert len(TRAINING_LEVELS) == 7

    def test_level_ordering(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        for i, level in enumerate(TRAINING_LEVELS):
            assert level.level_id == i + 1

    def test_level_1_no_prerequisites(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        assert TRAINING_LEVELS[0].prerequisites == []
        assert TRAINING_LEVELS[0].name == "Memory Operations"

    def test_level_7_has_prerequisites(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        level7 = TRAINING_LEVELS[6]
        assert level7.level_id == 7
        assert len(level7.prerequisites) > 0

    def test_all_levels_have_required_fields(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        for level in TRAINING_LEVELS:
            assert level.name
            assert level.description
            assert len(level.capabilities) > 0
            assert len(level.operations_unlocked) > 0
            assert len(level.eval_dimensions) > 0
            assert len(level.task_types) > 0
            assert level.min_score_to_advance > 0
            assert level.max_episodes > 0
            assert len(level.difficulty_range) == 2
            assert level.difficulty_range[0] <= level.difficulty_range[1]

    def test_difficulty_progression(self) -> None:
        from aegis.training.levels import TRAINING_LEVELS

        # Higher levels should generally have harder difficulty ranges
        for i in range(len(TRAINING_LEVELS) - 1):
            current = TRAINING_LEVELS[i]
            next_level = TRAINING_LEVELS[i + 1]
            assert next_level.difficulty_range[0] >= current.difficulty_range[0]


class TestTrainingLevelManager:
    """Test the TrainingLevelManager class."""

    def test_get_level(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        level = mgr.get_level(1)
        assert level.level_id == 1
        assert level.name == "Memory Operations"

    def test_get_level_invalid(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        with pytest.raises(KeyError):
            mgr.get_level(99)

    def test_all_levels(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        levels = mgr.all_levels()
        assert len(levels) == 7
        assert levels[0].level_id == 1
        assert levels[-1].level_id == 7

    def test_get_prerequisites(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        prereqs = mgr.get_prerequisites(1)
        assert prereqs == []

        prereqs = mgr.get_prerequisites(3)
        assert len(prereqs) == 2  # [1, 2]
        prereq_ids = [p.level_id for p in prereqs]
        assert 1 in prereq_ids
        assert 2 in prereq_ids

    def test_are_prerequisites_met(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        assert mgr.are_prerequisites_met(1, set()) is True  # No prereqs
        assert mgr.are_prerequisites_met(2, {1}) is True
        assert mgr.are_prerequisites_met(2, set()) is False
        assert mgr.are_prerequisites_met(3, {1, 2}) is True
        assert mgr.are_prerequisites_met(3, {1}) is False

    def test_get_current_level_no_scores(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        assert mgr.get_current_level({}) == 1
        assert mgr.get_current_level({"dimension_scores": {}, "overall_score": 0.0}) == 1

    def test_get_current_level_with_scores(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        # Give perfect scores for level 1 dimensions
        metrics = {
            "dimension_scores": {
                "1.1_verbatim_recall": 0.9,
                "1.2_temporal_ordering": 0.9,
                "1.3_source_attribution": 0.9,
                "1.4_update_propagation": 0.9,
                "1.5_selective_forgetting": 0.9,
            },
            "overall_score": 0.9,
        }
        level = mgr.get_current_level(metrics)
        assert level >= 2  # Should have passed level 1

    def test_get_current_level_with_completed(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        # The function returns early (level 1) if dimension_scores is empty and
        # overall_score <= 0. Provide a small overall_score so it enters the loop.
        metrics = {
            "dimension_scores": {
                "1.1_verbatim_recall": 0.3,
            },
            "overall_score": 0.3,
            "completed_levels": [1, 2, 3],
        }
        level = mgr.get_current_level(metrics)
        # completed_levels causes those levels to be counted as passed
        assert level >= 2

    def test_advance_level_not_ready(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.advance_level(
            1,
            {
                "dimension_scores": {"1.1_verbatim_recall": 0.3},
                "overall_score": 0.3,
                "episodes_at_level": 100,
            },
        )
        assert result is None

    def test_advance_level_ready(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.advance_level(
            1,
            {
                "dimension_scores": {
                    "1.1_verbatim_recall": 0.9,
                    "1.2_temporal_ordering": 0.9,
                    "1.3_source_attribution": 0.9,
                    "1.4_update_propagation": 0.9,
                    "1.5_selective_forgetting": 0.9,
                },
                "overall_score": 0.9,
                "episodes_at_level": 100,
            },
        )
        assert result == 2

    def test_advance_level_too_few_episodes(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.advance_level(
            1,
            {
                "dimension_scores": {
                    "1.1_verbatim_recall": 0.9,
                    "1.2_temporal_ordering": 0.9,
                    "1.3_source_attribution": 0.9,
                    "1.4_update_propagation": 0.9,
                    "1.5_selective_forgetting": 0.9,
                },
                "overall_score": 0.9,
                "episodes_at_level": 1,  # Too few
            },
        )
        assert result is None

    def test_advance_level_max_level(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.advance_level(
            7,
            {
                "dimension_scores": {},
                "overall_score": 0.99,
                "episodes_at_level": 1000,
            },
        )
        assert result is None  # Already at max

    def test_advance_level_invalid(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.advance_level(99, {"dimension_scores": {}, "overall_score": 0.9})
        assert result is None

    def test_advance_level_insufficient_dimensions(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        # Only one dimension scored (fewer than half of 5)
        result = mgr.advance_level(
            1,
            {
                "dimension_scores": {"1.1_verbatim_recall": 0.9},
                "overall_score": 0.3,
                "episodes_at_level": 100,
            },
        )
        assert result is None

    def test_advance_level_insufficient_dims_but_overall_high(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        # Only one dimension scored but overall score is high enough
        result = mgr.advance_level(
            1,
            {
                "dimension_scores": {"1.1_verbatim_recall": 0.9},
                "overall_score": 0.9,
                "episodes_at_level": 100,
            },
        )
        # Should advance since overall_score >= min_score_to_advance
        assert result == 2

    def test_record_score(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.record_score("agent-1", 1, 0.8)
        assert result["agent_id"] == "agent-1"
        assert result["level"] == 1
        assert result["total_scores"] == 1
        assert result["recent_mean"] == 0.8

        # Record more scores
        for _ in range(10):
            mgr.record_score("agent-1", 1, 0.75)

        result = mgr.record_score("agent-1", 1, 0.9)
        assert result["total_scores"] == 12

    def test_record_score_ready_to_advance(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        # Record enough high scores to be ready
        for _ in range(10):
            result = mgr.record_score("agent-1", 1, 0.8)

        assert result["ready_to_advance"] is True

    def test_record_score_not_ready_to_advance(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        result = mgr.record_score("agent-1", 1, 0.3)
        assert result["ready_to_advance"] is False  # Too few scores and low

    def test_get_curriculum_config(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        config = mgr.get_curriculum_config(1)
        assert config["level"] == 1
        assert config["level_name"] == "Memory Operations"
        assert "difficulty_distribution" in config
        assert "operations_unlocked" in config
        assert "learning_rate" in config
        assert config["learning_rate"] > 0

        # Check difficulty distribution sums to ~1.0
        dist = config["difficulty_distribution"]
        total = sum(dist.values())
        assert abs(total - 1.0) < 0.01

    def test_get_curriculum_config_all_levels(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        for level_id in range(1, 8):
            config = mgr.get_curriculum_config(level_id)
            assert config["level"] == level_id
            # Higher levels should have lower learning rates
            if level_id > 1:
                prev_config = mgr.get_curriculum_config(level_id - 1)
                assert config["learning_rate"] <= prev_config["learning_rate"]

    def test_generate_level_tasks(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        tasks = mgr.generate_level_tasks(1, count=5)
        assert len(tasks) == 5
        for task in tasks:
            assert task["level"] == 1
            assert "prompt" in task
            assert "difficulty" in task
            assert "operations_required" in task
            assert "eval_dimensions" in task

    def test_generate_level_tasks_all_levels(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        for level_id in range(1, 8):
            tasks = mgr.generate_level_tasks(level_id, count=3)
            assert len(tasks) == 3
            for task in tasks:
                assert task["level"] == level_id

    def test_generate_level_tasks_deterministic(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        tasks1 = mgr.generate_level_tasks(1, count=5)
        tasks2 = mgr.generate_level_tasks(1, count=5)
        # Same seeds should produce same task types and prompts
        for t1, t2 in zip(tasks1, tasks2):
            assert t1["task_type"] == t2["task_type"]
            assert t1["prompt"] == t2["prompt"]
            assert t1["difficulty"] == t2["difficulty"]

    def test_fill_template(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        level = mgr.get_level(1)
        result = mgr._fill_template(
            "Store '{fact}' from '{source}' about '{entity}'",
            "seed-123",
            level,
        )
        assert "{fact}" not in result
        assert "{source}" not in result
        assert "{entity}" not in result

    def test_summary(self) -> None:
        from aegis.training.levels import TrainingLevelManager

        mgr = TrainingLevelManager()
        mgr.record_score("agent-1", 1, 0.8)
        summary = mgr.summary()
        assert summary["total_levels"] == 7
        assert summary["agents_tracked"] == 1
        assert "agent-1" in summary["agents"]
        assert len(summary["levels"]) == 7

    def test_custom_levels(self) -> None:
        from aegis.training.levels import TrainingLevel, TrainingLevelManager

        custom = [
            TrainingLevel(
                level_id=1,
                name="Custom Level",
                description="A custom training level",
                capabilities=["cap1"],
                prerequisites=[],
                difficulty_range=(1, 2),
                operations_unlocked=["STORE"],
                eval_dimensions=["dim1"],
                task_types=["task1"],
            ),
        ]
        mgr = TrainingLevelManager(levels=custom)
        assert len(mgr.all_levels()) == 1
        assert mgr.get_level(1).name == "Custom Level"


# ============================================================================
# transfer.py tests
# ============================================================================


class TestTransferEdge:
    """Test the TransferEdge dataclass."""

    def test_construction(self) -> None:
        from aegis.training.transfer import TransferEdge

        edge = TransferEdge(
            source_domain="legal",
            target_domain="finance",
            transfer_score=0.6,
            interference_score=0.1,
            shared_skills=["retrieval", "reasoning"],
        )
        assert edge.source_domain == "legal"
        assert edge.target_domain == "finance"
        assert edge.transfer_score == 0.6
        assert edge.interference_score == 0.1
        assert len(edge.shared_skills) == 2


class TestTransferConfig:
    """Test the TransferConfig dataclass."""

    def test_defaults(self) -> None:
        from aegis.training.transfer import TransferConfig

        config = TransferConfig()
        assert config.maintenance_ratio == 0.15
        assert config.performance_threshold == 0.95
        assert config.ewc_lambda == 0.5
        assert config.interference_threshold == 0.05
        assert config.use_separate_adapter is False

    def test_custom(self) -> None:
        from aegis.training.transfer import TransferConfig

        config = TransferConfig(
            source_domain="legal",
            target_domain="finance",
            maintenance_ratio=0.2,
            performance_threshold=0.9,
        )
        assert config.source_domain == "legal"
        assert config.maintenance_ratio == 0.2


class TestTransferGraph:
    """Test the TransferGraph class."""

    def test_add_edge(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        edge = graph.add_edge("legal", "finance", 0.6, 0.1, ["retrieval"])
        assert edge.source_domain == "legal"
        assert edge.transfer_score == 0.6

    def test_get_transfer_score(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "finance", 0.6, 0.1)
        assert graph.get_transfer_score("legal", "finance") == 0.6
        assert graph.get_transfer_score("legal", "healthcare") == 0.0

    def test_get_interference(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "finance", 0.6, 0.1)
        assert graph.get_interference("legal", "finance") == 0.1
        assert graph.get_interference("legal", "healthcare") == 0.0

    def test_best_source_for(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "healthcare", 0.6, 0.1)
        graph.add_edge("finance", "healthcare", 0.8, 0.05)

        best = graph.best_source_for("healthcare")
        assert best == "finance"

    def test_best_source_for_no_edges(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        assert graph.best_source_for("legal") is None

    def test_best_source_for_single_edge(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "healthcare", 0.6, 0.1)
        assert graph.best_source_for("healthcare") == "legal"

    def test_best_source_prefers_low_interference(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "healthcare", 0.7, 0.5)  # High transfer but high interference
        graph.add_edge("finance", "healthcare", 0.7, 0.05)  # Same transfer, low interference

        best = graph.best_source_for("healthcare")
        assert best == "finance"

    def test_to_dict(self) -> None:
        from aegis.training.transfer import TransferGraph

        graph = TransferGraph()
        graph.add_edge("legal", "finance", 0.6, 0.1, ["skill1"])
        d = graph.to_dict()
        assert "legal" in d["nodes"]
        assert "finance" in d["nodes"]
        assert d["edge_count"] == 1
        assert len(d["edges"]) == 1


class TestTransferProtocol:
    """Test the TransferProtocol class."""

    def test_default_construction(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        assert protocol.graph is not None

    def test_prepare_transfer_no_interference(self) -> None:
        from aegis.training.transfer import TransferConfig, TransferProtocol

        config = TransferConfig(source_domain="legal", target_domain="finance")
        protocol = TransferProtocol(config=config)
        plan = protocol.prepare_transfer("legal", "finance")

        assert plan["source_domain"] == "legal"
        assert plan["target_domain"] == "finance"
        assert plan["maintenance_ratio"] == config.maintenance_ratio
        assert plan["recommendation"] == "shared_adapter"

    def test_prepare_transfer_high_interference(self) -> None:
        from aegis.training.transfer import TransferConfig, TransferProtocol

        config = TransferConfig(
            source_domain="legal",
            target_domain="finance",
            interference_threshold=0.05,
            separate_adapter_threshold=0.1,
        )
        protocol = TransferProtocol(config=config)
        # Add known high-interference edge
        protocol.graph.add_edge("legal", "finance", 0.3, 0.2)

        plan = protocol.prepare_transfer("legal", "finance")
        assert plan["known_interference"] == 0.2
        assert "warning" in plan
        assert plan["recommendation"] == "separate_adapter"

    def test_prepare_transfer_with_replay_buffer(self) -> None:
        from aegis.training.replay_buffer import Experience, ReplayBuffer
        from aegis.training.transfer import TransferConfig, TransferProtocol

        buf = ReplayBuffer(capacity=100)
        for i in range(10):
            buf.add(
                Experience(
                    prompt=f"legal task {i}",
                    domain="legal",
                    reward=0.7,
                    difficulty=2,
                )
            )

        config = TransferConfig(source_domain="legal", target_domain="finance")
        protocol = TransferProtocol(config=config, replay_buffer=buf)
        plan = protocol.prepare_transfer("legal", "finance")
        assert plan["maintenance_sample_count"] > 0

    def test_monitor_interference_no_scores(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        result = protocol.monitor_interference([], 0.8)
        assert result["interference_detected"] is False

    def test_monitor_interference_no_drop(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        protocol.prepare_transfer("legal", "finance")
        result = protocol.monitor_interference([0.85, 0.83, 0.84], 0.85)
        # Drop is ~0.01, below default threshold of 0.05
        assert result["interference_detected"] is False

    def test_monitor_interference_significant_drop(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        protocol.prepare_transfer("legal", "finance")
        result = protocol.monitor_interference([0.7, 0.68, 0.65], 0.85)
        assert result["interference_detected"] is True
        assert result["score_drop"] > 0.05

    def test_monitor_interference_worsening_trend(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        protocol.prepare_transfer("legal", "finance")
        # Record 3 measurements with worsening trend
        protocol.monitor_interference([0.78], 0.85)
        protocol.monitor_interference([0.75], 0.85)
        result = protocol.monitor_interference([0.70], 0.85)
        assert result["trend"] == "worsening"

    def test_build_mixed_curriculum_empty_tasks(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        result = protocol.build_mixed_curriculum("legal", "finance", [])
        assert result == []

    def test_build_mixed_curriculum_no_replay(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        target_tasks = [
            {"id": f"t{i}", "prompt": f"finance task {i}", "difficulty": 2} for i in range(10)
        ]
        mixed = protocol.build_mixed_curriculum("legal", "finance", target_tasks)
        assert len(mixed) > len(target_tasks)  # Should have maintenance tasks added
        # Check maintenance tasks are present
        maintenance_tasks = [t for t in mixed if t.get("is_maintenance")]
        assert len(maintenance_tasks) > 0

    def test_build_mixed_curriculum_with_replay(self) -> None:
        from aegis.training.replay_buffer import Experience, ReplayBuffer
        from aegis.training.transfer import TransferProtocol

        buf = ReplayBuffer(capacity=100)
        for i in range(10):
            buf.add(Experience(prompt=f"legal task {i}", domain="legal", reward=0.7, difficulty=2))

        protocol = TransferProtocol(replay_buffer=buf)
        target_tasks = [
            {"id": f"t{i}", "prompt": f"finance task {i}", "difficulty": 2} for i in range(10)
        ]
        mixed = protocol.build_mixed_curriculum("legal", "finance", target_tasks)
        assert len(mixed) > len(target_tasks)

    def test_should_separate_adapter_empty(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        assert protocol.should_separate_adapter([]) is False

    def test_should_separate_adapter_high_mean(self) -> None:
        from aegis.training.transfer import TransferConfig, TransferProtocol

        config = TransferConfig(separate_adapter_threshold=0.1)
        protocol = TransferProtocol(config=config)
        assert protocol.should_separate_adapter([0.2, 0.3, 0.25, 0.15]) is True

    def test_should_separate_adapter_consistently_above(self) -> None:
        from aegis.training.transfer import TransferConfig, TransferProtocol

        config = TransferConfig(interference_threshold=0.05, separate_adapter_threshold=0.5)
        protocol = TransferProtocol(config=config)
        # All above threshold
        history = [0.06, 0.07, 0.08, 0.09, 0.10]
        assert protocol.should_separate_adapter(history) is True

    def test_should_separate_adapter_monotonic_increase(self) -> None:
        from aegis.training.transfer import TransferConfig, TransferProtocol

        config = TransferConfig(interference_threshold=0.05, separate_adapter_threshold=0.5)
        protocol = TransferProtocol(config=config)
        history = [0.01, 0.02, 0.03, 0.04, 0.06]  # Monotonically increasing, last above threshold
        assert protocol.should_separate_adapter(history) is True

    def test_summary(self) -> None:
        from aegis.training.transfer import TransferProtocol

        protocol = TransferProtocol()
        protocol.prepare_transfer("legal", "finance")
        summary = protocol.summary()
        assert summary["transfer_runs"] == 1
        assert summary["has_replay_buffer"] is False
        assert "graph" in summary


class TestTransferLearningGraph:
    """Test the TransferLearningGraph class."""

    def test_record_transfer(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("legal", "finance", 0.6, 0.1)
        assert "legal" in graph._nodes
        assert "finance" in graph._nodes

    def test_record_transfer_bounds_values(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 1.5, -0.3)
        history = graph.get_history("a", "b")
        assert history[0]["transfer_score"] == 1.0
        assert history[0]["interference_score"] == 0.0

    def test_get_transfer_affinity_no_data(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        assert graph.get_transfer_affinity("a", "b") == 0.0

    def test_get_transfer_affinity_single(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("legal", "finance", 0.7, 0.1)
        affinity = graph.get_transfer_affinity("legal", "finance")
        assert affinity == 0.7  # With single measurement, returns latest

    def test_get_transfer_affinity_multiple(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("legal", "finance", 0.5, 0.1)
        graph.record_transfer("legal", "finance", 0.6, 0.1)
        graph.record_transfer("legal", "finance", 0.7, 0.1)
        affinity = graph.get_transfer_affinity("legal", "finance")
        assert 0.0 <= affinity <= 1.0
        # With improving trend, should get trend bonus
        assert affinity > 0.5

    def test_get_transfer_affinity_high_variance_penalty(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.9, 0.1)
        graph.record_transfer("a", "b", 0.1, 0.1)
        graph.record_transfer("a", "b", 0.9, 0.1)
        graph.record_transfer("a", "b", 0.1, 0.1)
        # High variance should reduce consistency bonus
        affinity = graph.get_transfer_affinity("a", "b")
        assert 0.0 <= affinity <= 1.0

    def test_get_interference_risk_no_data(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        assert graph.get_interference_risk("a", "b") == 0.0

    def test_get_interference_risk_single(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.5, 0.3)
        risk = graph.get_interference_risk("a", "b")
        assert risk == 0.3

    def test_get_interference_risk_worsening_trend(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.5, 0.1)
        graph.record_transfer("a", "b", 0.5, 0.2)
        graph.record_transfer("a", "b", 0.5, 0.3)
        risk = graph.get_interference_risk("a", "b")
        assert risk > 0.2  # Should include trend penalty

    def test_get_interference_risk_peak_penalty(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.5, 0.7)  # Very high interference
        graph.record_transfer("a", "b", 0.5, 0.2)  # Dropped since
        risk = graph.get_interference_risk("a", "b")
        assert risk > 0.2  # Peak penalty should keep risk elevated

    def test_recommend_strategy_joint(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.8, 0.05)
        strategy = graph.recommend_strategy("a", "b")
        assert strategy == "joint"

    def test_recommend_strategy_ewc(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.7, 0.25)
        strategy = graph.recommend_strategy("a", "b")
        assert strategy == "ewc"

    def test_recommend_strategy_separate_adapter_high_risk(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.3, 0.8)
        strategy = graph.recommend_strategy("a", "b")
        assert strategy == "separate_adapter"

    def test_recommend_strategy_separate_adapter_moderate_risk_low_affinity(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.2, 0.3)
        strategy = graph.recommend_strategy("a", "b")
        assert strategy == "separate_adapter"

    def test_recommend_strategy_ewc_low_affinity_low_risk(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.2, 0.05)
        strategy = graph.recommend_strategy("a", "b")
        assert strategy == "ewc"

    def test_set_strategy_override(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.8, 0.05)
        assert graph.recommend_strategy("a", "b") == "joint"

        graph.set_strategy_override("a", "b", "separate_adapter")
        assert graph.recommend_strategy("a", "b") == "separate_adapter"

    def test_set_strategy_override_invalid(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        with pytest.raises(ValueError, match="Invalid strategy"):
            graph.set_strategy_override("a", "b", "invalid")

    def test_get_history(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.5, 0.1)
        graph.record_transfer("a", "b", 0.6, 0.2)

        history = graph.get_history("a", "b")
        assert len(history) == 2
        assert history[0]["transfer_score"] == 0.5
        assert history[1]["transfer_score"] == 0.6

    def test_get_history_no_data(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        assert graph.get_history("a", "b") == []

    def test_get_all_pairs(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("a", "b", 0.5, 0.1)
        graph.record_transfer("c", "d", 0.6, 0.2)
        pairs = graph.get_all_pairs()
        assert ("a", "b") in pairs
        assert ("c", "d") in pairs

    def test_summary(self) -> None:
        from aegis.training.transfer import TransferLearningGraph

        graph = TransferLearningGraph()
        graph.record_transfer("legal", "finance", 0.6, 0.1)
        graph.record_transfer("legal", "finance", 0.7, 0.15)

        summary = graph.summary()
        assert summary["total_pairs"] == 1
        assert summary["total_measurements"] == 2
        assert len(summary["pairs"]) == 1
        pair = summary["pairs"][0]
        assert pair["source"] == "legal"
        assert pair["target"] == "finance"
        assert pair["measurements"] == 2


class TestCrossDomainTransferManager:
    """Test the CrossDomainTransferManager class."""

    def test_default_construction(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        assert mgr.config is not None
        assert mgr.is_halted is False

    def test_set_and_get_baseline(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        mgr.set_baseline("legal", 0.85)
        assert mgr.get_baseline("legal") == 0.85
        assert mgr.get_baseline("nonexistent") == 0.0

    def test_set_baseline_clamped(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        mgr.set_baseline("a", 1.5)
        assert mgr.get_baseline("a") == 1.0
        mgr.set_baseline("b", -0.5)
        assert mgr.get_baseline("b") == 0.0

    def test_create_maintenance_curriculum_empty_target(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        assert mgr.create_maintenance_curriculum(["s1"], []) == []

    def test_create_maintenance_curriculum_no_source(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        target = [{"id": "t1", "prompt": "task"}, {"id": "t2", "prompt": "task2"}]
        result = mgr.create_maintenance_curriculum([], target)
        assert len(result) == len(target)

    def test_create_maintenance_curriculum_with_dict_tasks(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", maintenance_ratio=0.2)
        mgr = CrossDomainTransferManager(config=config)
        source = [{"id": f"s{i}", "prompt": f"legal {i}"} for i in range(5)]
        target = [{"id": f"t{i}", "prompt": f"finance {i}"} for i in range(10)]

        mixed = mgr.create_maintenance_curriculum(source, target)
        assert len(mixed) > len(target)

        # Check maintenance markers
        maintenance_count = sum(
            1 for t in mixed if isinstance(t, dict) and t.get("_is_maintenance")
        )
        assert maintenance_count > 0

    def test_create_maintenance_curriculum_non_dict_tasks(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        source = ["task_a", "task_b"]
        target = ["target_1", "target_2", "target_3", "target_4", "target_5"]

        mixed = mgr.create_maintenance_curriculum(source, target)
        assert len(mixed) > len(target)

    def test_check_source_performance_above_threshold(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        result = mgr.check_source_performance({"source_score": 0.82})
        assert result is True  # 0.82 >= 0.85 * 0.95 = 0.8075

    def test_check_source_performance_below_threshold(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        result = mgr.check_source_performance({"source_score": 0.70})
        assert result is False  # 0.70 < 0.8075

    def test_check_source_performance_no_score(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal")
        mgr = CrossDomainTransferManager(config=config)
        assert mgr.check_source_performance({}) is True

    def test_check_source_performance_no_baseline(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal")
        mgr = CrossDomainTransferManager(config=config)
        assert mgr.check_source_performance({"source_score": 0.5}) is True

    def test_check_source_performance_domain_key(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        result = mgr.check_source_performance({"legal": 0.82})
        assert result is True

    def test_should_halt_not_triggered(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)

        result = mgr.should_halt({"legal": 0.85}, {"legal": 0.85})
        assert result is False
        assert mgr.is_halted is False

    def test_should_halt_triggered(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)

        result = mgr.should_halt({"legal": 0.7}, {"legal": 0.85})
        assert result is True
        assert mgr.is_halted is True

    def test_should_halt_stays_halted(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)

        mgr.should_halt({"legal": 0.7}, {"legal": 0.85})
        assert mgr.is_halted is True
        # Even with good scores now, should stay halted
        result = mgr.should_halt({"legal": 0.9}, {"legal": 0.85})
        assert result is True

    def test_should_halt_no_source_domain_checks_all(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(performance_threshold=0.95)  # No source_domain set
        mgr = CrossDomainTransferManager(config=config)

        result = mgr.should_halt(
            {"legal": 0.7, "finance": 0.9},
            {"legal": 0.85, "finance": 0.85},
        )
        assert result is True  # legal dropped below threshold

    def test_should_halt_no_source_domain_all_fine(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)

        result = mgr.should_halt(
            {"legal": 0.85, "finance": 0.85},
            {"legal": 0.85, "finance": 0.85},
        )
        assert result is False

    def test_should_halt_no_current_score(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal")
        mgr = CrossDomainTransferManager(config=config)
        result = mgr.should_halt({}, {"legal": 0.85})
        assert result is False

    def test_reset_halt(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)

        mgr.should_halt({"legal": 0.7}, {"legal": 0.85})
        assert mgr.is_halted is True

        mgr.reset_halt()
        assert mgr.is_halted is False

    def test_should_use_separate_adapter_empty(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        assert mgr.should_use_separate_adapter() is False

    def test_should_use_separate_adapter_high_mean(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(interference_threshold=0.05)
        mgr = CrossDomainTransferManager(config=config)
        result = mgr.should_use_separate_adapter([0.1, 0.2, 0.15, 0.1])
        assert result is True

    def test_should_use_separate_adapter_consistently_above(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(interference_threshold=0.05)
        mgr = CrossDomainTransferManager(config=config)
        # Last 5 all above 0.8 * threshold = 0.04
        result = mgr.should_use_separate_adapter([0.01, 0.02, 0.045, 0.045, 0.045, 0.045, 0.045])
        assert result is True

    def test_should_use_separate_adapter_monotonic_increasing(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(interference_threshold=0.05)
        mgr = CrossDomainTransferManager(config=config)
        result = mgr.should_use_separate_adapter([0.01, 0.03, 0.06])
        assert result is True

    def test_should_use_separate_adapter_falls_back_to_config(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(use_separate_adapter=True)
        mgr = CrossDomainTransferManager(config=config)
        result = mgr.should_use_separate_adapter([0.01, 0.01, 0.01])
        assert result is True

    def test_get_mixed_batch_empty(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        assert mgr.get_mixed_batch([], [], 10) == []
        assert mgr.get_mixed_batch([], [], 0) == []

    def test_get_mixed_batch_no_target(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        result = mgr.get_mixed_batch(["s1", "s2", "s3"], [], 3)
        assert result == ["s1", "s2", "s3"]

    def test_get_mixed_batch_no_source(self) -> None:
        from aegis.training.transfer import CrossDomainTransferManager

        mgr = CrossDomainTransferManager()
        result = mgr.get_mixed_batch([], ["t1", "t2", "t3"], 3)
        assert result == ["t1", "t2", "t3"]

    def test_get_mixed_batch_mixed(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(maintenance_ratio=0.2)
        mgr = CrossDomainTransferManager(config=config)
        source = [f"s{i}" for i in range(20)]
        target = [f"t{i}" for i in range(20)]
        batch = mgr.get_mixed_batch(source, target, 10)
        assert len(batch) == 10

    def test_summary(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", target_domain="finance")
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        summary = mgr.summary()
        assert summary["config"]["source_domain"] == "legal"
        assert summary["baselines"]["legal"] == 0.85
        assert summary["halted"] is False
        assert "interference" in summary

    def test_summary_with_performance_history(self) -> None:
        from aegis.training.transfer import TransferConfig, CrossDomainTransferManager

        config = TransferConfig(source_domain="legal", performance_threshold=0.95)
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        mgr.check_source_performance({"source_score": 0.82})
        mgr.check_source_performance({"source_score": 0.80})

        summary = mgr.summary()
        assert "performance" in summary
        perf = summary["performance"]
        assert len(perf) > 0


# ============================================================================
# Cross-module integration-style tests
# ============================================================================


class TestArchitectureDiscoveryIntegration:
    """Integration-style tests for architecture discovery workflows."""

    def test_propose_evaluate_evolve_cycle(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()

        # Propose
        arch = engine.propose("legal", {"retrieval_heavy": 0.6, "scale": "large"})
        assert arch.fitness_score == 0.0

        # Evaluate
        tasks = engine._generate_eval_tasks("legal", count=5)
        fitness = engine.evaluate(arch, tasks)
        assert fitness > 0.0

        # Add to library
        engine.library.add(arch)

        # Evolve
        child = engine.evolve(arch, mutation_rate=0.5)
        child_fitness = engine.evaluate(child, tasks)
        assert child_fitness > 0.0

        # Both in library
        engine.library.add(child)
        assert len(engine.library.search("legal", top_k=10)) >= 2

    def test_multi_domain_search_and_transfer(self) -> None:
        from aegis.training.architecture_discovery import ArchitectureDiscoveryEngine

        engine = ArchitectureDiscoveryEngine()
        # Search in legal
        legal_best = engine.search("legal", generations=1, population_size=4)
        assert legal_best.fitness_score > 0

        # Transfer to finance
        finance_arch = engine.cross_domain_transfer("legal", "finance")
        assert finance_arch.domain == "finance"
        assert finance_arch.fitness_score > 0


class TestTransferWorkflow:
    """Integration-style tests for transfer protocol workflows."""

    def test_full_transfer_workflow(self) -> None:
        from aegis.training.transfer import (
            CrossDomainTransferManager,
            TransferConfig,
            TransferLearningGraph,
        )

        # Set up graph
        graph = TransferLearningGraph()
        graph.record_transfer("legal", "finance", 0.6, 0.1)

        # Set up manager
        config = TransferConfig(
            source_domain="legal",
            target_domain="finance",
            maintenance_ratio=0.2,
            performance_threshold=0.95,
        )
        mgr = CrossDomainTransferManager(config=config)
        mgr.set_baseline("legal", 0.85)

        # Build curriculum
        source_tasks = [{"id": f"s{i}", "prompt": f"legal {i}"} for i in range(5)]
        target_tasks = [{"id": f"t{i}", "prompt": f"finance {i}"} for i in range(10)]
        mixed = mgr.create_maintenance_curriculum(source_tasks, target_tasks)
        assert len(mixed) > len(target_tasks)

        # Monitor source performance
        assert mgr.check_source_performance({"source_score": 0.83}) is True

        # Check if should halt
        assert mgr.should_halt({"legal": 0.83}, {"legal": 0.85}) is False

        # Get strategy recommendation
        strategy = graph.recommend_strategy("legal", "finance")
        assert strategy in ("joint", "ewc", "separate_adapter")

    def test_level_to_transfer_workflow(self) -> None:
        from aegis.training.levels import TrainingLevelManager
        from aegis.training.transfer import TransferConfig, TransferProtocol

        # Use level manager to generate tasks
        level_mgr = TrainingLevelManager()
        tasks = level_mgr.generate_level_tasks(2, count=10)
        assert len(tasks) == 10

        # Use transfer protocol to mix with maintenance
        config = TransferConfig(source_domain="legal", target_domain="finance")
        protocol = TransferProtocol(config=config)

        target_tasks = [
            {"id": t["id"], "prompt": t["prompt"], "difficulty": t["difficulty"]} for t in tasks
        ]
        mixed = protocol.build_mixed_curriculum("legal", "finance", target_tasks)
        assert len(mixed) > len(target_tasks)
