"""Tests for the SQLite persistence layer."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from aegis.eval.engine import EvalResult
from aegis.store.sqlite import SQLiteStore


def _make_result(
    run_id: str = "run-001",
    agent_id: str = "agent-a",
    overall_score: float = 0.85,
    dimension_scores: dict | None = None,
) -> EvalResult:
    return EvalResult(
        run_id=run_id,
        agent_id=agent_id,
        overall_score=overall_score,
        dimension_scores=dimension_scores or {"retention_accuracy": 0.9, "hallucination_rate": 0.8},
        created_at=datetime.now(tz=UTC),
    )


class TestSQLiteStore:
    def test_create_store_in_memory(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        assert store.db_path == ":memory:"

    def test_save_and_get_eval_run(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        result = _make_result()
        store.save_eval_run(result)

        loaded = store.get_eval_run("run-001")
        assert loaded is not None
        assert loaded.run_id == "run-001"
        assert loaded.agent_id == "agent-a"
        assert loaded.overall_score == pytest.approx(0.85)
        assert "retention_accuracy" in loaded.dimension_scores

    def test_get_not_found(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        assert store.get_eval_run("nonexistent") is None

    def test_list_eval_runs_pagination(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        for i in range(5):
            store.save_eval_run(_make_result(run_id=f"run-{i:03d}"))

        page1 = store.list_eval_runs(limit=2, offset=0)
        assert len(page1) == 2

        page2 = store.list_eval_runs(limit=2, offset=2)
        assert len(page2) == 2

        page3 = store.list_eval_runs(limit=2, offset=4)
        assert len(page3) == 1

    def test_list_eval_runs_filter_agent_id(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        store.save_eval_run(_make_result(run_id="r1", agent_id="alice"))
        store.save_eval_run(_make_result(run_id="r2", agent_id="bob"))
        store.save_eval_run(_make_result(run_id="r3", agent_id="alice"))

        alice_runs = store.list_eval_runs(agent_id="alice")
        assert len(alice_runs) == 2
        assert all(r.agent_id == "alice" for r in alice_runs)

    def test_list_eval_runs_order(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        early = _make_result(run_id="early")
        late = _make_result(run_id="late")
        store.save_eval_run(early)
        store.save_eval_run(late)

        rows = store.list_eval_runs()
        # newest first — 'late' was inserted second
        assert rows[0].run_id == "late"

    def test_upsert_eval_run(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        store.save_eval_run(_make_result(run_id="r1", overall_score=0.5))
        store.save_eval_run(_make_result(run_id="r1", overall_score=0.9))

        loaded = store.get_eval_run("r1")
        assert loaded is not None
        assert loaded.overall_score == pytest.approx(0.9)

        rows = store.list_eval_runs()
        assert len(rows) == 1

    def test_store_with_tmp_path(self, tmp_path: Path) -> None:
        db_file = tmp_path / "test.db"
        store = SQLiteStore(db_path=db_file)
        store.save_eval_run(_make_result())
        assert db_file.exists()

        loaded = store.get_eval_run("run-001")
        assert loaded is not None

    def test_save_and_get_training_job(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        now = datetime.now(tz=UTC)
        job_data = {
            "customer_id": "cust-1",
            "domain": "legal",
            "optimizer": "grpo",
            "status": "created",
            "created_at": now,
            "updated_at": now,
        }
        store.save_training_job("job-001", job_data)

        loaded = store.get_training_job("job-001")
        assert loaded is not None
        assert loaded["customer_id"] == "cust-1"
        assert loaded["domain"] == "legal"

    def test_update_training_job(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        now = datetime.now(tz=UTC)
        store.save_training_job(
            "job-001",
            {
                "customer_id": "cust-1",
                "domain": "legal",
                "optimizer": "grpo",
                "status": "created",
                "created_at": now,
                "updated_at": now,
            },
        )

        store.update_training_job("job-001", {"status": "completed"})
        loaded = store.get_training_job("job-001")
        assert loaded is not None
        assert loaded["status"] == "completed"

    def test_list_training_jobs(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        now = datetime.now(tz=UTC)
        for i in range(3):
            store.save_training_job(
                f"job-{i}",
                {
                    "customer_id": "cust-1",
                    "domain": "legal",
                    "optimizer": "grpo",
                    "status": "created",
                    "created_at": now,
                    "updated_at": now,
                },
            )

        rows = store.list_training_jobs()
        assert len(rows) == 3

    def test_get_training_job_not_found(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        assert store.get_training_job("nonexistent") is None

    def test_default_path(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))
        monkeypatch.delenv("AEGIS_DB_PATH", raising=False)

        # Reimport to pick up the new HOME
        from aegis.store import sqlite as sqlite_mod

        monkeypatch.setattr(sqlite_mod, "_DEFAULT_DIR", fake_home / ".aegis")
        monkeypatch.setattr(sqlite_mod, "_DEFAULT_DB", fake_home / ".aegis" / "aegis.db")

        store = SQLiteStore(db_path=None)
        assert str(fake_home) in store.db_path

    def test_delete_eval_run(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        store.save_eval_run(_make_result(run_id="r1"))
        store.save_eval_run(_make_result(run_id="r2"))

        assert store.delete_eval_run("r1") is True
        assert store.get_eval_run("r1") is None
        assert store.get_eval_run("r2") is not None

    def test_delete_eval_run_not_found(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        assert store.delete_eval_run("nonexistent") is False

    def test_count_eval_runs(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        assert store.count_eval_runs() == 0

        for i in range(5):
            store.save_eval_run(_make_result(run_id=f"run-{i:03d}"))
        assert store.count_eval_runs() == 5

    def test_count_eval_runs_by_agent(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        store.save_eval_run(_make_result(run_id="r1", agent_id="alice"))
        store.save_eval_run(_make_result(run_id="r2", agent_id="bob"))
        store.save_eval_run(_make_result(run_id="r3", agent_id="alice"))

        assert store.count_eval_runs(agent_id="alice") == 2
        assert store.count_eval_runs(agent_id="bob") == 1
        assert store.count_eval_runs(agent_id="charlie") == 0

    def test_delete_then_count(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        store.save_eval_run(_make_result(run_id="r1"))
        store.save_eval_run(_make_result(run_id="r2"))
        assert store.count_eval_runs() == 2

        store.delete_eval_run("r1")
        assert store.count_eval_runs() == 1

    def test_env_var_path(self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
        db_path = tmp_path / "custom.db"
        monkeypatch.setenv("AEGIS_DB_PATH", str(db_path))
        store = SQLiteStore(db_path=None)
        assert store.db_path == str(db_path)

    def test_save_and_get_benchmark_run(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        now = datetime.now(tz=UTC)
        run_data = {
            "suite": "legal-memory",
            "suite_size": 50,
            "overall_score": 0.42,
            "pass_threshold": 0.75,
            "passed": False,
            "dimension_scores": {"contract_supersession": 0.6},
            "domains": ["legal"],
            "created_at": now,
            "scorer_mode": "mock",
        }
        store.save_benchmark_run("bench-001", run_data)

        loaded = store.get_benchmark_run("bench-001")
        assert loaded is not None
        assert loaded["suite"] == "legal-memory"
        assert loaded["suite_size"] == 50
        assert loaded["passed"] is False

    def test_list_benchmark_runs_with_filter(self) -> None:
        store = SQLiteStore(db_path=":memory:")
        now = datetime.now(tz=UTC)

        store.save_benchmark_run(
            "bench-legal",
            {
                "suite": "legal-memory",
                "suite_size": 50,
                "overall_score": 0.4,
                "passed": False,
                "created_at": now,
            },
        )
        store.save_benchmark_run(
            "bench-finance",
            {
                "suite": "finance-memory",
                "suite_size": 50,
                "overall_score": 0.5,
                "passed": False,
                "created_at": now,
            },
        )

        all_rows = store.list_benchmark_runs()
        assert len(all_rows) == 2

        legal_rows = store.list_benchmark_runs(suite="legal-memory")
        assert len(legal_rows) == 1
        assert legal_rows[0].run_id == "bench-legal"
