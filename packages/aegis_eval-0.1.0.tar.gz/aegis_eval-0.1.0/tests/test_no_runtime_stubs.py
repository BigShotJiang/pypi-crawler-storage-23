"""Runtime guard to prevent stub markers in critical execution paths."""

from __future__ import annotations

import re
from pathlib import Path

_FORBIDDEN_MARKERS = ("[stub]", "stub implementation")
_TODO_PATTERN = re.compile(r"\bTODO\b")

_RUNTIME_FILES = [
    "src/aegis/api/app.py",
    "src/aegis/api/routes/retrieval.py",
    "src/aegis/api/routes/training.py",
    "src/aegis/eval/scenarios/generator.py",
    "src/aegis/retrieval/context.py",
    "src/aegis/retrieval/local_index.py",
    "src/aegis/training/engine.py",
    "src/aegis/training/optimizers.py",
]


def test_runtime_paths_do_not_contain_stub_or_todo_markers() -> None:
    repo_root = Path(__file__).resolve().parents[1]

    for relative_path in _RUNTIME_FILES:
        file_path = repo_root / relative_path
        text = file_path.read_text(encoding="utf-8")

        for marker in _FORBIDDEN_MARKERS:
            assert marker not in text, (
                f"Forbidden runtime marker '{marker}' found in {relative_path}."
            )

        assert _TODO_PATTERN.search(text) is None, (
            f"Unresolved TODO marker found in runtime file {relative_path}."
        )
