"""Shared test fixtures for Aegis test suite."""

from __future__ import annotations

from pathlib import Path

import pytest

from aegis.core.types import (
    ContextBlock,
    EvalCaseV1,
    EvalTier,
    JudgePacketV1,
    MemoryEventV1,
    MemoryOperation,
    MemoryTier,
    PromotionDecisionV1,
    PromotionStatus,
    RetrievalSource,
    RetrievalTraceV1,
    RewardTraceV1,
    StageReward,
    StepKind,
    TrajectoryStep,
    TrajectoryV1,
)


@pytest.fixture(autouse=True)
def _isolate_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensure every test uses an isolated SQLite database."""
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("AEGIS_DB_PATH", db_path)
    # Reset any cached store singletons so they pick up the new path
    import aegis.cli.main as cli_mod

    cli_mod._store_instance = None
    try:
        import aegis.api.routes.eval as eval_mod

        eval_mod._store_instance = None
    except Exception:
        pass
    try:
        import aegis.api.routes.training as train_mod

        train_mod._store_instance = None
    except Exception:
        pass


@pytest.fixture
def sample_trajectory() -> TrajectoryV1:
    return TrajectoryV1(
        agent_id="test-agent-v1",
        task_id="task-001",
        steps=[
            TrajectoryStep(kind=StepKind.THINK, content="Analyzing the contract clause..."),
            TrajectoryStep(kind=StepKind.SEARCH, content="query: indemnification clause"),
            TrajectoryStep(kind=StepKind.EVIDENCE, content="Found clause 4.2: indemnification..."),
            TrajectoryStep(kind=StepKind.REASON, content="The clause is standard but..."),
            TrajectoryStep(kind=StepKind.ANSWER, content="The indemnification clause is valid."),
        ],
        total_latency_ms=1250,
        total_tokens=450,
    )


@pytest.fixture
def sample_memory_event() -> MemoryEventV1:
    return MemoryEventV1(
        operation=MemoryOperation.STORE,
        memory_tier=MemoryTier.SESSION,
        key="client_preference_format",
        value="The client prefers bullet-point summaries over prose.",
        provenance={"source": "interaction_2026-03-15", "turn": 3},
        agent_id="test-agent-v1",
        customer_id="sterling",
    )


@pytest.fixture
def sample_retrieval_trace() -> RetrievalTraceV1:
    return RetrievalTraceV1(
        trajectory_id="traj-001",
        sources_queried=[
            RetrievalSource(
                source_type="vector",
                query="indemnification clause precedent",
                results_count=5,
                latency_ms=45,
            ),
            RetrievalSource(
                source_type="kg",
                query="Sterling Associates contracts",
                results_count=2,
                latency_ms=12,
            ),
        ],
        context_blocks=[
            ContextBlock(
                source_id="vec-001",
                content="Clause 4.2 states...",
                rerank_score=0.92,
                selected=True,
            ),
            ContextBlock(
                source_id="vec-003",
                content="Unrelated marketing doc",
                rerank_score=0.31,
                selected=False,
                reason="Below relevance threshold",
            ),
        ],
        total_retrieved=7,
        total_selected=4,
        total_dropped=3,
    )


@pytest.fixture
def sample_reward_trace() -> RewardTraceV1:
    return RewardTraceV1(
        rollout_id="rollout-001",
        stages=[
            StageReward(
                stage=1,
                stage_name="query_formulation",
                rule_score=0.9,
                semantic_score=0.85,
                judge_score=0.88,
                weight=0.1,
                weighted_score=0.088,
            ),
            StageReward(
                stage=5,
                stage_name="reasoning",
                rule_score=0.7,
                semantic_score=0.75,
                judge_score=0.72,
                weight=0.25,
                weighted_score=0.18,
            ),
        ],
        total_reward=0.73,
    )


@pytest.fixture
def sample_eval_case() -> EvalCaseV1:
    return EvalCaseV1(
        suite_id="core-memory-v1",
        dimension_id="retention_accuracy",
        tier=EvalTier.MEMORY_FIDELITY,
        prompt="What was the client's preferred contract format discussed in session 3?",
        context={"session_history": ["session_1", "session_2", "session_3"]},
        expected={"answer_contains": "bullet-point summaries"},
        difficulty=2,
        tags=["memory", "retention", "session"],
    )


@pytest.fixture
def sample_judge_packet() -> JudgePacketV1:
    return JudgePacketV1(
        eval_case_id="case-001",
        dimension_id="retention_accuracy",
        rule_score=0.9,
        semantic_score=0.85,
        judge_scores={"qwen-72b": 0.88, "gpt-4o": 0.90},
        ensemble_score=0.88,
        disagreement=0.05,
        explanation="Agent correctly recalled the client preference from session 3.",
    )


@pytest.fixture
def sample_promotion_decision() -> PromotionDecisionV1:
    return PromotionDecisionV1(
        adapter_id="sterling-legal-v3-lora",
        status=PromotionStatus.PASS,
        composite_improvement=4.2,
        tier7_clear=True,
        human_gate_required=True,
        human_gate_approved=True,
        human_gate_approver="partner@sterling.com",
        rollback_pointer="sterling-legal-v2-lora",
        eval_run_before="run-before-001",
        eval_run_after="run-after-001",
    )
