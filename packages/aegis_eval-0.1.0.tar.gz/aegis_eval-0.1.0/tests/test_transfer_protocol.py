"""Tests for transfer graph and transfer protocol curriculum mixing."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from aegis.training.transfer import TransferGraph, TransferProtocol


def test_transfer_graph_best_source_prefers_high_transfer_low_interference() -> None:
    graph = TransferGraph()
    graph.add_edge("legal", "finance", transfer_score=0.72, interference_score=0.08)
    graph.add_edge("safety", "finance", transfer_score=0.65, interference_score=0.01)
    graph.add_edge("ops", "finance", transfer_score=0.70, interference_score=0.03)

    assert graph.best_source_for("finance") == "ops"
    assert graph.get_transfer_score("ops", "finance") == 0.70
    assert graph.get_interference("ops", "finance") == 0.03


@dataclass
class _FakeExperience:
    id: str
    prompt: str
    difficulty: int
    reward: float


class _FakeReplayBuffer:
    def __init__(self, experiences: list[_FakeExperience] | None = None) -> None:
        self._experiences = experiences or []

    def maintenance_sample(self, domain: str, ratio: float) -> list[_FakeExperience]:  # noqa: ARG002
        return list(self._experiences)


def test_build_mixed_curriculum_uses_replay_maintenance_when_available() -> None:
    replay = _FakeReplayBuffer(
        experiences=[
            _FakeExperience(
                id="exp-1", prompt="Source maintenance prompt", difficulty=3, reward=0.9
            )
        ]
    )
    protocol = TransferProtocol(replay_buffer=replay)
    target_tasks = [
        {"id": "target-1", "prompt": "Analyze Q2 statements", "difficulty": 2, "domain": "finance"},
        {"id": "target-2", "prompt": "Assess liquidity risk", "difficulty": 3, "domain": "finance"},
    ]

    mixed = protocol.build_mixed_curriculum(
        source_domain="legal",
        target_domain="finance",
        target_tasks=target_tasks,
        maintenance_ratio=0.25,
    )

    assert len(mixed) > len(target_tasks)
    maintenance = [task for task in mixed if task.get("is_maintenance")]
    assert maintenance
    assert maintenance[0]["domain"] == "legal"
    assert maintenance[0]["metadata"]["from_buffer"] is True
    assert maintenance[0]["source_experience_id"] == "exp-1"


def test_build_mixed_curriculum_synthesizes_non_placeholder_maintenance() -> None:
    protocol = TransferProtocol(replay_buffer=None)
    target_tasks: list[dict[str, Any]] = [
        {"id": "target-a", "prompt": "Evaluate merger risk for deal X", "difficulty": 4},
        {"id": "target-b", "prompt": "Compare covenant terms", "difficulty": 3},
    ]

    mixed = protocol.build_mixed_curriculum(
        source_domain="legal",
        target_domain="finance",
        target_tasks=target_tasks,
        maintenance_ratio=0.30,
    )

    maintenance = [task for task in mixed if task.get("is_maintenance")]
    assert maintenance
    assert all("[maintenance:legal]" in str(task["prompt"]) for task in maintenance)
    assert all("placeholder" not in str(task["prompt"]).lower() for task in maintenance)
    assert all(task["metadata"]["synthetic"] is True for task in maintenance)
    assert all(task["metadata"]["target_domain"] == "finance" for task in maintenance)


def test_monitor_interference_detects_worsening_trend() -> None:
    protocol = TransferProtocol()
    protocol.prepare_transfer("legal", "finance")

    baseline = 0.90
    result_1 = protocol.monitor_interference(source_scores=[0.88], baseline_score=baseline)
    result_2 = protocol.monitor_interference(source_scores=[0.84], baseline_score=baseline)
    result_3 = protocol.monitor_interference(source_scores=[0.80], baseline_score=baseline)

    assert result_1["interference_detected"] is False
    assert result_2["interference_detected"] is True
    assert result_3["trend"] == "worsening"
    assert "Interference is worsening" in result_3["recommendation"]
