"""Tests for CrewAI adapter, AutoGen adapter, PDF exporter, and enhanced diagnostics.

Covers ~45 test cases across four modules:
- aegis.adapters.crewai.CrewAIAdapter
- aegis.adapters.autogen.AutoGenAdapter
- aegis.eval.reporting.pdf_export (generate_html_report, export_pdf, export_report)
- aegis.eval.reporting.diagnostic (generate_diagnostic — enhanced)
"""

from __future__ import annotations

import builtins
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aegis.core.types import EvalCaseV1, EvalTier, TrajectoryV1

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_eval_case(**overrides) -> EvalCaseV1:
    """Build a minimal EvalCaseV1 with sensible defaults, allowing overrides."""
    defaults = dict(
        suite_id="test-suite",
        dimension_id="tier1_retention",
        tier=EvalTier.MEMORY_FIDELITY,
        prompt="What is 2+2?",
        context={},
    )
    defaults.update(overrides)
    return EvalCaseV1(**defaults)


# ===================================================================
# CrewAIAdapter Tests
# ===================================================================


class TestCrewAIAdapter:
    """Tests for aegis.adapters.crewai.CrewAIAdapter."""

    def _make_adapter(self, crew=None, agent_id="crewai"):
        """Import and instantiate CrewAIAdapter with a mock crew.

        The crewai import inside evaluate() is patched separately per test.
        """
        from aegis.adapters.crewai import CrewAIAdapter

        return CrewAIAdapter(crew or MagicMock(), agent_id=agent_id)

    # -- name property ------------------------------------------------

    def test_name_returns_crewai(self):
        adapter = self._make_adapter()
        assert adapter.name == "crewai"

    # -- evaluate() with string result --------------------------------

    @patch.dict(sys.modules, {"crewai": MagicMock()})
    def test_evaluate_calls_kickoff_with_correct_inputs(self):
        crew = MagicMock()
        crew.kickoff.return_value = "The answer is 4"
        adapter = self._make_adapter(crew=crew)
        task = _make_eval_case(context={"extra": "data"})

        adapter.evaluate(task)

        crew.kickoff.assert_called_once()
        call_kwargs = crew.kickoff.call_args
        inputs = call_kwargs[1]["inputs"]
        assert inputs["input"] == task.prompt
        assert inputs["extra"] == "data"

    @patch.dict(sys.modules, {"crewai": MagicMock()})
    def test_evaluate_handles_string_result(self):
        crew = MagicMock()
        crew.kickoff.return_value = "String output"
        adapter = self._make_adapter(crew=crew)
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert isinstance(result, TrajectoryV1)
        assert result.steps[0].content == "String output"

    @patch.dict(sys.modules, {"crewai": MagicMock()})
    def test_evaluate_handles_crew_output_with_raw(self):
        crew_output = MagicMock()
        crew_output.raw = "Raw output text"
        # Make sure isinstance(result, str) returns False for the mock
        crew = MagicMock()
        crew.kickoff.return_value = crew_output
        adapter = self._make_adapter(crew=crew)
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert result.steps[0].content == "Raw output text"

    @patch.dict(sys.modules, {"crewai": MagicMock()})
    def test_evaluate_trajectory_structure(self):
        crew = MagicMock()
        crew.kickoff.return_value = "output"
        adapter = self._make_adapter(crew=crew, agent_id="my-crew")
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert result.agent_id == "my-crew"
        assert result.task_id == task.id
        assert len(result.steps) == 1
        assert result.steps[0].kind.value == "answer"
        assert result.total_latency_ms is not None
        assert result.total_latency_ms >= 0

    @patch.dict(sys.modules, {"crewai": MagicMock()})
    def test_evaluate_latency_is_positive(self):
        crew = MagicMock()
        crew.kickoff.return_value = "ok"
        adapter = self._make_adapter(crew=crew)
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert result.total_latency_ms >= 0
        assert result.steps[0].latency_ms >= 0
        assert result.total_latency_ms == result.steps[0].latency_ms

    def test_import_error_when_crewai_not_installed(self):
        """CrewAIAdapter.evaluate() raises ImportError when crewai is absent."""
        # Remove crewai from sys.modules if present, then block import
        sys.modules.pop("crewai", None)

        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "crewai":
                raise ImportError("No module named 'crewai'")
            return real_import(name, *args, **kwargs)

        adapter = self._make_adapter()
        task = _make_eval_case()

        with (
            patch("builtins.__import__", side_effect=mock_import),
            pytest.raises(ImportError, match="crewai"),
        ):
            adapter.evaluate(task)


# ===================================================================
# AutoGenAdapter Tests
# ===================================================================


class TestAutoGenAdapter:
    """Tests for aegis.adapters.autogen.AutoGenAdapter."""

    def _make_adapter(self, agent=None, agent_id="autogen"):
        from aegis.adapters.autogen import AutoGenAdapter

        return AutoGenAdapter(agent or MagicMock(), agent_id=agent_id)

    # -- name property ------------------------------------------------

    def test_name_returns_autogen(self):
        adapter = self._make_adapter()
        assert adapter.name == "autogen"

    # -- evaluate() with mocked agent ----------------------------------

    @patch.dict(sys.modules, {"autogen": MagicMock()})
    def test_evaluate_calls_generate_reply(self):
        agent = MagicMock()
        agent.generate_reply.return_value = "Agent reply"
        adapter = self._make_adapter(agent=agent)
        task = _make_eval_case()

        adapter.evaluate(task)

        agent.generate_reply.assert_called_once()
        call_kwargs = agent.generate_reply.call_args
        messages = call_kwargs[1]["messages"]
        assert any(m["role"] == "user" and m["content"] == task.prompt for m in messages)

    @patch.dict(sys.modules, {"autogen": MagicMock()})
    def test_evaluate_prepends_context_as_system_message(self):
        agent = MagicMock()
        agent.generate_reply.return_value = "reply"
        adapter = self._make_adapter(agent=agent)
        task = _make_eval_case(context={"domain": "legal", "style": "formal"})

        adapter.evaluate(task)

        messages = agent.generate_reply.call_args[1]["messages"]
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        # Context should contain both key-value pairs
        assert "domain: legal" in messages[0]["content"]
        assert "style: formal" in messages[0]["content"]
        assert messages[1]["role"] == "user"

    @patch.dict(sys.modules, {"autogen": MagicMock()})
    def test_evaluate_without_context_has_only_user_message(self):
        agent = MagicMock()
        agent.generate_reply.return_value = "reply"
        adapter = self._make_adapter(agent=agent)
        task = _make_eval_case(context={})

        adapter.evaluate(task)

        messages = agent.generate_reply.call_args[1]["messages"]
        assert len(messages) == 1
        assert messages[0]["role"] == "user"

    @patch.dict(sys.modules, {"autogen": MagicMock()})
    def test_evaluate_trajectory_structure(self):
        agent = MagicMock()
        agent.generate_reply.return_value = "the answer"
        adapter = self._make_adapter(agent=agent, agent_id="my-autogen")
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert isinstance(result, TrajectoryV1)
        assert result.agent_id == "my-autogen"
        assert result.task_id == task.id
        assert len(result.steps) == 1
        assert result.steps[0].kind.value == "answer"
        assert result.steps[0].content == "the answer"
        assert result.total_latency_ms >= 0

    @patch.dict(sys.modules, {"autogen": MagicMock()})
    def test_evaluate_non_string_result_is_coerced(self):
        agent = MagicMock()
        agent.generate_reply.return_value = {"text": "complex"}
        adapter = self._make_adapter(agent=agent)
        task = _make_eval_case()

        result = adapter.evaluate(task)

        assert isinstance(result.steps[0].content, str)

    def test_import_error_when_neither_autogen_nor_pyautogen_installed(self):
        """Should raise ImportError when both autogen and pyautogen are absent."""
        mods_backup = {k: v for k, v in sys.modules.items() if k in ("autogen", "pyautogen")}
        sys.modules.pop("autogen", None)
        sys.modules.pop("pyautogen", None)

        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name in ("autogen", "pyautogen"):
                raise ImportError(f"No module named '{name}'")
            return real_import(name, *args, **kwargs)

        adapter = self._make_adapter()
        task = _make_eval_case()

        with (
            patch("builtins.__import__", side_effect=mock_import),
            pytest.raises(ImportError, match="pyautogen"),
        ):
            adapter.evaluate(task)

        # Restore any removed modules
        sys.modules.update(mods_backup)


# ===================================================================
# PDF Export Tests
# ===================================================================


class TestPDFExport:
    """Tests for aegis.eval.reporting.pdf_export."""

    @pytest.fixture()
    def sample_diagnostic(self) -> dict:
        return {
            "strengths": ["Agent excels in memory retention"],
            "weaknesses": ["Reasoning quality needs improvement"],
            "recommendations": ["Train on tier4_logical_deduction"],
        }

    @pytest.fixture()
    def sample_dimension_scores(self) -> dict[str, float]:
        return {
            "tier1_retention": 0.92,
            "tier2_context_window": 0.65,
            "tier4_logical_deduction": 0.35,
        }

    # -- generate_html_report -----------------------------------------

    def test_html_report_contains_run_id(self, sample_diagnostic, sample_dimension_scores):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-abc-123",
            overall_score=0.75,
            dimension_scores=sample_dimension_scores,
            diagnostic=sample_diagnostic,
            agent_id="test-agent",
        )

        assert "run-abc-123" in html

    def test_html_report_contains_agent_id(self, sample_diagnostic, sample_dimension_scores):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-001",
            overall_score=0.75,
            dimension_scores=sample_dimension_scores,
            diagnostic=sample_diagnostic,
            agent_id="my-agent-v2",
        )

        assert "my-agent-v2" in html

    def test_html_report_contains_dimension_scores(
        self, sample_diagnostic, sample_dimension_scores
    ):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-001",
            overall_score=0.75,
            dimension_scores=sample_dimension_scores,
            diagnostic=sample_diagnostic,
        )

        assert "tier1_retention" in html
        assert "tier2_context_window" in html
        assert "tier4_logical_deduction" in html

    def test_html_report_with_empty_dimension_scores(self, sample_diagnostic):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-empty",
            overall_score=0.0,
            dimension_scores={},
            diagnostic=sample_diagnostic,
        )

        assert "run-empty" in html
        assert "0 dimensions evaluated" in html
        assert "<!DOCTYPE html>" in html

    def test_html_report_includes_diagnostic_sections(self, sample_dimension_scores):
        from aegis.eval.reporting.pdf_export import generate_html_report

        diagnostic = {
            "strengths": ["Strong memory"],
            "weaknesses": ["Weak reasoning"],
            "recommendations": ["Focus on tier4"],
        }

        html = generate_html_report(
            run_id="run-diag",
            overall_score=0.6,
            dimension_scores=sample_dimension_scores,
            diagnostic=diagnostic,
        )

        assert "Strengths" in html
        assert "Strong memory" in html
        assert "Areas for Improvement" in html
        assert "Weak reasoning" in html
        assert "Recommendations" in html
        assert "Focus on tier4" in html

    def test_html_report_green_color_for_high_score(self):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-green",
            overall_score=0.9,
            dimension_scores={"dim_high": 0.95},
            diagnostic={},
        )

        # Green color code
        assert "#22c55e" in html

    def test_html_report_yellow_color_for_mid_score(self):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-yellow",
            overall_score=0.6,
            dimension_scores={"dim_mid": 0.65},
            diagnostic={},
        )

        assert "#eab308" in html

    def test_html_report_red_color_for_low_score(self):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-red",
            overall_score=0.3,
            dimension_scores={"dim_low": 0.25},
            diagnostic={},
        )

        assert "#ef4444" in html

    # -- export_pdf ---------------------------------------------------

    def test_export_pdf_without_weasyprint_writes_html_fallback(self, tmp_path):
        from aegis.eval.reporting.pdf_export import export_pdf

        out = tmp_path / "report.pdf"
        html_content = "<html><body>Test</body></html>"

        # weasyprint should not be installed in test env
        with patch.dict(sys.modules, {"weasyprint": None}):
            result = export_pdf(html_content, out)

        # When weasyprint is missing, it writes HTML and returns False
        # The actual function tries import weasyprint which will ImportError
        # if weasyprint is truly absent. Let's test directly.
        out2 = tmp_path / "report2.pdf"
        real_import = builtins.__import__

        def block_weasyprint(name, *args, **kwargs):
            if name == "weasyprint":
                raise ImportError("No module named 'weasyprint'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=block_weasyprint):
            result = export_pdf(html_content, out2)

        assert result is False
        assert out2.exists()
        assert out2.read_text() == html_content

    # -- export_report ------------------------------------------------

    def test_export_report_html_format(self, tmp_path, sample_diagnostic, sample_dimension_scores):
        from aegis.eval.reporting.pdf_export import export_report

        out_path = tmp_path / "report.html"
        result = export_report(
            run_id="run-html",
            overall_score=0.75,
            dimension_scores=sample_dimension_scores,
            diagnostic=sample_diagnostic,
            output_path=out_path,
            fmt="html",
            agent_id="html-agent",
        )

        assert result == str(out_path)
        assert out_path.exists()
        content = out_path.read_text()
        assert "<!DOCTYPE html>" in content
        assert "run-html" in content
        assert "html-agent" in content

    def test_export_report_pdf_falls_back_to_html(
        self, tmp_path, sample_diagnostic, sample_dimension_scores
    ):
        from aegis.eval.reporting.pdf_export import export_report

        out_path = tmp_path / "report.pdf"

        real_import = builtins.__import__

        def block_weasyprint(name, *args, **kwargs):
            if name == "weasyprint":
                raise ImportError("No module named 'weasyprint'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=block_weasyprint):
            result = export_report(
                run_id="run-pdf",
                overall_score=0.5,
                dimension_scores=sample_dimension_scores,
                diagnostic=sample_diagnostic,
                output_path=out_path,
                fmt="pdf",
            )

        assert result == str(out_path)
        assert out_path.exists()
        # Should contain HTML since weasyprint is missing
        content = out_path.read_text()
        assert "<!DOCTYPE html>" in content

    def test_export_report_creates_parent_directories(self, tmp_path, sample_diagnostic):
        from aegis.eval.reporting.pdf_export import export_report

        out_path = tmp_path / "deep" / "nested" / "dir" / "report.html"
        result = export_report(
            run_id="run-nested",
            overall_score=0.8,
            dimension_scores={"dim_a": 0.8},
            diagnostic=sample_diagnostic,
            output_path=out_path,
            fmt="html",
        )

        assert Path(result).exists()

    def test_html_report_empty_diagnostic(self):
        from aegis.eval.reporting.pdf_export import generate_html_report

        html = generate_html_report(
            run_id="run-nodiag",
            overall_score=0.5,
            dimension_scores={"dim_x": 0.5},
            diagnostic={},
        )

        assert "No diagnostic data available." in html


# ===================================================================
# Enhanced Diagnostic Tests
# ===================================================================


class TestEnhancedDiagnostic:
    """Tests for aegis.eval.reporting.diagnostic.generate_diagnostic (enhanced)."""

    # -- Overall score ------------------------------------------------

    def test_mixed_scores_produces_correct_overall(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.9,
            "tier2_context": 0.6,
            "tier3_learning": 0.3,
        }
        report = generate_diagnostic("run-mixed", scores)

        expected_overall = round((0.9 + 0.6 + 0.3) / 3, 4)
        assert report["overall_score"] == expected_overall

    # -- Tier aggregation --------------------------------------------

    def test_tier_aggregation_groups_by_tier_prefix(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.8,
            "tier1_recall": 0.6,
            "tier2_window_mgmt": 0.9,
        }
        report = generate_diagnostic("run-tiers", scores)

        assert "Memory Fidelity" in report["tier_scores"]
        assert "Context Intelligence" in report["tier_scores"]
        # Memory Fidelity = avg(0.8, 0.6) = 0.7
        assert report["tier_scores"]["Memory Fidelity"] == round((0.8 + 0.6) / 2, 4)
        # Context Intelligence = 0.9
        assert report["tier_scores"]["Context Intelligence"] == 0.9

    # -- Weak dimensions (<0.5) ---------------------------------------

    def test_weak_dimensions_below_threshold(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_good": 0.85,
            "tier2_bad": 0.35,
            "tier3_terrible": 0.1,
        }
        report = generate_diagnostic("run-weak", scores)

        assert "tier2_bad" in report["weak_dimensions"]
        assert "tier3_terrible" in report["weak_dimensions"]
        assert "tier1_good" not in report["weak_dimensions"]

    # -- Strong dimensions (>=0.8) ------------------------------------

    def test_strong_dimensions_above_threshold(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_excellent": 0.95,
            "tier1_great": 0.80,
            "tier2_mediocre": 0.55,
        }
        report = generate_diagnostic("run-strong", scores)

        assert "tier1_excellent" in report["strong_dimensions"]
        assert "tier1_great" in report["strong_dimensions"]
        assert "tier2_mediocre" not in report["strong_dimensions"]

    # -- Strengths list -----------------------------------------------

    def test_strengths_nonempty_when_strong_dims_exist(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.95,
            "tier1_recall": 0.90,
        }
        report = generate_diagnostic("run-strengths", scores)

        assert len(report["strengths"]) >= 1
        assert any("excels" in s for s in report["strengths"])

    # -- Weaknesses list ----------------------------------------------

    def test_weaknesses_nonempty_when_weak_dims_exist(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.2,
            "tier2_context": 0.3,
        }
        report = generate_diagnostic("run-weaknesses", scores)

        assert len(report["weaknesses"]) >= 1
        assert any("underperforms" in w for w in report["weaknesses"])

    # -- Recommendations with impact levels ---------------------------

    def test_recommendations_include_impact_levels(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.2,  # gap=0.6 -> high impact
            "tier2_context": 0.55,  # gap=0.25 -> medium impact
            "tier3_learning": 0.7,  # gap=0.1 -> low impact
        }
        report = generate_diagnostic("run-recs", scores)

        recs = report["recommendations"]
        assert len(recs) >= 1
        # Check that impact levels appear in the recommendations
        rec_text = " ".join(recs)
        assert "high" in rec_text or "medium" in rec_text or "low" in rec_text

    def test_recommendations_high_impact_for_very_low_score(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.1,  # gap = 0.7 >= 0.5 -> high
        }
        report = generate_diagnostic("run-high-impact", scores)

        rec_text = " ".join(report["recommendations"])
        assert "high" in rec_text

    def test_recommendations_medium_impact_for_moderate_score(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.5,  # gap = 0.3 >= 0.25 -> medium
        }
        report = generate_diagnostic("run-med-impact", scores)

        rec_text = " ".join(report["recommendations"])
        assert "medium" in rec_text

    def test_recommendations_low_impact_for_near_threshold_score(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.7,  # gap = 0.1 < 0.25 -> low
        }
        report = generate_diagnostic("run-low-impact", scores)

        rec_text = " ".join(report["recommendations"])
        assert "low" in rec_text

    # -- training_focus ordering --------------------------------------

    def test_training_focus_ordered_by_lowest_score_first(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.5,
            "tier2_context": 0.3,
            "tier3_learning": 0.7,
            "tier4_reasoning": 0.1,
        }
        report = generate_diagnostic("run-focus", scores)

        focus = report["training_focus"]
        assert focus[0] == "tier4_reasoning"  # score 0.1
        assert focus[1] == "tier2_context"  # score 0.3
        assert focus[2] == "tier1_retention"  # score 0.5

    # -- root_causes: systematic tier weakness -------------------------

    def test_root_causes_detects_systematic_tier_weakness(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.2,
            "tier1_recall": 0.3,
            "tier2_context": 0.9,
        }
        report = generate_diagnostic("run-systematic", scores)

        assert len(report["root_causes"]) >= 1
        rc_text = " ".join(report["root_causes"])
        assert "Systematic weakness" in rc_text
        assert "Memory Fidelity" in rc_text

    # -- root_causes: adjacent-tier cascade ----------------------------

    def test_root_causes_detects_adjacent_tier_cascade(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.3,
            "tier2_context": 0.4,
            "tier3_learning": 0.9,
        }
        report = generate_diagnostic("run-cascade", scores)

        rc_text = " ".join(report["root_causes"])
        assert "Adjacent tiers" in rc_text
        assert "cascade" in rc_text.lower()

    # -- root_causes: high variance within tier ------------------------

    def test_root_causes_detects_high_variance_within_tier(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.95,
            "tier1_recall": 0.3,  # variance = 0.65 > 0.4
            "tier2_context": 0.7,
        }
        report = generate_diagnostic("run-variance", scores)

        rc_text = " ".join(report["root_causes"])
        assert "variance" in rc_text.lower()
        assert "Memory Fidelity" in rc_text

    # -- Empty dimension_scores ---------------------------------------

    def test_empty_dimension_scores_returns_empty_report(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        report = generate_diagnostic("run-empty", {})

        assert report["overall_score"] == 0.0
        assert report["tier_scores"] == {}
        assert report["weak_dimensions"] == []
        assert report["strong_dimensions"] == []
        assert report["strengths"] == []
        assert report["weaknesses"] == []
        assert report["training_focus"] == []
        assert report["root_causes"] == []

    # -- Architecture review recommendation for overall < 0.5 ---------

    def test_overall_below_05_triggers_architecture_review(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_retention": 0.2,
            "tier2_context": 0.3,
            "tier3_learning": 0.1,
        }
        report = generate_diagnostic("run-bad", scores)

        assert report["overall_score"] < 0.5
        rec_text = " ".join(report["recommendations"])
        assert "architecture" in rec_text.lower()

    # -- DiagnosticReport fields present in output --------------------

    def test_report_has_all_expected_keys(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {"tier1_retention": 0.7}
        report = generate_diagnostic("run-keys", scores)

        expected_keys = {
            "run_id",
            "overall_score",
            "tier_scores",
            "weak_dimensions",
            "strong_dimensions",
            "strengths",
            "weaknesses",
            "recommendations",
            "training_focus",
            "root_causes",
            "metadata",
        }
        assert expected_keys.issubset(set(report.keys()))

    def test_run_id_propagated(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        report = generate_diagnostic("run-id-check", {"tier1_a": 0.5})
        assert report["run_id"] == "run-id-check"

    # -- Edge cases ---------------------------------------------------

    def test_all_strong_dimensions_no_weaknesses(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_a": 0.9,
            "tier1_b": 0.85,
            "tier2_c": 0.95,
        }
        report = generate_diagnostic("run-all-strong", scores)

        assert len(report["weak_dimensions"]) == 0
        assert len(report["weaknesses"]) == 0
        assert len(report["strong_dimensions"]) == 3

    def test_all_weak_dimensions_no_strengths_in_strong_dims(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_a": 0.1,
            "tier2_b": 0.2,
            "tier3_c": 0.3,
        }
        report = generate_diagnostic("run-all-weak", scores)

        assert len(report["strong_dimensions"]) == 0
        assert len(report["weak_dimensions"]) == 3
        assert len(report["weaknesses"]) >= 1

    def test_training_focus_excludes_strong_dimensions(self):
        from aegis.eval.reporting.diagnostic import generate_diagnostic

        scores = {
            "tier1_a": 0.9,  # Strong -- excluded from training_focus
            "tier2_b": 0.4,  # Below threshold -- included
            "tier3_c": 0.6,  # Between thresholds -- included
        }
        report = generate_diagnostic("run-focus-exclude", scores)

        assert "tier1_a" not in report["training_focus"]
        assert "tier2_b" in report["training_focus"]
        assert "tier3_c" in report["training_focus"]
