"""Tests for the Docling document parser."""

from __future__ import annotations

from pathlib import Path

from aegis.ingestion.docling_parser import DoclingParser
from aegis.ingestion.parsers import Modality


class TestDoclingParser:
    """Test the DoclingParser interface and fallback behavior."""

    def test_supported_extensions(self) -> None:
        parser = DoclingParser()
        exts = parser.supported_extensions
        assert ".pdf" in exts
        assert ".docx" in exts
        assert ".xlsx" in exts
        assert ".pptx" in exts

    def test_supported_modalities(self) -> None:
        parser = DoclingParser()
        mods = parser.supported_modalities
        assert Modality.DOCUMENT in mods
        assert Modality.TABLE in mods

    def test_can_handle_pdf(self) -> None:
        parser = DoclingParser()
        assert parser.can_handle("report.pdf")
        assert parser.can_handle(Path("report.pdf"))

    def test_can_handle_docx(self) -> None:
        parser = DoclingParser()
        assert parser.can_handle("contract.docx")

    def test_cannot_handle_txt(self) -> None:
        parser = DoclingParser()
        assert not parser.can_handle("notes.txt")

    def test_fallback_for_binary_file(self, tmp_path: Path) -> None:
        """When docling is not installed, binary files return a placeholder."""
        parser = DoclingParser()
        # Force fallback mode
        parser._converter = None

        fake_pdf = tmp_path / "test.pdf"
        fake_pdf.write_bytes(b"%PDF-1.4 fake content")

        chunks = parser.parse(fake_pdf)
        assert len(chunks) == 1
        assert chunks[0].confidence < 0.5
        assert "install docling" in chunks[0].content.lower()

    def test_fallback_for_missing_file(self) -> None:
        parser = DoclingParser()
        parser._converter = None
        chunks = parser.parse("/nonexistent/file.pdf")
        assert chunks == []

    def test_fallback_with_raw_content(self) -> None:
        parser = DoclingParser()
        parser._converter = None
        chunks = parser.parse("test.pdf", content=b"Some raw text content here")
        assert len(chunks) == 1
        assert "Some raw text content here" in chunks[0].content


class TestDoclingParserRegistration:
    """Test that DoclingParser auto-registers in the ParserRegistry."""

    def test_registry_has_docling_extensions(self) -> None:
        from aegis.ingestion.parsers import ParserRegistry

        registry = ParserRegistry()
        exts = registry.supported_extensions()
        assert ".pdf" in exts
        assert ".docx" in exts

    def test_registry_returns_parser_for_pdf(self) -> None:
        from aegis.ingestion.parsers import ParserRegistry

        registry = ParserRegistry()
        parser = registry.get_parser("document.pdf")
        assert parser is not None
        assert isinstance(parser, DoclingParser)
