"""Coverage tests for API auth and authorization helpers."""

from __future__ import annotations

import time

import pytest

from aegis.api import auth as auth_mod
from aegis.api.auth import AuthConfig, AuthProvider, AuthUser


@pytest.fixture(autouse=True)
def _reset_default_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(auth_mod, "_default_provider", None)


def _provider(secret: str = "test-secret") -> AuthProvider:
    return AuthProvider(
        AuthConfig(
            jwt_secret=secret,
            issuer="aegis",
            audience="aegis-api",
            token_expiry_seconds=3600,
            api_key_prefix="aegis_",
        )
    )


def test_b64url_roundtrip_and_hash() -> None:
    raw = b"aegis-auth"
    enc = auth_mod._b64url_encode(raw)
    assert "=" not in enc
    assert auth_mod._b64url_decode(enc) == raw
    assert auth_mod._hash_api_key("k123") == auth_mod._hash_api_key("k123")


def test_create_jwt_rejects_unsupported_algorithm() -> None:
    with pytest.raises(ValueError):
        auth_mod._create_jwt({"sub": "u1"}, "secret", algorithm="HS512")


def test_decode_jwt_validation_paths() -> None:
    now = int(time.time())
    payload: dict[str, object] = {
        "sub": "user-1",
        "email": "u@example.com",
        "iss": "aegis",
        "aud": "aegis-api",
        "exp": now + 60,
    }
    token = auth_mod._create_jwt(payload, "secret")

    decoded = auth_mod._decode_jwt(token, "secret")
    assert decoded is not None
    assert decoded["sub"] == "user-1"

    assert auth_mod._decode_jwt(token, "wrong") is None
    assert auth_mod._decode_jwt("not-a-jwt", "secret") is None
    assert auth_mod._decode_jwt(token, "secret", algorithm="HS512") is None

    parts = token.split(".")
    bad_sig = f"{parts[0]}.{parts[1]}.AAAA"
    assert auth_mod._decode_jwt(bad_sig, "secret") is None

    expired = auth_mod._create_jwt({"sub": "u", "exp": now - 1}, "secret")
    assert auth_mod._decode_jwt(expired, "secret") is None


def test_resolve_permissions_dedupes_and_sorts() -> None:
    perms = auth_mod._resolve_permissions(["viewer", "developer"], ["custom:read", "eval:read"])
    assert perms == sorted(set(perms))
    assert "custom:read" in perms
    assert "training:write" in perms


def test_verify_jwt_and_issuer_audience_rules() -> None:
    provider = _provider()
    token = provider.create_jwt(
        user_id="u-1",
        email="u@example.com",
        roles=["viewer"],
        permissions=["custom:read"],
    )

    user = provider.verify_jwt(token)
    assert user is not None
    assert user.user_id == "u-1"
    assert "training:read" in user.permissions
    assert "custom:read" in user.permissions
    assert user.metadata["auth_method"] == "jwt"

    wrong_issuer = auth_mod._create_jwt(
        {
            "sub": "u-1",
            "email": "u@example.com",
            "iss": "other",
            "aud": "aegis-api",
            "exp": int(time.time()) + 60,
        },
        "test-secret",
    )
    assert provider.verify_jwt(wrong_issuer) is None

    aud_list = auth_mod._create_jwt(
        {
            "sub": "u-2",
            "email": "x@example.com",
            "iss": "aegis",
            "aud": ["foo", "aegis-api"],
            "exp": int(time.time()) + 60,
        },
        "test-secret",
    )
    assert provider.verify_jwt(aud_list) is not None

    wrong_aud = auth_mod._create_jwt(
        {
            "sub": "u-2",
            "email": "x@example.com",
            "iss": "aegis",
            "aud": ["foo"],
            "exp": int(time.time()) + 60,
        },
        "test-secret",
    )
    assert provider.verify_jwt(wrong_aud) is None


def test_verify_jwt_returns_none_without_secret() -> None:
    provider = AuthProvider(AuthConfig(jwt_secret=""))
    assert provider.verify_jwt("any") is None
    with pytest.raises(ValueError):
        provider.create_jwt("u", "u@example.com")


def test_api_key_lifecycle_and_authenticate_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    provider = _provider()
    raw_key, record = provider.create_api_key("user-a", ["memory:read"], expires_in_seconds=1)

    user = provider.verify_api_key(raw_key)
    assert user is not None
    assert user.user_id == "user-a"
    assert user.metadata["auth_method"] == "api_key"

    keys = provider.list_api_keys("user-a")
    assert len(keys) == 1
    assert keys[0].key_id == record.key_id

    # JWT is preferred if present and valid.
    token = provider.create_jwt("jwt-user", "jwt@example.com", roles=["viewer"])
    auth_user = provider.authenticate({"authorization": f"Bearer {token}", "x-api-key": raw_key})
    assert auth_user is not None
    assert auth_user.user_id == "jwt-user"

    # Invalid bearer falls back to API key.
    fallback_user = provider.authenticate({"Authorization": "Bearer invalid", "X-API-Key": raw_key})
    assert fallback_user is not None
    assert fallback_user.user_id == "user-a"

    assert provider.revoke_api_key(record.key_id) is True
    assert provider.revoke_api_key("missing") is False
    assert provider.verify_api_key(raw_key) is None

    # Expiry path.
    exp_key, _ = provider.create_api_key("user-b", ["eval:read"], expires_in_seconds=1)
    now = time.time()
    monkeypatch.setattr(auth_mod.time, "time", lambda: now + 10)
    assert provider.verify_api_key(exp_key) is None


def test_authorize_require_auth_and_require_permission() -> None:
    provider = _provider()
    auth_mod.set_default_provider(provider)

    token = provider.create_jwt("u-10", "u10@example.com", permissions=["memory:*"])
    headers = {"Authorization": f"Bearer {token}"}

    user = auth_mod.get_current_user(headers)
    assert user is not None
    assert provider.authorize(user, "memory", "read") is True
    assert provider.authorize(user, "memory", "delete") is True

    admin = AuthUser("admin", "a@example.com", permissions=["*:*"])
    assert provider.authorize(admin, "anything", "write") is True

    required = auth_mod.require_auth(headers)
    assert required.user_id == "u-10"

    auth_mod.require_permission(required, "memory", "write")

    with pytest.raises(PermissionError):
        auth_mod.require_permission(required, "eval", "write")

    with pytest.raises(PermissionError):
        auth_mod.require_auth({})


def test_get_default_provider_lazily_initializes() -> None:
    default_provider = auth_mod.get_default_provider()
    assert isinstance(default_provider, AuthProvider)
    assert auth_mod.get_current_user({}) is None
