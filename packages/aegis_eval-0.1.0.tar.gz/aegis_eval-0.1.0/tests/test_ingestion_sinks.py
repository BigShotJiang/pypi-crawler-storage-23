"""Tests for ingestion sinks, entity extractor, and pipeline storage wiring."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from aegis.ingestion.entity_extractor import (
    Entity,
    ExtractedEntities,
    Relation,
    SimpleEntityExtractor,
)
from aegis.ingestion.parsers import Modality, ParsedChunk
from aegis.ingestion.pipeline import IngestionConfig, IngestionPipeline, IngestionResult
from aegis.ingestion.sinks import CompositeSink, Neo4jSink, PgVectorSink, Sink

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_chunks(n: int = 3) -> list[ParsedChunk]:
    """Create *n* simple parsed chunks for testing."""
    return [
        ParsedChunk(
            content=f"Chunk {i} content with enough words for testing purposes here.",
            modality=Modality.TEXT,
            source_path="/tmp/test.txt",
            chunk_index=i,
            metadata={"content_hash": f"hash{i}"},
            confidence=0.9,
        )
        for i in range(n)
    ]


def _make_result(chunks: list[ParsedChunk] | None = None) -> IngestionResult:
    """Create an IngestionResult for testing."""
    chunks = chunks or _make_chunks()
    return IngestionResult(
        source_path="/tmp/test.txt",
        num_chunks=len(chunks),
        chunks=chunks,
        modality=Modality.TEXT,
        document_id="test-doc-001",
    )


class DummySink(Sink):
    """A simple in-memory sink for testing."""

    def __init__(self, name: str = "DummySink") -> None:
        self._name = name
        self.written: list[tuple[list[ParsedChunk], str, dict[str, Any]]] = []
        self.flushed = False

    @property
    def name(self) -> str:
        return self._name

    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        self.written.append((chunks, document_id, metadata))
        return len(chunks)

    def flush(self) -> None:
        self.flushed = True


class FailingSink(Sink):
    """A sink that always raises on write."""

    @property
    def name(self) -> str:
        return "FailingSink"

    def write(
        self,
        chunks: list[ParsedChunk],
        document_id: str,
        metadata: dict[str, Any],
    ) -> int:
        raise RuntimeError("Intentional write failure")

    def flush(self) -> None:
        raise RuntimeError("Intentional flush failure")


# ---------------------------------------------------------------------------
# SimpleEntityExtractor tests
# ---------------------------------------------------------------------------


class TestSimpleEntityExtractor:
    def test_extract_organizations(self) -> None:
        text = "Acme Corp reported earnings. Globex Inc had strong growth."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        org_texts = [e.text for e in result.entities if e.entity_type == "ORG"]
        assert any("Acme Corp" in t for t in org_texts)
        assert any("Globex Inc" in t for t in org_texts)

    def test_extract_dates_iso(self) -> None:
        text = "The filing was made on 2024-01-15 and reviewed on 2024-03-20."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        date_texts = [e.text for e in result.entities if e.entity_type == "DATE"]
        assert "2024-01-15" in date_texts
        assert "2024-03-20" in date_texts

    def test_extract_dates_verbose(self) -> None:
        text = "Filed on January 15, 2024 and heard in court March 20, 2024."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        date_texts = [e.text for e in result.entities if e.entity_type == "DATE"]
        assert any("January 15, 2024" in d for d in date_texts)

    def test_extract_money(self) -> None:
        text = "The settlement was $5.2 million. Revenue exceeded $100,000."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        money_texts = [e.text for e in result.entities if e.entity_type == "MONEY"]
        assert any("$5.2 million" in m for m in money_texts)
        assert any("$100,000" in m for m in money_texts)

    def test_extract_legal_terms(self) -> None:
        text = "The plaintiff filed a motion. The defendant objected. The court ruled."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        legal_texts = [e.text.lower() for e in result.entities if e.entity_type == "LEGAL_TERM"]
        assert "plaintiff" in legal_texts
        assert "defendant" in legal_texts
        assert "court" in legal_texts

    def test_extract_financial_terms(self) -> None:
        text = "EBITDA grew by 15%. Revenue was strong. Profit margin improved."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        fin_texts = [e.text for e in result.entities if e.entity_type == "FINANCIAL_TERM"]
        # Check case-insensitively
        fin_lower = [t.lower() for t in fin_texts]
        assert "ebitda" in fin_lower or "EBITDA" in fin_texts
        assert "revenue" in fin_lower

    def test_extract_percentage(self) -> None:
        text = "Growth rate was 15.5% year over year."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        pct_texts = [e.text for e in result.entities if e.entity_type == "PERCENTAGE"]
        assert any("15.5%" in p for p in pct_texts)

    def test_entity_positions(self) -> None:
        text = "Acme Corp is headquartered in NYC."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        orgs = [e for e in result.entities if e.entity_type == "ORG"]
        assert len(orgs) >= 1
        org = orgs[0]
        assert org.start >= 0
        assert org.end > org.start
        assert text[org.start : org.end].strip().startswith("Acme")

    def test_entities_sorted_by_position(self) -> None:
        text = "On 2024-01-15, Acme Corp earned $10 million in revenue."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        positions = [e.start for e in result.entities]
        assert positions == sorted(positions)

    def test_infer_org_money_relation(self) -> None:
        text = "Acme Corp reported revenue of $50 million."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        has_value_rels = [r for r in result.relations if r.predicate == "has_value"]
        assert len(has_value_rels) >= 1
        rel = has_value_rels[0]
        assert "Acme" in rel.subject
        assert "$50 million" in rel.object

    def test_infer_org_financial_metric_relation(self) -> None:
        text = "Acme Corp EBITDA improved significantly this quarter."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        metric_rels = [r for r in result.relations if r.predicate == "has_metric"]
        assert len(metric_rels) >= 1

    def test_infer_legal_relation(self) -> None:
        text = "The plaintiff Acme Corp filed a suit."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        legal_rels = [r for r in result.relations if r.predicate in ("filed_by", "involves")]
        assert len(legal_rels) >= 1

    def test_empty_text_returns_empty(self) -> None:
        extractor = SimpleEntityExtractor()
        result = extractor.extract("")
        assert result.entities == []
        assert result.relations == []

    def test_no_entities_text(self) -> None:
        extractor = SimpleEntityExtractor()
        result = extractor.extract("The quick brown fox jumps over the lazy dog.")
        # May or may not have entities depending on patterns, but should not crash
        assert isinstance(result, ExtractedEntities)

    def test_return_types(self) -> None:
        extractor = SimpleEntityExtractor()
        result = extractor.extract("Acme Corp earned $10 million on 2024-01-15.")
        assert isinstance(result, ExtractedEntities)
        for e in result.entities:
            assert isinstance(e, Entity)
        for r in result.relations:
            assert isinstance(r, Relation)
            assert 0.0 <= r.confidence <= 1.0

    def test_llc_org_pattern(self) -> None:
        text = "Smith & Partners LLC was acquired."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        org_texts = [e.text for e in result.entities if e.entity_type == "ORG"]
        assert any("LLC" in t for t in org_texts)

    def test_ltd_org_pattern(self) -> None:
        text = "Baker Holdings Ltd announced results."
        extractor = SimpleEntityExtractor()
        result = extractor.extract(text)
        org_texts = [e.text for e in result.entities if e.entity_type == "ORG"]
        assert any("Ltd" in t for t in org_texts)


# ---------------------------------------------------------------------------
# PgVectorSink tests
# ---------------------------------------------------------------------------


class TestPgVectorSink:
    def test_write_stores_entries(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        chunks = _make_chunks(3)
        count = sink.write(chunks, document_id="doc-001", metadata={"source": "test"})
        assert count == 3
        assert mock_store.store.call_count == 3

    def test_write_creates_memory_entries(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        chunks = _make_chunks(1)
        sink.write(chunks, document_id="doc-001", metadata={})

        stored_entry = mock_store.store.call_args[0][0]
        assert stored_entry.key == "doc-001:chunk:0"
        assert stored_entry.value == chunks[0].content
        assert stored_entry.provenance["document_id"] == "doc-001"
        assert stored_entry.provenance["source_path"] == "/tmp/test.txt"
        assert "doc:doc-001" in stored_entry.tags

    def test_write_handles_store_exception(self) -> None:
        mock_store = MagicMock()
        mock_store.store.side_effect = RuntimeError("DB error")
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        chunks = _make_chunks(2)
        count = sink.write(chunks, document_id="doc-001", metadata={})
        assert count == 0  # All failed

    def test_name(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        assert sink.name == "PgVectorSink"

    def test_flush_is_noop(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        sink.flush()  # Should not raise

    def test_requires_store_or_dsn(self) -> None:
        with pytest.raises(ValueError, match="Either store or dsn"):
            PgVectorSink(store=None, dsn=None, enable_embeddings=False)

    def test_metadata_merged(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        chunks = _make_chunks(1)
        sink.write(chunks, document_id="doc-001", metadata={"extra_key": "extra_value"})

        stored_entry = mock_store.store.call_args[0][0]
        assert stored_entry.metadata["extra_key"] == "extra_value"
        assert stored_entry.metadata["document_id"] == "doc-001"

    def test_write_empty_chunks(self) -> None:
        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        count = sink.write([], document_id="doc-001", metadata={})
        assert count == 0
        mock_store.store.assert_not_called()


# ---------------------------------------------------------------------------
# Neo4jSink tests
# ---------------------------------------------------------------------------


class TestNeo4jSink:
    def test_write_creates_document_node(self) -> None:
        mock_graph = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        chunks = _make_chunks(1)
        sink.write(chunks, document_id="doc-001", metadata={})

        # Check that add_node was called with the document node
        node_calls = [c[0][0] for c in mock_graph.add_node.call_args_list]
        assert "doc:doc-001" in node_calls

    def test_write_creates_chunk_nodes(self) -> None:
        mock_graph = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        chunks = _make_chunks(2)
        sink.write(chunks, document_id="doc-001", metadata={})

        node_calls = [c[0][0] for c in mock_graph.add_node.call_args_list]
        assert "chunk:doc-001:0" in node_calls
        assert "chunk:doc-001:1" in node_calls

    def test_write_creates_contains_edges(self) -> None:
        mock_graph = MagicMock()
        mock_graph.add_edge.return_value = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        chunks = _make_chunks(2)
        sink.write(chunks, document_id="doc-001", metadata={})

        # Filter CONTAINS edges
        contains_calls = [
            c
            for c in mock_graph.add_edge.call_args_list
            if c[1].get("relation") == "CONTAINS" or (len(c[0]) > 2 and c[0][2] == "CONTAINS")
        ]
        assert len(contains_calls) >= 2

    def test_write_extracts_entities(self) -> None:
        mock_graph = MagicMock()
        mock_graph.add_edge.return_value = MagicMock()
        sink = Neo4jSink(graph=mock_graph)

        # Chunk with entities that the extractor should pick up
        chunks = [
            ParsedChunk(
                content="Acme Corp reported revenue of $50 million on 2024-01-15.",
                modality=Modality.TEXT,
                source_path="/tmp/test.txt",
                chunk_index=0,
            )
        ]
        count = sink.write(chunks, document_id="doc-001", metadata={})
        assert count > 3  # doc node + chunk node + CONTAINS edge + entity nodes + MENTIONS edges

    def test_write_returns_count(self) -> None:
        mock_graph = MagicMock()
        mock_graph.add_edge.return_value = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        chunks = _make_chunks(1)
        count = sink.write(chunks, document_id="doc-001", metadata={})
        # At minimum: 1 doc node + 1 chunk node + 1 CONTAINS edge = 3
        assert count >= 3

    def test_name(self) -> None:
        mock_graph = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        assert sink.name == "Neo4jSink"

    def test_flush_is_noop(self) -> None:
        mock_graph = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        sink.flush()  # Should not raise

    def test_requires_graph_or_uri(self) -> None:
        with pytest.raises(ValueError, match="Either graph or uri"):
            Neo4jSink(graph=None, uri=None)

    def test_write_empty_chunks(self) -> None:
        mock_graph = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        count = sink.write([], document_id="doc-001", metadata={})
        # Still creates the document node
        assert count >= 1

    def test_handles_graph_exception(self) -> None:
        mock_graph = MagicMock()
        mock_graph.add_node.side_effect = RuntimeError("Graph error")
        sink = Neo4jSink(graph=mock_graph)
        chunks = _make_chunks(1)
        # Should not raise — errors are logged
        count = sink.write(chunks, document_id="doc-001", metadata={})
        assert count == 0


# ---------------------------------------------------------------------------
# CompositeSink tests
# ---------------------------------------------------------------------------


class TestCompositeSink:
    def test_writes_to_all_sinks(self) -> None:
        sink_a = DummySink("A")
        sink_b = DummySink("B")
        composite = CompositeSink([sink_a, sink_b])
        chunks = _make_chunks(3)

        count = composite.write(chunks, document_id="doc-001", metadata={"key": "val"})
        assert count == 6  # 3 per sink
        assert len(sink_a.written) == 1
        assert len(sink_b.written) == 1

    def test_returns_total_count(self) -> None:
        sink_a = DummySink("A")
        sink_b = DummySink("B")
        composite = CompositeSink([sink_a, sink_b])
        count = composite.write(_make_chunks(5), document_id="doc-001", metadata={})
        assert count == 10

    def test_flush_all_sinks(self) -> None:
        sink_a = DummySink("A")
        sink_b = DummySink("B")
        composite = CompositeSink([sink_a, sink_b])
        composite.flush()
        assert sink_a.flushed is True
        assert sink_b.flushed is True

    def test_name(self) -> None:
        composite = CompositeSink([])
        assert composite.name == "CompositeSink"

    def test_sinks_property(self) -> None:
        sink_a = DummySink("A")
        sink_b = DummySink("B")
        composite = CompositeSink([sink_a, sink_b])
        assert len(composite.sinks) == 2

    def test_sinks_property_returns_copy(self) -> None:
        sink_a = DummySink("A")
        composite = CompositeSink([sink_a])
        sinks = composite.sinks
        sinks.clear()
        assert len(composite.sinks) == 1

    def test_empty_composite(self) -> None:
        composite = CompositeSink([])
        count = composite.write(_make_chunks(2), document_id="doc-001", metadata={})
        assert count == 0

    def test_tolerates_failing_sink(self) -> None:
        sink_ok = DummySink("OK")
        sink_fail = FailingSink()
        composite = CompositeSink([sink_ok, sink_fail])
        chunks = _make_chunks(2)

        count = composite.write(chunks, document_id="doc-001", metadata={})
        assert count == 2  # Only the good sink's writes counted
        assert len(sink_ok.written) == 1

    def test_flush_tolerates_failure(self) -> None:
        sink_ok = DummySink("OK")
        sink_fail = FailingSink()
        composite = CompositeSink([sink_ok, sink_fail])
        composite.flush()  # Should not raise
        assert sink_ok.flushed is True


# ---------------------------------------------------------------------------
# IngestionPipeline.store_results() tests
# ---------------------------------------------------------------------------


class TestIngestionPipelineStoreResults:
    def test_store_results_with_sinks(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest(
            "doc.txt",
            content="Paragraph one content here.\n\nParagraph two content here.",
        )

        sink = DummySink("test")
        counts = pipeline.store_results(result, sinks=[sink])
        assert "test" in counts
        assert counts["test"] == result.num_chunks
        assert sink.flushed is True

    def test_store_results_no_sinks(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest("doc.txt", content="Some content here for testing now.")
        counts = pipeline.store_results(result, sinks=None)
        assert counts == {}

    def test_store_results_empty_sinks(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest("doc.txt", content="Some content here for testing now.")
        counts = pipeline.store_results(result, sinks=[])
        assert counts == {}

    def test_store_results_multiple_sinks(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest(
            "doc.txt",
            content="Hello world this is a test for sinks.",
        )

        sink_a = DummySink("SinkA")
        sink_b = DummySink("SinkB")
        counts = pipeline.store_results(result, sinks=[sink_a, sink_b])
        assert "SinkA" in counts
        assert "SinkB" in counts
        assert sink_a.flushed is True
        assert sink_b.flushed is True

    def test_store_results_passes_metadata(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest("doc.txt", content="Content with enough words here now.")
        result.metadata["custom_key"] = "custom_value"

        sink = DummySink("test")
        pipeline.store_results(result, sinks=[sink])

        _, doc_id, metadata = sink.written[0]
        assert doc_id == result.document_id
        assert metadata["source_path"] == "doc.txt"
        assert metadata["modality"] == "text"
        assert metadata["custom_key"] == "custom_value"

    def test_store_results_passes_document_id(self) -> None:
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest("doc.txt", content="Some text content for testing here.")

        sink = DummySink("test")
        pipeline.store_results(result, sinks=[sink])
        _, doc_id, _ = sink.written[0]
        assert doc_id == result.document_id

    def test_end_to_end_with_mock_pgvector(self) -> None:
        """End-to-end: ingest, then store to mocked PgVectorStore."""
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest(
            "doc.txt",
            content="First paragraph with enough words.\n\nSecond paragraph with enough words.",
        )

        mock_store = MagicMock()
        sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        counts = pipeline.store_results(result, sinks=[sink])

        assert counts["PgVectorSink"] == result.num_chunks
        assert mock_store.store.call_count == result.num_chunks

    def test_end_to_end_with_mock_neo4j(self) -> None:
        """End-to-end: ingest, then store to mocked Neo4jGraph."""
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest(
            "doc.txt",
            content="Acme Corp reported earnings of $10 million.",
        )

        mock_graph = MagicMock()
        mock_graph.add_edge.return_value = MagicMock()
        sink = Neo4jSink(graph=mock_graph)
        counts = pipeline.store_results(result, sinks=[sink])

        assert counts["Neo4jSink"] > 0
        assert mock_graph.add_node.called
        assert mock_graph.add_edge.called

    def test_end_to_end_composite(self) -> None:
        """End-to-end: ingest, then store to both backends via CompositeSink."""
        pipeline = IngestionPipeline(config=IngestionConfig(min_chunk_words=1))
        result = pipeline.ingest(
            "doc.txt",
            content="Acme Corp earned $50 million in revenue.",
        )

        mock_store = MagicMock()
        mock_graph = MagicMock()
        mock_graph.add_edge.return_value = MagicMock()

        pg_sink = PgVectorSink(store=mock_store, enable_embeddings=False)
        neo4j_sink = Neo4jSink(graph=mock_graph)

        counts = pipeline.store_results(result, sinks=[pg_sink, neo4j_sink])

        assert "PgVectorSink" in counts
        assert "Neo4jSink" in counts
        assert counts["PgVectorSink"] == result.num_chunks
        assert counts["Neo4jSink"] > 0


# ---------------------------------------------------------------------------
# Sink ABC tests
# ---------------------------------------------------------------------------


class TestSinkABC:
    def test_default_name_is_classname(self) -> None:
        sink = DummySink()
        # DummySink overrides name, but test the concept
        assert sink.name == "DummySink"

    def test_cannot_instantiate_abstract(self) -> None:
        with pytest.raises(TypeError):
            Sink()  # type: ignore[abstract]
