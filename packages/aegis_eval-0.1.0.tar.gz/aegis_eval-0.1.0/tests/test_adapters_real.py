"""Mocked integration tests for real adapter behaviors."""

from __future__ import annotations

import sys
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from aegis.adapters.anthropic import AnthropicAdapter
from aegis.adapters.dspy import DSPyAdapter
from aegis.adapters.langchain import LangChainAdapter
from aegis.adapters.langgraph import LangGraphAdapter
from aegis.adapters.llamaindex import LlamaIndexAdapter
from aegis.adapters.openai import OpenAIAdapter
from aegis.core.exceptions import AdapterError
from aegis.core.types import EvalCaseV1, EvalTier, StepKind


def _case(prompt: str = "Test prompt") -> EvalCaseV1:
    return EvalCaseV1(
        suite_id="adapter-suite",
        dimension_id="adapter-dimension",
        tier=EvalTier.REASONING_QUALITY,
        prompt=prompt,
        context={"customer_id": "cust-123"},
    )


def test_openai_adapter_captures_tool_calls_and_tokens() -> None:
    client = MagicMock()

    thread = SimpleNamespace(id="thread_1")
    run = SimpleNamespace(
        id="run_1",
        status="completed",
        usage=SimpleNamespace(total_tokens=123),
    )

    assistant_message = SimpleNamespace(
        role="assistant",
        content=[
            SimpleNamespace(text=SimpleNamespace(value="hello")),
            SimpleNamespace(text=SimpleNamespace(value="world")),
        ],
    )
    messages_page = SimpleNamespace(data=[assistant_message])

    tool_call = SimpleNamespace(
        type="function",
        function=SimpleNamespace(name="retrieve_policy"),
    )
    run_step = SimpleNamespace(
        id="step_1",
        step_details=SimpleNamespace(type="tool_calls", tool_calls=[tool_call]),
    )
    run_steps_page = SimpleNamespace(data=[run_step])

    client.beta.threads.create.return_value = thread
    client.beta.threads.messages.create.return_value = None
    client.beta.threads.runs.create_and_poll.return_value = run
    client.beta.threads.messages.list.return_value = messages_page
    client.beta.threads.runs.steps.list.return_value = run_steps_page

    adapter = OpenAIAdapter(client=client, assistant_id="asst_1")
    trajectory = adapter.evaluate(_case())

    assert trajectory.total_tokens == 123
    assert trajectory.steps[0].kind == StepKind.TOOL_CALL
    assert "retrieve_policy" in trajectory.steps[0].content
    assert trajectory.steps[-1].kind == StepKind.ANSWER
    assert trajectory.steps[-1].content == "hello world"
    assert trajectory.metadata["assistant_id"] == "asst_1"


def test_openai_adapter_raises_adapter_error_on_client_failure() -> None:
    client = MagicMock()
    client.beta.threads.create.side_effect = RuntimeError("network down")

    adapter = OpenAIAdapter(client=client, assistant_id="asst_1")
    with pytest.raises(AdapterError):
        adapter.evaluate(_case())


def test_anthropic_adapter_captures_tool_calls_and_tokens() -> None:
    client = MagicMock()

    tool_block = SimpleNamespace(
        type="tool_use",
        name="lookup_statute",
        input={"section": "4.2"},
        id="tool_1",
    )
    text_block = SimpleNamespace(type="text", text="Clause 4.2 governs this case.")
    message = SimpleNamespace(
        id="msg_1",
        content=[tool_block, text_block],
        usage=SimpleNamespace(input_tokens=10, output_tokens=20),
        stop_reason="end_turn",
    )
    client.messages.create.return_value = message

    adapter = AnthropicAdapter(client=client, model="claude-sonnet-4-20250514")
    trajectory = adapter.evaluate(_case())

    assert trajectory.total_tokens == 30
    assert trajectory.steps[0].kind == StepKind.TOOL_CALL
    assert "lookup_statute" in trajectory.steps[0].content
    assert trajectory.steps[-1].kind == StepKind.ANSWER
    assert "Clause 4.2" in trajectory.steps[-1].content
    assert trajectory.metadata["stop_reason"] == "end_turn"


def test_anthropic_adapter_raises_adapter_error_on_client_failure() -> None:
    client = MagicMock()
    client.messages.create.side_effect = RuntimeError("timeout")

    adapter = AnthropicAdapter(client=client)
    with pytest.raises(AdapterError):
        adapter.evaluate(_case())


def test_langchain_adapter_captures_reasoning_tools_and_answer() -> None:
    action = SimpleNamespace(
        tool="search_policy",
        tool_input="NDA termination",
        log="Need to search for termination clauses.",
    )
    executor = MagicMock()
    executor.invoke.return_value = {
        "intermediate_steps": [(action, "Found clause 8.1 in policy handbook.")],
        "output": "Clause 8.1 controls termination.",
        "token_usage": {"total_tokens": 77},
    }

    adapter = LangChainAdapter(agent_executor=executor)
    trajectory = adapter.evaluate(_case())

    assert [step.kind for step in trajectory.steps] == [
        StepKind.REASON,
        StepKind.SEARCH,
        StepKind.ANSWER,
    ]
    assert trajectory.total_tokens == 77
    assert "Clause 8.1" in trajectory.steps[-1].content


def test_llamaindex_adapter_captures_retrieval_nodes_and_answer() -> None:
    class _Node:
        def __init__(self) -> None:
            self.node_id = "n1"
            self.metadata = {"source": "kb"}

        def get_content(self) -> str:
            return "Retrieved evidence from KB."

    class _Response:
        def __init__(self) -> None:
            self.source_nodes = [SimpleNamespace(node=_Node(), score=0.88)]
            self.metadata = {"prompt_tokens": 5, "completion_tokens": 7}

        def __str__(self) -> str:
            return "Final synthesized answer."

    engine = MagicMock()
    engine.query.return_value = _Response()

    adapter = LlamaIndexAdapter(query_engine=engine)
    trajectory = adapter.evaluate(_case())

    assert trajectory.steps[0].kind == StepKind.SEARCH
    assert "Retrieved evidence" in trajectory.steps[0].content
    assert trajectory.steps[-1].kind == StepKind.ANSWER
    assert trajectory.steps[-1].content == "Final synthesized answer."
    assert trajectory.total_tokens == 12


def test_langgraph_adapter_streams_node_transitions() -> None:
    graph = MagicMock()
    graph.stream.return_value = [
        {"planner_node": {"content": "Drafted plan"}},
        {"tool_search": {"output": "Retrieved source"}},
        {"answer_node": {"response": "Completed response"}},
    ]

    with patch.dict(sys.modules, {"langgraph": MagicMock()}):
        adapter = LangGraphAdapter(graph=graph)
        trajectory = adapter.evaluate(_case())

    assert trajectory.steps
    assert any(step.kind == StepKind.TOOL_CALL for step in trajectory.steps)
    assert trajectory.steps[-1].kind == StepKind.ANSWER


def test_dspy_adapter_captures_trace_rationale_and_answer() -> None:
    prediction = SimpleNamespace(
        history=[{"action": "search", "content": "looked up regulation"}],
        passages=["regulation excerpt"],
        rationale="Need to apply the newest amendment.",
        answer="Use Amendment 2025-B.",
    )
    module = MagicMock(return_value=prediction)

    with patch.dict(sys.modules, {"dspy": MagicMock()}):
        adapter = DSPyAdapter(module=module)
        trajectory = adapter.evaluate(_case())

    kinds = [step.kind for step in trajectory.steps]
    assert StepKind.SEARCH in kinds
    assert StepKind.REASON in kinds
    assert trajectory.steps[-1].kind == StepKind.ANSWER
    assert "Amendment 2025-B" in trajectory.steps[-1].content
