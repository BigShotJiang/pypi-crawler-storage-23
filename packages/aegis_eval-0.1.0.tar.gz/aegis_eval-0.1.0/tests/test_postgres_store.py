"""Tests for the PostgreSQL/pgvector store backend.

These tests verify the PgVectorStore against a mock connection when the
real database is unavailable, and also test the module-level import guard.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from unittest.mock import patch

import pytest

from aegis.core.types import MemoryTier
from aegis.memory.types import MemoryEntry


def _make_entry(key: str = "test-key", value: str = "test value") -> MemoryEntry:
    return MemoryEntry(
        key=key,
        value=value,
        tier=MemoryTier.WORKING,
        confidence=0.95,
        tags=["test"],
        metadata={"source": "unit-test"},
    )


class TestPgVectorStoreImport:
    """Test that the lazy import mechanism works."""

    def test_store_init_requires_psycopg(self) -> None:
        """PgVectorStore should raise RuntimeError if psycopg is not installed."""
        with patch.dict("sys.modules", {"psycopg": None}):
            # Re-import to pick up the patch

            from aegis.store import postgres as pg_mod

            original = pg_mod._HAS_PG
            pg_mod._HAS_PG = False
            try:
                with pytest.raises(RuntimeError, match="psycopg"):
                    pg_mod.PgVectorStore(dsn="postgresql://fake")
            finally:
                pg_mod._HAS_PG = original

    def test_lazy_import_from_store_package(self) -> None:
        """Importing PgVectorStore from aegis.store should not crash."""
        from aegis.store import PgVectorStore

        assert PgVectorStore is not None


class TestPostgresEvalStoreImport:
    """Test that the PostgresEvalStore import guard works."""

    def test_store_init_requires_psycopg(self) -> None:
        """PostgresEvalStore should raise RuntimeError if psycopg is not installed."""
        from aegis.store import postgres_eval as pg_eval_mod

        original = pg_eval_mod._HAS_PG
        pg_eval_mod._HAS_PG = False
        try:
            with pytest.raises(RuntimeError, match="psycopg"):
                pg_eval_mod.PostgresEvalStore(dsn="postgresql://fake")
        finally:
            pg_eval_mod._HAS_PG = original

    def test_safe_json_serialises_datetimes(self) -> None:
        from aegis.store.postgres_eval import _safe_json

        now = datetime.now(tz=UTC)
        result = _safe_json({"ts": now, "name": "test"})
        assert now.isoformat() in result
        assert "test" in result

    def test_dt_to_pg_from_string(self) -> None:
        from aegis.store.postgres_eval import _dt_to_pg

        dt = _dt_to_pg("2025-01-15T12:00:00+00:00")
        assert isinstance(dt, datetime)
        assert dt.year == 2025

    def test_dt_to_pg_from_datetime(self) -> None:
        from aegis.store.postgres_eval import _dt_to_pg

        now = datetime.now(tz=UTC)
        assert _dt_to_pg(now) is now

    def test_dt_to_pg_fallback(self) -> None:
        from aegis.store.postgres_eval import _dt_to_pg

        assert _dt_to_pg(None) == datetime.min


class TestPgVectorStoreRowConversion:
    """Test the static row-to-entry conversion."""

    def test_row_to_entry(self) -> None:
        from aegis.store.postgres import PgVectorStore

        now = datetime.now(tz=UTC)
        row = (
            "key-1",
            json.dumps("hello world"),
            "working",
            0.9,
            json.dumps({"src": "test"}),
            json.dumps(["tag1"]),
            now,
            now,
            5,
            json.dumps({"m": 1}),
        )
        entry = PgVectorStore._row_to_entry(row)
        assert entry.key == "key-1"
        assert entry.value == "hello world"
        assert entry.tier == MemoryTier.WORKING
        assert entry.confidence == 0.9
        assert entry.tags == ["tag1"]
        assert entry.access_count == 5

    def test_row_to_entry_dict_value(self) -> None:
        from aegis.store.postgres import PgVectorStore

        now = datetime.now(tz=UTC)
        row = (
            "key-2",
            {"nested": "data"},  # Already parsed by psycopg JSONB
            "session",
            0.8,
            {"src": "test"},
            ["tag1", "tag2"],
            now,
            now,
            0,
            {},
        )
        entry = PgVectorStore._row_to_entry(row)
        assert entry.key == "key-2"
        assert entry.value == {"nested": "data"}
        assert entry.tier == MemoryTier.SESSION
