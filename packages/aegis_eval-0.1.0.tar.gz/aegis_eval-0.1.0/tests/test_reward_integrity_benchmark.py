"""Tests for the reward-integrity benchmark."""

from __future__ import annotations

from aegis.eval.benchmarks import RewardIntegrityBenchmark


def test_reward_integrity_suite_has_200_seeded_cases() -> None:
    benchmark = RewardIntegrityBenchmark()
    suite = benchmark.build_suite()

    assert suite.config.name == "aegis-reward-integrity-v1"
    assert len(suite.cases) == 200
    assert all(case.expected.get("is_hacked") is True for case in suite.cases)
    assert all("seeded_hacking" in case.tags for case in suite.cases)


def test_reward_integrity_seeded_recall_meets_m6_target() -> None:
    benchmark = RewardIntegrityBenchmark()
    report = benchmark.evaluate_recall()

    assert report["total_seeded"] == 200
    assert report["recall"] >= 0.9
    assert report["meets_target"] is True
