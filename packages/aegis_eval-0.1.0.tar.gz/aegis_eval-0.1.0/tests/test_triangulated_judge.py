"""Tests for triangulated judge weighting behavior."""

from __future__ import annotations

from typing import Any

from aegis.eval.judges.triangulated import TriangulatedJudge


class _ConstantScorer:
    def __init__(self, value: float) -> None:
        self._value = value

    def score(self, agent_output: Any, ground_truth: Any, **kwargs: Any) -> float:  # noqa: ARG002
        return self._value


class _ConstantLLMScorer(_ConstantScorer):
    def __init__(self, value: float, *, exhausted: bool = False) -> None:
        super().__init__(value)
        self._exhausted = exhausted

    @property
    def budget_exhausted(self) -> bool:
        return self._exhausted

    def budget_summary(self) -> dict[str, float | bool]:
        return {"budget_exhausted": self._exhausted, "spent_cost_usd": 0.0}


def test_non_adaptive_weights_respect_explicit_configuration() -> None:
    judge = TriangulatedJudge(
        rule_scorer=_ConstantScorer(0.2),
        semantic_scorer=_ConstantScorer(0.6),
        llm_scorer=_ConstantLLMScorer(0.9),
        weights=(0.2, 0.3, 0.5),
        adaptive_weighting=False,
    )

    packet = judge.judge("output", "truth")
    assert abs(packet.ensemble_score - 0.67) < 1e-6
    assert packet.evidence["weights"]["llm"] == 0.5


def test_adaptive_weighting_boosts_llm_on_rule_semantic_disagreement() -> None:
    judge = TriangulatedJudge(
        rule_scorer=_ConstantScorer(0.1),
        semantic_scorer=_ConstantScorer(0.9),
        llm_scorer=_ConstantLLMScorer(0.8),
        weights=(1 / 3, 1 / 3, 1 / 3),
        adaptive_weighting=True,
    )

    packet = judge.judge("output", "truth")
    assert packet.evidence["weights"]["llm"] > (1 / 3)


def test_budget_exhaustion_downweights_llm_to_zero() -> None:
    judge = TriangulatedJudge(
        rule_scorer=_ConstantScorer(0.6),
        semantic_scorer=_ConstantScorer(0.4),
        llm_scorer=_ConstantLLMScorer(0.9, exhausted=True),
        weights=(0.3, 0.3, 0.4),
        adaptive_weighting=True,
    )

    packet = judge.judge("output", "truth")
    assert packet.evidence["weights"]["llm"] == 0.0
    assert abs(packet.ensemble_score - 0.5) < 1e-6


def test_context_weight_override_takes_precedence() -> None:
    judge = TriangulatedJudge(
        rule_scorer=_ConstantScorer(0.5),
        semantic_scorer=_ConstantScorer(0.5),
        llm_scorer=_ConstantLLMScorer(0.5),
        weights=(1 / 3, 1 / 3, 1 / 3),
        adaptive_weighting=True,
    )

    packet = judge.judge("output", "truth", context={"weights": [0.6, 0.2, 0.2]})
    assert packet.evidence["weights"]["rule"] == 0.6
    assert packet.evidence["weights"]["semantic"] == 0.2
    assert packet.evidence["weights"]["llm"] == 0.2
