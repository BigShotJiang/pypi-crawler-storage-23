"""Tests for arena submission validation and execution."""

from __future__ import annotations

from aegis.arena.submission import SubmissionRunner, SubmissionValidator


def _submission_payload() -> dict[str, object]:
    return {
        "agent_name": "CounselBot",
        "agent_description": "Legal assistant focused on clause tracking and citation accuracy.",
        "framework": "openai",
        "domains": ["legal"],
        "model_size": "large",
        "public": True,
        "metadata": {"compute_cost_usd": 1.5},
    }


def test_validator_rejects_missing_required_field() -> None:
    validator = SubmissionValidator()
    is_valid, errors = validator.validate({"framework": "openai", "domains": ["legal"]})
    assert is_valid is False
    assert any("agent_name" in error for error in errors)


def test_runner_scores_are_deterministic() -> None:
    runner = SubmissionRunner()
    payload = _submission_payload()

    first = runner.run(payload)
    second = runner.run(payload)

    assert first["status"] == "completed"
    assert second["status"] == "completed"
    assert first["scores"] == second["scores"]
    assert "memory_fidelity" in first["scores"]
    assert "legal_clause_tracking" in first["scores"]


def test_runner_enforces_sandbox_timeout() -> None:
    runner = SubmissionRunner(sandbox_timeout=1)
    payload = _submission_payload()
    payload["metadata"] = {"estimated_runtime_ms": 2000}

    result = runner.run(payload)
    assert result["status"] == "failed"
    errors = result.get("errors", [])
    assert isinstance(errors, list)
    assert errors
    assert "sandbox timeout" in str(errors[0]).lower()
