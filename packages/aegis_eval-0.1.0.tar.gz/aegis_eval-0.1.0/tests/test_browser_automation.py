"""Tests for the Playwright browser automation client."""

from __future__ import annotations

import asyncio
import warnings
from unittest.mock import AsyncMock, MagicMock, patch

from aegis.ingestion.browser import BrowserAutomationClient
from aegis.ingestion.web import WebPage

# ---------------------------------------------------------------------------
# Basic construction
# ---------------------------------------------------------------------------


class TestBrowserAutomationClientInit:
    """Tests for BrowserAutomationClient construction."""

    def test_default_init(self) -> None:
        client = BrowserAutomationClient()
        assert client._browser_type == "chromium"
        assert client._headless is True
        assert client._launched is False

    def test_custom_init(self) -> None:
        client = BrowserAutomationClient(
            browser_type="firefox",
            headless=False,
            cache_dir=".cache/test_browser",
            rate_limit_rpm=60,
        )
        assert client._browser_type == "firefox"
        assert client._headless is False

    def test_inherits_webingester(self) -> None:
        from aegis.ingestion.web import WebIngester

        client = BrowserAutomationClient()
        assert isinstance(client, WebIngester)


# ---------------------------------------------------------------------------
# Fallback behaviour (no Playwright)
# ---------------------------------------------------------------------------


class TestFallbackBehaviour:
    """Test graceful fallback when Playwright is not installed."""

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", False)
    def test_fetch_falls_back_to_parent(self) -> None:
        """When Playwright is not available, fetch() delegates to WebIngester."""
        client = BrowserAutomationClient()
        with patch.object(
            client.__class__.__bases__[0],
            "fetch",
            return_value=WebPage(
                url="http://example.com", title="Test", content="<html>test</html>"
            ),
        ) as mock_fetch:
            result = client.fetch("http://example.com")
            mock_fetch.assert_called_once_with("http://example.com")
            assert result.url == "http://example.com"

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", False)
    def test_fetch_dynamic_warns_and_falls_back(self) -> None:
        """fetch_dynamic should warn when Playwright is missing."""
        client = BrowserAutomationClient()
        with (
            patch.object(
                client.__class__.__bases__[0],
                "fetch",
                return_value=WebPage(url="http://example.com", title="", content=""),
            ),
            warnings.catch_warnings(record=True) as w,
        ):
            warnings.simplefilter("always")
            result = asyncio.run(client.fetch_dynamic("http://example.com"))
            assert len(w) >= 1
            assert "Playwright not installed" in str(w[0].message)
            assert isinstance(result, WebPage)

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", False)
    def test_execute_script_returns_none(self) -> None:
        client = BrowserAutomationClient()
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            result = asyncio.run(client.execute_script("http://example.com", "return 42"))
            assert result is None

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", False)
    def test_take_screenshot_returns_empty(self) -> None:
        client = BrowserAutomationClient()
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            result = asyncio.run(client.take_screenshot("http://example.com", "/tmp/test.png"))
            assert result == ""


# ---------------------------------------------------------------------------
# Mock Playwright async tests
# ---------------------------------------------------------------------------


class TestWithMockPlaywright:
    """Tests using mocked Playwright."""

    def _make_mock_page(
        self, html: str = "<html><title>Test</title><body>Hello</body></html>"
    ) -> MagicMock:
        """Create a mock Playwright page."""
        page = AsyncMock()
        page.goto = AsyncMock()
        page.content = AsyncMock(return_value=html)
        page.close = AsyncMock()
        page.wait_for_timeout = AsyncMock()
        page.wait_for_selector = AsyncMock()
        page.click = AsyncMock()
        page.fill = AsyncMock()
        page.screenshot = AsyncMock()
        page.evaluate = AsyncMock(return_value=42)
        page.query_selector = AsyncMock(return_value=None)
        return page

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_fetch_dynamic_with_mock(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        # Bypass browser launch
        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        result = asyncio.run(client.fetch_dynamic("http://example.com", wait_time=500))

        assert isinstance(result, WebPage)
        assert result.url == "http://example.com"
        assert result.title == "Test"
        assert result.metadata.get("browser") is True
        mock_page.goto.assert_awaited_once()
        mock_page.close.assert_awaited_once()

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_execute_script_with_mock(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        result = asyncio.run(client.execute_script("http://example.com", "return document.title"))

        assert result == 42
        mock_page.evaluate.assert_awaited_once()
        mock_page.close.assert_awaited_once()

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_wait_for_selector_with_mock(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        result = asyncio.run(
            client.wait_for_selector("http://example.com", ".content", timeout=5000)
        )

        assert isinstance(result, WebPage)
        mock_page.wait_for_selector.assert_awaited_once_with(".content", timeout=5000)

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_click_with_mock(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        result = asyncio.run(client.click("http://example.com", "button.submit"))

        assert isinstance(result, WebPage)
        mock_page.click.assert_awaited_once_with("button.submit")

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_fill_form_with_mock(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        fields = {"#name": "John", "#email": "john@example.com"}
        result = asyncio.run(client.fill_form("http://example.com", fields))

        assert isinstance(result, WebPage)
        assert mock_page.fill.await_count == 2

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_take_screenshot_full_page(self) -> None:
        client = BrowserAutomationClient()
        mock_page = self._make_mock_page()

        client._launched = True
        client._browser = AsyncMock()
        client._browser.new_page = AsyncMock(return_value=mock_page)

        result = asyncio.run(client.take_screenshot("http://example.com", "/tmp/screenshot.png"))

        assert result == "/tmp/screenshot.png"
        mock_page.screenshot.assert_awaited_once_with(path="/tmp/screenshot.png")

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_close(self) -> None:
        client = BrowserAutomationClient()
        client._launched = True
        client._browser = AsyncMock()
        client._playwright = AsyncMock()

        asyncio.run(client.close())

        assert client._browser is None
        assert client._playwright is None
        assert client._launched is False


# ---------------------------------------------------------------------------
# WebPage output
# ---------------------------------------------------------------------------


class TestWebPageOutput:
    """Test that the client produces valid WebPage objects."""

    @patch("aegis.ingestion.browser._HAS_PLAYWRIGHT", True)
    def test_make_page_metadata(self) -> None:
        client = BrowserAutomationClient(browser_type="webkit")
        page = client._make_page("http://test.com", "<html><title>Hello</title></html>")
        assert page.url == "http://test.com"
        assert page.title == "Hello"
        assert page.metadata["browser"] is True
        assert page.metadata["engine"] == "webkit"
        assert page.fetched_at != ""

    def test_make_page_no_title(self) -> None:
        client = BrowserAutomationClient()
        page = client._make_page("http://test.com", "<html><body>no title</body></html>")
        assert page.title == ""


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------


class TestExports:
    """Test that the browser module is properly exported."""

    def test_import_from_ingestion(self) -> None:
        from aegis.ingestion import BrowserAutomationClient as BrowserClient

        assert BrowserClient is BrowserAutomationClient
