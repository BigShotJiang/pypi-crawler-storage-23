"""Tests for the observatory monitoring engine."""

from __future__ import annotations

from aegis.observatory.monitor import HealthCheckResult, ObservatoryMonitor


class TestRewardHacking:
    """Tests for ObservatoryMonitor.check_reward_hacking."""

    def test_reward_hacking_detects_inflation(self) -> None:
        """Traces with all rewards > 0.96 and stddev < 0.02 should be unhealthy."""
        monitor = ObservatoryMonitor()
        traces = [{"reward": 0.97} for _ in range(20)]
        result = monitor.check_reward_hacking(reward_traces=traces)

        assert not result.healthy
        assert "reward_inflation" in result.details["issues"]

    def test_reward_hacking_detects_oscillation(self) -> None:
        """Traces with an alternating up/down pattern should be unhealthy."""
        monitor = ObservatoryMonitor()
        # Create a strongly oscillating pattern with enough direction changes (>5)
        traces = [{"reward": 0.8 if i % 2 == 0 else 0.2} for i in range(20)]
        result = monitor.check_reward_hacking(reward_traces=traces)

        assert not result.healthy
        assert "reward_oscillation" in result.details["issues"]

    def test_reward_hacking_healthy_trace(self) -> None:
        """A normal reward distribution should be healthy."""
        monitor = ObservatoryMonitor()
        # Moderate rewards with reasonable variance, no oscillation
        traces = [{"reward": 0.5 + i * 0.02} for i in range(10)]
        result = monitor.check_reward_hacking(reward_traces=traces)

        assert result.healthy

    def test_reward_hacking_empty_traces(self) -> None:
        """No traces should result in a healthy check."""
        monitor = ObservatoryMonitor()
        result = monitor.check_reward_hacking(reward_traces=None)

        assert result.healthy
        assert result.score == 1.0
        assert result.details["traces_analysed"] == 0


class TestGradientHealth:
    """Tests for ObservatoryMonitor.check_gradient_health."""

    def test_gradient_health_detects_vanishing(self) -> None:
        """Norms all below 1e-8 should flag vanishing gradients."""
        monitor = ObservatoryMonitor()
        stats = {"norms": [1e-9, 1e-10, 1e-9, 1e-10, 1e-9]}
        result = monitor.check_gradient_health(gradient_stats=stats)

        assert not result.healthy
        assert "vanishing_gradients" in result.details["issues"]

    def test_gradient_health_detects_exploding(self) -> None:
        """Norms all above 1e4 should flag exploding gradients."""
        monitor = ObservatoryMonitor()
        stats = {"norms": [1e5, 2e5, 1.5e5, 3e5, 1e5]}
        result = monitor.check_gradient_health(gradient_stats=stats)

        assert not result.healthy
        assert "exploding_gradients" in result.details["issues"]

    def test_gradient_health_normal(self) -> None:
        """Normal gradient norms should be healthy."""
        monitor = ObservatoryMonitor()
        stats = {"norms": [0.1, 0.15, 0.12, 0.11, 0.13]}
        result = monitor.check_gradient_health(gradient_stats=stats)

        assert result.healthy
        assert result.score == 1.0

    def test_gradient_health_no_stats(self) -> None:
        """Passing None for gradient_stats should return healthy."""
        monitor = ObservatoryMonitor()
        result = monitor.check_gradient_health(gradient_stats=None)

        assert result.healthy
        assert result.score == 1.0


class TestMemoryHealth:
    """Tests for ObservatoryMonitor.check_memory_health."""

    def test_memory_health_detects_capacity(self) -> None:
        """Total entries near capacity should flag capacity pressure."""
        monitor = ObservatoryMonitor()
        stats = {
            "total_entries": 9500,
            "capacity": 10000,
            "stale_count": 0,
        }
        result = monitor.check_memory_health(memory_stats=stats)

        assert not result.healthy
        assert "capacity_pressure" in result.details["issues"]

    def test_memory_health_detects_staleness(self) -> None:
        """A high stale_count relative to total_entries should flag staleness."""
        monitor = ObservatoryMonitor()
        stats = {
            "total_entries": 1000,
            "capacity": 10000,
            "stale_count": 500,
        }
        result = monitor.check_memory_health(memory_stats=stats)

        assert not result.healthy
        assert "high_staleness" in result.details["issues"]

    def test_memory_health_normal(self) -> None:
        """Normal memory stats should be healthy."""
        monitor = ObservatoryMonitor()
        stats = {
            "total_entries": 500,
            "capacity": 10000,
            "stale_count": 10,
        }
        result = monitor.check_memory_health(memory_stats=stats)

        assert result.healthy
        assert result.score == 1.0


class TestDrift:
    """Tests for ObservatoryMonitor.check_drift."""

    def test_drift_detects_mean_shift(self) -> None:
        """A large mean difference relative to reference variance should flag drift."""
        monitor = ObservatoryMonitor()
        reference = {"mean": 0.5, "variance": 0.01}
        current = {"mean": 0.9, "variance": 0.01}
        result = monitor.check_drift(
            reference_distribution=reference,
            current_distribution=current,
        )

        assert not result.healthy
        assert "mean_drift" in result.details["issues"]

    def test_drift_no_drift(self) -> None:
        """Similar distributions should produce a healthy result."""
        monitor = ObservatoryMonitor()
        reference = {"mean": 0.5, "variance": 0.04}
        current = {"mean": 0.52, "variance": 0.04}
        result = monitor.check_drift(
            reference_distribution=reference,
            current_distribution=current,
        )

        assert result.healthy
        assert result.details["z_score"] < 2.0


class TestRunAllChecks:
    """Tests for ObservatoryMonitor.run_all_checks."""

    def test_run_all_checks_returns_4_results(self) -> None:
        """run_all_checks should return exactly 4 HealthCheckResult instances."""
        monitor = ObservatoryMonitor()
        results = monitor.run_all_checks()

        assert len(results) == 4
        assert all(isinstance(r, HealthCheckResult) for r in results)
        expected_names = {"reward_hacking", "gradient_health", "memory_health", "drift"}
        actual_names = {r.check_name for r in results}
        assert actual_names == expected_names
