# ruff: noqa
"""Comprehensive tests for security and infrastructure modules.

Covers compliance_reports, encryption, abac, differential_privacy,
metrics_exporter, auth, and leaderboard to increase coverage.
"""

from __future__ import annotations

import math
import os
import tempfile
import time
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# 1. Compliance Reports
# ---------------------------------------------------------------------------
from aegis.security.compliance_reports import (
    ComplianceReportGenerator,
    _assess_control,
    _build_report_summary,
    _classify_ai_risk,
    _collect_evidence,
    _collect_recommendations,
)


class TestAssessControl:
    """Tests for the _assess_control helper."""

    def test_compliant_when_all_keys_present(self) -> None:
        audit = {"rbac_enabled": True, "abac_enabled": True}
        result = _assess_control(
            "CC6.1", "Access controls", audit, ["rbac_enabled", "abac_enabled"], "Security"
        )
        assert result["status"] == "compliant"
        assert result["control_id"] == "CC6.1"
        assert result["category"] == "Security"
        assert len(result["evidence"]) == 2
        assert len(result["gaps"]) == 0
        assert "recommendations" not in result

    def test_partial_when_some_keys_missing(self) -> None:
        audit = {"rbac_enabled": True, "abac_enabled": False}
        result = _assess_control(
            "CC6.1", "Access controls", audit, ["rbac_enabled", "abac_enabled"], "Security"
        )
        assert result["status"] == "partial"
        assert len(result["evidence"]) == 1
        assert len(result["gaps"]) == 1
        assert "recommendations" in result

    def test_non_compliant_when_all_keys_missing(self) -> None:
        result = _assess_control(
            "CC6.1", "Access controls", {}, ["rbac_enabled", "abac_enabled"], "Security"
        )
        assert result["status"] == "non_compliant"
        assert len(result["evidence"]) == 0
        assert len(result["gaps"]) == 2
        assert len(result["recommendations"]) == 2

    def test_falsy_values_treated_as_missing(self) -> None:
        audit = {"rbac_enabled": 0, "abac_enabled": ""}
        result = _assess_control(
            "CC6.1", "desc", audit, ["rbac_enabled", "abac_enabled"], "Security"
        )
        assert result["status"] == "non_compliant"


class TestBuildReportSummary:
    """Tests for _build_report_summary."""

    def test_all_compliant(self) -> None:
        controls = [{"status": "compliant"}, {"status": "compliant"}]
        summary = _build_report_summary(controls)
        assert summary["overall_status"] == "compliant"
        assert summary["compliant"] == 2
        assert summary["compliance_pct"] == 100.0

    def test_all_non_compliant(self) -> None:
        controls = [{"status": "non_compliant"}, {"status": "non_compliant"}]
        summary = _build_report_summary(controls)
        assert summary["overall_status"] == "non_compliant"
        assert summary["compliance_pct"] == 0.0

    def test_mixed_status(self) -> None:
        controls = [{"status": "compliant"}, {"status": "non_compliant"}, {"status": "partial"}]
        summary = _build_report_summary(controls)
        assert summary["overall_status"] == "partial"
        assert summary["total_controls"] == 3

    def test_empty_controls(self) -> None:
        summary = _build_report_summary([])
        assert summary["total_controls"] == 0
        assert summary["compliance_pct"] == 0.0
        # With zero controls, compliant == total == 0, so overall is "compliant"
        assert summary["overall_status"] == "compliant"

    def test_partial_only(self) -> None:
        controls = [{"status": "partial"}, {"status": "partial"}]
        summary = _build_report_summary(controls)
        assert summary["overall_status"] == "partial"


class TestCollectHelpers:
    """Tests for _collect_recommendations and _collect_evidence."""

    def test_collect_recommendations_deduplicates(self) -> None:
        controls = [
            {"recommendations": ["Fix A", "Fix B"]},
            {"recommendations": ["Fix B", "Fix C"]},
            {},
        ]
        recs = _collect_recommendations(controls)
        assert recs == ["Fix A", "Fix B", "Fix C"]

    def test_collect_evidence_deduplicates(self) -> None:
        controls = [
            {"evidence": ["ev1: verified", "ev2: verified"]},
            {"evidence": ["ev2: verified", "ev3: verified"]},
        ]
        evidence = _collect_evidence(controls)
        assert evidence == ["ev1: verified", "ev2: verified", "ev3: verified"]


class TestClassifyAIRisk:
    """Tests for EU AI Act risk classification."""

    def test_unacceptable_biometric(self) -> None:
        result = _classify_ai_risk({"biometric_identification": True})
        assert result["level"] == "unacceptable"

    def test_unacceptable_critical_infra(self) -> None:
        result = _classify_ai_risk({"critical_infrastructure": True})
        assert result["level"] == "unacceptable"

    def test_high_risk_financial(self) -> None:
        result = _classify_ai_risk({"financial_scoring": True})
        assert result["level"] == "high"

    def test_high_risk_employment(self) -> None:
        result = _classify_ai_risk({"employment_decisions": True})
        assert result["level"] == "high"

    def test_limited_risk_customer_interaction(self) -> None:
        result = _classify_ai_risk({"customer_interaction": True})
        assert result["level"] == "limited"

    def test_limited_risk_content_gen(self) -> None:
        result = _classify_ai_risk({"content_generation": True})
        assert result["level"] == "limited"

    def test_minimal_risk_default(self) -> None:
        result = _classify_ai_risk({})
        assert result["level"] == "minimal"


class TestComplianceReportGenerator:
    """Tests for all report generation methods."""

    def setup_method(self) -> None:
        self.gen = ComplianceReportGenerator()

    def test_soc2_report_structure(self) -> None:
        audit = {
            "rbac_enabled": True,
            "abac_enabled": True,
            "audit_logging": True,
            "encryption_at_rest": True,
            "encryption_in_transit": True,
        }
        report = self.gen.generate_soc2_report(audit)
        assert report["report_type"] == "SOC 2 Type II Readiness"
        assert report["framework"] == "soc2"
        assert "generated_at" in report
        assert "summary" in report
        assert "controls" in report
        assert isinstance(report["controls"], list)
        assert len(report["controls"]) == 12
        assert "findings" in report
        assert "recommendations" in report
        assert "evidence_references" in report

    def test_soc2_fully_compliant(self) -> None:
        audit = {
            "rbac_enabled": True,
            "abac_enabled": True,
            "identity_management": True,
            "authentication_enabled": True,
            "mfa_enabled": True,
            "encryption_at_rest": True,
            "encryption_in_transit": True,
            "anomaly_detection": True,
            "audit_logging": True,
            "monitoring_enabled": True,
            "alerting_enabled": True,
            "change_management": True,
            "ci_cd_pipeline": True,
            "risk_assessment": True,
            "incident_response": True,
            "capacity_monitoring": True,
            "auto_scaling": True,
            "backup_enabled": True,
            "disaster_recovery": True,
            "data_validation": True,
            "data_classification": True,
        }
        report = self.gen.generate_soc2_report(audit)
        assert report["summary"]["overall_status"] == "compliant"
        assert len(report["findings"]) == 0

    def test_finra_report_structure(self) -> None:
        audit = {"communication_review": True, "content_filtering": True}
        report = self.gen.generate_finra_report(audit)
        assert report["report_type"] == "FINRA Compliance Assessment"
        assert report["framework"] == "finra"
        assert len(report["controls"]) == 6

    def test_finra_fully_non_compliant(self) -> None:
        report = self.gen.generate_finra_report({})
        assert report["summary"]["non_compliant"] == 6
        assert len(report["findings"]) == 6

    def test_eu_ai_act_report_structure(self) -> None:
        audit = {"risk_management": True, "financial_scoring": True}
        report = self.gen.generate_eu_ai_act_report(audit)
        assert report["report_type"] == "EU AI Act Compliance Assessment"
        assert report["framework"] == "eu_ai_act"
        assert len(report["controls"]) == 8
        assert "risk_classification" in report
        assert report["risk_classification"]["level"] == "high"

    def test_privacy_report_no_dp(self) -> None:
        report = self.gen.generate_privacy_report({})
        assert report["framework"] == "privacy"
        assert report["dp_metrics"] == {}

    def test_privacy_report_with_dp(self) -> None:
        data = {
            "dp_enabled": True,
            "epsilon_budget": 10.0,
            "consumed_epsilon": 3.0,
            "delta": 1e-5,
            "noise_multiplier": 1.1,
            "budget_tracking": True,
            "budget_enforcement": True,
        }
        report = self.gen.generate_privacy_report(data)
        dp = report["dp_metrics"]
        assert dp["epsilon_budget"] == 10.0
        assert dp["consumed_epsilon"] == 3.0
        assert dp["remaining_epsilon"] == 7.0
        assert dp["utilization_pct"] == 30.0
        assert dp["delta"] == 1e-5

    def test_privacy_report_dp_zero_budget(self) -> None:
        data = {"dp_enabled": True, "epsilon_budget": 0}
        report = self.gen.generate_privacy_report(data)
        dp = report["dp_metrics"]
        assert dp["remaining_epsilon"] == 0
        assert dp["utilization_pct"] == 0


# ---------------------------------------------------------------------------
# 2. Encryption
# ---------------------------------------------------------------------------
from aegis.security.encryption import (
    DataEncryptor,
    EncryptionConfig,
    SecretDetector,
    TLSConfig,
)


class TestEncryptionConfig:
    """Tests for EncryptionConfig defaults."""

    def test_defaults(self) -> None:
        cfg = EncryptionConfig()
        assert cfg.algorithm == "AES-256-GCM"
        assert cfg.key_derivation == "PBKDF2"
        assert cfg.iterations == 100_000


class TestDataEncryptor:
    """Tests for DataEncryptor encrypt/decrypt lifecycle."""

    def setup_method(self) -> None:
        self.enc = DataEncryptor("test-master-key")

    def test_encrypt_decrypt_roundtrip_string(self) -> None:
        plaintext = "Hello, Aegis!"
        encrypted = self.enc.encrypt(plaintext)
        assert isinstance(encrypted, bytes)
        decrypted = self.enc.decrypt(encrypted)
        assert decrypted == plaintext.encode("utf-8")

    def test_encrypt_decrypt_roundtrip_bytes(self) -> None:
        plaintext = b"\x00\x01\x02\xff"
        encrypted = self.enc.encrypt(plaintext)
        decrypted = self.enc.decrypt(encrypted)
        assert decrypted == plaintext

    def test_encrypt_produces_different_output_each_time(self) -> None:
        plaintext = "deterministic?"
        enc1 = self.enc.encrypt(plaintext)
        enc2 = self.enc.encrypt(plaintext)
        assert enc1 != enc2  # random salt + nonce

    def test_decrypt_too_short_raises(self) -> None:
        with pytest.raises(ValueError, match="too short"):
            self.enc.decrypt(b"\x00" * 10)

    def test_decrypt_tampered_data_raises(self) -> None:
        encrypted = self.enc.encrypt("secret data")
        tampered = bytearray(encrypted)
        tampered[40] ^= 0xFF
        with pytest.raises(ValueError, match="tag verification failed"):
            self.enc.decrypt(bytes(tampered))

    def test_wrong_key_fails(self) -> None:
        encrypted = self.enc.encrypt("secret data")
        other = DataEncryptor("wrong-key")
        with pytest.raises(ValueError, match="tag verification failed"):
            other.decrypt(encrypted)

    def test_derive_key(self) -> None:
        key1, salt1 = self.enc.derive_key("my-password")
        assert len(key1) == 32
        assert len(salt1) == 16
        key2, _ = self.enc.derive_key("my-password", salt=salt1)
        assert key1 == key2

    def test_derive_key_different_salts(self) -> None:
        key1, salt1 = self.enc.derive_key("password")
        key2, salt2 = self.enc.derive_key("password")
        assert salt1 != salt2
        assert key1 != key2

    def test_master_key_as_bytes(self) -> None:
        enc = DataEncryptor(b"raw-bytes-key")
        encrypted = enc.encrypt("test")
        decrypted = enc.decrypt(encrypted)
        assert decrypted == b"test"

    def test_custom_config_iterations(self) -> None:
        cfg = EncryptionConfig(iterations=1000)
        enc = DataEncryptor("key", config=cfg)
        encrypted = enc.encrypt("fast")
        decrypted = enc.decrypt(encrypted)
        assert decrypted == b"fast"

    def test_encrypt_empty_string(self) -> None:
        encrypted = self.enc.encrypt("")
        decrypted = self.enc.decrypt(encrypted)
        assert decrypted == b""


class TestEncryptField:
    """Tests for field-level encryption/decryption."""

    def setup_method(self) -> None:
        self.enc = DataEncryptor("field-master-key")

    def test_encrypt_and_decrypt_string_field(self) -> None:
        data = {"name": "Alice", "ssn": "123-45-6789", "age": 30}
        encrypted = self.enc.encrypt_field(data, ["ssn"])
        assert encrypted["name"] == "Alice"
        assert encrypted["age"] == 30
        assert encrypted["ssn"].startswith("__encrypted__:")
        decrypted = self.enc.decrypt_field(encrypted, ["ssn"])
        assert decrypted["ssn"] == "123-45-6789"

    def test_encrypt_field_nonexistent_key_ignored(self) -> None:
        data = {"name": "Alice"}
        encrypted = self.enc.encrypt_field(data, ["missing"])
        assert encrypted == {"name": "Alice"}

    def test_encrypt_field_dict_value(self) -> None:
        data = {"config": {"key": "val"}, "name": "test"}
        encrypted = self.enc.encrypt_field(data, ["config"])
        assert encrypted["config"].startswith("__encrypted__:")
        decrypted = self.enc.decrypt_field(encrypted, ["config"])
        assert decrypted["config"] == {"key": "val"}

    def test_encrypt_field_bytes_value(self) -> None:
        data = {"raw": b"binary data", "name": "test"}
        encrypted = self.enc.encrypt_field(data, ["raw"])
        assert encrypted["raw"].startswith("__encrypted__:")

    def test_decrypt_field_skips_non_encrypted(self) -> None:
        data = {"ssn": "plain-text", "name": "Alice"}
        result = self.enc.decrypt_field(data, ["ssn"])
        assert result["ssn"] == "plain-text"

    def test_decrypt_field_int_value_round_trip(self) -> None:
        data = {"count": 42}
        encrypted = self.enc.encrypt_field(data, ["count"])
        decrypted = self.enc.decrypt_field(encrypted, ["count"])
        assert decrypted["count"] == 42


class TestTLSConfig:
    """Tests for TLSConfig helpers."""

    def test_self_signed_cert_config(self) -> None:
        cfg = TLSConfig.generate_self_signed_cert_config()
        assert cfg["subject"]["CN"] == "aegis-local"
        assert cfg["key"]["algorithm"] == "RSA"
        assert cfg["key"]["size"] == 4096
        assert cfg["validity_days"] == 365
        assert "openssl_command" in cfg

    def test_tls_context_config(self) -> None:
        cfg = TLSConfig.get_tls_context_config("/path/cert.pem", "/path/key.pem")
        assert cfg["certfile"] == "/path/cert.pem"
        assert cfg["keyfile"] == "/path/key.pem"
        assert cfg["minimum_version"] == "TLSv1.2"
        assert cfg["honor_cipher_order"] is True

    def test_validate_certificate_file_not_found(self) -> None:
        result = TLSConfig.validate_certificate("/nonexistent/cert.pem")
        assert result["valid"] is False
        assert "not found" in result["errors"][0]

    def test_validate_certificate_valid_pem(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write("-----BEGIN CERTIFICATE-----\nMIIBkTCB...\n-----END CERTIFICATE-----\n")
            f.flush()
            result = TLSConfig.validate_certificate(f.name)
        os.unlink(f.name)
        assert result["valid"] is True
        assert result["format"] == "PEM"

    def test_validate_certificate_invalid_pem(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write("this is not a PEM file\n")
            f.flush()
            result = TLSConfig.validate_certificate(f.name)
        os.unlink(f.name)
        assert result["valid"] is False
        assert len(result["errors"]) == 2

    def test_validate_certificate_missing_end_marker(self) -> None:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as f:
            f.write("-----BEGIN CERTIFICATE-----\ndata\n")
            f.flush()
            result = TLSConfig.validate_certificate(f.name)
        os.unlink(f.name)
        assert result["valid"] is False
        assert any("END" in e for e in result["errors"])


class TestSecretDetector:
    """Tests for SecretDetector scan and redact."""

    def setup_method(self) -> None:
        self.detector = SecretDetector()

    def test_scan_aws_access_key(self) -> None:
        text = "key: AKIAIOSFODNN7EXAMPLE"
        findings = self.detector.scan(text)
        assert any(f["type"] == "aws_access_key" for f in findings)

    def test_scan_openai_key(self) -> None:
        text = "apikey=sk-abcdefghijklmnopqrstuvwxyz123456"
        findings = self.detector.scan(text)
        types = {f["type"] for f in findings}
        assert "openai_api_key" in types

    def test_scan_private_key_marker(self) -> None:
        text = "-----BEGIN RSA PRIVATE KEY-----"
        findings = self.detector.scan(text)
        assert any(f["type"] == "private_key" for f in findings)

    def test_scan_jwt(self) -> None:
        text = "token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZW1haWwiOiJ0ZXN0QGV4YW1wbGUuY29tIn0.abcdefghijklmnop"
        findings = self.detector.scan(text)
        assert any(f["type"] == "jwt_token" for f in findings)

    def test_scan_password_in_url(self) -> None:
        text = "postgres://user:supersecretpassword@localhost:5432/db"
        findings = self.detector.scan(text)
        assert any(f["type"] == "password_in_url" for f in findings)

    def test_scan_bearer_token(self) -> None:
        text = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI"
        findings = self.detector.scan(text)
        assert any(f["type"] == "bearer_token" for f in findings)

    def test_scan_no_secrets(self) -> None:
        text = "This is a perfectly clean document."
        findings = self.detector.scan(text)
        assert findings == []

    def test_redact_replaces_secrets(self) -> None:
        text = "-----BEGIN RSA PRIVATE KEY-----"
        redacted = self.detector.redact(text)
        assert "[REDACTED:" in redacted
        assert "-----BEGIN RSA PRIVATE KEY-----" not in redacted

    def test_redact_no_secrets_unchanged(self) -> None:
        text = "No secrets here"
        assert self.detector.redact(text) == text

    def test_scan_password_assignment(self) -> None:
        text = 'password = "myV3ryS3cur3Pass!"'
        findings = self.detector.scan(text)
        assert any(f["type"] == "password_assignment" for f in findings)

    def test_preview_truncation_long_match(self) -> None:
        text = "key: AKIAIOSFODNN7EXAMPLE"
        findings = self.detector.scan(text)
        for f in findings:
            if f["type"] == "aws_access_key":
                assert "..." in f["preview"]


# ---------------------------------------------------------------------------
# 3. ABAC (Attribute-Based Access Control)
# ---------------------------------------------------------------------------
from aegis.security.abac import (
    ABACEngine,
    ABACPolicy,
    Attribute,
    AttributeSet,
    PolicyCondition,
    data_classification_policy,
    department_policy,
    sensitivity_policy,
    time_based_policy,
)


class TestAttribute:
    """Tests for the Attribute dataclass."""

    def test_valid_types(self) -> None:
        for dt in ("string", "int", "bool", "datetime", "list"):
            attr = Attribute(name="test", value="v", data_type=dt)
            assert attr.data_type == dt

    def test_invalid_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid data_type"):
            Attribute(name="test", value="v", data_type="float")


class TestAttributeSet:
    """Tests for AttributeSet.get()."""

    def test_get_subject_attr(self) -> None:
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert attrs.get("subject.role") == "admin"

    def test_get_resource_attr(self) -> None:
        attrs = AttributeSet(resource_attrs={"classification": "restricted"})
        assert attrs.get("resource.classification") == "restricted"

    def test_get_environment_attr(self) -> None:
        attrs = AttributeSet(environment_attrs={"current_time": 10})
        assert attrs.get("environment.current_time") == 10

    def test_get_action_attr(self) -> None:
        attrs = AttributeSet(action_attrs={"type": "read"})
        assert attrs.get("action.type") == "read"

    def test_get_unknown_category(self) -> None:
        attrs = AttributeSet()
        assert attrs.get("unknown.field") is None

    def test_get_no_dot(self) -> None:
        attrs = AttributeSet()
        assert attrs.get("nodot") is None

    def test_get_missing_key(self) -> None:
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert attrs.get("subject.missing") is None


class TestPolicyCondition:
    """Tests for PolicyCondition.evaluate()."""

    def test_eq(self) -> None:
        cond = PolicyCondition("subject.role", "eq", "admin")
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert cond.evaluate(attrs) is True

    def test_neq(self) -> None:
        cond = PolicyCondition("subject.role", "neq", "admin")
        attrs = AttributeSet(subject_attrs={"role": "viewer"})
        assert cond.evaluate(attrs) is True

    def test_gt(self) -> None:
        cond = PolicyCondition("subject.clearance", "gt", 2)
        attrs = AttributeSet(subject_attrs={"clearance": 3})
        assert cond.evaluate(attrs) is True

    def test_lt(self) -> None:
        cond = PolicyCondition("subject.clearance", "lt", 3)
        attrs = AttributeSet(subject_attrs={"clearance": 2})
        assert cond.evaluate(attrs) is True

    def test_gte(self) -> None:
        cond = PolicyCondition("subject.clearance", "gte", 3)
        attrs = AttributeSet(subject_attrs={"clearance": 3})
        assert cond.evaluate(attrs) is True

    def test_lte(self) -> None:
        cond = PolicyCondition("subject.clearance", "lte", 3)
        attrs = AttributeSet(subject_attrs={"clearance": 3})
        assert cond.evaluate(attrs) is True

    def test_in(self) -> None:
        cond = PolicyCondition("subject.role", "in", ["admin", "dev"])
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert cond.evaluate(attrs) is True

    def test_not_in(self) -> None:
        cond = PolicyCondition("subject.role", "not_in", ["admin", "dev"])
        attrs = AttributeSet(subject_attrs={"role": "viewer"})
        assert cond.evaluate(attrs) is True

    def test_contains_list(self) -> None:
        cond = PolicyCondition("subject.tags", "contains", "legal")
        attrs = AttributeSet(subject_attrs={"tags": ["legal", "finance"]})
        assert cond.evaluate(attrs) is True

    def test_contains_string(self) -> None:
        cond = PolicyCondition("subject.name", "contains", "smith")
        attrs = AttributeSet(subject_attrs={"name": "john smith"})
        assert cond.evaluate(attrs) is True

    def test_contains_other_type(self) -> None:
        cond = PolicyCondition("subject.value", "contains", 42)
        attrs = AttributeSet(subject_attrs={"value": 42})
        assert cond.evaluate(attrs) is False

    def test_matches_regex(self) -> None:
        cond = PolicyCondition("subject.email", "matches", r".*@metronis\.com$")
        attrs = AttributeSet(subject_attrs={"email": "arnav@metronis.com"})
        assert cond.evaluate(attrs) is True

    def test_matches_non_string(self) -> None:
        cond = PolicyCondition("subject.value", "matches", r"\d+")
        attrs = AttributeSet(subject_attrs={"value": 42})
        assert cond.evaluate(attrs) is False

    def test_missing_attribute_denies_eq(self) -> None:
        cond = PolicyCondition("subject.role", "eq", "admin")
        attrs = AttributeSet()
        assert cond.evaluate(attrs) is False

    def test_missing_attribute_allows_neq(self) -> None:
        cond = PolicyCondition("subject.role", "neq", "admin")
        attrs = AttributeSet()
        assert cond.evaluate(attrs) is True

    def test_missing_attribute_allows_not_in(self) -> None:
        cond = PolicyCondition("subject.role", "not_in", ["admin"])
        attrs = AttributeSet()
        assert cond.evaluate(attrs) is True

    def test_invalid_operator_returns_false(self) -> None:
        cond = PolicyCondition("subject.role", "xor", "admin")
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert cond.evaluate(attrs) is False


class TestABACPolicy:
    """Tests for ABACPolicy.matches()."""

    def test_empty_conditions_never_matches(self) -> None:
        policy = ABACPolicy(id="p1", name="test", effect="allow", conditions=[])
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert policy.matches(attrs) is False

    def test_all_conditions_must_match(self) -> None:
        policy = ABACPolicy(
            id="p1",
            name="test",
            effect="allow",
            conditions=[
                PolicyCondition("subject.role", "eq", "admin"),
                PolicyCondition("subject.active", "eq", True),
            ],
        )
        attrs = AttributeSet(subject_attrs={"role": "admin", "active": True})
        assert policy.matches(attrs) is True

    def test_partial_conditions_fail(self) -> None:
        policy = ABACPolicy(
            id="p1",
            name="test",
            effect="allow",
            conditions=[
                PolicyCondition("subject.role", "eq", "admin"),
                PolicyCondition("subject.active", "eq", True),
            ],
        )
        attrs = AttributeSet(subject_attrs={"role": "admin", "active": False})
        assert policy.matches(attrs) is False


class TestABACEngine:
    """Tests for the ABACEngine."""

    def test_no_policies_denies_by_default(self) -> None:
        engine = ABACEngine()
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert engine.evaluate(attrs) is False

    def test_allow_policy(self) -> None:
        engine = ABACEngine()
        policy = ABACPolicy(
            id="allow-admin",
            name="Allow admins",
            effect="allow",
            conditions=[PolicyCondition("subject.role", "eq", "admin")],
        )
        engine.add_policy(policy)
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        assert engine.evaluate(attrs) is True

    def test_deny_overrides_allow(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="allow",
                name="Allow all",
                effect="allow",
                conditions=[PolicyCondition("subject.role", "eq", "admin")],
            )
        )
        engine.add_policy(
            ABACPolicy(
                id="deny",
                name="Deny classified",
                effect="deny",
                conditions=[PolicyCondition("resource.classification", "eq", "restricted")],
                priority=100,
            )
        )
        attrs = AttributeSet(
            subject_attrs={"role": "admin"},
            resource_attrs={"classification": "restricted"},
        )
        assert engine.evaluate(attrs) is False

    def test_remove_policy(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="p1",
                name="test",
                effect="deny",
                conditions=[PolicyCondition("subject.role", "eq", "admin")],
            )
        )
        assert engine.remove_policy("p1") is True
        assert engine.remove_policy("nonexistent") is False

    def test_list_policies_sorted_by_priority(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(id="low", name="Low", effect="allow", conditions=[], priority=10)
        )
        engine.add_policy(
            ABACPolicy(id="high", name="High", effect="deny", conditions=[], priority=100)
        )
        policies = engine.list_policies()
        assert policies[0].id == "high"
        assert policies[1].id == "low"

    def test_evaluate_detailed(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="allow-1",
                name="Allow",
                effect="allow",
                conditions=[PolicyCondition("subject.role", "eq", "admin")],
                priority=50,
            )
        )
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        result = engine.evaluate_detailed(attrs)
        assert result["decision"] == "allow"
        assert len(result["allowed_by"]) == 1
        assert result["total_evaluated"] == 1

    def test_evaluate_detailed_deny(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="deny-1",
                name="Deny",
                effect="deny",
                conditions=[PolicyCondition("subject.role", "eq", "admin")],
            )
        )
        attrs = AttributeSet(subject_attrs={"role": "admin"})
        result = engine.evaluate_detailed(attrs)
        assert result["decision"] == "deny"
        assert len(result["denied_by"]) == 1

    def test_check_access_convenience(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="allow-read",
                name="Allow read",
                effect="allow",
                conditions=[
                    PolicyCondition("subject.role", "eq", "admin"),
                    PolicyCondition("action.type", "eq", "read"),
                ],
            )
        )
        assert (
            engine.check_access(
                subject={"role": "admin"},
                resource={},
                action="read",
            )
            is True
        )

    def test_check_access_injects_current_time(self) -> None:
        engine = ABACEngine()
        engine.add_policy(
            ABACPolicy(
                id="allow-all",
                name="Allow all",
                effect="allow",
                conditions=[PolicyCondition("subject.role", "eq", "admin")],
            )
        )
        result = engine.check_access(
            subject={"role": "admin"},
            resource={},
            action="read",
        )
        assert result is True


class TestPrebuiltPolicies:
    """Tests for factory-created policies."""

    def test_data_classification_policy(self) -> None:
        policy = data_classification_policy()
        assert policy.id == "builtin_data_classification"
        assert policy.effect == "deny"
        # Matches when resource is restricted AND clearance < 3
        attrs = AttributeSet(
            resource_attrs={"classification": "restricted"},
            subject_attrs={"clearance": 2},
        )
        assert policy.matches(attrs) is True

    def test_data_classification_policy_high_clearance(self) -> None:
        policy = data_classification_policy()
        attrs = AttributeSet(
            resource_attrs={"classification": "restricted"},
            subject_attrs={"clearance": 3},
        )
        assert policy.matches(attrs) is False  # clearance is not < 3

    def test_time_based_policy(self) -> None:
        policy = time_based_policy()
        assert policy.id == "builtin_time_restriction"
        attrs = AttributeSet(
            resource_attrs={"business_hours_only": True},
            environment_attrs={"current_time": 5},
        )
        assert policy.matches(attrs) is True

    def test_department_policy(self) -> None:
        policy = department_policy()
        assert policy.effect == "deny"
        attrs = AttributeSet(
            resource_attrs={"cross_department_ok": False},
            subject_attrs={"department": "engineering"},
        )
        assert policy.matches(attrs) is True

    def test_department_policy_admin_exempt(self) -> None:
        policy = department_policy()
        attrs = AttributeSet(
            resource_attrs={"cross_department_ok": False},
            subject_attrs={"department": "admin"},
        )
        # The neq condition fails for admin, so deny doesn't apply
        assert policy.matches(attrs) is False

    def test_sensitivity_policy(self) -> None:
        policy = sensitivity_policy()
        attrs = AttributeSet(
            resource_attrs={"contains_pii": True},
            subject_attrs={"privacy_trained": False},
        )
        assert policy.matches(attrs) is True


# ---------------------------------------------------------------------------
# 4. Differential Privacy
# ---------------------------------------------------------------------------
from aegis.security.differential_privacy import (
    DPTrainingWrapper,
    GaussianMechanism,
    PrivacyAccountant,
    PrivacyBudget,
    PrivacyConfig,
)


class TestGaussianMechanism:
    """Tests for the Gaussian noise mechanism."""

    def setup_method(self) -> None:
        self.mech = GaussianMechanism()

    def test_add_noise_returns_float(self) -> None:
        result = self.mech.add_noise(10.0, sensitivity=1.0, epsilon=1.0)
        assert isinstance(result, float)

    def test_add_noise_is_noisy(self) -> None:
        """Over many calls, the noise should not always be zero."""
        values = [self.mech.add_noise(10.0, 1.0, 1.0) for _ in range(100)]
        assert not all(v == 10.0 for v in values)

    def test_add_noise_vector(self) -> None:
        result = self.mech.add_noise_vector([1.0, 2.0, 3.0], sensitivity=1.0, epsilon=1.0)
        assert len(result) == 3
        assert all(isinstance(v, float) for v in result)

    def test_compute_sigma_valid(self) -> None:
        sigma = GaussianMechanism._compute_sigma(1.0, 1.0, 1e-5)
        assert sigma > 0

    def test_compute_sigma_zero_epsilon_raises(self) -> None:
        with pytest.raises(ValueError, match="Epsilon must be positive"):
            GaussianMechanism._compute_sigma(1.0, 0.0)

    def test_compute_sigma_negative_epsilon_raises(self) -> None:
        with pytest.raises(ValueError, match="Epsilon must be positive"):
            GaussianMechanism._compute_sigma(1.0, -1.0)

    def test_compute_sigma_invalid_delta_raises(self) -> None:
        with pytest.raises(ValueError, match="Delta must be in"):
            GaussianMechanism._compute_sigma(1.0, 1.0, delta=0.0)
        with pytest.raises(ValueError, match="Delta must be in"):
            GaussianMechanism._compute_sigma(1.0, 1.0, delta=1.0)

    def test_compute_noise_multiplier(self) -> None:
        nm = GaussianMechanism.compute_noise_multiplier(
            epsilon=1.0, delta=1e-5, sample_rate=0.01, steps=1000
        )
        assert nm > 0
        assert isinstance(nm, float)

    def test_compute_noise_multiplier_invalid_params(self) -> None:
        with pytest.raises(ValueError, match="must be positive"):
            GaussianMechanism.compute_noise_multiplier(0.0, 1e-5, 0.01, 100)
        with pytest.raises(ValueError, match="must be positive"):
            GaussianMechanism.compute_noise_multiplier(1.0, 0.0, 0.01, 100)


class TestPrivacyAccountant:
    """Tests for privacy budget tracking."""

    def test_initial_budget(self) -> None:
        acc = PrivacyAccountant()
        assert acc.budget.consumed_epsilon == 0.0
        assert acc.budget.consumed_delta == 0.0

    def test_consume_tracks_spending(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=10.0))
        result = acc.consume(1.0, 1e-6)
        assert result is True  # within budget
        assert acc.budget.consumed_epsilon == 1.0
        assert acc.budget.consumed_delta == 1e-6

    def test_consume_exceeds_budget(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=1.0))
        result = acc.consume(2.0, 0.0)
        assert result is False  # over budget

    def test_remaining(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=10.0, max_delta=1e-5))
        acc.consume(3.0, 2e-6)
        eps_rem, delta_rem = acc.remaining()
        assert eps_rem == pytest.approx(7.0)
        assert delta_rem == pytest.approx(1e-5 - 2e-6)

    def test_remaining_floor_at_zero(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=1.0))
        acc.consume(5.0, 0.0)
        eps_rem, _ = acc.remaining()
        assert eps_rem == 0.0

    def test_is_exhausted(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=1.0))
        assert acc.is_exhausted() is False
        acc.consume(1.5, 0.0)
        assert acc.is_exhausted() is True

    def test_compose_rdp(self) -> None:
        acc = PrivacyAccountant()
        rdp = acc.compose_rdp(alpha=10.0, steps=100, noise_multiplier=1.0)
        expected = 100 * 10.0 / (2.0 * 1.0)
        assert rdp == pytest.approx(expected)

    def test_compose_rdp_invalid_alpha(self) -> None:
        acc = PrivacyAccountant()
        with pytest.raises(ValueError, match="Alpha must be > 1"):
            acc.compose_rdp(alpha=1.0, steps=100, noise_multiplier=1.0)

    def test_compose_rdp_invalid_noise(self) -> None:
        acc = PrivacyAccountant()
        with pytest.raises(ValueError, match="Noise multiplier must be positive"):
            acc.compose_rdp(alpha=2.0, steps=100, noise_multiplier=0.0)

    def test_rdp_to_dp(self) -> None:
        acc = PrivacyAccountant()
        eps = acc.rdp_to_dp(rdp_epsilon=5.0, alpha=10.0, delta=1e-5)
        expected = 5.0 - math.log(1e-5) / (10.0 - 1.0)
        assert eps == pytest.approx(expected)

    def test_rdp_to_dp_invalid_alpha(self) -> None:
        acc = PrivacyAccountant()
        with pytest.raises(ValueError, match="Alpha must be > 1"):
            acc.rdp_to_dp(5.0, alpha=0.5, delta=1e-5)

    def test_rdp_to_dp_invalid_delta(self) -> None:
        acc = PrivacyAccountant()
        with pytest.raises(ValueError, match="Delta must be positive"):
            acc.rdp_to_dp(5.0, alpha=2.0, delta=0.0)

    def test_generate_report(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=10.0))
        acc.consume(2.0, 1e-6)
        acc.consume(1.5, 1e-6)
        report = acc.generate_report()
        assert report["budget"]["max_epsilon"] == 10.0
        assert report["budget"]["consumed_epsilon"] == 3.5
        assert report["is_exhausted"] is False
        assert report["total_operations"] == 2
        assert len(report["history"]) == 2
        assert "generated_at" in report

    def test_generate_report_zero_max_epsilon(self) -> None:
        acc = PrivacyAccountant(PrivacyBudget(max_epsilon=0.0))
        report = acc.generate_report()
        assert report["budget"]["utilization_pct"] == 0.0


class TestDPTrainingWrapper:
    """Tests for the DP training wrapper."""

    def test_clip_gradients_within_norm(self) -> None:
        wrapper = DPTrainingWrapper(PrivacyConfig(max_grad_norm=5.0))
        grads = [1.0, 2.0, 1.0]
        clipped = wrapper.clip_gradients(grads)
        assert clipped == grads

    def test_clip_gradients_above_norm(self) -> None:
        wrapper = DPTrainingWrapper(PrivacyConfig(max_grad_norm=1.0))
        grads = [3.0, 4.0]  # norm = 5.0
        clipped = wrapper.clip_gradients(grads)
        result_norm = math.sqrt(sum(g * g for g in clipped))
        assert result_norm == pytest.approx(1.0, abs=1e-6)

    def test_clip_gradients_custom_norm(self) -> None:
        wrapper = DPTrainingWrapper()
        grads = [3.0, 4.0]  # norm = 5.0
        clipped = wrapper.clip_gradients(grads, max_norm=2.5)
        result_norm = math.sqrt(sum(g * g for g in clipped))
        assert result_norm == pytest.approx(2.5, abs=1e-6)

    def test_add_gradient_noise(self) -> None:
        wrapper = DPTrainingWrapper(PrivacyConfig(noise_multiplier=1.0, max_grad_norm=1.0))
        grads = [1.0, 2.0, 3.0]
        noised = wrapper.add_gradient_noise(grads)
        assert len(noised) == 3
        # Noise should make them different
        assert noised != grads

    def test_private_update(self) -> None:
        wrapper = DPTrainingWrapper(
            PrivacyConfig(
                max_grad_norm=1.0,
                noise_multiplier=0.5,
                lot_size=2,
            )
        )
        gradients = [[1.0, 0.5], [0.3, 0.2]]
        result = wrapper.private_update(gradients)
        assert len(result) == 2
        assert wrapper._steps == 1

    def test_private_update_empty(self) -> None:
        wrapper = DPTrainingWrapper()
        result = wrapper.private_update([])
        assert result == []

    def test_privacy_spent(self) -> None:
        wrapper = DPTrainingWrapper(
            PrivacyConfig(
                target_epsilon=5.0,
                target_delta=1e-5,
            )
        )
        gradients = [[1.0, 2.0], [3.0, 4.0]]
        wrapper.private_update(gradients)
        spent = wrapper.privacy_spent()
        assert spent["steps_completed"] == 1
        assert spent["target_epsilon"] == 5.0
        assert spent["target_delta"] == 1e-5
        assert spent["consumed_epsilon"] > 0

    def test_can_continue_initially(self) -> None:
        wrapper = DPTrainingWrapper()
        assert wrapper.can_continue() is True

    def test_accountant_property(self) -> None:
        wrapper = DPTrainingWrapper()
        assert isinstance(wrapper.accountant, PrivacyAccountant)


# ---------------------------------------------------------------------------
# 5. Metrics Exporter
# ---------------------------------------------------------------------------
from aegis.observatory.metrics_exporter import (
    MetricsExporter,
    _Counter,
    _Gauge,
    _Histogram,
)


class TestCounterMetric:
    """Tests for _Counter."""

    def test_inc_default(self) -> None:
        c = _Counter("test_counter", "help")
        c.inc()
        assert c.get() == 1.0

    def test_inc_with_label(self) -> None:
        c = _Counter("test_counter", "help")
        c.inc("label_a", 5.0)
        assert c.get("label_a") == 5.0
        assert c.get("label_b") == 0.0

    def test_inc_accumulates(self) -> None:
        c = _Counter("test_counter", "help")
        c.inc()
        c.inc()
        c.inc(amount=3.0)
        assert c.get() == 5.0


class TestGaugeMetric:
    """Tests for _Gauge."""

    def test_set_and_get(self) -> None:
        g = _Gauge("test_gauge", "help")
        g.set(42.0)
        assert g.get() == 42.0

    def test_set_with_label(self) -> None:
        g = _Gauge("test_gauge", "help")
        g.set(1.0, "label_x")
        g.set(2.0, "label_y")
        assert g.get("label_x") == 1.0
        assert g.get("label_y") == 2.0

    def test_get_default(self) -> None:
        g = _Gauge("test_gauge", "help")
        assert g.get("nonexistent") == 0.0


class TestHistogramMetric:
    """Tests for _Histogram."""

    def test_observe_and_count(self) -> None:
        h = _Histogram("test_hist", "help")
        h.observe(10.0)
        h.observe(20.0)
        assert h.count() == 2
        assert h.total() == 30.0

    def test_observe_with_label(self) -> None:
        h = _Histogram("test_hist", "help")
        h.observe(5.0, "op_a")
        h.observe(15.0, "op_a")
        assert h.count("op_a") == 2
        assert h.total("op_a") == 20.0
        assert h.count("op_b") == 0

    def test_bucket_counts(self) -> None:
        h = _Histogram("test_hist", "help", buckets=(10.0, 50.0, 100.0))
        h.observe(5.0)
        h.observe(30.0)
        h.observe(75.0)
        h.observe(200.0)
        buckets = h.bucket_counts()
        # 10.0 bucket: values <= 10 => 1
        assert buckets[0] == (10.0, 1)
        # 50.0 bucket: values <= 50 => 2
        assert buckets[1] == (50.0, 2)
        # 100.0 bucket: values <= 100 => 3
        assert buckets[2] == (100.0, 3)
        # +Inf: all 4
        assert buckets[3] == (float("inf"), 4)


class TestMetricsExporter:
    """Tests for the MetricsExporter."""

    def setup_method(self) -> None:
        self.exporter = MetricsExporter()

    def test_record_training_step(self) -> None:
        self.exporter.record_training_step(
            {
                "step": 1,
                "reward": 0.85,
                "loss": 0.12,
                "kl_divergence": 0.03,
                "entropy": 1.5,
                "grad_norm": 2.1,
                "learning_rate": 1e-4,
            }
        )
        data = self.exporter.export_json()
        assert data["training"]["steps_total"] == 1.0
        assert data["training"]["reward"]["1"] == 0.85
        assert data["training"]["loss"]["1"] == 0.12

    def test_record_training_step_memory_metrics(self) -> None:
        self.exporter.record_training_step(
            {
                "step": 2,
                "memory_bank_size": 1000,
                "dead_memory_pct": 5.5,
                "goodhart_divergence": 0.02,
            }
        )
        data = self.exporter.export_json()
        assert data["memory"]["bank_size"]["2"] == 1000.0
        assert data["memory"]["dead_memory_pct"]["2"] == 5.5

    def test_record_memory_operation_success(self) -> None:
        self.exporter.record_memory_operation("STORE", 15.0, True)
        data = self.exporter.export_json()
        assert data["memory"]["operations_total"]["STORE"] == 1.0
        assert data["memory"]["operation_durations_count"]["STORE"] == 1

    def test_record_memory_operation_failure(self) -> None:
        self.exporter.record_memory_operation("RETRIEVE", 200.0, False)
        data = self.exporter.export_json()
        assert data["memory"]["operation_errors"]["RETRIEVE"] == 1.0

    def test_record_observatory_alert(self) -> None:
        self.exporter.record_observatory_alert("goodhart_warning", "warning")
        data = self.exporter.export_json()
        assert data["observatory"]["alerts_total"]["goodhart_warning:warning"] == 1.0

    def test_record_observatory_auto_intervention(self) -> None:
        self.exporter.record_observatory_alert("auto_intervention", "critical")
        data = self.exporter.export_json()
        assert data["observatory"]["interventions_total"]["critical"] == 1.0

    def test_record_eval_score(self) -> None:
        self.exporter.record_eval_score("memory_fidelity", 0.92)
        data = self.exporter.export_json()
        assert data["eval"]["scores"]["memory_fidelity"] == 0.92
        assert data["eval"]["runs_total"]["memory_fidelity"] == 1.0

    def test_export_prometheus_format(self) -> None:
        self.exporter.record_training_step({"step": 1, "reward": 0.5})
        self.exporter.record_memory_operation("STORE", 10.0, True)
        self.exporter.record_eval_score("accuracy", 0.9)
        output = self.exporter.export_prometheus()
        assert "aegis_uptime_seconds" in output
        assert "aegis_training_steps_total" in output
        assert "aegis_training_reward" in output
        assert "# HELP" in output
        assert "# TYPE" in output

    def test_export_prometheus_empty(self) -> None:
        output = self.exporter.export_prometheus()
        assert "aegis_uptime_seconds" in output
        # Counters should show 0 when empty
        assert "aegis_training_steps_total 0" in output

    def test_export_json_structure(self) -> None:
        data = self.exporter.export_json()
        assert "uptime_seconds" in data
        assert "training" in data
        assert "memory" in data
        assert "observatory" in data
        assert "eval" in data

    def test_thread_safety_multiple_records(self) -> None:
        """Ensure no exceptions when recording from multiple calls."""
        import threading

        def record_training() -> None:
            for i in range(50):
                self.exporter.record_training_step({"step": i, "reward": 0.5})

        def record_memory() -> None:
            for i in range(50):
                self.exporter.record_memory_operation("STORE", float(i), True)

        t1 = threading.Thread(target=record_training)
        t2 = threading.Thread(target=record_memory)
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        data = self.exporter.export_json()
        assert data["training"]["steps_total"] == 50.0
        assert data["memory"]["operations_total"]["STORE"] == 50.0

    def test_format_counter_with_labels(self) -> None:
        c = _Counter("test_c", "help text")
        c.inc("label_a", 5.0)
        c.inc()
        lines = MetricsExporter._format_counter(c)
        text = "\n".join(lines)
        assert "# HELP test_c help text" in text
        assert "# TYPE test_c counter" in text
        assert 'test_c{label="label_a"} 5.0' in text
        assert "test_c 1.0" in text

    def test_format_gauge_empty(self) -> None:
        g = _Gauge("test_g", "help text")
        lines = MetricsExporter._format_gauge(g)
        text = "\n".join(lines)
        assert "test_g 0" in text

    def test_format_histogram_with_data(self) -> None:
        h = _Histogram("test_h", "help", buckets=(10.0, 100.0))
        h.observe(5.0, "op")
        h.observe(50.0, "op")
        lines = MetricsExporter._format_histogram(h)
        text = "\n".join(lines)
        assert "# TYPE test_h histogram" in text
        assert "test_h_bucket" in text
        assert "_count" in text
        assert "_sum" in text

    def test_format_histogram_empty(self) -> None:
        h = _Histogram("test_h", "help")
        lines = MetricsExporter._format_histogram(h)
        text = "\n".join(lines)
        assert 'test_h_bucket{le="+Inf"} 0' in text
        assert "test_h_count 0" in text
        assert "test_h_sum 0" in text


# ---------------------------------------------------------------------------
# 6. API Authentication
# ---------------------------------------------------------------------------
from aegis.api.auth import (
    APIKey,
    AuthConfig,
    AuthProvider,
    AuthUser,
    _b64url_decode,
    _b64url_encode,
    _create_jwt,
    _decode_jwt,
    _hash_api_key,
    _resolve_permissions,
    get_current_user,
    get_default_provider,
    require_auth,
    require_permission,
    set_default_provider,
)


class TestB64URLHelpers:
    """Tests for base64url encoding/decoding."""

    def test_roundtrip(self) -> None:
        data = b"Hello, World!"
        encoded = _b64url_encode(data)
        decoded = _b64url_decode(encoded)
        assert decoded == data

    def test_encode_strips_padding(self) -> None:
        encoded = _b64url_encode(b"a")
        assert "=" not in encoded

    def test_decode_handles_missing_padding(self) -> None:
        encoded = _b64url_encode(b"test data")
        decoded = _b64url_decode(encoded)
        assert decoded == b"test data"


class TestJWTCreation:
    """Tests for JWT create and decode."""

    def test_create_and_decode(self) -> None:
        payload = {"sub": "user1", "email": "test@example.com"}
        secret = "my-secret"
        token = _create_jwt(payload, secret)
        decoded = _decode_jwt(token, secret)
        assert decoded is not None
        assert decoded["sub"] == "user1"
        assert decoded["email"] == "test@example.com"

    def test_create_unsupported_algorithm(self) -> None:
        with pytest.raises(ValueError, match="Only HS256"):
            _create_jwt({}, "secret", algorithm="RS256")

    def test_decode_unsupported_algorithm(self) -> None:
        result = _decode_jwt("dummy.token.sig", "secret", algorithm="RS256")
        assert result is None

    def test_decode_invalid_token_format(self) -> None:
        assert _decode_jwt("not-a-jwt", "secret") is None
        assert _decode_jwt("a.b", "secret") is None
        assert _decode_jwt("a.b.c.d", "secret") is None

    def test_decode_wrong_secret(self) -> None:
        token = _create_jwt({"sub": "user1"}, "correct-secret")
        result = _decode_jwt(token, "wrong-secret")
        assert result is None

    def test_decode_expired_token(self) -> None:
        payload = {"sub": "user1", "exp": int(time.time()) - 3600}
        token = _create_jwt(payload, "secret")
        result = _decode_jwt(token, "secret")
        assert result is None

    def test_decode_valid_non_expired_token(self) -> None:
        payload = {"sub": "user1", "exp": int(time.time()) + 3600}
        token = _create_jwt(payload, "secret")
        result = _decode_jwt(token, "secret")
        assert result is not None
        assert result["sub"] == "user1"

    def test_decode_invalid_header(self) -> None:
        # Forge a token with wrong alg in header
        import json

        header = _b64url_encode(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
        payload = _b64url_encode(json.dumps({"sub": "user1"}).encode())
        token = f"{header}.{payload}.fakesig"
        result = _decode_jwt(token, "secret")
        assert result is None


class TestHashAPIKey:
    """Tests for API key hashing."""

    def test_hash_is_deterministic(self) -> None:
        h1 = _hash_api_key("my-api-key")
        h2 = _hash_api_key("my-api-key")
        assert h1 == h2

    def test_different_keys_different_hashes(self) -> None:
        h1 = _hash_api_key("key-a")
        h2 = _hash_api_key("key-b")
        assert h1 != h2

    def test_hash_is_hex(self) -> None:
        h = _hash_api_key("test")
        assert all(c in "0123456789abcdef" for c in h)
        assert len(h) == 64


class TestResolvePermissions:
    """Tests for role-permission resolution."""

    def test_admin_role(self) -> None:
        perms = _resolve_permissions(["admin"], [])
        assert "eval:read" in perms
        assert "eval:write" in perms
        assert "eval:delete" in perms
        assert "users:write" in perms

    def test_viewer_role(self) -> None:
        perms = _resolve_permissions(["viewer"], [])
        assert "eval:read" in perms
        assert "eval:write" not in perms

    def test_explicit_permissions_merged(self) -> None:
        perms = _resolve_permissions(["viewer"], ["custom:action"])
        assert "eval:read" in perms
        assert "custom:action" in perms

    def test_deduplication(self) -> None:
        perms = _resolve_permissions(["admin"], ["eval:read"])
        assert perms.count("eval:read") == 1

    def test_unknown_role(self) -> None:
        perms = _resolve_permissions(["unknown_role"], [])
        assert perms == []


class TestAuthProvider:
    """Tests for AuthProvider functionality."""

    def setup_method(self) -> None:
        self.config = AuthConfig(jwt_secret="test-secret-key-12345")
        self.provider = AuthProvider(self.config)

    # -- JWT verification --

    def test_create_and_verify_jwt(self) -> None:
        token = self.provider.create_jwt(user_id="user1", email="test@example.com", roles=["admin"])
        user = self.provider.verify_jwt(token)
        assert user is not None
        assert user.user_id == "user1"
        assert user.email == "test@example.com"
        assert "admin" in user.roles
        assert "eval:read" in user.permissions

    def test_verify_jwt_no_secret(self) -> None:
        provider = AuthProvider(AuthConfig(jwt_secret=""))
        user = provider.verify_jwt("any-token")
        assert user is None

    def test_create_jwt_no_secret_raises(self) -> None:
        provider = AuthProvider(AuthConfig(jwt_secret=""))
        with pytest.raises(ValueError, match="no jwt_secret"):
            provider.create_jwt("user1", "test@example.com")

    def test_verify_jwt_wrong_issuer(self) -> None:
        payload = {
            "sub": "user1",
            "email": "test@example.com",
            "iss": "wrong-issuer",
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret-key-12345")
        user = self.provider.verify_jwt(token)
        assert user is None

    def test_verify_jwt_wrong_audience_string(self) -> None:
        payload = {
            "sub": "user1",
            "email": "test@example.com",
            "aud": "wrong-audience",
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret-key-12345")
        user = self.provider.verify_jwt(token)
        assert user is None

    def test_verify_jwt_wrong_audience_list(self) -> None:
        payload = {
            "sub": "user1",
            "email": "test@example.com",
            "aud": ["other-api", "another-api"],
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret-key-12345")
        user = self.provider.verify_jwt(token)
        assert user is None

    def test_verify_jwt_valid_audience_list(self) -> None:
        payload = {
            "sub": "user1",
            "email": "test@example.com",
            "aud": ["aegis-api", "other-api"],
            "exp": int(time.time()) + 3600,
        }
        token = _create_jwt(payload, "test-secret-key-12345")
        user = self.provider.verify_jwt(token)
        assert user is not None

    def test_create_jwt_with_extra_claims(self) -> None:
        token = self.provider.create_jwt(
            user_id="user1",
            email="test@example.com",
            extra_claims={"custom": "value"},
        )
        user = self.provider.verify_jwt(token)
        assert user is not None

    def test_create_jwt_with_permissions(self) -> None:
        token = self.provider.create_jwt(
            user_id="user1",
            email="test@example.com",
            permissions=["custom:read"],
        )
        user = self.provider.verify_jwt(token)
        assert user is not None
        assert "custom:read" in user.permissions

    # -- API key lifecycle --

    def test_create_and_verify_api_key(self) -> None:
        raw, api_key = self.provider.create_api_key("user1", ["eval:read"])
        assert raw.startswith("aegis_")
        user = self.provider.verify_api_key(raw)
        assert user is not None
        assert user.user_id == "user1"
        assert "eval:read" in user.permissions

    def test_verify_unknown_api_key(self) -> None:
        user = self.provider.verify_api_key("aegis_unknown_key")
        assert user is None

    def test_revoke_api_key(self) -> None:
        raw, api_key = self.provider.create_api_key("user1", ["eval:read"])
        assert self.provider.revoke_api_key(api_key.key_id) is True
        user = self.provider.verify_api_key(raw)
        assert user is None

    def test_revoke_nonexistent_key(self) -> None:
        assert self.provider.revoke_api_key("nonexistent") is False

    def test_expired_api_key(self) -> None:
        raw, api_key = self.provider.create_api_key("user1", ["eval:read"], expires_in_seconds=-1)
        user = self.provider.verify_api_key(raw)
        assert user is None

    def test_list_api_keys(self) -> None:
        self.provider.create_api_key("user1", ["eval:read"])
        self.provider.create_api_key("user1", ["training:read"])
        self.provider.create_api_key("user2", ["memory:read"])
        keys = self.provider.list_api_keys("user1")
        assert len(keys) == 2
        keys2 = self.provider.list_api_keys("user2")
        assert len(keys2) == 1
        keys_none = self.provider.list_api_keys("unknown")
        assert keys_none == []

    # -- authenticate --

    def test_authenticate_bearer_token(self) -> None:
        token = self.provider.create_jwt("user1", "test@example.com", roles=["admin"])
        user = self.provider.authenticate({"Authorization": f"Bearer {token}"})
        assert user is not None
        assert user.user_id == "user1"

    def test_authenticate_api_key_header(self) -> None:
        raw, _ = self.provider.create_api_key("user1", ["eval:read"])
        user = self.provider.authenticate({"X-API-Key": raw})
        assert user is not None
        assert user.user_id == "user1"

    def test_authenticate_case_insensitive_headers(self) -> None:
        raw, _ = self.provider.create_api_key("user1", ["eval:read"])
        user = self.provider.authenticate({"x-api-key": raw})
        assert user is not None

    def test_authenticate_no_credentials(self) -> None:
        user = self.provider.authenticate({})
        assert user is None

    def test_authenticate_invalid_bearer_falls_through_to_api_key(self) -> None:
        raw, _ = self.provider.create_api_key("user1", ["eval:read"])
        user = self.provider.authenticate(
            {
                "Authorization": "Bearer invalid-token",
                "X-API-Key": raw,
            }
        )
        assert user is not None
        assert user.metadata["auth_method"] == "api_key"

    # -- authorize --

    def test_authorize_direct_permission(self) -> None:
        user = AuthUser(user_id="u1", email="", permissions=["eval:read"])
        assert self.provider.authorize(user, "eval", "read") is True
        assert self.provider.authorize(user, "eval", "write") is False

    def test_authorize_wildcard_resource(self) -> None:
        user = AuthUser(user_id="u1", email="", permissions=["eval:*"])
        assert self.provider.authorize(user, "eval", "read") is True
        assert self.provider.authorize(user, "eval", "delete") is True

    def test_authorize_global_admin(self) -> None:
        user = AuthUser(user_id="u1", email="", permissions=["*:*"])
        assert self.provider.authorize(user, "anything", "anything") is True


class TestAuthModuleFunctions:
    """Tests for module-level auth helper functions."""

    def setup_method(self) -> None:
        # Reset the module-level provider
        import aegis.api.auth as auth_mod

        auth_mod._default_provider = None

    def test_get_default_provider_creates_one(self) -> None:
        provider = get_default_provider()
        assert isinstance(provider, AuthProvider)

    def test_set_default_provider(self) -> None:
        config = AuthConfig(jwt_secret="custom-secret")
        custom = AuthProvider(config)
        set_default_provider(custom)
        assert get_default_provider() is custom

    def test_get_current_user_no_auth(self) -> None:
        user = get_current_user({})
        assert user is None

    def test_require_auth_raises_on_failure(self) -> None:
        with pytest.raises(PermissionError, match="Authentication required"):
            require_auth({})

    def test_require_permission_raises(self) -> None:
        user = AuthUser(user_id="u1", email="", permissions=[])
        with pytest.raises(PermissionError, match="Permission denied"):
            require_permission(user, "eval", "read")

    def test_require_permission_passes(self) -> None:
        config = AuthConfig(jwt_secret="secret")
        provider = AuthProvider(config)
        set_default_provider(provider)
        user = AuthUser(user_id="u1", email="", permissions=["eval:read"])
        # Should not raise
        require_permission(user, "eval", "read")

    def teardown_method(self) -> None:
        import aegis.api.auth as auth_mod

        auth_mod._default_provider = None


# ---------------------------------------------------------------------------
# 7. Leaderboard
# ---------------------------------------------------------------------------
from aegis.arena.leaderboard import (
    ELORating,
    Leaderboard,
    LeaderboardEntry,
    RankingConfig,
    _std,
)


class TestStdHelper:
    """Tests for the _std population standard deviation helper."""

    def test_single_value(self) -> None:
        assert _std([5.0]) == 0.0

    def test_empty(self) -> None:
        assert _std([]) == 0.0

    def test_known_values(self) -> None:
        values = [2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0]
        result = _std(values)
        assert result == pytest.approx(2.0, abs=0.01)


class TestELORating:
    """Tests for the ELO rating system."""

    def setup_method(self) -> None:
        self.elo = ELORating(k_factor=32, default_rating=1500)

    def test_initial_rating(self) -> None:
        assert self.elo.get_rating("new_agent") == 1500

    def test_update_winner_gains_loser_loses(self) -> None:
        self.elo.update("agent_a", "agent_b")
        assert self.elo.get_rating("agent_a") > 1500
        assert self.elo.get_rating("agent_b") < 1500

    def test_multiple_matches(self) -> None:
        for _ in range(10):
            self.elo.update("dominant", "weak")
        assert self.elo.get_rating("dominant") > self.elo.get_rating("weak")

    def test_get_rankings_sorted(self) -> None:
        self.elo.update("a", "b")
        self.elo.update("a", "c")
        rankings = self.elo.get_rankings()
        assert rankings[0]["agent_id"] == "a"
        assert rankings[0]["wins"] == 2
        assert rankings[0]["matches"] == 2

    def test_custom_k_factor_and_default(self) -> None:
        elo = ELORating(k_factor=64, default_rating=2000)
        assert elo.get_rating("agent") == 2000
        elo.update("a", "b")
        # Higher K means bigger rating changes
        delta = abs(elo.get_rating("a") - 2000)
        assert delta > 30  # With K=64 and equal starting, delta = 64 * 0.5 = 32

    def test_get_rankings_includes_stats(self) -> None:
        self.elo.update("a", "b")
        rankings = self.elo.get_rankings()
        for r in rankings:
            assert "agent_id" in r
            assert "rating" in r
            assert "wins" in r
            assert "losses" in r
            assert "matches" in r


class TestLeaderboard:
    """Tests for the Leaderboard class."""

    def setup_method(self) -> None:
        self.lb = Leaderboard()

    def test_add_result(self) -> None:
        entry = self.lb.add_result(
            "sub1",
            "Agent Alpha",
            "langchain",
            {"overall": 0.85, "dimensions": {"memory": 0.9, "reasoning": 0.8}},
        )
        assert entry.submission_id == "sub1"
        assert entry.overall_score == 0.85

    def test_add_result_overwrites_and_records_history(self) -> None:
        self.lb.add_result("sub1", "Agent A", "fw", {"overall": 0.5})
        self.lb.add_result("sub1", "Agent A", "fw", {"overall": 0.7})
        assert len(self.lb._history) == 2
        assert self.lb._history[1]["previous_score"] == 0.5
        assert self.lb._history[1]["delta"] == pytest.approx(0.2)

    def test_submit_result(self) -> None:
        self.lb.submit_result("agent1", {"memory": 0.8, "reasoning": 0.6})
        entry = self.lb.get_entry("agent1")
        assert entry is not None
        assert entry.overall_score == pytest.approx(0.7)

    def test_submit_result_empty_dimensions(self) -> None:
        self.lb.submit_result("agent1", {})
        entry = self.lb.get_entry("agent1")
        assert entry is not None
        assert entry.overall_score == 0.0

    def test_rank_default(self) -> None:
        self.lb.add_result("a", "Agent A", "fw", {"overall": 0.7})
        self.lb.add_result("b", "Agent B", "fw", {"overall": 0.9})
        self.lb.add_result("c", "Agent C", "fw", {"overall": 0.5})
        ranked = self.lb.rank(RankingConfig(min_dimensions=0))
        assert ranked[0].submission_id == "b"
        assert ranked[0].rank == 1
        assert ranked[2].submission_id == "c"
        assert ranked[2].rank == 3

    def test_rank_by_domain(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5, "domains": {"legal": 0.9}})
        self.lb.add_result("b", "B", "fw", {"overall": 0.9, "domains": {"legal": 0.3}})
        config = RankingConfig(sort_by="domain", domain_filter="legal", min_dimensions=0)
        ranked = self.lb.rank(config)
        assert ranked[0].submission_id == "a"

    def test_rank_by_dimension(self) -> None:
        self.lb.add_result(
            "a",
            "A",
            "fw",
            {"overall": 0.5, "dimensions": {"mem": 0.9, "reas": 0.1}},
        )
        self.lb.add_result(
            "b",
            "B",
            "fw",
            {"overall": 0.9, "dimensions": {"mem": 0.3, "reas": 0.5}},
        )
        config = RankingConfig(sort_by="dimension", min_dimensions=0)
        ranked = self.lb.rank(config)
        assert ranked[0].submission_id == "a"  # avg dim: 0.5 vs 0.4

    def test_rank_filter_model_size(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5}, model_size="7B")
        self.lb.add_result("b", "B", "fw", {"overall": 0.9}, model_size="70B")
        config = RankingConfig(model_size_filter="7B", min_dimensions=0)
        ranked = self.lb.rank(config)
        assert len(ranked) == 1
        assert ranked[0].submission_id == "a"

    def test_rank_filter_min_dimensions(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5, "dimensions": {"m": 0.5}})
        self.lb.add_result(
            "b",
            "B",
            "fw",
            {
                "overall": 0.9,
                "dimensions": {f"d{i}": 0.5 for i in range(6)},
            },
        )
        config = RankingConfig(min_dimensions=5)
        ranked = self.lb.rank(config)
        assert len(ranked) == 1
        assert ranked[0].submission_id == "b"

    def test_get_leaderboard(self) -> None:
        self.lb.submit_result("a1", {"m": 0.8, "r": 0.6})
        self.lb.submit_result("a2", {"m": 0.9, "r": 0.9})
        result = self.lb.get_leaderboard()
        assert len(result) == 2
        assert result[0]["rank"] == 1
        assert "overall_score" in result[0]

    def test_get_agent_details(self) -> None:
        self.lb.submit_result("agent1", {"memory": 0.8, "reasoning": 0.6})
        details = self.lb.get_agent_details("agent1")
        assert details["agent_id"] == "agent1"
        assert "dimension_scores" in details
        assert "rank" in details

    def test_get_agent_details_not_found(self) -> None:
        details = self.lb.get_agent_details("nonexistent")
        assert "error" in details

    def test_rank_by_dimension_id(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5, "dimensions": {"mem": 0.9}})
        self.lb.add_result("b", "B", "fw", {"overall": 0.8, "dimensions": {"mem": 0.4}})
        self.lb.add_result("c", "C", "fw", {"overall": 0.9, "dimensions": {"reas": 0.9}})
        ranked = self.lb.rank_by_dimension("mem")
        assert len(ranked) == 2
        assert ranked[0].submission_id == "a"

    def test_rank_by_cost_efficiency(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5}, compute_cost=1.0)
        self.lb.add_result("b", "B", "fw", {"overall": 0.9}, compute_cost=10.0)
        self.lb.add_result("c", "C", "fw", {"overall": 0.3})  # no cost
        ranked = self.lb.rank_by_cost_efficiency()
        assert len(ranked) == 2  # c excluded
        assert ranked[0].submission_id == "a"  # 0.5/1.0 > 0.9/10.0

    def test_get_entry(self) -> None:
        self.lb.add_result("sub1", "A", "fw", {"overall": 0.5})
        assert self.lb.get_entry("sub1") is not None
        assert self.lb.get_entry("nonexistent") is None

    def test_compare(self) -> None:
        self.lb.add_result(
            "a",
            "Alpha",
            "fw",
            {
                "overall": 0.8,
                "dimensions": {"mem": 0.9, "reas": 0.7},
            },
        )
        self.lb.add_result(
            "b",
            "Beta",
            "fw",
            {
                "overall": 0.6,
                "dimensions": {"mem": 0.5, "reas": 0.8},
            },
        )
        cmp = self.lb.compare("a", "b")
        assert cmp["overall"]["winner"] == "Alpha"
        assert cmp["overall"]["delta"] == pytest.approx(0.2)
        assert cmp["dimension_wins"]["a"] == 1  # mem
        assert cmp["dimension_wins"]["b"] == 1  # reas

    def test_compare_missing_submissions(self) -> None:
        cmp = self.lb.compare("x", "y")
        assert "error" in cmp

    def test_compare_partial_missing(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5})
        cmp = self.lb.compare("a", "missing")
        assert "error" in cmp

    def test_compare_tie(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5, "dimensions": {"m": 0.5}})
        self.lb.add_result("b", "B", "fw", {"overall": 0.5, "dimensions": {"m": 0.5}})
        cmp = self.lb.compare("a", "b")
        assert cmp["overall"]["winner"] == "tie"

    def test_trending(self) -> None:
        # Add initial, then update to create history with previous_score
        self.lb.add_result("a", "A", "fw", {"overall": 0.5})
        self.lb.add_result("a", "A", "fw", {"overall": 0.8})
        trends = self.lb.trending(period_days=7)
        assert len(trends) == 1
        assert trends[0]["delta"] == pytest.approx(0.3)

    def test_domain_leaders(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5, "domains": {"legal": 0.9}})
        self.lb.add_result("b", "B", "fw", {"overall": 0.8, "domains": {"legal": 0.4}})
        leaders = self.lb.domain_leaders("legal")
        assert leaders[0].submission_id == "a"

    def test_stats_empty(self) -> None:
        stats = self.lb.stats()
        assert stats["total_entries"] == 0

    def test_stats_with_entries(self) -> None:
        self.lb.add_result(
            "a",
            "A",
            "fw_a",
            {
                "overall": 0.5,
                "domains": {"legal": 0.6},
            },
        )
        self.lb.add_result(
            "b",
            "B",
            "fw_b",
            {
                "overall": 0.9,
                "domains": {"legal": 0.8},
            },
        )
        stats = self.lb.stats()
        assert stats["total_entries"] == 2
        assert stats["mean_score"] == pytest.approx(0.7)
        assert stats["min_score"] == pytest.approx(0.5)
        assert stats["max_score"] == pytest.approx(0.9)
        assert "legal" in stats["top_by_domain"]
        assert "fw_a" in stats["by_framework"]

    def test_export_json(self) -> None:
        self.lb.add_result("a", "A", "fw", {"overall": 0.5})
        result = self.lb.export("json")
        assert isinstance(result, dict)
        assert "leaderboard" in result
        assert "exported_at" in result

    def test_export_csv(self) -> None:
        self.lb.add_result(
            "a",
            "A",
            "fw",
            {
                "overall": 0.5,
                "dimensions": {f"d{i}": 0.5 for i in range(6)},
            },
        )
        result = self.lb.export("csv")
        assert isinstance(result, str)
        lines = result.strip().split("\n")
        assert len(lines) == 2  # header + 1 row
        assert "rank" in lines[0]

    def test_export_csv_empty(self) -> None:
        result = self.lb.export("csv")
        assert result == ""
