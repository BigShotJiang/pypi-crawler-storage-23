# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | Yes                |

## Reporting a Vulnerability

If you discover a security vulnerability in Aegis, please report it responsibly.

**Do not open a public GitHub issue for security vulnerabilities.**

Instead, email **security@metronis.dev** with:

1. A description of the vulnerability
2. Steps to reproduce
3. Potential impact assessment
4. Any suggested fixes (optional)

We will acknowledge receipt within 48 hours and provide a detailed response within 7 business days. We aim to release patches for confirmed vulnerabilities within 14 days of confirmation.

## Scope

This policy applies to:

- The `aegis-eval` Python package published on PyPI
- The official Docker images
- The Aegis API server
- The Aegis dashboard

## Security Considerations

Aegis handles AI agent evaluation data that may include sensitive information. Key security features:

- **No credential storage** — API keys are read from environment variables, never persisted
- **Input validation** — All API inputs are validated via Pydantic models
- **SQL injection prevention** — Parameterized queries throughout
- **Sandboxed eval** — Agent evaluation runs in isolated contexts
- **Audit logging** — All memory operations maintain full provenance trails
