## Summary

<!-- Describe your changes in 1-3 sentences. -->

## Changes

<!-- Bulleted list of what changed. -->

-

## Test Plan

<!-- How did you verify the changes? -->

- [ ] `pytest tests/ -v` passes
- [ ] `ruff check src/ tests/` clean
- [ ] `mypy src/aegis/` clean

## Related Issues

<!-- Link any related issues: Fixes #123, Relates to #456 -->
