"""Compatibility wrapper for benchmark harness imports.

The canonical implementation lives at
``aegis.eval.benchmarks.harness.BenchmarkHarness``.
"""

from aegis.eval.benchmarks.harness import BenchmarkHarness

__all__ = ["BenchmarkHarness"]
