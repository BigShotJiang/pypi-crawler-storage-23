"""Memory operations benchmark suite — 25 evaluation cases.

Covers the core memory operations: store/retrieve fidelity, update
correctness, forget/selective deletion, linking and graph operations,
and promote/demote with temporal bounds.
"""

from __future__ import annotations

from aegis.core.types import EvalCaseV1, EvalTier


class MemoryBenchmarkSuite:
    """Memory benchmark suite covering memory operations across tiers 1-3."""

    SUITE_ID = "memory-benchmark-v1"

    def get_cases(self) -> list[EvalCaseV1]:
        """Return the 25 memory benchmark test cases."""
        return [
            # ============================================================
            # STORE/RETRIEVE FIDELITY (5 cases)
            # ============================================================
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="exact_value_retention",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Store the following structured data and retrieve it exactly: "
                    "Customer ID: CUST-78923, Name: 'Eleanor Vance', "
                    "Account Balance: $142,567.89, Account Type: Premium, "
                    "Last Transaction: 2024-01-15T14:32:00Z, "
                    "Risk Rating: Medium. Retrieve all stored fields."
                ),
                expected={
                    "customer_id": "CUST-78923",
                    "name": "Eleanor Vance",
                    "account_balance": "$142,567.89",
                    "account_type": "Premium",
                    "last_transaction": "2024-01-15T14:32:00Z",
                    "risk_rating": "Medium",
                    "all_fields_retained": True,
                },
                difficulty=1,
                tags=["memory", "store", "retrieve", "fidelity", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="large_context_storage",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Store the following meeting transcript summary with 12 action "
                    "items: (1) Alice to finalize Q4 budget by Friday. (2) Bob to "
                    "schedule vendor demo for next Tuesday. (3) Carol to review "
                    "security audit findings. (4) Dave to update project timeline. "
                    "(5) Eve to prepare investor presentation. (6) Frank to negotiate "
                    "lease renewal terms. (7) Grace to conduct user interviews. "
                    "(8) Hank to patch critical vulnerability CVE-2024-1234. "
                    "(9) Iris to onboard new team members. (10) Jack to finalize "
                    "API documentation. (11) Kate to set up staging environment. "
                    "(12) Leo to review compliance checklist. "
                    "How many action items are stored and who owns item 8?"
                ),
                expected={
                    "total_items": 12,
                    "item_8_owner": "Hank",
                    "item_8_task": "patch critical vulnerability CVE-2024-1234",
                    "all_items_stored": True,
                },
                difficulty=2,
                tags=["memory", "store", "large_context", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="multi_type_retrieval",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Three different memory entries have been stored: "
                    "Entry A (text): 'The project deadline is March 31, 2024.' "
                    "Entry B (numeric): Revenue target = 2500000. "
                    "Entry C (structured): {'status': 'active', 'priority': 'high', "
                    "'assignee': 'team-alpha'}. "
                    "Retrieve entry B and entry C. What is the revenue target "
                    "and who is the assignee?"
                ),
                expected={
                    "revenue_target": "2500000",
                    "assignee": "team-alpha",
                    "entry_b_type": "numeric",
                    "entry_c_type": "structured",
                    "retrieval_count": 2,
                },
                difficulty=2,
                tags=["memory", "retrieve", "multi_type", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="retrieval_with_provenance",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "The following fact was stored from the Q3 2024 board minutes "
                    "(page 7, section 3.2): 'The board approved a $5M capital "
                    "expenditure for data center expansion.' Retrieve this fact "
                    "and provide its provenance information including source "
                    "document, page, and section."
                ),
                expected={
                    "fact": "board approved $5M capital expenditure",
                    "purpose": "data center expansion",
                    "source_document": "Q3 2024 board minutes",
                    "source_page": "page 7",
                    "source_section": "section 3.2",
                    "amount": "$5M",
                },
                difficulty=2,
                tags=["memory", "retrieve", "provenance", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="semantic_retrieval_accuracy",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                prompt=(
                    "The following entries are stored in memory: "
                    "M1: 'The company Q2 headcount was 1,250 employees.' "
                    "M2: 'The server response time averaged 45ms in production.' "
                    "M3: 'Customer satisfaction score reached 92% in the latest survey.' "
                    "M4: 'The marketing budget for H2 was set at $3.2M.' "
                    "M5: 'Employee retention rate improved to 94% this quarter.' "
                    "Query: 'What are the workforce-related metrics?' "
                    "Which entries should be retrieved?"
                ),
                expected={
                    "relevant_entries": ["M1", "M5"],
                    "irrelevant_entries": ["M2", "M3", "M4"],
                    "m1_content": "headcount 1,250",
                    "m5_content": "retention rate 94%",
                },
                difficulty=3,
                tags=["memory", "retrieve", "semantic", "tier2"],
            ),
            # ============================================================
            # UPDATE CORRECTNESS (5 cases)
            # ============================================================
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="partial_update_integrity",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "A customer record exists with: Name: 'John Martinez', "
                    "Email: 'john@example.com', Phone: '555-0123', "
                    "Address: '123 Main St, Austin, TX 78701', Plan: 'Basic'. "
                    "Update ONLY the plan to 'Enterprise' and the phone to "
                    "'555-0456'. All other fields must remain unchanged. "
                    "What are the current values of all fields after the update?"
                ),
                expected={
                    "name": "John Martinez",
                    "email": "john@example.com",
                    "phone": "555-0456",
                    "address": "123 Main St, Austin, TX 78701",
                    "plan": "Enterprise",
                    "unchanged_fields": ["name", "email", "address"],
                    "updated_fields": ["phone", "plan"],
                },
                difficulty=2,
                tags=["memory", "update", "partial", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="concurrent_update_handling",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Two agents simultaneously attempt to update the same inventory "
                    "record. Current stock: 100 units. Agent A processes an order "
                    "for 30 units (should decrement to 70). Agent B processes a "
                    "restock of 50 units (should increment to 150). If both updates "
                    "are applied correctly from the initial state, what should the "
                    "final stock be? Identify the correct final value and the "
                    "concurrency risk."
                ),
                expected={
                    "initial_stock": 100,
                    "agent_a_change": -30,
                    "agent_b_change": 50,
                    "correct_final_stock": 120,
                    "concurrency_risk": "lost update",
                    "requires": "atomic operations or locking",
                },
                difficulty=4,
                tags=["memory", "update", "concurrent", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="version_history_preservation",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "A document has been updated three times: "
                    "v1 (Jan 1): 'Project scope includes modules A and B.' "
                    "v2 (Feb 15): 'Project scope includes modules A, B, and C.' "
                    "v3 (Mar 10): 'Project scope includes modules A, B, C, and D. "
                    "Module B timeline extended to Q3.' "
                    "What is the current version, what changed in each version, "
                    "and what was the original scope?"
                ),
                expected={
                    "current_version": "v3",
                    "current_scope": "modules A, B, C, and D",
                    "original_scope": "modules A and B",
                    "v2_change": "added module C",
                    "v3_changes": ["added module D", "module B timeline extended"],
                    "version_count": 3,
                },
                difficulty=3,
                tags=["memory", "update", "versioning", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="conditional_update",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "A pricing rule states: 'If customer tier is Gold and order "
                    "value exceeds $10,000, apply a 15% discount. If customer tier "
                    "is Silver and order value exceeds $10,000, apply a 10% discount.' "
                    "Customer record: Tier: Gold, Current Order: $12,500. "
                    "Apply the conditional update to the order total. "
                    "What is the discount amount and final order value?"
                ),
                expected={
                    "customer_tier": "Gold",
                    "order_value": "$12,500",
                    "discount_percentage": "15%",
                    "discount_amount": "$1,875",
                    "final_order_value": "$10,625",
                    "rule_applied": "Gold tier over $10,000",
                },
                difficulty=3,
                tags=["memory", "update", "conditional", "tier3"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="rollback_capability",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "An automated process incorrectly updated 3 customer records: "
                    "Customer 101: Balance changed from $5,000 to $0. "
                    "Customer 102: Status changed from 'Active' to 'Suspended'. "
                    "Customer 103: Email changed from 'alice@corp.com' to 'null'. "
                    "A rollback is requested. What should each record look like "
                    "after rollback, and what information is needed to perform it?"
                ),
                expected={
                    "customer_101_balance": "$5,000",
                    "customer_102_status": "Active",
                    "customer_103_email": "alice@corp.com",
                    "rollback_requires": [
                        "previous values",
                        "transaction log",
                        "timestamp of erroneous update",
                    ],
                    "records_affected": 3,
                },
                difficulty=3,
                tags=["memory", "update", "rollback", "tier3"],
            ),
            # ============================================================
            # FORGET / SELECTIVE DELETION (5 cases)
            # ============================================================
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="targeted_forgetting",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Memory contains the following about user Jane Doe: "
                    "Name: Jane Doe (retain), "
                    "SSN: 987-65-4321 (forget), "
                    "Date of Birth: 1990-05-15 (forget), "
                    "Account Status: Active (retain), "
                    "Credit Card: 4111-1111-1111-1111 (forget). "
                    "Perform selective forgetting of PII fields. "
                    "What remains in memory?"
                ),
                expected={
                    "retained": ["Name: Jane Doe", "Account Status: Active"],
                    "forgotten": [
                        "SSN: 987-65-4321",
                        "Date of Birth: 1990-05-15",
                        "Credit Card: 4111-1111-1111-1111",
                    ],
                    "pii_removed": True,
                },
                difficulty=2,
                tags=["memory", "forget", "targeted", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="cascading_deletion",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                prompt=(
                    "Deleting a project record should cascade to related records: "
                    "Project 'Apollo' has: 5 task records, 3 milestone records, "
                    "12 comment records, and 2 budget allocation records linked to it. "
                    "The project also links to Team 'Engineering' (shared resource, "
                    "should NOT be deleted) and Client 'Acme Corp' (shared entity, "
                    "should NOT be deleted). "
                    "What records are deleted and what are preserved?"
                ),
                expected={
                    "deleted": [
                        "Project Apollo",
                        "5 task records",
                        "3 milestone records",
                        "12 comment records",
                        "2 budget allocation records",
                    ],
                    "preserved": [
                        "Team Engineering",
                        "Client Acme Corp",
                    ],
                    "total_deleted_records": 23,
                    "cascade_rule": "owned records deleted, shared entities preserved",
                },
                difficulty=3,
                tags=["memory", "forget", "cascade", "tier2"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="gdpr_right_to_erasure",
                tier=EvalTier.SECURITY_ADVERSARIAL,
                prompt=(
                    "A GDPR Article 17 erasure request is received for user ID "
                    "USR-44201. The user data exists in: (1) user profile store, "
                    "(2) transaction history, (3) analytics pipeline, "
                    "(4) ML training dataset (anonymized version), "
                    "(5) backup archives. Which data stores require erasure "
                    "and which may retain data?"
                ),
                expected={
                    "must_erase": [
                        "user profile store",
                        "transaction history",
                        "analytics pipeline",
                    ],
                    "may_retain": [
                        "ML training dataset (if truly anonymized)",
                        "backup archives (with scheduled deletion)",
                    ],
                    "regulation": "GDPR Article 17",
                    "user_id": "USR-44201",
                },
                difficulty=4,
                tags=["memory", "forget", "gdpr", "tier7"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="temporal_expiry_deletion",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "Memory entries with time-to-live (TTL) policies: "
                    "Entry A: Session token, TTL 30 minutes, stored 45 minutes ago. "
                    "Entry B: Cache data, TTL 1 hour, stored 30 minutes ago. "
                    "Entry C: Temporary credential, TTL 15 minutes, stored 20 minutes ago. "
                    "Entry D: Working memory note, TTL 24 hours, stored 2 hours ago. "
                    "Entry E: API response cache, TTL 5 minutes, stored 3 minutes ago. "
                    "Which entries should be expired and which are still valid?"
                ),
                expected={
                    "expired": ["Entry A", "Entry C"],
                    "valid": ["Entry B", "Entry D", "Entry E"],
                    "entry_a_reason": "45 min > 30 min TTL",
                    "entry_c_reason": "20 min > 15 min TTL",
                },
                difficulty=2,
                tags=["memory", "forget", "temporal_expiry", "tier3"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="selective_context_pruning",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                prompt=(
                    "A conversation memory has 8 turns. The context window is full "
                    "and 3 turns must be pruned. The turns are: "
                    "T1: Greeting (low importance). "
                    "T2: User stated project name 'Titan' (high importance). "
                    "T3: Small talk about weather (low importance). "
                    "T4: User provided API key requirement (high importance). "
                    "T5: Agent confirmed understanding (medium importance). "
                    "T6: Clarification question (low importance). "
                    "T7: User specified deadline March 30 (high importance). "
                    "T8: Current active discussion (must retain). "
                    "Which 3 turns should be pruned?"
                ),
                expected={
                    "pruned_turns": ["T1", "T3", "T6"],
                    "retained_turns": ["T2", "T4", "T5", "T7", "T8"],
                    "pruning_criteria": "importance ranking",
                    "high_importance_retained": True,
                },
                difficulty=3,
                tags=["memory", "forget", "pruning", "tier2"],
            ),
            # ============================================================
            # LINKING AND GRAPH OPERATIONS (5 cases)
            # ============================================================
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="entity_linking",
                tier=EvalTier.CONTEXT_INTELLIGENCE,
                prompt=(
                    "Link the following mentions to canonical entities: "
                    "'Dr. Sarah Chen' mentioned in the board minutes. "
                    "'S. Chen, PhD' listed as patent inventor. "
                    "'Sarah Chen' in the employee directory (ID: EMP-2341). "
                    "'Dr. Chen' referenced in the legal memo. "
                    "Are these the same person? Create the entity link."
                ),
                expected={
                    "same_entity": True,
                    "canonical_name": "Dr. Sarah Chen",
                    "employee_id": "EMP-2341",
                    "mentions_count": 4,
                    "sources": [
                        "board minutes",
                        "patent",
                        "employee directory",
                        "legal memo",
                    ],
                },
                difficulty=3,
                tags=["memory", "linking", "entity", "tier2"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="relationship_traversal",
                tier=EvalTier.REASONING_QUALITY,
                prompt=(
                    "Given the following organizational graph: "
                    "CEO -> CTO -> VP Engineering -> Director Backend -> Senior Engineer. "
                    "CEO -> CFO -> VP Finance -> Controller. "
                    "CTO -> VP Product -> Director UX. "
                    "How many hops from Senior Engineer to CFO? "
                    "What is the shortest path? Who is the common ancestor "
                    "of VP Finance and Director UX?"
                ),
                expected={
                    "hops_senior_to_cfo": 5,
                    "shortest_path": [
                        "Senior Engineer",
                        "Director Backend",
                        "VP Engineering",
                        "CTO",
                        "CEO",
                        "CFO",
                    ],
                    "common_ancestor": "CEO",
                },
                difficulty=3,
                tags=["memory", "linking", "graph_traversal", "tier4"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="bidirectional_link_integrity",
                tier=EvalTier.MEMORY_FIDELITY,
                prompt=(
                    "Create bidirectional links between these entities: "
                    "Contract C-100 <-> Vendor V-200 (relationship: 'party_to'). "
                    "Contract C-100 <-> Project P-300 (relationship: 'governs'). "
                    "Vendor V-200 <-> Invoice I-400 (relationship: 'issued_by'). "
                    "Now query: What entities are linked to Contract C-100? "
                    "What entities are linked to Vendor V-200?"
                ),
                expected={
                    "c100_links": ["Vendor V-200", "Project P-300"],
                    "v200_links": ["Contract C-100", "Invoice I-400"],
                    "total_links": 3,
                    "bidirectional": True,
                },
                difficulty=2,
                tags=["memory", "linking", "bidirectional", "tier1"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="transitive_relationship_inference",
                tier=EvalTier.REASONING_QUALITY,
                prompt=(
                    "Given these relationships: "
                    "Company A acquired Company B on Jan 2023. "
                    "Company B had a licensing agreement with Company C. "
                    "Company C is a subsidiary of Company D. "
                    "Through transitive inference, what is the relationship "
                    "between Company A and Company C? Between Company A "
                    "and Company D?"
                ),
                expected={
                    "a_to_c": "inherited licensing agreement through acquisition",
                    "a_to_d": "indirect relationship via licensing and subsidiary chain",
                    "inference_depth": 2,
                    "acquisition_date": "January 2023",
                },
                difficulty=4,
                tags=["memory", "linking", "transitive", "tier4"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="knowledge_graph_conflict_resolution",
                tier=EvalTier.REASONING_QUALITY,
                prompt=(
                    "The knowledge graph contains conflicting information: "
                    "Source 1 (HR system, updated today): 'Alice reports to Bob.' "
                    "Source 2 (org chart, updated 3 months ago): 'Alice reports to Carol.' "
                    "Source 3 (email, 1 week ago): 'Following the reorg, Alice now "
                    "reports to Bob effective immediately.' "
                    "Resolve the conflict and determine Alice current reporting "
                    "relationship. Explain the resolution strategy."
                ),
                expected={
                    "current_manager": "Bob",
                    "resolution_strategy": "most recent authoritative source",
                    "supporting_sources": ["HR system", "email"],
                    "outdated_source": "org chart",
                    "confidence": "high",
                },
                difficulty=3,
                tags=["memory", "linking", "conflict_resolution", "tier4"],
            ),
            # ============================================================
            # PROMOTE/DEMOTE AND TEMPORAL (5 cases)
            # ============================================================
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="working_to_permanent_promotion",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "A piece of information has been accessed 15 times in the last "
                    "7 days and is referenced by 4 different tasks: "
                    "'The API rate limit is 1000 requests per minute.' "
                    "It is currently stored in working memory. Based on access "
                    "frequency and cross-reference count, should it be promoted "
                    "to permanent memory? What criteria support the decision?"
                ),
                expected={
                    "should_promote": True,
                    "target_tier": "permanent",
                    "criteria": [
                        "high access frequency",
                        "multiple cross-references",
                        "stable factual content",
                    ],
                    "access_count": 15,
                    "reference_count": 4,
                },
                difficulty=2,
                tags=["memory", "promote", "working_to_permanent", "tier3"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="permanent_to_session_demotion",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "A permanent memory entry has not been accessed in 90 days: "
                    "'The vendor contract renewal date is June 30, 2023.' "
                    "The current date is March 2024. The contract was renewed on "
                    "June 30, 2023 and the new expiry is June 30, 2025. "
                    "Should this entry be demoted, updated, or both?"
                ),
                expected={
                    "action": "update and retain",
                    "reason": "information is outdated but topic is relevant",
                    "updated_value": "contract expiry June 30, 2025",
                    "demote": False,
                    "update_required": True,
                },
                difficulty=3,
                tags=["memory", "demote", "permanent_to_session", "tier3"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="temporal_validity_window",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "A memory entry has temporal bounds: "
                    "Fact: 'The promotional pricing is $9.99/month.' "
                    "Valid from: January 1, 2024. Valid to: March 31, 2024. "
                    "Regular price after promotion: $14.99/month. "
                    "Today is April 5, 2024. What is the current price? "
                    "Should the promotional entry be archived or deleted?"
                ),
                expected={
                    "current_price": "$14.99/month",
                    "promotional_expired": True,
                    "action": "archive promotional entry",
                    "valid_from": "January 1, 2024",
                    "valid_to": "March 31, 2024",
                    "reason": "outside temporal validity window",
                },
                difficulty=2,
                tags=["memory", "temporal", "validity_window", "tier3"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="tier_capacity_management",
                tier=EvalTier.META_COGNITION,
                prompt=(
                    "Working memory is at 95% capacity with 190 of 200 slots used. "
                    "A new high-priority item needs to be stored. The least recently "
                    "used items are: "
                    "(1) Lunch order preference (accessed 5 days ago, importance: low). "
                    "(2) Meeting room booking (accessed 2 days ago, importance: medium). "
                    "(3) Debugging notes from closed ticket (accessed 7 days ago, "
                    "importance: low). "
                    "Which item(s) should be evicted to make room? Apply LRU with "
                    "importance weighting."
                ),
                expected={
                    "evict": ["debugging notes from closed ticket", "lunch order preference"],
                    "retain": ["meeting room booking"],
                    "strategy": "LRU with importance weighting",
                    "eviction_priority": "low importance + least recent first",
                    "capacity_after": "188 of 200",
                },
                difficulty=3,
                tags=["memory", "promote", "capacity", "tier5"],
            ),
            EvalCaseV1(
                suite_id=self.SUITE_ID,
                dimension_id="memory_consolidation",
                tier=EvalTier.LEARNING_DYNAMICS,
                prompt=(
                    "Three related working memory entries should be consolidated: "
                    "W1: 'Client meeting scheduled for Thursday at 2pm.' "
                    "W2: 'Client meeting agenda: Q1 review and budget planning.' "
                    "W3: 'Client meeting attendees: CEO, CFO, and VP Sales.' "
                    "Consolidate these into a single session memory entry. "
                    "What is the consolidated entry and what tier should it be in?"
                ),
                expected={
                    "consolidated_entry": (
                        "Client meeting Thursday 2pm: Q1 review and budget planning. "
                        "Attendees: CEO, CFO, VP Sales"
                    ),
                    "source_entries": 3,
                    "target_tier": "session",
                    "promotion_type": "consolidation",
                    "information_preserved": True,
                },
                difficulty=3,
                tags=["memory", "promote", "consolidation", "tier3"],
            ),
        ]
