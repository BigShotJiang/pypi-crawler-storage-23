"""Contract schema dataclasses used by Flow submissions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class SubmissionNode:
    """Merkle node info embedded in a Flow submission."""

    root: bytes
    height: int


@dataclass
class SubmissionData:
    """Submission payload passed to the Flow contract."""

    length: int
    tags: bytes
    nodes: List[SubmissionNode]


@dataclass
class Submission:
    """Submission envelope sent to the Flow contract."""

    data: SubmissionData
    submitter: str
