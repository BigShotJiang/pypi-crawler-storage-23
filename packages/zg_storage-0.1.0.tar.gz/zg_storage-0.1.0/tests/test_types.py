from zg_storage.types import ShardConfig, ShardedNodes


def test_shard_config_aliases():
    cfg = ShardConfig.model_validate({"shardId": 1, "numShard": 4})
    assert cfg.shard_id == 1
    assert cfg.num_shard == 4


def test_sharded_nodes():
    nodes = ShardedNodes.model_validate(
        {
            "trusted": [{"url": "http://n1", "config": {"shardId": 0, "numShard": 2}}],
            "discovered": [],
        }
    )
    assert nodes.trusted[0].url == "http://n1"
    assert nodes.trusted[0].config.num_shard == 2
