from pathlib import Path

from zg_storage import FlowBuilder, submission_root
from zg_storage.utils import DEFAULT_CHUNK_SIZE, DEFAULT_SEGMENT_SIZE, compute_data_root


def test_data_root_matches_flow_submission(tmp_path: Path):
    data = b"hello 0g storage" * 123
    file_path = tmp_path / "data.bin"
    file_path.write_bytes(data)

    submission = FlowBuilder(str(file_path), b"").create_submission(
        "0x0000000000000000000000000000000000000000"
    )
    root1 = submission_root(submission)

    root2 = compute_data_root(data, DEFAULT_SEGMENT_SIZE, DEFAULT_CHUNK_SIZE)
    assert root1 == root2
