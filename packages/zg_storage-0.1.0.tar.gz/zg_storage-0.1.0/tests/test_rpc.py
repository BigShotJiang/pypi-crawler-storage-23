from zg_storage.rpc import RpcClient


def test_rpc_request_body():
    client = RpcClient("http://localhost:1234")
    body = client._request_body("test_method", [1, 2], request_id=7)
    assert body["jsonrpc"] == "2.0"
    assert body["id"] == 7
    assert body["method"] == "test_method"
    assert body["params"] == [1, 2]
