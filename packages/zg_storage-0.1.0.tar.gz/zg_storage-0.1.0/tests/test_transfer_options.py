from zg_storage.transfer import UploadOption


def test_upload_option_defaults():
    opt = UploadOption()
    assert opt.task_size == 10
    assert opt.expected_replica == 1
    assert opt.skip_tx is True
    assert opt.fast_mode is True
    assert opt.method == "min"
    assert opt.full_trusted is True
