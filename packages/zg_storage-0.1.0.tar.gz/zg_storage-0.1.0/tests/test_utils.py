from zg_storage.utils import ensure_hex, hex_to_bytes


def test_ensure_hex():
    assert ensure_hex("0x01") == "0x01"
    assert ensure_hex("01") == "0x01"
    assert ensure_hex(b"\x01") == "0x01"


def test_hex_to_bytes():
    assert hex_to_bytes("0x01") == b"\x01"
    assert hex_to_bytes("01") == b"\x01"
