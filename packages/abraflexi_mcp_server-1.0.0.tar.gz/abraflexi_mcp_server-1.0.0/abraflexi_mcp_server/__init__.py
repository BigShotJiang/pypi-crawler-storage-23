"""
AbraFlexi MCP Server package.
"""

__version__ = "1.0.0"
