# Maximilian Beck
from typing import Optional

import torch
import triton
import triton.language as tl

from .triton_utils import is_power_of_2, next_multiple_of, torch2triton_dtype

# Dimensions:
# B: batch size
# T: sequence length
# NGI: number of gates that depend on input
# NGR: number of gates that depend on recurrent state
# NH: number of heads
# DH: hidden dimension
# NS: number of states

# Note: NS dimension
# > in NS dimension the first index is the state that is used for recurrent weights


# Note on the kernel:
# we only pass the dimensions and not the stride to the kernel
# inside we compute the strides from the dimensions

# we assume for simplicity: NGR == NGI


@triton.jit
def triton_tanh(x):
    return (1.0 - tl.exp(-2.0 * x)) / (1.0 + tl.exp(-2.0 * x))


@triton.jit
def _backward_sequence_kernel(
    # inputs
    delta_states_all_outside,  # (NH, T, NS=4, B, DH) delta errors from all states
    delta_states_last_outside,  # (NH, NS=4, B, DH) delta errors from the last state
    R,  # (NH, NGR, DHout, DHin) recurrent weights
    states_all,  # (NH, T+1, NS=4, B, DH) all states
    gates_all,  # (NH, T, NGI, B, DH) all gates
    resets,  # (T, B) per-timestep reset mask (optional)
    delta_h_tmp,  # (NH, B, DH) scratch for recurrent delta_h propagation
    # outputs
    delta_states_initial,  # (NH, NS=4, B, DH) delta errors to initial states
    delta_Wx,  # (NH, T, NGI, B, DH) delta errors to inputs
    # dimensions
    T: tl.constexpr,  # sequence length
    NS: tl.constexpr,  # number of states
    B: tl.constexpr,  # batch size
    NH: tl.constexpr,  # number of heads
    DH: tl.constexpr,  # hidden dimension
    NGI: tl.constexpr,  # number of gates that depend on input
    NGR: tl.constexpr,  # number of gates that depend on recurrent state
    siz_B: tl.constexpr,  # the number of batches per thread block
    # consts
    DTYPE: tl.constexpr = tl.float32,
    HAS_RESETS: tl.constexpr = False,
    backward_recurrent_clip_val: tl.constexpr = -1.0,  # if > 0, clip the recurrent gradients
    TN: tl.constexpr = 16,  # output-column tile for recurrent matmul
):
    idx_b_NH, idx_b_B = tl.program_id(0), tl.program_id(1)

    ## compute the strides
    str_matR_NH = NGR * DH * DH
    str_matR_NGR = DH * DH
    str_matStatesAll_NH = (T + 1) * NS * B * DH
    str_matStatesAll_T = NS * B * DH
    str_matGatesAll_NH = T * NGI * B * DH
    str_matGatesAll_T = NGI * B * DH
    str_delta_states_all_outside_NH = T * NS * B * DH
    str_delta_states_all_outside_T = NS * B * DH
    str_matDeltaWx_NH = T * NGI * B * DH
    str_matDeltaWx_T = NGI * B * DH
    str_delta_h_tmp_NH = B * DH
    ##

    ## load delta errors from last state
    # load matDeltaH from last state
    matDeltaHtrans_last_ptr = tl.make_block_ptr(
        base=delta_states_last_outside + idx_b_NH * NS * B * DH + 0 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    matDeltaH_tplus1 = tl.load(matDeltaHtrans_last_ptr).to(tl.float32)  # (siz_B, DH)

    # load matDeltaC from last state
    matDeltaCtrans_last_ptr = tl.make_block_ptr(
        base=delta_states_last_outside + idx_b_NH * NS * B * DH + 1 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    matDeltaC_tplus1 = tl.load(matDeltaCtrans_last_ptr).to(tl.float32)  # (siz_B, DH)

    # load matDeltaN_tplus1 from last state
    matDeltaNtrans_last_ptr = tl.make_block_ptr(
        base=delta_states_last_outside + idx_b_NH * NS * B * DH + 2 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    matDeltaN_tplus1 = tl.load(matDeltaNtrans_last_ptr).to(tl.float32)  # (siz_B, DH)

    # Note: we do not need to load the m state as the gradients through this state cancel out

    ## loop over the sequence from T-1 to 0 (inclduding 0)
    for idx_t in range(T - 1, -1, -1):
        reset_vals = tl.zeros((siz_B,), dtype=tl.float32)
        if HAS_RESETS:
            row_idx = idx_b_B * siz_B + tl.arange(0, siz_B)
            reset_vals = tl.load(
                resets + idx_t * B + row_idx,
                mask=row_idx < B,
                other=0.0,
            ).to(tl.float32)
        reset_keep = 1.0 - reset_vals
        ## load gate activations G for the current time step idx_t
        # gates in float32 as tl.exp and tl.log are not supported in (b)float16
        matG_i_ptr = tl.make_block_ptr(
            base=gates_all + idx_b_NH * str_matGatesAll_NH + idx_t * str_matGatesAll_T + 0 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matG_ibar = tl.load(matG_i_ptr, boundary_check=(0, 1)).to(tl.float32)  # (siz_B, DH)

        matG_f_ptr = tl.make_block_ptr(
            base=gates_all + idx_b_NH * str_matGatesAll_NH + idx_t * str_matGatesAll_T + 1 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matG_fbar = tl.load(matG_f_ptr, boundary_check=(0, 1)).to(tl.float32)  # (siz_B, DH)

        matG_z_ptr = tl.make_block_ptr(
            base=gates_all + idx_b_NH * str_matGatesAll_NH + idx_t * str_matGatesAll_T + 2 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matG_z = tl.load(matG_z_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matG_o_ptr = tl.make_block_ptr(
            base=gates_all + idx_b_NH * str_matGatesAll_NH + idx_t * str_matGatesAll_T + 3 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matG_o = tl.load(matG_o_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        ## load the c_t, n_t, m_t states for the current time step idx_t from idx_t+1
        # (states_all contains the initial states at idx_t=0)
        matC_t_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t + 1) * str_matStatesAll_T + 1 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matC_t = tl.load(matC_t_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matN_t_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t + 1) * str_matStatesAll_T + 2 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matN_t = tl.load(matN_t_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matM_t_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t + 1) * str_matStatesAll_T + 3 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matM_t = tl.load(matM_t_ptr, boundary_check=(0, 1)).to(tl.float32)  # (siz_B, DH)

        ## load the c_t-1, n_t-1, m_t-1 states for the previous time step idx_t-1 from idx_t
        matC_tminus1_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t) * str_matStatesAll_T + 1 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matC_tminus1 = tl.load(matC_tminus1_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matN_tminus1_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t) * str_matStatesAll_T + 2 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matN_tminus1 = tl.load(matN_tminus1_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matM_tminus1_ptr = tl.make_block_ptr(
            base=states_all + idx_b_NH * str_matStatesAll_NH + (idx_t) * str_matStatesAll_T + 3 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matM_tminus1 = tl.load(matM_tminus1_ptr, boundary_check=(0, 1)).to(tl.float32)  # (siz_B, DH)

        ## load delta errors (delta_h_t, delta_c_t, delta_n_t) from outside for timestep idx_t
        matDeltaHtrans_out_t_ptr = tl.make_block_ptr(
            base=delta_states_all_outside
            + idx_b_NH * str_delta_states_all_outside_NH
            + idx_t * str_delta_states_all_outside_T
            + 0 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matDeltaHtrans_out_t = tl.load(matDeltaHtrans_out_t_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matDeltaCtrans_out_t_ptr = tl.make_block_ptr(
            base=delta_states_all_outside
            + idx_b_NH * str_delta_states_all_outside_NH
            + idx_t * str_delta_states_all_outside_T
            + 1 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matDeltaCtrans_out_t = tl.load(matDeltaCtrans_out_t_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        matDeltaNtrans_out_t_ptr = tl.make_block_ptr(
            base=delta_states_all_outside
            + idx_b_NH * str_delta_states_all_outside_NH
            + idx_t * str_delta_states_all_outside_T
            + 2 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matDeltaNtrans_out_t = tl.load(matDeltaNtrans_out_t_ptr, boundary_check=(0, 1))  # (siz_B, DH)

        ## compute the backward pointwise operations
        matDeltaH_t = matDeltaHtrans_out_t + matDeltaH_tplus1  # (siz_B, DH)
        matDeltaC_t = matDeltaCtrans_out_t + matDeltaC_tplus1  # (siz_B, DH)
        matDeltaN_t = matDeltaNtrans_out_t + matDeltaN_tplus1  # (siz_B, DH)

        # slstm pointwise backward (numerically stabilized)
        # Compute in float32 to avoid overflow/underflow in divisions
        EPS = 1e-6
        m_go = matG_o.to(tl.float32)
        m_ct = matC_t.to(tl.float32)
        m_nt = matN_t.to(tl.float32)
        m_dh = matDeltaH_t.to(tl.float32)
        matDeltaC_t = matDeltaC_t.to(tl.float32) + m_dh * (m_go / (m_nt + EPS))  # (siz_B, DH)
        matDeltaN_t = matDeltaN_t.to(tl.float32) - m_dh * (m_go * m_ct / ((m_nt + EPS) * (m_nt + EPS)))  # (siz_B, DH)

        matG_i = tl.exp(matG_ibar - matM_t)  # (siz_B, DH)
        matG_logfplusm = matM_tminus1 + tl.log(tl.sigmoid(matG_fbar))  # (siz_B, DH)
        matG_f = tl.exp(matG_logfplusm - matM_t)  # (siz_B, DH)

        # compute the delta gate errors # (siz_B, DHout)
        matDeltaGI = (matDeltaC_t * matG_z + matDeltaN_t) * matG_i
        matDeltaGF = (matDeltaC_t * matC_tminus1 + matDeltaN_t * matN_tminus1) * matG_f * tl.sigmoid(-matG_fbar)
        matDeltaGZ = matDeltaC_t * matG_i * (1 - matG_z * matG_z)
        matDeltaGO = m_dh * (m_ct / (m_nt + EPS)) * (1 - m_go) * m_go

        # compute the delta errors to previous states
        matDeltaC_tminus1 = matDeltaC_t * matG_f
        matDeltaN_tminus1 = matDeltaN_t * matG_f

        keep_broadcast = reset_keep[:, None]
        matDeltaC_tminus1 = matDeltaC_tminus1 * keep_broadcast
        matDeltaN_tminus1 = matDeltaN_tminus1 * keep_broadcast

        # Store delta_h_{t-1} in tiles to avoid loading full R (DH x DH) into shared memory.
        for n0 in range(0, DH, TN):
            matR_i_tile_ptr = tl.make_block_ptr(
                base=R + idx_b_NH * str_matR_NH + 0 * str_matR_NGR,
                shape=(DH, DH),
                strides=(DH, 1),
                offsets=(0, n0),
                block_shape=(DH, TN),
                order=(0, 1),
            )
            matR_i_tile = tl.load(matR_i_tile_ptr, boundary_check=(0, 1))

            matR_f_tile_ptr = tl.make_block_ptr(
                base=R + idx_b_NH * str_matR_NH + 1 * str_matR_NGR,
                shape=(DH, DH),
                strides=(DH, 1),
                offsets=(0, n0),
                block_shape=(DH, TN),
                order=(0, 1),
            )
            matR_f_tile = tl.load(matR_f_tile_ptr, boundary_check=(0, 1))

            matR_z_tile_ptr = tl.make_block_ptr(
                base=R + idx_b_NH * str_matR_NH + 2 * str_matR_NGR,
                shape=(DH, DH),
                strides=(DH, 1),
                offsets=(0, n0),
                block_shape=(DH, TN),
                order=(0, 1),
            )
            matR_z_tile = tl.load(matR_z_tile_ptr, boundary_check=(0, 1))

            matR_o_tile_ptr = tl.make_block_ptr(
                base=R + idx_b_NH * str_matR_NH + 3 * str_matR_NGR,
                shape=(DH, DH),
                strides=(DH, 1),
                offsets=(0, n0),
                block_shape=(DH, TN),
                order=(0, 1),
            )
            matR_o_tile = tl.load(matR_o_tile_ptr, boundary_check=(0, 1))

            matDeltaH_tile = tl.dot(matDeltaGI.to(DTYPE), matR_i_tile)  # (siz_B, TN)
            matDeltaH_tile += tl.dot(matDeltaGF.to(DTYPE), matR_f_tile)
            matDeltaH_tile += tl.dot(matDeltaGZ.to(DTYPE), matR_z_tile)
            matDeltaH_tile += tl.dot(matDeltaGO.to(DTYPE), matR_o_tile)
            matDeltaH_tile = matDeltaH_tile * keep_broadcast

            matDeltaH_store_ptr = tl.make_block_ptr(
                base=delta_h_tmp + idx_b_NH * str_delta_h_tmp_NH,
                shape=(B, DH),
                strides=(DH, 1),
                offsets=(idx_b_B * siz_B, n0),
                block_shape=(siz_B, TN),
                order=(0, 1),
            )
            tl.store(matDeltaH_store_ptr, matDeltaH_tile.to(DTYPE), boundary_check=(0, 1))

        ## store the deltaGate errors
        matDeltaGI_ptr = tl.make_block_ptr(
            base=delta_Wx + idx_b_NH * str_matDeltaWx_NH + idx_t * str_matDeltaWx_T + 0 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        tl.store(matDeltaGI_ptr, matDeltaGI.to(DTYPE), boundary_check=(0, 1))

        matDeltaGF_ptr = tl.make_block_ptr(
            base=delta_Wx + idx_b_NH * str_matDeltaWx_NH + idx_t * str_matDeltaWx_T + 1 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        tl.store(matDeltaGF_ptr, matDeltaGF.to(DTYPE), boundary_check=(0, 1))

        matDeltaGZ_ptr = tl.make_block_ptr(
            base=delta_Wx + idx_b_NH * str_matDeltaWx_NH + idx_t * str_matDeltaWx_T + 2 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        tl.store(matDeltaGZ_ptr, matDeltaGZ.to(DTYPE), boundary_check=(0, 1))

        matDeltaGO_ptr = tl.make_block_ptr(
            base=delta_Wx + idx_b_NH * str_matDeltaWx_NH + idx_t * str_matDeltaWx_T + 3 * B * DH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        tl.store(matDeltaGO_ptr, matDeltaGO.to(DTYPE), boundary_check=(0, 1))

        ## next iteration
        matDeltaH_tplus1_ptr = tl.make_block_ptr(
            base=delta_h_tmp + idx_b_NH * str_delta_h_tmp_NH,
            shape=(B, DH),
            strides=(DH, 1),
            offsets=(idx_b_B * siz_B, 0),
            block_shape=(siz_B, DH),
            order=(0, 1),
        )
        matDeltaH_tplus1 = tl.load(matDeltaH_tplus1_ptr, boundary_check=(0, 1)).to(tl.float32)  # (siz_B, DH)
        matDeltaC_tplus1 = matDeltaC_tminus1  # (siz_B, DH)
        matDeltaN_tplus1 = matDeltaN_tminus1  # (siz_B, DH)

    ## store the delta errors to the initial states
    matDeltaHtrans_initial_ptr = tl.make_block_ptr(
        base=delta_states_initial + idx_b_NH * NS * B * DH + 0 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    tl.store(matDeltaHtrans_initial_ptr, matDeltaH_tplus1.to(DTYPE), boundary_check=(0, 1))

    matDeltaCtrans_initial_ptr = tl.make_block_ptr(
        base=delta_states_initial + idx_b_NH * NS * B * DH + 1 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    tl.store(matDeltaCtrans_initial_ptr, matDeltaC_tplus1.to(DTYPE), boundary_check=(0, 1))

    matDeltaNtrans_initial_ptr = tl.make_block_ptr(
        base=delta_states_initial + idx_b_NH * NS * B * DH + 2 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    tl.store(matDeltaNtrans_initial_ptr, matDeltaN_tplus1.to(DTYPE), boundary_check=(0, 1))

    # set the initial m state gradient to zero
    matDeltaMtrans_initial_ptr = tl.make_block_ptr(
        base=delta_states_initial + idx_b_NH * NS * B * DH + 3 * B * DH,
        shape=(B, DH),
        strides=(DH, 1),
        offsets=(idx_b_B * siz_B, 0),
        block_shape=(siz_B, DH),
        order=(0, 1),
    )
    tl.store(matDeltaMtrans_initial_ptr, tl.zeros((siz_B, DH), dtype=DTYPE), boundary_check=(0, 1))


def backward_sequence(
    delta_states_all_outside: torch.Tensor,  # (T, NS, B, NH, D) all state delta errors from outside
    delta_states_last_outside: torch.Tensor,  # (NS, B, NH, D) last state delta errors from outside
    R: torch.Tensor,  # (NGR, NH, Dout, Din) recurrent weights
    states_all: torch.Tensor,  # (T+1, NS, B, NH, D) all states
    gates_all: torch.Tensor,  # (T, NGI, B, NH, D) all gates
    resets: Optional[torch.Tensor] = None,  # (B, T) reset mask
    backward_recurrent_clip_val: float | None = None,
    siz_B: int = 16,
    true_B: int | None = None,
) -> [
    torch.Tensor,  # (NS, B, NH, D) delta errors to initial states
    torch.Tensor,  # (B, T, NGI, NH, D) delta errors to inputs
    torch.Tensor,  # (NGR, NH, D, D) delta errors to recurrent weights
    torch.Tensor,  # (NH, NGI, D) delta errors to biases
]:
    # support the case where delta_states_last_outside has the time dimension explicitly
    T_dim_explicit = False
    if delta_states_last_outside.ndim == 5:
        assert delta_states_last_outside.shape[0] == 1, (
            f"states_initial.shape[0] must be 1: got {delta_states_last_outside.shape}."
        )
        T_dim_explicit = True
        delta_states_last_outside = delta_states_last_outside[0]

    if true_B is None:
        true_B = delta_states_all_outside.shape[2]
    T, NS, _, NH, DH = delta_states_all_outside.shape
    NGR, _, _, _ = R.shape
    assert NS == 4, "sLSTM has 4 states: h, c, n, m."
    assert NGR == 4, "sLSTM has 4 gates: i, f, z, o."
    NGI = NGR
    dtype = R.dtype
    device = R.device

    assert R.shape[1:] == (NH, DH, DH)

    assert delta_states_all_outside.dtype == dtype, (
        f"dtype mismatch: delta_states_all.dtype: {R.dtype}, R.dtype: {dtype}."
    )
    assert delta_states_last_outside.dtype == dtype, (
        f"dtype mismatch: delta_states_last.dtype: {R.dtype}, R.dtype: {dtype}."
    )

    has_resets = resets is not None
    resets_prepared: Optional[torch.Tensor]
    if has_resets:
        if resets.dim() == 1:
            resets = resets.unsqueeze(1).expand(true_B, T)
        assert resets.shape == (true_B, T), f"resets must have shape (B, T); got {resets.shape}"
        resets_prepared = resets.to(device=device, dtype=torch.float32, non_blocking=True)
    else:
        resets_prepared = None

    assert is_power_of_2(DH), f"head dimension must be a power of 2, got {DH}."

    MIN_BATCH_SIZE = 16  # we need at least 16 batches for tl.dot() (16x16 tensor cores)
    ## batch size padding to be a multiple of MIN_BATCH_SIZE
    effective_B = next_multiple_of(true_B, MIN_BATCH_SIZE)
    if effective_B != true_B:
        delta_states_all_outside = torch.cat(
            [
                delta_states_all_outside,
                torch.zeros([T, NS, effective_B - true_B, NH, DH], dtype=dtype, device=device),
            ],
            dim=2,
        )
        delta_states_last_outside = torch.cat(
            [
                delta_states_last_outside,
                torch.zeros([NS, effective_B - true_B, NH, DH], dtype=dtype, device=device),
            ],
            dim=1,
        )
        if has_resets:
            assert resets_prepared is not None
            resets_prepared = torch.cat(
                [
                    resets_prepared,
                    torch.zeros([effective_B - true_B, T], dtype=resets_prepared.dtype, device=device),
                ],
                dim=0,
            )

    if has_resets:
        assert resets_prepared is not None
        resets_kshaped = resets_prepared.t().contiguous()
    else:
        resets_kshaped = torch.empty((0,), device=device, dtype=torch.float32)

    # Reshapes for kernel
    R_kshaped = R.permute(1, 0, 2, 3).contiguous()

    delta_states_all_outside_kshaped = delta_states_all_outside.permute(3, 0, 1, 2, 4).contiguous()
    delta_states_last_outside_kshaped = delta_states_last_outside.permute(2, 0, 1, 3).contiguous()

    states_all_kshaped = states_all.permute(3, 0, 1, 2, 4).contiguous()
    gates_all_kshaped = gates_all.permute(3, 0, 1, 2, 4).contiguous()

    # kernel call
    num_B = triton.cdiv(effective_B, siz_B)
    grid = (NH, num_B)

    # Allocate output tensors
    delta_Wx = torch.empty([NH, T, NGI, effective_B, DH], dtype=dtype, device=device)
    delta_states_initial = torch.empty([NH, NS, effective_B, DH], dtype=dtype, device=device)
    delta_h_tmp = torch.empty([NH, effective_B, DH], dtype=dtype, device=device)

    if backward_recurrent_clip_val is None:
        backward_recurrent_clip_val = -1.0

    _backward_sequence_kernel[grid](
        delta_states_all_outside=delta_states_all_outside_kshaped,
        delta_states_last_outside=delta_states_last_outside_kshaped,
        R=R_kshaped,
        states_all=states_all_kshaped,
        gates_all=gates_all_kshaped,
        resets=resets_kshaped,
        delta_h_tmp=delta_h_tmp,
        delta_states_initial=delta_states_initial,
        delta_Wx=delta_Wx,
        T=T,
        NS=NS,
        B=effective_B,
        NH=NH,
        DH=DH,
        NGI=NGI,
        NGR=NGR,
        siz_B=siz_B,
        DTYPE=torch2triton_dtype(dtype),
        HAS_RESETS=has_resets,
        backward_recurrent_clip_val=backward_recurrent_clip_val,
        TN=16,
        num_warps=4,
    )

    delta_Wx = delta_Wx.permute(3, 1, 2, 0, 4)
    delta_states_initial = delta_states_initial.permute(1, 2, 0, 3)
    ## batch_size padding
    delta_states_initial = delta_states_initial[:, :true_B, ...]
    delta_Wx = delta_Wx[:true_B, ...]

    # Compute recurrent weight and bias gradients with PyTorch ops to avoid large
    # per-program shared memory requirements (especially when DH is large).
    h_prev = states_all[:-1, 0, :true_B].permute(1, 0, 2, 3)  # (B, T, NH, DH)
    if has_resets:
        assert resets is not None
        keep = (1.0 - resets[:true_B].to(device=device, dtype=dtype)).view(true_B, T, 1, 1)
        h_prev = h_prev * keep
    delta_b = delta_Wx.sum(dim=(0, 1))  # (NGI, NH, DH)
    delta_R = torch.einsum("btghd,bthk->ghdk", delta_Wx, h_prev).contiguous()  # (NGR, NH, DH, DH)

    if T_dim_explicit:
        delta_states_initial = delta_states_initial.unsqueeze(0)

    return delta_states_initial, delta_Wx, delta_R, delta_b
