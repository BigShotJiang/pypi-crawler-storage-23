﻿# encoding: utf-8
import re,sys,os,time,datetime,requests,json
from spiderx import sx
from PIL import Image, ImageDraw,ImageFont,ImageFilter
from collections import defaultdict
import numpy as np
import cv2
from . import sx
ff=sx.FFMPEG()
fonts_dict={}
FONT_HREF="http://ip.wgnms.top:9980/media/upload/user_1/2022-01-22/ppt_font.ttf"
def 计算时间(时间毫秒):
    return sx.时间秒转日期格式(int(时间毫秒 / 1000))
class FRAME:
    def __init__(self,frame_num,视频宽,视频高,背景图片,头像图片,显示头像=True,头像尺寸=200,字体路径=None,采样倍数=1,istest=False):
        self.istest = istest
        self.frame_num=frame_num
        self.frame_fname=f'{frame_num:0=6}.png'
        self.视频宽=视频宽
        self.视频高=视频高
        self.背景图片=self.加载图片(背景图片)
        self.头像图片=self.加载图片(头像图片)
        self.显示头像=显示头像
        self.头像尺寸=头像尺寸
        self.头像尺寸_padding=10
        self.字体路径=字体路径
        #----------------------------
        self.frame_size = (self.视频宽, self.视频高)
        self.frame_size_default = (self.视频宽, self.视频高) #绘图数据的标准尺寸
        self.frame_size_竖屏 = None #如果
        self.img_导出图片=None
        self.draw = None
        self.draw_points = None
        self.采样倍数=采样倍数
        self.高斯模糊半径 = 0.5 #float
        self.加载背景()
        if self.显示头像:
            self.加载头像()
    def 颜色转RGBA(self, 颜色值, 透明度: int = 1):
        """
        将颜色值转换为RGBA元组
        参数:
            颜色值:
                - 字符串: "#FF0000" 或 "FF0000"
                - 整数: 16711680 (十进制) 或 0xFF0000 (十六进制)
            透明度: 0-1之间的浮点数或整数，1为完全不透明
        返回:
            (r, g, b, a) 元组
        """
        # 处理透明度
        if 0 <= 透明度 <= 1:
            alpha_int = int(255 * 透明度)
        else:
            alpha_int = 255  # 默认完全不透明

        # 判断输入类型并处理
        if isinstance(颜色值, int):
            # 整数类型：支持十进制和十六进制表示
            # 确保只取RGB部分（24位）
            颜色值 = 颜色值 & 0xFFFFFF

            # 提取RGB分量
            r = (颜色值 >> 16) & 0xFF
            g = (颜色值 >> 8) & 0xFF
            b = 颜色值 & 0xFF

            return (r, g, b, alpha_int)

        elif isinstance(颜色值, str):
            # 字符串类型：十六进制表示
            颜色值 = 颜色值.lstrip('#')

            # 处理3位缩写格式（如 #FFF -> #FFFFFF）
            if len(颜色值) == 3:
                颜色值 = ''.join([c * 2 for c in 颜色值])

            # 处理6位标准格式
            if len(颜色值) == 6:
                r = int(颜色值[0:2], 16)
                g = int(颜色值[2:4], 16)
                b = int(颜色值[4:6], 16)
                return (r, g, b, alpha_int)

            # 处理8位格式（带透明度）
            elif len(颜色值) == 8:
                r = int(颜色值[0:2], 16)
                g = int(颜色值[2:4], 16)
                b = int(颜色值[4:6], 16)
                # 使用输入中的透明度，忽略透明度参数
                a = int(颜色值[6:8], 16)
                return (r, g, b, a)

            else:
                raise ValueError(f"无效的十六进制颜色值: #{颜色值}")

        elif isinstance(颜色值, tuple):
            # 元组类型：支持RGB和RGBA格式
            length = len(颜色值)
            if length == 3:
                # RGB格式：(r, g, b)
                r, g, b = 颜色值
                return (r, g, b, 透明度)
            elif length == 4:
                # RGBA格式：(r, g, b, a)
                r, g, b, a = 颜色值
                return (r, g, b, a)  # 使用元组中的透明度
            else:
                raise ValueError(f"无效的元组长度: {length}，期望3或4个元素")

        else:
            raise TypeError(f"不支持的颜色值类型: {type(颜色值)}")
    def 加载图片(self,图片):
        if isinstance(图片,str):
            if os.path.exists(图片):
                return Image.open(图片).convert('RGBA') #RGBA
            else:
                raise Exception('没有找到图片')
        elif type(图片)!=Image.Image:
            return Image.fromarray(图片).convert('RGBA')
        else:
            return 图片
    def 检查是否转竖屏(self, bg_image):
        if bg_image.size != self.frame_size:
            width, height = bg_image.size
            if width < height:  # 竖向图片
                # 创建透明背景
                bg = Image.new("RGBA", self.frame_size, (255, 255, 255, 0))
                # 计算缩放后的尺寸
                newH = int(self.frame_size[1])
                newW = int(newH * (width / height))
                self.frame_size_竖屏=(newW,newH)
                # 调整图片大小
                bg_image = bg_image.resize((newW, newH),Image.Resampling.LANCZOS)
                bg_image = bg_image.crop((0, 0, newW, self.frame_size[1]))
                # 将图片粘贴到背景中央
                x_position = round((self.frame_size[0] - newW) / 2)
                bg.paste(bg_image, (x_position, 0),bg_image)# 注意第三个参数是遮罩
                bg_image = bg
            else:
                bg_image = bg_image.resize(self.frame_size,Image.Resampling.LANCZOS)
        return bg_image
    def z(self, w=None, h=None,point=(),points=[],采样倍数=1):
        '''修正坐标：将坐标从原始尺寸缩放到新尺寸'''
        if self.frame_size_竖屏:
            #下面的应该怎么调整呢
            比例X = self.frame_size_竖屏[0] / self.frame_size[0]  # 宽度缩放
            比例Y = self.frame_size_竖屏[1] / self.frame_size[1]  # 高度缩放
            padding_X=(self.frame_size[0]-self.frame_size_竖屏[0])/2
            padding_Y=(self.frame_size[1]-self.frame_size_竖屏[1])/2
            标准X = self.frame_size[0] / self.frame_size_default[0]  # 宽度缩放
            标准Y = self.frame_size[1] / self.frame_size_default[1]  # 高度缩放
            change_w = lambda w: (padding_X + (w * 比例X * 标准X)) * 采样倍数
            change_h = lambda h: (padding_Y + (h * 比例Y * 标准Y))  * 采样倍数
        elif self.frame_size != self.frame_size_default:
            #生成尺寸不是默认尺寸修正点位
            标准X = self.frame_size[0] / self.frame_size_default[0]  # 宽度缩放
            标准Y = self.frame_size[1] / self.frame_size_default[1]  # 高度缩放
            change_w = lambda w : w * 标准X * 采样倍数
            change_h = lambda h : h * 标准Y * 采样倍数
        else:
            change_w = lambda w : w * 采样倍数
            change_h = lambda h : h * 采样倍数

        if w is not None:return change_w(w)
        elif h is not None:return change_h(h)
        elif point:return ( change_w(point[0]),change_h(point[1]) )
        elif points:return [ ( change_w(point[0]),change_h(point[1]) ) for point in points ]
    def f(self,font_size):
        '''修正字体大小'''
        if self.frame_size_竖屏:
            bl1=self.frame_size_竖屏[1]/self.frame_size[1]
            bl2=self.frame_size[1]/self.frame_size_default[1]
            return font_size * bl1 * bl2
        if self.frame_size != self.frame_size_default:
            # 获取字体高度
            return font_size * (self.frame_size[1] / self.frame_size_default[1])
        return font_size
    def 加载背景(self):
        """加载并调整背景图片尺寸"""
        bg = self.背景图片
        bg = self.检查是否转竖屏(bg_image=bg)
        # 保存原始背景图片用于后续的粘贴操作
        self.img_导出图片 = bg.copy()
        self.draw = ImageDraw.Draw(self.img_导出图片)
        if self.采样倍数 > 1:
            self.img_绘画图层 = Image.new('RGBA', (self.img_导出图片.size[0] * self.采样倍数, self.img_导出图片.size[1] * self.采样倍数), (0, 0, 0, 0))
            self.draw_points = ImageDraw.Draw(self.img_绘画图层)
    def 加载头像(self):
        """加载头像图片并粘贴到右上角"""
        if self.显示头像 and not self.头像图片 is None:
            pic = self.头像图片
            pic_w, pic_h = pic.size
            scale_factor = pic_w / pic_h
            new_w = self.头像尺寸
            new_h = round(new_w / scale_factor)
            pic_resized = pic.resize((new_w, new_h), Image.Resampling.LANCZOS)          # 缩放头像
            avatar_x = self.视频宽 - new_w - self.头像尺寸_padding
            avatar_y = self.头像尺寸_padding
            pic_pos = (avatar_x, avatar_y)
            self.img_导出图片.paste(pic_resized, pic_pos, pic_resized)
    def 文本(self,text, x,y, 颜色="black", 字体路径=None, 字体大小=20,透明度=1):
        if not 字体路径:
            字体路径=self.字体路径
        字体大小 = self.f(font_size=字体大小)
        if 字体路径 and os.path.exists(字体路径):
            font_name=(字体路径,字体大小)
            if font_name in fonts_dict.keys():
                font=fonts_dict[font_name]
            else:
                font = ImageFont.truetype(字体路径, 字体大小)
                fonts_dict[font_name]=font
        else:
            font = ImageFont.load_default(字体大小)
        self.draw.text(self.z(point=[x,y]), text, fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), font=font)
    def 画圆(self, 中心点:tuple, 半径:float, 颜色="black", 线条宽度=1,透明度=1):
        左上角 = (中心点[0] - 半径, 中心点[1] - 半径)
        右下角 = (中心点[0] + 半径, 中心点[1] + 半径)
        self.draw.ellipse(self.z(points=[左上角, 右下角]), outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画直线(self,起点,终点, 颜色="black", 线条宽度=1,透明度=1):
        if self.采样倍数 > 1:
            self.draw_points.line(self.z(points=[起点, 终点], 采样倍数=self.采样倍数), fill=self.颜色转RGBA(颜色值=颜色, 透明度=透明度), width=线条宽度 * self.采样倍数, joint='curve')  # miter curve bevel
        else:
            self.draw.line(self.z(points=[起点, 终点], 采样倍数=self.采样倍数), fill=self.颜色转RGBA(颜色值=颜色, 透明度=透明度), width=线条宽度 * self.采样倍数, joint='curve')  # miter curve bevel
    def 画曲线(self,points,颜色='black',线条宽度=1,透明度=1):
        ''' points=[(100,100),(200,200)]  [00:00:32]'''
        if self.采样倍数 > 1:
            self.draw_points.line(self.z(points=points, 采样倍数=self.采样倍数), fill=self.颜色转RGBA(颜色值=颜色, 透明度=透明度), width=线条宽度 * self.采样倍数, joint='curve')  # miter curve bevel
        else:
            self.draw.line(self.z(points=points,采样倍数=self.采样倍数), fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度*self.采样倍数,joint='curve')#miter curve bevel
    def 画点列表(self, points: list, 颜色="black", 透明度=1):
        for point in points:
            # #画加号
            # 半径 = 线条宽度 // 2
            # self.draw.ellipse([point[0] - 半径, point[1] - 半径, point[0] + 半径, point[1] + 半径], fill=颜色, outline=颜色)
            self.draw_points.point(self.z(point=point), fill=self.颜色转RGBA(颜色值=颜色, 透明度=透明度))
    def 画方块(self,起点,终点, 颜色="black",线条宽度=1,透明度=1):
        x1, y1 = 起点
        x2, y2 = 终点
        # 确保左小于右，上小于下
        x1, x2 = min(x1, x2), max(x1, x2)
        y1, y2 = min(y1, y2), max(y1, y2)
        # 绘制矩形轮廓
        self.draw.rectangle([self.z(w=x1), self.z(h=y1), self.z(w=x2), self.z(h=y2)], outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 导出图片(self,保存路径=None):
        """返回最终处理好的 PIL Image 对象"""
        if self.采样倍数 > 1:
            self.img_绘画图层 = self.img_绘画图层.filter(ImageFilter.GaussianBlur(radius=self.高斯模糊半径))  # radius 高斯模糊半径
            self.img_绘画图层 = self.img_绘画图层.resize(self.frame_size,resample=Image.Resampling.LANCZOS)
            #self.img_绘画图层 = self.img_绘画图层.filter(ImageFilter.SMOOTH_MORE)  # 平滑
            #self.img_绘画图层 = self.img_绘画图层.filter(ImageFilter.EDGE_ENHANCE_MORE)  # 增强边缘对比度
            self.img_导出图片 = Image.alpha_composite(self.img_导出图片, self.img_绘画图层)#合并背景 和绘画图层
        if 保存路径:
            path_dir, fname = os.path.split(保存路径)
            os.makedirs(path_dir,exist_ok=1)
            self.img_导出图片.save(保存路径)
        else:
            if self.istest:
                save_dir=os.path.abspath('frame_images')
                os.makedirs(save_dir, exist_ok=1)
                save_name=os.path.join(save_dir,self.frame_fname)
                self.img_导出图片.save(save_name) #RGBA 图片
            return np.array(self.img_导出图片)[:, :, [2, 1, 0]]  #RGBA->BGR
            #[00:07:47]
class VIDEO:
    def __init__(self,视频高,视频宽,视频路径,保存路径,音频路径=None,帧率=1,显示头像:bool=False,头像尺寸:int=200,线程数:int=10,采样倍数=1,font:str=None,start_frame:int=0,istest:bool=False):
        self.istest=istest
        self.font=self.加载字体(font)
        self.分组长度=60
        self.背景图片_文件夹='ppt'
        self.显示头像=显示头像
        self.头像尺寸=头像尺寸
        self.线程数=线程数
        self.采样倍数=采样倍数
        self.帧率=帧率
        self.视频路径=os.path.abspath(视频路径)
        self.音频路径=os.path.abspath(音频路径) if 音频路径 else None
        self.保存路径 = os.path.abspath(保存路径)
        self.生成视频路径=os.path.abspath('create.mp4')
        self.视频高=视频高
        self.视频宽=视频宽
        self.frame_size=(self.视频宽,self.视频高)
        self.frame_size_default=(self.视频宽,self.视频高)
        self.背景图片_image_白色背景 = np.ones((self.frame_size[1], self.frame_size[0], 3), dtype=np.uint8) * 255
        #self.背景图片_image_黑色背景 = np.zeros((self.frame_size[1], self.frame_size[0], 3), dtype=np.uint8)
        self.共享画面_frame_num_value={}
        self.背景图片_frame_num_data={}
        self.背景图片_docId_data={}
        self.背景图片_docId_原图片_size_newWidth={}
        self.背景图片_docId_image_objects={}
        self.画图数据_docId_列表=defaultdict(list)
        self.start_frame=start_frame
    def 加载字体(self,font):
        if font:
            if os.path.exists(font):
                return font
        #加载目录字体
        if os.path.exists('font.ttf'):
            return 'font.ttf'
        else:
            default_dir = os.path.join(os.path.expanduser('~'), 'FFMPEG')
            os.makedirs(default_dir, exist_ok=1)
            font_path = os.path.join(default_dir, "font.ttf")
            if os.path.exists(font_path):
                return font_path
            else:
                sx.下载文件_进度条(文件路径=font_path, 网址=FONT_HREF)
                if os.path.exists(font_path):
                    return font_path
    def 计算帧(self,时间毫秒):
        if 时间毫秒<0:
            return 0
        return int((时间毫秒/1000)*self.帧率)
    @sx.zsq_try
    def 添加_背景图片(self,docId_index,时间毫秒,图片链接,数据,白板=False):
        pic_obj={}
        frame_num=self.计算帧(时间毫秒)
        pic_obj['docId_index'] = docId_index
        pic_obj['frame_num']=frame_num
        pic_obj['show_time']=计算时间(时间毫秒)
        pic_obj['path'] = f'{self.背景图片_文件夹}/{docId_index}.jpg'
        pic_obj['data'] = 数据
        pic_obj['url'] = 图片链接
        pic_obj['wb'] = 白板
        self.背景图片_frame_num_data[frame_num]=pic_obj
        self.背景图片_docId_data[docId_index]=pic_obj
    def 下载_背景图片(self):
        os.makedirs('ppt',exist_ok=1)
        tasks=[]
        for k,p in self.背景图片_frame_num_data.items():
            path=os.path.abspath(p['path'])
            req=(path,p['url'])
            if req not in tasks:
                tasks.append(req)
        print(f'\r正在下载PPT图片(共{len(tasks)}张)',end='', flush=True)
        sx.多线程运行(lambda x:sx.下载文件(文件路径=x[0],网址=x[1]),参数列表=tasks,回调函数=None,线程数=10,异步=True)
        for k, p in self.背景图片_frame_num_data.items():
            path = os.path.abspath(p['path'])
            if os.path.exists(path):
                pil_img = Image.open(path).convert("RGBA")
                self.背景图片_docId_原图片_size_newWidth[p['docId_index']] = [pil_img.size, int(
                    self.视频高 * (pil_img.size[0] / pil_img.size[1]))]
                if pil_img.size != self.frame_size:
                    pil_img = pil_img.resize(self.frame_size)
                # pil_img = pil_img.resize((600,800)) #竖屏测试
                self.背景图片_docId_image_objects[p['docId_index']] = pil_img
        print(f'\r完成下载PPT图片(共{len(tasks)}张)', flush=True)
    def 添加_共享画面(self,时间毫秒,共享画面值:bool):
        self.共享画面_frame_num_value[self.计算帧(时间毫秒)]=共享画面值
    def 添加_画图帧(self,docId_index,时间毫秒,数据,类型,id=None):
        draw_obj={}
        draw_obj['id']=id
        draw_obj['type']=类型
        draw_obj['frame_num']=self.计算帧(时间毫秒)
        draw_obj['show_time']=计算时间(时间毫秒)
        draw_obj['docId_index']=docId_index
        draw_obj['data']=数据
        self.画图数据_docId_列表[docId_index].append(draw_obj)
    @sx.zsq_try
    def worker(self,args):
        frame_num, docId, 视频帧, 共享画面 = args
        bg_frame = self.背景图片_docId_image_objects[docId]
        if 共享画面:
            bg_frame, 视频帧 = 视频帧, bg_frame
        new_frame = FRAME(frame_num=frame_num, 视频宽=self.视频宽, 视频高=self.视频高, 显示头像=self.显示头像, 头像尺寸=self.头像尺寸, 头像图片=视频帧,背景图片=bg_frame,字体路径=self.font,采样倍数=self.采样倍数,istest=self.istest)
        new_frame.高斯模糊半径=0.5
        new_frame.frame_size_default=self.frame_size_default
        ''' 画图处理逻辑 '''
        # -----------------------------------------------------------
        if not 共享画面:
            draws=self.画图数据_docId_列表[docId]
            shapeIds=[]
            for draw in draws[::-1]:
                if draw['frame_num']<=frame_num:
                    tp=draw['type']
                    data=draw['data']
                    if tp=='text':
                        shapes=sx.json_path(data,'$..shapes')
                        if shapes:
                            for shape in shapes:
                                text = shape['text']
                                shapeId = shape['shapeId']
                                if shapeId not in shapeIds:
                                    fontSize = shape['fontSize']
                                    textColor =shape['textColor']
                                    x = shape['x']
                                    y = shape['y']
                                    new_frame.文本(text=text,字体大小=fontSize,颜色=textColor,x=x,y=y)
                                    shapeIds.append(shapeId)
                        else:
                            text = data['data']['text']
                            shapeId = data['data']['shapeId']
                            if shapeId not in shapeIds:
                                fontSize=data['data']['fontSize']
                                textColor=data['data']['textColor']
                                x=data['data']['x']
                                y=data['data']['y']
                                new_frame.文本(text=text, 字体大小=fontSize,颜色=textColor, x=x, y=y)
                                shapeIds.append(shapeId)
                    elif tp=='rectangle':
                        shapeId = sx.json_path(draw, '$..data..shapeId')
                        if shapeId not in shapeIds:
                            thickness = sx.json_path(draw, '$..data..thickness')
                            color = sx.json_path(draw, '$..data..color')
                            startX = sx.json_path(draw, '$..data..startX')
                            startY = sx.json_path(draw, '$..data..startY')
                            width = sx.json_path(draw, '$..data..width')
                            height = sx.json_path(draw, '$..data..height')
                            endX = startX + width
                            endY = startY + height
                            new_frame.画方块(起点=(startX , startY),终点=(endX, endY),颜色=color,线条宽度=thickness)
                            shapeIds.append(shapeId)
                    elif tp=='line':
                        thickness = sx.json_path(draw, '$..data..thickness')
                        color = sx.json_path(draw, '$..data..color')
                        startX = sx.json_path(draw, '$..data..startX')
                        startY = sx.json_path(draw, '$..data..startY')
                        endX = sx.json_path(draw, '$..data..endX')
                        endY = sx.json_path(draw, '$..data..endY')
                        # 绘制直线
                        new_frame.画直线(起点=(startX, startY),终点=(endX, endY),颜色=color,线条宽度=thickness)
                    else:
                        shapeId = sx.json_path(draw, '$..data..shapeId')
                        if shapeId not in shapeIds:
                            points=sx.json_path(draw, '$..data..points')
                            thickness=sx.json_path(draw, '$..data..thickness')
                            color=sx.json_path(draw, '$..data..color')
                            if points:
                               new_frame.画曲线(points=[(x['x'],x['y']) for x in points],颜色=color,线条宽度=thickness)
                            shapeIds.append(shapeId)
        return frame_num, new_frame.导出图片()
    def 生成视频(self):
        try:
            self.视频对象 = cv2.VideoCapture(self.视频路径)
            self.视频_总帧数 = self.视频对象.get(cv2.CAP_PROP_FRAME_COUNT)
            self.视频_帧数 = int(self.视频对象.get(cv2.CAP_PROP_FPS))
            self.视频_时长 = self.视频_总帧数 / self.视频_帧数

            fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # 注意：macOS上可能需要使用'mp4v'而不是'XVID'
            video = cv2.VideoWriter(self.生成视频路径, fourcc, self.帧率, self.frame_size)
            self.frame_interval = self.视频_帧数 / self.帧率
            self.总帧数 = int(self.视频_时长 * self.帧率)
            if self.帧率>=self.视频_帧数:
                self.帧率=self.视频_帧数
            if self.istest:
                测试分钟数=10
                self.总帧数 = self.start_frame + ( 测试分钟数 * 60)
            frame_zu_step = self.线程数  # 线程数
            frame_zu = sx.列表分组(range(self.总帧数), step=self.分组长度)
            frame_zu_count = len(frame_zu)
            start_time = time.time()

            print(f'字体:{self.font}')
            print(f'线程:{self.线程数} 抗锯齿:{self.采样倍数 if self.采样倍数 > 1 else "关"} 头像:{self.头像尺寸 if self.显示头像 else "关"} '
                f'帧率:{self.视频_帧数}>{self.帧率} 时长:{计算时间(self.视频_时长*1000)} 分辨率:{self.frame_size}')
            def callback(rt):
                frame_num, frame = rt
                video.write(frame)
            共享画面=False
            for i, zu in enumerate(frame_zu):
                args_list = []
                for frame_num in zu:
                    if frame_num in self.背景图片_frame_num_data.keys():
                        docId_index = self.背景图片_frame_num_data[frame_num]['docId_index']
                    if frame_num in self.共享画面_frame_num_value.keys():
                        共享画面=self.共享画面_frame_num_value[frame_num]
                    if self.istest:
                        if frame_num < self.start_frame:
                            continue
                    #加载视频帧
                    self.视频对象.set(cv2.CAP_PROP_POS_FRAMES, int(frame_num * self.frame_interval)-1)
                    ret, bgr_frame = self.视频对象.read()
                    视频帧 = Image.fromarray(bgr_frame[:,:,::-1]).convert("RGBA")
                    args_list.append((frame_num,docId_index,视频帧,共享画面))
                sx.多线程运行(运行函数=self.worker, 回调函数=callback, 参数列表=args_list, 线程数=frame_zu_step, 异步=False)
                sx.打印_进度条(字符串=f'page:{docId_index}', 当前ID=i, 总数=frame_zu_count, 步长=1)
            end_time = time.time()
            sx.pcolor(f'\n耗时[{sx.时间秒转日期格式(round(end_time - start_time))}]','warn')
        except Exception as e:
            sx.打印错误(e)
        video.release()
        self.视频对象.release()
    def 合并音频(self):
        cmd = [
            ff.ffmpeg_path,
            "-i", self.生成视频路径,  # 视频文件
            "-i", self.音频路径 if self.音频路径 else self.视频路径,  # 音频文件
            "-c:v", "copy",  # 直接复制视频流
            "-c:a", "copy",  # 重新编码音频为AAC格式
            "-map", "0:v:0",  # 使用第一个文件的视频
            "-map", "1:a:0",  # 使用第二个文件的音频
            "-shortest",  # 以最短的流结束
            "-y",  # 覆盖输出
            "-loglevel", "error",  # 只输出错误信息
            self.保存路径  # 输出文件
        ]
        ff.执行(cmd, show=True)
        if os.path.exists(self.生成视频路径):
            os.remove(self.生成视频路径)
        if os.path.exists(self.保存路径):
            sx.pcolor(f'保存路径:{self.保存路径}\n')
    def run(self):
        self.下载_背景图片()
        self.生成视频()
        self.合并音频()
if __name__ == '__main__':
    '''
    class MyVideo(ppt.VIDEO):
        @sx.zsq_try
        def worker(self, args):
            [frame_num, docId, 视频帧] = args
    
    
    # cr=FRAME(frame_num=100, 视频宽=800,视频高=600,背景图片='1.png',头像图片='2.png',显示头像=True,头像尺寸=100,istest=True)
    # cr.文本(text= '你好hello！!abc əʊ',x=200,y=300,颜色='#000000',字体路径='font.ttf',字体大小=24)
    # cr.画直线(起点=(100,100),终点=(300,300),颜色='#300000',线条宽度=3)
    # cr.画点列表(points=[(100,100),(200,200)])
    # cr.画方块(起点=(100,100),终点=(200,200))
    # points = [(50, 350), (150, 50), (250, 350), (350, 50)]
    # cr.画曲线(points, 颜色="blue", 线条宽度=3)
    # cr.画圆(中心点=(200, 200), 半径=100, 颜色="red", 线条宽度=3)
    # image=cr.导出图片('a.png')
    # print(image)
    
    a=PPT()
    a.添加_背景图片('...')
    a.添加_画图帧()
    a.run()
    '''
