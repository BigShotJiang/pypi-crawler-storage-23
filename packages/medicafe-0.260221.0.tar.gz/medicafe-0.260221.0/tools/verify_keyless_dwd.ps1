# Verify (and optionally deploy) MediLink Gmail Orchestrator keyless DWD in production.
# Safe defaults:
# - Does not change Cloud Run AUTH_MODE unless you pass -SetAuthMode.
# - Can skip build/deploy with -SkipDeploy.
#
# Example (recommended):
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\\tools\\verify_keyless_dwd.ps1"
#
# Example (non-interactive):
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\\tools\\verify_keyless_dwd.ps1" -NoInteractive -AssumeWorkspaceAllowlisted -SkipDeploy

param(
    [string]$ProjectId = "genial-analyzer-476721-f8",
    [string]$Region = "us-central1",
    [string]$ServiceName = "medilink-gmail-orchestrator",
    [string]$ArtifactRepo = "medilink-repo",
    [string]$ImageName = "medilink-gmail-orchestrator",
    [string]$ServiceAccountEmail = "",
    [string]$SchedulerJob = "gmail-watch-refresh",
    [switch]$SkipDeploy,
    [switch]$RequireDeploy,
    [switch]$DockerFallback,
    [switch]$FixAuthMode,
    [switch]$ExerciseAdminEndpoint,
    [switch]$AssumeWorkspaceAllowlisted,
    [ValidateSet("dwd_preferred", "dwd_required", "user_oauth_only")]
    [string]$SetAuthMode = "",
    [switch]$NoInteractive
)

function Find-Gcloud {
    $gcloudPath = "$env:USERPROFILE\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd"
    if (Test-Path $gcloudPath) { return $gcloudPath }
    throw "gcloud.cmd not found at expected path: $gcloudPath"
}

function Fail([string]$Message) {
    Write-Host "ERROR: $Message" -ForegroundColor Red
    throw $Message
}

function Confirm([string]$Prompt, [bool]$DefaultNo = $true) {
    if ($NoInteractive) { return -not $DefaultNo }
    $suffix = if ($DefaultNo) { " (y/N): " } else { " (Y/n): " }
    $ans = Read-Host ($Prompt + $suffix)
    if ([string]::IsNullOrWhiteSpace($ans)) { return -not $DefaultNo }
    $t = $ans.Trim().ToLowerInvariant()
    return ($t -eq "y" -or $t -eq "yes" -or $t.StartsWith("y"))
}

function Run([string[]]$GcloudArgs, [switch]$IgnoreFailure) {
    if (-not $GcloudArgs -or $GcloudArgs.Count -eq 0) {
        Fail "Internal error: attempted to invoke gcloud with empty argument list."
    }
    $cmd = $GcloudArgs -join " "
    Write-Host ">> $cmd" -ForegroundColor DarkGray
    $output = & $gcloudExe @GcloudArgs 2>&1
    if ($LASTEXITCODE -ne 0 -and -not $IgnoreFailure) {
        Write-Host $output -ForegroundColor Yellow
        Fail "Command failed: $cmd"
    }
    return $output
}

$script:LAST_GCLOUD_CMD = ""
function Run-Soft([string[]]$GcloudArgs) {
    # Same as Run, but never throws; returns output (may be empty) and preserves $LASTEXITCODE.
    if (-not $GcloudArgs -or $GcloudArgs.Count -eq 0) {
        Write-Host "WARN: Internal error: attempted to invoke gcloud with empty argument list." -ForegroundColor Yellow
        return ""
    }
    $cmd = $GcloudArgs -join " "
    $script:LAST_GCLOUD_CMD = $cmd
    Write-Host ">> $cmd" -ForegroundColor DarkGray
    $output = & $gcloudExe @GcloudArgs 2>&1
    return $output
}

function Extract-JwtFromOutput($Output) {
    # gcloud stderr redirected into stdout yields ErrorRecord objects; coerce to string safely.
    $text = ($Output | Out-String).Trim()
    if (-not $text) { return "" }

    # Prefer the last JWT-looking line.
    $lines = $text -split "`r?`n"
    for ($idx = $lines.Length - 1; $idx -ge 0; $idx--) {
        $line = $lines[$idx].Trim()
        if ($line -match '^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$') {
            return $line
        }
    }
    return ""
}

$dockerExe = $null
function Find-Docker {
    try {
        $cmd = Get-Command docker -ErrorAction Stop
        return $cmd.Path
    } catch {
        return $null
    }
}

function Run-Docker([string[]]$DockerArgs, [switch]$IgnoreFailure) {
    if (-not $dockerExe) { Fail "Docker not found in PATH." }
    if (-not $DockerArgs -or $DockerArgs.Count -eq 0) { Fail "Internal error: attempted to invoke docker with empty arg list." }
    $cmd = $DockerArgs -join " "
    Write-Host ">> docker $cmd" -ForegroundColor DarkGray
    $output = & $dockerExe @DockerArgs 2>&1
    if ($LASTEXITCODE -ne 0 -and -not $IgnoreFailure) {
        Write-Host $output -ForegroundColor Yellow
        Fail "Docker command failed: docker $cmd"
    }
    return $output
}

$gcloudExe = Find-Gcloud
$dockerExe = Find-Docker

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "VERIFY KEYLESS DWD (MEDILINK GMAIL)" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Project: $ProjectId" -ForegroundColor White
Write-Host "Region: $Region" -ForegroundColor White
Write-Host "Service: $ServiceName" -ForegroundColor White
Write-Host "Artifact Repo: $ArtifactRepo" -ForegroundColor Gray
Write-Host "Image: $ImageName" -ForegroundColor Gray
Write-Host "Scheduler Job: $SchedulerJob" -ForegroundColor Gray
Write-Host "SkipDeploy: $SkipDeploy" -ForegroundColor Gray
Write-Host "RequireDeploy: $RequireDeploy" -ForegroundColor Gray
Write-Host "DockerFallback: $DockerFallback" -ForegroundColor Gray
Write-Host "FixAuthMode: $FixAuthMode" -ForegroundColor Gray
Write-Host "ExerciseAdminEndpoint: $ExerciseAdminEndpoint" -ForegroundColor Gray
Write-Host "SetAuthMode: $SetAuthMode" -ForegroundColor Gray
Write-Host "NoInteractive: $NoInteractive" -ForegroundColor Gray
Write-Host "DockerDetected: $([bool]$dockerExe)" -ForegroundColor Gray
Write-Host ""

if (-not $ServiceAccountEmail) {
    $ServiceAccountEmail = "$ServiceName@$ProjectId.iam.gserviceaccount.com"
}

# Basic gcloud sanity
$authUser = & $gcloudExe config get-value account 2>$null
if (-not $authUser) { Fail "gcloud is not authenticated. Run: gcloud auth login" }
Write-Host "OK: gcloud authenticated as: $authUser" -ForegroundColor Green

Run @("config", "set", "project", $ProjectId) | Out-Null
Write-Host "OK: gcloud project set: $ProjectId" -ForegroundColor Green

# 0) Snapshot current Cloud Run service state (helps explain why keyless logs may not appear)
Write-Host ""
Write-Host "== Step 0: Snapshot current Cloud Run service state ==" -ForegroundColor Cyan
$svcJson = Run @(
    "run", "services", "describe", $ServiceName,
    "--project", $ProjectId,
    "--region", $Region,
    "--format", "json"
) -IgnoreFailure
$serviceUrl = ""
$adminSecret = ""
$adminSecretRef = $null
$currentAuthMode = ""
$keyBasedDwdConfigured = $false
if ($svcJson) {
    try {
        $svc = ($svcJson | Out-String | ConvertFrom-Json)
        $rev = $svc.status.latestReadyRevisionName
        $img = $svc.spec.template.spec.containers[0].image
        $saName = $svc.spec.template.spec.serviceAccountName
        $serviceUrl = [string]$svc.status.url
        $env = @{}
        foreach ($e in ($svc.spec.template.spec.containers[0].env | ForEach-Object { $_ })) {
            if (-not $e.name) { continue }

            # Cloud Run env vars can be literal ("value") or Secret Manager references ("valueSource"/"valueFrom").
            # Do NOT print secret values. For references, store a marker plus the referenced secret name/version.
            $name = [string]$e.name
            $val = $null
            if ($null -ne $e.value -and -not [string]::IsNullOrEmpty([string]$e.value)) {
                $val = [string]$e.value
                $env[$name] = $val
                continue
            }

            $secretName = $null
            $secretVersion = $null

            # Try a few shapes; Cloud Run API surfaces slightly different fields across tools/versions.
            if ($e.valueSource -and $e.valueSource.secretKeyRef) {
                $secretName = [string]$e.valueSource.secretKeyRef.secret
                $secretVersion = [string]$e.valueSource.secretKeyRef.version
            } elseif ($e.valueFrom -and $e.valueFrom.secretKeyRef) {
                $secretName = [string]$e.valueFrom.secretKeyRef.name
                $secretVersion = [string]$e.valueFrom.secretKeyRef.version
            } elseif ($e.valueFrom -and $e.valueFrom.secretKeyRef -and $e.valueFrom.secretKeyRef.secret) {
                $secretName = [string]$e.valueFrom.secretKeyRef.secret
                $secretVersion = [string]$e.valueFrom.secretKeyRef.version
            }

            if ($secretName) {
                if (-not $secretVersion) { $secretVersion = "latest" }
                $env[$name] = ("<secret:{0}:{1}>" -f $secretName, $secretVersion)
                if ($name -eq "ADMIN_SHARED_SECRET") {
                    $adminSecretRef = @{ secret = $secretName; version = $secretVersion }
                }
            } else {
                $env[$name] = ""
            }
        }
        $currentAuthMode = [string]$env["AUTH_MODE"]
        $adminSecret = [string]$env["ADMIN_SHARED_SECRET"]
        $mb = [string]$env["MAILBOX_USER"]
        $keyBasedDwdConfigured = [bool]($env.ContainsKey("SERVICE_ACCOUNT_JSON") -or $env.ContainsKey("GOOGLE_APPLICATION_CREDENTIALS"))
        Write-Host ("Cloud Run latestReadyRevisionName: {0}" -f $rev) -ForegroundColor White
        Write-Host ("Cloud Run image: {0}" -f $img) -ForegroundColor White
        Write-Host ("Cloud Run service account: {0}" -f $saName) -ForegroundColor White
        Write-Host ("Cloud Run URL: {0}" -f $serviceUrl) -ForegroundColor White
        Write-Host ("Cloud Run AUTH_MODE: {0}" -f $currentAuthMode) -ForegroundColor Gray
        Write-Host ("Cloud Run MAILBOX_USER: {0}" -f ($mb | ForEach-Object { $_ })) -ForegroundColor Gray
        Write-Host ("Key-based DWD env configured: {0}" -f $keyBasedDwdConfigured) -ForegroundColor Gray
        $adminSecretSet = $false
        if ($adminSecret -and -not $adminSecret.StartsWith("<secret:")) { $adminSecretSet = $true }
        if ($adminSecret -and $adminSecret.StartsWith("<secret:")) { $adminSecretSet = $true }
        Write-Host ("ADMIN_SHARED_SECRET set: {0}" -f $adminSecretSet) -ForegroundColor Gray
        if ($adminSecretRef) {
            Write-Host ("ADMIN_SHARED_SECRET source: Secret Manager ({0}, version {1})" -f $adminSecretRef.secret, $adminSecretRef.version) -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "WARN: Could not parse Cloud Run describe JSON." -ForegroundColor Yellow
    }
} else {
    Write-Host "WARN: Could not describe Cloud Run service (service may not exist yet)." -ForegroundColor Yellow
}

# 0b) Optionally fix missing AUTH_MODE by running validator once (non validate-only)
if ($FixAuthMode -or ($currentAuthMode -eq "" -and -not $NoInteractive)) {
    if (-not $FixAuthMode) {
        # Default "Yes" here: if AUTH_MODE is unset, verification will almost always fail to find
        # keyless DWD logs because the intended code path is ambiguous.
        if (-not (Confirm "Cloud Run AUTH_MODE is empty. Set AUTH_MODE=dwd_preferred now via validator?" $false)) {
            Write-Host "Skipping AUTH_MODE fix." -ForegroundColor Yellow
        } else {
            $FixAuthMode = $true
        }
    }
    if ($FixAuthMode) {
        Write-Host ""
        Write-Host "== Step 0b: Fix AUTH_MODE via validator (sets AUTH_MODE=dwd_preferred) ==" -ForegroundColor Cyan
        $validatorFix = Join-Path $PSScriptRoot "..\\cloud\\orchestrator\\validate_and_complete_setup.py"
        & py -3.11 -X utf8 $validatorFix --no-interactive --project-id $ProjectId --region $Region --service-name $ServiceName --set-auth-mode dwd_preferred | Out-Host
    }
}

# 1) Enable IAM Credentials API
Write-Host ""
Write-Host "== Step 1: Enable IAM Credentials API ==" -ForegroundColor Cyan
Run @("services", "enable", "iamcredentials.googleapis.com", "--project", $ProjectId) | Out-Null
Write-Host "OK: iamcredentials.googleapis.com enabled" -ForegroundColor Green

# 2) Token Creator on self (signJwt)
Write-Host ""
Write-Host "== Step 2: Grant Token Creator on self ==" -ForegroundColor Cyan
Run @(
    "iam", "service-accounts", "add-iam-policy-binding", $ServiceAccountEmail,
    "--project", $ProjectId,
    "--member", "serviceAccount:$ServiceAccountEmail",
    "--role", "roles/iam.serviceAccountTokenCreator"
) | Out-Null
Write-Host "OK: Token Creator binding applied" -ForegroundColor Green

# 3) Get SA OAuth2 client ID (Workspace allowlist)
Write-Host ""
Write-Host "== Step 3: Get service account OAuth2 client ID (for Workspace DWD allowlist) ==" -ForegroundColor Cyan
$clientId = Run @(
    "iam", "service-accounts", "describe", $ServiceAccountEmail,
    "--project", $ProjectId,
    "--format", "value(oauth2ClientId)"
)
$clientId = ($clientId | Select-Object -Last 1).Trim()
if (-not $clientId) { Fail "Could not read oauth2ClientId for $ServiceAccountEmail" }
Write-Host "Service Account OAuth2 Client ID: $clientId" -ForegroundColor White

if (-not $AssumeWorkspaceAllowlisted) {
    Write-Host ""
    Write-Host "Workspace action required (cannot be automated here):" -ForegroundColor Yellow
    Write-Host "- Admin Console -> Security -> API controls -> Domain-wide delegation" -ForegroundColor Yellow
    Write-Host "- Add the client ID above with Gmail scopes (at minimum):" -ForegroundColor Yellow
    Write-Host "  https://www.googleapis.com/auth/gmail.modify" -ForegroundColor Yellow
    Write-Host "  https://www.googleapis.com/auth/gmail.readonly" -ForegroundColor Yellow
    if (-not (Confirm "Have you completed the Workspace DWD allowlist for this client ID?" $true)) {
        Fail "Stop: complete Workspace DWD allowlist first, then re-run with -AssumeWorkspaceAllowlisted if desired."
    }
}

# 4) Optional deploy (ensures new container deps are live)
if (-not $SkipDeploy) {
    Write-Host ""
    Write-Host "== Step 4: Build and deploy (Cloud Build -> Artifact Registry -> Cloud Run) ==" -ForegroundColor Cyan

    Write-Host ">> Clearing potentially stale gcloud build overrides (best effort)" -ForegroundColor DarkGray
    Run-Soft @("config", "unset", "builds/worker_pool") | Out-Null
    Run-Soft @("config", "unset", "builds/service_account") | Out-Null
    Run-Soft @("config", "unset", "api_endpoint_overrides/cloudbuild") | Out-Null

    # Ensure Artifact Registry repo exists
    $repoDescribe = & $gcloudExe artifacts repositories describe $ArtifactRepo --location $Region --project $ProjectId 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Artifact Registry repo '$ArtifactRepo' not found; creating..." -ForegroundColor Yellow
        Run @(
            "artifacts", "repositories", "create", $ArtifactRepo,
            "--repository-format=docker",
            "--location", $Region,
            "--project", $ProjectId
        ) | Out-Null
    }

    $deploySucceeded = $false
    Push-Location (Join-Path $PSScriptRoot "..\\cloud\\orchestrator")
    try {
        $tag = "$Region-docker.pkg.dev/$ProjectId/$ArtifactRepo/$ImageName"
        try {
            Run @(
                "builds", "submit",
                "--tag", $tag,
                "--project", $ProjectId,
                "--region", $Region,
                "--default-buckets-behavior=regional-user-owned-bucket",
                "."
            ) | Out-Null

            Run @(
                "run", "deploy", $ServiceName,
                "--project", $ProjectId,
                "--region", $Region,
                "--image", $tag,
                "--service-account", $ServiceAccountEmail,
                "--no-allow-unauthenticated"
            ) | Out-Null
            $deploySucceeded = $true
        } catch {
            Write-Host "WARN: Build/deploy failed. Continuing with verification steps." -ForegroundColor Yellow
            Write-Host "      If this is Cloud Build NOT_FOUND, known workarounds are:" -ForegroundColor Yellow
            Write-Host "      - Re-run this script with -SkipDeploy to proceed without deploying" -ForegroundColor Yellow
            Write-Host "      - Use the validator's Cloud Build remediation (py -3.11 cloud/orchestrator/validate_and_complete_setup.py)" -ForegroundColor Yellow
            Write-Host "      - Use local Docker build/push as a fallback (if Docker is installed)" -ForegroundColor Yellow
            if ($DockerFallback -and $dockerExe) {
                if (Confirm "Cloud Build failed. Attempt Docker build/push/deploy fallback now?" $false) {
                    Write-Host "Attempting Docker fallback deploy..." -ForegroundColor Cyan
                    # Configure Docker auth for Artifact Registry
                    Run @("auth", "configure-docker", "$Region-docker.pkg.dev", "--quiet") | Out-Null
                    Run-Docker @("build", "-t", $tag, ".") | Out-Null
                    Run-Docker @("push", $tag) | Out-Null
                    Run @(
                        "run", "deploy", $ServiceName,
                        "--project", $ProjectId,
                        "--region", $Region,
                        "--image", $tag,
                        "--service-account", $ServiceAccountEmail,
                        "--no-allow-unauthenticated"
                    ) | Out-Null
                    $deploySucceeded = $true
                } else {
                    Write-Host "Docker fallback skipped." -ForegroundColor Yellow
                }
            }
            if ($RequireDeploy) {
                throw
            }
        }
    } finally {
        Pop-Location
    }
    if ($deploySucceeded) {
        Write-Host "OK: Build/deploy complete" -ForegroundColor Green
    } else {
        Write-Host "WARN: Build/deploy did not complete successfully (continuing anyway)." -ForegroundColor Yellow
    }
} else {
    Write-Host ""
    Write-Host "== Step 4: Build/deploy skipped ==" -ForegroundColor Cyan
}

# 5) Optional: set AUTH_MODE explicitly (safe: uses validator semantics)
if ($SetAuthMode) {
    Write-Host ""
    Write-Host "== Step 5: Set AUTH_MODE on Cloud Run via validator ==" -ForegroundColor Cyan
    $validator = Join-Path $PSScriptRoot "..\\cloud\\orchestrator\\validate_and_complete_setup.py"
    if (-not (Test-Path $validator)) { Fail "Validator script not found at: $validator" }
    if (-not $NoInteractive) {
        if (-not (Confirm "Set AUTH_MODE='$SetAuthMode' on Cloud Run now?" $true)) {
            Write-Host "Skipping AUTH_MODE update." -ForegroundColor Yellow
        } else {
            & py -3.11 $validator --no-interactive --project-id $ProjectId --region $Region --service-name $ServiceName --set-auth-mode $SetAuthMode | Out-Host
        }
    } else {
        & py -3.11 $validator --no-interactive --project-id $ProjectId --region $Region --service-name $ServiceName --set-auth-mode $SetAuthMode | Out-Host
    }
}

# 6) Trigger scheduler job to force a Gmail-using action
Write-Host ""
Write-Host "== Step 6: Trigger scheduler job to exercise Gmail auth ==" -ForegroundColor Cyan
$runOut = Run @(
    "scheduler", "jobs", "run", $SchedulerJob,
    "--project", $ProjectId,
    "--location", $Region
) -IgnoreFailure | Out-Null
Write-Host "OK: Scheduler run requested (check job/logs if it fails)" -ForegroundColor Green

Write-Host ""
Write-Host "== Step 6b: Check recent scheduler job logs (best effort) ==" -ForegroundColor Cyan
$filter = 'resource.type="cloud_scheduler_job" AND resource.labels.job_id="' + $SchedulerJob + '"'
Run @(
    "logging", "read", $filter,
    "--project", $ProjectId,
    "--freshness", "30m",
    "--limit", "10",
    "--format", "table(timestamp,severity,resource.labels.job_id,jsonPayload.status,jsonPayload.httpRequest.status,textPayload)"
) -IgnoreFailure | Out-Host

Write-Host ""
Write-Host "== Step 6b2: Scheduler job logs (JSON, best effort) ==" -ForegroundColor Cyan
Run @(
    "logging", "read", $filter,
    "--project", $ProjectId,
    "--freshness", "30m",
    "--limit", "5",
    "--format", "json"
) -IgnoreFailure | Out-Host

Write-Host ""
Write-Host "== Step 6c: Describe scheduler job target (best effort) ==" -ForegroundColor Cyan
$jobJson = Run-Soft @(
    "scheduler", "jobs", "describe", $SchedulerJob,
    "--project", $ProjectId,
    "--location", $Region,
    "--format", "json"
)
if ($LASTEXITCODE -ne 0 -or -not $jobJson) {
    Write-Host "WARN: Could not describe scheduler job (insufficient permissions or missing job)." -ForegroundColor Yellow
    $job = $null
} else {
    try {
        $job = ($jobJson | Out-String | ConvertFrom-Json)
    } catch {
        Write-Host "WARN: Could not parse scheduler job JSON." -ForegroundColor Yellow
        $job = $null
    }
}
if ($job) {
    $targetUri = [string]$job.httpTarget.uri
    $oidcSa = [string]$job.httpTarget.oidcToken.serviceAccountEmail
    $aud = [string]$job.httpTarget.oidcToken.audience
    Write-Host ("Scheduler target URI: {0}" -f $targetUri) -ForegroundColor Gray
    Write-Host ("Scheduler OIDC SA: {0}" -f $oidcSa) -ForegroundColor Gray
    Write-Host ("Scheduler OIDC audience: {0}" -f $aud) -ForegroundColor Gray
    if ($serviceUrl -and $targetUri -and -not ($targetUri.StartsWith($serviceUrl))) {
        Write-Host ("WARN: Scheduler target does not start with Cloud Run URL. Expected prefix: {0}" -f $serviceUrl) -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "== Step 6c2: Check scheduler invoker IAM on Cloud Run (best effort) ==" -ForegroundColor Cyan
if ($job -and $job.httpTarget -and $job.httpTarget.oidcToken -and $job.httpTarget.oidcToken.serviceAccountEmail) {
    $schedulerInvoker = [string]$job.httpTarget.oidcToken.serviceAccountEmail
    $policyJson = Run-Soft @(
        "run", "services", "get-iam-policy", $ServiceName,
        "--project", $ProjectId,
        "--region", $Region,
        "--format", "json"
    )
    if ($LASTEXITCODE -eq 0 -and $policyJson) {
        $hasInvoker = $false
        try {
            $policy = ($policyJson | Out-String | ConvertFrom-Json)
            foreach ($b in ($policy.bindings | ForEach-Object { $_ })) {
                if ($b.role -eq "roles/run.invoker") {
                    foreach ($m in ($b.members | ForEach-Object { $_ })) {
                        if ($m -eq ("serviceAccount:" + $schedulerInvoker)) { $hasInvoker = $true }
                    }
                }
            }
        } catch {
            Write-Host "WARN: Could not parse Cloud Run IAM policy." -ForegroundColor Yellow
        }
        if ($hasInvoker) {
            Write-Host ("OK: Scheduler OIDC SA already has roles/run.invoker: {0}" -f $schedulerInvoker) -ForegroundColor Green
        } else {
            Write-Host ("WARN: Scheduler OIDC SA does NOT have roles/run.invoker: {0}" -f $schedulerInvoker) -ForegroundColor Yellow
            if (Confirm "Grant roles/run.invoker on this Cloud Run service to the scheduler OIDC service account now?" $true) {
                Run @(
                    "run", "services", "add-iam-policy-binding", $ServiceName,
                    "--project", $ProjectId,
                    "--region", $Region,
                    "--member", ("serviceAccount:" + $schedulerInvoker),
                    "--role", "roles/run.invoker"
                ) | Out-Null
                Write-Host "OK: roles/run.invoker granted to scheduler OIDC service account." -ForegroundColor Green
            } else {
                Write-Host "Skipping invoker grant." -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host "WARN: Could not fetch Cloud Run IAM policy (best effort only)." -ForegroundColor Yellow
    }
} else {
    Write-Host "WARN: Scheduler job does not appear to use OIDC with a service account (cannot validate invoker IAM)." -ForegroundColor Yellow
}

# 6d) Optional: call the admin endpoint directly to force a Gmail API call (bypasses scheduler issues)
if ($ExerciseAdminEndpoint -or (-not $NoInteractive -and $serviceUrl -and ($adminSecret -or $adminSecretRef) -and (Confirm "Call /admin/resume-history directly now to force a Gmail API call?" $true))) {
    if (-not $serviceUrl) {
        Write-Host "WARN: Cannot exercise admin endpoint: Cloud Run URL not available." -ForegroundColor Yellow
    } elseif (-not $adminSecret) {
        if ($adminSecretRef) {
            if (Confirm ("ADMIN_SHARED_SECRET is a Secret Manager reference ({0}). Fetch it now to call the admin endpoint?" -f $adminSecretRef.secret) $true) {
                $adminSecret = Run-Soft @(
                    "secrets", "versions", "access", $adminSecretRef.version,
                    "--secret", $adminSecretRef.secret,
                    "--project", $ProjectId
                )
                if ($LASTEXITCODE -ne 0 -or -not $adminSecret) {
                    Write-Host "WARN: Failed to fetch ADMIN_SHARED_SECRET from Secret Manager; skipping admin endpoint call." -ForegroundColor Yellow
                    $adminSecret = ""
                } else {
                    $adminSecret = ($adminSecret | Select-Object -Last 1).Trim()
                    Write-Host "OK: Retrieved ADMIN_SHARED_SECRET from Secret Manager (value not printed)." -ForegroundColor Green
                }
            } else {
                Write-Host "Skipping admin endpoint call (secret not fetched)." -ForegroundColor Yellow
            }
        } else {
            Write-Host "WARN: Cannot exercise admin endpoint: ADMIN_SHARED_SECRET is not set on Cloud Run." -ForegroundColor Yellow
        }
    } else {
        Write-Host ""
        Write-Host "== Step 6d: Directly call /admin/resume-history (forces Gmail auth) ==" -ForegroundColor Cyan
        # Cloud Run requires an identity token whose audience matches the service URL.
        $rawTokenOut = Run-Soft @("auth", "print-identity-token", "--project", $ProjectId, "--audiences", $serviceUrl)
        if ($LASTEXITCODE -ne 0) {
            Write-Host "WARN: Failed to obtain identity token. gcloud output:" -ForegroundColor Yellow
            Write-Host ($rawTokenOut | Out-String) -ForegroundColor Yellow
        }
        $idToken = Extract-JwtFromOutput $rawTokenOut
        if (-not $idToken) {
            Write-Host "WARN: Could not obtain identity token; skipping direct call." -ForegroundColor Yellow
        } else {
            $uri = ($serviceUrl.TrimEnd("/") + "/admin/resume-history")
            try {
                $headers = @{ Authorization = "Bearer $idToken"; "Content-Type" = "application/json" }
                $body = @{ secret = $adminSecret } | ConvertTo-Json -Compress
                Write-Host ("POST {0} (body secret omitted from logs)" -f $uri) -ForegroundColor DarkGray
                $resp = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body $body -TimeoutSec 60
                Write-Host "OK: Admin endpoint call completed." -ForegroundColor Green
            } catch {
                $msg = $_.Exception.Message
                $code = $null
                try {
                    if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
                        $code = [int]$_.Exception.Response.StatusCode.value__
                    }
                } catch { }
                if ($code) {
                    Write-Host ("WARN: Admin endpoint call failed (HTTP {0}): {1}" -f $code, $msg) -ForegroundColor Yellow
                } else {
                    Write-Host ("WARN: Admin endpoint call failed: {0}" -f $msg) -ForegroundColor Yellow
                }

                # Common cause: caller lacks Cloud Run invoker. Offer a guided fix then retry once.
                if (-not $NoInteractive -and ($code -eq 401 -or $code -eq 403) -and $authUser) {
                    if (Confirm ("Grant roles/run.invoker on this Cloud Run service to the current user ({0}) and retry once?" -f $authUser) $true) {
                        Run @(
                            "run", "services", "add-iam-policy-binding", $ServiceName,
                            "--project", $ProjectId,
                            "--region", $Region,
                            "--member", ("user:" + $authUser.Trim()),
                            "--role", "roles/run.invoker"
                        ) | Out-Null
                        Write-Host "OK: roles/run.invoker granted to current user. Retrying admin call..." -ForegroundColor Green
                        try {
                            $rawTokenOut2 = Run-Soft @("auth", "print-identity-token", "--project", $ProjectId, "--audiences", $serviceUrl)
                            $idToken2 = Extract-JwtFromOutput $rawTokenOut2
                            if ($idToken2) {
                                $headers2 = @{ Authorization = "Bearer $idToken2"; "Content-Type" = "application/json" }
                                $body2 = @{ secret = $adminSecret } | ConvertTo-Json -Compress
                                $resp2 = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers2 -Body $body2 -TimeoutSec 60
                                Write-Host "OK: Admin endpoint call completed after granting invoker." -ForegroundColor Green
                            } else {
                                Write-Host "WARN: Could not obtain identity token after granting invoker; not retrying." -ForegroundColor Yellow
                            }
                        } catch {
                            Write-Host ("WARN: Retry after granting invoker still failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
                        }
                    }
                }
            }
        }
    }
}

# 7) Check Cloud Run logs for keyless DWD line
Write-Host ""
Write-Host "== Step 7: Check Cloud Run logs for keyless DWD ==" -ForegroundColor Cyan
$logs = $null
$foundKeyless = $false
$foundAnyMode = $false

for ($attempt = 1; $attempt -le 3; $attempt++) {
    $logs = Run @(
        "run", "services", "logs", "read", $ServiceName,
        "--project", $ProjectId,
        "--region", $Region,
        "--limit", "300"
    ) -IgnoreFailure

    if ($logs) {
        $modeLines = $logs | Select-String -SimpleMatch "Gmail auth mode:" | Select-Object -First 10
        if ($modeLines) {
            $foundAnyMode = $true
            Write-Host "Observed auth mode lines (latest):" -ForegroundColor Gray
            $modeLines | ForEach-Object { Write-Host ("  " + $_.Line) -ForegroundColor Gray }
        }
        if ($logs | Select-String -SimpleMatch "Gmail auth mode: dwd (keyless)" -Quiet) {
            $foundKeyless = $true
            break
        }
    }
    if ($attempt -lt 3) {
        Start-Sleep -Seconds 10
    }
}

if ($foundKeyless) {
    Write-Host "OK: Verified: log contains 'Gmail auth mode: dwd (keyless)'" -ForegroundColor Green
} elseif ($foundAnyMode) {
    Write-Host "WARN: Did not find 'Gmail auth mode: dwd (keyless)' yet. A different auth mode is active (see lines above)." -ForegroundColor Yellow
} else {
    Write-Host "WARN: No 'Gmail auth mode:' lines found in recent logs." -ForegroundColor Yellow
}

if (-not $foundKeyless) {
    Write-Host "Next checks:" -ForegroundColor Yellow
    Write-Host "  - Ensure Workspace DWD allowlist is set for client ID: $clientId" -ForegroundColor Yellow
    Write-Host "  - Ensure Token Creator on self is applied and iamcredentials API is enabled" -ForegroundColor Yellow
    Write-Host "  - If you did not deploy new code, re-run with -SkipDeploy (verification only) or fix Cloud Build/Docker deploy and retry" -ForegroundColor Yellow
    Write-Host "  - Re-run scheduler job and then re-check logs" -ForegroundColor Yellow
}

# 8) Run validator validate-only as final gate
Write-Host ""
Write-Host "== Step 8: Run validator (validate-only) ==" -ForegroundColor Cyan
$validator2 = Join-Path $PSScriptRoot "..\\cloud\\orchestrator\\validate_and_complete_setup.py"
& py -3.11 -X utf8 $validator2 --no-interactive --project-id $ProjectId --region $Region --service-name $ServiceName --validate-only | Out-Host

Write-Host ""
Write-Host "Done." -ForegroundColor Green
