#!/usr/bin/env python
"""
Verification script to confirm updater fixes are present in the running environment.

This script checks:
1. Updater version is 2.0.3
2. Minimal import flags are set before MediCafe imports
3. Launcher has flags set before imports
4. Which updater path is being used
"""

import os
import sys
import re

def check_updater_version():
    """Check if updater script shows version 2.0.3"""
    updater_path = os.path.join('MediBot', 'update_medicafe.py')
    if not os.path.exists(updater_path):
        print("[ERROR] Updater script not found at: {}".format(updater_path))
        return False
    
    with open(updater_path, 'r') as f:
        content = f.read()
    
    # Check version in comment
    version_match = re.search(r'Script Version:\s*(\d+\.\d+\.\d+)', content)
    if version_match:
        version = version_match.group(1)
        if version == '2.0.3':
            print("[OK] Updater version is 2.0.3 (comment)")
        else:
            print("[WARN] Updater version is {} (expected 2.0.3)".format(version))
    
    # Check SCRIPT_VERSION constant
    version_match = re.search(r'SCRIPT_VERSION\s*=\s*["\'](\d+\.\d+\.\d+)["\']', content)
    if version_match:
        version = version_match.group(1)
        if version == '2.0.3':
            print("[OK] Updater version is 2.0.3 (constant)")
        else:
            print("[WARN] Updater version is {} (expected 2.0.3)".format(version))
    
    return True

def check_updater_flags():
    """Check if minimal import flags are set before MediCafe imports in updater"""
    updater_path = os.path.join('MediBot', 'update_medicafe.py')
    if not os.path.exists(updater_path):
        return False
    
    with open(updater_path, 'r') as f:
        lines = f.readlines()
    
    # Find where flags are set
    flag_set_line = None
    medicafe_import_line = None
    
    for i, line in enumerate(lines, 1):
        if 'MEDICAFE_MINIMAL_IMPORT' in line and 'setdefault' in line:
            flag_set_line = i
        if 'from MediCafe' in line or 'import MediCafe' in line:
            if medicafe_import_line is None:
                medicafe_import_line = i
    
    if flag_set_line is None:
        print("[ERROR] MEDICAFE_MINIMAL_IMPORT flag not found in updater")
        return False
    
    if medicafe_import_line is None:
        print("[WARN] No MediCafe imports found in updater (may be OK)")
        return True
    
    if flag_set_line < medicafe_import_line:
        print("[OK] Minimal import flags are set before MediCafe imports in updater (line {} < {})".format(
            flag_set_line, medicafe_import_line))
        return True
    else:
        print("[ERROR] Minimal import flags are set AFTER MediCafe imports (line {} >= {})".format(
            flag_set_line, medicafe_import_line))
        return False

def check_launcher_flags():
    """Check if minimal import flags are set before MediCafe imports in launcher"""
    launcher_path = os.path.join('MediCafe', 'launcher.py')
    if not os.path.exists(launcher_path):
        print("[ERROR] Launcher script not found at: {}".format(launcher_path))
        return False
    
    with open(launcher_path, 'r') as f:
        lines = f.readlines()
    
    # Find where flags are set
    flag_set_line = None
    medicafe_import_line = None
    
    for i, line in enumerate(lines, 1):
        if 'MEDICAFE_MINIMAL_IMPORT' in line and 'setdefault' in line:
            flag_set_line = i
        if 'from MediCafe' in line or 'import MediCafe' in line:
            if medicafe_import_line is None:
                medicafe_import_line = i
    
    if flag_set_line is None:
        print("[ERROR] MEDICAFE_MINIMAL_IMPORT flag not found in launcher")
        return False
    
    if medicafe_import_line is None:
        print("[WARN] No MediCafe imports found in launcher (unexpected)")
        return False
    
    if flag_set_line < medicafe_import_line:
        print("[OK] Minimal import flags are set before MediCafe imports in launcher (line {} < {})".format(
            flag_set_line, medicafe_import_line))
        return True
    else:
        print("[ERROR] Minimal import flags are set AFTER MediCafe imports (line {} >= {})".format(
            flag_set_line, medicafe_import_line))
        return False

def check_updater_paths():
    """Check which updater paths exist and their versions"""
    paths_to_check = [
        ('Local', os.path.join('MediBot', 'update_medicafe.py')),
        ('Legacy', r'F:\Medibot\update_medicafe.py'),
    ]
    
    results = []
    for name, path in paths_to_check:
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    content = f.read()
                version_match = re.search(r'SCRIPT_VERSION\s*=\s*["\'](\d+\.\d+\.\d+)["\']', content)
                if version_match:
                    version = version_match.group(1)
                    mtime = os.path.getmtime(path)
                    results.append((name, path, version, mtime))
                    print("[INFO] {} updater exists: {} (version {}, modified {})".format(
                        name, path, version, mtime))
                else:
                    print("[WARN] {} updater exists but version not found: {}".format(name, path))
            except Exception as e:
                print("[ERROR] Failed to read {} updater: {}".format(name, e))
        else:
            print("[INFO] {} updater does not exist: {}".format(name, path))
    
    return results

def main():
    print("=" * 60)
    print("MediCafe Updater Fixes Verification")
    print("=" * 60)
    print()
    
    results = {
        'updater_version': check_updater_version(),
        'updater_flags': check_updater_flags(),
        'launcher_flags': check_launcher_flags(),
    }
    
    print()
    print("Updater Paths:")
    print("-" * 60)
    check_updater_paths()
    
    print()
    print("=" * 60)
    print("Summary")
    print("=" * 60)
    
    all_ok = all(results.values())
    for check, result in results.items():
        status = "[OK]" if result else "[FAIL]"
        print("{} {}: {}".format(status, check, "PASS" if result else "FAIL"))
    
    if all_ok:
        print()
        print("[SUCCESS] All checks passed!")
        return 0
    else:
        print()
        print("[FAILURE] Some checks failed. Please review the output above.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
