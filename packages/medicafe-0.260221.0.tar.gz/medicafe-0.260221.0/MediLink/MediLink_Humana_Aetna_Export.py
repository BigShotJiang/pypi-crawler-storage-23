# MediLink_Humana_Aetna_Export.py
# Humana/Aetna Patient List Export Utility
# Exports Humana and Aetna patients from CSV, grouped by month, to printable TXT format
#
# XP / Python 3.4.4 compatible
# ASCII-only UI
#
# Configuration (uses existing keys from config.json):
# {
#   "CSV_FILE_PATH": "path/to/csv/file.csv",
#   "MediLink_Config": {
#     "local_claims_path": "path/to/save/txt/files"
#   }
# }
#
# Usage: Access via MediLink main menu -> Tools -> Export Humana/Aetna list

from __future__ import print_function

import glob
import os
import sys
from datetime import datetime
from collections import defaultdict, OrderedDict

# Ensure MediCafe module path is available
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    from MediCafe.core_utils import get_shared_config_loader, extract_medilink_config
    MediLink_ConfigLoader = get_shared_config_loader()
except Exception:
    MediLink_ConfigLoader = None
    extract_medilink_config = None

try:
    from MediBot import MediBot_Preprocessor_lib
except Exception:
    MediBot_Preprocessor_lib = None

try:
    from MediBot.MediBot_docx_index import get_diagnosis_code_allowed_set
except Exception:
    get_diagnosis_code_allowed_set = None


# Insurance names to include (same set as excluded in MediBot_Preprocessor_lib.filter_rows)
# This must match the exclusion list in MediBot/MediBot_Preprocessor_lib.py
HUMANA_AETNA_INSURANCE_NAMES = {'AETNA', 'AETNA MEDICARE', 'HUMANA MED HMO', 'HUMANA'}


def _log(message, level="INFO"):
    """Simple logging wrapper."""
    if MediLink_ConfigLoader:
        try:
            MediLink_ConfigLoader.log(message, level=level)
        except Exception:
            pass


def _get_payto_provider_name(config):
    """Best-effort fetch of payto_provider_name from config/MediLink_Config."""
    try:
        if not isinstance(config, dict):
            return ''
        medi = config.get('MediLink_Config')
        if isinstance(medi, dict):
            name = medi.get('payto_provider_name') or ''
        else:
            name = config.get('payto_provider_name') or ''
        name = str(name).strip()
        return name
    except Exception:
        return ''


def _parse_date_string(date_str):
    """Parse date string in various formats and return datetime object. Accepts datetime objects."""
    if date_str is None:
        return None
    if isinstance(date_str, datetime):
        return date_str
    if not isinstance(date_str, str):
        return None
    
    date_str = date_str.strip()
    if not date_str or date_str == 'MISSING':
        return None
    
    # Try common date formats
    formats = ['%m-%d-%Y', '%m/%d/%Y', '%Y-%m-%d', '%m-%d-%y', '%m/%d/%y', '%Y/%m/%d']
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    
    return None


def load_all_csvs_from_directory(csv_path):
    """
    Load all CSV files from the directory containing the specified CSV path.
    
    Args:
        csv_path: Path to primary CSV file (used to determine directory)
    
    Returns:
        tuple: (combined_csv_data: list, csv_files_loaded: list of paths)
    """
    if not MediBot_Preprocessor_lib:
        _log("MediBot_Preprocessor_lib not available for loading CSVs", level="ERROR")
        return [], []
    
    # Get directory containing the CSV
    csv_dir = os.path.dirname(os.path.abspath(csv_path))
    _log("Discovering CSV files in directory: {}".format(csv_dir), level="INFO")
    
    # Find all .csv files in the directory
    csv_pattern = os.path.join(csv_dir, '*.csv')
    csv_files = glob.glob(csv_pattern)
    
    if not csv_files:
        _log("No CSV files found in directory: {}".format(csv_dir), level="WARNING")
        return [], []
    
    # Sort for consistent ordering
    csv_files = sorted(csv_files)
    _log("Found {} CSV file(s) in directory".format(len(csv_files)), level="INFO")
    
    combined_data = []
    loaded_files = []
    
    for csv_file in csv_files:
        try:
            _log("Loading CSV: {}".format(os.path.basename(csv_file)), level="INFO")
            data = MediBot_Preprocessor_lib.load_csv_data(csv_file)
            combined_data.extend(data)
            loaded_files.append(csv_file)
            _log("Loaded {} rows from {}".format(len(data), os.path.basename(csv_file)), level="INFO")
        except Exception as e:
            _log("Error loading CSV {}: {}".format(os.path.basename(csv_file), e), level="WARNING")
            print("Warning: Could not load {}: {}".format(os.path.basename(csv_file), e))
    
    _log("Combined total: {} rows from {} file(s)".format(len(combined_data), len(loaded_files)), level="INFO")
    return combined_data, loaded_files


def filter_humana_aetna_patients(csv_data):
    """
    Filter CSV data to include only Humana and Aetna patients.
    
    Args:
        csv_data: List of CSV row dictionaries
    
    Returns:
        List of filtered rows (Humana/Aetna only)
    """
    filtered = []
    for row in csv_data:
        primary_insurance = (str(row.get('Primary Insurance') or '')).strip().upper()
        if primary_insurance in HUMANA_AETNA_INSURANCE_NAMES:
            filtered.append(row)
    
    _log("Filtered to {} Humana/Aetna patients from {} total rows".format(
        len(filtered), len(csv_data)), level="INFO")
    
    return filtered


def group_by_month(csv_data):
    """
    Group patient data by month (year-month) based on Surgery Date.
    
    Args:
        csv_data: List of CSV row dictionaries
    
    Returns:
        dict: {(year, month): [rows]}, sorted by year-month
    """
    by_month = defaultdict(list)
    skipped_count = 0
    
    for row in csv_data:
        # Try multiple column names for surgery date
        surgery_date = (row.get('Surgery Date') or
                       row.get('Service Date') or
                       row.get('Date of Service') or
                       row.get('DOS'))
        if surgery_date is None or surgery_date == '':
            skipped_count += 1
            continue
        # Normalize: load_csv_data returns strings; if ever datetime (e.g. from other pipeline), _parse_date_string accepts it
        if isinstance(surgery_date, datetime) and surgery_date != datetime.min:
            date_obj = surgery_date
        else:
            date_obj = _parse_date_string(surgery_date)
        if not date_obj:
            skipped_count += 1
            continue
        
        # Group by (year, month)
        key = (date_obj.year, date_obj.month)
        by_month[key].append({
            'row': row,
            'date_obj': date_obj
        })
    
    if skipped_count > 0:
        _log("Skipped {} rows with missing or invalid surgery dates".format(skipped_count), level="WARNING")
    
    # Sort by year-month
    sorted_months = sorted(by_month.keys())
    # Python 3.4 dicts are unordered; preserve chronological order explicitly.
    result = OrderedDict((month, by_month[month]) for month in sorted_months)
    
    _log("Grouped patients into {} months".format(len(result)), level="INFO")
    
    return result


def discover_available_months(grouped_data):
    """
    Discover available months from grouped data.
    
    Args:
        grouped_data: dict from group_by_month()
    
    Returns:
        dict: {(year, month): unique_patient_count}
    """
    month_counts = {}
    for (year, month), records in grouped_data.items():
        # Count unique patients in this month
        patients_in_month = defaultdict(list)
        for record in records:
            row = record['row']
            patient_id = str(row.get('Patient ID 2') or row.get('Patient ID #2') or
                            row.get('Patient ID') or 'N/A')
            patients_in_month[patient_id].append(record)
        month_counts[(year, month)] = len(patients_in_month)
    
    return month_counts


def format_month_selection_menu(available_months):
    """
    Format the month selection menu display.
    
    Args:
        available_months: dict {(year, month): patient_count}
    
    Returns:
        str: Formatted menu string
    """
    if not available_months:
        return "No months found with data."
    
    sorted_months = sorted(available_months.keys())
    total_patients = sum(available_months.values())
    
    lines = []
    lines.append("\nAvailable Months:")
    for year, month in sorted_months:
        count = available_months[(year, month)]
        month_name = datetime(year, month, 1).strftime('%B %Y')
        lines.append("  {}: {:,} patients".format(month_name, count))
    lines.append("  Total: {:,} patients".format(total_patients))
    lines.append("")
    lines.append("Export Options:")
    lines.append("1. Export all months ({:,} total patients)".format(total_patients))
    lines.append("2. Export specific month(s)")
    lines.append("3. Cancel")
    
    return "\n".join(lines)


def get_month_selection(available_months):
    """
    Get month selection from user.
    
    Args:
        available_months: dict {(year, month): patient_count}
    
    Returns:
        list: Selected months (list of (year, month) tuples), or None for all months, or [] for cancel
    """
    if not available_months:
        return []
    
    sorted_months = sorted(available_months.keys())
    
    while True:
        choice = input("Enter your choice: ").strip()
        
        if choice == '1':
            return None  # All months
        elif choice == '3':
            return []  # Cancel
        elif choice == '2':
            # Show numbered list of months
            print("\nSelect months to export (comma-separated, e.g., 1,3):")
            for idx, (year, month) in enumerate(sorted_months, 1):
                count = available_months[(year, month)]
                month_name = datetime(year, month, 1).strftime('%B %Y')
                print("{}. {} ({:,} patients)".format(idx, month_name, count))
            
            selection_input = input("\n> ").strip()
            if not selection_input:
                return []
            
            # Parse comma-separated selections
            selected_indices = []
            for part in selection_input.split(','):
                part = part.strip()
                if part.isdigit():
                    idx = int(part) - 1  # Convert to 0-based
                    if 0 <= idx < len(sorted_months):
                        selected_indices.append(idx)
            
            if not selected_indices:
                print("No valid selections. Cancelling.")
                return []
            
            # Convert indices to (year, month) tuples
            selected_months = [sorted_months[idx] for idx in selected_indices]
            return selected_months
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")


def build_export_content(grouped_data, config=None):
    """
    Build the printable text content with patients grouped by month.
    One row per patient per month; multiple service dates shown as Service Date 1 and Service Date 2.
    
    Args:
        grouped_data: dict from group_by_month()
        config: Optional config dict (used to show payto_provider_name in header)
    
    Returns:
        str: Formatted text content
    """
    # Table formatting: keep widths stable and ensure headers do not overflow their columns.
    # NOTE: On Python 3.4, dict iteration order is not guaranteed, so we always sort month keys when rendering.
    row_fmt = "{:<4} | {:<18} | {:<6} | {:<25} | {:<14} | {:<14} | {:<8}"
    header_row = row_fmt.format(
        "No.", "Insurance", "Pat ID", "Patient Name", "Service Date 1", "Service Date 2", "Amount"
    )
    table_width = len(header_row)

    lines = []
    
    # Header
    lines.append("Humana HMO/Aetna Patient List")
    lines.append("=" * table_width)
    payto_provider_name = _get_payto_provider_name(config)
    if payto_provider_name:
        # Per user preference: show just the provider name (no label).
        lines.append("{}".format(payto_provider_name))
    lines.append("Generated: {}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    lines.append("")
    
    if not grouped_data:
        lines.append("No Humana/Aetna patients found in CSV data.")
        return "\n".join(lines)
    
    # Count unique patients across all months
    unique_patients_by_month = {}
    for (year, month), records in grouped_data.items():
        # Group by patient ID within this month
        patients_in_month = defaultdict(list)
        for record in records:
            row = record['row']
            patient_id = str(row.get('Patient ID 2') or row.get('Patient ID #2') or
                            row.get('Patient ID') or 'N/A')
            patients_in_month[patient_id].append(record)
        unique_patients_by_month[(year, month)] = len(patients_in_month)
    
    total_patients = sum(unique_patients_by_month.values())
    lines.append("Total Patients: {}".format(total_patients))
    lines.append("")
    
    # Group by month (chronological)
    for (year, month) in sorted(grouped_data.keys()):
        records = grouped_data[(year, month)]
        # Month header
        month_name = datetime(year, month, 1).strftime('%B %Y')
        lines.append("")
        lines.append("-" * table_width)
        lines.append("{} ({} patients)".format(month_name, unique_patients_by_month[(year, month)]))
        lines.append("-" * table_width)
        
        # Table header (No., Insurance, Pat ID, Name, Service Date 1, Service Date 2, Amount)
        lines.append(header_row)
        lines.append("-" * table_width)
        
        # Group records by patient ID
        patients_in_month = defaultdict(list)
        for record in records:
            row = record['row']
            patient_id = str(row.get('Patient ID 2') or row.get('Patient ID #2') or
                            row.get('Patient ID') or 'N/A')
            patients_in_month[patient_id].append(record)
        
        # Sort patients by insurance group, then Service Date 1 (earliest at top).
        # User preference: Aetna-related patients first, then Humana-related patients.
        def _insurance_group_rank(patient_id):
            recs = patients_in_month.get(patient_id) or []
            row0 = recs[0].get('row', {}) if recs else {}
            ins = str(row0.get('Primary Insurance') or '').strip().upper()
            if 'AETNA' in ins:
                return 0
            if 'HUMANA' in ins:
                return 1
            return 9

        def _insurance_group_label(rank):
            if rank == 0:
                return "[AETNA PATIENTS]"
            if rank == 1:
                return "[HUMANA PATIENTS]"
            return "[OTHER PATIENTS]"

        def _first_service_date(patient_id):
            recs = patients_in_month[patient_id]
            dates = sorted(set(
                rec['date_obj'].date() if hasattr(rec['date_obj'], 'date') else rec['date_obj']
                for rec in recs if rec.get('date_obj') is not None
            ))
            return dates[0] if dates else None

        def _patient_sort_key(patient_id):
            rank = _insurance_group_rank(patient_id)
            first_date = _first_service_date(patient_id) or datetime.max.date()
            # Tie-breakers for stable output on Python 3.4
            recs = patients_in_month.get(patient_id) or []
            row0 = recs[0].get('row', {}) if recs else {}
            name = str(row0.get('Patient Name') or row0.get('Name') or '').strip().upper()
            return (rank, first_date, name, str(patient_id))

        sorted_patient_ids = sorted(patients_in_month.keys(), key=_patient_sort_key)
        
        # One row per patient (coerce to str before slice - CSV may have numbers/dates)
        # Row number resets to 1 for each month
        row_num = 1
        month_total_amount = 0
        current_group_rank = None
        for patient_id in sorted_patient_ids:
            rank = _insurance_group_rank(patient_id)
            if rank != current_group_rank:
                current_group_rank = rank
                lines.append(row_fmt.format("", "", "", _insurance_group_label(rank), "", "", ""))

            patient_records = patients_in_month[patient_id]
            
            # Take first record's row for patient info (all records for same patient share ID/name/insurance)
            row = patient_records[0]['row']
            
            # Collect unique calendar-day service dates (dedupe by date only: same day in multiple CSVs or different times = one date)
            # Using .date() ensures same calendar day with different times doesn't show twice in Service Date 1/2 or inflate Amount
            service_dates = sorted(set(
                rec['date_obj'].date() if hasattr(rec['date_obj'], 'date') else rec['date_obj']
                for rec in patient_records if rec.get('date_obj') is not None
            ))
            
            # Keys: load_csv_data uses clean_header which strips '#' so "Patient ID #2" -> "Patient ID 2"
            patient_id_display = str(row.get('Patient ID 2') or row.get('Patient ID #2') or
                                    row.get('Patient ID') or 'N/A')[:6]

            _pn = row.get('Patient Name') or row.get('Name')
            if _pn:
                patient_name = str(_pn)[:25]
            else:
                # Raw CSV from load_csv_data() has Patient First/Last; "Patient Name" is added only by MediBot preprocessing
                first = str(row.get('Patient First') or '').strip()
                last = str(row.get('Patient Last') or '').strip()
                patient_name = ('{}, {}'.format(last, first) if (last or first) else 'Unknown').strip() or 'Unknown'
                patient_name = patient_name[:25]

            insurance = str(row.get('Primary Insurance') or '')[:18]
            
            # Service Date 1 (first date) and Service Date 2 (second date or blank)
            service_date_1 = service_dates[0].strftime('%m/%d/%Y') if len(service_dates) >= 1 else ''
            service_date_2 = service_dates[1].strftime('%m/%d/%Y') if len(service_dates) >= 2 else '-'
            
            # Amount: $100 per service date for this patient in this month
            amount_value = len(service_dates) * 100
            month_total_amount += amount_value
            amount = "${}".format(amount_value)

            # Format row (No., Insurance, Pat ID, Patient Name, Service Date 1, Service Date 2, Amount)
            patient_line = row_fmt.format(
                str(row_num), insurance, patient_id_display, patient_name, service_date_1, service_date_2, amount
            )
            lines.append(patient_line)
            row_num += 1

        # Leave a few blank rows for hand-written additions before the total.
        for _ in range(3):
            lines.append(row_fmt.format("", "", "", "", "", "", ""))

        # Month total (sum of Amount column), with comma formatting for thousands.
        total_amount_display = "${:,}".format(month_total_amount)
        lines.append("-" * table_width)
        total_line = row_fmt.format("", "", "", "Total Amount", "", "", total_amount_display)
        lines.append(total_line)
        # Underline to make total stand out in plain ASCII/Notepad.
        lines.append("=" * table_width)
        
        lines.append("")
    
    lines.append("")
    lines.append("=" * table_width)
    lines.append("End of Report")
    
    return "\n".join(lines)


def save_export_to_file(content, config):
    """
    Save the export content to a timestamped text file and open it.
    
    Args:
        content: Text content to save
        config: Configuration dictionary
    
    Returns:
        tuple: (success: bool, file_path: str or None)
    """
    try:
        file_name = "Humana_Aetna_Export_{}.txt".format(
            datetime.now().strftime('%Y%m%d_%H%M%S')
        )
        
        # Get save path from config (same pattern as receipts)
        if isinstance(config, dict):
            cfg_candidate = config.get('MediLink_Config')
            if isinstance(cfg_candidate, dict):
                cfg = cfg_candidate
            else:
                cfg = config
        else:
            cfg = {}
        
        # Try local_claims_path first, fall back to outputFilePath (top-level), then current dir
        output_path = config.get('outputFilePath', '') if isinstance(config, dict) else ''
        save_dir = (cfg.get('local_claims_path') or output_path or '.')
        
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        
        file_path = os.path.join(save_dir, file_name)
        
        # Write file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        _log("Export saved to: {}".format(file_path), level="INFO")
        print("Export saved to: {}".format(file_path))
        
        # Open file automatically for user (Windows-specific)
        if os.name == 'nt':
            try:
                os.startfile(file_path)
                _log("Opened export file in default application", level="INFO")
            except Exception as e:
                _log("Could not auto-open file: {}".format(e), level="WARNING")
                print("Note: Could not automatically open file. Please open manually.")
        
        return True, file_path
    
    except Exception as e:
        _log("Error saving export file: {}".format(e), level="ERROR")
        print("Error saving export file: {}".format(e))
        return False, None


def run_humana_aetna_export(config):
    """
    Main entry point for Humana/Aetna export.
    
    Args:
        config: Configuration dictionary
    
    Returns:
        dict: Summary with success status
    """
    _log("Humana/Aetna export utility started", level="INFO")
    
    print("\n" + "="*60)
    print("Humana/Aetna Patient List Export")
    print("="*60)
    
    # Get CSV path
    csv_path = config.get('CSV_FILE_PATH', '')
    if not csv_path:
        print("Error: CSV_FILE_PATH not configured in config.json")
        _log("CSV_FILE_PATH not configured", level="ERROR")
        return {'success': False, 'error': 'CSV_FILE_PATH not configured'}
    
    if not os.path.exists(csv_path):
        print("Error: CSV file not found: {}".format(csv_path))
        _log("CSV file not found: {}".format(csv_path), level="ERROR")
        return {'success': False, 'error': 'CSV file not found'}
    
    # Check if MediBot_Preprocessor_lib is available
    if not MediBot_Preprocessor_lib:
        print("Error: MediBot preprocessing module not available.")
        _log("MediBot_Preprocessor_lib not available", level="ERROR")
        return {'success': False, 'error': 'MediBot module not available'}
    
    # Load all CSVs from directory
    csv_dir = os.path.dirname(os.path.abspath(csv_path))
    print("\nLoading CSV data from directory: {}".format(csv_dir))
    _log("Loading CSVs from directory: {}".format(csv_dir), level="INFO")
    
    try:
        csv_data, csv_files_loaded = load_all_csvs_from_directory(csv_path)
        if not csv_data:
            print("Error: No CSV data loaded from directory")
            _log("No CSV data loaded", level="ERROR")
            return {'success': False, 'error': 'No CSV data loaded'}
        
        print("Loaded {} total rows from {} CSV file(s)".format(len(csv_data), len(csv_files_loaded)))
        for csv_file in csv_files_loaded:
            print("  - {}".format(os.path.basename(csv_file)))
        _log("Loaded {} CSV rows from {} files".format(len(csv_data), len(csv_files_loaded)), level="INFO")
    except Exception as e:
        print("Error loading CSV files: {}".format(e))
        _log("Error loading CSVs: {}".format(e), level="ERROR")
        return {'success': False, 'error': 'CSV load failed'}
    
    # Filter to Humana/Aetna only
    print("\nFiltering to Humana/Aetna patients only...")
    filtered_data = filter_humana_aetna_patients(csv_data)
    
    if not filtered_data:
        print("No Humana/Aetna patients found in CSV data.")
        print("Export cancelled.")
        _log("No Humana/Aetna patients found", level="WARNING")
        return {'success': False, 'error': 'No Humana/Aetna patients found'}
    
    print("Found {} Humana/Aetna patients".format(len(filtered_data)))

    # Group by month
    print("\nGrouping patients by month...")
    grouped_data = group_by_month(filtered_data)
    
    if not grouped_data:
        print("No valid surgery dates found for Humana/Aetna patients.")
        print("Export cancelled.")
        _log("No valid surgery dates", level="WARNING")
        return {'success': False, 'error': 'No valid surgery dates'}
    
    print("Grouped into {} months".format(len(grouped_data)))
    
    # Filter by diagnostic code using DOCX schedule index
    if extract_medilink_config:
        medi = extract_medilink_config(config)
    else:
        medi = config.get('MediLink_Config', {})
    
    local_storage_path = medi.get('local_storage_path', '')
    
    if local_storage_path and os.path.exists(local_storage_path) and get_diagnosis_code_allowed_set:
        try:
            print("Applying diagnostic code filter...")
            
            # Collect all date values from grouped_data
            date_values = []
            for month_records in grouped_data.values():
                for record in month_records:
                    if record.get('date_obj'):
                        date_values.append(record['date_obj'])
            
            # Get allowed set (patient_id, date_str) tuples with non-empty diagnosis
            allowed_set = get_diagnosis_code_allowed_set(local_storage_path, date_values)
            
            if allowed_set:
                # Filter each month's records by allowed set
                original_total = sum(len(records) for records in grouped_data.values())
                filtered_grouped_data = OrderedDict()

                # Preserve chronological month ordering explicitly (Python 3.4 dicts are unordered).
                for month_key in sorted(grouped_data.keys()):
                    month_records = grouped_data[month_key]
                    filtered_records = []
                    for record in month_records:
                        row = record.get('row', {})
                        patient_id = str(row.get('Patient ID 2') or row.get('Patient ID #2') or
                                        row.get('Patient ID') or 'N/A')
                        date_obj = record.get('date_obj')
                        if date_obj:
                            date_str = date_obj.strftime('%m-%d-%Y')
                            if (patient_id, date_str) in allowed_set:
                                filtered_records.append(record)
                    
                    if filtered_records:
                        filtered_grouped_data[month_key] = filtered_records
                
                grouped_data = filtered_grouped_data
                filtered_total = sum(len(records) for records in grouped_data.values())
                excluded = original_total - filtered_total
                
                print("Diagnostic code filter applied: {} records kept, {} excluded".format(
                    filtered_total, excluded))
                _log("Diagnostic code filter: {} records kept, {} excluded (no diagnosis code)".format(
                    filtered_total, excluded), level="INFO")
            else:
                print("Warning: No diagnosis codes found in index. Including all patients.")
                _log("Diagnostic code filter skipped: empty allowed set from index", level="WARNING")
        except Exception as e:
            print("Warning: Error applying diagnostic code filter: {}".format(e))
            _log("Error applying diagnostic code filter: {}".format(e), level="WARNING")
    else:
        if not local_storage_path:
            _log("Diagnostic code filter skipped: local_storage_path not configured", level="INFO")
        elif not os.path.exists(local_storage_path):
            _log("Diagnostic code filter skipped: local_storage_path does not exist", level="WARNING")
        elif not get_diagnosis_code_allowed_set:
            _log("Diagnostic code filter skipped: DOCX index module not available", level="WARNING")
    
    # Discover available months and show selection menu
    print("\nDiscovering available months...")
    available_months = discover_available_months(grouped_data)
    
    if not available_months:
        print("No months with valid data found.")
        print("Export cancelled.")
        _log("No valid months found", level="WARNING")
        return {'success': False, 'error': 'No valid months'}
    
    # Show month selection menu
    print(format_month_selection_menu(available_months))
    selected_months = get_month_selection(available_months)
    
    if selected_months == []:
        _log("Export cancelled by user during month selection", level="INFO")
        print("Export cancelled by user.")
        return {'success': False, 'error': 'Cancelled by user'}
    
    # Filter grouped_data to selected months
    if selected_months is None:
        # All months selected
        selected_months_list = sorted(grouped_data.keys())
        _log("User selected all months for export", level="INFO")
        print("\nExporting all {} months...".format(len(selected_months_list)))
    else:
        # Specific months selected
        selected_months_list = sorted(selected_months)
        grouped_data = OrderedDict((month, grouped_data[month]) for month in selected_months_list if month in grouped_data)
        _log("User selected {} specific month(s): {}".format(len(selected_months_list), selected_months_list), level="INFO")
        print("\nExporting {} selected month(s)...".format(len(selected_months_list)))
    
    # Build export content
    print("\nBuilding export report...")
    export_content = build_export_content(grouped_data, config=config)
    
    # Save to file
    print("\nSaving export to file...")
    success, file_path = save_export_to_file(export_content, config)
    
    if success:
        print("\n" + "="*60)
        print("Export completed successfully!")
        print("File: {}".format(file_path))
        print("="*60)
        _log("Humana/Aetna export completed successfully", level="INFO")
        return {
            'success': True,
            'file_path': file_path,
            'total_patients': sum(len(records) for records in grouped_data.values()),
            'months': len(grouped_data)
        }
    else:
        print("\nExport completed with errors.")
        _log("Humana/Aetna export failed", level="ERROR")
        return {'success': False, 'error': 'File save failed'}
