import os
import requests
from icecream import ic
from dotenv import load_dotenv

load_dotenv()

# Availity v1 token (healthcare-hipaa-transactions-demo scope; old dev-partner URL and scope=hipaa no longer valid)
url = "https://api.availity.com/v1/token"

data = {
    'grant_type': 'client_credentials',
    'client_id': os.getenv("CLIENT_ID"),
    'client_secret': os.getenv("CLIENT_SECRET"),
    'scope': 'healthcare-hipaa-transactions-demo'
}

headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
}

resp = requests.post(url, headers = headers, data = data)
ic(resp.json())