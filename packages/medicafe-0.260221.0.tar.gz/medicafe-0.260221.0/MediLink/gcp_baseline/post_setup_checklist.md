Post-Setup Checklist
====================

Complete these items after running `setup_gcp.sh`.

1. OAuth Consent Screen
   - In the Google Cloud console, open the new project and configure the OAuth consent screen.
   - Use Internal if the Workspace domain allows it; otherwise begin the External verification process.
   - Add the scopes used by both flows: `gmail.modify`, `gmail.compose`, `gmail.readonly`, `gmail.send`, `script.external_request`, `script.scriptapp`, `script.projects`, `userinfo.email`, `drive`.
   - Set the support email to match the `SUPPORT_EMAIL` value used when running `setup_gcp.sh`.

2. OAuth Brand and Clients
   - Confirm that `setup_gcp.sh` produced `MediLink/json/credentials.json` (desktop client) and `MediLink/gcp_baseline/web_client_secret.json` (web client).
   - Archive both JSON files securely (password manager or secrets store) because Google only reveals the client secret at creation time.
   - Ensure the web client redirect URIs include `https://script.google.com/macros/d/<<SCRIPT_ID>>/usercallback` and `https://127.0.0.1:8000`.

3. Link Apps Script to the Cloud Project (see `apps_script_link_and_redeploy.md`)
   - Open the GAS project backing `webapp.html`/`main.js` and choose **Project Settings -> Google Cloud Platform (GCP) Project**.
   - Select **Change project** and enter the new project number.
   - Redeploy the web application and Execution API deployment under the new project and capture the new URLs/IDs.

4. Execution API Re-auth
   - In the Apps Script editor, run `setDownloadedEmails` once to force the new OAuth client to authorize Drive and Gmail scopes.
   - Confirm that `get_docx_results` executes successfully via the Execution API (check logs for any scope warnings).

5. Local XP Helper Update (see `local_token_refresh.md`)
   - Copy the new `credentials.json` into the XP host under `json\credentials.json` (preserve ASCII encoding).
   - Delete any stale `token.json` so the next run forces the user through the updated OAuth consent flow.

6. Validation
   - Run the non-OTP path via `initializeDocxEmailListFlow()` and verify that DOCX downloads complete and cleanup runs without 401/403 errors.
   - Run the OTP/manual path and confirm the subject list populates and `get_link` opens the protected message.
   - Inspect logs to ensure no HIPAA data leaks and that error handling remains unchanged.

7. Handoff
   - Archive the generated OAuth JSON files in a secure location according to policy.
   - Record the new project id, number, and OAuth client ids in the team password manager for future reference.
