#!/usr/bin/env bash

# MediLink baseline GCP bootstrapper
# ----------------------------------
# This script prepares the Google Cloud project that backs the legacy MediLink
# Gmail Apps Script + local XP helper integration. It authenticates gcloud,
# enables core APIs, creates (or reuses) the OAuth brand, and provisions both
# desktop and web OAuth clients. The desktop client credentials are written to
# MediLink/json/credentials.json for MediLink_Gmail.py.

set -euo pipefail

PYTHON_BIN=${PYTHON_BIN:-python3}
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    PYTHON_BIN=python
fi
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    echo "python3/python is required on PATH." 1>&2
    exit 1
fi

function is_windows() {
    case "${OSTYPE:-}" in
        msys*|cygwin*|win*) return 0 ;;
        *) return 1 ;;
    esac
}

function make_tmp() {
    local t
    t=$("$PYTHON_BIN" - <<'PY'
import tempfile, os
fd, path = tempfile.mkstemp(prefix='medilink_', suffix='.json')
os.close(fd)
print(path)
PY
)
    echo "$t"
}

function gcloud_json() {
    local out
    out=$(make_tmp)
    gcloud "$@" --format=json > "$out"
    echo "$out"
}

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
MEDILINK_ROOT=$(dirname "${SCRIPT_DIR}")
JSON_DIR="${MEDILINK_ROOT}/json"
mkdir -p "${JSON_DIR}"

function require_var() {
    if [ -z "${!1:-}" ]; then
        echo "Environment variable $1 is required." 1>&2
        exit 1
    fi
}

if ! command -v gcloud >/dev/null 2>&1; then
    echo "gcloud CLI is required on PATH." 1>&2
    exit 1
fi

# python availability handled via PYTHON_BIN above

require_var "PROJECT_ID"
require_var "BILLING_ACCOUNT_ID"
require_var "SUPPORT_EMAIL"
require_var "SCRIPT_ID"

PROJECT_NAME="${PROJECT_NAME:-MediLink Baseline Integration}"
GCLOUD_CONFIG="${GCLOUD_CONFIG:-medilink-baseline}"
OAUTH_APP_NAME="${OAUTH_APP_NAME:-MediLink Baseline}"
AUTO_CREATE_OAUTH="${AUTO_CREATE_OAUTH:-0}"

echo "Authenticating gcloud (a browser window will open)..."
gcloud auth login --update-adc

# Align ADC quota project early to avoid warnings
gcloud auth application-default set-quota-project "${PROJECT_ID}" >/dev/null 2>&1 || true

echo "Using project id: ${PROJECT_ID}"
echo "Using billing account: ${BILLING_ACCOUNT_ID}"
echo "Using support email: ${SUPPORT_EMAIL}"
echo "Using Apps Script id: ${SCRIPT_ID}"
echo "Using gcloud config: ${GCLOUD_CONFIG}"
echo "Using OAuth app display name: ${OAUTH_APP_NAME}"
echo "Auto-create OAuth clients: ${AUTO_CREATE_OAUTH} (0 = manual-first)"

if gcloud config configurations list --format="value(name)" | grep -q "^${GCLOUD_CONFIG}$"; then
    echo "Activating existing gcloud config ${GCLOUD_CONFIG}"
    gcloud config configurations activate "${GCLOUD_CONFIG}" >/dev/null
else
    echo "Creating gcloud config ${GCLOUD_CONFIG}"
    gcloud config configurations create "${GCLOUD_CONFIG}" >/dev/null
fi

gcloud config set core/project "${PROJECT_ID}" >/dev/null
# Align ADC quota project to avoid warnings about ADC quota mismatch
gcloud auth application-default set-quota-project "${PROJECT_ID}" >/dev/null 2>&1 || true
# Avoid gcloud --format=value(...) and stdin pipes; use temp file JSON
_AUTH_LIST_JSON=$(gcloud_json auth list)
ACTIVE_ACCOUNT=$("$PYTHON_BIN" - "${_AUTH_LIST_JSON}" <<'PY'
import sys, json
path = sys.argv[1]
try:
    with open(path, 'r') as fh:
        arr = json.load(fh) or []
except Exception:
    arr = []
for e in arr:
    if (e.get('status') or '').upper() == 'ACTIVE':
        print(e.get('account') or '')
        break
PY
)
rm -f "${_AUTH_LIST_JSON}"
if [ -z "${ACTIVE_ACCOUNT}" ]; then
    echo "Authentication did not yield an active account. Please re-run the script." 1>&2
    exit 1
fi
gcloud config set core/account "${ACTIVE_ACCOUNT}" >/dev/null

if ! gcloud projects describe "${PROJECT_ID}" >/dev/null 2>&1; then
    echo "Creating project ${PROJECT_ID}"
    gcloud projects create "${PROJECT_ID}" --name="${PROJECT_NAME}" --set-as-default
else
    echo "Project ${PROJECT_ID} already exists; reusing."
fi

echo "Checking billing linkage"
_BILL_JSON=$(gcloud_json beta billing projects describe "${PROJECT_ID}" 2>/dev/null || true)
CURRENT_BILLING=$("$PYTHON_BIN" - "${_BILL_JSON}" <<'PY'
import sys, json
path = sys.argv[1]
try:
    with open(path, 'r') as fh:
        obj = json.load(fh) or {}
except Exception:
    obj = {}
print(obj.get('billingAccountName', ''))
PY
)
rm -f "${_BILL_JSON}"
if [ -n "${CURRENT_BILLING}" ]; then
    echo "Project already linked to billing account: ${CURRENT_BILLING}"
else
    echo "Linking billing account"
    gcloud beta billing projects link "${PROJECT_ID}" --billing-account="${BILLING_ACCOUNT_ID}" >/dev/null
fi

echo "Enabling required APIs"
APIS=(
    "drive.googleapis.com"
    "gmail.googleapis.com"
    "people.googleapis.com"
    "script.googleapis.com"
    "cloudresourcemanager.googleapis.com"
    "serviceusage.googleapis.com"
    "iap.googleapis.com"
)
for api in "${APIS[@]}"; do
    echo "- ${api}"
    gcloud services enable "${api}" --project "${PROJECT_ID}"
done

_PROJ_JSON=$(gcloud_json projects describe "${PROJECT_ID}")
PROJECT_NUMBER=$("$PYTHON_BIN" - "${_PROJ_JSON}" <<'PY'
import sys, json
path = sys.argv[1]
try:
    with open(path, 'r') as fh:
        obj = json.load(fh) or {}
except Exception:
    obj = {}
print(obj.get('projectNumber', ''))
PY
)
rm -f "${_PROJ_JSON}"
if [ -z "${PROJECT_NUMBER}" ]; then
    echo "Unable to determine project number." 1>&2
    exit 1
fi

echo "Ensuring OAuth brand"
BRAND_PATH=""
_BRANDS_JSON=$(gcloud_json iap oauth-brands list --quiet)
BRAND_PATH=$("$PYTHON_BIN" - "${_BRANDS_JSON}" "${PROJECT_NUMBER}" <<'PY'
import sys, json
path, pn = sys.argv[1], sys.argv[2]
try:
    with open(path, 'r') as fh:
        arr = json.load(fh) or []
except Exception:
    arr = []
for b in arr:
    name = (b.get('name') or '')
    if name.startswith('projects/{}/brands'.format(pn)):
        print(name)
        break
PY
)
rm -f "${_BRANDS_JSON}"

if [ -z "${BRAND_PATH}" ]; then
    echo "Creating OAuth brand"
    gcloud iap oauth-brands create --application_title="${OAUTH_APP_NAME}" --support_email="${SUPPORT_EMAIL}" --quiet
    _BRANDS_JSON=$(gcloud_json iap oauth-brands list --quiet)
    BRAND_PATH=$("$PYTHON_BIN" - "${_BRANDS_JSON}" "${PROJECT_NUMBER}" <<'PY'
import sys, json
path, pn = sys.argv[1], sys.argv[2]
try:
    with open(path, 'r') as fh:
        arr = json.load(fh) or []
except Exception:
    arr = []
for b in arr:
    name = (b.get('name') or '')
    if name.startswith('projects/{}/brands'.format(pn)):
        print(name)
        break
PY
    )
    rm -f "${_BRANDS_JSON}"
fi

if [ -z "${BRAND_PATH}" ]; then
    echo "Failed to create or retrieve OAuth brand." 1>&2
    exit 1
fi

echo "Using OAuth brand: ${BRAND_PATH}"

DESKTOP_DISPLAY="${OAUTH_APP_NAME} Desktop"
WEB_DISPLAY="${OAUTH_APP_NAME} Web"

function client_exists() {
    local display_name="$1"
    local _clients_json
    _clients_json=$(gcloud_json iap oauth-clients list "projects/${PROJECT_NUMBER}/brands/${PROJECT_NUMBER}" --quiet)
    if "$PYTHON_BIN" - "${_clients_json}" "$display_name" <<'PY'
import sys, json
path, name = sys.argv[1], sys.argv[2]
try:
    with open(path, 'r') as fh:
        arr = json.load(fh) or []
except Exception:
    arr = []
import sys
sys.exit(0 if any((c.get('displayName') or '') == name for c in arr) else 1)
PY
    then
        rm -f "${_clients_json}"
        return 0
    fi
    rm -f "${_clients_json}"
    return 1
}

function create_desktop_client() {
    if client_exists "${DESKTOP_DISPLAY}"; then
        echo "Desktop OAuth client '${DESKTOP_DISPLAY}' already exists. Skipping creation."
        return 1
    fi
    echo "Creating desktop OAuth client (${DESKTOP_DISPLAY})"
    local raw_path="${SCRIPT_DIR}/desktop_client_raw.json"
    gcloud iap oauth-clients create "projects/${PROJECT_NUMBER}/brands/${PROJECT_NUMBER}" --display_name="${DESKTOP_DISPLAY}" --format=json --quiet > "${raw_path}"
    if [ ! -s "${raw_path}" ]; then
        echo "Failed to create desktop OAuth client; empty response." 1>&2
        exit 1
    fi
    "$PYTHON_BIN" - "$raw_path" "${PROJECT_ID}" "${SCRIPT_DIR}/desktop_client_secret.json" <<'PY'
import json, sys, os
raw_path, project_id, out_path = sys.argv[1:]
with open(raw_path, 'r') as fh:
    data = json.load(fh)
name = data.get('name') or ''
client_id = data.get('clientId') or data.get('client_id') or (name.split('/')[-1] if name else '')
client_secret = data.get('secret') or data.get('clientSecret') or data.get('client_secret')
if not client_id or not client_secret:
    raise SystemExit('Missing client_id or client_secret in desktop client output')
redirects = [
    'http://localhost',
    'http://localhost:8080',
    'http://127.0.0.1',
    'http://localhost:8000',  # HTTP redirect URI for HTTP mode (development/troubleshooting)
    'http://127.0.0.1:8000',  # HTTP redirect URI fallback for HTTP mode
]
# Optionally include deprecated OOB only if explicitly allowed
if os.environ.get('OAUTH_ALLOW_OOB', '').lower() in ('1', 'true'):
    redirects.append('urn:ietf:wg:oauth:2.0:oob')
payload = {
    'installed': {
        'client_id': client_id,
        'project_id': project_id,
        'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
        'token_uri': 'https://oauth2.googleapis.com/token',
        'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
        'client_secret': client_secret,
        'redirect_uris': redirects,
    }
}
with open(out_path, 'w') as fh:
    json.dump(payload, fh, indent=2, sort_keys=True)
PY
    if [ ! -s "${SCRIPT_DIR}/desktop_client_secret.json" ]; then
        echo "Desktop secret file was not created." 1>&2
        exit 1
    fi
    cp "${SCRIPT_DIR}/desktop_client_secret.json" "${JSON_DIR}/credentials.json"
    if ! is_windows; then
        chmod 600 "${JSON_DIR}/credentials.json" || true
    fi
    echo "Desktop credentials written to ${JSON_DIR}/credentials.json"
    return 0
}

function create_web_client() {
    if client_exists "${WEB_DISPLAY}"; then
        echo "Web OAuth client '${WEB_DISPLAY}' already exists. Skipping creation."
        return 1
    fi
    echo "Creating web OAuth client (${WEB_DISPLAY})"
    local raw_path="${SCRIPT_DIR}/web_client_raw.json"
    gcloud iap oauth-clients create \
        "projects/${PROJECT_NUMBER}/brands/${PROJECT_NUMBER}" \
        --display_name="${WEB_DISPLAY}" \
        --format=json --quiet > "${raw_path}"
    if [ ! -s "${raw_path}" ]; then
        echo "Failed to create web OAuth client; empty response." 1>&2
        exit 1
    fi
    "$PYTHON_BIN" - "$raw_path" "${PROJECT_ID}" "${SCRIPT_ID}" "${SCRIPT_DIR}/web_client_secret.json" <<'PY'
import json, sys
raw_path, project_id, script_id, out_path = sys.argv[1:]
with open(raw_path, 'r') as fh:
    data = json.load(fh)
name = data.get('name') or ''
client_id = data.get('clientId') or data.get('client_id') or (name.split('/')[-1] if name else '')
client_secret = data.get('secret') or data.get('clientSecret') or data.get('client_secret')
if not client_id or not client_secret:
    raise SystemExit('Missing client_id or client_secret in web client output')
redirects = [
    'https://script.google.com/macros/d/{}/usercallback'.format(script_id),
    'https://127.0.0.1:8000',  # HTTPS redirect URI (default mode)
    'http://localhost:8000',  # HTTP redirect URI for HTTP mode (development/troubleshooting only)
    'http://127.0.0.1:8000',  # HTTP redirect URI fallback for HTTP mode
]
payload = {
    'web': {
        'client_id': client_id,
        'project_id': project_id,
        'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
        'token_uri': 'https://oauth2.googleapis.com/token',
        'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
        'client_secret': client_secret,
        'redirect_uris': redirects,
        'javascript_origins': [
            'https://script.google.com',
            'https://script.googleusercontent.com'
        ]
    }
}
with open(out_path, 'w') as fh:
    json.dump(payload, fh, indent=2, sort_keys=True)
PY
    if [ ! -s "${SCRIPT_DIR}/web_client_secret.json" ]; then
        echo "Web client secret file was not created." 1>&2
        exit 1
    fi
    echo "Web client secret written to ${SCRIPT_DIR}/web_client_secret.json"
    return 0
}

DESKTOP_CREATED=0
WEB_CREATED=0

if [ "${AUTO_CREATE_OAUTH}" = "1" ]; then
    if create_desktop_client; then
        DESKTOP_CREATED=1
    fi
    if create_web_client; then
        WEB_CREATED=1
    fi
else
    echo
    echo "Manual OAuth client creation required (AUTO_CREATE_OAUTH=0):"
    echo "1) Create a Web OAuth client in APIs & Services > Credentials"
    echo "   - Name: ${OAUTH_APP_NAME} Local Helper"
    echo "   - Authorized redirect URIs: https://127.0.0.1:8000"
    echo "   - Download the JSON and save to ${JSON_DIR}/credentials.json"
    echo "2) (Optional) If you prefer a Desktop client, change the helper redirect to http://127.0.0.1:8000"
    echo "   in MediLink_Gmail.py and create a Desktop OAuth client instead; download JSON to ${JSON_DIR}/credentials.json"
    echo "3) Link your Apps Script project to this GCP project and keep consent in External/Testing with test users."
fi

echo
echo "Summary"
echo "-------"
echo "Project ID: ${PROJECT_ID}"
echo "Project Number: ${PROJECT_NUMBER}"
echo "OAuth Brand: ${BRAND_PATH}"
if [ "${DESKTOP_CREATED}" -eq 1 ]; then
    echo "Desktop OAuth client created and stored at ${JSON_DIR}/credentials.json"
else
    echo "Desktop OAuth client already existed; verify credentials manually if needed."
fi
if [ "${WEB_CREATED}" -eq 1 ]; then
    echo "Web OAuth client created; secret saved at ${SCRIPT_DIR}/web_client_secret.json"
else
    echo "Web OAuth client already existed; web client secret not regenerated."
fi

cat <<'NEXT'

Next manual steps:
1. Configure the OAuth consent screen in the Google Cloud console (use Internal when allowed).
2. In the Apps Script editor, link the project to this Cloud project (Project Settings -> Google Cloud Platform project) and redeploy the web app / Execution API.
3. Delete any existing MediLink token.json before re-running MediLink_Gmail.py so the new credentials are used.
4. Follow post_setup_checklist.md to validate both OTP and non-OTP flows.

NEXT
