#!/usr/bin/env python
import argparse
import json
import sqlite3

EXPECTED_TABLES = [
    "model_metadata", "ingest_artifact", "qa_result", "replay_queue",
    "patient", "payer", "insurance_plan", "coverage", "encounter",
    "claim", "claim_line", "extracted_canonical_record", "projection_result",
    "mapping_rule", "constraint_rule", "rule_decision_log",
]


def query_one(conn, q):
    return conn.execute(q).fetchone()[0]


def verify_table_inventory(conn):
    """Verify all 16 expected tables exist."""
    cursor = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name IN ({0})".format(
            ",".join(["?"] * len(EXPECTED_TABLES))
        ),
        EXPECTED_TABLES,
    )
    found = set(row[0] for row in cursor.fetchall())
    missing = set(EXPECTED_TABLES) - found
    if missing:
        raise SystemExit("missing tables: {0}".format(sorted(missing)))
    return len(found)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    args = p.parse_args()

    conn = sqlite3.connect(args.db)
    conn.execute("PRAGMA foreign_keys = ON")

    table_count = verify_table_inventory(conn)

    checks = {}
    checks["table_count"] = table_count
    checks["ingest_artifact_count"] = query_one(conn, "SELECT COUNT(*) FROM ingest_artifact")
    checks["qa_reject_count"] = query_one(conn, "SELECT COUNT(*) FROM qa_result WHERE status='reject'")
    checks["replay_pending_count"] = query_one(conn, "SELECT COUNT(*) FROM replay_queue WHERE status='pending'")
    checks["patient_count"] = query_one(conn, "SELECT COUNT(*) FROM patient")
    checks["claim_count"] = query_one(conn, "SELECT COUNT(*) FROM claim")
    checks["projection_count"] = query_one(conn, "SELECT COUNT(*) FROM projection_result")
    checks["orphan_claim_lines"] = query_one(conn, "SELECT COUNT(*) FROM claim_line cl LEFT JOIN claim c ON c.claim_id = cl.claim_id WHERE c.claim_id IS NULL")

    if checks["orphan_claim_lines"] != 0:
        raise SystemExit("orphan claim lines detected")

    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
