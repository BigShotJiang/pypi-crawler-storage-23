#!/usr/bin/env python
"""
Phase A bootstrap for XP Local Parallel Validation.
Creates lab/, applies schema, writes metadata, status, and run cursor.
XP-compatible: Python 3.4.4, stdlib only (no pathlib, no f-strings).
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import platform
import sqlite3
import sys
import time

# Lock and safe-write from shared module
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from lab_lock import acquire_lock, release_lock, replace_safe_write
    from lab_path_utils import resolve_lab_root
    from phase_a_common import BOOTSTRAP_VERSION, iso_utc_now, run_id as make_run_id
except ImportError:
    print("lab_lock module required; run from workspace root.", file=sys.stderr)
    sys.exit(1)
EXPECTED_TABLES = [
    "model_metadata", "ingest_artifact", "qa_result", "replay_queue",
    "patient", "payer", "insurance_plan", "coverage", "encounter",
    "claim", "claim_line", "extracted_canonical_record", "projection_result",
    "mapping_rule", "constraint_rule", "rule_decision_log",
]
ARTIFACT_CLASSES = [
    "csv", "docx", "dat", "jsonl", "837", "receipt", "xml",
    "crosswalk", "config", "deductible_cache"
]


def _workspace_root():
    """Workspace root from script location. Do not use getcwd."""
    this_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(this_dir, "..", ".."))


def _resolve_lab_root(args):
    """Lab root: --lab-dir > MEDICAFE_LAB_DIR > workspace_root/lab."""
    return resolve_lab_root(args.lab_dir, _workspace_root())


# Error codes for Phase A failure reporting
PHASE_A_SELFCHECK_FAIL = "PHASE_A_SELFCHECK_FAIL"
PHASE_A_TABLE_INVENTORY = "PHASE_A_TABLE_INVENTORY"
PHASE_A_METADATA = "PHASE_A_METADATA"
PHASE_A_LOCK_FAIL = "PHASE_A_LOCK_FAIL"
PHASE_A_SCHEMA_MISSING = "PHASE_A_SCHEMA_MISSING"
PHASE_A_SQLITE_ERROR = "PHASE_A_SQLITE_ERROR"
PHASE_A_IO_ERROR = "PHASE_A_IO_ERROR"


def should_report_failure(error_code, env):
    """Return True if failure should trigger auto-report. Skip for lock and expected rejection."""
    if error_code == PHASE_A_LOCK_FAIL:
        return False
    if env.get("MEDICAFE_PHASE_A_EXPECTED_LOCK_REJECT") == "1":
        return False
    return True


def _maybe_report_failure(lab_root, error_code, run_id, schema_sha, first_failed_check,
                          report_json_path=None, report_txt_path=None):
    """Call phase_a_auto_report when should_report_failure; catch and log any report errors."""
    if not should_report_failure(error_code, os.environ):
        return
    try:
        from phase_a_auto_report import submit_phase_a_failure_report
        txt_path = report_txt_path
        if txt_path is None and report_json_path:
            txt_path = report_json_path.replace(".json", ".txt")
            if not os.path.exists(txt_path):
                txt_path = None
        ctx = {
            "error_code": error_code,
            "run_id": run_id or "",
            "first_failed_check": first_failed_check or "unknown",
            "schema_sql_sha256": schema_sha or "",
            "report_json_path": report_json_path,
            "report_txt_path": report_txt_path or txt_path,
        }
        submit_phase_a_failure_report(lab_root, ctx)
    except Exception as e:
        try:
            print("Phase A report failed: {0}".format(e), file=sys.stderr)
        except Exception:
            pass


def _query_one(conn, sql, params=None):
    if params is None:
        params = ()
    return conn.execute(sql, params).fetchone()[0]


def _verify_table_inventory(conn):
    placeholders = ",".join(["?"] * len(EXPECTED_TABLES))
    cursor = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name IN ({0})".format(placeholders),
        EXPECTED_TABLES,
    )
    found = set([row[0] for row in cursor.fetchall()])
    missing = sorted(list(set(EXPECTED_TABLES) - found))
    return len(found), missing


def _append_check(checks, name, ok, detail):
    checks.append({
        "name": name,
        "ok": bool(ok),
        "detail": detail,
    })


def _write_text_report(path, report):
    lines = []
    lines.append("Phase A Self-Check Report")
    lines.append("run_id: {0}".format(report.get("run_id")))
    lines.append("generated_at_utc: {0}".format(report.get("generated_at_utc")))
    lines.append("ok: {0}".format(report.get("ok")))
    host = report.get("host", {})
    lines.append("host_platform: {0}".format(host.get("platform")))
    lines.append("host_release: {0}".format(host.get("release")))
    lines.append("host_machine: {0}".format(host.get("machine")))
    lines.append("python_version: {0}".format(host.get("python_version")))
    lines.append("")
    lines.append("Checks:")
    for c in report.get("checks", []):
        lines.append("- {0}: {1} ({2})".format(c.get("name"), "PASS" if c.get("ok") else "FAIL", c.get("detail")))
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def run_phase_a_self_check(lab_root, db_path, status_path, cursor_path, run_id, schema_sha, strict_seed_checks=True):
    """
    Self-check Phase A artifacts and emit machine-readable + text evidence in lab/reports.
    Returns (ok, json_report_path, txt_report_path).
    """
    checks = []
    now_utc = iso_utc_now()
    reports_dir = os.path.join(lab_root, "reports")
    report_json_path = os.path.join(reports_dir, "bootstrap_phase_a_selfcheck_{0}.json".format(run_id))
    report_txt_path = os.path.join(reports_dir, "bootstrap_phase_a_selfcheck_{0}.txt".format(run_id))

    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)

    # DB and table inventory
    _append_check(checks, "db_exists", os.path.exists(db_path), "db_path={0}".format(db_path))
    table_count = 0
    db_conn = None
    metadata = {}
    if os.path.exists(db_path):
        try:
            db_conn = sqlite3.connect(db_path)
            db_conn.execute("PRAGMA foreign_keys = ON")
            table_count, missing_tables = _verify_table_inventory(db_conn)
            _append_check(
                checks,
                "table_inventory",
                len(missing_tables) == 0 and table_count == len(EXPECTED_TABLES),
                "table_count={0}, missing={1}".format(table_count, missing_tables),
            )
            rows = db_conn.execute("SELECT key, value FROM model_metadata").fetchall()
            metadata = dict(rows)
        except Exception as e:
            _append_check(checks, "db_open_inventory", False, str(e))
        finally:
            if db_conn is not None:
                db_conn.close()
    else:
        _append_check(checks, "table_inventory", False, "db missing")

    # Metadata checks
    required_meta = [
        "schema_version", "run_id", "schema_sql_sha256", "bootstrap_version",
        "build_start_utc", "build_start_local", "host_platform", "host_release",
        "host_machine", "python_version", "schema_file_applied", "contract_snapshot",
    ]
    missing_meta = [k for k in required_meta if k not in metadata]
    _append_check(
        checks,
        "metadata_required_keys",
        len(missing_meta) == 0,
        "missing={0}".format(missing_meta),
    )
    run_id_ok = bool(str(metadata.get("run_id", "") or "").strip())
    if strict_seed_checks:
        run_id_ok = (metadata.get("run_id") == run_id)
    _append_check(
        checks,
        "metadata_run_id_match",
        run_id_ok,
        "expected={0}, actual={1}, strict={2}".format(run_id, metadata.get("run_id"), strict_seed_checks),
    )
    _append_check(
        checks,
        "metadata_schema_sha_match",
        metadata.get("schema_sql_sha256") == schema_sha,
        "expected={0}, actual={1}".format(schema_sha, metadata.get("schema_sql_sha256")),
    )
    snapshot_ok = False
    snapshot_detail = "missing"
    try:
        snapshot = json.loads(metadata.get("contract_snapshot", "{}"))
        classes = snapshot.get("artifact_classes", [])
        snapshot_ok = (
            snapshot.get("lab_root") == lab_root and
            snapshot.get("workspace_root") == _workspace_root() and
            snapshot.get("schema_file") == "unified_relational_model_v1.sql" and
            classes == ARTIFACT_CLASSES
        )
        snapshot_detail = "artifact_classes={0}".format(len(classes))
    except Exception as e:
        snapshot_detail = str(e)
    _append_check(checks, "metadata_contract_snapshot", snapshot_ok, snapshot_detail)

    # Status and cursor checks
    status_ok = False
    status_detail = "missing"
    if os.path.exists(status_path):
        try:
            with open(status_path, "r", encoding="utf-8") as f:
                status = json.load(f)
            run_id_match = bool(str(status.get("run_id", "") or "").strip())
            if strict_seed_checks:
                run_id_match = (status.get("run_id") == run_id)
            if strict_seed_checks:
                status_ok = (
                    status.get("run_state") == "idle" and
                    status.get("current_phase") == "A" and
                    status.get("schema_version") == "1" and
                    run_id_match
                )
            else:
                status_ok = isinstance(status, dict) and bool(str(status.get("run_id", "") or "").strip())
            status_detail = "run_state={0}, phase={1}, strict={2}".format(
                status.get("run_state"), status.get("current_phase"), strict_seed_checks)
        except Exception as e:
            status_detail = str(e)
    _append_check(checks, "shadow_status", status_ok, status_detail)

    cursor_ok = False
    cursor_detail = "missing"
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor_doc = json.load(f)
            classes = sorted(list(cursor_doc.get("artifact_classes", {}).keys()))
            expected = sorted(list(ARTIFACT_CLASSES))
            if strict_seed_checks:
                cursor_ok = classes == expected
            else:
                cursor_ok = isinstance(cursor_doc.get("artifact_classes", {}), dict)
            cursor_detail = "class_count={0}, strict={1}".format(len(classes), strict_seed_checks)
        except Exception as e:
            cursor_detail = str(e)
    _append_check(checks, "run_cursor", cursor_ok, cursor_detail)

    overall_ok = all([c.get("ok") for c in checks])
    report = {
        "phase": "A",
        "run_id": run_id,
        "generated_at_utc": now_utc,
        "ok": overall_ok,
        "host": {
            "platform": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python_version": sys.version.split()[0],
        },
        "checks": checks,
    }
    with open(report_json_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    _write_text_report(report_txt_path, report)
    return overall_ok, report_json_path, report_txt_path


def main():
    parser = argparse.ArgumentParser(description="Phase A bootstrap for XP Local Parallel Validation")
    parser.add_argument("--lab-dir", dest="lab_dir", default=None, help="Override lab root")
    parser.add_argument("--reset", action="store_true", help="Delete DB, status, cursor; re-create from scratch")
    args = parser.parse_args()

    workspace_root = _workspace_root()
    lab_root = _resolve_lab_root(args)
    sql_path = os.path.join(workspace_root, "sql", "unified_relational_model_v1.sql")
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    status_path = os.path.join(lab_root, "shadow_status.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    tracker_path = os.path.join(lab_root, "cloud_health_tracker.json")
    alert_state_path = os.path.join(lab_root, "cloud_health_alert_state.json")

    lock_acquired = False
    conn = None
    try:
        # 1. Create lab/ and lab/reports/
        os.makedirs(lab_root, exist_ok=True)
        os.makedirs(os.path.join(lab_root, "reports"), exist_ok=True)

        # 2. Acquire lock
        acquire_lock(lab_root)
        lock_acquired = True

        # 3. If --reset: delete DB, status, cursor
        if args.reset:
            for p in (db_path, status_path, cursor_path, state_path, tracker_path, alert_state_path):
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except Exception as e:
                        print("Failed to remove {0}: {1}".format(p, e), file=sys.stderr)
                        return 1

        # 4. Check SQL file exists
        if not os.path.exists(sql_path):
            print("Schema file not found: {0}".format(sql_path), file=sys.stderr)
            _maybe_report_failure(
                lab_root, PHASE_A_SCHEMA_MISSING,
                run_id="", schema_sha="", first_failed_check="schema",
                report_json_path=None, report_txt_path=None,
            )
            return 1

        # 5. Apply schema
        with open(sql_path, "r", encoding="utf-8") as f:
            sql_content = f.read()
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(sql_content)
        conn.commit()

        # 6. Compute schema SHA256 and run_id
        schema_sha = hashlib.sha256(sql_content.encode("utf-8")).hexdigest()
        run_id = make_run_id()
        now_utc = iso_utc_now()
        now_local = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

        # 7. Write metadata stamp
        contract_snapshot = json.dumps({
            "lab_root": lab_root,
            "workspace_root": workspace_root,
            "artifact_classes": ARTIFACT_CLASSES,
            "schema_file": "unified_relational_model_v1.sql",
            "bootstrap_version": BOOTSTRAP_VERSION,
        })
        meta_rows = [
            ("schema_version", "1"),
            ("run_id", run_id),
            ("schema_sql_sha256", schema_sha),
            ("bootstrap_version", BOOTSTRAP_VERSION),
            ("build_start_utc", now_utc),
            ("build_start_local", now_local),
            ("host_platform", platform.system()),
            ("host_release", platform.release()),
            ("host_machine", platform.machine()),
            ("python_version", sys.version.split()[0]),
            ("schema_file_applied", "unified_relational_model_v1.sql"),
            ("contract_snapshot", contract_snapshot),
        ]
        for k, v in meta_rows:
            conn.execute(
                "INSERT OR REPLACE INTO model_metadata (key, value, created_at) VALUES (?, ?, datetime('now'))",
                (k, v)
            )
        conn.commit()

        # 8. Seed shadow_status.json only when missing.
        shadow_status = {
            "run_state": "idle",
            "heartbeat_at_utc": None,
            "last_success_at_utc": None,
            "current_phase": "A",
            "error_summary": None,
            "schema_version": "1",
            "lab_root": lab_root,
            "run_id": run_id,
        }
        status_seeded = False
        if not os.path.exists(status_path):
            replace_safe_write(status_path, shadow_status)
            status_seeded = True

        # 9. Seed run_cursor.json only when missing.
        run_cursor = {
            "version": 1,
            "updated_at_utc": now_utc,
            "artifact_classes": {}
        }
        for ac in ARTIFACT_CLASSES:
            run_cursor["artifact_classes"][ac] = {"last_scan_mtime": None, "last_scan_path": None}
        cursor_seeded = False
        if not os.path.exists(cursor_path):
            replace_safe_write(cursor_path, run_cursor)
            cursor_seeded = True

        # 10. Seed diagnostics_state.json so first-launch health checks have stable context.
        diagnostics_state = {
            "version": 2,
            "updated_at_utc": now_utc,
            "last_phase_a_run_id": run_id,
            "last_phase_a_ok": True,
            "last_schema_sha256": schema_sha,
            "last_discovery_ok": None,
            "last_phase_c_ok": None,
            "last_phase_d_ok": None,
            "last_phase_e_ok": None,
            "last_shadow_pipeline_ok": None,
            "pipeline_state": "idle",
            "active_run_id": "",
            "active_phase": "",
            "last_error_code": "",
            "started_at_utc": now_utc,
            "heartbeat_at_utc": None,
            "finished_at_utc": now_utc,
        }
        state_seeded = False
        if not os.path.exists(state_path):
            replace_safe_write(state_path, diagnostics_state)
            state_seeded = True

        # 11. Seed cloud health tracker state for deterministic first-launch behavior.
        cloud_health_tracker = {
            "version": 1,
            "issues": {},
            "last_updated_epoch": None,
        }
        tracker_seeded = False
        if not os.path.exists(tracker_path):
            replace_safe_write(tracker_path, cloud_health_tracker)
            tracker_seeded = True

        cloud_health_alert_state = {
            "last_issue_key": "",
            "last_sent_epoch": 0,
        }
        alert_seeded = False
        if not os.path.exists(alert_state_path):
            replace_safe_write(alert_state_path, cloud_health_alert_state)
            alert_seeded = True

        # 12. Embedded self-check + evidence artifacts (for XP run validation in-place)
        check_ok, check_json, check_txt = run_phase_a_self_check(
            lab_root=lab_root,
            db_path=db_path,
            status_path=status_path,
            cursor_path=cursor_path,
            run_id=run_id,
            schema_sha=schema_sha,
            strict_seed_checks=bool(args.reset or status_seeded or cursor_seeded or state_seeded or tracker_seeded or alert_seeded),
        )
        if not check_ok:
            first_failed = "unknown"
            try:
                with open(check_json, "r", encoding="utf-8") as f:
                    report_data = json.load(f)
                for c in report_data.get("checks", []):
                    if not c.get("ok"):
                        first_failed = c.get("name", "unknown")
                        break
            except Exception:
                pass
            _maybe_report_failure(
                lab_root, PHASE_A_SELFCHECK_FAIL,
                run_id=run_id, schema_sha=schema_sha, first_failed_check=first_failed,
                report_json_path=check_json, report_txt_path=check_txt,
            )
            print("Phase A self-check failed. See: {0}".format(check_json), file=sys.stderr)
            return 1

        print("Phase A bootstrap complete. lab_root={0}".format(lab_root))
        print("Phase A self-check report (json): {0}".format(check_json))
        print("Phase A self-check report (txt): {0}".format(check_txt))
        return 0

    except KeyboardInterrupt:
        print("Phase A bootstrap interrupted by control event; source unknown.", file=sys.stderr)
        return 130
    except sqlite3.Error as e:
        print("Schema execution failed: {0}".format(e), file=sys.stderr)
        schema_sha_ex = ""
        try:
            if os.path.exists(sql_path):
                with open(sql_path, "rb") as f:
                    schema_sha_ex = hashlib.sha256(f.read()).hexdigest()
        except Exception:
            pass
        _maybe_report_failure(
            lab_root, PHASE_A_SQLITE_ERROR,
            run_id="", schema_sha=schema_sha_ex, first_failed_check="schema_execution",
            report_json_path=None, report_txt_path=None,
        )
        return 1
    except IOError as e:
        print("Failed to write file: {0}".format(e), file=sys.stderr)
        _maybe_report_failure(
            lab_root, PHASE_A_IO_ERROR,
            run_id="", schema_sha="", first_failed_check="io_error",
            report_json_path=None, report_txt_path=None,
        )
        return 1
    except OSError as e:
        print("Failed to create lab directory: {0}".format(e), file=sys.stderr)
        _maybe_report_failure(
            lab_root, PHASE_A_IO_ERROR,
            run_id="", schema_sha="", first_failed_check="os_error",
            report_json_path=None, report_txt_path=None,
        )
        return 1
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
        if lock_acquired:
            release_lock(lab_root, owner_pid=str(os.getpid()))


if __name__ == "__main__":
    sys.exit(main())
