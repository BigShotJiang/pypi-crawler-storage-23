#!/usr/bin/env python
"""
Shared constants and helpers for Phase A bootstrap, diagnostics, and reporting.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import time
import uuid

BOOTSTRAP_VERSION = "1.0"


def iso_utc_now():
    """ISO 8601 UTC timestamp."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def run_id():
    """Format: YYYYMMDD-HHMMSS-<first8hex>."""
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    try:
        hex_part = uuid.uuid4().hex[:8]
    except Exception:
        hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
    return "{0}-{1}".format(ts, hex_part)
