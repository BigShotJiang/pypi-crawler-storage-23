#!/usr/bin/env python
"""
XP Shadow Pipeline orchestrator: runs A -> B -> C -> D -> E -> F.
Single authoritative path for unattended end-to-end automation.
Uses dedicated pipeline lock (shadow_pipeline.lock); does not long-hold lab/shadow.lock.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import subprocess
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from lab_path_utils import resolve_lab_root
from phase_a_common import iso_utc_now, run_id
from failure_contract import build_failure_context

PIPELINE_LOCK_NAME = "shadow_pipeline.lock"


def _workspace_root():
    return _WORKSPACE_ROOT


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _pid_running(pid):
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError):
        return False


def _parse_pipeline_lock(lock_path):
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        pid = None
        heartbeat = None
        for line in content.splitlines():
            if line.startswith("pid="):
                pid = line[4:].strip()
            elif line.startswith("heartbeat_at_utc="):
                heartbeat = line[17:].strip()
        return (pid, heartbeat)
    except Exception:
        return (None, None)


def _acquire_pipeline_lock(lab_root):
    """Acquire lab/shadow_pipeline.lock. Returns True if acquired, False if already running."""
    os.makedirs(lab_root, exist_ok=True)
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    max_retries = 2
    for attempt in range(max_retries + 1):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            content = "pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), now)
            os.write(fd, content.encode("ascii"))
            os.close(fd)
            return True
        except (OSError, IOError) as e:
            errno_val = getattr(e, "errno", None)
            if errno_val not in (17, 183):
                raise
        pid, heartbeat = _parse_pipeline_lock(lock_path)
        if pid is None:
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            continue
        if _pid_running(pid):
            return False  # Never steal from a running process
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        if attempt >= max_retries:
            return False
    return False


def _release_pipeline_lock(lab_root):
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception:
        pass


def _refresh_lock_heartbeat(lab_root):
    """Update heartbeat_at_utc in the pipeline lock file. Keeps long runs from being considered stale."""
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    tmp_path = lock_path + ".tmp"
    if not os.path.exists(lock_path):
        return
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        lines = []
        for line in content.splitlines():
            if line.startswith("heartbeat_at_utc="):
                lines.append("heartbeat_at_utc={0}".format(now))
            else:
                lines.append(line)
        new_content = "\n".join(lines) + "\n"
        with open(tmp_path, "w") as f:
            f.write(new_content)
        os.replace(tmp_path, lock_path)
    except Exception:
        pass
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def _update_pipeline_state(lab_root, rid, started_at, finished_at, ok, failed_phase=None, error_code=None,
                           skip_reason=None, heartbeat_at_utc=None, phase_run_ids=None, failure_context=None):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_run_id"] = rid
    state["last_shadow_pipeline_started_at_utc"] = started_at
    state["last_shadow_pipeline_finished_at_utc"] = finished_at
    state["last_shadow_pipeline_ok"] = ok
    state["last_shadow_pipeline_failed_phase"] = failed_phase or ""
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "completed" if ok else "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["started_at_utc"] = started_at
    state["finished_at_utc"] = finished_at
    state["updated_at_utc"] = finished_at
    state["phase_f_report_sent"] = False
    state["phase_f_report_sent_for_run_id"] = ""
    if phase_run_ids:
        state["last_shadow_pipeline_phase_run_ids"] = phase_run_ids
    if skip_reason:
        state["last_shadow_pipeline_skip_reason"] = skip_reason
    if heartbeat_at_utc:
        state["last_shadow_pipeline_lock_heartbeat_at_utc"] = heartbeat_at_utc
        state["heartbeat_at_utc"] = heartbeat_at_utc
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _update_pipeline_phase_f_failure(lab_root, rid, error_code, phase_f_lock_diag_path="", failure_context=None):
    """Update only failure fields; do not touch phase_f_report_sent*."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_ok"] = False
    state["last_shadow_pipeline_failed_phase"] = "F"
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["last_phase_f_lock_diag_path"] = phase_f_lock_diag_path or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["finished_at_utc"] = iso_utc_now()
    state["updated_at_utc"] = state.get("finished_at_utc")
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _update_pipeline_phase_marker(lab_root, rid, phase_name, now_utc):
    """Owner-only write path for lifecycle fields during active pipeline run."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "bootstrapping" if phase_name == "A" else "running"
    state["active_run_id"] = rid
    state["active_phase"] = phase_name
    state["started_at_utc"] = state.get("started_at_utc") or now_utc
    state["heartbeat_at_utc"] = now_utc
    state["updated_at_utc"] = now_utc
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _run_phase(script_name, lab_root, python_exe, repo_root, env):
    """Run a phase script. Returns (ok, exit_code)."""
    script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
    if not os.path.exists(script_path):
        return False, -1
    proc_env = env.copy()
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    call_kwargs = {"cwd": repo_root, "env": proc_env}
    if script_name == "bootstrap_lab.py" and os.name == "nt":
        call_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    try:
        rc = subprocess.call([python_exe, script_path], **call_kwargs)
    except KeyboardInterrupt:
        if script_name == "bootstrap_lab.py":
            print(
                "Bootstrap interrupted by control event; source unknown.",
                file=sys.stderr,
            )
            return False, 130
        raise
    return (rc == 0), rc


def _read_cursor_run_id(lab_root, cursor_key):
    """Read a run_id from cursor. Returns non-empty string or empty."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return ""
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cursor = json.load(f)
        rid = cursor.get(cursor_key, "") or ""
        return str(rid).strip() if rid else ""
    except Exception:
        return ""


def _read_phase_error_code(lab_root, phase_name):
    """Read persisted phase-specific error code from diagnostics_state.json."""
    phase_key = "last_phase_{0}_error_code".format(str(phase_name or "").strip().lower())
    if not phase_key or phase_key == "last_phase__error_code":
        return ""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return ""
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        value = state.get(phase_key, "")
        return str(value).strip() if value else ""
    except Exception:
        return ""


_PHASE_CURSOR_KEYS = {"B": "last_phase_b_run_id", "C": "last_phase_c_run_id",
                      "D": "last_phase_d_run_id", "E": "last_phase_e_run_id"}


def run_shadow_pipeline(lab_root):
    """
    Run A -> B -> C -> D -> E, then package/send via Phase F.
    Returns (ok, run_id, failed_phase, error_code).
    """
    rid = run_id()
    started_at = iso_utc_now()

    if not _acquire_pipeline_lock(lab_root):
        _update_pipeline_state(lab_root, rid, started_at, iso_utc_now(), False,
                              skip_reason="already_running")
        return False, rid, None, "already_running"

    python_exe = sys.executable
    repo_root = _workspace_root()
    env = os.environ.copy()
    env["target_folder"] = env.get("target_folder", "")
    env["source_folder"] = env.get("source_folder", "")

    phases = [
        ("A", "bootstrap_lab.py"),
        ("B", "discover_artifacts.py"),
        ("C", "ingest_from_manifest.py"),
        ("D", "run_qa_canonical.py"),
        ("E", "run_projection_parity.py"),
    ]

    failed_phase = None
    error_code = None
    failure_context = {}
    phase_run_ids = {}
    policy_trigger = False
    phase_f_ok = False

    try:
        # Owner write path updates lifecycle keys (v2 additive schema).
        _update_pipeline_phase_marker(lab_root, rid, "A", started_at)
        for phase_name, script_name in phases:
            _update_pipeline_phase_marker(lab_root, rid, phase_name, iso_utc_now())
            ok, rc = _run_phase(script_name, lab_root, python_exe, repo_root, env)
            _refresh_lock_heartbeat(lab_root)
            if ok and phase_name in _PHASE_CURSOR_KEYS:
                rid_val = _read_cursor_run_id(lab_root, _PHASE_CURSOR_KEYS[phase_name])
                if rid_val:
                    phase_run_ids[phase_name] = rid_val
            if not ok:
                failed_phase = phase_name
                if rc == 130:
                    error_code = "PIPELINE_INTERRUPTED_SOURCE_UNKNOWN"
                    failure_context = build_failure_context(
                        phase_name, error_code, "Process interrupted", "KeyboardInterrupt"
                    )
                else:
                    phase_error = _read_phase_error_code(lab_root, phase_name)
                    if phase_error:
                        error_code = phase_error
                    else:
                        error_code = "PHASE_{0}_EXIT_{1}".format(phase_name, rc)
                    failure_context = build_failure_context(
                        phase_name, error_code, "Phase process exited with rc={0}".format(rc), "ProcessExit"
                    )
                break

        finished_at = iso_utc_now()
        pipeline_ok = (failed_phase is None)
        _update_pipeline_state(lab_root, rid, started_at, finished_at, pipeline_ok,
                              failed_phase, error_code, heartbeat_at_utc=finished_at,
                              phase_run_ids=phase_run_ids, failure_context=failure_context)

        phase_f_script = os.path.join(repo_root, "scripts", "unified_model", "package_shadow_run_report.py")
        if not os.path.exists(phase_f_script):
            pipeline_ok = False
            failed_phase = "F"
            error_code = "PHASE_F_SCRIPT_MISSING"
            failure_context = build_failure_context("F", error_code, "package_shadow_run_report.py missing", "LookupError")
            _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
        else:
            try:
                from package_shadow_run_report import run_package
            except (ImportError, AttributeError):
                pipeline_ok = False
                failed_phase = "F"
                error_code = "PHASE_F_ENTRYPOINT_MISSING"
                failure_context = build_failure_context("F", error_code, "run_package import/entrypoint missing", "ImportError")
                _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
            else:
                try:
                    phase_f_ok, rj, rt, ix, phase_f_err, policy_trigger, phase_f_detail = run_package(
                        lab_root, pipeline_run_id=rid, run_id_source="cli", auto_report=False
                    )
                    if not phase_f_ok:
                        lock_diag = ""
                        lock_owner_running = False
                        lock_heartbeat_stale = True
                        if isinstance(phase_f_detail, dict):
                            lock_diag = phase_f_detail.get("lock_diag_path", "") or ""
                            lock_owner_running = bool(phase_f_detail.get("lock_owner_running"))
                            lock_heartbeat_stale = bool(phase_f_detail.get("lock_heartbeat_stale", True))
                        if phase_f_err == "PHASE_F_LOCK_FAIL" and lock_owner_running and not lock_heartbeat_stale:
                            # Benign contention: classify as attach/retry rather than opaque fatal.
                            pipeline_ok = True
                            failed_phase = None
                            error_code = "PHASE_F_LOCK_CONTENDED_ATTACH"
                            failure_context = build_failure_context(
                                "F", error_code, "Lock owned by active process; attached to existing run", "SystemExit"
                            )
                            _update_pipeline_state(
                                lab_root, rid, started_at, iso_utc_now(), True,
                                failed_phase=None, error_code=error_code,
                                heartbeat_at_utc=iso_utc_now(), phase_run_ids=phase_run_ids,
                                failure_context=failure_context
                            )
                        else:
                            pipeline_ok = False
                            failed_phase = "F"
                            error_code = phase_f_err or "PHASE_F_EXIT_1"
                            detail = ""
                            exc = ""
                            if isinstance(phase_f_detail, dict):
                                detail = str(phase_f_detail.get("error_detail", "") or "")
                                exc = str(phase_f_detail.get("source_exception_class", "") or "")
                            failure_context = build_failure_context("F", error_code, detail, exc)
                            _update_pipeline_phase_f_failure(
                                lab_root, rid, error_code,
                                phase_f_lock_diag_path=lock_diag,
                                failure_context=failure_context
                            )
                except Exception:
                    pipeline_ok = False
                    failed_phase = "F"
                    error_code = "PHASE_F_ENTRYPOINT_MISSING"
                    failure_context = build_failure_context("F", error_code, "run_package raised unexpectedly", "Exception")
                    _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
    finally:
        _release_pipeline_lock(lab_root)

    if policy_trigger and phase_f_ok and rj and rt and ix:
        try:
            from package_shadow_run_report import run_phase_f_report_send
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            st = {}
            try:
                if os.path.exists(state_path):
                    with open(state_path, "r", encoding="utf-8") as f:
                        st = json.load(f)
            except Exception:
                pass
            run_phase_f_report_send(lab_root, rj, rt, ix, {
                "run_id": rid,
                "pipeline_ok": pipeline_ok,
                "failed_phase": failed_phase or "",
                "error_code": error_code or "",
                "contract_parity_status": st.get("last_contract_parity_status", "") or "",
            })
        except Exception:
            pass

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    run_fallback = True
    try:
        if os.path.exists(state_path):
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            if st.get("phase_f_report_sent") is True and st.get("phase_f_report_sent_for_run_id") == rid:
                run_fallback = False
    except Exception:
        pass

    if not pipeline_ok and run_fallback:
        try:
            from phase_e_auto_report import submit_phase_e_failure_report
            submit_phase_e_failure_report(lab_root, {
                "error_code": error_code or "PIPELINE_FAIL",
                "run_id": rid,
                "first_failed": failed_phase or "unknown",
                "lab_root": lab_root,
                "summary": {"phase": "pipeline", "failed_phase": failed_phase},
            })
        except Exception:
            pass

    return pipeline_ok, rid, failed_phase, error_code


def main():
    parser = argparse.ArgumentParser(description="XP Shadow Pipeline (A->B->C->D->E->F)")
    parser.add_argument("--lab-dir", help="Override lab root")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
    if not ok:
        if error_code == "already_running":
            print("Pipeline skipped: prior run still active.", file=sys.stderr)
            sys.exit(0)  # Non-failure; intentional overlap guard
        print("Pipeline failed at Phase {0}: {1}".format(failed_phase, error_code), file=sys.stderr)
        sys.exit(1)
    print("Pipeline ok: {0}".format(rid))


if __name__ == "__main__":
    main()
