# MediCafe/routing_reason_codes.py
"""
Canonical reason-code taxonomy and classifier for payer routing decisions.
Used by api_core and claim-status handling for deterministic fallback and logging.

Python 3.4 compatible.
"""

import re

try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    requests = None
    _REQUESTS_AVAILABLE = False

# Canonical reason codes
UNSUPPORTED_PAYER = 'unsupported_payer'
MEMBER_REQUIRED = 'member_required'
NO_DATA = 'no_data'
AUTH_ISSUE = 'auth_issue'
TRANSPORT_ERROR = 'transport_error'

REASON_CODES = (UNSUPPORTED_PAYER, MEMBER_REQUIRED, NO_DATA, AUTH_ISSUE, TRANSPORT_ERROR)

_NEXT_STEP_HINTS = {
    UNSUPPORTED_PAYER: "Confirm allowed payers for this TIN with UHC or remove payer from list.",
    MEMBER_REQUIRED: "Use member-level search (memberId + DOB or name + DOB) for OPTUMAI; provider-wide search may not be supported.",
    NO_DATA: "Verify payerId/TIN/date range; try narrower date range if needed.",
    AUTH_ISSUE: "Verify client credentials and OPTUMAI subscription.",
    TRANSPORT_ERROR: "Retry later or check network.",
}

_DEFAULT_HINT = "Check logs for details."


def classify_routing_reason(error=None, status_code=None, error_code=None, error_description=None):
    """
    Classify an error into a canonical routing reason code and next-step hint.
    Prioritizes structured fields (status_code, error_code) over free-text.

    Args:
        error: Exception or str (used for msg when no structured fields match)
        status_code: str or int, e.g. '401', 401
        error_code: str from GraphQL
        error_description: str from GraphQL/API

    Returns:
        tuple: (reason_code: str, next_step_hint: str)
    """
    msg = ''
    msg_lower = ''
    if error is not None:
        try:
            msg = str(error)
            msg_lower = msg.lower()
        except Exception:
            pass

    ec_upper = (error_code or '').upper()
    ed_lower = (error_description or '').lower()

    # Phase A: Structured fields first
    if status_code is not None:
        sc = status_code
        if sc == 401 or sc == '401':
            return (AUTH_ISSUE, _NEXT_STEP_HINTS[AUTH_ISSUE])
        if sc == 403 or sc == '403':
            return (AUTH_ISSUE, "Check providerTaxId and subscription permissions.")

    if ec_upper and ('UNAUTHORIZED' in ec_upper or 'INVALID_ACCESS_TOKEN' in ec_upper):
        return (AUTH_ISSUE, _NEXT_STEP_HINTS[AUTH_ISSUE])
    if ed_lower and 'invalid_access_token' in ed_lower:
        return (AUTH_ISSUE, _NEXT_STEP_HINTS[AUTH_ISSUE])

    if ec_upper and ('FORBIDDEN' in ec_upper or 'ACCESS_DENIED' in ec_upper):
        return (AUTH_ISSUE, "Check providerTaxId and subscription permissions.")

    if ec_upper and 'MISSING_REQUIRED_FIELD' in ec_upper:
        return (MEMBER_REQUIRED, _NEXT_STEP_HINTS[MEMBER_REQUIRED])

    if ec_upper and ('LCLM_PS_105' in ec_upper or 'LCLM_PS_202' in ec_upper):
        return (UNSUPPORTED_PAYER, _NEXT_STEP_HINTS[UNSUPPORTED_PAYER])

    if ec_upper and 'LCLM_PS_203' in ec_upper:
        return (NO_DATA, "Restart pagination (omit transactionId) or retry soon; the pagination token may be expired.")
    if ec_upper and 'LCLM_PS_201' in ec_upper:
        return (NO_DATA, _NEXT_STEP_HINTS[NO_DATA])

    # Phase B: Exception type
    if _REQUESTS_AVAILABLE and error is not None and isinstance(error, BaseException):
        if isinstance(error, requests.exceptions.Timeout):
            return (TRANSPORT_ERROR, _NEXT_STEP_HINTS[TRANSPORT_ERROR])
        if isinstance(error, requests.exceptions.ConnectionError):
            return (TRANSPORT_ERROR, _NEXT_STEP_HINTS[TRANSPORT_ERROR])
        if isinstance(error, requests.exceptions.RequestException):
            return (TRANSPORT_ERROR, _NEXT_STEP_HINTS[TRANSPORT_ERROR])

    # Phase C: String heuristics (only when structured and exception did not match)
    if msg:
        if re.search(r'\b401\b', msg) or 'invalid_access_token' in msg_lower:
            return (AUTH_ISSUE, _NEXT_STEP_HINTS[AUTH_ISSUE])
        if re.search(r'\b403\b', msg) or 'permission' in msg_lower:
            return (AUTH_ISSUE, "Check providerTaxId and subscription permissions.")
        if 'LCLM_PS_105' in msg or 'LCLM_PS_202' in msg:
            return (UNSUPPORTED_PAYER, _NEXT_STEP_HINTS[UNSUPPORTED_PAYER])
        if 'MISSING_REQUIRED_FIELD' in msg or ('member' in msg_lower and 'mandatory' in msg_lower):
            return (MEMBER_REQUIRED, _NEXT_STEP_HINTS[MEMBER_REQUIRED])
        if 'LCLM_PS_203' in msg:
            return (NO_DATA, "Restart pagination (omit transactionId) or retry soon; the pagination token may be expired.")
        if 'LCLM_PS_201' in msg:
            return (NO_DATA, _NEXT_STEP_HINTS[NO_DATA])
        if 'timeout' in msg_lower or 'connection' in msg_lower:
            return (TRANSPORT_ERROR, _NEXT_STEP_HINTS[TRANSPORT_ERROR])
        if ('not supported' in msg_lower or 'pspfns' in msg_lower or
                'payer_not_supported' in msg or 'payer_not_in_defaults' in msg):
            return (UNSUPPORTED_PAYER, "Payer not supported for this operation; try UHCAPI if configured.")

    return (TRANSPORT_ERROR, _NEXT_STEP_HINTS[TRANSPORT_ERROR])


def next_step_hint(reason_code):
    """Return actionable next-step hint for a reason code. Default if unknown."""
    if not reason_code:
        return _DEFAULT_HINT
    return _NEXT_STEP_HINTS.get(reason_code, _DEFAULT_HINT)


def is_suppressible(reason_code):
    """True for member_required, auth_issue. False for no_data, transport_error, others."""
    return reason_code in (MEMBER_REQUIRED, AUTH_ISSUE)
