#!/usr/bin/env python
"""
Run-centric cloud artifact tooling.

This module keeps run-id discovery/index/triage builders separate from
cloud_readiness.py orchestration wrappers.
"""
from __future__ import print_function

import os
import re
import time


ARTIFACT_PHASE_LAYOUT = (
    {
        'code': 'B',
        'name': 'Discovery',
        'required': (
            {'label': 'summary', 'prefix': 'artifact_discovery_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'manifest', 'prefix': 'artifact_manifest_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'C',
        'name': 'Ingest',
        'required': (
            {'label': 'summary', 'prefix': 'ingest_write_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'anomalies', 'prefix': 'ingest_write_anomalies_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'D',
        'name': 'QA',
        'required': (
            {'label': 'summary', 'prefix': 'qa_canonical_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'reject_samples', 'prefix': 'qa_reject_samples_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'E',
        'name': 'Projection',
        'required': (
            {'label': 'summary', 'prefix': 'projection_parity_summary_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'deviation_samples', 'prefix': 'projection_deviation_samples_', 'suffixes': ('.jsonl',)},
        ),
    },
    {
        'code': 'F',
        'name': 'Shadow Health',
        'required': (
            {'label': 'shadow_report', 'prefix': 'shadow_run_report_', 'suffixes': ('.json', '.txt')},
        ),
        'optional': (
            {'label': 'evidence_index', 'prefix': 'shadow_evidence_index_', 'suffixes': ('.json',)},
            {'label': 'mismatch', 'prefix': 'phase_f_mismatch_', 'suffixes': ('.txt',)},
        ),
    },
)


def append_unique_path(paths, seen, path):
    if not path:
        return
    try:
        norm = os.path.normcase(os.path.abspath(path))
    except Exception:
        norm = str(path)
    if norm in seen:
        return
    seen.add(norm)
    paths.append(path)


def safe_run_token(run_id):
    token = str(run_id or '').strip()
    if not token:
        return 'unknown'
    return re.sub(r'[^A-Za-z0-9._-]+', '_', token)


def collect_group_paths_for_run(reports_dir, run_id, group):
    paths = []
    prefix = group.get('prefix', '')
    suffixes = group.get('suffixes', ()) or ()
    for suffix in suffixes:
        path = os.path.join(reports_dir, '{0}{1}{2}'.format(prefix, run_id, suffix))
        if os.path.isfile(path):
            paths.append(path)
    return paths


def collect_artifact_run_candidates(reports_dir, artifact_phase_layout=None):
    """Collect (mtime, run_id, path) candidates across all known artifact prefixes."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if not reports_dir or not os.path.exists(reports_dir):
        return []
    try:
        names = os.listdir(reports_dir)
    except (IOError, OSError):
        return []
    candidates = []
    for phase in artifact_phase_layout:
        groups = list(phase.get('required', ())) + list(phase.get('optional', ()))
        for group in groups:
            prefix = group.get('prefix', '')
            suffixes = group.get('suffixes', ()) or ()
            for name in names:
                if not name.startswith(prefix):
                    continue
                if not any(name.endswith(suf) for suf in suffixes):
                    continue
                path = os.path.join(reports_dir, name)
                if not os.path.isfile(path):
                    continue
                run_id = name[len(prefix):]
                if '.' in run_id:
                    run_id = run_id.rsplit('.', 1)[0]
                if not run_id:
                    continue
                try:
                    mt = os.path.getmtime(path)
                except (IOError, OSError):
                    mt = 0
                candidates.append((mt, run_id, path))
    return candidates


def recent_artifact_run_ids(reports_dir, limit=20, collect_artifact_run_candidates_fn=None):
    """Return unique run_ids ordered newest-first by artifact mtime."""
    if collect_artifact_run_candidates_fn is None:
        collect_artifact_run_candidates_fn = collect_artifact_run_candidates
    candidates = collect_artifact_run_candidates_fn(reports_dir)
    if not candidates:
        return []
    candidates.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
    run_ids = []
    seen = set()
    for _mt, run_id, _path in candidates:
        if run_id in seen:
            continue
        seen.add(run_id)
        run_ids.append(run_id)
        if len(run_ids) >= int(limit or 20):
            break
    return run_ids


def run_has_required_artifacts(
        reports_dir,
        run_id,
        run_id_by_phase=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None):
    """Return (complete_bool, missing_required_labels)."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    phase_map = run_id_by_phase if isinstance(run_id_by_phase, dict) else {}
    missing = []
    for phase in artifact_phase_layout:
        phase_code = str(phase.get('code', '') or '').strip().upper()
        phase_run_id = str(phase_map.get(phase_code, run_id) or '').strip()
        for group in list(phase.get('required', ())):
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group)
            if not paths:
                missing.append('{0}:{1}'.format(phase.get('code', '?'), group.get('label', 'required')))
    return (len(missing) == 0, missing)


def find_latest_complete_artifact_run_id(
        reports_dir,
        exclude_run_id='',
        recent_artifact_run_ids_fn=None,
        run_has_required_artifacts_fn=None):
    """Return latest run_id where all phase required artifacts are present."""
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids
    if run_has_required_artifacts_fn is None:
        run_has_required_artifacts_fn = run_has_required_artifacts
    exclude = str(exclude_run_id or '').strip()
    for run_id in recent_artifact_run_ids_fn(reports_dir, limit=50):
        if exclude and run_id == exclude:
            continue
        is_complete, _ = run_has_required_artifacts_fn(reports_dir, run_id)
        if is_complete:
            return run_id
    return ''


def find_latest_artifact_run_id(reports_dir, collect_artifact_run_candidates_fn=None):
    if collect_artifact_run_candidates_fn is None:
        collect_artifact_run_candidates_fn = collect_artifact_run_candidates
    candidates = collect_artifact_run_candidates_fn(reports_dir)
    if not candidates:
        return ''
    candidates.sort(key=lambda item: (item[0], item[1], item[2]))
    return candidates[-1][1]


def _phase_codes(artifact_phase_layout):
    return [str(x.get('code', '') or '').strip().upper() for x in (artifact_phase_layout or []) if x.get('code')]


def _build_single_token_phase_map(run_id, artifact_phase_layout):
    rid = str(run_id or '').strip()
    out = {}
    for code in _phase_codes(artifact_phase_layout):
        out[code] = rid
    return out


def _extract_run_id_from_group_path(path, group):
    if not path:
        return ''
    name = os.path.basename(str(path))
    prefix = str(group.get('prefix', '') or '')
    suffixes = group.get('suffixes', ()) or ()
    if not prefix or not name.startswith(prefix):
        return ''
    for suffix in suffixes:
        if suffix and name.endswith(suffix):
            return name[len(prefix):-len(suffix)]
    return ''


def _extract_phase_run_id_from_path(path, phase):
    groups = list(phase.get('required', ())) + list(phase.get('optional', ()))
    for group in groups:
        rid = _extract_run_id_from_group_path(path, group)
        if rid:
            return rid
    return ''


def _phase_run_ids_from_shadow_report(
        reports_dir,
        run_id,
        artifact_phase_layout=None,
        load_json_dict_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    json_path = os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(run_id))
    if not os.path.isfile(json_path):
        return ({}, 'shadow_report_json_missing')
    report = load_json_dict_fn(json_path)
    source_paths = report.get('source_summary_paths', []) if isinstance(report.get('source_summary_paths', []), list) else []
    if not source_paths:
        return ({}, 'shadow_report_missing_source_summary_paths')
    phase_run_ids = {}
    phase_layout_no_f = [x for x in artifact_phase_layout if str(x.get('code', '') or '').strip().upper() != 'F']
    for candidate in source_paths:
        if not candidate or str(candidate) == '__MISSING__':
            continue
        for phase in phase_layout_no_f:
            code = str(phase.get('code', '') or '').strip().upper()
            rid = _extract_phase_run_id_from_path(candidate, phase)
            if rid:
                phase_run_ids[code] = rid
                break
    return (phase_run_ids, 'shadow_report_source_summary_paths')


def _evaluate_phase_rows(
        reports_dir,
        run_id_by_phase,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        append_unique_path_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path

    rows = []
    all_files = []
    seen_all = set()
    missing_required = []
    required_hits = 0
    required_total = 0

    for phase in artifact_phase_layout:
        phase_code = str(phase.get('code', '') or '').strip().upper()
        phase_run_id = str((run_id_by_phase or {}).get(phase_code, '') or '').strip()
        required_groups = list(phase.get('required', ()))
        optional_groups = list(phase.get('optional', ()))
        phase_files = []
        seen_phase = set()
        required_missing = []
        required_met = True
        has_any = False

        for group in required_groups:
            required_total += 1
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group) if phase_run_id else []
            if not paths:
                required_met = False
                required_missing.append(group.get('label', 'required'))
                continue
            required_hits += 1
            has_any = True
            for path in paths:
                append_unique_path_fn(phase_files, seen_phase, path)
                append_unique_path_fn(all_files, seen_all, path)

        for group in optional_groups:
            paths = collect_group_paths_for_run_fn(reports_dir, phase_run_id, group) if phase_run_id else []
            if paths:
                has_any = True
            for path in paths:
                append_unique_path_fn(phase_files, seen_phase, path)
                append_unique_path_fn(all_files, seen_all, path)

        if required_met:
            status = 'complete'
        elif has_any:
            status = 'partial'
        else:
            status = 'missing'
        if required_missing:
            missing_required.append('{0}:{1}'.format(phase.get('code', '?'), ','.join(required_missing)))
        rows.append({
            'code': phase.get('code', '?'),
            'name': phase.get('name', 'Phase'),
            'status': status,
            'required_missing': required_missing,
            'resolved_run_id': phase_run_id or '-',
            'files': phase_files,
        })

    return {
        'rows': rows,
        'artifact_files': all_files,
        'missing_required': missing_required,
        'required_hits': int(required_hits),
        'required_total': int(required_total),
    }


def decide_run_artifact_resolution(
        reports_dir,
        run_id,
        diagnostics_state,
        pipeline_running=False,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        load_json_dict_fn=None,
        append_unique_path_fn=None):
    """Auto-decide artifact resolution path for runbook generation."""
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path

    resolved_run_id = str(run_id or '').strip()
    state = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    last_pipeline_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    state_phase_map_raw = state.get('last_shadow_pipeline_phase_run_ids', {})
    state_phase_map_raw = state_phase_map_raw if isinstance(state_phase_map_raw, dict) else {}
    is_last_pipeline_root = bool(last_pipeline_run_id and last_pipeline_run_id == resolved_run_id)
    is_active_pipeline_root = bool(pipeline_running and active_run_id and active_run_id == resolved_run_id)
    state_map_is_anchored = bool(is_last_pipeline_root or is_active_pipeline_root)

    single_map = _build_single_token_phase_map(resolved_run_id, artifact_phase_layout)
    single_eval = _evaluate_phase_rows(
        reports_dir,
        single_map,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        append_unique_path_fn=append_unique_path_fn,
    )

    decision = {
        'decision': 'single_token',
        'confidence': 'high',
        'reason': 'single_run_id_lookup',
        'notes': [],
        'pipeline_run_id': resolved_run_id,
        'run_id_by_phase': single_map,
        'evaluation': single_eval,
    }

    shadow_json = os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(resolved_run_id))
    pipeline_candidate = bool(
        resolved_run_id and (
            resolved_run_id == last_pipeline_run_id
            or os.path.isfile(shadow_json)
        )
    )
    if not pipeline_candidate:
        decision['reason'] = 'requested_run_not_pipeline_root'
        return decision

    # Candidate 1: diagnostics_state phase map
    map_state = {}
    for phase in artifact_phase_layout:
        code = str(phase.get('code', '') or '').strip().upper()
        if code == 'F':
            continue
        rid = str(state_phase_map_raw.get(code, '') or '').strip()
        if rid:
            map_state[code] = rid
    has_full_state_map = all(map_state.get(code, '') for code in ('B', 'C', 'D', 'E'))

    # Candidate 2: shadow report source paths
    map_shadow, shadow_reason = _phase_run_ids_from_shadow_report(
        reports_dir,
        resolved_run_id,
        artifact_phase_layout=artifact_phase_layout,
        load_json_dict_fn=load_json_dict_fn,
    )
    has_full_shadow_map = all(str(map_shadow.get(code, '') or '').strip() for code in ('B', 'C', 'D', 'E'))
    map_state_eval = None
    map_shadow_eval = None

    # Prefer explicit run-local lineage encoded by the requested run's shadow report.
    if has_full_shadow_map:
        candidate_shadow_map = dict(single_map)
        candidate_shadow_map.update(map_shadow)
        map_shadow_eval = _evaluate_phase_rows(
            reports_dir,
            candidate_shadow_map,
            artifact_phase_layout=artifact_phase_layout,
            collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
            append_unique_path_fn=append_unique_path_fn,
        )
        if not map_shadow_eval.get('missing_required'):
            decision.update({
                'decision': 'pipeline_phase_map',
                'confidence': 'medium',
                'reason': shadow_reason,
                'run_id_by_phase': candidate_shadow_map,
                'evaluation': map_shadow_eval,
            })
            decision['notes'].append('Resolved per-phase run IDs from shadow_run_report source_summary_paths.')
            return decision

    # Candidate 1 (fallback): diagnostics_state phase map, only when anchored to requested pipeline root.
    if has_full_state_map and state_map_is_anchored:
        state_shadow_conflict = False
        for code in ('B', 'C', 'D', 'E'):
            shadow_rid = str(map_shadow.get(code, '') or '').strip()
            state_rid = str(map_state.get(code, '') or '').strip()
            if shadow_rid and state_rid and shadow_rid != state_rid:
                state_shadow_conflict = True
                break
        if state_shadow_conflict:
            decision['notes'].append(
                'State phase map conflicts with run-local shadow source lineage; ignoring state map for this run.'
            )
        else:
            candidate_map = dict(single_map)
            candidate_map.update(map_state)
            map_state_eval = _evaluate_phase_rows(
                reports_dir,
                candidate_map,
                artifact_phase_layout=artifact_phase_layout,
                collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
                append_unique_path_fn=append_unique_path_fn,
            )
            if not map_state_eval.get('missing_required'):
                decision.update({
                    'decision': 'pipeline_phase_map',
                    'confidence': 'high',
                    'reason': 'diagnostics_state_phase_map_valid',
                    'run_id_by_phase': candidate_map,
                    'evaluation': map_state_eval,
                })
                decision['notes'].append(
                    'Resolved per-phase run IDs from diagnostics_state.last_shadow_pipeline_phase_run_ids for anchored pipeline root.'
                )
                return decision

    if has_full_state_map and not state_map_is_anchored:
        decision['notes'].append(
            'Ignoring diagnostics_state phase map because requested run is not active/last pipeline root.'
        )

    # If the pipeline is still running for this run_id, keep map semantics to avoid false stale classification.
    if is_active_pipeline_root and has_full_state_map:
        candidate_map = dict(single_map)
        candidate_map.update(map_state)
        if map_state_eval is None:
            map_state_eval = _evaluate_phase_rows(
                reports_dir,
                candidate_map,
                artifact_phase_layout=artifact_phase_layout,
                collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
                append_unique_path_fn=append_unique_path_fn,
            )
        decision.update({
            'decision': 'pipeline_phase_map',
            'confidence': 'low',
            'reason': 'pipeline_active_phase_map_pending',
            'run_id_by_phase': candidate_map,
            'evaluation': map_state_eval,
        })
        decision['notes'].append('Pipeline is active; mapped phase artifacts may still be materializing.')
        return decision

    # Drift guard: if mapped candidates are weaker than single-token, fall back and explain.
    weak_state_map = bool(
        has_full_state_map and map_state_eval is not None
        and len(map_state_eval.get('missing_required', [])) > len(single_eval.get('missing_required', []))
    )
    weak_shadow_map = bool(
        has_full_shadow_map and map_shadow_eval is not None
        and len(map_shadow_eval.get('missing_required', [])) > len(single_eval.get('missing_required', []))
    )
    if weak_state_map or weak_shadow_map:
        decision['reason'] = 'phase_map_state_file_drift_fallback_single_token'
        decision['notes'].append('Phase map exists but produced more required gaps than single-token lookup.')
    elif has_full_state_map and not state_map_is_anchored:
        decision['reason'] = 'state_phase_map_unanchored_fallback_single_token'
        decision['notes'].append('State phase map is not tied to this run_id lineage.')
    elif has_full_state_map or has_full_shadow_map:
        decision['reason'] = 'phase_map_incomplete_fallback_single_token'
        decision['notes'].append('Phase map was available but required artifacts were incomplete.')
    else:
        decision['reason'] = 'pipeline_phase_map_unavailable_fallback_single_token'
        decision['notes'].append('No complete phase map found in diagnostics state or shadow report JSON.')
    return decision


def _find_nearest_complete_run_id_with_decision(
        reports_dir,
        exclude_run_id,
        diagnostics_state,
        pipeline_running,
        recent_artifact_run_ids_fn=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        load_json_dict_fn=None,
        append_unique_path_fn=None):
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if load_json_dict_fn is None:
        load_json_dict_fn = lambda _path: {}
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path
    exclude = str(exclude_run_id or '').strip()
    for candidate_run_id in recent_artifact_run_ids_fn(reports_dir, limit=50):
        if exclude and candidate_run_id == exclude:
            continue
        decision = decide_run_artifact_resolution(
            reports_dir,
            candidate_run_id,
            diagnostics_state,
            pipeline_running=pipeline_running,
            artifact_phase_layout=artifact_phase_layout,
            collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
            load_json_dict_fn=load_json_dict_fn,
            append_unique_path_fn=append_unique_path_fn,
        )
        evaluation = decision.get('evaluation', {}) if isinstance(decision.get('evaluation', {}), dict) else {}
        missing_required = evaluation.get('missing_required', []) if isinstance(evaluation.get('missing_required', []), list) else []
        if not missing_required:
            return candidate_run_id
    return ''


def build_run_artifact_snapshot(
        repo_root,
        run_id='',
        resolve_lab_root_fn=None,
        reports_dir_access_error_fn=None,
        find_latest_artifact_run_id_fn=None,
        load_json_dict_fn=None,
        find_latest_complete_artifact_run_id_fn=None,
        recent_artifact_run_ids_fn=None,
        is_pipeline_running_fn=None,
        artifact_phase_layout=None,
        collect_group_paths_for_run_fn=None,
        append_unique_path_fn=None):
    if artifact_phase_layout is None:
        artifact_phase_layout = ARTIFACT_PHASE_LAYOUT
    if collect_group_paths_for_run_fn is None:
        collect_group_paths_for_run_fn = collect_group_paths_for_run
    if append_unique_path_fn is None:
        append_unique_path_fn = append_unique_path
    if find_latest_artifact_run_id_fn is None:
        find_latest_artifact_run_id_fn = find_latest_artifact_run_id
    if find_latest_complete_artifact_run_id_fn is None:
        find_latest_complete_artifact_run_id_fn = find_latest_complete_artifact_run_id
    if recent_artifact_run_ids_fn is None:
        recent_artifact_run_ids_fn = recent_artifact_run_ids

    lab_root = resolve_lab_root_fn(repo_root)
    reports_dir = os.path.join(lab_root, 'reports')
    reports_err = reports_dir_access_error_fn(lab_root)
    if reports_err:
        return (False, reports_err, None)
    if reports_dir and not os.path.exists(reports_dir):
        return (False, 'No reports directory: {0}'.format(reports_dir), None)

    resolved_run_id = str(run_id or '').strip()
    if not resolved_run_id:
        resolved_run_id = find_latest_artifact_run_id_fn(reports_dir)
    if not resolved_run_id:
        return (False, 'No run-scoped artifacts found in reports directory.', None)

    diagnostics_state = load_json_dict_fn(os.path.join(lab_root, 'diagnostics_state.json'))
    pipeline_running = bool(is_pipeline_running_fn(lab_root))
    resolution = decide_run_artifact_resolution(
        reports_dir,
        resolved_run_id,
        diagnostics_state,
        pipeline_running=pipeline_running,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        load_json_dict_fn=load_json_dict_fn,
        append_unique_path_fn=append_unique_path_fn,
    )
    evaluation = resolution.get('evaluation', {}) if isinstance(resolution.get('evaluation', {}), dict) else {}
    rows = evaluation.get('rows', []) if isinstance(evaluation.get('rows', []), list) else []
    all_files = evaluation.get('artifact_files', []) if isinstance(evaluation.get('artifact_files', []), list) else []
    missing_required = evaluation.get('missing_required', []) if isinstance(evaluation.get('missing_required', []), list) else []

    if not all_files:
        return (False, 'No artifacts found for run_id={0}.'.format(resolved_run_id), None)

    context_files = []
    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        ctx_path = os.path.join(lab_root, ctx_name)
        if os.path.isfile(ctx_path):
            context_files.append(ctx_path)
    recent_run_ids = recent_artifact_run_ids_fn(reports_dir, limit=12)
    nearest_complete_run_id = _find_nearest_complete_run_id_with_decision(
        reports_dir,
        exclude_run_id=resolved_run_id,
        diagnostics_state=diagnostics_state,
        pipeline_running=pipeline_running,
        recent_artifact_run_ids_fn=recent_artifact_run_ids_fn,
        artifact_phase_layout=artifact_phase_layout,
        collect_group_paths_for_run_fn=collect_group_paths_for_run_fn,
        load_json_dict_fn=load_json_dict_fn,
        append_unique_path_fn=append_unique_path_fn,
    )

    return (True, '', {
        'lab_root': lab_root,
        'reports_dir': reports_dir,
        'run_id': resolved_run_id,
        'phase_rows': rows,
        'artifact_files': all_files,
        'context_files': context_files,
        'missing_required': missing_required,
        'diagnostics_state': diagnostics_state,
        'nearest_complete_run_id': nearest_complete_run_id,
        'recent_run_ids': recent_run_ids,
        'pipeline_running': pipeline_running,
        'pipeline_run_id': resolution.get('pipeline_run_id', resolved_run_id),
        'phase_run_ids': resolution.get('run_id_by_phase', {}),
        'resolution_decision': resolution.get('decision', 'single_token'),
        'resolution_confidence': resolution.get('confidence', 'unknown'),
        'resolution_reason': resolution.get('reason', ''),
        'resolution_notes': resolution.get('notes', []),
    })


def write_run_artifact_index(snapshot, latest_alias=False):
    reports_dir = snapshot.get('reports_dir', '')
    run_id = snapshot.get('run_id', '')
    token = safe_run_token(run_id)
    if latest_alias:
        filename = 'run_artifact_index_latest.txt'
    else:
        filename = 'run_artifact_index_{0}.txt'.format(token)
    path = os.path.join(reports_dir, filename)
    lines = []
    lines.append('Run Artifact Index')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('run_id={0}'.format(run_id))
    lines.append('pipeline_run_id={0}'.format(snapshot.get('pipeline_run_id', run_id)))
    lines.append('lab_root={0}'.format(snapshot.get('lab_root', '')))
    lines.append('')
    for row in snapshot.get('phase_rows', []):
        lines.append('[{0}] {1} status={2} resolved_run_id={3}'.format(
            row.get('code', '?'),
            row.get('name', 'Phase'),
            row.get('status', 'missing').upper(),
            row.get('resolved_run_id', '-')))
        missing = row.get('required_missing', [])
        if missing:
            lines.append(' - missing_required={0}'.format(','.join(missing)))
        files = row.get('files', [])
        if files:
            for fp in files:
                lines.append(' - {0}'.format(fp))
        else:
            lines.append(' - (no files)')
        lines.append('')
    if snapshot.get('context_files'):
        lines.append('Context files:')
        for fp in snapshot.get('context_files', []):
            lines.append(' - {0}'.format(fp))
        lines.append('')

    status_counts = {'complete': 0, 'partial': 0, 'missing': 0}
    for row in snapshot.get('phase_rows', []):
        st = row.get('status', 'missing')
        status_counts[st] = status_counts.get(st, 0) + 1
    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    run_id = snapshot.get('run_id', '')
    if active_run_id and run_id == active_run_id:
        alignment = 'active'
    elif last_run_id and run_id == last_run_id:
        alignment = 'last_completed'
    elif active_run_id or last_run_id:
        alignment = 'mismatch'
    else:
        alignment = 'none'

    lines.append('Runbook Interpretation:')
    lines.append(' - phase_counts=complete:{0},partial:{1},missing:{2}'.format(
        status_counts.get('complete', 0),
        status_counts.get('partial', 0),
        status_counts.get('missing', 0),
    ))
    lines.append(' - resolution_decision={0}'.format(snapshot.get('resolution_decision', 'single_token')))
    lines.append(' - resolution_confidence={0}'.format(snapshot.get('resolution_confidence', 'unknown')))
    lines.append(' - resolution_reason={0}'.format(snapshot.get('resolution_reason', '')))
    phase_run_ids = snapshot.get('phase_run_ids', {}) if isinstance(snapshot.get('phase_run_ids', {}), dict) else {}
    if phase_run_ids:
        parts = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            rid = str(phase_run_ids.get(code, '') or '-')
            parts.append('{0}:{1}'.format(code, rid))
        lines.append(' - phase_run_ids={0}'.format(','.join(parts)))
    lines.append(' - run_alignment={0}'.format(alignment))
    lines.append(' - nearest_complete_run_id={0}'.format(snapshot.get('nearest_complete_run_id', '') or '-'))
    lines.append('What To Do Now:')
    if status_counts.get('missing', 0) > 0:
        lines.append(' 1) Treat this run as incomplete for full-phase evidence.')
        lines.append(' 2) Open latest Artifact Triage Pack for consolidated gap/runbook guidance.')
        if snapshot.get('nearest_complete_run_id'):
            lines.append(' 3) Inspect nearest complete run_id={0} for baseline evidence.'.format(
                snapshot.get('nearest_complete_run_id')))
    else:
        lines.append(' 1) This run has required artifacts across B..F; use this index for file-level review.')
        lines.append(' 2) Send latest run evidence bundle if escalation/archive is required.')
    lines.append('')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def write_artifact_triage_pack(snapshot, latest_alias=False):
    reports_dir = snapshot.get('reports_dir', '')
    run_id = snapshot.get('run_id', '')
    token = safe_run_token(run_id)
    if latest_alias:
        filename = 'artifact_triage_pack_latest.txt'
    else:
        filename = 'artifact_triage_pack_{0}.txt'.format(token)
    path = os.path.join(reports_dir, filename)

    status_counts = {'complete': 0, 'partial': 0, 'missing': 0}
    for row in snapshot.get('phase_rows', []):
        st = row.get('status', 'missing')
        status_counts[st] = status_counts.get(st, 0) + 1

    if status_counts.get('missing', 0) > 0:
        overall = 'MISSING'
    elif status_counts.get('partial', 0) > 0:
        overall = 'PARTIAL'
    else:
        overall = 'COMPLETE'

    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    pipeline_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    last_error_code = str(state.get('last_error_code', '') or state.get('last_shadow_pipeline_error_code', '') or '').strip()
    pipeline_running = bool(snapshot.get('pipeline_running'))
    nearest_complete = str(snapshot.get('nearest_complete_run_id', '') or '').strip()
    resolution_decision = str(snapshot.get('resolution_decision', '') or 'single_token').strip()
    resolution_confidence = str(snapshot.get('resolution_confidence', '') or 'unknown').strip()
    resolution_reason = str(snapshot.get('resolution_reason', '') or '').strip()
    resolution_notes = snapshot.get('resolution_notes', []) if isinstance(snapshot.get('resolution_notes', []), list) else []

    reasoning = []
    actions = []
    if overall == 'COMPLETE':
        classification = 'READY'
        reasoning.append('All required phase artifacts (B..F) are present for this run.')
        actions.append('Use run artifact index for detailed file-level verification before handoff.')
        actions.append('Send latest run evidence bundle if you need to escalate or archive evidence.')
    else:
        classification = 'INCOMPLETE'
        if pipeline_state in ('running', 'bootstrapping') and active_run_id and active_run_id == run_id:
            reasoning.append('This run is currently active; missing artifacts may be expected until completion.')
            actions.append('Wait for pipeline completion, then reopen latest Artifact Triage Pack.')
        elif pipeline_state in ('running', 'bootstrapping') and active_run_id and active_run_id != run_id:
            reasoning.append('A different active run exists; this run may be a stale or partial artifact set.')
            actions.append('Inspect active run_id={0} first using run-ID artifact index.'.format(active_run_id))
            actions.append('Reopen latest Artifact Triage Pack after active run settles.')
        else:
            if resolution_decision == 'pipeline_phase_map':
                reasoning.append('Phase-mapped pipeline lineage detected; missing artifacts are relative to mapped per-phase run IDs.')
            elif status_counts.get('complete', 0) <= 1 and status_counts.get('missing', 0) >= 3:
                reasoning.append('Pattern suggests a partial/manual phase run rather than a coherent A->F pipeline run.')
            else:
                reasoning.append('Required artifacts are missing while pipeline is not actively writing them.')
            actions.append('Trigger full shadow pipeline (A->F) from Cloud Readiness Manual Pipeline Control.')
            actions.append('Reopen latest Artifact Triage Pack to confirm all required artifacts appear.')
        if nearest_complete:
            actions.append('Inspect previous coherent run_id={0} for baseline comparison.'.format(nearest_complete))
        actions.append('If blockers remain, send latest run evidence bundle for support triage.')

    run_alignment = 'none'
    if active_run_id and run_id == active_run_id:
        run_alignment = 'active'
    elif last_run_id and run_id == last_run_id:
        run_alignment = 'last_completed'
    elif active_run_id or last_run_id:
        run_alignment = 'mismatch'

    lines = []
    lines.append('Artifact Triage Pack')
    lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
    lines.append('run_id={0}'.format(run_id))
    lines.append('pipeline_run_id={0}'.format(snapshot.get('pipeline_run_id', run_id)))
    lines.append('overall={0}'.format(overall))
    lines.append('phase_counts=complete:{0},partial:{1},missing:{2}'.format(
        status_counts.get('complete', 0),
        status_counts.get('partial', 0),
        status_counts.get('missing', 0),
    ))
    lines.append('')
    lines.append('Phase coverage:')
    for row in snapshot.get('phase_rows', []):
        files = row.get('files', [])
        line = ' - [{0}] {1}: {2} (files={3})'.format(
            row.get('code', '?'),
            row.get('name', 'Phase'),
            row.get('status', 'missing').upper(),
            len(files),
        )
        lines.append(line)
        lines.append('   resolved_run_id={0}'.format(row.get('resolved_run_id', '-')))
        missing = row.get('required_missing', [])
        if missing:
            lines.append('   missing_required={0}'.format(','.join(missing)))
    lines.append('')
    lines.append('Critical gaps:')
    missing_required = snapshot.get('missing_required', [])
    if missing_required:
        for item in missing_required:
            lines.append(' - {0}'.format(item))
    else:
        lines.append(' - none')
    lines.append('')
    lines.append('Runbook Interpretation:')
    lines.append(' - classification={0}'.format(classification))
    for item in reasoning:
        lines.append(' - reasoning: {0}'.format(item))
    lines.append('')
    lines.append('Consequential Diagnostics:')
    lines.append(' - pipeline_state={0}'.format(pipeline_state or 'unknown'))
    lines.append(' - pipeline_lock_running={0}'.format(pipeline_running))
    lines.append(' - active_run_id={0}'.format(active_run_id or '-'))
    lines.append(' - last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'))
    lines.append(' - resolution_decision={0}'.format(resolution_decision))
    lines.append(' - resolution_confidence={0}'.format(resolution_confidence))
    lines.append(' - resolution_reason={0}'.format(resolution_reason or '-'))
    phase_run_ids = snapshot.get('phase_run_ids', {}) if isinstance(snapshot.get('phase_run_ids', {}), dict) else {}
    if phase_run_ids:
        parts = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            rid = str(phase_run_ids.get(code, '') or '-')
            parts.append('{0}:{1}'.format(code, rid))
        lines.append(' - phase_run_ids={0}'.format(','.join(parts)))
    for note in resolution_notes[:3]:
        lines.append(' - resolution_note={0}'.format(note))
    lines.append(' - run_id_alignment={0}'.format(run_alignment))
    lines.append(' - last_error_code={0}'.format(last_error_code or '-'))
    lines.append(' - nearest_complete_run_id={0}'.format(nearest_complete or '-'))
    recent_runs = snapshot.get('recent_run_ids', []) if isinstance(snapshot.get('recent_run_ids', []), list) else []
    if recent_runs:
        lines.append(' - recent_run_ids={0}'.format(','.join(recent_runs[:6])))
    lines.append('')
    lines.append('What To Do Now:')
    step = 1
    for action in actions:
        lines.append(' {0}) {1}'.format(step, action))
        step += 1
    lines.append('')
    lines.append('Tip: open run artifact index for full file paths.')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path


def artifact_bundle_quality(snapshot):
    """Return quality summary for run-evidence bundle decisions."""
    rows = snapshot.get('phase_rows', []) if isinstance(snapshot.get('phase_rows', []), list) else []
    total = len(rows) or 1
    complete = len([r for r in rows if str(r.get('status', '')).lower() == 'complete'])
    partial = len([r for r in rows if str(r.get('status', '')).lower() == 'partial'])
    missing = len([r for r in rows if str(r.get('status', '')).lower() == 'missing'])
    score = int(round((complete * 1.0 + partial * 0.5) / float(total) * 100.0))
    if score >= 90 and missing == 0:
        label = 'HIGH'
    elif score >= 60:
        label = 'MEDIUM'
    else:
        label = 'LOW'
    recommendation = 'send_current_run'
    if label == 'LOW' and snapshot.get('nearest_complete_run_id'):
        recommendation = 'prefer_nearest_complete'
    return {
        'score': score,
        'label': label,
        'complete': complete,
        'partial': partial,
        'missing': missing,
        'recommendation': recommendation,
    }


def build_run_id_diagnostics(snapshot, requested_run_id):
    """Build diagnostics text when explicit run-id inspect fails."""
    if not isinstance(snapshot, dict):
        snapshot = {}
    recent = snapshot.get('recent_run_ids', []) if isinstance(snapshot.get('recent_run_ids', []), list) else []
    state = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state', {}), dict) else {}
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    last_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    nearest_complete = str(snapshot.get('nearest_complete_run_id', '') or '').strip()

    bits = []
    bits.append('Run ID diagnostics for {0}:'.format(requested_run_id))
    bits.append('active_run_id={0}'.format(active_run_id or '-'))
    bits.append('last_shadow_pipeline_run_id={0}'.format(last_run_id or '-'))
    bits.append('nearest_complete_run_id={0}'.format(nearest_complete or '-'))
    if recent:
        bits.append('recent_run_ids={0}'.format(','.join(recent[:8])))
    if active_run_id and requested_run_id != active_run_id:
        bits.append('note=requested run differs from currently active run.')
    if nearest_complete and requested_run_id != nearest_complete:
        bits.append('note=requested run is not latest complete run.')
    return ' '.join(bits)
