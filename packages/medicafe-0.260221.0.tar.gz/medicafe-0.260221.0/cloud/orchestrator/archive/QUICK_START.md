# Quick Start Guide - Running the Setup Scripts

## Important: Where These Scripts Run

**These scripts run on YOUR LOCAL WINDOWS MACHINE** (not inside GCP).

The scripts use the `gcloud` command-line tool to configure your GCP project remotely. Think of it like using a remote control - you run commands from your computer that control things in the cloud.

## Prerequisites

### 1. Install Google Cloud SDK (gcloud CLI)

If you don't have `gcloud` installed:

1. Download from: https://cloud.google.com/sdk/docs/install
2. Run the installer (choose "Windows" version)
3. Open a NEW PowerShell window after installation

### 2. Authenticate with Your Google Account

Run these commands in PowerShell:

```powershell
# Login to your Google account
gcloud auth login

# Set your default project
gcloud config set project genial-analyzer-476721-f8

# Verify you can access the project
gcloud projects describe genial-analyzer-476721-f8
```

If the last command shows project details, you're ready!

## Step-by-Step: Running the Setup Script

### Step 1: Navigate to the Orchestrator Directory

Open PowerShell and navigate to the script location:

```powershell
cd "G:\My Drive\Codes\MediCafe\cloud\orchestrator"
```

### Step 2: Verify the Script Exists

List the files to make sure the script is there:

```powershell
dir *.ps1
```

You should see `setup_gcp.ps1` and `build_and_deploy.ps1`

### Step 3: Run the Setup Script

Execute the PowerShell script (this may take a few minutes):

```powershell
.\setup_gcp.ps1 genial-analyzer-476721-f8
```

**What happens:**
- The script runs commands on your computer
- Each `gcloud` command talks to Google Cloud to create resources
- You'll see progress messages as each step completes

### Step 4: Handle Any Permission Issues

If you see errors about permissions, you may need to:

1. **Enable Billing** on your GCP project (if not already done):
   - Go to: https://console.cloud.google.com/billing?project=genial-analyzer-476721-f8
   - Link a billing account

2. **Grant yourself proper permissions**:
   - Go to: https://console.cloud.google.com/iam-admin/iam?project=genial-analyzer-476721-f8
   - Ensure your account has "Owner" or "Editor" role

### Step 5: Manual Steps After Script Completes

The script will pause and ask you to complete manual steps:

1. **Enable Domain-Wide Delegation** (in Google Workspace Admin Console)
2. **Initialize Firestore** (in GCP Console web interface)
3. **Create Firestore Index** (in GCP Console)

These can't be automated via scripts, so you do them in the web browser.

### Step 6: Deploy Cloud Run

Once manual steps are done, run the deployment script:

```powershell
.\build_and_deploy.ps1 genial-analyzer-476721-f8 YOUR_MAILBOX@domain.com
```

Replace `YOUR_MAILBOX@domain.com` with the actual Gmail address you want to monitor.

## Understanding the Process

Here's what happens when you run the script:

```
Your Computer                Google Cloud Platform
     |                              |
     |----> gcloud command -------->| Creates service account
     |                              |
     |<---- Success message --------| Returns confirmation
     |                              |
     |----> gcloud command -------->| Creates storage bucket
     |                              |
     |<---- Success message --------| Returns confirmation
     |                              |
     ... (and so on)
```

The script is just automating many `gcloud` commands you could run manually.

## Troubleshooting

### "gcloud: command not found"
- Google Cloud SDK is not installed
- Solution: Install from https://cloud.google.com/sdk/docs/install

### "Permission denied" errors
- Your Google account doesn't have access to the project
- Solution: Verify you're logged in: `gcloud auth list`
- Verify project access: `gcloud projects describe genial-analyzer-476721-f8`

### "API not enabled" errors
- Some APIs need to be enabled
- Solution: The script tries to enable them, but you may need to enable billing first

### Script execution policy error in PowerShell
If you see: "cannot be loaded because running scripts is disabled"

Run this first:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## Need Help?

If you get stuck at any step, note:
- The exact error message
- What step you were on
- Any output from the script

Then we can troubleshoot together!





