"""Cleanup helpers invoked when the XP agent acknowledges delivery."""

from __future__ import annotations

import logging
from typing import Dict, List

from config import Config
import services


LOGGER = logging.getLogger("medilink.orchestrator.cleanup")


def _delete_gcs_objects(files: List[Dict[str, str]], config: Config) -> None:
    if not files:
        return
    storage_client = services.storage_client(config)
    bucket = storage_client.bucket(config.gcs_bucket)
    for file_info in files:
        gcs_path = file_info.get("gcs_path")
        if not gcs_path:
            continue
        blob = bucket.blob(gcs_path)
        try:
            blob.delete()
            LOGGER.info("Deleted GCS object %s", gcs_path)
        except Exception as exc:  # pragma: no cover - best effort cleanup
            LOGGER.warning("Failed to delete %s: %s", gcs_path, exc)


def _mark_thread_processed(queue_doc: Dict[str, any], config: Config) -> None:
    if not config.gmail_processed_label and not config.gmail_remove_labels:
        return
    thread_id = queue_doc.get("thread_id")
    if not thread_id:
        return
    gmail_client = services.gmail_client(config)
    body = {}
    if config.gmail_processed_label:
        body.setdefault("addLabelIds", []).append(config.gmail_processed_label)
    if config.gmail_remove_labels:
        body.setdefault("removeLabelIds", []).extend(config.gmail_remove_labels)
    try:
        gmail_client.users().threads().modify(userId="me", id=thread_id, body=body).execute()
        LOGGER.info("Marked thread %s processed", thread_id)
    except Exception as exc:  # pragma: no cover - cleanup best effort
        LOGGER.warning("Failed to mark thread %s processed: %s", thread_id, exc)


def perform_cleanup(queue_doc: Dict[str, any], config: Config) -> None:
    files = queue_doc.get("files", [])
    if config.cleanup_gcs_files:
        _delete_gcs_objects(files, config)
    _mark_thread_processed(queue_doc, config)

