#!/usr/bin/env python3
"""Validate and auto-complete MediLink cloud orchestrator setup."""

from __future__ import annotations

import sys
from typing import Optional, Sequence

if __package__:
    from .setup_common import _configure_color, _require_python_311
    from .setup_flow import gather_config_interactive, parse_args, run_checks
else:
    from setup_common import _configure_color, _require_python_311
    from setup_flow import gather_config_interactive, parse_args, run_checks


def main(argv: Optional[Sequence[str]] = None) -> int:
    _require_python_311()
    args = parse_args(argv)
    _configure_color(getattr(args, "color", "auto"))
    args = gather_config_interactive(args)
    return run_checks(args)


if __name__ == "__main__":
    sys.exit(main())
