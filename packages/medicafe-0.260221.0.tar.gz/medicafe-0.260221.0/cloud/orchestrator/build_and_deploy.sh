#!/bin/bash
# Build and Deploy Cloud Run Service
# Usage: ./build_and_deploy.sh PROJECT_ID MAILBOX_USER [ADMIN_SECRET]

set -e

PROJECT_ID="${1}"
MAILBOX_USER="${2}"
ADMIN_SECRET="${3}"

if [ -z "$PROJECT_ID" ] || [ -z "$MAILBOX_USER" ]; then
    echo "Usage: $0 PROJECT_ID MAILBOX_USER [ADMIN_SECRET]"
    echo "Example: $0 my-medilink-project gmail_shared@domain.com"
    exit 1
fi

# Generate admin secret if not provided
if [ -z "$ADMIN_SECRET" ]; then
    ADMIN_SECRET=$(openssl rand -hex 16)
    echo "Generated ADMIN_SHARED_SECRET: ${ADMIN_SECRET}"
    echo "⚠️  Save this secret - you'll need it for Cloud Scheduler!"
fi

# Set the project
gcloud config set project ${PROJECT_ID}

echo "=== Building Docker image ==="
IMAGE_NAME="gcr.io/${PROJECT_ID}/medilink-gmail-orchestrator"
gcloud builds submit --tag ${IMAGE_NAME} .

echo ""
echo "=== Deploying Cloud Run Service ==="
SA_EMAIL="medilink-gmail-orchestrator@${PROJECT_ID}.iam.gserviceaccount.com"
BUCKET_NAME="medilink-gmail-staging"

gcloud run deploy medilink-gmail-orchestrator \
  --project ${PROJECT_ID} \
  --image ${IMAGE_NAME} \
  --region us-central1 \
  --no-allow-unauthenticated \
  --service-account ${SA_EMAIL} \
  --set-env-vars "PROJECT_ID=${PROJECT_ID}" \
  --set-env-vars "MAILBOX_USER=${MAILBOX_USER}" \
  --set-env-vars "GCS_BUCKET=${BUCKET_NAME}" \
  --set-env-vars "FIRESTORE_QUEUE_COLLECTION=queues" \
  --set-env-vars "FIRESTORE_STATE_COLLECTION=sync_state" \
  --set-env-vars "SIGNED_URL_TTL_SECONDS=3600" \
  --set-env-vars "JWT_ISSUER=medilink-orchestrator" \
  --set-env-vars "JWT_AUDIENCE=medilink-xp-agent" \
  --set-env-vars "GMAIL_PROCESSED_LABEL=Label_Processed" \
  --set-env-vars "GMAIL_REMOVE_LABEL_IDS=INBOX" \
  --set-env-vars "CLEANUP_GCS_FILES=true" \
  --set-env-vars "READY_BATCH_SIZE=10" \
  --set-env-vars "ADMIN_SHARED_SECRET=${ADMIN_SECRET}" \
  --memory 512Mi \
  --cpu 1 \
  --timeout 300

echo ""
echo "=== Getting Service URL ==="
SERVICE_URL=$(gcloud run services describe medilink-gmail-orchestrator \
  --project ${PROJECT_ID} \
  --region us-central1 \
  --format="value(status.url)")

echo "Cloud Run service deployed at: ${SERVICE_URL}"
echo ""
echo "⚠️  IMPORTANT: You need to set up SERVICE_ACCOUNT_JSON environment variable"
echo "Option 1: Add to Cloud Run secrets (recommended)"
echo "Option 2: Set as environment variable with base64-encoded JSON"
echo ""
echo "Next steps:"
echo "1. Set SERVICE_ACCOUNT_JSON in Cloud Run (or GOOGLE_APPLICATION_CREDENTIALS)"
echo "2. Create Pub/Sub subscription pointing to: ${SERVICE_URL}/pubsub/push"
echo "3. Register Gmail watch using tools/gmail_watch_bootstrap.py"
echo ""



















