"""Unit tests for AUTH_MODE-conditioned OAuth secret checks.

Tests verify: dwd_required + OAuth missing -> pass with advisory;
dwd_required + OAuth present -> pass; dwd_preferred + OAuth missing -> fail;
dwd_preferred + OAuth present -> pass; env unreadable -> treat as dwd_preferred.
"""

import unittest
from unittest import mock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestAuthModeOAuthLogic(unittest.TestCase):
    """Test auth-mode aware OAuth secret requirement logic."""

    def test_dwd_required_oauth_missing_advisory_pass(self):
        """dwd_required + OAuth missing -> pass with advisory warning."""
        from setup_flow import _get_auth_mode_from_cloud_run, _result, _VALID_AUTH_MODES

        with mock.patch("setup_flow._get_cloud_run_env") as mock_env:
            mock_env.return_value = {"AUTH_MODE": "dwd_required"}
            mode, readable = _get_auth_mode_from_cloud_run("p", "r", "s")
            self.assertEqual(mode, "dwd_required")
            self.assertTrue(readable)

        # When dwd_required and any secret missing, we add advisory pass
        secret_ok = False
        auth_mode = "dwd_required"
        if auth_mode == "dwd_required" and not secret_ok:
            res = _result(
                "OAuth secrets (advisory)",
                True,
                "AUTH_MODE=dwd_required; OAuth secrets not required for steady state. Missing: x. Keep for rollback if desired.",
            )
            self.assertTrue(res.ok)
            self.assertIn("OAuth secrets not required", res.detail)

    def test_dwd_required_oauth_present_pass(self):
        """dwd_required + OAuth present -> pass (use raw checks, all ok)."""
        auth_mode = "dwd_required"
        secret_client_ok = secret_secret_ok = secret_refresh_ok = True
        if auth_mode == "dwd_required" and not (secret_client_ok and secret_secret_ok and secret_refresh_ok):
            add_advisory = True
        else:
            add_advisory = False
        self.assertFalse(add_advisory)

    def test_dwd_preferred_oauth_missing_fail(self):
        """dwd_preferred + OAuth missing -> fail with manual steps."""
        from setup_flow import _get_auth_mode_from_cloud_run

        with mock.patch("setup_flow._get_cloud_run_env") as mock_env:
            mock_env.return_value = {"AUTH_MODE": "dwd_preferred"}
            mode, _ = _get_auth_mode_from_cloud_run("p", "r", "s")
            self.assertEqual(mode, "dwd_preferred")

        auth_mode = "dwd_preferred"
        secret_ok = False
        if auth_mode == "dwd_required" and not secret_ok:
            add_advisory = True
        else:
            add_advisory = False
        self.assertFalse(add_advisory)
        # Raw checks would fail

    def test_dwd_preferred_oauth_present_pass(self):
        """dwd_preferred + OAuth present -> pass."""
        auth_mode = "dwd_preferred"
        secret_ok = True
        if auth_mode == "dwd_required" and not secret_ok:
            add_advisory = True
        else:
            add_advisory = False
        self.assertFalse(add_advisory)

    def test_env_unreadable_treat_as_dwd_preferred(self):
        """Env unreadable (mock describe failure) -> treat as dwd_preferred, OAuth required."""
        from setup_flow import _get_auth_mode_from_cloud_run

        with mock.patch("setup_flow._get_cloud_run_env") as mock_env:
            mock_env.return_value = {}
            mode, readable = _get_auth_mode_from_cloud_run("p", "r", "s")
            self.assertEqual(mode, "dwd_preferred")
            self.assertFalse(readable)


if __name__ == "__main__":
    unittest.main()
