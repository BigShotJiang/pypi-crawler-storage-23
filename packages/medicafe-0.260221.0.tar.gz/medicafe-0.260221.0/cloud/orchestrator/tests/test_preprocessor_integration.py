"""Integration tests for preprocessor shadow vs enforce behavior and idempotency."""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from google.cloud import firestore  # noqa: F401
    from config import Config
    from processor import _handle_message, _find_existing_queue_doc, MachineIdResolutionError
    INTEGRATION_DEPS_AVAILABLE = True
except ImportError:
    INTEGRATION_DEPS_AVAILABLE = False

from unittest.mock import Mock, patch, MagicMock


@unittest.skipUnless(INTEGRATION_DEPS_AVAILABLE, "google-cloud-firestore not available")
class TestPreprocessorShadowEnforce(unittest.TestCase):
    """Test shadow vs enforce behavior via processor._handle_message."""

    @patch("processor.services.firestore_client")
    @patch("processor.services.storage_client")
    @patch("processor.services.gmail_client")
    def test_enforce_reject_skips_queue_write(self, mock_gmail, mock_storage, mock_fs):
        """When enforce mode and reject: no queue write, ingest_errors written."""

        config = Mock(spec=Config)
        config.preprocessor_mode = "enforce"
        config.gcs_bucket = "test-bucket"
        config.ingest_errors_collection_path = "ingest_errors"
        config.state_collection_path = "sync_state"
        config.queue_collection_path = "queues"
        config.default_machine_id = "clinic-001"
        config.allowed_sender_domains = None
        config.allowed_attachment_extensions = ["docx", "csv"]

        # Message that will fail preprocessor: missing received_at in raw_candidate
        # But we build raw_candidate from message - message has internalDate
        # So we need a message that produces a reject. Use empty files + not otp.
        message = {
            "id": "msg-123",
            "threadId": "thread-1",
            "historyId": "789",
            "internalDate": "1698879600000",
            "payload": {"headers": [{"name": "Subject", "value": "Test"}]},
        }
        mock_fs_client = MagicMock()
        mock_fs.return_value = mock_fs_client
        mock_storage_client = MagicMock()
        mock_storage.return_value = mock_storage_client
        mock_gmail_client = MagicMock()
        mock_gmail.return_value = mock_gmail_client

        # _extract_machine_id returns default_machine_id
        # _detect_secure_message returns False
        # _collect_attachments returns [] (no attachments)
        # So we get empty_files_not_otp reject
        with patch("processor._persist_queue_entry") as persist_mock:
            with patch("processor._write_ingest_error") as write_mock:
                with patch("processor._collect_attachments", return_value=[]):
                    with patch("processor._extract_machine_id", return_value="clinic-001"):
                        with patch("processor._detect_secure_message", return_value=False):
                            _handle_message(message, mock_gmail_client, mock_storage_client, mock_fs_client, config)

        # Enforce reject: _persist_queue_entry must NOT be called
        self.assertEqual(persist_mock.call_count, 0)
        # ingest_errors must be written
        write_mock.assert_called_once()
        call_kwargs = write_mock.call_args[1]
        self.assertEqual(call_kwargs["message_id"], "msg-123")
        self.assertEqual(call_kwargs["reject_code"], "empty_files_not_otp")

    @patch("processor.services.firestore_client")
    @patch("processor.services.storage_client")
    @patch("processor.services.gmail_client")
    def test_shadow_reject_still_writes_queue(self, mock_gmail, mock_storage, mock_fs):
        """When shadow mode and reject: queue write still happens."""

        config = Mock(spec=Config)
        config.preprocessor_mode = "shadow"
        config.gcs_bucket = "test-bucket"
        config.ingest_errors_collection_path = "ingest_errors"
        config.state_collection_path = "sync_state"
        config.queue_collection_path = "queues"
        config.default_machine_id = "clinic-001"
        config.allowed_sender_domains = None
        config.allowed_attachment_extensions = ["docx", "csv"]

        message = {
            "id": "msg-123",
            "threadId": "thread-1",
            "historyId": "789",
            "internalDate": "1698879600000",
            "payload": {"headers": [{"name": "Subject", "value": "Test"}]},
        }
        mock_fs_client = MagicMock()
        mock_fs.return_value = mock_fs_client
        # _find_existing_queue_doc returns None (no existing)
        mock_fs_client.collection.return_value.where.return_value.limit.return_value.stream.return_value = []
        mock_fs_client.collection.return_value.document.return_value.set = MagicMock()
        mock_fs_client.collection.return_value.document.return_value.get.return_value.exists = False
        mock_storage_client = MagicMock()
        mock_storage.return_value = mock_storage_client
        mock_gmail_client = MagicMock()
        mock_gmail.return_value = mock_gmail_client

        with patch("processor._persist_queue_entry") as persist_mock:
            with patch("processor._write_ingest_error") as write_mock:
                with patch("processor._collect_attachments", return_value=[]):
                    with patch("processor._extract_machine_id", return_value="clinic-001"):
                        with patch("processor._detect_secure_message", return_value=False):
                            _handle_message(message, mock_gmail_client, mock_storage_client, mock_fs_client, config)

        # In shadow mode, queue was written (persist_queue_entry called)
        self.assertEqual(persist_mock.call_count, 1)
        persist_kwargs = persist_mock.call_args[1]
        self.assertEqual(persist_kwargs.get("preprocessor_reject_code"), "empty_files_not_otp")
        # ingest_errors was also written (reject telemetry)
        write_mock.assert_called_once()
        self.assertEqual(write_mock.call_args[1]["reject_code"], "empty_files_not_otp")

    @patch("processor.services.firestore_client")
    @patch("processor.services.storage_client")
    @patch("processor.services.gmail_client")
    def test_machine_id_resolution_failure_writes_ingest_error(self, mock_gmail, mock_storage, mock_fs):
        """When _extract_machine_id raises MachineIdResolutionError: ingest_errors written, no queue write."""

        config = Mock(spec=Config)
        config.preprocessor_mode = "shadow"
        config.gcs_bucket = "test-bucket"
        config.ingest_errors_collection_path = "ingest_errors"
        config.state_collection_path = "sync_state"
        config.queue_collection_path = "queues"
        config.default_machine_id = None
        config.allowed_sender_domains = None
        config.allowed_attachment_extensions = ["docx", "csv"]

        message = {
            "id": "msg-routing-fail",
            "threadId": "thread-1",
            "historyId": "789",
            "internalDate": "1698879600000",
            "payload": {"headers": [{"name": "Subject", "value": "Test"}]},
        }
        mock_fs_client = MagicMock()
        mock_fs.return_value = mock_fs_client
        mock_storage_client = MagicMock()
        mock_storage.return_value = mock_storage_client
        mock_gmail_client = MagicMock()
        mock_gmail.return_value = mock_gmail_client

        with patch("processor._persist_queue_entry") as persist_mock:
            with patch("processor._write_ingest_error") as write_mock:
                with patch(
                    "processor._extract_machine_id",
                    side_effect=MachineIdResolutionError("Unable to determine machine id for message msg-routing-fail"),
                ):
                    _handle_message(message, mock_gmail_client, mock_storage_client, mock_fs_client, config)

        self.assertEqual(persist_mock.call_count, 0)
        write_mock.assert_called_once()
        call_kwargs = write_mock.call_args[1]
        self.assertEqual(call_kwargs["reject_code"], "machine_id_resolution_failure")
        self.assertEqual(call_kwargs["stage"], "processor")
        self.assertEqual(call_kwargs["message_id"], "msg-routing-fail")
        self.assertEqual(call_kwargs["machine_id"], "")

    @patch("processor.services.firestore_client")
    @patch("processor.services.storage_client")
    @patch("processor.services.gmail_client")
    def test_non_machine_exception_writes_ingest_error_and_raises(self, mock_gmail, mock_storage, mock_fs):
        """Unexpected processing exceptions write ingest_errors with deterministic code and are re-raised."""

        config = Mock(spec=Config)
        config.preprocessor_mode = "shadow"
        config.gcs_bucket = "test-bucket"
        config.ingest_errors_collection_path = "ingest_errors"
        config.state_collection_path = "sync_state"
        config.queue_collection_path = "queues"
        config.default_machine_id = "clinic-001"
        config.allowed_sender_domains = None
        config.allowed_attachment_extensions = ["docx", "csv"]

        message = {
            "id": "msg-boom",
            "threadId": "thread-1",
            "historyId": "789",
            "internalDate": "1698879600000",
            "payload": {"headers": [{"name": "Subject", "value": "Test"}]},
        }
        mock_fs_client = MagicMock()
        mock_fs.return_value = mock_fs_client
        mock_storage_client = MagicMock()
        mock_storage.return_value = mock_storage_client
        mock_gmail_client = MagicMock()
        mock_gmail.return_value = mock_gmail_client

        with patch("processor._persist_queue_entry") as persist_mock:
            with patch("processor._write_ingest_error") as write_mock:
                with patch("processor._extract_machine_id", return_value="clinic-001"):
                    with patch("processor._detect_secure_message", return_value=False):
                        with patch("processor._collect_attachments", side_effect=RuntimeError("boom")):
                            with self.assertRaises(RuntimeError):
                                _handle_message(message, mock_gmail_client, mock_storage_client, mock_fs_client, config)

        self.assertEqual(persist_mock.call_count, 0)
        write_mock.assert_called_once()
        call_kwargs = write_mock.call_args[1]
        self.assertEqual(call_kwargs["reject_code"], "processor_unhandled_exception")
        self.assertEqual(call_kwargs["stage"], "processor")
        self.assertEqual(call_kwargs["message_id"], "msg-boom")
        self.assertEqual(call_kwargs["machine_id"], "clinic-001")


@unittest.skipUnless(INTEGRATION_DEPS_AVAILABLE, "google-cloud-firestore not available")
class TestProcessorIdempotency(unittest.TestCase):
    """Test duplicate message_id prevention."""

    def test_find_existing_queue_doc_returns_existing(self):
        """_find_existing_queue_doc finds doc by message_id."""
        from processor import _find_existing_queue_doc
        from config import Config

        config = Mock(spec=Config)
        config.queue_collection_path = "queues"
        mock_fs = MagicMock()
        mock_doc = MagicMock()
        mock_doc.id = "existing-doc-id"
        mock_doc.to_dict.return_value = {"message_id": "msg-1", "acked": False}
        mock_fs.collection.return_value.where.return_value.limit.return_value.stream.return_value = [mock_doc]

        result = _find_existing_queue_doc(mock_fs, config, "msg-1")
        self.assertIsNotNone(result)
        self.assertEqual(result.id, "existing-doc-id")

    def test_find_existing_queue_doc_returns_none_when_missing(self):
        """_find_existing_queue_doc returns None when no match."""

        config = Mock(spec=Config)
        config.queue_collection_path = "queues"
        mock_fs = MagicMock()
        mock_fs.collection.return_value.where.return_value.limit.return_value.stream.return_value = []

        result = _find_existing_queue_doc(mock_fs, config, "msg-1")
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
