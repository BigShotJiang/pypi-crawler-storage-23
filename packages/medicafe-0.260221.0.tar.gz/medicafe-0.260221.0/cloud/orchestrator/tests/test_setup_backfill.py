"""Integration tests for setup-flow _offer_backfill."""

from __future__ import annotations

import sys
import os
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from setup_flow import _offer_backfill
from setup_common import Context


class TestOfferBackfill(unittest.TestCase):
    """Test _offer_backfill integration: prompt yes -> endpoint call -> evidence write."""

    def test_validate_only_skipped(self):
        """validate_only => no endpoint calls."""
        args = MagicMock()
        args.validate_only = True
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="sec", service_account_email="")

        with patch("setup_flow._call_cloud_run_admin_post") as mock_call:
            _offer_backfill(args, ctx)
            mock_call.assert_not_called()

    def test_no_service_url_skipped(self):
        """Missing service_url => no endpoint calls."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="", admin_secret="sec", service_account_email="")

        with patch("setup_flow._call_cloud_run_admin_post") as mock_call:
            _offer_backfill(args, ctx)
            mock_call.assert_not_called()

    def test_no_admin_secret_skipped(self):
        """Missing admin_secret => no endpoint calls."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="", service_account_email="")

        with patch("setup_flow._call_cloud_run_admin_post") as mock_call:
            _offer_backfill(args, ctx)
            mock_call.assert_not_called()

    def test_no_interactive_prints_manual_command(self):
        """--no-interactive => print manual curl command, no prompt."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = False
        ctx = Context(service_url="https://svc.run.app/admin", admin_secret="sec", service_account_email="")

        with patch("setup_flow._call_cloud_run_admin_post") as mock_call:
            with patch("builtins.print") as mock_print:
                _offer_backfill(args, ctx)
                mock_call.assert_not_called()
                printed = "\n".join(str(c) for c in mock_print.call_args_list)
                self.assertIn("backfill-backlog", printed)
                self.assertIn("curl", printed)

    @patch("setup_flow.write_backfill_evidence_artifact")
    @patch("setup_flow._confirm")
    @patch("setup_flow._call_cloud_run_admin_post")
    def test_interactive_has_backlog_yes_runs_and_writes_evidence(
        self,
        mock_call,
        mock_confirm,
        mock_write_evidence,
    ):
        """Interactive, has_backlog, confirm=yes => endpoint called twice, evidence written."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="sec", service_account_email="")

        mock_confirm.return_value = True
        mock_call.side_effect = [
            (True, {"mode": "preview", "has_backlog": True}, ""),
            (True, {"mode": "run", "status": "ok", "scanned_count": 2, "processed_count": 2, "skipped_count": 0, "failed_count": 0}, ""),
        ]
        mock_write_evidence.return_value = "docs/runbooks/evidence/backfill_run_20260212T120000Z_abc12345.json"

        _offer_backfill(args, ctx)

        self.assertEqual(mock_call.call_count, 2)
        self.assertEqual(mock_confirm.call_count, 1)
        run_body = mock_call.call_args_list[1][0][5]
        self.assertNotIn("label_ids", run_body)
        self.assertIn("secret", run_body)
        self.assertIn("batch_size", run_body)
        mock_write_evidence.assert_called_once()
        call_args = mock_write_evidence.call_args[0]
        self.assertEqual(call_args[0]["mode"], "run")
        self.assertEqual(call_args[0]["scanned_count"], 2)
        self.assertEqual(call_args[1], "p")
        self.assertEqual(call_args[2], "s")
        self.assertEqual(call_args[3], "r")

    @patch("setup_flow._call_cloud_run_admin_post")
    def test_interactive_has_backlog_false_skips(self, mock_call):
        """Interactive, has_backlog=false => no run prompt."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="sec", service_account_email="")

        mock_call.return_value = (True, {"mode": "preview", "has_backlog": False}, "")

        _offer_backfill(args, ctx)

        mock_call.assert_called_once()
        self.assertEqual(mock_call.call_args[0][4], "/admin/backfill-backlog")
        self.assertTrue(mock_call.call_args[0][5].get("preview_only"))

    @patch("setup_flow._confirm")
    @patch("setup_flow._call_cloud_run_admin_post")
    def test_interactive_confirm_no_skips_run(self, mock_call, mock_confirm):
        """Interactive, has_backlog, confirm=no => no run call."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="sec", service_account_email="")

        mock_call.return_value = (True, {"mode": "preview", "has_backlog": True}, "")
        mock_confirm.return_value = False

        _offer_backfill(args, ctx)

        self.assertEqual(mock_call.call_count, 1)

    @patch("setup_flow.write_backfill_evidence_artifact")
    @patch("setup_flow._confirm")
    @patch("setup_flow._call_cloud_run_admin_post")
    def test_partial_failure_prints_warning(self, mock_call, mock_confirm, mock_write_evidence):
        """When failed_count > 0, warning is printed."""
        args = MagicMock()
        args.validate_only = False
        args.project_id = "p"
        args.region = "r"
        args.service_name = "s"
        args.interactive = True
        ctx = Context(service_url="https://url", admin_secret="sec", service_account_email="")

        mock_confirm.return_value = True
        mock_call.side_effect = [
            (True, {"mode": "preview", "has_backlog": True}, ""),
            (True, {"mode": "run", "status": "partial_failure", "scanned_count": 2, "processed_count": 1, "skipped_count": 0, "failed_count": 1}, ""),
        ]
        mock_write_evidence.return_value = "docs/runbooks/evidence/backfill_run_20260212T120000Z_abc12345.json"

        with patch("builtins.print") as mock_print:
            _offer_backfill(args, ctx)

        printed = "\n".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("Some messages failed", printed)
        self.assertIn("failed_count=1", printed)


if __name__ == "__main__":
    unittest.main()
