"""Unit tests for alert reconcile decision paths.

Tests: drift detected -> reconcile invoked; no drift -> skip;
drift + no channels provided -> channels never in update mask;
permission-denied -> graceful fail with DECISION.
"""

import unittest
from unittest import mock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestAlertReconcileDecisionPaths(unittest.TestCase):
    """Test alert drift detection and reconcile decision logic."""

    def test_drift_detected_missing_policy(self):
        """Drift detected (missing policy) -> reconcile invoked (exit 1 from check-drift)."""
        from setup_alerting import EXPECTED_POLICY_DISPLAY_NAMES, _check_drift

        args = mock.Mock()
        args.project_id = "test-project"
        args.access_token = None
        args.notification_email = ""
        args.notification_channel = None

        with mock.patch("setup_alerting._access_token", return_value="token"):
            with mock.patch("setup_alerting._list_alert_policies") as mock_list:
                mock_list.return_value = []  # No policies
                exit_code = _check_drift(args)
                self.assertEqual(exit_code, 1)

    def test_no_drift_skip(self):
        """No drift -> skip reconcile (exit 0 from check-drift)."""
        from setup_alerting import _check_drift

        args = mock.Mock()
        args.project_id = "test-project"
        args.access_token = None
        args.notification_email = ""
        args.notification_channel = None

        policies = [
            {"displayName": name, "enabled": True}
            for name in (
                "MediLink Orchestrator - Cloud Run 5xx errors",
                "MediLink Orchestrator - Cloud Run startup or crash logs",
                "MediLink Orchestrator - Scheduler refresh failures",
                "MediLink Orchestrator - PubSub undelivered backlog",
                "MediLink Orchestrator - PubSub oldest unacked age",
                "MediLink Orchestrator - Watch refresh stale",
            )
        ]

        with mock.patch("setup_alerting._access_token", return_value="token"):
            with mock.patch("setup_alerting._list_alert_policies", return_value=policies):
                exit_code = _check_drift(args)
                self.assertEqual(exit_code, 0)

    def test_channels_never_in_update_mask_when_not_provided(self):
        """Drift + no channels provided -> channels never in update mask (guardrail)."""
        from setup_alerting import _upsert_alert_policy

        desired = {
            "displayName": "Test Policy",
            "enabled": True,
            "conditions": [],
        }
        existing = {"Test Policy": {"name": "projects/p/alertPolicies/123", "enabled": True}}
        # channels_explicitly_provided=False: notification_channels must not be in update_fields
        result = _upsert_alert_policy(
            "p", "token", desired, existing, dry_run=True,
            channels_explicitly_provided=False,
        )
        self.assertIn("DRY-RUN update", result)

    def test_permission_denied_graceful_fail(self):
        """Permission-denied on Monitoring API -> graceful fail; DECISION explains."""
        from setup_alerting import _check_drift
        import io

        args = mock.Mock()
        args.project_id = "test-project"
        args.access_token = None
        args.notification_email = ""
        args.notification_channel = None

        with mock.patch("setup_alerting._access_token", return_value="token"):
            with mock.patch("setup_alerting._list_alert_policies") as mock_list:
                mock_list.side_effect = RuntimeError("HTTP 403 for GET ... PERMISSION_DENIED")
                with mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
                    exit_code = _check_drift(args)
                    self.assertEqual(exit_code, 2)
                    out = mock_stdout.getvalue()
                    self.assertIn("DECISION:", out)
                    self.assertTrue("permission denied" in out.lower() or "PERMISSION_DENIED" in out)

    def test_upsert_alert_policy_update_path_non_dry_run(self):
        """Update path (dry_run=False) calls PATCH with correct updateMask."""
        from setup_alerting import _upsert_alert_policy

        desired = {
            "displayName": "Test Policy",
            "enabled": True,
            "conditions": [],
        }
        existing = {"Test Policy": {"name": "projects/p/alertPolicies/123", "enabled": True}}

        with mock.patch("setup_alerting._request_json") as mock_req:
            mock_req.return_value = {}
            result = _upsert_alert_policy(
                "p", "token", desired, existing, dry_run=False,
                channels_explicitly_provided=False,
            )
            self.assertIn("UPDATED", result)
            mock_req.assert_called_once()
            call_args = mock_req.call_args
            self.assertEqual(call_args[0][0], "PATCH")
            url = call_args[0][1]
            self.assertIn("updateMask=", url)
            self.assertIn("display_name", url)

    def test_permission_denied_does_not_trigger_reconcile(self):
        """When check-drift returns 2 (cannot assess), reconcile must NOT run."""
        from setup_flow import _run_alert_drift_reconcile
        import io

        args = mock.Mock()
        args.project_id = "test-project"
        args.service_name = "medilink-gmail-orchestrator"
        args.scheduler_job = "gmail-watch-refresh"
        args.subscription = "gmail-new-emails-sub"
        args.mailbox_user = "daniel@strategicimplementation.us"

        with mock.patch("setup_flow._run", return_value=mock.Mock(returncode=0, stdout="token\n")):
            with mock.patch("setup_flow.subprocess.run") as mock_run:
                mock_run.return_value = mock.Mock(returncode=2)
                with mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
                    ok, summary = _run_alert_drift_reconcile(args)
                    out = mock_stdout.getvalue()
                    self.assertTrue(ok)
                    self.assertIn("not assessable", summary)
                    self.assertIn("cannot assess drift", out)
                self.assertIn("skipping reconcile", out)
                self.assertEqual(mock_run.call_count, 1)

    def test_reconcile_failure_surfaces(self):
        """When reconcile subprocess returns non-zero, DECISION is emitted."""
        from setup_flow import _run_alert_drift_reconcile
        import io

        args = mock.Mock()
        args.project_id = "test-project"
        args.service_name = "medilink-gmail-orchestrator"
        args.scheduler_job = "gmail-watch-refresh"
        args.subscription = "gmail-new-emails-sub"
        args.mailbox_user = "daniel@strategicimplementation.us"

        def run_side_effect(cmd, **kwargs):
            if "--check-drift" in cmd:
                return mock.Mock(returncode=1)
            return mock.Mock(returncode=99)

        with mock.patch("setup_flow._run", return_value=mock.Mock(returncode=0, stdout="token\n")):
            with mock.patch("setup_flow.subprocess.run", side_effect=run_side_effect):
                with mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
                    result, summary = _run_alert_drift_reconcile(args)
                    out = mock_stdout.getvalue()
                    self.assertFalse(result)
                    self.assertIn("reconcile failed", summary)
                    self.assertIn("alert reconcile failed", out)
                self.assertIn("99", out)


if __name__ == "__main__":
    unittest.main()
