"""Unit tests for preprocessor gate metrics without real Firestore dependency."""

from __future__ import annotations

import datetime as dt
import os
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import preprocessor_gate


class _FakeDoc:
    def __init__(self, data, exists=True):
        self._data = data
        self.exists = exists

    def to_dict(self):
        return dict(self._data or {})


class _FakeDocRef:
    def __init__(self, doc):
        self._doc = doc

    def get(self):
        return self._doc


class _FakeCollection:
    def __init__(self, docs=None, named_docs=None):
        self._docs = docs or []
        self._named_docs = named_docs or {}

    def stream(self):
        return iter(self._docs)

    def where(self, *_args, **_kwargs):
        # Query filter support is not required for this unit test.
        return self

    def document(self, name):
        return _FakeDocRef(self._named_docs.get(name, _FakeDoc({}, exists=False)))


class _FakeClient:
    def __init__(self, collections):
        self._collections = collections

    def collection(self, name):
        return self._collections[name]


class TestPreprocessorGate(unittest.TestCase):
    def _build_fake_firestore(self, queue_docs, ingest_docs):
        shadow_started_at = dt.datetime(2026, 2, 1, tzinfo=dt.timezone.utc)
        collections = {
            "sync_state": _FakeCollection(
                named_docs={
                    "preprocessor": _FakeDoc(
                        {"shadow_started_at": shadow_started_at},
                        exists=True,
                    )
                }
            ),
            "queues": _FakeCollection(docs=queue_docs),
            "ingest_errors": _FakeCollection(docs=ingest_docs),
        }
        fake_client = _FakeClient(collections)
        fake_firestore_mod = types.SimpleNamespace(Client=lambda project: fake_client)
        return fake_firestore_mod

    def test_dropped_without_repair_count_detected(self):
        created = dt.datetime(2026, 2, 2, tzinfo=dt.timezone.utc)
        queue_docs = [
            _FakeDoc({"message_id": "m1", "attempt_id": "a1", "created_at": created}),
            _FakeDoc(
                {
                    "message_id": "m2",
                    "attempt_id": "a2",
                    "preprocessor_reject_code": "empty_files_not_otp",
                    "created_at": created,
                }
            ),
        ]
        ingest_docs = []
        fake_firestore = self._build_fake_firestore(queue_docs, ingest_docs)

        with patch.object(preprocessor_gate, "FIRESTORE_AVAILABLE", True):
            with patch.object(preprocessor_gate, "firestore", fake_firestore):
                passed, reason, metrics = preprocessor_gate.check_preprocessor_gate(
                    "proj",
                    queue_collection="queues",
                    state_collection="sync_state",
                    ingest_errors_collection="ingest_errors",
                    preprocessor_mode="shadow",
                )

        self.assertFalse(passed)
        self.assertIsNotNone(metrics)
        self.assertEqual(metrics.dropped_without_repair_record_count, 1)
        # Gate should still fail first on sample size threshold.
        self.assertIn("unique_shadow_processed_count", reason or "")

    def test_dropped_without_repair_count_zero_when_repair_exists(self):
        created = dt.datetime(2026, 2, 2, tzinfo=dt.timezone.utc)
        queue_docs = [
            _FakeDoc(
                {
                    "message_id": "m2",
                    "attempt_id": "a2",
                    "preprocessor_reject_code": "empty_files_not_otp",
                    "created_at": created,
                }
            ),
        ]
        ingest_docs = [
            _FakeDoc(
                {
                    "message_id": "m2",
                    "attempt_id": "a2",
                    "reject_code": "empty_files_not_otp",
                    "created_at": created,
                }
            )
        ]
        fake_firestore = self._build_fake_firestore(queue_docs, ingest_docs)

        with patch.object(preprocessor_gate, "FIRESTORE_AVAILABLE", True):
            with patch.object(preprocessor_gate, "firestore", fake_firestore):
                _passed, _reason, metrics = preprocessor_gate.check_preprocessor_gate(
                    "proj",
                    queue_collection="queues",
                    state_collection="sync_state",
                    ingest_errors_collection="ingest_errors",
                    preprocessor_mode="shadow",
                )

        self.assertIsNotNone(metrics)
        self.assertEqual(metrics.dropped_without_repair_record_count, 0)

    def test_processor_stage_code_not_unknown(self):
        """Processor-stage machine_id_resolution_failure is known; does not inflate unknown_reject_code_count."""

        created = dt.datetime(2026, 2, 2, tzinfo=dt.timezone.utc)
        queue_docs = [
            _FakeDoc({"message_id": "m1", "attempt_id": "a1", "created_at": created}),
        ]
        ingest_docs = [
            _FakeDoc(
                {
                    "message_id": "m2",
                    "attempt_id": "a2",
                    "reject_code": "machine_id_resolution_failure",
                    "stage": "processor",
                    "created_at": created,
                }
            ),
        ]
        fake_firestore = self._build_fake_firestore(queue_docs, ingest_docs)

        with patch.object(preprocessor_gate, "FIRESTORE_AVAILABLE", True):
            with patch.object(preprocessor_gate, "firestore", fake_firestore):
                _passed, _reason, metrics = preprocessor_gate.check_preprocessor_gate(
                    "proj",
                    queue_collection="queues",
                    state_collection="sync_state",
                    ingest_errors_collection="ingest_errors",
                    preprocessor_mode="shadow",
                )

        self.assertIsNotNone(metrics)
        self.assertEqual(metrics.unknown_reject_code_count, 0)


if __name__ == "__main__":
    unittest.main()
