"""Unit tests for preprocessor promotion logic."""

from __future__ import annotations

import os
import sys
import tempfile
import json
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from setup_flow import _ensure_subscription, _maybe_promote_preprocessor_enforce
from setup_evidence import write_gate_snapshot_artifact


class _FakeMetrics:
    unique_shadow_processed_count = 60
    unknown_reject_code_count = 0
    preprocess_unhandled_exception_count = 0
    duplicate_queue_doc_count_by_message_id = 0
    dropped_without_repair_record_count = 0
    reject_count = 0
    mode = "shadow"


class TestMaybePromotePreprocessorEnforce(unittest.TestCase):
    """Test _maybe_promote_preprocessor_enforce helper."""

    def test_validate_only_no_mutation(self):
        """validate_only=True => no mutation (return False, env unchanged)."""
        args = MagicMock()
        args.validate_only = True
        args.promote_preprocessor_enforce = True
        args.interactive = True
        env = {"PREPROCESSOR_MODE": "shadow"}
        update_mock = MagicMock()
        result = _maybe_promote_preprocessor_enforce(
            args, validate_only=True, gate_passed=True, env=env,
            project_id="p", region="r", service_name="s",
            update_fn=update_mock,
        )
        self.assertFalse(result)
        update_mock.assert_not_called()
        self.assertEqual(env.get("PREPROCESSOR_MODE"), "shadow")

    def test_interactive_confirm_false_no_mutation(self):
        """interactive=True, confirm returns False => no mutation."""
        args = MagicMock()
        args.promote_preprocessor_enforce = True
        args.interactive = True
        env = {"PREPROCESSOR_MODE": "shadow"}
        update_mock = MagicMock()
        confirm_mock = MagicMock(return_value=False)
        result = _maybe_promote_preprocessor_enforce(
            args, validate_only=False, gate_passed=True, env=env,
            project_id="p", region="r", service_name="s",
            update_fn=update_mock, confirm_fn=confirm_mock,
        )
        self.assertFalse(result)
        update_mock.assert_not_called()
        confirm_mock.assert_called_once()

    def test_interactive_confirm_true_mutation_applied(self):
        """interactive=True, confirm returns True => mutation applied."""
        args = MagicMock()
        args.promote_preprocessor_enforce = True
        args.interactive = True
        env = {"PREPROCESSOR_MODE": "shadow"}
        update_mock = MagicMock()
        update_mock.return_value = MagicMock(returncode=0)
        confirm_mock = MagicMock(return_value=True)
        result = _maybe_promote_preprocessor_enforce(
            args, validate_only=False, gate_passed=True, env=env,
            project_id="p", region="r", service_name="s",
            update_fn=update_mock, confirm_fn=confirm_mock,
        )
        self.assertTrue(result)
        update_mock.assert_called_once()
        self.assertEqual(env["PREPROCESSOR_MODE"], "enforce")

    def test_non_interactive_flag_and_gate_mutation_applied(self):
        """interactive=False, gate pass + flag => mutation applied (no prompt)."""
        args = MagicMock()
        args.promote_preprocessor_enforce = True
        args.interactive = False
        env = {"PREPROCESSOR_MODE": "shadow"}
        update_mock = MagicMock()
        update_mock.return_value = MagicMock(returncode=0)
        confirm_mock = MagicMock()
        result = _maybe_promote_preprocessor_enforce(
            args, validate_only=False, gate_passed=True, env=env,
            project_id="p", region="r", service_name="s",
            update_fn=update_mock, confirm_fn=confirm_mock,
        )
        self.assertTrue(result)
        confirm_mock.assert_not_called()
        update_mock.assert_called_once()

    def test_gate_fail_no_mutation(self):
        """gate_passed=False => no mutation."""
        args = MagicMock()
        args.promote_preprocessor_enforce = True
        env = {"PREPROCESSOR_MODE": "shadow"}
        update_mock = MagicMock()
        result = _maybe_promote_preprocessor_enforce(
            args, validate_only=False, gate_passed=False, env=env,
            project_id="p", region="r", service_name="s",
            update_fn=update_mock,
        )
        self.assertFalse(result)
        update_mock.assert_not_called()


class TestWriteGateSnapshotArtifact(unittest.TestCase):
    """Test write_gate_snapshot_artifact."""

    def test_write_snapshot_creates_file(self):
        """Snapshot is written with correct fields and naming."""
        import setup_evidence as mod
        with tempfile.TemporaryDirectory() as tmp:
            evidence_dir = os.path.join(tmp, "docs", "runbooks", "evidence")
            os.makedirs(evidence_dir, exist_ok=True)
            with patch.object(mod, "_project_root", return_value=tmp):
                path = write_gate_snapshot_artifact(
                    _FakeMetrics(),
                    gate_passed=True,
                    reason=None,
                    project_id="test-proj",
                    service_name="test-svc",
                    region="us-central1",
                    invocation_mode="validate_only",
                )
                self.assertIsNotNone(path)
                self.assertIn("preprocessor_gate_snapshot_", path)
                self.assertIn("docs", path)
                self.assertIn("evidence", path)
                self.assertTrue(os.path.isfile(path))
                with open(path, encoding="utf-8") as f:
                    import json
                    data = json.load(f)
                self.assertEqual(data["unique_shadow_processed"], 60)
                self.assertEqual(data["gate_pass"], True)
                self.assertEqual(data["invocation_mode"], "validate_only")
                self.assertEqual(data["project_id"], "test-proj")


class TestSubscriptionDlqPolicy(unittest.TestCase):
    """Verify validator enforces DLQ/retry subscription policy."""

    @patch("setup_flow._run")
    def test_validate_only_detects_dlq_policy_drift(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout=json.dumps(
                {
                    "pushConfig": {
                        "pushEndpoint": "https://svc/pubsub/push",
                        "oidcToken": {"serviceAccountEmail": "sa@test.iam.gserviceaccount.com"},
                    },
                    "deadLetterPolicy": {
                        "deadLetterTopic": "projects/test/topics/wrong-dlq",
                        "maxDeliveryAttempts": 5,
                    },
                }
            ),
        )
        result = _ensure_subscription(
            project_id="test",
            subscription="sub",
            topic="topic",
            push_endpoint="https://svc/pubsub/push",
            service_account_email="sa@test.iam.gserviceaccount.com",
            validate_only=True,
            dead_letter_topic="gmail-new-emails-dlq",
            max_delivery_attempts=10,
        )
        self.assertFalse(result.ok)
        self.assertIn("needs update", result.detail)

    @patch("setup_flow._run")
    def test_create_subscription_includes_dlq_flags(self, mock_run):
        mock_run.side_effect = [
            MagicMock(returncode=1, stdout=""),  # describe missing
            MagicMock(returncode=0, stdout=""),  # create success
        ]
        result = _ensure_subscription(
            project_id="test",
            subscription="sub",
            topic="topic",
            push_endpoint="https://svc/pubsub/push",
            service_account_email="sa@test.iam.gserviceaccount.com",
            validate_only=False,
            dead_letter_topic="gmail-new-emails-dlq",
            max_delivery_attempts=10,
        )
        self.assertTrue(result.ok)
        create_cmd = mock_run.call_args_list[1][0][0]
        self.assertIn("--dead-letter-topic", create_cmd)
        self.assertIn("gmail-new-emails-dlq", create_cmd)
        self.assertIn("--max-delivery-attempts", create_cmd)
        self.assertIn("10", create_cmd)

    @patch("setup_flow._run")
    def test_update_subscription_includes_dlq_flags(self, mock_run):
        mock_run.side_effect = [
            MagicMock(
                returncode=0,
                stdout=json.dumps(
                    {
                        "pushConfig": {
                            "pushEndpoint": "https://svc/old",
                            "oidcToken": {"serviceAccountEmail": "sa@test.iam.gserviceaccount.com"},
                        },
                        "deadLetterPolicy": {
                            "deadLetterTopic": "projects/test/topics/old",
                            "maxDeliveryAttempts": 5,
                        },
                    }
                ),
            ),
            MagicMock(returncode=0, stdout=""),
        ]
        result = _ensure_subscription(
            project_id="test",
            subscription="sub",
            topic="topic",
            push_endpoint="https://svc/pubsub/push",
            service_account_email="sa@test.iam.gserviceaccount.com",
            validate_only=False,
            dead_letter_topic="gmail-new-emails-dlq",
            max_delivery_attempts=10,
        )
        self.assertTrue(result.ok)
        update_cmd = mock_run.call_args_list[1][0][0]
        self.assertIn("update", update_cmd)
        self.assertIn("--dead-letter-topic", update_cmd)
        self.assertIn("--max-delivery-attempts", update_cmd)


class TestRunbookSnippetPresence(unittest.TestCase):
    """Test runbook contains required command snippets (minimal matching)."""

    def test_runbook_contains_rollback_snippets(self):
        """Runbook contains PREPROCESSOR_MODE=shadow and gcloud run services update."""
        # Go up from cloud/orchestrator/tests/ to project root
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        runbook_path = os.path.join(root, "docs", "runbooks", "MediLink_Gmail_Orchestrator_Operations.md")
        self.assertTrue(os.path.isfile(runbook_path), "Runbook not found")
        with open(runbook_path, encoding="utf-8") as f:
            content = f.read()
        self.assertIn("PREPROCESSOR_MODE=shadow", content)
        self.assertIn("gcloud run services update", content)


if __name__ == "__main__":
    unittest.main()
