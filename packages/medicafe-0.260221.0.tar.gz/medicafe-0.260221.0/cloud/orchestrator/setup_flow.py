from __future__ import annotations

import argparse
import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Dict, List, Optional, Sequence, Tuple

if __package__:
    from . import watch
    from .setup_evidence import write_backfill_evidence_artifact, write_gate_snapshot_artifact
    from .setup_common import (
        CheckResult,
        Context,
        ManualStep,
        REQUIRED_APIS,
        REQUIRED_MANUAL_STEPS,
        SERVICE_ACCOUNT_ROLES,
        _add_secret_version_gcloud,
        _check_secret_has_version,
        _cleanup_cloud_build_source_tarballs,
        _cloud_build_auto_remediate_gcloud_overrides,
        _cloud_build_preflight_hints,
        _call_cloud_run_admin_post,
        _command_error,
        _confirm,
        _ensure_bucket_role_binding,
        _ensure_custom_cloud_build_service_account,
        _ensure_secret_created,
        _extract_service_account_email,
        _get_cloud_build_default_service_account,
        _get_project_from_gcloud,
        _get_project_info,
        _get_project_number,
        _list_buckets,
        _list_cloud_run_services,
        _list_pubsub_topics,
        _parse_oauth_client_json,
        _print_auto_action,
        _print_result,
        _prompt,
        _require_gcloud,
        _resolve_secret_marker,
        _result,
        _run,
        _run_json,
        _run_oauth_flow_and_store_refresh_token,
        _service_account_resource_name,
        _service_account_state,
        _tag_info,
        _tag_ok,
        _tag_fail,
        _try_get_cloud_run_service,
    )
    from .setup_runtime import _verify_runtime
else:
    import watch
    from setup_evidence import write_backfill_evidence_artifact, write_gate_snapshot_artifact
    from setup_common import (
        CheckResult,
        Context,
        ManualStep,
        REQUIRED_APIS,
        REQUIRED_MANUAL_STEPS,
        SERVICE_ACCOUNT_ROLES,
        _add_secret_version_gcloud,
        _check_secret_has_version,
        _cleanup_cloud_build_source_tarballs,
        _cloud_build_auto_remediate_gcloud_overrides,
        _cloud_build_preflight_hints,
        _call_cloud_run_admin_post,
        _command_error,
        _confirm,
        _ensure_bucket_role_binding,
        _ensure_custom_cloud_build_service_account,
        _ensure_secret_created,
        _extract_service_account_email,
        _get_cloud_build_default_service_account,
        _get_project_from_gcloud,
        _get_project_info,
        _get_project_number,
        _list_buckets,
        _list_cloud_run_services,
        _list_pubsub_topics,
        _parse_oauth_client_json,
        _print_auto_action,
        _print_result,
        _prompt,
        _require_gcloud,
        _resolve_secret_marker,
        _result,
        _run,
        _run_json,
        _run_oauth_flow_and_store_refresh_token,
        _service_account_resource_name,
        _service_account_state,
        _tag_info,
        _tag_ok,
        _tag_fail,
        _try_get_cloud_run_service,
    )
    from setup_runtime import _verify_runtime

def _emit_decision(msg: str) -> None:
    """Emit a decision trace line for operator transparency."""
    print("DECISION: {}".format(msg))


def _run_alert_drift_reconcile(args: argparse.Namespace) -> Tuple[bool, str]:
    """
    Check for alert policy drift; if drift detected, run idempotent reconcile.
    Does not pass --notification-channel (preserves existing channels).
    Returns (ok, summary):
    - ok=True when no drift, cannot assess (non-fatal), or reconcile succeeded
    - ok=False when reconcile was required but failed
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    alert_script = os.path.join(script_dir, "setup_alerting.py")
    repo_root = os.path.dirname(os.path.dirname(script_dir))  # cloud/orchestrator -> repo root
    if not os.path.isfile(alert_script):
        return True, "setup_alerting.py not found; skipped"
    access_token = ""
    token_proc = _run(["gcloud", "auth", "print-access-token"])
    if token_proc.returncode == 0 and (token_proc.stdout or "").strip():
        access_token = (token_proc.stdout or "").strip()

    check_cmd = [
        sys.executable, alert_script,
        "--project-id", args.project_id,
        "--service-name", getattr(args, "service_name", "medilink-gmail-orchestrator"),
        "--scheduler-job", getattr(args, "scheduler_job", "gmail-watch-refresh"),
        "--subscription", getattr(args, "subscription", "gmail-new-emails-sub"),
        "--notification-email", getattr(args, "mailbox_user", ""),
        "--check-drift",
    ]
    if access_token:
        check_cmd.extend(["--access-token", access_token])
    proc = subprocess.run(check_cmd, cwd=repo_root)
    if proc.returncode == 0:
        return True, "no drift detected"
    if proc.returncode != 1:
        _emit_decision("cannot assess drift (exit {}) -> skipping reconcile".format(proc.returncode))
        return True, "drift check not assessable (exit {})".format(proc.returncode)
    _emit_decision("alert policy drift detected -> running idempotent reconcile")
    reconcile_cmd = [
        sys.executable, alert_script,
        "--project-id", args.project_id,
        "--service-name", getattr(args, "service_name", "medilink-gmail-orchestrator"),
        "--scheduler-job", getattr(args, "scheduler_job", "gmail-watch-refresh"),
        "--subscription", getattr(args, "subscription", "gmail-new-emails-sub"),
        "--notification-email", getattr(args, "mailbox_user", ""),
    ]
    if access_token:
        reconcile_cmd.extend(["--access-token", access_token])
    reconcile_proc = subprocess.run(reconcile_cmd, cwd=repo_root)
    if reconcile_proc.returncode != 0:
        _emit_decision("alert reconcile failed (exit {}) -> check setup_alerting output".format(reconcile_proc.returncode))
        return False, "reconcile failed (exit {})".format(reconcile_proc.returncode)
    return True, "drift detected and reconciled"


def _get_auth_mode_from_cloud_run(project_id: str, region: str, service_name: str) -> Tuple[str, bool]:
    """
    Resolve AUTH_MODE for OAuth secret requirement decisions.
    Primary source: Cloud Run env. If env cannot be read, treat as dwd_preferred (fail safe).
    Returns (auth_mode, env_readable).
    """
    env = _get_cloud_run_env(project_id, region, service_name)
    if not env:
        return ("dwd_preferred", False)
    mode = (env.get("AUTH_MODE") or "").strip().lower()
    if mode in _VALID_AUTH_MODES:
        return (mode, True)
    return ("dwd_preferred", True)


def _check_auth() -> CheckResult:
    proc = _run(["gcloud", "auth", "list", "--filter=status:ACTIVE", "--format=value(account)"])
    account = (proc.stdout or "").strip()
    if proc.returncode == 0 and account:
        return _result("gcloud auth", True, "active account: {}".format(account))
    return _result("gcloud auth", False, "no active gcloud account (run: gcloud auth login)")


def _ensure_project(project_id: str, validate_only: bool) -> CheckResult:
    proc = _run(["gcloud", "config", "get-value", "project"])
    current = (proc.stdout or "").strip()
    if proc.returncode == 0 and current == project_id:
        return _result("gcloud project", True, "configured as {}".format(project_id))
    if validate_only:
        return _result("gcloud project", False, "current={} expected={}".format(current or "unset", project_id))

    _print_auto_action("Setting active gcloud project to {}".format(project_id))
    set_proc = _run(["gcloud", "config", "set", "project", project_id])
    if set_proc.returncode == 0:
        return _result("gcloud project", True, "set to {}".format(project_id))
    return _result("gcloud project", False, _command_error(set_proc))


def _ensure_apis(project_id: str, validate_only: bool) -> CheckResult:
    payload = _run_json(["gcloud", "services", "list", "--enabled", "--project", project_id, "--format=json"])
    enabled_names = set()
    for svc in payload or []:
        if isinstance(svc, dict):
            enabled_names.add((svc.get("config") or {}).get("name"))
    missing = [api for api in REQUIRED_APIS if api not in enabled_names]
    if not missing:
        return _result("required APIs", True, "all required APIs are enabled")
    if validate_only:
        return _result("required APIs", False, "missing: {}".format(", ".join(missing)))

    _print_auto_action("Enabling missing APIs: {}".format(", ".join(missing)))
    proc = _run(["gcloud", "services", "enable", *missing, "--project", project_id])
    if proc.returncode == 0:
        return _result("required APIs", True, "enabled: {}".format(", ".join(missing)))
    return _result("required APIs", False, _command_error(proc))


def _ensure_service_account(project_id: str, service_account_email: str, validate_only: bool) -> CheckResult:
    proc = _run(["gcloud", "iam", "service-accounts", "describe", service_account_email, "--project", project_id])
    if proc.returncode == 0:
        return _result("service account", True, service_account_email)
    if validate_only:
        return _result("service account", False, "missing: {}".format(service_account_email))

    account_name = service_account_email.split("@")[0]
    _print_auto_action("Creating service account {}".format(account_name))
    create = _run([
        "gcloud", "iam", "service-accounts", "create", account_name,
        "--display-name", "MediLink Gmail Orchestrator", "--project", project_id,
    ])
    if create.returncode == 0:
        return _result("service account", True, "created {}".format(service_account_email))
    return _result("service account", False, _command_error(create))


def _binding_exists(policy: object, role: str, member: str) -> bool:
    if not isinstance(policy, dict):
        return False
    for binding in policy.get("bindings", []):
        if isinstance(binding, dict) and binding.get("role") == role and member in (binding.get("members") or []):
            return True
    return False


def _ensure_roles(project_id: str, service_account_email: str, validate_only: bool) -> CheckResult:
    member = "serviceAccount:{}".format(service_account_email)
    policy = _run_json(["gcloud", "projects", "get-iam-policy", project_id, "--format=json"])
    missing = [role for role in SERVICE_ACCOUNT_ROLES if not _binding_exists(policy, role, member)]
    if not missing:
        return _result("service account IAM roles", True, "all required roles present")
    if validate_only:
        return _result("service account IAM roles", False, "missing: {}".format(", ".join(missing)))

    failed = []
    for role in missing:
        _print_auto_action("Granting {} to {}".format(role, service_account_email))
        add = _run([
            "gcloud", "projects", "add-iam-policy-binding", project_id,
            "--member", member, "--role", role, "--quiet",
        ])
        if add.returncode != 0:
            failed.append("{} ({})".format(role, _command_error(add)))
    if not failed:
        return _result("service account IAM roles", True, "granted: {}".format(", ".join(missing)))
    return _result("service account IAM roles", False, "failed: {}".format("; ".join(failed)))


def _ensure_bucket(project_id: str, bucket: str, validate_only: bool) -> CheckResult:
    describe = _run(["gcloud", "storage", "buckets", "describe", "gs://{}".format(bucket), "--project", project_id])
    if describe.returncode == 0:
        return _result("Cloud Storage bucket", True, bucket)
    if validate_only:
        return _result("Cloud Storage bucket", False, "missing: gs://{}".format(bucket))

    _print_auto_action("Creating bucket gs://{}".format(bucket))
    create = _run([
        "gcloud", "storage", "buckets", "create", "gs://{}".format(bucket),
        "--project", project_id, "--location", "us-central1", "--uniform-bucket-level-access",
    ])
    if create.returncode == 0:
        return _result("Cloud Storage bucket", True, "created gs://{}".format(bucket))
    return _result("Cloud Storage bucket", False, _command_error(create))


def _ensure_topic(project_id: str, topic: str, validate_only: bool) -> CheckResult:
    describe = _run(["gcloud", "pubsub", "topics", "describe", topic, "--project", project_id])
    if describe.returncode == 0:
        return _result("Pub/Sub topic", True, topic)
    if validate_only:
        return _result("Pub/Sub topic", False, "missing: {}".format(topic))

    _print_auto_action("Creating Pub/Sub topic {}".format(topic))
    create = _run(["gcloud", "pubsub", "topics", "create", topic, "--project", project_id])
    if create.returncode == 0:
        return _result("Pub/Sub topic", True, "created {}".format(topic))
    return _result("Pub/Sub topic", False, _command_error(create))


def _ensure_gmail_pubsub_publisher(project_id: str, topic: str, validate_only: bool) -> CheckResult:
    """
    Ensure Gmail push service identity can publish test messages to the topic.

    Gmail watch registration requires this principal to have roles/pubsub.publisher:
    serviceAccount:gmail-api-push@system.gserviceaccount.com
    """
    member = "serviceAccount:gmail-api-push@system.gserviceaccount.com"
    role = "roles/pubsub.publisher"
    policy = _run_json([
        "gcloud", "pubsub", "topics", "get-iam-policy", topic,
        "--project", project_id, "--format=json",
    ])
    if _binding_exists(policy, role, member):
        return _result("Gmail Pub/Sub publisher IAM", True, "configured")
    if validate_only:
        return _result("Gmail Pub/Sub publisher IAM", False, "missing: {} on topic {}".format(member, topic))

    _print_auto_action("Granting {} on topic {} to {}".format(role, topic, member))
    add = _run([
        "gcloud", "pubsub", "topics", "add-iam-policy-binding", topic,
        "--project", project_id,
        "--member", member,
        "--role", role,
        "--quiet",
    ])
    if add.returncode == 0:
        return _result("Gmail Pub/Sub publisher IAM", True, "granted {}".format(member))
    err = _command_error(add)
    err_lower = err.lower()
    if (
        "constraints/iam.allowedpolicymemberdomains" in err_lower
        or "not in permitted organization" in err_lower
        or "one or more users named in the policy do not belong to a permitted customer" in err_lower
    ):
        return _result(
            "Gmail Pub/Sub publisher IAM",
            False,
            "blocked by organization policy (domain restricted sharing). "
            "Org Policy admin must allow principal 'serviceAccount:gmail-api-push@system.gserviceaccount.com' "
            "or temporarily relax the constraint for this project before Gmail watch can work.",
        )
    return _result("Gmail Pub/Sub publisher IAM", False, err)


def _ensure_pubsub_dlq_publisher(project_id: str, dlq_topic: str, validate_only: bool) -> CheckResult:
    """
    Ensure Pub/Sub service agent can publish dead-lettered messages to DLQ topic.

    Principal format:
      service-{PROJECT_NUMBER}@gcp-sa-pubsub.iam.gserviceaccount.com
    """
    project_number = _get_project_number(project_id)
    if not project_number:
        return _result("Pub/Sub DLQ publisher IAM", False, "could not resolve project number")
    member = "serviceAccount:service-{}@gcp-sa-pubsub.iam.gserviceaccount.com".format(project_number)
    role = "roles/pubsub.publisher"
    policy = _run_json([
        "gcloud", "pubsub", "topics", "get-iam-policy", dlq_topic,
        "--project", project_id, "--format=json",
    ])
    if _binding_exists(policy, role, member):
        return _result("Pub/Sub DLQ publisher IAM", True, "configured")
    if validate_only:
        return _result("Pub/Sub DLQ publisher IAM", False, "missing: {} on topic {}".format(member, dlq_topic))

    _print_auto_action("Granting {} on DLQ topic {} to {}".format(role, dlq_topic, member))
    add = _run([
        "gcloud", "pubsub", "topics", "add-iam-policy-binding", dlq_topic,
        "--project", project_id,
        "--member", member,
        "--role", role,
        "--quiet",
    ])
    if add.returncode == 0:
        return _result("Pub/Sub DLQ publisher IAM", True, "granted {}".format(member))
    return _result("Pub/Sub DLQ publisher IAM", False, _command_error(add))


def _check_dwd_readiness(
    project_id: str,
    region: str,
    service_name: str,
    service_account_email: str,
    mailbox_user: str,
    current_env: Optional[Dict[str, str]] = None,
) -> CheckResult:
    """
    Detect whether DWD (domain-wide delegation) is configured and give actionable guidance.
    Uses heuristic only (no network probe); validator runs on operator machine, not runtime.
    """
    env = current_env if current_env is not None else _get_cloud_run_env(project_id, region, service_name)
    effective_mode = (env.get("AUTH_MODE") or "").strip().lower() or "dwd_preferred"
    mailbox = (env.get("MAILBOX_USER") or mailbox_user or "").strip()
    if effective_mode not in ("dwd_preferred", "dwd_required"):
        return _result(
            "DWD readiness",
            True,
            "AUTH_MODE={} (user OAuth path; DWD not required)".format(effective_mode or "user_oauth_only"),
        )
    if not mailbox:
        return _result(
            "DWD readiness",
            False,
            "AUTH_MODE={} but MAILBOX_USER is not set on Cloud Run. "
            "Set MAILBOX_USER to the delegated mailbox email (e.g. the Workspace user to act as).".format(effective_mode),
        )
    key_based_configured = bool(
        env.get("SERVICE_ACCOUNT_JSON") or env.get("GOOGLE_APPLICATION_CREDENTIALS")
    )
    if key_based_configured:
        detail = (
            "AUTH_MODE={}, MAILBOX_USER set, key-based DWD configured. For DWD to work: in Google Workspace Admin "
            "Console go to Security > API controls > Domain-wide delegation; add the service account client ID "
            "(from IAM > Service accounts > {} > Show advanced > Client ID) with scopes: "
            "https://www.googleapis.com/auth/gmail.modify, https://www.googleapis.com/auth/gmail.readonly. "
            "If DWD is not yet allowlisted, runtime will use user OAuth fallback when AUTH_MODE=dwd_preferred.".format(
                effective_mode, service_account_email
            )
        )
    else:
        detail = (
            "Keyless DWD intended; requires IAM Credentials API enabled and Token Creator on signing SA. "
            "To verify: set SERVICE_ACCOUNT_EMAIL or SIGNING_SERVICE_ACCOUNT_EMAIL if metadata is unavailable; "
            "then check runtime logs for 'Gmail auth mode: dwd (keyless)'."
        )
    return _result("DWD readiness", True, detail)


def _check_keyless_dwd_prereqs(project_id: str, service_account_email: str) -> CheckResult:
    """
    Check keyless DWD prerequisites (label as 'prereqs present', not 'verified working').
    Real readiness is confirmed by runtime log line 'Gmail auth mode: dwd (keyless)'.
    """
    # Check 1: IAM Credentials API enabled
    api_check = _run([
        "gcloud", "services", "list",
        "--enabled",
        "--filter", "name:iamcredentials.googleapis.com",
        "--project", project_id,
        "--format", "value(name)",
    ])
    if api_check.returncode != 0 or "iamcredentials.googleapis.com" not in (api_check.stdout or ""):
        return _result(
            "Keyless DWD prereqs present",
            False,
            "IAM Credentials API not enabled. Enable: gcloud services enable iamcredentials.googleapis.com --project {}".format(project_id)
        )
    
    # Check 2: SA has Token Creator on self (already checked separately, but confirm here)
    member = "serviceAccount:{}".format(service_account_email)
    get_policy = _run([
        "gcloud", "iam", "service-accounts", "get-iam-policy", service_account_email,
        "--project", project_id, "--format", "json",
    ])
    if get_policy.returncode != 0:
        return _result(
            "Keyless DWD prereqs present",
            False,
            "Cannot verify Token Creator binding: {}".format(_command_error(get_policy))
        )
    
    try:
        policy = json.loads(get_policy.stdout or "{}")
        for binding in policy.get("bindings", []) or []:
            if binding.get("role") != "roles/iam.serviceAccountTokenCreator":
                continue
            if member in (binding.get("members", []) or []):
                return _result(
                    "Keyless DWD prereqs present",
                    True,
                    "IAM Credentials API enabled, SA has Token Creator on self. Note: this does NOT confirm Workspace allowlist; runtime log 'Gmail auth mode: dwd (keyless)' is the real verification."
                )
    except Exception:
        pass
    
    return _result(
        "Keyless DWD prereqs present",
        False,
        "SA missing Token Creator on self. Fix: gcloud iam service-accounts add-iam-policy-binding {} --project {} --member {} --role roles/iam.serviceAccountTokenCreator".format(
            service_account_email, project_id, member
        )
    )


def _check_firestore_database(project_id: str) -> CheckResult:
    """Check Firestore (default) database exists; include location in detail when present."""
    payload = _run_json([
        "gcloud", "firestore", "databases", "describe", "--database=(default)", "--project", project_id, "--format=json",
    ])
    if payload is None:
        return _result("Firestore database", False, "missing or not accessible")
    if not isinstance(payload, dict):
        return _result("Firestore database", False, "missing or not accessible")
    location = (payload.get("locationId") or payload.get("name", "").split("/")[-1] or "unknown")
    return _result("Firestore database", True, "(default) exists in {}".format(location))


def _check_secret_exists(project_id: str, secret_name: str) -> CheckResult:
    proc = _run(["gcloud", "secrets", "describe", secret_name, "--project", project_id])
    if proc.returncode == 0:
        return _result("Secret Manager secret", True, secret_name)
    return _result("Secret Manager secret", False, "missing: {}".format(secret_name))


def _get_service_url(project_id: str, service_name: str, region: str) -> Optional[str]:
    proc = _run([
        "gcloud", "run", "services", "describe", service_name,
        "--project", project_id, "--region", region, "--format=value(status.url)",
    ])
    if proc.returncode != 0:
        return None
    return (proc.stdout or "").strip() or None


def _artifact_registry_repo_exists(project_id: str, location: str, repo_name: str) -> bool:
    """Return True if the Artifact Registry Docker repo exists (2024+ preferred over gcr.io)."""
    payload = _run_json([
        "gcloud", "artifacts", "repositories", "describe", repo_name,
        "--location", location, "--project", project_id, "--format=json",
    ])
    return isinstance(payload, dict)


def _artifact_image_exists(project_id: str, location: str, repo_name: str, image_name: str) -> bool:
    """Return True if image has at least one digest in Artifact Registry."""
    image_ref = "{}-docker.pkg.dev/{}/{}/{}".format(location, project_id, repo_name, image_name)
    proc = _run([
        "gcloud", "artifacts", "docker", "images", "list", image_ref,
        "--project", project_id,
        "--include-tags",
        "--format=value(digest)",
        "--limit", "1",
    ])
    if proc.returncode != 0:
        return False
    return bool((proc.stdout or "").strip())


def _recommended_build_service_account_email(
    project_id: str,
    region: str,
    explicit_build_service_account: str,
    fallback_account_name: str,
) -> str:
    """Best-effort recommendation for gcloud builds submit --service-account."""
    explicit_email = _extract_service_account_email(explicit_build_service_account or "")
    if explicit_email:
        return explicit_email
    default_build_sa = _get_cloud_build_default_service_account(project_id, region)
    if default_build_sa and _service_account_state(project_id, default_build_sa) == "not_found":
        return "{}@{}.iam.gserviceaccount.com".format(fallback_account_name, project_id)
    return ""


def _ensure_artifact_registry_repo(project_id: str, location: str, repo_name: str) -> Tuple[bool, str]:
    """Create the Artifact Registry Docker repo if it does not exist. Idempotent. Returns (success, message)."""
    if _artifact_registry_repo_exists(project_id, location, repo_name):
        return True, "repository already exists"
    _print_auto_action("Creating Artifact Registry repository {} in {}".format(repo_name, location))
    proc = _run([
        "gcloud", "artifacts", "repositories", "create", repo_name,
        "--repository-format=docker", "--location", location, "--project", project_id,
    ])
    if proc.returncode == 0:
        return True, "created"
    err = _command_error(proc)
    if "already exists" in err.lower():
        return True, "already exists"
    return False, err


def _ensure_cloud_build_service_agent(project_id: str) -> Tuple[bool, str]:
    """Ensure Cloud Build service identities exist and have required roles. Fixes NOT_FOUND on first build."""
    info = _get_project_info(project_id)
    project_number = (info or {}).get("projectNumber")
    if not project_number:
        return False, "could not get project number"
    # Two identities: legacy (used by workers) and service agent (used by Cloud Build API). Both need roles.
    legacy_sa = "{}@cloudbuild.gserviceaccount.com".format(project_number)
    service_agent_sa = "service-{}@gcp-sa-cloudbuild.iam.gserviceaccount.com".format(project_number)
    _print_auto_action("Ensuring Cloud Build service identity exists and has required roles")
    # Create legacy service identity if missing (idempotent; may already exist).
    create = _run([
        "gcloud", "beta", "services", "identity", "create",
        "--service=cloudbuild.googleapis.com", "--project", project_id,
    ])
    if create.returncode != 0 and "already exists" not in _command_error(create).lower():
        return False, "Cloud Build service identity create: {}".format(_command_error(create))
    for sa_email in (legacy_sa, service_agent_sa):
        # Grant Cloud Build Service Agent role (required for builds to run).
        bind = _run([
            "gcloud", "projects", "add-iam-policy-binding", project_id,
            "--member", "serviceAccount:{}".format(sa_email),
            "--role", "roles/cloudbuild.serviceAgent", "--quiet",
        ])
        if bind.returncode != 0 and "not found" not in _command_error(bind).lower():
            return False, "grant cloudbuild.serviceAgent to {}: {}".format(sa_email, _command_error(bind))
        # Grant Service Usage Consumer so Cloud Build can use project services (fixes serviceusage.services.use errors).
        bind2 = _run([
            "gcloud", "projects", "add-iam-policy-binding", project_id,
            "--member", "serviceAccount:{}".format(sa_email),
            "--role", "roles/serviceusage.serviceUsageConsumer", "--quiet",
        ])
        if bind2.returncode != 0 and "not found" not in _command_error(bind2).lower():
            return False, "grant serviceusage.serviceUsageConsumer to {}: {}".format(sa_email, _command_error(bind2))
    return True, ""


def _print_cloud_build_failure_diagnostics(project_id: str, build_proc: subprocess.CompletedProcess) -> None:
    """On build failure, print actionable links and hints."""
    combined = (build_proc.stdout or "") + "\n" + (build_proc.stderr or "")
    # Capture build log URL if present (e.g. "Created https://console.cloud.google.com/cloud-build/builds/...")
    build_url_match = re.search(
        r"https://console\.cloud\.google\.com/cloud-build/builds/[^\s\)\]]+",
        combined,
    )
    if build_url_match:
        print("Build log: {}".format(build_url_match.group(0)))
    history_url = "https://console.cloud.google.com/cloud-build/builds?project={}".format(project_id)
    print("Cloud Build history: {}".format(history_url))
    print("If the build service account is missing: in IAM, enable 'Show google-managed service accounts' to see the Cloud Build service account.")
    if "NOT_FOUND" in combined and "not found" in combined.lower():
        if "locations/global" in combined:
            print("NOT_FOUND on locations/global: Cloud Build no longer uses global; always pass --region (e.g. --region us-central1).")
        print("Check hidden gcloud build overrides that can force missing resources:")
        print("  gcloud config get-value builds/worker_pool")
        print("  gcloud config get-value builds/service_account")
        print("  gcloud config get-value api_endpoint_overrides/cloudbuild")
        print("  gcloud config unset builds/worker_pool")
        print("  gcloud config unset builds/service_account")
        print("  gcloud config unset api_endpoint_overrides/cloudbuild")
        print("Check default build service account (2024+ projects can default to Compute Engine SA):")
        print("  gcloud builds get-default-service-account --project {} --region <REGION>".format(project_id))
        print("  gcloud iam service-accounts describe <SERVICE_ACCOUNT_EMAIL> --project {}".format(project_id))
        print("Try re-enabling the API: gcloud services enable cloudbuild.googleapis.com --project {}".format(project_id))
        print("If NOT_FOUND persists: build with Docker and push to Artifact Registry, then deploy (see manual steps). Or open a support case; the project may need Cloud Build regional provisioning.")
    if "FAILED_PRECONDITION" in combined and "cloudbuild-logs" in combined and "does not have access to bucket" in combined:
        print("Cloud Build failed precondition: selected build service account cannot write Cloud Build logs bucket.")
        print("Grant bucket-level storage.admin to the selected build service account on the logs bucket.")


def _extract_cloud_run_logs_url(text: str) -> str:
    m = re.search(r"https://console\.cloud\.google\.com/logs/viewer\?[^\s\)\]]+", text or "")
    return m.group(0) if m else ""


def _extract_cloud_run_revision_name(text: str) -> str:
    m = re.search(r"revision_name/([a-z0-9\-]+)", text or "", flags=re.IGNORECASE)
    return m.group(1) if m else ""


def _print_cloud_run_deploy_failure_diagnostics(
    project_id: str,
    region: str,
    service_name: str,
    deploy_proc: subprocess.CompletedProcess,
) -> None:
    combined = (deploy_proc.stdout or "") + "\n" + (deploy_proc.stderr or "")
    print("Cloud Run deploy diagnostics:")
    print("Service: {} (region: {})".format(service_name, region))
    if "failed to start and listen on the port" in combined.lower():
        print("Container failed startup health check (did not listen on PORT in time).")
    logs_url = _extract_cloud_run_logs_url(combined)
    if logs_url:
        print("Revision logs: {}".format(logs_url))
    revision = _extract_cloud_run_revision_name(combined)
    print("CLI logs: gcloud run services logs read {} --project {} --region {} --limit 200".format(service_name, project_id, region))
    if revision:
        print(
            "Revision-focused logs: gcloud logging read 'resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"{}\" AND resource.labels.revision_name=\"{}\"' --project {} --limit 100 --format='value(textPayload)'".format(
                service_name, revision, project_id
            )
        )


def _merge_service_accounts(*service_account_groups: Optional[Sequence[str]]) -> List[str]:
    seen = set()
    ordered = []
    for group in service_account_groups:
        for sa in group or ():
            email = (sa or "").strip()
            if not email or email in seen:
                continue
            seen.add(email)
            ordered.append(email)
    return ordered


def _ensure_cloud_build_logs_bucket_access(project_id: str, region: str, build_service_account_email: str) -> Tuple[bool, str]:
    """
    Ensure the regional Cloud Build logs bucket exists and is writable by the build SA.

    Why storage.admin at bucket level:
    gcloud submit can fail with FAILED_PRECONDITION if the selected build SA cannot
    create/read objects in gs://<PROJECT_NUMBER>-<REGION>-cloudbuild-logs.
    """
    project_number = _get_project_number(project_id)
    if not project_number:
        return False, "could not get project number for logs bucket"
    bucket_uri = "gs://{}-{}-cloudbuild-logs".format(project_number, region)
    describe = _run([
        "gcloud", "storage", "buckets", "describe", bucket_uri, "--project", project_id,
    ])
    if describe.returncode != 0:
        create = _run([
            "gcloud", "storage", "buckets", "create", bucket_uri,
            "--project", project_id, "--location", region, "--uniform-bucket-level-access",
        ])
        if create.returncode != 0:
            return False, "create logs bucket {}: {}".format(bucket_uri, _command_error(create))
    ok, err = _ensure_bucket_role_binding(bucket_uri, project_id, build_service_account_email, "roles/storage.admin")
    if not ok:
        return False, "grant roles/storage.admin on {} to {}: {}".format(bucket_uri, build_service_account_email, err)
    return True, bucket_uri


def _ensure_cloud_build_staging_bucket(
    project_id: str,
    region: str,
    reader_service_accounts: Optional[Sequence[str]] = None,
) -> Tuple[bool, str]:
    """Ensure a regional GCS bucket exists for source staging and build identities can read it."""
    project_number = _get_project_number(project_id)
    if not project_number:
        return False, ""
    legacy_sa = "{}@cloudbuild.gserviceaccount.com".format(project_number)
    readers = _merge_service_accounts([legacy_sa], reader_service_accounts)
    # Bucket name: alphanumeric and hyphens only, max 63 chars.
    base = "{}_cloudbuild_{}".format(project_id.replace(".", "-"), region).lower()
    bucket_name = "".join(c if c.isalnum() or c == "-" else "-" for c in base)[:63]
    bucket_uri = "gs://{}".format(bucket_name)
    describe = _run([
        "gcloud", "storage", "buckets", "describe", bucket_uri, "--project", project_id,
    ])
    if describe.returncode != 0:
        _print_auto_action("Creating regional staging bucket for Cloud Build: {}".format(bucket_uri))
        create = _run([
            "gcloud", "storage", "buckets", "create", bucket_uri,
            "--project", project_id, "--location", region, "--uniform-bucket-level-access",
        ])
        if create.returncode != 0:
            return False, ""
    # Build-time identity must read uploaded source archive from staging.
    for sa_email in readers:
        ok, _ = _ensure_bucket_role_binding(bucket_uri, project_id, sa_email, "roles/storage.objectViewer")
        if not ok:
            return False, ""
    return True, "{}/staging".format(bucket_uri)


def _ensure_cloud_build_default_bucket_accessible(
    project_id: str,
    reader_service_accounts: Optional[Sequence[str]] = None,
) -> None:
    """Ensure build identities can read the default bucket (project_cloudbuild)."""
    project_number = _get_project_number(project_id)
    if not project_number:
        return
    legacy_sa = "{}@cloudbuild.gserviceaccount.com".format(project_number)
    readers = _merge_service_accounts([legacy_sa], reader_service_accounts)
    bucket_name = "{}_cloudbuild".format(project_id.replace(".", "-"))
    bucket_uri = "gs://{}".format(bucket_name)
    describe = _run([
        "gcloud", "storage", "buckets", "describe", bucket_uri, "--project", project_id,
    ])
    if describe.returncode != 0:
        return
    for sa_email in readers:
        _ensure_bucket_role_binding(bucket_uri, project_id, sa_email, "roles/storage.objectViewer")


def _ensure_cloud_build_regional_default_bucket_accessible(
    project_id: str,
    region: str,
    reader_service_accounts: Optional[Sequence[str]] = None,
) -> None:
    """Ensure build identities can read regional default bucket (project_region_cloudbuild)."""
    project_number = _get_project_number(project_id)
    if not project_number:
        return
    legacy_sa = "{}@cloudbuild.gserviceaccount.com".format(project_number)
    readers = _merge_service_accounts([legacy_sa], reader_service_accounts)
    bucket_name = "{}_{}_cloudbuild".format(project_id.replace(".", "-"), region)
    bucket_uri = "gs://{}".format(bucket_name)
    describe = _run([
        "gcloud", "storage", "buckets", "describe", bucket_uri, "--project", project_id,
    ])
    if describe.returncode != 0:
        return
    for sa_email in readers:
        _ensure_bucket_role_binding(bucket_uri, project_id, sa_email, "roles/storage.objectViewer")


def _run_build_and_deploy_cloud_run(
    project_id: str,
    region: str,
    service_name: str,
    service_account_email: str,
    artifact_repo: str,
    orchestrator_dir: str,
    build_service_account: str = "",
    build_service_account_name: str = "medilink-build-sa",
) -> Tuple[bool, str]:
    """Build image via Cloud Build (Artifact Registry) and deploy to Cloud Run. Returns (success, message)."""
    # Clear hidden local gcloud overrides that have caused NOT_FOUND by referencing missing pools/SAs/endpoints.
    cleared = _cloud_build_auto_remediate_gcloud_overrides()
    if cleared:
        _print_auto_action("Cleared local gcloud Cloud Build overrides: {}".format(", ".join(cleared)))

    ok, msg = _ensure_cloud_build_service_agent(project_id)
    if not ok:
        return False, "Cloud Build setup: {}".format(msg)
    image = "{}-docker.pkg.dev/{}/{}/{}".format(region, project_id, artifact_repo, service_name)
    ok, msg = _ensure_artifact_registry_repo(project_id, region, artifact_repo)
    if not ok:
        return False, "Artifact Registry repo: {}".format(msg)
    selected_build_sa = _extract_service_account_email(build_service_account or "")
    if not selected_build_sa:
        default_build_sa = _get_cloud_build_default_service_account(project_id, region)
        default_sa_state = _service_account_state(project_id, default_build_sa) if default_build_sa else "error"
        # Root-cause path seen in this project:
        # Cloud Build defaults to <PROJECT_NUMBER>-compute@developer.gserviceaccount.com.
        # If that SA was deleted, CreateBuild can return NOT_FOUND with no build record.
        # Fallback to a dedicated SA and pass --service-account explicitly.
        if default_build_sa and default_sa_state == "not_found":
            print("Cloud Build preflight: default build service account '{}' is missing; using dedicated build service account.".format(default_build_sa))
            ok_custom, custom_or_err = _ensure_custom_cloud_build_service_account(project_id, region, build_service_account_name)
            if not ok_custom:
                return False, custom_or_err
            selected_build_sa = custom_or_err
        elif default_build_sa and default_sa_state == "permission_denied":
            print("Cloud Build preflight: cannot verify default build service account '{}' (iam.serviceAccounts.get denied).".format(default_build_sa))
        elif default_build_sa:
            print("Cloud Build preflight: default build service account '{}' appears available.".format(default_build_sa))
    else:
        # User explicitly asked for build SA; ensure baseline permissions and buckets are ready.
        sa_state = _service_account_state(project_id, selected_build_sa)
        if sa_state == "not_found":
            return False, "Configured build service account not found: {}".format(selected_build_sa)
        if sa_state == "permission_denied":
            print("Cloud Build preflight: cannot verify configured build service account '{}' (iam.serviceAccounts.get denied).".format(selected_build_sa))
        if selected_build_sa.endswith("@{}.iam.gserviceaccount.com".format(project_id)):
            account_name = selected_build_sa.split("@")[0]
            ok_custom, custom_or_err = _ensure_custom_cloud_build_service_account(project_id, region, account_name)
            if not ok_custom:
                return False, custom_or_err
            selected_build_sa = custom_or_err
    # Optional: use explicit regional staging bucket so creation is predictable.
    staging_dir = ""
    extra_readers = [selected_build_sa] if selected_build_sa else []
    ok_staging, staging_dir = _ensure_cloud_build_staging_bucket(project_id, region, reader_service_accounts=extra_readers)
    if not ok_staging:
        staging_dir = ""  # proceed without --gcs-source-staging-dir; gcloud will use default bucket
    # Ensure build identities can read default buckets so submit can read uploaded source.
    _ensure_cloud_build_default_bucket_accessible(project_id, reader_service_accounts=extra_readers)
    _ensure_cloud_build_regional_default_bucket_accessible(project_id, region, reader_service_accounts=extra_readers)
    if selected_build_sa:
        logs_ok, logs_msg = _ensure_cloud_build_logs_bucket_access(project_id, region, selected_build_sa)
        if not logs_ok:
            return False, logs_msg
    preflight_hints = _cloud_build_preflight_hints(project_id, region)
    for hint in preflight_hints:
        print("Cloud Build preflight: {}".format(hint))
    # Note: local gcloud override quick-fixes are auto-applied above. Do not print manual "unset" steps here
    # unless we are in validate-only mode (where we avoid applying changes).
    _print_auto_action("Building image (Cloud Build) and deploying to Cloud Run")
    # Always use --region; locations/global returns NOT_FOUND in many projects (Cloud Build is regional).
    build_cmd = [
        "gcloud", "builds", "submit", "--tag", image,
        "--project", project_id, "--region", region,
        "--default-buckets-behavior=regional-user-owned-bucket",
        ".",
    ]
    if selected_build_sa:
        selected_build_sa_resource = _service_account_resource_name(project_id, selected_build_sa)
        build_cmd = build_cmd[:-1] + [
            "--service-account",
            selected_build_sa_resource,
            ".",
        ]
    if staging_dir:
        build_cmd = build_cmd[:-1] + ["--gcs-source-staging-dir", staging_dir, "."]
    build = _run(build_cmd, cwd=orchestrator_dir)
    docker_fallback_ok = False
    if build.returncode != 0:
        # Best-effort auto-remediation for transient NOT_FOUND patterns:
        # - re-enable API
        # - ensure service identities exist
        # - clear gcloud overrides again
        # then retry a few times with small backoff. We have observed intermittent Cloud Build 404s.
        err = _command_error(build)
        is_not_found = ("NOT_FOUND" in err) or ("requested entity was not found" in err.lower())
        if is_not_found:
            print("Cloud Build retry: detected NOT_FOUND. Applying best-effort remediation then retrying...")
            _run(["gcloud", "services", "enable", "cloudbuild.googleapis.com", "--project", project_id])
            _ensure_cloud_build_service_agent(project_id)
            cleared2 = _cloud_build_auto_remediate_gcloud_overrides()
            if cleared2:
                _print_auto_action("Cleared local gcloud Cloud Build overrides: {}".format(", ".join(cleared2)))
            for delay_s in (3, 8, 20):
                time.sleep(delay_s)
                build = _run(build_cmd, cwd=orchestrator_dir)
                if build.returncode == 0:
                    break
                err = _command_error(build)
                if ("NOT_FOUND" not in err) and ("not found" not in err.lower()):
                    break
            if build.returncode != 0:
                # Docker fallback: only attempt when Docker is available (user installed Docker Desktop) and the
                # Cloud Build API is returning NOT_FOUND. This gives us a path forward without "fragile hacks".
                if shutil.which("docker"):
                    print("Cloud Build still NOT_FOUND. Attempting local Docker build/push fallback...")
                    cfg = _run(["gcloud", "auth", "configure-docker", "{}-docker.pkg.dev".format(region), "--quiet"])
                    if cfg.returncode != 0:
                        _print_cloud_build_failure_diagnostics(project_id, build)
                        return False, "Docker fallback failed: gcloud auth configure-docker: {}".format(_command_error(cfg))
                    dv = _run(["docker", "version"])
                    if dv.returncode != 0:
                        _print_cloud_build_failure_diagnostics(project_id, build)
                        return False, "Docker fallback failed: docker engine not available: {}".format(_command_error(dv))
                    db = _run(["docker", "build", "-t", image, "."], cwd=orchestrator_dir)
                    if db.returncode != 0:
                        _print_cloud_build_failure_diagnostics(project_id, build)
                        return False, "Docker fallback failed: docker build: {}".format(_command_error(db))
                    dp = _run(["docker", "push", image], cwd=orchestrator_dir)
                    if dp.returncode != 0:
                        _print_cloud_build_failure_diagnostics(project_id, build)
                        return False, "Docker fallback failed: docker push: {}".format(_command_error(dp))
                    # Docker push succeeded; proceed to Cloud Run deploy with the same image tag.
                    print("Docker fallback succeeded (built and pushed {}). Proceeding to deploy...".format(image))
                    docker_fallback_ok = True
                else:
                    _print_cloud_build_failure_diagnostics(project_id, build)
                    return False, "Build failed (Cloud Build NOT_FOUND, docker not available): {}".format(_command_error(build))

        if not docker_fallback_ok:
            _print_cloud_build_failure_diagnostics(project_id, build)
            return False, "Build failed: {}".format(_command_error(build))
    deploy = _run([
        "gcloud", "run", "deploy", service_name,
        "--image", image, "--region", region, "--project", project_id,
        "--service-account", service_account_email, "--no-allow-unauthenticated",
    ])
    if deploy.returncode != 0:
        _print_cloud_run_deploy_failure_diagnostics(project_id, region, service_name, deploy)
        return False, "Deploy failed: {}".format(_command_error(deploy))
    return True, "built and deployed"


def _ensure_subscription(
    project_id: str,
    subscription: str,
    topic: str,
    push_endpoint: str,
    service_account_email: str,
    validate_only: bool,
    dead_letter_topic: str,
    max_delivery_attempts: int,
) -> CheckResult:
    if max_delivery_attempts < 5 or max_delivery_attempts > 100:
        return _result(
            "Pub/Sub subscription",
            False,
            "invalid max_delivery_attempts={} (expected 5-100)".format(max_delivery_attempts),
        )

    dead_letter_topic_resource = "projects/{}/topics/{}".format(project_id, dead_letter_topic)
    expected_max_attempts = str(max_delivery_attempts)

    describe = _run([
        "gcloud", "pubsub", "subscriptions", "describe", subscription,
        "--project", project_id,
        "--format", "json",
    ])
    if describe.returncode == 0:
        current = {}
        try:
            current = json.loads(describe.stdout or "{}")
        except Exception:
            current = {}
        push = (current.get("pushConfig") or {}) if isinstance(current, dict) else {}
        oidc = (push.get("oidcToken") or {}) if isinstance(push, dict) else {}
        dead = (current.get("deadLetterPolicy") or {}) if isinstance(current, dict) else {}
        drift = []
        if (push.get("pushEndpoint") or "") != push_endpoint:
            drift.append("push_endpoint")
        if (oidc.get("serviceAccountEmail") or "") != service_account_email:
            drift.append("push_auth_service_account")
        if (dead.get("deadLetterTopic") or "") != dead_letter_topic_resource:
            drift.append("dead_letter_topic")
        if str(dead.get("maxDeliveryAttempts") or "") != expected_max_attempts:
            drift.append("max_delivery_attempts")

        if not drift:
            return _result("Pub/Sub subscription", True, subscription)
        if validate_only:
            return _result("Pub/Sub subscription", False, "needs update: {}".format(", ".join(drift)))

        _print_auto_action("Updating Pub/Sub subscription {} ({})".format(subscription, ", ".join(drift)))
        update = _run([
            "gcloud", "pubsub", "subscriptions", "update", subscription,
            "--project", project_id,
            "--push-endpoint", push_endpoint,
            "--push-auth-service-account", service_account_email,
            "--dead-letter-topic", dead_letter_topic,
            "--max-delivery-attempts", expected_max_attempts,
        ])
        if update.returncode == 0:
            return _result("Pub/Sub subscription", True, "updated {}".format(subscription))
        return _result("Pub/Sub subscription", False, _command_error(update))

    if validate_only:
        return _result("Pub/Sub subscription", False, "missing: {}".format(subscription))

    _print_auto_action("Creating Pub/Sub subscription {}".format(subscription))
    create = _run([
        "gcloud", "pubsub", "subscriptions", "create", subscription,
        "--project", project_id,
        "--topic", topic,
        "--push-endpoint", push_endpoint,
        "--push-auth-service-account", service_account_email,
        "--dead-letter-topic", dead_letter_topic,
        "--max-delivery-attempts", expected_max_attempts,
    ])
    if create.returncode == 0:
        return _result("Pub/Sub subscription", True, "created {}".format(subscription))
    return _result("Pub/Sub subscription", False, _command_error(create))


def _get_cloud_run_env(project_id: str, region: str, service_name: str) -> Dict[str, str]:
    payload = _run_json([
        "gcloud", "run", "services", "describe", service_name,
        "--project", project_id, "--region", region, "--format=json",
    ])
    if not isinstance(payload, dict):
        return {}
    out = {}
    containers = ((payload.get("spec") or {}).get("template") or {}).get("spec", {}).get("containers", [])
    if not containers:
        return out
    for item in containers[0].get("env", []) or []:
        name = item.get("name")
        value = item.get("value")
        if name:
            out[name] = value
    return out


_VALID_AUTH_MODES = ("dwd_preferred", "dwd_required", "user_oauth_only")
_DEFAULT_DLQ_TOPIC = "gmail-new-emails-dlq"
_DEFAULT_SUBSCRIPTION_MAX_DELIVERY_ATTEMPTS = 10
_PLACEHOLDER_PROJECT_IDS = frozenset({
    "placeholder",
    "your-project-id",
    "your_project_id",
    "project-id",
    "project_id",
    "my-project",
    "changeme",
    "<project-id>",
    "{project-id}",
})


def _is_placeholder_project_id(value: str) -> bool:
    raw = (value or "").strip().lower()
    if not raw:
        return False
    if raw in _PLACEHOLDER_PROJECT_IDS:
        return True
    return raw.startswith("placeholder")


def _resolve_subscription_retry_policy_defaults(
    project_id: str,
    subscription: str,
    fallback_dlq_topic: str,
    fallback_max_delivery_attempts: int,
    *,
    detect_dlq_topic: bool,
    detect_max_attempts: bool,
) -> Tuple[str, int, Optional[str]]:
    """
    Resolve effective DLQ topic / max-delivery-attempts.

    Intelligent defaulting behavior:
    - If the subscription exists and the caller kept defaults, preserve current subscription policy.
    - If caller provided explicit overrides (non-default values), keep caller values.
    Returns (dlq_topic, max_delivery_attempts, decision_note).
    """
    effective_topic = fallback_dlq_topic
    effective_attempts = fallback_max_delivery_attempts
    describe = _run([
        "gcloud", "pubsub", "subscriptions", "describe", subscription,
        "--project", project_id,
        "--format", "json",
    ])
    if describe.returncode != 0:
        return effective_topic, effective_attempts, None
    try:
        payload = json.loads(describe.stdout or "{}")
    except Exception:
        return effective_topic, effective_attempts, None
    if not isinstance(payload, dict):
        return effective_topic, effective_attempts, None
    policy = payload.get("deadLetterPolicy") or {}
    if not isinstance(policy, dict):
        policy = {}

    note_parts: List[str] = []
    topic_resource = str(policy.get("deadLetterTopic") or "").strip()
    if detect_dlq_topic and topic_resource:
        if "/topics/" in topic_resource:
            effective_topic = topic_resource.split("/topics/", 1)[1]
        else:
            effective_topic = topic_resource
        note_parts.append("DLQ topic={}".format(effective_topic))

    if detect_max_attempts:
        current_attempts = policy.get("maxDeliveryAttempts")
        try:
            parsed_attempts = int(str(current_attempts).strip()) if current_attempts is not None else 0
        except Exception:
            parsed_attempts = 0
        if 5 <= parsed_attempts <= 100:
            effective_attempts = parsed_attempts
            note_parts.append("max_delivery_attempts={}".format(effective_attempts))

    if not note_parts:
        return effective_topic, effective_attempts, None
    return effective_topic, effective_attempts, "subscription exists; preserving {}".format(", ".join(note_parts))


def _ensure_cloud_run_env(
    project_id: str,
    region: str,
    service_name: str,
    mailbox_user: str,
    bucket: str,
    default_machine_id: Optional[str],
    allowed_extensions: str,
    label_ids: Sequence[str],
    topic: str,
    client_id_secret: str,
    client_secret_secret: str,
    refresh_token_secret: str,
    validate_only: bool,
    current_env: Optional[Dict[str, str]] = None,
    auth_mode_override: Optional[str] = None,
) -> CheckResult:
    current = current_env if current_env is not None else _get_cloud_run_env(project_id, region, service_name)
    auth_mode = auth_mode_override
    if auth_mode is None or auth_mode not in _VALID_AUTH_MODES:
        existing = (current.get("AUTH_MODE") or "").strip().lower()
        auth_mode = existing if existing in _VALID_AUTH_MODES else "dwd_preferred"
    expected = {
        "PROJECT_ID": project_id,
        "MAILBOX_USER": mailbox_user,
        "GCS_BUCKET": bucket,
        "AUTH_MODE": auth_mode,
        "GMAIL_PUBSUB_TOPIC": topic or "gmail-new-emails",
        "GMAIL_OAUTH_CLIENT_ID_SECRET": client_id_secret,
        "GMAIL_OAUTH_CLIENT_SECRET_SECRET": client_secret_secret,
        "GMAIL_OAUTH_REFRESH_TOKEN_SECRET": refresh_token_secret,
        "ALLOWED_ATTACHMENT_EXTENSIONS": allowed_extensions,
    }
    if default_machine_id:
        expected["DEFAULT_MACHINE_ID"] = default_machine_id
    if label_ids:
        expected["GMAIL_LABEL_IDS"] = ",".join(label_ids)
    missing_or_mismatch = []
    for key, value in expected.items():
        if current.get(key) != value:
            missing_or_mismatch.append("{}={}".format(key, value))

    if not missing_or_mismatch:
        return _result("Cloud Run env vars", True, "already configured")
    if validate_only:
        return _result("Cloud Run env vars", False, "needs update: {}".format(", ".join(missing_or_mismatch)))

    _print_auto_action("Updating Cloud Run env vars for orchestrator")
    updates = {k: str(v) for k, v in expected.items() if current.get(k) != v}
    merged_env = dict(current)
    merged_env.update(updates)
    update = _update_cloud_run_env_via_file(project_id, region, service_name, merged_env)
    if update.returncode == 0:
        return _result("Cloud Run env vars", True, "updated")
    return _result("Cloud Run env vars", False, _command_error(update))


def _update_cloud_run_env_via_file(
    project_id: str,
    region: str,
    service_name: str,
    env_map: Dict[str, str],
) -> subprocess.CompletedProcess:
    """
    Update Cloud Run env vars using --env-vars-file.

    This avoids Windows/cmd escaping issues with --update-env-vars when values
    contain commas (e.g. ALLOWED_ATTACHMENT_EXTENSIONS=docx,csv).
    """
    path = ""
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
            for key in sorted(env_map):
                # JSON string literals are valid YAML scalar values.
                f.write("{}: {}\n".format(key, json.dumps(str(env_map[key]))))
            path = f.name
        return _run([
            "gcloud", "run", "services", "update", service_name,
            "--project", project_id,
            "--region", region,
            "--env-vars-file", path,
        ])
    finally:
        if path:
            try:
                os.unlink(path)
            except Exception:
                pass


def _offer_backfill(args: argparse.Namespace, ctx: Context) -> None:
    """
    Offer backlog backfill after preprocessor gate. When --no-interactive, print manual command.
    When interactive and has_backlog, prompt and run on confirm.
    """
    validate_only = bool(getattr(args, "validate_only", False))
    if validate_only:
        return
    if not ctx.service_url or not ctx.admin_secret:
        return

    if not getattr(args, "interactive", True):
        url = "{}/admin/backfill-backlog".format(ctx.service_url.rstrip("/"))
        print("\n{} To run backlog backfill later, call:".format(_tag_info()))
        print("  curl -X POST {} -H 'Content-Type: application/json' -d '{{\"secret\":\"<ADMIN_SHARED_SECRET>\"}}'".format(url))
        return

    # Interactive: preview first
    ok, resp, err = _call_cloud_run_admin_post(
        args.project_id,
        args.region,
        args.service_name,
        ctx.service_url,
        "/admin/backfill-backlog",
        {"secret": ctx.admin_secret, "preview_only": True},
        validate_only=validate_only,
        interactive=True,
    )
    if not ok:
        print("\n{} Backlog preview failed: {}".format(_tag_info(), err))
        return
    if not (isinstance(resp, dict) and resp.get("has_backlog")):
        return

    if not _confirm("Run backlog backfill for labeled messages now?", default=False):
        return

    body = {"secret": ctx.admin_secret, "batch_size": 20}
    ok2, resp2, err2 = _call_cloud_run_admin_post(
        args.project_id,
        args.region,
        args.service_name,
        ctx.service_url,
        "/admin/backfill-backlog",
        body,
        validate_only=validate_only,
        interactive=True,
    )
    if not ok2:
        print("{} Backfill failed: {}".format(_tag_fail(), err2))
        return
    if isinstance(resp2, dict):
        failed = resp2.get("failed_count", 0)
        if failed > 0:
            print("{} Some messages failed (failed_count={})".format(_tag_fail(), failed))
        tag = _tag_ok() if failed == 0 else _tag_info()
        print("{} Backfill: scanned={} processed={} skipped={} failed={}".format(
            tag,
            resp2.get("scanned_count", 0),
            resp2.get("processed_count", 0),
            resp2.get("skipped_count", 0),
            resp2.get("failed_count", 0),
        ))
        ev_path = write_backfill_evidence_artifact(
            resp2,
            args.project_id,
            args.service_name,
            args.region,
        )
        if ev_path:
            print("{} Evidence: {}".format(_tag_info(), ev_path))


def _maybe_promote_preprocessor_enforce(
    args,
    validate_only: bool,
    gate_passed: bool,
    env: Dict[str, str],
    project_id: str,
    region: str,
    service_name: str,
    update_fn=None,
    confirm_fn=None,
    on_fail=None,
) -> bool:
    """
    Apply PREPROCESSOR_MODE=enforce when gate passes and confirmed.
    Returns True if promotion was applied successfully, False otherwise.
    Pure logic for unit testing; inject update_fn/confirm_fn for tests.
    on_fail(proc): optional callback when update fails, for printing.
    """
    if validate_only:
        return False
    if not gate_passed or not getattr(args, "promote_preprocessor_enforce", False):
        return False
    do_confirm = confirm_fn or _confirm
    if getattr(args, "interactive", True):
        if not do_confirm(
            "Promote PREPROCESSOR_MODE to enforce? This will skip queue writes for rejected candidates.",
            default=False,
        ):
            return False
    env_for_update = dict(env)
    env_for_update["PREPROCESSOR_MODE"] = "enforce"
    _print_auto_action("Setting PREPROCESSOR_MODE=enforce on Cloud Run")
    do_update = update_fn or _update_cloud_run_env_via_file
    proc = do_update(project_id, region, service_name, env_for_update)
    if proc.returncode != 0:
        if on_fail:
            on_fail(proc)
        return False
    env["PREPROCESSOR_MODE"] = "enforce"
    return True


def _register_watch(
    project_id: str,
    mailbox_user: str,
    topic: str,
    client_id_secret: str,
    client_secret_secret: str,
    refresh_token_secret: str,
    label_ids: Optional[List[str]] = None,
) -> Tuple[bool, str, str]:
    try:
        from google.auth.transport.requests import Request
        from google.cloud import secretmanager
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
    except Exception as exc:
        return (
            False,
            "python dependencies missing for Gmail watch registration: {}. "
            "Install locally with: pip install google-api-python-client google-auth google-auth-oauthlib google-cloud-secret-manager".format(exc),
            "",
        )

    client = secretmanager.SecretManagerServiceClient()

    def secret_value(name: str) -> str:
        full_name = name if name.startswith("projects/") else "projects/{}/secrets/{}/versions/latest".format(project_id, name)
        if "/versions/" not in full_name:
            full_name = "{}/versions/latest".format(full_name)
        response = client.access_secret_version(request={"name": full_name})
        return response.payload.data.decode("utf-8")

    try:
        refresh_token = secret_value(refresh_token_secret)
        oauth_client_id = secret_value(client_id_secret)
        oauth_client_secret = secret_value(client_secret_secret)

        creds = Credentials(
            token=None,
            refresh_token=refresh_token,
            client_id=oauth_client_id,
            client_secret=oauth_client_secret,
            token_uri="https://oauth2.googleapis.com/token",
            scopes=["https://www.googleapis.com/auth/gmail.modify"],
        )
        creds.refresh(Request())

        gmail = build("gmail", "v1", credentials=creds, cache_discovery=False)
        detail, history_id, _ = watch.register_gmail_watch_impl(
            gmail, project_id, mailbox_user, topic, label_ids or []
        )
        return True, detail, history_id
    except Exception as exc:
        msg = str(exc)
        if "invalid_client" in msg.lower():
            return (
                False,
                "Gmail OAuth refresh failed with invalid_client. "
                "The refresh token does not match the current OAuth client_id/client_secret in Secret Manager "
                "(or that OAuth client is disabled/deleted). Recreate/refresh the token using the same client JSON "
                "and update secrets '{}', '{}', '{}'.".format(
                    client_id_secret, client_secret_secret, refresh_token_secret
                ),
            ), ""
        return False, "Gmail watch registration failed: {}".format(msg), ""


def _check_scheduler_job(project_id: str, region: str, job_name: str) -> CheckResult:
    proc = _run([
        "gcloud", "scheduler", "jobs", "describe", job_name,
        "--project", project_id, "--location", region,
        "--format", "json",
    ])
    if proc.returncode != 0:
        return _result("Cloud Scheduler job", False, "missing: {}".format(job_name))
    try:
        data = json.loads(proc.stdout or "{}")
        target = (data.get("httpTarget") or {})
        uri = target.get("uri") or ""
        method = target.get("httpMethod") or ""
        if uri and method:
            return _result("Cloud Scheduler job", True, "{} ({})".format(job_name, method))
        return _result("Cloud Scheduler job", True, job_name)
    except Exception:
        return _result("Cloud Scheduler job", True, job_name)


def _ensure_cloud_run_invoker_binding(
    project_id: str,
    region: str,
    service_name: str,
    member: str,
    validate_only: bool,
) -> CheckResult:
    """Ensure a principal can invoke a Cloud Run service (required for Cloud Scheduler OIDC SA)."""
    get_policy = _run([
        "gcloud", "run", "services", "get-iam-policy", service_name,
        "--project", project_id, "--region", region,
        "--format", "json",
    ])
    if get_policy.returncode != 0:
        return _result("Cloud Run invoker IAM", False, _command_error(get_policy))
    try:
        policy = json.loads(get_policy.stdout or "{}")
        for binding in policy.get("bindings", []) or []:
            if binding.get("role") != "roles/run.invoker":
                continue
            members = binding.get("members", []) or []
            if member in members:
                return _result("Cloud Run invoker IAM", True, "configured ({})".format(member))
    except Exception:
        pass

    if validate_only:
        return _result(
            "Cloud Run invoker IAM",
            False,
            "missing binding for {}. Fix: gcloud run services add-iam-policy-binding {} --project {} --region {} --member {} --role roles/run.invoker".format(
                member, service_name, project_id, region, member
            ),
        )
    _print_auto_action("Granting roles/run.invoker on Cloud Run service to {}".format(member))
    add = _run([
        "gcloud", "run", "services", "add-iam-policy-binding", service_name,
        "--project", project_id, "--region", region,
        "--member", member,
        "--role", "roles/run.invoker",
        "--quiet",
    ])
    if add.returncode == 0:
        return _result("Cloud Run invoker IAM", True, "configured ({})".format(member))
    return _result("Cloud Run invoker IAM", False, _command_error(add))


def _ensure_token_creator_self(
    project_id: str,
    service_account_email: str,
    validate_only: bool,
) -> CheckResult:
    """Ensure the orchestrator SA can call IAM Credentials signJwt for keyless DWD (Token Creator on self)."""
    member = "serviceAccount:{}".format(service_account_email)
    get_policy = _run([
        "gcloud", "iam", "service-accounts", "get-iam-policy", service_account_email,
        "--project", project_id,
        "--format", "json",
    ])
    if get_policy.returncode != 0:
        return _result("IAM Token Creator (self)", False, _command_error(get_policy))
    try:
        policy = json.loads(get_policy.stdout or "{}")
        for binding in policy.get("bindings", []) or []:
            if binding.get("role") != "roles/iam.serviceAccountTokenCreator":
                continue
            if member in (binding.get("members", []) or []):
                return _result("IAM Token Creator (self)", True, "configured ({})".format(member))
    except Exception:
        pass

    if validate_only:
        return _result(
            "IAM Token Creator (self)",
            False,
            "missing. Fix: gcloud iam service-accounts add-iam-policy-binding {} --project {} --member {} --role roles/iam.serviceAccountTokenCreator".format(
                service_account_email, project_id, member
            ),
        )
    _print_auto_action("Granting roles/iam.serviceAccountTokenCreator on {} to itself".format(service_account_email))
    add = _run([
        "gcloud", "iam", "service-accounts", "add-iam-policy-binding", service_account_email,
        "--project", project_id,
        "--member", member,
        "--role", "roles/iam.serviceAccountTokenCreator",
        "--quiet",
    ])
    if add.returncode == 0:
        return _result("IAM Token Creator (self)", True, "configured ({})".format(member))
    return _result("IAM Token Creator (self)", False, _command_error(add))


def _ensure_scheduler_job(
    project_id: str,
    region: str,
    job_name: str,
    service_url: str,
    service_account_email: str,
    admin_secret: str,
    history_id_hint: str,
    validate_only: bool,
) -> CheckResult:
    expected_uri = "{}/admin/resume-history".format(service_url)
    # Cloud Run expects aud = service URL (no path). If you set aud to the path, it can break auth.
    expected_aud = service_url
    # Some deployed revisions historically required a numeric history_id in the payload.
    # If we have a valid hint from watch registration, include it to avoid 400s.
    hint = (history_id_hint or "").strip()
    payload: Dict[str, Any] = {"secret": admin_secret}
    if hint.isdigit():
        # Use a JSON number (int) to be compatible with older deployments that used pydantic models
        # expecting an integer history_id.
        payload["history_id"] = int(hint)
    expected_body = json.dumps(payload)

    def _headers_args_for_update() -> List[str]:
        # Newer gcloud: update uses --update-headers; older builds used --headers.
        return ["--update-headers", "Content-Type=application/json"]

    def _headers_args_for_create() -> List[str]:
        # Create commonly supports --headers; some versions also accept --update-headers.
        return ["--headers", "Content-Type=application/json"]

    def _scheduler_update(args_list: List[str]) -> subprocess.CompletedProcess:
        proc = _run(args_list)
        if proc.returncode == 0:
            return proc
        err = _command_error(proc)
        if "unrecognized arguments" in err.lower() and "--update-headers" in err:
            # Retry for older gcloud.
            retry = [a for a in args_list if a != "--update-headers"]
            retry.insert(retry.index("Content-Type=application/json"), "--headers")
            return _run(retry)
        if "unrecognized arguments" in err.lower() and "--headers" in err:
            # Retry for newer gcloud.
            retry = [a for a in args_list if a != "--headers"]
            retry.insert(retry.index("Content-Type=application/json"), "--update-headers")
            return _run(retry)
        return proc

    def _scheduler_create(args_list: List[str]) -> subprocess.CompletedProcess:
        proc = _run(args_list)
        if proc.returncode == 0:
            return proc
        err = _command_error(proc)
        if "unrecognized arguments" in err.lower() and "--headers" in err:
            # Retry for newer gcloud.
            retry = [a for a in args_list if a != "--headers"]
            retry.insert(retry.index("Content-Type=application/json"), "--update-headers")
            return _run(retry)
        if "unrecognized arguments" in err.lower() and "--update-headers" in err:
            # Retry for older gcloud.
            retry = [a for a in args_list if a != "--update-headers"]
            retry.insert(retry.index("Content-Type=application/json"), "--headers")
            return _run(retry)
        return proc

    # If it exists, verify key attributes. If mismatched, update in auto-remediation mode.
    describe = _run([
        "gcloud", "scheduler", "jobs", "describe", job_name,
        "--project", project_id, "--location", region,
        "--format", "json",
    ])
    if describe.returncode == 0:
        try:
            data = json.loads(describe.stdout or "{}")
            target = (data.get("httpTarget") or {})
            uri = target.get("uri") or ""
            method = (target.get("httpMethod") or "").upper()
            oidc = (target.get("oidcToken") or {})
            oidc_sa = oidc.get("serviceAccountEmail") or ""
            aud = oidc.get("audience") or ""
            body_b64 = target.get("body") or ""

            ok = True
            mismatches: List[str] = []
            if uri != expected_uri:
                ok = False
                mismatches.append("uri")
            if method != "POST":
                ok = False
                mismatches.append("httpMethod")
            if oidc_sa != service_account_email:
                ok = False
                mismatches.append("oidcServiceAccountEmail")
            # Always set/require explicit audience. Relying on default audience can break Cloud Run auth.
            if aud != expected_aud:
                ok = False
                mismatches.append("oidcAudience")
            if not body_b64:
                ok = False
                mismatches.append("messageBody")
            else:
                # Detect known-bad historical payload that caused 5xx loops (wrote non-numeric historyId into state).
                try:
                    decoded = base64.b64decode(body_b64.encode("utf-8")).decode("utf-8", errors="replace").strip()
                    if "bootstrap-required" in decoded:
                        ok = False
                        mismatches.append("messageBody")
                    else:
                        # Compare payload shape without printing secrets.
                        try:
                            parsed = json.loads(decoded) if decoded else {}
                            if not isinstance(parsed, dict):
                                raise ValueError("body JSON is not an object")
                            if str(parsed.get("secret") or "") != admin_secret:
                                ok = False
                                mismatches.append("messageBodySecret")
                            if hint.isdigit():
                                existing_hid = parsed.get("history_id") or parsed.get("historyId") or ""
                                if not str(existing_hid).isdigit() or str(existing_hid) != hint:
                                    ok = False
                                    mismatches.append("messageBodyHistoryId")
                        except Exception:
                            ok = False
                            mismatches.append("messageBody")
                except Exception:
                    ok = False
                    mismatches.append("messageBody")

            if ok:
                return _result("Cloud Scheduler job", True, job_name)

            if validate_only:
                return _result("Cloud Scheduler job", False, "needs update (mismatch: {})".format(", ".join(mismatches)))

            _print_auto_action("Updating Cloud Scheduler job {} (mismatch: {})".format(job_name, ", ".join(mismatches)))
            update = _scheduler_update([
                "gcloud", "scheduler", "jobs", "update", "http", job_name,
                "--project", project_id, "--location", region,
                "--schedule", "0 */6 * * *",
                "--uri", expected_uri,
                "--http-method", "POST",
                *_headers_args_for_update(),
                "--message-body", expected_body,
                "--oidc-service-account-email", service_account_email,
                "--oidc-token-audience", expected_aud,
                "--time-zone", "Etc/UTC",
            ])
            if update.returncode == 0:
                return _result("Cloud Scheduler job", True, "updated {}".format(job_name))
            return _result("Cloud Scheduler job", False, _command_error(update))
        except Exception:
            # If parsing fails, treat as existing.
            return _result("Cloud Scheduler job", True, job_name)

    existing = _result("Cloud Scheduler job", False, "missing: {}".format(job_name))
    if validate_only:
        return existing

    _print_auto_action("Creating Cloud Scheduler job {}".format(job_name))
    create = _scheduler_create([
        "gcloud", "scheduler", "jobs", "create", "http", job_name,
        "--project", project_id, "--location", region,
        "--schedule", "0 */6 * * *",
        "--uri", expected_uri,
        "--http-method", "POST",
        *_headers_args_for_create(),
        "--message-body", expected_body,
        "--oidc-service-account-email", service_account_email,
        "--oidc-token-audience", expected_aud,
        "--time-zone", "Etc/UTC",
    ])
    if create.returncode == 0:
        return _result("Cloud Scheduler job", True, "created {}".format(job_name))
    return _result("Cloud Scheduler job", False, _command_error(create))


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate and auto-complete MediLink cloud setup")
    parser.add_argument("--project-id", default=None, help="GCP Project ID (optional in interactive mode)")
    parser.add_argument("--mailbox-user", default="daniel@strategicimplementation.us")
    parser.add_argument("--region", default="us-central1")
    parser.add_argument("--service-name", default="medilink-gmail-orchestrator")
    parser.add_argument("--service-account-name", default="medilink-gmail-orchestrator")
    parser.add_argument("--bucket", default="medilink-gmail-staging")
    parser.add_argument("--topic", default="gmail-new-emails")
    parser.add_argument("--subscription", default="gmail-new-emails-sub")
    parser.add_argument(
        "--dlq-topic",
        default=_DEFAULT_DLQ_TOPIC,
        help=(
            "Dead-letter topic override for Pub/Sub retries. "
            "When left at default, the script auto-detects and preserves the current subscription policy."
        ),
    )
    parser.add_argument(
        "--subscription-max-delivery-attempts",
        type=int,
        default=_DEFAULT_SUBSCRIPTION_MAX_DELIVERY_ATTEMPTS,
        help=(
            "Pub/Sub max delivery attempts before dead-lettering (5-100). "
            "When left at default, the script auto-detects and preserves the current subscription policy."
        ),
    )
    parser.add_argument(
        "--default-machine-id",
        default="clinic-default",
        help=(
            "Default machine_id when inbound messages do not specify a machine. "
            "Prevents /admin/resume-history from failing with 'Unable to determine machine id'."
        ),
    )
    parser.add_argument("--allowed-extensions", default="docx,csv")
    parser.add_argument("--label-id", action="append", default=None,
                        help="Gmail label ID to watch (repeat for multiple)")
    parser.add_argument("--client-id-secret", default="gmail_oauth_client_id")
    parser.add_argument("--client-secret-secret", default="gmail_oauth_client_secret")
    parser.add_argument("--refresh-token-secret", default="gmail_oauth_refresh_token")
    parser.add_argument("--oauth-client-json", default="",
                        help="Optional path to OAuth client JSON (used for token tooling in interactive mode)")
    parser.add_argument("--scheduler-job", default="gmail-watch-refresh")
    parser.add_argument("--artifact-repo", default="medilink-repo",
                        help="Artifact Registry Docker repo name (used when building/deploying; 2024+ preferred over gcr.io)")
    parser.add_argument("--build-service-account", default="",
                        help="Optional build SA email (or full resource path) for gcloud builds submit --service-account")
    parser.add_argument("--build-service-account-name", default="medilink-build-sa",
                        help="Fallback SA name to create when default Cloud Build SA is missing")
    parser.add_argument(
        "--deploy",
        action="store_true",
        help=(
            "Build and deploy the current local orchestrator code to Cloud Run (even if the service already exists). "
            "Uses Cloud Build + Artifact Registry. This is opt-in because it changes production runtime."
        ),
    )
    parser.add_argument("--validate-only", action="store_true", help="Do not apply changes; checks only")
    parser.add_argument("--verify-runtime", action="store_true",
                        help="Best-effort runtime verification: run the scheduler job once and scan Cloud Run logs for 'Gmail auth mode:' lines (does not require a rebuild).")
    parser.add_argument(
        "--skip-verify-runtime",
        action="store_true",
        help=(
            "Skip runtime verification even in interactive auto-remediation runs. "
            "By default, the script runs a best-effort verification after a successful remediation."
        ),
    )
    parser.add_argument(
        "--no-auto-verify-fixes",
        action="store_true",
        help=(
            "In --verify-runtime, disable safe auto-fixes (DEFAULT_MACHINE_ID, SERVICE_ACCOUNT_EMAIL, scheduler invoker IAM) "
            "and only print diagnostics."
        ),
    )
    parser.add_argument(
        "--attempt-direct-admin-call",
        action="store_true",
        help="In --verify-runtime, attempt a direct call to /admin/resume-history for verification (may require SA impersonation). Default is off to avoid interactive stalls.",
    )
    parser.add_argument("--set-auth-mode", default=None,
                        choices=["dwd_preferred", "dwd_required", "user_oauth_only"],
                        help="Set AUTH_MODE on Cloud Run (ignored in --validate-only; requires confirmation unless --no-interactive)")
    parser.add_argument(
        "--promote-dwd-required",
        action="store_true",
        help=(
            "After runtime verification confirms keyless DWD is working, set AUTH_MODE=dwd_required and re-verify. "
            "In interactive mode, the script may prompt to promote even without this flag. "
            "In --no-interactive mode, this flag is required to promote."
        ),
    )
    parser.add_argument("--interactive", action="store_true", default=True,
                        help="Query GCP and prompt for or confirm settings (default)")
    parser.add_argument("--no-interactive", action="store_false", dest="interactive",
                        help="Use only CLI args; require --project-id")
    parser.add_argument(
        "--color",
        default="auto",
        choices=["auto", "always", "never"],
        help="Colorize output (default: auto). Use 'never' for CI/log files.",
    )
    parser.add_argument(
        "--cleanup-cloudbuild-sources",
        action="store_true",
        help="After success, delete Cloud Build submit source archives (tgz) from staging buckets (safe: skips if builds are running).",
    )
    parser.add_argument(
        "--cleanup-cloudbuild-sources-days",
        type=int,
        default=2,
        help="Only delete Cloud Build source archives older than this many days. Use 0 to delete all matching source archives.",
    )
    parser.add_argument(
        "--cleanup-cloudbuild-sources-all-regions",
        action="store_true",
        help="Also scan/delete from other <project>_<region>_cloudbuild buckets (not just the configured region).",
    )
    parser.add_argument(
        "--promote-preprocessor-enforce",
        action="store_true",
        help="When preprocessor gate passes, set PREPROCESSOR_MODE=enforce on Cloud Run. Requires gate pass.",
    )
    return parser.parse_args(argv)


def _print_config_usage() -> None:
    """Print one-line reminder for non-interactive usage."""
    print("Tip: Run without --project-id for interactive mode. With --no-interactive you must pass --project-id.")


def _print_required_manual_steps() -> None:
    """Print the list of things that must be obtained manually from GCP / OAuth."""
    print("\n--- Required manual steps (get these from GCP Console / OAuth when needed) ---")
    for idx, step in enumerate(REQUIRED_MANUAL_STEPS, 1):
        print("\n{}. {}".format(idx, step.title))
        print("   Why: {}".format(step.why))
        for line in step.instructions:
            print("   - {}".format(line))
    print("\n--- End of required manual steps ---\n")


def gather_config_interactive(args: argparse.Namespace) -> argparse.Namespace:
    """Query GCP where possible and prompt for or confirm each setting. Returns args with values set."""
    _require_gcloud()
    if args.interactive:
        print("Using Python {} ({})".format(sys.version.split()[0], sys.executable))
    if not args.interactive:
        if not args.project_id:
            _print_config_usage()
            raise RuntimeError("--project-id is required when running with --no-interactive")
        if _is_placeholder_project_id(args.project_id):
            raise RuntimeError(
                "Detected placeholder --project-id '{}'. Use a real project id (example: genial-analyzer-476721-f8).".format(
                    args.project_id
                )
            )
        return args

    _print_required_manual_steps()

    # --- Project ID (required before live discovery) ---
    project_id = (args.project_id or "").strip()
    current = _get_project_from_gcloud()
    if not project_id:
        if current:
            if _is_placeholder_project_id(current):
                print("Current gcloud project '{}' looks like a placeholder and will not be used.".format(current))
            else:
                project_id = current
                print("Using current gcloud project '{}' as default.".format(current))
        else:
            project_id = _prompt("Enter GCP Project ID", "genial-analyzer-476721-f8")
    if _is_placeholder_project_id(project_id):
        print("Project ID '{}' looks like a placeholder.".format(project_id))
        project_id = _prompt("Enter GCP Project ID", "genial-analyzer-476721-f8")
        if _is_placeholder_project_id(project_id):
            raise RuntimeError(
                "Project ID '{}' is still placeholder-like. Aborting to prevent accidental writes.".format(project_id)
            )
    if not project_id:
        raise RuntimeError("Project ID is required. Set it with --project-id or in interactive prompt.")

    # Ensure project for subsequent gcloud calls
    _run(["gcloud", "config", "set", "project", project_id])
    args.project_id = project_id

    # --- Discover defaults from GCP first ---
    info = _get_project_info(project_id)
    if info:
        proj_num = info.get("projectNumber") or "(unknown)"
        print("GCP Project: {} (number: {})".format(project_id, proj_num))
    else:
        print("Could not fetch project details from GCP; using project ID '{}'.".format(project_id))

    print("Discovering Cloud Run service defaults...")
    run_services: List[Tuple[str, str, str]] = []
    quick_service = _try_get_cloud_run_service(project_id, args.region, args.service_name)
    if quick_service:
        run_services = [quick_service]
    else:
        run_services = _list_cloud_run_services(project_id)
    if run_services:
        if len(run_services) > 1:
            print("Cloud Run services found: {} (defaulting to first for detected config)".format(
                ", ".join(["{}@{}".format(name, reg) for reg, name, _ in run_services])
            ))
        region, svc_name, url = run_services[0]
        args.region = region
        args.service_name = svc_name
        if url:
            print("Detected Cloud Run default: '{}' in region '{}' ({})".format(svc_name, region, url))
        else:
            print("Detected Cloud Run default: '{}' in region '{}'".format(svc_name, region))

        # Pull a few useful defaults from the existing service env (when present).
        # This keeps re-runs idempotent and avoids reintroducing known runtime 500s.
        try:
            env_vars = _get_cloud_run_env(project_id, args.region, args.service_name)
        except Exception:
            env_vars = {}
        existing_default_machine_id = (env_vars.get("DEFAULT_MACHINE_ID") or "").strip()
        if existing_default_machine_id:
            args.default_machine_id = existing_default_machine_id
    else:
        print("No Cloud Run services found. Keeping configured defaults for region/service.")

    buckets = _list_buckets(project_id)
    suggested_bucket = args.bucket
    if buckets:
        medilink_buckets = [b for b in buckets if "medilink" in b.lower()]
        if medilink_buckets:
            suggested_bucket = medilink_buckets[0]
        print("Existing buckets: {}".format(", ".join(buckets) or "(none)"))
    args.bucket = suggested_bucket

    topics = _list_pubsub_topics(project_id)
    if topics:
        gmail_topics = [t for t in topics if "gmail" in t.lower() or "email" in t.lower()]
        if gmail_topics:
            args.topic = gmail_topics[0]
        print("Pub/Sub topics: {}".format(", ".join(topics)))

    # Auto-detect current subscription retry policy when caller did not explicitly override.
    detect_dlq_topic = (args.dlq_topic == _DEFAULT_DLQ_TOPIC)
    detect_max_attempts = (
        int(args.subscription_max_delivery_attempts) == _DEFAULT_SUBSCRIPTION_MAX_DELIVERY_ATTEMPTS
    )
    resolved_dlq_topic, resolved_attempts, decision_note = _resolve_subscription_retry_policy_defaults(
        project_id=project_id,
        subscription=args.subscription,
        fallback_dlq_topic=args.dlq_topic,
        fallback_max_delivery_attempts=int(args.subscription_max_delivery_attempts),
        detect_dlq_topic=detect_dlq_topic,
        detect_max_attempts=detect_max_attempts,
    )
    args.dlq_topic = resolved_dlq_topic
    args.subscription_max_delivery_attempts = resolved_attempts
    if decision_note:
        _emit_decision("Pub/Sub retry policy auto-default: {}".format(decision_note))

    print("\n--- Detected defaults ---")
    print("  Project ID: {}".format(args.project_id))
    print("  Region: {}".format(args.region))
    print("  Service name: {}".format(args.service_name))
    print("  Bucket: {}".format(args.bucket))
    print(
        "  Topic: {} -> Subscription: {} (DLQ: {}, max attempts: {})".format(
            args.topic,
            args.subscription,
            args.dlq_topic,
            args.subscription_max_delivery_attempts,
        )
    )
    print("  Mailbox: {}".format(args.mailbox_user))
    dmid = (args.default_machine_id or "").strip() or "(unset)"
    print("  Default machine_id: {}".format(dmid))
    print("  Secret names: client_id='{}', client_secret='{}', refresh_token='{}'".format(
        args.client_id_secret, args.client_secret_secret, args.refresh_token_secret))
    print("---")
    if not _confirm("Use these detected defaults", default=True):
        print("Enter changes (press Enter to keep each current value).")
        args.region = _prompt("Region", args.region)
        args.service_name = _prompt("Service name", args.service_name)
        args.bucket = _prompt("Bucket name", args.bucket)
        args.topic = _prompt("Topic name", args.topic)
        args.subscription = _prompt("Subscription name", args.subscription)
        args.dlq_topic = _prompt("DLQ topic name", args.dlq_topic)
        attempts_raw = _prompt(
            "Subscription max delivery attempts (5-100)",
            str(args.subscription_max_delivery_attempts),
        )
        try:
            args.subscription_max_delivery_attempts = int(attempts_raw)
        except Exception:
            print("Invalid max delivery attempts '{}'; keeping {}.".format(
                attempts_raw, args.subscription_max_delivery_attempts
            ))
        args.mailbox_user = _prompt("Mailbox user (Gmail address)", args.mailbox_user)
        args.default_machine_id = _prompt("Default machine_id", args.default_machine_id)
        print("Secret Manager secret names (these are names, not secret values).")
        args.client_id_secret = _prompt("client_id secret name", args.client_id_secret)
        args.client_secret_secret = _prompt("client_secret secret name", args.client_secret_secret)
        args.refresh_token_secret = _prompt("refresh_token secret name", args.refresh_token_secret)

    # --- OAuth client JSON: query GCP to see if secrets already have values ---
    oauth_client_config: Optional[Dict[str, Any]] = None
    oauth_client_json_path = (args.oauth_client_json or "").strip()
    has_client_id = _check_secret_has_version(project_id, args.client_id_secret)
    has_client_secret = _check_secret_has_version(project_id, args.client_secret_secret)
    if has_client_id and has_client_secret:
        print("OAuth client_id and client_secret secrets already have values in Secret Manager.")
        # Default to NO: overwriting OAuth client secrets is disruptive and should be opt-in.
        if _confirm("Add or overwrite from a new OAuth client JSON file", default=False):
            path = _prompt("Path to OAuth client JSON (installed or web format)", oauth_client_json_path or "")
            if path:
                oauth_client_config = _parse_oauth_client_json(path)
                if oauth_client_config:
                    oauth_client_json_path = path
                    block = oauth_client_config.get("installed") or oauth_client_config.get("web") or {}
                    cid, csec = block.get("client_id"), block.get("client_secret")
                    if cid and csec:
                        _ensure_secret_created(project_id, args.client_id_secret)
                        _ensure_secret_created(project_id, args.client_secret_secret)
                        if _add_secret_version_gcloud(project_id, args.client_id_secret, cid)[0] and _add_secret_version_gcloud(project_id, args.client_secret_secret, csec)[0]:
                            print("Client ID and client secret updated in Secret Manager.")
                        else:
                            print("Warning: failed to add one or both secret versions.")
                    else:
                        print("JSON missing client_id or client_secret; skipping.")
                        oauth_client_config = None
                else:
                    print("Could not parse JSON; skipping.")
    else:
        print("OAuth client_id and/or client_secret secrets are missing or have no versions.")
        path = _prompt("Path to OAuth client JSON file (installed or web format) [Enter to skip]", oauth_client_json_path or "")
        if path:
            oauth_client_config = _parse_oauth_client_json(path)
            if oauth_client_config:
                oauth_client_json_path = path
                block = oauth_client_config.get("installed") or oauth_client_config.get("web") or {}
                cid, csec = block.get("client_id"), block.get("client_secret")
                if cid and csec:
                    if _ensure_secret_created(project_id, args.client_id_secret)[0] and _ensure_secret_created(project_id, args.client_secret_secret)[0]:
                        if _add_secret_version_gcloud(project_id, args.client_id_secret, cid)[0] and _add_secret_version_gcloud(project_id, args.client_secret_secret, csec)[0]:
                            print("Client ID and client secret stored in Secret Manager.")
                        else:
                            print("Warning: failed to add one or both secret versions.")
                else:
                    print("JSON missing client_id or client_secret; skipping.")
                    oauth_client_config = None
            else:
                print("Could not parse JSON; skipping.")

    # --- Optional: OAuth flow to get refresh token and store in Secret Manager ---
    if oauth_client_config and _confirm("Run OAuth flow now to get refresh token and store in Secret Manager? (opens browser)", default=False):
        ok, msg = _run_oauth_flow_and_store_refresh_token(
            project_id=project_id,
            client_config=oauth_client_config,
            refresh_token_secret=args.refresh_token_secret,
            mailbox_user=args.mailbox_user,
            client_id_secret_name=args.client_id_secret,
            client_secret_secret_name=args.client_secret_secret,
            oauth_client_json_path=oauth_client_json_path,
            prefer_powershell=(os.name == "nt"),
        )
        if ok:
            print("Refresh token stored. Gmail watch will be registered during validation if Cloud Run is deployed.")
        else:
            print("OAuth flow failed: {}".format(msg))
            print("You can run tools/get_gmail_oauth_token.ps1 later (or add the refresh token to Secret Manager manually).")

    if oauth_client_json_path:
        args.oauth_client_json = oauth_client_json_path

    print("\n--- Configuration summary ---")
    print("  Project ID: {}".format(args.project_id))
    print("  Region: {}".format(args.region))
    print("  Service name: {}".format(args.service_name))
    print("  Bucket: {}".format(args.bucket))
    print(
        "  Topic: {} -> Subscription: {} (DLQ: {}, max attempts: {})".format(
            args.topic,
            args.subscription,
            args.dlq_topic,
            args.subscription_max_delivery_attempts,
        )
    )
    print("  Mailbox: {}".format(args.mailbox_user))
    dmid2 = (args.default_machine_id or "").strip() or "(unset)"
    print("  Default machine_id: {}".format(dmid2))
    build_sa_summary = args.build_service_account or "(auto: use Cloud Build default; fallback to {} if missing)".format(args.build_service_account_name)
    print("  Build service account: {}".format(build_sa_summary))
    print("---\n")
    if not _confirm("Proceed with validation and auto-remediation using this config"):
        raise RuntimeError("Aborted by user.")

    return args


def _build_manual_steps(args: argparse.Namespace, checks: List[CheckResult], ctx: Context) -> List[ManualStep]:
    failed = {c.name for c in checks if not c.ok}
    steps = []

    if "Cloud Run deploy attempt" in failed:
        svc = args.service_name
        proj = args.project_id
        region = args.region
        repo = getattr(args, "artifact_repo", "medilink-repo")
        sa = "{}@{}.iam.gserviceaccount.com".format(args.service_account_name, proj)
        image = "{}-docker.pkg.dev/{}/{}/{}".format(region, proj, repo, svc)
        build_sa_email = _recommended_build_service_account_email(
            project_id=proj,
            region=region,
            explicit_build_service_account=args.build_service_account,
            fallback_account_name=args.build_service_account_name,
        )
        build_sa_resource = ""
        if build_sa_email:
            build_sa_resource = " --service-account={}".format(_service_account_resource_name(proj, build_sa_email))

        instructions = [
            "If you intended to roll out new code, rebuild + redeploy is required (a deploy of an existing tag does not change the image digest).",
            "Re-run this script with: py -3.11 cloud/orchestrator/validate_and_complete_setup.py --deploy",
            "Manual (Cloud Build): open terminal in cloud/orchestrator, then:",
            "  gcloud builds submit --tag {} --project {} --region {} --default-buckets-behavior=regional-user-owned-bucket{} .".format(
                image, proj, region, build_sa_resource
            ),
            "  gcloud run deploy {} --image {} --region {} --project {} --service-account {} --no-allow-unauthenticated".format(
                svc, image, region, proj, sa
            ),
        ]
        if shutil.which("docker"):
            instructions.append(
                "If Cloud Build returns NOT_FOUND repeatedly: build and push with Docker instead: docker build -t {} . ; gcloud auth configure-docker {}-docker.pkg.dev ; docker push {} ; then deploy.".format(
                    image, region, image
                )
            )
        else:
            instructions.append(
                "If Cloud Build returns NOT_FOUND and Docker is not installed on this machine: install Docker Desktop (or build/push from another machine/CI) then deploy."
            )
        instructions.append("If NOT_FOUND persists across environments: open a Google Cloud support case; the project may need Cloud Build backend provisioning repair.")
        steps.append(
            ManualStep(
                title="Deploy updated Cloud Run revision",
                why="A deploy attempt failed, so the running service may still be on an older image (runtime fixes will not take effect until a new image digest is deployed).",
                instructions=instructions,
            )
        )

    if "Cloud Run service" in failed:
        svc = args.service_name
        proj = args.project_id
        region = args.region
        repo = getattr(args, "artifact_repo", "medilink-repo")
        sa = "{}@{}.iam.gserviceaccount.com".format(args.service_account_name, proj)
        image = "{}-docker.pkg.dev/{}/{}/{}".format(region, proj, repo, svc)
        build_sa_email = _recommended_build_service_account_email(
            project_id=proj,
            region=region,
            explicit_build_service_account=args.build_service_account,
            fallback_account_name=args.build_service_account_name,
        )
        build_sa_resource = ""
        if build_sa_email:
            build_sa_resource = " --service-account={}".format(_service_account_resource_name(proj, build_sa_email))
        image_exists = _artifact_image_exists(proj, region, repo, svc)
        deploy_failed_startup = any(
            c.name == "Cloud Run deploy attempt" and (not c.ok) and "failed to start and listen on the port" in c.detail.lower()
            for c in checks
        )
        instructions = [
            "Or re-run this script and choose to build and deploy automatically (uses Artifact Registry).",
            "Manual: open terminal in cloud/orchestrator.",
            "Artifact Registry: gcloud artifacts repositories create {} --repository-format=docker --location {} --project {}.".format(repo, region, proj),
        ]
        if image_exists:
            instructions.append("Image already exists in Artifact Registry. Start with deploy-only retry.")
            instructions.append("Deploy: gcloud run deploy {} --image {} --region {} --project {} --service-account {} --no-allow-unauthenticated.".format(svc, image, region, proj, sa))
            if deploy_failed_startup:
                instructions.append("Container startup failed in last attempt. Read logs first: gcloud run services logs read {} --project {} --region {} --limit 200.".format(svc, proj, region))
            instructions.append("Optional rebuild (if code changed): gcloud builds submit --tag {} --project {} --region {} --default-buckets-behavior=regional-user-owned-bucket{} .".format(image, proj, region, build_sa_resource))
        else:
            instructions.append("Build (Cloud Build): gcloud builds submit --tag {} --project {} --region {} --default-buckets-behavior=regional-user-owned-bucket{} .".format(image, proj, region, build_sa_resource))
            instructions.append("Deploy: gcloud run deploy {} --image {} --region {} --project {} --service-account {} --no-allow-unauthenticated.".format(svc, image, region, proj, sa))
        if shutil.which("docker"):
            instructions.append(
                "If Cloud Build returns NOT_FOUND repeatedly: build and push with Docker instead: docker build -t {} . ; gcloud auth configure-docker {}-docker.pkg.dev ; docker push {} ; then run the Deploy line below.".format(
                    image, region, image
                )
            )
        else:
            instructions.append(
                "If Cloud Build returns NOT_FOUND and Docker is not installed on this machine: install Docker Desktop (or build/push from another machine/CI) and then run the Deploy line above."
            )
        instructions.append("On Windows PowerShell if gcloud fails with 'scripts is disabled', use gcloud.cmd instead of gcloud. Re-run this script.")
        why = "Service does not exist yet, so downstream automation cannot run."
        if deploy_failed_startup:
            why = "Cloud Run deployment reached revision creation, but container startup health checks failed."
        steps.append(
            ManualStep(
                title="Deploy Cloud Run service",
                why=why,
                instructions=instructions,
            )
        )

    if "Firestore database" in failed:
        steps.append(
            ManualStep(
                title="Initialize Firestore in Native mode",
                why="Initial database creation and first indexing are one-time console tasks in many orgs.",
                instructions=[
                    "Console -> Firestore Database -> Create database.",
                    "Choose Native mode.",
                    "Choose region {} (or keep region consistent with your deployment).".format(args.region),
                    "After create, open Indexes and add composite index for collection 'queues': machine_id ASC, acked ASC, created_at ASC.",
                ],
            )
        )

    missing_secrets = [
        c.detail.replace("missing: ", "")
        for c in checks
        if c.name == "Secret Manager secret" and not c.ok and c.detail.startswith("missing:")
    ]
    if missing_secrets:
        instructions = ["Create/add values for these secrets:"]
        for secret in missing_secrets:
            instructions.append("gcloud secrets create {} --replication-policy=automatic --project {}".format(secret, args.project_id))
            instructions.append("printf '<VALUE>' | gcloud secrets versions add {} --data-file=- --project {}".format(secret, args.project_id))
        instructions.append("Re-run this script to let it auto-register Gmail watch.")
        steps.append(
            ManualStep(
                title="Create Gmail OAuth secrets",
                why="Watch registration and runtime mailbox access depend on these values.",
                instructions=instructions,
            )
        )

    watch_dep_error = any(
        c.name == "Gmail watch registration"
        and (not c.ok)
        and "python dependencies missing for gmail watch registration" in c.detail.lower()
        for c in checks
    )
    if watch_dep_error:
        steps.append(
            ManualStep(
                title="Install Local Gmail Watch Dependencies",
                why="The setup script registers Gmail watch from your local Python environment.",
                instructions=[
                    "Install local dependencies: pip install google-api-python-client google-auth google-auth-oauthlib google-cloud-secret-manager",
                    "Re-run this script to complete Gmail watch registration.",
                ],
            )
        )

    if ctx.service_url and "Cloud Scheduler job" in failed and not ctx.admin_secret:
        steps.append(
            ManualStep(
                title="Set ADMIN_SHARED_SECRET on Cloud Run",
                why="Scheduler job auto-creation requires a secret payload for /admin/resume-history.",
                instructions=[
                    "Generate secret: openssl rand -hex 16",
                    "Update service: gcloud run services update {} --project {} --region {} --update-env-vars ADMIN_SHARED_SECRET=<SECRET>".format(args.service_name, args.project_id, args.region),
                    "Re-run this script.",
                ],
            )
        )

    return steps


def _print_manual_steps(steps: List[ManualStep]) -> None:
    if not steps:
        return
    print("\nManual steps required:")
    for idx, step in enumerate(steps, 1):
        print("\n{}. {}".format(idx, step.title))
        print("   Why: {}".format(step.why))
        for line in step.instructions:
            print("   - {}".format(line))


def _append_cloud_run_dependent_checks(
    args: argparse.Namespace,
    service_url: str,
    service_account_email: str,
    validate_only: bool,
    dlq_topic: str,
    subscription_max_delivery_attempts: int,
    secret_client: CheckResult,
    secret_secret: CheckResult,
    secret_refresh: CheckResult,
    checks: List[CheckResult],
) -> Optional[str]:
    """Append subscription, env, watch, scheduler checks; return ADMIN_SHARED_SECRET if set."""
    env_vars = _get_cloud_run_env(args.project_id, args.region, args.service_name)
    auth_mode_override = None
    if getattr(args, "set_auth_mode", None) and not validate_only:
        if args.interactive and not _confirm(
            "Set AUTH_MODE to '{}' on Cloud Run? This changes runtime behavior.".format(args.set_auth_mode),
            default=False,
        ):
            pass
        else:
            auth_mode_override = args.set_auth_mode
    checks.append(
        _ensure_subscription(
            args.project_id,
            args.subscription,
            args.topic,
            "{}/pubsub/push".format(service_url),
            service_account_email,
            validate_only,
            dlq_topic,
            subscription_max_delivery_attempts,
        )
    )
    checks.append(
        _ensure_cloud_run_env(
            args.project_id,
            args.region,
            args.service_name,
            args.mailbox_user,
            args.bucket,
            args.default_machine_id or None,
            args.allowed_extensions,
            (args.label_id or []),
            args.topic,
            args.client_id_secret,
            args.client_secret_secret,
            args.refresh_token_secret,
            validate_only,
            current_env=env_vars,
            auth_mode_override=auth_mode_override,
        )
    )
    checks.append(
        _check_dwd_readiness(
            args.project_id,
            args.region,
            args.service_name,
            service_account_email,
            args.mailbox_user,
            current_env=env_vars,
        )
    )
    checks.append(_ensure_token_creator_self(args.project_id, service_account_email, validate_only))
    checks.append(_check_keyless_dwd_prereqs(args.project_id, service_account_email))
    # Cloud Scheduler uses OIDC to call the Cloud Run service; it must be granted roles/run.invoker.
    checks.append(
        _ensure_cloud_run_invoker_binding(
            args.project_id,
            args.region,
            args.service_name,
            "serviceAccount:{}".format(service_account_email),
            validate_only,
        )
    )
    gmail_pubsub_publisher = _ensure_gmail_pubsub_publisher(args.project_id, args.topic, validate_only)
    checks.append(gmail_pubsub_publisher)
    checks.append(_ensure_pubsub_dlq_publisher(args.project_id, dlq_topic, validate_only))
    admin_secret_raw = env_vars.get("ADMIN_SHARED_SECRET") or ""
    admin_secret = _resolve_secret_marker(args.project_id, admin_secret_raw)
    watch_history_id = ""
    if secret_client.ok and secret_secret.ok and secret_refresh.ok:
        if validate_only:
            checks.append(_result("Gmail watch registration", True, "skipped in validate-only mode"))
        elif not gmail_pubsub_publisher.ok:
            checks.append(_result(
                "Gmail watch registration",
                False,
                "skipped: Gmail Pub/Sub publisher IAM is not ready",
            ))
        else:
            _print_auto_action("Attempting Gmail watch registration")
            label_ids = watch.normalize_label_ids(raw=env_vars.get("GMAIL_LABEL_IDS") or "")
            ok, detail, watch_history_id = _register_watch(
                project_id=args.project_id,
                mailbox_user=args.mailbox_user,
                topic=args.topic,
                client_id_secret=args.client_id_secret,
                client_secret_secret=args.client_secret_secret,
                refresh_token_secret=args.refresh_token_secret,
                label_ids=label_ids,
            )
            checks.append(_result("Gmail watch registration", ok, detail))
    else:
        checks.append(_result("Gmail watch registration", False, "skipped: required OAuth secrets are missing"))
    if admin_secret:
        checks.append(
            _ensure_scheduler_job(
                args.project_id,
                args.region,
                args.scheduler_job,
                service_url,
                service_account_email,
                admin_secret,
                watch_history_id,
                validate_only,
            )
        )
    else:
        # Check if scheduler job already exists - if so, missing ADMIN_SHARED_SECRET is a failure
        job_exists = _run([
            "gcloud", "scheduler", "jobs", "describe", args.scheduler_job,
            "--project", args.project_id, "--location", args.region,
            "--format", "value(name)",
        ])
        if job_exists.returncode == 0 and job_exists.stdout.strip():
            # Job exists but ADMIN_SHARED_SECRET is not set or cannot be resolved locally
            if admin_secret_raw and admin_secret_raw.startswith("<secret:"):
                checks.append(_result(
                    "Cloud Scheduler job",
                    False,
                    "Cannot verify ADMIN_SHARED_SECRET locally (secret reference could not be resolved; may be permissions). "
                    "Scheduler job '{}' exists. Verify in Cloud Console that Cloud Run has the secret and that the job body.secret matches.".format(args.scheduler_job)
                ))
            else:
                checks.append(_result(
                    "Cloud Scheduler job",
                    False,
                    "ADMIN_SHARED_SECRET is not set on Cloud Run but scheduler job '{}' exists. Set ADMIN_SHARED_SECRET on Cloud Run to match the job's body.secret value.".format(args.scheduler_job)
                ))
        else:
            # Job doesn't exist and secret not set - just skip
            if admin_secret_raw and admin_secret_raw.startswith("<secret:"):
                checks.append(_result("Cloud Scheduler job", True, "skipped: ADMIN_SHARED_SECRET is a secret reference but could not be resolved locally"))
            else:
                checks.append(_result("Cloud Scheduler job", True, "skipped: ADMIN_SHARED_SECRET is not set on Cloud Run"))
    return admin_secret


def run_checks(args: argparse.Namespace) -> int:
    _require_gcloud()
    validate_only = bool(args.validate_only)
    if validate_only:
        print("{} Running in validate-only mode (no auto-remediation).".format(_tag_info()))
    else:
        print("{} Running in auto-remediation mode (script decides actions from detected state).".format(_tag_info()))

    service_account_email = "{}@{}.iam.gserviceaccount.com".format(args.service_account_name, args.project_id)

    # Resolve AUTH_MODE from Cloud Run env (primary source). Used for OAuth secret requirement decisions.
    auth_mode, env_readable = _get_auth_mode_from_cloud_run(args.project_id, args.region, args.service_name)
    if not env_readable:
        _emit_decision("Cloud Run env unreadable -> treating as dwd_preferred, OAuth secrets required")
    elif auth_mode == "dwd_required":
        _emit_decision("AUTH_MODE=dwd_required -> OAuth secret checks downgraded to advisory")
    else:
        _emit_decision("AUTH_MODE={} -> OAuth secrets required for fallback".format(auth_mode))

    # Intelligent retry-policy defaults:
    # - If caller kept defaults, preserve existing subscription DLQ/attempt settings.
    # - If caller provided non-default values, treat them as explicit overrides.
    detect_dlq_topic = (args.dlq_topic == _DEFAULT_DLQ_TOPIC)
    detect_max_attempts = (
        int(args.subscription_max_delivery_attempts) == _DEFAULT_SUBSCRIPTION_MAX_DELIVERY_ATTEMPTS
    )
    effective_dlq_topic, effective_max_attempts, retry_note = _resolve_subscription_retry_policy_defaults(
        project_id=args.project_id,
        subscription=args.subscription,
        fallback_dlq_topic=args.dlq_topic,
        fallback_max_delivery_attempts=int(args.subscription_max_delivery_attempts),
        detect_dlq_topic=detect_dlq_topic,
        detect_max_attempts=detect_max_attempts,
    )
    args.dlq_topic = effective_dlq_topic
    args.subscription_max_delivery_attempts = effective_max_attempts
    if retry_note:
        _emit_decision("Pub/Sub retry policy auto-default: {}".format(retry_note))

    checks: List[CheckResult] = []

    auth = _check_auth()
    checks.append(auth)
    if not auth.ok:
        for result in checks:
            _print_result(result)
        print("\nCannot continue until gcloud authentication is available.")
        return 1

    checks.append(_ensure_project(args.project_id, validate_only))
    checks.append(_ensure_apis(args.project_id, validate_only))
    checks.append(_ensure_service_account(args.project_id, service_account_email, validate_only))
    checks.append(_ensure_roles(args.project_id, service_account_email, validate_only))
    checks.append(_ensure_bucket(args.project_id, args.bucket, validate_only))
    checks.append(_ensure_topic(args.project_id, args.topic, validate_only))
    checks.append(_ensure_topic(args.project_id, effective_dlq_topic, validate_only))

    checks.append(_check_firestore_database(args.project_id))
    secret_client = _check_secret_exists(args.project_id, args.client_id_secret)
    secret_secret = _check_secret_exists(args.project_id, args.client_secret_secret)
    secret_refresh = _check_secret_exists(args.project_id, args.refresh_token_secret)
    # Auth-mode aware: when dwd_required, OAuth secrets are advisory (pass if missing; warn)
    if auth_mode == "dwd_required" and not (secret_client.ok and secret_secret.ok and secret_refresh.ok):
        missing = [n for n, r in [
            (args.client_id_secret, secret_client),
            (args.client_secret_secret, secret_secret),
            (args.refresh_token_secret, secret_refresh),
        ] if not r.ok]
        checks.append(_result(
            "OAuth secrets (advisory)",
            True,
            "AUTH_MODE=dwd_required; OAuth secrets not required for steady state. Missing: {}. Keep for rollback if desired.".format(", ".join(missing)),
        ))
    else:
        checks.extend([secret_client, secret_secret, secret_refresh])

    service_url = _get_service_url(args.project_id, args.service_name, args.region)
    admin_secret = None

    # Optional deploy: if explicitly requested, attempt build+deploy even when the Cloud Run service already exists.
    # This is needed to roll out code fixes to a running service when the image is stale.
    if service_url and bool(getattr(args, "deploy", False)) and (not validate_only):
        orchestrator_dir = os.path.dirname(os.path.abspath(__file__))
        ok, msg = _run_build_and_deploy_cloud_run(
            args.project_id,
            args.region,
            args.service_name,
            service_account_email,
            args.artifact_repo,
            orchestrator_dir,
            build_service_account=args.build_service_account,
            build_service_account_name=args.build_service_account_name,
        )
        if ok:
            checks.append(_result("Cloud Run deploy attempt", True, "build and deploy command completed"))
            # Refresh URL after deploy so downstream checks use current state.
            service_url = _get_service_url(args.project_id, args.service_name, args.region)
        else:
            checks.append(_result("Cloud Run deploy attempt", False, msg))

    if not service_url:
        checks.append(_result("Cloud Run service", False, "service not found: {}".format(args.service_name)))
        # Optional: attempt build and deploy in interactive mode (Artifact Registry, 2024+ recommended).
        if args.interactive and not validate_only and _confirm("Attempt to build and deploy Cloud Run service now? (uses Artifact Registry)", default=True):
            orchestrator_dir = os.path.dirname(os.path.abspath(__file__))
            ok, msg = _run_build_and_deploy_cloud_run(
                args.project_id,
                args.region,
                args.service_name,
                service_account_email,
                args.artifact_repo,
                orchestrator_dir,
                build_service_account=args.build_service_account,
                build_service_account_name=args.build_service_account_name,
            )
            if ok:
                checks.append(_result("Cloud Run deploy attempt", True, "build and deploy command completed"))
                service_url = _get_service_url(args.project_id, args.service_name, args.region)
                if service_url:
                    checks.append(_result("Cloud Run service", True, "{} ({})".format(args.service_name, service_url)))
                    admin_secret = _append_cloud_run_dependent_checks(
                        args, service_url, service_account_email, validate_only,
                        effective_dlq_topic, effective_max_attempts,
                        secret_client, secret_secret, secret_refresh, checks,
                    )
                else:
                    print("Deploy reported success but service URL not found yet; re-run this script to verify.")
            else:
                checks.append(_result("Cloud Run deploy attempt", False, msg))
                print("Build/deploy failed: {}".format(msg))
                print("You can deploy manually (see manual steps below) then re-run this script.")
    else:
        checks.append(_result("Cloud Run service", True, "{} ({})".format(args.service_name, service_url)))
        admin_secret = _append_cloud_run_dependent_checks(
            args, service_url, service_account_email, validate_only,
            effective_dlq_topic, effective_max_attempts,
            secret_client, secret_secret, secret_refresh, checks,
        )

    for result in checks:
        _print_result(result)

    has_failures = any(not r.ok for r in checks)
    ctx = Context(service_url=service_url, admin_secret=admin_secret, service_account_email=service_account_email)

    if has_failures:
        _print_manual_steps(_build_manual_steps(args, checks, ctx))
        print("\nSetup is not fully complete yet. See failures/manual steps above.")
        if getattr(args, "verify_runtime", False):
            print("\nRuntime verification (--verify-runtime):")
            _verify_runtime(args, ctx)
        return 1

    print("\nAll checks passed and setup actions are complete.")

    # Preprocessor gate check (authoritative from queues + ingest_errors)
    try:
        try:
            if __package__:
                from .preprocessor_gate import check_preprocessor_gate
            else:
                from preprocessor_gate import check_preprocessor_gate
        except ImportError:
            import sys
            script_dir = os.path.dirname(os.path.abspath(__file__))
            if script_dir not in sys.path:
                sys.path.insert(0, script_dir)
            from preprocessor_gate import check_preprocessor_gate
        env = _get_cloud_run_env(args.project_id, args.region, args.service_name)
        preprocessor_mode = (env.get("PREPROCESSOR_MODE") or "shadow").strip().lower()
        gate_passed, reason, metrics = check_preprocessor_gate(
            args.project_id,
            queue_collection=env.get("FIRESTORE_QUEUE_COLLECTION", "queues"),
            state_collection=env.get("FIRESTORE_STATE_COLLECTION", "sync_state"),
            ingest_errors_collection=env.get("FIRESTORE_INGEST_ERRORS_COLLECTION", "ingest_errors"),
            preprocessor_mode=preprocessor_mode,
        )
        if metrics:
            print("\nPreprocessor gate: mode={} unique_shadow_processed={} reject_count={} "
                  "unknown_codes={} unhandled_exceptions={} dropped={} duplicates={}".format(
                      metrics.mode,
                      metrics.unique_shadow_processed_count,
                      metrics.reject_count,
                      metrics.unknown_reject_code_count,
                      metrics.preprocess_unhandled_exception_count,
                      metrics.dropped_without_repair_record_count,
                      metrics.duplicate_queue_doc_count_by_message_id,
                  ))
        if gate_passed:
            print("PREPROCESSOR_GATE: pass")
            print("Action: run with --promote-preprocessor-enforce")
        else:
            print("PREPROCESSOR_GATE: fail")
            print("Reason: {}".format(reason or "unknown"))
            print("Action: remain in PREPROCESSOR_MODE=shadow and continue collecting cohort telemetry.")
        # Snapshot artifact (best-effort)
        inv_mode = "validate_only" if validate_only else ("interactive" if args.interactive else "non_interactive")
        snapshot_path = write_gate_snapshot_artifact(
            metrics, gate_passed, reason,
            args.project_id, args.service_name, args.region,
            invocation_mode=inv_mode,
        )
        if snapshot_path:
            print("{} Gate snapshot: {}".format(_tag_info(), snapshot_path))
        # Gate fail does NOT fail the run - platform is healthy; gate is informational
        def _on_promote_fail(proc):
            print("{} Failed to set PREPROCESSOR_MODE: {}".format(_tag_fail(), _command_error(proc)))

        if validate_only and getattr(args, "promote_preprocessor_enforce", False):
            print("{} Skipping PREPROCESSOR_MODE promotion (validate-only; no mutation).".format(_tag_info()))
        elif _maybe_promote_preprocessor_enforce(
            args, validate_only, gate_passed, env,
            args.project_id, args.region, args.service_name,
            on_fail=_on_promote_fail,
        ):
            print("{} PREPROCESSOR_MODE set to enforce.".format(_tag_ok()))
    except Exception as exc:
        print("PREPROCESSOR_GATE: fail")
        print("Reason: cannot assess ({})".format(exc))
    # Gate assessment failure does NOT fail the run - platform checks passed

    # Backlog backfill: offer when not validate_only and service_url/admin_secret available
    _offer_backfill(args, ctx)

    # Alert drift reconcile: when not validate_only, check drift and run idempotent reconcile if needed
    alert_summary = "not run (validate-only)"
    if not validate_only:
        alert_ok, alert_summary = _run_alert_drift_reconcile(args)
        if not alert_ok:
            print("\nALERTING SUMMARY: {}".format(alert_summary))
            print("\nAlert reconcile failed. See DECISION trace above.")
            return 1
    print("\nALERTING SUMMARY: {}".format(alert_summary))

    # Optional housekeeping: Cloud Build submit uploads are safe to delete and can accumulate during troubleshooting.
    if getattr(args, "cleanup_cloudbuild_sources", False):
        res = _cleanup_cloud_build_source_tarballs(
            args.project_id,
            args.region,
            days=int(getattr(args, "cleanup_cloudbuild_sources_days", 2)),
            all_regions=bool(getattr(args, "cleanup_cloudbuild_sources_all_regions", False)),
            validate_only=validate_only,
            interactive=bool(args.interactive),
        )
        _print_result(res)

    # Intelligent default: after a successful auto-remediation run, perform a best-effort runtime verification
    # unless explicitly skipped. This follows the runbook and keeps the tool self-diagnosing.
    should_verify = bool(getattr(args, "verify_runtime", False))
    if (not should_verify) and (not validate_only) and bool(args.interactive) and (not bool(getattr(args, "skip_verify_runtime", False))):
        should_verify = True
    verify_res = None
    if should_verify:
        print("\nRuntime verification (--verify-runtime):")
        verify_res = _verify_runtime(args, ctx)
        _maybe_promote_to_dwd_required(args, ctx, verify_res)
    _maybe_offer_guided_alert_smoke_drill(args, ctx, verify_res, should_verify)
    return 0


def _maybe_promote_to_dwd_required(args: argparse.Namespace, ctx: Context, verify_res: object) -> None:
    """
    After keyless DWD is verified working at runtime, offer to promote AUTH_MODE to dwd_required.

    This is intentionally late in the sequence: we only promote after we have proof that keyless DWD works.
    """
    try:
        validate_only = bool(args.validate_only)
        interactive = bool(args.interactive)
        if validate_only:
            return

        # verify_res is returned by setup_runtime._verify_runtime. Treat it as duck-typed to avoid tight coupling.
        keyless_ok = bool(getattr(verify_res, "keyless_proof", False))
        handler_ok = bool(getattr(verify_res, "handler_invoked", False))
        http_status = getattr(verify_res, "effective_http_status", None)
        http_ok = isinstance(http_status, int) and 200 <= http_status < 300

        if not (keyless_ok and handler_ok and http_ok):
            return

        # If the operator explicitly set auth mode already, do not prompt again.
        if getattr(args, "set_auth_mode", None):
            return

        env = _get_cloud_run_env(args.project_id, args.region, args.service_name)
        cur = (env.get("AUTH_MODE") or "").strip().lower()
        if cur == "dwd_required":
            return

        should_promote = False
        if interactive:
            should_promote = _confirm(
                "Keyless DWD verified. Promote AUTH_MODE to 'dwd_required' on Cloud Run now? (Rollback: set AUTH_MODE back to dwd_preferred)",
                default=False,
            )
        else:
            should_promote = bool(getattr(args, "promote_dwd_required", False))

        if not should_promote:
            return

        _print_auto_action("Promoting AUTH_MODE to dwd_required (runtime will no longer use user OAuth fallback)")
        env["AUTH_MODE"] = "dwd_required"
        upd = _update_cloud_run_env_via_file(args.project_id, args.region, args.service_name, env)
        if upd.returncode != 0:
            print("{} Failed to promote AUTH_MODE: {}".format(_tag_fail(), _command_error(upd)))
            return

        print("{} AUTH_MODE promoted to dwd_required. Re-running runtime verification...".format(_tag_ok()))
        _verify_runtime(args, ctx)
    except Exception:
        # Promotion is best-effort only; never fail setup because of this.
        return


def _describe_scheduler_job(project_id: str, region: str, job_name: str) -> Tuple[Dict[str, str], Optional[str]]:
    """Return a small scheduler target snapshot for guided drill messaging."""
    proc = _run([
        "gcloud", "scheduler", "jobs", "describe", job_name,
        "--project", project_id, "--location", region, "--format", "json",
    ])
    if proc.returncode != 0:
        return {}, _command_error(proc)
    try:
        payload = json.loads(proc.stdout or "{}")
    except Exception as exc:
        return {}, "failed to parse scheduler job describe output: {}".format(exc)
    http = payload.get("httpTarget") or {}
    oidc = http.get("oidcToken") or {}
    return {
        "state": str(payload.get("state") or ""),
        "uri": str(http.get("uri") or ""),
        "audience": str(oidc.get("audience") or ""),
        "oidc_service_account_email": str(oidc.get("serviceAccountEmail") or ""),
    }, None


def _get_watch_stale_policy_hours(project_id: str) -> Tuple[Optional[int], Optional[str]]:
    """
    Best-effort read of current watch-stale alert threshold (hours) from Monitoring policy.
    Returns (hours, error). hours=None means unknown.
    """
    proc = _run([
        "gcloud", "monitoring", "policies", "list",
        "--project", project_id,
        "--format", "json",
    ])
    if proc.returncode != 0:
        return None, _command_error(proc)
    try:
        policies = json.loads(proc.stdout or "[]")
    except Exception as exc:
        return None, "failed to parse monitoring policies JSON: {}".format(exc)
    for p in policies or []:
        if (p.get("displayName") or "") != "MediLink Orchestrator - Watch refresh stale":
            continue
        for cond in (p.get("conditions") or []):
            absent = cond.get("conditionAbsent") or {}
            duration = str(absent.get("duration") or "").strip()
            if duration.endswith("s"):
                try:
                    seconds = int(duration[:-1])
                    if seconds > 0:
                        # round to nearest hour for operator messaging
                        hours = max(1, int(round(seconds / 3600.0)))
                        return hours, None
                except Exception:
                    pass
    return None, "watch stale policy not found or duration unavailable"


def _run_setup_alerting_apply(
    project_id: str,
    service_name: str,
    scheduler_job: str,
    subscription: str,
    watch_stale_hours: Optional[int] = None,
) -> Tuple[bool, str]:
    """Run setup_alerting.py idempotent apply; optional watch-stale-hours override."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    alert_script = os.path.join(script_dir, "setup_alerting.py")
    repo_root = os.path.dirname(os.path.dirname(os.path.dirname(script_dir)))
    if not os.path.isfile(alert_script):
        return False, "setup_alerting.py not found"
    cmd = [
        sys.executable, alert_script,
        "--project-id", project_id,
        "--service-name", service_name,
        "--scheduler-job", scheduler_job,
        "--subscription", subscription,
    ]
    if watch_stale_hours is not None:
        cmd.extend(["--watch-stale-hours", str(int(watch_stale_hours))])
    proc = subprocess.run(cmd, cwd=repo_root)
    if proc.returncode != 0:
        return False, "setup_alerting apply failed (exit {})".format(proc.returncode)
    return True, "ok"


def _write_guided_drill_evidence(
    args: argparse.Namespace,
    scheduler_snapshot: Dict[str, str],
    observed_alert_delivery: bool,
    resumed_ok: bool,
    rerun_ok: bool,
    verify_res: object,
    drill_window_hours: Optional[int] = None,
    window_temporarily_changed: bool = False,
) -> None:
    """Write a lightweight evidence artifact for guided drill handoff."""
    try:
        repo_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        evidence_dir = os.path.join(repo_root, "docs", "runbooks", "evidence")
        os.makedirs(evidence_dir, exist_ok=True)
        stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        path = os.path.join(evidence_dir, "guided_smoke_drill_{}.txt".format(stamp))

        effective_http_status = getattr(verify_res, "effective_http_status", None)
        handler_invoked = bool(getattr(verify_res, "handler_invoked", False))
        keyless_proof = bool(getattr(verify_res, "keyless_proof", False))
        startup_proof = bool(getattr(verify_res, "startup_proof", False))

        lines = [
            "Guided Alert Smoke Drill Evidence",
            "timestamp_utc={}".format(stamp),
            "project_id={}".format(args.project_id),
            "region={}".format(args.region),
            "service_name={}".format(args.service_name),
            "scheduler_job={}".format(args.scheduler_job),
            "scheduler_uri={}".format(scheduler_snapshot.get("uri", "")),
            "scheduler_oidc_audience={}".format(scheduler_snapshot.get("audience", "")),
            "scheduler_oidc_service_account={}".format(scheduler_snapshot.get("oidc_service_account_email", "")),
            "drill_window_hours={}".format("" if drill_window_hours is None else drill_window_hours),
            "window_temporarily_changed={}".format(window_temporarily_changed),
            "observed_alert_delivery={}".format(observed_alert_delivery),
            "resumed_scheduler={}".format(resumed_ok),
            "triggered_scheduler_run_after_resume={}".format(rerun_ok),
            "verify_runtime_effective_http_status={}".format(effective_http_status),
            "verify_runtime_handler_invoked={}".format(handler_invoked),
            "verify_runtime_keyless_proof={}".format(keyless_proof),
            "verify_runtime_startup_proof={}".format(startup_proof),
            "",
            "Pass criteria:",
            "- alert fired and notification delivered and incident created during pause window",
            "- scheduler resumed and manual run succeeded after rollback",
            "- verify-runtime shows /admin/resume-history 2xx and handler proof",
        ]
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print("{} Guided drill evidence written: {}".format(_tag_ok(), path))
    except Exception as exc:
        print("{} Could not write guided drill evidence: {}".format(_tag_fail(), exc))


def _maybe_offer_guided_alert_smoke_drill(
    args: argparse.Namespace,
    ctx: Context,
    verify_res: object,
    runtime_verify_ran: bool,
) -> None:
    """
    Offer an interactive, safety-first smoke drill after runtime verification.

    This keeps the script self-diagnosing while avoiding destructive automation:
    the operator must explicitly confirm pause/resume and external alert evidence.
    """
    if bool(getattr(args, "validate_only", False)):
        return
    if not bool(getattr(args, "interactive", False)):
        return
    if not runtime_verify_ran or verify_res is None:
        return

    effective_http_status = getattr(verify_res, "effective_http_status", None)
    baseline_http_ok = isinstance(effective_http_status, int) and 200 <= effective_http_status < 300
    baseline_handler_ok = bool(getattr(verify_res, "handler_invoked", False))
    if not (baseline_http_ok and baseline_handler_ok):
        _emit_decision("skipping guided smoke drill offer because baseline runtime proof is not yet stable (need 2xx + handler proof)")
        return

    snapshot, snapshot_err = _describe_scheduler_job(args.project_id, args.region, args.scheduler_job)
    if snapshot_err:
        _emit_decision("skipping guided smoke drill offer (could not read scheduler job): {}".format(snapshot_err))
        return

    watch_hours, watch_hours_err = _get_watch_stale_policy_hours(args.project_id)
    accelerated_window_changed = False
    restore_watch_hours: Optional[int] = None
    if watch_hours is not None:
        print("\nCurrent watch-stale alert window: {} hour(s).".format(watch_hours))
    elif watch_hours_err:
        print("\n{} Could not detect watch-stale alert window: {}".format(_tag_info(), watch_hours_err))

    print("\nOptional guided alert smoke drill (change window)")
    print("What this is for:")
    print("- Proves alerting is operational end-to-end, not only configured.")
    print("- Verifies that pause of watch refresh leads to alert/notification/incident.")
    print("- Verifies rollback by resuming scheduler and re-running runtime checks.")
    print("Expected impact:")
    print("- Scheduler job '{}' will be paused temporarily.".format(args.scheduler_job))
    print("- During the pause window, watch refresh does not run.")
    print("- You should run this only in an approved change window.")
    print("What the script will do if you continue:")
    print("- Pause scheduler, wait for your manual confirmation, resume scheduler, trigger one run, and re-verify runtime.")
    print("- Save an evidence artifact under docs/runbooks/evidence/.")
    if watch_hours is not None:
        print("- Estimated wait: about {} hour(s) before watch-stale alert can fire (unless temporarily accelerated).".format(watch_hours))
    else:
        print("- Estimated wait: depends on your watch-stale policy window.")
    if not _confirm("Start guided alert smoke drill now?", default=False):
        return

    if (watch_hours is not None) and (watch_hours > 1):
        print("\nAcceleration option:")
        print("- Current window is {}h, which can be long for a drill.".format(watch_hours))
        print("- Script can temporarily set watch-stale threshold to 1h for this drill, then restore it.")
        if _confirm("Temporarily set watch-stale threshold to 1h for faster drill?", default=True):
            _emit_decision("temporary drill acceleration selected -> setting watch-stale threshold to 1h")
            ok_accel, msg_accel = _run_setup_alerting_apply(
                args.project_id,
                args.service_name,
                args.scheduler_job,
                args.subscription,
                watch_stale_hours=1,
            )
            if ok_accel:
                accelerated_window_changed = True
                restore_watch_hours = watch_hours
                watch_hours = 1
                print("{} Watch-stale threshold temporarily set to 1h for drill.".format(_tag_ok()))
            else:
                print("{} Could not apply temporary 1h watch-stale threshold: {}".format(_tag_fail(), msg_accel))
                print("{} Continuing drill with current threshold window.".format(_tag_info()))

    job_state = (snapshot.get("state") or "").strip().upper()
    if job_state == "PAUSED":
        print("{} Scheduler job is already PAUSED. Assuming drill is already in progress.".format(_tag_info()))
    else:
        if not _confirm("Pause scheduler job '{}' now?".format(args.scheduler_job), default=True):
            print("{} Guided drill canceled before pause.".format(_tag_info()))
            return
        pause_proc = _run([
            "gcloud", "scheduler", "jobs", "pause", args.scheduler_job,
            "--project", args.project_id, "--location", args.region,
        ])
        if pause_proc.returncode != 0:
            print("{} Failed to pause scheduler job: {}".format(_tag_fail(), _command_error(pause_proc)))
            return
        print("{} Scheduler job paused.".format(_tag_ok()))

    print("\nManual observation step required:")
    if watch_hours is not None:
        print("1) Wait for the watch-stale alert threshold window (currently {}h).".format(watch_hours))
    else:
        print("1) Wait for your configured watch-stale alert threshold window.")
    print("2) Confirm alert condition fired.")
    print("3) Confirm notification was delivered.")
    print("4) Confirm incident was created.")
    observed_alert_delivery = _confirm(
        "Have you observed alert fired + notification delivered + incident created?",
        default=False,
    )

    if not _confirm("Resume scheduler now and run rollback verification?", default=True):
        print("{} Scheduler may remain paused. Resume it manually to avoid stale watch state.".format(_tag_fail()))
        print("   gcloud scheduler jobs resume {} --project {} --location {}".format(
            args.scheduler_job, args.project_id, args.region
        ))
        _write_guided_drill_evidence(
            args, snapshot, observed_alert_delivery, False, False, verify_res,
            drill_window_hours=watch_hours,
            window_temporarily_changed=accelerated_window_changed,
        )
        if accelerated_window_changed and restore_watch_hours and restore_watch_hours > 1:
            _emit_decision("restoring watch-stale threshold to {}h after early exit".format(restore_watch_hours))
            ok_restore, msg_restore = _run_setup_alerting_apply(
                args.project_id,
                args.service_name,
                args.scheduler_job,
                args.subscription,
                watch_stale_hours=restore_watch_hours,
            )
            if ok_restore:
                print("{} Restored watch-stale threshold to {}h.".format(_tag_ok(), restore_watch_hours))
            else:
                print("{} Failed to restore watch-stale threshold automatically: {}".format(_tag_fail(), msg_restore))
        return

    resumed_ok = False
    rerun_ok = False
    resume_proc = _run([
        "gcloud", "scheduler", "jobs", "resume", args.scheduler_job,
        "--project", args.project_id, "--location", args.region,
    ])
    if resume_proc.returncode == 0:
        resumed_ok = True
        print("{} Scheduler job resumed.".format(_tag_ok()))
    else:
        print("{} Failed to resume scheduler job: {}".format(_tag_fail(), _command_error(resume_proc)))

    if resumed_ok:
        run_proc = _run([
            "gcloud", "scheduler", "jobs", "run", args.scheduler_job,
            "--project", args.project_id, "--location", args.region,
        ])
        if run_proc.returncode == 0:
            rerun_ok = True
            print("{} Scheduler job run requested.".format(_tag_ok()))
        else:
            print("{} Failed to trigger scheduler run after resume: {}".format(_tag_fail(), _command_error(run_proc)))

    print("\nPost-drill runtime verification:")
    verify_after = _verify_runtime(args, ctx)
    final_http = getattr(verify_after, "effective_http_status", None)
    final_http_ok = isinstance(final_http, int) and 200 <= final_http < 300
    final_handler_ok = bool(getattr(verify_after, "handler_invoked", False))
    final_pass = bool(observed_alert_delivery and resumed_ok and rerun_ok and final_http_ok and final_handler_ok)

    if final_pass:
        print("{} Guided drill PASS: alert delivery observed and rollback verification succeeded.".format(_tag_ok()))
    else:
        print("{} Guided drill NOT COMPLETE: review outputs and runbook criteria before signing off.".format(_tag_fail()))
    _write_guided_drill_evidence(
        args, snapshot, observed_alert_delivery, resumed_ok, rerun_ok, verify_after,
        drill_window_hours=watch_hours,
        window_temporarily_changed=accelerated_window_changed,
    )
    if accelerated_window_changed and restore_watch_hours and restore_watch_hours > 1:
        _emit_decision("restoring watch-stale threshold to {}h after drill".format(restore_watch_hours))
        ok_restore, msg_restore = _run_setup_alerting_apply(
            args.project_id,
            args.service_name,
            args.scheduler_job,
            args.subscription,
            watch_stale_hours=restore_watch_hours,
        )
        if ok_restore:
            print("{} Restored watch-stale threshold to {}h.".format(_tag_ok(), restore_watch_hours))
        else:
            print("{} Failed to restore watch-stale threshold automatically: {}".format(_tag_fail(), msg_restore))
