# Gmail Forwarding Setup Guide

This guide explains how to set up email forwarding from the personal Gmail account (`mariavidaud@gmail.com`) to the Workspace account (`daniel@strategicimplementation.us`) for monitoring.

## Why Forward to Workspace?

- ✅ **No OAuth2 token expiration** - Uses domain-wide delegation (permanent)
- ✅ **More reliable** - Workspace accounts designed for automation
- ✅ **Better security** - Domain-wide delegation is more secure than OAuth2
- ✅ **No maintenance** - Gmail forwarding rules are persistent

## Step-by-Step Setup

### Step 1: Set Up Forwarding in Personal Gmail

1. **Log into `mariavidaud@gmail.com`**

2. **Go to Settings**:
   - Click the gear icon (⚙️) → "See all settings"
   - Click on the "Forwarding and POP/IMAP" tab

3. **Add Forwarding Address**:
   - Click "Add a forwarding address"
   - Enter: `daniel@strategicimplementation.us`
   - Click "Next" → "Proceed"
   - Click "OK"

4. **Verify Forwarding Address**:
   - Check `daniel@strategicimplementation.us` inbox for a verification email
   - Click the verification link in the email
   - Or copy the verification code and enter it in Gmail settings

5. **Enable Forwarding**:
   - Select "Forward a copy of incoming mail to `daniel@strategicimplementation.us`"
   - Choose what to do with original messages:
     - **Recommended**: "Keep Gmail's copy in the Inbox" (so original account keeps emails)
     - Or "Archive Gmail's copy" (moves to archive)
     - Or "Delete Gmail's copy" (removes from original account)
   - Click "Save Changes"

### Step 2: (Optional) Create a Filter for Specific Emails

If you only want to forward emails with attachments or matching specific criteria:

1. **In Gmail Settings** → "Filters and Blocked Addresses" tab
2. Click "Create a new filter"
3. **Set filter criteria** (examples):
   - Has attachment: ✓
   - From: (specific senders)
   - Subject: (keywords)
   - etc.
4. Click "Create filter"
5. Check "Forward it to: daniel@strategicimplementation.us"
6. Click "Create filter"

### Step 3: (Optional) Set Up Label/Folder in Workspace Account

To organize forwarded emails in `daniel@strategicimplementation.us`:

1. **Log into `daniel@strategicimplementation.us`**
2. **Go to Settings** → "Labels"
3. **Create a new label**: `MediLink/Forwarded`
4. **Create a filter** to automatically label forwarded emails:
   - Settings → "Filters and Blocked Addresses"
   - Create filter with: "From: mariavidaud@gmail.com"
   - Action: "Apply the label: MediLink/Forwarded"
   - Save

## Verification

After setup, test forwarding:

1. **Send a test email** to `mariavidaud@gmail.com` with an attachment
2. **Check `daniel@strategicimplementation.us`** - should receive the email
3. **Verify the orchestrator will process it** once deployed

## Important Notes

### Forwarding Behavior
- ✅ Forwarding is **permanent** and doesn't expire
- ✅ Works even if the personal Gmail account is not actively accessed
- ✅ No user intervention needed once set up

### Email Processing
- The orchestrator monitors `daniel@strategicimplementation.us`
- Processes all emails that arrive (including forwarded ones)
- Uses domain-wide delegation (no OAuth2 needed)

### If Forwarding Stops
- Rare, but possible if forwarding is disabled manually
- Check Gmail settings if emails stop appearing in Workspace account
- Verify forwarding address is still active

## Next Steps

After forwarding is set up:

1. ✅ **Enable domain-wide delegation** (for `daniel@strategicimplementation.us`)
2. ✅ **Deploy Cloud Run** with `MAILBOX_USER=daniel@strategicimplementation.us`
3. ✅ **Register Gmail watch** on the Workspace account
4. ✅ **Test with a forwarded email**

See `SETUP_GUIDE.md` for complete deployment instructions.



















