#!/bin/bash
# GCP Infrastructure Setup Script for MediLink Gmail Orchestrator
# Usage: ./setup_gcp.sh PROJECT_ID

set -e

PROJECT_ID="${1}"
if [ -z "$PROJECT_ID" ]; then
    echo "Usage: $0 PROJECT_ID"
    echo "Example: $0 my-medilink-project"
    exit 1
fi

echo "Setting up GCP infrastructure for project: ${PROJECT_ID}"
echo ""

# Set the project
gcloud config set project ${PROJECT_ID}

echo "=== Step 1: Enabling Required APIs ==="
gcloud services enable \
  gmail.googleapis.com \
  drive.googleapis.com \
  pubsub.googleapis.com \
  run.googleapis.com \
  iam.googleapis.com \
  iamcredentials.googleapis.com \
  firestore.googleapis.com \
  storage.googleapis.com \
  eventarc.googleapis.com \
  cloudbuild.googleapis.com \
  cloudscheduler.googleapis.com

echo ""
echo "=== Step 2: Creating Service Account ==="
SA_EMAIL="medilink-gmail-orchestrator@${PROJECT_ID}.iam.gserviceaccount.com"
gcloud iam service-accounts create medilink-gmail-orchestrator \
  --display-name="MediLink Gmail Orchestrator" \
  --project=${PROJECT_ID}

echo "Granting IAM roles to service account..."
gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/iam.serviceAccountTokenCreator"

gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/storage.objectAdmin"

gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/datastore.user"

gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member="serviceAccount:${SA_EMAIL}" \
  --role="roles/pubsub.publisher"

echo ""
echo "=== Step 3: Creating Service Account Key ==="
gcloud iam service-accounts keys create medilink-gmail-orchestrator.json \
  --iam-account=${SA_EMAIL}

echo "Service account key saved to: medilink-gmail-orchestrator.json"
echo ""
echo "⚠️  IMPORTANT: Enable Domain-Wide Delegation:"
echo "1. Go to: https://admin.google.com/ac/owl"
echo "2. Navigate to: Security -> API controls -> Domain-wide delegation"
echo "3. Add new client ID (from the JSON key: client_id field)"
echo "4. Authorize scopes: https://www.googleapis.com/auth/gmail.modify,https://www.googleapis.com/auth/gmail.readonly,https://www.googleapis.com/auth/gmail.send,https://www.googleapis.com/auth/drive"
echo ""

echo "=== Step 4: Creating Cloud Storage Bucket ==="
BUCKET_NAME="medilink-gmail-staging"
gsutil mb -p ${PROJECT_ID} -l us-central1 gs://${BUCKET_NAME} || echo "Bucket may already exist"

echo ""
echo "=== Step 5: Setting up Firestore ==="
echo "Note: Firestore must be initialized via the GCP Console"
echo "1. Go to: https://console.cloud.google.com/firestore/databases?project=${PROJECT_ID}"
echo "2. Click 'Create Database'"
echo "3. Select 'Native mode'"
echo "4. Choose location (recommend: us-central1)"
echo "5. Create collections: 'queues' and 'sync_state'"
echo ""
echo "After Firestore is created, create composite index:"
echo "Collection: queues"
echo "Fields: machine_id (ASC), acked (ASC), created_at (ASC)"
echo ""

echo "=== Step 6: Creating Pub/Sub Topic ==="
gcloud pubsub topics create gmail-new-emails --project=${PROJECT_ID} || echo "Topic may already exist"

echo ""
echo "=== Step 7: Next Steps ==="
echo "1. Complete Firestore setup in Console"
echo "2. Enable domain-wide delegation (instructions above)"
echo "3. Run: ./build_and_deploy.sh ${PROJECT_ID} <MAILBOX_USER>"
echo ""
echo "Setup script complete!"



















