"""Evidence artifact helpers for validator runs."""

from __future__ import annotations

import datetime as dt
import json
import logging
import os
import uuid
from typing import Any, Dict, Optional

LOGGER = logging.getLogger("medilink.orchestrator.setup_evidence")


def _project_root() -> str:
    """Repo root (parent of cloud/)."""
    here = os.path.dirname(os.path.abspath(__file__))  # cloud/orchestrator
    return os.path.dirname(os.path.dirname(here))      # repo root


def _write_evidence_json(name_prefix: str, payload: Dict[str, Any]) -> Optional[str]:
    """
    Write evidence artifact to docs/runbooks/evidence/. Best-effort; log warning on failure.
    Returns path if written, None otherwise.
    """
    try:
        root = _project_root()
        evidence_dir = os.path.join(root, "docs", "runbooks", "evidence")
        os.makedirs(evidence_dir, exist_ok=True)
        ts = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        suffix = uuid.uuid4().hex[:8]
        fname = "{}_{}_{}.json".format(name_prefix, ts, suffix)
        path = os.path.join(evidence_dir, fname)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return path
    except Exception as exc:
        LOGGER.warning("Failed to write evidence artifact %s: %s", name_prefix, exc)
        return None


def write_gate_snapshot_artifact(
    metrics: Any,
    gate_passed: bool,
    reason: Optional[str],
    project_id: str,
    service_name: str,
    region: str,
    invocation_mode: str = "interactive",
    service_revision: Optional[str] = None,
) -> Optional[str]:
    """
    Write gate snapshot to docs/runbooks/evidence/. Best-effort; log warning on failure.
    Returns path if written, None otherwise.
    """
    if metrics is None:
        return None
    payload = {
        "unique_shadow_processed": getattr(metrics, "unique_shadow_processed_count", 0),
        "unknown_reject_code": getattr(metrics, "unknown_reject_code_count", 0),
        "unhandled_exception": getattr(metrics, "preprocess_unhandled_exception_count", 0),
        "duplicates": getattr(metrics, "duplicate_queue_doc_count_by_message_id", 0),
        "missing_repair_record": getattr(metrics, "dropped_without_repair_record_count", 0),
        "gate_pass": gate_passed,
        "reason": reason,
        "mode": getattr(metrics, "mode", "shadow"),
        "project_id": project_id,
        "service": service_name,
        "region": region,
        "captured_at_utc": dt.datetime.utcnow().replace(tzinfo=dt.timezone.utc).isoformat(),
        "invocation_mode": invocation_mode,
    }
    if service_revision:
        payload["service_revision"] = service_revision
    return _write_evidence_json("preprocessor_gate_snapshot", payload)


def write_backfill_evidence_artifact(
    result: Dict[str, Any],
    project_id: str,
    service_name: str,
    region: str,
) -> Optional[str]:
    """
    Write backfill run evidence to docs/runbooks/evidence/. Best-effort.
    Returns path if written, None otherwise.
    """
    payload = dict(result)
    payload["project_id"] = project_id
    payload["service"] = service_name
    payload["region"] = region
    payload["captured_at_utc"] = dt.datetime.utcnow().replace(tzinfo=dt.timezone.utc).isoformat()
    return _write_evidence_json("backfill_run", payload)
