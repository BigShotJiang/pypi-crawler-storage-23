#!/usr/bin/env python3
"""Startup script with detailed logging for Cloud Run debugging."""

import sys
import os
import logging
import traceback

# Set up logging immediately
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

def log_environment():
    """Log important environment variables and system info."""
    logger.info("=== STARTUP ENVIRONMENT CHECK ===")

    # Check Python version
    logger.info(f"Python version: {sys.version}")

    # Check working directory
    logger.info(f"Working directory: {os.getcwd()}")

    # Check if main.py exists
    main_exists = os.path.exists("main.py")
    logger.info(f"main.py exists: {main_exists}")

    # Check if api.py exists
    api_exists = os.path.exists("api.py")
    logger.info(f"api.py exists: {api_exists}")

    # Log important environment variables (without sensitive data)
    important_env_vars = [
        'PORT', 'PROJECT_ID', 'MAILBOX_USER', 'GCS_BUCKET',
        'AUTH_MODE',  # dwd_preferred | dwd_required | user_oauth_only (ASCII-only for operator logs)
        'GOOGLE_CLOUD_PROJECT', 'K_SERVICE', 'K_REVISION'
    ]

    for var in important_env_vars:
        value = os.environ.get(var, 'NOT_SET')
        if var in ['PROJECT_ID', 'MAILBOX_USER', 'GCS_BUCKET']:
            # Log first few chars for these to verify they're set
            display_value = value[:10] + '...' if len(value) > 10 else value
        else:
            display_value = value
        logger.info(f"{var}: {display_value}")

    # Check file permissions
    try:
        with open("main.py", "r") as f:
            first_line = f.readline().strip()
        logger.info(f"main.py first line: {first_line}")
    except Exception as e:
        logger.error(f"Cannot read main.py: {e}")

def test_imports():
    """Test critical imports."""
    logger.info("=== TESTING IMPORTS ===")

    try:
        logger.info("Importing fastapi...")
        import fastapi
        logger.info("OK: FastAPI version: %s", getattr(fastapi, "__version__", "unknown"))
    except Exception as e:
        logger.error("FAIL: FastAPI import failed: %s", e)
        return False

    try:
        logger.info("Importing uvicorn...")
        import uvicorn
        logger.info("OK: Uvicorn version: %s", getattr(uvicorn, "__version__", "unknown"))
    except Exception as e:
        logger.error("FAIL: Uvicorn import failed: %s", e)
        return False

    try:
        logger.info("Testing main app import...")
        from main import app
        logger.info("OK: Main app import successful")
        logger.info(f"App type: {type(app)}")
    except Exception as e:
        logger.error("FAIL: Main app import failed: %s", e)
        logger.error(f"Traceback: {traceback.format_exc()}")
        return False

    return True

def main():
    """Main startup function. Start listening on PORT immediately so Cloud Run passes the health check."""
    try:
        # Lightweight env dump; helps operators prove which revision/code path is running.
        # Keep it quick to avoid delaying Cloud Run readiness.
        log_environment()

        port = int(os.environ.get("PORT", "8080"))
        # Bind to port as soon as possible; Cloud Run fails if the container doesn't listen in time.
        logger.info("Starting server on port %s (host=0.0.0.0)", port)

        from main import app
        import uvicorn

        uvicorn.run(
            app,
            host="0.0.0.0",
            port=port,
            log_level="info",
            access_log=True,
            server_header=False,
            date_header=False,
        )
    except Exception as e:
        logger.error("Startup failed: %s", e)
        logger.error(traceback.format_exc())
        sys.exit(1)

if __name__ == "__main__":
    main()


















