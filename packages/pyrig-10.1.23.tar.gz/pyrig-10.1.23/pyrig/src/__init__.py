"""The src package contains all code for the project."""
