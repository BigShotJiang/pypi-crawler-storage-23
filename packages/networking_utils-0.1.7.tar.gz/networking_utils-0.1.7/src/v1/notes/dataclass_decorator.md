@dataclass is a Python standard library decorator that auto-generates boilerplate methods for a class based on its field annotations.

Without @dataclass — you'd write this manually:

class SessionInfo:
    def __init__(self, user: str, line: str, idle_hours: float):
        self.user = user
        self.line = line
        self.idle_hours = idle_hours

    def __repr__(self):
        return f"SessionInfo(user={self.user!r}, line={self.line!r}, idle_hours={self.idle_hours!r})"

    def __eq__(self, other):
        return (self.user == other.user and
                self.line == other.line and
                self.idle_hours == other.idle_hours)
With @dataclass — Python generates all of that automatically:

@dataclass
class SessionInfo:
    user: str
    line: str
    idle_hours: float
These two are functionally equivalent. @dataclass generates __init__, __repr__, and __eq__ for free.

What you get automatically
Generated method	What it does	Example
__init__	Constructor with all fields as parameters	SessionInfo(user="admin", line="vty 0", idle_hours=0.09)
__repr__	Human-readable string representation	SessionInfo(user='admin', line='vty 0', idle_hours=0.09)
__eq__	Equality comparison by field values	s1 == s2 compares all fields
Why this codebase uses @dataclass
All the models (SessionInfo, FilesystemResult, AuditDeviceResult, etc.) are pure data containers — they hold values and have no complex behavior. @dataclass is the idiomatic Python way to define such structures:


# Creating an instance — __init__ generated automatically
session = SessionInfo(user="admin", line="vty 0", idle_hours=0.09)

# Accessing fields — normal attribute access
if session.idle_hours < 12.0:
    print(session.user)   # "admin"

# Printing — __repr__ generated automatically
print(session)   # SessionInfo(user='admin', line='vty 0', idle_hours=0.09)

# Comparing — __eq__ generated automatically
s1 = SessionInfo("admin", "vty 0", 0.09)
s2 = SessionInfo("admin", "vty 0", 0.09)
print(s1 == s2)  # True