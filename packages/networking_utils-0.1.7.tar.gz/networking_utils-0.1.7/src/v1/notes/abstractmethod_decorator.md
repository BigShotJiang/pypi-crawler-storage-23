@abstractmethod

It's a decorator from Python's abc (Abstract Base Classes) module. It marks a method as required to be implemented by any concrete subclass.

If a subclass of BaseDriver forgets to implement _get_os_version, Python will raise a TypeError at instantiation time — you can't even create an instance of that class. It's a compile-time-style contract enforced at runtime:


class BadDriver(BaseDriver):
    pass  # forgot to implement _get_os_version

BadDriver(transport)  # → TypeError: Can't instantiate abstract class BadDriver
                      #   without an implementation for abstract method '_get_os_version'
This is how BaseDriver guarantees that every one of the 11 platform drivers (Cisco, Juniper, F5, etc.) has all 7 required methods — the abstract decorator makes it impossible to skip one.

... (Ellipsis)

It's Python's built-in Ellipsis object, used here as a deliberate "empty body" placeholder. It's functionally equivalent to pass in this context — the method has no implementation because the subclass is expected to provide one.

The reason ... is preferred over pass in abstract methods is convention: it signals "this is intentionally left blank as a stub", whereas pass is more commonly seen in concrete code. You'll also see ... used this way in .pyi type stub files and in Protocol definitions.

Both of these are valid and identical in effect:


@abstractmethod
def _get_os_version(self): ...      # preferred style for abstract/stub methods

@abstractmethod
def _get_os_version(self): pass     # also works, but less idiomatic

The abstract _get_os_version in base_driver.py is just the contract. The real show version logic lives in each concrete driver. For example:

Grep "def _get_os_version" (in /home/es8488/claude_network_device_audit/python/src/network_device_audit/drivers, glob: **/*.py)
12 lines of output
Each of the 11 drivers has its own real implementation. Here's what one looks like — cisco_ios/driver.py:28:

Read driver.py (lines 29-48)
So the layering works like this:


base_driver.py
  _get_os_version(self): ...    ← abstract stub — just declares the contract
                                   "every driver MUST have this"

cisco_ios/driver.py
  _get_os_version(self):        ← real implementation
      out = self.transport.send_command("show version")
      m = re.search(r"Cisco IOS Software.*Version\s+([\w().]+)", out)
      return m.group(1) if m else out.splitlines()[0][:80]
Each driver sends the platform-specific command (show version, show system information, etc.) and then uses regex to extract just the version string from the raw CLI output. The base class's ... stub is intentionally empty — its only job is to force every subclass to provide the real thing.