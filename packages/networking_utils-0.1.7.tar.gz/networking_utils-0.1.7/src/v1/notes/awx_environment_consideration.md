# AWX Environment Considerations

## Overview

The `roles/common/tasks/main.yml` runs `pip install -e .` at the start of every job.
This installs three dependencies declared in `python/setup.py`:

| Library | Version | Purpose |
|---------|---------|---------|
| `netmiko` | `>=4.3.0` | SSH to network devices (platform detection + audit) |
| `paramiko` | `>=3.4.0` | Raw SSH for detection when device type is unknown |
| `PyYAML` | `>=6.0` | Read/write `detect_result.yml` handoff file |

Whether these libraries persist between jobs — and whether the internet is needed each
run — depends on which AWX execution model your environment uses.

---

## Model 1: Execution Environment (container-based) — AWX 2.0+

Modern AWX runs each job inside an ephemeral container called an
**Execution Environment (EE)**. The container is created fresh at job start and
destroyed when the job ends.

**Behavior:**
```
Job starts  → fresh container spawned
              pip install -e .  → downloads netmiko, paramiko, PyYAML from PyPI
              job runs
Job ends    → container destroyed
                └── installed libraries GONE

Next job    → fresh container spawned again
              pip install -e .  → must install again
```

### pip cache (key optimization)

pip maintains a local download cache (`~/.cache/pip`). If this cache directory is
**mounted from the host into the container**, pip reuses cached `.whl` files on
subsequent runs and does NOT re-download from the internet:

```
First run:   pip downloads from PyPI → saves to ~/.cache/pip
Second run:  pip finds cache → installs from local cache (no internet needed, fast)
```

Without a cache mount, every job downloads from the internet (~30-60 MB per run).

### Recommended options for container-based AWX

**Option A — pip cache volume mount (simplest)**
Mount the AWX server's pip cache directory into the EE container so it persists
across job runs. Configure in AWX's job settings or EE definition.

**Option B — Custom Execution Environment image (most robust)**
Bake `netmiko`, `paramiko`, and `PyYAML` directly into a custom EE container image.
The `pip install -e .` step then only registers the editable package (near-instant,
no dependencies to download). Rebuild the image only when dependency versions change.

Example `execution-environment.yml`:
```yaml
dependencies:
  python:
    - netmiko>=4.3.0
    - paramiko>=3.4.0
    - PyYAML>=6.0
```

Build with: `ansible-builder build -t my-network-audit-ee`

---

## Model 2: Traditional AWX (no containers) — AWX 1.x / older setups

AWX runs jobs directly on the AWX server (or a separate worker node) using a
persistent Python environment (system Python or a virtualenv). Installed packages
survive between jobs.

**Behavior:**
```
Job 1:  pip install -e .  → installs netmiko, paramiko, PyYAML (first time only)
Job 2:  pip install -e .  → already installed, pip checks versions and exits quickly
Job 3:  pip install -e .  → already installed, pip checks versions and exits quickly
```

No internet access is required after the first successful run (unless a new version
is required by `setup.py`).

This is why `changed_when: false` is set on the pip task — pip always prints output
even when nothing changes, and without this flag every AWX job would show as
"changed" in its run history even when nothing was actually modified.

---

## Summary

| AWX type | Libraries persist between jobs? | Internet needed each run? |
|----------|--------------------------------|--------------------------|
| Container-based EE (AWX 2.0+) | No — container is discarded | Yes, unless pip cache is mounted or EE image pre-installs libs |
| Traditional / no containers | Yes — persists on server | No — already installed after first run |

---

## Recommendation

For production environments running 4000+ devices on a schedule:

1. **If using Execution Environments:** build a custom EE image with the three
   libraries pre-installed. This eliminates the per-job download, reduces job
   startup time, and removes the dependency on internet access at job runtime.

2. **If using traditional AWX:** no action needed — `pip install -e .` is
   effectively a no-op after the first run.

3. **If internet access from AWX is restricted (air-gapped):** configure a
   private PyPI mirror (e.g., Artifactory, Nexus) and point pip to it via
   `pip.conf` or the `PIP_INDEX_URL` environment variable in AWX settings.
