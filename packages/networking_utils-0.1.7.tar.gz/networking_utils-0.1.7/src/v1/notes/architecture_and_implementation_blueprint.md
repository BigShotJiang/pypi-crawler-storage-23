# network_device_audit -- Architecture & Implementation Blueprint v2

------------------------------------------------------------------------

## 1. Project Goal

Build an AWX-scheduled Ansible playbook that audits 4000+ heterogeneous
network devices across a large organization.

**Ansible is a thin wrapper and orchestrator only.** All device
interaction logic — SSH connectivity, platform detection, compliance
checks, config remediation, and reporting — is implemented in native
Python. Existing Ansible network modules (e.g. `cisco.ios`, `junipernetworks.junos`,
`ansible.netcommon`) are **not used**. Python uses Netmiko (preferred)
or Paramiko (fallback) directly.

------------------------------------------------------------------------

## 2. Supported Device Types

The following platforms are in scope. A dedicated driver must be
implemented for each:

| Platform         | Notes                                                              |
|------------------|--------------------------------------------------------------------|
| Cisco IOS        | Enable mode required (same password). Includes Catalyst switches   |
| Cisco IOS-XE     | Enable mode required (same password). Includes newer Catalyst 9k+  |
| Cisco IOS-XR     | Enable mode required (same password)                               |
| Cisco NX-OS      | Enable mode required (same password). If ACI mode detected, skip in Audit Mode (detect only) |
| Juniper JunOS    |                                                                    |
| Arista EOS       |                                                                    |
| F5               |                                                                    |
| Citrix VPX/SDX   |                                                                    |
| Dell OS10        |                                                                    |
| Dell OS9/FTOS    |                                                                    |
| A10              |                                                                    |

------------------------------------------------------------------------

## 3. Execution Model

-   Playbooks run on AWX as scheduled jobs.
-   AWX manages inventory and credentials.
-   AWX connects directly to devices (no jump host required).
-   Credentials are passed to the Python layer via Ansible vars.
-   Enable password (where required) uses the same value as the login
    password.
-   Config-save/commit actions are permitted and must be logged and
    reported.

------------------------------------------------------------------------

## 4. Ansible vs Python Responsibilities

### Ansible does:
-   Schedule and launch jobs via AWX
-   Pass inventory, credentials, and parameters to the Python layer
-   Invoke the Python entry point (`script` or `command` module)
-   Collect and store artifacts after Python execution completes

### Ansible does NOT:
-   Connect to devices directly
-   Use any Ansible network modules (e.g. `cisco.ios`, `junipernetworks.junos`,
    `ansible.netcommon`, `napalm`)
-   Implement any detection, auditing, or remediation logic

### Python does:
-   All SSH connectivity (via Netmiko or Paramiko)
-   Platform detection and fingerprinting
-   All audit checks (OS version, filesystem, fan health, config diff)
-   Config backup and remediation
-   Multi-threaded execution
-   Result serialization (JSON/YAML) and artifact packaging (.tar.gz)

------------------------------------------------------------------------

## 5. Multi-Threading Requirement

-   The system must use multi-threading to detect and audit devices
    concurrently.
-   Default thread pool size: **8 threads** (configurable via playbook
    variable).
-   Thread pool cap is the sole concurrency control mechanism — no
    additional AAA rate limiting is required.
-   Threading applies to both Detect Mode and Audit Mode.

------------------------------------------------------------------------

## 6. Operational Modes

### 6.1 Detect Mode

-   Scheduled: **weekly**
-   Purpose: SSH into each device, identify its platform/device type,
    and write results to `detect_result.yml`.
-   Storage destination for `detect_result.yml` is controlled by the
    playbook parameter `detect_result_storage` (see Section 6.3).
-   `detect_result.yml` serves as the source of truth consumed by
    Audit Mode.

### 6.2 Audit Mode

-   Scheduled: **daily**
-   Purpose: Perform compliance audit using device types from
    `detect_result.yml`.
-   Reads `detect_result.yml` from the location specified by
    `detect_result_storage` parameter.
-   Fails hard with a clear error if `detect_result.yml` is missing
    or unreadable.
-   Devices marked `unknown` in detect results are skipped.

### 6.3 detect_result_storage Parameter

Controls where `detect_result.yml` is written (detect mode) and read
from (audit mode). Set as an AWX extra variable at job launch.

| Value   | Behavior                                                                 |
|---------|--------------------------------------------------------------------------|
| `repo`  | Commit `detect_result.yml` to the project repo via git push. Requires AWX git push access. Provides full version history. |
| `local` | Write `detect_result.yml` to a well-known path on the AWX server (e.g. `/var/lib/awx/detect_results/detect_result.yml`). Simpler, no git access required. |

Default: `repo`

### Other Audit Mode AWX Extra Variables

| Variable                  | Default | Description                                                                              |
|---------------------------|---------|------------------------------------------------------------------------------------------|
| `thread_count`            | `8`     | Concurrent SSH connections (ThreadPoolExecutor workers).                                 |
| `ssh_port`                | `22`    | SSH port used for all device connections.                                                |
| `session_max_idle_hours`  | `12`    | Sessions idle less than this many hours are treated as active and block a config save.   |
| `filesystem_critical_pct` | `70`    | Filesystem usage % above which the check is flagged CRITICAL (`>` threshold = CRITICAL). |
| `change`                  | `false` | If `true`, save running config to startup when unsaved changes are detected. If `false` (default), report the diff only — no backup or save is performed. All other audit checks always run regardless of this setting. |

------------------------------------------------------------------------

## 6. Device Detection Strategy

Detection is attempted in the following order for each device:

1.  **Primary — Netmiko SSHDetect**: Use Netmiko's built-in
    autodetect.
2.  **Fallback — Paramiko + `show version`**: If Netmiko autodetect
    fails, connect via raw Paramiko SSH and run `show version` on all
    devices. Parse prompt and/or `show version` output to fingerprint
    the platform.
3.  **Last resort**: If both methods fail, mark device as `unknown`.
    Unknown devices are skipped in Audit Mode.

### 6.1 NX-OS ACI Mode Heuristic Detection

During detect, if a device is identified as NX-OS, determine whether
it is running in ACI mode using the following heuristics (in order):

1.  Check `show version` output for the keyword `aci` in the software
    version string (ACI NX-OS builds typically include "aci" in the
    image name).
2.  Run `show system internal processes | grep apic` — presence of
    APIC-related processes confirms ACI mode.
3.  Run `show system mode` — if output contains `ACI`, confirm ACI
    mode.

If any heuristic confirms ACI mode, record `aci_mode: true` in
`detect_result.yml` for that device. Audit Mode will skip these
devices.

------------------------------------------------------------------------

## 7. Audit Items

-   Device type confirmation
-   Operating System version collection
-   Filesystem usage check:
    -   Linux-based platforms check `/var` usage (the primary writable
        partition on these OS types).
    -   Non-Linux platforms check their native persistent storage
        equivalent (see table below). There is no `/var` on these
        platforms.
    -   The `path` field in audit results reflects the actual path
        checked on that platform (e.g. `flash:` for IOS, `/var` for
        IOS-XR).
    -   If the storage path does not exist or cannot be queried, skip
        this check.
    -   Threshold: **> 70% usage = critical finding** (configurable via
        `filesystem_critical_pct` playbook variable / `--filesystem-critical-pct` CLI
        flag; default 70)

    | Platform         | OS type       | Filesystem path checked |
    |------------------|---------------|-------------------------|
    | Cisco IOS        | IOS (non-Linux) | `flash:`              |
    | Cisco IOS-XE     | IOS-XE (non-Linux) | `disk0:`           |
    | Cisco IOS-XR     | Linux-based   | `/var`                  |
    | Cisco NX-OS      | Linux-based   | `/var`                  |
    | Juniper JunOS    | FreeBSD-based | `/var`                  |
    | Arista EOS       | Linux-based   | `/var/log`              |
    | F5               | Linux-based   | `/var`                  |
    | Citrix VPX/SDX   | Linux-based   | `/var`                  |
    | Dell OS10        | Linux-based   | `/var`                  |
    | Dell OS9/FTOS    | non-Linux     | `flash:`                |
    | A10              | Linux-based   | `/var`                  |
-   Fan health status check:
    -   Simple **pass/fail per fan** (no RPM or temperature data
        required).
    -   If the platform does not expose fan status via CLI, mark as
        `n/a`.
-   Unsaved configuration detection (running vs startup config):
    -   If no difference: mark compliant.
    -   If unsaved config exists:
        -   If `change=false` (default): record the diff, mark as
            `report_only`, and stop — **no backup or save is performed**.
        -   If `change=true`:
            -   Check for active SSH sessions on the device:
                -   Each platform driver implements its own session check
                    using the platform-native command (see Section 7.1).
                -   If any session has been active for **≤ 12 hours**: skip
                    the save, log the reason (active session detected), and
                    mark the device as `save_skipped`. (The 12-hour threshold
                    is configurable via `session_max_idle_hours` playbook
                    variable / `--session-max-idle-hours` CLI flag; default 12)
                -   If all sessions have been active for **> 12 hours** (or
                    no active sessions found): proceed with save.
            -   Backup old config
            -   Save running config (write memory / commit)
            -   Verify remediation: re-run diff and confirm it is clean

### 7.1 Per-Platform SSH Session Check Commands

Each driver uses the platform-native command to retrieve active SSH
sessions and their duration. The driver parses the output and returns
the age (in hours) of the youngest active session.

| Platform       | Command                        | Duration field             |
|----------------|--------------------------------|----------------------------|
| Cisco IOS      | `show users`                   | Idle/connect time in output |
| Cisco IOS-XE   | `show users`                   | Idle/connect time in output |
| Cisco IOS-XR   | `show users`                   | Idle/connect time in output |
| Cisco NX-OS    | `show users`                   | Login time in output        |
| Juniper JunOS  | `show system users`            | Login time in output        |
| Arista EOS     | `show users`                   | Duration in output          |
| F5             | `show sys connection`          | Duration in output          |
| Citrix VPX/SDX | `who`                          | Login time in output        |
| Dell OS10      | `show users`                   | Idle/connect time in output |
| Dell OS9/FTOS  | `show users`                   | Idle/connect time in output |
| A10            | `show admin-session`           | Duration in output          |

If the session check command fails or the output cannot be parsed,
the save is **skipped by default** (safe side) and the failure is
logged.

------------------------------------------------------------------------

## 8. Error Handling & Retry Policy

### 8.1 Unreachable Devices (SSH connection failure)

-   Retry up to **3 attempts with exponential backoff**.
-   After 3 failures, mark device as `unreachable` and log the error.

### 8.2 Partial Failures (connected but command times out)

-   Retry the specific timed-out command up to **3 attempts with
    exponential backoff**.
-   If the command still fails after 3 retries, log the failure and
    continue with the remaining checks on the device.
-   The device session is not aborted on a single command failure.

------------------------------------------------------------------------

## 9. F5 / Citrix HA Special Treatment

F5 BIG-IP and Citrix VPX/SDX can run in high-availability (HA)
configurations.  Their config-save workflow is fundamentally different
from standalone devices and requires HA-awareness at audit time.

### 9.1 Shared Design Decisions (both platforms)

-   **Always audit the active/primary node.** If a thread's inventory
    device is determined to be a standby/secondary, it is immediately
    marked `ha_standby_skipped` and the thread exits. The thread that
    audits the active node is responsible for all follow-up work on
    standby members.
-   **Standby member IPs are discovered from the active node's CLI**,
    not from the AWX inventory. This keeps the approach self-contained
    and requires no extra inventory entries for HA peers.
-   **Fallback to standard single-device save** when no HA group /
    HA peer is detected (standalone deployments).
-   **Auto-sync anomaly reporting:** if auto-sync is enabled but the
    group is still out of sync, this indicates a production issue. In
    that case take no remediation action — report the anomaly and let
    operators investigate.

### 9.2 F5 BIG-IP — Device Group Config Sync

F5 uses *device groups* (DSC — Device Service Clustering) to replicate
configuration across cluster members.

#### Discovery (from the active device)

1.  Run `tmsh list cm device-group` to enumerate all device groups and
    their member hostnames/IPs.
2.  Run `tmsh show cm sync-status` to determine:
    -   Which device is currently **active** (traffic group owner).
    -   The sync state of each member (`In Sync`, `Changes Pending`,
        `Disconnected`, `Sync Failed`).
    -   Whether **auto-sync** is configured for each device group
        (`auto-sync enabled` / `auto-sync disabled`).

#### Config-save logic

| Condition | Action |
|---|---|
| No device group found (standalone) | Fall back to standard `save sys config` on this device only. |
| This device is a **standby** member | Mark as `ha_standby_skipped`. Active-node thread handles the group. |
| Any member **out of sync** AND auto-sync **disabled** | Enforce sync from active: `run cm config-sync to-group <group>`. Then SSH to each member individually and run `save sys config`. |
| Any member **out of sync** AND auto-sync **enabled** | Do NOT sync. Report as `ha_sync_anomaly` (auto-sync should have handled this — production issue). |
| All members **in sync** | Run `save sys config` on each member individually (running config is consistent; just persist it to disk). |

#### Reporting

The audit result for the active node includes:
-   `ha_group`: device group name
-   `ha_members`: list of member hostnames/IPs with their individual
    sync status
-   `ha_auto_sync`: `true` / `false`
-   `ha_sync_enforced`: `true` if a `config-sync` command was issued
-   `ha_anomaly`: `true` if auto-sync was on but group was out of sync
-   `config_saved_members`: list of members where `save sys config`
    succeeded

### 9.3 Citrix VPX/SDX — HA Pair

Citrix ADC uses a **primary/secondary HA pair**. The primary processes
traffic; the secondary is a hot standby.

#### Discovery (from the active device)

1.  Run `show ha node` to determine:
    -   This node's HA role: `Primary` or `Secondary`.
    -   The peer node's IP address (`show ha node` includes peer IP).
    -   HA sync state: `IN SYNC` / `OUT OF SYNC`.
    -   Whether **synchronisation** (auto-sync) is enabled:
        `Sync State: ENABLED` / `DISABLED`.

#### Config-save logic

| Condition | Action |
|---|---|
| No HA peer found (standalone) | Fall back to standard `save ns config` on this node only. |
| This node is the **secondary** | Mark as `ha_standby_skipped`. Primary-node thread handles the pair. |
| Nodes **out of sync** AND auto-sync **disabled** | Force HA sync from primary: `force ha failover` is NOT used — instead run `sync ha files` or equivalent to push config to secondary. Then `save ns config` on both nodes. |
| Nodes **out of sync** AND auto-sync **enabled** | Do NOT sync. Report as `ha_sync_anomaly` (production issue). |
| Nodes **in sync** | Run `save ns config` on primary, then SSH to secondary and run `save ns config` there too. |

#### Reporting

The audit result for the primary node includes:
-   `ha_peer_ip`: secondary node IP
-   `ha_state`: `IN SYNC` / `OUT OF SYNC`
-   `ha_auto_sync`: `true` / `false`
-   `ha_sync_enforced`: `true` if a sync command was issued
-   `ha_anomaly`: `true` if auto-sync was on but pair was out of sync
-   `config_saved_members`: `[primary_hostname, secondary_hostname]` on
    success

------------------------------------------------------------------------

## 10. Detect Mode Flow Diagram

    Start (AWX Job - mode=detect)
        ↓
    Load Inventory Targets
        ↓
    Initialize Thread Pool (default 8 threads)
        ↓
    For each device (executed concurrently):
        → Attempt SSH login (3 retries with backoff on failure)
            → If failed after 3 attempts: record unreachable/error
            → If successful:
                → Attempt Netmiko SSHDetect (primary)
                    → If identified: map to canonical device_type + driver
                    → If failed: attempt Paramiko + show version (fallback)
                        → If identified: map to canonical device_type + driver
                        → If failed: mark as unknown
                → Write result to detect_result.yml + raw session log
        ↓
    Aggregate summary report
        ↓
    Store detect_result.yml based on detect_result_storage param:
        → If repo:  commit and push to project repo (via git push)
        → If local: write to /var/lib/awx/detect_results/detect_result.yml
        ↓
    Bundle all artifacts into a single .tar.gz file
        ↓
    Store .tar.gz as AWX job artifact (downloadable from AWX UI)
        ↓
    End

------------------------------------------------------------------------

## 11. Audit Mode Flow Diagram

    Start (AWX Job - mode=audit)
        ↓
    Load detect_result.yml based on detect_result_storage param:
        → If repo:  read from project repo path
        → If local: read from /var/lib/awx/detect_results/detect_result.yml
        → If missing or unreadable: FAIL HARD with clear error message
        ↓
    Load Inventory Targets
        ↓
    Initialize Thread Pool (default 8 threads)
        ↓
    For each device (executed concurrently):
        → Check device_type from detect_result.yml
            → If unknown: skip device, log skip reason
            → If NX-OS in ACI mode: skip device, log skip reason (detect only, no audit required)
        → Attempt SSH Connect (3 retries with backoff on failure)
            → If failed after 3 attempts: record unreachable/error
            → If successful:
                → Enter enable mode if required (Cisco platforms)
                → Collect metadata (OS version, device type confirmation)
                    (retry each command up to 3x with backoff on timeout)
                → Check filesystem / /var usage
                    (retry each command up to 3x with backoff on timeout)
                    → If /var or equivalent does not exist: skip
                    → If > filesystem_critical_pct% (default 70): flag as critical
                → Check fan health per fan
                    (retry each command up to 3x with backoff on timeout)
                    → If no CLI fan status available: mark n/a
                → Compare running vs startup config
                    (retry each command up to 3x with backoff on timeout)
                    → If no difference: mark compliant
                    → If unsaved config exists:
                        → If change=false (default):
                            → Record diff, mark as report_only (no save)
                        → If change=true:
                            → Check active SSH sessions on device
                                → If any session active ≤ session_max_idle_hours (default 12):
                                    → Skip save, log active session details
                                    → Mark as save_skipped
                                → If all sessions > session_max_idle_hours (or none active):
                                    → Backup old config
                                    → Save running config (write memory / commit)
                                    → Re-run diff to verify remediation is clean
                → Write audit_result.json + raw session log
        ↓
    Aggregate summary report (highlight devices where config was saved or save was skipped)
        ↓
    Bundle all artifacts into a single .tar.gz file
        ↓
    Store .tar.gz as AWX job artifact (downloadable from AWX UI)
        ↓
    End

------------------------------------------------------------------------

## 12. Reporting Requirements

-   All artifacts stored as a single downloadable `.tar.gz` AWX job
    artifact.
-   Per-device structured JSON results (`audit_result.json`).
-   Raw session logs retained per device.
-   Explicit reporting of devices where configuration was
    saved/committed.
-   Aggregated summary visible in AWX job output.
-   `detect_result.yml` committed to project repo after each detect
    run for historical tracking.

------------------------------------------------------------------------

## 13. Codebase Directory Structure Overview

    network_device_audit/
      playbooks/
        detect.yml
        audit.yml
      roles/
        detect/
        audit/
        common/
      python/
        src/network_device_audit/
          core/
          transport/
          detect/
          audit/
          drivers/
            cisco_ios/
            cisco_iosxe/
            cisco_iosxr/
            cisco_nxos/
            juniper_junos/
            arista_eos/
            f5/
            citrix/
            dell_os10/
            dell_os9/
            a10/
          parsers/
      inventories/
      artifacts/
      detect_result.yml
      docs/
