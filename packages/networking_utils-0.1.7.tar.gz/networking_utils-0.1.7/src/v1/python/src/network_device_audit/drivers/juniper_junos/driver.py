# ============================================================
# drivers/juniper_junos/driver.py — Juniper JunOS Driver
# ============================================================
# Covers: Juniper MX (routers), QFX (data center switches),
#         SRX (firewalls/security gateways), EX (enterprise switches).
#
# JunOS is FreeBSD-based (not Linux — FreeBSD is a separate Unix
# derivative). Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     JunOS CLI grants full access on login; no "enable" command.
#   - Filesystem: /var on FreeBSD — checked via Juniper's own
#     "show system storage" command (not raw df).
#   - Config model: commit-based (same concept as IOS-XR)
#     "commit" saves/activates; "rollback 0" = last committed config
#   - CLI pipe operator: Juniper uses "| match" instead of "| grep"
#     and "| display set" converts config to set-format (flat/scriptable)
#   - Sessions: "show system users" (different from Cisco's "show users")
#     IDLE column: "-" means actively typing (0 idle), integer = minutes
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class JuniperJunOSDriver(BaseDriver):
    PLATFORM = "juniper_junos"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False          # JunOS: full CLI access without a separate enable step

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # JunOS version line: "JUNOS 21.4R3.15"
        # Pattern: "JUNOS" keyword followed by version string.
        # Version format: <major>.<minor>R<build>.<patch> (e.g. "21.4R3.15")
        # [\w.R\-]+ matches letters, digits, dots, 'R', and hyphens — all valid in JunOS versions.
        m = re.search(r"JUNOS\s+([\w.R\-]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("show system storage | match /var")
        # COMMAND EXPLANATION:
        # "show system storage" is Juniper's built-in command for filesystem usage.
        # It shows all mounted filesystems with used/free space — similar to 'df'.
        # "| match /var" is Juniper's pipe filter (equivalent to "| grep /var") —
        # returns only lines containing "/var".
        #
        # Example output (after pipe filter):
        #   /var           5.6G  3.8G  1.3G    74%  /var
        #
        # Columns (df-style): Filesystem / Size / Used / Avail / Use% / Mounted-on
        # The percentage column (Use%) is what we need.
        #
        # WHY NOT "df -h /var"?
        # Juniper's "show system storage" is preferred over raw shell commands
        # because it works within the JunOS CLI without needing shell escape (start shell).
        # "| match" is the JunOS equivalent of grep.
        if not out:
            # If the command returns no output (maybe /var is not a separate mount),
            # return SKIPPED rather than raising an error.
            return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                # Matches the "Use%" column, e.g. "74%".
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var",                            # Path checked
                        usage_pct=pct,                          # e.g. 74.0
                        status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL
                    )
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show chassis environment | match fan")
        # COMMAND EXPLANATION:
        # "show chassis environment" shows hardware sensor data (temps, fans, PSUs).
        # "| match fan" filters to lines containing "fan" (case-insensitive match).
        #
        # Example output:
        #   Intake Fan 0          Spinning at normal speed
        #   Intake Fan 1          Spinning at normal speed
        #   Exhaust Fan 0         OK
        #
        # JunOS fan status words:
        #   "OK" or "Spinning" = healthy
        #   "Check" or "Failed" or "Absent" = problem
        if not out:
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: capture fan name + status keyword.
            # JunOS fan names can include spaces: "Intake Fan 0", "Exhaust Fan 1".
            m = re.search(r"([\w\s]+ [Ff]an[\s\w]*).*?(OK|Check|Absent|Spinning|Failed)", line, re.IGNORECASE)
            if m:
                # "OK" and "Spinning" = fan is working
                # "Check", "Absent", "Failed" = problem
                status = FanStatus.PASS if re.search(r"OK|Spinning", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # "show configuration | display set" outputs the config in SET FORMAT:
        # each stanza becomes a flat "set" command, e.g.:
        #   set interfaces ge-0/0/0 unit 0 family inet address 10.1.1.1/30
        # This format is diff-friendly (each line is independent) and scriptable.
        # Alternative: "show configuration" without "display set" shows hierarchical format.
        # timeout=60: large JunOS configs (MX with BGP/MPLS) can take 30+ seconds.
        return self.transport.send_command("show configuration | display set", timeout=60)

    def _get_startup_config(self) -> str:
        # JunOS committed config is the running config; "rollback 1" is previous
        # JUNOS COMMIT MODEL:
        # JunOS uses a commit-based config model (similar to IOS-XR):
        #   - Active config (running) = what's currently applied
        #   - "rollback 0" = the last committed version (same as current active)
        #   - "rollback 1" = the previous committed version (one step back)
        #
        # "show configuration | display set | rollback 0" means:
        #   "Show configuration AS OF rollback point 0, in set format"
        # rollback 0 is the persisted committed state that survives reboot.
        # Since rollback 0 == running when there are no uncommitted changes,
        # configs_differ() will return False (no save needed) in normal operation.
        return self.transport.send_command("show configuration | display set | rollback 0", timeout=60)

    def _save_config(self) -> str:
        # JunOS SAVE = COMMIT:
        # "commit" atomically validates and activates the candidate configuration.
        # After commit, the new config becomes both running AND rollback 0 (persistent).
        # If there's nothing in the candidate config, commit returns "commit complete" without error.
        return self.transport.send_command("commit", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # show system users example:
        # USER     TTY      FROM            LOGIN@  IDLE WHAT
        # admin    p0       10.0.0.100      2:00PM     - cli
        # ops      p1       10.0.0.101      8:00AM    14  cli
        # IDLE "-" means currently active (treat as 0 min); number = minutes idle
        #
        # Column layout:
        #   [0] USER  = username
        #   [1] TTY   = terminal (e.g. "p0" = pseudo-terminal 0 = SSH)
        #   [2] FROM  = source IP
        #   [3] LOGIN = login time (e.g. "2:00PM")
        #   [4] IDLE  = minutes idle OR "-" if currently active
        #   [5] WHAT  = current command (usually "cli")
        out = self.transport.send_command("show system users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and the header row (starts with "USER").
            if not line.strip() or re.match(r"\s*USER", line, re.IGNORECASE):
                continue
            parts = line.split()
            # Need at least 5 columns to have user, tty, from, login, idle.
            if len(parts) >= 5:
                user = parts[0]      # Column 0: username
                line_id = parts[1]   # Column 1: terminal (e.g. "p0")
                idle_str = parts[4]  # Column 4: IDLE value ("-" or minutes)
                if idle_str == "-":
                    # "-" means actively typing — treat as 0.0 hours idle.
                    # An active user = session is NOT idle → do NOT skip config save.
                    idle_hours = 0.0
                else:
                    # parse_hhmm_ss handles: "14" (minutes as decimal), "1:30" (HH:MM), etc.
                    idle_hours = parse_hhmm_ss(idle_str)
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 = treat as active if parse fails (conservative).
                ))
        return sessions
