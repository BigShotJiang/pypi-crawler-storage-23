"""
main_audit.py — Audit Mode Entry Point

This is the top-level script that Ansible runs to perform the full device audit.
It is invoked by the Ansible playbook (playbooks/audit.yml) as:

    python -m network_device_audit.main_audit \\
        --inventory              /path/to/inventory.json \\  # Rendered from Ansible inventory
        --username               <user> \\                    # SSH username (from AWX credential)
        --password               <pass> \\                    # SSH password (from AWX credential)
        --artifact-dir           /runner/artifacts/<job_id> \\  # AWX artifact dir for output files
        --repo-path              /path/to/project \\          # Project root (for "repo" storage mode)
        --storage                repo|local \\                # Where detect_result.yml was saved
        --threads                8 \\                         # Concurrent SSH connections
        --job-id                 <job_id> \\                  # AWX job ID (for artifact filenames)
        --session-max-idle-hours 12 \\                        # Hours threshold for "active session" detection
        --filesystem-critical-pct 70 \\                       # % /var usage above which we flag CRITICAL
        --change                                              # (optional) enable config save/remediation

--change FLAG:
  Without --change (default): the audit is fully read-only.  OS version,
  filesystem, fans, and running-vs-startup diff are all collected and reported,
  but the tool NEVER writes anything to a device.  Config diffs are recorded as
  ConfigStatus.REPORT_ONLY in the per-device JSON and counted in the summary.

  With --change: when unsaved config is found and no active session blocks the
  save (idle < --session-max-idle-hours), the tool performs backup → save →
  verify and records ConfigStatus.REMEDIATED.  For F5/Citrix HA groups the
  driver opens fresh SSH sessions to each member and saves them all.

WHAT THIS SCRIPT DOES:
  1. Parses CLI arguments (injected by Ansible playbook)
  2. Loads detect_result.yml — the handoff file written by detect mode.
     CRITICAL: If this file is missing, audit mode exits immediately (code 1).
     Audit mode CANNOT proceed without knowing each device's platform type.
  3. Loads the JSON inventory (for device IP addresses)
  4. For each inventory device:
     - Checks detect_result.yml: was detection successful? Is it ACI mode?
     - Skips devices that weren't identified or are in ACI mode
     - Submits auditable devices to the ThreadPoolExecutor
  5. Collects results and writes audit artifacts (.tar.gz bundle)
  6. Exits with code 0 (success) for any outcome — device failures are recorded

THE detect_result.yml DEPENDENCY:
  Audit mode depends completely on detect mode having run first.
  detect_result.yml contains:
    - platform label (e.g. "cisco_ios") → which driver to use
    - netmiko device_type (e.g. "cisco_xe") → how to connect
    - aci_mode flag → whether to skip this device
    - status → whether detection succeeded
  Without this file, audit mode can't know which CLI commands to send to each device.

ACI MODE SKIP:
  NX-OS devices in ACI mode are managed by an APIC controller.
  Running audit commands (like copy running-config startup-config) on an ACI-managed
  Nexus switch would interfere with the APIC fabric. These devices are SKIPPED.
"""

import argparse
import json
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from .core.exceptions import DetectResultMissingError
from .core.logger import setup_logging
from .core.models import AuditDeviceResult, DeviceStatus
from .detect.result_store import load_detect_results
from .audit.auditor import audit_device
from .audit.reporter import write_audit_results

# Maps platform labels to Netmiko device_type strings.
# WHY a separate mapping here (and not in drivers/registry.py)?
# The driver registry maps platforms to driver CLASSES.
# This mapping is for Netmiko specifically — Netmiko has its own naming conventions
# that don't always match our internal platform labels.
# For example:
#   Our label:     Netmiko type:   WHY different?
#   cisco_iosxe -> cisco_xe        Netmiko uses "xe" abbreviation (not "iosxe")
#   cisco_iosxr -> cisco_xr        Netmiko uses "xr" abbreviation (not "iosxr")
#   dell_os9    -> dell_ftos       Netmiko calls it "ftos" (Force10 OS) not "os9"
#   f5          -> f5_ltm          Netmiko type is product-specific (LTM = Local Traffic Manager)
#   citrix      -> generic_termserver  No native Netmiko Citrix driver; use generic terminal
#   a10         -> generic_termserver  No native Netmiko A10 driver; use generic terminal
_PLATFORM_TO_NETMIKO = {
    "cisco_ios":     "cisco_ios",         # Cisco IOS — Netmiko native driver
    "cisco_iosxe":   "cisco_xe",          # Cisco IOS-XE — Netmiko uses "xe" abbreviation
    "cisco_iosxr":   "cisco_xr",          # Cisco IOS-XR — Netmiko uses "xr" abbreviation
    "cisco_nxos":    "cisco_nxos",        # Cisco NX-OS — Netmiko native driver
    "juniper_junos": "juniper_junos",     # Juniper JunOS — Netmiko native driver
    "arista_eos":    "arista_eos",        # Arista EOS — Netmiko native driver
    "f5":            "f5_ltm",            # F5 BIG-IP — Netmiko type is "f5_ltm" (LTM product)
    "citrix":        "generic_termserver",# Citrix ADC — no native Netmiko driver; generic terminal
    "dell_os10":     "dell_os10",         # Dell OS10 — Netmiko native driver
    "dell_os9":      "dell_ftos",         # Dell OS9 — Netmiko calls it FTOS (Force10 OS)
    "a10":           "generic_termserver",# A10 Networks — no native Netmiko driver; generic terminal
}


def parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments passed by the Ansible playbook.

    These arguments mirror detect mode's arguments — the same playbook structure
    is used for both modes, with only the Python module name changing.
    """
    p = argparse.ArgumentParser(description="Network device audit mode")
    p.add_argument("--inventory", required=True, help="Path to JSON inventory file")
    # --inventory: JSON file rendered from Ansible inventory.
    # Same format as detect mode: [{"hostname": "sw01", "ip": "10.0.0.1"}, ...]

    p.add_argument("--username", required=True)
    p.add_argument("--password", required=True)
    # --username/--password: SSH credentials injected from AWX machine credentials.

    p.add_argument("--artifact-dir", required=True)
    # --artifact-dir: AWX artifact directory. All output files go here.

    p.add_argument("--repo-path", default=None)
    # --repo-path: project repo root. Must match what was used in detect mode.
    # Used to find detect_result.yml in "repo" storage mode.

    p.add_argument("--storage", default="repo", choices=["repo", "local"])
    # --storage: where detect_result.yml was written in detect mode.
    # IMPORTANT: must match the detect run's storage mode, or the file won't be found.

    p.add_argument("--threads", type=int, default=8)
    # --threads: concurrent SSH connections to devices.

    p.add_argument("--job-id", required=True)
    # --job-id: AWX_JOB_ID, used to name the artifact bundle.

    p.add_argument("--port", type=int, default=22)
    # --port: SSH port.

    p.add_argument("--session-max-idle-hours", type=float, default=12.0)
    # --session-max-idle-hours: sessions idle less than this many hours are treated as
    # "active" and will block a config save.  Default 12 = full business-day coverage.

    p.add_argument("--filesystem-critical-pct", type=float, default=70.0)
    # --filesystem-critical-pct: /var (or equivalent) usage percentage above which the
    # filesystem check is flagged CRITICAL.  Default 70 = >70% triggers CRITICAL.

    p.add_argument("--change", action="store_true", default=False)
    # --change: enables config save/remediation mode.
    # action="store_true": the flag is a boolean switch — pass it to enable, omit to disable.
    #   Without --change (default, False): fully read-only audit.
    #     Config diffs are found and reported as REPORT_ONLY.
    #     NO backup is taken, NO save command is sent to any device.
    #   With --change (True): remediation mode.
    #     When a config diff is found and no active session blocks the save,
    #     the tool runs backup → save → verify.
    #     For F5/Citrix HA groups, the driver SSHes to each member and saves them all.
    # IMPORTANT: In AWX, the Ansible playbook conditionally adds the "--change" flag
    # based on the "change" extra variable (see playbooks/audit.yml).

    return p.parse_args()


def load_inventory(path: str) -> list[dict]:
    """Load device inventory from the JSON file rendered by Ansible."""
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def run_audit(args: argparse.Namespace) -> int:
    """
    Main audit logic. Returns exit code (0 = success, 1 = fatal error).

    Fatal error: detect_result.yml missing (exits with code 1).
    All other errors (device unreachable, audit failure) are recorded in results,
    not propagated as fatal errors. The script exits with 0 regardless.
    """
    setup_logging(log_dir=args.artifact_dir, job_id=args.job_id)
    # setup_logging: stdout + file handlers for AWX visibility and artifact logging.
    logger = logging.getLogger(__name__)

    # ── Load detect_result.yml — fail hard if missing ─────────────────────────
    try:
        detect_data = load_detect_results(
            storage_mode=args.storage,
            repo_path=args.repo_path,
        )
        # load_detect_results() reads the detect_result.yml from the configured location.
        # Returns a dict: {"devices": {"hostname": {...}, "hostname2": {...}}}
    except DetectResultMissingError as exc:
        # FATAL: cannot proceed without detect results.
        # If detect mode hasn't run, or the file was lost, we must abort.
        logger.critical("FATAL: %s", exc)
        print(f"FATAL: {exc}", file=sys.stderr)
        return 1    # Exit code 1 = fatal failure; Ansible will mark the task as failed.

    detect_devices: dict = detect_data.get("devices", {})
    # detect_devices: dict keyed by hostname — O(1) lookup for each inventory device.
    # Example: detect_devices["sw-core-01"] = {"platform": "cisco_ios", "ip": ..., ...}

    inventory = load_inventory(args.inventory)
    logger.info("Audit mode started — %d inventory devices, %d threads", len(inventory), args.threads)

    results: list[AuditDeviceResult] = []
    # Results list: one entry per device. Skip results are added immediately;
    # audit results are added as futures complete.

    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        futures = {}    # Maps Future → hostname (for error reporting after future completes)

        for device in inventory:
            hostname = device["hostname"]
            ip = device.get("ip", hostname)     # IP for SSH; fallback to hostname if no "ip" key
            detect_entry = detect_devices.get(hostname, {})
            # detect_entry: the detect_result.yml entry for this device.
            # Empty dict {} if hostname not found in detect results (device added after last detect run).

            platform = detect_entry.get("platform")
            # platform: our internal label (e.g. "cisco_ios", "juniper_junos").
            # None if device wasn't detected or detection failed.

            aci_mode = detect_entry.get("aci_mode", False)
            # aci_mode: True if this is a NX-OS switch in ACI fabric mode.
            # ACI devices must be skipped — audit commands would interfere with APIC.

            status = detect_entry.get("status", "unknown")
            # status: "success", "unknown", "unreachable", "error"
            # Only "success" means we can audit this device.

            # ── Skip non-auditable devices ────────────────────────────────────
            if status != "success" or not platform:
                # Skip if:
                #   - Detection never ran for this device (status "unknown")
                #   - Detection failed (status "unreachable" or "error")
                #   - Platform was not identified (platform = None)
                skip_result = AuditDeviceResult(
                    hostname=hostname,
                    ip=ip,
                    platform=platform or "unknown",
                    status=DeviceStatus.SKIPPED,
                    error=f"Skipped: detect status='{status}'",
                )
                results.append(skip_result)
                logger.info("[%s] Skipped (detect status: %s)", hostname, status)
                continue    # Move to next device in inventory loop

            if aci_mode:
                # Skip ACI-mode NX-OS devices.
                # ACI = Application Policy Infrastructure Controller mode.
                # In ACI mode, the Nexus switch is managed entirely by APIC.
                # Running "copy running-config startup-config" on an ACI switch
                # could interfere with the APIC-managed config state.
                skip_result = AuditDeviceResult(
                    hostname=hostname,
                    ip=ip,
                    platform=platform,
                    status=DeviceStatus.SKIPPED,
                    error="Skipped: NX-OS ACI mode (audit not required)",
                )
                results.append(skip_result)
                logger.info("[%s] Skipped (NX-OS ACI mode)", hostname)
                continue

            # ── Submit auditable device to thread pool ────────────────────────
            netmiko_type = _PLATFORM_TO_NETMIKO.get(platform, "autodetect")
            # Look up the Netmiko device_type string for this platform.
            # Fallback "autodetect": Netmiko will try to detect the platform automatically.
            # This shouldn't happen in practice since all 11 platforms are in the mapping,
            # but it's a safe fallback for new platforms not yet added to _PLATFORM_TO_NETMIKO.

            futures[
                pool.submit(
                    audit_device,               # Function to run in each thread
                    hostname=hostname,
                    ip=ip,                      # SSH to IP (not hostname — avoids DNS issues)
                    platform=platform,
                    netmiko_device_type=netmiko_type,
                    username=args.username,
                    password=args.password,
                    artifact_dir=args.artifact_dir,
                    port=args.port,
                    session_max_idle_hours=args.session_max_idle_hours,
                    filesystem_critical_pct=args.filesystem_critical_pct,
                    change=args.change,
                    # change=False (default): read-only audit, diffs recorded as REPORT_ONLY.
                    # change=True: remediation enabled — backup → save → verify on changed devices.
                    # For F5/Citrix HA: change is also forwarded to the driver's save_config()
                    # via auditor.py, which passes it to audit_config() which passes it to
                    # driver.save_config() — HA-aware saves only run when change=True.
                )
            ] = hostname
            # Map Future → hostname so we can identify the device when the future completes.

        # ── Collect results as futures complete ───────────────────────────────
        for future in as_completed(futures):
            # as_completed() yields futures as they finish (order not guaranteed).
            hostname = futures[future]
            try:
                result = future.result()
                # audit_device() NEVER raises (it catches all exceptions internally).
                # future.result() should always return successfully.
                # This try/except is a safety net for truly unexpected exceptions.
            except Exception as exc:
                logger.error("Unexpected error for %s: %s", hostname, exc, exc_info=True)
                # Find the IP from inventory for error reporting.
                inv_entry = next((d for d in inventory if d["hostname"] == hostname), {})
                result = AuditDeviceResult(
                    hostname=hostname,
                    ip=inv_entry.get("ip", hostname),
                    platform="unknown",
                    status=DeviceStatus.ERROR,
                    error=str(exc),
                )
            results.append(result)

    # ── Write artifacts + .tar.gz ─────────────────────────────────────────────
    tar_path = write_audit_results(
        results=results,
        artifact_dir=args.artifact_dir,
        job_id=args.job_id,
    )
    # write_audit_results() writes:
    #   - Per-device JSON files (audit findings)
    #   - Per-device session logs (raw SSH transcript)
    #   - audit_summary.json (aggregate counters)
    #   - Prints human-readable summary to stdout (visible in AWX job output)
    #   - .tar.gz bundle of everything
    logger.info("Audit complete. Artifact: %s", tar_path)
    return 0    # Always 0 — individual device failures are in the results, not fatal


def main() -> None:
    """Entry point called by `python -m network_device_audit.main_audit`."""
    args = parse_args()
    sys.exit(run_audit(args))
    # sys.exit(0) on success, sys.exit(1) only if detect_result.yml is missing.


if __name__ == "__main__":
    main()
    # __name__ == "__main__" guard: allows module import without execution.
    # Called when run as "python -m network_device_audit.main_audit".
