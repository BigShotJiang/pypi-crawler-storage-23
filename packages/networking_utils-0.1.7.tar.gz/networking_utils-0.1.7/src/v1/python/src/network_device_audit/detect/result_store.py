"""
detect/result_store.py — detect_result.yml Persistence

Handles reading and writing of detect_result.yml, which is the handoff
file between detect mode (runs weekly) and audit mode (runs daily).

detect_result.yml structure:
  devices:
    sw-core-01:
      ip: 10.0.0.1
      platform: cisco_ios
      device_type: cisco_ios
      detection_method: netmiko
      aci_mode: false
      status: success
      error: null

Two storage modes are supported, chosen via the detect_result_storage
Ansible playbook variable:

  "repo":  Write the file to the project git repo root, then
           git add + commit + push.  Provides a full version history
           of every detect run (who changed what, when).  Requires
           AWX to have git push access (SSH key or token on the repo).

  "local": Write to /var/lib/awx/detect_results/detect_result.yml on
           the AWX server filesystem.  Simpler — no git credentials
           needed.  The file persists across AWX jobs (not in /tmp).
"""

import logging
import os
import subprocess              # For running git commands
from pathlib import Path
from typing import Optional

import yaml                    # PyYAML: reads/writes YAML files (detect_result.yml)

from ..core.models import DetectDeviceResult

logger = logging.getLogger(__name__)

# Default filesystem path for "local" storage mode.
# /var/lib/awx/ is the standard AWX data directory — persists across job runs.
# /detect_results/ is a subdirectory we create; not part of AWX's own layout.
LOCAL_DEFAULT_PATH = "/var/lib/awx/detect_results/detect_result.yml"


def save_detect_results(
    results: list[DetectDeviceResult],   # All detect results from this run
    storage_mode: str,                   # "repo" or "local"
    repo_path: Optional[str] = None,     # Project repo root (required for "repo" mode)
    local_path: str = LOCAL_DEFAULT_PATH,
    git_user_name: str = "AWX Automation",    # Git commit author name
    git_user_email: str = "awx@automation.local",  # Git commit author email
) -> str:
    """
    Serialize results to detect_result.yml and persist per storage_mode.

    Args:
        results:        List of DetectDeviceResult objects from this detect run.
        storage_mode:   "repo" or "local".
        repo_path:      Absolute path to the project repo root (required for "repo" mode).
        local_path:     File path for "local" mode.
        git_user_name:  Git commit author displayed in git log.
        git_user_email: Git commit author email displayed in git log.

    Returns:
        Absolute path to the written detect_result.yml file.
    """
    # First convert the list of dataclass objects to a plain dict
    # (YAML serialization works on plain dicts/lists, not dataclasses)
    data = _results_to_dict(results)

    if storage_mode == "repo":
        if not repo_path:
            raise ValueError("repo_path must be provided when storage_mode='repo'")
        return _save_to_repo(data, repo_path, git_user_name, git_user_email)
    elif storage_mode == "local":
        return _save_to_local(data, local_path)
    else:
        raise ValueError(f"Unknown detect_result_storage value: '{storage_mode}'")


def load_detect_results(
    storage_mode: str,
    repo_path: Optional[str] = None,
    local_path: str = LOCAL_DEFAULT_PATH,
) -> dict:
    """
    Load detect_result.yml from the configured location.

    Called by main_audit.py at startup.  Audit mode CANNOT proceed without
    this file — it needs the platform type for every device to know which
    driver to instantiate and which Netmiko device_type to pass to ConnectHandler.

    Returns:
        Parsed YAML as a Python dict: {"devices": {"hostname": {...}, ...}}

    Raises:
        DetectResultMissingError: if the file cannot be found or parsed.
        This is a fatal error — audit mode exits with code 1 on this exception.
    """
    # Lazy import to avoid circular import at module-load time.
    # DetectResultMissingError is in core.exceptions; importing at function
    # level means this module doesn't need to import core.exceptions globally.
    from ..core.exceptions import DetectResultMissingError

    if storage_mode == "repo":
        if not repo_path:
            raise ValueError("repo_path must be provided when storage_mode='repo'")
        file_path = os.path.join(repo_path, "detect_result.yml")
        # detect_result.yml lives at the root of the project repo
    else:
        file_path = local_path   # Fixed path on the AWX server

    if not os.path.isfile(file_path):
        raise DetectResultMissingError(
            f"detect_result.yml not found at '{file_path}'. "
            "Run detect mode first."
        )
    try:
        with open(file_path, "r", encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}
            # yaml.safe_load: parses YAML safely (no arbitrary Python object execution)
            # 'or {}': if the file is empty, return an empty dict rather than None
    except Exception as exc:
        raise DetectResultMissingError(
            f"Failed to read detect_result.yml at '{file_path}': {exc}"
        ) from exc


# ── Private helpers ───────────────────────────────────────────────────────────

def _results_to_dict(results: list[DetectDeviceResult]) -> dict:
    """
    Convert a list of DetectDeviceResult dataclasses to a YAML-serializable dict.

    The dict is keyed by hostname so audit mode can do O(1) lookup by hostname
    instead of scanning a list.  The resulting YAML structure is human-readable:
      devices:
        sw-core-01:
          ip: 10.0.0.1
          platform: cisco_ios
          ...
    """
    devices = {}
    for r in results:
        devices[r.hostname] = {
            "ip": r.ip,
            "platform": r.platform,                 # Internal label (e.g. "cisco_iosxe")
            "device_type": r.device_type,           # Netmiko type (e.g. "cisco_xe")
            "detection_method": r.detection_method, # "netmiko", "paramiko", or None
            "aci_mode": r.aci_mode,                 # True if NX-OS in ACI mode
            "status": r.status.value,               # .value: converts Enum to string
            "error": r.error,                       # None for successful detects
        }
    return {"devices": devices}   # Wrapped in "devices" key for YAML readability


def _save_to_local(data: dict, path: str) -> str:
    """Write the data dict to a YAML file at the specified path."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    # Create intermediate directories if they don't exist.
    # E.g. creates /var/lib/awx/detect_results/ on first run.
    with open(path, "w", encoding="utf-8") as fh:
        yaml.dump(data, fh, default_flow_style=False, sort_keys=True)
        # default_flow_style=False: use block-style YAML (human-readable multi-line)
        #   instead of {key: value} inline style.
        # sort_keys=True: alphabetically sort keys for deterministic output.
        #   This makes git diffs clean (only changed entries appear as changed).
    logger.info("detect_result.yml written to %s", path)
    return path


def _save_to_repo(data: dict, repo_path: str, user_name: str, user_email: str) -> str:
    """
    Write detect_result.yml to the repo root and git commit + push.

    WHY git commit from Python?
    AWX projects are git repos.  Committing detect_result.yml back to the
    repo provides:
      - Full history of every weekly detect run
      - Ability to see exactly when a device changed platform or became unreachable
      - The file travels with the playbook code so both are always in sync

    Git author identity is set via environment variables rather than global
    git config to avoid permanently changing the AWX server's git identity.
    """
    file_path = os.path.join(repo_path, "detect_result.yml")
    _save_to_local(data, file_path)   # Write the file first (same logic as local mode)

    # Set git identity for this commit only — use environment variables
    # instead of 'git config' to avoid touching the global/local git config.
    env = os.environ.copy()           # Start from current environment (inherits PATH etc.)
    env["GIT_AUTHOR_NAME"] = user_name
    env["GIT_AUTHOR_EMAIL"] = user_email
    env["GIT_COMMITTER_NAME"] = user_name
    env["GIT_COMMITTER_EMAIL"] = user_email

    def _run(cmd: list[str]) -> str:
        """Run a git command in the repo directory and return stdout."""
        result = subprocess.run(
            cmd,
            cwd=repo_path,              # Run git from the repo root
            env=env,                    # Inject our identity vars
            capture_output=True,        # Capture both stdout and stderr
            text=True,                  # Return strings, not bytes
            check=True,                 # Raise CalledProcessError on non-zero exit
        )
        return result.stdout.strip()

    try:
        _run(["git", "add", "detect_result.yml"])
        # Stage only detect_result.yml — don't accidentally stage other changes
        # that might be in the working tree from a previous failed run.

        _run(["git", "commit", "-m", "chore: update detect_result.yml [AWX automated]"])
        # Commit with a consistent message so these automated commits are
        # easy to identify in git log.  [AWX automated] tag makes filtering simple.

        _run(["git", "push"])
        # Push to the remote (typically origin/main).
        # Requires AWX to have push access — SSH key or token configured in
        # AWX's project credential settings.

        logger.info("detect_result.yml committed and pushed to repo")
    except subprocess.CalledProcessError as exc:
        if "nothing to commit" in (exc.stdout + exc.stderr):
            # Detect results are identical to the previous run — no changes needed.
            # This is common if no devices changed platform since last detect.
            logger.info("detect_result.yml unchanged — no commit needed")
        else:
            # Real git error (push rejected, remote unreachable, permissions denied).
            # Log the git output for debugging and re-raise to fail the detect job.
            logger.error("Git push failed: %s\n%s", exc.stdout, exc.stderr)
            raise

    return file_path
