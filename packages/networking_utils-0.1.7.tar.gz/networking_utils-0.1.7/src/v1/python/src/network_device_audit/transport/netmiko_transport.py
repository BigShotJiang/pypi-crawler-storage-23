# ============================================================
# transport/netmiko_transport.py — Primary SSH Transport
# ============================================================
# NetmikoTransport is the primary SSH transport used for all
# audit operations.  It wraps the Netmiko library which:
#
#   - Knows platform-specific prompt patterns and paging commands
#     (e.g. "terminal length 0" for Cisco, "set cli screen-length 0"
#     for Juniper) so output is never truncated by --More-- prompts.
#   - Handles command echo stripping and trailing prompt removal
#     automatically, returning clean command output.
#   - Supports enable mode (privilege escalation) natively.
#
# This transport is NOT used during detect mode's platform
# fingerprinting — detect uses NetmikoSSHDetect first, and
# ParamikoTransport as a fallback.
# ============================================================

import logging
from typing import Optional

# ConnectHandler: Netmiko's main connection class; dispatches to the right
# platform handler based on device_type.
# NetmikoTimeoutException: raised when SSH times out.
# NetmikoAuthenticationException: raised when credentials are rejected.
from netmiko import ConnectHandler, NetmikoTimeoutException, NetmikoAuthenticationException

from .base import BaseTransport
# Import our project-specific exceptions so we don't expose Netmiko
# internals to callers.  The driver and auditor layers only know about
# DeviceUnreachableError and CommandTimeoutError.
from ..core.exceptions import DeviceUnreachableError, CommandTimeoutError

logger = logging.getLogger(__name__)  # "network_device_audit.transport.netmiko_transport"


class NetmikoTransport(BaseTransport):
    """
    Netmiko-backed SSH transport.

    The caller is responsible for providing the correct `device_type` string
    as understood by Netmiko (e.g. 'cisco_ios', 'juniper_junos', etc.).
    The device_type comes from detect_result.yml (_PLATFORM_TO_NETMIKO map
    in main_audit.py converts platform labels to Netmiko strings).
    """

    def __init__(
        self,
        hostname: str,
        username: str,
        password: str,
        device_type: str,          # Netmiko device_type string (e.g. "cisco_ios", "cisco_xe")
        port: int = 22,
        secret: Optional[str] = None,
        # 'secret' is the enable password for Cisco devices.
        # If None, defaults to the login password (same password policy per design).
        session_timeout: int = 60,
        # How long (seconds) Netmiko waits for the device to send data during a
        # command.  60s is generous but needed for large configs on slow devices.
        conn_timeout: int = 15,
        # How long (seconds) to wait for the initial TCP+SSH handshake to complete.
        # 15s is enough for LAN-reachable devices; increase for WAN with high RTT.
    ):
        super().__init__(hostname, username, password, port)  # Store base attributes
        self.device_type = device_type
        self.secret = secret or password   # Fall back to login password as enable secret
        self.session_timeout = session_timeout
        self.conn_timeout = conn_timeout
        self._connection = None            # Holds the Netmiko ConnectHandler instance after connect()

    def connect(self) -> None:
        # Build the parameter dict Netmiko's ConnectHandler expects.
        # Using a dict (rather than keyword args inline) makes it easy to log
        # or modify before passing.
        params = {
            "device_type": self.device_type,   # Tells Netmiko which platform handler to load
            "host": self.hostname,              # SSH target IP or hostname
            "username": self.username,
            "password": self.password,
            "secret": self.secret,             # Enable password (for Cisco platforms)
            "port": self.port,
            "timeout": self.conn_timeout,      # TCP+SSH connection timeout
            "session_timeout": self.session_timeout,  # Per-command read timeout
            "fast_cli": False,
            # fast_cli=True sends commands without waiting for a prompt pattern.
            # It's faster but less reliable for slow devices.  False is safer
            # for heterogeneous production environments.
        }
        try:
            logger.debug("Connecting to %s via Netmiko (%s)", self.hostname, self.device_type)
            self._connection = ConnectHandler(**params)
            # ConnectHandler opens the TCP connection, completes SSH handshake,
            # waits for the login prompt, sends credentials, and waits for the
            # command prompt.  On success, the device is ready to receive commands.
            self._log(f"[CONNECT] {self.hostname} ({self.device_type})")
            # Record the connection event in the session log for debugging.
        except NetmikoAuthenticationException as exc:
            # Authentication failed — wrong username/password or AAA rejection.
            # Convert to our project exception so callers don't need to import Netmiko.
            raise DeviceUnreachableError(
                f"Authentication failed for {self.hostname}: {exc}"
            ) from exc   # 'from exc' chains the original exception for full traceback
        except (NetmikoTimeoutException, Exception) as exc:
            # TCP timeout, SSH error, or any other connection failure.
            # Catch-all (Exception) handles edge cases like DNS failures, RST packets.
            raise DeviceUnreachableError(
                f"Cannot connect to {self.hostname}: {exc}"
            ) from exc

    def disconnect(self) -> None:
        if self._connection:
            try:
                self._connection.disconnect()
                # Sends the platform-appropriate logout command and closes the TCP socket.
            except Exception:
                pass            # Silently ignore disconnect errors — the session may
                                # already be dead (device rebooted, TCP RST, etc.)
            self._connection = None   # Clear the reference so is_connected() returns False

    def send_command(self, command: str, timeout: int = 30) -> str:
        if not self._connection:
            # Guard: raise a clear error if called without connecting first
            raise DeviceUnreachableError(f"Not connected to {self.hostname}")
        try:
            logger.debug("[%s] >>> %s", self.hostname, command)  # Log command at DEBUG level
            output = self._connection.send_command(
                command,
                read_timeout=timeout,
                # read_timeout overrides session_timeout for this specific command.
                # Callers pass timeout=60 for slow commands (show running-config).
                expect_string=None,
                # expect_string=None tells Netmiko to wait for the command prompt
                # pattern (defined per device_type) rather than a custom string.
                # This is the standard, reliable approach.
            )
            self._log(f">>> {command}\n{output}")  # Record command + response in session log
            return output
        except NetmikoTimeoutException as exc:
            # Command didn't finish within read_timeout seconds.
            raise CommandTimeoutError(
                f"Command timed out on {self.hostname}: {command}"
            ) from exc
        except Exception as exc:
            # Any other Netmiko or socket error during command execution.
            # Wrapped as CommandTimeoutError so BaseDriver's retry logic
            # treats it like a timeout (retry the command, not the connection).
            raise CommandTimeoutError(
                f"Command error on {self.hostname} [{command}]: {exc}"
            ) from exc

    def enter_enable_mode(self) -> None:
        """
        Escalate to privileged EXEC (enable) mode on Cisco platforms.

        Called by auditor.py before running audit commands on devices where
        NEEDS_ENABLE=True (Cisco IOS, IOS-XE, IOS-XR, NX-OS).
        Without enable mode, commands like 'show running-config' may return
        incomplete output or be rejected entirely on these platforms.
        """
        if not self._connection:
            raise DeviceUnreachableError(f"Not connected to {self.hostname}")
        try:
            if not self._connection.check_enable_mode():
                # check_enable_mode() returns True if already in enable mode
                # (prompt ends with '#').  Only send 'enable' if not already there.
                self._connection.enable()
                # enable() sends 'enable', waits for 'Password:', sends self.secret,
                # then waits for the '#' privileged prompt.
                self._log("[ENABLE MODE entered]")
        except Exception as exc:
            # Lazy import to avoid circular import at module load time.
            # EnableModeError is defined in core.exceptions alongside others.
            from ..core.exceptions import EnableModeError
            raise EnableModeError(
                f"Failed to enter enable mode on {self.hostname}: {exc}"
            ) from exc

    def is_connected(self) -> bool:
        # Simple: connected if ConnectHandler instance exists.
        # We don't send a keepalive here — callers check this before sending commands.
        return self._connection is not None
