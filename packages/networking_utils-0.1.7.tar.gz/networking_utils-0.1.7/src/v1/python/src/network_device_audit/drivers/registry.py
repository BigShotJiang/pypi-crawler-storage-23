"""
drivers/registry.py — Platform Driver Registry

Maps the platform label strings (stored in detect_result.yml) to their
concrete driver classes.  This is the single lookup point that connects
the "which platform is this device?" answer (from detect mode) to the
"which class handles this platform's CLI?" question (in audit mode).

HOW IT WORKS:
  1. detect mode writes platform labels (e.g. "cisco_ios") to detect_result.yml
  2. audit mode reads the label for each device
  3. auditor.py calls get_driver_class(platform) → returns e.g. CiscoIOSDriver
  4. auditor.py instantiates: driver = CiscoIOSDriver(transport)
  5. audit runs using driver.get_os_version(), driver.check_filesystem(), etc.

To add a new platform:
  1. Create a new driver class inheriting from BaseDriver in a new subdirectory
  2. Add one import line here
  3. Add one entry to _REGISTRY dict
  No other files need changes.
"""

# ── Import all 11 platform driver classes ─────────────────────────────────────
# Each import makes Python load the driver module and class.
# All drivers are imported at module load time so KeyError happens early
# (at import, not at runtime when a specific device is audited).
from .cisco_ios.driver import CiscoIOSDriver
from .cisco_iosxe.driver import CiscoIOSXEDriver
from .cisco_iosxr.driver import CiscoIOSXRDriver
from .cisco_nxos.driver import CiscoNXOSDriver
from .juniper_junos.driver import JuniperJunOSDriver
from .arista_eos.driver import AristaEOSDriver
from .f5.driver import F5Driver
from .citrix.driver import CitrixDriver
from .dell_os10.driver import DellOS10Driver
from .dell_os9.driver import DellOS9Driver
from .a10.driver import A10Driver
from .base_driver import BaseDriver  # For type annotation in get_driver_class()

# ── Registry dict ─────────────────────────────────────────────────────────────
# Keys: platform label strings — must match exactly what's written to
#       detect_result.yml by the detector and fingerprint modules.
# Values: driver CLASS objects (not instances — instantiated per-device in auditor.py)
#
# type[BaseDriver] annotation: the dict holds class references, not instances.
# This allows auditor.py to do: driver_cls = get_driver_class(platform); driver = driver_cls(transport)
_REGISTRY: dict[str, type[BaseDriver]] = {
    "cisco_ios":     CiscoIOSDriver,     # Cisco IOS (Classic, Catalyst 2k/3k/4k)
    "cisco_iosxe":   CiscoIOSXEDriver,   # Cisco IOS-XE (Catalyst 9k, ASR 1k)
    "cisco_iosxr":   CiscoIOSXRDriver,   # Cisco IOS-XR (ASR 9k, NCS series)
    "cisco_nxos":    CiscoNXOSDriver,    # Cisco NX-OS (Nexus 9k/7k/5k — standalone mode)
    "juniper_junos": JuniperJunOSDriver, # Juniper JunOS (MX, QFX, SRX)
    "arista_eos":    AristaEOSDriver,    # Arista EOS (7000, 7500 series)
    "f5":            F5Driver,           # F5 BIG-IP (LTM appliances and VE)
    "citrix":        CitrixDriver,       # Citrix ADC (NetScaler VPX and SDX)
    "dell_os10":     DellOS10Driver,     # Dell OS10 (S-series, Z-series)
    "dell_os9":      DellOS9Driver,      # Dell OS9/FTOS (older Force10 OS)
    "a10":           A10Driver,          # A10 Networks Thunder (ACOS)
}


def get_driver_class(platform: str) -> type[BaseDriver]:
    """
    Return the driver class for the given platform label.

    Args:
        platform: Platform label string from detect_result.yml
                  (e.g. "cisco_ios", "juniper_junos").

    Returns:
        The driver class (not an instance) for the given platform.

    Raises:
        KeyError: if the platform label is not in the registry.
        This is caught by auditor.py and recorded as an error result
        for the device (prevents a crash from stopping the entire audit).
    """
    return _REGISTRY[platform]


def supported_platforms() -> list[str]:
    """
    Return a list of all registered platform labels.

    Useful for validation (e.g. check if a detect_result.yml platform
    label is known) or for documentation/reporting purposes.
    """
    return list(_REGISTRY.keys())
