"""
detect/detector.py — Main Device Detection Orchestrator

Orchestrates the full detection strategy for a single device:

  Step 1 — Netmiko SSHDetect (primary)
    Netmiko's SSHDetect connects and runs its built-in autodetect
    algorithm, which tries multiple device_type strings, looking for
    distinctive prompt patterns.  This is the fastest and most reliable
    method for well-known Cisco/Juniper/Arista platforms.

  Step 2 — Paramiko + show version (fallback)
    If SSHDetect fails (e.g. unsupported platform, unusual prompt format,
    or timeout during autodetect), we open a raw Paramiko shell and run
    'show version', then fingerprint the output against our rule table.
    This covers F5, Citrix, Dell, A10 and any platform Netmiko doesn't
    handle natively.

  Step 3 — Mark unknown
    If both methods fail, the device is marked DeviceStatus.UNKNOWN.
    Unknown devices are skipped entirely in audit mode.

  ACI check (NX-OS only)
    After identifying a device as NX-OS, we run an additional check to
    determine if it's running in ACI mode (managed by APIC controller).
    ACI-mode devices must be skipped in audit — their configs are managed
    by the fabric, not individually.

detect_device() always returns a DetectDeviceResult and never raises.
All exceptions are caught internally and recorded in the result.
"""

import logging
from typing import Optional, Tuple

# SSHDetect: Netmiko's built-in platform autodetection class.
# It attempts to identify the device by trying known prompt patterns.
from netmiko import SSHDetect
from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException

from ..core.exceptions import DeviceUnreachableError
from ..core.models import DetectDeviceResult, DeviceStatus
from ..core.retry import retry_call          # Retry wrapper for transient failures
from ..transport.paramiko_transport import ParamikoTransport  # Fallback transport
from .aci_detector import is_aci_mode        # NX-OS ACI heuristics
from .fingerprint import fingerprint_show_version, fingerprint_prompt  # Pattern matching

logger = logging.getLogger(__name__)

# Set of Netmiko device_type strings that require enable mode.
# Used in detect to know which platform labels need privilege escalation.
# (Currently informational — detection doesn't enter enable mode itself.)
ENABLE_REQUIRED_TYPES = {"cisco_ios", "cisco_xe", "cisco_xr", "cisco_nxos"}


def detect_device(
    hostname: str,     # Display name from AWX inventory (used in log messages)
    ip: str,           # Actual IP address used for SSH (may differ from hostname)
    username: str,
    password: str,
    port: int = 22,
    conn_timeout: int = 15,
) -> DetectDeviceResult:
    """
    Detect the platform of a single device.

    This is the only public function in this module.  All internal
    steps are handled by private helper functions below.

    Returns a DetectDeviceResult regardless of outcome — never raises.
    Errors are captured in result.error and result.status.
    """
    # Initialize result with UNKNOWN status — updated as detection progresses
    result = DetectDeviceResult(
        hostname=hostname,
        ip=ip,
        device_type=None,       # Will be set to Netmiko type string on success
        platform=None,          # Will be set to our internal label on success
        detection_method=None,  # Will be set to "netmiko" or "paramiko" on success
        status=DeviceStatus.UNKNOWN,
    )

    # ── Step 1: Netmiko SSHDetect ──────────────────────────────────────────
    # ip is used for SSH (not hostname) — avoids DNS lookup failures for devices
    # where the hostname doesn't resolve but the IP is directly reachable.
    netmiko_type, show_version_out = _try_netmiko_detect(
        hostname=ip, username=username, password=password,
        port=port, conn_timeout=conn_timeout,
    )

    if netmiko_type:
        # SSHDetect successfully identified the platform
        platform_label = _netmiko_type_to_label(netmiko_type)
        # Convert Netmiko's internal type string to our canonical label
        # (e.g. "cisco_xe" → "cisco_iosxe", "f5_ltm" → "f5")
        result.device_type = netmiko_type
        result.platform = platform_label
        result.detection_method = "netmiko"
        result.status = DeviceStatus.SUCCESS
        logger.info("[%s] Detected via Netmiko SSHDetect: %s", hostname, netmiko_type)
    else:
        # ── Step 2: Paramiko fallback ──────────────────────────────────────
        # Unpack 5-tuple: (platform_label, netmiko_type, show_version, raw_log, error)
        logger.info("[%s] Netmiko autodetect failed, trying Paramiko fallback", hostname)
        platform_label, netmiko_type, show_version_out, raw_log, err = _try_paramiko_detect(
            hostname=ip, username=username, password=password,
            port=port, conn_timeout=conn_timeout,
        )
        result.raw_log = raw_log   # Save SSH session log even if detection failed

        if netmiko_type:
            # Fingerprinting succeeded
            result.device_type = netmiko_type
            result.platform = platform_label
            result.detection_method = "paramiko"
            result.status = DeviceStatus.SUCCESS
            logger.info("[%s] Detected via Paramiko fingerprint: %s", hostname, netmiko_type)
        elif err and "unreachable" in err.lower():
            # Both Netmiko AND Paramiko failed to connect — device is truly unreachable
            result.status = DeviceStatus.UNREACHABLE
            result.error = err
            logger.warning("[%s] Unreachable: %s", hostname, err)
            return result   # Early return — no point running ACI check on unreachable device
        else:
            # Connected but couldn't identify the platform — mark as unknown
            result.status = DeviceStatus.UNKNOWN
            result.error = err or "Fingerprint did not match any known platform"
            logger.warning("[%s] Platform unknown after all detection methods", hostname)
            return result   # Early return — ACI check only applies to NX-OS

    # ── Step 3: ACI mode check (NX-OS only) ───────────────────────────────
    # We only run this for confirmed NX-OS devices.  Netmiko's SSHDetect
    # identifies these as "cisco_nxos" (the Netmiko device_type string, not
    # our label "cisco_nxos" — they happen to be the same in this case).
    if result.device_type == "cisco_nxos":
        result.aci_mode = _check_aci(
            hostname=ip, username=username, password=password,
            port=port, show_version_out=show_version_out,
        )
        if result.aci_mode:
            logger.info("[%s] NX-OS ACI mode detected — will be skipped in audit", hostname)

    return result


# ── Private helpers ────────────────────────────────────────────────────────────

def _try_netmiko_detect(
    hostname: str, username: str, password: str, port: int, conn_timeout: int
) -> Tuple[Optional[str], str]:
    """
    Attempt Netmiko SSHDetect.

    SSHDetect works by:
      1. Connecting with device_type="autodetect"
      2. Examining the SSH banner and initial prompt
      3. Trying a series of platform-specific prompt patterns
      4. Returning the best-match device_type string

    Returns: (device_type_or_None, show_version_output)
      device_type: Netmiko's canonical string (e.g. "cisco_ios") or None on failure.
      show_version_output: empty string (SSHDetect doesn't run show version).
    """
    params = {
        "device_type": "autodetect",  # Special value that triggers SSHDetect logic
        "host": hostname,
        "username": username,
        "password": password,
        "port": port,
        "timeout": conn_timeout,
    }
    try:
        def _detect():
            # Inner function so retry_call can call it multiple times
            guesser = SSHDetect(**params)
            best_match = guesser.autodetect()
            # autodetect() returns the best-matching device_type string, or None
            return best_match, guesser.potential_matches
            # potential_matches: dict of {device_type: score} — logged for debugging

        device_type, _ = retry_call(
            _detect,
            attempts=3,
            exceptions=(NetmikoTimeoutException, Exception),
            # Retry on timeout (transient network blip) and any other exception.
            # Authentication failures are re-raised immediately (not retried)
            # by the except clause below.
        )
        return device_type, ""
    except (NetmikoAuthenticationException, DeviceUnreachableError):
        # Auth failure or unreachable — re-raise to be caught by detect_device().
        # No point retrying authentication failures (wrong password doesn't fix itself).
        raise
    except Exception as exc:
        # SSHDetect timed out or returned None — this is expected for platforms
        # Netmiko doesn't know about.  Log at DEBUG and return None to trigger fallback.
        logger.debug("Netmiko SSHDetect failed for %s: %s", hostname, exc)
        return None, ""


def _try_paramiko_detect(
    hostname: str, username: str, password: str, port: int, conn_timeout: int
) -> Tuple[Optional[str], Optional[str], str, str, Optional[str]]:
    """
    Attempt Paramiko connection + show version fingerprint.

    Opens a raw interactive SSH shell (no platform knowledge required),
    sends 'show version', and matches the output against our fingerprint rules.

    Returns 5-tuple:
      (platform_label, netmiko_type, show_version_out, raw_log, error_msg)
      - platform_label: None if detection failed
      - netmiko_type:   None if detection failed
      - show_version_out: raw output (for ACI check if NX-OS found)
      - raw_log: full SSH session log for artifact bundle
      - error_msg: failure description, or None on success
    """
    transport = ParamikoTransport(
        hostname=hostname, username=username, password=password,
        port=port, conn_timeout=conn_timeout,
    )
    show_version_out = ""
    try:
        # Connect with retry — 3 attempts with exponential backoff
        retry_call(
            transport.connect,
            attempts=3,
            exceptions=(DeviceUnreachableError,),
        )
    except DeviceUnreachableError as exc:
        # Device truly unreachable — both SSH libraries failed.
        # Prefix with "unreachable:" so detect_device() can distinguish this
        # from a "connected but unknown platform" failure.
        return None, None, "", "", f"unreachable: {exc}"

    try:
        # 'show version' works across all 11 supported platforms (it may have
        # slightly different syntax on some — e.g. Juniper uses 'show version'
        # without arguments, NX-OS uses 'show version' — all return vendor info).
        show_version_out = transport.send_command("show version", timeout=30)
        match = fingerprint_show_version(show_version_out)
        if match:
            platform_label, netmiko_type = match
            return platform_label, netmiko_type, show_version_out, transport.get_session_log(), None
        # Connected and got output but no rule matched — unknown platform
        return None, None, show_version_out, transport.get_session_log(), None
    except Exception as exc:
        # Command failed (timeout or error) after connect succeeded
        return None, None, show_version_out, transport.get_session_log(), str(exc)
    finally:
        transport.disconnect()
        # Always disconnect, regardless of success or exception.
        # 'finally' runs even if an exception is raised in the try block.


def _check_aci(
    hostname: str, username: str, password: str, port: int, show_version_out: str
) -> bool:
    """
    Open a fresh Paramiko connection to run ACI heuristics.

    WHY a new connection instead of reusing the detection connection?
    The Paramiko connection from _try_paramiko_detect was already
    disconnected in its finally block.  A new connection is cleaner than
    trying to pass a potentially-stale connection between functions.

    Returns False on any error — if ACI detection fails, assume standalone NX-OS.
    """
    transport = ParamikoTransport(
        hostname=hostname, username=username, password=password, port=port,
    )
    try:
        transport.connect()
        return is_aci_mode(transport, show_version_output=show_version_out)
        # Pass the already-fetched show version output so is_aci_mode() can
        # check for the 'aci' keyword without making an extra command.
    except Exception as exc:
        logger.debug("ACI check failed for %s: %s", hostname, exc)
        return False    # Conservative: if we can't check, assume not ACI
    finally:
        transport.disconnect()


def _netmiko_type_to_label(netmiko_type: str) -> str:
    """
    Map a Netmiko device_type string to our internal platform label.

    WHY: Netmiko's type strings don't always match our labels.
      "cisco_xe"  → "cisco_iosxe"   (Netmiko abbreviates, we use full name)
      "cisco_xr"  → "cisco_iosxr"
      "f5_ltm"    → "f5"            (Netmiko includes product line, we simplify)
      "dell_ftos" → "dell_os9"      (Netmiko uses old OS name, we use new name)

    Our labels are used as keys in the driver registry and in detect_result.yml.
    Unknown types are returned as-is (pass-through).
    """
    mapping = {
        "cisco_ios":     "cisco_ios",
        "cisco_xe":      "cisco_iosxe",   # IOS-XE
        "cisco_xr":      "cisco_iosxr",   # IOS-XR
        "cisco_nxos":    "cisco_nxos",
        "juniper_junos": "juniper_junos",
        "arista_eos":    "arista_eos",
        "f5_ltm":        "f5",
        "dell_os10":     "dell_os10",
        "dell_ftos":     "dell_os9",      # FTOS is Dell's old name for OS9
    }
    return mapping.get(netmiko_type, netmiko_type)
    # Falls back to netmiko_type if not in mapping — safer than KeyError
