# ============================================================
# core/exceptions.py — Custom Exception Hierarchy
# ============================================================
# All project-specific exceptions are defined here in one place.
# Using named exceptions (rather than raising generic Exception)
# lets callers catch exactly the failure category they care about
# without accidentally swallowing unrelated errors.
#
# None of these inherit from each other intentionally — each
# represents a distinct failure mode that callers handle differently
# (retry, skip device, log warning, fatal exit, etc.).
# ============================================================


class DeviceUnreachableError(Exception):
    """
    Raised when an SSH connection to a device fails after all retry attempts.

    Thrown by NetmikoTransport.connect() and ParamikoTransport.connect()
    when the connection cannot be established (auth failure, timeout,
    host unreachable).

    The retry layer (retry_call) catches this on each attempt and re-raises
    once all attempts are exhausted.  The detect and audit orchestrators
    catch it at the top level to mark the device as DeviceStatus.UNREACHABLE
    in results, then continue to the next device.

    Typical causes: host unreachable due to routing/firewall, SSH port closed,
    TCP RST from device, authentication failure.
    """


class CommandTimeoutError(Exception):
    """
    Raised when a CLI command sent to a connected device does not return
    output within the configured timeout, after all retry attempts.

    Thrown by NetmikoTransport.send_command() (wraps NetmikoTimeoutException)
    and ParamikoTransport.send_command() (wraps socket.timeout).

    BaseDriver wraps every _check_* method call in retry_call with this
    exception type.  If the command still fails after 3 retries, non-critical
    checks (filesystem, fans) return a SKIPPED/NA result instead of aborting
    the session.  Config commands (get_running_config, save_config) will
    propagate the error as a REMEDIATION_FAILED or ERROR device status.

    Typical causes: device is slow to respond (large config), paging not
    suppressed, command hung waiting for an external resource.
    """


class DetectionFailedError(Exception):
    """
    Raised when both Netmiko SSHDetect and the Paramiko fingerprint
    fallback fail to identify the platform of a device.

    In practice, detector.py catches this internally and converts it to a
    DeviceStatus.UNKNOWN result rather than propagating it to callers.
    Detect mode never raises this exception outside the detector module.
    """


class DetectResultMissingError(Exception):
    """
    Raised by result_store.load_detect_results() when detect_result.yml
    cannot be found at the expected location, or the file cannot be parsed.

    Audit mode treats this as a fatal error: it cannot run without knowing
    each device's platform type.  main_audit.py catches this exception,
    prints a clear error message to stderr, and exits with code 1.

    Common causes:
      - Audit mode run before detect mode has ever been run
      - detect_result_storage mismatch (detect wrote to 'local' but audit
        is reading from 'repo', or vice versa)
      - git push failed in the previous detect run (storage=repo mode)
      - File was manually deleted or moved
    """


class EnableModeError(Exception):
    """
    Raised when entering Cisco enable mode (privileged EXEC) fails.

    Thrown by NetmikoTransport.enter_enable_mode() when:
      - The enable password is incorrect
      - The device rejects privilege escalation
      - A timeout occurs waiting for the enable prompt

    In audit mode, auditor.py catches this as a warning and continues
    without enable mode.  Some commands may return restricted output
    but the session is not aborted — other checks still run.
    """


class ConfigSaveError(Exception):
    """
    Raised when a config save command (write memory / commit / save ns config)
    raises an exception other than CommandTimeoutError.

    Defined for completeness and future use.  config_audit.py currently
    wraps save_config() in a broad except block that handles both this and
    generic exceptions, returning ConfigStatus.REMEDIATION_FAILED with the
    error captured in ConfigResult.error.
    """


class RemediationVerificationError(Exception):
    """
    Raised conceptually when post-save verification fails — i.e., after
    saving the running config to startup, a re-diff still shows differences.

    In practice, config_audit.py detects this condition directly (without
    raising this exception) by re-running configs_differ() after save and
    returning ConfigStatus.REMEDIATION_FAILED if the diff is still non-empty.
    This class is defined for future use in case the flow is refactored to
    use exception-based control flow.
    """


class HAAutoSyncAnomalyError(Exception):
    """
    Raised by F5Driver._save_config() and CitrixDriver._save_config() when
    the HA group / HA pair is out of sync despite auto-sync being enabled.

    This condition means the HA platform's own synchronisation mechanism has
    already failed or is actively failing — there is a production issue that
    auto-sync should have resolved but didn't.  Attempting a manual save in
    this state would be unsafe (the two sides disagree on config and we don't
    know which side is authoritative).

    config_audit.py catches this exception specifically and records
    ConfigStatus.HA_SYNC_ANOMALY in the result rather than treating it as
    a generic REMEDIATION_FAILED.  Operators are expected to investigate
    the HA sync issue manually.

    Typical causes:
      - F5 DSC replication failure (network split, certificate mismatch)
      - Citrix HA synchronisation disabled or broken
      - Clock skew or connectivity issues between HA peers
    """
