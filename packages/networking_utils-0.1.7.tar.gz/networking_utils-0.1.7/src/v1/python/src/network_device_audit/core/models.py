# ============================================================
# core/models.py — Shared Data Models
# ============================================================
# All dataclasses and enums used throughout the project are
# defined here in one place.  Keeping them in a single module
# avoids circular imports and gives a single source of truth
# for every data structure passed between layers.
# ============================================================

from dataclasses import dataclass, field  # dataclass: auto-generates __init__, __repr__, etc.
                                           # field: lets us specify default_factory for mutable defaults
from typing import Optional                # Optional[T] means the value can be T or None
from enum import Enum                      # Enum: creates a closed set of named constants


# ── DeviceStatus ──────────────────────────────────────────────────────────────
# Top-level outcome of trying to detect or audit a single device.
# Using str+Enum means the value serializes directly to its string label
# (e.g. DeviceStatus.SUCCESS serializes as "success" in JSON/YAML), which
# avoids a manual .value call every time we write output.
class DeviceStatus(str, Enum):
    SUCCESS     = "success"      # Device was reached and processed without errors
    UNREACHABLE = "unreachable"  # SSH connection failed after all retries
    UNKNOWN     = "unknown"      # Platform could not be identified (detect mode)
    SKIPPED     = "skipped"      # Device was intentionally not processed
                                 # (e.g. ACI mode NX-OS, or unknown detect status)
    ERROR       = "error"        # An unexpected exception occurred during processing


# ── FanStatus ─────────────────────────────────────────────────────────────────
# Result of a single fan check on a device.
# PASS: fan is spinning normally (OK/Normal/Good/Spinning keywords)
# FAIL: fan is absent, failed, or in an error state
# NA:   the platform does not expose fan status via CLI (virtual appliances,
#       some software-only platforms), or the command is not supported
class FanStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    NA   = "n/a"


# ── FilesystemStatus ──────────────────────────────────────────────────────────
# Result of the filesystem usage check.
# OK:       usage is below the 70% critical threshold
# CRITICAL: usage is above 70% — requires attention
# SKIPPED:  the filesystem path does not exist on this device, or the
#           check command failed/timed out after retries
class FilesystemStatus(str, Enum):
    OK       = "ok"
    CRITICAL = "critical"
    SKIPPED  = "skipped"


# ── ConfigStatus ──────────────────────────────────────────────────────────────
# Outcome of the running-vs-startup config audit for a single device.
# COMPLIANT:          running config == startup config (nothing to do)
# REPORT_ONLY:        configs differed but --change flag was False; diff is
#                     recorded and reported but NO backup or save is performed.
#                     This is the default (safe, read-only) mode.
# REMEDIATED:         configs differed; backup taken, saved, and verified clean
#                     Only possible when --change=True.
# REMEDIATION_FAILED: save was attempted but post-save diff was still dirty,
#                     OR the save command itself raised an exception
# SAVE_SKIPPED:       configs differed but save was skipped because at least one
#                     active SSH session had been idle < session_max_idle_hours
#                     (another admin might be actively working; unsafe to save)
# HA_SYNC_ANOMALY:    F5/Citrix HA pair: auto-sync is configured but the group
#                     is still out of sync — production issue, no save attempted.
#                     Requires manual operator investigation.
# ERROR:              an exception prevented the config audit from completing
class ConfigStatus(str, Enum):
    COMPLIANT          = "compliant"
    REPORT_ONLY        = "report_only"
    REMEDIATED         = "remediated"
    REMEDIATION_FAILED = "remediation_failed"
    SAVE_SKIPPED       = "save_skipped"
    HA_SYNC_ANOMALY    = "ha_sync_anomaly"
    ERROR              = "error"


# ── SessionInfo ───────────────────────────────────────────────────────────────
# Represents a single active SSH/CLI session on a device as seen by the
# platform's session-listing command (show users / show system users / who).
# idle_hours is the key field: config_audit compares it against
# session_max_idle_hours (configurable, default 12.0) to decide whether to
# skip the config save.
@dataclass
class SessionInfo:
    user: str         # Login username (e.g. "admin", "ops")
    line: str         # Terminal line identifier (e.g. "vty 0", "pts/0")
    idle_hours: float # Hours since last activity.  0.0 means actively typing now.
                      # If parsing fails, drivers default to 0.0 (conservative:
                      # treat unknown idle time as "very recent → skip save").


# ── FanResult ─────────────────────────────────────────────────────────────────
# Result for a single fan within a device's chassis.
# Devices can have multiple fans so audit results carry a list of FanResult.
@dataclass
class FanResult:
    fan_id: str       # Platform-specific fan identifier (e.g. "Fan 1", "Fan 1/2")
    status: FanStatus # PASS, FAIL, or NA


# ── FilesystemResult ──────────────────────────────────────────────────────────
# Result of the filesystem usage check for one device.
# path reflects the actual path checked (flash: for IOS, /var for Linux-based
# platforms, disk0: for IOS-XE, etc.) — NOT always literally "/var".
@dataclass
class FilesystemResult:
    path: str                    # Actual filesystem path checked (e.g. "flash:", "/var")
    usage_pct: Optional[float]   # Percentage used (0–100).  None if check was skipped
                                 # or the command output could not be parsed.
    status: FilesystemStatus     # OK, CRITICAL, or SKIPPED


# ── ConfigResult ──────────────────────────────────────────────────────────────
# Full outcome of the running-vs-startup config audit for one device.
# backup_path is set only when a backup was taken before saving.
# diff_before shows what differed BEFORE remediation.
# diff_after shows any residual diff AFTER saving (should be empty on success).
# error carries a human-readable message for SAVE_SKIPPED and failure states.
@dataclass
class ConfigResult:
    status: ConfigStatus
    backup_path: Optional[str] = None   # Absolute path to the pre-save backup file
    diff_before: Optional[str] = None   # Unified diff: startup→running (before save)
    diff_after: Optional[str]  = None   # Unified diff after save (non-None = still dirty)
    error: Optional[str]       = None   # Reason for skip/failure (shown in report)


# ── DetectDeviceResult ────────────────────────────────────────────────────────
# Output of the detect mode for a single device.
# Serialized to detect_result.yml (keyed by hostname) after detect mode runs.
# Audit mode reads this file to know each device's platform before connecting.
@dataclass
class DetectDeviceResult:
    hostname: str                       # Device hostname (as in AWX inventory)
    ip: str                             # IP address used for SSH
    device_type: Optional[str]          # Netmiko device_type string (e.g. "cisco_ios")
                                        # None if detection failed
    platform: Optional[str]            # Human-readable label (e.g. "cisco_ios")
                                        # Used as the key into the driver registry
    detection_method: Optional[str]    # "netmiko" (SSHDetect) or "paramiko" (fallback)
                                        # None if detection failed
    aci_mode: bool = False              # True if NX-OS device is running in ACI mode
                                        # (managed by APIC; audit should be skipped)
    status: DeviceStatus = DeviceStatus.UNKNOWN  # Default to UNKNOWN until updated
    error: Optional[str] = None         # Error message if unreachable/unknown
    raw_log: str = ""                   # Raw SSH session log (commands + responses)


# ── AuditDeviceResult ─────────────────────────────────────────────────────────
# Full audit output for a single device.
# Serialized to per-device JSON files in the artifact bundle.
# All Optional fields are None when the audit was skipped or failed before
# that check could be reached.
@dataclass
class AuditDeviceResult:
    hostname: str                                # Device hostname
    ip: str                                      # IP address
    platform: str                                # Platform label (e.g. "cisco_iosxe")
    status: DeviceStatus                         # Overall outcome for this device
    os_version: Optional[str] = None            # Collected OS version string
    filesystem: Optional[FilesystemResult] = None  # Storage usage result
    fans: list[FanResult] = field(default_factory=list)  # Per-fan results
                                                 # field(default_factory=list) creates a new
                                                 # empty list for each instance — avoids the
                                                 # mutable default argument Python pitfall
    config: Optional[ConfigResult] = None       # Config diff/save result
    config_saved: bool = False                   # True if running config was saved to startup
    config_save_skipped: bool = False            # True if save was skipped (active session)
    config_report_only: bool = False             # True if diff was found but --change=False
                                                 # (report-only mode, no backup or save)
    error: Optional[str] = None                  # Error message if the device failed
    raw_log: str = ""                            # Raw SSH session log for debugging

    # ── HA fields (F5 / Citrix only) ──────────────────────────────────────────
    # All None for non-HA platforms. Populated by auditor.py from driver.get_ha_info()
    # after the config audit completes on the active node.
    ha_group: Optional[str] = None
    # F5: device group name (e.g. "/Common/failover-group").
    # Citrix: set to "ha_pair" as a marker that HA was detected.
    # None for standalone devices and all non-F5/Citrix platforms.

    ha_peer_ip: Optional[str] = None
    # Citrix only: management IP of the secondary (standby) node.
    # F5 uses ha_members list instead (can have >2 members).

    ha_members: Optional[list] = None
    # F5 only: list of dicts, one per device-group member.
    # Each dict: {"hostname": str, "management_ip": str, "sync_status": str}
    # Example: [{"hostname": "bigip1.example.com", "management_ip": "10.0.0.1",
    #             "sync_status": "In Sync"}]

    ha_auto_sync: Optional[bool] = None
    # True if the HA group/pair has auto-sync configured.
    # F5: from "auto-sync enabled" in tmsh list cm device-group output.
    # Citrix: from "Sync State: ENABLED" in show ha node output.

    ha_sync_enforced: Optional[bool] = None
    # True if a manual sync command was issued (because auto-sync was off
    # and the group was out of sync).
    # F5: "run cm config-sync to-group <group>".
    # Citrix: "sync ha files" or equivalent push command.
    # False if group was already in sync (no sync command needed).
    # None if HA was not detected.

    ha_anomaly: Optional[bool] = None
    # True if auto-sync was enabled but the group was still out of sync.
    # This indicates a production issue — auto-sync should have handled it.
    # In anomaly mode, NO save is attempted. Operators must investigate.

    ha_config_saved_members: Optional[list] = None
    # List of member hostnames where "save sys config" / "save ns config"
    # succeeded. On full success equals all ha_members hostnames.
    # Shorter list indicates partial failures (some members couldn't be saved).


# ── DetectSummary ─────────────────────────────────────────────────────────────
# Aggregate counters for a detect mode run.
# Written to detect_summary.json in the artifact bundle and printed to stdout.
@dataclass
class DetectSummary:
    total: int        # Total devices processed
    identified: int   # Devices successfully identified (DeviceStatus.SUCCESS)
    unknown: int      # Devices where platform could not be determined
    unreachable: int  # Devices that could not be reached via SSH
    aci_mode: int     # NX-OS devices found to be in ACI mode


# ── AuditSummary ──────────────────────────────────────────────────────────────
# Aggregate counters for an audit mode run.
# Written to audit_summary.json and printed to stdout as the AUDIT SUMMARY block.
@dataclass
class AuditSummary:
    total: int               # Total devices in inventory
    success: int             # Devices fully audited without error
    unreachable: int         # Devices that could not be reached via SSH
    skipped: int             # Devices skipped (unknown platform, ACI mode, HA standby)
    error: int               # Devices that errored during audit
    config_saved: int        # Devices where running config was saved to startup
                             # (only non-zero when --change=True)
    config_save_skipped: int # Devices with unsaved changes where save was skipped
                             # due to an active session within session_max_idle_hours
    config_report_only: int  # Devices with unsaved changes found in report-only mode
                             # (--change=False, the default). Diff is recorded but
                             # no backup or save is performed.
    filesystem_critical: int # Devices with filesystem usage above filesystem_critical_pct
    fan_failures: int        # Devices with at least one fan in FAIL state
