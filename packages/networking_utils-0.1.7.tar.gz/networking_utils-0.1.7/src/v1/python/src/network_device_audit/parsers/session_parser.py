"""
parsers/session_parser.py — SSH Session Output Parsers

This module provides two functions for parsing SSH session output into
idle/age hours for active session detection:

  parse_hhmm_ss():
    Used by platforms where "show users" (or equivalent) reports IDLE DURATION.
    Platforms: Cisco IOS, IOS-XE, IOS-XR, NX-OS, Arista EOS, Dell OS10,
               Dell OS9/FTOS, A10 Networks, Juniper JunOS (partial).
    Input formats: "00:05:23", "2d03h", "1w2d", "14" (minutes), "MM:SS"

  session_age_from_login_time():
    Used by platforms where the session command reports LOGIN TIME (absolute timestamp).
    Platforms: F5 BIG-IP (Linux "who" command), Citrix ADC (FreeBSD "who" command).
    Input formats: "Oct 19 14:23", "2024-10-19 14:23", "2:00PM"

WHY TWO DIFFERENT APPROACHES?
  - Cisco/Dell/A10: "show users" reports how long the session has been IDLE.
    Idle time is directly what we need for the "< 12 hours" check.
  - F5/Citrix: use the Linux/FreeBSD "who" command which reports LOGIN TIME.
    We compute age = (current_time - login_time). Age is the upper bound of idle time.
    (A session logged in 1 hour ago has been idle for at most 1 hour.)
"""

import re
from datetime import datetime, timezone
from typing import Optional


def parse_hhmm_ss(time_str: str) -> Optional[float]:
    """
    Parse HH:MM:SS or H:MM:SS idle time strings into hours.
    Also handles Cisco shorthand like '2d03h', '00:05:23', '1w2d'.
    Returns None if unparseable.

    Handles all Cisco/Dell/A10 idle time formats:
      "1w2d"     → weeks+days shorthand (1 week 2 days = 1*168 + 2*24 = 216h)
      "2d03h"    → days+hours shorthand (2 days 3 hours = 2*24 + 3 = 51h)
      "2d"       → days only shorthand (2 days = 48h)
      "00:05:23" → HH:MM:SS (0 hours 5 minutes 23 seconds = 0.089h)
      "5:23"     → MM:SS (5 minutes 23 seconds = 0.090h)
      "14"       → plain integer = minutes (Juniper: "14" means 14 minutes = 0.233h)

    Returns:
        float: hours as a decimal (e.g. 0.089 for 5 minutes 23 seconds)
        None:  if the format is not recognized — caller should use safe default 0.0
    """
    time_str = time_str.strip()
    # Strip whitespace first — some platforms include trailing spaces in output.

    # ── Pattern 1: Weeks+days shorthand: "1w2d" ──────────────────────────────
    m = re.match(r"(\d+)w(\d+)d", time_str)
    # Matches: "1w2d" (1 week, 2 days), "2w1d" (2 weeks, 1 day), etc.
    # Cisco IOS uses this for very old idle sessions (e.g., VTY line opened weeks ago).
    if m:
        return int(m.group(1)) * 168 + int(m.group(2)) * 24
        # 1 week = 7 days = 168 hours; 1 day = 24 hours.
        # Example: "1w2d" → 1*168 + 2*24 = 216.0 hours

    # ── Pattern 2: Days+hours shorthand: "2d03h" or "2d" ────────────────────
    m = re.match(r"(\d+)d(\d+)?h?", time_str)
    # Matches:
    #   "2d03h" → 2 days, 3 hours (group(2) = "03")
    #   "2d"    → 2 days, 0 hours (group(2) = None — the (\d+)? is optional)
    # The h? at the end makes the "h" suffix optional (some platforms omit it).
    if m:
        days = int(m.group(1))
        hours = int(m.group(2)) if m.group(2) else 0  # Default 0 hours if not present
        return days * 24 + hours
        # Example: "2d03h" → 2*24 + 3 = 51.0 hours

    # ── Pattern 3: HH:MM:SS format: "00:05:23" ───────────────────────────────
    m = re.match(r"(\d+):(\d{2}):(\d{2})", time_str)
    # Matches exactly 3 groups of digits separated by colons.
    # \d{2}: exactly 2 digits for minutes and seconds (MM and SS fields).
    # \d+:   1 or more digits for hours (e.g. "0", "00", "100" all valid).
    if m:
        return int(m.group(1)) + int(m.group(2)) / 60 + int(m.group(3)) / 3600
        # Convert: hours + (minutes / 60) + (seconds / 3600)
        # Example: "00:05:23" → 0 + 5/60 + 23/3600 = 0.0897h

    # ── Pattern 4: MM:SS format: "5:23" ──────────────────────────────────────
    m = re.match(r"(\d+):(\d{2})$", time_str)
    # Matches exactly 2 groups: minutes and seconds (no hours group).
    # $ anchor ensures we don't match the HH:MM part of "HH:MM:SS" (pattern 3 takes those).
    if m:
        return int(m.group(1)) / 60 + int(m.group(2)) / 3600
        # Convert: minutes/60 + seconds/3600
        # Example: "5:23" → 5/60 + 23/3600 = 0.0897h

    # ── Pattern 5: Plain integer minutes: "14" ───────────────────────────────
    m = re.match(r"^(\d+)$", time_str)
    # Matches a string that is ONLY digits (no colons, letters, or other characters).
    # ^ and $ anchors: ensures the entire string is digits (not a substring match).
    # WHY? Juniper JunOS "show system users" shows IDLE as a plain integer (minutes).
    if m:
        return int(m.group(1)) / 60
        # Convert minutes to hours: 14 minutes → 14/60 = 0.233 hours.

    # ── No pattern matched ────────────────────────────────────────────────────
    return None
    # Caller should use default of 0.0 (conservative = treat as active).


def session_age_from_login_time(login_str: str) -> Optional[float]:
    """
    Compute session age in hours from a login timestamp string.
    Handles formats like:
      - "Oct 19 14:23"   (no year — assumes current year)
      - "2024-10-19 14:23:00"
      - "Mon Oct 19 14:23:00 2024"
    Returns None if unparseable.

    Used by F5 (Linux "who") and Citrix (FreeBSD "who") drivers which report
    login time (when the session was established), not idle duration.

    We compute age = (now_UTC - login_time) in hours.
    This is used as a proxy for idle time: a session that logged in 2 hours ago
    has been idle for at most 2 hours.

    Year handling:
      Many formats don't include the year. We assume the current year,
      then check if the resulting datetime is in the future. If so, it
      must be from last year (e.g., "Dec 31" checked on "Jan 1" = last year).
    """
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    # now: current UTC time WITHOUT timezone info (naive datetime).
    # We use UTC for consistency regardless of AWX server timezone.
    # .replace(tzinfo=None): makes it a "naive" datetime for comparison
    # with the parsed login times (which are also naive — no timezone).

    formats = [
        "%b %d %H:%M",          # Oct 19 14:23 — FreeBSD "who" (month day time)
        "%b %d %H:%M:%S",       # Oct 19 14:23:00 — FreeBSD "who" with seconds
        "%Y-%m-%d %H:%M:%S",    # 2024-10-19 14:23:00 — Linux "who" ISO format
        "%a %b %d %H:%M:%S %Y", # Mon Oct 19 14:23:00 2024 — long format with weekday+year
        "%H:%M",                 # 14:23 — same-day login (time only, no date)
        "%I:%M%p",               # 2:00PM — 12-hour format (Juniper JunOS login time)
    ]
    # WHY try multiple formats (not just one)?
    # "who" output format varies between Linux (F5) and FreeBSD (Citrix):
    #   Linux "who" (F5):      "2024-10-19 14:23" (ISO date)
    #   FreeBSD "who" (Citrix): "Oct 19 14:23" (abbreviated month)
    # We try all formats and return the first one that parses successfully.

    for fmt in formats:
        try:
            dt = datetime.strptime(login_str.strip(), fmt)
            # strptime: parses the string into a datetime object using the format template.
            # Raises ValueError if the format doesn't match — caught below.

            if dt.year == 1900:
                # strptime defaults to year 1900 when no year is in the format string.
                # Replace with current year for formats that don't include a year.
                dt = dt.replace(year=now.year)

            # If parsed date is in the future, it's last year
            # Example: today is January 5, 2025. Login was "Dec 31 23:59".
            # Parsed as Dec 31, 2025 (future) → must be Dec 31, 2024 (last year).
            if dt > now:
                dt = dt.replace(year=now.year - 1)

            delta = now - dt
            # delta = timedelta representing how long ago the user logged in.
            return delta.total_seconds() / 3600
            # Convert to hours: total_seconds() / 3600
            # Example: logged in 2.5 hours ago → 9000 seconds / 3600 = 2.5 hours

        except ValueError:
            # This format didn't match — try the next one.
            continue

    # ── No format matched ─────────────────────────────────────────────────────
    return None
    # Caller should use default of 0.0 (conservative = treat as active).
