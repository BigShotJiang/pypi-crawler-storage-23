# ============================================================
# core/logger.py — Logging Configuration
# ============================================================
# Sets up two tiers of logging:
#
#   1. Root logger (setup_logging): captures all log output
#      from every module and writes to both stdout (visible in
#      AWX job output) and a per-job file (job_id.log in artifact_dir).
#
#   2. Per-device logger (get_device_logger): a child logger
#      that also writes raw session output (commands + device
#      responses) to a per-device file for debugging.
#
# Both loggers are standard Python logging objects — any module
# that calls logging.getLogger(__name__) will automatically
# inherit the root handler configuration.
# ============================================================

import logging                     # Python standard logging framework
import logging.handlers            # RotatingFileHandler etc. (imported for potential future use)
import os                          # os.path.join for building file paths
from pathlib import Path           # Path.mkdir for creating log directories


def setup_logging(
    log_dir: str,                  # Directory where the per-job log file will be created
    job_id: str,                   # Used to name the log file (e.g. "12345.log")
    level: int = logging.INFO,     # Minimum severity to record; INFO shows normal flow,
                                   # DEBUG would also show raw SSH command/response pairs
) -> logging.Logger:
    """
    Configure root logger to write to both stdout and a per-job log file.

    Called once at the start of main_detect.py and main_audit.py.
    After this call, any module that does logging.getLogger(__name__)
    will automatically write to both outputs.

    Args:
        log_dir:  Directory where log files are written (usually artifact_dir).
        job_id:   Unique job identifier used in the log filename.
        level:    Logging level (default INFO).

    Returns:
        Configured root logger.
    """
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    # Create the log directory if it doesn't exist.
    # parents=True: create all intermediate directories as needed.
    # exist_ok=True: don't raise an error if the directory already exists.

    log_path = os.path.join(log_dir, f"{job_id}.log")
    # Full path for the per-job log file.
    # Example: /runner/artifacts/12345/12345.log
    # This file is included in the downloadable .tar.gz artifact.

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        # %(asctime)s   — timestamp (formatted by datefmt below)
        # [%(levelname)s] — severity level: INFO, WARNING, ERROR, etc.
        # %(name)s      — logger name (module path, e.g. "network_device_audit.detect.detector")
        # %(message)s   — the actual log message
        datefmt="%Y-%m-%dT%H:%M:%S",
        # ISO 8601 format makes log timestamps easy to parse and correlate
        # across distributed systems.  Example: "2024-10-19T08:30:12"
    )

    root = logging.getLogger()   # Get the root logger (parent of ALL loggers in the process)
    root.setLevel(level)         # Set the minimum level — messages below this are discarded
                                 # before reaching any handler

    # ── Handler 1: stdout ─────────────────────────────────────────────────
    # Makes log messages visible in the AWX job output tab in real time.
    # This is what operators see when watching a running job.
    sh = logging.StreamHandler()  # StreamHandler defaults to sys.stderr; we leave it as-is
                                  # (AWX captures both stdout and stderr in the job output)
    sh.setFormatter(fmt)          # Apply our timestamp+level+name format
    root.addHandler(sh)           # Attach to root so all module loggers write here

    # ── Handler 2: file ───────────────────────────────────────────────────
    # Writes to a file that persists after the job completes.
    # The file is bundled into the .tar.gz artifact by reporter.py.
    fh = logging.FileHandler(log_path, encoding="utf-8")
    # encoding="utf-8" ensures non-ASCII device output (banners, hostnames) is
    # stored correctly without UnicodeEncodeError on non-UTF-8 systems.
    fh.setFormatter(fmt)          # Same format as stdout for consistency
    root.addHandler(fh)           # Attach to root logger

    return root                   # Return the configured root logger (rarely used by callers,
                                  # but useful for testing to inspect handlers)


def get_device_logger(hostname: str, log_dir: str) -> logging.Logger:
    """
    Return a child logger that also writes raw session output to a per-device
    file at <log_dir>/<hostname>_session.log.

    WHY: The root logger captures structured log messages (INFO, WARNING, ERROR).
    Device session logs need a separate, low-level record of every command sent
    and every response received during the SSH session.  These are invaluable
    for debugging why a regex failed to parse output on a specific device.

    The returned logger is a child of the root logger (named "device.<hostname>"),
    so its messages propagate up to the root handlers (stdout + job log file)
    in addition to the per-device file.
    """
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    session_path = os.path.join(log_dir, f"{hostname}_session.log")
    # Per-device file: e.g. /runner/artifacts/12345/sw-core-01_session.log

    device_logger = logging.getLogger(f"device.{hostname}")
    # Child logger under the "device" namespace.
    # Naming pattern "device.sw-core-01" groups all device loggers together
    # and allows future filtering (e.g. only show device-level logs).
    device_logger.setLevel(logging.DEBUG)
    # DEBUG captures everything including raw command/response pairs logged
    # by the transport layer.  The root logger's level still filters what
    # propagates to stdout/job log.

    # ── Guard against duplicate handlers ──────────────────────────────────
    # If get_device_logger is called multiple times for the same hostname
    # (e.g. in tests or if a device appears in multiple inventory groups),
    # adding a second handler would cause duplicate log entries.
    # This check ensures the file handler is only added once.
    if not any(
        isinstance(h, logging.FileHandler) and h.baseFilename == session_path
        for h in device_logger.handlers
        # Iterate existing handlers; only add a new one if none already
        # points to this specific session log file path.
    ):
        fh = logging.FileHandler(session_path, encoding="utf-8")
        fh.setFormatter(
            logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S")
            # Lighter format for session logs — just timestamp + message.
            # No level/name prefix needed since all entries in a session log
            # are from the same device's SSH session.
            # Example line: "08:30:12 >>> show version\nCisco IOS Software..."
        )
        device_logger.addHandler(fh)

    return device_logger
