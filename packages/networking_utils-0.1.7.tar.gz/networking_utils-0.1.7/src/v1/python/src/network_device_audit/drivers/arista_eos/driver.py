# ============================================================
# drivers/arista_eos/driver.py — Arista EOS Driver
# ============================================================
# Covers: Arista 7000 series, 7500 series (data center switches).
#
# Arista EOS (Extensible Operating System) is Linux-based.
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     EOS puts users directly into a privileged shell by default.
#   - Filesystem: Linux-based; checks /var/log specifically
#     WHY /var/log instead of /var?
#     On Arista EOS, /var/log is the filesystem that fills up during
#     normal operation (event logs, debug logs). The "bash" prefix is
#     required to run Linux shell commands within the EOS CLI.
#   - Config save: "copy running-config startup-config" (not "write memory")
#   - Sessions: "show users" with Username/TTY/Idle/Time/Host columns
#   - EOS supports both CLI and eAPI (REST API) modes; we use CLI only
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class AristaEOSDriver(BaseDriver):
    PLATFORM = "arista_eos"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False       # EOS: privileged mode is the default on login

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # EOS version line: "EOS version 4.28.3M"
        # Pattern searches for "EOS version" followed by the version string.
        # Version format: major.minor.patch+release (e.g. "4.28.3M" where M = maintenance)
        m = re.search(r"EOS\s+version\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("bash df -h /var/log 2>/dev/null || echo 'not found'")
        # COMMAND EXPLANATION:
        # "bash" prefix: required on EOS to run standard Linux shell commands.
        # EOS CLI is a custom shell; "bash" drops into the underlying Linux bash.
        #
        # "df -h /var/log": standard POSIX df showing /var/log filesystem usage.
        # -h = human-readable sizes.
        #
        # "2>/dev/null": suppresses error messages if /var/log doesn't exist as a mount.
        # "|| echo 'not found'": if df fails (non-zero exit), print "not found" instead
        # of showing an error — allows us to detect failure gracefully.
        #
        # WHY /var/log (not /var)?
        # On Arista EOS, /var/log is the partition that fills up during operation
        # (event logs, debug logs). /var itself may not be a separate mount.
        if "not found" in out or not out.strip():
            # df command failed — /var/log may not be mounted or bash unavailable.
            return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                # Matches the "Use%" column in df output.
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var/log",                        # Actual path checked on EOS
                        usage_pct=pct,
                        status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL
                    )
        return FilesystemResult(path="/var/log", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show system environment cooling")
        # "show system environment cooling" is the EOS command for fan/cooling status.
        # Note: EOS does NOT use "show environment fan" like Cisco does.
        # The EOS command is "system environment cooling" — shows fan tray status.
        #
        # Example output:
        #   System cooling status: Ok
        #   Fan Tray 1:
        #     Fan 1/1 (speed Ok): 7800 RPM
        #   Fan Tray 2:
        #     Fan 2/1 (speed notInserted)
        #
        # EOS fan status words:
        #   "ok" = healthy fan (note: lowercase on EOS)
        #   "notInserted", "powerOff", "Failure" = problem
        if not out or "invalid" in out.lower():
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: "Fan 1/1" or "Fan 2/1" followed by status keyword.
            # EOS uses "/" in fan identifiers (tray/fan notation).
            m = re.search(r"(Fan\s*[\w/]+).*?(ok|notInserted|powerOff|Failure)", line, re.IGNORECASE)
            if m:
                # Only "ok" means healthy; all other statuses mean problem.
                status = FanStatus.PASS if re.search(r"ok", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # "show running-config" on EOS shows the current active configuration.
        # EOS config format is similar to Cisco IOS but with EOS-specific syntax.
        # timeout=60: large EOS configs (100G data center switches) can be slow.
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # "show startup-config" shows what will load on next boot.
        # On EOS, this is stored in /mnt/flash/startup-config.
        # timeout=60: same reason as running-config.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # Arista EOS DOES NOT use "write memory".
        # The correct save command is "copy running-config startup-config".
        # This writes the current running config to /mnt/flash/startup-config.
        return self.transport.send_command("copy running-config startup-config", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # show users example:
        # Username   TTY     Idle     Time            Host        Service
        # admin      tty1    0:00:00  Oct 19 14:23    10.0.0.100  ssh
        #
        # Column layout:
        #   [0] Username = username
        #   [1] TTY      = terminal (e.g. "tty1")
        #   [2] Idle     = idle time in HH:MM:SS format
        #   [3+] Time, Host, Service = remaining columns (not used for idle check)
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and the header row (starts with "Username").
            if not line.strip() or re.match(r"\s*Username", line, re.IGNORECASE):
                continue
            parts = line.split()
            # Need at least 3 columns to have username, tty, and idle time.
            if len(parts) >= 3:
                user = parts[0]       # Column 0: username
                line_id = parts[1]    # Column 1: terminal (e.g. "tty1")
                idle_str = parts[2]   # Column 2: idle time (HH:MM:SS)
                idle_hours = parse_hhmm_ss(idle_str)
                # parse_hhmm_ss converts "0:00:00" → 0.0h, "0:02:30" → 0.042h, etc.
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 = treat as active if parse fails (conservative).
                ))
        return sessions
