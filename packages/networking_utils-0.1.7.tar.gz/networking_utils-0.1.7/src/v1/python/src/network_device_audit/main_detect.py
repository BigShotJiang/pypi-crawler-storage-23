"""
main_detect.py — Detect Mode Entry Point

This is the top-level script that Ansible runs to perform platform detection
across all inventory devices. It is invoked by the Ansible playbook as:

    python -m network_device_audit.main_detect \\
        --inventory  /path/to/inventory.json \\  # Rendered from Ansible inventory
        --username   <user> \\                    # SSH username (from AWX credential)
        --password   <pass> \\                    # SSH password (from AWX credential)
        --artifact-dir /runner/artifacts/<job_id> \\  # AWX artifact dir for output files
        --repo-path  /path/to/project \\          # Project root (for "repo" storage mode)
        --storage    repo|local \\                # Where to write detect_result.yml
        --threads    8 \\                         # Concurrent SSH connections
        --job-id     <job_id>                    # AWX job ID (for artifact filenames)

WHAT THIS SCRIPT DOES:
  1. Parses CLI arguments (injected by Ansible playbook)
  2. Loads the JSON inventory (rendered from Ansible's internal inventory format)
  3. Spawns a ThreadPoolExecutor with --threads workers
  4. Runs detect_device() for each device in parallel
  5. Collects results and saves them to detect_result.yml (the handoff file)
  6. Writes session logs, summary JSON, and .tar.gz artifact bundle
  7. Exits with code 0 (success) always — individual device failures are recorded,
     not propagated as script failures

WHY ThreadPoolExecutor (not asyncio)?
  - Network device SSH is I/O-bound (waiting for responses), making it ideal for threads
  - ThreadPoolExecutor has a simple API and handles worker lifecycle automatically
  - Using threads (not async) avoids requiring async-aware SSH libraries
  - 8 concurrent threads is the sweet spot: enough parallelism without overwhelming
    AWX's network connection or overloading device management planes
"""

import argparse
import json
import logging
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

from .core.logger import setup_logging
from .core.models import DetectDeviceResult, DeviceStatus
from .detect.detector import detect_device
from .detect.result_store import save_detect_results
from .audit.reporter import write_detect_results


def parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments passed by the Ansible playbook.

    All arguments are injected by the Ansible task — this script doesn't
    read environment variables or config files directly (those are translated
    to CLI args by the playbook).
    """
    p = argparse.ArgumentParser(description="Network device detect mode")
    p.add_argument("--inventory", required=True, help="Path to JSON inventory file")
    # --inventory: path to the JSON file rendered by the Ansible playbook.
    # The Ansible inventory has to be converted to JSON first because Python
    # doesn't understand Ansible's native YAML/INI inventory format.

    p.add_argument("--username", required=True)
    # --username: SSH login username. Set from AWX "machine credentials" — the
    # playbook injects it using {{ username }} (from extra_vars or credentials).

    p.add_argument("--password", required=True)
    # --password: SSH login password. Set from AWX credentials.
    # Marked no_log: true in the Ansible task so it doesn't appear in AWX output.

    p.add_argument("--artifact-dir", required=True)
    # --artifact-dir: directory where all output files are written.
    # AWX sets AWX_ARTIFACTS_DIR; the playbook passes it as this argument.
    # Files in this dir are uploaded to AWX artifact storage at job end.

    p.add_argument("--repo-path", default=None, help="Project repo root (required for storage=repo)")
    # --repo-path: full filesystem path to the project git repository.
    # Used by "repo" storage mode to write detect_result.yml to the repo and git push.
    # Set to None for "local" storage mode.

    p.add_argument("--storage", default="repo", choices=["repo", "local"])
    # --storage: where to write detect_result.yml.
    # "repo":  git commit + push to the project repo (provides history)
    # "local": write to /var/lib/awx/detect_results/ on the AWX server filesystem

    p.add_argument("--threads", type=int, default=8)
    # --threads: number of concurrent SSH connections.
    # AWX inventory variable detect_thread_count controls this.
    # Default 8 is safe for most environments; increase for faster detection.

    p.add_argument("--job-id", required=True)
    # --job-id: AWX_JOB_ID, used to name the artifact bundle:
    # detect_<job_id>_<timestamp>.tar.gz

    p.add_argument("--port", type=int, default=22)
    # --port: SSH port. Default 22; some environments use non-standard ports.
    return p.parse_args()


def load_inventory(path: str) -> list[dict]:
    """
    Load inventory from a JSON file.

    Expected format:
        [{"hostname": "sw01", "ip": "10.0.0.1"}, ...]

    WHY JSON (not Ansible YAML inventory)?
    Python can't read Ansible's internal inventory format directly.
    The Ansible playbook renders the inventory to JSON using:
        inventory_json: "{{ groups['all'] | map('extract', hostvars) | list | to_json }}"
    This JSON is written to a temp file and passed as --inventory.
    """
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def run_detect(args: argparse.Namespace) -> int:
    """
    Main detect logic. Returns exit code (0 = success, 1 = fatal error).

    WHY return an int instead of sys.exit() directly?
    Returning the exit code from run_detect() makes the function testable
    without actually exiting the process during unit tests.
    """
    setup_logging(log_dir=args.artifact_dir, job_id=args.job_id)
    # setup_logging: configures two handlers:
    #   1. stdout (visible in AWX job output)
    #   2. file at artifact_dir/detect_<job_id>.log (included in artifact bundle)
    logger = logging.getLogger(__name__)

    devices = load_inventory(args.inventory)
    logger.info("Detect mode started — %d devices, %d threads", len(devices), args.threads)

    results: list[DetectDeviceResult] = []
    # Pre-allocate list; results are appended as futures complete.

    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        # ThreadPoolExecutor: manages a pool of worker threads.
        # max_workers=args.threads: at most this many concurrent SSH connections.
        # The context manager (with) automatically waits for all futures on exit
        # (pool.shutdown(wait=True) is called automatically).

        futures = {
            pool.submit(
                detect_device,          # Function to run in each thread
                hostname=d["hostname"], # Device hostname (used for logging and results)
                ip=d.get("ip", d["hostname"]),  # IP for SSH; falls back to hostname if no "ip" key
                username=args.username,
                password=args.password,
                port=args.port,
            ): d                        # Map future → device dict for error reporting
            for d in devices
        }
        # Dict comprehension: submits all devices to the thread pool immediately.
        # All devices start detection concurrently (up to max_workers at a time).
        # futures.keys() = Future objects
        # futures.values() = device dicts ({"hostname": ..., "ip": ...})

        for future in as_completed(futures):
            # as_completed() yields futures as they finish (not in submission order).
            # This allows us to process results as they come in rather than waiting
            # for all devices before processing any.
            device = futures[future]    # Retrieve the device dict for this future
            try:
                result = future.result()
                # future.result(): returns the DetectDeviceResult if the thread succeeded,
                # or re-raises any exception that occurred in the thread.
            except Exception as exc:
                # Unexpected exception from detect_device() itself — shouldn't normally
                # happen since detect_device() is designed to catch its own exceptions.
                # This is a safety net for truly unexpected errors.
                logger.error("Unexpected error for %s: %s", device["hostname"], exc, exc_info=True)
                result = DetectDeviceResult(
                    hostname=device["hostname"],
                    ip=device.get("ip", device["hostname"]),
                    device_type=None,       # Unknown — detection never completed
                    platform=None,          # Unknown — detection never completed
                    detection_method=None,  # Unknown — detection never completed
                    status=DeviceStatus.ERROR,
                    error=str(exc),
                )
            results.append(result)

    # ── Save detect_result.yml ────────────────────────────────────────────────
    save_detect_results(
        results=results,
        storage_mode=args.storage,  # "repo" or "local"
        repo_path=args.repo_path,   # Required for "repo" mode; None for "local"
    )
    # save_detect_results() writes detect_result.yml and (for "repo" mode) git commits.
    # This is the HANDOFF FILE — audit mode reads it to know which driver to use per device.

    # ── Write artifacts + .tar.gz ─────────────────────────────────────────────
    tar_path = write_detect_results(
        results=results,
        artifact_dir=args.artifact_dir,
        job_id=args.job_id,
    )
    # write_detect_results() writes:
    #   - Session logs per device (artifact_dir/session_logs/)
    #   - detect_summary.json (aggregate counts)
    #   - .tar.gz bundle of everything
    logger.info("Detect complete. Artifact: %s", tar_path)

    # Print a one-line summary to stdout for quick visibility in AWX job output.
    identified = sum(1 for r in results if r.status == DeviceStatus.SUCCESS)
    unknown = sum(1 for r in results if r.status == DeviceStatus.UNKNOWN)
    unreachable = sum(1 for r in results if r.status == DeviceStatus.UNREACHABLE)
    print(f"Detect complete: {identified} identified, {unknown} unknown, {unreachable} unreachable")
    return 0


def main() -> None:
    """Entry point called by `python -m network_device_audit.main_detect`."""
    args = parse_args()
    sys.exit(run_detect(args))
    # sys.exit() with the return code from run_detect().
    # Exit code 0 = success. Ansible checks this — non-zero would fail the task.
    # run_detect() always returns 0 (device-level failures are recorded, not fatal).


if __name__ == "__main__":
    main()
    # __name__ == "__main__" guard: allows this module to be imported without executing.
    # When run as "python main_detect.py" or "python -m network_device_audit.main_detect",
    # __name__ is "__main__" and main() is called.
    # When imported (e.g., in unit tests), __name__ is the module name and main() is not called.
