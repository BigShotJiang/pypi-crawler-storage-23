# ============================================================
# transport/paramiko_transport.py — Fallback Detection Transport
# ============================================================
# ParamikoTransport is used ONLY during detect mode as a fallback
# when Netmiko SSHDetect fails.  It opens a raw interactive SSH
# shell (no platform knowledge) and issues 'show version' to
# fingerprint the device.
#
# WHY raw Paramiko instead of Netmiko in fallback mode?
#   Netmiko SSHDetect fails when it can't determine the platform.
#   If we tried to use NetmikoTransport at this point we'd still need
#   to know the device_type — which is exactly what we're trying to
#   discover.  Paramiko's generic shell doesn't need a device_type;
#   it just opens an SSH shell and lets us type commands like a human.
#
# Limitations (acceptable for detect-only use):
#   - No prompt pattern awareness: output is collected by waiting for
#     a 2-second silence window, not by detecting a prompt.
#   - No paging control: if show version output paginates (rare), we
#     may get partial output.  Fingerprinting works on partial output.
#   - Not used for audit: all audit operations use NetmikoTransport.
# ============================================================

import logging
import socket                # socket.timeout for timeout detection
import time                  # time.sleep() for inter-command pauses
from typing import Optional

import paramiko              # Raw SSH library; no network-device-specific knowledge

from .base import BaseTransport
from ..core.exceptions import DeviceUnreachableError, CommandTimeoutError

logger = logging.getLogger(__name__)

RECV_BUFFER = 65535     # Bytes to read per recv() call.
                         # 64KB is large enough to receive most CLI responses in one chunk.
INTER_CMD_SLEEP = 0.5   # Seconds to pause after sending a command before reading.
                         # Gives the device time to start generating output before
                         # our first recv() call.  Avoids getting an empty response
                         # because we read before the device has typed anything.


class ParamikoTransport(BaseTransport):
    """
    Raw Paramiko SSH transport used as the Netmiko fallback.
    Primarily used during detection (read-only fingerprinting).
    """

    def __init__(
        self,
        hostname: str,
        username: str,
        password: str,
        port: int = 22,
        conn_timeout: int = 15,      # TCP+SSH connection timeout in seconds
        recv_timeout: int = 30,      # Default per-read timeout in seconds
    ):
        super().__init__(hostname, username, password, port)
        self.conn_timeout = conn_timeout
        self.recv_timeout = recv_timeout
        self._client: Optional[paramiko.SSHClient] = None    # Manages the SSH connection
        self._channel: Optional[paramiko.Channel] = None     # Interactive shell channel

    def connect(self) -> None:
        try:
            logger.debug("Connecting to %s via Paramiko", self.hostname)
            client = paramiko.SSHClient()
            # SSHClient is Paramiko's high-level SSH client.  It wraps Transport
            # and handles authentication, key exchange, etc.

            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            # AutoAddPolicy automatically accepts any host key without verification.
            # WHY: We're connecting to ~4000 diverse devices; maintaining a known_hosts
            # file for all of them is not practical.  Accept the risk: these devices
            # are on a managed internal network where MITM attacks are controlled.
            # RejectPolicy (the default) would fail on first connect to every device.

            client.connect(
                hostname=self.hostname,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=self.conn_timeout,   # TCP connection establishment timeout
                allow_agent=False,
                # Disable SSH agent forwarding.  We're on an AWX server with no
                # SSH agent running; disabling prevents Paramiko from even trying
                # to contact a nonexistent agent, which would slow down connects.
                look_for_keys=False,
                # Don't search ~/.ssh/ for private keys.  We always use password auth.
                # Disabling speeds up connection and avoids key-related errors.
            )
            self._client = client

            # Open an interactive shell channel (like opening a terminal session)
            self._channel = client.invoke_shell(width=200, height=50)
            # width=200: wide terminal prevents line wrapping in show commands.
            # height=50: terminal height; used by paging but we don't rely on it.
            # invoke_shell() is needed (vs. exec_command()) because we want a
            # persistent session where we can send multiple commands, not a
            # single command + connection close.

            self._channel.settimeout(self.recv_timeout)
            # Default recv timeout for this channel.  send_command overrides this
            # per-call but this sets a safe upper bound.

            time.sleep(1)
            # Wait 1 second after opening the shell for the device to send its
            # login banner, MOTD, and initial command prompt.  Without this
            # sleep, _drain() might run before the banner arrives.

            self._drain()
            # Discard the login banner, MOTD, and initial prompt.
            # We don't need them — we just want a clean slate before sending commands.

            self._log(f"[CONNECT] {self.hostname} (paramiko)")

        except paramiko.AuthenticationException as exc:
            raise DeviceUnreachableError(
                f"Authentication failed for {self.hostname}: {exc}"
            ) from exc
        except (socket.timeout, socket.error, Exception) as exc:
            # socket.timeout: TCP connect timeout
            # socket.error:   network-level errors (RST, ICMP unreachable)
            # Exception:      catch-all for any other Paramiko/OS error
            raise DeviceUnreachableError(
                f"Cannot connect to {self.hostname}: {exc}"
            ) from exc

    def disconnect(self) -> None:
        # Close channel first, then client.  Order matters: closing the client
        # without closing the channel first can cause ResourceWarning in Python.
        if self._channel:
            try:
                self._channel.close()
            except Exception:
                pass        # Ignore errors — channel may already be closed by device
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass        # Ignore errors — safe to call even if already closed
        self._channel = None
        self._client = None  # Clear references so is_connected() returns False

    def send_command(self, command: str, timeout: int = 30) -> str:
        if not self._channel:
            raise DeviceUnreachableError(f"Not connected to {self.hostname}")
        try:
            self._channel.settimeout(timeout)
            # Override the channel timeout for this specific command.
            # Allows different commands to have different timeouts.

            self._channel.send(command + "\n")
            # Send the command followed by newline (Enter key).
            # The device will echo the command back and then output the response.

            time.sleep(INTER_CMD_SLEEP)
            # Short pause before reading — gives the device time to start
            # responding.  Without this, recv() might return empty immediately.

            output = self._recv_until_prompt(timeout=timeout)
            # Read all device output until we detect a 2-second silence.

            self._log(f">>> {command}\n{output}")
            return output
        except socket.timeout as exc:
            raise CommandTimeoutError(
                f"Command timed out on {self.hostname}: {command}"
            ) from exc
        except Exception as exc:
            raise CommandTimeoutError(
                f"Command error on {self.hostname} [{command}]: {exc}"
            ) from exc

    def is_connected(self) -> bool:
        # Require both the SSH client and channel to be active.
        # Either being None means we can't send commands.
        return self._channel is not None and self._client is not None

    def _drain(self) -> str:
        """
        Read and discard any pending data on the channel.

        Called after connect() to consume the login banner and initial prompt.
        Uses recv_ready() to poll for data rather than blocking recv(),
        stopping after a 2-second silence window.
        """
        output = b""
        self._channel.settimeout(2)    # Short timeout: just drain what's there now
        try:
            while self._channel.recv_ready():
                # recv_ready() returns True if data is waiting in the buffer.
                output += self._channel.recv(RECV_BUFFER)
                time.sleep(0.1)        # Brief pause between reads to let more data arrive
        except socket.timeout:
            pass    # Silence period reached — nothing more to drain
        return output.decode("utf-8", errors="replace")
        # errors="replace" substitutes ? for any bytes that aren't valid UTF-8
        # (common in device banners with box-drawing characters or special chars).

    def _recv_until_prompt(self, timeout: int = 30) -> str:
        """
        Read channel output until no more data arrives within a short window.

        Heuristic: if recv() raises socket.timeout (no data in 2s), assume
        the command has finished.  This is simpler than detecting a prompt
        pattern (which would require knowing the prompt — but we're in
        detection mode precisely because we DON'T know the platform yet).

        Suitable for read-only detection commands (show version) on all platforms.
        NOT suitable for interactive commands or prompts that require a response.
        """
        output = b""
        deadline = time.time() + timeout   # Absolute deadline: don't loop past this time
        self._channel.settimeout(2)
        # Inner timeout: 2 seconds per recv() attempt.
        # If no data arrives in 2 seconds, we assume the device is done sending.

        while time.time() < deadline:
            try:
                chunk = self._channel.recv(RECV_BUFFER)
                # Read up to RECV_BUFFER bytes.  Blocks for up to 2 seconds.
                if not chunk:
                    break    # EOF from server (connection closed)
                output += chunk
            except socket.timeout:
                # 2-second silence — command output is complete
                break

        return output.decode("utf-8", errors="replace")
