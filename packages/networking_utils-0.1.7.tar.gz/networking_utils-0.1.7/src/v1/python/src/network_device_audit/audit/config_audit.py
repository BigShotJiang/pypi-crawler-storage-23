"""
audit/config_audit.py — Configuration Audit Logic

This module handles the config comparison, backup, save, and verification
workflow for a single device. It is called by auditor.py after the
basic health checks (OS version, filesystem, fans) are complete.

FULL WORKFLOW:
  1. Fetch running config and startup config from the device
  2. Compare them (driver.configs_differ) — if identical, mark COMPLIANT and done
  3. If they differ (unsaved changes exist):
     a. If change=False (default): record the diff, mark REPORT_ONLY, and stop.
        No backup or save is ever performed in report-only mode.
     b. If change=True: proceed with remediation:
        i.  Check active SSH sessions — skip save if any session idle <
            session_max_idle_hours (safety: don't overwrite in-progress edits)
        ii. Backup the current startup config to the artifact directory
        iii.Execute the platform-specific save command (write memory / commit…)
        iv. Re-fetch both configs and verify they now match
        v.  Return REMEDIATED (success) or REMEDIATION_FAILED (save didn't work)

--change FLAG (change parameter):
  False (default) = report-only mode.  Audit runs fully (OS, filesystem, fans,
                    diff) but the tool NEVER touches the device config.  Safe
                    for daily read-only runs where humans review the report.
  True            = remediation mode.  When unsaved changes are found and no
                    blocking session exists, the tool saves the config and
                    verifies the save.  Use for scheduled remediation windows.

SESSION CHECK LOGIC (only reached when change=True):
  idle_hours < session_max_idle_hours = "recently active session" = DO NOT SAVE
  Default threshold is 12 hours — covers a full business-day session.
  If a network engineer logged in this morning and their session is still open
  (but idle while they stepped away), we don't want to auto-save over their
  in-progress config edits.

HA ANOMALY LOGIC (F5 / Citrix only, only when change=True):
  If driver.save_config() raises HAAutoSyncAnomalyError, it means HA auto-sync
  is configured but the group/pair is still out of sync — a production issue
  that operators must investigate manually.  We record HA_SYNC_ANOMALY status
  and do NOT attempt any further save.
"""

import logging
import os
from pathlib import Path

from ..core.models import ConfigResult, ConfigStatus, SessionInfo
from ..core.exceptions import RemediationVerificationError, HAAutoSyncAnomalyError

logger = logging.getLogger(__name__)


def audit_config(
    driver,
    backup_dir: str,
    hostname: str,
    session_max_idle_hours: float = 12.0,
    change: bool = False,
) -> ConfigResult:
    """
    Full config audit for a single device:
      1. Fetch running and startup configs
      2. If they differ:
         a. If change=False: record diff, return REPORT_ONLY (no backup/save)
         b. If change=True:
            i.  Check active SSH sessions — skip save if any session idle < session_max_idle_hours
            ii. Backup → save → verify
      3. Return a ConfigResult

    Args:
        driver:                An instantiated platform driver with an active transport.
                               Must have: get_running_config(), get_startup_config(),
                               configs_differ(), get_active_sessions(), save_config().
        backup_dir:            Directory where config backups are written.
                               Created automatically if it doesn't exist.
                               Only used when change=True (no backup in report-only mode).
        hostname:              Device hostname (used in log messages and backup filename).
        session_max_idle_hours: Sessions idle less than this many hours are treated as
                               active and will block a config save (default 12).
                               Only evaluated when change=True.
        change:                If False (default), report diffs but never save.
                               If True, save config when safe to do so.

    Returns:
        ConfigResult with one of these statuses:
          COMPLIANT:          running == startup, no action needed
          REPORT_ONLY:        unsaved changes found, but change=False — diff recorded,
                              no backup or save performed
          SAVE_SKIPPED:       change=True but active session detected (idle < session_max_idle_hours)
          REMEDIATED:         change=True, successfully saved config and verified
          REMEDIATION_FAILED: change=True, save attempted but configs still differ after save,
                              OR save command raised an exception (other than HA anomaly)
          HA_SYNC_ANOMALY:    change=True but F5/Citrix auto-sync is on and group is out of
                              sync — production issue, no save attempted
    """
    # ── Step 1: Fetch configs ─────────────────────────────────────────────────
    running = driver.get_running_config()
    # running = what's currently in memory (active, applied now)

    startup = driver.get_startup_config()
    # startup = what loads on next boot (NVRAM / bigip.conf / committed config)

    # ── Step 2: Compare ───────────────────────────────────────────────────────
    if not driver.configs_differ(running, startup):
        # configs_differ() strips whitespace before comparing, so minor formatting
        # differences don't count as real differences.
        logger.info("[%s] Config is compliant (running == startup)", hostname)
        return ConfigResult(status=ConfigStatus.COMPLIANT)
        # Early return: no further action needed for this device.

    logger.info("[%s] Unsaved config detected", hostname)

    # ── Step 2a: Report-only mode (change=False) ──────────────────────────────
    if not change:
        # --change was not set (default behaviour): record the diff but do NOT
        # perform any backup or save operation.  The operator reviews the report
        # and decides whether to re-run with --change=True.
        logger.info(
            "[%s] REPORT_ONLY mode (--change not set) — diff recorded, no save performed",
            hostname,
        )
        return ConfigResult(
            status=ConfigStatus.REPORT_ONLY,
            diff_before=_short_diff(running, startup),
            # diff_before: shows exactly what changed (running vs startup).
            # No backup_path — no backup was taken in report-only mode.
            # No error — this is the expected outcome in report-only mode.
        )

    # ─────────────────────────────────────────────────────────────────────────
    # All steps below only execute when change=True.
    # ─────────────────────────────────────────────────────────────────────────

    logger.info(
        "[%s] change=True — checking active sessions before save", hostname
    )

    # ── Step 2b: Check active SSH sessions ───────────────────────────────────
    sessions = driver.get_active_sessions()
    # get_active_sessions() returns a list of SessionInfo objects.
    # Each SessionInfo has: user, line (vty 0, pts/0, etc.), idle_hours.

    blocking = [s for s in sessions if s.idle_hours < session_max_idle_hours]
    # "blocking" sessions = ones that are too recently active to safely save over.
    # idle_hours < session_max_idle_hours = session was active within the threshold window.
    # Example: idle_hours=0.09 (5 minutes idle) → blocking (with default 12h threshold)
    # Example: idle_hours=25.0 (25 hours idle) → NOT blocking

    if blocking:
        # At least one recently active session found — DO NOT SAVE.
        # Safety measure: auto-saving config when an engineer is actively logged in
        # could overwrite in-progress changes they haven't committed yet.
        session_details = ", ".join(
            f"{s.user}@{s.line} (idle {s.idle_hours:.1f}h)" for s in blocking
        )
        # session_details example: "admin@vty 0 (idle 0.1h), ops@vty 1 (idle 2.5h)"
        logger.warning(
            "[%s] Config save SKIPPED — %d active session(s) within last %.0fh: %s",
            hostname, len(blocking), session_max_idle_hours, session_details,
        )
        return ConfigResult(
            status=ConfigStatus.SAVE_SKIPPED,
            diff_before=_short_diff(running, startup),  # Include diff for visibility in reports
            error=f"Active session(s) detected (idle < {session_max_idle_hours}h): {session_details}",
        )

    logger.info("[%s] No recent active sessions — proceeding with config save", hostname)

    # ── Step 3: Backup old startup config ────────────────────────────────────
    backup_path = _backup_config(startup, backup_dir, hostname)
    # WHY backup STARTUP (not running)?
    # We're about to overwrite the startup config with the running config.
    # The backup preserves what was in startup BEFORE the save, so we can
    # restore it if the save causes unexpected issues.
    # Running config is not backed up because it's what we're saving TO startup.

    # ── Step 4: Save running config ───────────────────────────────────────────
    try:
        save_output = driver.save_config()
        # save_config() calls the platform-specific save command:
        #   Cisco IOS/IOS-XR: "write memory"
        #   Cisco IOS-XE/NX-OS/EOS: "copy running-config startup-config"
        #   JunOS/IOS-XR: "commit"
        #   F5: "save /sys config" (HA-aware: may save on multiple members)
        #   Citrix: "save ns config" (HA-aware: may save on primary + secondary)
        logger.info("[%s] Config saved: %s", hostname, save_output.strip()[:80])
        # [:80] truncates the save output for log readability.

    except HAAutoSyncAnomalyError as exc:
        # F5 / Citrix: auto-sync is configured and enabled, but the HA group/pair
        # is still out of sync.  This is a production issue — the platform's own
        # sync mechanism failed.  We must NOT attempt a manual save because we
        # don't know which side has the authoritative config.  Report the anomaly
        # and let operators investigate.
        logger.error(
            "[%s] HA sync anomaly — auto-sync enabled but group is out of sync: %s",
            hostname, exc,
        )
        return ConfigResult(
            status=ConfigStatus.HA_SYNC_ANOMALY,
            backup_path=backup_path,    # Backup was already taken — return its path
            diff_before=_short_diff(running, startup),
            error=str(exc),
        )

    except Exception as exc:
        # Save command failed (timeout, enable mode issue, command error, etc.)
        return ConfigResult(
            status=ConfigStatus.REMEDIATION_FAILED,
            backup_path=backup_path,                    # Backup path still returned (backup was done)
            diff_before=_short_diff(running, startup),  # Show what differed before the failed save
            error=f"Save failed: {exc}",
        )

    # ── Step 5: Verify — re-fetch and re-diff ────────────────────────────────
    running_after = driver.get_running_config()
    startup_after = driver.get_startup_config()
    # Re-fetch BOTH configs after the save to verify they now match.
    # WHY re-fetch both? Some devices take a moment to flush the config to storage.
    # Fetching both fresh ensures we see the post-save state.

    if driver.configs_differ(running_after, startup_after):
        # Post-save diff still exists — save command appeared to succeed but
        # configs don't match. This could happen if:
        #   - save command output "OK" but didn't actually write
        #   - partial save (filesystem full, permission error)
        #   - platform-specific save behavior we didn't anticipate
        logger.error("[%s] Remediation verification failed — configs still differ", hostname)
        return ConfigResult(
            status=ConfigStatus.REMEDIATION_FAILED,
            backup_path=backup_path,
            diff_before=_short_diff(running, startup),              # Before-save diff
            diff_after=_short_diff(running_after, startup_after),   # After-save diff (still exists!)
            error="Post-save diff not clean",
        )

    # ── Success: configs now match ────────────────────────────────────────────
    logger.info("[%s] Remediation verified — config is now clean", hostname)
    return ConfigResult(
        status=ConfigStatus.REMEDIATED,
        backup_path=backup_path,
        diff_before=_short_diff(running, startup),  # Record what was fixed for audit trail
    )


def _backup_config(config: str, backup_dir: str, hostname: str) -> str:
    """
    Write config to <backup_dir>/<hostname>_startup_backup.txt and return the path.

    WHY backup startup config (not running)?
    We're saving running → startup. The backup preserves what startup was
    BEFORE the save, so we have a restore point if needed.

    The backup filename includes only the hostname (not a timestamp) so that
    each run overwrites the previous backup — preventing backup file proliferation.
    AWX artifact bundles (.tar.gz) are timestamped, providing historical backups.
    """
    Path(backup_dir).mkdir(parents=True, exist_ok=True)
    # Create backup_dir and all parent directories if they don't exist.
    # parents=True: creates intermediate dirs (like mkdir -p).
    # exist_ok=True: no error if directory already exists.

    path = os.path.join(backup_dir, f"{hostname}_startup_backup.txt")
    # Naming: "{hostname}_startup_backup.txt" — clearly identifies what's backed up.
    # Plain .txt extension: human-readable without any special tooling.

    with open(path, "w", encoding="utf-8") as fh:
        fh.write(config)
    # Write the config as-is (no transformation) so it can be diffed/restored easily.

    logger.debug("[%s] Startup config backed up to %s", hostname, path)
    return path
    # Return the path so ConfigResult can include it in the audit record.


def _short_diff(running: str, startup: str) -> str:
    """
    Return a trimmed unified diff of running vs startup configs (first 2000 chars).

    WHY unified diff?
    Unified diff (the format used by git diff) shows context lines (unchanged)
    alongside changes (+ added, - removed). This is the most human-readable
    and well-understood diff format for config review.

    WHY truncate to 2000 chars?
    Configs can be thousands of lines. A 2000-char diff is sufficient to:
      - Show what categories of changes exist (interfaces, VLANs, ACLs, etc.)
      - Fit in a JSON audit result without bloating the file
      - Be readable in an AWX job log without scrolling forever

    fromfile="startup", tofile="running": labels in the diff header showing
    which side is which:
      --- startup     (what was saved/what boots)
      +++ running     (what's actually applied now)
      +new_line       (in running but NOT in startup = unsaved addition)
      -old_line       (in startup but NOT in running = removed from running)
    """
    import difflib
    # Lazy import: difflib is only needed when configs differ.
    # Avoids importing it at module load time for devices that are COMPLIANT.

    diff_lines = list(
        difflib.unified_diff(
            startup.splitlines(keepends=True),   # Startup = "from" (old state)
            running.splitlines(keepends=True),   # Running = "to" (new state)
            fromfile="startup",                  # Label for the startup side
            tofile="running",                    # Label for the running side
            lineterm="",                         # Don't add extra newlines between diff lines
        )
    )
    diff_text = "".join(diff_lines)
    # Truncate to 2000 characters to keep the audit result JSON compact.
    return diff_text[:2000] + ("…[truncated]" if len(diff_text) > 2000 else "")
    # Append a "…[truncated]" marker so readers know there's more diff not shown.
