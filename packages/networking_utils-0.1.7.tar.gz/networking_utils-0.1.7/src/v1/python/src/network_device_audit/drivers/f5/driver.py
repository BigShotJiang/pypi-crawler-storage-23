# ============================================================
# drivers/f5/driver.py — F5 BIG-IP Driver (HA-aware)
# ============================================================
# Covers: F5 BIG-IP LTM (Local Traffic Manager) appliances and
#         VE (Virtual Edition) — the virtual appliance form factor.
#
# F5 BIG-IP runs a custom Linux-based OS called TMOS.
# TMOS is built on a hardened Linux with a proprietary management
# CLI called "tmsh" (Traffic Management Shell).
#
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     tmsh CLI grants full access on login; no "enable" concept.
#   - Filesystem: Linux /var — checked directly with "df -h /var"
#     (tmsh allows raw Linux commands like df, cat, who)
#   - Config save: "save /sys config" — writes to /config/bigip.conf
#   - Running config: "list /all-properties recursive" (tmsh syntax)
#   - Startup config: stored in /config/bigip.conf (flat file)
#   - Sessions: uses Linux "who" command (not a network CLI command)
#     WHY "who" instead of "show users"?
#     tmsh exposes the underlying Linux user session table via "who".
#     "who" is a standard Linux command that shows logged-in users
#     with their login TIME (not idle time). We convert login time
#     to session age using session_age_from_login_time().
#
# HA DESIGN (F5 DSC — Device Service Clustering):
#   F5 uses "device groups" to replicate config across HA cluster members.
#   There are two group types:
#     sync-only    — internal F5 trust group (ignore — not user HA)
#     sync-failover — the actual user-configured HA group (target for our audit)
#
#   HA discovery sequence (run once, cached):
#     1. tmsh show cm failover-status → is this device ACTIVE or STANDBY?
#     2. tmsh list cm device-group    → find sync-failover group, members, auto-sync flag
#     3. tmsh list cm device          → get management IPs for each member
#     4. tmsh show cm sync-status     → per-member sync state
#
#   Config save sequence (only when change=True, only from active node):
#     - Any member out-of-sync + auto-sync disabled:
#         run cm config-sync to-group <group>   (force sync from active to peers)
#         SSH to each member individually → save /sys config
#     - Any member out-of-sync + auto-sync enabled:
#         RAISE HAAutoSyncAnomalyError (production issue, no save)
#     - All members in sync:
#         SSH to each member individually → save /sys config
# ============================================================

import re
import logging
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...core.exceptions import HAAutoSyncAnomalyError
from ...parsers.session_parser import session_age_from_login_time
# NOTE: F5 uses session_age_from_login_time (NOT parse_hhmm_ss) because
# "who" outputs LOGIN TIME (absolute timestamp), not IDLE DURATION.
# session_age_from_login_time() converts login time to hours-since-login.

logger = logging.getLogger(__name__)


class F5Driver(BaseDriver):
    PLATFORM = "f5"          # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False      # tmsh: full access without enable mode

    def __init__(self, transport, filesystem_critical_pct: float = 70.0,
                 username: Optional[str] = None, password: Optional[str] = None,
                 port: int = 22):
        super().__init__(
            transport,
            filesystem_critical_pct=filesystem_critical_pct,
            username=username,
            password=password,
            port=port,
        )
        self._ha_info: Optional[dict] = None
        # _ha_info: cache for HA discovery results.
        # Populated by _discover_ha() which is called inside is_ha_standby().
        # None = not yet discovered.  {} = discovered, standalone (no HA group found).
        # dict with keys = HA topology detected.
        # Caching avoids running 4 tmsh commands twice — is_ha_standby() and
        # save_config() both need HA data, so we discover once and reuse.

    # ── HA discovery ──────────────────────────────────────────────────────────

    def _discover_ha(self) -> None:
        """
        Discover F5 DSC (Device Service Clustering) HA topology from this device.
        Results are cached in self._ha_info.  Safe to call multiple times.

        Populates self._ha_info with:
          is_standby     : bool — True if this device is the STANDBY member
          ha_group       : str | None — sync-failover group name (None = standalone)
          ha_auto_sync   : bool — True if auto-sync is enabled on the group
          ha_members     : list of dicts — one per group member:
                             {"hostname": str, "management_ip": str, "sync_status": str}
          ha_anomaly     : bool — True if auto-sync enabled but any member out of sync

        HA sync_status values seen in tmsh show cm sync-status:
          "In Sync"         — member is fully synchronized
          "Changes Pending" — member has config changes not yet replicated
          "Sync Failed"     — replication error
          "Disconnected"    — member unreachable to the sync mechanism
          "Unknown"         — status could not be parsed

        If any discovery command fails, a safe fallback is applied:
          _ha_info["is_standby"] = False  (don't skip what might be an active device)
          _ha_info["ha_group"]   = None   (treat as standalone)
        This is conservative — we'd rather audit a standby device than silently
        skip an active one.
        """
        if self._ha_info is not None:
            return   # Already cached — skip re-discovery

        self._ha_info = {}   # Mark as "discovery attempted" (even if all steps fail)

        # ── Step 1: Active or standby? ────────────────────────────────────────
        try:
            failover_out = self.transport.send_command("tmsh show cm failover-status")
            # Example output (ACTIVE):
            #   --------------------------------------------------
            #   | FailoverStatus                                 |
            #   --------------------------------------------------
            #   | Color                | green                  |
            #   | Status               | active                 |
            #   | Failover State       | ACTIVE                 |
            #   --------------------------------------------------
            # Example output (STANDBY):
            #   | Failover State       | STANDBY                |
            is_standby = bool(re.search(r"Failover\s+State\s*\|\s*STANDBY", failover_out, re.IGNORECASE))
            # Match "Failover State | STANDBY" (table format).
            # re.IGNORECASE: handle both "STANDBY" and "standby" in edge cases.
            self._ha_info["is_standby"] = is_standby
        except Exception as exc:
            logger.warning("[F5] Could not determine failover status: %s — assuming active", exc)
            self._ha_info["is_standby"] = False
            # Safe default: treat as active so the audit proceeds.

        # ── Step 2: Find the sync-failover device group ───────────────────────
        try:
            group_out = self.transport.send_command("tmsh list cm device-group", timeout=30)
            # "tmsh list cm device-group" lists ALL device groups, including the
            # internal "device_trust_group" (type: sync-only) which F5 creates
            # automatically and is NOT the user-configured HA group.
            # We want ONLY groups of type "sync-failover".
            #
            # Example output for a sync-failover group:
            #   cm device-group /Common/failover-group {
            #       auto-sync disabled
            #       devices {
            #           /Common/bigip1.example.com { }
            #           /Common/bigip2.example.com { }
            #       }
            #       type sync-failover
            #   }
            ha_group_name, auto_sync, member_names = self._parse_sync_failover_group(group_out)
        except Exception as exc:
            logger.warning("[F5] Could not parse device groups: %s — treating as standalone", exc)
            self._ha_info["ha_group"] = None
            return   # No HA info available; standalone treatment

        if not ha_group_name:
            # No sync-failover group found — this is a standalone F5.
            self._ha_info["ha_group"] = None
            return   # No further HA discovery needed

        self._ha_info["ha_group"] = ha_group_name
        self._ha_info["ha_auto_sync"] = auto_sync

        # ── Step 3: Get management IP for each member ─────────────────────────
        try:
            device_out = self.transport.send_command("tmsh list cm device", timeout=30)
            # "tmsh list cm device" shows device details for each cluster member.
            # Example output:
            #   cm device /Common/bigip1.example.com {
            #       management-ip 10.0.0.1
            #       ...
            #   }
            #   cm device /Common/bigip2.example.com {
            #       management-ip 10.0.0.2
            #       ...
            #   }
            member_ips = self._parse_device_management_ips(device_out, member_names)
        except Exception as exc:
            logger.warning("[F5] Could not parse device management IPs: %s", exc)
            member_ips = {}   # Will result in members with "unknown" IPs — save will skip them

        # ── Step 4: Get per-member sync status ────────────────────────────────
        try:
            sync_out = self.transport.send_command("tmsh show cm sync-status", timeout=30)
            # "tmsh show cm sync-status" shows the overall sync state and per-member status.
            # Example output (in sync):
            #   | Status      | In Sync  |
            #
            # Example output (out of sync):
            #   | Status      | Changes Pending  |
            #   | bigip1.example.com              |
            #   |     Status: Changes Pending     |
            #   | bigip2.example.com              |
            #   |     Status: In Sync             |
        except Exception as exc:
            logger.warning("[F5] Could not get sync status: %s — assuming in sync", exc)
            sync_out = ""   # Will cause all members to show "Unknown" sync status

        # Build members list: one dict per member with hostname, ip, sync_status
        members = []
        for full_name in member_names:
            short_name = full_name.split("/")[-1]
            # full_name: "/Common/bigip1.example.com"
            # short_name: "bigip1.example.com" (strips "/Common/" prefix)
            # tmsh show cm sync-status uses short names, not the full /Common/... path.

            mgmt_ip = member_ips.get(full_name, "unknown")
            # Management IP from Step 3; "unknown" if the device wasn't in the list.

            sync_status = self._parse_member_sync_status(sync_out, short_name)
            # Look for this member's individual status line in the sync output.

            members.append({
                "hostname": short_name,
                "management_ip": mgmt_ip,
                "sync_status": sync_status,
            })

        self._ha_info["ha_members"] = members

        # ── Step 5: Anomaly detection ─────────────────────────────────────────
        any_out_of_sync = any(
            m["sync_status"] not in ("In Sync",)
            for m in members
        )
        # "In Sync" = the only safe status.  "Changes Pending", "Sync Failed",
        # "Disconnected", "Unknown" all count as "out of sync" for our purposes.

        self._ha_info["ha_anomaly"] = auto_sync and any_out_of_sync
        # Anomaly = auto-sync is ON but group is still out of sync.
        # This means F5's own replication mechanism is not working → production issue.

    def _parse_sync_failover_group(self, output: str):
        """
        Parse 'tmsh list cm device-group' output and return the first
        sync-failover group's name, auto-sync flag, and member list.

        Returns: (group_name, auto_sync, member_names) where group_name is
        None if no sync-failover group is found.

        Splits the output into per-group blocks by looking for 'cm device-group'
        header lines, then finds the one that contains 'type sync-failover'.
        """
        ha_group_name = None
        auto_sync = False
        member_names = []

        # Split by "cm device-group" prefix to get individual group blocks.
        # re.split with a lookahead keeps the delimiter at the start of each block.
        blocks = re.split(r"(?=cm device-group\s)", output)
        for block in blocks:
            if "sync-failover" not in block:
                # This is the internal "sync-only" trust group — skip it.
                # "sync-only" = F5's internal certificate/trust synchronisation
                # group that exists on every clustered F5. It is NOT the
                # user-configured HA failover group we care about.
                continue

            # Found a sync-failover block — extract name, auto-sync, members.
            name_m = re.search(r"cm device-group\s+([\S]+)", block)
            # Match: "cm device-group /Common/failover-group {"
            # Group 1 captures: "/Common/failover-group"
            if name_m:
                ha_group_name = name_m.group(1)

            auto_sync = bool(re.search(r"auto-sync\s+enabled", block, re.IGNORECASE))
            # "auto-sync enabled"  → True
            # "auto-sync disabled" → False (re.search returns None → bool(None) = False)

            # Extract device member names from the devices { ... } block.
            devices_m = re.search(r"devices\s*\{([^}]+)\}", block, re.DOTALL)
            # Match: "devices {\n    /Common/bigip1.example.com { }\n    ...\n}"
            # Group 1 captures everything inside the braces.
            if devices_m:
                member_names = re.findall(r"(/[\S]+)\s*\{", devices_m.group(1))
                # Find all "/Common/hostname { }" entries inside the devices block.
                # Each match group(1) is the full path like "/Common/bigip1.example.com".

            break   # Use the first sync-failover group found (there should only be one)

        return ha_group_name, auto_sync, member_names

    def _parse_device_management_ips(self, output: str, member_names: list) -> dict:
        """
        Parse 'tmsh list cm device' output and extract management-ip for each member.

        Returns a dict mapping full device path → management IP string.
        Example: {"/Common/bigip1.example.com": "10.0.0.1", ...}
        """
        ips = {}
        for full_name in member_names:
            # Search for the management-ip value inside this device's block.
            # The regex spans across newlines (re.DOTALL) to find the ip after the device name.
            # Pattern: "bigip1.example.com" ... "management-ip 10.0.0.1"
            short_name = re.escape(full_name.split("/")[-1])
            # re.escape: escape any dots in the hostname for safe regex use.
            ip_m = re.search(
                rf"{short_name}.*?management-ip\s+([\d.]+)",
                output,
                re.DOTALL,
            )
            # re.DOTALL: lets ".*?" match across newlines, so the pattern can span
            # from the device name line to the management-ip line inside the block.
            if ip_m:
                ips[full_name] = ip_m.group(1)   # e.g. "10.0.0.1"
        return ips

    def _parse_member_sync_status(self, output: str, short_name: str) -> str:
        """
        Parse 'tmsh show cm sync-status' and return the sync status for one member.

        When the group is in sync the per-member section may be absent from output
        (F5 only shows device-level detail when there is a discrepancy).
        In that case we parse the top-level "Status" line instead.

        Returns a status string: "In Sync", "Changes Pending", "Sync Failed",
        "Disconnected", or "Unknown" (if parsing fails).
        """
        # Try to find a per-member status line for this specific device.
        # Pattern: "bigip1.example.com\n    Status: Changes Pending"
        member_m = re.search(
            rf"{re.escape(short_name)}[^\n]*\n[^\n]*Status:\s*([^\n|]+)",
            output,
            re.IGNORECASE,
        )
        if member_m:
            return member_m.group(1).strip()
        # Strip trailing whitespace and pipe characters from table-formatted output.

        # No per-member section found — check top-level status.
        # When ALL members are in sync, F5 only shows one line: "Status | In Sync".
        top_m = re.search(r"\|\s*Status\s*\|\s*([^|]+)\|", output, re.IGNORECASE)
        if top_m:
            return top_m.group(1).strip()

        return "Unknown"   # Could not parse sync status for this member

    # ── BaseDriver overrides — HA-capable methods ──────────────────────────────

    def is_ha_standby(self) -> bool:
        """
        Return True if this F5 device is currently the STANDBY (secondary) member.

        Runs _discover_ha() on first call to populate self._ha_info.
        Subsequent calls (e.g. from save_config()) return immediately from cache.

        Safe failure: if failover-status command fails, _discover_ha() defaults
        is_standby to False → this method returns False → audit proceeds normally.
        """
        self._discover_ha()   # Populate self._ha_info (no-op if already cached)
        return self._ha_info.get("is_standby", False)
        # .get() with default False: safe even if _ha_info is still {} (empty dict
        # from a failed discovery where _discover_ha() returned early after the group
        # lookup failed).

    def get_ha_info(self) -> dict:
        """
        Return the cached HA topology dict for auditor.py to merge into AuditDeviceResult.

        The dict keys match the ha_* fields on AuditDeviceResult:
          ha_group, ha_members, ha_auto_sync, ha_sync_enforced,
          ha_anomaly, ha_config_saved_members.

        save_config() adds ha_sync_enforced and ha_config_saved_members to the dict
        after the save operations complete, so callers should call get_ha_info()
        AFTER config_audit() (and thus after save_config()) has finished.
        """
        if self._ha_info is None:
            return {}   # _discover_ha() was never called (shouldn't happen in normal flow)
        return self._ha_info

    def save_config(self) -> str:
        """
        HA-aware config save override.

        For STANDALONE F5 (no device group):
          Calls the base save_config() which retries _save_config() up to 3x.
          _save_config() issues "save /sys config" on self.transport.

        For HA F5 (sync-failover group found):
          Overrides the base retry wrapper entirely — HA logic is too stateful
          for blind retries (sync command must not run multiple times).

          1. If any member is out of sync AND auto-sync is enabled:
               → Raise HAAutoSyncAnomalyError (caller records HA_SYNC_ANOMALY status)
          2. If any member is out of sync AND auto-sync is disabled:
               → Run "run cm config-sync to-group <group>" to push config from active
          3. For all members (including self): SSH individually and "save /sys config"
               → self is identified by matching management IP to self.transport.hostname
               → peers get fresh NetmikoTransport connections
          4. Update self._ha_info with ha_sync_enforced and ha_config_saved_members

        IMPORTANT: This method is only called when change=True.
        When change=False, audit_config() returns REPORT_ONLY before reaching save_config().
        """
        self._discover_ha()   # Ensure HA info is cached (no-op if already done)

        ha_group = self._ha_info.get("ha_group")
        if not ha_group:
            # Standalone F5 — use the base class save_config() which adds retry logic.
            # _save_config() is the actual "save /sys config" command (see below).
            logger.info("[F5] Standalone device — standard save /sys config")
            result = super().save_config()   # BaseDriver.save_config() with retry
            self._ha_info["ha_sync_enforced"] = False
            self._ha_info["ha_config_saved_members"] = [self.transport.hostname]
            return result

        # ── HA path ───────────────────────────────────────────────────────────
        members = self._ha_info.get("ha_members", [])
        auto_sync = self._ha_info.get("ha_auto_sync", False)

        any_out_of_sync = any(
            m["sync_status"] not in ("In Sync",) for m in members
        )
        # Count any non-"In Sync" status as "out of sync" (conservative).

        if any_out_of_sync and auto_sync:
            # F5 auto-sync is on, but the group is still out of sync.
            # This is a production issue — auto-sync should have replicated
            # the config change already.  Do NOT attempt manual save.
            out_of_sync_names = [
                m["hostname"] for m in members if m["sync_status"] != "In Sync"
            ]
            self._ha_info["ha_sync_enforced"] = False
            raise HAAutoSyncAnomalyError(
                f"F5 device group '{ha_group}' has auto-sync enabled but "
                f"these members are still out of sync: {out_of_sync_names}. "
                "Production issue — investigate DSC replication before saving."
            )

        # ── Force sync if needed (auto-sync off + group out of sync) ──────────
        if any_out_of_sync and not auto_sync:
            # Group is out of sync and auto-sync is disabled.
            # Manually push the running config from this active device to all peers.
            logger.info(
                "[F5] Enforcing config sync to group '%s' (auto-sync disabled, out of sync)",
                ha_group,
            )
            self.transport.send_command(
                f"run cm config-sync to-group {ha_group}",
                timeout=120,
                # 120 seconds: config sync can take a while for large configs.
                # F5 will return the prompt once sync is complete.
            )
            self._ha_info["ha_sync_enforced"] = True
            logger.info("[F5] Config sync to group '%s' completed", ha_group)
        else:
            self._ha_info["ha_sync_enforced"] = False
            # Group is already in sync — no sync command needed.

        # ── Save on every member individually ──────────────────────────────────
        # WHY save each member individually even if they're in sync?
        # "In sync" means the running config is replicated across all members.
        # But "save" (run cmd → bigip.conf) must be done per-device because
        # F5 does NOT automatically persist config to disk on all members —
        # each device must be individually told to save /sys config.
        saved_members = []
        current_ip = self.transport.hostname
        # self.transport.hostname is the IP address of the current device
        # (set by auditor.py as: NetmikoTransport(hostname=ip, ...)).

        for member in members:
            member_ip = member.get("management_ip", "unknown")
            member_hostname = member.get("hostname", "unknown")

            if member_ip == "unknown":
                # Management IP not discovered — cannot SSH to this member.
                logger.warning(
                    "[F5] Skipping save on '%s' — management IP unknown", member_hostname
                )
                continue

            if member_ip == current_ip:
                # This member IS the current device we're already connected to.
                # Use the existing transport rather than opening a new SSH session.
                try:
                    self.transport.send_command("save /sys config", timeout=60)
                    # "save /sys config": persists running config to /config/bigip.conf.
                    # timeout=60: write to disk can take up to a minute on large configs.
                    saved_members.append(member_hostname)
                    logger.info("[F5] Saved config on self (%s / %s)", member_hostname, member_ip)
                except Exception as exc:
                    logger.error(
                        "[F5] Failed to save config on self (%s / %s): %s",
                        member_hostname, member_ip, exc,
                    )
                    # Log and continue — save what we can on other members.
            else:
                # Peer member — open a fresh SSH connection to this device.
                try:
                    self._save_on_peer(peer_ip=member_ip, peer_hostname=member_hostname)
                    saved_members.append(member_hostname)
                    logger.info(
                        "[F5] Saved config on peer '%s' (%s)", member_hostname, member_ip
                    )
                except Exception as exc:
                    logger.error(
                        "[F5] Failed to save config on peer '%s' (%s): %s",
                        member_hostname, member_ip, exc,
                    )
                    # Log and continue — partial saves are still better than none.

        self._ha_info["ha_config_saved_members"] = saved_members
        # Record which members were successfully saved for the audit report.

        summary = (
            f"HA save: {len(saved_members)}/{len(members)} members saved "
            f"({', '.join(saved_members)})"
        )
        logger.info("[F5] %s", summary)
        return summary

    def _save_on_peer(self, peer_ip: str, peer_hostname: str) -> None:
        """
        Open a fresh SSH connection to a peer F5 member and run 'save /sys config'.

        WHY a fresh connection (not the existing self.transport)?
        self.transport is connected to the ACTIVE device (the one being audited).
        Peer devices are different physical/virtual systems — each needs its own
        SSH session.  Netmiko handles the connection lifecycle; we close it in finally.

        Args:
            peer_ip:       Management IP of the peer F5 to connect to.
            peer_hostname: Peer device's short hostname (for log messages only).

        Raises:
            Any exception from NetmikoTransport.connect() or send_command() —
            caller (save_config()) logs and continues so other members can be saved.
        """
        from ...transport.netmiko_transport import NetmikoTransport
        # Lazy import: avoids circular import at module load time.
        # NetmikoTransport imports from transport/, which doesn't import drivers/,
        # so there's no actual circular dependency — but keeping the import here
        # keeps the driver file's top-level imports clean.

        peer_transport = NetmikoTransport(
            hostname=peer_ip,         # SSH target: management IP of the peer
            username=self.username,   # Same credentials as the primary connection
            password=self.password,   # self.username/password stored in BaseDriver.__init__
            device_type="f5_ltm",     # Netmiko device type for F5 BIG-IP LTM
            port=self.port,           # SSH port (default 22; stored in BaseDriver)
            secret=self.password,     # Enable secret = same as login password (F5 doesn't
                                      # use enable mode, but Netmiko needs the parameter)
        )
        peer_transport.connect()
        try:
            peer_transport.send_command("save /sys config", timeout=60)
            # Same save command as the primary device.
            # timeout=60: write to disk takes time on large F5 configs.
        finally:
            peer_transport.disconnect()
            # Always close the peer SSH session — even if save failed.
            # This prevents SSH session leaks on the peer device.

    # ── Standard audit methods (unchanged from original) ─────────────────────

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show sys version")
        # F5 "show sys version" output includes:
        #   Version                    14.1.5.6
        #   Build                      0.0.9
        #   Date                       Mon ...
        # Pattern captures the "Version" field value.
        m = re.search(r"Version\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("df -h /var")
        # F5 TMOS is Linux-based, so standard POSIX "df" works directly.
        # "df -h /var" shows disk usage for the /var partition.
        # -h = human-readable (K, M, G units) — we only need the % column.
        #
        # Example output:
        #   Filesystem      Size  Used Avail Use% Mounted on
        #   /dev/mapper/vg0  20G   14G  5.5G  72% /var
        #
        # "no such" check: if /var isn't mounted separately, df may error.
        if not out or "no such" in out.lower():
            return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                # Matches the "Use%" percentage column.
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var",                            # Actual path checked
                        usage_pct=pct,
                        status=self._filesystem_status(pct),    # OK/CRITICAL based on threshold
                    )
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show sys hardware field-fmt | grep -i fan")
        # COMMAND EXPLANATION:
        # "show sys hardware field-fmt": F5 tmsh command that shows hardware info
        # in "field format" — structured key: value pairs (easier to parse).
        # "| grep -i fan": tmsh supports Linux pipe commands; grep filters fan lines.
        #
        # Example output (after grep filter):
        #   fan.1.name fan-1
        #   fan.1.speed 5130
        #   fan.1.status good
        #   fan.2.name fan-2
        #   fan.2.status bad
        #
        # Pattern matches "fan<identifier> <status>" in field-format output.
        if not out:
            # No fan output — likely F5 VE (virtual edition) with no physical fans.
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Match: fan name (fan.1.name or fan.1) followed by status keyword.
            # Group 1: fan identifier (e.g. "fan.1.status" prefix matches "fan[\w.-]+")
            # Group 2: status value ("good", "bad", "missing", "ok")
            m = re.search(r"(fan[\w.-]+)\s+(good|bad|missing|ok)", line, re.IGNORECASE)
            if m:
                status = FanStatus.PASS if re.search(r"good|ok", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # F5 RUNNING CONFIG = tmsh "list" command:
        # "list /all-properties recursive" shows ALL config objects with all properties.
        # /all-properties: include properties even if they're at default values.
        # recursive: include all nested objects (pools, members, monitors, etc.).
        #
        # WHY NOT "show running-config"?
        # F5 doesn't use IOS-style "show running-config".
        # tmsh's "list" is the equivalent — it shows object definitions in tmsh syntax.
        #
        # timeout=90: F5 configs on large LTMs can be huge (thousands of VIPs,
        # pools, iRules). 90 seconds is needed for large appliances.
        return self.transport.send_command("list /all-properties recursive", timeout=90)

    def _get_startup_config(self) -> str:
        # F5 STARTUP CONFIG = /config/bigip.conf file on disk.
        # Unlike IOS where startup config is in NVRAM, F5 stores startup config
        # as a flat file at /config/bigip.conf.
        #
        # "cat /config/bigip.conf" reads this file directly (tmsh allows Linux commands).
        # After "save /sys config", bigip.conf is updated to match running config.
        #
        # timeout=90: same reason as running config — can be very large.
        return self.transport.send_command("cat /config/bigip.conf", timeout=90)

    def _save_config(self) -> str:
        # Called by BaseDriver.save_config() (with retry) for standalone devices.
        # HA-capable save_config() override (above) calls this indirectly via super()
        # only for standalone F5 devices.
        #
        # F5 SAVE = "save /sys config":
        # This writes the current running configuration to /config/bigip.conf.
        # After this, bigip.conf (startup) matches running config — no unsaved changes.
        # Equivalent to "write memory" on IOS or "copy running-config startup-config" on IOS-XE.
        return self.transport.send_command("save /sys config", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # F5 is Linux-based; `who` shows logged-in users with login time
        # Example: admin   pts/0        2024-10-19 14:23 (10.0.0.100)
        #
        # WHY "who" and NOT "show users"?
        # F5 tmsh doesn't have a "show users" command. Since TMOS is Linux-based,
        # the "who" command is available and shows all logged-in users.
        #
        # WHY session_age_from_login_time instead of parse_hhmm_ss?
        # "who" outputs LOGIN TIME (absolute timestamp like "2024-10-19 14:23"),
        # NOT idle duration (like "00:05:23").
        # session_age_from_login_time() calculates how many hours ago the user logged in.
        # We use this as a proxy for "how long has this session been open".
        # A session that's been open for < 12 hours might still be active.
        out = self.transport.send_command("who")
        sessions = []
        for line in out.splitlines():
            if not line.strip():
                continue
            parts = line.split()
            # who output: "admin pts/0 2024-10-19 14:23 (10.0.0.100)"
            # parts[0] = user, parts[1] = terminal, parts[2] = date, parts[3] = time
            if len(parts) >= 3:
                user = parts[0]      # Column 0: username (e.g. "admin")
                line_id = parts[1]   # Column 1: terminal (e.g. "pts/0")
                # Login time is "YYYY-MM-DD HH:MM" spread across parts[2] and parts[3].
                # If only 3 parts (no time portion), use just parts[2].
                login_str = " ".join(parts[2:4]) if len(parts) >= 4 else parts[2]
                age_hours = session_age_from_login_time(login_str)
                # session_age_from_login_time: "2024-10-19 14:23" → hours since that time
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=age_hours if age_hours is not None else 0.0,
                    # Default 0.0 = treat as active if parse fails (conservative).
                ))
        return sessions
