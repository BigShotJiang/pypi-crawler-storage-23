"""
detect/aci_detector.py — NX-OS ACI Mode Heuristic Detection

WHY THIS EXISTS:
  Cisco Nexus switches can run in two fundamentally different modes:
    1. Standalone NX-OS: normal switch/router, fully auditable.
    2. ACI mode: the switch is managed by an APIC (Application Policy
       Infrastructure Controller) fabric controller.  In ACI mode,
       the switch's configuration is controlled entirely by the APIC.
       Running 'copy running-config startup-config' or other audit
       commands could interfere with ACI fabric operations.

  We detect ACI mode during detect phase and set aci_mode=True in
  detect_result.yml for those devices.  Audit mode skips them entirely.

DETECTION STRATEGY:
  Three heuristics are tried in order.  As soon as ANY confirms ACI mode,
  we return True immediately (short-circuit evaluation).  This avoids
  running unnecessary commands if the first check is conclusive.

  1. Keyword in show version output (already fetched — no extra command)
  2. APIC process in process table (one extra command)
  3. show system mode output (one extra command)

  If all three commands fail or return no match, we assume NOT ACI mode.
  False negatives (calling a real ACI switch "standalone") are unlikely
  because all three heuristics would have to fail simultaneously.
  False positives are also unlikely — these are ACI-specific signals.
"""

import logging
import re
from typing import Protocol  # Protocol: structural subtyping (duck typing interface)

logger = logging.getLogger(__name__)


class _HasSendCommand(Protocol):
    """
    Structural protocol matching any object with a send_command() method.

    WHY Protocol instead of BaseTransport?
    Using Protocol (duck typing) rather than importing BaseTransport avoids
    a circular import and makes the function more flexible — any object
    that has send_command(command, timeout) can be passed here, not just
    our specific transport classes.
    """
    def send_command(self, command: str, timeout: int = 30) -> str: ...


def is_aci_mode(transport: _HasSendCommand, show_version_output: str = "") -> bool:
    """
    Heuristic ACI detection for NX-OS devices.

    Called from detector.py after a device has been identified as NX-OS.
    Tries three signals in order and returns True as soon as any confirms.

    Args:
        transport:           An active SSH transport to the NX-OS device.
        show_version_output: The 'show version' output already fetched during
                             detection — reused here to avoid a redundant command.

    Returns:
        True if any heuristic confirms ACI mode, False otherwise.
    """

    # ── Heuristic 1: 'aci' keyword in show version ────────────────────────
    # NX-OS ACI builds include 'aci' in their software image filename.
    # Example: "system:    version 16.0(1h) [Feature Pack aci]"
    # Example image name: "nxos.9.3.10.aci.bin"
    # This is free because show version was already run during detection.
    if show_version_output and re.search(r"\baci\b", show_version_output, re.IGNORECASE):
        logger.info("ACI mode confirmed via show version output (aci keyword)")
        return True   # Short-circuit: no need to run more commands

    # ── Heuristic 2: APIC process in process table ────────────────────────
    # In ACI mode, NX-OS runs APIC-related management processes.
    # 'show system internal processes | grep apic' will return non-empty
    # output if any APIC process is running.
    # This command is NX-OS internal and may be unavailable on some versions;
    # any error is silently caught and we fall through to heuristic 3.
    try:
        out = transport.send_command(
            "show system internal processes | grep apic", timeout=20
            # timeout=20: shorter timeout — this is a quick in-memory process list check
        )
        if out and re.search(r"apic", out, re.IGNORECASE):
            logger.info("ACI mode confirmed via APIC process presence")
            return True
    except Exception as exc:
        # Command not supported on this NX-OS version, or pipe/grep failed.
        # Log at DEBUG (not WARNING) since this is an expected failure path
        # for standalone NX-OS devices.
        logger.debug("ACI heuristic #2 skipped (command error): %s", exc)

    # ── Heuristic 3: show system mode ────────────────────────────────────
    # On some NX-OS versions, 'show system mode' explicitly reports the mode.
    # Example output on ACI switch: "System Mode: ACI"
    # Falls through to here only if the first two heuristics were inconclusive.
    try:
        out = transport.send_command("show system mode", timeout=20)
        if out and re.search(r"\bACI\b", out, re.IGNORECASE):
            # \b word boundary ensures we match "ACI" as a whole word,
            # not as part of another word like "RACING".
            logger.info("ACI mode confirmed via 'show system mode'")
            return True
    except Exception as exc:
        logger.debug("ACI heuristic #3 skipped (command error): %s", exc)

    # All three heuristics were either negative or failed — assume standalone NX-OS.
    return False
