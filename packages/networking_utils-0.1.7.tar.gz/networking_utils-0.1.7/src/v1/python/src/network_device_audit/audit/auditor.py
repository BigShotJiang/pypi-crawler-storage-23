"""
audit/auditor.py — Per-Device Audit Orchestrator

This module is the main entry point for auditing a SINGLE device.
It is called once per device by main_audit.py's ThreadPoolExecutor.

WHAT IT DOES (in order):
  1. Look up the driver class for this device's platform from the registry
  2. Create a NetmikoTransport (SSH connection parameters)
  3. Connect to the device (with retry on failure)
  4. Enter enable mode if the platform requires it
  5. Check HA standby role (F5/Citrix only) — skip if this device is standby
  6. Run health checks: OS version, filesystem usage, fan status
  7. Run config audit: compare running vs startup, backup/save if needed
     (save only happens when change=True)
  8. Merge HA metadata from driver.get_ha_info() into the result (F5/Citrix)
  9. Disconnect and return AuditDeviceResult (always — never raises)

DESIGN PRINCIPLES:
  - audit_device() NEVER raises exceptions — all errors are caught and
    stored in AuditDeviceResult.error / AuditDeviceResult.status.
    This ensures a single device failure doesn't stop the entire audit.
  - transport.disconnect() is in a finally block — always called even
    if the audit itself fails partway through.
  - result.raw_log is set in finally — session log is always captured
    even if audit errors out.

HA STANDBY SKIP:
  For F5 and Citrix devices, auditor.py calls driver.is_ha_standby() after
  connecting.  If the device is a standby/secondary HA member, the audit
  is immediately marked SKIPPED and the thread exits.  The thread that
  audits the active/primary node is responsible for all config-save work on
  the HA group members (via new SSH connections opened inside the driver).
"""

import logging

from ..core.models import AuditDeviceResult, DeviceStatus, ConfigStatus
from ..core.exceptions import DeviceUnreachableError, EnableModeError
from ..core.retry import retry_call
from ..drivers.registry import get_driver_class
from ..transport.netmiko_transport import NetmikoTransport
from .config_audit import audit_config

logger = logging.getLogger(__name__)


def audit_device(
    hostname: str,
    ip: str,
    platform: str,
    netmiko_device_type: str,
    username: str,
    password: str,
    artifact_dir: str,
    port: int = 22,
    session_max_idle_hours: float = 12.0,
    filesystem_critical_pct: float = 70.0,
    change: bool = False,
) -> AuditDeviceResult:
    """
    Run full audit for a single device.  Returns AuditDeviceResult — never raises.

    Args:
        hostname:           Device hostname (from inventory). Used for logging,
                            backup filenames, and the audit result record.
        ip:                 IP address used for SSH connection (NOT hostname — avoids
                            DNS failures in environments with unreliable DNS).
        platform:           Platform label from detect_result.yml (e.g. "cisco_ios").
                            Used to look up the correct driver class in the registry.
        netmiko_device_type: Netmiko device_type string (e.g. "cisco_ios", "cisco_xe").
                            Used by Netmiko's ConnectHandler for platform-specific
                            prompt patterns and command handling.
        username:           SSH login username (from AWX credentials).
        password:           SSH login password (also used as enable secret if needed).
        artifact_dir:           AWX artifact directory where config backups and logs are saved.
                                Typically: /var/lib/awx/projects/<job_id>/artifacts/
        port:                   SSH port number (default 22; configurable for non-standard setups).
        session_max_idle_hours: Sessions idle less than this many hours are treated as active
                                and will block a config save (default 12).
                                Only evaluated when change=True.
        filesystem_critical_pct: Filesystem usage percentage above which the check is flagged
                                CRITICAL (default 70, meaning >70% = CRITICAL).
        change:                 If False (default), report config diffs but never save.
                                If True, save config when it's safe to do so (no active sessions).
                                Passed through to audit_config() and to HA-aware drivers.

    Returns:
        AuditDeviceResult with all audit findings. status field indicates overall outcome:
          SUCCESS:    Audit completed without errors
          UNREACHABLE: Could not SSH to device after retry
          SKIPPED:    HA standby node — skipped (active-node thread handles the group)
          ERROR:      Connected but audit encountered an exception
    """
    # Pre-populate result with error status — will be overwritten on success.
    # This ensures the result always has a valid status even if we return early.
    result = AuditDeviceResult(
        hostname=hostname,
        ip=ip,
        platform=platform,
        status=DeviceStatus.ERROR,  # Pessimistic default — overwritten to SUCCESS at end
    )

    # ── Step 1: Get driver class ──────────────────────────────────────────────
    try:
        driver_cls = get_driver_class(platform)
        # get_driver_class() looks up the platform label in the registry dict.
        # Returns the CLASS (not an instance) — e.g., CiscoIOSDriver.
    except KeyError:
        # Platform label from detect_result.yml not found in registry.
        # This can happen if detect_result.yml was written by a newer version
        # of the tool with a platform we haven't added to the registry yet.
        result.error = f"No driver registered for platform '{platform}'"
        return result   # Early return — no point trying to connect without a driver

    # ── Step 2: Create transport ──────────────────────────────────────────────
    transport = NetmikoTransport(
        hostname=ip,                         # Use IP (not DNS hostname) for reliability
        username=username,                   # SSH username from AWX credentials
        password=password,                   # SSH password from AWX credentials
        device_type=netmiko_device_type,     # Netmiko platform type (e.g. "cisco_xe")
        port=port,                           # SSH port (default 22)
        secret=password,                     # Enable secret = same as login password (common practice)
        # NOTE: secret defaults to password because most network devices use the same
        # password for both login and enable mode. If a device uses a different enable
        # password, this would need to be updated — but currently not in scope.
    )

    # ── Step 3: Connect to device (with retry) ────────────────────────────────
    try:
        retry_call(
            transport.connect,              # Function to retry
            attempts=3,                     # Try up to 3 times before giving up
            exceptions=(DeviceUnreachableError,),  # Only retry on SSH connection failures
            # NOT retried: EnableModeError, CommandTimeoutError — those are post-connection issues
        )
        # retry_call uses exponential backoff: immediate, 1s, 2s
        # WHY retry? Network devices can be temporarily unreachable due to:
        #   - CPU spikes causing SSH timeouts
        #   - Transient connectivity blips
        #   - VPN/management plane delays
    except DeviceUnreachableError as exc:
        # All 3 connection attempts failed — device is genuinely unreachable.
        result.status = DeviceStatus.UNREACHABLE
        result.error = str(exc)
        logger.warning("[%s] Unreachable: %s", hostname, exc)
        return result   # Early return — can't audit an unreachable device

    # ── Step 4: Instantiate driver ────────────────────────────────────────────
    driver = driver_cls(
        transport,
        filesystem_critical_pct=filesystem_critical_pct,
        username=username,
        password=password,
        port=port,
        # username / password / port are passed here so HA-capable drivers
        # (F5Driver, CitrixDriver) can open fresh SSH connections to peer devices
        # during save_config().  Non-HA drivers store but never use these values.
    )

    try:
        # ── Step 5: Enter enable mode if required ─────────────────────────────
        if driver.NEEDS_ENABLE:
            # NEEDS_ENABLE = True for: Cisco IOS, IOS-XE, IOS-XR, NX-OS
            # NEEDS_ENABLE = False for: JunOS, EOS, F5, Citrix, Dell OS10, Dell OS9, A10
            try:
                transport.enter_enable_mode()
                # Sends "enable" command + enable secret, waits for "#" prompt.
                # After this, privileged commands (show running-config etc.) are available.
            except EnableModeError as exc:
                # Enable mode failed but we continue (log warning, don't abort).
                # WHY not abort? Some commands might still work in exec mode.
                # The audit will proceed — any commands requiring privilege will fail individually.
                logger.warning("[%s] Enable mode failed: %s — continuing without it", hostname, exc)

        # ── Step 6: HA standby check (F5 / Citrix only) ──────────────────────
        try:
            if driver.is_ha_standby():
                # This device is an HA standby/secondary member.
                # The thread that audits the active/primary node handles all config-save
                # operations for the entire group (via new SSH connections to each member).
                # Nothing useful to audit here — mark as skipped and exit.
                logger.info(
                    "[%s] HA standby node detected — skipping audit (active node handles group)",
                    hostname,
                )
                result.status = DeviceStatus.SKIPPED
                result.error = "HA standby node — active node thread handles config save for this group"
                return result   # Early return from try block; finally still runs for disconnect
        except Exception as exc:
            # HA discovery failed (command error, parse error, etc.).
            # Safe failure: log the warning but continue treating device as active/standalone.
            # Better to audit a standby device than to silently skip an active one.
            logger.warning(
                "[%s] HA standby check failed (%s) — treating as active/standalone",
                hostname, exc,
            )
            # result.status remains ERROR at this point; will be overwritten to SUCCESS
            # if the rest of the audit completes successfully.

        # ── Step 7a: OS version check ─────────────────────────────────────────
        result.os_version = driver.get_os_version()
        # get_os_version() retries internally (via BaseDriver retry wrapper).
        # Returns version string (e.g. "15.9(3)M2") or None on failure.
        logger.info("[%s] OS version: %s", hostname, result.os_version)

        # ── Step 7b: Filesystem check ─────────────────────────────────────────
        result.filesystem = driver.check_filesystem()
        # check_filesystem() returns FilesystemResult with path, usage_pct, status.
        # Status: OK (<=filesystem_critical_pct%), CRITICAL (>threshold%), SKIPPED (parse failed)
        logger.info(
            "[%s] Filesystem %s: %s%% (%s)",
            hostname,
            result.filesystem.path,       # e.g. "flash:", "/var", "disk0:"
            result.filesystem.usage_pct,  # e.g. 65.0
            result.filesystem.status.value,  # e.g. "ok", "critical"
        )

        # ── Step 7c: Fan health check ─────────────────────────────────────────
        result.fans = driver.check_fans()
        # check_fans() returns list[FanResult] with fan_id and status (PASS/FAIL/NA).
        # NA = command not supported or virtual platform (no physical fans).
        for fan in result.fans:
            logger.info("[%s] Fan %s: %s", hostname, fan.fan_id, fan.status.value)

        # ── Step 7d: Config audit ─────────────────────────────────────────────
        backup_dir = f"{artifact_dir}/backups"
        # Backups go into a "backups" subdirectory of the artifact directory.
        # artifact_dir is provided by AWX (AWX_ARTIFACTS_DIR environment variable).
        # All files in artifact_dir are bundled into a .tar.gz by reporter.py.
        # NOTE: backup_dir is only used when change=True; config_audit.py never
        # creates the directory or writes any backup files when change=False.

        result.config = audit_config(
            driver,
            backup_dir=backup_dir,
            hostname=hostname,
            session_max_idle_hours=session_max_idle_hours,
            change=change,
            # change=False (default): diff is reported, no backup or save performed.
            # change=True: full remediation workflow (session check → backup → save → verify).
        )
        # audit_config() returns ConfigResult with one of these statuses:
        #   COMPLIANT          — no diff found
        #   REPORT_ONLY        — diff found, change=False (nothing written to device)
        #   SAVE_SKIPPED       — diff found, change=True, blocked by active session
        #   REMEDIATED         — diff found, change=True, saved and verified
        #   REMEDIATION_FAILED — diff found, change=True, save failed or verify failed
        #   HA_SYNC_ANOMALY    — F5/Citrix: auto-sync on but group is out of sync

        result.config_saved = result.config.status == ConfigStatus.REMEDIATED
        # config_saved = True only if save was executed AND verified successfully.
        # Used in reporter.py to list "devices where config was saved" in the summary.
        # Only possible when change=True.

        result.config_save_skipped = result.config.status == ConfigStatus.SAVE_SKIPPED
        # config_save_skipped = True if there were unsaved changes but an active session
        # prevented us from saving. Reported separately so ops team can follow up manually.
        # Only possible when change=True.

        result.config_report_only = result.config.status == ConfigStatus.REPORT_ONLY
        # config_report_only = True if unsaved changes were found but change=False.
        # This is the expected state in default (read-only) mode — it means the audit
        # found something actionable but didn't touch the device.

        # ── Step 8: Merge HA metadata ─────────────────────────────────────────
        ha_info = driver.get_ha_info()
        # get_ha_info() returns {} for all non-HA drivers.
        # For F5Driver and CitrixDriver it returns the dict populated by
        # _discover_ha() (called inside is_ha_standby() in Step 6 above).
        # NOTE: ha_config_saved_members is also set inside save_config() when
        # change=True, so it reflects the actual save results.

        if ha_info:
            # Write each HA field from the driver's cache into the audit result.
            # These appear as top-level fields in the per-device JSON output.
            result.ha_group               = ha_info.get("ha_group")
            result.ha_peer_ip             = ha_info.get("ha_peer_ip")
            result.ha_members             = ha_info.get("ha_members")
            result.ha_auto_sync           = ha_info.get("ha_auto_sync")
            result.ha_sync_enforced       = ha_info.get("ha_sync_enforced")
            result.ha_anomaly             = ha_info.get("ha_anomaly")
            result.ha_config_saved_members = ha_info.get("ha_config_saved_members")

        # ── All checks complete ───────────────────────────────────────────────
        result.status = DeviceStatus.SUCCESS
        # Only set SUCCESS after ALL checks complete without exception.
        # Any earlier exception will keep result.status = ERROR.

    except Exception as exc:
        # Catch-all for any unexpected error during the audit.
        # Examples: CommandTimeoutError on a slow device, SSH disconnection mid-audit,
        # regex error in a driver method, filesystem permission error in backup.
        result.status = DeviceStatus.ERROR
        result.error = str(exc)
        logger.error("[%s] Audit error: %s", hostname, exc, exc_info=True)
        # exc_info=True: includes the full stack trace in the log file.
        # This is essential for debugging driver bugs.
    finally:
        # ── Always capture session log and disconnect ─────────────────────────
        result.raw_log = transport.get_session_log()
        # get_session_log() returns the full record of all commands sent and
        # responses received. This is the raw SSH session log, stored in
        # "{hostname}_session.log" by reporter.py.
        # WHY in finally? Even if audit fails, the partial session log is valuable
        # for debugging (shows which command caused the error).

        transport.disconnect()
        # Close the SSH session. This is safe to call even if connect() failed
        # (NetmikoTransport.disconnect() checks if connected before disconnecting).
        # finally guarantees this runs even if an exception was raised.

    return result
