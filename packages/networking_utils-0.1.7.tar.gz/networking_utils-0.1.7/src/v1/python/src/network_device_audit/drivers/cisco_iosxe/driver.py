# ============================================================
# drivers/cisco_iosxe/driver.py — Cisco IOS-XE Driver
# ============================================================
# Covers: Cisco IOS-XE (Catalyst 9k series, ASR 1k series,
#         ISR 4k series, CSR 1000V virtual routers).
#
# IOS-XE is a newer, Linux-kernel-based Cisco OS that evolved
# from IOS.  The CLI is largely compatible with IOS but with
# differences in:
#   - Filesystem: disk0: instead of flash: (primary storage)
#   - Version string: "Cisco IOS XE Software" vs "Cisco IOS Software"
#   - Fan output format is similar to IOS
#   - Config save: still "write memory" (same as IOS)
#
# Key characteristics:
#   - Enable mode required (NEEDS_ENABLE = True)
#   - Filesystem: disk0: (non-Linux native storage)
#   - Config save: "write memory"
#   - Sessions: "show users" — same format as Cisco IOS
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class CiscoIOSXEDriver(BaseDriver):
    PLATFORM = "cisco_iosxe"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = True         # IOS-XE requires enable mode for privileged commands

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # IOS-XE version line: "Cisco IOS XE Software, Version 17.9.4a"
        # Note "XE" in the pattern — distinguishes from classic IOS pattern.
        m = re.search(r"Cisco IOS XE Software.*Version\s+([\w().]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("show disk0: | include bytes")
        # IOS-XE uses disk0: (not flash:) as the primary persistent storage device.
        # "show disk0: | include bytes" returns:
        #   "XXXXXXXXX bytes total (XXXXXXXXX bytes free)"
        # Same format as IOS's flash: output — pattern is identical.
        m = re.search(r"(\d+)\s+bytes total.*?(\d+)\s+bytes free", out, re.IGNORECASE)
        if m:
            total = int(m.group(1))
            free = int(m.group(2))
            used_pct = round((total - free) / total * 100, 1) if total else None
            return FilesystemResult(
                path="disk0:",           # IOS-XE primary storage (equivalent to /var on Linux)
                usage_pct=used_pct,
                status=self._filesystem_status(used_pct),
            )
        return FilesystemResult(path="disk0:", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # IOS-XE fan output format is similar to IOS:
        #   "Fan 1   OK"  or  "Fan 1   Normal"
        # On virtual IOS-XE (CSR 1000V) or some platforms, this command
        # returns "Invalid input" or "not supported".
        if not out or "invalid" in out.lower() or "not supported" in out.lower():
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            m = re.search(r"(Fan\s*\S+).*?(OK|Normal|Good|Failed|Absent|Not Present)", line, re.IGNORECASE)
            if m:
                status = FanStatus.PASS if re.search(r"OK|Normal|Good", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # timeout=60: Catalyst 9k configs can be large (spanning-tree, ACLs, QoS).
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # Same command as IOS — IOS-XE maintains backward CLI compatibility.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # "write memory" saves running config to startup config on IOS-XE.
        # Alternative: "copy running-config startup-config" — same effect.
        return self.transport.send_command("write memory", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # IOS-XE "show users" format is identical to classic IOS:
        #     Line       User       Host(s)              Idle          Location
        # *  2 vty 0     admin      idle                 00:05:23     10.0.0.100
        #    3 vty 1     ops        idle                 2d03h        10.0.0.101
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            if not line.strip() or "Line" in line:
                continue
            m = re.match(
                r"[\s*]*\d+\s+(vty\s*\d+|con\s*\d+|aux\s*\d+)\s+(\S+)\s+\S+\s+(\S+)",
                line, re.IGNORECASE,
            )
            if m:
                idle_hours = parse_hhmm_ss(m.group(3))
                sessions.append(SessionInfo(
                    user=m.group(2),           # m.group(2) = username
                    line=m.group(1).strip(),   # m.group(1) = line type (e.g. "vty 0")
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                ))
        return sessions
