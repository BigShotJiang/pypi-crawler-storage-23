# ============================================================
# drivers/cisco_ios/driver.py — Cisco IOS Driver
# ============================================================
# Covers: Classic Cisco IOS (Catalyst 2k, 3k, 4k switches;
#         legacy routers).  Also used for Catalyst switches
#         running traditional IOS (not IOS-XE).
#
# Key characteristics:
#   - Enable mode required (NEEDS_ENABLE = True)
#   - Filesystem: flash: (non-Linux; NOT /var)
#   - Config save: "write memory"
#   - Sessions: "show users" with HH:MM:SS / Xd YYh idle format
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss  # Shared idle-time parser


class CiscoIOSDriver(BaseDriver):
    PLATFORM = "cisco_ios"   # Must match the key in registry.py and detect_result.yml
    NEEDS_ENABLE = True      # IOS requires 'enable' before privileged commands work
                             # (show running-config, show startup-config)

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # "show version" on IOS returns a multi-line banner including:
        # "Cisco IOS Software, Version 15.9(3)M2, RELEASE SOFTWARE"
        m = re.search(r"Cisco IOS Software.*Version\s+([\w().]+)", out, re.IGNORECASE)
        # Group 1 captures the version string: e.g. "15.9(3)M2"
        return m.group(1) if m else out.splitlines()[0][:80]
        # Fallback: return the first line of output (up to 80 chars) if regex fails.
        # This handles non-standard IOS banners while still returning something useful.

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("show flash: | include bytes")
        # "show flash: | include bytes" filters the flash filesystem listing to
        # just the summary line, e.g.:
        #   "123456789 bytes total (98765432 bytes free)"
        # "| include bytes" is IOS's built-in output filter (similar to grep).
        # This avoids returning megabytes of file listing that we'd have to parse.
        #
        # NOTE: flash: is the IOS equivalent of /var on Linux-based platforms.
        # IOS doesn't have /var — its persistent storage is the flash filesystem.
        m = re.search(r"(\d+)\s+bytes total.*?(\d+)\s+bytes free", out, re.IGNORECASE)
        if m:
            total = int(m.group(1))   # Total flash capacity in bytes
            free = int(m.group(2))    # Available (unused) bytes
            # Calculate used percentage: (total - free) / total * 100
            # round(..., 1) for one decimal place (e.g. 48.3%)
            used_pct = round((total - free) / total * 100, 1) if total else None
            return FilesystemResult(
                path="flash:",          # The actual path checked on this platform
                usage_pct=used_pct,
                status=self._filesystem_status(used_pct),  # >70% = CRITICAL
            )
        # Could not parse the output (IOS variant without the "bytes" summary line)
        return FilesystemResult(path="flash:", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # "show environment fan" is the standard IOS command for fan status.
        # On modular chassis (Catalyst 4500/6500), it shows per-fan status.
        # On fixed-configuration switches (2960, 3750), it may report "not supported"
        # or return an "Invalid input" error — handled below.
        if not out or "invalid" in out.lower() or "not supported" in out.lower():
            # Command not supported on this IOS platform/version — return NA
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Parse lines like: "Fan 1   OK" or "Fan 2   Failed"
            m = re.search(r"(Fan\s*\S+).*?(OK|Normal|Good|Failed|Absent|Not Present)", line, re.IGNORECASE)
            if m:
                # Group 1: fan identifier (e.g. "Fan 1", "Fan 1/1")
                # Group 2: status keyword
                status = FanStatus.PASS if re.search(r"OK|Normal|Good", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        # If no fan lines matched, return NA rather than an empty list
        # (empty list would look like "no fans checked" in reports)
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # timeout=60: large configs on IOS devices can take 30-60s to output fully.
        # The default 30s timeout is not enough for devices with thousands of lines.
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # "show startup-config" reads from NVRAM (what gets loaded on next boot).
        # We compare this against running config to detect unsaved changes.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # "write memory" (alias: "copy running-config startup-config") saves the
        # running config to NVRAM.  This is the standard IOS save command.
        # After this, running config and startup config should be identical.
        return self.transport.send_command("write memory", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # "show users" on Cisco IOS output example:
        #     Line       User       Host(s)              Idle          Location
        # *  2 vty 0     admin      idle                 00:05:23     10.0.0.100
        #    3 vty 1     ops        idle                 2d03h        10.0.0.101
        #
        # The * indicates the current session (our own SSH session).
        # Columns: line_number line_type user host idle location
        # Idle format: HH:MM:SS (e.g. 00:05:23) or shorthand (e.g. 2d03h, 1w2d)
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip the header row and blank lines
            if not line.strip() or "Line" in line:
                continue
            # Regex captures: line type (vty/con/aux + number), username, idle time
            # [\s*]* matches optional leading spaces and the current-session asterisk
            # \d+ matches the line number
            m = re.match(
                r"[\s*]*\d+\s+(vty\s*\d+|con\s*\d+|aux\s*\d+)\s+(\S+)\s+\S+\s+(\S+)",
                line, re.IGNORECASE,
            )
            if m:
                line_id = m.group(1).strip()   # e.g. "vty 0", "con 0"
                user = m.group(2)              # e.g. "admin"
                idle_str = m.group(3)          # e.g. "00:05:23", "2d03h"
                idle_hours = parse_hhmm_ss(idle_str)
                # parse_hhmm_ss converts "00:05:23" → 0.09h, "2d03h" → 51h, etc.
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 if parsing fails — conservative (triggers save skip)
                ))
        return sessions
