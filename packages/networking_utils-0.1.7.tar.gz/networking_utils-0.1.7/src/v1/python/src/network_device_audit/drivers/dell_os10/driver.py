# ============================================================
# drivers/dell_os10/driver.py — Dell OS10 Driver
# ============================================================
# Covers: Dell EMC PowerSwitch S-series (S5248F, S5296F, etc.),
#         Z-series, and other Dell switches running OS10.
#
# Dell OS10 is Linux-based (built on Debian Linux with a custom
# network application layer). It's significantly different from
# the older Dell OS9 / FTOS (which was non-Linux).
#
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     OS10 puts users directly into a privileged CLI.
#   - Filesystem: Linux /var — BUT requires "system bash" prefix
#     to run Linux commands within the OS10 CLI (similar to
#     Arista's "bash" prefix). Raw Linux shell commands are not
#     available directly in the OS10 CLI without this prefix.
#   - Config save: "copy running-configuration startup-configuration"
#     (note: OS10 uses "configuration" not "config" as keyword)
#   - Sessions: "show users" in IOS-XE-like format (vty lines)
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class DellOS10Driver(BaseDriver):
    PLATFORM = "dell_os10"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False      # OS10: privileged CLI without enable mode

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # OS10 version line: "OS Version: 10.5.3.2"
        # Pattern: "OS Version:" followed by the version number.
        m = re.search(r"OS Version:\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("system bash df -h /var 2>/dev/null")
        # COMMAND EXPLANATION:
        # "system bash" prefix: required on OS10 to run Linux shell commands.
        # OS10 CLI is a custom shell; "system bash" spawns a bash subshell.
        # Similar to Arista's "bash" prefix.
        #
        # "df -h /var": standard POSIX df showing /var filesystem usage.
        # -h = human-readable sizes.
        #
        # "2>/dev/null": suppresses error output if /var isn't a separate mount.
        #
        # Note: unlike Arista, we don't need "|| echo 'not found'" because
        # "2>/dev/null" is sufficient — df failure produces no output.
        if not out or "not found" in out.lower():
            # df returned no output or "not found" — /var may not be separately mounted.
            return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                # Matches the "Use%" percentage column in df output.
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var",                            # Path checked
                        usage_pct=pct,
                        status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL
                    )
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # "show environment fan" is supported on OS10 (same syntax as Cisco IOS).
        # OS10 fan status keywords include multi-word phrases like "present and operating".
        #
        # Example output:
        #   Fan Tray 1/1: present and operating
        #   Fan Tray 1/2: absent
        #   Fan Tray 2/1: failed
        if not out or "invalid" in out.lower():
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: "Fan <identifier>" followed by status.
            # OS10 status words:
            #   "present and operating" = healthy (multi-word!)
            #   "absent" or "failed" = problem
            #   "ok" = alternate healthy status on some OS10 versions
            m = re.search(r"(Fan\s*[\w/-]+).*?(present and operating|absent|failed|ok)", line, re.IGNORECASE)
            if m:
                # "operating", "ok", and "present" (part of "present and operating") = PASS
                status = FanStatus.PASS if re.search(r"operating|ok|present", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # NOTE: OS10 uses "show running-configuration" (full word "configuration")
        # NOT "show running-config" (abbreviated "config" as on IOS/IOS-XE).
        # This is a key CLI difference between OS10 and Cisco-style platforms.
        # timeout=60: large OS10 configs can be slow.
        return self.transport.send_command("show running-configuration", timeout=60)

    def _get_startup_config(self) -> str:
        # Same note as running-configuration — OS10 uses full word "configuration".
        return self.transport.send_command("show startup-configuration", timeout=60)

    def _save_config(self) -> str:
        # OS10 save command:
        # "copy running-configuration startup-configuration"
        # Note: both keywords are "configuration" (not abbreviated "config").
        # This saves running config to startup config (survives reboot).
        return self.transport.send_command("copy running-configuration startup-configuration", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # Dell OS10 show users is similar to IOS-XE format:
        #     Line       User       Host(s)              Idle          Location
        # *  2 vty 0     admin      idle                 00:05:23     10.0.0.100
        #    3 vty 1     ops        idle                 2d03h        10.0.0.101
        #
        # The format matches classic Cisco IOS/IOS-XE "show users" output.
        # Header check: skip lines starting with "Line" or "User".
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and header rows (start with "Line" or "User").
            if not line.strip() or re.match(r"\s*(Line|User)", line, re.IGNORECASE):
                continue
            # Regex: same pattern as Cisco IOS — handles optional asterisk (current session).
            m = re.match(
                r"[\s*]*\d+\s+(vty\s*\d+|con\s*\d+)\s+(\S+)\s+\S+\s+(\S+)",
                line, re.IGNORECASE,
            )
            if m:
                idle_hours = parse_hhmm_ss(m.group(3))
                # parse_hhmm_ss handles: "00:05:23" → 0.09h, "2d03h" → 51.0h
                sessions.append(SessionInfo(
                    user=m.group(2),           # m.group(2) = username
                    line=m.group(1).strip(),   # m.group(1) = line type (e.g. "vty 0")
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                ))
        return sessions
