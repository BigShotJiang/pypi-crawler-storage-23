# ============================================================
# drivers/dell_os9/driver.py — Dell OS9 / FTOS Driver
# ============================================================
# Covers: Dell Force10 switches running OS9 (FTOS = Force10 OS).
#         Older Dell/Force10 hardware: S-series, Z-series, C-series
#         running the legacy OS9 platform (NOT OS10).
#
# Dell OS9 (FTOS) is NOT Linux-based — it's a proprietary OS
# inherited from the Force10 Networks acquisition. This makes it
# fundamentally different from OS10 (which IS Linux-based).
#
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     FTOS puts users in exec mode on login; no "enable" command.
#   - Filesystem: flash: (non-Linux storage — same concept as IOS)
#     "show file-systems" shows flash: total/free bytes.
#     There is NO /var because FTOS is not Linux — it uses
#     a proprietary flash filesystem (similar to Cisco IOS flash:).
#   - Config save: "copy running-config startup-config"
#     (uses abbreviated "config" like Cisco IOS, unlike Dell OS10)
#   - Version: "FTOS Version X.X" or "OS Version: X.X" depending
#     on FTOS version and hardware model
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class DellOS9Driver(BaseDriver):
    """Dell OS9 / FTOS (Force10 Operating System) driver."""
    PLATFORM = "dell_os9"    # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False      # FTOS: exec mode on login, no enable needed

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # FTOS version formats (varies by model/version):
        #   Format 1 (older FTOS): "FTOS Version 9.14.2.10"
        #   Format 2 (newer FTOS): "OS Version: 9.14.2.10"
        # Try "FTOS Version" first (older format).
        m = re.search(r"FTOS\s+Version\s+([\w.]+)", out, re.IGNORECASE)
        if not m:
            # Fall back to "OS Version:" format (newer FTOS versions).
            m = re.search(r"OS\s+Version:\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        # FTOS uses flash filesystem; /var equivalent is flash:
        # IMPORTANT: FTOS is NOT Linux — there is no /var or df command.
        # "show file-systems" is the FTOS command to view flash storage.
        out = self.transport.send_command("show file-systems")
        # "show file-systems" output example:
        #   File System    Size(b)     Free(b)    Type    Flags  Prefixes
        #   flash:         524288000   123456789  flash   rw     flash:
        #   slot0:         2147483648  987654321  flash   ro     slot0:
        #
        # Pattern: "flash:" followed by total bytes and free bytes.
        # re.DOTALL not needed since we're searching across the line, not multiline.
        m = re.search(r"flash:.*?(\d+)\s+(\d+)", out, re.IGNORECASE)
        if m:
            total = int(m.group(1))   # Total flash capacity in bytes
            free = int(m.group(2))    # Available (free) bytes
            # Calculate used percentage: (total - free) / total * 100
            # round(..., 1) for one decimal place (e.g. 76.5%)
            used_pct = round((total - free) / total * 100, 1) if total else None
            return FilesystemResult(
                path="flash:",                          # Non-Linux flash storage (not /var)
                usage_pct=used_pct,
                status=self._filesystem_status(used_pct),   # PASS/WARNING/CRITICAL
            )
        # If "show file-systems" doesn't include flash: or can't be parsed.
        return FilesystemResult(path="flash:", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # "show environment fan" on FTOS shows per-fan module status.
        # FTOS fan status keywords:
        #   "present" = fan module is physically present (healthy)
        #   "absent"  = fan module removed (problem)
        #   "failed"  = fan hardware failure
        #   "ok"      = alternate healthy status on some FTOS versions
        if not out or "invalid" in out.lower():
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: "Fan <identifier>" followed by status keyword.
            m = re.search(r"(Fan\s*[\w/-]+).*?(present|absent|failed|ok)", line, re.IGNORECASE)
            if m:
                # "present" and "ok" = healthy; "absent" and "failed" = problem
                status = FanStatus.PASS if re.search(r"present|ok", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # FTOS uses abbreviated "running-config" (not "running-configuration" like OS10).
        # This is the Cisco-style CLI convention from Force10's design.
        # timeout=60: large FTOS configs on aggregation switches can be slow.
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # "show startup-config" shows what's stored in NVRAM (loaded on next boot).
        # Same abbreviated "config" keyword as running-config.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # FTOS save command uses Cisco-style abbreviated "config":
        # "copy running-config startup-config"
        # (NOT "copy running-configuration startup-configuration" like Dell OS10)
        # This saves the running config to NVRAM (startup config).
        return self.transport.send_command("copy running-config startup-config", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # FTOS show users format is similar to IOS:
        #     Line       User       Host(s)              Idle          Location
        # *  2 vty 0     admin      idle                 00:05:23     10.0.0.100
        #    3 vty 1     ops        idle                 2d03h        10.0.0.101
        #
        # Header check: skip lines starting with "Line" or "User".
        # Asterisk (*) marks the current session (our SSH connection).
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and header rows.
            if not line.strip() or re.match(r"\s*(Line|User)", line, re.IGNORECASE):
                continue
            # Same regex as Cisco IOS — FTOS "show users" format is compatible.
            # [\s*]* handles optional asterisk for current session.
            m = re.match(
                r"[\s*]*\d+\s+(vty\s*\d+|con\s*\d+)\s+(\S+)\s+\S+\s+(\S+)",
                line, re.IGNORECASE,
            )
            if m:
                idle_hours = parse_hhmm_ss(m.group(3))
                # parse_hhmm_ss handles: "00:05:23" → 0.09h, "2d03h" → 51.0h
                sessions.append(SessionInfo(
                    user=m.group(2),           # m.group(2) = username
                    line=m.group(1).strip(),   # m.group(1) = line type (e.g. "vty 0")
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                ))
        return sessions
