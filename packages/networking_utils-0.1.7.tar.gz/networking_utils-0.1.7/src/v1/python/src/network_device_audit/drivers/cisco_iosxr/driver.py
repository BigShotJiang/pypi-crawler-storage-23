# ============================================================
# drivers/cisco_iosxr/driver.py — Cisco IOS-XR Driver
# ============================================================
# Covers: Cisco IOS-XR (ASR 9000, NCS series, CRS routers).
#
# IOS-XR is a fundamentally different OS from classic IOS/IOS-XE:
#   - Linux-kernel-based (not the proprietary IOS kernel)
#   - Uses a "commit" model for config changes (like Juniper)
#     rather than the live "write memory" model of IOS/IOS-XE
#   - Filesystem IS Linux /var (not flash: or disk0:)
#   - Running vs startup distinction: "committed" config = what
#     gets loaded on next reboot (equivalent to startup config)
#   - Separate config namespace: every change must be explicitly
#     committed; uncommitted changes are in a "candidate config"
#
# Key differences from IOS/IOS-XE:
#   - No "write memory" — save is done with "commit"
#   - Startup config equivalent: "show running-config commit"
#     (the last committed version, what boots from)
#   - Filesystem check: df -h /var (standard Linux command)
#   - Sessions: "show users" format is similar to IOS
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class CiscoIOSXRDriver(BaseDriver):
    PLATFORM = "cisco_iosxr"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = True         # IOS-XR requires enable mode for privileged show commands

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # IOS-XR version line: "Cisco IOS XR Software, Version 7.5.2"
        # Pattern searches for "Cisco IOS XR Software" (distinguishes from IOS and IOS-XE)
        # then captures the version string after "Version ".
        m = re.search(r"Cisco IOS XR Software.*Version\s+([\w().]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]
        # Fallback: first line of output, truncated to 80 chars.

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("df -h /var")
        # IOS-XR is Linux-based, so standard POSIX 'df' command works.
        # 'df -h /var' checks the /var filesystem specifically.
        # -h flag: human-readable sizes (K, M, G) — but we only need the % column.
        #
        # Example output:
        #   Filesystem      Size  Used Avail Use% Mounted on
        #   /dev/sda4        20G   12G  6.5G  65% /var
        #
        # We filter lines containing "/var" or the header "Filesystem".
        # The header check is just for reference; we only parse data lines.
        lines = [l for l in out.splitlines() if "/var" in l or "Filesystem" in l]
        for line in lines:
            m = re.search(r"(\d+)%", line)
            # Matches the "Use%" column, e.g. "65%".
            # The % is always adjacent to its digit with no space in df output.
            if m:
                pct = float(m.group(1))
                return FilesystemResult(
                    path="/var",                            # Actual path checked on this OS
                    usage_pct=pct,                          # e.g. 65.0
                    status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL threshold check
                )
        # If df output couldn't be parsed (e.g., /var doesn't exist as a separate mount),
        # return SKIPPED rather than failing the audit.
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # "show environment fan" reports fan hardware status on IOS-XR.
        # On virtual IOS-XR (e.g., XRv9000 simulation), this command may return
        # "invalid input" — handled below.
        if not out or "invalid" in out.lower():
            # Command not supported on this platform/version — return NA.
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Parse lines like: "Fan 0/0    Normal" or "Fan 0/1    Failed"
            # IOS-XR uses "Normal" for healthy fans (vs "OK" or "Good" on other platforms).
            m = re.search(r"(Fan\s*\S+).*?(Normal|OK|Good|Failed|Not Present)", line, re.IGNORECASE)
            if m:
                # Group 1: fan identifier (e.g. "Fan 0/0")
                # Group 2: status keyword
                status = FanStatus.PASS if re.search(r"Normal|OK|Good", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]
        # Return NA if no fan lines were matched (prevents empty list in reports).

    def _get_running_config(self) -> str:
        # "show running-config" on IOS-XR shows the candidate/active configuration
        # (the live config currently applied — NOT the committed/startup version).
        # timeout=60: IOS-XR configs can be large on ASR 9000 (complex MPLS/segment routing).
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # IOS-XR COMMIT MODEL EXPLANATION:
        # Unlike IOS/IOS-XE where "write memory" saves to NVRAM startup config,
        # IOS-XR uses a two-phase commit model:
        #   1. Edit commands go into a "candidate configuration" (uncommitted)
        #   2. "commit" makes the candidate become the running config AND persists it
        #
        # "show running-config commit" shows the LAST COMMITTED configuration,
        # which is what the router would boot with on next reload.
        # This is the IOS-XR equivalent of "show startup-config" on classic IOS.
        #
        # Note: On some IOS-XR versions this command may not exist.
        # In that case, audit mode logs the error and treats configs as differing.
        return self.transport.send_command("show running-config commit", timeout=60)

    def _save_config(self) -> str:
        # IOS-XR SAVE = COMMIT:
        # There is no "write memory" on IOS-XR.
        # "commit" atomically applies the candidate configuration AND makes it
        # persistent (survives reboot). This replaces both "write memory" and
        # "copy running-config startup-config" from IOS/IOS-XE.
        #
        # If there are no pending changes in the candidate config, "commit"
        # returns quickly with "No configuration changes to commit."
        # BaseDriver.save_config() treats any non-exception return as success.
        return self.transport.send_command("commit", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # IOS-XR "show users" format is very similar to classic IOS:
        #     Line       User       Host(s)              Idle          Location
        # *  2 vty 0     admin      idle                 00:05:23     10.0.0.100
        #    3 vty 1     ops        idle                 2d03h        10.0.0.101
        #
        # The asterisk (*) marks our current session.
        # Idle format: HH:MM:SS or shorthand like "2d03h", "1w2d".
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and the header row.
            if not line.strip() or "Line" in line:
                continue
            # Regex captures line type (vty/con/aux + number), username, idle time.
            # [\s*]* matches optional leading whitespace and the asterisk (current session marker).
            m = re.match(
                r"[\s*]*\d+\s+(vty\s*\d+|con\s*\d+|aux\s*\d+)\s+(\S+)\s+\S+\s+(\S+)",
                line, re.IGNORECASE,
            )
            if m:
                idle_hours = parse_hhmm_ss(m.group(3))
                # parse_hhmm_ss: converts "00:05:23" → 0.09h, "2d03h" → 51.0h, etc.
                sessions.append(SessionInfo(
                    user=m.group(2),           # m.group(2) = username (e.g. "admin")
                    line=m.group(1).strip(),   # m.group(1) = line type (e.g. "vty 0")
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 if parsing fails — conservative: treats session as active,
                    # which will cause save_config() to skip saving (safe behavior).
                ))
        return sessions
