# ============================================================
# drivers/cisco_nxos/driver.py — Cisco NX-OS Driver
# ============================================================
# Covers: Cisco Nexus 9000, 7000, 5000 series (standalone mode).
#         NOT used for ACI mode — ACI devices are detected by
#         aci_detector.py and SKIPPED entirely during audit.
#
# NX-OS is a Linux-kernel-based OS (evolved from SAN-OS).
# Key characteristics:
#   - Enable mode required (NEEDS_ENABLE = True)
#   - Filesystem: Linux /var (df -h /var — NOT flash: or disk0:)
#   - Config save: "copy running-config startup-config" (same as
#     IOS-XE/EOS — not "write memory" like classic IOS/IOS-XR)
#   - Sessions: "show users" but with a different column layout
#     than classic IOS (NAME/LINE/TIME/IDLE format)
#   - Version string: "NXOS: version X.X" or "system: version X.X"
#     (two different formats across NX-OS versions/platforms)
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class CiscoNXOSDriver(BaseDriver):
    PLATFORM = "cisco_nxos"   # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = True        # NX-OS requires 'enable' before privileged commands

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # NX-OS has TWO version string formats depending on platform/version:
        #   Nexus 9000 (newer):  "NXOS: version 9.3(10)"
        #   Nexus 7000 (older):  "system:    version 8.4(4)"
        # We try the newer NXOS format first, fall back to "system:" format.
        m = re.search(r"NXOS:\s+version\s+([\w().]+)", out, re.IGNORECASE)
        if not m:
            # Older NX-OS (7000 series) uses "system: version" label.
            m = re.search(r"system:\s+version\s+([\w().]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]
        # Fallback: return first line of output up to 80 chars if neither regex matches.

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("df -h /var")
        # NX-OS runs a Linux kernel, so standard POSIX df is available.
        # 'df -h /var' shows disk usage for the /var partition.
        # -h = human-readable sizes (shows M, G units) but we only read the % column.
        #
        # Example output:
        #   Filesystem      Size  Used Avail Use% Mounted on
        #   /dev/mapper/vg0  15G   9G   5G   65% /var
        #
        # We look specifically for the line containing "/var" to find the data row.
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                # Matches the "Use%" percentage column, e.g. "65%".
                # The percent sign is always adjacent to the digits in df output.
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var",                            # Actual path checked
                        usage_pct=pct,                          # e.g. 65.0
                        status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL
                    )
        # If no "/var" line found or df failed, return SKIPPED.
        # This can happen on virtualized Nexus or unsupported versions.
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment fan")
        # "show environment fan" on NX-OS reports per-fan status.
        # On virtual Nexus (NX-OSv), the command may return "invalid input".
        if not out or "invalid" in out.lower():
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # NX-OS fan output format (Nexus 9000 example):
            #   Fan 1/1    Ok
            #   Fan 1/2    Fail
            #   Fan 2/1    Absent
            # Note: NX-OS uses "Ok" (not "OK") for fan status — case-insensitive match handles both.
            # Fan identifiers can include rack/slot notation like "Fan 1/1".
            m = re.search(r"(Fan\s*[\w/]+).*?(Ok|Fail|Absent)", line, re.IGNORECASE)
            if m:
                # "Ok" = healthy, "Fail" or "Absent" = problem
                status = FanStatus.PASS if re.search(r"Ok", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # "show running-config" on NX-OS shows the currently active configuration.
        # timeout=60: Nexus configs can be very large (hundreds of port-channels,
        # VLAN configs, QoS policies, etc. on 9500-series aggregation switches).
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # "show startup-config" shows what will be loaded on next reboot.
        # If running != startup, there are unsaved changes that would be lost on reload.
        # timeout=60: same reason as running-config — can be large.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # NX-OS DOES NOT use "write memory" (that's classic IOS/IOS-XR).
        # On NX-OS, the correct save command is:
        #   "copy running-config startup-config"
        # This copies the current running config to the startup config file.
        # After this command, running == startup — no unsaved changes remain.
        return self.transport.send_command("copy running-config startup-config", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # NX-OS "show users" has a DIFFERENT format than classic IOS.
        # NX-OS format:
        #   NAME    LINE         TIME             IDLE          PID COMMENT
        #   admin   pts/0        Oct 19 14:23    00:00:05     12345
        #   ops     pts/1        Oct 19 08:00    02:00:30     12346
        #
        # Column layout (space-separated):
        #   [0] NAME  = username
        #   [1] LINE  = terminal (e.g. "pts/0" = SSH session)
        #   [2] TIME  = login time (date, e.g. "Oct")
        #   [3] TIME  = login time (continued, e.g. "19")
        #   ... this depends on how TIME is formatted; IDLE is parsed by index
        #   [3] IDLE  = idle duration (HH:MM:SS format)
        #
        # Note: parts[3] = IDLE because the TIME value is "Oct 19 14:23" = 3 tokens,
        # pushing IDLE to index [3] only when TIME fits in 1 token (like "Oct" alone).
        # The comment in the original code references index 3 as IDLE — this is
        # platform-specific and was confirmed from NX-OS documentation.
        out = self.transport.send_command("show users")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and the header row (starts with "NAME").
            if not line.strip() or re.match(r"\s*NAME", line, re.IGNORECASE):
                continue
            parts = line.split()
            # Need at least 4 columns to have user, line, time, idle.
            if len(parts) >= 4:
                user = parts[0]      # Column 0: username
                line_id = parts[1]   # Column 1: terminal (e.g. "pts/0")
                # Column 3: IDLE duration in HH:MM:SS format.
                # The TIME column (login date) is columns 2 and beyond until IDLE.
                idle_str = parts[3]
                idle_hours = parse_hhmm_ss(idle_str)
                # parse_hhmm_ss converts "00:00:05" → 0.0014h, "02:00:30" → 2.008h, etc.
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 = treat as active (conservative — prevents accidental saves).
                ))
        return sessions
