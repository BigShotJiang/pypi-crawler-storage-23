# ============================================================
# transport/base.py — Abstract SSH Transport Interface
# ============================================================
# Defines the interface that ALL transport implementations must
# satisfy.  There are two concrete implementations:
#
#   NetmikoTransport  — primary; used for all audit operations.
#                       Netmiko knows each platform's paging
#                       commands, enable prompts, and command
#                       terminators, so it handles protocol details
#                       automatically.
#
#   ParamikoTransport — fallback; used ONLY during detect mode
#                       when Netmiko SSHDetect fails.  Opens a raw
#                       interactive shell and sends show version for
#                       fingerprinting.  Read-only; not used in audit.
#
# WHY abstract base class (ABC)?
#   - Enforces that every subclass implements connect(), disconnect(),
#     send_command(), and is_connected() or Python raises a TypeError
#     at instantiation time — not at runtime when the method is called.
#   - Audit drivers and orchestrators depend ONLY on BaseTransport's
#     interface (not on Netmiko or Paramiko directly).  This separation
#     means swapping the SSH library only requires a new transport class,
#     not changes to any driver or audit logic.
# ============================================================

from abc import ABC, abstractmethod  # ABC: marks class as abstract; abstractmethod: enforces override
from typing import Optional          # Optional[T] = T | None (not used directly here but
                                     # kept for consistency with other core modules)


class BaseTransport(ABC):
    """Abstract SSH transport that all concrete transports must implement."""

    def __init__(self, hostname: str, username: str, password: str, port: int = 22):
        # Store connection parameters as instance attributes so subclass
        # connect() methods can use them without re-accepting as arguments.
        self.hostname = hostname      # Device hostname or IP (used in log messages and SSH target)
        self.username = username      # SSH login username (from AWX machine credential)
        self.password = password      # SSH login password (from AWX machine credential)
        self.port = port              # SSH port; default 22, configurable for non-standard setups
        self._session_log: list[str] = []
        # Accumulates a chronological record of every command sent and
        # every device response during this SSH session.  Retrieved via
        # get_session_log() and written to <hostname>_session.log in the
        # artifact bundle for post-job debugging.

    @abstractmethod
    def connect(self) -> None:
        """
        Open the SSH connection to the device.

        Implementations MUST raise DeviceUnreachableError (not a
        library-specific exception like NetmikoTimeoutException) if
        the connection cannot be established.  This normalizes error
        handling — the retry layer catches DeviceUnreachableError
        regardless of which transport is in use.
        """

    @abstractmethod
    def disconnect(self) -> None:
        """
        Close the SSH connection cleanly.

        MUST be idempotent — safe to call multiple times or when not
        connected (e.g. from a finally block and again from __exit__).
        Silently ignore errors from the underlying library on close.
        """

    @abstractmethod
    def send_command(self, command: str, timeout: int = 30) -> str:
        """
        Send a CLI command to the device and return the response as a string.

        Args:
            command: The command string (e.g. "show version", "show running-config").
            timeout: Seconds to wait for the device to finish responding.
                     Long commands (show running-config on large devices) need
                     longer timeouts — callers pass timeout=60 or timeout=90.

        Returns:
            Device response text with the command echo and trailing prompt stripped
            (Netmiko does this automatically; Paramiko's heuristic reader does it
            approximately).

        Raises:
            DeviceUnreachableError: if the transport is not connected.
            CommandTimeoutError:    if the device doesn't respond within timeout.
        """

    @abstractmethod
    def is_connected(self) -> bool:
        """
        Return True if the underlying SSH connection object is active.

        Used by send_command() to raise a meaningful DeviceUnreachableError
        instead of a cryptic AttributeError if called on a disconnected transport.
        """

    def get_session_log(self) -> str:
        """
        Return the full session log as a single multi-line string.

        The log contains every command sent (prefixed with '>>>') and
        every response, in chronological order.  Used by auditor.py to
        populate AuditDeviceResult.raw_log, which is then written to
        <hostname>_session.log in the artifact .tar.gz.
        """
        return "\n".join(self._session_log)

    def _log(self, entry: str) -> None:
        """
        Append an entry to the internal session log.

        Called internally by concrete transport implementations each time
        a command is sent or a notable event occurs (connect, enable mode).
        Kept private (_log) because external code should use get_session_log()
        to read, not to write.
        """
        self._session_log.append(entry)

    # ── Context manager protocol ───────────────────────────────────────────
    # Enables use with Python's 'with' statement:
    #
    #   with NetmikoTransport(...) as t:
    #       t.send_command("show version")
    #   # t.disconnect() is called automatically here — even on exception
    #
    # This guarantees sessions are always closed, preventing SSH session
    # leaks on the device which could fill the device's vty line table.

    def __enter__(self):
        self.connect()  # Open the SSH session when entering the 'with' block
        return self     # The 'as' variable is bound to this transport instance

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()   # Always close, even if an exception occurred in the block
        return False        # Return False to let exceptions propagate normally
                            # (returning True would suppress them)
