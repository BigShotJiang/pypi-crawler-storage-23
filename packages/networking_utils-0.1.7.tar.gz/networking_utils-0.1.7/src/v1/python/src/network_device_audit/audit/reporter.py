"""
audit/reporter.py — Artifact Reporter

Writes audit and detect results to disk and bundles them into a .tar.gz
for AWX artifact upload. This module handles ALL file output from the tool.

OUTPUT STRUCTURE (audit mode):
  <artifact_dir>/
    devices/
      sw-core-01_audit_result.json   # Per-device audit findings
      sw-core-01_session.log         # Raw SSH session log for that device
      fw-edge-01_audit_result.json
      fw-edge-01_session.log
      ...
    backups/
      sw-core-01_startup_backup.txt  # Config backup (created by config_audit.py)
      ...
    audit_summary.json               # Aggregate counters for all devices
    audit_<job_id>_<timestamp>.tar.gz  # Everything bundled for download

OUTPUT STRUCTURE (detect mode):
  <artifact_dir>/
    session_logs/
      sw-core-01_detect_session.log
      ...
    detect_summary.json
    detect_<job_id>_<timestamp>.tar.gz

WHY .tar.gz?
AWX's artifact storage can accept .tar.gz files as a single upload.
Bundling all per-device files makes it easy to download the complete
audit in one click from the AWX UI.
"""

import json
import logging
import os
import tarfile                          # Python standard library for creating .tar.gz archives
from dataclasses import asdict          # Converts dataclass instances to plain dicts for JSON
from datetime import datetime, timezone # For UTC timestamp in bundle filename
from pathlib import Path                # Cross-platform path manipulation
from typing import Union

from ..core.models import (
    AuditDeviceResult,
    DetectDeviceResult,
    AuditSummary,
    DetectSummary,
    DeviceStatus,
    FilesystemStatus,
    FanStatus,
    ConfigStatus,
)

logger = logging.getLogger(__name__)


# ── Detect reporting ──────────────────────────────────────────────────────────

def write_detect_results(
    results: list[DetectDeviceResult],
    artifact_dir: str,
    job_id: str,
) -> str:
    """
    Write per-device session logs, build summary, and return the .tar.gz path.

    Called by main_detect.py after all devices have been detected.

    Args:
        results:      List of DetectDeviceResult objects (one per device).
        artifact_dir: AWX artifact directory (AWX_ARTIFACTS_DIR environment variable).
        job_id:       AWX job ID (AWX_JOB_ID environment variable). Used in filename.

    Returns:
        Path to the .tar.gz archive containing all detect artifacts.
    """
    Path(artifact_dir).mkdir(parents=True, exist_ok=True)
    # Create artifact_dir if it doesn't exist.
    # parents=True: create intermediate directories.
    # exist_ok=True: no error if it already exists.

    _write_session_logs(results, artifact_dir, mode="detect")
    # Write per-device SSH session logs to artifact_dir/session_logs/.

    summary = _build_detect_summary(results)
    # Build aggregate counters: total, identified, unknown, unreachable, aci_mode.

    summary_path = _write_json(
        {"job_id": job_id, "mode": "detect", "summary": asdict(summary)},
        os.path.join(artifact_dir, "detect_summary.json"),
    )
    # asdict(summary): converts DetectSummary dataclass to a plain dict for JSON serialization.
    # The JSON includes job_id and mode for traceability (which job produced this file).

    logger.info("Detect summary: %s", asdict(summary))
    # Log the summary dict for visibility in AWX job output.

    return _bundle_tar_gz(artifact_dir, job_id, mode="detect")
    # Bundle everything into detect_<job_id>_<timestamp>.tar.gz and return the path.


def write_audit_results(
    results: list[AuditDeviceResult],
    artifact_dir: str,
    job_id: str,
) -> str:
    """
    Write per-device JSON + session logs, build summary, and return the .tar.gz path.

    Called by main_audit.py after all devices have been audited.

    Args:
        results:      List of AuditDeviceResult objects (one per device).
        artifact_dir: AWX artifact directory.
        job_id:       AWX job ID. Used in bundle filename.

    Returns:
        Path to the .tar.gz archive containing all audit artifacts.
    """
    Path(artifact_dir).mkdir(parents=True, exist_ok=True)

    devices_dir = os.path.join(artifact_dir, "devices")
    Path(devices_dir).mkdir(parents=True, exist_ok=True)
    # Separate "devices" subdirectory keeps per-device files organized
    # separately from the summary file.

    for r in results:
        # Per-device JSON: one file per device with all audit findings.
        _write_json(
            _audit_result_to_dict(r),
            os.path.join(devices_dir, f"{r.hostname}_audit_result.json"),
        )
        # Filename: "{hostname}_audit_result.json" — easy to find specific device.

        # Per-device session log: raw SSH commands/responses for debugging.
        if r.raw_log:
            # Only write session log if one was captured (raw_log may be None
            # if the device was unreachable and connect() failed immediately).
            log_path = os.path.join(devices_dir, f"{r.hostname}_session.log")
            Path(log_path).write_text(r.raw_log, encoding="utf-8")

    summary = _build_audit_summary(results)
    # Build aggregate counters for the full audit run.

    _write_json(
        {"job_id": job_id, "mode": "audit", "summary": asdict(summary)},
        os.path.join(artifact_dir, "audit_summary.json"),
    )
    # audit_summary.json is the top-level summary for the entire audit job.

    # Print summary to stdout so it's visible in AWX job output.
    # AWX captures stdout and displays it in the "Output" tab of the job UI.
    _print_audit_summary(summary, results)

    return _bundle_tar_gz(artifact_dir, job_id, mode="audit")


# ── Private helpers ───────────────────────────────────────────────────────────

def _write_json(data: dict, path: str) -> str:
    """Write a dict to a JSON file and return the path."""
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, default=str)
        # indent=2: human-readable formatting (2-space indentation).
        # default=str: converts any non-JSON-serializable values (like Enum, datetime)
        #   to strings automatically. This is a safety net for enum values that weren't
        #   explicitly converted to .value.
    return path


def _write_session_logs(
    results: Union[list[DetectDeviceResult], list[AuditDeviceResult]],
    artifact_dir: str,
    mode: str,
) -> None:
    """
    Write per-device SSH session logs to artifact_dir/session_logs/.

    Session logs contain the raw SSH commands sent and responses received.
    These are invaluable for debugging driver issues or understanding
    exactly what the tool did on a device.

    Filename format: {hostname}_{mode}_session.log
    Example: sw-core-01_detect_session.log
    """
    logs_dir = os.path.join(artifact_dir, "session_logs")
    Path(logs_dir).mkdir(parents=True, exist_ok=True)
    for r in results:
        if r.raw_log:
            # Only write if raw_log is not None or empty.
            # raw_log is None when device was unreachable (no session was established).
            log_path = os.path.join(logs_dir, f"{r.hostname}_{mode}_session.log")
            Path(log_path).write_text(r.raw_log, encoding="utf-8")


def _bundle_tar_gz(artifact_dir: str, job_id: str, mode: str) -> str:
    """
    Bundle the entire artifact_dir into a .tar.gz and return its path.

    The bundle is created inside artifact_dir itself. The bundle filename is
    timestamped with UTC time so multiple runs on the same day don't overwrite
    each other:  {mode}_{job_id}_{YYYYMMDDTHHMMSS}.tar.gz

    WHY bundle everything?
    AWX artifact storage works best with a single file per job. Bundling all
    per-device JSON files, session logs, and backups into one .tar.gz makes
    it easy to download and review the complete audit in one step.
    """
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    # UTC timestamp format: 20241019T142300 (ISO 8601 basic format, no separators).
    # UTC (not local time) for consistency regardless of AWX server timezone.

    tar_name = f"{mode}_{job_id}_{ts}.tar.gz"
    # Example: "audit_42_20241019T142300.tar.gz"
    tar_path = os.path.join(artifact_dir, tar_name)

    with tarfile.open(tar_path, "w:gz") as tar:
        # "w:gz" = write mode, gzip compression.
        for item in Path(artifact_dir).iterdir():
            if item.name != tar_name:
                # Skip the .tar.gz file itself — don't include the archive in itself!
                # This would create infinite recursion in the bundle.
                tar.add(item, arcname=item.name)
                # arcname=item.name: store with just the filename (no full path prefix).
                # This ensures the archive extracts to flat files, not deep directory trees.

    logger.info("Artifact bundle: %s", tar_path)
    return tar_path


def _build_detect_summary(results: list[DetectDeviceResult]) -> DetectSummary:
    """Build aggregate counters for the detect run."""
    return DetectSummary(
        total=len(results),
        # Total number of devices in inventory that detect was attempted on.

        identified=sum(1 for r in results if r.status == DeviceStatus.SUCCESS),
        # SUCCESS in detect mode = platform successfully identified.

        unknown=sum(1 for r in results if r.status == DeviceStatus.UNKNOWN),
        # UNKNOWN = connected but couldn't fingerprint the platform.

        unreachable=sum(1 for r in results if r.status == DeviceStatus.UNREACHABLE),
        # UNREACHABLE = couldn't SSH to device (wrong IP, firewall, device down).

        aci_mode=sum(1 for r in results if r.aci_mode),
        # ACI mode = NX-OS in ACI fabric mode — will be skipped in audit mode.
    )


def _build_audit_summary(results: list[AuditDeviceResult]) -> AuditSummary:
    """Build aggregate counters for the audit run."""
    return AuditSummary(
        total=len(results),
        # Total devices attempted.

        success=sum(1 for r in results if r.status == DeviceStatus.SUCCESS),
        # SUCCESS = all audit checks completed without exception.

        unreachable=sum(1 for r in results if r.status == DeviceStatus.UNREACHABLE),
        # UNREACHABLE = SSH connection failed after 3 attempts.

        skipped=sum(1 for r in results if r.status == DeviceStatus.SKIPPED),
        # SKIPPED = device marked for skip (ACI mode, HA standby node, etc.)

        error=sum(1 for r in results if r.status == DeviceStatus.ERROR),
        # ERROR = connected but audit failed with an exception.

        config_saved=sum(1 for r in results if r.config_saved),
        # Number of devices where running config was successfully saved to startup.
        # Only non-zero when --change=True was set for the audit run.

        config_save_skipped=sum(1 for r in results if r.config_save_skipped),
        # Number of devices with unsaved changes where save was skipped due to
        # an active session within session_max_idle_hours. Needs manual follow-up.
        # Only relevant when --change=True was set.

        config_report_only=sum(1 for r in results if r.config_report_only),
        # Number of devices where unsaved config changes were FOUND but NOT saved
        # because the audit ran in report-only mode (--change not set, the default).
        # These devices need attention — re-run with --change=True to remediate,
        # or investigate why the config was not saved previously.

        filesystem_critical=sum(
            1 for r in results
            if r.filesystem and r.filesystem.status == FilesystemStatus.CRITICAL
        ),
        # Number of devices with filesystem usage above filesystem_critical_pct.
        # These need immediate attention to prevent device failures.

        fan_failures=sum(
            1 for r in results
            if any(f.status == FanStatus.FAIL for f in (r.fans or []))
        ),
        # Number of devices with at least one failed fan.
        # "r.fans or []" handles None (if fan check wasn't run due to error).
    )


def _audit_result_to_dict(r: AuditDeviceResult) -> dict:
    """
    Convert an AuditDeviceResult to a JSON-serializable dict.

    WHY manual conversion instead of asdict()?
    dataclasses.asdict() is recursive and would convert nested Enum values
    to their raw Enum objects (not their .value strings). We manually build
    the dict to control exactly what goes in the JSON (including .value for enums).

    Also, we conditionally include filesystem/fans/config only if they exist,
    keeping the JSON clean for devices that failed before those checks ran.
    """
    d = {
        "hostname": r.hostname,                  # Device name from inventory
        "ip": r.ip,                              # IP used for SSH
        "platform": r.platform,                  # Platform label (e.g. "cisco_ios")
        "status": r.status.value,                # .value: "success", "error", "unreachable"
        "os_version": r.os_version,              # e.g. "15.9(3)M2" or None
        "config_saved": r.config_saved,          # True if save was executed and verified
        "config_save_skipped": r.config_save_skipped,  # True if save was skipped (active session)
        "config_report_only": r.config_report_only,    # True if diff found but --change not set
        "error": r.error,                        # Error message string, or None
    }
    if r.filesystem:
        # Only include filesystem section if the check was run.
        d["filesystem"] = {
            "path": r.filesystem.path,           # e.g. "flash:", "/var", "disk0:"
            "usage_pct": r.filesystem.usage_pct, # e.g. 65.0 or None
            "status": r.filesystem.status.value, # "ok", "critical", "skipped"
        }
    if r.fans:
        # Only include fans section if the check was run.
        d["fans"] = [{"fan_id": f.fan_id, "status": f.status.value} for f in r.fans]
        # List of dicts: [{"fan_id": "Fan 1", "status": "pass"}, ...]
    if r.config:
        # Only include config section if the config audit was run.
        d["config"] = {
            "status": r.config.status.value,     # "compliant", "report_only", "remediated",
                                                  # "save_skipped", "remediation_failed",
                                                  # "ha_sync_anomaly", "error"
            "backup_path": r.config.backup_path, # Path to startup config backup file, or None
            "diff_before": r.config.diff_before, # Unified diff of running vs startup, or None
            "diff_after": r.config.diff_after,   # Post-save diff (non-None = verify failed)
            "error": r.config.error,             # Error message if save failed/skipped, or None
        }

    # ── HA fields (F5 / Citrix only) ──────────────────────────────────────────
    # Only include the "ha" section if any HA field is populated.
    # For all non-HA platforms (Cisco, Juniper, etc.) every ha_* field is None
    # and this block is skipped entirely — keeps JSON clean.
    ha_fields = {
        "ha_group":                r.ha_group,
        "ha_peer_ip":              r.ha_peer_ip,
        "ha_members":              r.ha_members,
        "ha_auto_sync":            r.ha_auto_sync,
        "ha_sync_enforced":        r.ha_sync_enforced,
        "ha_anomaly":              r.ha_anomaly,
        "ha_config_saved_members": r.ha_config_saved_members,
    }
    if any(v is not None for v in ha_fields.values()):
        # At least one HA field is set — include the "ha" section in the JSON.
        d["ha"] = ha_fields
        # Example output for an F5 HA device:
        # "ha": {
        #   "ha_group": "/Common/failover-group",
        #   "ha_peer_ip": null,
        #   "ha_members": [
        #     {"hostname": "bigip1.example.com", "management_ip": "10.0.0.1", "sync_status": "In Sync"},
        #     {"hostname": "bigip2.example.com", "management_ip": "10.0.0.2", "sync_status": "In Sync"}
        #   ],
        #   "ha_auto_sync": false,
        #   "ha_sync_enforced": false,
        #   "ha_anomaly": false,
        #   "ha_config_saved_members": ["bigip1.example.com", "bigip2.example.com"]
        # }

    return d


def _print_audit_summary(summary: AuditSummary, results: list[AuditDeviceResult]) -> None:
    """
    Print a human-readable summary to stdout for AWX job output visibility.

    WHY print to stdout?
    AWX captures stdout from the Python script and displays it in the
    "Output" tab of the AWX job UI. This makes the audit summary visible
    immediately without downloading the artifact bundle.

    The summary includes:
      - Aggregate counters (total, success, unreachable, etc.)
      - Detailed lists for actionable items (saved configs, skipped saves,
        critical filesystems) so ops team can act without digging into JSON files.
    """
    sep = "=" * 60
    print(sep)
    print("AUDIT SUMMARY")
    print(sep)
    print(f"  Total devices   : {summary.total}")
    print(f"  Success         : {summary.success}")
    print(f"  Unreachable     : {summary.unreachable}")
    print(f"  Skipped         : {summary.skipped}")
    print(f"  Error           : {summary.error}")
    print(f"  Config saved    : {summary.config_saved}")
    # config_saved > 0 only when --change was set and save succeeded.
    print(f"  Save skipped    : {summary.config_save_skipped}")
    # config_save_skipped > 0 only when --change was set but active session blocked the save.
    print(f"  Report only     : {summary.config_report_only}")
    # config_report_only > 0 when --change was NOT set (default mode) and diffs were found.
    # These devices have unsaved config changes that need operator attention.
    print(f"  Filesystem crit : {summary.filesystem_critical}")
    print(f"  Fan failures    : {summary.fan_failures}")

    if summary.config_saved > 0:
        # List devices where config was auto-saved — for audit trail visibility.
        print()
        print("DEVICES WHERE CONFIG WAS SAVED:")
        for r in results:
            if r.config_saved:
                print(f"  - {r.hostname} ({r.ip}) [{r.platform}]")

    if summary.config_save_skipped > 0:
        # List devices where save was skipped — these need manual follow-up.
        # Include the blocking session details so ops team knows who to contact.
        print()
        print("DEVICES WHERE CONFIG SAVE WAS SKIPPED (active session detected):")
        for r in results:
            if r.config_save_skipped:
                reason = r.config.error if r.config else "unknown"
                print(f"  - {r.hostname} ({r.ip}) [{r.platform}] — {reason}")

    if summary.config_report_only > 0:
        # List devices with unsaved config changes found in report-only mode.
        # These are actionable: re-run with --change=True (or change=true in AWX)
        # to auto-save, or investigate why configs were changed without saving.
        print()
        print("DEVICES WITH UNSAVED CONFIG (report-only mode, --change not set):")
        for r in results:
            if r.config_report_only:
                print(f"  - {r.hostname} ({r.ip}) [{r.platform}]")
        print("  (Re-run with --change to save these configs)")
        # Tip: prompts ops team on the exact action to take.

    if summary.filesystem_critical > 0:
        # List devices with critical filesystem usage — potential for device failures.
        # Include the path and percentage so ops team knows severity at a glance.
        print()
        print("DEVICES WITH CRITICAL FILESYSTEM USAGE:")
        for r in results:
            if r.filesystem and r.filesystem.status == FilesystemStatus.CRITICAL:
                print(f"  - {r.hostname} ({r.ip}) {r.filesystem.path}: {r.filesystem.usage_pct}%")

    print(sep)
