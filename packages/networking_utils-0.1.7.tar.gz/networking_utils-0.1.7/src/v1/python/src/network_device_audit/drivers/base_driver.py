"""
drivers/base_driver.py — Abstract Platform Driver Base Class

ARCHITECTURE OVERVIEW:
  Every supported platform (Cisco IOS, Juniper JunOS, F5, etc.) has a
  dedicated driver class that inherits from BaseDriver.  The driver class
  implements 7 abstract methods using the platform's native CLI commands.

  BaseDriver provides:
    1. Public API methods (get_os_version, check_filesystem, etc.) that
       wrap each abstract method in retry logic.  Callers (auditor.py,
       config_audit.py) only use the public API — they never call the
       underscore-prefixed abstract methods directly.
    2. Safe failure defaults: if a check fails after retries, returns a
       meaningful "skipped" result rather than raising an exception.
    3. Shared utility: _filesystem_status() threshold logic (configurable %; default >70% = critical)
       is implemented once here rather than duplicated in each driver.

TWO-TIER METHOD DESIGN:
  Public method        → retries + safe default fallback
  Private abstract _*  → raw CLI command + parsing (no retry)

  Example:
    check_filesystem()       ← auditor.py calls this
      └─ retry_call(_check_filesystem, ...)   ← retries up to 3x
           └─ CiscoIOSDriver._check_filesystem()  ← actual 'show flash:' command
"""

from abc import ABC, abstractmethod  # Enforce implementation of abstract methods
from typing import Optional

from ..core.models import (
    FilesystemResult,
    FilesystemStatus,
    FanResult,
    FanStatus,
    ConfigResult,    # Imported for type hints (not used directly in base_driver)
    ConfigStatus,    # Same
    SessionInfo,     # Used for get_active_sessions() return type
)
from ..core.retry import retry_call          # Functional retry with exponential backoff
from ..core.exceptions import CommandTimeoutError  # Exception type to catch and retry

# ── Shared constants ──────────────────────────────────────────────────────────
RETRY_ATTEMPTS = 3               # Max attempts per command (connection level retries
                                 # are handled separately in auditor.py)

RETRY_BACKOFF = 2.0              # Exponential backoff base in seconds:
                                 # Attempt 2 waits 1s, attempt 3 waits 2s


class BaseDriver(ABC):
    """
    Abstract base class for all platform-specific drivers.

    All drivers receive a connected transport instance and expose a
    uniform audit API that the auditor and config_audit layers use.
    The transport is platform-agnostic — drivers use transport.send_command()
    to send CLI strings and receive raw output, then parse that output
    themselves using platform-specific regex patterns.
    """

    # ── Class-level attributes ─────────────────────────────────────────────────
    # These are overridden in each concrete driver subclass.

    #: Human-readable platform label matching detect_result.yml and the driver registry.
    #: Used in log messages and result records.
    PLATFORM: str = ""

    #: Whether this platform requires escalation to enable (privileged EXEC) mode.
    #: True for all Cisco platforms (IOS, IOS-XE, IOS-XR, NX-OS).
    #: auditor.py checks NEEDS_ENABLE and calls transport.enter_enable_mode() if True.
    NEEDS_ENABLE: bool = False

    def __init__(
        self,
        transport,
        filesystem_critical_pct: float = 70.0,
        username: Optional[str] = None,
        password: Optional[str] = None,
        port: int = 22,
    ):
        # The transport is already connected when the driver is instantiated.
        # auditor.py handles the connection (with retry) before creating the driver.
        self.transport = transport   # BaseTransport instance (NetmikoTransport in audit mode)

        self.filesystem_critical_pct = filesystem_critical_pct
        # filesystem_critical_pct: /var (or equivalent) usage % above which we flag CRITICAL.
        # Passed from the CLI --filesystem-critical-pct argument (default 70).

        self.username = username
        self.password = password
        self.port = port
        # username / password / port: SSH credentials passed through from audit_device().
        # Used ONLY by HA-capable drivers (F5Driver, CitrixDriver) to open fresh SSH
        # connections to HA peer devices during save_config().
        # All other drivers store these but never use them — they operate solely through
        # self.transport (the already-connected session from auditor.py).

    # ── Public API — with retry and safe fallbacks ────────────────────────────
    # These methods are called by auditor.py and config_audit.py.
    # They wrap the abstract _* methods in retry_call to handle transient
    # command timeouts without aborting the entire device session.

    def get_os_version(self) -> Optional[str]:
        """
        Collect the device OS version string.

        Returns None on persistent failure (non-critical — other checks continue).
        """
        try:
            return retry_call(
                self._get_os_version,
                attempts=RETRY_ATTEMPTS,
                backoff_base=RETRY_BACKOFF,
                exceptions=(CommandTimeoutError, Exception),
                # Catch both timeout and any other exception (e.g. parse error)
                # so a single platform's weird output format doesn't crash the audit.
            )
        except Exception:
            return None   # Non-critical: audit continues without OS version

    def check_filesystem(self) -> FilesystemResult:
        """
        Check filesystem/storage usage.

        Returns FilesystemStatus.SKIPPED on failure (non-critical).
        """
        try:
            return retry_call(
                self._check_filesystem,
                attempts=RETRY_ATTEMPTS,
                backoff_base=RETRY_BACKOFF,
                exceptions=(CommandTimeoutError, Exception),
            )
        except Exception:
            # Return a SKIPPED result with path="unknown" — better than crashing.
            # The audit continues, and SKIPPED is recorded in the JSON output.
            return FilesystemResult(path="unknown", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def check_fans(self) -> list[FanResult]:
        """
        Check fan health status.

        Returns [FanResult(fan_id="all", status=NA)] on failure (non-critical).
        """
        try:
            return retry_call(
                self._check_fans,
                attempts=RETRY_ATTEMPTS,
                backoff_base=RETRY_BACKOFF,
                exceptions=(CommandTimeoutError, Exception),
            )
        except Exception:
            # Return NA result — fan check is optional; failure doesn't abort audit.
            return [FanResult(fan_id="all", status=FanStatus.NA)]

    def get_running_config(self) -> str:
        """
        Fetch the running configuration.

        RAISES on failure — config comparison cannot proceed without this.
        The exception propagates to config_audit.py which records it as an error.
        """
        return retry_call(
            self._get_running_config,
            attempts=RETRY_ATTEMPTS,
            backoff_base=RETRY_BACKOFF,
            exceptions=(CommandTimeoutError, Exception),
        )
        # No try/except here — this is critical. If we can't fetch the running
        # config after 3 retries, the config audit cannot run and should fail.

    def get_startup_config(self) -> str:
        """
        Fetch the startup (saved) configuration.

        RAISES on failure — same reasoning as get_running_config.
        """
        return retry_call(
            self._get_startup_config,
            attempts=RETRY_ATTEMPTS,
            backoff_base=RETRY_BACKOFF,
            exceptions=(CommandTimeoutError, Exception),
        )

    def save_config(self) -> str:
        """
        Save the running config to startup (write memory / commit).

        RAISES on failure — config_audit.py catches this and records
        ConfigStatus.REMEDIATION_FAILED.
        """
        return retry_call(
            self._save_config,
            attempts=RETRY_ATTEMPTS,
            backoff_base=RETRY_BACKOFF,
            exceptions=(CommandTimeoutError, Exception),
        )

    def get_active_sessions(self) -> list[SessionInfo]:
        """
        Return a list of active SSH/CLI sessions currently on the device.

        Called by config_audit.py before attempting to save the config.
        If any session has been idle for < 12 hours, the save is skipped
        to avoid overwriting work an active admin might be doing.

        SAFE DEFAULT ON FAILURE: if the command fails or output cannot be
        parsed, returns [SessionInfo(idle_hours=0.0)] — treating the unknown
        situation as if there IS a recent active session.  This causes the
        save to be skipped rather than risking an unsafe save.

        WHY 0.0 hours as default?
          0.0 hours = "just now active" → triggers skip (idle < 12h threshold).
          This is conservative: we'd rather skip a save than accidentally save
          config while an admin is actively working on the device.
        """
        try:
            return retry_call(
                self._get_active_sessions,
                attempts=RETRY_ATTEMPTS,
                backoff_base=RETRY_BACKOFF,
                exceptions=(CommandTimeoutError, Exception),
            )
        except Exception:
            # Command failed after retries — return conservative "active" session
            return [SessionInfo(user="unknown", line="unknown", idle_hours=0.0)]

    def configs_differ(self, running: str, startup: str) -> bool:
        """
        Return True if running and startup configs are meaningfully different.

        Both configs are stripped of leading/trailing whitespace before comparison.
        Whitespace-only differences (trailing newlines, spacing) don't trigger
        a save — only actual configuration content differences do.

        Used twice: before save (to decide if save is needed) and after save
        (to verify the save actually worked).
        """
        return running.strip() != startup.strip()

    def is_ha_standby(self) -> bool:
        """
        Return True if this device is currently a standby (secondary) HA member.

        Default implementation returns False — the vast majority of drivers are
        not HA-capable and are never standby nodes.

        F5Driver and CitrixDriver override this method to:
          1. Run platform-specific HA discovery commands (tmsh show cm failover-status
             for F5; show ha node for Citrix).
          2. Cache the full HA topology in self._ha_info for later use by
             save_config() and get_ha_info().
          3. Return True if this device is the standby/secondary member.

        Called by auditor.py AFTER enabling enable mode but BEFORE running any
        audit checks.  If True, auditor.py immediately marks the device as SKIPPED
        (status="skipped", error="HA standby node") and returns — the active-node
        thread is responsible for all config-save work on the group.

        Safe failure: if the HA discovery commands fail (command error, parse
        failure), this method should return False (not standby) so the audit
        continues normally — conservatively treating the device as active/standalone
        rather than silently skipping it.
        """
        return False  # Default: not HA-aware, never a standby node

    def get_ha_info(self) -> dict:
        """
        Return HA topology and save-operation metadata discovered during this audit.

        Default implementation returns an empty dict — non-HA drivers never populate
        any HA metadata.

        F5Driver and CitrixDriver override this to return the cached self._ha_info dict
        populated by _discover_ha() (called inside is_ha_standby()).

        The dict keys mirror the ha_* fields on AuditDeviceResult:
          ha_group             : str  — F5 device group name (or "ha_pair" for Citrix)
          ha_peer_ip           : str  — Citrix secondary IP (F5 uses ha_members instead)
          ha_members           : list — F5 per-member dicts (hostname, ip, sync_status)
          ha_auto_sync         : bool — True if auto-sync is configured
          ha_sync_enforced     : bool — True if a manual sync command was issued
          ha_anomaly           : bool — True if auto-sync on but still out of sync
          ha_config_saved_members : list — member hostnames where save succeeded

        Called by auditor.py AFTER config_audit() completes. auditor.py reads the
        returned dict and writes its values to the corresponding fields of
        AuditDeviceResult so they appear in the per-device JSON output.
        """
        return {}  # Default: no HA info

    def _filesystem_status(self, pct: Optional[float]) -> FilesystemStatus:
        """
        Convert a usage percentage to a FilesystemStatus enum value.

        Shared logic: all 11 drivers use the same threshold (self.filesystem_critical_pct).
        By implementing it here, the threshold is defined in one place
        and automatically applies to every platform without copying.

        Args:
            pct: Usage percentage (0-100), or None if parsing failed.

        Returns:
            SKIPPED if pct is None (couldn't parse the output).
            CRITICAL if pct > filesystem_critical_pct (action required).
            OK if pct <= filesystem_critical_pct (within acceptable range).
        """
        if pct is None:
            return FilesystemStatus.SKIPPED
        return FilesystemStatus.CRITICAL if pct > self.filesystem_critical_pct else FilesystemStatus.OK

    # ── Abstract methods — implemented by each platform driver ────────────────
    # These receive no retry logic — they just issue the platform-specific CLI
    # command and parse the output.  The public API methods above add retry.

    @abstractmethod
    def _get_os_version(self) -> Optional[str]:
        """Run 'show version' and extract the OS version string."""
        ...

    @abstractmethod
    def _check_filesystem(self) -> FilesystemResult:
        """Check storage usage on the platform-appropriate filesystem path."""
        ...

    @abstractmethod
    def _check_fans(self) -> list[FanResult]:
        """Check fan health status via the platform's environment command."""
        ...

    @abstractmethod
    def _get_running_config(self) -> str:
        """Fetch the running (active) configuration as a string."""
        ...

    @abstractmethod
    def _get_startup_config(self) -> str:
        """Fetch the startup (saved) configuration as a string."""
        ...

    @abstractmethod
    def _save_config(self) -> str:
        """Save running config to startup (write memory / commit / etc.)."""
        ...

    @abstractmethod
    def _get_active_sessions(self) -> list[SessionInfo]:
        """List active SSH/CLI sessions and their idle time in hours."""
        ...
