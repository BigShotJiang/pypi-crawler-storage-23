# ============================================================
# core/retry.py — Exponential Backoff Retry Utilities
# ============================================================
# Provides two ways to add retry behaviour:
#
#   @retry(...)        — decorator form, applied at function definition
#   retry_call(...)    — functional form, called at the use-site
#
# The functional form (retry_call) is preferred in this project because
# the _check_* methods on drivers are abstract and cannot be decorated at
# definition time in the base class.  BaseDriver wraps each call to
# _check_filesystem(), _check_fans(), etc. using retry_call.
#
# Backoff schedule (DEFAULT_ATTEMPTS=3, BASE_BACKOFF=2.0):
#   Attempt 1: immediate
#   Attempt 2: wait 2.0 ** 0 = 1.0 second
#   Attempt 3: wait 2.0 ** 1 = 2.0 seconds
#   (total max wait before giving up: ~3 seconds + command execution time)
# ============================================================

import time                           # time.sleep() for the backoff delay
import logging                        # Log warnings on each failed attempt
from functools import wraps           # @wraps preserves function metadata (name, docstring)
                                      # so introspection and logging show the original name
from typing import Callable, Tuple, Type  # Type hints for function signature clarity

logger = logging.getLogger(__name__)  # Module-level logger; messages appear as
                                      # "network_device_audit.core.retry: ..." in logs

# ── Constants ────────────────────────────────────────────────────────────────
DEFAULT_ATTEMPTS = 3          # Max times to attempt a function call before giving up.
                              # 3 strikes a balance: enough resilience for transient
                              # network blips without spending too long on a bad device.
BASE_BACKOFF = 2.0            # Base for exponential backoff calculation:
                              # delay = BASE_BACKOFF ** (attempt_index - 1)
                              # Attempt 2 waits 1s, attempt 3 waits 2s.


# ── Decorator form ────────────────────────────────────────────────────────────
def retry(
    attempts: int = DEFAULT_ATTEMPTS,
    backoff_base: float = BASE_BACKOFF,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    # Tuple of exception types to catch and retry on.
    # Default catches any Exception; narrow this to retry only on specific errors
    # (e.g. exceptions=(CommandTimeoutError,) to retry only timeouts).
    reraise_as: Type[Exception] = None,
    # If provided, the last caught exception is re-raised wrapped in this type.
    # Useful for converting library-specific exceptions to project exceptions
    # (e.g. reraise_as=DeviceUnreachableError converts Netmiko errors).
):
    """
    Decorator: retry a function up to `attempts` times with exponential backoff.

    On each failure the delay is backoff_base ** attempt_index (1s, 2s, 4s, …).
    If all attempts are exhausted, reraises the last exception (or wraps it in
    `reraise_as` if provided).
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)                      # Copy func's __name__, __doc__ onto wrapper
        def wrapper(*args, **kwargs):
            last_exc = None               # Tracks the most recent exception for re-raise
            for attempt in range(1, attempts + 1):
                # range(1, N+1) makes attempt numbers 1-based in log messages
                # (more human-readable than 0-based)
                try:
                    return func(*args, **kwargs)   # Call the original function
                except exceptions as exc:
                    last_exc = exc                 # Remember this exception
                    if attempt < attempts:
                        # Not the last attempt — compute delay and wait
                        delay = backoff_base ** (attempt - 1)
                        # attempt=1 → delay=2^0=1.0s
                        # attempt=2 → delay=2^1=2.0s
                        # attempt=3 would be last, so we never sleep before it
                        logger.warning(
                            "%s attempt %d/%d failed: %s — retrying in %.1fs",
                            func.__qualname__,  # Full qualified name (e.g. CiscoIOSDriver._check_filesystem)
                            attempt, attempts,
                            exc,
                            delay,
                        )
                        time.sleep(delay)           # Blocking sleep — OK because each device
                                                    # runs in its own thread (ThreadPoolExecutor)
                    else:
                        # Final attempt also failed — log error before re-raising
                        logger.error(
                            "%s failed after %d attempts: %s",
                            func.__qualname__, attempts, exc,
                        )
            # All attempts exhausted — re-raise the last exception
            if reraise_as is not None:
                # Wrap in the specified exception type (chaining the original)
                raise reraise_as(str(last_exc)) from last_exc
            raise last_exc
        return wrapper
    return decorator


# ── Functional form ───────────────────────────────────────────────────────────
def retry_call(
    func: Callable,
    args: tuple = (),              # Positional arguments to pass to func
    kwargs: dict = None,           # Keyword arguments to pass to func
    attempts: int = DEFAULT_ATTEMPTS,
    backoff_base: float = BASE_BACKOFF,
    exceptions: Tuple[Type[Exception], ...] = (Exception,),
    reraise_as: Type[Exception] = None,
):
    """
    Functional form of retry — call `func(*args, **kwargs)` with retries.

    Preferred over the @retry decorator when:
      - The function is a bound method resolved at call time (driver methods)
      - The exception types or attempt count vary per call site
      - You need to pass different arguments on each call

    Used extensively in BaseDriver to wrap the abstract _check_* methods:
        retry_call(self._check_filesystem, attempts=3, exceptions=(CommandTimeoutError,))
    """
    if kwargs is None:
        kwargs = {}                # Mutable default argument safety — create new dict
    last_exc = None
    for attempt in range(1, attempts + 1):
        try:
            return func(*args, **kwargs)    # Call the function with provided arguments
        except exceptions as exc:
            last_exc = exc
            if attempt < attempts:
                delay = backoff_base ** (attempt - 1)
                logger.warning(
                    "%s attempt %d/%d failed: %s — retrying in %.1fs",
                    func.__qualname__,          # Shows e.g. "CiscoIOSDriver._get_running_config"
                    attempt, attempts,
                    exc,
                    delay,
                )
                time.sleep(delay)               # Wait before next attempt
            else:
                logger.error(
                    "%s failed after %d attempts: %s",
                    func.__qualname__, attempts, exc,
                )
    if reraise_as is not None:
        raise reraise_as(str(last_exc)) from last_exc
    raise last_exc
