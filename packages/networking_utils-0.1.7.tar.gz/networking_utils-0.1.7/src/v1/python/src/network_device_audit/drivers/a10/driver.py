# ============================================================
# drivers/a10/driver.py — A10 Networks Thunder / ACOS Driver
# ============================================================
# Covers: A10 Networks Thunder Series (ADC, CGN, TPS, CFW).
#         Runs ACOS (Advanced Core OS) — a Linux-based OS.
#
# A10 Thunder is used as an ADC (Application Delivery Controller),
# load balancer, or DDoS protection appliance in data centers.
#
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     ACOS CLI puts users in exec mode on login.
#   - Filesystem: Linux /var — BUT A10 has its own "show disk"
#     command that shows /var usage without needing df.
#     WHY "show disk" instead of "df -h /var"?
#     A10's ACOS CLI doesn't expose raw Linux commands like df.
#     "show disk" is the ACOS-specific command for storage status.
#     Output format: "Disk usage: 45%  (/var: 6.2G/14G)"
#   - Config save: "write memory" (A10 uses IOS-style save, not "copy")
#   - Sessions: "show admin-session" (A10-specific, not "show users")
#     Output has User/Terminal/From/Idle columns with HH:MM:SS idle.
# ============================================================

import re
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...parsers.session_parser import parse_hhmm_ss


class A10Driver(BaseDriver):
    """A10 Networks Thunder / ACOS driver."""
    PLATFORM = "a10"         # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False      # ACOS: exec mode on login, no enable step

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show version")
        # A10 ACOS version formats:
        #   Short format: "ACOS 5.2.1-p8"
        #   Long format:  "Advanced Core OS (ACOS) version 5.2.1-P8"
        # Try short format first: "ACOS" followed by version.
        m = re.search(r"ACOS\s+([\w.]+)", out, re.IGNORECASE)
        if not m:
            # Try long format: "Advanced Core OS (ACOS) version X.X"
            m = re.search(r"Advanced\s+Core\s+OS\s+\(ACOS\)\s+version\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("show disk")
        # A10 "show disk" command shows storage usage in ACOS-specific format.
        # Standard Linux "df" is NOT available in the ACOS CLI directly.
        #
        # Example output format 1 (newer ACOS):
        #   Disk usage: 45%  (/var: 6.2G/14G)
        # Example output format 2 (some ACOS versions):
        #   /var              14G    6.2G    7.4G    46%  /var
        #
        # Pattern 1: "/var" followed by percentage — captures /var-specific usage.
        # This is tried first because it's more specific (actual /var percentage).
        m = re.search(r"/var.*?(\d+)%", out, re.IGNORECASE)
        if not m:
            # Pattern 2: "Disk usage:" followed by overall percentage.
            # Fallback when /var percentage is not shown separately.
            m = re.search(r"Disk usage:\s*(\d+)%", out, re.IGNORECASE)
        if m:
            pct = float(m.group(1))
            return FilesystemResult(
                path="/var",                            # A10 is Linux-based; /var is primary storage
                usage_pct=pct,
                status=self._filesystem_status(pct),    # PASS/WARNING/CRITICAL threshold check
            )
        # If "show disk" produces output we can't parse, return SKIPPED.
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        out = self.transport.send_command("show environment")
        # "show environment" on A10 shows hardware environmental status:
        # temperature sensors, power supplies, and fans.
        #
        # Example output:
        #   Fan 1: normal
        #   Fan 2: normal
        #   Fan Tray 1: ok
        #
        # A10 virtual Thunder (vThunder) has no physical fans;
        # "virtual" in output = virtual instance → return NA.
        if not out or "invalid" in out.lower() or "virtual" in out.lower():
            # "invalid": command not supported on this ACOS version.
            # "virtual": vThunder virtual appliance — no physical fans.
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: "Fan <name>: <status>" format.
            # Fan names can include spaces and hyphens: "Fan 1", "Fan Tray 1".
            # Status keywords: "normal", "ok", "good" = healthy; "failed", "absent" = problem.
            m = re.search(r"(Fan[\s\w-]+):\s*(normal|ok|good|failed|absent)", line, re.IGNORECASE)
            if m:
                status = FanStatus.PASS if re.search(r"normal|ok|good", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # "show running-config" works on ACOS (Cisco-style abbreviated command).
        # Output includes: VIPs, SLBs, ACLs, interfaces, etc.
        # timeout=60: large A10 configs with many VIPs can be slow.
        return self.transport.send_command("show running-config", timeout=60)

    def _get_startup_config(self) -> str:
        # "show startup-config" shows the saved configuration that loads on reboot.
        # If running != startup, there are unsaved changes.
        return self.transport.send_command("show startup-config", timeout=60)

    def _save_config(self) -> str:
        # A10 SAVE = "write memory":
        # A10 uses the IOS-style "write memory" command (not "copy running-config startup-config").
        # This is unusual for a Linux-based platform — most Linux-based platforms use "copy..."
        # A10 chose IOS-compatible CLI conventions for familiarity.
        return self.transport.send_command("write memory", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # A10 show admin-session example:
        # User       Terminal   From            Idle
        # admin      pts/0      10.0.0.100      00:03:15
        # ops        pts/1      10.0.0.101      00:00:05
        #
        # WHY "show admin-session" and NOT "show users"?
        # A10 doesn't have a standard "show users" command.
        # "show admin-session" is the A10-specific command showing active management sessions.
        # It reports IDLE time in HH:MM:SS format (like Cisco IOS), not login time.
        #
        # Column layout:
        #   [0] User     = username
        #   [1] Terminal = terminal/tty (e.g. "pts/0")
        #   [2] From     = source IP
        #   [3] Idle     = idle time in HH:MM:SS format
        out = self.transport.send_command("show admin-session")
        sessions = []
        for line in out.splitlines():
            # Skip blank lines and header rows (start with "User" or "Terminal").
            if not line.strip() or re.match(r"\s*(User|Terminal)", line, re.IGNORECASE):
                continue
            parts = line.split()
            # Need at least 4 columns to have user, terminal, from, and idle.
            if len(parts) >= 4:
                user = parts[0]       # Column 0: username (e.g. "admin")
                line_id = parts[1]    # Column 1: terminal (e.g. "pts/0")
                idle_str = parts[3]   # Column 3: idle time (HH:MM:SS), skipping "From" at index 2
                idle_hours = parse_hhmm_ss(idle_str)
                # parse_hhmm_ss converts "00:03:15" → 0.054h, "00:00:05" → 0.0014h
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=idle_hours if idle_hours is not None else 0.0,
                    # Default 0.0 = treat as active if parse fails (conservative).
                ))
        return sessions
