"""
detect/fingerprint.py — Paramiko Fallback Platform Fingerprinting

When Netmiko SSHDetect fails to identify a device's platform, this module
provides a second attempt using regex pattern matching against the output of
'show version'.

WHY 'show version'?
  - Every supported platform implements some form of 'show version' (or
    equivalent) that includes vendor/OS name strings in the output.
  - It's a read-only, non-disruptive command that works before enable mode.
  - The output is distinctive enough to uniquely identify all 11 platforms.

Returns (platform_label, netmiko_device_type) tuples or None.
  - platform_label   : internal key used by the driver registry (e.g. "cisco_ios")
  - netmiko_device_type: the string Netmiko's ConnectHandler expects (e.g. "cisco_ios")
    These are NOT always the same — e.g. Cisco IOS-XE uses "cisco_xe" in Netmiko
    but "cisco_iosxe" as our internal label.
"""

import re
from typing import Optional, Tuple

# ── Fingerprint rule table ────────────────────────────────────────────────────
# Each entry is a 3-tuple:
#   (regex_pattern, platform_label, netmiko_device_type)
#
# Rules are evaluated IN ORDER — first match wins.
# ORDER MATTERS: More specific patterns must come before general ones.
#   - "IOS-XR Software" must appear before "Cisco IOS Software" because IOS-XR
#     output also contains "Cisco" but is a completely different OS.
#   - "NX-OS" before "Cisco IOS" for the same reason.
#   - "IOS XE" before "Cisco IOS Software" because XE output also says "Cisco IOS".
#
# All patterns are tested with re.IGNORECASE so capitalization variations
# in device output don't cause misidentification.
_FINGERPRINT_RULES: list[Tuple[str, str, str]] = [
    # ── Cisco (most specific first) ───────────────────────────────────────────
    (r"IOS-XR\s+Software",              "cisco_iosxr",    "cisco_xr"),
    # "Cisco IOS XR Software, Version 7.9.2" — IOS-XR (ASR 9k, NCS series)
    # Netmiko type "cisco_xr" handles XR-specific prompt patterns.

    (r"NX-OS.*Software|Cisco Nexus",    "cisco_nxos",     "cisco_nxos"),
    # "Cisco Nexus Operating System (NX-OS) Software" — NX-OS (Nexus switches)
    # Also matches "Cisco Nexus 9000" in case the OS line is missing.

    (r"IOS-XE.*Software|Cisco IOS XE",  "cisco_iosxe",    "cisco_xe"),
    # "Cisco IOS XE Software, Version 17.9.4a" — IOS-XE (Catalyst 9k, ASR 1k)
    # Netmiko type "cisco_xe" (note: not "cisco_iosxe").

    (r"Cisco IOS Software",              "cisco_ios",      "cisco_ios"),
    # "Cisco IOS Software, Version 15.9(3)M2" — Classic IOS (Catalyst 2k/3k/4k)
    # This is the broadest Cisco pattern; must come last among Cisco rules.

    # ── Juniper ───────────────────────────────────────────────────────────────
    (r"JUNOS\s+Software|Juniper Networks", "juniper_junos", "juniper_junos"),
    # "JUNOS Software Release [22.4R3-S2.1]" — JunOS (MX, QFX, SRX series)

    # ── Arista ────────────────────────────────────────────────────────────────
    (r"Arista\s+EOS|EOS\s+version",      "arista_eos",    "arista_eos"),
    # "Arista EOS version 4.31.2F" — Arista EOS (7000/7500 series)

    # ── F5 ────────────────────────────────────────────────────────────────────
    (r"BIG-IP|F5 Networks",              "f5",            "f5_ltm"),
    # "BIG-IP Version 16.1.4.2" — F5 BIG-IP (LTM appliances and virtual editions)
    # Netmiko type "f5_ltm" handles F5's tmsh prompt.

    # ── Citrix ────────────────────────────────────────────────────────────────
    (r"NetScaler|Citrix ADC|Citrix VPX|Citrix SDX", "citrix", "generic_termserver"),
    # "NetScaler NS13.1" — Citrix ADC (formerly NetScaler) VPX and SDX
    # Netmiko "generic_termserver" is used because Netmiko has no native Citrix driver.
    # generic_termserver simply opens a shell and waits for any prompt.

    # ── Dell OS10 ────────────────────────────────────────────────────────────
    (r"Dell EMC Networking OS10|OS10 Enterprise", "dell_os10", "dell_os10"),
    # "Dell EMC Networking OS10 Enterprise" — Dell OS10 (S-series, Z-series)
    # Netmiko has a native dell_os10 driver.

    # ── Dell OS9 / FTOS ──────────────────────────────────────────────────────
    (r"Dell Networking OS|FTOS\s+Version|Force10 Networks", "dell_os9", "dell_ftos"),
    # "FTOS Version 9.14.2.15" — Dell OS9 / FTOS (older Force10 OS)
    # Netmiko type "dell_ftos" handles the FTOS prompt.

    # ── A10 Networks ─────────────────────────────────────────────────────────
    (r"A10 Networks|Thunder\s+Series|ACOS\s+Version", "a10", "generic_termserver"),
    # "Advanced Core OS (ACOS) Version 5.2.1-p5" — A10 Thunder load balancers
    # Netmiko has no native A10 driver; generic_termserver is used.
]


def fingerprint_show_version(
    output: str,
) -> Optional[Tuple[str, str]]:
    """
    Try to identify the platform from `show version` output.

    Iterates the _FINGERPRINT_RULES list and returns the first match.
    The rule list is ordered most-specific-first to prevent false matches.

    Args:
        output: Raw 'show version' command output from the device.

    Returns:
        (platform_label, netmiko_device_type) if a rule matches, or None.
    """
    if not output:
        # Empty output means the command failed or returned nothing.
        # Can't fingerprint from nothing.
        return None
    for pattern, platform_label, netmiko_type in _FINGERPRINT_RULES:
        if re.search(pattern, output, re.IGNORECASE):
            # First match wins — return immediately without checking remaining rules
            return platform_label, netmiko_type
    return None   # No rule matched — platform is unknown


def fingerprint_prompt(prompt: str) -> Optional[Tuple[str, str]]:
    """
    Light-touch prompt-based heuristic used before `show version` is attempted.

    WHY: Some platforms have distinctive prompt formats that can be identified
    before sending any commands.  This is a fast pre-check.

    Returns (platform_label, netmiko_device_type) or None if prompt doesn't
    match any known pattern.  Currently identifies Juniper and Arista;
    all others require show version.
    """
    if not prompt:
        return None
    # Juniper JunOS prompt format: "username@hostname>" (operational) or
    # "username@hostname#" (configure terminal).
    # The @ between user and hostname is distinctive — Cisco uses "hostname#".
    if re.search(r"@[\w.-]+[>#]$", prompt):
        return "juniper_junos", "juniper_junos"
    # Arista: some versions include "Arista" in the login banner or initial output.
    if re.search(r"Arista", prompt, re.IGNORECASE):
        return "arista_eos", "arista_eos"
    return None
