# ============================================================
# drivers/citrix/driver.py — Citrix ADC (NetScaler) Driver (HA-aware)
# ============================================================
# Covers: Citrix ADC VPX (virtual appliance) and SDX (hardware).
#         ADC = Application Delivery Controller (load balancer).
#         Previously called "NetScaler" before Citrix rebranding.
#
# Citrix ADC runs on a FreeBSD-based NS (NetScaler) kernel.
# Key characteristics:
#   - No enable mode needed (NEEDS_ENABLE = False)
#     NS shell grants full access on login as nsroot or admin.
#   - Filesystem: /var — checked with standard "df -h /var"
#     (NS shell allows POSIX df command)
#   - Fan check: VPX is virtual (no fans); SDX is physical hardware.
#     We detect virtual vs physical from "show hardware" output.
#   - Config commands:
#       Running: "show ns runningConfig"
#       Startup: "show ns savedConfig"
#       Save:    "save ns config"
#   - Sessions: uses "who" command (FreeBSD-style login time output)
#     "who" shows "Oct 19 14:23" format (not YYYY-MM-DD like Linux).
#     session_age_from_login_time() handles both formats.
#
# HA DESIGN (Citrix ADC HA pair):
#   Citrix uses a primary/secondary pair (not device groups like F5).
#   The primary processes traffic; the secondary is a hot standby.
#   HA information is available via "show ha node".
#
#   HA discovery sequence (run once, cached):
#     1. show ha node → determines this node's role (Primary/Secondary),
#        peer IP, sync state (IN SYNC / OUT OF SYNC), and auto-sync flag.
#
#   Config save sequence (only when change=True, only from primary):
#     - Nodes out-of-sync + auto-sync enabled:
#         RAISE HAAutoSyncAnomalyError (production issue, no save)
#     - Nodes out-of-sync + auto-sync disabled:
#         run "sync ha files" to push config from primary to secondary
#         SSH to primary → save ns config
#         SSH to secondary → save ns config
#     - Nodes in sync:
#         SSH to primary (self) → save ns config
#         SSH to secondary (peer) → save ns config
# ============================================================

import re
import logging
from typing import Optional

from ..base_driver import BaseDriver
from ...core.models import FilesystemResult, FilesystemStatus, FanResult, FanStatus, SessionInfo
from ...core.exceptions import HAAutoSyncAnomalyError
from ...parsers.session_parser import session_age_from_login_time
# NOTE: Citrix uses session_age_from_login_time (NOT parse_hhmm_ss) because
# "who" on FreeBSD outputs LOGIN TIME, not idle duration.
# session_age_from_login_time() converts "Oct 19 14:23" to hours-since-login.

logger = logging.getLogger(__name__)


class CitrixDriver(BaseDriver):
    """
    Driver for Citrix ADC (NetScaler) VPX and SDX appliances.

    VPX and SDX share the same CLI surface exposed via SSH.
    SDX has a management shell; VPX uses the FreeBSD-based NS shell.
    """
    PLATFORM = "citrix"      # Label matching registry.py and detect_result.yml
    NEEDS_ENABLE = False      # NS shell: full access without enable mode

    def __init__(self, transport, filesystem_critical_pct: float = 70.0,
                 username: Optional[str] = None, password: Optional[str] = None,
                 port: int = 22):
        super().__init__(
            transport,
            filesystem_critical_pct=filesystem_critical_pct,
            username=username,
            password=password,
            port=port,
        )
        self._ha_info: Optional[dict] = None
        # _ha_info: cache for HA discovery results.
        # Populated by _discover_ha() inside is_ha_standby().
        # None = not yet discovered.  {} = discovered, standalone (no HA peer found).
        # dict with keys = HA topology detected.

    # ── HA discovery ──────────────────────────────────────────────────────────

    def _discover_ha(self) -> None:
        """
        Discover Citrix ADC HA pair topology from this node.
        Results are cached in self._ha_info.  Safe to call multiple times.

        Runs a single command: "show ha node"

        Populates self._ha_info with:
          is_standby     : bool — True if this node is Secondary
          ha_group       : str | None — "ha_pair" if HA detected, None if standalone
          ha_peer_ip     : str | None — management IP of the peer (secondary or primary)
          ha_auto_sync   : bool — True if "Sync State: ENABLED"
          ha_state       : str — "IN SYNC" or "OUT OF SYNC" (raw text from CLI)
          ha_anomaly     : bool — True if auto-sync enabled but OUT OF SYNC

        "show ha node" output example (HA configured, this node is Primary):
            1)  Node ID: 0
                IP address: 10.0.0.1
                Node State: Primary
                Master State: Enable
                Sync State: ENABLED
                Propagation: ENABLED
                Enabled Interfaces: 0/1 1/1
                HA Mon: ON
            2)  Node ID: 1
                IP address: 10.0.0.2
                Node State: Secondary
                Sync State: ENABLED

        "show ha node" output example (standalone, no HA):
            (output typically empty, or just shows "Node ID: 0" without a peer entry)

        Safe failure: if the command fails or output can't be parsed,
        _ha_info["is_standby"] = False, _ha_info["ha_group"] = None → standalone treatment.
        """
        if self._ha_info is not None:
            return   # Already cached — skip re-discovery

        self._ha_info = {}   # Mark as "discovery attempted"

        try:
            out = self.transport.send_command("show ha node")
            # "show ha node" lists all nodes in the HA configuration.
            # On a standalone ADC it shows only the local node (no "Secondary" entry).
        except Exception as exc:
            logger.warning("[Citrix] Could not run 'show ha node': %s — treating as standalone", exc)
            self._ha_info["is_standby"] = False
            self._ha_info["ha_group"] = None
            return

        # Parse the output to determine HA role and peer info.
        self._parse_ha_node_output(out)

    def _parse_ha_node_output(self, output: str) -> None:
        """
        Parse 'show ha node' output and populate self._ha_info.

        The output lists each HA node as a numbered block.
        We look for "Node State: Secondary" and "Node State: Primary" to
        determine roles and collect peer IP addresses.
        """
        # Split output into per-node blocks (separated by numbered list items).
        # Each block starts with "1)", "2)", etc.
        node_blocks = re.split(r"\d+\)\s*", output)
        # re.split on "\d+\)" splits at "1) ", "2) " etc.
        # Leading empty string from split is filtered by the "if block.strip()" below.

        nodes = []
        for block in node_blocks:
            if not block.strip():
                continue   # Skip empty segments from split

            ip_m = re.search(r"IP\s+address:\s*([\d.]+)", block, re.IGNORECASE)
            # Match: "IP address: 10.0.0.1"
            state_m = re.search(r"Node\s+State:\s*(\w+)", block, re.IGNORECASE)
            # Match: "Node State: Primary" or "Node State: Secondary"
            sync_m = re.search(r"Sync\s+State:\s*(\w+)", block, re.IGNORECASE)
            # Match: "Sync State: ENABLED" or "Sync State: DISABLED"

            if ip_m and state_m:
                nodes.append({
                    "ip": ip_m.group(1),           # e.g. "10.0.0.1"
                    "state": state_m.group(1).lower(),  # "primary" or "secondary"
                    "sync_enabled": bool(
                        sync_m and sync_m.group(1).upper() == "ENABLED"
                    ),
                    # sync_enabled: True if "Sync State: ENABLED" for this node.
                })

        if len(nodes) < 2:
            # Only one node found (or zero) — standalone ADC, no HA peer.
            logger.debug("[Citrix] No HA peer found in 'show ha node' — standalone")
            self._ha_info["is_standby"] = False
            self._ha_info["ha_group"] = None
            return

        # ── HA pair detected ──────────────────────────────────────────────────
        # Determine which node is primary and which is secondary.
        primary_node   = next((n for n in nodes if n["state"] == "primary"),   None)
        secondary_node = next((n for n in nodes if n["state"] == "secondary"), None)

        if not primary_node or not secondary_node:
            # Couldn't clearly determine roles — could be both in "init" state.
            # Treat as standalone to be safe.
            logger.warning(
                "[Citrix] Could not determine primary/secondary roles from HA node output"
                " — treating as standalone"
            )
            self._ha_info["is_standby"] = False
            self._ha_info["ha_group"] = None
            return

        current_ip = self.transport.hostname
        # self.transport.hostname is the IP used to connect to this device.
        # We compare it with the parsed node IPs to determine which node WE are.
        # If we connected to the secondary IP, we ARE the secondary (standby).

        is_standby = secondary_node["ip"] == current_ip

        # Auto-sync is enabled if the primary node reports Sync State: ENABLED.
        # In practice the primary node's sync setting controls the pair.
        auto_sync = primary_node["sync_enabled"]

        # Determine initial sync state directly from the 'output' parameter.
        # "OUT OF SYNC" appears verbatim in show ha node output when the
        # secondary is not synchronized with the primary.
        # This sets the initial state at discovery time; _check_sync_state()
        # refreshes it just before save_config() runs (to catch changes since discovery).
        out_of_sync = bool(re.search(r"OUT\s+OF\s+SYNC", output, re.IGNORECASE))

        # Store peer IP: the IP of the OTHER node (not us).
        peer_ip = secondary_node["ip"] if not is_standby else primary_node["ip"]
        # If we are primary → peer is secondary.
        # If we are secondary → peer is primary.

        self._ha_info.update({
            "is_standby":   is_standby,
            "ha_group":     "ha_pair",    # Marker: Citrix uses "ha_pair" (no named group like F5)
            "ha_peer_ip":   peer_ip,
            "ha_auto_sync": auto_sync,
            "ha_state":     "OUT OF SYNC" if out_of_sync else "IN SYNC",
            # ha_state set from initial discovery; refreshed in _check_sync_state() at save time.
            "ha_anomaly":   auto_sync and out_of_sync,
            # Anomaly at discovery time; re-evaluated by _check_sync_state() at save time.
        })

    def _check_sync_state(self) -> None:
        """
        Check current HA sync state and update self._ha_info["ha_state"] and
        self._ha_info["ha_anomaly"].

        Called by save_config() on the primary node before deciding whether to
        enforce sync.  _discover_ha() must have been called first.

        "show ha node" output for an out-of-sync pair includes:
            Master State: OUT OF SYNC
        or:
            Sync State: OUT OF SYNC

        When in sync, these fields show "Enable" / "ENABLED" respectively.
        """
        try:
            out = self.transport.send_command("show ha node")
        except Exception as exc:
            logger.warning("[Citrix] Could not check sync state: %s — assuming in sync", exc)
            self._ha_info["ha_state"] = "unknown"
            self._ha_info["ha_anomaly"] = False
            return

        out_of_sync = bool(re.search(r"OUT\s+OF\s+SYNC", out, re.IGNORECASE))
        # "OUT OF SYNC" appears in the Master State or Sync State fields when the
        # secondary node is not synchronized with the primary.

        ha_state = "OUT OF SYNC" if out_of_sync else "IN SYNC"
        auto_sync = self._ha_info.get("ha_auto_sync", False)
        anomaly = auto_sync and out_of_sync
        # Anomaly = auto-sync ON but still out of sync → production issue.

        self._ha_info["ha_state"] = ha_state
        self._ha_info["ha_anomaly"] = anomaly

    # ── BaseDriver overrides — HA-capable methods ──────────────────────────────

    def is_ha_standby(self) -> bool:
        """
        Return True if this Citrix ADC node is currently the Secondary (standby) member.

        Runs _discover_ha() on first call.  Subsequent calls return from cache.

        Safe failure: if "show ha node" fails, _discover_ha() defaults is_standby
        to False → this method returns False → audit proceeds normally.
        """
        self._discover_ha()   # Populate self._ha_info (no-op if already cached)
        return self._ha_info.get("is_standby", False)

    def get_ha_info(self) -> dict:
        """
        Return the cached HA info dict for auditor.py to merge into AuditDeviceResult.

        Relevant keys: ha_group ("ha_pair"), ha_peer_ip, ha_auto_sync,
        ha_sync_enforced, ha_anomaly, ha_config_saved_members.

        Note: ha_members is not used for Citrix (F5 concept); use ha_peer_ip instead.
        save_config() adds ha_sync_enforced and ha_config_saved_members after the
        save operations complete.
        """
        if self._ha_info is None:
            return {}
        return self._ha_info

    def save_config(self) -> str:
        """
        HA-aware config save override for Citrix ADC.

        For STANDALONE Citrix (no HA peer):
          Falls back to BaseDriver.save_config() → _save_config() with retry.
          _save_config() issues "save ns config" on self.transport.

        For HA PRIMARY:
          1. Re-check current sync state (may have changed since discovery).
          2. If OUT OF SYNC + auto-sync enabled → raise HAAutoSyncAnomalyError.
          3. If OUT OF SYNC + auto-sync disabled → run "sync ha files" to push
             config from primary to secondary.
          4. Save on primary (self.transport) then SSH to secondary and save there.

        IMPORTANT: Called only when change=True.
        When change=False, audit_config() returns REPORT_ONLY before reaching here.
        """
        self._discover_ha()   # Ensure HA info is cached

        ha_group = self._ha_info.get("ha_group")
        if not ha_group:
            # Standalone Citrix ADC — use base class save with retry.
            logger.info("[Citrix] Standalone device — standard save ns config")
            result = super().save_config()
            self._ha_info["ha_sync_enforced"] = False
            self._ha_info["ha_config_saved_members"] = [self.transport.hostname]
            return result

        # ── HA path (primary node only) ────────────────────────────────────────
        # Re-check sync state now (not just at discovery time).
        self._check_sync_state()

        peer_ip   = self._ha_info.get("ha_peer_ip")
        auto_sync = self._ha_info.get("ha_auto_sync", False)
        ha_state  = self._ha_info.get("ha_state", "unknown")
        out_of_sync = (ha_state == "OUT OF SYNC")

        if out_of_sync and auto_sync:
            # Auto-sync is on but pair is out of sync → production issue.
            # Do NOT save.
            self._ha_info["ha_sync_enforced"] = False
            raise HAAutoSyncAnomalyError(
                f"Citrix HA pair has auto-sync (Sync State: ENABLED) but pair is "
                f"OUT OF SYNC (peer IP: {peer_ip}). "
                "Production issue — investigate HA synchronisation before saving."
            )

        # ── Force sync if needed (auto-sync off + out of sync) ────────────────
        if out_of_sync and not auto_sync:
            # Manually push the primary config to the secondary.
            logger.info(
                "[Citrix] HA pair OUT OF SYNC and auto-sync disabled — running sync ha files"
            )
            self.transport.send_command("sync ha files", timeout=60)
            # "sync ha files": Citrix NS command that forces an immediate push of
            # configuration files from the primary node to the secondary.
            # timeout=60: sync can take a while over slow links.
            self._ha_info["ha_sync_enforced"] = True
            logger.info("[Citrix] HA sync completed")
        else:
            self._ha_info["ha_sync_enforced"] = False
            # Group already in sync — no sync command needed.

        # ── Save on each node individually ────────────────────────────────────
        # Like F5, "save ns config" must be run on EACH node separately.
        # The HA sync replicates the running config, not the saved config file.
        saved_members = []
        self_hostname = self.transport.hostname   # IP we connected to (the primary)

        # ── Save on self (primary) ────────────────────────────────────────────
        try:
            self.transport.send_command("save ns config", timeout=60)
            # "save ns config": persists running config to the saved config file.
            # Equivalent to "write memory" on IOS.
            saved_members.append(self_hostname)
            logger.info("[Citrix] Saved config on primary (%s)", self_hostname)
        except Exception as exc:
            logger.error("[Citrix] Failed to save config on primary (%s): %s", self_hostname, exc)
            # Log and continue — still try to save on secondary.

        # ── Save on secondary (peer) ──────────────────────────────────────────
        if peer_ip and peer_ip != "unknown":
            try:
                self._save_on_peer(peer_ip=peer_ip, peer_hostname=peer_ip)
                saved_members.append(peer_ip)
                logger.info("[Citrix] Saved config on secondary (%s)", peer_ip)
            except Exception as exc:
                logger.error(
                    "[Citrix] Failed to save config on secondary (%s): %s", peer_ip, exc
                )
                # Log and continue — primary save was already done.
        else:
            logger.warning("[Citrix] Peer IP unknown — cannot save config on secondary")

        self._ha_info["ha_config_saved_members"] = saved_members

        summary = (
            f"HA save: {len(saved_members)} node(s) saved "
            f"({', '.join(saved_members)})"
        )
        logger.info("[Citrix] %s", summary)
        return summary

    def _save_on_peer(self, peer_ip: str, peer_hostname: str) -> None:
        """
        Open a fresh SSH connection to the Citrix HA secondary node and run
        'save ns config'.

        Args:
            peer_ip:       Management IP of the secondary Citrix ADC node.
            peer_hostname: Identifier for the peer (used in log messages only).

        Raises:
            Any exception from NetmikoTransport — caller (save_config()) logs and
            continues so the primary's save is not affected by a peer failure.
        """
        from ...transport.netmiko_transport import NetmikoTransport
        # Lazy import: avoids circular import at module load time.

        peer_transport = NetmikoTransport(
            hostname=peer_ip,
            username=self.username,            # Same credentials as primary connection
            password=self.password,            # Stored in BaseDriver.__init__
            device_type="generic_termserver",  # Netmiko device type for Citrix ADC
            # WHY generic_termserver?
            # Netmiko has no native Citrix driver. "generic_termserver" provides a
            # basic SSH connection that works for Citrix NS shell — it doesn't try
            # to apply any platform-specific prompt patterns, which is correct
            # because Citrix uses a custom prompt (">").
            port=self.port,
            secret=self.password,
        )
        peer_transport.connect()
        try:
            peer_transport.send_command("save ns config", timeout=60)
            # Same save command as the primary node.
        finally:
            peer_transport.disconnect()
            # Always close the peer SSH session — even if save failed.

    # ── Standard audit methods (unchanged from original) ─────────────────────

    def _get_os_version(self) -> Optional[str]:
        out = self.transport.send_command("show ns version")
        # Citrix NS version output:
        #   NetScaler NS13.1: Build 49.15.nc, Date: ...
        # Pattern 1: "NetScaler NS" followed by version (e.g. "13.1")
        m = re.search(r"NetScaler NS([\w.]+)", out, re.IGNORECASE)
        if not m:
            # Pattern 2: "Build" followed by build number (e.g. "49.15.nc")
            # Used as fallback if the NS version pattern doesn't match.
            m = re.search(r"Build\s+([\w.]+)", out, re.IGNORECASE)
        return m.group(1) if m else out.splitlines()[0][:80]

    def _check_filesystem(self) -> FilesystemResult:
        out = self.transport.send_command("df -h /var")
        # Citrix ADC NS shell allows standard POSIX "df" command.
        # "df -h /var" shows disk usage for the /var partition.
        # -h = human-readable sizes.
        #
        # Example output:
        #   Filesystem      Size    Used   Avail Capacity  Mounted on
        #   /dev/da0s1e     4.9G    2.1G   2.4G    47%    /var
        #
        # Note: FreeBSD df uses "Capacity" instead of "Use%" for the % column,
        # but the regex "(\d+)%" matches regardless of column header name.
        #
        # Failure cases:
        #   "no such": /var not a separate mount or df error
        #   "command not found": df not available in this NS shell version
        if not out or "no such" in out.lower() or "command not found" in out.lower():
            return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)
        for line in out.splitlines():
            if "/var" in line:
                m = re.search(r"(\d+)%", line)
                if m:
                    pct = float(m.group(1))
                    return FilesystemResult(
                        path="/var",                            # Path checked
                        usage_pct=pct,
                        status=self._filesystem_status(pct),    # OK/CRITICAL based on threshold
                    )
        return FilesystemResult(path="/var", usage_pct=None, status=FilesystemStatus.SKIPPED)

    def _check_fans(self) -> list[FanResult]:
        # VPX is virtual — no physical fans
        # SDX has hardware sensors accessible via show hardware
        out = self.transport.send_command("show hardware")
        # "show hardware" on Citrix ADC shows platform type and hardware details.
        # On VPX (virtual): output includes "virtual" or "VPX" in the platform field.
        # On SDX (hardware): output shows physical chassis info including fan status.
        #
        # Fan status keywords in SDX hardware output:
        #   "ok", "good", "normal" = fan working
        #   "failed" = fan problem
        if not out or "virtual" in out.lower() or "vpx" in out.lower():
            # VPX is a virtual appliance — it has no physical fans.
            # Return NA rather than FAIL (no fans is expected for VPX).
            return [FanResult(fan_id="all", status=FanStatus.NA)]
        results = []
        for line in out.splitlines():
            # Pattern: "fan<name>: <status>" format in hardware output.
            # Group 1: fan identifier (e.g. "fan tray 1", "fan-1")
            # Group 2: status keyword
            m = re.search(r"(fan[\w\s-]+):\s*(ok|good|failed|normal)", line, re.IGNORECASE)
            if m:
                status = FanStatus.PASS if re.search(r"ok|good|normal", m.group(2), re.IGNORECASE) else FanStatus.FAIL
                results.append(FanResult(fan_id=m.group(1).strip(), status=status))
        return results or [FanResult(fan_id="all", status=FanStatus.NA)]

    def _get_running_config(self) -> str:
        # "show ns runningConfig" shows the currently active ADC configuration.
        # This is the Citrix-specific equivalent of "show running-config".
        # Output includes: VIPs, LB methods, SSL certs, ACLs, etc.
        # timeout=60: large ADC configs with many VIPs can be slow.
        return self.transport.send_command("show ns runningConfig", timeout=60)

    def _get_startup_config(self) -> str:
        # "show ns savedConfig" shows the LAST SAVED configuration.
        # Unlike running config (in memory), saved config is what loads on next reboot.
        # If running != saved, there are unsaved changes that would be lost on reboot.
        return self.transport.send_command("show ns savedConfig", timeout=60)

    def _save_config(self) -> str:
        # Called by BaseDriver.save_config() (with retry) for standalone devices.
        # HA-capable save_config() override (above) calls super() only for standalone.
        #
        # "save ns config" saves the running config to the startup config.
        # Equivalent of "write memory" on IOS or "save /sys config" on F5.
        # After this, runningConfig == savedConfig — no unsaved changes.
        return self.transport.send_command("save ns config", timeout=60)

    def _get_active_sessions(self) -> list[SessionInfo]:
        # Citrix NS shell exposes `who` (FreeBSD-based)
        # Example: nsroot  pts/0        Oct 19 14:23   (10.0.0.100)
        #
        # WHY "who" and NOT "show users"?
        # Citrix NS shell is FreeBSD-based and exposes standard POSIX utilities.
        # "who" shows logged-in users with their login timestamp.
        #
        # FreeBSD "who" format differs from Linux "who":
        #   FreeBSD: "nsroot  pts/0  Oct 19 14:23  (10.0.0.100)"
        #   Linux:   "admin   pts/0  2024-10-19 14:23  (10.0.0.100)"
        # session_age_from_login_time() handles both "Oct 19 14:23" and "2024-10-19 14:23".
        out = self.transport.send_command("who")
        sessions = []
        for line in out.splitlines():
            if not line.strip():
                continue
            parts = line.split()
            # who output: "nsroot pts/0 Oct 19 14:23 (10.0.0.100)"
            # parts[0]=user, parts[1]=terminal, parts[2]=month, parts[3]=day, parts[4]=time
            if len(parts) >= 4:
                user = parts[0]      # Column 0: username (e.g. "nsroot")
                line_id = parts[1]   # Column 1: terminal (e.g. "pts/0")
                # Login time: "Oct 19 14:23" — parts[2] + parts[3] + parts[4]
                # Joining parts 2-4 gives "Oct 19 14:23" (month day time).
                login_str = " ".join(parts[2:5])
                age_hours = session_age_from_login_time(login_str)
                # session_age_from_login_time: "Oct 19 14:23" → hours since that time
                sessions.append(SessionInfo(
                    user=user,
                    line=line_id,
                    idle_hours=age_hours if age_hours is not None else 0.0,
                    # Default 0.0 = treat as active if parse fails (conservative).
                ))
        return sessions
