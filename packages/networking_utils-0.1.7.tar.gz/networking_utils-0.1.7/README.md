# network_device_audit

AWX-scheduled Ansible + Python tool that audits 4000+ heterogeneous network devices.

Ansible is a thin orchestrator only. All device interaction — SSH, detection, compliance checks, config remediation, and reporting — is implemented in native Python using Netmiko and Paramiko.

---

## Supported Platforms

| Platform | Notes |
|---|---|
| Cisco IOS | Includes Catalyst switches. Enable mode required. |
| Cisco IOS-XE | Includes Catalyst 9k+. Enable mode required. |
| Cisco IOS-XR | Enable mode required. |
| Cisco NX-OS | Enable mode required. ACI-mode devices are detected but skipped in audit. |
| Juniper JunOS | |
| Arista EOS | |
| F5 BIG-IP | |
| Citrix VPX/SDX | |
| Dell OS10 | |
| Dell OS9/FTOS | |
| A10 Networks | |

---

## Operational Modes

### Detect Mode (run weekly)
Logs into every device, identifies the platform, and writes `detect_result.yml` to the repo (or a local path).

### Audit Mode (run daily)
Reads `detect_result.yml` and performs compliance checks on each device:
- OS version collection
- Filesystem / `/var` usage (critical if > 70%)
- Fan health (pass/fail per fan)
- Running vs startup config comparison — if unsaved config exists: backup → save → verify

---

## Prerequisites

- Python 3.9+
- AWX with git push credentials configured (for `storage=repo` mode)
- Python dependencies installed on the AWX execution environment:

```bash
cd python/
pip install -e .
```

---

## Playbook Variables

| Variable | Default | Description |
|---|---|---|
| `detect_result_storage` | `repo` | Where to store/read `detect_result.yml`. `repo` = commit to git, `local` = `/var/lib/awx/detect_results/detect_result.yml` |
| `thread_count` | `8` | Number of concurrent device threads |
| `ssh_port` | `22` | SSH port |

Credentials (`ansible_user`, `ansible_password`) are injected by AWX machine credentials.

---

## Usage

### Run from AWX

1. Create two AWX job templates pointing to this project:
   - **Detect job**: playbook = `playbooks/detect.yml`, schedule = weekly
   - **Audit job**: playbook = `playbooks/audit.yml`, schedule = daily

2. Set extra variables on each job template as needed:

```yaml
detect_result_storage: repo   # or "local"
thread_count: 8
ssh_port: 22
```

3. Assign an AWX machine credential with `ansible_user` and `ansible_password`.

---

### Run from the command line (development/testing)

#### Detect mode

```bash
cd python/

python -m network_device_audit.main_detect \
  --inventory    /path/to/inventory.json \
  --username     admin \
  --password     s3cr3t \
  --artifact-dir /tmp/audit_artifacts \
  --repo-path    /path/to/project \
  --storage      repo \
  --threads      8 \
  --job-id       test-001
```

#### Audit mode

```bash
cd python/

python -m network_device_audit.main_audit \
  --inventory    /path/to/inventory.json \
  --username     admin \
  --password     s3cr3t \
  --artifact-dir /tmp/audit_artifacts \
  --repo-path    /path/to/project \
  --storage      repo \
  --threads      8 \
  --job-id       test-002
```

Use `--storage local` to skip git and write/read `detect_result.yml` from a local path instead:

```bash
python -m network_device_audit.main_detect \
  --storage local \
  ...

python -m network_device_audit.main_audit \
  --storage local \
  ...
```

---

### Inventory JSON format

Both entry points expect a flat JSON array:

```json
[
  { "hostname": "sw-core-01", "ip": "10.0.0.1" },
  { "hostname": "sw-core-02", "ip": "10.0.0.2" },
  { "hostname": "fw-edge-01", "ip": "10.0.1.1" }
]
```

The AWX playbooks generate this file automatically from the AWX inventory via the `roles/common/templates/inventory.json.j2` template.

---

## Artifacts

After each job run, a single `.tar.gz` file is written to the artifact directory and stored as an AWX job artifact (downloadable from the AWX UI). It contains:

```
detect_<job_id>_<timestamp>.tar.gz   (detect mode)
audit_<job_id>_<timestamp>.tar.gz    (audit mode)
  ├── audit_summary.json             — aggregate counts
  ├── devices/
  │   ├── <hostname>_audit_result.json
  │   └── <hostname>_session.log
  └── backups/
      └── <hostname>_startup_backup.txt  (only when config was saved)
```

---

## Project Structure

```
network_device_audit/
  playbooks/
    detect.yml
    audit.yml
  roles/
    detect/
    audit/
    common/
  python/
    src/network_device_audit/
      core/           # models, exceptions, retry, logger
      transport/      # Netmiko + Paramiko transports
      detect/         # detector, fingerprint, ACI heuristic, result_store
      audit/          # auditor, config_audit, reporter
      drivers/        # base driver + 11 platform drivers + registry
      parsers/
    requirements.txt
    setup.py
  inventories/
  artifacts/
  detect_result.yml   # written by detect mode, read by audit mode
```
