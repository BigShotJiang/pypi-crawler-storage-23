import unittest


def test_import():
    import gtaf_sdk


class TestImport(unittest.TestCase):
    def test_import(self):
        test_import()


if __name__ == "__main__":
    unittest.main()
