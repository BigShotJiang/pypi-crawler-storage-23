import matplotlib
import numpy as np
import matplotlib.pyplot as plt

x = np.random.rand(100, 100)
plt.imshow(x)
plt.show()
