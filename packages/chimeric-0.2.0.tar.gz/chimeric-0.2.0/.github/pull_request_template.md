## Summary

<!-- What does this PR do? -->

-

## Breaking Changes

<!-- List any breaking changes, or write "None". -->

None

## Test Plan

<!-- What was tested? -->

- [ ]
- [ ]

## Checklist

- [ ] Tests pass (`nox -s tests`)
- [ ] Coverage ≥ 80%
- [ ] Docs updated (if public API changed)
- [ ] No hardcoded secrets or credentials
