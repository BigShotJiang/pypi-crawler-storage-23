"""Unit tests for chimeric package."""
