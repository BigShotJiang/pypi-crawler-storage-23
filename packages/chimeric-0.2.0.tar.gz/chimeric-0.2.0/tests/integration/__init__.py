"""Integration tests for chimeric package."""
