"""Cachibot services."""

from cachibot.services.name_generator import generate_bot_names

__all__ = ["generate_bot_names"]
