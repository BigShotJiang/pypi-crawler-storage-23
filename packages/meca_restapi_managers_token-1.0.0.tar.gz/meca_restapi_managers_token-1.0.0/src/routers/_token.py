from ..tables.db import SqlDB
from ..tables.token import Token

from fastapi import APIRouter

db = SqlDB('home#token.db').wal().check_same_thread(False)
SessionAnnotated = db.SessionAnnotated
token = APIRouter(lifespan=db.init)


@token.post('/update')
async def update(token: Token, session: SessionAnnotated) -> Token:
    existing = session.get(Token, (token.app, token.user))
    if existing:
        session.merge(token)
        session.commit()
        session.refresh(existing)
        return existing
    else:
        session.add(token)
        session.commit()
        session.refresh(token)
        return token


@token.post('/get')
def get(token: Token, session: SessionAnnotated) -> Token:
    token = session.get(Token, (token.app, token.user))
    return token
