from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated, List
from typing_extensions import Self  # 兼容Python3.10

from sqlalchemy import Engine
from sqlmodel import Session, SQLModel, create_engine

from fastapi import Depends, FastAPI


class SqlDB:
    path: Path | str
    connect_args: dict = {}
    uri: str
    query: List[str] = []
    db: str

    _engine: Engine = None

    def _parse_path(self, path: str | Path):
        if isinstance(path, Path):
            path = path.absolute()
        elif isinstance(path, str) and path.startswith('home#'):
            path = (Path('~')/'databases'/path.split('#')[1]).expanduser().absolute()
        else:
            return

        if not path.parent.is_dir():
            path.parent.mkdir(parents=True, exist_ok=True)
        self.uri = f'sqlite:///{path.as_posix()}'
        self.path = path

    def __init__(self, path: str | Path) -> Self:
        self._parse_path(path=path)

    def __str__(self):
        if self.query:
            return f'{self.uri}?{"&".join(self.query)}'
        else:
            return f'{self.uri}'
        
    def __repr__(self):
        return str(self)
    
    def wal(self) -> Self:
        self.query.append('journal_mode=WAL')
        return self
    
    def check_same_thread(self, value: bool) -> Self:
        self.connect_args['check_same_thread'] = value
        return self

    @property
    def engine(self) -> Engine:
        if self._engine is None:
            self._engine = create_engine(str(self), connect_args=self.connect_args)
        return self._engine

    @asynccontextmanager
    async def init(self, _app: FastAPI):
        SQLModel.metadata.create_all(self.engine)
        yield

    @property
    def SessionAnnotated(self) -> Annotated:
        def _session():
            with Session(self.engine) as __session:
                yield __session
        return Annotated[Session, Depends(_session)]