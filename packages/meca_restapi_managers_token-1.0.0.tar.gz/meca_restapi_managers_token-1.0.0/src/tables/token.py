from sqlmodel import Field, SQLModel
from time import time

class Token(SQLModel, table=True):
    app: str = Field(primary_key=True)
    user: str = Field(primary_key=True)
    access_token: str
    refresh_token: str
    access_exp: int
    refresh_exp: int

    @property
    def access_valid(self) -> bool:
        return self.access_exp > time.time()
    
    @property
    def refresh_valid(self) -> bool:
        return self.refresh_exp > time.time()