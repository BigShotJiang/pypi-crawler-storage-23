"""
Screens module for minion_code
Contains UI screen components using Textual
"""
