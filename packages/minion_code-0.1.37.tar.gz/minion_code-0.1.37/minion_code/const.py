#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pathlib import Path

# Define the root directory of the minion project
MINION_CODE_ROOT = Path(__file__).parent.parent
