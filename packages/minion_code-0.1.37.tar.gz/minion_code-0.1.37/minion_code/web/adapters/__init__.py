"""Web output adapters."""

from .web_adapter import WebOutputAdapter

__all__ = ["WebOutputAdapter"]
