"""Web services."""

from .session_manager import SessionManager, session_manager

__all__ = ["SessionManager", "session_manager"]
