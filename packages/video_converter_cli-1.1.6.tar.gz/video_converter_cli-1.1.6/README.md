# Video and Image Converter

Command-line tool to convert videos and images between formats (FFmpeg for video, Pillow for images).

**Developed by [L3CHUGU1T4](https://github.com/L3CHUGU1T4)**

---

## Install (PyPI)

Requires Python 3.8+ and [FFmpeg](https://ffmpeg.org/download.html) (for video conversion; images work without it).

```bash
pip install video-converter-cli
```

---

## Requirements

- Python 3.8+
- FFmpeg (for video conversion)
- Pillow (included via pip)

---

## Usage

Run `converter` from any directory:

```bash
converter --help
```

### Arguments and options

| Argument / Option | Description |
|-------------------|-------------|
| `files`           | One or more video or image files to convert. |
| `-o`, `--output PATH` | Output file path (only when converting a single file). |
| `--quality {ultrafast,fast,medium,slow,veryslow}` | Video encoding preset (default: `medium`). |
| `--crf N`         | Video quality 18–28; lower = better (default: `22`). |

### Default output

- **Videos:** `<name>.mp4` in the same directory.
- **Images:** JPEG/JPG → `<name>.png`; others → `<name>.jpg`.

### Supported formats

- **Video:** AVI, MP4, MOV, MKV, WebM, FLV, WMV, M4V  
- **Image:** JPEG, PNG, BMP, TIFF, WebP, GIF  

---

## Examples

```bash
converter video.avi
converter video.avi -o output.mov
converter image.jpg
converter image.png -o output.jpg
converter video.avi --quality slow --crf 18
converter file1.avi file2.jpg file3.png
```

---

## Building an executable locally (optional)

If you want a standalone executable (no pip) on your machine:

```bash
pip install -r requirements.txt
python build_exe.py
python install.py
```

Or manually:

```bash
pip install pyinstaller
pyinstaller --onefile --name converter Converter.py
```

The executable will be in `dist/converter` (or `dist/converter.exe` on Windows).

---

## Publishing to PyPI

To publish or update the package on PyPI:

```bash
pip install build twine
python -m build
twine upload dist/*.whl dist/*.tar.gz
```

(Use `build_exe.py` only for building the standalone executable; use `python -m build` for the PyPI package.)

Users can then install with: `pip install video-converter-cli` and run `converter`.

---

## License

MIT License. See [LICENSE](LICENSE).

**Developed by L3CHUGU1T4**
