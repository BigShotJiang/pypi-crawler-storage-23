# The `npfl139` Package: Modules Used in the Deep Reinforcement Learning Course (NPFL139)

This package contains the modules used in the
[Deep Reinforcement Learning course (NPFL139)](http://ufal.mff.cuni.cz/courses/npfl139),
available under the Mozilla Public License 2.0.
