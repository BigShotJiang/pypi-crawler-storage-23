"""
Torrent: Expert-Aware Multi-Batch Pipeline for MoE Inference

论文实现: Klotski: Efficient Mixture-of-Expert Inference via Expert-Aware Multi-Batch Pipeline
arXiv:2502.06888 (2025)

与 speculators / vLLM 生态配合使用，可在 pip install speculators 后
通过 pip install torrent-moe 独立安装。

安装方式:
    pip install speculators
    pip install torrent-moe
"""

from torrent.planner import HardwareProfiler, ConstraintSolver
from torrent.prefetch import CorrelationTable, AsyncLoader
from torrent.runtime import MemoryManager, ExpertExecutor, TorrentPipeline
from torrent.metrics import MetricsCollector
from torrent.nbatch_engine import TorrentNBatchEngine

__version__ = "0.1.0"
__all__ = [
    "HardwareProfiler",
    "ConstraintSolver",
    "CorrelationTable",
    "AsyncLoader",
    "MemoryManager",
    "ExpertExecutor",
    "TorrentPipeline",
    "MetricsCollector",
    "TorrentNBatchEngine",
]
