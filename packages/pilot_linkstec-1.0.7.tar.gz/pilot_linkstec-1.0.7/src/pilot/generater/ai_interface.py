# 文件：pilot/generater/ai_interface.py
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

# 导入刚才定义的 DTO
from pilot.generater.generation_config import GenerationConfigDTO


class AIInterface(ABC):
    @abstractmethod
    def generate_content(
            self,
            prompt: str,
            gen_config: Optional[GenerationConfigDTO] = None,
            stream: Optional[bool] = None,
            **kwargs
    ) -> Dict[str, Any]:
        """
        AI コンテンツ生成の抽象メソッド。

        Args:
            prompt: ユーザーからの入力テキスト
            gen_config: AIの生成パラメータを制御するDTO
            stream: ストリーミング出力を強制するかどうか（DTOの設定を上書き）
            **kwargs: 各ベンダー固有の特殊なパラメータ用
        """
        pass