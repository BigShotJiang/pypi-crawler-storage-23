"""
VLA Auto-Shape - Universal Drop-in Replacement
===============================================
Automatically handles ANY tensor shape.
Just enable and everything works at VLA precision.

Usage:
    from simgen.vla.auto import enable_auto
    enable_auto()

    # Now torch.sum and torch.matmul use VLA
    result = torch.sum(x)           # Any shape
    result = torch.matmul(a, b)     # 1D, 2D, 3D, 4D
"""

import torch
from typing import Optional
from functools import wraps

# Import the base VLA functions
from ..vla_runtime import (
    vla_sum, vla_mean, vla_var, vla_std, vla_norm,
    vla_dot, vla_matmul, vla_bmm,
    vla_mse_loss,
    VLAResult,
)

_enabled = False
_original_ops = {}


# =============================================================================
# Auto-Shape Wrappers
# =============================================================================

def auto_sum(x: torch.Tensor, dim=None, keepdim: bool = False, **kwargs) -> torch.Tensor:
    """VLA sum with automatic shape handling."""
    if not x.is_cuda:
        return _original_ops['sum'](x, dim=dim, keepdim=keepdim, **kwargs)

    if dim is None:
        result = vla_sum(x, exact=True)
        return result if not keepdim else result.reshape([1] * x.ndim)

    # Reduction along specific dim
    if isinstance(dim, int):
        dim = dim if dim >= 0 else x.ndim + dim
        dims = [dim]
    else:
        dims = [d if d >= 0 else x.ndim + d for d in dim]

    # Use FP64 for now (VLA kernel is for full reduction)
    result = x.double().sum(dim=dim, keepdim=keepdim)
    return result


def auto_matmul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """VLA matmul with automatic shape handling for 1D to 4D."""
    if not a.is_cuda:
        return _original_ops['matmul'](a, b)

    # 1D @ 1D -> dot product
    if a.ndim == 1 and b.ndim == 1:
        return vla_dot(a, b)

    # 2D @ 2D -> matrix multiply
    if a.ndim == 2 and b.ndim == 2:
        return vla_matmul(a, b)

    # 3D @ 3D -> batch matmul
    if a.ndim == 3 and b.ndim == 3:
        return vla_bmm(a, b)

    # 4D @ 4D -> reshape to 3D, bmm, reshape back
    if a.ndim == 4 and b.ndim == 4:
        B1, B2, M, K = a.shape
        _, _, K2, N = b.shape
        a_3d = a.reshape(B1 * B2, M, K)
        b_3d = b.reshape(B1 * B2, K, N)
        result = vla_bmm(a_3d, b_3d)
        return result.reshape(B1, B2, M, N)

    # Mixed dimensions - use FP64
    return torch.matmul(a.double(), b.double())


def auto_mm(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """VLA mm (2D only)."""
    if not a.is_cuda:
        return _original_ops['mm'](a, b)
    return vla_matmul(a, b)


def auto_bmm(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """VLA bmm (3D only)."""
    if not a.is_cuda:
        return _original_ops['bmm'](a, b)
    return vla_bmm(a, b)


# =============================================================================
# Enable/Disable
# =============================================================================

def enable_auto():
    """Enable VLA auto-shape for ALL tensor operations."""
    global _enabled, _original_ops

    if _enabled:
        return

    # Store originals
    _original_ops['sum'] = torch.sum
    _original_ops['matmul'] = torch.matmul
    _original_ops['mm'] = torch.mm
    _original_ops['bmm'] = torch.bmm

    # Patch
    torch.sum = auto_sum
    torch.matmul = auto_matmul
    torch.mm = auto_mm
    torch.bmm = auto_bmm

    _enabled = True
    print("[VLA Auto] Enabled - torch.sum/matmul now use VLA")


def disable_auto():
    """Disable VLA auto-shape and restore original ops."""
    global _enabled, _original_ops

    if not _enabled:
        return

    torch.sum = _original_ops['sum']
    torch.matmul = _original_ops['matmul']
    torch.mm = _original_ops['mm']
    torch.bmm = _original_ops['bmm']

    _enabled = False
    print("[VLA Auto] Disabled - using standard PyTorch")


class auto_mode:
    """Context manager for VLA auto mode."""

    def __enter__(self):
        enable_auto()
        return self

    def __exit__(self, *args):
        disable_auto()


__all__ = [
    'enable_auto',
    'disable_auto',
    'auto_mode',
    'auto_sum',
    'auto_matmul',
    'auto_mm',
    'auto_bmm',
]
