"""Allow running as ``python -m parse_lp``."""

import sys

from parse_lp.cli import main

sys.exit(main())
