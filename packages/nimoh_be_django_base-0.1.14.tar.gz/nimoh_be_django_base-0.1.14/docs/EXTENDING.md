# Extending nimoh-be-django-base

This guide covers the main extension points: the user model, email templates,
serializers/views, and middleware.

---

## 1. Subclassing `AbstractNimohUser`

### Minimal (no extra fields)

```python
# profiles/models.py
from nimoh_base.auth.models import AbstractNimohUser

class User(AbstractNimohUser):
    class Meta(AbstractNimohUser.Meta):
        swappable = "AUTH_USER_MODEL"
```

Even if you add nothing, creating your own concrete model lets you add fields
later without touching the package.

### With additional fields

```python
from nimoh_base.auth.models import AbstractNimohUser
from django.db import models

class User(AbstractNimohUser):
    bio         = models.TextField(blank=True)
    website     = models.URLField(blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    is_premium  = models.BooleanField(default=False)

    class Meta(AbstractNimohUser.Meta):
        swappable = "AUTH_USER_MODEL"
```

### Using `AbstractNimohUser` built-ins

```python
# Lock account manually
user.lock_account(duration_minutes=60)

# In a login view / signal handler
if auth_failed:
    user.record_failed_login()   # auto-locks after threshold

if auth_succeeded:
    user.record_successful_login()

# Check before processing a request
if user.is_account_locked():
    raise PermissionDenied("Account temporarily locked.")
```

---

## 2. Custom User Serializers

The package ships `UserSerializer` and `RegisterSerializer` in
`nimoh_base.auth.serializers`.  Override them in your project:

```python
# profiles/serializers.py
from nimoh_base.auth.serializers import UserSerializer as BaseUserSerializer

class UserSerializer(BaseUserSerializer):
    class Meta(BaseUserSerializer.Meta):
        fields = BaseUserSerializer.Meta.fields + ["bio", "website", "is_premium"]
        read_only_fields = BaseUserSerializer.Meta.read_only_fields + ["is_premium"]
```

Then point DRF at the override by adding to your settings:

```python
# config/settings/base.py
REST_FRAMEWORK = {
    **NimohBaseSettings.get_base_rest_framework(),
    "DEFAULT_AUTHENTICATION_CLASSES": [...],   # keep other keys from base
}
```

Or swap the serializer class inside a custom view (see below).

---

## 3. Extending Package Views

Package views live in `nimoh_base.auth.views`, `nimoh_base.monitoring.views`,
and `nimoh_base.privacy.views`.  The cleanest override pattern is subclassing:

```python
# profiles/views.py
from nimoh_base.auth.views import UserDetailView

class UserDetailView(UserDetailView):
    '''Return extra profile fields alongside base user data.'''

    def get_serializer_class(self):
        from profiles.serializers import UserSerializer
        return UserSerializer
```

Then register the override URL **before** `nimoh_base_urlpatterns()`:

```python
# config/urls.py
from profiles.views import UserDetailView

urlpatterns = [
    path("api/v1/auth/user/", UserDetailView.as_view()),   # ← your override
    *nimoh_base_urlpatterns(api_prefix="api/v1/"),         # ← package defaults
]
```

Django matches the first applicable pattern, so your override wins.

---

## 4. Email Template Overrides

The package ships Jinja2-compatible HTML + plain-text templates under:

```
nimoh_base/templates/
  emails/
    auth/
      email_verification_email.html
      email_verification_email.txt
      password_reset_email.html
      password_reset_email.txt
      account_locked_email.html
    privacy/
      gdpr_export_email.html
      data_deletion_confirmation_email.html
```

**Override any template** by placing a matching file in your project's template
directory (must appear in `TEMPLATES[*]['DIRS']`):

```
myproject/
└── templates/
    └── emails/
        └── auth/
            └── password_reset_email.html   ← your custom version
```

Template context variables available in every auth email:

| Variable | Description |
|----------|-------------|
| `site_name` | `NIMOH_BASE['SITE_NAME']` |
| `support_email` | `NIMOH_BASE['SUPPORT_EMAIL']` |
| `user` | The `User` instance |
| `uid` | URL-safe base64-encoded user PK |
| `token` | One-time token |
| `domain` | Request domain |
| `protocol` | `https` or `http` |

---

## 5. Adding Custom Middleware

`NimohBaseSettings.get_base_middleware()` returns a list you can extend:

```python
MIDDLEWARE = NimohBaseSettings.get_base_middleware() + [
    "myproject.middleware.RequestIDMiddleware",
    "myproject.middleware.TenantMiddleware",
]
```

To **replace** a package middleware, copy the list and swap the entry:

```python
base = NimohBaseSettings.get_base_middleware()
MIDDLEWARE = [
    m.replace(
        "nimoh_base.core.middleware.security.SecurityHeadersMiddleware",
        "myproject.middleware.CustomSecurityHeadersMiddleware",
    )
    for m in base
]
```

---

## 6. Custom Throttle Classes

The package registers several named throttle scopes.  Add project-specific
scopes without replacing the defaults:

```python
REST_FRAMEWORK = {
    **NimohBaseSettings.get_base_rest_framework(),
    "DEFAULT_THROTTLE_RATES": {
        # keep package defaults
        **NimohBaseSettings.get_base_rest_framework()["DEFAULT_THROTTLE_RATES"],
        # add project-specific scopes
        "premium_api": "1000/day",
        "public_upload": "20/hour",
    },
}
```

---

## 7. BYO Privacy Profile fields

`PrivacyProfile` is a concrete model with a `OneToOneField` to `AUTH_USER_MODEL`.
Add extra consent or preference fields by creating a **parallel** profile model
in your project and connecting it via a signal or property — rather than
monkey-patching the package model.

```python
# profiles/models.py
from django.db import models
from django.conf import settings

class ExtendedPrivacyProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="extended_privacy",
    )
    opt_in_marketing = models.BooleanField(default=False)
    opt_in_analytics = models.BooleanField(default=False)
```

---

## 8. Running Package Tests Against Your Model

If you override `AbstractNimohUser`, run the package test suite with your
concrete model to catch any regressions:

```bash
# Point DJANGO_SETTINGS_MODULE at a test-settings file that sets AUTH_USER_MODEL
# to your concrete User subclass, then:
pytest tests/ -v
```

The package's `conftest.py` uses `pytest-django` and auto-discovers fixtures from
`tests/factories.py`.
