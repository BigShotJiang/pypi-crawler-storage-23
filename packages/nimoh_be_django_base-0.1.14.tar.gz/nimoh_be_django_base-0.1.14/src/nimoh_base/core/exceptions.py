"""
Custom exception handlers implementing RFC 7807 Problem Details for HTTP APIs.

This module provides Problem+JSON format error responses for better API error handling.
"""

import logging

from rest_framework import status
from rest_framework.exceptions import APIException, ValidationError
from rest_framework.views import exception_handler

logger = logging.getLogger(__name__)


class ProblemDetailException(APIException):
    """
    Base exception class for Problem+JSON formatted errors (RFC 7807).

    Attributes:
        status_code: HTTP status code
        default_detail: Default error message
        type: Problem type URI
        title: Short error title
        detail: Detailed error description
        instance: URI identifying specific error instance
    """

    status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
    default_detail = "A server error occurred."
    default_code = "error"

    def __init__(self, detail=None, code=None, type_uri=None, title=None, instance=None, status_code=None, **kwargs):
        if status_code is not None:
            self.status_code = status_code
        super().__init__(detail, code)
        self.type = type_uri or "about:blank"
        self.title = title or get_error_title(self.status_code)
        self.instance = instance
        self.extra = kwargs


def get_error_title(status_code):
    """Get a human-readable title for HTTP status code."""
    titles = {
        400: "Bad Request",
        401: "Unauthorized",
        403: "Forbidden",
        404: "Not Found",
        405: "Method Not Allowed",
        409: "Conflict",
        422: "Unprocessable Entity",
        429: "Too Many Requests",
        500: "Internal Server Error",
        502: "Bad Gateway",
        503: "Service Unavailable",
    }
    return titles.get(status_code, "Error")


def get_error_detail(exc):
    """Extract detailed error message from exception."""
    if hasattr(exc, "detail"):
        return exc.detail
    return str(exc)


def format_validation_errors(validation_errors):
    """Format Django/DRF validation errors into Problem+JSON invalid-params format."""
    invalid_params = []

    if isinstance(validation_errors, dict):
        for field, errors in validation_errors.items():
            if isinstance(errors, list):
                for error in errors:
                    invalid_params.append({"name": field, "reason": str(error)})
            else:
                invalid_params.append({"name": field, "reason": str(errors)})
    elif isinstance(validation_errors, list):
        for error in validation_errors:
            invalid_params.append({"name": "non_field_error", "reason": str(error)})
    else:
        invalid_params.append({"name": "non_field_error", "reason": str(validation_errors)})

    return invalid_params


def log_error(exc, context, status_code):
    """Log error with comprehensive context information."""
    request = context.get("view").request if context.get("view") else None

    extra_context = {
        "status_code": status_code,
        "exception_class": exc.__class__.__name__,
    }

    if request:
        extra_context.update(
            {
                "path": request.path,
                "method": request.method,
                "user": str(request.user) if hasattr(request, "user") else None,
                "ip": get_client_ip(request),
            }
        )

    logger.error(
        f"API Exception: {exc.__class__.__name__}", exc_info=exc if status_code >= 500 else None, extra=extra_context
    )


# Consolidated: Use nimoh_base.core.utils.get_client_ip
from nimoh_base.core.utils import get_client_ip  # noqa: E402


def problem_exception_handler(exc, context):
    """
    Custom exception handler implementing RFC 7807 Problem Details.

    Converts all DRF exceptions into Problem+JSON format for consistent error responses.

    Also fixes the ATOMIC_REQUESTS interaction: DRF's default handler calls
    set_rollback() for ALL exceptions including 4xx client errors, which
    prevents legitimate side effects (audit logs, failed-login counters)
    from persisting. We reverse the rollback flag for client errors so that
    only 5xx server errors trigger a transaction rollback.
    """
    # Call DRF's default exception handler first
    response = exception_handler(exc, context)

    if response is not None:
        status_code = response.status_code

        # For client errors (4xx), reverse the rollback that DRF's default
        # handler applied so side-effect writes (audit logs, login counters)
        # persist even when a validation/auth error is raised.
        if status_code < 500:
            from django.db import connection

            if connection.in_atomic_block:
                connection.set_rollback(False)

        # Build Problem+JSON response
        problem_data = {
            "type": "about:blank",
            "title": get_error_title(status_code),
            "status": status_code,
            "detail": get_error_detail(exc),
        }

        # Add instance URI if available from request context
        request = context.get("view").request if context.get("view") else None
        if request:
            problem_data["instance"] = request.path

        # Handle validation errors specially
        if isinstance(exc, ValidationError):
            problem_data["type"] = "about:blank#validation-error"
            problem_data["title"] = "Validation Error"
            problem_data["invalid_params"] = format_validation_errors(exc.detail)

        # Add custom fields from ProblemDetailException
        if isinstance(exc, ProblemDetailException):
            if exc.type:
                problem_data["type"] = exc.type
            if exc.title:
                problem_data["title"] = exc.title
            if exc.instance:
                problem_data["instance"] = exc.instance
            if exc.extra:
                problem_data.update(exc.extra)

        # Log the error
        log_error(exc, context, status_code)

        response.data = problem_data

    return response


# Alias for backward compatibility
custom_exception_handler = problem_exception_handler
