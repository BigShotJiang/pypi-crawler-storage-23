"""Task definitions for System Monitor service."""

from typing import ClassVar

from orangeqs.juice.task import Task


class EnableHeater(Task):
    """Task to enable a Heater."""

    component_id: str
    parallel: ClassVar[bool] = True


class DisableHeater(Task):
    """Task to disable a Heater."""

    component_id: str
    parallel: ClassVar[bool] = True


class SetHeaterPower(Task):
    """Task to set the power setting level of a Heater."""

    component_id: str
    power: float
    parallel: ClassVar[bool] = True


class GetHeaterOutputPower(Task):
    """Task to get the output power of a Heater."""

    component_id: str
    parallel: ClassVar[bool] = True


class GetHeaterPowerSetting(Task):
    """Task to get the power setting of a Heater."""

    component_id: str
    parallel: ClassVar[bool] = True


class IsHeaterEnabled(Task):
    """Task to check if a Heater is enabled."""

    component_id: str
    parallel: ClassVar[bool] = True


class AreCompressorsEnabled(Task):
    """Task to check if compressors are enabled."""

    parallel: ClassVar[bool] = True


class EnableCompressors(Task):
    """Task to enable compressors."""

    parallel: ClassVar[bool] = True


class DisableCompressors(Task):
    """Task to disable compressors."""

    parallel: ClassVar[bool] = True


class GetGHSValveState(Task):
    """Task to get state of GHS valve."""

    valve_id: str
    parallel: ClassVar[bool] = True


class OpenGHSValve(Task):
    """Task to open GHS valve."""

    valve_id: str
    parallel: ClassVar[bool] = True


class CloseGHSValve(Task):
    """Task to close GHS valve."""

    valve_id: str
    parallel: ClassVar[bool] = True


class GetGHSPumpState(Task):
    """Task to get state of GHS pump."""

    pump_id: str
    parallel: ClassVar[bool] = True


class EnableGHSPump(Task):
    """Task to enable GHS pump."""

    pump_id: str
    parallel: ClassVar[bool] = True


class DisableGHSPump(Task):
    """Task to disable GHS pump."""

    pump_id: str
    parallel: ClassVar[bool] = True


class StartGHSCondensation(Task):
    """Task to start condensation."""

    parallel: ClassVar[bool] = True


class StartGHSRecovery(Task):
    """Task to start recovery."""

    parallel: ClassVar[bool] = True
