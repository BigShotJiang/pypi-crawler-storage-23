"""Module containting OQS juice mock GHS."""

from collections.abc import Sequence

from orangeqs.juice.messaging import Event
from orangeqs.juice.system_monitor.data_structures import (
    ComponentEnabledPoint,
    FlowratePoint,
    PressurePoint,
)
from orangeqs.juice.system_monitor.mock_settings import MockGHSSettings


class MockGHS:
    """Mock Class for GHS device."""

    def __init__(
        self,
        settings: MockGHSSettings,
        component_id: str = "ghs",
    ) -> None:
        self._component_id = component_id
        self.settings = settings
        self._pressures: dict[str, float] = {
            name: idx for idx, name in enumerate(settings.pressure_sensors)
        }
        self._valve_states: dict[str, bool] = {name: False for name in settings.valves}
        self._pump_states: dict[str, bool] = {name: False for name in settings.pumps}
        self._flow = 11

    async def update(self) -> bool:
        """Blank update."""
        return True

    async def open_valve(self, valve_id: str) -> bool:
        """Mock opening a valve."""
        if valve_id not in self.settings.valves:
            raise ValueError(f"Valve ID {valve_id} not recognized.")
        self._valve_states[valve_id] = True
        return True

    async def close_valve(self, valve_id: str) -> bool:
        """Mock closing a valve."""
        if valve_id not in self.settings.valves:
            raise ValueError(f"Valve ID {valve_id} not recognized.")
        self._valve_states[valve_id] = False
        return True

    async def start_pump(self, pump_id: str) -> bool:
        """Mock starting a pump."""
        if pump_id not in self.settings.pumps:
            raise ValueError(f"Pump ID {pump_id} not recognized.")
        self._pump_states[pump_id] = True
        return True

    async def stop_pump(self, pump_id: str) -> bool:
        """Mock stopping a pump."""
        if pump_id not in self.settings.pumps:
            raise ValueError(f"Pump ID {pump_id} not recognized.")
        self._pump_states[pump_id] = False
        return True

    async def start_condense_helium(self) -> bool:
        """Mock start of condensation."""
        return True

    async def start_recover_helium(self) -> bool:
        """Mock start of recovery."""
        return True

    @property
    def pressures(self) -> dict[str, float]:
        """Current pressures of all lines in the GHS."""
        return self._pressures

    @property
    def flow(self) -> float:
        """Current flow rate of the helium mixture."""
        return self._flow

    @property
    def valve_states(self) -> dict[str, bool]:
        """Current states of all valves in the GHS."""
        return self._valve_states

    @property
    def pump_states(self) -> dict[str, bool]:
        """Current states of all pumps in the GHS."""
        return self._pump_states

    @property
    def datapoints(self) -> Sequence[Event]:
        """Get all datapoints for the Bluefors GHS state."""
        points: Sequence[Event] = [
            *[
                PressurePoint(
                    pressure=press,
                    unit="bar",
                    component_id=self._component_id,
                    sensor_id=sid,
                )
                for sid, press in self.pressures.items()
            ],
            FlowratePoint(
                component_id=self._component_id,
                sensor_id="flow",
                flowrate=self.flow,
                unit="mmol/sec",
            ),
            *[
                ComponentEnabledPoint(
                    component_id=f"{self._component_id}.{valve}",
                    enabled=open,
                )
                for valve, open in self.valve_states.items()
            ],
            *[
                ComponentEnabledPoint(
                    component_id=f"{self._component_id}.{pump}",
                    enabled=on,
                )
                for pump, on in self.pump_states.items()
            ],
        ]

        return points
