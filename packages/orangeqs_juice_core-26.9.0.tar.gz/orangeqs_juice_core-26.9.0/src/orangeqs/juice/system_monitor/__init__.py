"""OrangeQS Juice System Monitor Service."""
