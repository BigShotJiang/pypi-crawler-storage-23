"""Configure formatting of warnings in the CLI using `click`."""

import logging

import click


class _ClickWarningHandler(logging.Handler):
    """Custom logging handler that emits formatted warnings using `click`."""

    def __init__(self) -> None:
        logging.Handler.__init__(self=self)

    def emit(self, record: logging.LogRecord) -> None:
        r"""Format the warning message and output it using `click`.

        The raw message is expected to be in the format
        `"{location}: {message}\n warnings.warn(\n"`, which is the output from
        `warnings.formatwarning` and cannot be changed.

        The warning will be emitted as bold yellow text in the following format:
        ```
        [WARNING] {message}
        {location}
        ```

        Parameters
        ----------
        record : logging.LogRecord
            The log record containing the warning message.
        """
        contents, *_ = record.getMessage().rsplit("\n", 2)
        location, message = contents.split(" ", 1)
        formatted = f"[{record.levelname}] {message}\n{location.strip(':')}"
        click.echo(click.style(formatted, fg="yellow", bold=True), err=True)


def configure_warnings_formatting() -> None:
    """Configure warnings to use a custom logging handler that uses `click`."""
    # Capture warnings and redirect them to the logging system
    logging.captureWarnings(True)

    handler = _ClickWarningHandler()
    handler.setLevel(logging.WARNING)

    logger = logging.getLogger("py.warnings")
    logger.setLevel(logging.WARNING)
    logger.addHandler(handler)
