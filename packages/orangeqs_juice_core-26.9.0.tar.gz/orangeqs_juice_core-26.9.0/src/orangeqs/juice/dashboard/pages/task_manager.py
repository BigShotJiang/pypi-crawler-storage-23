"""Task Manager Page."""

from __future__ import annotations

import logging
import traceback
from importlib.resources import files
from typing import TYPE_CHECKING, Any

import panel as pn
from bokeh.themes import Theme

from orangeqs.juice.dashboard import juice_environment
from orangeqs.juice.dashboard.widgets import ServiceStatusWidget, TaskTableWidget
from orangeqs.juice.orchestration.settings import OrchestrationSettings

if TYPE_CHECKING:
    from panel.template import Template

_logger = logging.getLogger(__name__)

BOKEH_THEME = Theme(
    filename=str(files("orangeqs.juice.dashboard").joinpath("theme.yaml"))
)


def create_task_manager_doc(template_variables: dict[str, Any]) -> Template:
    """Create the task manager page."""
    template = juice_environment.get_panel_template("task_manager.html")

    # TODO: Move error handling to ServiceStatusWidget instead, don't do it
    try:
        service_list = [
            service
            for service in OrchestrationSettings.load().services
            if service != "task-manager"
        ]
        _logger.debug("Loading task manager dashboard.")
        service_status_widget = ServiceStatusWidget(
            services=service_list,
        )
        task_table_widget = TaskTableWidget(
            services=service_list,
        )
        pn.state.execute(task_table_widget.initial_update)
        pn.state.execute(service_status_widget.initial_update)

        template.add_panel("service_status_widget", service_status_widget.root)
        for root_name, root in task_table_widget.roots().items():
            template.add_panel(root_name, root)
    except Exception as ex:
        _logger.error("Failed to load task manager dashboard.", exc_info=ex)
        template.add_variable("load_failed", True)
        template.add_variable("traceback", traceback.format_exc())

    template.add_variable("page_title", "Task Manager")
    for k, v in template_variables.items():
        template.add_variable(k, v)

    _logger.debug("Successfully setup task manager bokeh document.")
    return template
