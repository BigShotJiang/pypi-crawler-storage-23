"""Overview dashboard page."""

import logging
from typing import Any

from panel.template import Template

from orangeqs.juice.dashboard import juice_environment
from orangeqs.juice.dashboard.utils import HOME_PAGE_APPS

_logger = logging.getLogger(__name__)


def create_home_doc(template_variables: dict[str, Any]) -> Template:
    """Create the home page."""
    _logger.debug(
        "create_home_doc called with template_variables: %s",
        template_variables,
    )

    template = Template(juice_environment.get_template("home.html"))

    # setting up document title
    template.add_variable("page_title", "Home")
    template.add_variable("categories", HOME_PAGE_APPS)
    for k, v in template_variables.items():
        template.add_variable(k, v)
    _logger.debug("Home doc rendered with template variables: %s", template_variables)
    return template
