"""Fridge monitor dashboard page."""

import asyncio
import logging
import traceback
from importlib.resources import files
from typing import Any

import panel as pn
from bokeh.io import curdoc
from bokeh.themes import Theme
from panel import Tabs
from panel.template import Template
from param.parameterized import Event  # pyright: ignore[reportMissingTypeStubs]

from orangeqs.juice.dashboard import juice_environment
from orangeqs.juice.dashboard.schemas import FridgeMonitorDashboardSettings
from orangeqs.juice.dashboard.widgets.compressor_widget import CompressorWidget
from orangeqs.juice.dashboard.widgets.ghs_widget import GHSWidget
from orangeqs.juice.dashboard.widgets.heater_widget import HeatersWidget
from orangeqs.juice.dashboard.widgets.temperature_widget import TemperatureWidget

_logger = logging.getLogger(__name__)


BOKEH_THEME = Theme(
    filename=str(files("orangeqs.juice.dashboard").joinpath("theme.yaml"))
)


class FridgeMonitorDash:
    """Class managing the fridge monitor dashboard."""

    def __init__(self, config: FridgeMonitorDashboardSettings) -> None:
        self._doc = curdoc()
        self.widgets: list[
            HeatersWidget | TemperatureWidget | CompressorWidget | GHSWidget
        ] = [
            GHSWidget(
                ghs_layout_filepath=config.ghs_layout_file,
                ghs_valves=config.ghs_valves,
                ghs_pumps=config.ghs_pumps,
                ghs_pressure_sensors=config.ghs_sensors,
                mode=config.mode,
            ),
            TemperatureWidget(
                thermometry_component_id=config.thermometry_component_id,
                thermometer_map=config.thermometers,
            ),
            HeatersWidget(heaters_config=config.heaters, mode=config.mode),
        ]
        for compressor_id, display_name in config.compressors.items():
            self.widgets.append(
                CompressorWidget(
                    component_id=compressor_id,
                    display_name=display_name,
                    mode=config.mode,
                )
            )
        self.root = Tabs(
            *[widget.tab_panel for widget in self.widgets],
            sizing_mode="stretch_width",
            dynamic=True,
        )
        self.root.param.watch(self._tab_changed, "active")  # type: ignore

    def _tab_changed(self, e: Event) -> None:
        _logger.debug(f"Fridge Monitor Dashboard tab changed from {e.old} to {e.new}.")  # pyright: ignore[reportUnknownMemberType]
        asyncio.create_task(self.widgets[e.new].initial_update())  # type: ignore

    def update(self) -> None:
        """Update all widgets in the dashboard."""
        for widget in self.widgets:
            widget.update()

    def initial_update(self) -> None:
        """Initialize data of all widgets in the dashboard."""
        for widget in self.widgets:
            asyncio.create_task(widget.initial_update())


def create_fridge_monitor_doc(template_variables: dict[str, Any]) -> Template:
    """Create Fridge monitor tabs and embed them in a Template.

    Parameters
    ----------
    doc : Document
        The Bokeh document to which the table will be added.
    """
    _logger.debug(
        f"Starting Fridge Monitor with template variables {template_variables}."
    )

    template = juice_environment.get_panel_template("fridge_monitor.html")
    try:
        config = FridgeMonitorDashboardSettings.load()
        sysmon_dash = FridgeMonitorDash(config)
        pn.state.add_periodic_callback(sysmon_dash.update, period=1000)  # type: ignore
        pn.state.execute(sysmon_dash.initial_update)
        template.add_panel("sysmon_dash", sysmon_dash.root)
        _logger.debug("Created Fridge Monitor Dashboard")
    except Exception as e:
        _logger.error(f"Failed to create System Monitor Dashboard: {e}")
        template.add_variable("load_failed", True)
        template.add_variable("traceback", traceback.format_exc())

    template.add_variable("page_title", "Fridge Monitor")
    for k, v in template_variables.items():
        template.add_variable(k, v)
    _logger.debug("Succesfully added widgets and variables to Fridge Monitor template.")
    return template
