"""Static file handlers for the OrangeQS Juice dashboard."""

from __future__ import annotations

import os
from importlib.resources import files
from typing import Any

from tornado import web
from typing_extensions import override


class EmbeddedStaticFileHandler(web.StaticFileHandler):
    """Static handler with file path to Juice assets.

    We use /juice to avoid conflicts with other static files.
    """

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Init static file handler while discarding template variables."""
        asset_root = str(files("orangeqs.juice.dashboard") / "static")
        # using `with as_file` does not here here if the package is a ZIP file
        # or on python < 3.12.
        super().initialize(path=asset_root)


class HomeDirectoryFileHandler(web.StaticFileHandler):
    """Static file handler that serves the user's home directory.

    Disables all types of caching.
    """

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Init static file handler while discarding template variables."""
        super().initialize(path=os.path.expanduser("~"))

    @override
    def set_extra_headers(self, path: str) -> None:
        """Set extra headers to disable caching for static files."""
        # Disable caching by setting cache-related headers
        super().set_extra_headers(path)
        self.set_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.set_header("Pragma", "no-cache")
        self.set_header("Expires", "0")
