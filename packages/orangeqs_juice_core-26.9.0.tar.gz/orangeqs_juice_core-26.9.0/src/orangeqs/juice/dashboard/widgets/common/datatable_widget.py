"""Base class for 2D data with named rows and columns. Uses pn.widgets.Tabulator."""

import asyncio
from typing import Any

import pandas as pd
import param  # pyright: ignore[reportMissingTypeStubs]
from panel.widgets import Tabulator

from orangeqs.juice.dashboard.utils import get_stylesheet


class DataTableWidget(param.Parameterized):
    """Base class for 2D data with named rows and columns. Uses pn.widgets.Tabulator.

    Examples
    --------
    ```
    class MyTable(DataTableWidget):
        def __init_():
            super().__init__(
                column_names=["cpu_percent", "mem_percent", "mem_usage"],
                column_display_names={
                    "cpu_percent": "CPU [%]",
                    "mem_percent": "Memory [%]",
                    "mem_usage": "Memory Usage",
                },
                data_table_opts=data_table_opts,
                initial_values={"mem_usage": pd.Series(dtype=str)},
            )

        @override
        async def _update(self) -> pd.DataFrame | None:
            return generate_dataframe()

    my_table = MyTable()
    panel.state.execute(my_table.start)
    ```
    Here, initial_values is passed so the memory data will not be interpreted
    as a number and displayed as "NaN".
    Furthermore, panel.state.execute is used to acquire the Bokeh document lock
    so the UI can be updated.

    Note that overriding `_update` is necessary for the automatic update loop to work.
    If you do not want the widget to update automatically, you can simply not override
    `_update` and not call `start`.


    Parameters
    ----------
    column_names : list[str]
        The column names.
    column_display_names : dict[str, str], optional
        A mapping from column name to display name. Will be displayed as table header.
        If a column is not present, defaults to capitalized field name.
    row_names : str, optional
        The row names. If not provided, _set_row_names should be called later.
    row_names_column_name : str, optional
        The name of the column that displays the row names.
    update_period : int, optional
        Update period in milliseconds. Defaults to 1000ms.
    tabulator_opts : dict[str, Any], optional
        Standard Tabulator options exposed by Panel. See https://panel.holoviz.org/reference/widgets/Tabulator.html.
    data_table_opts : dict[str, Any], optional
        TabulatorJS configuration options. These are passed to the JS library and can be
        used to set configuration options that Panel does not expose.
        See https://www.tabulator.info/docs/6.3/options for available options.
    initial_values : dict[str, Any], optional
        Initial values for the table data.
    """

    table: Tabulator
    _keys: list[str]
    _fields: list[str]
    _data: pd.DataFrame = param.DataFrame(pd.DataFrame())  # type: ignore

    def __init__(
        self,
        column_names: list[str],
        column_display_names: dict[str, str] | None = None,
        row_names: list[str] | None = None,
        row_names_column_name: str | None = None,
        update_period: int = 1000,
        data_table_opts: dict[str, Any] | None = {},
        tabulator_opts: dict[str, Any] | None = {},
        initial_values: dict[str, Any] | None = {},
    ) -> None:
        super().__init__()  # type: ignore
        self._update_period = update_period
        self._row_names = row_names or pd.Series(dtype=str)
        self._column_names = column_names
        self._row_col_name = row_names_column_name or "#"
        self._column_display_names = {self._row_col_name: self._row_col_name} | (
            column_display_names or {e: e.capitalize() for e in column_names}
        )
        self._data = pd.DataFrame(
            {self._row_col_name: self._row_names}
            | {
                self._column_display_names.get(col): (initial_values or {}).get(
                    col, ["loading..."] * len(self._row_names)
                )
                for col in self._column_names
            }
        )

        default_config = {
            "sortable": {self._row_col_name: False},
            "layout": "fit_data_stretch",
            "show_index": False,
            "disabled": True,  # Make the cells uneditable
            "sizing_mode": "stretch_width",
            "stylesheets": [get_stylesheet("custom-bokeh.css")],
        }

        default_config.update(tabulator_opts or {})

        self.table = Tabulator.from_param(  # type: ignore
            self.param._data,  # type: ignore
            configuration={"autoResize": True} | (data_table_opts or {}),
            **default_config,
        )

    async def _update(self) -> pd.DataFrame | None:
        pass

    def _set_row_names(self, new: list[str]) -> None:
        self._row_names = new

    async def start(self) -> None:
        """Start the widget update loop."""
        while True:
            df = await self._update()
            if df is not None:
                if len(df) != len(self._row_names):
                    raise ValueError(
                        "The amount of rows and row names are not equal.\n"
                        + f"Row names are: {self._row_names}.\n"
                        + f"Row lengths are: {len(df)}\n"
                        + "Use `self._set_row_names` to set row names."
                    )
                df.insert(loc=0, column=self._row_col_name, value=self._row_names)  # type: ignore
                df = df.rename(columns=lambda c: self._column_display_names.get(c))  # type: ignore
                self._data = df
            await asyncio.sleep(self._update_period / 1000)
