"""Widget that displays service usages."""

import logging
from typing import Annotated, Any, ClassVar

from pandas import DataFrame, Series
from typing_extensions import override

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.widgets.common import DataTableWidget
from orangeqs.juice.database import Point
from orangeqs.juice.orchestration.settings import OrchestrationSettings

_logger = logging.getLogger(__name__)


class ServiceUsageOverviewTable(DataTableWidget):
    """
    Overview of the services and their resource usages.

    Data collected by Telegraf is displayed here, such as the `active`,
    `load` and `sub` tags of the various services.
    """

    def __init__(
        self,
        *,
        data_table_opts: dict[str, Any] | None = None,
    ) -> None:
        self._bucket = OrchestrationSettings.load().telegraf.influxdb2_bucket
        _logger.info("Using InfluxDB Telegraf bucket: %s", self._bucket)

        self._query_api = influxdb2_query_api_async()

        super().__init__(  # type: ignore
            column_names=["cpu_percent", "mem_percent", "mem_usage"],
            column_display_names={
                "cpu_percent": "CPU [%]",
                "mem_percent": "Memory [%]",
                "mem_usage": "Memory Usage",
            },
            data_table_opts=data_table_opts,
            initial_values={"mem_usage": Series(dtype=str)},
        )

    @override
    async def _update(self) -> DataFrame | None:
        """Update the Service Usage table by querying InfluxDB."""
        _logger.debug("""Updating ServiceUsageOverviewTable data""")

        try:
            reply = await _ServiceUsageData.query_async(
                query_api=self._query_api, bucket="system_logs", limit=1, start="-1m"
            )
            if not reply:
                _logger.warning(
                    "No data received from InfluxDB for service Usage overview."
                )
                return None
        except Exception as ex:
            _logger.error(
                "Could not retrieve data for service usage overview.", exc_info=ex
            )
            raise RuntimeError("Could not retrieve data for service usage overview.")

        reply = sorted(reply, key=lambda e: e.name)
        raw = {col: [entry[col] for entry in reply] for col in self._column_names}
        _logger.debug(f"Service usage data retrieved: {raw}.")
        # Update row names in case a service goes offline/a new one comes online
        self._set_row_names([e.name for e in reply])

        _logger.debug("Service usage data updated.")
        return DataFrame(raw)


class _ServiceUsageData(Point):
    def __getitem__(self, key: str) -> float | str:
        return getattr(self, key)

    measurement: ClassVar[str] = "podman_stats"
    cpu_percent: float
    mem_percent: float
    mem_usage: str
    name: Annotated[str, "tag"]
