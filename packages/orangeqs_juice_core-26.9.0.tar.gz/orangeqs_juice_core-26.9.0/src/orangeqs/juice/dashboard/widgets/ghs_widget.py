"""Module containing system monitor GHS widget."""

import asyncio
import logging
import os
import re
import xml.etree.ElementTree as ET
from typing import Any, Literal

import panel as pn
from bokeh.io import curdoc
from panel import bind  # pyright: ignore[reportUnknownVariableType]
from panel.layout import Column, Row
from panel.pane import HTML
from panel.widgets import Button
from param import Parameterized, String  # pyright: ignore[reportMissingTypeStubs]

from orangeqs.juice.client import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.messaging import Event
from orangeqs.juice.system_monitor.data_structures import (
    ComponentEnabledPoint,
    FlowratePoint,
    PressurePoint,
)
from orangeqs.juice.system_monitor.tasks import (
    CloseGHSValve,
    DisableGHSPump,
    EnableGHSPump,
    GetGHSPumpState,
    GetGHSValveState,
    OpenGHSValve,
    StartGHSCondensation,
    StartGHSRecovery,
)

_logger = logging.getLogger(__name__)
_logger.setLevel("DEBUG")


class GHSWidget(Parameterized):
    """Gas Handling System Widget."""

    # XML string that defines the main GHS layout.
    ghs_layout: str = String(default="")  # pyright: ignore[reportAssignmentType]

    def __init__(
        self,
        ghs_layout_filepath: str = "",
        ghs_valves: list[str] = [],
        ghs_pumps: list[str] = [],
        ghs_pressure_sensors: list[str] = [],
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        """Initialize class."""
        super().__init__()  # type: ignore
        self._doc = curdoc()
        self.juice_client = Client()
        self._layout_path = ghs_layout_filepath
        self._layout = None
        self._layout_div = HTML(bind(str, self.param.ghs_layout), width=800, height=600)
        self._button_states = {bid: False for bid in ghs_valves}
        self._using_placeholder = False
        self._button_states.update({bid: False for bid in ghs_pumps})
        button_width = 60
        button_height: int | None = None
        self._pressures = {sid: float("nan") for sid in ghs_pressure_sensors}
        self._flow = float("nan")
        self._valve_buttons = {
            button_id: OnOffToggle(
                doc=self._doc,
                service=DEFAULT_SYSTEM_MONITOR_SERVICE,
                on_task=OpenGHSValve(valve_id=button_id),
                off_task=CloseGHSValve(valve_id=button_id),
                response_timeout=10,
                device_state_check_task=GetGHSValveState(valve_id=button_id),
                enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs.{button_id}",
                title=f"{button_id}",
                button_width=button_width,
                button_height=button_height,
                on_label="Open",
                off_label="Close",
                mode=mode,
            )
            for button_id in ghs_valves
        }
        self._pump_buttons = {
            button_id: OnOffToggle(
                doc=self._doc,
                service=DEFAULT_SYSTEM_MONITOR_SERVICE,
                on_task=EnableGHSPump(pump_id=button_id),
                off_task=DisableGHSPump(pump_id=button_id),
                response_timeout=10,
                device_state_check_task=GetGHSPumpState(pump_id=button_id),
                enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs.{button_id}",
                title=f"{button_id}",
                button_width=button_width,
                button_height=button_height,
                mode=mode,
            )
            for button_id in ghs_pumps
        }
        self._control_buttons = {
            "condense": Button(
                name="Condense Helium Mixture",
                button_type="default",
                width=3 * button_width,
                height=button_height,
                disabled=(mode == "read_only"),
            ),
            "recover": Button(
                name="Recover Helium Mixture",
                button_type="default",
                width=3 * button_width,
                height=button_height,
                disabled=(mode == "read_only"),
            ),
        }

        bind(self._condense_callback, self._control_buttons["condense"], watch=True)
        bind(self._recover_callback, self._control_buttons["recover"], watch=True)

        # Group headers
        self._control_header = HTML("<b>GHS Control</b>", width=200)
        self._valve_header = HTML("<b>Valves</b>", width=200)
        self._pump_header = HTML("<b>Pumps</b>", width=200)

        # Initial filtered lists
        self._filtered_control = list(self._control_buttons.values())
        self._filtered_valves = list(self._valve_buttons.values())
        self._filtered_pumps = list(self._pump_buttons.values())

        div_width = 65

        def make_buttons_col(buttons: list[Any], width: int = div_width) -> Column:
            rows: list[Row] = []
            for i in range(0, len(buttons), 3):
                group = buttons[i : i + 3]
                row_items = [
                    Row(
                        HTML(f"{b.title} ", width=width, align="center"),
                        b.root,
                        styles={
                            "border-radius": "5px",
                            "box-shadow": "var(--box-shadow-light)",
                            "margin": "2px",
                        },
                    )
                    for b in group
                ]
                rows.append(Row(*row_items))
            return Column(*rows)

        self._control_buttons_col = Row(
            *self._filtered_control,
            styles={
                "border-radius": "5px",
                "box-shadow": "var(--box-shadow-light)",
                "margin": "2px",
            },
        )
        self._valve_buttons_col = make_buttons_col(self._filtered_valves, width=40)
        self._pump_buttons_col = make_buttons_col(self._filtered_pumps)

        self.tab_panel = Column(
            Row(
                self._layout_div,
                Column(
                    Column(
                        self._control_header,
                        self._control_buttons_col,
                    ),
                    Column(
                        self._valve_header,
                        self._valve_buttons_col,
                    ),
                    Column(
                        self._pump_header,
                        self._pump_buttons_col,
                    ),
                ),
            ),
            name="GHS",
        )
        topic_filters = [
            (FlowratePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
            (PressurePoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
            (ComponentEnabledPoint, f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.ghs"),
        ]
        # Need to keep a reference to the subscriber tasks to avoid garbage collection
        self._subscriber_tasks = subscribe_to_events_task(
            self._doc, topic_filters, self._update_sub
        )
        self._update_event = asyncio.Event()

    async def initial_update(self) -> None:
        """Load initialization data of GHS dashboard."""
        tasks: list[Any] = []
        layout_loaded = False
        self._using_placeholder = False
        if self._layout_path != "":
            try:
                ET.register_namespace("", "http://www.w3.org/2000/svg")
                self._layout = ET.parse(self._layout_path)
                self.ghs_layout = ET.tostring(
                    self._layout.getroot(),  # pyright: ignore
                    encoding="utf8",
                ).decode("utf-8")
                _logger.debug("Loaded SVG succesfully.")
                pn.state.execute(self.update)
                layout_loaded = True
                self._using_placeholder = False
            except Exception as e:
                _logger.error(f"Could not load ghs layout at {self._layout_path}. {e}")

        if not layout_loaded:
            # Try to load placeholder.svg from static/images
            placeholder_path = os.path.join(
                os.path.dirname(__file__), "../static/images/placeholder.svg"
            )
            try:
                self._using_placeholder = True
                ET.register_namespace("", "http://www.w3.org/2000/svg")
                self._layout = ET.parse(placeholder_path)
                # Compose error message with SVG
                svg_content = ET.tostring(
                    self._layout.getroot(),  # pyright: ignore
                    encoding="utf8",
                ).decode("utf-8")
                error_message = (
                    f"<div style='color:red;'>Could not find GHS layout. "
                    f"Place your SVG at {self._layout_path} and "
                    "restart the dashboard to apply changes.</div>"
                )
                self.ghs_layout = error_message + svg_content
                _logger.info(f"Loaded placeholder SVG from {placeholder_path}.")
            except Exception as e:
                _logger.error(
                    f"Could not load ghs layout at {self._layout_path} or placeholder. "
                    f"{e}"
                )

        tasks.extend(
            [
                asyncio.create_task(b.initial_update())
                for b in self._valve_buttons.values()
            ]
        )
        tasks.extend(
            [
                asyncio.create_task(b.initial_update())
                for b in self._pump_buttons.values()
            ]
        )
        await asyncio.gather(*tasks)

    def update(self) -> None:
        """Update GHS dashboard layout."""
        if self._layout is not None:
            # update layout with new data
            for b_id, state in self._button_states.items():
                el = self._layout.find(f".//*[@id='{b_id}']")
                if el is None:
                    continue
                el.attrib["style"] = re.sub(
                    r"(?<=fill:#)[\w]{6}",
                    (r"7CB75D" if state else "000000"),
                    el.attrib.get("style", "fill:#000000"),
                )
            for p_id, val in self._pressures.items():
                el = self._layout.find(f".//*[@id='{p_id}']")
                if el is None:
                    continue
                el.text = f"{val:.2g}"
            el = self._layout.find(".//*[@id='flow']")
            if el is not None:
                el.text = f"{self._flow:.2f}"
            svg_content = ET.tostring(self._layout.getroot(), encoding="utf8").decode(
                "utf-8"
            )  # pyright: ignore
            if self._using_placeholder:
                error_message = (
                    f"<div style='color:red;'>Could not find GHS layout. "
                    f"Place your SVG at {self._layout_path} and "
                    "restart the dashboard to apply changes.</div>"
                )
                self.ghs_layout = error_message + svg_content
            else:
                self.ghs_layout = svg_content
            # _logger.debug(f"Updated layout to new svg: {self._layout_div.text}")
        # else:
        # _logger.debug("No layout to update")
        self._update_event.clear()

    def _update_sub(self, event: Event) -> None:
        # Isolate
        match event:
            case FlowratePoint():
                self._flow = event.flowrate
            case PressurePoint():
                if event.sensor_id in self._pressures:
                    self._pressures[event.sensor_id] = event.pressure
            case ComponentEnabledPoint():
                id = event.topic().split(".")[-1]
                if id in self._button_states:
                    self._button_states[id] = event.enabled
            case _:
                _logger.warning(f"GHS dash received unsupported event {event}")
        if not self._update_event.is_set():
            self._update_event.set()
            pn.state.execute(self.update)

    def _condense_callback(self) -> None:
        asyncio.create_task(
            self.juice_client.request(
                DEFAULT_SYSTEM_MONITOR_SERVICE, StartGHSCondensation(), check=True
            )
        )

    def _recover_callback(self) -> None:
        asyncio.create_task(
            self.juice_client.request(
                DEFAULT_SYSTEM_MONITOR_SERVICE, StartGHSRecovery(), check=True
            )
        )
