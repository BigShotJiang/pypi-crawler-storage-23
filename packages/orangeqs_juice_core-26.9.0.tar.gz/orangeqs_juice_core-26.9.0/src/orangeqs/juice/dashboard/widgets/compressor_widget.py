"""Compressor control and monitoring widget for the Juice dashboard."""

import asyncio
import logging
from typing import Literal, ParamSpec, TypeVar, cast

from bokeh.io import curdoc
from panel.layout import Column
from typing_extensions import override

from orangeqs.juice import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.dashboard.widgets.common import DataTableWidget
from orangeqs.juice.system_monitor.data_structures import (
    PressurePoint,
    StatusmessagePoint,
    TemperaturePoint,
)
from orangeqs.juice.system_monitor.tasks import (
    AreCompressorsEnabled,
    DisableCompressors,
    EnableCompressors,
)

_logger = logging.getLogger(__name__)


P = ParamSpec("P")
R = TypeVar("R")


class CompressorWidget(DataTableWidget):
    """Compressor control and monitoring widget."""

    def __init__(
        self,
        component_id: str,
        display_name: str,
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self._juice_client = Client()
        self.display_name = display_name
        self.component_id = component_id

        super().__init__(
            column_names=["Value"],
            row_names_column_name="Parameter",
            row_names=[
                "Operating State",
                "Error",
                "Warning",
                "High Pressure",
                "Low Pressure",
                "Coolant In Temperature",
                "Coolant Out Temperature",
                "Oil Temperature",
                "Helium Temperature",
            ],
            tabulator_opts={"sortable": False},
        )

        self._on_off_toggle = OnOffToggle(
            doc=curdoc(),
            service=DEFAULT_SYSTEM_MONITOR_SERVICE,
            on_task=EnableCompressors(),
            off_task=DisableCompressors(),
            response_timeout=10,
            device_state_check_task=AreCompressorsEnabled(),
            enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{component_id}",
            title=f"{self.display_name}",
            button_width=120,
            button_height=30,
            mode=mode,
        )

        self.tab_panel = Column(
            self._on_off_toggle.root, self.table, name=self.display_name
        )

        topic = f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.component_id}"
        subscription_list = [
            (TemperaturePoint, topic),
            (PressurePoint, topic),
            (StatusmessagePoint, topic),
        ]

        self.subscriber_task = subscribe_to_events_task(
            doc=curdoc(),
            subscriptions=subscription_list,
            handler=self._update_event_handler,
        )

    async def initial_update(self) -> None:
        """Initialize data of all widgets in the dashboard."""
        _logger.debug(f"Initialising Compressor Widget: {self.display_name}")
        self.initial_update_task = asyncio.create_task(
            self._on_off_toggle.initial_update()
        )

    @override
    async def _update(self) -> None:
        """Update the compressor widget data.

        We are using pubsub instead of periodic updates so this method is not used.
        """
        pass

    def update(self) -> None:
        """Update the compressor widget data."""
        pass

    def _update_event_handler(
        self,
        event: TemperaturePoint | PressurePoint | StatusmessagePoint,
    ) -> None:
        _logger.debug(
            f"Handling event {event.__class__.__name__} topic {event.topic()}"
        )

        match event:
            case StatusmessagePoint():
                match event.message_id:
                    case "operating_state":
                        self._update_table("Operating State", event.message)
                    case "warning":
                        self._update_table("Warning", event.message)
                    case "error":
                        self._update_table("Error", event.message)
                    case _:
                        _logger.warning(
                            f"Unknown message_id {event.message_id} "
                            "in StatusmessagePoint."
                        )

            case TemperaturePoint():
                if event.sensor_id in [
                    "coolant_in_temperature",
                    "coolant_out_temperature",
                    "oil_temperature",
                    "helium_temperature",
                ]:
                    self._update_table(
                        event.sensor_id.replace("_", " ").title(),
                        f"{event.temperature:.1f} K",
                    )
            case PressurePoint():
                if event.sensor_id == "high_pressure":
                    self._update_table(
                        "High Pressure", f"{event.pressure:.2f} {event.unit}"
                    )
                elif event.sensor_id == "low_pressure":
                    self._update_table(
                        "Low Pressure", f"{event.pressure:.2f} {event.unit}"
                    )

    def _update_table(self, parameter: str, value: str) -> None:
        normalized = [
            s.strip("'").strip('"')
            for s in self._data["Parameter"]
            if isinstance(s, str)
        ]
        if parameter not in normalized:
            _logger.warning(f"Parameter {parameter} not found in table.")
            _logger.warning(f"Parameters are: {[repr(x) for x in normalized]}")
            return
        else:
            idx = self._data.index[self._data["Parameter"] == parameter][0]  # type: ignore
            if parameter == "Error":
                current_errors = cast("str", self._data.loc[idx, "Value"])
                if "NO_ERRORS" in current_errors or "NO_ERRORS" in value:
                    pass
                elif value not in current_errors:
                    value = current_errors + "; " + value
                else:
                    value = current_errors
            if parameter == "Warning":
                current_warnings = cast("str", self._data.loc[idx, "Value"])
                if "NO_WARNINGS" in current_warnings or "NO_WARNINGS" in value:
                    pass
                elif value not in current_warnings:
                    value = current_warnings + "; " + value
                else:
                    value = current_warnings

            self._data.loc[idx, "Value"] = value  # type: ignore
            self.param.trigger("_data")
