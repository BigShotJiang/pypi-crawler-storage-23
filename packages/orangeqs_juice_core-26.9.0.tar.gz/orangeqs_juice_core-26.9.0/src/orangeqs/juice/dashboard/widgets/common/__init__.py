"""Common helper classes and functions for the dashboard widgets."""

from .datatable_widget import DataTableWidget

__all__ = ["DataTableWidget"]
