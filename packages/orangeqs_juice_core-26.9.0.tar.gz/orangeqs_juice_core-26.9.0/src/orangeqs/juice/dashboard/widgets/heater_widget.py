"""Widget for controlling heater units."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Literal

from bokeh.io import curdoc
from panel.layout import Column, Row
from panel.pane import HTML
from panel.widgets import Button, LiteralInput
from param import Number, Parameterized, bind  # type: ignore

from orangeqs.juice.client import Client
from orangeqs.juice.dashboard.components.on_off_widget import OnOffToggle
from orangeqs.juice.dashboard.schemas import DEFAULT_SYSTEM_MONITOR_SERVICE
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.system_monitor.data_structures import PowerSettingPoint
from orangeqs.juice.system_monitor.tasks import (
    DisableHeater,
    EnableHeater,
    GetHeaterOutputPower,
    GetHeaterPowerSetting,
    IsHeaterEnabled,
    SetHeaterPower,
)

if TYPE_CHECKING:
    from param.parameterized import Event  # pyright: ignore[reportMissingTypeStubs]

logger = logging.getLogger(__name__)

W_TO_MW_CONVERSION = 1000.0


class HeatersWidget:
    """Widget to control multiple heater units."""

    def __init__(
        self,
        heaters_config: dict[str, str],
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self.individual_heater_widgets: list[SingleHeaterWidget] = []
        for heater_name, display_name in heaters_config.items():
            self.individual_heater_widgets.append(
                SingleHeaterWidget(
                    heater_name=heater_name,
                    display_name=display_name,
                    mode=mode,
                )
            )
            logger.debug(f"Created Heater Widget: {display_name}")
        self.tab_panel = Row(
            *[widget.root for widget in self.individual_heater_widgets],
            name="Heaters Control",
        )

    async def initial_update(self) -> None:
        """Initialise Widget."""
        for heater_widget in self.individual_heater_widgets:
            asyncio.create_task(heater_widget.initial_update())

    def update(self) -> None:
        """Update the heater widget data."""
        pass


class SingleHeaterWidget(Parameterized):
    """Widget to control a single heater unit in the system monitor."""

    measured_power: float = Number(default=0.00)  # type: ignore
    power_setting: float = Number(default=None, allow_None=True)  # type: ignore

    def __init__(
        self,
        heater_name: str,
        display_name: str,
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        super().__init__()  # type: ignore
        self._doc = curdoc()
        self.heater_name = heater_name
        self.display_name = display_name

        self.juice_client = Client()
        self.title_div = HTML(object=display_name, width=200, height=25)
        self.on_off_toggle = OnOffToggle(
            doc=self._doc,
            service=DEFAULT_SYSTEM_MONITOR_SERVICE,
            on_task=EnableHeater(component_id=heater_name),
            off_task=DisableHeater(component_id=heater_name),
            response_timeout=10,
            device_state_check_task=IsHeaterEnabled(component_id=heater_name),
            enabled_topic=f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{heater_name}",
            title=f"{display_name}",
            button_width=120,
            button_height=30,
            mode=mode,
        )

        self.measured_power_display = HTML(
            bind(
                lambda v: f"Measured Power Output: {v} mW",  # pyright: ignore[reportUnknownLambdaType]
                self.param.measured_power,
            ),
            width=240,
            height=30,
            styles={"font-size": "15px", "color": "#2a2a2a", "text-align": "center"},
        )

        self.power_input = LiteralInput.from_param(  # type: ignore
            self.param.power_setting,  # type: ignore
            name="",
            placeholder="Enter Power",
            width=120,
            height=30,
            disabled=mode == "read_only",
            styles={"margin-left": "5px", "margin-right": "5px"},
        )
        self.power_input.type = float
        self.update_power = Button(
            name="Set Power(mW)",
            button_type="default",
            width=120,
            height=30,
            disabled=mode == "read_only",
            styles={"margin-left": "5px"},
        )

        self.update_power.on_click(self.update_power_callback)
        self.power_input_row = Row(self.power_input, self.update_power)

        self.root = Column(
            self.title_div,
            self.on_off_toggle.root,
            self.power_input_row,
            self.measured_power_display,
            styles={
                "border-color": "black",
                "border-style": "solid",
                "border-width": "1px",
            },
        )
        self.initialized = False

    def update_power_callback(self, _event: Event) -> None:
        """Update power on device."""
        if self.power_setting is None:  # type: ignore
            return
        asyncio.create_task(
            self.juice_client.execute(
                DEFAULT_SYSTEM_MONITOR_SERVICE,
                SetHeaterPower(
                    component_id=self.heater_name,
                    power=self.power_setting / W_TO_MW_CONVERSION,
                ),
                check=True,
            )
        )

        logger.info(
            f"Changed Output Power of {self.display_name} to {self.power_setting} mW"
        )

    async def initial_update(self) -> None:
        """Initialise the state of the widget."""
        logger.debug(f"Initialising Heater Widget: {self.display_name}")
        self.initial_update_task = asyncio.create_task(
            self.on_off_toggle.initial_update()
        )
        get_heater_power_setting_result = await self.juice_client.execute(
            DEFAULT_SYSTEM_MONITOR_SERVICE,
            GetHeaterPowerSetting(component_id=self.heater_name),
            check=True,
        )
        self.power_setting = get_heater_power_setting_result.result * W_TO_MW_CONVERSION
        get_heater_output_power_result = await self.juice_client.execute(
            DEFAULT_SYSTEM_MONITOR_SERVICE,
            GetHeaterOutputPower(component_id=self.heater_name),
            check=True,
        )
        self.measured_power = get_heater_output_power_result.result * W_TO_MW_CONVERSION
        logger.debug(
            f"Retrieved Power for {self.display_name}: {self.measured_power} mW"
        )

        self.listener_task = subscribe_to_events_task(
            self._doc,
            [
                (
                    PowerSettingPoint,
                    f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{self.heater_name}",
                ),
            ],
            self._handle_power_setting_point,
        )

        self.initialized = True

    def _handle_power_setting_point(self, event: PowerSettingPoint) -> None:
        """Handle updates from the system monitor about heater power changes."""
        if not self.initialized:
            return

        self.measured_power = event.output_power * W_TO_MW_CONVERSION
        self.power_setting = event.power_setting * W_TO_MW_CONVERSION
        logger.debug(
            f"Received PowerSettingPoint for {self.display_name}: "
            f"Power={self.measured_power} mW"
        )
