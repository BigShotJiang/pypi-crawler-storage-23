"""Service log widget."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Literal

import pandas as pd
from bokeh.models import HTMLTemplateFormatter
from panel import bind, depends  # pyright: ignore[reportUnknownVariableType]
from panel.pane import HTML
from panel.widgets import (
    Button,
    DatetimePicker,
    MultiChoice,
    Tabulator,
)
from param import (  # pyright: ignore[reportMissingTypeStubs]
    Boolean,
    DataFrame,
    Date,
    Integer,
    List,
    Parameter,
    Parameterized,
)

from orangeqs.juice.client.logging import (
    _query_service_logs,  # pyright: ignore[reportPrivateUsage]
)
from orangeqs.juice.dashboard.utils import get_stylesheet, to_local_time
from orangeqs.juice.orchestration.settings import OrchestrationSettings

if TYPE_CHECKING:
    from panel.viewable import Viewable

_logger = logging.getLogger(__name__)

_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S %Z"
_PYTHON_LOG_LEVELS = ["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"]


class ServiceLogWidget(Parameterized):
    """Widget to display log messages from services."""

    max_time_interval: timedelta = Parameter(default=timedelta(hours=1), precedence=0)  # type: ignore
    max_num_records: int = Integer(default=10_000, precedence=0)  # type: ignore

    # Reactive parameters
    # None is "until now"
    time_interval_end: datetime | None = Date(default=None, allow_None=True)  # type: ignore
    selected_services: list[str] = List(default=[], item_type=str)  # type: ignore
    selected_levels: list[str] = List(default=[], item_type=str)  # type: ignore
    _data: pd.DataFrame = DataFrame(
        pd.DataFrame(  # type: ignore
            {
                "_time": pd.Series(dtype=str),
                "service": pd.Series(dtype=str),
                "level": pd.Series(dtype=str),
                "message": pd.Series(dtype=str),
                "path": pd.Series(dtype=str),
                "lineno": pd.Series(dtype=int),
            }
        )
    )

    # read-only state
    _last_update: datetime = Date(default=datetime.fromtimestamp(0, tz=timezone.utc))  # type: ignore
    _updating: bool = Boolean(default=False, precedence=-1)  # type: ignore
    _initialized = False

    def __init__(
        self,
        max_time_interval: timedelta,
        max_num_records: int = 10_000,
    ) -> None:
        super().__init__()  # type: ignore
        self.time_interval_end: datetime | None = None  # None means "until now"
        self._updating = False
        self.max_time_interval = max_time_interval
        self.max_num_records = max_num_records

        settings = OrchestrationSettings.load()

        self._all_services = list(settings.services.keys())
        self._all_levels = list(_PYTHON_LOG_LEVELS)
        self.selected_levels = self._all_levels[:3]  # warning or higher by default
        self.selected_services = []
        self._raw_data = self._data

        self._create_ui_elements()

        self._initialized = True
        self._filtering = False

        _logger.debug("Reached end of __init__ for ServiceLogWidget")

    def _create_ui_elements(self) -> None:
        self.datetime_picker = DatetimePicker.from_param(  # pyright: ignore[reportUnknownMemberType]
            self.param.time_interval_end,
            name="",
        )

        def _reset(_) -> None:  # noqa: ANN001
            self.time_interval_end = None

        self.datetime_picker_reset_button = Button(
            name="Until now", button_type="primary"
        )
        self.datetime_picker_reset_button.on_click(_reset)  # type: ignore

        self.multichoice_service = MultiChoice.from_param(  # type: ignore
            self.param.selected_services,  # type: ignore
            name="",
            options=self._all_services,
            min_width=140,
        )

        self.multichoice_level = MultiChoice.from_param(  # type: ignore
            self.param.selected_levels,
            name="",
            options=self._all_levels,
            min_width=140,
        )

        overflow_template = """
            <div style="white-space: nowrap; overflow: hidden;
                text-overflow: ellipsis;"
                title="<%= value %>">
                <%= value %>
            </div>
            """
        self.data_table = Tabulator.from_param(  # type: ignore
            self.param._data,  # type: ignore
            name="Service Logs",
            show_index=False,
            pagination="local",
            page_size=50,
            sizing_mode="stretch_width",
            titles={
                "_time": "Time",
                "service": "Service",
                "level": "Level",
                "message": "Message",
                "path": "File",
                "lineno": "Line",
            },
            formatters={
                "path": HTMLTemplateFormatter(template=overflow_template),
                "message": HTMLTemplateFormatter(template=overflow_template),
            },
            layout="fit_data_stretch",
            disabled=True,  # Make the table cells non-editable
            stylesheets=[get_stylesheet("custom-bokeh.css")],
        )

        self._div_update_warning = HTML(
            bind(
                lambda v: f"Last update: {v.strftime(_DATETIME_FORMAT)}",  # type: ignore
                self.param._last_update,  # type: ignore
            ),
            stylesheets=[get_stylesheet("warning.css")],
        )
        self._div_update_warning.visible = False

    def roots(self) -> dict[str, Viewable]:
        """Roots for the widget."""
        return {
            "datetime_picker": self.datetime_picker,
            "datetime_picker_reset_button": self.datetime_picker_reset_button,
            "multichoice_service": self.multichoice_service,
            "multichoice_level": self.multichoice_level,
            "logs_table": self.data_table,
            "warning": self._div_update_warning,
        }

    def template_variables(self) -> dict[str, Any]:
        """Template variables for the widget."""
        return {"max_num_records": self.max_num_records}

    @depends("time_interval_end", watch=True)
    def update(self, triggered_periodically: bool = False) -> None:
        """Update logs from the database."""
        _logger.debug("Updating service log widget")
        # If the previous callback has not returned yet, we skip update
        if self._updating:
            _logger.debug("Skipping update, previous callback still in progress")
            return
        # If user has selected the fixed time interval, periodic update is not done
        if triggered_periodically and self.time_interval_end is not None:
            _logger.debug("Skipping periodic update, user selected time interval")
            return

        self._updating = True
        interval_end = self.time_interval_end or datetime.now(tz=timezone.utc)
        interval_start = max(self._last_update, interval_end - self.max_time_interval)

        _logger.debug(
            f"Fetching logs from {interval_start.strftime(_DATETIME_FORMAT)} "
            f"to {interval_end.strftime(_DATETIME_FORMAT)}"
        )
        try:
            new_data = _retrieve_formatted_logs(
                start=interval_start,
                stop=interval_end,
                level="DEBUG",
                max_count=self.max_num_records,
            )
        except Exception as e:
            self._div_update_warning.visible = True
            _logger.error("Failed to fetch data", exc_info=e)
        else:
            self._div_update_warning.visible = False
            if new_data is not None and not new_data.empty:
                self._raw_data = pd.concat(  # pyright: ignore[reportUnknownMemberType]
                    [self._raw_data, new_data], ignore_index=True
                )
                self._last_update = interval_end
                if not self._filtering:
                    self._apply_filters()  # pyright: ignore[reportCallIssue]
        finally:
            self._updating = False

    @depends("selected_services", "selected_levels", watch=True)
    def _apply_filters(self) -> None:
        if not self._initialized:
            return
        self._filtering = True
        view = self._raw_data.copy()  # type: ignore
        _logger.debug(f"Filtering on services: {self.selected_services}")
        view = view[view["service"].isin(self.selected_services or self._all_services)]  # type: ignore
        _logger.debug(f"Filtering on levels: {self.selected_levels}")
        view = view[view["level"].isin(self.selected_levels)]  # type: ignore
        if not view.equals(self.data_table.value):  # type: ignore
            self._data = view
            _logger.info(f"Updated logs to : {view}")
        self._filtering = False


def _retrieve_formatted_logs(
    start: datetime,
    stop: datetime,
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
    max_count: int,
) -> pd.DataFrame | None:
    """Retrieve log messages from InfluxDB and format them for display.

    Thin wrapper around _get_service_logs that formats the output as a DataFrame.

    Parameters
    ----------
    start : int
        Start time for query
    end : int
        End time for query.

    Returns
    -------
    pd.DataFrame | None
        DataFrame containing the log messages, or None if no messages are found.
    """
    time_now = datetime.now(tz=timezone.utc)
    start_query = int((time_now - start).total_seconds())
    stop_query = int((time_now - stop).total_seconds())

    log_events = _query_service_logs(
        start=start_query,
        stop=stop_query,
        max_count=max_count,
        level=level,
    )
    _logger.debug(f"Retrieved {len(log_events)} log events")

    if len(log_events) == 0:
        _logger.info("No log events found")
        return

    _logger.debug("Formatting log events")
    data: list[dict[str, str | datetime | None]] = []
    for event in log_events:
        record: dict[str, str] = json.loads(event.serialized_record)
        local_time = to_local_time(event.time)
        data.append(  # type: ignore
            {
                "_time": local_time.strftime(_DATETIME_FORMAT),
                "service": event.service,
                "level": record.get("levelname"),
                "message": record.get("message"),
                "path": record.get("pathname"),
                "lineno": record.get("lineno"),
            }
        )
    return pd.DataFrame(data)
