"""Widget for controlling thermometry units."""

import asyncio
import logging
from datetime import datetime
from typing import Any, cast

from bokeh.io import curdoc
from panel.io.model import JSCode
from panel.layout import Column, Row, Spacer
from panel.pane import HTML, ECharts
from panel.widgets import Select
from param.parameterized import Event  # pyright: ignore[reportMissingTypeStubs]

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.schemas import (
    CRYOSTAT_LEVELS,
    DEFAULT_SYSTEM_MONITOR_SERVICE,
)
from orangeqs.juice.dashboard.utils import (
    get_pallete,
    subscribe_to_events_task,
    to_local_time,
)
from orangeqs.juice.system_monitor.data_structures import TemperaturePoint

_logger = logging.getLogger(__name__)

_SECS_7_DAYS = 7 * 24 * 3600
_SECS_2_DAYS = 2 * 24 * 3600
_SECS_1_DAY = 1 * 24 * 3600
_SECS_12_HOURS = 12 * 3600
_SECS_6_HOURS = 6 * 3600
_SECS_3_HOURS = 3 * 3600
_SECS_1_HOUR = 1 * 3600
_SECS_15_MINUTES = 15 * 60


class _TemperaturePlot:
    _option: dict[str, Any]
    state: dict[
        str,
        dict[  # map sensor ID to sensor data
            str, list[datetime] | list[float]  # map field (like "time") to values
        ],
    ]

    def __init__(
        self,
        level: str,
        sensor_ids: list[str],
        colors: list[str],
    ) -> None:
        self._option = {
            "title": {"text": f"{level} Temperature"},
            "tooltip": {"trigger": "axis"},
            "dataZoom": [
                {"type": "inside", "xAxisIndex": 0},
            ],
            "xAxis": {
                "type": "time",
                "axisLabel": {
                    "hideOverlap": True,
                    "formatter": JSCode("""
                        v => {
                            const d = new Date(v);
                            return d.toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                            });
                        }
                    """),
                },
            },
            "yAxis": {
                "type": "value",
                "name": "Temperature (K)",
                "axisLabel": {
                    "formatter": JSCode("""
                        v => {
                            if (v >= 1e3) return (v / 1e3).toFixed(2) + 'k';
                            return v.toFixed(2);
                        }
                    """)
                },
                "min": JSCode("v => v.min - (v.max - v.min) * 0.125"),
                "max": JSCode("v => v.max + (v.max - v.min) * 0.125"),
            },
        }
        self.level = level
        self.colors = colors
        self.sensor_ids = sensor_ids
        self.state = {}
        for sid in sensor_ids:
            self.state[sid] = {"time": [], "temperature": []}
        self.root = ECharts(self._option, height=300, sizing_mode="stretch_width")
        _logger.debug(f"Plot set up for level: {level} with sensor IDs: {sensor_ids}")

    def update(self) -> None:
        self._option["series"] = [
            {
                "name": sid,
                "type": "line",
                "showSymbol": False,
                "emphasis": {"focus": "series"},
                "lineStyle": {
                    "color": self.colors[i] if i < len(self.colors) else "#000000",
                    "width": 1,
                },
                "data": [
                    [time, temp]
                    for time, temp in zip(
                        self.state[sid]["time"], self.state[sid]["temperature"]
                    )
                ],
            }
            for i, sid in enumerate(self.sensor_ids)
        ]

        self.root.param.trigger("object")


class TemperatureWidget:
    """Widget to display temperature measurements from thermometry units.

    Uses an ECharts pane to display temperature information over time,
    and provides a dropdown selector to filter the data on specified time ranges.
    Each cryostat level displays its own temperature sensor info as a separate
    `_TemperaturePlot`. Multiple temperature sensors per level may exist.

    Parameters
    ----------
    thermometry_component_id : str
        The ID that is used to retrieve information from the backend.
    thermometer_map: dict[str, str]
        Mapping from sensor ID to cryostat level. Defaults to none.
    """

    def __init__(
        self,
        thermometry_component_id: str,
        thermometer_map: dict[str, str] = {},
    ) -> None:
        self._doc = curdoc()
        self.time_ranges = {
            "7 days": _SECS_7_DAYS,
            "2 days": _SECS_2_DAYS,
            "1 day": _SECS_1_DAY,
            "12 hours": _SECS_12_HOURS,
            "6 hours": _SECS_6_HOURS,
            "3 hours": _SECS_3_HOURS,
            "1 hour": _SECS_1_HOUR,
            "15 minutes": _SECS_15_MINUTES,
        }
        self.selected_range = "3 hours"
        self.select_div = HTML(object="Show data since:", align="center")
        self.range_select = Select(
            value=self.selected_range,
            options=list(self.time_ranges.keys()),
        )
        self.range_select.param.watch(self._on_range_change, "value")  # type: ignore
        self.valid_levels = [
            lvl for lvl in CRYOSTAT_LEVELS if lvl in set(thermometer_map.values())
        ]
        self.timerange = _SECS_3_HOURS
        colors = get_pallete(len(thermometer_map))
        self.plots = [
            _TemperaturePlot(
                level=lvl,
                sensor_ids=[
                    id for id, i_lvl in thermometer_map.items() if i_lvl == lvl
                ],
                # rotate the list so each plot gets different colours
                colors=colors[i:] + colors[:i],
            )
            for i, lvl in enumerate(self.valid_levels)
        ]
        row_1 = Row(*[p.root for p in self.plots[0:3]])
        row_2 = Row(
            *(
                [p.root for p in self.plots[3:5]]
                # Add a spacer here so the plots don't stretch wider than
                # the plots on the row above
                + [Spacer(min_width=400, sizing_mode="stretch_width")]
            )
        )

        # Add range select to the top right of the tab panel

        select_row = Row(
            Spacer(sizing_mode="stretch_width"),
            self.select_div,
            self.range_select,
            sizing_mode="stretch_width",
        )
        self.tab_panel = Column(
            select_row,
            row_1,
            row_2,
            name="Temperature",
        )
        self._query_api = influxdb2_query_api_async()
        self._thermometer_map = thermometer_map
        topic_filters = [
            (
                TemperaturePoint,
                f"{DEFAULT_SYSTEM_MONITOR_SERVICE}.{thermometry_component_id}.{topic}",
            )
            for topic in thermometer_map
        ]
        # Need to keep a reference to the subscriber tasks to avoid garbage collection
        self.subscriber_tasks = lambda: subscribe_to_events_task(
            self._doc, topic_filters, self.update_sub
        )
        self._sub_task = None

    async def initial_update(self, timerange_s: int = -1) -> None:
        """Load initial data from InfluxDB2."""
        self.timerange = timerange_s if timerange_s > 0 else self.timerange
        query = f"""
            from(bucket: "system_monitor")
                |> range(start: -{self.timerange}s)
                |> filter(fn: (r) => r["_measurement"] == "temperature_measurement")
                |> filter(fn: (r) => r["_field"] == "temperature")
                |> filter(fn: (r) => r["level"] != "N/A")
                |> aggregateWindow(
                    every: {max(self.timerange // 500, 10)}s,
                    fn: mean, createEmpty: false
                )
                |> group()
                |> keep(columns: ["_value", "_time", "level", "sensor_id"])
                |> sort(columns: ["_time"], desc: false)
                |> yield(name: "mean")
            """
        result = await self._query_api.query(query)
        data: dict[str, dict[str, list[Any]]] = {}
        for table in result:
            for rec in table.records:
                sid = rec["sensor_id"]
                if sid not in self._thermometer_map:
                    _logger.warning(
                        f"Received data from database unknown sensor ID {sid}"
                    )
                    continue
                if sid not in data:
                    data[sid] = dict(time=[], temperature=[])
                local_time = to_local_time(rec["_time"])
                data[sid]["temperature"].append(rec["_value"])
                data[sid]["time"].append(local_time)
        _logger.debug(f"Queried data from sensors {data.keys()}")
        for sid, s_data in data.items():
            for plot in self.plots:
                if sid in plot.sensor_ids:
                    plot.state[sid] = s_data
                plot.update()
        self._sub_task = self.subscriber_tasks()

    def _on_range_change(self, event: Event) -> None:
        # event.old and event.new hold previous and current values
        self.selected_range = cast("str", event.new)  # type: ignore

        range_value = self.time_ranges.get(self.selected_range, _SECS_1_DAY)
        if self._sub_task:
            self._sub_task.cancel()
        self._aggregation_task = asyncio.create_task(self.initial_update(range_value))

    def update(self) -> None:
        """Manually updating is not necessary for this widget."""
        pass

    def update_sub(self, event: TemperaturePoint) -> None:
        """Update the plot with new data from subscriber."""
        # Process the event as needed
        _logger.debug(f"Received TemperaturePoint event: {event}")
        if not any(event.sensor_id in plot.sensor_ids for plot in self.plots):
            _logger.debug(
                f"event sensor {event.sensor_id} not in"
                f"{[plot.sensor_ids for plot in self.plots]}"
            )
            return
        new_data = {
            "time": [event.time],
            "temperature": [event.temperature],
        }
        _logger.debug(f"Received temp {new_data}")

        level = self._thermometer_map[event.sensor_id]
        plot = next(p for p in self.plots if p.level == level)
        plot.state[event.sensor_id]["time"].append(event.time)  # type: ignore
        plot.state[event.sensor_id]["temperature"].append(event.temperature)  # type: ignore
        plot.update()
