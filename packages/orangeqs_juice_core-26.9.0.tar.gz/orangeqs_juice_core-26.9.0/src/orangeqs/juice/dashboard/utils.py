"""Utilities for dashboard."""

from __future__ import annotations

import itertools
import logging
import os
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from bokeh.document import Document
from typing_extensions import override

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

    from bokeh.application.application import SessionContext
    from tornado import web

import asyncio
import re
from functools import partial
from inspect import Signature, signature

import pandas as pd
from bokeh.application import Application
from bokeh.application.handlers import FunctionHandler
from bokeh.models import ImportedStyleSheet
from jinja2 import BaseLoader, ChoiceLoader, Environment, PackageLoader
from jinja2 import Template as JinjaTemplate
from panel.template import Template
from panel.viewable import ServableMixin
from pydantic import BaseModel, Field, model_validator

from orangeqs.juice._entrypoints import collect_entry_points
from orangeqs.juice.client.pubsub import subscriber_async

_logger = logging.getLogger(__name__)

TORNADO_APPLICATIONS = collect_entry_points(group="juice.dashboard.tornado")
BOKEH_APPLICATIONS = collect_entry_points(group="juice.dashboard.bokeh")


def create_dashboard_config() -> DashboardConfig:
    """Create dashboard configuration by collecting entry points."""
    pages = DashboardConfig()
    # Collect pages from entry points
    for method_name, entry_point in itertools.chain(
        BOKEH_APPLICATIONS.items(),
        filter(lambda e: e[0] == "/", TORNADO_APPLICATIONS.items()),
    ):
        _logger.debug(f"Found entry point: {method_name} -> {entry_point.name}")
        pages.add_page_from_entrypoint(method_name)

    # Modifications for the navigation bar
    pages.entries["core"].name = "Juice"

    return pages


def _jupyterhub_service_prefix() -> str:
    """Get the JupyterHub service prefix without trailing slash.

    Looks up the `JUPYTERHUB_SERVICE_PREFIX` environment variable to determine the
    prefix. This variable usually contains the prefix for the user container, e.g.
    `/user/<username>`. Ensures that the returned prefix has no trailing slash.
    """
    prefix = os.environ.get("JUPYTERHUB_SERVICE_PREFIX", "")
    if prefix.endswith("/"):
        prefix = prefix[:-1]
    return prefix


def dashboard_base_url() -> str:
    """Get the base URL for the dashboard without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint for the dashboard, which is `/dashboard`

    An example full URL would be `/user/<username>/dashboard`.
    """
    return f"{_jupyterhub_service_prefix()}/dashboard"


def filebrowser_base_url() -> str:
    """Get the base URL for the filebrowser without trailing slash.

    A direct link to a specific path in the file browser can be constructed as
    `{filebrowser_base_url()}/path/to/directory`.

    The URL returned by this function consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The proxy path for the file browser, which is `/filebrowser`
    - The endpoint to serve files of the file browser, which is `/files`

    An example returned URL is `/user/<username>/filebrowser/files`.
    """
    return f"{_jupyterhub_service_prefix()}/filebrowser/files"


def jupyterlab_base_url() -> str:
    """Get the base URL for JupyterLab without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint to serve JupyterLab, which is `/lab`

    An example full URL would be `/user/<username>/lab`.
    """
    return f"{_jupyterhub_service_prefix()}/lab"


def vscode_base_url() -> str:
    """Get the base URL for VS Code without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint to serve VS Code, which is `/vscode`

    An example full URL would be `/user/<username>/vscode`.
    Specific folders can be opened by adding `?folder=path/to/folder` to the URL.
    """
    return f"{_jupyterhub_service_prefix()}/vscode"


def collect_dashboard_applications() -> tuple[
    list[tuple[str, type[web.RequestHandler], dict[str, Any]]],
    dict[str, Callable[..., Template] | Application],
]:
    """Collect all dashboard applications defined by extensions.

    Returns
    -------
    dict[str, type[web.RequestHandler], dict[str, Any]]
        A dictionary mapping URL paths to Tornado request handlers
        and their initialization arguments.
    dict[str, Application]
        A dictionary mapping URL paths to Bokeh applications.
    """
    # Assemble template variables
    template_variables = {
        "base_url": dashboard_base_url(),
        **create_dashboard_config().model_dump(),
    }

    # Collect tornado applications from entry points
    applications: list[tuple[str, type[web.RequestHandler], dict[str, Any]]] = []
    _logger.debug("Collecting tornado applications from entry points")
    for method_name, entry_point in TORNADO_APPLICATIONS.items():
        _logger.debug(f"Found tornado entry point: {method_name} -> {entry_point.name}")
        handler = entry_point.load()
        applications.append(
            (
                f"/{method_name.lstrip('/')}",
                handler,
                {"template_variables": template_variables},
            )
        )

    # Collect bokeh applications from entry points
    bokeh_apps: dict[str, Callable[..., Template] | Application] = {}
    _logger.debug("Collecting bokeh applications from entry points")
    for method_name, entry_point in BOKEH_APPLICATIONS.items():
        _logger.debug(f"Found Bokeh entry point: {method_name} -> {entry_point.name}")
        try:
            app_function = entry_point.load()
            _logger.debug(
                f"Loaded Bokeh app function for {method_name}: {repr(app_function)}"
            )
            kind = _classify_app_function(app_function)

            try:
                if kind == "doc_modifier":
                    _app = Application(  # type: ignore
                        FunctionHandler(partial(app_function, template_variables))
                    )
                elif kind == "panel_factory":

                    def _app(func=app_function, vars=template_variables):  # type: ignore # noqa: ANN001, ANN202
                        return func(vars)
                else:
                    raise RuntimeError("This should be unreachable.")
            except TypeError as e:
                raise TypeError(
                    "Cannot determine how to handle app function"
                    f"{app_function.__name__!r}: {e}."
                    "Expected a Bokeh doc-modifier or a Panel viewable factory."
                )

            bokeh_apps[f"/{method_name.lstrip('/')}"] = _app

        except Exception as e:
            _logger.error(f"Failed to load Bokeh app {method_name}: {e}")

    return applications, bokeh_apps


def _classify_app_function(func: Callable[..., Any]) -> str:
    """
    Determine what kind of app function a function is.

    If the function has a Bokeh Document as a parameter, it will be
    classified as a Bokeh Document modification function. For example
    `create_overview_doc(template_variables: dict[str, Any], doc: Document) -> None`.
    If the return annotation is servable by Panel or the literal string "Template"
    it will be classified as a Panel Template creation function. For example
    `create_overview_doc(template_variables: dict[str, Any]) -> Template`.

    Parameters
    ----------
        func: Callable[..., Any]
            The function to classify.

    Returns
    -------
        Either "doc_modifier" for Bokeh Document modification functions or panel_factory
        for Panel Template creation functions.
    """
    sig = signature(func)

    params = list(sig.parameters.values())
    has_doc_param = any(p.annotation is Document or p.name == "doc" for p in params)

    return_ann = sig.return_annotation

    # Function modifies a Bokeh doc
    if has_doc_param:
        return "doc_modifier"

    # Function produces a Panel viewable
    if return_ann is not Signature.empty and (
        (isinstance(return_ann, type) and issubclass(return_ann, ServableMixin))
        or isinstance(return_ann, str)
        and return_ann.split(".")[-1] == "Template"
    ):
        return "panel_factory"

    raise TypeError(f"Unrecognised signature: {params} -> {return_ann}")


def _url_to_name(url: str) -> str:
    """Convert a URL path to a human-readable name.

    Replaces `-`, `_`, and `/` with spaces and capitalizes each word.
    """
    words = re.split(r"[-/_]+", url.strip("/"))
    return " ".join(word.capitalize() for word in words)


# TODO: This list is hardcoded for now. Eventually we should
# migrate from the entry-point system to a configuration system
# for defining dashboard applications. This allows to include metadata
# like description and thumbnail image, and to define categories
# and ordering of the applications.
def _common_apps() -> dict[str, DashboardCategory]:
    """Build a list of dashboard applications."""
    entries: dict[str, DashboardCategory] = {}
    entries["core"] = DashboardCategory(
        order=10,
        name="Juice Core",
        image="static/juice/images/orangeqs-juice.svg",
        url="core/home",
        pages={
            "system-overview": DashboardEntry(
                order=10,
                name="System overview",
                url="core/system-overview",
                description=("CPU, memory and disk usage and service resource usage."),
                image="static/juice/images/thumbnails/juice.svg",
            ),
            "service-logs": DashboardEntry(
                order=15,
                name="Service logs",
                url="core/service-logs",
                description=(
                    "Logs of each service, useful for debugging and monitoring."
                ),
                image="static/juice/images/thumbnails/juice.svg",
            ),
            "task-manager": DashboardEntry(
                order=20,
                name="Task manager",
                url="core/task-manager",
                description=("Service kernel states and list of tasks."),
                image="static/juice/images/thumbnails/juice.svg",
            ),
            "fridge-monitor": DashboardEntry(
                order=30,
                name="Fridge monitor",
                url="core/fridge-monitor",
                description=("Overview and control of the cryogenic system."),
                image="static/juice/images/thumbnails/juice.svg",
            ),
        },
    )
    entries["tools"] = DashboardCategory(
        order=30,
        name="Tools",
        pages={
            "jupyterlab": DashboardEntry(
                name="JupyterLab",
                url=jupyterlab_base_url(),
                description=("Managing Jupyter notebooks, Python code and files."),
                image="static/juice/images/thumbnails/jupyterlab.svg",
                new_tab=True,
            ),
            "vscode": DashboardEntry(
                name="VS Code",
                url=vscode_base_url(),
                description=("Web interface for Visual Studio Code."),
                image="static/juice/images/thumbnails/vscode.svg",
                new_tab=True,
            ),
            "filebrowser": DashboardEntry(
                name="File browser",
                url=filebrowser_base_url(),
                description=("Web interface for browsing and downloading files."),
                image="static/juice/images/thumbnails/filebrowser.svg",
                new_tab=True,
            ),
        },
    )
    entries["resources"] = DashboardCategory(
        order=40,
        name="Resources",
        pages={
            "documentation": DashboardEntry(
                name="Documentation",
                url="https://docs.orangeqs.com/juice/core",
                description=("Tutorials, examples, concepts and reference."),
                image="static/juice/images/thumbnails/docs.svg",
                new_tab=True,
            ),
        },
    )

    # Conditionally include extension pages based on entrypoints
    extension_pages = [
        "graph-monitor",
        "instrument-monitor",
        "plot-monitor",
        "fridge-automation",
    ]
    if any(page in BOKEH_APPLICATIONS for page in extension_pages):
        entries["extensions"] = DashboardCategory(
            order=20,
            name="Extensions",
            pages={},
        )
    if "instrument-monitor" in BOKEH_APPLICATIONS:
        entries["extensions"].pages["instrument"] = DashboardEntry(
            order=10,
            name="Instrument Monitor",
            url="instrument-monitor",
            description=("Instrument and quantum device state explorer."),
            image="static/juice/images/thumbnails/juice.svg",
        )
    if "graph-monitor" in BOKEH_APPLICATIONS:
        entries["extensions"].pages["graph"] = DashboardEntry(
            order=20,
            name="Graph Monitor",
            url="graph-monitor",
            description=("Calibration graph progress and analyzed experiment results."),
            image="static/juice/images/thumbnails/juice.svg",
        )
    if "plot-monitor" in BOKEH_APPLICATIONS:
        entries["extensions"].pages["plot"] = DashboardEntry(
            order=30,
            name="Plot Monitor",
            url="plot-monitor",
            description=("Live plotting of experimental results."),
            image="static/juice/images/thumbnails/juice.svg",
        )
    if "fridge-automation" in BOKEH_APPLICATIONS:
        entries["extensions"].pages["fridge-automation"] = DashboardEntry(
            order=40,
            name="Fridge Automation",
            url="fridge-automation",
            description=("Automated control of the cryogenic system."),
            image="static/juice/images/thumbnails/juice.svg",
        )

    return entries


class DashboardEntry(BaseModel):
    """Dashboard navigation bar entry."""

    name: str
    """Human-readable name of the entry."""
    url: str | None = None
    """URL path of the entry, or None if not a link.

    If the URL starts with `http://` or `https://`, it's considered an absolute URL.
    If the URL starts with a `/`, it's considered an absolute path on the current
    domain.
    Otherwise the URL is considered relative to the dashboard base URL, which is useful
    for linking to specific dashboard pages.
    """
    new_tab: bool = False
    """Whether to open the link in a new tab."""
    image: str | None = None
    """Optional image URL for the entry.

    Always relative to the dashboard base URL.
    """

    description: str | None = None
    """Optional description of the entry, shown on the homepage."""

    order: int = Field(default=100, ge=0)
    """Order of the entry in the navigation bar. Lower numbers appear first."""


class DashboardCategory(DashboardEntry):
    """Category in the dashboard navigation bar."""

    pages: dict[str, DashboardEntry] = Field(default_factory=dict)
    """Sub-pages under this category, keyed by unique keys."""


class DashboardConfig(BaseModel):
    """Configuration for the dashboard.

    Defines the structure of the navigation bar. Might be extended in the future.
    """

    entries: dict[str, DashboardCategory] = Field(default_factory=dict)
    """Top-level categories in the navigation bar, keyed by unique keys."""

    def add_page_from_entrypoint(self, url: str) -> None:
        """Add a page to the dashboard by URL.

        If the page URL is found in the common apps, it will be added as that entry.

        Otherwise, this assumes the URL is of the form "category/page" or just "page".
        Automatically creates categories as needed.
        """
        existing_entry = _url_exists_in_common_apps(url)
        if existing_entry:
            return

        url = url.strip("/")
        if not url:
            # Cannot add a page with an empty URL
            return

        category_url, _, relative_page_url = url.partition("/")

        if category_url not in self.entries:
            self.entries[category_url] = DashboardCategory(
                name=_url_to_name(category_url)
            )
        category: DashboardCategory = self.entries[category_url]

        if relative_page_url:
            # Add the page to the category
            page = DashboardEntry(
                name=_url_to_name(relative_page_url),
                url=url,
            )
            category.pages[relative_page_url] = page
        else:
            # Make the category entry point to this page.
            category.url = url

    @model_validator(mode="after")
    def _add_common_apps(self) -> DashboardConfig:
        """Add common apps to the dashboard configuration."""
        for category_key, category in HOME_PAGE_APPS.items():
            if category_key not in self.entries:
                self.entries[category_key] = category.model_copy(deep=True)
            else:
                for page_key, entry in category.pages.items():
                    if page_key not in self.entries[category_key].pages:
                        self.entries[category_key].pages[page_key] = entry.model_copy(
                            deep=True
                        )
        return self


HOME_PAGE_APPS = _common_apps()
"""Predefined common applications for the dashboard homepage.

These are also used to populate the navigation bar.
"""


def _url_exists_in_common_apps(url: str) -> bool:
    """Check if a URL exists in the common apps.

    Returns
    -------
    bool
        True if the URL is found in the common apps, False otherwise.
    """
    for category in HOME_PAGE_APPS.values():
        if category.url == url:
            return True
        for entry in category.pages.values():
            if entry.url == url:
                return True
    return False


def subscribe_to_events_task(
    doc: Document,
    subscriptions: list[tuple[type, str]],
    handler: Callable[[Any], None],
) -> asyncio.Task[Any]:
    """
    Create and manage an async task to listen for pub/sub events.

    WARNING: The returned task must be kept referenced to avoid being garbage collected.

    Parameters
    ----------
        doc: Document
            The Bokeh document to schedule callbacks on.
        subscriptions: list[tuple[type, str]]
            A list of (event class, topic) tuples to subscribe to.
        handler: Callable[[Any], None]
            A callable to handle each incoming event.

    Returns
    -------
        An asyncio.Task managing the subscription.

    Example:
        class SomeDashboardComponent:
            def __init__(self, client, doc):
                self.client = client
                self.doc = doc
                self.listener_task = subscribe_to_events_task(
                    self.doc,
                    [(QuantityUpdate, "he3_flow")],
                    self._handle_event
                )

            def _handle_event(self, event):
                # Process event (e.g. update a ColumnDataSource)
                self.source.patch({...})
    """

    async def listen() -> None:
        subscriber = subscriber_async()
        for event_class, topic in subscriptions:
            subscriber.subscribe(event_class, topic=topic)

            _logger.debug("Subscribed to %s on topic %s", event_class, topic)

        asyncio.create_task(subscriber.listen())

        while True:
            event = await subscriber.queue.get()
            try:
                doc.add_next_tick_callback(partial(handler, event))
            except Exception as e:
                _logger.warning(f"Could not schedule callback: {e}")
                break

    task = asyncio.create_task(listen())

    def on_done(t: asyncio.Task[Any]) -> None:
        try:
            exc = t.exception()
            if exc:
                _logger.exception(f"Listener crashed: {exc}")
        except asyncio.CancelledError:
            _logger.info("Listener was cancelled.")
        except Exception:
            _logger.exception("Unexpected exception in listener")

    task.add_done_callback(on_done)

    def _on_session_destroyed(
        session_context: SessionContext, task: asyncio.Task[Any]
    ) -> None:
        if not task.done():
            task.cancel()
            _logger.info("Listener task cancelled due to session end.")

    doc.on_session_destroyed(partial(_on_session_destroyed, task=task))

    return task


def get_pallete(count: int) -> list[str]:
    """Return OQS color palatte for <count> colors, repeating."""
    base_list = [
        "#326299",  # oqs_blue
        "#EA7422",  # oqs_orange
        "#7CB75D",  # oqs_green
        "#E62D27",  # oqs_red
        "#F9BF0C",  # oqs_amber
        "#45D4D2",  # oqs_cyan
    ]

    def cycle() -> Iterator[str]:
        """Cycle through base_list of colors."""
        while True:
            yield from base_list

    return [x for (_, x) in zip(range(count), cycle())]


def get_stylesheet(path: str) -> ImportedStyleSheet:
    """Retrieve CSS file hosted by the singleuser server."""
    return ImportedStyleSheet(url=dashboard_base_url() + f"/static/juice/css/{path}")


def to_local_time(dt: datetime) -> datetime:
    """
    Convert a datetime object to the local timezone.

    Parameters
    ----------
        dt (datetime): The datetime object to convert. It should be timezone-aware.
                       If the input datetime is naive (lacking timezone information),
                       it will be assumed to be in UTC, and a warning will be raised.

    Returns
    -------
        datetime: The datetime object converted to the local timezone.

    Notes
    -----
        - If the input is a pandas.Timestamp, it will be handled similarly, with naive
          timestamps being assumed to be in UTC.
        - A warning will be logged if the input datetime or pandas.Timestamp is naive.
    """
    if isinstance(dt, pd.Timestamp):
        if dt.tz is None:
            _logger.warning(
                "Input pandas Timestamp is naive (no timezone info), assuming UTC.",
                stacklevel=2,
            )
            dt = dt.tz_localize(tz=timezone.utc)
        return dt.tz_convert(datetime.now().astimezone().tzinfo)
    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        _logger.warning(
            "Input datetime is naive (no timezone info), assuming UTC.", stacklevel=2
        )
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone()


class JuiceEnvironment(Environment):
    """Manage the Jinja template environment for Juice."""

    _template_paths = [
        "orangeqs.juice.dashboard",
        "orangeqs.juice.dashboard.pages.templates",
    ]

    @override
    def __init__(
        self,
        extra_loaders: BaseLoader | list[BaseLoader] | None = None,
        extra_template_paths: str | list[str] | None = None,
    ) -> None:
        """Juice template environment.

        Parameters
        ----------
            extra_loaders: BaseLoader | list[BaseLoader] = None
                Extra Jinja template loaders. Useful for Juice Extensions that cannot
                place templates in the Juice Core templates directory.
            extra_template_paths: str | list[str] = None
                Extra template paths. For example `orangeqs.juice_ext.my_ext.templates`.
        """
        template_paths: list[str] = self._template_paths
        if extra_template_paths:
            if isinstance(extra_template_paths, list):
                template_paths += extra_template_paths
            else:
                template_paths.append(extra_template_paths)
        loaders: list[BaseLoader] = [
            PackageLoader(p, package_path="") for p in template_paths
        ]
        if extra_loaders:
            if isinstance(extra_loaders, list):
                loaders += extra_loaders
            else:
                loaders.append(extra_loaders)
        super().__init__(loader=ChoiceLoader(loaders))

    def get_jinja_template(self, file_name: str) -> JinjaTemplate:
        """Retrieve a Jinja template by name."""
        return self.get_template(file_name)

    def get_panel_template(self, file_name: str) -> Template:
        """Retrieve a template by file name as a Panel template.

        For Juice Extensions: Note that if the directory the template file
        is in has not been added with extra_loaders or extra_template_paths
        in the init function beforehand, it will not be found.
        """
        return Template(self.get_template(file_name))
