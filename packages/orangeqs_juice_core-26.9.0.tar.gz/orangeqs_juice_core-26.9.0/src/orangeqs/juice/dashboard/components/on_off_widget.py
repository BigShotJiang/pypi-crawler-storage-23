"""Widget for turning ON and OFF hardware."""

from __future__ import annotations

import asyncio
import logging
import time
from enum import IntEnum
from typing import TYPE_CHECKING, Literal

from bokeh.core.enums import ButtonType
from bokeh.layouts import row
from bokeh.models.widgets import Button

from orangeqs.juice.client import Client
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.system_monitor.data_structures import ComponentEnabledPoint

if TYPE_CHECKING:
    from bokeh.document import Document

    from orangeqs.juice.task import Task

logger = logging.getLogger(__name__)


class ToggleState(IntEnum):
    """State of device state toggling."""

    OFF = 0
    ON_REQUESTED = 1
    ON = 2
    OFF_REQUESTED = 3


class OnOffToggle:
    """Utility Widget to turn on and off a hardware component in a service."""

    def __init__(
        self,
        *,
        doc: Document,
        service: str,
        on_task: Task,
        off_task: Task,
        response_timeout: int,
        device_state_check_task: Task,
        enabled_topic: str,
        title: str,
        button_width: int,
        button_height: int | None,
        on_label: str = "On",
        off_label: str = "Off",
        mode: Literal["read_only", "power_user"] = "power_user",
    ) -> None:
        self._doc = doc
        self.service = service
        self.on_task = on_task
        self.off_task = off_task
        self.device_state_check_task = device_state_check_task
        self.title = title
        self.response_timeout = response_timeout
        self.toggle_state = None
        self.toggle_requested_time = float("-inf")
        self.juice_client = Client()
        self.enabled_topic = enabled_topic

        self.on_button = Button(
            label=on_label,
            button_type="default",
            width=button_width,
            height=button_height,
        )
        self.off_button = Button(
            label=off_label,
            button_type="default",
            width=button_width,
            height=button_height,
        )
        self.on_button.on_click(self._on_callback)
        self.off_button.on_click(self._off_callback)

        if mode == "read_only":
            self.on_button.disabled = True
            self.off_button.disabled = True

        self.root = row(self.on_button, self.off_button)
        self.initialized = False  # To track if initial_update has been called

    async def initial_update(self) -> None:
        """Initialise the state of the widget."""
        logger.debug(f"Initialising OnOffToggle Widget: {self.title}")
        returned_task_result = await self.juice_client.execute(
            self.service,
            self.device_state_check_task,
            check=True,
        )
        device_state = returned_task_result.result

        logger.debug(f"Retrieved Device State for {self.title}: {device_state}")
        if device_state is True:
            self.toggle_state = ToggleState.ON
        elif device_state is False:
            self.toggle_state = ToggleState.OFF
        else:
            logger.critical(
                f"Unknown Device State {device_state} received for {self.title}"
            )
            return
        self._doc.add_next_tick_callback(self._update_button_states)

        self.listener_task = subscribe_to_events_task(
            self._doc,
            [
                (ComponentEnabledPoint, self.enabled_topic),
            ],
            self._handle_enabled_update,
        )

        self.initialized = True

    def _on_callback(self) -> None:
        """Handle ON button press."""
        logger.debug(f"Starting ON task for {self.title}")
        asyncio.create_task(
            self.juice_client.request(self.service, self.on_task, check=True)
        )
        self.toggle_requested_time = time.time()
        self.toggle_state = ToggleState.ON_REQUESTED
        self._doc.add_next_tick_callback(self._update_button_states)

    def _off_callback(self) -> None:
        """Handle OFF button press."""
        logger.debug(f"Starting OFF task for {self.title}")
        asyncio.create_task(
            self.juice_client.request(self.service, self.off_task, check=True)
        )
        self.toggle_requested_time = time.time()
        self.toggle_state = ToggleState.OFF_REQUESTED
        self._doc.add_next_tick_callback(self._update_button_states)

    def _handle_enabled_update(self, event: ComponentEnabledPoint) -> None:
        """Handle incoming state update event."""
        logger.debug(
            f"Received state update for {self.title} over topic "
            f"{event.topic()}: Enabled={event.enabled}"
        )
        if event.enabled is True:
            self.toggle_state = ToggleState.ON
        else:
            self.toggle_state = ToggleState.OFF
        logger.debug(f"Updated internal state for {self.title} to {self.toggle_state}")
        self._doc.add_next_tick_callback(self._update_button_states)

    def _update_button_states(self) -> None:
        """Update button colors based on toggle_state variable."""
        if self.toggle_state is ToggleState.OFF:
            self.on_button.button_type = ButtonType.default  # type: ignore
            self.off_button.button_type = ButtonType.success  # type: ignore

        elif self.toggle_state is ToggleState.ON_REQUESTED:
            self.on_button.button_type = ButtonType.warning  # type: ignore
            self.off_button.button_type = ButtonType.default  # type: ignore

        elif self.toggle_state is ToggleState.ON:
            self.on_button.button_type = ButtonType.success  # type: ignore
            self.off_button.button_type = ButtonType.default  # type: ignore

        elif self.toggle_state is ToggleState.OFF_REQUESTED:
            self.on_button.button_type = ButtonType.default  # type: ignore
            self.off_button.button_type = ButtonType.warning  # type: ignore

        else:
            logger.critical(
                f"Unknown internal dashboard state {self.toggle_state} for {self.title}"
            )
            # Disable buttons in case of an unknown state
            self.on_button.disabled = True
            self.off_button.disabled = True
