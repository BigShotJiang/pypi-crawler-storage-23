DASHBOARD_PORT = 8443
"""The port on which the dashboard server listens.

This means the dashboard will be accessible through the Jupyterlab proxy at
`/user/<username>/proxy/8443` and its alias `/user/<username>/dashboard`.
"""

FILEBROWSER_PORT = 8085
"""The port on which the file browser server listens.

This means the file browser will be accessible through the Jupyterlab proxy at
`/user/<username>/proxy/8085/files` and its alias `/user/<username>/filebrowser`.
"""
