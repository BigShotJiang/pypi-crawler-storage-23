import logging
import os


def setup_logging(file_logging: bool = True) -> logging.Logger:
    logger = logging.getLogger()
    logging.basicConfig(level=logging.DEBUG)
    logger.setLevel(logging.DEBUG)

    if file_logging:
        log_file = os.getenv("DASHBOARD_LOG_FILE")
        if not log_file:
            raise ValueError("Dashboard log file path not found in configuration")
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        ch = logging.FileHandler(log_file)
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    logging.getLogger("bokeh.server.tornado").addFilter(SuppressBokehRouteDump())
    return logger


class SuppressBokehRouteDump(logging.Filter):
    def __init__(self) -> None:
        super().__init__()
        self._dropping = False

    def filter(self, record: logging.LogRecord) -> bool:
        if record.name != "bokeh.server.tornado":
            return True

        msg = record.getMessage()

        # First line of the dump
        if msg == "Patterns are:":
            self._dropping = True
            return False

        # The following lines are the indented route entries
        if self._dropping:
            if msg.startswith("  "):
                return False
            # first non-indented line -> stop dropping
            self._dropping = False

        return True
