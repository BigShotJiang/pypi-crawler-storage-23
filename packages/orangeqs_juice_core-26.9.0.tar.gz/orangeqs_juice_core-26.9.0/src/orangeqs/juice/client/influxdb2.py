"""
Utilities to interact with OrangeQS Juice InfluxDB databases.

This module defines cached shortcuts to get databases and their specific APIs based on
Juice config. Resulting API wrappers are cached, which reduces amount of objects that
Juice needs to construct internally to communicate with databases.
"""
# pyright: reportMissingTypeStubs=false

from datetime import datetime

from influxdb_client.client.influxdb_client import InfluxDBClient
from influxdb_client.client.influxdb_client_async import InfluxDBClientAsync
from influxdb_client.client.query_api import QueryApi
from influxdb_client.client.query_api_async import QueryApiAsync
from influxdb_client.client.write_api import WriteApi, WriteOptions
from influxdb_client.client.write_api_async import WriteApiAsync

from orangeqs.juice.schemas.influxdb2 import InfluxDB2Tokens

from .identity import get_identity

__all__ = [
    "influxdb2_client",
    "influxdb2_client_async",
    "influxdb2_query_api",
    "influxdb2_query_api_async",
    "influxdb2_write_api",
    "influxdb2_write_api_async",
]


def retrieve_influxdb2_token() -> str:
    """
    Retrieve the InfluxDB2 token based on the current identity.

    Returns
    -------
        The InfluxDB2 token.
    """
    tokens = InfluxDB2Tokens.load().tokens
    identity_type, identity_name = get_identity()
    token = None

    if identity_type == "user":
        token = tokens.get("user")
    elif identity_type == "service":
        token = tokens.get(identity_name)
    if token is None:
        raise RuntimeError(
            f"No InfluxDB2 token found for identity {identity_type}-{identity_name}"
        )
    return token.token


def influxdb2_client() -> InfluxDBClient:
    """
    Get an InfluxDB2 API client for the database.

    Returns
    -------
        InfluxDB client.
    """
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    influxdb2_settings = OrchestrationSettings.load().influxdb2
    token = retrieve_influxdb2_token()
    return InfluxDBClient(influxdb2_settings.url, token, org=influxdb2_settings.org)


def influxdb2_client_async() -> InfluxDBClientAsync:
    """
    Get an InfluxDB2 API client for the database.

    Returns
    -------
        InfluxDBAsync client.
    """
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    influxdb2_settings = OrchestrationSettings.load().influxdb2
    token = retrieve_influxdb2_token()
    return InfluxDBClientAsync(
        influxdb2_settings.url, token, org=influxdb2_settings.org
    )


def influxdb2_query_api() -> QueryApi:
    """
    Get an InfluxDB2 query API client for the database.

    Returns
    -------
        InfluxDB query API.
    """
    return influxdb2_client().query_api()  # type: ignore


def influxdb2_query_api_async() -> QueryApiAsync:
    """
    Get an InfluxDB2 query API async client for the database.

    Returns
    -------
        InfluxDBAsync query API.
    """
    return influxdb2_client_async().query_api()  # type: ignore


def influxdb2_write_api(
    write_options: WriteOptions = WriteOptions(),
) -> WriteApi:
    """
    Get an InfluxDB2 write API client for the database.

    Parameters
    ----------
    write_options : WriteOptions, optional
        Configuration options for batching, retries, etc.

    Returns
    -------
        WriteApi
    """
    return influxdb2_client().write_api(write_options)  # type: ignore


def influxdb2_write_api_async() -> WriteApiAsync:
    """
    Get an InfluxDB2 write API async client for the database.

    Returns
    -------
        WriteApiAsync
    """
    return influxdb2_client_async().write_api()  # type: ignore


def datetime_to_unix_ns_int(dt_obj: datetime) -> int:
    """Return a Unix Nanosecond object from a native python datetime object.

    This is useful when making influxdb2 queries as it expects either RFC3339
    compliant strings or unix ns integers
    https://docs.influxdata.com/influxdb/v2/query-data/flux/operate-on-timestamps/#rfc3339-to-unix-nanosecond
    """
    return int(dt_obj.timestamp() * 1_000_000_000)
