"""Sending tasks to a service over a websocket connection."""

import asyncio
import contextlib
import logging
import time
import warnings
from typing import (
    Any,
    Generic,
    TypeVar,
)
from uuid import uuid4

import tornado.websocket
import websockets.sync.client
from pydantic import TypeAdapter
from typing_extensions import ParamSpec
from websockets import ConnectionClosed
from websockets.sync.utils import Deadline

from orangeqs.juice.schemas.task_manager import TaskManagerConfig
from orangeqs.juice.schemas.tasks import TaskServerConfigs
from orangeqs.juice.task import Task, TaskFuture, TaskResult

_P = ParamSpec("_P")
_T = TypeVar("_T")

_logger = logging.getLogger(__name__)


def _generate_task_id() -> str:
    """Generate a unique task ID."""
    return str(uuid4())


class TaskClient:
    """Client to send tasks to be executed over a websocket connection."""

    max_connection_attempts: int
    """Maximum number of connection attempts before giving up."""

    base_connection_delay: float
    """Base delay in seconds for exponential backoff between connection attempts."""

    def __init__(
        self, base_url: str, websocket_kwargs: dict[str, Any] | None = None
    ) -> None:
        """
        Client to send tasks to be executed over a websocket connection.

        Parameters
        ----------
        base_url: str
            Base url for all websocket requests, including `ws://`
        websocket_kwargs : dict (optional)
            Additional kwargs passed to `tornado.websocket.websocket_connect`.
        """
        self.base_url = base_url
        self.websocket_kwargs = websocket_kwargs or {}
        self.connect_attempted: asyncio.Event = asyncio.Event()
        self.connect_result: asyncio.Future[None] = asyncio.Future()
        self.max_connection_attempts = 5
        self.base_connection_delay = 1

        self._pending_tasks: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self._connect_recv_task: asyncio.Task[None] | None = None
        self._client: tornado.websocket.WebSocketClientConnection | None = None
        self._is_closed = False

    async def connect(self) -> None:
        """Wait until connected to the server.

        Will start the connect and receive loop if it has not been started yet.

        Raises
        ------
        RuntimeError
            If the client has been closed and cannot be reused.
        ConnectionError
            If the connection could not be established.
        """
        if self._is_closed:
            raise RuntimeError("This TaskClient has been closed and cannot be reused.")

        if self._connect_recv_task is None:
            self._connect_recv_task = asyncio.create_task(self._connect_recv_loop())

        await self.connect_attempted.wait()
        self.connect_result.result()

    async def _connect(self) -> None:
        """Initiate the websocket connection. For use in the receive loop."""
        attempts = 0
        try:
            _logger.debug("Connecting to task server at %s", self.base_url)
            while True:
                try:
                    self._client = await tornado.websocket.websocket_connect(
                        f"{self.base_url}/tasks",
                        **self.websocket_kwargs,
                    )
                    self.connect_result.set_result(None)
                    break
                except Exception:
                    attempts += 1
                    _logger.debug(
                        "Attempt %d/%d to connect failed",
                        attempts,
                        self.max_connection_attempts,
                    )
                    if attempts >= self.max_connection_attempts:
                        raise
                    delay = self.base_connection_delay * 2 ** (attempts - 1)
                    await asyncio.sleep(delay)
        except Exception as exception:
            self.connect_result.set_exception(exception)
            self._client = None
        except asyncio.CancelledError:
            self.connect_result.set_exception(RuntimeError("Connection cancelled"))
            self._client = None
        finally:
            self.connect_attempted.set()

    async def _connect_recv_loop(self) -> None:
        """Connect and receive messages from the server.

        If the connection drops, all pending tasks are set to an exception and
        the client attempts to reconnect.
        """
        try:
            while True:
                await self._connect()
                if self._client is None:
                    _logger.debug(
                        "Failed to connect, closing task client: %s",
                        self.connect_result.exception(),
                    )
                    # We do not have to report an error as any callers of connect()
                    # will already have received the exception from connect_result.
                    break
                try:
                    while True:
                        msg = await self._client.read_message()
                        if msg is None:
                            raise ConnectionError(
                                "Task client lost connection to service."
                            )
                        try:
                            msg_data = tornado.escape.json_decode(msg)
                            task_id = msg_data.get("id")
                            if task_id not in self._pending_tasks:
                                _logger.warning(
                                    "Received result for unknown task ID: %s", task_id
                                )
                                continue

                            self._pending_tasks[task_id].set_result(msg_data)
                            self._pending_tasks.pop(task_id, None)
                        except Exception:
                            _logger.exception("Failed to handle message: %s", msg)
                except Exception as exception:
                    _logger.warning(
                        "Error in receive loop: %s: %s",
                        type(exception).__name__,
                        exception,
                    )
                    self._set_pending_tasks(exception)
                    # This loop will try to reconnect, so we need a new future.
                    self.connect_result = asyncio.Future()
                    self.connect_attempted.clear()
                except asyncio.CancelledError:
                    _logger.debug("Receive loop cancelled")
                    # We should not propagate the cancellation into the task futures.
                    self._set_pending_tasks(RuntimeError("Receive loop cancelled"))
                    break
                finally:
                    self._client.close()
        finally:
            # Prevent further requests
            self._is_closed = True

    def _set_pending_tasks(self, exception: Exception) -> None:
        """Handle client errors by setting all pending tasks to exception."""
        for future in self._pending_tasks.values():
            if not future.done():
                future.set_exception(exception)
        self._pending_tasks.clear()

    def close(self) -> None:
        """Close the connection to the server.

        This stops the receive loop and prevents further requests.
        """
        if self._connect_recv_task:
            self._connect_recv_task.cancel()
        else:
            # Connect + receive loop was never started, set state manually.
            self._is_closed = True

        # Ensure that we always retrieve the result of connect_result to avoid warnings
        with contextlib.suppress(Exception):
            self.connect_result.result()

    async def wait_closed(self) -> None:
        """Wait until the client is fully closed."""
        if self._connect_recv_task:
            await self._connect_recv_task
            with contextlib.suppress(asyncio.CancelledError):
                await self._connect_recv_task

    def is_closed(self) -> bool:
        """Check if the client has been closed."""
        return self._is_closed

    async def request_raw(
        self,
        task_id: str,
        message: str | bytes,
    ) -> TaskFuture[dict[str, Any]]:
        """Request a task to be executed from raw data.

        As this function returns, it means the request has been sent to the server,
        but the task may not have been executed yet. Use the returned future to wait
        for the task result.

        Parameters
        ----------
        task_id : str
            The ID of the task to send.
        message : str | bytes
            The raw message representing the task to send.

        Returns
        -------
        TaskFuture
            A future that will resolve to the task result.
        """
        await self.connect()
        result: asyncio.Future[Any] = TaskFuture[dict[str, Any]](task_id)
        self._pending_tasks[task_id] = result

        assert self._client is not None, "Client should be connected"
        await self._client.write_message(message)
        return result

    async def request(self, target: str, task: Task) -> TaskFuture[dict[str, Any]]:
        """Request a task to be executed.

        As this function returns, it means the request has been sent to the server,
        but the task may not have been executed yet. Use the returned future to wait
        for the task result.

        Parameters
        ----------
        target : str
            The target service to execute the task on.
        task : Task
            The task to execute.

        Returns
        -------
        TaskFuture
            A future that will resolve to the task result.
        """
        return await self.request_raw(*_serialize_task(target, task))

    async def execute(self, target: str, task: Task) -> dict[str, Any]:
        """Execute a task and wait for the result.

        This is equivalent to calling `await (await client.request(...))`.

        Parameters
        ----------
        target : str
            The target service to execute the task on.
        task : Task
            The task to execute.

        Returns
        -------
        dict
            The result of the task.
        """
        request = await self.request(target, task)
        return await request


class TaskClientBlocking:
    max_connection_attempts: int
    """Maximum number of connection attempts before giving up."""

    connection_timeout: float
    """Maximum time in seconds to wait for each connection attempt."""

    base_connection_delay: float
    """Base delay in seconds for exponential backoff between connection attempts."""

    def __init__(
        self, base_url: str, websocket_kwargs: dict[str, Any] | None = None
    ) -> None:
        """
        Client to send tasks to be executed over a websocket connection.

        Parameters
        ----------
        base_url: str
            Base url for all websocket requests, including `ws://`
        websocket_kwargs : dict (optional)
            Additional kwargs passed to `websockets.sync.client.connect`.
        """
        self.base_url = base_url
        self.websocket_kwargs = websocket_kwargs or {}
        self.max_connection_attempts = 5
        self.base_connection_delay = 1
        self.connection_timeout = 10

        self._client: websockets.sync.client.ClientConnection | None = None
        self._is_closed = False
        self._pending_tasks: set[str] = set()

    def connect(self) -> None:
        """Wait until connected to the server.

        Attempts to connect multiple times with exponential backoff.
        Tries for `max_connection_attempts` times before giving up.

        Raises
        ------
        RuntimeError
            If the client has been closed and cannot be reused.
        ConnectionError
            If the connection could not be established.
        """
        if self.is_closed():
            raise RuntimeError("This TaskClient has been closed and cannot be reused.")

        self._connect()

    def _connect(
        self, max_attempts: int | None = None, timeout: float | None = None
    ) -> websockets.sync.client.ClientConnection:
        """Initiate the websocket connection and set `_client`."""
        deadline = Deadline(timeout)
        delay = self.base_connection_delay
        if max_attempts is None:
            max_attempts = self.max_connection_attempts

        for attempt in range(max_attempts):
            try:
                timeout = deadline.timeout()
                # Always cap each individual connect timeout to detect if no connection
                # can be made within a reasonable time limit.
                if timeout is None or timeout > self.connection_timeout:
                    timeout = self.connection_timeout
                _client = websockets.sync.client.connect(
                    f"{self.base_url}/tasks",
                    open_timeout=timeout,
                    **self.websocket_kwargs,
                )
            except (OSError, TimeoutError) as e:
                remaining_time = deadline.timeout(raise_if_elapsed=False)
                timeout_expired = remaining_time is not None and remaining_time <= 0
                if timeout_expired:
                    raise
                if attempt == max_attempts - 1:
                    self.close()
                    raise ConnectionError(
                        f"Could not connect to task server at {self.base_url}: {e}"
                    ) from e

                # Never sleep longer than the remaining timeout
                if remaining_time is not None and remaining_time < delay:
                    delay = remaining_time

                _logger.debug("Connection failed, retrying in %.1f seconds...", delay)
                time.sleep(delay)
                delay *= 2
            else:
                # New connection, so will not receive previously pending tasks anymore.
                self._pending_tasks.clear()
                self._client = _client
                return _client
        assert False, "Unreachable"

    def is_closed(self) -> bool:
        """Check if the client has been closed."""
        return self._is_closed

    def close(self) -> None:
        """Close the connection to the server.

        This prevents further requests. This can be called multiple times.
        """
        if self._client is not None:
            self._client.close()
        self._is_closed = True

    def _send(
        self,
        message: str,
        timeout: float | None = None,
    ) -> None:
        """Send data over the websocket connection.

        Handles reconnecting if the connection is lost.

        Parameters
        ----------
        message : str
            The raw data to send.
        timeout : float | None
            Optional timeout in seconds for the connect.
        """
        if self._client is None:
            client = self._connect(timeout=timeout)
            client.send(message)
        else:
            try:
                self._client.send(message)
            except ConnectionClosed:
                client = self._connect(timeout=timeout)
                client.send(message)

    def _request(self, target: str, task: Task, timeout: float | None = None) -> str:
        """Request a task to be executed.

        As this function returns, it means the request has been sent to the server,
        but the task may not have been executed yet.
        Use the task ID to track the result.

        Parameters
        ----------
        target : str
            The target service to execute the task on.
        task : Task
            The task to execute.
        timeout : float | None
            Optional timeout in seconds for sending the task.

        Returns
        -------
        str
            The ID of the requested task.
        """
        task_id, message = _serialize_task(target, task)
        self._send(message, timeout=timeout)
        self._pending_tasks.add(task_id)
        return task_id

    def execute(self, target: str, task: Task, timeout: float | None = None) -> Any:  # noqa: ANN401
        """Execute a task and wait for the result.

        This is equivalent to calling `await (await client.request(...))`.

        Parameters
        ----------
        target : str
            The target service to execute the task on.
        task : Task
            The task to execute.
        timeout : float | None
            Optional timeout for sending the task and receiving the result.

        Returns
        -------
        dict
            The result of the task.
        """
        deadline = Deadline(timeout)
        request_id = self._request(target, task, timeout=timeout)
        assert self._client is not None
        while True:
            try:
                raw_data = self._client.recv(decode=True, timeout=deadline.timeout())
            except ConnectionClosed as e:
                self.close()
                raise ConnectionError(
                    "Task client lost connection while waiting for task result."
                ) from e
            result = tornado.escape.json_decode(raw_data)
            if "id" not in result:
                warnings.warn("Received result without task ID, ignoring.")
            if result["id"] not in self._pending_tasks:
                warnings.warn(
                    f"Received result for unknown task ID: {result['id']!r}, ignoring."
                )
                continue
            self._pending_tasks.remove(result["id"])
            if result["id"] != request_id:
                # This was a task that previously timed out, ignore it.
                continue
            return result


def _serialize_task(target: str, task: Task) -> tuple[str, str]:
    """Serialize a task for sending over the websocket.

    Parameters
    ----------
    target : str
        The target service to execute the task on.
    task : Task
        The task to serialize.

    Returns
    -------
    str
        The generated task ID.
    str
        The serialized task data.
    """
    request_id = _generate_task_id()

    task_data = {
        "id": request_id,
        "target": target,
        "type": task.type(),
        "metadata": {
            "parallel": task.parallel,
            "display_name": task.display_name,
        },
        "payload": task.model_dump(exclude={"parallel", "display_name"}),
    }
    return request_id, tornado.escape.json_encode(task_data)


TaskClientClass = TypeVar("TaskClientClass", bound=TaskClient | TaskClientBlocking)


class TaskClientProvider(Generic[TaskClientClass]):
    """Mixin providing a registry of task clients."""

    def __init__(
        self,
        task_server_config: TaskServerConfigs,
        task_manager_config: TaskManagerConfig,
        client_class: type[TaskClientClass],
    ) -> None:
        """Initialize the TaskClientProvider.

        Parameters
        ----------
        task_server_config : TaskServerConfigs
            Configurations for the task servers of OrangeQS Juice services.
        task_manager_config : TaskManagerConfig
            Configuration for the task manager, including network settings.
        client_class : type[TaskClientClass]
            The class of the task client to create.
        """
        self._task_server_configs = task_server_config
        self._task_manager_config = task_manager_config
        self._task_clients: dict[str, TaskClientClass] = {}
        self._client_class = client_class

    def client_host_port_for(self, target: str) -> str:
        """Retrieve the host and port for the given target."""
        config = self._task_server_configs.for_service(target)
        return f"{config.ip}:{config.port}"

    def client_factory(self, target: str) -> TaskClientClass:
        """Create a new TaskClient for the given target."""
        return self._client_class(
            f"ws://{self.client_host_port_for(target)}",
            websocket_kwargs=self._websocket_kwargs(),
        )

    def client_for_target(self, target: str) -> TaskClientClass:
        """Get a cached client or create a new one for the given target.

        Automatically cleans up closed clients.
        """
        # Clean up closed clients
        if target in self._task_clients and self._task_clients[target].is_closed():
            del self._task_clients[target]

        if target not in self._task_clients:
            self._task_clients[target] = self.client_factory(target)

        return self._task_clients[target]

    def _websocket_kwargs(self) -> dict[str, Any]:
        """Get websocket kwargs based on the client class.

        Returns
        -------
        dict[str, Any]
            The websocket keyword arguments that are compatible with the underlying
            websocket library.
        """
        config = self._task_manager_config
        if self._client_class is TaskClient:
            # Uses tornado.websocket
            return {
                "ping_interval": config.websocket_ping_interval,
                "ping_timeout": config.websocket_ping_timeout,
                "max_message_size": config.websocket_max_message_size,
            }
        elif self._client_class is TaskClientBlocking:
            # Uses websockets.sync
            return {
                "ping_interval": config.websocket_ping_interval,
                "ping_timeout": config.websocket_ping_timeout,
                "max_size": config.websocket_max_message_size,
            }
        else:
            raise TypeError(f"Unknown client class: {self._client_class}")


task_result_adapter = TypeAdapter[TaskResult](TaskResult)
