"""Management of entry points defined by extensions for the Juice client."""

import inspect
import logging
from collections.abc import Callable
from importlib.metadata import EntryPoint, entry_points
from typing import Concatenate, ParamSpec, TypeVar, cast

_logger = logging.getLogger(__name__)


def collect_entry_points(group: str) -> dict[str, EntryPoint]:
    """Collect all entry points in the specified group.

    Currently, we support entrypoints for Juice Client and Dashboard.

    Parameters
    ----------
    group : str
        The entry point group name.

    Returns
    -------
    dict
        A mapping of method names to entrypoint objects.
        These are the methods that should be injected into the Juice client.

    Raises
    ------
    RuntimeError
        If multiple entry points define the same method name.
    """
    _logger.debug(f"Collecting entry points from {group} group")

    # Load all entry points defined by extensions for the Juice client
    eps = entry_points(group=group)

    result: dict[str, EntryPoint] = {}
    for ep in eps:
        method_name = ep.name
        if method_name in result:
            raise RuntimeError(
                f"Method '{ep.name}' defined in multiple entry points. "
                f"Entrypoint '{ep}' conflicts with existing '{result[method_name]}'."
                "Method names should be unique."
            )
        result[method_name] = ep

    return result


_T = TypeVar("_T")
_P = ParamSpec("_P")
_R = TypeVar("_R")


def wrap_function_as_method(
    object_type: type[_T],
    object_instance: _T,
    # The method is passed as the last arguments to stop the type checker
    # from making premature assumptions about the type of _T.
    method: Callable[_P, _R] | Callable[Concatenate[_T, _P], _R],
) -> Callable[_P, _R]:
    """Possibly wrap a function to make it a method of an object.

    If the function is determined to be a method, it is wrapped to take
    the client instance as the first parameter.
    Uses a simple heuristic to determine if the function is a client method:
    - If the first parameter has type annotations, check if it is the object type.
    - Otherwise, check if the first parameter is named 'client'.

    The function that is returned can be set on `object_instance`
    using {meth}`setattr` and will behave as a method of that instance.

    Parameters
    ----------
    object_type : type
        The type of the object instance to check type annotations against.
    object_instance : instance of `object_type`
        The instance of the object to which the method will be bound.
    method : callable
        The function to possibly wrap.

    Returns
    -------
    callable
        The wrapped method that can be set using {meth}`setattr` on `object_instance`.
    """
    sig = inspect.signature(method)
    params = list(sig.parameters.values())

    if params and (
        (params[0].annotation and params[0].annotation == object_type)
        or (params[0].name == "client")
    ):
        # The method has the object instance as the first parameter.
        method = cast("Callable[Concatenate[_T, _P], _R]", method)

        def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _R:  # noqa: ANN401
            return method(object_instance, *args, **kwargs)

        wrapper.__doc__ = method.__doc__
        return wrapper

    # The method does not have the object instance as the first parameter,
    method = cast("Callable[_P, _R]", method)
    return method
