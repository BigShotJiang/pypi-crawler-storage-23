import http.client
import socket
import xmlrpc.client
from typing import Any


class UnixStreamHTTPConnection(http.client.HTTPConnection):
    def connect(self) -> None:
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(self.host)


class UnixStreamTransport(xmlrpc.client.Transport):
    def __init__(self, socket_path: str) -> None:
        self.socket_path = socket_path
        super().__init__()

    def make_connection(
        self, host: tuple[str, dict[str, str]] | str
    ) -> http.client.HTTPConnection:
        return UnixStreamHTTPConnection(self.socket_path)


class UnixStreamXMLRPCClient(xmlrpc.client.ServerProxy):
    def __init__(self, addr: str, **kwargs: Any) -> None:  # noqa: ANN401
        transport = UnixStreamTransport(addr)
        super().__init__("http://", transport=transport, **kwargs)
