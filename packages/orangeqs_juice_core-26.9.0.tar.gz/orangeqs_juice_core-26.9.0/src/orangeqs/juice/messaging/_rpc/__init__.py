"""RPC implementation over unix domain sockets.

Built on top of the standard `xmlrpc` library.
Based on https://gist.github.com/grantjenks/095de18c51fa8f118b68be80a624c45a.
"""

from ._client import UnixStreamXMLRPCClient
from ._server import UnixStreamXMLRPCServer

__all__ = [
    "UnixStreamXMLRPCClient",
    "UnixStreamXMLRPCServer",
]
