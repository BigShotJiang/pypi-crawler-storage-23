"""Management of the environments of the OrangeQS Juice installation."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime
from pathlib import Path

import tomli_w

from orangeqs.juice.orchestration._constants import SINGLEUSER_ENVIRONMENT_NAME
from orangeqs.juice.orchestration.settings import (
    BUNDLED_WHEEL_PATH,
    BuildSettings,
    ContainerFolderSettings,
    DataFolderSettings,
    EnvironmentSettings,
    OrchestrationSettings,
    UvEnvironmentSettings,
    UvSourcesType,
)
from orangeqs.juice.orchestration.sources import juice_cli_path
from orangeqs.juice.orchestration.template import load_template
from orangeqs.juice.settings import SHARED_RUNTIME_PATH, SYSTEM_CONFIG_PATH


def _common_mounts(settings: ContainerFolderSettings) -> list[str]:
    """Return the mounts common to all environments."""
    return [
        f"{SYSTEM_CONFIG_PATH}:{SYSTEM_CONFIG_PATH}:ro",
        f"{SHARED_RUNTIME_PATH}:{SHARED_RUNTIME_PATH}:rw",
        f"/var/lib/juice/user/shared:{settings.shared_path}",
    ]


def _editable_path_target(path: Path, settings: UvEnvironmentSettings) -> Path:
    """Map an editable path to a target path inside the container.

    Paths starting with `~` are expanded to the user home path inside the container.
    Absolute paths are mapped to `<shared_lib_path>/<path.name>`.
    Other relative paths are not allowed and will raise an error.
    """
    if str(path).startswith("~"):
        # We cannot use `.expanduser()` as it would be the use host home path.
        return Path(str(path).replace("~", settings.home_path))
    if not path.is_absolute():
        raise ValueError(f"Path {path} is not absolute.")
    return Path(settings.shared_lib_path) / path.name


def _uv_editable_source_path(item: dict[str, str | bool]) -> Path | None:
    """Return the source path if the source is editable."""
    if "editable" not in item or not item["editable"]:
        return None
    if "path" not in item:
        raise ValueError("Editable source must have a 'path' key.")
    if not isinstance(item["path"], str):
        raise ValueError("Editable source 'path' must be a string.")
    if item["path"].startswith("~"):
        return Path(item["path"])
    if not (path := Path(item["path"])).is_absolute():
        raise ValueError(f"Path {path} is not absolute.")
    return path


def _uv_editable_mounts(settings: UvEnvironmentSettings) -> list[str]:
    """Return a list of mounts for all editable sources in this environment.

    This maps absolute paths of editable sources (from the context of the host)
    to their target paths (from the context of the container).
    By default this is `~/shared/lib`.
    """
    volumes: list[str] = []
    # Add all editable sources from different locations
    for source in settings.sources.values():
        if isinstance(source, dict):
            source = [source]
        for item in source:
            if not (path := _uv_editable_source_path(item)):
                continue
            if str(path).startswith("~"):
                # If the path starts with `~` we assume it is relative to the user
                # home directory inside the container, hence no need to mount it.
                continue
            target_path = _editable_path_target(path, settings)
            # We mount all editable mounts with write permissions, such that
            # users can develop packages from within their user container.
            mount = f"{str(path)}:{str(target_path)}"
            volumes.append(mount)
    return volumes


def _uv_dist_mounts(
    name: str, settings: UvEnvironmentSettings, env_folder: Path
) -> list[str]:
    """Return the mounts for wheels of Python packages.

    This includes the OrangeQS Juice wheel and the distribution folder.
    It only mounts the Juice wheel if it exists on the host system,
    as Juice might be installed in editable mode.
    """
    mounts: list[str] = [
        # TODO: Use real data folder settings
        "/var/lib/juice/dist:/dist:ro",
    ]
    if Path(BUNDLED_WHEEL_PATH).exists():
        mounts.append(f"{BUNDLED_WHEEL_PATH}:{BUNDLED_WHEEL_PATH}:ro")

    return mounts


def _uv_build_environment_mounts(
    name: str, settings: UvEnvironmentSettings, env_folder: Path
) -> list[str]:
    """Return a list of mount paths required for the `uv` build environment."""
    return [
        *_uv_dist_mounts(name, settings, env_folder),
        *_uv_editable_mounts(settings),
    ]


def _uv_runtime_mounts(
    name: str, settings: UvEnvironmentSettings, env_folder: Path
) -> list[str]:
    """Return a list of mount paths required for the `uv` runtime environment."""
    return [
        # The uv environment syncs all packages at runtime, so we need access to the
        # wheels in the dist folder.
        # TODO: Instead of mounting the dist folder, we should copy the wheels over
        #       during the build phase, such that we do not need to mount the dist
        #       folder at runtime. That way the environment is also frozen at runtime.
        *_uv_dist_mounts(name, settings, env_folder),
        *_uv_editable_mounts(settings),
    ]


def _uv_sources_in_container(settings: UvEnvironmentSettings) -> UvSourcesType:
    """Return the sources for the `uv` environment for inside the container.

    This maps editable source paths on the host to the paths inside the container.
    Paths starting with `~` are expanded to the user home path inside the container.
    Absolute paths are mapped to `<shared_lib_path>/<path.name>`.
    """
    sources = deepcopy(settings.sources)
    for source_name, source in sources.items():
        if not isinstance(source, list):
            source = [source]
            sources[source_name] = source
        for item in source:
            if (path := _uv_editable_source_path(item)) is None:
                continue
            item["path"] = str(_editable_path_target(path, settings))
    return sources


def runtime_environment_mounts(
    name: str,
    settings: EnvironmentSettings,
    env_folder: Path,
) -> list[str]:
    """Return the mounts required at runtime for a given environment.

    For now this only includes mounts for editable sources.

    Parameters
    ----------
    name : str
        The name of the environment.
    settings : EnvironmentSettings
        The settings for the environment.
    env_folder : Path
        The folder where environment data is stored.

    Returns
    -------
    list[str]
        A list of mount paths required for the environment at runtime.
        The format is docker/podman compatible, meaning
        that it can be used directly in the `-v` or `--mount` flag
    """
    common_mounts = _common_mounts(settings)
    if settings.type == "uv":
        return common_mounts + _uv_runtime_mounts(name, settings, env_folder)


def _uv_build_settings(
    name: str,
    settings: UvEnvironmentSettings,
    env_folder: Path,
) -> BuildSettings:
    """Return the build environment settings for a `uv` environment."""
    return BuildSettings(
        name=name,
        workdir=str(env_folder / name),
        volumes=_uv_build_environment_mounts(name, settings, env_folder)
        + _common_mounts(settings),
    )


def build_settings(
    name: str,
    settings: EnvironmentSettings,
    data_folder: DataFolderSettings,
) -> BuildSettings:
    """Return the build environment settings for a given environment."""
    # Environment specific settings
    if settings.type == "uv":
        build_settings = _uv_build_settings(name, settings, Path(data_folder.env_data))
    else:
        raise ValueError(f"Unsupported environment type: {settings.type}")

    # Common settings
    build_settings.build_args = {
        "USER_UID": str(data_folder.user_id),
        "USER_GID": str(data_folder.group_id),
    }
    build_settings.systemd.service.exec_start_pre.append(
        f"{juice_cli_path()} hook start-pre environment-{name}"
    )
    build_settings.systemd.service.exec_stop_post.append("podman image prune -f")
    build_settings.update(settings.container)

    return build_settings


def _uv_write_pyproject(
    name: str, settings: UvEnvironmentSettings, env_folder: Path
) -> Path:
    """Write the dependencies to a pyproject file for a `uv` environment."""
    pyproject_file = env_folder / name / "pyproject.toml"
    pyproject_file.parent.mkdir(parents=True, exist_ok=True)
    pyproject_content = {
        "project": {
            "version": "0.0.0",
            "name": f"juice-env-{name}",
            "dependencies": settings.dependencies,
            "requires-python": f"=={settings.python_version}.*",
        },
        "tool": {
            "uv": {
                "sources": _uv_sources_in_container(settings),
            }
        },
    }
    with pyproject_file.open("wb") as f:
        # Write a header with timestamp to invalidate the podman build cache.
        f.write(b"# This file was generated by OrangeQS Juice\n")
        f.write(f"# Generated at {datetime.now().isoformat()}\n".encode())
        f.write(b"\n")
        tomli_w.dump(pyproject_content, f)
    return pyproject_file


def _uv_write_containerfile(
    name: str, settings: UvEnvironmentSettings, env_folder: Path
) -> Path:
    """Write the Containerfile for building a `uv` environment."""
    template = load_template("environment.Containerfile.j2")
    dockerfile_path = env_folder / name / "Containerfile"
    dockerfile_path.parent.mkdir(parents=True, exist_ok=True)
    is_singleuser = name == SINGLEUSER_ENVIRONMENT_NAME
    with dockerfile_path.open("w") as f:
        f.write(
            template.render(
                settings.model_dump(exclude_none=True), is_singleuser=is_singleuser
            )
        )
    return dockerfile_path


def render_environment(
    name: str, settings: EnvironmentSettings, env_folder: Path
) -> list[Path]:
    """Render the files that define an environment to its own environment folder.

    It writes the files to a separate folder for each environment.
    For a `uv` environment the files are `pyproject.toml` and `Containerfile`.

    Parameters
    ----------
    name : str
        The name of the environment.
    settings : EnvironmentSettings
        The settings for the environment.
    env_folder : Path
        The folder where environment data is stored for all environments.

    Returns
    -------
    list[Path]
        A list of paths to the rendered files for the environment.
    """
    if settings.type == "uv":
        return [
            _uv_write_pyproject(name, settings, env_folder),
            _uv_write_containerfile(name, settings, env_folder),
        ]


def list_environments(
    orchestration_settings: OrchestrationSettings,
) -> dict[str, EnvironmentSettings]:
    """Return a list of all environment names defined in the orchestration settings.

    This includes environments for each service and the singleuser environment.

    Parameters
    ----------
    orchestration_settings : OrchestrationSettings
        The orchestration settings containing the environments to list.

    Returns
    -------
    dict[str, EnvironmentSettings]
        A dictionary where the keys are environment names and the values are
        the corresponding environment settings.
    """
    return {
        service_name: service.environment
        for service_name, service in orchestration_settings.services.items()
    } | {
        SINGLEUSER_ENVIRONMENT_NAME: (
            orchestration_settings.jupyterhub.singleuser.environment
        ),
    }


def render_environments(
    orchestration_settings: OrchestrationSettings,
) -> dict[str, list[Path]]:
    """Render all environments defined in the orchestration settings.

    It writes the files to a separate folder for each environment.
    These files can subsequently be used to build each environment.
    Consists of one environment per service and the singleuser environment.

    Parameters
    ----------
    orchestration_settings : OrchestrationSettings
        The orchestration settings containing the environments to render.

    Returns
    -------
    dict[str, list[Path]]
        A dictionary where the keys are environment names and the values are lists of
        paths to the rendered files for each environment.
    """
    env_folder = Path(orchestration_settings.data_folder.env_data)
    return {
        name: render_environment(name, settings, env_folder)
        for name, settings in list_environments(orchestration_settings).items()
    }
