"""Utilities for collecting service information."""

from pathlib import Path

from orangeqs.juice.orchestration import environment
from orangeqs.juice.orchestration.settings import (
    BuildSettings,
    ContainerSettings,
    EnvironmentSettings,
    OrchestrationSettings,
    ServiceSettings,
)
from orangeqs.juice.orchestration.sources import juice_cli_path
from orangeqs.juice.orchestration.template import load_template

_ORCHESTRATOR_SERVICE_TEMPLATE = "orchestrator.service.j2"


def system_services_from_settings(
    settings: OrchestrationSettings,
) -> tuple[list[ContainerSettings], list[BuildSettings]]:
    """Return a list of containers and build services based on the settings.

    This functions collects all containers (and image builds) required for the full
    OrangeQS Juice installation based on the provided settings.

    This includes:
    - Containers for each OrangeQS Juice service defined in `services`.
    - Build services for each environment defined in the `services.<key>.environment`.
    - (TODO) Containers for system services like the database, JupyterHub, etc.

    """
    env_folder = Path(settings.data_folder.env_data)

    def _container_from_service(
        name: str, service: ServiceSettings
    ) -> ContainerSettings:
        """Container settings for a given OrangeQS Juice service."""
        supervisord_config_mount = (
            str(Path(settings.data_folder.service_data) / name / "supervisord.conf")
            + ":/etc/supervisord.conf:ro"
        )

        container_settings = ContainerSettings(
            name=name,
            image=f"juice-{name}",
            environment={
                "JUICE_IDENTITY": f"service-{name}",
            },
            command="supervisord",
            volumes=environment.runtime_environment_mounts(
                name,
                service.environment,
                env_folder,
            )
            + [supervisord_config_mount],
        )
        # Apply systemd settings separately to not override the default!
        # We use `After` to wait for the build to finish if it's
        # already in progress, but do not trigger a build automatically.
        container_settings.systemd.unit.after = [f"juice-{name}-build.service"]
        container_settings.systemd.service.exec_start_pre = [
            f"{juice_cli_path()} hook start-pre service-{name}"
        ]

        # Update with any additional container settings from the environment definition.
        container_settings.update(service.environment.container)
        return container_settings

    def _build_from_environment(
        name: str, env_settings: EnvironmentSettings
    ) -> BuildSettings:
        """Build settings for a given environment."""
        build_settings = environment.build_settings(
            name,
            env_settings,
            settings.data_folder,
        )
        return build_settings

    return [
        _container_from_service(name, service)
        for name, service in settings.services.items()
    ], [
        _build_from_environment(name, env_settings)
        for name, env_settings in environment.list_environments(settings).items()
    ]


def render_supervisor_configurations(config: OrchestrationSettings) -> None:
    """Render the supervisord configuration for the services."""
    jinja_template = load_template("service_supervisor/supervisord.conf.j2")
    template_name = jinja_template.filename  # Load full path to template file
    if not template_name:
        raise ValueError("Template file name is not set. Cannot copy.")

    base_folder = Path(config.data_folder.service_data)
    current_services: list[str] = list(config.services.keys())

    for service in current_services:
        output_folder = base_folder / service
        output_folder.mkdir(exist_ok=True)
        variables = {"service_name": service}
        rendered_content = jinja_template.render(**variables)
        output_file = output_folder / "supervisord.conf"
        output_file.write_text(rendered_content)


def render_orchestrator_service() -> str:
    """Render the orchestrator systemd service file.

    This is a systemd service that exposes RPC methods for orchestrating
    Juice services.

    Returns
    -------
    str
        The name of the rendered service file without extension.
    """
    from orangeqs.juice.orchestration.sources import juice_cli_path

    variables = {
        "juice_cli_path": juice_cli_path(),
    }

    destination_folder = Path("/etc/systemd/system")
    output_file = destination_folder / "juice-orchestrator.service"
    template = load_template(_ORCHESTRATOR_SERVICE_TEMPLATE)

    rendered_content = template.render(**variables)
    output_file.write_text(rendered_content)
    return output_file.stem
