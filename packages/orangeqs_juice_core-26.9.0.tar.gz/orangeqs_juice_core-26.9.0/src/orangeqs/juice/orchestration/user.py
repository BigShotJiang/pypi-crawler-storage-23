"""Ensure the OrangeQS Juice system user and group exist."""

import subprocess
from pathlib import Path

import tomli_w

from orangeqs.juice.orchestration.settings import (
    DataFolderSettings,
    OrchestrationSettings,
)
from orangeqs.juice.settings import SYSTEM_CONFIG_PATH

_JUICE_DATA_USERNAME = "juice-data"
_JUICE_DATA_GROUPNAME = "juice-data"
_CONFIG_FILENAME = "juice_data_user.toml"


def _user_id(username: str) -> int | None:
    """Get the user ID for a given username.

    Parameters
    ----------
    username : str
        The username to look up.

    Returns
    -------
    int | None
        The user ID, or None if the user does not exist.
    """
    import pwd

    try:
        return pwd.getpwnam(username).pw_uid
    except KeyError:
        return None


def _group_id(groupname: str) -> int | None:
    """Get the group ID for a given group name.

    Parameters
    ----------
    groupname : str
        The group name to look up.

    Returns
    -------
    int | None
        The group ID, or None if the group does not exist.
    """
    import grp

    try:
        return grp.getgrnam(groupname).gr_gid
    except KeyError:
        return None


def _user_group_id(username: str) -> int | None:
    """Get the group ID for a given username.

    Parameters
    ----------
    username : str
        The username to look up.

    Returns
    -------
    int | None
        The group ID, or None if the user does not exist.
    """
    import pwd

    try:
        return pwd.getpwnam(username).pw_gid
    except KeyError:
        return None


def ensure_juice_user_and_group(settings: DataFolderSettings) -> bool:
    """Ensure the 'juice-data' user and group are correctly configured.

    If the uid and gid are not set in the settings, this function will create
    the 'juice-data' user and group if they do not exist, and update the settings
    with the correct uid and gid.

    Parameters
    ----------
    settings : DataFolderSettings
        The data folder settings.

    Returns
    -------
    bool
        True if any changes were made, False otherwise.
        Changes include creating the user/group or writing updated settings to disk.
    """
    # Check whether the uid or gid is already configured
    user_id_configured = "user_id" in settings.model_dump(
        include={"user_id"}, exclude_unset=True
    )
    group_id_configured = "group_id" in settings.model_dump(
        include={"group_id"}, exclude_unset=True
    )

    if user_id_configured and group_id_configured:
        # Nothing to do
        return False

    if user_id_configured != group_id_configured:
        raise ValueError(
            "Both user_id and group_id must be configured together, or neither."
        )

    # Create the group if it does not exist
    group_id = _group_id(_JUICE_DATA_GROUPNAME)
    if not group_id:
        subprocess.run(
            ["groupadd", _JUICE_DATA_GROUPNAME],
            check=True,
        )
        group_id = _group_id(_JUICE_DATA_GROUPNAME)
        assert group_id is not None, f"Failed to create {_JUICE_DATA_GROUPNAME} group."

    # Create the user if it does not exist
    user_id = _user_id(_JUICE_DATA_USERNAME)
    if not user_id:
        subprocess.run(
            [
                "useradd",
                "--no-create-home",
                "-g",
                f"{group_id}",
                _JUICE_DATA_USERNAME,
            ],
            check=True,
        )
        user_id = _user_id(_JUICE_DATA_USERNAME)
        assert user_id is not None, f"Failed to create {_JUICE_DATA_USERNAME} user."

    # Assert the user has the correct primary group
    assert group_id == _user_group_id(_JUICE_DATA_USERNAME), (
        f"User {_JUICE_DATA_USERNAME} exists, "
        f"but its primary group is not {_JUICE_DATA_GROUPNAME}. "
        "Please fix this manually."
    )

    # Write the uid and gid to disk
    settings_to_write = {
        "data_folder": DataFolderSettings(
            user_id=user_id,
            group_id=group_id,
        ).model_dump(exclude_unset=True)
    }
    output_path = (
        Path(SYSTEM_CONFIG_PATH)
        / f"{OrchestrationSettings.filename}.d"
        / _CONFIG_FILENAME
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as f:
        tomli_w.dump(settings_to_write, f)

    return True
