"""Configuration fort the OrangeQS Juice orchestrator."""

from __future__ import annotations

import os
from abc import ABCMeta
from copy import deepcopy
from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any, ClassVar, Literal, Union

from pydantic import ConfigDict, Field, computed_field, model_validator

from orangeqs import juice
from orangeqs.juice.orchestration._constants import SINGLEUSER_ENVIRONMENT_NAME
from orangeqs.juice.orchestration.sources import juice_cli_path
from orangeqs.juice.settings import BaseConfigurable, Configurable

if TYPE_CHECKING:
    import sys

    if sys.version_info >= (3, 11):
        from typing import Self
    else:
        from typing_extensions import Self


BUNDLED_WHEEL_PATH = (
    f"/opt/orangeqs/juice/dist/orangeqs_juice_core-{juice.__version__}-py3-none-any.whl"
)
"""
Path to the bundled wheel file of the OrangeQS Juice package as part of the system
package. Note that this file does not necessarily exist, for example in development
installations.
"""


class DataFolderSettings(BaseConfigurable):
    """Settings for data folder locations on the host system."""

    model_config = ConfigDict(use_attribute_docstrings=True)

    env_data: str = "/var/lib/juice/env"
    """Folder with environment definitions created from the settings."""
    service_data: str = "/var/lib/juice/service"
    """Service specific data files."""
    dist_data: str = "/var/lib/juice/dist"
    """Folder containing wheels for Python packages."""
    lib_data: str = "/var/lib/juice/lib"
    """Folder containing source code for Python packages for editable installs.
    """

    user_data: str = "/var/lib/juice/user"
    """Folder containing the home directories of all users.

    The home directories are stored in `./{username}` subfolders.
    """
    user_data_shared: str = "/var/lib/juice/user/shared"
    """Folder containing shared data for all users.

    This is mounted as `~/shared` in the container by default.
    """

    shared_runtime_data: str = "/var/run/juice"
    """Shared runtime data folder.

    This is where shared runtime data is stored, such as service info and kernel specs.
    Even though this folder contains service-specific secrets, for now this folder
    is shared with all users and OrangeQS Juice services.

    This is mounted as `/var/run/juice` in the container by default.
    """

    # TODO: For now we assume all user IDs in containers are 1000
    user_id: int = 1000
    """The user ID to set as the owner of user data folders.

    This should correspond to the `juice-data` user on the host system.
    This setting is set automatically on installation.
    """

    group_id: int = 1000
    """The group ID to set as the owner of user data folders.

    This should correspond to the `juice-data` group on the host system.
    This setting is set automatically on installation.
    """


class ContainerFolderSettings(BaseConfigurable):
    """Settings for the target mount locations of standard folders."""

    home_path: str = "/home/user"
    """The mount path of the home directory in the container."""
    shared_path: str = "~/shared"
    """The mount path of the shared data folder in the container."""
    shared_lib_path: str = "~/shared/lib"
    """The mount path of the shared lib folder in the container."""

    @model_validator(mode="after")
    def _resolve_paths(self) -> Self:
        """Resolve paths for the container folders."""
        self.shared_path = self.shared_path.replace("~", self.home_path)
        self.shared_lib_path = self.shared_lib_path.replace("~", self.home_path)
        return self


class PodmanSettings(BaseConfigurable):
    """Settings for Podman containerization."""

    container_folder: str = "/etc/containers/systemd"


class ContainerizationSettings(BaseConfigurable):
    """Settings for containerization."""

    network_name: str = "juice"
    container_type: Literal["podman"] = "podman"
    container_prefix: str = "juice-"
    build_prefix: str = "juice-"

    # Container type specific settings
    podman: PodmanSettings = Field(default_factory=PodmanSettings)


class PortMapping(BaseConfigurable):
    """Port Forwarding configuration for a container."""

    host_port: int | None
    container_port: int | None


class SystemdUnitSettings(BaseConfigurable):
    """Settings for the [Unit] section of the systemd service of a container.

    Each field corresponds to an option in the `[Unit]` section of a systemd service.
    See https://www.freedesktop.org/software/systemd/man/latest/systemd.unit.html#%5BUnit%5D%20Section%20Options
    for more info.
    """

    after: list[str] = Field(default_factory=list)
    requires: list[str] = Field(default_factory=list)
    wants: list[str] = Field(default_factory=list)


class SystemdServiceSettings(BaseConfigurable):
    """Settings for the [Service] section of the systemd service of a container.

    Each field corresponds to an option in the `[Service]` section of a systemd service.
    See https://www.freedesktop.org/software/systemd/man/latest/systemd.service.html#Options
    for more info.
    """

    restart: Literal[
        "no",
        "on-success",
        "on-failure",
        "on-abnormal",
        "on-watchdog",
        "on-abort",
        "always",
        None,
    ] = None
    restart_steps: int | None = None
    restart_sec: int | None = None
    timeout_start_sec: int | None = None
    restart_max_delay_sec: int | None = None

    exec_start_pre: list[str] = Field(default_factory=list)
    exec_start_post: list[str] = Field(default_factory=list)
    exec_stop_post: list[str] = Field(default_factory=list)


class SystemdSettings(BaseConfigurable):
    """Settings for the systemd service of a container."""

    unit: SystemdUnitSettings = Field(default_factory=SystemdUnitSettings)
    service: SystemdServiceSettings = Field(default_factory=SystemdServiceSettings)


class ContainerSettings(BaseConfigurable):
    """Settings for spawning a container."""

    image: str
    tag: str | None = None
    name: str
    command: str | None = None
    entrypoint: str | None = None
    user: str | None = None
    workdir: str | None = None
    volumes: list[str] = Field(default_factory=list)
    environment: dict[str, str] = Field(default_factory=dict)
    memory: str | None = None
    devices: list[str] = Field(default_factory=list)
    network: str = "juice"
    privileged: bool = False
    env_file: str | None = None
    port_forwarding: list[PortMapping] = Field(default_factory=list[PortMapping])
    group_add: list[str] = Field(default_factory=list)
    arch: str | None = None  # This is equivalent to the --arch option of podman build.
    systemd: SystemdSettings = SystemdSettings(
        service=SystemdServiceSettings(
            restart="always",
            restart_steps=10,
            restart_sec=5,
            timeout_start_sec=900,
            restart_max_delay_sec=60,
        )
    )

    def update(self, other: PartialContainerSettings) -> None:
        """Update this instance in-place with additional container setting."""
        self.volumes.extend(other.volumes)
        self.environment.update(other.environment)
        self.port_forwarding.extend(other.port_forwarding)
        self.devices.extend(other.devices)
        self.group_add.extend(other.group_add)
        self.memory = other.memory or self.memory


class BuildSettings(BaseConfigurable):
    """Settings for building a container image."""

    name: str
    file: str | None = None  # Path to ContainerFile
    workdir: str | None = None
    volumes: list[str] = Field(default_factory=list)
    environment: dict[str, str] = Field(default_factory=dict)
    arch: str | None = None  # This is equivalent to the --arch option of podman build.
    build_args: dict[str, str] = Field(default_factory=dict)
    systemd: SystemdSettings = Field(default_factory=SystemdSettings)

    @model_validator(mode="after")
    def _validate_file_or_workdir(self) -> Self:
        """Set the default Dockerfile if not provided."""
        if not self.file and not self.workdir:
            raise ValueError(
                "Either 'file' or 'workdir' must be provided for BuildSettings."
            )
        return self

    def update(self, other: PartialContainerSettings) -> None:
        """Update this instance in-place with additional build settings."""
        self.volumes.extend(other.volumes)
        self.environment.update(other.environment)
        # We do not extend the following options for build settings:
        # - port_forwarding
        # - devices
        # - group_add
        # - memory


class InfluxDB2BucketDescription(BaseConfigurable):
    """Settings for a single bucket of InfluxDB2 Instance."""

    name: str
    retention: str = "0s"
    """The retention duration for the bucket.

    See https://docs.influxdata.com/influxdb/v2/reference/cli/influx/bucket/update/#retention-periods
    for the format. A retention of "0s" means to retain data indefinitely.
    """
    description: str | None = None
    org: str = "orangeqs-juice"


class InfluxDB2InstanceSettings(BaseConfigurable):
    """Settings for an instance of influxDB2."""

    url: str = "http://juice-influxdb2:8086"
    org: str = "orangeqs-juice"
    secrets_path: str = "/etc/juice/influxdb2/secrets.env"
    config_path: str = "/etc/juice/influxdb2"
    data_path: str = "/var/lib/juice/influxdb2"
    buckets: dict[str, InfluxDB2BucketDescription] = Field(default_factory=dict)
    container: ContainerSettings = ContainerSettings(
        image="docker.io/library/influxdb",
        tag="2.7-alpine",
        name="influxdb2",
        volumes=[
            f"{data_path}:/var/lib/influxdb2",
            f"{config_path}:/etc/influxdb2",
        ],
        env_file=secrets_path,
        port_forwarding=[PortMapping(host_port=8086, container_port=8086)],
    )

    @model_validator(mode="after")
    def _add_default_buckets(self) -> Self:
        """Add the default buckets if not already present."""
        if "system_logs" not in self.buckets:
            self.buckets["system_logs"] = InfluxDB2BucketDescription(name="system_logs")
        if "service_logs" not in self.buckets:
            self.buckets["service_logs"] = InfluxDB2BucketDescription(
                name="service_logs"
            )
        if "identifiers" not in self.buckets:
            self.buckets["identifiers"] = InfluxDB2BucketDescription(name="identifiers")
        if "task-manager" not in self.buckets:
            self.buckets["task-manager"] = InfluxDB2BucketDescription(
                name="task-manager"
            )
        return self


class TelegrafSettings(BaseConfigurable):
    """Settings for configuring Telegraf outputs."""

    influxdb2_org: str
    influxdb2_bucket: str
    influxdb2_url: str
    config_path: str
    podman_stats_interval: str
    podman_stats_timeout: str


class PartialContainerSettings(BaseConfigurable):
    """Partial settings for a container."""

    volumes: list[str] = Field(default_factory=list)
    """List of volume mounts for the container."""
    environment: dict[str, str] = Field(default_factory=dict)
    """Dictionary of environment variables for the container."""
    port_forwarding: list[PortMapping] = Field(default_factory=list[PortMapping])
    """List of port mappings for the container."""
    devices: list[str] = Field(default_factory=list)
    """List of device mappings for the container."""
    group_add: list[str] = Field(default_factory=list)
    """List of additional groups to add the container user to."""
    memory: str | None = None
    """Memory limit for the container.

    Expects a number suffixed by a unit ("K", "M", "G", "T"), e.g., "512M" or "2G".
    Note that the unit must be uppercase!

    This option will be ignored for environment builds.
    """


class BaseEnvironmentSettings(ContainerFolderSettings, metaclass=ABCMeta):
    """Base class for environment settings."""

    container: PartialContainerSettings = Field(
        default_factory=PartialContainerSettings
    )
    """Additional settings for the container of an environment.

    These settings are merged on top of the default settings generated for
    the environment. These settings are applied both to the build container
    and the runtime container.
    """


_UvSourceType = dict[str, Union[str, bool]]  # noqa: UP007
UvSourcesType = dict[str, Union[_UvSourceType, list[_UvSourceType]]]  # noqa: UP007


class UvEnvironmentSettings(BaseEnvironmentSettings):
    """Settings for a `uv`-based environment in Juice."""

    base_image: str = "quay.io/almalinuxorg/almalinux:10"
    type: Literal["uv"] = "uv"
    arch: str | None = None
    python_version: str = "3.12"
    dependencies: list[str] = Field(default_factory=list)
    sources: UvSourcesType = Field(default_factory=dict)

    system_packages: list[str] = Field(default_factory=list)
    """List of system packages to install in the environment container.

    These packages will be installed using `dnf install`.
    """

    @model_validator(mode="after")
    def _add_default_packages(self) -> Self:
        """Install default system packages."""
        default_packages = [
            "git",
            "nano",
            "nodejs",
            # TODO: Remove this once we have configured all deployments that need this.
            "mesa-libGL",
        ]
        for package in default_packages:
            if package not in self.system_packages:
                self.system_packages.append(package)
        return self

    @model_validator(mode="after")
    def _add_orangeqs_juice_core(self) -> Self:
        if "orangeqs-juice-core[runtime]" not in self.dependencies:
            # Dependencies required at runtime in containers that are not referenced
            # in the code. This includes programs like supervisor.
            self.dependencies.append("orangeqs-juice-core[runtime]")
        if "orangeqs-juice-core" not in self.sources:
            if not (source := juice_install_source()):
                raise ValueError(
                    "No local install candidate for `orangeqs-juice-core` found. Please"
                    " provide a source in the `sources` field for all environments."
                )
            source_type, source_path = source
            if source_type == "editable":
                self.sources["orangeqs-juice-core"] = {
                    "editable": True,
                    "path": source_path,
                }
            elif source_type == "wheel":
                self.sources["orangeqs-juice-core"] = {"path": source_path}
            elif source_type == "release":
                # This might break when the user has manually specified a version,
                # but this is unsupported for now anyway.
                self.dependencies.append(source_path)
            else:
                raise ValueError(f"Unknown source type: {source_type}")

        return self


EnvironmentSettings = Annotated[
    UvEnvironmentSettings,
    Field(discriminator="type"),
]
"""
Union type for all types of environment settings supported by OrangeQS Juice.

Currently only supports {class}`UvEnvironmentSettings`.
"""


class EnvironmentsSettings(BaseConfigurable):
    """Common environments used by services and JupyterHub."""

    default: EnvironmentSettings = Field(default_factory=UvEnvironmentSettings)
    """The default environment to use for services and JupyterHub.

    This environment is used when a service or JupyterHub does not specify
    its own environment. To specify an environment for a specific service or
    JupyterHub, set the `environment` field in the respective settings.
    The format is the same as this field.
    """


_USE_DEFAULT_ENVIRONMENT_SENTINEL = UvEnvironmentSettings(
    # Prevent expensive validator to run and use a unique value.
    sources={"orangeqs-juice-core": {"__sentinel__": True}},
)
"""Sentinel value to indicate the default environment should be used.

Warning: This sentinel has to be compared by equality, not by identity!
This is because pydantic deep copies default values when creating models.
"""


class JupyterHubMainHubSettings(BaseConfigurable):
    """Settings for the main Hub of a JupyterHub instance."""

    secrets_file: str = "secrets.env"
    """File containing secrets for the JupyterHub instance."""

    config_file: str = "jupyterhub_config.py"
    """File containing the JupyterHub configuration, rendered by Juice orchestration."""

    singleuser_config_file: str = "jupyter_singleuser_config.py"
    """File containing the Jupyter Server configuration for singleuser containers."""

    authenticator_class: Literal["shared-password", "pam", "gitlab"] = "pam"
    """The authenticator class to use for JupyterHub.

    Depending on the the authenticator class, the following contents are expected in the
    `secrets_file`. By default this file is at `/etc/juice/jupyterhub/secrets.env`.
    - `'shared-password'`:

        ```text
        JUICE_JUPYTERHUB_SHARED_PASSWORD=<password for all users>
        JUICE_JUPYTERHUB_ADMIN_PASSWORD=<admin password>
        ```

    - `'pam'`:
        No additional secrets required.
    - `'gitlab'`:

        ```text
        JUPYTERHUB_OAUTH_APP_ID=<OAuth application ID>
        JUPYTERHUB_OAUTH_APP_SECRET=<OAuth application secret>
        # Should not have a trailing slash, e.g. https://gitlab.com
        JUPYTERHUB_OAUTH_GITLAB_URL=<GitLab instance URL>
        # ID of the group whose members are allowed to log in, e.g. `54`.
        JUPYTERHUB_OAUTH_GITLAB_GROUP=<Allowed GitLab group>
        ```

    """

    user_max_idle_timeout: int = 1800
    """The maximum idle time (in seconds) for singleuser servers before culled."""

    port: int = 8888
    """The port to access the JupyterHub instance on."""

    admin_users: list[str] = ["root"]
    """List of admin users for the JupyterHub instance."""

    extra_config: str | None = None
    """Extra configuration to add to the JupyterHub config file.

    Useful for adding custom configuration options not directly supported.
    """

    oauth_callback_url: str | None = None
    """The OAuth callback URL for the JupyterHub instance."""

    @model_validator(mode="after")
    def _validate_oauth_settings(self) -> Self:
        """Validate OAuth settings if using OAuth authenticator."""
        if self.authenticator_class == "gitlab":
            if not self.oauth_callback_url:
                raise ValueError(
                    "OAuth callback URL must be set when using 'gitlab' "
                    "as authenticator_class."
                )
        else:
            if self.oauth_callback_url:
                raise ValueError(
                    "OAuth callback URL should not be set when not using 'gitlab' "
                    "as authenticator_class."
                )
        return self


class JupyterHubSingleUserServerSettings(ContainerFolderSettings):
    """Settings for the single-user servers spawned by the Hub."""

    environment: EnvironmentSettings = _USE_DEFAULT_ENVIRONMENT_SENTINEL
    """The environment to use for singleuser servers.

    Defaults to `environments.default` if not specified.
    When overriding the environment, be aware that it does not inherit
    from the default environment!

    This environment will always have `jupyterhub`, `jupyterlab` and
    `jupyter-server-proxy` added as dependencies automatically.
    """

    dashboard_log_file: str = "/tmp/user/dashboard_log"
    """The file where dashboard logs are stored."""

    # If the command is not on the $PATH, it should be specified with the full path.
    cmd: list[str] = [
        "/env/.venv/bin/supervisord",
        "-c",
        "/env/supervisor/supervisord.conf",
    ]
    """The command to run in the singleuser server container."""


class JupyterHubInstanceSettings(BaseConfigurable):
    """Top-level settings for a JupyterHub instance managed by Juice."""

    database_dir: str = "/var/lib/juice/jupyterhub/database"
    user_data_dir: str = "/var/lib/juice/user"
    config_dir: str = "/etc/juice/jupyterhub"
    supervisor_config_dir: str = "/etc/juice/jupyterhub/supervisor"

    main_hub: JupyterHubMainHubSettings = Field(
        default_factory=JupyterHubMainHubSettings
    )
    singleuser: JupyterHubSingleUserServerSettings = Field(
        default_factory=JupyterHubSingleUserServerSettings
    )

    @computed_field
    @property
    def build(self) -> BuildSettings:
        """Generate build service settings."""
        destination_folder = Path(self.config_dir)
        output_file = destination_folder / "Containerfile"
        return BuildSettings(
            name="jupyterhub",
            file=str(output_file.absolute()),
        )

    @computed_field
    @property
    def container(self) -> ContainerSettings:
        """Generate Jupyterhub Container settings."""
        main_hub_config_path = os.path.join(self.config_dir, self.main_hub.config_file)
        volumes = [
            # The user data folder is mounted inside the container to create user
            # home directories from the main hub before spawning singleuser servers.
            f"{self.user_data_dir}:{self.user_data_dir}",
            f"{self.database_dir}:/var/lib/jupyterhub",
            f"{main_hub_config_path}:/srv/jupyterhub/jupyterhub_config.py:ro",
            "/run/podman/podman.sock:/var/run/docker.sock:rw",
            f"{self.supervisor_config_dir}:/etc/juice/jupyterhub/supervisor",
        ]
        if self.main_hub.authenticator_class in ["shared-password", "gitlab"]:
            env_file = os.path.join(self.config_dir, self.main_hub.secrets_file)
        elif self.main_hub.authenticator_class == "pam":
            env_file = None
            volumes.extend(
                [
                    "/etc/passwd:/etc/passwd:ro",
                    "/etc/group:/etc/group:ro",
                    "/etc/shadow:/etc/shadow:ro",
                ]
            )
        else:
            env_file = None
        jupyterhub_build_service = "juice-jupyterhub-build.service"
        singleuser_build_service = f"juice-{SINGLEUSER_ENVIRONMENT_NAME}-build.service"
        return ContainerSettings(
            image="juice-jupyterhub",
            name="jupyterhub",
            volumes=volumes,
            env_file=env_file,
            port_forwarding=[
                PortMapping(
                    host_port=self.main_hub.port, container_port=self.main_hub.port
                )
            ],
            systemd=SystemdSettings(
                unit=SystemdUnitSettings(
                    # We use `After` to wait for the build to finish if it's
                    # already in progress, but do not trigger a build automatically.
                    after=[jupyterhub_build_service, singleuser_build_service],
                ),
                service=SystemdServiceSettings(
                    exec_start_pre=[
                        f"{juice_cli_path()} hook start-pre system-jupyterhub",
                    ]
                ),
            ),
        )


class ServiceSettings(BaseConfigurable):
    """Settings for a OrangeQS Juice service."""

    environment: EnvironmentSettings = _USE_DEFAULT_ENVIRONMENT_SENTINEL
    """The environment definition to use for the service.

    Defaults to `environments.default` if not specified.
    When overriding the environment, be aware that it does not inherit
    from the default environment!
    """

    entrypoint: str = "orangeqs.juice.service:IPythonService"
    """
    Class to use as the entrypoint for the service.

    Uses the format `<module>:<class>`.
    """

    init_args: list[Any] = Field(default_factory=list)
    """
    List of arguments to pass to the service class on initialization.

    Will be passed as `*init_args` to the service class.
    """

    init_kwargs: dict[str, Any] = Field(default_factory=dict)
    """
    Dictionary of keyword arguments to pass to the service class on initialization.

    Will be passed as `**init_kwargs` to the service class.
    """


class OrchestrationSettings(Configurable):
    """Settings for the installation of OrangeQS Juice.

    :::{warning}

    Note that this is the only configuration file which can **only** be loaded from
    `/etc/juice/config`! This configuration file can thus only be modified by the system
    administrator, and not from the lab repository or extensions.

    :::
    """

    filename: ClassVar[str] = "orchestration"

    environments: EnvironmentsSettings = Field(default_factory=EnvironmentsSettings)
    """Common environments used by services and JupyterHub."""

    data_folder: DataFolderSettings = Field(default_factory=DataFolderSettings)
    """Settings for data folder locations on the host system."""
    services: dict[str, ServiceSettings] = Field(default_factory=dict)
    """Collection of OrangeQS Juice services to run.

    The key corresponds to the name of the service.
    """
    containerization: ContainerizationSettings = Field(
        default_factory=ContainerizationSettings
    )
    influxdb2: InfluxDB2InstanceSettings = Field(
        default_factory=InfluxDB2InstanceSettings
    )
    jupyterhub: JupyterHubInstanceSettings = Field(
        default_factory=JupyterHubInstanceSettings
    )
    """Configuration for the JupyterHub instance managed by Juice."""

    @computed_field
    @property
    def telegraf(self) -> TelegrafSettings:
        """Generate Telegraf settings."""
        default_telegraf_bucket = "system_logs"
        return TelegrafSettings(
            influxdb2_org=self.influxdb2.buckets[default_telegraf_bucket].org,
            influxdb2_bucket=default_telegraf_bucket,
            # Accessing InfluxDB2 via localhost since Telegraf runs on the host,
            # and therefore juice-influxdb2 is not resolvable.
            influxdb2_url="http://localhost:8086",
            config_path="/etc/telegraf/telegraf.d/50-juice.conf",
            podman_stats_timeout="30s",
            podman_stats_interval="5s",
        )

    @model_validator(mode="after")
    def _add_task_manager_service(self) -> Self:
        """Add the task manager service if not already present."""
        if "task-manager" not in self.services:
            self.services["task-manager"] = ServiceSettings(
                entrypoint="orangeqs.juice.task_manager:TaskManagerService",
            )
        return self

    @model_validator(mode="after")
    def _apply_default_environment(self) -> Self:
        """Apply the default environment to services using the sentinel value."""
        for service_name, service_settings in self.services.items():
            if service_settings.environment == _USE_DEFAULT_ENVIRONMENT_SENTINEL:
                self.services[service_name].environment = deepcopy(
                    self.environments.default
                )
        if self.jupyterhub.singleuser.environment == _USE_DEFAULT_ENVIRONMENT_SENTINEL:
            self.jupyterhub.singleuser.environment = deepcopy(self.environments.default)
        return self

    @model_validator(mode="after")
    def _add_singleuser_dependencies(self) -> Self:
        """Add jupyter dependencies to the environment.

        We cannot run this validator on `JupyterHubSingleUserServerSettings` directly
        because we need to have resolved the default environment first.

        List of dependencies to add:
        - jupyterhub
        - jupyterlab
        - jupyter-server-proxy
        - jupyter-code-server
        """
        singleuser_environment = self.jupyterhub.singleuser.environment
        assert singleuser_environment != _USE_DEFAULT_ENVIRONMENT_SENTINEL, (
            "Validator should not run on sentinel value."
        )
        if "orangeqs-juice-core[singleuser]" not in singleuser_environment.dependencies:
            singleuser_environment.dependencies.append(
                "orangeqs-juice-core[singleuser]"
            )

        singleuser_config_path = os.path.join(
            self.jupyterhub.config_dir, self.jupyterhub.main_hub.singleuser_config_file
        )
        singleuser_environment.container.volumes.append(
            f"{singleuser_config_path}:/etc/jupyter/jupyter_server_config.py:ro"
        )

        return self


def juice_install_source() -> (
    tuple[Literal["editable", "wheel", "release"], str] | None
):
    """Attempt to find an installation source of the Juice Python package.

    If the package is installed in editable mode, it will return the
    path to the source directory. Otherwise it will look for a wheel
    file in common locations (part of the system package).
    If running a released version, it will return the dependency specifier.

    Returns
    -------
    tuple or None
        If a suitable source is found, returns tuple of the source type
        ("editable", "wheel" or "release") and the path to the source.
        If no suitable source is found, returns None.
    """
    if juice_source := _find_juice_source_editable():
        return "editable", juice_source

    if juice_source := _find_juice_source_wheel():
        return "wheel", juice_source

    if juice_source := _find_juice_source_released():
        return "release", juice_source

    return None


def _find_juice_source_editable() -> str | None:  # noqa: UP007
    """Find the source path of the Juice package if installed in editable mode.

    If installed in editable mode, we expect a `src` directory in the package path.
    To be extra sure, we also check for the presence of a `.git` folder
    in the parent directory of the `src` directory.
    """
    import importlib.util

    spec = importlib.util.find_spec("orangeqs.juice")
    if spec is None or not spec.origin:
        return None
    # spec.origin is the package __init__.py, so 3x .parent is the src directory.
    possible_src_path = Path(spec.origin).absolute().parent.parent.parent
    if possible_src_path.name != "src":
        # The package is likely installed in site-packages
        return None

    repo_path = possible_src_path.parent
    git_folder = repo_path / ".git"
    if not git_folder.exists() or not git_folder.is_dir():
        # Not a git repository, not a valid editable install
        return None

    return str(repo_path)


def _find_juice_source_wheel() -> str | None:
    """Find the Juice wheel on the bundled path if it exists."""
    if Path(BUNDLED_WHEEL_PATH).is_file():
        return BUNDLED_WHEEL_PATH


def _find_juice_source_released() -> str | None:
    """Find the Juice dependency specifier if running a released version."""
    from orangeqs.juice._version import version_is_from_git

    if version_is_from_git():
        # Not running a release
        return None

    return f"orangeqs-juice-core=={juice.__version__}"
