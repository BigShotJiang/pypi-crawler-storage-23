"""Module for managing the OrangeQS Juice installation."""
