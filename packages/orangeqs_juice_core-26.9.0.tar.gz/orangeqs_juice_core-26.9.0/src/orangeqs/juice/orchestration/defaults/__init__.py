"""Functions to install default files and configurations for OrangeQS Juice.

It ensures that default files are only installed once, allowing the system administrator
to remove the files if needed. The installation status of each file/component tracked in
the `<SYSTEM_CONFIG_PATH>/.defaults` directory.
"""

import os
import shutil
from pathlib import Path

from orangeqs.juice.orchestration.settings import OrchestrationSettings
from orangeqs.juice.settings import SYSTEM_CONFIG_PATH

_INSTALLATION_STATUS_DIR = Path(SYSTEM_CONFIG_PATH, ".defaults")


def install(settings: OrchestrationSettings) -> None:
    """Install default files and configurations for OrangeQS Juice.

    This function installs defaults that are bundled with OrangeQS Juice:
    - A default lab extension in the user data shared folder.
    - Default system configurations in the system config folder.

    It ensures that these files are only installed once
    and do not overwrite existing files.

    Parameters
    ----------
    settings : OrchestrationSettings
        The settings of the orchestrator.
    """
    _install_lab_extension(settings)
    _install_system_configs()
    _create_empty_singleuser_config(settings)


def _install_lab_extension(settings: OrchestrationSettings) -> None:
    """Install a default lab extension to the user data shared folder."""
    _install_key = "lab_extension"
    lab_target_path = Path(settings.data_folder.user_data_shared) / "lib" / "lab"
    if lab_target_path.exists() or _is_installed(_install_key):
        return

    lab_source_path = Path(__file__).parent / "lab"
    lab_target_path.mkdir(parents=True, exist_ok=True)
    shutil.copytree(lab_source_path, lab_target_path, dirs_exist_ok=True)

    # Recursively change ownership of the lab extension files
    uid, gid = settings.data_folder.user_id, settings.data_folder.group_id
    for dirpath, _, filenames in os.walk(lab_target_path):
        shutil.chown(dirpath, uid, gid)
        for filename in filenames:
            shutil.chown(os.path.join(dirpath, filename), uid, gid)

    _set_installed(_install_key)


def _install_system_configs() -> None:
    """Install default system configurations to the system config folder."""
    target_path = Path(SYSTEM_CONFIG_PATH)
    if not target_path.exists():
        target_path.mkdir(parents=True, exist_ok=True)

    source_path = Path(__file__).parent / "system_config"
    for config in source_path.iterdir():
        if not config.is_file() or not config.name.endswith(".toml"):
            continue

        target_file = target_path / config.name
        _install_key = f"system_config_{config.stem}"
        if target_file.exists() or _is_installed(_install_key):
            # Skip if the file already exists or has been installed before
            continue

        shutil.copy(config, target_file)
        _set_installed(_install_key)


def _is_installed(key: str) -> bool:
    """Check if a specific default component is installed.

    A components is considered to be installed if its key exists as a file
    in the `<SYSTEM_CONFIG_PATH>/.defaults` directory.

    Parameters
    ----------
    key : str
        The key of the component to check.
    """
    return (_INSTALLATION_STATUS_DIR / key).exists()


def _set_installed(key: str, installed: bool = True) -> None:
    """Set the installation status of a specific default file.

    If not `installed`, the file corresponding to `key` is removed from the
    `<SYSTEM_CONFIG_PATH>/.defaults` directory, indicating it should be (re)installed.
    If `installed`, the file is created, indicating it should not be (re)installed.

    Parameters
    ----------
    key : str
        The key of the component to set.
    installed : bool
        The installation status to set.
    """
    target_file = _INSTALLATION_STATUS_DIR / key
    if installed == target_file.exists():
        # No change needed
        return

    if installed:
        target_file.parent.mkdir(parents=True, exist_ok=True)
        target_file.touch()
    else:
        target_file.unlink()


def _create_empty_singleuser_config(settings: OrchestrationSettings) -> None:
    """Create empty singleuser configuration file if it do not exist.

    This is necessary as the singleuser build requires these files as volume mounts.
    As the build does not use the contents of these files, empty files are good enough.
    During the Jupyterhub installation these files are populated, thus they will always
    be correctly configured during runtime.
    """
    config_dir = settings.jupyterhub.config_dir
    os.makedirs(config_dir, exist_ok=True)

    # Create singleuser config if it does not exist
    singleuser_config_path = os.path.join(
        config_dir, settings.jupyterhub.main_hub.singleuser_config_file
    )
    if not os.path.exists(singleuser_config_path):
        with open(singleuser_config_path, "w") as f:
            f.write("")
