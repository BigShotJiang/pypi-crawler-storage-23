import asyncio

from orangeqs.juice.messaging.zmq import ZMQProxy
from orangeqs.juice.orchestration.settings import OrchestrationSettings
from orangeqs.juice.schemas.task_manager import (
    TaskManagerConfig,
    TaskManagerConnectionInfo,
)
from orangeqs.juice.schemas.tasks import TaskServerConfigs
from orangeqs.juice.service import Service
from orangeqs.juice.task_manager._kernel_monitor import KernelMonitor
from orangeqs.juice.task_manager._router import TaskRouter


class TaskManagerService(Service):
    """Service for the task manager."""

    def __init__(self, service_name: str) -> None:
        super().__init__(service_name)

        self.config = TaskManagerConfig.load()

        self._store_connection_info()

        task_server_configs = TaskServerConfigs.load()
        self.task_router = TaskRouter(self.loop, self.config, task_server_configs)

        self._kernel_monitors = {
            service: KernelMonitor(
                service=service,
                loop=self.loop,
                report_interval=self.config.kernel_status_report_interval,
            )
            for service in OrchestrationSettings.load().services
            if service != "task-manager"
        }  ## See #207

    def _store_connection_info(self) -> None:
        """Store connection information for the task manager service.

        This connection info is used by clients to connect to the task manager.
        """
        ip = self.config.network.ip or f"juice-{self.service_name}"
        TaskManagerConnectionInfo(
            **self.config.network.model_dump(exclude={"ip"}), ip=ip
        ).store("default", exist_ok=True)

    def start(self) -> None:
        """Start the service."""
        self.loop.run_until_complete(self._start())

    async def _start(self) -> None:
        """Start all parts of the service."""
        await asyncio.gather(
            self.task_router.start(),
            self._start_proxy(),
            self._start_kernel_monitors(),
        )

    async def _start_kernel_monitors(self) -> None:
        """Start all kernel monitors."""
        await asyncio.gather(
            *[monitor.run() for monitor in self._kernel_monitors.values()]
        )

    async def _start_proxy(self) -> None:
        """Start the ZMQ proxy for pub/sub messaging.

        Runs indefinitely.
        """
        sub_uri = f"tcp://*:{self.config.network.sub_port}"
        pub_uri = f"tcp://*:{self.config.network.pub_port}"

        proxy = ZMQProxy(pub_uri=pub_uri, sub_uri=sub_uri)
        await proxy.run()
