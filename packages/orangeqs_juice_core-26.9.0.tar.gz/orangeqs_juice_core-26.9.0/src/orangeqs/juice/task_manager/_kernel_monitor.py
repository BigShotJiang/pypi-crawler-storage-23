"""Kernel Status Monitor for Task Manager."""

import asyncio
import logging
import time
from typing import Literal

from orangeqs.juice import Client
from orangeqs.juice._util import rerun_on_exception
from orangeqs.juice.client import influxdb2
from orangeqs.juice.client.ipython import ipython_client_async
from orangeqs.juice.client.pubsub import publish_event
from orangeqs.juice.task_manager._schemas import IPythonServiceState

_logger = logging.getLogger(__name__)


class KernelMonitor:
    """A class to monitor the status of a single Juice IPythonService Kernel."""

    def __init__(
        self,
        service: str,
        loop: asyncio.AbstractEventLoop,
        report_interval: int = 60,
    ) -> None:
        """Create a kernel queue for managing tasks on a kernel.

        Will automatically start handling the queue upon creation.

        Parameters
        ----------
        service : str
            Name of the service the kernel client belongs.
        kernel_client : AsyncKernelClient
            The kernel client belonging to the service.
        loop : asyncio.AbstractEventLoop
            The asyncio event loop to run the kernel queue on.
        report_interval : int, optional
            Interval in seconds to report kernel status, by default 60
        """
        self.service = service
        self.loop = loop
        self.report_interval = report_interval
        self._kernel_status: Literal[
            "idle", "busy", "restarting", "connecting", "unknown"
        ] = "unknown"
        self.publisher = Client().publisher_async()
        self.write_api = influxdb2.influxdb2_write_api()

        _logger.info(f"{self.service}: Initialized Kernel Monitor.")

    @rerun_on_exception
    async def run(self) -> None:
        """Run the Kernel Monitor.

        This runs a loop that monitors the kernel status and reports it at
        regular intervals. In parallel, it listens for kernel messages to update
        the status immediately upon changes.
        """
        _logger.info(f"{self.service}: Starting Kernel Monitor tasks.")
        while True:  # This loop runs if the heartbeat dies and we need to reconnect
            self.kernel_client = ipython_client_async(service=self.service)
            await self.handle_kernel_status("connecting")
            success = await self._wait_for_kernel_ready(timeout=self.report_interval)
            if not success:
                continue
            await self.handle_kernel_status("idle")
            report_future = asyncio.ensure_future(asyncio.sleep(self.report_interval))
            # sleep_future is used to force the loop to iterate and check heartbeat
            # every second
            sleep_future = asyncio.ensure_future(asyncio.sleep(1.0))
            iopub_future = asyncio.ensure_future(self.kernel_client.get_iopub_msg())

            _logger.info(f"{self.service}: Kernel is ready, starting monitoring.")
            while self.kernel_client.hb_channel.is_beating():
                done, _ = await asyncio.wait(
                    [sleep_future, report_future, iopub_future],
                    return_when=asyncio.FIRST_COMPLETED,
                )

                if iopub_future in done:
                    msg = iopub_future.result()
                    if msg["msg_type"] == "status":
                        await self.handle_kernel_status(
                            msg["content"]["execution_state"]
                        )
                    if (
                        msg["msg_type"] == "shutdown_reply"
                        and msg["content"]["status"] == "ok"
                    ):
                        await self.handle_kernel_status("restarting")
                        # Give kernel time to shutdown before reconnecting
                        await asyncio.sleep(1.0)
                    iopub_future = asyncio.ensure_future(
                        self.kernel_client.get_iopub_msg()
                    )

                if report_future in done:
                    await self.handle_kernel_status()
                    report_future = asyncio.ensure_future(
                        asyncio.sleep(self.report_interval)
                    )

                if sleep_future in done:
                    sleep_future = asyncio.ensure_future(asyncio.sleep(1.0))

            _logger.info(f"{self.service}: Kernel heartbeat lost, reconnecting.")

    async def _wait_for_kernel_ready(self, timeout: float) -> bool:
        """Wait for a kernel associated with the kernel_client to be ready.

        Starts the heartbeat and iopub channels if they are not already running.
        """
        deadline = time.monotonic() + timeout
        if not self.kernel_client.hb_channel.is_alive():
            self.kernel_client.hb_channel.start()

        if not self.kernel_client.iopub_channel.is_alive():
            self.kernel_client.iopub_channel.start()

        while True:
            try:
                await self.kernel_client.wait_for_ready(timeout=1.0)
                return True
            except RuntimeError as e:
                if time.monotonic() > deadline:
                    _logger.warning(f"{self.service}: Kernel is not ready yet. {e}")
                    return False
            except Exception as e:
                _logger.exception(e)
                await asyncio.sleep(1.0)
                return False

    async def handle_kernel_status(
        self,
        new_status: Literal["idle", "busy", "restarting", "connecting", "unknown"]
        | None = None,
    ) -> None:
        """Update the internal _kernel_status and publish the new state.

        If new_status is None, use the current kernel status.

        Parameters
        ----------
        new_status : Literal["idle", "busy", "restarting", "connecting", "unknown"]
                            | None
            The new kernel status to set. If None, use the current status
        """
        if new_status is not None:
            self._kernel_status = new_status
        state_point = IPythonServiceState(
            service=self.service,
            state=self._kernel_status,
        )
        await publish_event(
            state_point,
            publisher=self.publisher,
            write_api=self.write_api,
            bucket="task-manager",
        )
        # HARDCODED, guaranteed by OrchestrationSettings validator to exist
