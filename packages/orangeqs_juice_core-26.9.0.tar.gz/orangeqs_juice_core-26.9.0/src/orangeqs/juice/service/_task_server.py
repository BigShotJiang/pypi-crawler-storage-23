"""Task handler for services."""

import asyncio
import contextlib
import inspect
import logging
import sys
import threading
import traceback
from collections.abc import Callable, Coroutine
from typing import Any, TypeVar

import tornado
import tornado.web
import tornado.websocket

from orangeqs.juice.schemas.task_manager import TaskManagerConfig
from orangeqs.juice.schemas.tasks import TaskServerConfig
from orangeqs.juice.task import Task

_logger = logging.getLogger(__name__)

_TaskType = TypeVar("_TaskType", bound=Task)


class TaskHandlerRegistry:
    """Registry for task handlers.

    Provides methods to register and handle tasks by type.
    """

    def __init__(self) -> None:
        self._task_handlers: dict[str, tuple[type[Task], Callable[[Any], Any]]] = {}

    def register_handler(
        self, task_type: type[_TaskType], func: Callable[[_TaskType], Any]
    ) -> None:
        """Register a handler for a specific task type.

        Parameters
        ----------
        task_type : type[Task]
            The type of the task to register the handler for.
        func : Callable[[Task], Any]
            The handler function to register. It should take a single argument of the
            task type and return any value.
        """
        _logger.debug("Registering handler %s for task type %s", func, task_type)
        # Allow overwriting the handler, but only if it's the exact same class.
        if (
            task_type.type() in self._task_handlers
            and self._task_handlers[task_type.type()][0] is not task_type
        ):
            raise ValueError(
                f"Cannot register handler for {task_type}. "
                f"There is already a different class registered for task type "
                f"{task_type.type()}: {self._task_handlers[task_type.type()][0]}"
            )
        self._task_handlers[task_type.type()] = task_type, func

    def handle_task(self, task: Task) -> Any:  # noqa: ANN401
        """Handle a task by calling the registered handler.

        Parameters
        ----------
        task : Task
            The task to handle.

        Returns
        -------
        Any
            The result of the handler function.

        Raises
        ------
        ValueError
            If no handler is registered for the task type.
        """
        task_type = type(task)
        if task_type.type() not in self._task_handlers:
            # TODO: Look for handlers for base classes of task_type
            raise ValueError(
                "No handler registered for task schema "
                f"{task_type.__module__}.{task_type.__name__}. "
                f"Type was {task_type.type()}."
            )

        _, handler = self._task_handlers[task_type.type()]
        _logger.debug("Calling %s for handling task type %s", handler, task_type)
        return handler(task)


class TaskServer(TaskHandlerRegistry):
    """A server for handling incoming tasks over WebSockets."""

    def __init__(self, config: TaskServerConfig) -> None:
        super().__init__()
        self._loop: asyncio.AbstractEventLoop | None = None

        self._task_manager_config = TaskManagerConfig.load()
        self._task_server_config = config

    def start(self) -> None:
        """Start the task server in a separate thread."""
        self._start_task_server_thread()

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        """The event loop used by the service.

        If a subclass uses a different event loop, it should override this property.
        """
        if self._loop is None:
            try:
                self._loop = asyncio.get_running_loop()
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
        return self._loop

    async def _handle_task(self, task_data: dict[str, Any], _: str | bytes) -> Any:  # noqa: ANN401
        """Handle a task by deserializing it and calling the registered handler."""
        task_instance = self._deserialize_task(task_data)

        async def _handle() -> Any:  # noqa: ANN401
            result = self.handle_task(task_instance)
            if inspect.isawaitable(result):
                result = await result
            return result

        # Submit the coroutine to the main service event loop in the main thread.
        future = asyncio.run_coroutine_threadsafe(_handle(), self.loop)
        async_future = asyncio.wrap_future(future)
        return await async_future

    def _deserialize_task(self, data: dict[str, Any]) -> Task:
        """Deserialize a task from a dictionary.

        Parameters
        ----------
        data : dict[str, Any]
            The dictionary to deserialize the task from. It must contain a "type" key
            with the fully qualified name of the task class.

        Returns
        -------
        Task
            The deserialized task.

        Raises
        ------
        ValueError
            If the "type" key is missing or if the task type is unknown.
        """
        if "type" not in data:
            raise ValueError("Missing 'type' key in task data")

        task_type_name = data.get("type")
        if task_type_name not in self._task_handlers:
            raise ValueError(f"Unknown task type: {task_type_name}")
        task_type, _ = self._task_handlers[task_type_name]

        payload = data.get("payload", {})
        return task_type.model_validate(payload)

    async def _run_task_server(self) -> None:
        """Run a tornado server for handling incoming tasks.

        Should be run in a separate thread and runs indefinitely.
        """
        self._task_app = tornado.web.Application(
            [
                (r"/tasks", WebsocketHandler, {"handle_message": self._handle_task}),
            ],
            websocket_ping_interval=self._task_manager_config.websocket_ping_interval,
            websocket_ping_timeout=self._task_manager_config.websocket_ping_timeout,
            websocket_max_message_size=self._task_manager_config.websocket_max_message_size,
        )

        _logger.debug(
            "Starting task server on port %d",
            self._task_server_config.port,
        )

        self._task_http_server = self._task_app.listen(
            self._task_server_config.port, address=self._task_server_config.ip
        )
        await asyncio.Event().wait()

    def _start_task_server_thread(self) -> None:
        """Start the server thread for handling incoming tasks."""
        self._server_thread = threading.Thread(
            target=asyncio.run, args=(self._run_task_server(),), daemon=True
        )
        self._server_thread.start()


class WebsocketHandler(tornado.websocket.WebSocketHandler):
    """Websocket handler for deserializing incoming tasks.

    Handles incoming messages by deserializing them and calling the provided
    `handle_message` function. The result is then serialized and sent back to the
    client.
    """

    def initialize(
        self,
        handle_message: Callable[
            [dict[str, Any], str | bytes], Coroutine[None, None, Any]
        ],
        raw: bool = False,
    ) -> None:
        """Initialize the handler with the message handling function.

        Parameters
        ----------
        handle_message : Callable[[dict[str, Any]], Coroutine[None, None, Any]]
            The function to handle incoming messages. It should take a dictionary
            (the deserialized message) and return a coroutine that resolves to the
            result to be sent back to the client.
        raw : bool
            If True, expects the `handle_message` function to return the raw dictionary
            response to be send back to the client.
        """
        self.handle_message = handle_message
        self.raw = raw
        # Keep track of message handlers to be able to cancel them on close.
        self._message_handlers: set[asyncio.Task[None]] = set()

    def on_message(self, message: str | bytes) -> None:
        """Handle incoming message on websocket."""
        # Tornado handles message sequently, so while this method is still processing
        # it will not receive the next messages, including pings!
        # To mitigate this we return a future to handle the message in the background.
        # See https://github.com/tornadoweb/tornado/issues/2532 for more information.
        # Warning: this results in replies possibly not coming back in order!
        self._message_handlers.add(asyncio.ensure_future(self._handle_request(message)))

    def on_close(self) -> None:
        """Cancel all pending message handlers tasks."""
        super().on_close()
        for task in self._message_handlers:
            task.cancel()

    async def _handle_request(self, message: str | bytes) -> None:
        """Handle an incoming request.

        Deserializes the message, calls the handler, and sends back the result.
        """
        # Attempt to get a request id to be able to report errors.
        try:
            msg_data = tornado.escape.json_decode(message)

            request_id = msg_data.get("id")
            if request_id is None:
                raise ValueError("Message does not contain an 'id' field.")
        except Exception:
            _logger.exception("Failed to decode message: %s", message)
            if task := asyncio.current_task():
                self._message_handlers.discard(task)
            return

        # Now that we have an id, we can call the handler and report errors.
        try:
            result = await self.handle_message(msg_data, message)

            if not self.raw:
                result = {
                    "id": request_id,
                    "status": "ok",
                    "result": result,
                }

            await self.write_message(result)
        except (Exception, asyncio.CancelledError) as ex:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            assert exc_type is not None  # for type checking
            exc_traceback = traceback.format_exception(
                exc_type, exc_value, exc_traceback
            )
            with contextlib.suppress(tornado.websocket.WebSocketClosedError):
                # We report the error on a best effort basis, as the connection
                # might already be closed.
                await self.write_message(
                    {
                        "id": request_id,
                        "status": "error",
                        "ename": exc_type.__name__,
                        "evalue": str(ex),
                        "traceback": "".join(exc_traceback),
                    }
                )
        finally:
            if task := asyncio.current_task():
                self._message_handlers.discard(task)
