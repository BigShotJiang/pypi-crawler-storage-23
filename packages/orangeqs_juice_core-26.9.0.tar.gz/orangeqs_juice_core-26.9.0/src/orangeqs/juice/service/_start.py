import importlib

from orangeqs.juice.service._service import Service


def start(service_name: str) -> None:
    """Start an OrangeQS Juice service by its name.

    Imports the entrypoint class and starts the service.

    Parameters
    ----------
    service_name : str
        The name of the service to start.s
    """
    from orangeqs.juice.orchestration.settings import OrchestrationSettings

    settings = OrchestrationSettings.load()
    service = settings.services.get(service_name, None)
    if not service:
        raise ValueError(f"Service '{service_name}' not found in settings.")

    try:
        module_name, class_name = service.entrypoint.split(":", maxsplit=1)
    except ValueError:
        raise ValueError(
            f"Invalid entrypoint format '{service.entrypoint}'. "
            "Expected 'module:class'."
        )

    try:
        module = importlib.import_module(module_name)
    except ImportError as e:
        raise RuntimeError(
            f"Failed to import service entrypoint '{service.entrypoint}'"
        ) from e

    if not hasattr(module, class_name):
        raise RuntimeError(
            f"Service entrypoint '{service.entrypoint}' does not have "
            f"a class named '{class_name}'."
        )

    service_class = getattr(module, class_name)
    if not issubclass(service_class, Service):
        raise TypeError(
            f"Service entrypoint '{service.entrypoint}' must be a subclass of "
            "'orangeqs.juice.service.Service'."
        )

    service_instance = service_class(
        service_name,
        *service.init_args,
        **service.init_kwargs,
    )
    service_instance.start()
