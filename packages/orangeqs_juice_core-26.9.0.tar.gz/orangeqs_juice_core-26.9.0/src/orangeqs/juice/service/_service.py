"""OrangeQS Juice service base class and start method."""

import logging
import logging.config
from typing import Any

from orangeqs.juice.client.influxdb2 import retrieve_influxdb2_token
from orangeqs.juice.schemas.logging import ServiceLoggingConfigs
from orangeqs.juice.schemas.tasks import (
    Ping,
    RebuildEnvironmentDryRun,
    SleepAsync,
    SleepSync,
    TaskServerConfigs,
)
from orangeqs.juice.service._info import store_service_info
from orangeqs.juice.service._task_server import TaskServer


class Service(TaskServer):
    """Base class for OrangeQS Juice services.

    This class can be extended to create specific service implementations.
    It provides a common interface for starting services.

    Parameters
    ----------
    service_name : str
        The name of the service. Will be used to load the service configuration.
    """

    def __init__(self, service_name: str) -> None:
        task_server_config = TaskServerConfigs.load().for_service(service_name)
        super().__init__(config=task_server_config)

        self.service_name = service_name

        store_service_info(service_name)

        logging.config.dictConfig(_logging_config(service_name))
        logging.getLogger(__name__).info(
            f"Successfully configured logging for service {service_name}"
        )

        self.register_handler(Ping, self._handle_ping)
        self.register_handler(SleepSync, self._handle_sleep_sync)
        self.register_handler(SleepAsync, self._handle_sleep_async)
        self.register_handler(
            RebuildEnvironmentDryRun, self._handle_rebuild_environment_dry_run
        )

    def start(self) -> None:
        """Start the service.

        This method can be overridden by subclasses to implement service-specific
        startup logic. Should always call `super().start()`.

        If you want to run asynchronous code, you should use `self.loop`
        to run your async functions.
        """
        super().start()

    def _handle_ping(self, task: Ping) -> str:
        """Handle a ping task."""
        return task.message

    def _handle_sleep_sync(self, task: SleepSync) -> None:
        """Handle a sleep task."""
        import time

        time.sleep(task.duration)
        return None

    async def _handle_sleep_async(self, task: SleepAsync) -> None:
        """Handle a sleep task."""
        import asyncio

        await asyncio.sleep(task.duration)
        return None

    def _handle_rebuild_environment_dry_run(
        self, task: RebuildEnvironmentDryRun
    ) -> tuple[bool, list[str]]:
        """Handle a rebuild environment dry-run task."""
        from orangeqs.juice.client.service import (
            _uv_sync_dry_run,  # pyright: ignore[reportPrivateUsage]
        )

        return _uv_sync_dry_run()


def _logging_config(service_name: str) -> dict[str, Any]:
    """Return the logging configuration for the service."""
    service_logging_configs = ServiceLoggingConfigs.load()
    log_level_stdout = service_logging_configs.services[service_name].log_level_stdout

    try:
        retrieve_influxdb2_token()
        # If token is unconfigured, this will fallback to only stdout logging

        log_level_influxdb = service_logging_configs.services[
            service_name
        ].log_level_influxdb
        log_bucket_name = service_logging_configs.bucket_name

        handlers = {
            "stdout": {
                "class": "logging.StreamHandler",
                "formatter": "full",
                "level": log_level_stdout,
                "stream": "ext://sys.stdout",
                "filters": ["skip_stdout_filter"],
            },
            "influxdb": {
                "class": "orangeqs.juice.service._logging.JuiceInfluxLoggingHandler",
                "formatter": "message_only",
                "level": log_level_influxdb,
                "bucket": log_bucket_name,
                "service": service_name,
            },
        }

        root_handlers = ["stdout", "influxdb"]
        root_level = min(log_level_stdout, log_level_influxdb)

    except Exception as e:
        handlers = {
            "stdout": {
                "class": "logging.StreamHandler",
                "formatter": "full",
                "level": log_level_stdout,
                "stream": "ext://sys.stdout",
                "filters": ["skip_stdout_filter"],
            },
        }

        root_handlers = ["stdout"]
        root_level = log_level_stdout
        logging.critical(f"InfluxDB logging setup failed: {e}")

    return {
        "version": 1,
        "filters": {
            "skip_stdout_filter": {
                "()": "orangeqs.juice.service._service.SkipStdoutFilter"
            },
        },
        "formatters": {
            "full": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            },
            "message_only": {
                "format": "%(message)s",
            },
        },
        "handlers": handlers,
        "root": {
            "handlers": root_handlers,
            "level": root_level,
        },
        "loggers": {
            "orangeqs.juice": {
                "level": logging.DEBUG,
            },
        },
    }


class SkipStdoutFilter(logging.Filter):
    """A logging filter that skips records meant to be excluded from stdout."""

    def filter(self, record: logging.LogRecord) -> bool:
        return not getattr(record, "skip_stdout", False)
