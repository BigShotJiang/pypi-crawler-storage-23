import json
import logging
import os
import subprocess
import sys

from orangeqs.juice.schemas.runtime import JuiceServicesInfo, PackageInfo, ServiceInfo

_logger = logging.getLogger(__name__)


def _retrieve_package_list() -> dict[str, PackageInfo]:
    """Retrieve a dictionary of locally installed packages.

    This function retrieves a list of installed packages using either `uv` or `pip`.
    If all methods fail, it raises a RuntimeError with details of the failures.

    Returns
    -------
        dict: A dictionary mapping package names to their details.

    Raises
    ------
        RuntimeError: If all methods to retrieve the package list fail.
    """
    # Mapping of method => (command, cwd)
    methods = {
        "uv": (
            ["uv", "pip", "list", "--format", "json"],
            os.environ.get("UV_PROJECT", None),
        ),
        "pip": (
            [sys.executable, "-m", "pip", "list", "--local", "--format", "json"],
            None,
        ),
    }

    def _retrieve_with_kwargs(
        method: str, args: list[str], cwd: str | None
    ) -> dict[str, PackageInfo]:
        """Attempt to retrieve package list using the specified method."""
        try:
            result = subprocess.run(
                args,
                stdout=subprocess.PIPE,
                text=True,
                check=True,
                cwd=cwd,
            )
            data = json.loads(result.stdout)
            return {
                package_info["name"]: PackageInfo(
                    version=package_info["version"],
                    editable_project_location=package_info.get(
                        "editable_project_location"
                    ),
                )
                for package_info in data
            }
        except json.JSONDecodeError as e:
            raise RuntimeError(
                f"Failed to parse package info from {method} JSON output."
            ) from e
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to run pip list using {method}") from e

    exceptions: list[tuple[str, RuntimeError]] = []
    for method, args in methods.items():
        try:
            return _retrieve_with_kwargs(method, *args)
        except RuntimeError as e:
            exceptions.append((method, e))

    errors = "\n".join(f"Using {method} raised: {e}" for method, e in exceptions)

    raise RuntimeError(
        f"All methods for retrieving package list failed.\n{errors}\n"
        "Please ensure that the required tools are installed and accessible."
    )


def store_service_info(service_name: str) -> None:
    """Store OrangeQS Juice service information in the shared runtime data folder.

    Retrieves information about the currently running service and stores it under the
    given service name in the shared runtime data folder.

    Parameters
    ----------
    service_name : str
        The name of the currently running service to store information for.
    """
    system_info = JuiceServicesInfo(
        services={
            service_name: ServiceInfo(
                user_installed_packages=_retrieve_package_list(),
            )
        }
    )
    system_info.store(key=service_name, exist_ok=True)
