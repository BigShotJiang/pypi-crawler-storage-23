"""Documentation utilities for OrangeQS Juice.

Provides Sphinx directives for documenting {class}`~.settings.Configurable` classes.
"""

import importlib.util

if (
    importlib.util.find_spec("sphinx") is None
    or importlib.util.find_spec("docutils") is None
):
    raise ImportError(
        "The 'sphinx' feature is required for documentation generation. "
        "Please install `orangeqs-juice-core[sphinx]`."
    )

from sphinx.application import Sphinx
from sphinx.util.typing import ExtensionMetadata

from ._domain import ConfigDomain


def setup(app: Sphinx) -> ExtensionMetadata:
    app.add_domain(ConfigDomain)

    return {
        "version": "0.1",
        "parallel_read_safe": True,
        "parallel_write_safe": True,
    }
