"""Common types and models used in OrangeQS schemas."""

from typing import Annotated

from pydantic import Field

PortNumber = Annotated[int, Field(gt=0, lt=1 << 16)]
"""Valid TCP port number."""
