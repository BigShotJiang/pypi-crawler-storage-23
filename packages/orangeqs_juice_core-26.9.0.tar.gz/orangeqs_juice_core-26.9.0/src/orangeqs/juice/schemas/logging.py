"""Schemas for Logging Configuration."""

import logging
from collections import defaultdict
from typing import Annotated, ClassVar

from pydantic import Field

from orangeqs.juice.database import Point
from orangeqs.juice.settings import BaseConfigurable, Configurable


class LogEvent(Point):
    """Log Event Point."""

    measurement: ClassVar[str] = "logs"
    """Measurement name for log events."""

    service: Annotated[str, "tag"]
    """OrangeQS Juice Service which generated the log message ."""

    level: Annotated[int, "tag"]
    """Level of the log message."""

    serialized_record: str
    """The serialized python log record."""


class ServiceLoggingConfig(BaseConfigurable):
    """Logging Configuration of a single Service."""

    log_level_influxdb: int = logging.INFO
    """Log level of the InfluxDB logger of the service."""

    log_level_stdout: int = logging.INFO
    """Log level of the stdout logger of the service."""


class ServiceLoggingConfigs(Configurable):
    """
    Centralized logging configuration for all Juice services.

    By default, all services inherit the same logging settings, which can be
    customized for individual services as needed. Each service logs to both
    InfluxDB2 and stdout, with handlers set to capture messages at `INFO` level
    and above by default.

    You can review logs via the dashboard or by using
    {meth}`Client.display_service_logs
    <orangeqs.juice.client.Client.display_service_logs>`

    WARNING: A service must be restarted for changes to its logging configuration
    to take effect.
    """

    filename: ClassVar[str] = "service-logging"

    bucket_name: str = "service_logs"
    """Name of the InfluxDB bucket to log to."""

    services: defaultdict[
        str,
        Annotated[ServiceLoggingConfig, Field(default_factory=ServiceLoggingConfig)],
    ] = Field(default_factory=lambda: defaultdict(ServiceLoggingConfig))
    """Logging configuration for each service."""
