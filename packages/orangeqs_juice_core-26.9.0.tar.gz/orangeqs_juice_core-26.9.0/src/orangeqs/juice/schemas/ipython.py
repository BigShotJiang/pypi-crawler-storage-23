"""IPython related schemas."""

from typing import ClassVar, Literal

from pydantic import BaseModel, Field

from orangeqs.juice.settings import Configurable, RuntimeData

from .common import PortNumber


class IPythonKernelConfigs(Configurable):
    """Configurations for IPython kernels of all services.

    IPython kernels in OrangeQS Juice services use the default configuration of IPython
    if not configured here. This means that the kernel will use a random key and ports
    by default.

    This configuration allows to override the default IPython configuration.
    """

    filename: ClassVar[str] = "ipykernel"

    services: dict[str, "KernelConnectionInfo"] = Field(default_factory=dict)
    """IPython kernel configuration for all services."""


class KernelConnectionInfo(BaseModel):
    """IPython kernel connection of a single service.

    This schema is compatible with the connection info used by IPython, for example
    {meth}`jupyter_client.client.KernelClient.load_connection_info`.
    """

    shell_port: PortNumber | None = None
    """IPython shell port."""

    iopub_port: PortNumber | None = None
    """IPython IOPub port."""

    stdin_port: PortNumber | None = None
    """IPython standard input port."""

    control_port: PortNumber | None = None
    """IPython control port."""

    hb_port: PortNumber | None = None
    """IPython heartbeat port."""

    key: str | None = None
    """Communication secret key."""

    ip: str | None = None
    """IP address service listens, or the hostname that will resolve to IP address."""

    transport: Literal["tcp", "ipc"] | None = None
    """IPython transport."""

    signature_scheme: str | None = None
    """IPython communication signature scheme."""


class KernelConnectionRegistry(RuntimeData):
    """Registry of IPython kernel connection information for all services.

    IPython services store their connection information in this registry on start.
    IPython clients use this registry to load the connection information
    for the service they want to connect to.
    The registry is stored in the shared runtime data directory
    """

    filename: ClassVar[str] = "ipykernel-connection"

    services: dict[str, "KernelConnectionInfo"] = Field(default_factory=dict)
    """Kernel connection information for all services."""
