"""An operating system for testing, characterizing and operating quantum chips."""

from . import client, schemas, settings
from ._version import __version__ as __version__
from .client import Client

__all__ = [
    "Client",
    "client",
    "settings",
    "__version__",
    "schemas",
]
