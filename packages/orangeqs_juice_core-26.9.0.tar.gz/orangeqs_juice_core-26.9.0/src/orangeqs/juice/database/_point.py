"""Base class for time-series data points."""

import logging
import typing
from collections.abc import Mapping
from datetime import datetime, timezone
from functools import partial
from typing import Any, ClassVar, Literal, cast

import numpy as np
import pandas as pd
from influxdb_client import Point as InfluxDBPoint
from influxdb_client import QueryApi, WriteApi
from influxdb_client.client.query_api_async import QueryApiAsync
from influxdb_client.client.write_api_async import WriteApiAsync
from pydantic import BaseModel, Field
from typing_extensions import Self

_DataType = str | int | float | bool | list[str] | list[int] | list[float] | list[bool]
_FilterType = Mapping[str, _DataType]

_logger = logging.getLogger(__name__)


class Point(BaseModel):
    """
    Base class for time-series data points used to store and query data from InfluxDB.

    Subclassing this class defines a schema for a specific measurement. This schema
    class can be used to store and query data from InfluxDB. The schema is based on
    a {class}`pydantic.BaseModel`, so all pydantic features are available.

    This base class follows two additional conventions:
    - By default, all fields are stored as InfluxDB fields. To mark a field as a tag,
      annotate the type using the string `"tag"`,
      e.g. `field: typing.Annotated[str, "tag"]`.
    - Every subclass must define a `measurement` class variable, which specifies the
      InfluxDB measurement name, e.g. `measurement: typing.ClassVar[str] = "some_name"`.

    Also see [schema design best practices](https://docs.influxdata.com/influxdb/v2/write-data/best-practices/schema-design/)
    in the InfluxDB documentation, especially regarding the use of tags vs. fields.

    Examples
    --------
    This example shows:
    - How to define a schema for a specific measurement.
    - How to store a record.
    - How to query it from the database.

    ```python
    from typing import Annotated, ClassVar
    from datetime import datetime
    from orangeqs.juice.database import Point

    # Define a schema
    class SomeEvent(Point):
        measurement: ClassVar[str] = "some_event"

        event_id: Annotated[str, "tag"]
        value: float

    # Writing the event to InfluxDB
    event = SomeEvent(event_id="event123", value=42.0)
    event.write(write_api, bucket="my_bucket")

    # Querying events from InfluxDB
    events = SomeEvent.query(
        query_api,
        bucket="my_bucket",
        filters={"event_id": "event123"},
        limit=10
    )
    ```
    """

    # TODO: Should we make the bucket part of the schema definition?

    measurement: ClassVar[str]
    """
    Name of the InfluxDB measurement. Must be unique and defined in every subclass.
    """

    time: datetime = Field(default_factory=partial(datetime.now, tz=timezone.utc))
    """
    The timestamp of the data point. Defaults to the current time in UTC.
    """

    __record_field_keys__: ClassVar[set[str]]
    __record_tag_keys__: ClassVar[set[str]]

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """Determine which model fields are InfluxDB tags and fields."""
        # Called after pydantic model construction
        super().__pydantic_init_subclass__(**kwargs)
        cls.__record_field_keys__ = set()
        cls.__record_tag_keys__ = set()
        for key, field in cls.model_fields.items():
            # Skip special fields
            if key in ("measurement", "time"):
                continue

            # Check if field is annotated with Annotated[..., "tag"]
            if hasattr(field, "metadata") and "tag" in field.metadata:
                cls.__record_tag_keys__.add(key)
                continue

            # Otherwise, assume it's a field.
            cls.__record_field_keys__.add(key)

    def to_influxdb2(self) -> InfluxDBPoint:
        """
        Convert the Point instance to an InfluxDB Point.

        Returns
        -------
        influxdb_client.Point
            The corresponding InfluxDB Point object.
        """
        return InfluxDBPoint.from_dict(
            self.model_dump(),
            record_measurement_name=self.measurement,
            record_field_keys=self.__record_field_keys__,
            record_tag_keys=self.__record_tag_keys__,
            record_time_key="time",
        )

    def write(self, write_api: WriteApi, bucket: str, **kwargs: Any) -> None:  # noqa: ANN401
        """
        Write the Point instance to InfluxDB.

        Parameters
        ----------
        write_api : influxdb_client.WriteApi
            The InfluxDB WriteApi instance.
        bucket : str
            The target bucket in InfluxDB.
        **kwargs : Any
            Additional keyword arguments to pass to the `WriteApi.write()` method.
        """
        point = self.to_influxdb2()
        write_api.write(bucket=bucket, record=point, **kwargs)  # pyright: ignore[reportUnknownMemberType]

    async def write_async(
        self,
        write_api: WriteApiAsync,
        bucket: str,
        **kwargs: Any,  # noqa: ANN401
    ) -> None:
        """
        Write the Point instance to InfluxDB.

        Parameters
        ----------
        write_api : influxdb_client.WriteApiAsync
            The InfluxDB WriteApiAsync instance.
        bucket : str
            The target bucket in InfluxDB.
        **kwargs : Any
            Additional keyword arguments to pass to the `WriteApiAsync.write()` method.
        """
        point = self.to_influxdb2()
        await write_api.write(bucket=bucket, record=point, **kwargs)  # pyright: ignore[reportUnknownMemberType]

    @typing.overload
    @classmethod
    def query(
        cls,
        query_api: QueryApi,
        bucket: str,
        output: Literal["dataframe"],
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> pd.DataFrame: ...
    @typing.overload
    @classmethod
    def query(
        cls,
        query_api: QueryApi,
        bucket: str,
        output: Literal["list"] = "list",
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> list[Self]: ...

    @classmethod
    def query(
        cls,
        query_api: QueryApi,
        bucket: str,
        output: Literal["list", "dataframe"] = "list",
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> list[Self] | pd.DataFrame:
        """
        Query the database for all points of this type based on filters.

        Parameters
        ----------
        query_api : influxdb_client.QueryApi
            The InfluxDB QueryApi instance.
        bucket : str
            The target bucket in InfluxDB.
        output : "list" or "dataframe", optional
            The output format: "list" returns a list of instances of `Self`,
            "dataframe" returns a pandas DataFrame (default is "list").
        filters : dict[str, str | int | float | bool | list[str | int | float | bool]]
            A dictionary of filters to apply. The keys correspond to field or tag names,
            and the values can be a single value or a list of values for "OR" filtering.
            All filters are combined with "AND".
            Defaults to None, which means no filtering.
            For example, the filter `{"name": ["a", "b"], "color": "blue"}` corresponds
            to `(name == "a" or name == "b") and (color == "blue")`.
        limit : int, optional
            The maximum number of records per series key to return. Defaults to 100.
            A series key is a unique combination of tag values.
            See [series](https://docs.influxdata.com/influxdb/v2/reference/key-concepts/data-elements/#series)
            in the InfluxDB documentation for more information.
        start : str, optional
            The start time for the query in InfluxDB time format.
            Defaults to "-1h" (last hour).
        stop : str, optional
            The stop time for the query in InfluxDB time format.
            Defaults to "now()".
        sort : "asc", "desc" or None, optional
            The sort order for the results based on time.
            If None, no sorting is applied. Defaults to "desc".

        Returns
        -------
        list[Self] | pd.DataFrame
            A collection of `Self` instances or a DataFrame if `output="dataframe"`.
        """
        query = _build_query(cls, bucket, filters, limit, start, stop, sort)

        _logger.debug("Running InfluxDB query:\n%s", query)

        df = cast(
            "pd.DataFrame | list[pd.DataFrame]",
            query_api.query_data_frame(query),  # pyright: ignore[reportUnknownMemberType]
        )

        return _process_result(df, cls, output=output)

    @typing.overload
    @classmethod
    async def query_async(
        cls,
        query_api: QueryApiAsync,
        bucket: str,
        output: Literal["dataframe"],
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> pd.DataFrame: ...
    @typing.overload
    @classmethod
    async def query_async(
        cls,
        query_api: QueryApiAsync,
        bucket: str,
        output: Literal["list"] = "list",
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> list[Self]: ...

    @classmethod
    async def query_async(
        cls,
        query_api: QueryApiAsync,
        bucket: str,
        output: Literal["list", "dataframe"] = "list",
        filters: _FilterType | None = None,
        limit: int = 100,
        start: str = "-1h",
        stop: str = "now()",
        sort: Literal["asc", "desc", None] = "desc",
    ) -> list[Self] | pd.DataFrame:
        """
        Query the database for all points of this type based on filters.

        Parameters
        ----------
        query_api : influxdb_client.QueryApiAsync
            The InfluxDB QueryApiAsync instance.
        bucket : str
            The target bucket in InfluxDB.
        output : "list" or "dataframe", optional
            The output format: "list" returns a list of instances of `Self`,
            "dataframe" returns a pandas DataFrame (default is "list").
        filters : dict[str, str | int | float | bool | list[str | int | float | bool]]
            A dictionary of filters to apply. The keys correspond to field or tag names,
            and the values can be a single value or a list of values for "OR" filtering.
            All filters are combined with "AND".
            Defaults to None, which means no filtering.
            For example, the filter `{"name": ["a", "b"], "color": "blue"}` corresponds
            to `(name == "a" or name == "b") and (color == "blue")`.
        limit : int, optional
            The maximum number of records per series key to return. Defaults to 100.
            A series key is a unique combination of tag values.
            See [series](https://docs.influxdata.com/influxdb/v2/reference/key-concepts/data-elements/#series)
            in the InfluxDB documentation for more information.
        start : str, optional
            The start time for the query in InfluxDB time format.
            Defaults to "-1h" (last hour).
        stop : str, optional
            The stop time for the query in InfluxDB time format.
            Defaults to "now()".
        sort : "asc", "desc" or None, optional
            The sort order for the results based on time.
            If None, no sorting is applied. Defaults to "desc".

        Returns
        -------
        list[Self] | pd.DataFrame
            A collection of `Self` instances or a DataFrame if `output="dataframe"`.
        """
        query = _build_query(cls, bucket, filters, limit, start, stop, sort)

        _logger.debug("Running InfluxDB query:\n%s", query)

        df = cast(
            "pd.DataFrame | list[pd.DataFrame]",
            await query_api.query_data_frame(query),  # pyright: ignore[reportUnknownMemberType]
        )

        return _process_result(df, cls, output=output)


_Point = typing.TypeVar("_Point", bound=Point)


@typing.overload
def _process_result(
    df: pd.DataFrame | list[pd.DataFrame],
    cls: type[_Point],
    output: Literal["dataframe"],
) -> pd.DataFrame: ...
@typing.overload
def _process_result(
    df: pd.DataFrame | list[pd.DataFrame],
    cls: type[_Point],
    output: Literal["list"] = "list",
) -> list[_Point]: ...


def _process_result(
    df: pd.DataFrame | list[pd.DataFrame],
    cls: type[_Point],
    output: Literal["list", "dataframe"] = "list",
) -> list[_Point] | pd.DataFrame:
    if isinstance(df, list):
        # This happens if the model has fields that can be stored as different
        # types in InfluxDB, e.g. an optional field. We try to concatenate the tables,
        # as this is still likely to be a valid result.
        try:
            df = pd.concat(df, ignore_index=True)
        except Exception as e:
            raise ValueError(
                "Query returned multiple tables that could not be concatenated."
            ) from e
    if df.empty:
        if output == "dataframe":
            return pd.DataFrame(columns=list(cls.model_fields.keys()))
        return []

    df.rename(columns={"_time": "time"}, inplace=True)

    # TODO: This should be revisited when we use query_raw instead of query_data_frame.
    # Starting from Pandas 3.0, np.nan is used for all missing string values.
    # This causes issues with pydantic model validation, which expects either None or
    # an empty string for missing string values. To fix this, we replace np.nan with
    # empty strings for string columns. Usually this would be bad practice, but in this
    # specific case it's fine to do, as InfluxDB does not distinguish between missing
    # string values and empty strings.
    # See https://pandas.pydata.org/docs/user_guide/migration-3-strings.html
    for col in df.select_dtypes(include=["object", "string"]):
        # We also include "object" to handle the case when all values are None
        # and to support pandas 2.x. This will break if numpy dtypes are used in
        # the dataframe, but InfluxDB does not do that.
        df[col] = df[col].replace({pd.NA: "", np.nan: "", None: ""})

    model_fields = set(cls.model_fields)
    columns = set(df.columns)
    extra_fields = columns - model_fields
    if extra_fields:
        df.drop(columns=extra_fields, inplace=True)
    missing_fields = model_fields - columns
    for field in missing_fields:
        # Use the default from the model
        model_default = cls.model_fields[field].default
        df[field] = model_default

    if output == "dataframe":
        return df
    records = df.to_dict(orient="records")  # pyright: ignore[reportUnknownMemberType]
    return [cls.model_validate(record) for record in records]


def _build_query(
    cls: type[Point],
    bucket: str,
    filters: _FilterType | None,
    limit: int,
    start: str,
    stop: str,
    sort: Literal["asc", "desc", None],
) -> str:
    """Build the InfluxDB Flux query string based on parameters.

    See {meth}`~.Point.query()` for parameter descriptions.
    """
    query = (
        f'from(bucket: "{bucket}")\n'
        f"  |> range(start: {start}, stop: {stop})\n"
        f'  |> filter(fn: (r) => r._measurement == "{cls.measurement}")\n'
    )
    tag_filters: _FilterType = {}
    field_filters: _FilterType = {}
    # Separate tag and field filters
    for key, value in (filters or {}).items():
        if key in cls.__record_tag_keys__:
            tag_filters[key] = value
        elif key in cls.__record_field_keys__:
            field_filters[key] = value
        else:
            raise ValueError(
                f"Cannot apply filter on field '{key}'. "
                f"Schema of '{cls}' does not contain this field.",
            )

    for key, value in tag_filters.items():
        query += f"  |> filter({_format_filter(key, value)})\n"

    query += (
        '  |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")\n'
    )

    for key, value in field_filters.items():
        query += f"  |> filter({_format_filter(key, value)})\n"

    if sort:
        desc = _format_value(sort == "desc")
        query += f'  |> sort(columns: ["_time"], desc: {desc})\n'
    query += f"  |> limit(n: {limit})"
    return query


def _format_value(value: _DataType | list[_DataType]) -> str:
    if isinstance(value, list):
        return "[" + ",".join(_format_value(v) for v in value) + "]"
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _format_filter(key: str, value: _DataType | list[_DataType]) -> str:
    if isinstance(value, list):
        return f'fn: (r) => contains(value: r["{key}"], set: {_format_value(value)})'
    else:
        return f'fn: (r) => r["{key}"] == {_format_value(value)}'
