"""Database functionality based on InfluxDB2.

OrangeQS Juice integrates with an [InfluxDB2](https://docs.influxdata.com/influxdb/v2/get-started/)
database for storing time series data.
This module provides the {class}`Point` base class, which can be subclassed to define
schemas for specific measurements.

See {ref}`extensions-database` for an interactive guide on how to use the database.
"""

from ._point import Point

__all__ = ["Point"]
