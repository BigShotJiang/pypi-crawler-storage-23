# OrangeQS Juice

![OrangeQS Juice Logo](https://gitlab.com/orangeqs/juice/-/raw/main/docs/source/images/logo_landscape.svg)

[![Latest release](https://gitlab.com/orangeqs/juice/-/badges/release.svg)](https://gitlab.com/orangeqs/juice/-/releases)
[![PyPI](https://img.shields.io/pypi/v/orangeqs-juice-core.svg)](https://pypi.org/project/orangeqs-juice-core/)
[![Apache 2.0 License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://gitlab.com/orangeqs/juice/-/blob/main/LICENSE)
[![Documentation](https://img.shields.io/badge/Documentation-green)](https://docs.orangeqs.com/juice/core)

**OrangeQS Juice** is an operating system designed to control quantum test systems, developed and maintained by Orange Quantum Systems.

OrangeQS Juice provides a robust and scalable platform for managing and automating quantum device testing. It is built to integrate seamlessly with a variety of quantum hardware and measurement instruments.

For full installation and usage instructions, please visit our official [documentation](https://docs.orangeqs.com/juice/core).

## Installation

See the [Installation guide](https://docs.orangeqs.com/juice/core/tutorials/getting-started/installation.html).

## License

This project is licensed under the Apache 2.0 License.

## Contributing

See the [Contributing guide](https://docs.orangeqs.com/juice/core/contribute/).

## Contact

For questions, support, or commercial inquiries, please contact us at juice@orangeqs.com.
