"""Tests for the capabilities subpackage."""
