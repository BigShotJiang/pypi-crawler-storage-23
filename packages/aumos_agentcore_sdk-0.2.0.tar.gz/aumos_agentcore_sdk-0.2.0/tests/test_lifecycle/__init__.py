"""Tests for the lifecycle subpackage."""
