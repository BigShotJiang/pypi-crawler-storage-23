"""Tests for the bridges subpackage."""
