# SPDX-FileCopyrightText: 2024-present santosh <void@some.where>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
