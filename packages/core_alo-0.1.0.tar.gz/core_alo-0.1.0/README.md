# core-alo

Reusable core functionality (utils, mixins, services) for FastAPI applications — avoids copy-pasting common patterns across services.

## Features

- **Configuration**: Pydantic Settings-based config management (env vars, CORS, DB, email, Keycloak, GCS)
- **Authentication**: Keycloak OpenID Connect integration with FastAPI dependency injection
- **Database**: SQLAlchemy 2.0 base models, session management, and audit mixins
- **Services**: Generic CRUD base service with user-scoped queries and audit field auto-population
- **Mixins**: FastAPI class-based view mixins (user, admin, API key, OTLP token)
- **Storage**: Google Cloud Storage abstraction with presigned URL support
- **Email**: SMTP email utilities with Jinja2 template rendering
- **Exceptions**: Common HTTP exception classes (404, 403)
- **Schemas**: Pydantic v2 schemas for users, audit fields, and email attachments

## Installation

```bash
pip install core-alo
```

## Requirements

- Python 3.13+
- FastAPI >= 0.115
- SQLAlchemy >= 2.0
- Pydantic >= 2.11

## Usage

```python
from core_alo.config import settings
from core_alo.models import BaseModel, AuditModelMixin
from core_alo.services import BaseService
from core_alo.mixins import UserCBVMixin, AdminCBVMixin
from core_alo.exceptions import HTTPNotFoundException
```

## License

MIT — Copyright (c) 2025 Alomana
