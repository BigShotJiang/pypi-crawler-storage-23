import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import emails  # type: ignore
from emails.backend.response import Response
from jinja2 import Template
from pydantic import BaseModel
from .schemas import EmailAttachment

from .config import Settings, settings as default_settings
from . import logger


@dataclass
class EmailData:
    html_content: str
    subject: str


def render_email_template(*, template_name: str, context: dict[str, Any]) -> str:
    template_str = (
        Path(__file__).parent / "email-templates" / "build" / template_name
    ).read_text()
    html_content = Template(template_str).render(context)
    return html_content


def send_email(
    *,
    email_to: str,
    subject: str = "",
    html_content: str = "",
    attachments: list[EmailAttachment] | None = None,
    settings: Settings = default_settings,
) -> Response:
    assert settings.emails_enabled, "no provided configuration for email variables"
    message: emails.Message = emails.Message(
        subject=subject,
        html=html_content,
        mail_from=(settings.EMAILS_FROM_NAME, settings.EMAILS_FROM_EMAIL),
    )

    # Add attachments if provided
    attachments = attachments or []
    for attachment in attachments:
        message.attach(
            filename=attachment.filename,
            data=attachment.data,
            content_type=attachment.content_type,
        )

    smtp_options = {"host": settings.SMTP_HOST, "port": settings.SMTP_PORT}
    if settings.SMTP_TLS:
        smtp_options["tls"] = True
    elif settings.SMTP_SSL:
        smtp_options["ssl"] = True
    if settings.SMTP_USER:
        smtp_options["user"] = settings.SMTP_USER
    if settings.SMTP_PASSWORD:
        smtp_options["password"] = settings.SMTP_PASSWORD
    response = message.send(to=email_to, smtp=smtp_options)

    # logger.info(f"smtp options: {smtp_options}")
    logger.info(f"send email result: {response}")
    return response


# Custom implementation for sqlmodel_update for sqlalchemy
def sqlmodel_update(
    self,
    obj: dict[str, Any] | BaseModel,
    update: dict[str, Any] | None = None,
):
    use_update = (update or {}).copy()
    if isinstance(obj, dict):
        for key, value in {**obj, **use_update}.items():
            if key in self.__table__.columns.keys():
                setattr(self, key, value)
    elif isinstance(obj, BaseModel):
        for key in obj.model_fields:
            if key in use_update:
                value = use_update.pop(key)
            else:
                value = getattr(obj, key)
            setattr(self, key, value)
        for remaining_key in use_update:
            if remaining_key in self.__table__.columns.keys():
                value = use_update.pop(remaining_key)
                setattr(self, remaining_key, value)
    else:
        raise ValueError(
            "Can't use sqlmodel_update() with something that "
            f"is not a dict or SQLModel or Pydantic model: {obj}"
        )
    return self
