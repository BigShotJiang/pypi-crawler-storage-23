import logging
from typing import Callable
from urllib.request import Request
from urllib import parse

from fastapi import Depends, HTTPException, Security, WebSocketException, status
from fastapi.security import OAuth2PasswordBearer
from keycloak import KeycloakOpenID

from .schemas import KeycloakUser, UserPublic
from .constants import DEFAULT_ADMIN_GROUP, ErrorMsgs
from .config import Settings, settings


oauth2_scheme = OAuth2PasswordBearer(tokenUrl=settings.AUTH_TOKEN_URL)

keycloak_openid = KeycloakOpenID(
    server_url=settings.OIDC_SERVER_URL,  # https://sso.example.com/auth/
    client_id=settings.OIDC_CLIENT_ID,  # backend-client-id
    realm_name=settings.OIDC_REALM,  # example-realm
    client_secret_key=settings.OIDC_CLIENT_SECRET,  # your backend client secret
    verify=True,
)


async def login_endpoint(request: Request):
    try:
        # TODO: review this
        text = await request.body()
        text = text.decode()
        qs = parse.parse_qs(text)
        username = request.query_params.get("username", qs.get("username")[0])
        password = request.query_params.get("password", qs.get("password")[0])
        code = request.query_params.get(
            "code", qs.get("code")[0] if qs.get("code") else ""
        )
        token = keycloak_openid.token(
            username, password, totp=code if code != "" else None
        )

        return token
    except Exception as e:
        str(e)
        logging.error(f"[keycloak_auth.login_endpoint] Error: {e}")
        raise HTTPException(status_code=401, detail="Invalid credentials")


def get_payload(token: str, ws: bool = False):
    try:
        # Decodes the JWT token using the python-keycloak library
        user_info = keycloak_openid.userinfo(token)
        logging.info(f"[keycloak_auth.get_payload] User info: {user_info}")
        if "error" in user_info:
            raise HTTPException(status_code=401, detail="Invalid token")
        return user_info
    except Exception as e:
        if ws:
            raise WebSocketException(
                code=status.WS_1008_POLICY_VIOLATION,
                reason=ErrorMsgs.INVALID_AUTH_CREDENTIALS,
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=ErrorMsgs.INVALID_AUTH_CREDENTIALS,
            headers={"WWW-Authenticate": "Bearer"},
        ) from e


def get_user_info(payload: dict, ws: bool = False) -> KeycloakUser:
    try:
        return KeycloakUser(
            id=payload.get("sub"),
            username=payload.get("preferred_username"),
            email=payload.get("email"),
            first_name=payload.get("given_name"),
            last_name=payload.get("family_name"),
            realm_roles=payload.get("realm_roles", []),
            groups=payload.get("groups", []),
        )
    except Exception as e:
        if ws:
            raise WebSocketException(
                code=status.WS_1008_POLICY_VIOLATION,
                reason=str(e),
            )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),  # "Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


# Dependencies
async def get_payload_dep(token: str = Security(oauth2_scheme)) -> dict:
    return get_payload(token)


async def get_user_info_dep(payload: dict = Depends(get_payload_dep)) -> KeycloakUser:
    return get_user_info(payload)


def get_current_user(
    user_info: KeycloakUser = Depends(get_user_info_dep),
) -> UserPublic:
    user = UserPublic.model_validate(user_info.model_dump())
    user._keycloak_user = user_info
    return user


def get_current_active_admin_user(
    keycloak_user: KeycloakUser = Depends(get_user_info_dep),
) -> UserPublic:
    current_user = UserPublic.model_validate(keycloak_user.model_dump())
    current_user._keycloak_user = keycloak_user
    groups = keycloak_user.groups or []
    if DEFAULT_ADMIN_GROUP not in groups:
        raise HTTPException(
            status_code=403, detail="The user doesn't have enough privileges"
        )
    return current_user


def get_current_user_no_auth() -> None:
    return None


def get_auth_deps(settings: Settings) -> Callable:
    if settings.AUTH_TYPE == "oidc":
        return get_current_user
    else:
        return get_current_user_no_auth
