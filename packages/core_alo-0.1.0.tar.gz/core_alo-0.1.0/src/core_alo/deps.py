import secrets
from typing import Annotated

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

from .config import settings
from .db import SessionLocal, get_db


SessionDep = Annotated[SessionLocal, Depends(get_db)]

# Define security schemes for better OpenAPI documentation
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)


def verify_api_key(
    api_key: Annotated[str | None, Security(api_key_header)] = None,
) -> str:
    """Verify API key using constant-time comparison to prevent timing attacks."""
    if api_key is None or not secrets.compare_digest(api_key, settings.API_KEY):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    return api_key


def verify_otlp_token(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Security(bearer_scheme)
    ] = None,
) -> str:
    """Verify OTLP bearer token using constant-time comparison to prevent timing attacks."""
    if credentials is None or not secrets.compare_digest(
        credentials.credentials, settings.OTEL_EXPORTER_OTLP_HEADERS.split("=")[1]
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid OTLP token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return credentials.credentials
