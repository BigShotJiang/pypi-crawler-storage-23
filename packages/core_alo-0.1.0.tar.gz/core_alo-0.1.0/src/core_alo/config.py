import json
import warnings
from pathlib import Path
from typing import Annotated, Any, Literal

from pydantic import (
    AnyUrl,
    BeforeValidator,
    PostgresDsn,
    computed_field,
    model_validator,
)
from pydantic_core import MultiHostUrl
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing_extensions import Self


def parse_cors(v: Any) -> list[str] | str:
    if isinstance(v, str) and not v.startswith("["):
        return [i.strip() for i in v.split(",")]
    elif isinstance(v, list | str):
        return v
    raise ValueError(v)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_ignore_empty=True,
        extra="ignore",
    )

    # Core
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "changethis"
    ENVIRONMENT: Literal["local", "staging", "production"] = "local"
    ROOT_PATH: Path = Path(__file__).parent
    STATIC_PATH: Path = ROOT_PATH / "static"
    FRONTEND_HOST: str = "http://localhost:3000"
    API_KEY: str = ""

    # OpenTelemetry
    OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: str = ""
    OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: str = ""
    OTEL_EXPORTER_OTLP_LOGS_ENDPOINT: str = ""
    OTEL_EXPORTER_OTLP_HEADERS: str = ""

    BACKEND_CORS_ORIGINS: Annotated[
        list[AnyUrl] | str, BeforeValidator(parse_cors)
    ] = []

    @computed_field  # type: ignore[prop-decorator]
    @property
    def all_cors_origins(self) -> list[str]:
        if self.ENVIRONMENT == "local":
            return ["*"]
        return [str(origin).rstrip("/") for origin in self.BACKEND_CORS_ORIGINS] + [
            self.FRONTEND_HOST
        ]

    PROJECT_NAME: str = "Alomana Core"
    PROJECT_TECHNICAL_NAME: str = "alomana_core"

    # DB
    POSTGRES_SERVER: str = ""
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = ""
    POSTGRES_PASSWORD: str = ""
    POSTGRES_DB: str = ""

    @computed_field  # type: ignore[prop-decorator]
    @property
    def SQLALCHEMY_DATABASE_URI(self) -> PostgresDsn | None:
        if not self.POSTGRES_SERVER:
            return None
        return MultiHostUrl.build(
            scheme="postgresql+psycopg",
            username=self.POSTGRES_USER,
            password=self.POSTGRES_PASSWORD,
            host=self.POSTGRES_SERVER,
            port=self.POSTGRES_PORT,
            path=self.POSTGRES_DB,
        )

    # Email
    SMTP_TLS: bool = True
    SMTP_SSL: bool = False
    SMTP_PORT: int = 587
    SMTP_HOST: str | None = None
    SMTP_USER: str | None = None
    SMTP_PASSWORD: str | None = None
    EMAILS_FROM_EMAIL: str | None = None
    EMAILS_FROM_NAME: str | None = "Alomana"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def emails_enabled(self) -> bool:
        return bool(self.SMTP_HOST and self.EMAILS_FROM_EMAIL)

    def _check_default_secret(self, var_name: str, value: str | None) -> None:
        if value == "changethis":
            message = (
                f'The value of {var_name} is "changethis", '
                "for security, please change it, at least for deployments."
            )
            if self.ENVIRONMENT == "local":
                warnings.warn(message, stacklevel=1)
            else:
                raise ValueError(message)

    @model_validator(mode="after")
    def _enforce_non_default_secrets(self) -> Self:
        self._check_default_secret("SECRET_KEY", self.SECRET_KEY)
        return self

    # Keycloak OIDC
    AUTH_TYPE: Literal["oidc", "none"] = "oidc"
    AUTH_TOKEN_URL: str = "auth/token"
    OIDC_CLIENT_ID: str = ""
    OIDC_CLIENT_SECRET: str = ""
    OIDC_ISSUER: str = "http://localhost:7080/realms/central_hub"
    OIDC_REALM: str = "central_hub"
    OIDC_ADMIN_EMAIL: str = "admin"
    OIDC_ADMIN_PWD: str = "admin"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OIDC_SERVER_URL(self) -> str:
        return self.OIDC_ISSUER.replace(f"/realms/{self.OIDC_REALM}", "")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OIDC_BASE_URL(self) -> str:
        return f"{self.OIDC_ISSUER}/protocol/openid-connect"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OIDC_TOKEN_URL(self) -> str:
        return f"{self.OIDC_BASE_URL}/token"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OIDC_AUTH_URL(self) -> str:
        return f"{self.OIDC_BASE_URL}/auth"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OIDC_CERTS_URL(self) -> str:
        return f"{self.OIDC_BASE_URL}/certs"

    # AI
    OPENAI_API_KEY: str = ""
    GEMINI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""

    # Google Cloud
    GC_PROJECT: str = ""
    GC_CREDENTIALS_JSON: str = ""

    @property
    def GC_CREDENTIALS_DICT(self) -> dict[str, Any]:
        return json.loads(self.GC_CREDENTIALS_JSON)


settings = Settings()
