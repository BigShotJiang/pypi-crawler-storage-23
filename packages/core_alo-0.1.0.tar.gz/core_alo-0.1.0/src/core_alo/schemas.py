from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class TimeAuditSchemaMixin(BaseModel):
    created_at: datetime | None = None
    updated_at: datetime | None = None


class UserAuditSchemaMixin(BaseModel):
    created_by_id: int | None = None
    # created_by: Optional["UserPublic"] = None
    # created_by: Any | None = None
    updated_by_id: int | None = None
    # updated_by: Any | None = None


class AuditSchemaMixin(TimeAuditSchemaMixin, UserAuditSchemaMixin):
    pass


# Generic message response
class ResponseMessage(BaseModel):
    detail: str


class BaseSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int | str | None = None


class UserBase(BaseSchema):
    email: EmailStr = Field(max_length=255)
    username: str = Field(max_length=255)
    is_active: bool = True
    is_superuser: bool = False
    first_name: str | None = Field(None, max_length=255)
    last_name: str | None = Field(None, max_length=255)


class UserCreate(UserBase):
    pass


class UserPublic(AuditSchemaMixin, UserBase):
    _keycloak_user: Optional["KeycloakUser"] = None


class KeycloakUser(BaseModel):
    id: str
    username: str
    email: EmailStr
    first_name: str
    last_name: str
    realm_roles: list[str] = Field(default_factory=list)
    groups: list[str] = Field(default_factory=list)


class EmailAttachment(BaseModel):
    filename: str
    data: bytes
    content_type: str
