from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .config import settings


# Some agents don't need a database, so we mock the yield
if settings.SQLALCHEMY_DATABASE_URI:
    engine = create_engine(str(settings.SQLALCHEMY_DATABASE_URI))
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
else:
    SessionLocal = lambda: None


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        if db:
            db.close()
