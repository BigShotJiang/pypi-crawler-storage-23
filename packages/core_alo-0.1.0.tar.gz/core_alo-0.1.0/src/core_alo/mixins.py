from typing import ClassVar

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from .deps import get_db, verify_api_key, verify_otlp_token
from .keycloak_auth import get_current_active_admin_user, get_current_user
from .schemas import UserPublic
from .services import BaseService


class BaseCBVMixin:
    db: Session = Depends(get_db)
    request: Request

    service_class: ClassVar[type[BaseService]]

    def get_service(self):
        return self.service_class(
            self.db, user=getattr(self, "user", None), request=self.request
        )


class UserCBVMixin(BaseCBVMixin):
    user: UserPublic = Depends(get_current_user)


class AdminCBVMixin(BaseCBVMixin):
    user: UserPublic = Depends(get_current_active_admin_user)


class ApiTokenCBVMixin(BaseCBVMixin):
    api_key: str = Depends(verify_api_key)


class OtlpTokenCBVMixin(BaseCBVMixin):
    otlp_token: str = Depends(verify_otlp_token)
