import logging
from datetime import timedelta
import uuid
from collections.abc import Sequence
from typing import BinaryIO, Optional, TypeVar, Union

from fastapi import Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session
from google.cloud import storage
from google.oauth2 import service_account
from keycloak import KeycloakOpenIDConnection, KeycloakAdmin

from .config import Settings, settings
from .models import BaseModel
from .utils import sqlmodel_update
from .schemas import UserPublic
from .exceptions import HTTPNotFoundException

ModelType = TypeVar("ModelType", bound=BaseModel)


# TODO: improve/change this
class BaseService:
    model: type[ModelType]

    def __init__(
        self,
        db: Session,
        request: Request | None = None,
        user: UserPublic | None = None,
    ):
        self.db = db
        self.request = request
        self.user = user

    def get_object(
        self,
        obj_id: int | uuid.UUID | None = None,
        raise404: bool = True,
        filters: tuple = (),
        model: type[ModelType] | None = None,
    ):
        model = model or self.model
        if obj_id:
            filters = (*filters, model.id == obj_id)

        obj: ModelType = self.db.scalars(select(model).where(*filters)).first()
        if not obj and raise404:
            raise HTTPNotFoundException(item=f"{model.__name__}")
        return obj

    def get_objects(
        self,
        filters: tuple = (),
        model: type[ModelType] | None = None,
        order_by: tuple = (),
    ):
        model = model or self.model
        return self.db.scalars(select(model).where(*filters).order_by(*order_by)).all()

    def create_object(
        self,
        payload,
        update: dict | None = None,
        model: type[ModelType] | None = None,
        commit: bool = True,
    ):
        model = model or self.model

        update = update or {}
        if hasattr(model, "created_by_id"):
            update["created_by_id"] = getattr(self.user, "id", None)
            update["updated_by_id"] = getattr(self.user, "id", None)

        obj = model(**{**payload.model_dump(mode="json"), **update})
        # obj = model.model_validate(payload, update=update)
        self.db.add(obj)
        if commit:
            self.db.commit()
            self.db.refresh(obj)
        else:
            self.db.flush()
        return obj

    def update_object(
        self,
        payload,
        obj_id: int | uuid.UUID | None = None,
        obj=None,
        update: dict | None = None,
        model: type[ModelType] | None = None,
        filters: tuple = (),
        commit: bool = True,
    ):
        update = update or {}
        if hasattr(model, "updated_by_id"):
            update["updated_by_id"] = getattr(self.user, "id", None)

        model = model or self.model
        obj = obj if obj else self.get_object(obj_id, model=model, filters=filters)

        obj_data = payload.model_dump(exclude_unset=True)
        obj = sqlmodel_update(obj, obj=obj_data, update=update)
        self.db.add(obj)
        if commit:
            self.db.commit()
            self.db.refresh(obj)
        else:
            self.db.flush()
        return obj

    def delete_object(
        self,
        obj_id: int | uuid.UUID | None = None,
        obj=None,
        model: type[ModelType] | None = None,
        filters: tuple = (),
        commit: bool = True,
    ):
        model = model or self.model
        obj = obj if obj else self.get_object(obj_id, model=model, filters=filters)

        self.db.delete(obj)
        if commit:
            self.db.commit()
        else:
            self.db.flush()
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    def get_user_objects(
        self,
        user_id: int,
        filters: tuple = (),
        model: type[ModelType] | None = None,
    ) -> Sequence[ModelType]:
        filters = (*filters, self.model.created_by_id == user_id)
        return self.get_objects(filters, model)


class BaseStorage:
    def upload_file(self, *args, **kwargs) -> str:
        raise NotImplementedError

    def get_file(self, *args, **kwargs) -> bytes:
        raise NotImplementedError

    def delete_file(self, *args, **kwargs) -> bool:
        raise NotImplementedError

    def get_presigned_url(self, *args, **kwargs) -> str:
        raise NotImplementedError

    def get_presigned_urls(self, *args, **kwargs) -> dict[str, str]:
        raise NotImplementedError


class GCStorage(BaseStorage):
    def __init__(self, bucket_name: str, settings: Settings):
        self.bucket_name = bucket_name

        credentials = service_account.Credentials.from_service_account_info(
            settings.GC_CREDENTIALS_DICT
        )
        self.client = storage.Client(credentials=credentials)
        self.bucket = self.client.bucket(bucket_name)

    def upload_file(
        self,
        source: Union[BinaryIO, bytes],
        destination_path: str,
        content_type: Optional[str] = None,
    ) -> str:
        blob = self.bucket.blob(destination_path)
        blob.upload_from_string(source, content_type=content_type)
        return f"gs://{self.bucket_name}/{destination_path}"

    def get_presigned_url(
        self, file_path: str, expires_in_minutes: int = 10, method: str = "GET"
    ) -> str:
        """Generate a presigned URL for a file"""
        file_path = self.preprocess_file_path(file_path)
        blob = self.bucket.blob(file_path)

        # Generate a signed URL that expires in the specified minutes
        url = blob.generate_signed_url(
            version="v4",
            expiration=timedelta(minutes=expires_in_minutes),
            method=method,
        )
        return url

    def get_presigned_urls(
        self,
        prefix: str = "",
        expires_in_minutes: int = 10,
    ) -> dict[str, str]:
        """Generate presigned URLs for multiple files with a given prefix"""
        blobs = self.client.list_blobs(self.bucket, prefix=prefix)

        urls = {}
        for blob in blobs:
            url = blob.generate_signed_url(
                version="v4",
                expiration=timedelta(minutes=expires_in_minutes),
                method="GET",
            )
            urls[blob.name] = url

        return urls

    def get_file(self, file_path: str) -> bytes:
        file_path = self.preprocess_file_path(file_path)
        blob = self.bucket.blob(file_path)
        if not blob.exists():
            raise HTTPNotFoundException(item=f"File: {file_path}")
        return blob.download_as_bytes()

    def file_exists(self, file_path: str) -> bool:
        file_path = self.preprocess_file_path(file_path)
        blob = self.bucket.blob(file_path)
        return blob.exists()

    def delete_file(self, file_path: str) -> bool:
        file_path = self.preprocess_file_path(file_path)
        blob = self.bucket.blob(file_path)
        if blob.exists():
            blob.delete()
            return True
        return False

    def list_files(self, prefix: str = "", limit: int | None = None) -> list[str]:
        blobs = self.client.list_blobs(self.bucket, prefix=prefix, max_results=limit)
        return [blob.name for blob in blobs]

    def preprocess_file_path(self, file_path: str) -> bool:
        if file_path.startswith("gs://"):
            file_path = file_path.replace(f"gs://{self.bucket_name}/", "")
        return file_path


class KeycloakService:
    """Service for interacting with Keycloak admin API to manage clients."""

    def __init__(self):
        keycloak_connection = KeycloakOpenIDConnection(
            server_url=settings.OIDC_SERVER_URL,
            username=settings.OIDC_ADMIN_EMAIL,
            password=settings.OIDC_ADMIN_PWD,
            realm_name=settings.OIDC_REALM,
            user_realm_name=settings.OIDC_REALM,
            client_id=settings.OIDC_CLIENT_ID,
            client_secret_key=settings.OIDC_CLIENT_SECRET,
            verify=True,
        )

        self.keycloak_url = settings.OIDC_SERVER_URL
        self.admin_user = settings.OIDC_ADMIN_EMAIL
        self.admin_password = settings.OIDC_ADMIN_PWD
        self.realm_name = settings.OIDC_REALM

        logging.info(f"Attempting to connect to Keycloak at {self.keycloak_url}")
        self.admin = KeycloakAdmin(connection=keycloak_connection)

    def get_all_realm_roles(self) -> list:
        """Get all realm roles"""
        return self.admin.get_realm_roles()
