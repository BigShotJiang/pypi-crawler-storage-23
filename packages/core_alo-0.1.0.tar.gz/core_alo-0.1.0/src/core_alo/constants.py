from enum import StrEnum

DEFAULT_ADMIN_GROUP = "admins"


class ErrorMsgs(StrEnum):
    DEFAULT_ERROR_MSG = "Something went wrong."
    ITEM_NOT_FOUND = "{item} Not found."
    INVALID_VALUE_PROVIDED = (
        "The {entity} is invalid. Allowed: {allowed}. Provided: {provided}."
    )
    INVALID_ENTITY = "The {entity} is invalid."
    INVALID_AUTH_CREDENTIALS = "Invalid authentication credentials."
    FORBIDDEN_ACCESS = (
        "Access forbidden. You don't have permission to access this resource."
    )
