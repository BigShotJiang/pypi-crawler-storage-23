from datetime import UTC, datetime
from typing import Any, Optional

from sqlalchemy import DateTime, ForeignKey, Integer
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    declared_attr,
    mapped_column,
    relationship,
)


class BaseModel(DeclarativeBase):
    id: Mapped[int] = mapped_column(primary_key=True)


class TimeAuditModelMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(UTC), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        nullable=False,
    )


class UserAuditModelMixin:
    @declared_attr.directive
    def created_by_id(cls) -> Mapped[int | None]:
        return mapped_column(Integer, ForeignKey("user.id"), nullable=True)

    @declared_attr.directive
    def updated_by_id(cls) -> Mapped[int | None]:
        return mapped_column(Integer, ForeignKey("user.id"), nullable=True)

    # TODO: if want to see corect return annotation of these fields,
    #   need to overwrite return annotation in child class
    @declared_attr.directive
    def created_by(cls) -> Mapped[Optional[Any]]:
        return relationship(
            "User",
            foreign_keys=[cls.created_by_id],
            primaryjoin=f"{cls.__name__}.created_by_id == User.id",
            uselist=False,
        )

    @declared_attr.directive
    def updated_by(cls) -> Mapped[Optional[Any]]:
        return relationship(
            "User",
            foreign_keys=[cls.updated_by_id],
            primaryjoin=f"{cls.__name__}.updated_by_id == User.id",
            uselist=False,
        )


class AuditModelMixin(TimeAuditModelMixin, UserAuditModelMixin):
    pass
