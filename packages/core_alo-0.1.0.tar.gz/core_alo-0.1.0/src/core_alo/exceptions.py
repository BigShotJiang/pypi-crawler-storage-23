from fastapi import HTTPException

from .constants import ErrorMsgs


class DefaultHTTPException(HTTPException):
    def __init__(
        self,
        status_code: int = 400,
        detail: str = ErrorMsgs.DEFAULT_ERROR_MSG,
        headers: dict | None = None,
    ):
        super().__init__(status_code, detail, headers)


class HTTPNotFoundException(HTTPException):
    def __init__(
        self, status_code: int = 404, item: str = "Item", headers: dict | None = None
    ):
        super().__init__(
            status_code, ErrorMsgs.ITEM_NOT_FOUND.format(item=item), headers
        )


class HTTPForbiddenException(HTTPException):
    def __init__(
        self,
        status_code: int = 403,
        detail: str = ErrorMsgs.FORBIDDEN_ACCESS,
        headers: dict | None = None,
    ):
        super().__init__(status_code, detail, headers)
