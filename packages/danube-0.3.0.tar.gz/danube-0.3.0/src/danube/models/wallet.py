"""Wallet models for the Danube SDK."""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class WalletBalance(BaseModel):
    """User's wallet balance."""

    balance_cents: int = 0
    balance_dollars: float = 0.0
    lifetime_spent_cents: int = 0
    lifetime_deposited_cents: int = 0

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "WalletBalance":
        return cls(
            balance_cents=data.get("balance_cents", 0),
            balance_dollars=data.get("balance_dollars", 0.0),
            lifetime_spent_cents=data.get("lifetime_spent_cents", 0),
            lifetime_deposited_cents=data.get("lifetime_deposited_cents", 0),
        )


class WalletTransaction(BaseModel):
    """A wallet transaction record."""

    id: str = ""
    type: str = ""
    amount_cents: int = 0
    balance_after_cents: int = 0
    reference_id: Optional[str] = None
    metadata: Dict[str, Any] = {}
    created_at: Optional[str] = None

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "WalletTransaction":
        return cls(
            id=data.get("id", ""),
            type=data.get("type", ""),
            amount_cents=data.get("amount_cents", 0),
            balance_after_cents=data.get("balance_after_cents", 0),
            reference_id=data.get("reference_id"),
            metadata=data.get("metadata", {}),
            created_at=data.get("created_at"),
        )
