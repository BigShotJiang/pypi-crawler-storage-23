"""Credential models for the Danube SDK."""

from typing import Any, Dict

from pydantic import BaseModel


class CredentialStoreResult(BaseModel):
    """Result from storing a credential."""

    success: bool = False
    service_id: str = ""
    service_name: str = ""
    credential_type: str = ""

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "CredentialStoreResult":
        return cls(
            success=data.get("success", False),
            service_id=data.get("service_id", ""),
            service_name=data.get("service_name", ""),
            credential_type=data.get("credential_type", ""),
        )
