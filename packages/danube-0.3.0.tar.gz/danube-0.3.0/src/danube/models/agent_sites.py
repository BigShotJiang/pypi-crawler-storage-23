"""Agent Web models for the Danube SDK.

Models for the Agent Web feature, which crawls websites across multiple pages
and extracts rich structured data (identity, products, team, blog, jobs,
contact, about, services, docs, pricing, faq, legal, navigation) for AI agents.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SiteComponents(BaseModel):
    """Structured components extracted from a website via Agent Web.

    Up to 13 component types are extracted via multi-page crawling:
    identity, products, team, blog, jobs, contact, about, services,
    docs, pricing, faq, legal, navigation.
    """

    contact: Optional[Dict[str, Any]] = None
    about: Optional[Dict[str, Any]] = None
    services: Optional[List[Dict[str, Any]]] = None
    docs: Optional[Dict[str, Any]] = None
    pricing: Optional[Dict[str, Any]] = None
    faq: Optional[List[Dict[str, Any]]] = None
    legal: Optional[Dict[str, Any]] = None
    navigation: Optional[List[Dict[str, Any]]] = None
    identity: Optional[Dict[str, Any]] = None
    products: Optional[List[Dict[str, Any]]] = None
    team: Optional[List[Dict[str, Any]]] = None
    blog: Optional[List[Dict[str, Any]]] = None
    jobs: Optional[List[Dict[str, Any]]] = None


class AgentSite(BaseModel):
    """An agent-friendly site with structured components."""

    id: str
    domain: str
    url: str
    status: str = "pending"
    page_title: Optional[str] = None
    page_description: Optional[str] = None
    favicon_url: Optional[str] = None
    components: SiteComponents = Field(default_factory=SiteComponents)
    discovered_tools: List[Dict[str, Any]] = Field(default_factory=list)
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    service_id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "AgentSite":
        components_data = data.get("components", {})
        components = SiteComponents(**components_data) if isinstance(components_data, dict) else SiteComponents()

        return cls(
            id=data.get("id", ""),
            domain=data.get("domain", ""),
            url=data.get("url", ""),
            status=data.get("status", "pending"),
            page_title=data.get("page_title"),
            page_description=data.get("page_description"),
            favicon_url=data.get("favicon_url"),
            components=components,
            discovered_tools=data.get("discovered_tools", []),
            category=data.get("category"),
            tags=data.get("tags", []),
            service_id=data.get("service_id"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


class AgentSiteListItem(BaseModel):
    """Summary of a site for directory listings."""

    id: str
    domain: str
    page_title: Optional[str] = None
    page_description: Optional[str] = None
    favicon_url: Optional[str] = None
    category: Optional[str] = None
    component_count: int = 0
    tool_count: int = 0
    status: str = "pending"

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "AgentSiteListItem":
        return cls(
            id=data.get("id", ""),
            domain=data.get("domain", ""),
            page_title=data.get("page_title"),
            page_description=data.get("page_description"),
            favicon_url=data.get("favicon_url"),
            category=data.get("category"),
            component_count=data.get("component_count", 0),
            tool_count=data.get("tool_count", 0),
            status=data.get("status", "pending"),
        )
