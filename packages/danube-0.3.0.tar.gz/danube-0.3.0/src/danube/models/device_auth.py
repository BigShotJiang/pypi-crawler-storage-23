"""Device auth models for the Danube SDK."""

from typing import Any, Dict

from pydantic import BaseModel


class DeviceCode(BaseModel):
    """Response from initiating a device auth flow."""

    device_code: str = ""
    user_code: str = ""
    verification_url: str = ""
    expires_in: int = 600
    interval: int = 5

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "DeviceCode":
        return cls(
            device_code=data.get("device_code", ""),
            user_code=data.get("user_code", ""),
            verification_url=data.get("verification_url", data.get("verification_uri", "")),
            expires_in=data.get("expires_in", 600),
            interval=data.get("interval", 5),
        )


class DeviceToken(BaseModel):
    """Response from polling for a device token."""

    api_key: str = ""
    key_prefix: str = ""

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "DeviceToken":
        return cls(
            api_key=data.get("api_key", ""),
            key_prefix=data.get("key_prefix", ""),
        )
