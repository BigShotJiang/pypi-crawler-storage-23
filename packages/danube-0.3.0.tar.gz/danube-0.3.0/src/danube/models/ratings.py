"""Rating models for the Danube SDK."""

from typing import Any, Dict, Optional

from pydantic import BaseModel


class ToolRating(BaseModel):
    """A user's rating for a tool."""

    tool_id: str = ""
    rating: int = 0
    comment: Optional[str] = None
    created_at: Optional[str] = None

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "ToolRating":
        return cls(
            tool_id=data.get("tool_id", ""),
            rating=data.get("rating", 0),
            comment=data.get("comment"),
            created_at=data.get("created_at"),
        )


class RatingAggregate(BaseModel):
    """Aggregated ratings for a tool."""

    tool_id: str = ""
    average_rating: float = 0.0
    total_ratings: int = 0
    rating_distribution: Dict[str, int] = {}

    model_config = {"extra": "ignore"}

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "RatingAggregate":
        return cls(
            tool_id=data.get("tool_id", ""),
            average_rating=data.get("average_rating", 0.0),
            total_ratings=data.get("total_ratings", 0),
            rating_distribution=data.get("rating_distribution", {}),
        )
