"""Models for agent registration and commerce."""

from typing import Any, Dict, Optional


class AgentRegistration:
    """Result of registering a new autonomous agent."""

    def __init__(
        self,
        agent_id: str,
        api_key: str,
        wallet_id: str,
        balance_usdc: str,
        deposit_address: Optional[str] = None,
        registration_url: str = "",
    ):
        self.agent_id = agent_id
        self.api_key = api_key
        self.wallet_id = wallet_id
        self.balance_usdc = balance_usdc
        self.deposit_address = deposit_address
        self.registration_url = registration_url

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "AgentRegistration":
        return cls(
            agent_id=data.get("agent_id", ""),
            api_key=data.get("api_key", ""),
            wallet_id=data.get("wallet_id", ""),
            balance_usdc=data.get("balance_usdc", "0.000000"),
            deposit_address=data.get("deposit_address"),
            registration_url=data.get("registration_url", ""),
        )

    def __repr__(self) -> str:
        return f"AgentRegistration(agent_id='{self.agent_id}', wallet_id='{self.wallet_id}')"


class AgentInfo:
    """Agent profile and wallet information."""

    def __init__(
        self,
        agent_id: str,
        name: str,
        agent_type: str,
        operator_email: Optional[str] = None,
        wallet: Optional[Dict[str, Any]] = None,
        deposit_address: Optional[str] = None,
        registration_url: str = "",
        created_at: str = "",
    ):
        self.agent_id = agent_id
        self.name = name
        self.agent_type = agent_type
        self.operator_email = operator_email
        self.wallet = wallet or {}
        self.deposit_address = deposit_address
        self.registration_url = registration_url
        self.created_at = created_at

    @property
    def balance_usdc(self) -> str:
        return self.wallet.get("balance_usdc", "0.000000")

    @property
    def balance_atomic(self) -> int:
        return self.wallet.get("balance_atomic", 0)

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "AgentInfo":
        return cls(
            agent_id=data.get("agent_id", ""),
            name=data.get("name", ""),
            agent_type=data.get("agent_type", ""),
            operator_email=data.get("operator_email"),
            wallet=data.get("wallet"),
            deposit_address=data.get("deposit_address"),
            registration_url=data.get("registration_url", ""),
            created_at=data.get("created_at", ""),
        )

    def __repr__(self) -> str:
        return f"AgentInfo(agent_id='{self.agent_id}', name='{self.name}', balance='{self.balance_usdc}')"


class AgentFundResult:
    """Result of a wallet funding request."""

    def __init__(
        self,
        wallet_id: str,
        method: str,
        checkout_url: Optional[str] = None,
        deposit_address: Optional[str] = None,
        network: Optional[str] = None,
        usdc_contract: Optional[str] = None,
        balance_usdc: str = "0.000000",
    ):
        self.wallet_id = wallet_id
        self.method = method
        self.checkout_url = checkout_url
        self.deposit_address = deposit_address
        self.network = network
        self.usdc_contract = usdc_contract
        self.balance_usdc = balance_usdc

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "AgentFundResult":
        return cls(
            wallet_id=data.get("wallet_id", ""),
            method=data.get("method", ""),
            checkout_url=data.get("checkout_url"),
            deposit_address=data.get("deposit_address"),
            network=data.get("network"),
            usdc_contract=data.get("usdc_contract"),
            balance_usdc=data.get("balance_usdc", "0.000000"),
        )

    def __repr__(self) -> str:
        return f"AgentFundResult(method='{self.method}', balance='{self.balance_usdc}')"
