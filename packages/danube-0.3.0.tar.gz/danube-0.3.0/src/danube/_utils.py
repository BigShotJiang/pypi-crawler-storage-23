"""Internal utilities for the Danube SDK."""

import uuid
from typing import Optional


def is_valid_uuid(value: str) -> bool:
    """Check if a string is a valid UUID.

    Args:
        value: String to check.

    Returns:
        True if the string is a valid UUID, False otherwise.
    """
    try:
        uuid.UUID(str(value))
        return True
    except (ValueError, AttributeError):
        return False


def clean_id(value: Optional[str]) -> Optional[str]:
    """Clean a potential ID value by stripping quotes and whitespace.

    Args:
        value: String to clean.

    Returns:
        Cleaned string, or None if input was None.
    """
    if value is None:
        return None
    return value.strip().strip('"').strip("'")
