"""Configuration for the Danube SDK."""

import os
from dataclasses import dataclass, field
from typing import Optional


DEFAULT_BASE_URL = "https://api.danubeai.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3


@dataclass
class DanubeConfig:
    """Configuration for the Danube client.

    Attributes:
        api_key: Danube API key. Falls back to DANUBE_API_KEY env var.
        base_url: API base URL. Defaults to https://api.danubeai.com
        timeout: Request timeout in seconds.
        max_retries: Number of retries for failed requests.
        verify_ssl: Whether to verify SSL certificates.
        user_agent: Custom user agent string.
    """

    api_key: str = field(default_factory=lambda: os.environ.get("DANUBE_API_KEY", ""))
    base_url: str = field(
        default_factory=lambda: os.environ.get("DANUBE_API_URL", DEFAULT_BASE_URL)
    )
    timeout: float = field(
        default_factory=lambda: float(
            os.environ.get("DANUBE_TIMEOUT", str(DEFAULT_TIMEOUT))
        )
    )
    max_retries: int = field(
        default_factory=lambda: int(
            os.environ.get("DANUBE_MAX_RETRIES", str(DEFAULT_MAX_RETRIES))
        )
    )
    verify_ssl: bool = True
    user_agent: str = "danube-python-sdk/0.2.0"

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        # Ensure base_url doesn't have trailing slash
        self.base_url = self.base_url.rstrip("/")

    def validate(self) -> None:
        """Validate that required configuration is present.

        Raises:
            ValueError: If API key is missing.
        """
        if not self.api_key:
            raise ValueError(
                "API key required. Set DANUBE_API_KEY environment variable "
                "or pass api_key parameter."
            )

    @classmethod
    def from_env(cls) -> "DanubeConfig":
        """Create configuration from environment variables.

        Returns:
            DanubeConfig instance populated from environment.
        """
        return cls()

    def with_overrides(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> "DanubeConfig":
        """Create a new config with specific overrides.

        Args:
            api_key: Override API key.
            base_url: Override base URL.
            timeout: Override timeout.
            max_retries: Override max retries.

        Returns:
            New DanubeConfig with overrides applied.
        """
        return DanubeConfig(
            api_key=api_key if api_key is not None else self.api_key,
            base_url=base_url if base_url is not None else self.base_url,
            timeout=timeout if timeout is not None else self.timeout,
            max_retries=max_retries if max_retries is not None else self.max_retries,
            verify_ssl=self.verify_ssl,
            user_agent=self.user_agent,
        )
