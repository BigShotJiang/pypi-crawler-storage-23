"""Danube AI Python SDK.

A Python SDK for interacting with the Danube AI API, providing access
to services, tools, skills, and user identity management.

Example usage:
    from danube import DanubeClient

    # Synchronous usage
    with DanubeClient(api_key="dk_...") as client:
        services = client.services.list()
        result = client.tools.execute(tool_name="Weather - Get Current")

    # Async usage
    from danube import AsyncDanubeClient

    async with AsyncDanubeClient(api_key="dk_...") as client:
        services = await client.services.list()
        result = await client.tools.execute(tool_name="Weather - Get Current")
"""

__version__ = "0.3.0"

# Main clients
from danube.async_client import AsyncDanubeClient
from danube.client import DanubeClient

# Configuration
from danube.config import DanubeConfig

# Exceptions
from danube.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConfigurationRequiredError,
    DanubeConnectionError,
    DanubeError,
    DanubeTimeoutError,
    ExecutionError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)

# Models
from danube.models import (
    APIKeyPermissions,
    APIKeyResponse,
    APIKeyWithSecret,
    AgentSite,
    AgentSiteListItem,
    Contact,
    CredentialStoreResult,
    DeviceCode,
    DeviceToken,
    Identity,
    Parameter,
    RatingAggregate,
    Service,
    ServiceToolsResult,
    ServiceType,
    SiteComponents,
    Skill,
    SkillContent,
    SkillFile,
    SpendingLimits,
    Tool,
    ToolRating,
    ToolResult,
    WalletBalance,
    WalletTransaction,
    WebhookCreateResponse,
    WebhookDeliveryResponse,
    WebhookResponse,
    Workflow,
    WorkflowDetail,
    WorkflowExecution,
    WorkflowStep,
    WorkflowStepResult,
)

__all__ = [
    # Version
    "__version__",
    # Clients
    "DanubeClient",
    "AsyncDanubeClient",
    # Configuration
    "DanubeConfig",
    # Exceptions
    "DanubeError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ExecutionError",
    "ConfigurationRequiredError",
    "DanubeConnectionError",
    "DanubeTimeoutError",
    # Models - Services
    "Service",
    "ServiceToolsResult",
    "ServiceType",
    # Models - Tools
    "Tool",
    "Parameter",
    "ToolResult",
    # Models - Skills
    "Skill",
    "SkillContent",
    "SkillFile",
    # Models - Identity
    "Identity",
    "Contact",
    # Models - Workflows
    "Workflow",
    "WorkflowDetail",
    "WorkflowStep",
    "WorkflowStepResult",
    "WorkflowExecution",
    # Models - Agent Sites
    "AgentSite",
    "AgentSiteListItem",
    "SiteComponents",
    # Models - Wallet
    "WalletBalance",
    "WalletTransaction",
    # Models - Ratings
    "ToolRating",
    "RatingAggregate",
    # Models - API Keys
    "APIKeyPermissions",
    "APIKeyResponse",
    "APIKeyWithSecret",
    "SpendingLimits",
    # Models - Webhooks
    "WebhookResponse",
    "WebhookCreateResponse",
    "WebhookDeliveryResponse",
    # Models - Credentials
    "CredentialStoreResult",
    # Models - Device Auth
    "DeviceCode",
    "DeviceToken",
]
