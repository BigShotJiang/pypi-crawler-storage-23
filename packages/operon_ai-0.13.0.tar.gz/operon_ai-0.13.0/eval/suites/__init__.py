"""Evaluation suites for the synthetic harness."""
