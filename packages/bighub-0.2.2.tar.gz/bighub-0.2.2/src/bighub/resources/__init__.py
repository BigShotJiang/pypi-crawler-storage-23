# Resource namespaces exposed via top-level clients.
