from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import httpx

from .auth import build_auth_headers
from .exceptions import BighubAPIError, BighubAuthError, BighubNetworkError, BighubTimeoutError


def _join_url(base_url: str, path: str) -> str:
    return f"{base_url.rstrip('/')}/{path.lstrip('/')}"


def _should_retry(status_code: Optional[int], exc: Optional[Exception]) -> bool:
    if exc is not None:
        return isinstance(exc, (httpx.ConnectError, httpx.ReadError, httpx.RemoteProtocolError))
    if status_code is None:
        return False
    return status_code in (408, 409, 425, 429) or 500 <= status_code <= 599


@dataclass
class RetryConfig:
    max_retries: int = 2
    backoff_base: float = 0.25
    backoff_cap: float = 2.5

    def backoff(self, attempt: int) -> float:
        # Exponential backoff + bounded jitter.
        delay = min(self.backoff_cap, self.backoff_base * (2 ** max(0, attempt - 1)))
        return delay + random.uniform(0.0, min(0.25, delay / 2))


def build_headers(
    *,
    api_key: Optional[str],
    bearer_token: Optional[str],
    user_agent: str,
    extra_headers: Optional[Dict[str, str]] = None,
    idempotency_key: Optional[str] = None,
) -> Dict[str, str]:
    headers = {"User-Agent": user_agent, "Accept": "application/json"}
    headers.update(build_auth_headers(api_key=api_key, bearer_token=bearer_token))
    if extra_headers:
        headers.update(extra_headers)
    if idempotency_key:
        headers["Idempotency-Key"] = idempotency_key
    return headers


def parse_response_or_raise(response: httpx.Response) -> Dict[str, Any]:
    content_type = response.headers.get("content-type", "")
    body: Dict[str, Any] = {}
    if "application/json" in content_type:
        try:
            body = response.json()
        except Exception:
            body = {}

    if 200 <= response.status_code < 300:
        return body

    if response.status_code in (401, 403):
        detail = body.get("detail") if isinstance(body, dict) else None
        raise BighubAuthError(str(detail or "Unauthorized"))

    detail = body.get("detail") if isinstance(body, dict) else None
    request_id = None
    if isinstance(body, dict):
        request_id = body.get("request_id") or body.get("validation_id")
        if not request_id:
            err = body.get("error")
            if isinstance(err, dict):
                request_id = err.get("request_id")
    code = None
    if isinstance(detail, dict):
        code = detail.get("code")
    raise BighubAPIError(
        message=response.reason_phrase or "API error",
        status_code=response.status_code,
        request_id=request_id,
        code=code,
        detail=detail,
        response_body=body if body else None,
    )


class SyncTransport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str],
        bearer_token: Optional[str],
        timeout: float,
        retry: RetryConfig,
        user_agent: str,
    ) -> None:
        self.base_url = base_url
        self.api_key = api_key
        self.bearer_token = bearer_token
        self.timeout = timeout
        self.retry = retry
        self.user_agent = user_agent
        self._client = httpx.Client(timeout=timeout)

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        *,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        url = _join_url(self.base_url, path)
        req_headers = build_headers(
            api_key=self.api_key,
            bearer_token=self.bearer_token,
            user_agent=self.user_agent,
            extra_headers=headers,
            idempotency_key=idempotency_key,
        )

        last_exc: Optional[Exception] = None
        for attempt in range(1, self.retry.max_retries + 2):
            status_code: Optional[int] = None
            try:
                response = self._client.request(
                    method=method.upper(),
                    url=url,
                    params=params,
                    json=json_body,
                    headers=req_headers,
                )
                status_code = response.status_code
                if _should_retry(status_code=status_code, exc=None) and attempt <= self.retry.max_retries:
                    time.sleep(self.retry.backoff(attempt))
                    continue
                return parse_response_or_raise(response)
            except httpx.TimeoutException as exc:
                if attempt <= self.retry.max_retries:
                    time.sleep(self.retry.backoff(attempt))
                    continue
                raise BighubTimeoutError(f"Request timed out: {method.upper()} {path}") from exc
            except httpx.RequestError as exc:
                last_exc = exc
                if _should_retry(status_code=status_code, exc=exc) and attempt <= self.retry.max_retries:
                    time.sleep(self.retry.backoff(attempt))
                    continue
                raise BighubNetworkError(f"Network error: {method.upper()} {path}") from exc

        raise BighubNetworkError(f"Request failed after retries: {method.upper()} {path}") from last_exc


class AsyncTransport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str],
        bearer_token: Optional[str],
        timeout: float,
        retry: RetryConfig,
        user_agent: str,
    ) -> None:
        self.base_url = base_url
        self.api_key = api_key
        self.bearer_token = bearer_token
        self.timeout = timeout
        self.retry = retry
        self.user_agent = user_agent
        self._client = httpx.AsyncClient(timeout=timeout)

    async def close(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        *,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        url = _join_url(self.base_url, path)
        req_headers = build_headers(
            api_key=self.api_key,
            bearer_token=self.bearer_token,
            user_agent=self.user_agent,
            extra_headers=headers,
            idempotency_key=idempotency_key,
        )

        last_exc: Optional[Exception] = None
        for attempt in range(1, self.retry.max_retries + 2):
            status_code: Optional[int] = None
            try:
                response = await self._client.request(
                    method=method.upper(),
                    url=url,
                    params=params,
                    json=json_body,
                    headers=req_headers,
                )
                status_code = response.status_code
                if _should_retry(status_code=status_code, exc=None) and attempt <= self.retry.max_retries:
                    await asyncio.sleep(self.retry.backoff(attempt))
                    continue
                return parse_response_or_raise(response)
            except httpx.TimeoutException as exc:
                if attempt <= self.retry.max_retries:
                    await asyncio.sleep(self.retry.backoff(attempt))
                    continue
                raise BighubTimeoutError(f"Request timed out: {method.upper()} {path}") from exc
            except httpx.RequestError as exc:
                last_exc = exc
                if _should_retry(status_code=status_code, exc=exc) and attempt <= self.retry.max_retries:
                    await asyncio.sleep(self.retry.backoff(attempt))
                    continue
                raise BighubNetworkError(f"Network error: {method.upper()} {path}") from exc

        raise BighubNetworkError(f"Request failed after retries: {method.upper()} {path}") from last_exc
