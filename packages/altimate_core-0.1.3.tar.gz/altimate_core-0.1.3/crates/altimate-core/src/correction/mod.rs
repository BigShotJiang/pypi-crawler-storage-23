//! Iterative correction protocol.
//!
//! Implements the "propose-verify-refine" loop for agentic text-to-SQL:
//! validate → fix → lint → re-validate, tracking all iterations and
//! computing a quality score for the final result.

pub mod engine;
pub mod types;
