//! Types for dbt integration.

use serde::{Deserialize, Serialize};

/// A dbt model extracted from a project.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbtModel {
    /// Model name (file stem)
    pub name: String,
    /// Relative path to the model file
    pub path: String,
    /// Raw SQL content (with Jinja stripped)
    pub sql: String,
    /// Original SQL content (with Jinja)
    pub raw_sql: String,
    /// Materialization type
    #[serde(skip_serializing_if = "Option::is_none")]
    pub materialization: Option<String>,
    /// Model description from schema.yml
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    /// Referenced models (ref() calls)
    pub refs: Vec<String>,
    /// Referenced sources (source() calls)
    pub sources: Vec<DbtSourceRef>,
}

/// A dbt source reference.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbtSourceRef {
    pub source_name: String,
    pub table_name: String,
}

/// Result of parsing a dbt project.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbtProject {
    /// Project name
    pub name: String,
    /// Models found
    pub models: Vec<DbtModel>,
    /// Model dependency order (topological sort)
    pub build_order: Vec<String>,
    /// Parsing warnings
    pub warnings: Vec<String>,
}
