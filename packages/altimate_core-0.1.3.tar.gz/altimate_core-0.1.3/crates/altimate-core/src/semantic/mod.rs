//! Semantic validation module.
//!
//! Detects SQL queries that are syntactically valid but logically wrong.
//! Uses DataFusion logical plan analysis combined with schema metadata
//! (foreign keys, primary keys) to detect issues like:
//!
//! - Cartesian products (missing JOIN conditions)
//! - Wrong JOIN keys (not matching FK relationships)
//! - Aggregate/GROUP BY mismatches
//! - WHERE vs HAVING confusion
//! - Duplicate counting after one-to-many JOINs
//! - NULL-unsafe comparisons (`= NULL` instead of `IS NULL`)
//! - And more
//!
//! # Example
//!
//! ```rust,no_run
//! use altimate_core::semantic::engine::check_semantics;
//! use altimate_core::SchemaDefinition;
//!
//! # async fn example() {
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//! let result = check_semantics("SELECT * FROM users, orders", &schema).await;
//! assert!(!result.findings.is_empty());
//! # }
//! ```

pub mod engine;
pub mod rules;
pub mod types;
