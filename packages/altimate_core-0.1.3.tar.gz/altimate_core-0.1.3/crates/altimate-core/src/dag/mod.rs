//! SQL visualization DAG generation.
//!
//! Decomposes a SQL query into a directed acyclic graph of structural nodes
//! (tables, joins, filters, groups, subqueries) for visual representation.
//!
//! # Example
//!
//! ```no_run
//! use altimate_core::dag::build_dag;
//! use polyglot_sql::dialects::DialectType;
//!
//! let result = build_dag(
//!     "WITH cte AS (SELECT id FROM t) SELECT * FROM cte",
//!     DialectType::Snowflake,
//! ).unwrap();
//! assert!(result.ctes.contains(&"cte".to_string()));
//! ```

pub mod engine;
pub mod types;

pub use engine::{build_dag, build_dag_with_schema};
pub use types::{DagColumn, DagNode, DagResult, TableSchema};
