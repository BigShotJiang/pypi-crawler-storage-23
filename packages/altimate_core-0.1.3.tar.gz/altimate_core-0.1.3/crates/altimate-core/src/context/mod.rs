//! Context window optimizer for AI agents.
//!
//! Compresses schema definitions into progressively smaller representations
//! using a five-level progressive disclosure model. This minimizes context
//! window usage while preserving the information agents need to generate
//! correct SQL.
//!
//! ## Progressive Disclosure Levels
//!
//! | Level | Name | Description | ~Tokens (10 tables) |
//! |-------|------|-------------|---------------------|
//! | 0 | Fingerprint | Just the hash | ~10 |
//! | 1 | TableList | Table names + descriptions + column counts | ~50 |
//! | 2 | ColumnNames | Table names + column names (no types) | ~200 |
//! | 3 | FullRelevant | Full for relevant tables, names for others | ~500 |
//! | 4 | Full | Complete schema with all details | ~2000+ |
//!
//! ## Usage
//!
//! ```rust,no_run
//! use altimate_core::context::{optimize_context, optimize_for_query, schema_summary, schema_fingerprint};
//! use altimate_core::context::types::{ContextConfig, DisclosureLevel};
//! use altimate_core::schema::types::SchemaDefinition;
//!
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//!
//! // Full schema optimization with auto-stepdown
//! let config = ContextConfig {
//!     max_tokens: 1000,
//!     level: DisclosureLevel::ColumnNames,
//!     ..Default::default()
//! };
//! let result = optimize_context(&schema, &config).unwrap();
//! println!("Used level: {}, tokens: {}", result.level_used, result.estimated_tokens);
//!
//! // Query-specific optimization
//! let result = optimize_for_query("SELECT id FROM users", &schema, &config).unwrap();
//! println!("Compression: {:.0}%", (1.0 - result.compression_ratio) * 100.0);
//! ```

pub mod engine;
pub mod types;

pub use engine::{optimize_context, optimize_for_query, schema_fingerprint, schema_summary};
pub use types::*;
