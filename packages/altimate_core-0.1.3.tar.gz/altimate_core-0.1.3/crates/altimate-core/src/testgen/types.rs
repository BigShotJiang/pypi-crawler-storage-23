//! Types for test generation.

use serde::{Deserialize, Serialize};

/// A generated test case for a SQL query.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestCase {
    /// Test case name
    pub name: String,
    /// Test category (e.g., "boundary", "null", "empty", "type_edge")
    pub category: String,
    /// Description of what this test case verifies
    pub description: String,
    /// Input values (column name -> test value)
    pub inputs: Vec<TestInput>,
    /// Expected behavior
    pub expected: TestExpectation,
}

/// A single test input value.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestInput {
    pub column: String,
    pub value: String,
    pub data_type: String,
}

/// Expected test outcome.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TestExpectation {
    /// Query should return rows
    ReturnsRows,
    /// Query should return empty
    ReturnsEmpty,
    /// Query should error
    ShouldError,
    /// Specific row count expected
    RowCount(usize),
}

/// Result of test generation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TestGenResult {
    /// The original SQL query
    pub sql: String,
    /// Generated test cases
    pub test_cases: Vec<TestCase>,
    /// Columns analyzed
    pub columns_analyzed: Vec<String>,
    /// Tables referenced
    pub tables_referenced: Vec<String>,
}
