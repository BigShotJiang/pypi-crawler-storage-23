//! Query complexity analysis and cloud cost estimation.
//!
//! This module provides multi-dimensional complexity scoring (0-100),
//! static cost estimation for cloud data warehouses, CI/CD gating,
//! cross-dialect comparison, and dbt project-wide reporting.
//!
//! # Overview
//!
//! - **Cost Estimation:** Predict bytes scanned and USD cost per dialect
//!   using table statistics and selectivity heuristics.
//! - **Complexity Scoring v2:** Multi-dimensional 0-100 score across
//!   structural, semantic, and cost dimensions.
//! - **CI/CD Gate:** Threshold checking with SARIF output for GitHub integration.
//! - **Cross-Dialect Comparison:** Compare cost/complexity across dialects.
//! - **dbt Report:** Project-wide model scoring and recommendations.

pub mod cost_estimator;
pub mod cost_profiles;
pub mod dbt_report;
pub mod dialect_compare;
pub mod feedback;
pub mod gate;
pub mod scoring;
pub mod types;

pub use cost_estimator::estimate_cost;
pub use cost_profiles::{
    CostProfile, PricingModel, PricingOptions, QueryType, SnowflakeWarehouseSize,
};
pub use dbt_report::generate_dbt_complexity_report;
pub use dialect_compare::compare_dialects;
pub use feedback::{
    CalibratedEstimate, CalibrationSource, FeedbackBaseline, FeedbackStore, FeedbackValidation,
    TenantConfig, TenantStatus, calibrate_estimate, create_tenant, ingest_feedback,
    load_feedback_store, save_feedback_store, sql_fingerprint, tenant_status,
};
pub use gate::{check_complexity_gate, format_sarif};
pub use scoring::compute_complexity_v2;
pub use types::*;
