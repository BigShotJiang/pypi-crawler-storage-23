//! SQL completion engine.
//!
//! Given partial SQL and a schema, suggests completions: columns, tables,
//! functions, JOIN conditions, WHERE clauses. Designed for editor integration.

pub mod engine;
pub mod types;

pub use engine::complete;
pub use types::*;
