//! Database schema introspection.
//!
//! Generates dialect-specific INFORMATION_SCHEMA queries and parses results
//! into altimate-core SchemaDefinition format. Supports two modes:
//! 1. Generate introspection SQL for manual execution
//! 2. Parse INFORMATION_SCHEMA JSON output into schema

pub mod engine;
pub mod types;

pub use engine::{generate_introspection_sql, parse_introspection_output};
pub use types::*;
