//! SQL anti-pattern tagging engine.
//!
//! Detects 6 SQL anti-patterns using polyglot-sql's multi-dialect parser:
//! - `select_star`: SELECT * usage (including nested and COUNT(*))
//! - `filter_has_func`: Functions on columns in WHERE (prevents index usage)
//! - `join_has_func`: Functions on columns in JOIN ON (prevents join optimization)
//! - `agg_before_join`: Aggregation before JOIN pattern
//! - `select_without_limit`: SELECT without LIMIT clause
//! - `create_or_replace_table`: CREATE OR REPLACE TABLE (data loss risk)

pub mod engine;
pub mod predicates;
pub mod rules;
pub mod types;
pub mod walk;

pub use engine::analyze_tags;
pub use types::{AnalysisConfig, TagReport, TagResult};
