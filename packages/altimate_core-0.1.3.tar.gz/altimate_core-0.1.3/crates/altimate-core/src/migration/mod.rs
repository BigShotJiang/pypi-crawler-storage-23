//! Migration safety analysis.
//!
//! Validates that SQL migrations (ALTER TABLE, DROP, etc.) are safe:
//! detects data loss, type narrowing, missing defaults, etc.

pub mod analyzer;
pub mod types;

pub use analyzer::analyze_migration;
pub use types::*;
