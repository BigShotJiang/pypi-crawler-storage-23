use altimate_core::lineage::{column_lineage, polyglot_column_lineage};
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    let sql = r#"SELECT
  CASE WHEN plan._ht_op_type = 'removed'
  THEN plan."_ht_oldPK"::TEXT
  ELSE plan."PK"::TEXT END
  as row_id,
  plan._ht_op_type as op_type
FROM hightouch_planner.sync2239655_request1046090296_plan as plan"#;

    let schema_json = serde_json::json!({
        "SYNC2239655_REQUEST1046090296_PLAN": {
            "_HT_OP_TYPE": "VARCHAR",
            "PK": "VARCHAR",
            "_HT_OLDPK": "VARCHAR",
            "MEMBER_ID": "VARCHAR"
        }
    });

    let schema: HashMap<String, serde_json::Value> = serde_json::from_value(schema_json).unwrap();

    // Check polyglot edges
    eprintln!("=== Polyglot edges ===");
    match polyglot_column_lineage(sql, SqlDialect::Snowflake) {
        Ok(result) => {
            for edge in &result.edges {
                eprintln!(
                    "  {} -> {}.{} (terminal: {:?})",
                    edge.target_column, edge.source_table, edge.source_column, edge.terminal_kind
                );
            }
        }
        Err(e) => eprintln!("Error: {}", e),
    }

    // Check full lineage
    eprintln!("\n=== Full column_lineage ===");
    match column_lineage(sql, SqlDialect::Snowflake, &schema, None) {
        Ok(result) => {
            for (col, sources) in &result.column_dict {
                eprintln!("  {} -> {:?}", col, sources);
            }
        }
        Err(e) => eprintln!("Error: {}", e),
    }
}
