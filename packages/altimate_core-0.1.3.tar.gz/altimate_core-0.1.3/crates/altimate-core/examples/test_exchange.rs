use altimate_core::lineage::column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    let sql = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id , usd_exchange_rate from
(SELECT *, row_number() OVER (PARTITION BY SUBSTRING(EXCHANGE_DATE,1,10) ORDER BY  INSERT_TIMESTAMP DESC) AS RANKS
     from ods.currency_exchange_rate
     where EXCHANGE_CURRENCY = 'CAD'
     )currency_exchange_rate
WHERE RANKS = 1
order by exchange_date_id desc"#;

    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(
        r#"{
        "CURRENCY_EXCHANGE_RATE": {"EXCHANGE_DATE": "VARCHAR", "USD_EXCHANGE_RATE": "VARCHAR"}
    }"#,
    )
    .unwrap();

    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("=== Output ===");
    for (k, v) in &result.column_dict {
        let mut srcs: Vec<_> = v.iter().collect();
        srcs.sort();
        eprintln!("  {}: {:?}", k, srcs);
    }

    eprintln!("\n=== Expected ===");
    eprintln!("  EXCHANGE_DATE_ID: CURRENCY_EXCHANGE_RATE.EXCHANGE_DATE");
    eprintln!("  USD_EXCHANGE_RATE: CURRENCY_EXCHANGE_RATE.USD_EXCHANGE_RATE");
}
