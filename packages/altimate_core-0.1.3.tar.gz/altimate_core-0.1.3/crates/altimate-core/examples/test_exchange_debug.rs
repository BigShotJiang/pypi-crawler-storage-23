use altimate_core::lineage::polyglot_column_lineage;
use altimate_core::schema::types::SqlDialect;

fn main() {
    let sql = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id , usd_exchange_rate from
(SELECT *, row_number() OVER (PARTITION BY SUBSTRING(EXCHANGE_DATE,1,10) ORDER BY  INSERT_TIMESTAMP DESC) AS RANKS
     from ods.currency_exchange_rate
     where EXCHANGE_CURRENCY = 'CAD'
     )currency_exchange_rate
WHERE RANKS = 1
order by exchange_date_id desc"#;

    let result = polyglot_column_lineage(sql, SqlDialect::Snowflake).unwrap();
    eprintln!("=== Polyglot Edges ({}) ===", result.edges.len());
    for edge in &result.edges {
        eprintln!(
            "  {} -> {} (source: {}.{}, kind: {:?})",
            edge.target_column,
            edge.source_column,
            edge.source_table,
            edge.source_column,
            edge.terminal_kind
        );
    }
}
