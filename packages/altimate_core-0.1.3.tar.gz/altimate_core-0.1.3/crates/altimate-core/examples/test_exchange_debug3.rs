use altimate_core::lineage::polyglot_column_lineage;
use altimate_core::schema::types::SqlDialect;

fn main() {
    // Direct table reference
    let sql = r#"select REPLACE(SUBSTRING(EXCHANGE_DATE,1,10),'-','') AS exchange_date_id, usd_exchange_rate
FROM currency_exchange_rate"#;

    let result = polyglot_column_lineage(sql, SqlDialect::Snowflake).unwrap();
    eprintln!(
        "=== Polyglot edges (direct table) ({}) ===",
        result.edges.len()
    );
    for edge in &result.edges {
        eprintln!(
            "  target={}, source={}.{}, kind={:?}",
            edge.target_column, edge.source_table, edge.source_column, edge.terminal_kind
        );
    }

    // Simpler: just SUBSTRING
    let sql2 =
        r#"select SUBSTRING(EXCHANGE_DATE,1,10) AS exchange_date_id FROM currency_exchange_rate"#;
    let result2 = polyglot_column_lineage(sql2, SqlDialect::Snowflake).unwrap();
    eprintln!(
        "\n=== Polyglot edges (SUBSTRING only) ({}) ===",
        result2.edges.len()
    );
    for edge in &result2.edges {
        eprintln!(
            "  target={}, source={}.{}, kind={:?}",
            edge.target_column, edge.source_table, edge.source_column, edge.terminal_kind
        );
    }

    // Even simpler: just REPLACE
    let sql3 =
        r#"select REPLACE(EXCHANGE_DATE,'-','') AS exchange_date_id FROM currency_exchange_rate"#;
    let result3 = polyglot_column_lineage(sql3, SqlDialect::Snowflake).unwrap();
    eprintln!(
        "\n=== Polyglot edges (REPLACE only) ({}) ===",
        result3.edges.len()
    );
    for edge in &result3.edges {
        eprintln!(
            "  target={}, source={}.{}, kind={:?}",
            edge.target_column, edge.source_table, edge.source_column, edge.terminal_kind
        );
    }
}
