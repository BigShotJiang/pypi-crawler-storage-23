use altimate_core::lineage::column_lineage;
use altimate_core::lineage::polyglot_column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    let sql = r#"SELECT * FROM (
          SELECT
      "_ht_to_filter"."AVAILABLE"
,      "_ht_to_filter"."GUID"
    FROM
    (
      select insert_ts, update_ts, guid, is_giftcard_method_visible,
to_number((available*0.01),38,2) as available
from  ebates_prod.asset.ebatescom_giftcard_target_members
where is_giftcard_method_visible = true
and available between 500 and 50000


  ) AS "_ht_to_filter"
        ) AS _ht_to_filter_pk
        WHERE
          "GUID"
          IS NOT NULL"#;

    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(
        r#"{
        "EBATESCOM_GIFTCARD_TARGET_MEMBERS": {"GUID": "VARCHAR", "AVAILABLE": "VARCHAR"}
    }"#,
    )
    .unwrap();

    // Raw edges from polyglot
    let edges = polyglot_column_lineage(sql, SqlDialect::Snowflake).unwrap();
    eprintln!("=== Raw polyglot edges ({}) ===", edges.edges.len());
    for edge in &edges.edges {
        eprintln!(
            "  src_table='{}' src_col='{}' -> target='{}' (kind={:?})",
            edge.source_table, edge.source_column, edge.target_column, edge.terminal_kind
        );
    }

    // Our processed output
    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== column_dict ===");
    for (k, v) in &result.column_dict {
        eprintln!("  {}: {:?}", k, v);
    }

    eprintln!("\n=== expected ===");
    eprintln!("  GUID: [\"EBATESCOM_GIFTCARD_TARGET_MEMBERS\".\"GUID\"]");
    eprintln!("  AVAILABLE: [\"EBATESCOM_GIFTCARD_TARGET_MEMBERS\".\"AVAILABLE\"]");
}
