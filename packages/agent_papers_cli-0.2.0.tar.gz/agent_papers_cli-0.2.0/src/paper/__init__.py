"""paper - A CLI tool for reading, skimming, and searching academic papers."""

__version__ = "0.1.0"
