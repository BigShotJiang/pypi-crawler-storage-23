"""Allow running CLI as: python -m recursor_sdk"""
from recursor_sdk.cli import main

if __name__ == "__main__":
    main()

