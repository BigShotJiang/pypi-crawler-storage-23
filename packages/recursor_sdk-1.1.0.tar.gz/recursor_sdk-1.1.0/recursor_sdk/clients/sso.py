from typing import Any, Dict


class SSOClientMixin:
    """Mixin for SSO / Social Login operations (GitHub, Google, generic providers)"""

    def sso_github_login(self, code: str) -> Dict[str, Any]:
        """Login or register using a GitHub OAuth code.

        Exchanges the code for a GitHub access token on the backend,
        fetches the user profile, and returns JWT tokens.

        Args:
            code: The OAuth authorization code received from the GitHub callback.

        Returns:
            dict with ``access_token`` and ``refresh_token``.
        """
        response = self._post("/client/auth/sso/github/login", {"code": code})
        if "access_token" in response:
            self.set_access_token(response["access_token"])
        return response

    def sso_google_login(self, id_token: str) -> Dict[str, Any]:
        """Login or register using a Google ID token.

        The backend verifies the token with Google and returns JWT tokens.

        Args:
            id_token: Google ID token obtained from the Google Sign-In flow.

        Returns:
            dict with ``access_token`` and ``refresh_token``.
        """
        response = self._post("/client/auth/sso/google/login", {"id_token": id_token})
        if "access_token" in response:
            self.set_access_token(response["access_token"])
        return response

    def sso_get_login_url(self, provider: str) -> Dict[str, Any]:
        """Get the SSO authorization URL for a given provider.

        Args:
            provider: SSO provider name (e.g. ``"github"``, ``"google"``).

        Returns:
            dict with ``authorize_url`` key.
        """
        return self._get(f"/client/auth/sso/{provider}/login")
