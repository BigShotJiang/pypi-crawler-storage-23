from typing import Any, Dict, List


class GitHubClientMixin:
    """Mixin for GitHub Sync operations (repo listing, indexing, OAuth)"""

    def github_auth_callback(self, code: str) -> Dict[str, Any]:
        """Exchange a GitHub OAuth code for an access token.

        Args:
            code: The OAuth authorization code received from GitHub callback.

        Returns:
            dict with ``access_token`` key containing the GitHub token.
        """
        return self._post("/client/github/auth/callback", {"code": code})

    def github_list_repositories(self, token: str) -> List[Dict[str, Any]]:
        """List repositories for the authenticated GitHub user.

        Args:
            token: GitHub access token obtained via ``github_auth_callback``.

        Returns:
            List of repository objects from the GitHub API.
        """
        return self._get("/client/github/repositories", params={"token": token})

    def github_index_repository(self, full_name: str, token: str) -> Dict[str, Any]:
        """Trigger background indexing for a selected GitHub repository.

        Args:
            full_name: Full repository name (e.g. ``owner/repo``).
            token: GitHub access token.

        Returns:
            dict with ``status``, ``repository``, and ``message`` keys.
        """
        return self._post("/client/github/index", {
            "full_name": full_name,
            "token": token,
        })
