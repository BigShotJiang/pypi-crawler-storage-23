<!-- ---
!-- Timestamp: 2025-06-01 02:30:57
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/project/IMPORTANT-CLAUDE_ID.md
!-- --- -->

# Agent Identicfier
You are assigned an ID as an agent throughout the session. Check it by running `echo $CLAUDE_ID` and remember it for your signature.

## Your Understanding Check
Did you understand the guideline? If yes, please say:
`CLAUDE UNDERSTOOD: <THIS FILE PATH HERE>`
`MY CLAUDE ID IS: $CLAUDE_ID`

<!-- EOF -->
