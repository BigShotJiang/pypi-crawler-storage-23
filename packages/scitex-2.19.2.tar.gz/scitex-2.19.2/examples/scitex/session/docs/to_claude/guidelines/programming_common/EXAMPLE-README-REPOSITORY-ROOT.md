<!-- ---
!-- Timestamp: 2025-07-02 07:33:56
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.claude/to_claude/guidelines/python/HOW-TO-WRITE-README.md
!-- --- -->

# REPOSITORY NAME HERE

One line explanation of the repository here.

## 🚀 Key Features
- **🤖 XXX**: Simple explanation
- **⏰ XXX**: Simple explanation
- **📊 XXX**: Simple explanation
- **📋 XXX**: Simple explanation

---

## 📺 Examples

### Demonstration

![Demo gif](./docs/package-name-demo.gif)

### 📋 XXX

```
Example here in an appropriate language or simple markdown format
```

## Usage
```
Usage here in an appropriate language or simple markdown format
```

---

## 📦 Installation

INSTLLATION GUIDE HERE

---

## 🎯 Quick Start

QUICK START HERE

### (OPTIONAL) Configuration

CONFIGURATIONS HERE

## (OPTIONAL) References

REFERENCES HERE
---

## 📧 Contact
Yusuke Watanabe (ywatanabe@alumni.u-tokyo.ac.jp)

<!-- EOF -->
