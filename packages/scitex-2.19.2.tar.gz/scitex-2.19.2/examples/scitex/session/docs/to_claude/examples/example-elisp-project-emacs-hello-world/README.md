<!-- ---
!-- Timestamp: 2025-05-12 21:49:26
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.emacs.d/lisp/sample-package/README.md
!-- --- -->

# sample-project

This is a sample project to self-explain how Elisp package is written in our workflow.

<!-- EOF -->
