<!-- ---
!-- Timestamp: 2025-05-26 06:50:50
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/project/do-not-create-any-new-file-nor-directory-in-project-root.md
!-- --- -->

DO NOT CREATE ANY NEW FILE NOR DIRECTORY IN PROJECT ROOT.

<!-- EOF -->
