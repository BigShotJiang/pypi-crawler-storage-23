<!-- ---
!-- Timestamp: 2025-06-07 02:30:49
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.claude/to_claude/guidelines/project/IMPORTANT-documentation.md
!-- --- -->

## Documentation
- Write documents under ./docs/by_agents
- Write README.md in each directory

<!-- EOF -->
