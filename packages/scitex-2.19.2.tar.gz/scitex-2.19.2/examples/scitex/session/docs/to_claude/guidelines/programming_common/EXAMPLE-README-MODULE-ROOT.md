<!-- ---
!-- Timestamp: 2025-07-02 07:40:36
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.claude/to_claude/guidelines/programming_common/EXAMPLE-README-MODULE-ROOT.md
!-- --- -->

# REPOSIORY NAME XXX Module

One line explanation like: The XXX module provides ...

## Feature 01

Feature 01 provides ...

### Supported ...

Using tables ...

### Example Usage

```
EXAMPLE USAGE HERE
```

## Feature 02

...

## Contact
Yusuke Watanabe (ywatanabe@alumni.u-tokyo.ac.jp

<!-- EOF -->
