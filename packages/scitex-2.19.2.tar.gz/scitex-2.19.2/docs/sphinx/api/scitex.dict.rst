scitex.dict API Reference
=========================

.. automodule:: scitex.dict
   :members:
   :show-inheritance:
