scitex.scholar API Reference
============================

.. automodule:: scitex.scholar
   :members:
   :show-inheritance:
