API Reference
=============

Auto-generated API documentation for all SciTeX modules.

.. toctree::
   :maxdepth: 1

   scitex.session
   scitex.io
   scitex.config
   scitex.logging
   scitex.repro
   scitex.clew
   scitex.stats
   scitex.plt
   scitex.dsp
   scitex.diagram
   scitex.scholar
   scitex.writer
   scitex.linter
   scitex.ai
   scitex.nn
   scitex.template
   scitex.decorators
   scitex.introspect
   scitex.pd
   scitex.gen
   scitex.db
   scitex.dict
   scitex.str
   scitex.path
   scitex.social
