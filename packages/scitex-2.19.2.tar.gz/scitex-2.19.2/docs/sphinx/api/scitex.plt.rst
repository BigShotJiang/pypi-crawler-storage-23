scitex.plt API Reference
========================

.. note::

   ``scitex.plt`` wraps matplotlib with data-tracking axes. The plotting API
   is migrating to `figrecipe <https://github.com/ywatanabe1989/figrecipe>`_.
   See :doc:`/modules/plt` for usage documentation.

.. automodule:: scitex.plt
   :members: subplots
   :show-inheritance:
