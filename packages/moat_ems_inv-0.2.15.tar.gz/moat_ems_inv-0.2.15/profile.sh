alias vi="vim -U ~/.vimrc"
export LESS="-cRemsi -y5 -z-2"

. :DIR:/env/bin/activate
