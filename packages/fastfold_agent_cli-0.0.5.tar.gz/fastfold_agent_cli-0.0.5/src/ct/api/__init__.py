"""ct Data Query API — serves filtered queries against large datasets via DuckDB."""
