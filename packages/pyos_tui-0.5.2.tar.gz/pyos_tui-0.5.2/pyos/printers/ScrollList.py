# printers/ScrollList.py

from functools import partial
from .printers import make_scroll_list

class ScrollList:
    @staticmethod
    def layout(min_height=5, flex=1, max_height=None):
        cfg = {"flex": flex, "min_height": min_height}
        if max_height is not None:
            cfg["max_height"] = max_height
        return cfg

    @staticmethod
    def display_state(screen, items=None, selected_index=0, focused=False, input_handler=None, mouse_handler=None, min_height=5, flex=1, max_height=None):
        ctx = {
            "items": list(items or []),
            "selected_index": int(selected_index),
            "focused": bool(focused),
            "layout": ScrollList.layout(min_height, flex, max_height),
            "line_generator": partial(make_scroll_list, screen)
        }
        if input_handler:
            ctx["input_handler"] = input_handler
        if mouse_handler:
            ctx["mouse_handler"] = mouse_handler
        return ctx
