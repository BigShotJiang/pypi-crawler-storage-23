LEFT_BRACKET = 91
RIGHT_BRACKET = 93
ESC = 27
ENTER = 10
BACKSPACE = 8
TAB = 9
CTRL_F = 6
F1 = 265
F2 = 266
F3 = 267
F4 = 268
F5 = 269
F6 = 270
FORWARD_SLASH = 47
UP = 259
DOWN = 258
LEFT = 260
RIGHT = 261
HOME = 262
END = 360

_NORMALIZE = {
    13: ENTER,
    343: ENTER,       # curses.KEY_ENTER
    127: BACKSPACE,
    263: BACKSPACE,    # curses.KEY_BACKSPACE
}


def normalize(key_code):
    """Map platform-variant key codes to their canonical Keys constant."""
    return _NORMALIZE.get(key_code, key_code)
