class StopApplication:
    def __init__(self, exception=None):
        self.exception = exception


class ExceptionOccured:
    def __init__(self, exception):
        self.exception = exception


class KeyState:
    PRESSED = "pressed"
    REPEATED = "repeated"
    RELEASED = "released"


class KeyStroke:
    def __init__(self, key, state=KeyState.PRESSED):
        self.key = key
        self.state = state


class KeyRelease:
    def __init__(self, key):
        self.key = key


class ButtonEvent:
    def __init__(self, identifier):
        self.identifier = identifier

class UIEvent:
    def __init__(self, ui_element=None):
        self.ui_element = ui_element


class TextBoxChange(UIEvent): pass


class TextBoxSubmit(UIEvent): pass


class ScrollChange(UIEvent): pass


class MouseButton:
    LEFT = 0
    MIDDLE = 1
    RIGHT = 2
    NONE = 3


class MouseDown:
    def __init__(self, button, x, y, modifiers=0):
        self.button = button
        self.x = x
        self.y = y
        self.modifiers = modifiers


class MouseUp:
    def __init__(self, button, x, y, modifiers=0):
        self.button = button
        self.x = x
        self.y = y
        self.modifiers = modifiers


class MouseClick:
    def __init__(self, button, x, y, modifiers=0):
        self.button = button
        self.x = x
        self.y = y
        self.modifiers = modifiers


class MouseScroll:
    def __init__(self, direction, x, y, modifiers=0):
        self.direction = direction
        self.x = x
        self.y = y
        self.modifiers = modifiers


class MouseDrag:
    def __init__(self, button, x, y, start_x, start_y, modifiers=0):
        self.button = button
        self.x = x
        self.y = y
        self.start_x = start_x
        self.start_y = start_y
        self.modifiers = modifiers


class MouseMove:
    def __init__(self, x, y, modifiers=0):
        self.x = x
        self.y = y
        self.modifiers = modifiers