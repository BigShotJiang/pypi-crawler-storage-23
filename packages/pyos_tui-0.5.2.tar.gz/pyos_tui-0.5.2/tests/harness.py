"""
Backwards-compatibility shim — canonical implementation is now in pyos.testing.

Existing code that imports from this path (including importlib.spec_from_file_location
pointing at ~/repos/pyos/tests/harness.py) will continue to work.
"""

from pyos.testing.harness import MockScreen, HarnessApplication

__all__ = ["MockScreen", "HarnessApplication"]
