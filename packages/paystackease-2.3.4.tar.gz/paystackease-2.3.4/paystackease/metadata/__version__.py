from paystackease.utils._compact import metadata


__version__ = metadata.version("paystackease")
