from enum import Enum


class MarketStatusValue(Enum):
    OPEN = 'open'
    CLOSED = 'closed'
    EXTENDED_HOURS = 'extended-hours'
