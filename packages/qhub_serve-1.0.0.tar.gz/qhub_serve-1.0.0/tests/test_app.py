import os
import unittest

from busypie import wait, SECOND
from fastapi.testclient import TestClient

from qhub_serve.app import app

client = TestClient(app)


def run_with_exception(data: dict, params: dict):
    raise ValueError("This is a custom error message")


def has_job_finished(job_id):
    response = client.get(f"/{job_id}")
    job_status = response.json()["status"]
    return (
        job_status == "FAILED" or job_status == "SUCCEEDED" or job_status == "CANCELLED"
    )


class AppTests(unittest.TestCase):
    def tearDown(self):
        if "ENTRYPOINT" in os.environ:
            del os.environ["ENTRYPOINT"]

    def test_run_service_execution_with_string_input(self):
        input_data = {
            "data": {"test_data": "test_data_value2"},
            "params": {"test_param": "test_param_value2"},
        }

        response = client.post("/", json=input_data)
        json = response.json()

        self.assertEqual(201, response.status_code)
        self.assertEqual("PENDING", json["status"])
        self.assertIsNotNone(json["id"])

    def test_run_service_execution_with_array_input(self):
        input_data = {
            "data": {"value": ["abc", "dce"]},
            "params": {"value2": ["abc", "dce"]},
        }

        response = client.post("/", json=input_data)
        json = response.json()

        self.assertEqual(201, response.status_code)
        self.assertEqual("PENDING", json["status"])
        self.assertIsNotNone(json["id"])

    def test_get_status_will_raise_error_when_no_service_execution(self):
        response = client.get(f"/123")

        self.assertEqual(404, response.status_code)

    def test_get_status(self):
        response = client.post("/", json={"data": {"values": [1]}, "params": {}})
        json = response.json()

        self.assertEqual(201, response.status_code)
        self.assertEqual("PENDING", json["status"])
        self.assertIsNotNone(json["id"])

        id = json["id"]

        wait().at_most(2, SECOND).until(lambda: has_job_finished(id))

        response = client.get(f"/{id}")
        json = response.json()

        self.assertEqual(200, response.status_code)
        self.assertEqual("SUCCEEDED", json["status"])

    def test_get_status_when_service_execution_failed(self):
        os.environ["ENTRYPOINT"] = "tests.test_app:run_with_exception"

        response = client.post("/", json={"data": {"values": [1]}, "params": {}})
        json = response.json()

        self.assertEqual(201, response.status_code)
        self.assertEqual("PENDING", json["status"])
        self.assertIsNotNone(json["id"])

        id = json["id"]

        wait().at_most(2, SECOND).until(lambda: has_job_finished(id))

        response = client.get(f"/{id}")
        json = response.json()

        self.assertEqual(200, response.status_code)
        self.assertEqual("FAILED", json["status"])

    def test_get_result(self):
        response = client.post("/", json={"data": {"values": [1]}, "params": {}})
        json = response.json()

        self.assertEqual(201, response.status_code)
        self.assertEqual("PENDING", json["status"])
        self.assertIsNotNone(json["id"])

        id = json["id"]

        wait().at_most(2, SECOND).until(lambda: has_job_finished(id))

        response = client.get(f"/{id}/result")
        json = response.json()

        self.assertEqual(200, response.status_code)
        self.assertEqual(1, json["sum"])
