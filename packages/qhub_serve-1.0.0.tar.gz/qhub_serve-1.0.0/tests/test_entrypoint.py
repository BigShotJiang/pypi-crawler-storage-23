import unittest
from tempfile import TemporaryDirectory

from qhub_serve.entrypoint import run_entrypoint_wrapper


def run_valid(**kwargs):
    return {"result": True}


def run_exception(**kwargs):
    raise Exception()


class EntrypointTests(unittest.TestCase):
    def test_should_execute_entrypoint(self):
        entry_point = "tests.test_entrypoint:run_valid"
        response = run_entrypoint_wrapper(
            entry_point, {}, TemporaryDirectory(), TemporaryDirectory()
        )

        self.assertDictEqual(response, {"result": True})

    def test_will_raise_error_when_entrypoint_raised_exception(self):
        entry_point = "tests.test_entrypoint:run_exception"

        with self.assertRaises(Exception):
            run_entrypoint_wrapper(
                entry_point, {}, TemporaryDirectory(), TemporaryDirectory()
            )

    def test_will_raise_error_when_entrypoint_invalid(self):
        entry_point = "tests.test_entrypoint:invalid_entry_point"

        with self.assertRaises(Exception):
            run_entrypoint_wrapper(
                entry_point, {}, TemporaryDirectory(), TemporaryDirectory()
            )

    def test_will_raise_error_when_entrypoint_null(self):
        with self.assertRaises(Exception):
            run_entrypoint_wrapper(None, {}, TemporaryDirectory(), TemporaryDirectory())
