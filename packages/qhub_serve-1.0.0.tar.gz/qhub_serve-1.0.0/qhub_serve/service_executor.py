import json
import os
from concurrent.futures import ThreadPoolExecutor
from tempfile import TemporaryDirectory
from typing import Dict, Any, List

from fastapi import HTTPException
from qhub.api.service.types import (
    HalLink,
    ResultResponse,
    ResultResponseEmbedded,
    ResultResponseLinks,
    ServiceExecution,
)
from qhub.commons.file import list_directory_files
from starlette.responses import StreamingResponse

from .entrypoint import run_entrypoint_wrapper
from .service_execution_state import ServiceExecutionState


class ServiceExecutor:
    def __init__(self):
        self.states: Dict[str, ServiceExecutionState] = {}
        self.executor = ThreadPoolExecutor(max_workers=3)

    def list(self) -> List[ServiceExecution]:
        return [state.get_status() for state in self.states.values()]

    def run(self, id: str, raw_input: Dict[str, Any]) -> None:
        entrypoint = os.environ.get("ENTRYPOINT", "src.program:run")

        input_directory = TemporaryDirectory()
        output_directory = TemporaryDirectory()

        future = self.executor.submit(
            run_entrypoint_wrapper,
            entrypoint,
            raw_input,
            input_directory,
            output_directory,
        )

        state = ServiceExecutionState(id, future, input_directory, output_directory)
        self.states[id] = state

    def get_status(self, id: str) -> ServiceExecution:
        state = self.states.get(id)
        if state is None:
            raise HTTPException(status_code=404, detail="Not found")

        return state.get_status()

    def get_result(self, id: str) -> ResultResponse:
        state = self.states.get(id)
        if state is None:
            raise HTTPException(status_code=404, detail="Not found")

        output_files = list_directory_files(
            state.output_directory.name, strip_extension_from_key=False
        )

        links = ResultResponseLinks(status=HalLink(href=f"/{id}"))
        output_file_links = {}
        for output_file_name in output_files:
            output_file_links[output_file_name] = HalLink(
                href=f"/{id}/result/{output_file_name}"
            )
        links = links.model_copy(update=output_file_links)

        embedded = ResultResponseEmbedded(status=self.get_status(id))

        response = ResultResponse(links=links, embedded=embedded)

        if "output.json" not in output_files:
            return response

        file_path = output_files.get("output.json")
        json_value = json.load(open(file_path, "r"))
        return response.model_copy(update=json_value)

    def get_result_file(self, id: str, name: str):
        output_files = self.get_result_files(id)

        if name not in output_files:
            raise HTTPException(status_code=404, detail="Not found")

        file_path = output_files[name]

        return StreamingResponse(
            open(file_path, "rb"), media_type="application/octet-stream"
        )

    def get_result_files(self, id: str) -> Dict[str, str]:
        state = self.states.get(id)
        if state is None:
            raise HTTPException(status_code=404, detail="Not found")

        return list_directory_files(state.output_directory.name)

    def cancel(self, id: str) -> None:
        state = self.states.get(id)
        if state is None:
            raise HTTPException(status_code=404, detail="Not found")

        state.cancel()
