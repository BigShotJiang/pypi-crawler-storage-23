import time
import uuid
from typing import List, Optional

from fastapi import FastAPI, Path, BackgroundTasks, Response
from qhub.api.service.types import LogEntry, ResultResponse, ServiceExecution
from qhub.commons.logging import init_logging
from starlette.requests import Request
from starlette.responses import StreamingResponse

from .date import format_timestamp
from .service_executor import ServiceExecutor

app = FastAPI(
    title="Hub Service API",
    version="1.0",
    description="API description for a managed services on the Kipu Quantum Hub.",
    contact={
        "name": "Kipu Quantum GmbH",
        "url": "https://kipu-quantum.com",
        "email": "support-hub@kipu-quantum.com",
    },
)

init_logging()

service_executor = ServiceExecutor()


@app.get("/", summary="List of service executions", tags=["Service API"])
def get_service_executions() -> List[ServiceExecution]:
    return service_executor.list()


@app.post(
    "/",
    summary="Asynchronous execution of the service",
    status_code=201,
    tags=["Service API"],
)
async def start_execution(request: Request, response: Response, background_tasks: BackgroundTasks) -> ServiceExecution:
    raw_input = await request.json()
    id = str(uuid.uuid4())
    background_tasks.add_task(service_executor.run, id, raw_input)
    response.headers["Location"] = f"/{id}"
    return ServiceExecution(
        id=id,
        status="PENDING",
        created_at=format_timestamp(time.time()),
        started_at=None,
        ended_at=None,
    )


@app.get(
    "/{id}",
    summary="Check the status of a service execution",
    tags=["Service API"]
)
def get_status(id: str = Path(description="The id of a service execution")) -> ServiceExecution:
    return service_executor.get_status(id)


@app.get(
    "/{id}/result",
    summary="Get the result of a service execution",
    response_model=ResultResponse,
    response_model_exclude_none=True,
    tags=["Service API"],
)
def get_result(id: str = Path(description="The id of a service execution")) -> ResultResponse:
    return service_executor.get_result(id)


@app.get(
    "/{id}/result/{file}",
    summary="Download a result file of a service execution",
    tags=["Service API"],
)
def get_result_file(id: str = Path(description="The id of a service execution"),
                    file: str = Path(description="The name of the result file")) -> StreamingResponse:
    return service_executor.get_result_file(id, file)


@app.get(
    "/{id}/log",
    summary="Get the log output of a service execution",
    responses={
        200: {"description": "List of log entries"},
        204: {"description": "No log entries available, retry later"},
    },
    tags=["Service API"],
)
def get_log(id: str = Path(description="The id of a service execution")) -> Optional[List[LogEntry]]:
    return None


@app.put(
    "/{id}/cancel",
    summary="Cancel a service execution",
    status_code=204,
    tags=["Service API"],
)
def cancel_execution(id: str = Path(description="The id of a service execution")) -> None:
    service_executor.cancel(id)
