import time
from concurrent.futures import Future
from tempfile import TemporaryDirectory
from typing import Any

from qhub.api.service.types import ServiceExecution

from .date import format_timestamp


class ServiceExecutionState:
    def __init__(
        self,
        id: str,
        future: Future,
        input_directory: TemporaryDirectory,
        output_directory: TemporaryDirectory,
    ):
        self.id = id
        self.created_at = time.time()
        self.started_at = time.time()
        self.ended_at = None
        self.future = future
        self.future.add_done_callback(lambda f: self.__set_ended_at())
        self.input_directory = input_directory
        self.output_directory = output_directory

    def has_finished(self):
        return self.future.done()

    def get_status(self) -> ServiceExecution:
        if self.future.exception() is not None:
            status = "FAILED"
        elif self.future.cancelled():
            status = "CANCELLED"
        elif self.future.done():
            status = "SUCCEEDED"
        else:
            status = "RUNNING"

        return ServiceExecution(
            id=self.id,
            status=status,
            created_at=format_timestamp(self.created_at),
            started_at=format_timestamp(self.started_at),
            ended_at=format_timestamp(self.ended_at),
        )

    def get_result(self) -> Any:
        if self.future.exception() is not None:
            return None

        if not self.has_finished():
            return None

        return self.future.result()

    def cancel(self):
        self.future.cancel()

    def __set_ended_at(self):
        self.ended_at = time.time()
