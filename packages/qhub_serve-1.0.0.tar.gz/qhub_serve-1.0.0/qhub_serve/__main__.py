import argparse
import os
import sys


def main():
    parser = argparse.ArgumentParser(
        description="Run a Kipu Quantum Hub service workspace locally, imitating the platform runtime."
    )
    parser.add_argument(
        "--workspace",
        default=os.getcwd(),
        help="Path to the workspace directory (default: current working directory)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind the server to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8081,
        help="Port to bind the server to (default: 8081)",
    )
    parser.add_argument(
        "--entrypoint",
        default="src.program:run",
        help="Entrypoint in 'module:function' notation, relative to the workspace (default: src.program:run)",
    )
    args = parser.parse_args()

    workspace = os.path.abspath(args.workspace)
    if not os.path.isdir(workspace):
        print(
            f"Error: workspace directory does not exist: {workspace}", file=sys.stderr
        )
        sys.exit(1)

    # Make the workspace importable: `src.program` resolves from the workspace root.
    if workspace not in sys.path:
        sys.path.insert(0, workspace)

    os.environ.setdefault("ENTRYPOINT", args.entrypoint)

    import uvicorn

    uvicorn.run(
        "qhub_serve.app:app",
        host=args.host,
        port=args.port,
        reload=True,
        reload_dirs=[workspace],
    )


if __name__ == "__main__":
    main()
