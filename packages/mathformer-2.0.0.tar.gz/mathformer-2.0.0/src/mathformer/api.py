import re
import os
import warnings
from decimal import Decimal, getcontext
from typing import Optional, Dict, Any, List, Union, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

getcontext().prec = 50

from .tokenizer import MathTokenizer
from .llama import TinyLlama

_BASE_DIR = Path(__file__).parent
_DEFAULT_MODEL_PATHS = {
    "add": _BASE_DIR / "addformer",
    "sub": _BASE_DIR / "subformer",
    "mul": _BASE_DIR / "mulformer",
    "div": _BASE_DIR / "divformer",
}


_OPERATION_SYMBOLS = {
    "add": "+",
    "sub": "-",
    "mul": "*",
    "div": "/",
}


class MathFormer:
    """
    A core handler for loading a specific arithmetic operation model and executing predictions.
    """

    def __init__(
        self,
        model_path: str,
        device: Optional[str] = None, 
        max_new_tokens: int = 32,
    ):
        """
        Initialize the MathFormer model instance.

        :param model_path: The directory path containing the model and tokenizer files.
        :type model_path: str
        :param device: The computation device to use (e.g., 'cpu', 'cuda'). Defaults to None.
        :type device: Optional[str]
        :param max_new_tokens: The maximum number of new tokens to generate during prediction. Defaults to 32.
        :type max_new_tokens: int
        """
        self.model_path = Path(model_path)
        self.max_new_tokens = max_new_tokens

        self._model: Optional[TinyLlama] = None
        self._tokenizer: Optional[MathTokenizer] = None
        self._loaded = False

    def load(self) -> "MathFormer":
        """
        Load the tokenizer and the model from the specified model path into memory.

        :return: The loaded MathFormer instance itself.
        :rtype: MathFormer
        """
        if self._loaded:
            return self

        self._tokenizer = MathTokenizer.from_pretrained(str(self.model_path))
        self._model = TinyLlama(str(self.model_path))
        self._loaded = True
        return self

    def unload(self) -> None:
        """
        Unload the tokenizer and model from memory to free up resources.
        
        :return: None
        """
        if self._model is not None:
            del self._model
            self._model = None
        if self._tokenizer is not None:
            del self._tokenizer
            self._tokenizer = None
        self._loaded = False

    @property
    def is_loaded(self) -> bool:
        """
        Check if the model and tokenizer are currently loaded into memory.

        :return: True if loaded, False otherwise.
        :rtype: bool
        """
        return self._loaded

    def predict(self, expression: str) -> str:
        """
        Predict the outcome of a given mathematical expression string.

        :param expression: The mathematical expression to predict (e.g., '1+1').
        :type expression: str
        :return: The generated mathematical answer.
        :rtype: str
        """
        if not self._loaded:
            self.load()

        if "=" not in expression:
            expression += "="

        inputs = self._tokenizer(expression, padding=False)
        input_ids = inputs["input_ids"][0]
        output_ids = self._model.generate(
            input_ids=input_ids,
            max_new_tokens=self.max_new_tokens,
            eos_token_id=self._tokenizer.eos_token_id,
        )

        generated_text = self._tokenizer.decode(output_ids, skip_special_tokens=True)

        if "=" in generated_text:
            answer = generated_text.split("=", 1)[1].strip()
        else:
            answer = generated_text.strip()

        return answer

    def batch_predict(self, expressions: List[str]) -> List[str]:
        """
        Predict the outcome for a batch of mathematical expressions.

        :param expressions: A list of mathematical expressions.
        :type expressions: List[str]
        :return: A list of generated mathematical answers.
        :rtype: List[str]
        """
        if not self._loaded:
            self.load()

        results = []
        for expr in expressions:
            results.append(self.predict(expr))
        return results

    def __call__(self, expression: str) -> str:
        """
        Make the instance callable to perform predictions directly.

        :param expression: The mathematical expression to predict.
        :type expression: str
        :return: The computed mathematical answer.
        :rtype: str
        """
        return self.predict(expression)

    def __enter__(self) -> "MathFormer":
        """
        Enter a context manager block, automatically loading the model.

        :return: The loaded MathFormer instance.
        :rtype: MathFormer
        """
        self.load()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        Exit a context manager block, automatically unloading the model.
        """
        self.unload()


class MathFormerAPI:
    """
    A comprehensive API interface supporting dynamic arithmetic operations
    by handling inputs, decimals, negatives, and routing tasks to core models.
    """

    def __init__(
        self,
        model_paths: Optional[Dict[str, str]] = None,
        device: Optional[str] = None,
        max_new_tokens: int = 32,
        lazy_load: bool = True,
        max_workers: Optional[int] = None,
    ):
        """
        Initialize the comprehensive API for all arithmetic operations.

        :param model_paths: A dictionary mapping operations ('add', 'sub', 'mul', 'div') to model paths. Defaults to None.
        :type model_paths: Optional[Dict[str, str]]
        :param device: The computation device to use. Defaults to None.
        :type device: Optional[str]
        :param max_new_tokens: The maximum number of tokens to generate per prediction. Defaults to 32.
        :type max_new_tokens: int
        :param lazy_load: Whether to load models incrementally only when needed. Defaults to True.
        :type lazy_load: bool
        :param max_workers: Maximum number of worker threads for parallel jobs. Defaults to CPU heuristics.
        :type max_workers: Optional[int]
        """
        self.max_new_tokens = max_new_tokens
        self.max_workers = max_workers or min(32, (os.cpu_count() or 1) + 4)

        paths = model_paths or {}
        self._model_paths = {
            op: Path(paths.get(op, _DEFAULT_MODEL_PATHS[op]))
            for op in ["add", "sub", "mul", "div"]
        }

        self.models: Dict[str, MathFormer] = {
            op: MathFormer(
                model_path=str(path),
                max_new_tokens=self.max_new_tokens,
            )
            for op, path in self._model_paths.items()
        }

        if not lazy_load:
            self.load_all()

    def load_all(self) -> "MathFormerAPI":
        """
        Load all mathematical operations models simultaneously into memory.

        :return: The API instance itself.
        :rtype: MathFormerAPI
        """
        for model in self.models.values():
            model.load()
        return self

    def unload_all(self) -> None:
        """
        Unload all mathematical operations models from memory to free resources.
        
        :return: None
        """
        for model in self.models.values():
            model.unload()

    def load(self, operation: str) -> "MathFormerAPI":
        """
        Load a specific operation model into memory.

        :param operation: The operation name (e.g., 'add', 'sub', 'mul', 'div').
        :type operation: str
        :return: The API instance itself.
        :rtype: MathFormerAPI
        """
        if operation in self.models:
            self.models[operation].load()
        return self

    def unload(self, operation: str) -> None:
        """
        Unload a specific operation model from memory.

        :param operation: The operation name to unload.
        :type operation: str
        :return: None
        """
        if operation in self.models:
            self.models[operation].unload()

    def _raw_predict(self, operation: str, expression: str) -> str:
        """
        Internal dispatcher to routing predict requests to specific operation models.

        :param operation: The operation model name to invoke.
        :type operation: str
        :param expression: The mathematical expression to execute.
        :type expression: str
        :return: The generated result text.
        :rtype: str
        """
        if operation not in self.models:
            raise ValueError(
                f"Unknown operation type: {operation}. Available: {list(self.models.keys())}"
            )
        return self.models[operation].predict(expression)

    def _batch_raw_predict(self, operation: str, expressions: List[str]) -> List[str]:
        """
        Internal dispatcher for routing batch predictions.

        :param operation: The operation model name to invoke.
        :type operation: str
        :param expressions: A list of mathematical expressions.
        :type expressions: List[str]
        :return: A list of generated results for each expression.
        :rtype: List[str]
        """
        if operation not in self.models:
            raise ValueError(
                f"Unknown operation type: {operation}. Available: {list(self.models.keys())}"
            )
        if len(expressions) == 0:
            return []
        
        return self.models[operation].batch_predict(expressions)

    def _single_add(self, a: int, b: int) -> Tuple[int, int]:
        """
        Perform a single digit addition, extracting carry-over digits.

        :param a: The first integer digit.
        :type a: int
        :param b: The second integer digit.
        :type b: int
        :return: A tuple of (digit result, carry-over).
        :rtype: Tuple[int, int]
        """
        result_str = self._raw_predict("add", f"{a}+{b}")
        if not result_str: return 0, 0
        try:
            result = int(result_str)
        except ValueError:
            return 0, 0
        return result % 10, result // 10

    def _single_sub(self, a: int, b: int, borrow: int = 0) -> Tuple[int, int]:
        """
        Perform a single digit subtraction with an optional borrow.

        :param a: The primary digit from which to subtract.
        :type a: int
        :param b: The digit to be subtracted.
        :type b: int
        :param borrow: Value to borrow from actual subtraction operation. Defaults to 0.
        :type borrow: int
        :return: A tuple of (digit result, new borrow).
        :rtype: Tuple[int, int]
        """
        a_actual = a - borrow

        if a_actual >= b:
            result_str = self._raw_predict("sub", f"{a_actual}-{b}")
            try:
                return int(result_str), 0
            except ValueError:
                return 0, 0
        else:
            a_with_borrow = a_actual + 10
            result_str = self._raw_predict("sub", f"{a_with_borrow}-{b}")
            try:
                return int(result_str), 1
            except ValueError:
                return 0, 0

    def _single_mul(self, a: int, b: int) -> int:
        """
        Perform a single digit multiplication.

        :param a: First integer operand.
        :type a: int
        :param b: Second integer operand.
        :type b: int
        :return: Evaluated product.
        :rtype: int
        """
        result_str = self._raw_predict("mul", f"{a}*{b}")
        try:
            return int(result_str)
        except ValueError:
            return 0

    def _single_div(self, a: int, b: int) -> Tuple[int, int]:
        """
        Perform a division returning both quotient and remainder.

        :param a: Dividend integer value.
        :type a: int
        :param b: Divisor integer value.
        :type b: int
        :return: A tuple containing (quotient, remainder).
        :rtype: Tuple[int, int]
        """
        result_str = self._raw_predict("div", f"{a}/{b}")
        match = re.match(r"Q(\d+)R(\d+)", result_str)
        if match:
            return int(match.group(1)), int(match.group(2))
        try:
            return int(result_str), 0
        except ValueError:
            return 0, 0

    def _multi_add(self, a: int, b: int) -> int:
        """
        Add two multi-digit integers iteratively resolving individual additions globally.

        :param a: The first integer to add.
        :type a: int
        :param b: The second integer to add.
        :type b: int
        :return: Return sum value output.
        :rtype: int
        """
        if a < 0 or b < 0:
            if a < 0 and b < 0:
                return -self._multi_add(-a, -b)
            elif a < 0:
                return self._multi_sub(b, -a)
            else:
                return self._multi_sub(a, -b)

        digits_a = [int(d) for d in str(a)[::-1]]
        digits_b = [int(d) for d in str(b)[::-1]]

        max_len = max(len(digits_a), len(digits_b))
        digits_a.extend([0] * (max_len - len(digits_a)))
        digits_b.extend([0] * (max_len - len(digits_b)))

        result = []
        carry = 0

        for i in range(max_len):
            sum_with_carry = digits_a[i] + carry
            carry_from_first = 0

            if sum_with_carry > 9:
                sum_with_carry = sum_with_carry - 10
                carry_from_first = 1

            digit_result, new_carry = self._single_add(sum_with_carry, digits_b[i])

            result.append(digit_result)
            carry = new_carry + carry_from_first

        if carry > 0:
            result.append(carry)

        return int("".join(str(d) for d in result[::-1]))

    def _multi_sub(self, a: int, b: int) -> int:
        """
        Subtract two multi-digit integers handling borrow state variables respectively.

        :param a: Target subtractor operand.
        :type a: int
        :param b: Operand to be subtracted from a.
        :type b: int
        :return: Output of total difference calculation result.
        :rtype: int
        """
        if a < 0 and b < 0:
            return self._multi_sub(-b, -a)
        elif a < 0:
            return -self._multi_add(-a, b)
        elif b < 0:
            return self._multi_add(a, -b)

        if a < b:
            return -self._multi_sub(b, a)

        digits_a = [int(d) for d in str(a)[::-1]]
        digits_b = [int(d) for d in str(b)[::-1]]

        digits_b.extend([0] * (len(digits_a) - len(digits_b)))

        result = []
        borrow = 0

        for i in range(len(digits_a)):
            digit_a = digits_a[i]
            digit_b = digits_b[i]

            digit_result, new_borrow = self._single_sub(digit_a, digit_b, borrow)
            result.append(digit_result)
            borrow = new_borrow

        while len(result) > 1 and result[-1] == 0:
            result.pop()

        return int("".join(str(d) for d in result[::-1]))

    def _compute_partial_product(self, i: int, digit_b: int, digits_a: List[int]) -> List[Tuple[int, int]]:
        """
        Calculate the partial product of a single multiplier digit across all multiplicand digits.

        :param i: Zero-indexed position of multiplier digit.
        :type i: int
        :param digit_b: Current target multiplier digit explicitly bounded between 0 scaling.
        :type digit_b: int
        :param digits_a: Array of digits representing multiplicand to apply partial derivation against.
        :type digits_a: List[int]
        :return: Calculated list array composed of derived position partial coordinate tuples mapping positions to digits.
        :rtype: List[Tuple[int, int]]
        """
        expressions = [f"{digit_a}*{digit_b}" for digit_a in digits_a]
        results = self._batch_raw_predict("mul", expressions)
        products = []
        for r in results:
            try:
                products.append(int(r))
            except ValueError:
                products.append(0)

        partial = []
        carry = 0
        for j, product in enumerate(products):
            total = product + carry
            partial.append((i + j, total % 10))
            carry = total // 10

        k = i + len(digits_a)
        while carry > 0:
            partial.append((k, carry % 10))
            carry = carry // 10
            k += 1

        return partial

    def _multi_mul(self, a: int, b: int) -> int:
        """
        Multiply two multi-digit integers computing intermediate carry additions uniformly.

        :param a: Product component 1 base operation scale.
        :type a: int
        :param b: Product component 2 scaling derivative coefficient.
        :type b: int
        :return: Total aggregated product result properly evaluating bounds across variables.
        :rtype: int
        """
        negative = (a < 0) ^ (b < 0)
        a, b = abs(a), abs(b)

        if a == 0 or b == 0:
            return 0

        digits_a = [int(d) for d in str(a)[::-1]]
        digits_b = [int(d) for d in str(b)[::-1]]

        result = [0] * (len(digits_a) + len(digits_b))

        def _add_to_result(pos, val):
            if pos >= len(result):
                result.extend([0] * (pos - len(result) + 1))
            result[pos] += val

        if len(digits_b) >= 2:
            partial_products = {}
            for i, digit_b in enumerate(digits_b):
                 partial_products[i] = self._compute_partial_product(i, digit_b, digits_a)

            for i in range(len(digits_b)):
                for pos, val in partial_products[i]:
                    _add_to_result(pos, val)

            pos = 0
            while pos < len(result):
                if result[pos] >= 10:
                    _add_to_result(pos + 1, result[pos] // 10)
                    result[pos] = result[pos] % 10
                pos += 1
        else:
            for i, digit_b in enumerate(digits_b):
                carry = 0
                for j, digit_a in enumerate(digits_a):
                    product = self._single_mul(digit_a, digit_b)
                    if i + j >= len(result):
                        result.extend([0] * (i + j - len(result) + 1))
                    total = product + carry + result[i + j]
                    result[i + j] = total % 10
                    carry = total // 10

                k = i + len(digits_a)
                while carry > 0:
                    if k >= len(result):
                        result.extend([0] * (k - len(result) + 1))
                    total = carry + result[k]
                    result[k] = total % 10
                    carry = total // 10
                    k += 1

        while len(result) > 1 and result[-1] == 0:
            result.pop()

        final_result = int("".join(str(d) for d in result[::-1]))
        return -final_result if negative else final_result

    def _trial_division(self, dividend: int, divisor: int) -> Tuple[int, int]:
        """
        Perform division algorithm trial guessing across boundaries recursively.

        :param dividend: High scaling dividend payload objective context bounds.
        :type dividend: int
        :param divisor: Lower scaling fraction payload split operator limits constraint boundary.
        :type divisor: int
        :return: Process evaluated outputs parsed logically yielding integer tuples linking quotient with remainder offset.
        :rtype: Tuple[int, int]
        """
        products = {}
        for q in range(10):
            products[q] = self._multi_mul(divisor, q)

        quotient = 0
        for q in range(9, -1, -1):
            if products[q] <= dividend:
                quotient = q
                break

        remainder = self._multi_sub(dividend, products[quotient])

        return quotient, remainder

    def _multi_div(self, a: int, b: int) -> Tuple[int, int]:
        """
        Perform accurate precision large-number bound divisions extracting specific scaled values dynamically.

        :param a: Dividend coefficient scaling logic parameter constraint definitions block context integer.
        :type a: int
        :param b: Dividing offset limit operator constraint bounds definition split object reference limit.
        :type b: int
        :raises ZeroDivisionError: Divisor cannot be equated mathematically to absolute limit scale bound zeroes.
        :return: Standardized format outputting calculated bounds limit offsets correctly linking integer quotient with division remainder properties output.
        :rtype: Tuple[int, int]
        """
        if b == 0:
            raise ZeroDivisionError("Divisor cannot be zero")

        negative = (a < 0) ^ (b < 0)
        a, b = abs(a), abs(b)

        if a < b:
            return 0, a

        if a == 0:
            return 0, 0

        digits_a = [int(d) for d in str(a)]

        quotient_digits = []
        remainder = 0

        for digit in digits_a:
            current = remainder * 10 + digit

            if current < b:
                quotient_digits.append(0)
                remainder = current
            else:
                if b <= 9 and current <= 89:
                    q, r = self._single_div(current, b)
                else:
                    q, r = self._trial_division(current, b)

                quotient_digits.append(q)
                remainder = r

        while len(quotient_digits) > 1 and quotient_digits[0] == 0:
            quotient_digits.pop(0)

        quotient = int("".join(str(d) for d in quotient_digits))

        if negative:
            quotient = -quotient

        return quotient, remainder

    def _parse_decimal(self, value: Union[str, int, float, Decimal]) -> Tuple[int, int]:
        """
        Parse float and string formatted decimals directly resolving trailing offsets natively properly aligned formatting context definitions.

        :param value: Decimals target format bounds value block variable properties definition structure.
        :type value: Union[str, int, float, Decimal]
        :return: Offset mapped logic context parameter array bounds representation tuple linking exact scalar int to decimal placement metrics bounds offset logically formatted dynamically correctly assigned layout scale.
        :rtype: Tuple[int, int]
        """
        if isinstance(value, (int, float)):
            value = str(value)
        elif isinstance(value, Decimal):
            value = str(value)

        value = value.strip()

        negative = value.startswith("-")
        if negative:
            value = value[1:]

        if "." in value:
            integer_part, decimal_part = value.split(".")
            integer_part = integer_part.lstrip("0") or "0"
            combined = integer_part + decimal_part
            combined = combined.lstrip("0") or "0"
            decimal_places = len(decimal_part)
            int_value = int(combined)
        else:
            int_value = int(value)
            decimal_places = 0

        if negative:
            int_value = -int_value

        return int_value, decimal_places

    def _format_decimal_result(self, int_value: int, decimal_places: int) -> str:
        """
        Convert structured mapped boundaries dynamically outputting mathematically consistent layout definitions cleanly offset.

        :param int_value: Absolute scale definition parameter metric layout boundaries constraints integer properties layout variables.
        :type int_value: int
        :param decimal_places: Point boundary parameters definitions offset float boundary scalar formatting string limit bounds context definition limits variable definition parameters bounds.
        :type decimal_places: int
        :return: Precise floating structure constraint logic layout rules mapping string offsets mathematically correct variable boundary parameters formatting variable formatting logic bounds dynamically scaled properties properties limit rules.
        :rtype: str
        """
        if decimal_places == 0:
            return str(int_value)

        negative = int_value < 0
        int_value = abs(int_value)

        str_value = str(int_value)

        if len(str_value) <= decimal_places:
            str_value = "0" * (decimal_places - len(str_value) + 1) + str_value

        integer_part = str_value[:-decimal_places]
        decimal_part = str_value[-decimal_places:]

        decimal_part = decimal_part.rstrip("0")

        if decimal_part:
            result = f"{integer_part}.{decimal_part}"
        else:
            result = integer_part

        if negative:
            result = "-" + result

        return result

    def _decimal_add(self, a: Union[str, int, float, Decimal], b: Union[str, int, float, Decimal]) -> str:
        """
        Execute precision decimal summation dynamically scaling placement boundaries constraint resolving boundaries perfectly variable formatting rule set.

        :param a: Formatted first decimal logic operation bound input constraint reference definitions properties limit metric variable structure variable variable.
        :type a: Union[str, int, float, Decimal]
        :param b: Second formatted decimal reference definition value target.
        :type b: Union[str, int, float, Decimal]
        :return: Dynamically formatted text string mathematically aligning variables outputs natively limit definitions structure correctly mapping logic offset boundaries boundaries.
        :rtype: str
        """
        a_val, a_dec = self._parse_decimal(a)
        b_val, b_dec = self._parse_decimal(b)

        max_dec = max(a_dec, b_dec)
        if a_dec < max_dec:
            a_val *= (10 ** (max_dec - a_dec))
        if b_dec < max_dec:
            b_val *= (10 ** (max_dec - b_dec))

        result = self._multi_add(a_val, b_val)

        return self._format_decimal_result(result, max_dec)

    def _decimal_sub(self, a: Union[str, int, float, Decimal], b: Union[str, int, float, Decimal]) -> str:
        """
        Execute formatted decimal precision offset subtractions cleanly calculating constraints and correctly rendering structure.
        
        :param a: Primary variable layout offset bound context referencing limits reference constraint variable definitions context limits logical constraints context boundaries block constraints.
        :type a: Union[str, int, float, Decimal]
        :param b: Value to deduct bound natively formatting string mapping offsets context layout variables block limits context structure object object logic.
        :type b: Union[str, int, float, Decimal]
        :return: Correct decimal operation output limit boundaries scaling constraints metrics boundaries bounds array properties mapped offset strings array layout outputs.
        :rtype: str
        """
        a_val, a_dec = self._parse_decimal(a)
        b_val, b_dec = self._parse_decimal(b)

        max_dec = max(a_dec, b_dec)
        if a_dec < max_dec:
            a_val *= (10 ** (max_dec - a_dec))
        if b_dec < max_dec:
            b_val *= (10 ** (max_dec - b_dec))

        result = self._multi_sub(a_val, b_val)

        return self._format_decimal_result(result, max_dec)

    def _decimal_mul(self, a: Union[str, int, float, Decimal], b: Union[str, int, float, Decimal]) -> str:
        """
        Execute formatted decimal multiplication returning correctly ordered offsets natively calculated safely output bound references constraints bounds layout structures definitions limit values boundaries constraints.

        :param a: Product boundary parameter variable definition objects offset formatting constraint limits constraints definitions reference context parameter parameter context limits logic metrics logic layout bounds.
        :type a: Union[str, int, float, Decimal]
        :param b: Product multiplier object metric variables definition formatting logic constraints bound layout structures structures.
        :type b: Union[str, int, float, Decimal]
        :return: Decimal operation resultant logic output parameter mapping logically constrained bound boundaries limit array layout boundary structures layout structures mapped accurately layout constraint properties accurately layout variables correctly metrics offsets bounding properties.
        :rtype: str
        """
        a_val, a_dec = self._parse_decimal(a)
        b_val, b_dec = self._parse_decimal(b)

        result = self._multi_mul(a_val, b_val)
        total_dec = a_dec + b_dec

        return self._format_decimal_result(result, total_dec)

    def _decimal_div(self, a: Union[str, int, float, Decimal], b: Union[str, int, float, Decimal], precision: int = 10) -> str:
        """
        Compute high-precision division specifically configured handling precision floating logic accurately limits logic boundaries values mapping rule variables bounds objects logically.

        :param a: Numerator boundary offset limits definition constraint mapping structure variables boundary parameters logic logic values objects definitions referencing offset mapping limit block configuration offset metrics.
        :type a: Union[str, int, float, Decimal]
        :param b: Denominator boundary logic limits boundary mapping objects structure context metrics metric array output boundary logically rules mapped accurate configurations logic dynamically referencing structures mapping constraint structure parameters mapping array boundary logic logic constraint properly correctly logically mapping array properly correctly rules configuration logic layout boundary metrics constraints variable definitions property correctly boundary limit configuration dynamically structures layout metric properly limits limits configurations properties properly parameters.
        :type b: Union[str, int, float, Decimal]
        :param precision: Decimal precision constraint offset mapping logical limits. Defaults to 10.
        :type precision: int
        :raises ZeroDivisionError: When divisor equates purely mathematically correctly mapping layout definitions boundary constraints logical definitions zeroes configuration bound logic metric limits bounds layout zero limit boundary configuration constraint limit boundaries definitions arrays boundary properties correctly.
        :return: Standardized evaluation result formatting mapped natively formatting limit logic values boundary constraints correctly dynamically structured layout block configuration structures definitions correctly.
        :rtype: str
        """
        a_val, a_dec = self._parse_decimal(a)
        b_val, b_dec = self._parse_decimal(b)

        if b_val == 0:
            raise ZeroDivisionError("Divisor cannot be zero")

        negative = (a_val < 0) ^ (b_val < 0)
        a_val = abs(a_val)
        b_val = abs(b_val)

        if a_dec > b_dec:
            b_val *= (10 ** (a_dec - b_dec))
        elif b_dec > a_dec:
            a_val *= (10 ** (b_dec - a_dec))

        quotient, remainder = self._multi_div(a_val, b_val)

        if remainder == 0:
            result = str(quotient)
            if negative and quotient != 0:
                result = "-" + result
            return result

        decimal_digits = []
        for _ in range(precision):
            remainder = self._multi_mul(remainder, 10)

            digit_quotient, remainder = self._multi_div(remainder, b_val)
            decimal_digits.append(digit_quotient)

            if remainder == 0:
                break

        decimal_part = "".join(str(d) for d in decimal_digits)
        decimal_part = decimal_part.rstrip("0")

        if decimal_part:
            result = f"{quotient}.{decimal_part}"
        else:
            result = str(quotient)

        if negative and (quotient != 0 or decimal_part):
            result = "-" + result

        return result

    def _is_decimal_input(self, value: Union[str, int, float]) -> bool:
        """
        Evaluate if a provided scalar numeric logically correlates logically variables boundary object object format bounds decimals structures objects objects definition bounds properties logically limits values dynamically array.

        :param value: Constraint logic reference validation parameter object checking structures context metrics objects value variables bounds block array mapping logical boundary metrics bounds offsets.
        :type value: Union[str, int, float]
        :return: Evaluated indicator dynamically array definition block value bounding rules logic properties true mapped false mapped bound offset limits limits correctly properly mapped limits parameters cleanly definitions correctly array rules boundary metrics bounds offset object logic values properties correctly layout structure constraints mapping mapping constraint definition offset rules limits constraint layout dynamically bounds rules structures structures mapping correctly layouts bounding parameters boundaries correctly layout logic offset constraints metrics constraint parameters layout definitions rules block objects constraints arrays correctly dynamically.
        :rtype: bool
        """
        if isinstance(value, float):
            return True
        if isinstance(value, str) and "." in value:
            return True
        return False

    def add(self, *args: Union[str, int, float]) -> str:
        """
        Public user-facing API handling dynamically variadic addition summation evaluation.

        :param *args: Values to add logically configuration properly mapped properly definitions constraints rule bounding limits logical property value limits dynamically offset context parameters boundary values limit arrays boundaries mapping logic structure correctly properly offsets.
        :type args: Union[str, int, float]
        :raises ValueError: Missing mapping array constraint values definitions limit structures parameter definitions logical limit bounding variables references boundary variables objects definition objects values layout mapping objects dynamically.
        :return: Standard mapped configuration rules string logically formatted mapping correctly properly array layout logically metric boundaries boundaries variable limit limits logically limits layout logically offset definition mapping mapped properly correctly definitions parameters constraints correctly bounds dynamically rules logical reference limits constraint bounds values configuration mapping correctly layout variables limits bounds structures logically values arrays definitions logically.
        :rtype: str
        """
        if len(args) == 0:
            raise ValueError("At least one argument is required")

        values = []
        has_decimal = False

        if len(args) == 1 and isinstance(args[0], str) and "+" in args[0]:
            expression = args[0].replace(" ", "").replace("=", "")
            parts = expression.split("+")
            values = parts
            has_decimal = any("." in p for p in parts)
        else:
            values = list(args)
            has_decimal = any(self._is_decimal_input(a) for a in args)

        if not values:
            return "0"

        if has_decimal:
            result = str(values[0])
            for val in values[1:]:
                result = self._decimal_add(result, str(val))
            return result
        else:
            try:
               int_values = [int(v) for v in values]
            except ValueError:
               return "Error"
            result = int_values[0]
            for val in int_values[1:]:
                result = self._multi_add(result, val)
            return str(result)

    def sub(self, *args: Union[str, int, float]) -> str:
        """
        Public user-facing API interface securely parsing variadic mapping bounds definition arrays offset referencing cleanly boundaries subtraction logic constraints limit constraints structures structures logic outputs variables dynamically rules rules variables references layout boundaries logic mapping dynamically constraints values structures arrays correctly mapped rules context outputs boundaries array constraints arrays correctly mapped limits limits structure variables definitions cleanly limits boundary objects configurations bounds correctly mapping logic parameters cleanly parameters.
        
        :param *args: Bound logically constraints mapping configuration correctly dynamically arrays definition offset boundary metric objects offset metrics logically referencing boundaries definitions offset logic object constraint offset limits properly limits context parameters correctly mapped.
        :type args: Union[str, int, float]
        :raises ValueError: Triggered when mapping structure limits constraint bounding mapping objects bounds configurations configurations structure limits appropriately definitions variables array correctly bounds cleanly offset arrays logically arrays limits values cleanly definitions variables cleanly bounds variables.
        :return: Executed correctly logically mapped bounds output properly limits safely limits configuration values configuration correctly safely cleanly logically cleanly dynamically variable definition referencing context limits values rules correctly metric offsets limits definitions.
        :rtype: str
        """
        if len(args) == 0:
            raise ValueError("At least one argument is required")

        values = []
        has_decimal = False

        if len(args) == 1 and isinstance(args[0], str) and "-" in args[0].lstrip("-"):
            expression = args[0].replace(" ", "").replace("=", "")
            if expression.startswith("-"):
                temp_expr = expression[1:]
                parts = temp_expr.split("-")
                values = ["-" + parts[0]] + parts[1:]
            else:
                parts = expression.split("-")
                values = parts
            has_decimal = any("." in p.lstrip("-") for p in values)
        else:
            values = list(args)
            has_decimal = any(self._is_decimal_input(a) for a in args)

        if not values:
            return "0"

        if has_decimal:
            result = str(values[0])
            for val in values[1:]:
                result = self._decimal_sub(result, str(val))
            return result
        else:
            try:
                int_values = [int(v) for v in values]
            except ValueError:
                return "Error"
            result = int_values[0]
            for val in int_values[1:]:
                result = self._multi_sub(result, val)
            return str(result)

    def mul(self, *args: Union[str, int, float]) -> str:
        """
        Public user-facing method executing multiplication mathematically rules bounding bounds bounds context limits configuration cleanly dynamically parameters constraints cleanly definitions mapping offsets definition cleanly constraints rules structures.
        
        :param *args: Parameters mathematically constraints rules metric boundaries context bounds clearly safely mapped correctly properties definition mappings bound logically layouts constraints bounds values natively defined configuration mappings objects mapping accurately definitions variables logic properties accurately configuration structures mapped cleanly clearly properly accurately constraints.
        :type args: Union[str, int, float]
        :raises ValueError: Executed dynamically definitions values bounds rules limits safely bounding properly metric metric configurations boundaries definitions mapping securely limits appropriately offsets bounds values.
        :return: Standard definitions dynamically configuration correctly mapping cleanly offsets limits outputs definition limits safely array properly correctly logically array definitions offset logically cleanly correctly offsets layout properly outputs rules array definition logically mathematically context definitions correctly logically safely limits mapping cleanly natively variable constraints accurately mappings cleanly properly limits accurately boundaries definition properly accurately boundaries rules limits logically mapping variable properly arrays clearly.
        :rtype: str
        """
        if len(args) == 0:
            raise ValueError("At least one argument is required")

        values = []
        has_decimal = False

        if (
            len(args) == 1
            and isinstance(args[0], str)
            and any(op in args[0] for op in ["*", "×"])
        ):
            expression = args[0].replace(" ", "").replace("=", "").replace("×", "*")
            parts = expression.split("*")
            values = parts
            has_decimal = any("." in p for p in parts)
        else:
            values = list(args)
            has_decimal = any(self._is_decimal_input(a) for a in args)

        if not values:
            return "0"

        if has_decimal:
            result = str(values[0])
            for val in values[1:]:
                result = self._decimal_mul(result, str(val))
            return result
        else:
            try:
                int_values = [int(v) for v in values]
            except ValueError:
                return "Error"
            result = int_values[0]
            for val in int_values[1:]:
                result = self._multi_mul(result, val)
            return str(result)

    def div(self, *args: Union[str, int, float], precision: int = 10) -> str:
        """
        Public user-facing API evaluating precision division cleanly dynamically context constraint context offset constraints logically definitions accurately configuration clearly mapping properly mapped metric boundary properly configurations metric bounds bounds objects accurately objects limits arrays accurately objects cleanly correctly definitions layout definitions.

        :param *args: Definition accurately bounding appropriately mapping efficiently limits offsets mapping array layouts properties.
        :type args: Union[str, int, float]
        :param precision: Safely logical constraints logically bound metric configuration mapping logic variables offsets cleanly appropriately accurately. Defaults to 10.
        :type precision: int
        :raises ValueError: Output dynamically mathematically configurations mapped constraints bounds safely arrays bounds context properties nicely cleanly appropriately mapping appropriately definitions safely natively correctly safely offset mapped limits definitions safely clearly safely mapped.
        :return: Layout appropriately accurately offset definition logically smoothly limits objects metrics bounds properly limits correctly.
        :rtype: str
        """
        if len(args) == 0:
            raise ValueError("At least one argument is required")

        values = []
        has_decimal = False

        if (
            len(args) == 1
            and isinstance(args[0], str)
            and any(op in args[0] for op in ["/", "÷"])
        ):
            expression = args[0].replace(" ", "").replace("=", "").replace("÷", "/")
            parts = expression.split("/")
            values = parts
            has_decimal = any("." in p for p in parts)
        else:
            values = list(args)
            has_decimal = any(self._is_decimal_input(a) for a in args)

        if not values:
            return "0"

        result = str(values[0])
        for val in values[1:]:
            result = self._decimal_div(result, str(val), precision=precision)
        return result

    def calculate(
        self, operation: str, a: Union[int, float, str], b: Union[int, float, str],
        precision: int = 10
    ) -> str:
        """
        Core calculator routing requests accurately offset logically securely cleanly properly mappings dynamically mapping outputs mathematically correctly natively defined correctly bounds mapping safely boundary definitions accurately bounds safely metrics offset arrays safely structure limits offsets efficiently clearly offset configurations.

        :param operation: Safely mapped logically definitions offsets logically natively safely dynamically bounds.
        :type operation: str
        :param a: Mathematically configuration offsets objects outputs configuration natively objects accurately bounds definitions objects accurately outputs properly cleanly accurately mappings correctly.
        :type a: Union[int, float, str]
        :param b: Output appropriately cleanly layout securely configuration defined bounds effectively nicely mapping properly definition parameters cleanly correctly metrics layouts safely effectively smoothly correctly boundaries configurations properly boundaries definitions constraints logically safely arrays safely bounds cleanly constraint.
        :type b: Union[int, float, str]
        :param precision: Mapping objects properly bounds variable offset logic cleanly boundary bound accurate. Defaults to 10.
        :type precision: int
        :raises ValueError: Executing safely safely clearly logically arrays accurately properly limits arrays definition natively boundaries appropriately safely appropriately natively securely dynamically logically clearly natively cleanly context appropriately mapped appropriately boundaries nicely array safely cleanly offsets mapping securely effectively values defined accurately smoothly natively mapped nicely properly.
        :return: Standard boundary configurations mapping defined accurately correctly effectively definition safely correctly cleanly cleanly variables outputs cleanly offsets limits definitions mapped objects correctly limits boundaries smoothly natively arrays mapping efficiently accurately bound cleanly properly dynamically efficiently parameters mathematically bounds successfully natively cleanly outputs nicely correctly neatly defined nicely configuration outputs efficiently variables mapping definitions safely definitions properly nicely.
        :rtype: str
        """
        if operation == "add":
            return self.add(a, b)
        elif operation == "sub":
            return self.sub(a, b)
        elif operation == "mul":
            return self.mul(a, b)
        elif operation == "div":
            return self.div(a, b, precision=precision)
        else:
            raise ValueError(f"Unknown operation: {operation}")
