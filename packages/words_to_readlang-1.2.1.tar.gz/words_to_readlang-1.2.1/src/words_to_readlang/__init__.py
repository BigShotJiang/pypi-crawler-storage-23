"""words-to-readlang: Convert vocabulary exports to Readlang CSV format.

This library provides tools for converting vocabulary files from various
language learning platforms (Pod101, Language Reactor, etc.) into the CSV
format accepted by Readlang's word import feature.

Basic usage:
    >>> from words_to_readlang import Converter
    >>> from pathlib import Path
    >>>
    >>> converter = Converter(fetch_examples=True, src_lang="fin")
    >>> output_files = converter.convert(
    ...     input_path=Path("words.csv"),
    ...     output_path=Path("readlang.csv"),
    ...     parser_name="pod101"
    ... )

For command-line usage, see the CLI documentation or run:
    words-to-readlang --help
"""

from .__version__ import __version__
from .core import Converter
from .models import Entry
from .parsers import Parser, get_parser, list_parsers, register_parser
from .services.fetcher import ExampleFetcher
from .writers.readlang import ReadlangWriter

__all__ = [
    "__version__",
    "Converter",
    "Entry",
    "Parser",
    "get_parser",
    "list_parsers",
    "register_parser",
    "ExampleFetcher",
    "ReadlangWriter",
]
