"""Language code utilities."""

# Language code to English name mapping
LANGUAGE_NAMES = {
    "afr": "Afrikaans",
    "sqi": "Albanian",
    "amh": "Amharic",
    "ara": "Arabic",
    "hye": "Armenian",
    "asm": "Assamese",
    "aym": "Aymara",
    "aze": "Azerbaijani",
    "bam": "Bambara",
    "eus": "Basque",
    "bel": "Belarusian",
    "ben": "Bengali",
    "bos": "Bosnian",
    "bre": "Breton",
    "bul": "Bulgarian",
    "mya": "Burmese",
    "yue": "Cantonese",
    "cat": "Catalan",
    "ceb": "Cebuano",
    "cmn": "Chinese",
    "cor": "Corsican",
    "hrv": "Croatian",
    "ces": "Czech",
    "dan": "Danish",
    "div": "Dhivehi",
    "nld": "Dutch",
    "eng": "English",
    "epo": "Esperanto",
    "est": "Estonian",
    "ewe": "Ewe",
    "fil": "Filipino",
    "fin": "Finnish",
    "fra": "French",
    "fry": "Frisian",
    "glg": "Galician",
    "kat": "Georgian",
    "deu": "German",
    "ell": "Greek",
    "grn": "Guarani",
    "guj": "Gujarati",
    "hat": "Haitian Creole",
    "hau": "Hausa",
    "heb": "Hebrew",
    "hin": "Hindi",
    "hun": "Hungarian",
    "isl": "Icelandic",
    "ibo": "Igbo",
    "ind": "Indonesian",
    "gle": "Irish",
    "ita": "Italian",
    "jpn": "Japanese",
    "jav": "Javanese",
    "kan": "Kannada",
    "kaz": "Kazakh",
    "khm": "Khmer",
    "kin": "Kinyarwanda",
    "kor": "Korean",
    "kur": "Kurdish (Kurmanji)",
    "ckb": "Kurdish (Sorani)",
    "kir": "Kyrgyz",
    "lao": "Lao",
    "lat": "Latin",
    "lav": "Latvian",
    "lin": "Lingala",
    "lit": "Lithuanian",
    "lug": "Luganda",
    "ltz": "Luxembourgish",
    "mkd": "Macedonian",
    "mlg": "Malagasy",
    "msa": "Malay",
    "mal": "Malayalam",
    "mlt": "Maltese",
    "mri": "Maori",
    "mar": "Marathi",
    "mon": "Mongolian",
    "nep": "Nepali",
    "nor": "Norwegian",
    "nya": "Nyanja / Chichewa",
    "ori": "Odia / Oriya",
    "orm": "Oromo",
    "pus": "Pashto",
    "fas": "Persian",
    "pol": "Polish",
    "por": "Portuguese",
    "pan": "Punjabi",
    "que": "Quechua",
    "ron": "Romanian",
    "rus": "Russian",
    "smo": "Samoan",
    "san": "Sanskrit",
    "gla": "Scots Gaelic",
    "srp": "Serbian",
    "sot": "Sesotho",
    "sna": "Shona",
    "snd": "Sindhi",
    "sin": "Sinhala / Sinhalese",
    "slk": "Slovak",
    "slv": "Slovenian",
    "som": "Somali",
    "spa": "Spanish",
    "sun": "Sundanese",
    "swa": "Swahili",
    "swe": "Swedish",
    "tgk": "Tajik",
    "tam": "Tamil",
    "tat": "Tatar",
    "tel": "Telugu",
    "tha": "Thai",
    "tir": "Tigrinya",
    "zho": "Traditional Chinese",
    "tso": "Tsonga",
    "tur": "Turkish",
    "tuk": "Turkmen",
    "aka": "Twi / Akan",
    "ukr": "Ukrainian",
    "urd": "Urdu",
    "uig": "Uyghur",
    "uzb": "Uzbek",
    "vie": "Vietnamese",
    "cym": "Welsh",
    "xho": "Xhosa",
    "yid": "Yiddish",
    "yor": "Yoruba",
    "zul": "Zulu",
}


def get_language_name(code: str) -> str:
    """Get the English name for a language code.

    Args:
        code: ISO 639-3 language code

    Returns:
        English language name, or the code itself if not found
    """
    return LANGUAGE_NAMES.get(code, code.upper())


def format_language_pair(source_code: str, target_code: str) -> str:
    """Format a language pair for display.

    Args:
        source_code: Source language code
        target_code: Target language code

    Returns:
        Formatted string like "Finnish → English"
    """
    source_name = get_language_name(source_code)
    target_name = get_language_name(target_code)
    return f"{source_name} → {target_name}"
