"""
Cypher-to-SQL Translation Artifacts

Classes for managing SQL generation from Cypher AST.
Supports multi-stage queries via Common Table Expressions (CTEs).
"""

from dataclasses import dataclass, field
from typing import List, Any, Dict, Optional, Union
import logging
import json
from . import ast
from iris_vector_graph.security import validate_table_name, VALID_GRAPH_TABLES

logger = logging.getLogger(__name__)

# Module-level schema prefix configuration
# Set to "Graph_KG" to use Graph_KG.nodes, Graph_KG.rdf_labels, etc.
# Set to "" (empty string) for unqualified table names
_schema_prefix: str = ""


def set_schema_prefix(prefix: str) -> None:
    """Set the schema prefix for all table references in generated SQL.
    
    Args:
        prefix: Schema name (e.g., "Graph_KG") or empty string for unqualified names
    """
    global _schema_prefix
    _schema_prefix = prefix


def get_schema_prefix() -> str:
    """Get the current schema prefix."""
    return _schema_prefix


def _table(name: str) -> str:
    """Return fully qualified table name with schema prefix if configured.
    
    Security: Validates name against VALID_GRAPH_TABLES allowlist to prevent
    SQL injection via table name manipulation.
    
    Args:
        name: Table name (must be in VALID_GRAPH_TABLES)
        
    Returns:
        Schema-qualified table name (e.g., "Graph_KG.nodes")
        
    Raises:
        ValueError: If name is not in the allowlist
    """
    # Validate against allowlist - raises ValueError if invalid
    validate_table_name(name)
    
    if _schema_prefix:
        return f"{_schema_prefix}.{name}"
    return name


def labels_subquery(node_expr: str) -> str:
    return f"(SELECT JSON_ARRAYAGG(label) FROM {_table('rdf_labels')} WHERE s = {node_expr})"


def properties_subquery(node_expr: str) -> str:
    # Stable string-based JSON aggregation.
    # We avoid native JSON_OBJECT in subqueries as it triggers an IRIS optimizer bug 
    # (looking for %QPAR in the local schema) in some versions (e.g. 2025.1).
    # We use minimal REPLACE calls for performance while ensuring valid JSON escaping.
    return (
        "(SELECT JSON_ARRAYAGG("
        "'{\"key\":\"' || REPLACE(REPLACE(\"key\", '\\', '\\\\'), '\"', '\\\"') || "
        "'\",\"value\":\"' || REPLACE(REPLACE(val, '\\', '\\\\'), '\"', '\\\"') || '\"}') "
        f"FROM {_table('rdf_props')} WHERE s = {node_expr})"
    )

@dataclass
class QueryMetadata:
    """Query execution metadata tracking."""
    estimated_rows: Optional[int] = None
    index_usage: List[str] = field(default_factory=list)
    optimization_applied: List[str] = field(default_factory=list)
    complexity_score: Optional[float] = None


@dataclass
class SQLQuery:
    """Generated SQL query with parameters and metadata."""
    sql: Union[str, List[str]]
    parameters: List[List[Any]] = field(default_factory=list)
    query_metadata: QueryMetadata = field(default_factory=QueryMetadata)
    is_transactional: bool = False


class TranslationContext:
    """Stateful context for SQL generation across multiple query stages."""
    
    def __init__(self, parent: Optional['TranslationContext'] = None):
        self.variable_aliases: Dict[str, str] = {}
        if parent is not None:
            self.variable_aliases = parent.variable_aliases.copy()

        # Variables that are scalar (not graph nodes) — skip node expansion in RETURN
        self.scalar_variables: set = set() if parent is None else parent.scalar_variables.copy()

        self.select_items: List[str] = []
        self.from_clauses: List[str] = []
        self.join_clauses: List[str] = []
        self.where_conditions: List[str] = []
        self.group_by_items: List[str] = []
        
        self.select_params: List[Any] = []
        self.join_params: List[Any] = []
        self.where_params: List[Any] = []
        
        self.dml_statements: List[tuple[str, List[Any]]] = []
        
        self.all_stage_params: List[Any] = [] if parent is None else parent.all_stage_params
        self._alias_counter: int = 0 if parent is None else parent._alias_counter
        self.stages: List[str] = [] if parent is None else parent.stages
        self.input_params: Dict[str, Any] = {} if parent is None else parent.input_params

    def next_alias(self, prefix: str = "t") -> str:
        alias = f"{prefix}{self._alias_counter}"
        self._alias_counter += 1
        return alias

    def register_variable(self, variable: str, prefix: str = "n") -> str:
        if variable not in self.variable_aliases:
            self.variable_aliases[variable] = self.next_alias(prefix)
        return self.variable_aliases[variable]

    def add_select_param(self, value: Any) -> str:
        self.select_params.append(value); return "?"

    def add_join_param(self, value: Any) -> str:
        self.join_params.append(value); return "?"

    def add_where_param(self, value: Any) -> str:
        self.where_params.append(value); return "?"

    def build_stage_sql(self, distinct: bool = False, select_override: Optional[str] = None) -> tuple[str, List[Any]]:
        """Build SQL for a single stage and return (sql, combined_params)"""
        select = select_override if select_override else f"SELECT {'DISTINCT ' if distinct else ''}{', '.join(self.select_items)}"
        parts = [select]
        if self.from_clauses: parts.append(f"FROM {', '.join(self.from_clauses)}")
        if self.join_clauses: parts.extend(self.join_clauses)
        if self.where_conditions: parts.append(f"WHERE {' AND '.join(self.where_conditions)}")
        if self.group_by_items: parts.append(f"GROUP BY {', '.join(self.group_by_items)}")
        
        sql = "\n".join(parts)
        params = (self.select_params if not select_override else []) + self.join_params + self.where_params
        
        # NOTE: We don't clear params here because they might be needed for the next stage or final assembly.
        # But for DML subqueries, we must be careful not to double-count.
        return sql, params


    def add_dml(self, sql: str, params: List[Any]):
        self.dml_statements.append((sql, params))


def translate_procedure_call(proc: ast.CypherProcedureCall, context: TranslationContext) -> None:
    """Translate a CALL procedure into a VecSearch CTE prepended to context.stages.

    Supported procedure: ivg.vector.search(label, property, query_input, limit [, options])

    Mode 1 — pre-computed vector (list[float]):
        SELECT TOP {limit} e.id AS node, VECTOR_COSINE(..., TO_VECTOR(?)) AS score ...
    Mode 2 — text via IRIS EMBEDDING() (requires IRIS 2024.3+):
        SELECT TOP {limit} e.id AS node, VECTOR_COSINE(..., EMBEDDING(?, ?)) AS score ...

    The caller (engine.execute_cypher) is responsible for detecting Mode 2 availability
    and raising UnsupportedOperationError before SQL is executed if EMBEDDING() is absent.

    Precondition: This function is ONLY called for procedure_name == "ivg.vector.search".
    """
    if proc.procedure_name != "ivg.vector.search":
        raise ValueError(f"Unknown procedure: {proc.procedure_name!r}. Only 'ivg.vector.search' is supported.")

    args = proc.arguments
    if len(args) < 4:
        raise ValueError(
            f"ivg.vector.search requires at least 4 arguments "
            f"(label, property, query_input, limit), got {len(args)}"
        )

    # Resolve label (arg 0) — must be a string literal
    label_arg = args[0]
    if not isinstance(label_arg, ast.Literal) or not isinstance(label_arg.value, str):
        raise ValueError("ivg.vector.search: first argument (label) must be a string literal")
    label = label_arg.value
    # Security: validate label against allowlist-based table name check (reuse same validator)
    validate_table_name("rdf_labels")  # warm validator cache
    # Label itself goes into SQL as a parameterized value, not as a table name — safe.

    # Resolve property (arg 1) — string literal, typically "embedding"
    prop_arg = args[1]
    if not isinstance(prop_arg, ast.Literal) or not isinstance(prop_arg.value, str):
        raise ValueError("ivg.vector.search: second argument (property) must be a string literal")
    # property name is unused in SQL (embedding column is always 'emb') but stored for future use

    # Resolve query_input (arg 2) — list[float] or str (for Mode 2)
    query_input_arg = args[2]
    if isinstance(query_input_arg, ast.Literal):
        raw = query_input_arg.value
        # Parser wraps list literals as list[ast.Literal]; unwrap to list[float]
        if isinstance(raw, list):
            query_input: Any = [item.value if isinstance(item, ast.Literal) else item for item in raw]
        else:
            query_input = raw
    elif isinstance(query_input_arg, ast.Variable):
        var_name = query_input_arg.name
        if var_name in context.input_params:
            query_input = context.input_params[var_name]
        else:
            raise ValueError(f"ivg.vector.search: parameter '${var_name}' not found in params")
    else:
        raise ValueError("ivg.vector.search: third argument (query_input) must be a literal or parameter")

    # Resolve limit (arg 3) — integer literal or parameter
    limit_arg = args[3]
    if isinstance(limit_arg, ast.Literal):
        limit_val = limit_arg.value
    elif isinstance(limit_arg, ast.Variable):
        var_name = limit_arg.name
        if var_name in context.input_params:
            limit_val = context.input_params[var_name]
        else:
            raise ValueError(f"ivg.vector.search: parameter '${var_name}' not found in params")
    else:
        raise ValueError("ivg.vector.search: fourth argument (limit) must be an integer literal or parameter")
    try:
        limit_int = int(limit_val)
    except (TypeError, ValueError):
        raise ValueError(f"ivg.vector.search: limit must be an integer, got {limit_val!r}")
    if limit_int <= 0:
        raise ValueError(f"ivg.vector.search: limit must be > 0, got {limit_int}")

    # Resolve options
    raw_options = proc.options or {}
    # Resolve any Literal-wrapped option values
    options: Dict[str, Any] = {}
    for k, v in raw_options.items():
        options[k] = v.value if isinstance(v, ast.Literal) else v

    similarity = options.get("similarity", "cosine")
    if similarity not in ("cosine", "dot_product"):
        raise ValueError(f"ivg.vector.search: similarity must be 'cosine' or 'dot_product', got {similarity!r}")

    vector_fn = "VECTOR_COSINE" if similarity == "cosine" else "VECTOR_DOT_PRODUCT"
    emb_table = _table("kg_NodeEmbeddings")
    labels_tbl = _table("rdf_labels")

    # Determine mode and build SQL expression + ordered params
    if isinstance(query_input, list):
        # Mode 1: pre-computed vector
        # Use TO_VECTOR(?, DOUBLE) — unquoted keyword — to match VECTOR(DOUBLE, N) column type.
        # IRIS requires the type specifier as a keyword literal (not a string literal or bind param).
        vec_json = json.dumps(query_input)
        similarity_expr = f"{vector_fn}(e.emb, TO_VECTOR(?, DOUBLE))"
        ordered_params: List[Any] = [vec_json, label]
    elif isinstance(query_input, str):
        # Mode 2: text via IRIS EMBEDDING() function
        embedding_config: Optional[str] = options.get("embedding_config")
        if not embedding_config:
            raise ValueError(
                "ivg.vector.search: 'embedding_config' option required when query_input is a string (Mode 2)"
            )
        similarity_expr = f"{vector_fn}(e.emb, EMBEDDING(?, ?))"
        ordered_params = [query_input, embedding_config, label]
    else:
        raise ValueError(
            f"ivg.vector.search: query_input must be a list[float] or str, got {type(query_input).__name__}"
        )

    # Build VecSearch CTE SQL
    # Uses HNSW index automatically via TOP N + ORDER BY similarity DESC pattern
    # NOTE: kg_NodeEmbeddings uses 'id' as the primary key column (not 'node_id')
    cte_sql = (
        f"SELECT TOP {limit_int} e.id AS node, {similarity_expr} AS score\n"
        f"FROM {emb_table} e\n"
        f"JOIN {labels_tbl} lbl ON lbl.s = e.id AND lbl.label = ?\n"
        f"ORDER BY score DESC"
    )

    context.all_stage_params.extend(ordered_params)
    context.stages.insert(0, f"VecSearch AS (\n{cte_sql}\n)")

    # Pre-populate variable_aliases so subsequent MATCH/RETURN can resolve YIELD variables.
    # 'node' is the id column aliased as 'node'; 'score' is a scalar float — mark it accordingly.
    for item in proc.yield_items:
        context.variable_aliases[item] = "VecSearch"
    if "score" in proc.yield_items:
        context.scalar_variables.add("score")


def translate_to_sql(cypher_query: ast.CypherQuery, params: Optional[Dict[str, Any]] = None) -> SQLQuery:
    context = TranslationContext()
    context.input_params = params or {}
    metadata = QueryMetadata()
    is_transactional = False

    # Handle CALL procedure (vector search) — emits VecSearch CTE before any MATCH stages
    if cypher_query.procedure_call is not None:
        translate_procedure_call(cypher_query.procedure_call, context)
        # If there are no subsequent query parts (pure CALL ... YIELD ... RETURN), set FROM now.
        # If there are query parts, FROM is set per-part in the loop below.
        if not cypher_query.query_parts:
            context.from_clauses.append("VecSearch")

    for i, part in enumerate(cypher_query.query_parts):
        context.select_items, context.from_clauses, context.join_clauses = [], [], []
        context.where_conditions, context.group_by_items = [], []
        context.select_params, context.join_params, context.where_params = [], [], []
        if i > 0:
            context.from_clauses.append(f"Stage{i}")
        elif cypher_query.procedure_call is not None:
            # Re-add VecSearch as the primary FROM source for the first query part
            # when a CALL procedure is present (it was cleared by the reset above).
            context.from_clauses.append("VecSearch")
        for clause in part.clauses:
            if isinstance(clause, ast.MatchClause): translate_match_clause(clause, context, metadata)
            elif isinstance(clause, ast.UnwindClause): translate_unwind_clause(clause, context)
            elif isinstance(clause, ast.UpdatingClause):
                is_transactional = True
                translate_updating_clause(clause, context, metadata)
            elif isinstance(clause, ast.WhereClause): translate_where_clause(clause, context)
        if part.with_clause:
            translate_with_clause(part.with_clause, context)
            sql, stage_params = context.build_stage_sql(part.with_clause.distinct)
            context.all_stage_params.extend(stage_params)
            context.stages.append(f"Stage{i+1} AS (\n{sql}\n)")
            new_aliases = {}
            for item in part.with_clause.items:
                alias = item.alias or (item.expression.name if isinstance(item.expression, ast.Variable) else None)
                if alias: new_aliases[alias] = f"Stage{i+1}"
            context.variable_aliases = new_aliases

    # 2. Final stage (RETURN)
    # If the last QueryPart had a WITH clause, we must select from that CTE stage.
    # Otherwise, we continue with the context of the last QueryPart (e.g. current MATCH joins).
    last_part_had_with = cypher_query.query_parts[-1].with_clause is not None if cypher_query.query_parts else False
    if context.stages and last_part_had_with:
        context.select_items, context.select_params = [], []
        context.from_clauses, context.join_clauses, context.join_params = [f"Stage{len(context.stages)}"], [], []
        context.where_conditions, context.where_params = [], []
    
    if cypher_query.return_clause: translate_return_clause(cypher_query.return_clause, context)
    
    # Process ORDER BY BEFORE building SQL to ensure JOINs are included
    order_by_items = preprocess_order_by(cypher_query, context)
    
    if is_transactional:
        stmts, all_params = [], []
        for s, p in context.dml_statements:
            stmts.append(s); all_params.append(p)
        if cypher_query.return_clause:
            sql, p = context.build_stage_sql(cypher_query.return_clause.distinct)
            sql = apply_pagination(sql, cypher_query, context, order_by_items)
            if context.stages:
                sql = "WITH " + ",\n".join(context.stages) + "\n" + sql
                all_params.append(context.all_stage_params + p)
            else: all_params.append(p)
            stmts.append(sql)
        return SQLQuery(sql=stmts, parameters=all_params, query_metadata=metadata, is_transactional=True)
    else:
        sql, p = context.build_stage_sql(cypher_query.return_clause.distinct if cypher_query.return_clause else False)
        sql = apply_pagination(sql, cypher_query, context, order_by_items)
        if context.stages:
            sql = "WITH " + ",\n".join(context.stages) + "\n" + sql
            return SQLQuery(sql=sql, parameters=[context.all_stage_params + p], query_metadata=metadata)
        return SQLQuery(sql=sql, parameters=[p], query_metadata=metadata)


def preprocess_order_by(query: ast.CypherQuery, context: TranslationContext) -> list:
    """Process ORDER BY expressions BEFORE building SQL to ensure JOINs are added."""
    if not query.order_by_clause:
        return []
    items = []
    for item in query.order_by_clause.items:
        expr = translate_expression(item.expression, context, segment="where")
        # IRIS doesn't support NULLS LAST, so we omit it
        items.append(f"{expr} {'ASC' if item.ascending else 'DESC'}")
    return items


def _resolve_pagination_value(value, context: TranslationContext) -> Optional[int]:
    """Resolve a SKIP/LIMIT value that may be an integer literal or a parameter variable."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, ast.Variable):
        resolved = context.input_params.get(value.name)
        if resolved is None:
            raise ValueError(f"Parameter '${value.name}' used in SKIP/LIMIT but not provided in params dict")
        return int(resolved)
    return int(value)


def apply_pagination(sql: str, query: ast.CypherQuery, context: TranslationContext, order_by_items: list = None) -> str:
    if order_by_items:
        sql += f"\nORDER BY {', '.join(order_by_items)}"
    limit = _resolve_pagination_value(query.limit, context)
    skip = _resolve_pagination_value(query.skip, context)
    if limit is not None: sql += f"\nLIMIT {limit}"
    if skip is not None: sql += f"\nOFFSET {skip}"
    return sql


def translate_updating_clause(upd, context, metadata):
    if isinstance(upd, ast.CreateClause): translate_create_clause(upd, context, metadata)
    elif isinstance(upd, ast.DeleteClause): translate_delete_clause(upd, context, metadata)
    elif isinstance(upd, ast.MergeClause): translate_merge_clause(upd, context, metadata)
    elif isinstance(upd, ast.SetClause): translate_set_clause(upd, context, metadata)
    elif isinstance(upd, ast.RemoveClause): translate_remove_clause(upd, context, metadata)


def translate_unwind_clause(unwind, context):
    expr = translate_expression(unwind.expression, context, segment="join")
    if isinstance(unwind.expression, ast.Variable) and unwind.expression.name in context.input_params:
        val = context.input_params[unwind.expression.name]
        if isinstance(val, list): context.join_params[-1] = json.dumps(val)
    alias = context.register_variable(unwind.alias, prefix="u")
    context.from_clauses.append(f"JSON_TABLE({expr}, '$[*]' COLUMNS ({unwind.alias} VARCHAR(1000) PATH '$')) {alias}")


def translate_create_clause(create, context, metadata):
    for node in create.pattern.nodes:
        if node.variable and node.variable in context.variable_aliases: continue
        node_id_expr = node.properties.get("id") or node.properties.get("node_id")
        if node_id_expr is None: raise ValueError("CREATE node requires an 'id' property")
        
        if isinstance(node_id_expr, ast.Variable):
            var_alias = context.variable_aliases.get(node_id_expr.name)
            if not var_alias: raise ValueError(f"Undefined: {node_id_expr.name}")
            
            # 1.1 Insert into nodes
            # We need to capture the parameters specifically for this rowset subquery
            sql, p = context.build_stage_sql(select_override=f"SELECT {var_alias}.{node_id_expr.name} AS node_id")
            # Filter parameters to only include those referenced in the SQL subquery
            # Since build_stage_sql just concatenates all params, and we used ? for all, 
            # we need to ensure the number of ? matches len(p).
            # Our current build_stage_sql is correct because it only includes params for the current stage.
            context.add_dml(f"INSERT INTO {_table('nodes')} (node_id) SELECT t.node_id FROM ({sql}) AS t WHERE NOT EXISTS (SELECT 1 FROM {_table('nodes')} WHERE node_id = t.node_id)", p)
            for label in node.labels:
                context.add_dml(f"INSERT INTO {_table('rdf_labels')} (s, label) SELECT t.node_id, ? FROM ({sql}) AS t WHERE NOT EXISTS (SELECT 1 FROM {_table('rdf_labels')} WHERE s = t.node_id AND label = ?)", [label] + p + [label])
        else:
            node_id = node_id_expr.value if isinstance(node_id_expr, ast.Literal) else node_id_expr
            context.add_dml(f"INSERT INTO {_table('nodes')} (node_id) SELECT ? WHERE NOT EXISTS (SELECT 1 FROM {_table('nodes')} WHERE node_id = ?)", [node_id, node_id])
            for label in node.labels:
                context.add_dml(f"INSERT INTO {_table('rdf_labels')} (s, label) SELECT ?, ? WHERE NOT EXISTS (SELECT 1 FROM {_table('rdf_labels')} WHERE s = ? AND label = ?)", [node_id, label, node_id, label])
            for k, v in node.properties.items():
                val = v.value if isinstance(v, ast.Literal) else v
                # Property 'id' or 'node_id' is stored in both nodes table AND rdf_props
                # for Cypher query consistency.
                context.add_dml(f"INSERT INTO {_table('rdf_props')} (s, \"key\", val) SELECT ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM {_table('rdf_props')} WHERE s = ? AND \"key\" = ?)", [node_id, k, val, node_id, k])
        if node.variable: context.register_variable(node.variable)
    
    for i, rel in enumerate(create.pattern.relationships):
        source_node, target_node = create.pattern.nodes[i], create.pattern.nodes[i+1]
        s_id_expr = source_node.properties.get("id") or source_node.properties.get("node_id")
        t_id_expr = target_node.properties.get("id") or target_node.properties.get("node_id")
        s_id = s_id_expr.value if isinstance(s_id_expr, ast.Literal) else s_id_expr if not isinstance(s_id_expr, ast.Variable) else None
        t_id = t_id_expr.value if isinstance(t_id_expr, ast.Literal) else t_id_expr if not isinstance(t_id_expr, ast.Variable) else None
        if s_id and t_id:
            for rt in rel.types: context.add_dml(f"INSERT INTO {_table('rdf_edges')} (s, p, o_id) VALUES (?, ?, ?)", [s_id, rt, t_id])
        else:
            s_alias = context.variable_aliases.get(source_node.variable) if source_node.variable else None
            t_alias = context.variable_aliases.get(target_node.variable) if target_node.variable else None
            s_expr, s_p = ("?", [s_id]) if s_id else (f"{s_alias}.{source_node.variable}" if s_alias and s_alias.startswith('Stage') else f"{s_alias}.node_id", [])
            t_expr, t_p = ("?", [t_id]) if t_id else (f"{t_alias}.{target_node.variable}" if t_alias and t_alias.startswith('Stage') else f"{t_alias}.node_id", [])
            for rt in rel.types:
                sql, p = context.build_stage_sql(select_override=f"SELECT {s_expr}, ?, {t_expr}")
                context.add_dml(f"INSERT INTO {_table('rdf_edges')} (s, p, o_id) {sql}", s_p + [rt] + t_p + p)


def translate_delete_clause(delete, context, metadata):
    for var in delete.expressions:
        alias = context.variable_aliases.get(var.name)
        if not alias: raise ValueError(f"Undefined: {var.name}")
        subquery, subparams = context.build_stage_sql(select_override=f"SELECT {alias}.node_id")
        if delete.detach: context.add_dml(f"DELETE FROM {_table('rdf_edges')} WHERE s IN ({subquery}) OR o_id IN ({subquery})", subparams + subparams)
        if not alias.startswith('e'):
            context.add_dml(f"DELETE FROM {_table('rdf_labels')} WHERE s IN ({subquery})", subparams)
            context.add_dml(f"DELETE FROM {_table('rdf_props')} WHERE s IN ({subquery})", subparams)
            context.add_dml(f"DELETE FROM {_table('nodes')} WHERE node_id IN ({subquery})", subparams)
        else: context.add_dml(f"DELETE FROM {_table('rdf_edges')} WHERE s = (SELECT s FROM {_table('rdf_edges')} {alias}) AND p = (SELECT p FROM {_table('rdf_edges')} {alias}) AND o_id = (SELECT o_id FROM {_table('rdf_edges')} {alias})", [])


def translate_merge_clause(merge, context, metadata):
    translate_create_clause(ast.CreateClause(merge.pattern), context, metadata)
    for action, is_create in [(merge.on_create, True), (merge.on_match, False)]:
        if action:
            for item in action.items:
                if isinstance(item, ast.SetItem) and isinstance(item.expression, ast.PropertyReference):
                    node_id = context.variable_aliases.get(item.expression.variable)
                    k, v = item.expression.property_name, item.value
                    val = v.value if isinstance(v, ast.Literal) else v
                    if is_create: context.add_dml(f"INSERT INTO {_table('rdf_props')} (s, \"key\", val) SELECT node_id, ?, ? FROM {_table('nodes')} WHERE node_id = ? AND NOT EXISTS (SELECT 1 FROM {_table('rdf_props')} WHERE s = ? AND \"key\" = ?)", [k, val, node_id, node_id, k])
                    else: context.add_dml(f"UPDATE {_table('rdf_props')} SET val = ? WHERE s = ? AND \"key\" = ?", [val, node_id, k])


def translate_set_clause(set_cl, context, metadata):
    for item in set_cl.items:
        if isinstance(item.expression, ast.PropertyReference):
            alias, k, v = context.variable_aliases.get(item.expression.variable), item.expression.property_name, item.value
            val = v.value if isinstance(v, ast.Literal) else v
            subquery, subparams = context.build_stage_sql(select_override=f"SELECT {alias}.node_id")
            context.add_dml(f"UPDATE {_table('rdf_props')} SET val = ? WHERE s IN ({subquery}) AND \"key\" = ?", [val] + subparams + [k])
            context.add_dml(f"INSERT INTO {_table('rdf_props')} (s, \"key\", val) SELECT node_id, ?, ? FROM {_table('nodes')} WHERE node_id IN ({subquery}) AND NOT EXISTS (SELECT 1 FROM {_table('rdf_props')} WHERE s = {_table('nodes')}.node_id AND \"key\" = ?)", [k, val] + subparams + [k])
        elif isinstance(item.expression, ast.Variable):
            alias, label = context.variable_aliases.get(item.expression.name), str(item.value.value if isinstance(item.value, ast.Literal) else item.value)
            subquery, subparams = context.build_stage_sql(select_override=f"SELECT {alias}.node_id")
            context.add_dml(f"INSERT INTO {_table('rdf_labels')} (s, label) SELECT node_id, ? FROM {_table('nodes')} WHERE node_id IN ({subquery}) AND NOT EXISTS (SELECT 1 FROM {_table('rdf_labels')} WHERE s = {_table('nodes')}.node_id AND label = ?)", [label] + subparams + [label])


def translate_remove_clause(remove, context, metadata):
    for item in remove.items:
        if isinstance(item.expression, ast.PropertyReference):
            alias, k = context.variable_aliases.get(item.expression.variable), item.expression.property_name
            subquery, subparams = context.build_stage_sql(select_override=f"SELECT {alias}.node_id")
            context.add_dml(f"DELETE FROM {_table('rdf_props')} WHERE s IN ({subquery}) AND \"key\" = ?", subparams + [k])


def translate_match_clause(match_clause, context, metadata):
    for pattern in match_clause.patterns:
        if not pattern.nodes: continue
        translate_node_pattern(pattern.nodes[0], context, metadata, optional=match_clause.optional)
        for i, rel in enumerate(pattern.relationships):
            translate_relationship_pattern(rel, pattern.nodes[i], pattern.nodes[i+1], context, metadata, optional=match_clause.optional)
            translate_node_pattern(pattern.nodes[i+1], context, metadata, optional=match_clause.optional)


def translate_node_pattern(node, context, metadata, optional=False):
    if node.variable and node.variable in context.variable_aliases:
        # If variable is already bound, we don't need to join nodes or labels again
        return
    alias = context.register_variable(node.variable) if node.variable else context.next_alias("n")
    jt = "LEFT OUTER JOIN" if optional else "JOIN"
    nodes_tbl = _table('nodes')
    if not context.from_clauses: context.from_clauses.append(f"{nodes_tbl} {alias}")
    elif f"{nodes_tbl} {alias}" not in context.from_clauses and not any(alias in j for j in context.join_clauses): context.join_clauses.append(f"CROSS JOIN {nodes_tbl} {alias}")
    for label in node.labels:
        l_alias = context.next_alias("l")
        context.join_clauses.append(f"{jt} {_table('rdf_labels')} {l_alias} ON {l_alias}.s = {alias}.node_id AND {l_alias}.label = {context.add_join_param(label)}")
        if not optional: context.where_conditions.append(f"{l_alias}.s IS NOT NULL")
    for k, v in node.properties.items():
        val_sql = translate_expression(v, context, segment="where")
        if k in ("node_id", "id"):
            context.where_conditions.append(f"{alias}.node_id = {val_sql}")
        else:
            p_alias = context.next_alias("p")
            context.join_clauses.append(
                f"{jt} {_table('rdf_props')} {p_alias} "
                f"ON {p_alias}.s = {alias}.node_id AND {p_alias}.\"key\" = {context.add_join_param(k)}"
            )
            if optional:
                context.where_conditions.append(f"({p_alias}.s IS NULL OR {p_alias}.val = {val_sql})")
            else:
                context.where_conditions.append(f"{p_alias}.val = {val_sql}")


def translate_relationship_pattern(rel, source_node, target_node, context, metadata, optional=False):
    source_alias = context.variable_aliases[source_node.variable]
    is_new_target = target_node.variable not in context.variable_aliases
    target_alias = context.register_variable(target_node.variable)
    edge_alias = context.register_variable(rel.variable, prefix="e") if rel.variable else context.next_alias("e")
    
    # Stage CTEs expose the variable name as the column; VecSearch exposes 'node' as the column.
    # Regular node tables expose 'node_id'. CTE aliases that start with 'Stage' or equal 'VecSearch'
    # use the variable name directly.
    def _node_col(variable, alias):
        if alias.startswith('Stage') or alias == 'VecSearch':
            return variable
        return "node_id"
    s_col = _node_col(source_node.variable, source_alias)
    t_col = _node_col(target_node.variable, target_alias)
    jt = "LEFT OUTER JOIN" if optional else "JOIN"
    
    if rel.direction == ast.Direction.OUTGOING:
        edge_cond, target_on = f"{edge_alias}.s = {source_alias}.{s_col}", f"{target_alias}.{t_col} = {edge_alias}.o_id"
    elif rel.direction == ast.Direction.INCOMING:
        edge_cond, target_on = f"{edge_alias}.o_id = {source_alias}.{s_col}", f"{target_alias}.{t_col} = {edge_alias}.s"
    else:
        edge_cond = f"({edge_alias}.s = {source_alias}.{s_col} OR {edge_alias}.o_id = {source_alias}.{s_col})"
        target_on = f"({target_alias}.{t_col} = {edge_alias}.o_id OR {target_alias}.{t_col} = {edge_alias}.s)"
        
    if rel.types:
        if len(rel.types) == 1: edge_cond += f" AND {edge_alias}.p = {context.add_join_param(rel.types[0])}"
        else: edge_cond += f" AND {edge_alias}.p IN ({', '.join([context.add_join_param(t) for t in rel.types])})"
        
    context.join_clauses.append(f"{jt} {_table('rdf_edges')} {edge_alias} ON {edge_cond}")
    
    if is_new_target and not target_alias.startswith('Stage'):
        context.join_clauses.append(f"{jt} {_table('nodes')} {target_alias} ON {target_on}")
    else:
        # If target node is already joined, add the connection as a WHERE condition
        context.where_conditions.append(target_on)


def translate_where_clause(where, context):
    context.where_conditions.append(translate_boolean_expression(where.expression, context))


def translate_boolean_expression(expr, context) -> str:
    if not isinstance(expr, ast.BooleanExpression): return translate_expression(expr, context, segment="where")
    op = expr.operator
    if op == ast.BooleanOperator.AND: return "(" + " AND ".join(translate_boolean_expression(o, context) for o in expr.operands) + ")"
    if op == ast.BooleanOperator.OR: return "(" + " OR ".join(translate_boolean_expression(o, context) for o in expr.operands) + ")"
    if op == ast.BooleanOperator.NOT: return f"NOT ({translate_boolean_expression(expr.operands[0], context)})"
    left_expr = expr.operands[0]
    right_expr = expr.operands[1] if len(expr.operands) > 1 else None
    left = translate_expression(left_expr, context, segment="where")
    if op == ast.BooleanOperator.IS_NULL: return f"{left} IS NULL"
    if op == ast.BooleanOperator.IS_NOT_NULL: return f"{left} IS NOT NULL"
    right = translate_expression(right_expr, context, segment="where")
    if op in (
        ast.BooleanOperator.LESS_THAN,
        ast.BooleanOperator.LESS_THAN_OR_EQUAL,
        ast.BooleanOperator.GREATER_THAN,
        ast.BooleanOperator.GREATER_THAN_OR_EQUAL,
    ):
        if isinstance(left_expr, ast.PropertyReference):
            left = f"CAST({left} AS DOUBLE)"
        if isinstance(right_expr, ast.PropertyReference):
            right = f"CAST({right} AS DOUBLE)"
    if op == ast.BooleanOperator.EQUALS: return f"{left} = {right}"
    if op == ast.BooleanOperator.NOT_EQUALS: return f"{left} <> {right}"
    if op == ast.BooleanOperator.LESS_THAN: return f"{left} < {right}"
    if op == ast.BooleanOperator.LESS_THAN_OR_EQUAL: return f"{left} <= {right}"
    if op == ast.BooleanOperator.GREATER_THAN: return f"{left} > {right}"
    if op == ast.BooleanOperator.GREATER_THAN_OR_EQUAL: return f"{left} >= {right}"
    if op == ast.BooleanOperator.STARTS_WITH: return f"{left} LIKE ({right} || '%')"
    if op == ast.BooleanOperator.ENDS_WITH: return f"{left} LIKE ('%' || {right})"
    if op == ast.BooleanOperator.CONTAINS: return f"{left} LIKE ('%' || {right} || '%')"
    if op == ast.BooleanOperator.IN: return f"{left} IN {right}"
    raise ValueError(f"Unsupported operator: {op}")


def translate_expression(expr, context, segment="select") -> str:
    if isinstance(expr, ast.PropertyReference):
        alias = context.variable_aliases.get(expr.variable)
        if not alias: raise ValueError(f"Undefined: {expr.variable}")
        if alias.startswith('Stage'):
            if expr.property_name in ("node_id", "id"): return f"{alias}.{expr.variable}"
            return f"{alias}.{expr.variable}_{expr.property_name}"
        if expr.property_name in ("node_id", "id"): return f"{alias}.node_id"
        p_alias = context.next_alias("p")
        context.join_clauses.append(f"JOIN {_table('rdf_props')} {p_alias} ON {p_alias}.s = {alias}.node_id AND {p_alias}.\"key\" = {context.add_join_param(expr.property_name)}")
        return f"{p_alias}.val"
    if isinstance(expr, ast.Variable):
        alias = context.variable_aliases.get(expr.name)
        if not alias:
            if expr.name in context.input_params:
                v = context.input_params[expr.name]
                if segment == "select": return context.add_select_param(v)
                if segment == "join": return context.add_join_param(v)
                return context.add_where_param(v)
            raise ValueError(f"Undefined: {expr.name}")
        if alias.startswith('Stage'): return f"{alias}.{expr.name}"
        if alias.startswith('e'): return f"{alias}.p"
        # Scalar variables from CALL YIELD (e.g. 'score') are referenced by column name directly
        if expr.name in context.scalar_variables: return f"{alias}.{expr.name}"
        return f"{alias}.node_id"
    if isinstance(expr, ast.Literal):
        v = expr.value
        # Boolean/NULL literals translate to SQL constants — no parameterization needed
        if v is True: return "1"
        if v is False: return "0"
        if v is None: return "NULL"
        if segment == "select": return context.add_select_param(v)
        if segment == "join": return context.add_join_param(v)
        return context.add_where_param(v)
    if isinstance(expr, ast.AggregationFunction):
        arg = translate_expression(expr.argument, context, segment=segment) if expr.argument else "*"
        fn = "JSON_ARRAYAGG" if expr.function_name.upper() == "COLLECT" else expr.function_name.upper()
        return f"{fn}({'DISTINCT ' if expr.distinct else ''}{arg})"
    if isinstance(expr, ast.FunctionCall):
        fn = expr.function_name.lower()
        if fn in ("shortestpath", "allshortestpaths"):
            from .algorithms.paths import generate_shortest_path_sql
            args = [translate_expression(arg, context, segment=segment) for arg in expr.arguments]
            s_id, t_id = (args[0] if len(args) > 0 else "NULL"), (args[1] if len(args) > 1 else "NULL")
            inner = generate_shortest_path_sql("?", "?", 10, fn == "allshortestpaths")
            return f"(SELECT TOP 1 path FROM ({inner}) WHERE 1=1)"
        fn, args = expr.function_name.lower(), [translate_expression(arg, context, segment=segment) for arg in expr.arguments]
        if fn in ("id", "type"): return args[0] if args else "NULL"
        if fn == "labels": return labels_subquery(args[0] if args else "NULL")
        if fn == "properties": return properties_subquery(args[0] if args else "NULL")
        # Cypher → SQL function name mapping
        _CYPHER_FN_MAP = {
            "tolower": "LOWER",
            "toupper": "UPPER",
            "trim": "TRIM",
            "ltrim": "LTRIM",
            "rtrim": "RTRIM",
            "tostring": "CAST",   # handled below
            "tointeger": "CAST",  # handled below
            "tofloat": "CAST",    # handled below
            "size": "LENGTH",
            "length": "LENGTH",
            "substring": "SUBSTRING",
            "left": "LEFT",
            "right": "RIGHT",
            "split": "STRTOK_TO_TABLE",  # IRIS equivalent
            "replace": "REPLACE",
            "reverse": "REVERSE",
            "abs": "ABS",
            "ceil": "CEILING",
            "floor": "FLOOR",
            "round": "ROUND",
            "sqrt": "SQRT",
            "sign": "SIGN",
            "coalesce": "COALESCE",
            "nullif": "NULLIF",
            "exists": "EXISTS",
            "keys": "NULL",  # not directly supported
            "toboolean": "CASE WHEN",  # handled below
        }
        sql_fn = _CYPHER_FN_MAP.get(fn, fn.upper())
        return f"{sql_fn}({', '.join(args)})"
    return "NULL"


def translate_return_clause(ret, context):
    has_agg = any(isinstance(i.expression, ast.AggregationFunction) for i in ret.items)
    for item in ret.items:
        if isinstance(item.expression, ast.Variable):
            var_name = item.expression.name
            alias_name = context.variable_aliases.get(var_name)
            # Skip node expansion for scalar variables (e.g. 'score' from CALL YIELD)
            is_scalar = var_name in context.scalar_variables
            if alias_name and not alias_name.startswith("e") and not is_scalar:
                prefix = item.alias or var_name
                # VecSearch CTE columns are named by their alias (e.g. 'node'), not 'node_id'
                node_expr = f"{alias_name}.{var_name}" if alias_name.startswith("Stage") or alias_name == "VecSearch" else f"{alias_name}.node_id"
                context.select_items.append(f"{node_expr} AS {prefix}_id")
                context.select_items.append(f"{labels_subquery(node_expr)} AS {prefix}_labels")
                context.select_items.append(f"{properties_subquery(node_expr)} AS {prefix}_props")
                continue
        sql = translate_expression(item.expression, context, segment="select")
        alias = item.alias
        if alias is None:
            if isinstance(item.expression, ast.PropertyReference): alias = f"{item.expression.variable}_{item.expression.property_name}"
            elif isinstance(item.expression, ast.Variable): alias = item.expression.name
            elif isinstance(item.expression, (ast.AggregationFunction, ast.FunctionCall)): alias = f"{item.expression.function_name}_res"
        if alias: context.select_items.append(f"{sql} AS {alias.replace('.', '_')}")
        else: context.select_items.append(sql)
        if has_agg and not isinstance(item.expression, ast.AggregationFunction): context.group_by_items.append(sql)


def translate_with_clause(with_clause, context):
    has_agg = any(isinstance(i.expression, ast.AggregationFunction) for i in with_clause.items)
    for item in with_clause.items:
        sql = translate_expression(item.expression, context, segment="select")
        alias = item.alias
        if alias is None:
            if isinstance(item.expression, ast.PropertyReference): alias = f"{item.expression.variable}_{item.expression.property_name}"
            elif isinstance(item.expression, ast.Variable): alias = item.expression.name
            elif isinstance(item.expression, ast.AggregationFunction): alias = f"{item.expression.function_name}"
        if alias is None: alias = context.next_alias("v")
        context.select_items.append(f"{sql} AS {alias.replace('.', '_')}")
        if has_agg and not isinstance(item.expression, ast.AggregationFunction): context.group_by_items.append(sql)
    if with_clause.where_clause: context.where_conditions.append(translate_boolean_expression(with_clause.where_clause.expression, context))
