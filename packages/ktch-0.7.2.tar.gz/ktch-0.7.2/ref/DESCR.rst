.. _image_passiflora_leaves_dataset:

Passiflora Leaf Scan Images dataset
====================================

**Dataset Characteristics:**

.. list-table::
   :widths: 30 70

   * - Classes
     - 10 (species)
   * - Samples total
     - 25 (scan images)
   * - Image size
     - 1268 x 1748 pixels, RGB (3 channels)
   * - Image format
     - PNG (lossless)
   * - Features
     - uint8, [0, 255]
   * - Total size
     - ~45 MB
   * - License
     - CC0 (Public Domain)

|

Scanned leaf images of 10 *Passiflora* (passion flower) species, selected
to represent a wide range of leaf morphologies from simple elliptical shapes
to deeply lobed forms. Each image contains multiple leaves from a single
plant individual, arranged on a flatbed scanner.

This dataset is intended for teaching and demonstrating outline extraction,
image-based morphometric analysis, and shape classification of biological
specimens.

Content
-------

The dataset contains 25 PNG images and a metadata CSV file.

**Images** (``images/`` directory):

Each image is a flatbed scan of multiple leaves from one individual plant.
Leaves are arranged from tip (youngest, leaf 1) to base (oldest), capturing
developmental variation within a single plant. Images have been resized to
1/4 of the original TIFF resolution using area-based interpolation
(``cv2.INTER_AREA``) to preserve edge quality for outline extraction.

**Metadata** (``metadata.csv``):

.. list-table::
   :header-rows: 1

   * - Column
     - Type
     - Description
   * - ``image_id``
     - str
     - Filename stem (e.g., ``Pcae1_1_8``), serves as scan identifier
   * - ``abbreviation``
     - str
     - 4-letter species code (e.g., ``Pcae`` for *P. caerulea*)
   * - ``genus``
     - str
     - Genus name (always ``Passiflora``)
   * - ``species``
     - str
     - Specific epithet (e.g., ``caerulea``)
   * - ``individual_id``
     - str
     - Plant identifier (e.g., ``Pcae1``)
   * - ``leaf_start``
     - int
     - First leaf number in the scan (tip side)
   * - ``leaf_end``
     - int
     - Last leaf number in the scan (base side)

Species
-------

.. list-table::
   :header-rows: 1

   * - Abbreviation
     - Species
     - Leaf morphology
     - Images
     - Leaves
   * - ``Pcor``
     - *P. coriacea*
     - Simple elliptical
     - 1
     - 7
   * - ``Prub``
     - *P. rubra*
     - 2-lobed
     - 1
     - 10
   * - ``Pmal``
     - *P. malacophylla*
     - Simple round
     - 2
     - 11
   * - ``Pedu``
     - *P. edulis*
     - 3-lobed
     - 5
     - 20
   * - ``Pcae``
     - *P. caerulea*
     - 3-lobed
     - 2
     - 16
   * - ``Pcin``
     - *P. cincinnata*
     - 3-lobed (deep)
     - 4
     - 14
   * - ``Pmis``
     - *P. misera*
     - Deep 2-lobed
     - 1
     - 14
   * - ``Pgra``
     - *P. gracilis*
     - 3-lobed (narrow)
     - 3
     - 18
   * - ``Pcri``
     - *P. cristalina*
     - 5-lobed
     - 4
     - 19
   * - ``Psub``
     - *P. suberosa*
     - Variable 3-lobed
     - 2
     - 9

The 10 species were selected from the original 40-species dataset to span
the full morphological range: from simple, unlobed leaves (*P. coriacea*)
to complex 5-lobed forms (*P. cristalina*). This diversity makes the
dataset suitable for demonstrating both simple and advanced outline
extraction and classification techniques.

Source
------

This dataset is a subset of the data published in:

.. [1] Chitwood, D. H. and Otoni, W. C. (2017).
   "Morphometric analysis of *Passiflora* leaves: the relationship between
   landmarks of the vasculature and elliptical Fourier descriptors of the
   blade." *GigaScience*, 6(1), giw008.
   https://doi.org/10.1093/gigascience/giw008

The original data (555 scan images covering 3,300+ leaves from 40 species)
is available from GigaDB:

.. [2] Chitwood, D. H. and Otoni, W. C. (2016).
   "Supporting data for 'Morphometric analysis of Passiflora leaves'."
   *GigaScience Database*.
   https://doi.org/10.5524/100251

License
-------

CC0 1.0 Universal (Public Domain Dedication).
