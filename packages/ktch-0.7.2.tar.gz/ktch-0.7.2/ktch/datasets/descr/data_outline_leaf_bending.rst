Synthetic 3D Leaf Bending Outline Dataset
==========================================
