"""Tests for ktch.plot module."""
