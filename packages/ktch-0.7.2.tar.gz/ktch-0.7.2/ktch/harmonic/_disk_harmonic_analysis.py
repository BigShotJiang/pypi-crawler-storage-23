"""Disk Harmonic Analysis"""

# Copyright 2025 Koji Noshita
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings
from typing import List

import numpy as np
import numpy.typing as npt
import pandas as pd
import scipy as sp
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.parallel import Parallel, delayed


class DiskHarmonicAnalysis(TransformerMixin, BaseEstimator):
    r"""Disk Harmonic Analysis

    Parameters
    ------------------------
    n_harmonics: int, default=10
        Number of harmonics to use ($n_\mathrm{max}$).
    n_jobs: int, default=None
        The number of jobs to run in parallel. None means 1 unless in a
        joblib.parallel_backend context. -1 means using all processors.
    verbose: int, default=0
        The verbosity level.


    Notes
    ------------------------
    [Zhang_etal_2017]_

    .. math::
        \begin{align}
            \mathbf{p}(r, \theta) = \sum_{n=0}^{N} \sum_{m=-n}^n
            \left(
                c_n^m D_n^m(r, \theta)
            \right)
        \end{align}

    , where :math:`D_n^m(r, \theta)` are disk harmonics:

    .. math::
        \begin{align}
            D_n^m(r, \theta) = R_n^{|m|}(r) e^{im\theta}
        \end{align}

    , where :math:`R_n^{|m|}(r)` are radial polynomials:

    .. math::

        \begin{align}
            R_n^{|m|}(r) = \sum_{s=0}^{(n-|m|)/2} (-1)^s
            \frac{(n-s)!}{s!((n+|m|)/2 - s)!((n-|m|)/2 - s)!} r^{n-2s}
        \end{align}

    References
    ------------------------
    .. [Zhang_etal_2017]
    """

    def __init__(
        self,
        n_harmonics=10,
        n_jobs=None,
        verbose=0,
    ):
        self.n_harmonics = n_harmonics
        self.n_jobs = n_jobs
        self.verbose = verbose
