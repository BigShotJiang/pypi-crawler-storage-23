# Product Overview

**ktch** is a Python library for model-based morphometrics, providing scikit-learn compatible APIs for analyzing biological shapes and forms. It enables researchers in biology, paleontology, and related fields to quantitatively study morphological variation.

## Core Capabilities

1. **Landmark-based morphometrics**: Generalized Procrustes Analysis (GPA), semilandmark sliding, thin-plate spline deformation
2. **Harmonic-based morphometrics**: Elliptic Fourier Analysis (EFA) for 2D/3D outlines, Spherical Harmonic Analysis (SPHARM) for 3D surfaces, Disk Harmonic Analysis
3. **Scikit-learn integration**: All analysis classes implement `TransformerMixin`/`BaseEstimator`, enabling pipeline composition, cross-validation, and ML workflows
4. **File I/O**: Read/write standard morphometric formats (TPS, CHC, SPHARM-PDM)
5. **Built-in datasets**: Reference datasets for learning and benchmarking (mosquito wings, trilobite cephala, bottles, leaf bending, Passiflora leaves)

## Target Use Cases

- Shape analysis of biological specimens (2D landmarks, 2D/3D outlines, 3D surfaces)
- Morphological variation studies across populations or species
- Integration of morphometric methods into machine learning pipelines
- Teaching and learning geometric morphometrics

## Value Proposition

- Unified sklearn-compatible API across diverse morphometric methods (landmark, harmonic)
- Bridges the gap between traditional morphometrics software and modern data science workflows
- Mathematically rigorous implementations with academic references
- Supports 2D and 3D data in a consistent interface

---
_Focus on patterns and purpose, not exhaustive feature lists_
