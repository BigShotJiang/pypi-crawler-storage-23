---
name: Documentation improvement
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

#### Describe the issue linked to the documentation

<!--
Tell us about the confusion introduced in the documentation.
-->

#### Suggest a potential alternative/fix

<!--
Tell us how we could improve the documentation in this regard.
-->
