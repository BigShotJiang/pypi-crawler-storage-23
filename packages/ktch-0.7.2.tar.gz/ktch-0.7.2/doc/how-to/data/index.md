(how-to-data)=

# Data

Guides for loading and handling morphometric data.

```{eval-rst}
.. toctree::
    :maxdepth: 1

    load_tps
    load_chc
    load_spharm
    use_datasets
    2d_outline_registration
```
