(how-to-analysis)=

# Analysis

Guides for morphometric analysis with scikit-learn integration.

```{eval-rst}
.. toctree::
    :maxdepth: 1

    use_with_pipeline
    cross_validation
    reconstruct_shapes
```
