(how-to-visualization)=

# Visualization

Guides for visualizing morphometric data and results.

```{eval-rst}
.. toctree::
    :maxdepth: 1

    tps_grid
    morphospace
```
