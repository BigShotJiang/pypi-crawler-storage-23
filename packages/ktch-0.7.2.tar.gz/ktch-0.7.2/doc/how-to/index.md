(how-to)=

# How-to Guides

Task-oriented guides for common operations.

```{eval-rst}
.. toctree::
    :maxdepth: 2

    data/index
    analysis/index
    visualization/index
```
