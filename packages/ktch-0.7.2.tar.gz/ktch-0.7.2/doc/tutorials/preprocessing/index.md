(tutorials-preprocessing)=

# Preprocessing

Tutorials for preparing data before morphometric analysis with ktch.

```{eval-rst}
.. toctree::
    :maxdepth: 1

    outline_extraction_2d
```
