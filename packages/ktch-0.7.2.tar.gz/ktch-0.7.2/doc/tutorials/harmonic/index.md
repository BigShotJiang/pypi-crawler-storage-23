(harmonic-tutorials)=

# Harmonic-based Morphometrics Tutorials

Tutorials for the :mod:`ktch.harmonic` module.

```{eval-rst}
.. toctree::
    :maxdepth: 1

    ./elliptic_Fourier_analysis
    ./elliptic_Fourier_analysis_3d
    ./spharm
```
