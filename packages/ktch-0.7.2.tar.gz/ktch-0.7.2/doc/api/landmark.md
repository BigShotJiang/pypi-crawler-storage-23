(landmark-ref)=

# ktch.landmark

landmark classes and utility functions

```{eval-rst}
.. automodule:: ktch.landmark
   :no-members:
   :no-inherited-members:
```

## Classes

```{eval-rst}
.. currentmodule:: ktch.landmark

.. autosummary::
   :toctree: generated/
   :template: base.rst

   GeneralizedProcrustesAnalysis
```

## Functions

```{eval-rst}
.. currentmodule:: ktch.landmark

.. autosummary::
   :toctree: generated/
   :template: base.rst

   centroid_size
   define_curve_sliders
   combine_landmarks_and_curves
```
