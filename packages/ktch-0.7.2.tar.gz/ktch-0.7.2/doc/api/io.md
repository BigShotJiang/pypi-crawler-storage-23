(io_ref)=

# ktch.io

```{eval-rst}
.. automodule:: ktch.io
   :no-members:
   :no-inherited-members:
```

## Functions

```{eval-rst}
.. currentmodule:: ktch

.. autosummary::
   :toctree: generated/
   :template: base.rst
   
   io.read_tps
   io.write_tps
   io.read_chc
   io.write_chc
   io.read_spharmpdm_coef
```
