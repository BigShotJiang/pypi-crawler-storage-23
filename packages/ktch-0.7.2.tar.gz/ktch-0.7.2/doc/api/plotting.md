(plotting-ref)=

# Plotting

```{eval-rst}
.. automodule:: ktch.plot
   :no-members:
   :no-inherited-members:
```

```{eval-rst}
.. currentmodule:: ktch

.. autosummary::
   :toctree: generated/
   :template: base.rst

   plot.explained_variance_ratio_plot
   plot.tps_grid_2d_plot
```
