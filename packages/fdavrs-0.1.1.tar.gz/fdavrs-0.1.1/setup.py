from setuptools import setup, find_packages
import os

# Try UTF-8 first, fallback to UTF-16 if Windows saved it differently
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except UnicodeDecodeError:
    with open("README.md", "r", encoding="utf-16") as fh:
        long_description = fh.read()

setup(
    name="fdavrs",
    version="0.1.1", 
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.24.0",
        "scipy>=1.11.0"
    ],
    author="Srivandhi",
    description="Federated Drift-Aware Vision Reliability System SDK",
    long_description=long_description,
    long_description_content_type="text/markdown", 
)