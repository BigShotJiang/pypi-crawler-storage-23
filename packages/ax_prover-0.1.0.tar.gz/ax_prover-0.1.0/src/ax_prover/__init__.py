"""ax-prover - Lean4 formalization assistant."""

from importlib.metadata import version

__version__ = version("ax-prover")
