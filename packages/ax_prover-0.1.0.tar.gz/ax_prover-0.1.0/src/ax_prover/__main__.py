"""Entry point for running ax_prover as a module."""

from .main import main

if __name__ == "__main__":
    main()
