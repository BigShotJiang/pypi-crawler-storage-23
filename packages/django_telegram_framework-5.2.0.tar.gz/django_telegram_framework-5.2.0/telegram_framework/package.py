"""
Package info
"""
name = 'django-telegram-framework'
version = '5.2.0'
status = '3 - Alpha'
