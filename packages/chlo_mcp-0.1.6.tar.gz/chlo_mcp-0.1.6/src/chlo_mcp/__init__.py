"""Chlo MCP server — connect your codebase to AI agents."""

__version__ = "0.1.0"
