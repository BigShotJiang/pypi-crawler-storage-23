# seqpulse (Python SDK)

SeqPulse SDK for:

- HTTP metrics instrumentation
- metrics endpoint exposure
- optional HMAC v2 validation on inbound SeqPulse calls

## Install

```bash
pip install seqpulse
```

## FastAPI usage

```python
from fastapi import FastAPI
from seqpulse import SeqPulse

app = FastAPI()

seqpulse = SeqPulse(
    endpoint="/seqpulse-metrics",
    hmac_enabled=True,
    hmac_secret="hmac_xxx",
)

app.middleware("http")(seqpulse.middleware())
```

## Returned payload

`GET /seqpulse-metrics` returns:

```json
{
  "metrics": {
    "requests_per_sec": 0.25,
    "latency_p95": 31.221,
    "error_rate": 0,
    "cpu_usage": 0.42,
    "memory_usage": 0.18
  }
}
```

## Notes

- This SDK does not manage CI/CD trigger/finish workflow.
- `api_key` is optional and not used directly in metrics payload or HMAC validation.
- Metrics sampling window is fixed to 60 seconds (not configurable in SDK init).

## Local smoke test

```bash
python scripts/smoke.py
```
