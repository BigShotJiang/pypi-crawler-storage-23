"""
PhysLang: Write math, run code.

A domain-specific language for mathematical physics that lets you
write mathematical notation directly and execute it as Python.

Usage:
    from physlang import run, compile_to_python, compile_to_jax
    
    result = run("sum(n, 1, 100, n)")
    code = compile_to_python("let x = 5")
    
    # Launch the web IDE
    from physlang import launch_ide
    launch_ide()
    
    # Install desktop shortcut (creates icon on desktop)
    from physlang import install_desktop
    install_desktop()
"""

__version__ = "0.1.0"

from .parser import parse, expand_latex
from .compiler import compile_to_python, compile_to_jax
from .runtime import execute
from .repl import launch_ide
from .desktop import install_desktop, uninstall_desktop

__all__ = [
    "parse",
    "expand_latex",
    "compile_to_python",
    "compile_to_jax",
    "execute",
    "run",
    "launch_ide",
    "install_desktop",
    "uninstall_desktop",
]


def run(source: str, backend: str = "numpy", show_code: bool = False):
    """
    Parse and execute PhysLang source code.
    
    Args:
        source: PhysLang source code
        backend: "numpy" or "jax"
        show_code: Print generated code before executing
        
    Returns:
        Result of execution
    """
    source = expand_latex(source)
    ast = parse(source)
    
    if backend == "jax":
        code = compile_to_jax(ast)
    else:
        code = compile_to_python(ast)
    
    if show_code:
        print("# Generated code:")
        print(code)
        print()
    
    return execute(code)
