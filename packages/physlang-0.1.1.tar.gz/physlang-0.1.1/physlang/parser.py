"""
PhysLang Parser

Hand-written lexer and recursive descent parser.
No external dependencies.
"""

from dataclasses import dataclass
from typing import List, Any, Optional, Union
from enum import Enum, auto


# ============================================================================
# LaTeX to Unicode Mapping
# ============================================================================

LATEX_TO_UNICODE = {
    # Greek lowercase
    '\\alpha': 'α', '\\beta': 'β', '\\gamma': 'γ', '\\delta': 'δ',
    '\\epsilon': 'ε', '\\zeta': 'ζ', '\\eta': 'η', '\\theta': 'θ',
    '\\iota': 'ι', '\\kappa': 'κ', '\\lambda': 'λ', '\\mu': 'μ',
    '\\nu': 'ν', '\\xi': 'ξ', '\\pi': 'π', '\\rho': 'ρ',
    '\\sigma': 'σ', '\\tau': 'τ', '\\upsilon': 'υ', '\\phi': 'φ',
    '\\chi': 'χ', '\\psi': 'ψ', '\\omega': 'ω',
    # Greek uppercase
    '\\Gamma': 'Γ', '\\Delta': 'Δ', '\\Theta': 'Θ', '\\Lambda': 'Λ',
    '\\Xi': 'Ξ', '\\Pi': 'Π', '\\Sigma': 'Σ', '\\Phi': 'Φ',
    '\\Psi': 'Ψ', '\\Omega': 'Ω',
    # Calculus
    '\\sum': '∑', '\\prod': '∏', '\\int': '∫', '\\partial': '∂',
    '\\nabla': '∇', '\\infty': '∞',
    # Operators
    '\\pm': '±', '\\mp': '∓', '\\times': '×', '\\div': '÷',
    '\\cdot': '·', '\\sqrt': '√', '\\degree': '°',
    # Relations
    '\\leq': '≤', '\\le': '≤', '\\geq': '≥', '\\ge': '≥',
    '\\neq': '≠', '\\approx': '≈', '\\equiv': '≡', '\\propto': '∝',
    # Sets
    '\\in': '∈', '\\subset': '⊂', '\\cup': '∪', '\\cap': '∩', '\\emptyset': '∅',
    '\\forall': '∀', '\\exists': '∃', '\\neg': '¬', '\\land': '∧', '\\lor': '∨',
    # Arrows
    '\\to': '→', '\\rightarrow': '→', '\\leftarrow': '←', '\\Rightarrow': '⇒',
    '\\mapsto': '↦',
    # Quantum
    '\\dagger': '†', '\\hbar': 'ℏ', '\\ell': 'ℓ',
    '\\langle': '⟨', '\\rangle': '⟩', '\\otimes': '⊗', '\\oplus': '⊕',
    # Number sets
    '\\RR': 'ℝ', '\\CC': 'ℂ', '\\ZZ': 'ℤ', '\\NN': 'ℕ', '\\QQ': 'ℚ',
    # Superscripts
    '^0': '⁰', '^1': '¹', '^2': '²', '^3': '³', '^4': '⁴',
    '^5': '⁵', '^6': '⁶', '^7': '⁷', '^8': '⁸', '^9': '⁹',
    '^n': 'ⁿ', '^i': 'ⁱ', '^+': '⁺', '^-': '⁻',
    # Subscripts
    '_0': '₀', '_1': '₁', '_2': '₂', '_3': '₃', '_4': '₄',
    '_5': '₅', '_6': '₆', '_7': '₇', '_8': '₈', '_9': '₉',
    '_i': 'ᵢ', '_j': 'ⱼ', '_n': 'ₙ',
}


def expand_latex(text: str) -> str:
    """Expand LaTeX notation to Unicode symbols."""
    result = text
    for latex, unicode in sorted(LATEX_TO_UNICODE.items(), key=lambda x: -len(x[0])):
        result = result.replace(latex, unicode)
    return result


# ============================================================================
# AST Nodes
# ============================================================================

@dataclass
class Number:
    value: float

@dataclass  
class Variable:
    name: str

@dataclass
class BinOp:
    op: str
    left: Any
    right: Any

@dataclass
class UnaryOp:
    op: str
    operand: Any

@dataclass
class Power:
    base: Any
    exponent: Any

@dataclass
class Subscript:
    base: Any
    indices: List[Any]

@dataclass
class FunctionCall:
    name: str
    args: List[Any]

@dataclass
class FunctionDef:
    name: str
    params: List[str]
    body: Any

@dataclass
class Summation:
    index: str
    start: Any
    end: Any
    body: Any

@dataclass
class Product:
    index: str
    start: Any
    end: Any
    body: Any

@dataclass
class Integral:
    var: str
    lower: Optional[Any]
    upper: Optional[Any]
    body: Any

@dataclass
class Derivative:
    var: str
    body: Any
    order: int = 1

@dataclass
class Gradient:
    func: Any
    point: Any

@dataclass
class LetBinding:
    name: str
    params: Optional[List[str]]
    value: Any

@dataclass
class OperatorDecl:
    name: str
    indices: List[str]
    kind: str

@dataclass
class Dagger:
    operand: Any

@dataclass
class Trace:
    operand: Any
    subsystem: Optional[str] = None

@dataclass
class BraKet:
    bra: Any
    ket: Any

@dataclass
class Ket:
    label: Any

@dataclass
class Bra:
    label: Any

@dataclass
class Sample:
    var: str
    distribution: Any

@dataclass
class Expectation:
    operand: Any

@dataclass
class Compute:
    expr: Any

@dataclass
class Program:
    statements: List[Any]


# ============================================================================
# Tokenizer
# ============================================================================

class TokenType(Enum):
    NUMBER = auto()
    IDENT = auto()
    GREEK = auto()
    LET = auto()
    COMPUTE = auto()
    OPERATOR = auto()
    SAMPLE = auto()
    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    CARET = auto()
    UNDERSCORE = auto()
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    LBRACE = auto()
    RBRACE = auto()
    COMMA = auto()
    COLON = auto()
    EQUALS = auto()
    SEMICOLON = auto()
    SUM = auto()
    PROD = auto()
    INT = auto()
    PARTIAL = auto()
    NABLA = auto()
    INFTY = auto()
    DAGGER = auto()
    LANGLE = auto()
    RANGLE = auto()
    OTIMES = auto()
    OPLUS = auto()
    PIPE = auto()
    SUPERSCRIPT = auto()
    SUBSCRIPT_CHAR = auto()
    TILDE = auto()
    ARROW = auto()
    NEWLINE = auto()
    EOF = auto()


@dataclass
class Token:
    type: TokenType
    value: str
    line: int = 1
    col: int = 1


GREEK_CHARS = set('αβγδεζηθικλμνξπρστυφχψωΓΔΘΛΞΠΣΦΨΩℏℓ')
SUPERSCRIPTS = {'⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4',
                '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9',
                'ⁿ': 'n', 'ⁱ': 'i', '⁺': '+', '⁻': '-'}
SUBSCRIPTS = {'₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
              '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9',
              'ᵢ': 'i', 'ⱼ': 'j', 'ₙ': 'n'}
KEYWORDS = {'let': TokenType.LET, 'compute': TokenType.COMPUTE,
            'operator': TokenType.OPERATOR, 'sample': TokenType.SAMPLE}


class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.col = 1
    
    def peek(self, offset: int = 0) -> str:
        pos = self.pos + offset
        return self.source[pos] if pos < len(self.source) else ''
    
    def advance(self) -> str:
        ch = self.peek()
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch
    
    def tokenize(self) -> List[Token]:
        tokens = []
        
        while self.pos < len(self.source):
            while self.peek() in ' \t\r':
                self.advance()
            if self.pos >= len(self.source):
                break
            
            ch = self.peek()
            line, col = self.line, self.col
            
            if ch == '\n':
                self.advance()
                tokens.append(Token(TokenType.NEWLINE, '\n', line, col))
            elif ch == '#':
                while self.peek() and self.peek() != '\n':
                    self.advance()
            elif ch in SUPERSCRIPTS:
                val = ''
                while self.peek() in SUPERSCRIPTS:
                    val += SUPERSCRIPTS[self.advance()]
                tokens.append(Token(TokenType.SUPERSCRIPT, val, line, col))
            elif ch in SUBSCRIPTS:
                val = ''
                while self.peek() in SUBSCRIPTS:
                    val += SUBSCRIPTS[self.advance()]
                tokens.append(Token(TokenType.SUBSCRIPT_CHAR, val, line, col))
            elif ch.isdigit() or (ch == '.' and self.peek(1).isdigit()):
                tokens.append(self._number(line, col))
            elif ch.isalpha() or ch == '_' or ch in GREEK_CHARS:
                tokens.append(self._ident(line, col))
            else:
                tok = self._symbol(line, col)
                if tok:
                    tokens.append(tok)
        
        tokens.append(Token(TokenType.EOF, '', self.line, self.col))
        return tokens
    
    def _number(self, line: int, col: int) -> Token:
        val = ''
        while self.peek().isdigit() and self.peek() not in SUPERSCRIPTS and self.peek() not in SUBSCRIPTS:
            val += self.advance()
        if self.peek() == '.' and self.peek(1).isdigit():
            val += self.advance()
            while self.peek().isdigit() and self.peek() not in SUPERSCRIPTS and self.peek() not in SUBSCRIPTS:
                val += self.advance()
        if self.peek() in 'eE':
            val += self.advance()
            if self.peek() in '+-':
                val += self.advance()
            while self.peek().isdigit() and self.peek() not in SUPERSCRIPTS and self.peek() not in SUBSCRIPTS:
                val += self.advance()
        return Token(TokenType.NUMBER, val, line, col)
    
    def _ident(self, line: int, col: int) -> Token:
        val = ''
        while True:
            ch = self.peek()
            # Stop if it's a superscript or subscript
            if ch in SUPERSCRIPTS or ch in SUBSCRIPTS:
                break
            # Continue if alphanumeric, underscore, or Greek
            if ch.isalnum() or ch == '_' or ch in GREEK_CHARS:
                val += self.advance()
            else:
                break
        if val in KEYWORDS:
            return Token(KEYWORDS[val], val, line, col)
        if len(val) == 1 and val in GREEK_CHARS:
            return Token(TokenType.GREEK, val, line, col)
        return Token(TokenType.IDENT, val, line, col)
    
    def _symbol(self, line: int, col: int) -> Optional[Token]:
        ch = self.advance()
        simple = {
            '+': TokenType.PLUS, '-': TokenType.MINUS, '−': TokenType.MINUS,
            '*': TokenType.STAR, '×': TokenType.STAR, '·': TokenType.STAR,
            '/': TokenType.SLASH, '÷': TokenType.SLASH,
            '^': TokenType.CARET, '_': TokenType.UNDERSCORE,
            '(': TokenType.LPAREN, ')': TokenType.RPAREN,
            '[': TokenType.LBRACKET, ']': TokenType.RBRACKET,
            '{': TokenType.LBRACE, '}': TokenType.RBRACE,
            ',': TokenType.COMMA, ':': TokenType.COLON,
            '=': TokenType.EQUALS, ';': TokenType.SEMICOLON,
            '~': TokenType.TILDE, '∼': TokenType.TILDE, '|': TokenType.PIPE,
            '∑': TokenType.SUM, '∏': TokenType.PROD,
            '∫': TokenType.INT, '∬': TokenType.INT, '∮': TokenType.INT,
            '∂': TokenType.PARTIAL, '∇': TokenType.NABLA, '∞': TokenType.INFTY,
            '†': TokenType.DAGGER, '‡': TokenType.DAGGER,
            '⟨': TokenType.LANGLE, '⟩': TokenType.RANGLE,
            '⊗': TokenType.OTIMES, '⊕': TokenType.OPLUS,
            '→': TokenType.ARROW, '↦': TokenType.ARROW,
        }
        return Token(simple[ch], ch, line, col) if ch in simple else None


# ============================================================================
# Parser
# ============================================================================

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def peek(self, offset: int = 0) -> Token:
        pos = self.pos + offset
        return self.tokens[pos] if pos < len(self.tokens) else self.tokens[-1]
    
    def advance(self) -> Token:
        tok = self.peek()
        self.pos += 1
        return tok
    
    def expect(self, type: TokenType) -> Token:
        tok = self.advance()
        if tok.type != type:
            raise SyntaxError(f"Expected {type.name}, got {tok.type.name} at line {tok.line}")
        return tok
    
    def match(self, *types: TokenType) -> bool:
        return self.peek().type in types
    
    def skip_newlines(self):
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> Program:
        statements = []
        self.skip_newlines()
        while not self.match(TokenType.EOF):
            stmt = self._statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        return Program(statements)
    
    def _statement(self):
        if self.match(TokenType.LET):
            return self._let()
        elif self.match(TokenType.COMPUTE):
            return self._compute()
        elif self.match(TokenType.OPERATOR):
            return self._operator_decl()
        elif self.match(TokenType.SAMPLE):
            return self._sample()
        else:
            return self._expr()
    
    def _let(self) -> LetBinding:
        self.advance()
        name = self.advance()
        if name.type not in (TokenType.IDENT, TokenType.GREEK):
            raise SyntaxError(f"Expected identifier after 'let'")
        
        params = None
        if self.match(TokenType.LPAREN):
            self.advance()
            params = []
            while not self.match(TokenType.RPAREN):
                p = self.advance()
                params.append(p.value)
                if self.match(TokenType.COMMA):
                    self.advance()
            self.expect(TokenType.RPAREN)
        
        self.expect(TokenType.EQUALS)
        value = self._expr()
        return LetBinding(name.value, params, value)
    
    def _compute(self) -> Compute:
        self.advance()
        return Compute(self._expr())
    
    def _operator_decl(self) -> OperatorDecl:
        self.advance()
        name = self.advance()
        indices = []
        if self.match(TokenType.LBRACKET):
            self.advance()
            while not self.match(TokenType.RBRACKET):
                idx = self.advance()
                indices.append(idx.value)
                if self.match(TokenType.COMMA):
                    self.advance()
            self.expect(TokenType.RBRACKET)
        self.expect(TokenType.COLON)
        kind = self.advance()
        return OperatorDecl(name.value, indices, kind.value)
    
    def _sample(self) -> Sample:
        self.advance()
        var = self.advance()
        self.expect(TokenType.TILDE)
        dist = self._expr()
        return Sample(var.value, dist)
    
    def _expr(self):
        return self._additive()
    
    def _additive(self):
        left = self._multiplicative()
        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = '+' if self.advance().type == TokenType.PLUS else '-'
            right = self._multiplicative()
            left = BinOp(op, left, right)
        return left
    
    def _multiplicative(self):
        left = self._power()
        while self.match(TokenType.STAR, TokenType.SLASH):
            op = '*' if self.advance().type == TokenType.STAR else '/'
            right = self._power()
            left = BinOp(op, left, right)
        # Implicit multiplication
        while self.match(TokenType.NUMBER, TokenType.IDENT, TokenType.GREEK, TokenType.LPAREN):
            if self.peek().type == TokenType.NUMBER and self.peek(-1).type == TokenType.NUMBER:
                break
            right = self._power()
            left = BinOp('*', left, right)
        return left
    
    def _power(self):
        base = self._unary()
        if self.match(TokenType.SUPERSCRIPT):
            exp_str = self.advance().value
            exp = Number(float(exp_str)) if exp_str.isdigit() else Variable(exp_str)
            return Power(base, exp)
        if self.match(TokenType.CARET):
            self.advance()
            if self.match(TokenType.LBRACE):
                self.advance()
                exp = self._expr()
                self.expect(TokenType.RBRACE)
            else:
                exp = self._unary()
            return Power(base, exp)
        return base
    
    def _unary(self):
        if self.match(TokenType.MINUS):
            self.advance()
            return UnaryOp('-', self._unary())
        return self._postfix()
    
    def _postfix(self):
        expr = self._primary()
        while True:
            if self.match(TokenType.DAGGER):
                self.advance()
                expr = Dagger(expr)
            elif self.match(TokenType.LBRACKET):
                self.advance()
                indices = [self._expr()]
                while self.match(TokenType.COMMA):
                    self.advance()
                    indices.append(self._expr())
                self.expect(TokenType.RBRACKET)
                expr = Subscript(expr, indices)
            elif self.match(TokenType.LPAREN) and isinstance(expr, Variable):
                self.advance()
                args = []
                while not self.match(TokenType.RPAREN):
                    args.append(self._expr())
                    if self.match(TokenType.COMMA):
                        self.advance()
                self.expect(TokenType.RPAREN)
                expr = FunctionCall(expr.name, args)
            else:
                break
        return expr
    
    def _primary(self):
        tok = self.peek()
        
        if self.match(TokenType.NUMBER):
            self.advance()
            return Number(float(tok.value))
        
        if self.match(TokenType.IDENT, TokenType.GREEK):
            self.advance()
            return Variable(tok.value)
        
        if self.match(TokenType.LPAREN):
            self.advance()
            expr = self._expr()
            self.expect(TokenType.RPAREN)
            return expr
        
        if self.match(TokenType.INFTY):
            self.advance()
            return Variable('inf')
        
        if self.match(TokenType.LANGLE):
            return self._braket()
        
        if self.match(TokenType.PIPE):
            return self._ket()
        
        raise SyntaxError(f"Unexpected token: {tok.type.name} '{tok.value}' at line {tok.line}")
    
    def _braket(self) -> Union[BraKet, Bra]:
        self.advance()
        left = self._expr()
        if self.match(TokenType.PIPE):
            self.advance()
            if self.match(TokenType.RANGLE):
                self.advance()
                return Bra(left)
            right = self._expr()
            self.expect(TokenType.RANGLE)
            return BraKet(left, right)
        self.expect(TokenType.RANGLE)
        return Bra(left)
    
    def _ket(self) -> Ket:
        self.advance()
        label = self._expr()
        self.expect(TokenType.RANGLE)
        return Ket(label)


# ============================================================================
# Public API
# ============================================================================

def parse(source: str) -> Program:
    """Parse PhysLang source code into an AST."""
    source = expand_latex(source)
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    return parser.parse()
