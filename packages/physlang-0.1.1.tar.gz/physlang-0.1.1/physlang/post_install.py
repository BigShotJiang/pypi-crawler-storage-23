"""
Post-installation script for PhysLang.

Automatically creates desktop shortcut when pip install completes.
"""

import sys
import os


def post_install():
    """Run after pip install to set up desktop integration."""
    # Don't run during CI/CD or when explicitly disabled
    if os.environ.get('PHYSLANG_NO_DESKTOP'):
        return
    
    # Don't run if not in a terminal (e.g., during automated installs)
    if not sys.stdout.isatty():
        return
    
    try:
        from .desktop import install_desktop
        print()
        print("=" * 50)
        print("  PhysLang installed successfully!")
        print("=" * 50)
        print()
        install_desktop(quiet=False)
        print()
        print("You can now:")
        print("  • Double-click the PhysLang IDE icon on your desktop")
        print("  • Or run: physlang --ide")
        print("  • Or run: physlang (for command-line REPL)")
        print()
    except Exception as e:
        # Don't fail the install if desktop integration fails
        print(f"Note: Could not create desktop shortcut ({e})")
        print("You can still run: physlang --ide")


if __name__ == '__main__':
    post_install()
