"""
PhysLang Desktop Integration

Creates desktop shortcuts and application entries for easy access to the IDE.
"""

import sys
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional


def get_assets_dir() -> Path:
    """Get path to assets directory."""
    return Path(__file__).parent / 'assets'


def get_icon_path(format: str = 'png') -> Path:
    """Get path to icon file."""
    assets = get_assets_dir()
    if format == 'ico':
        return assets / 'icon.ico'
    elif format == 'svg':
        return assets / 'icon.svg'
    else:
        return assets / 'icon.png'


def get_physlang_executable() -> str:
    """Get the path to the physlang executable."""
    # Try to find in PATH
    physlang_path = shutil.which('physlang')
    if physlang_path:
        return physlang_path
    
    # Fallback to python -m
    return f'"{sys.executable}" -m physlang.repl'


def install_desktop_linux() -> bool:
    """Install desktop entry on Linux."""
    applications_dir = Path.home() / '.local' / 'share' / 'applications'
    icons_dir = Path.home() / '.local' / 'share' / 'icons' / 'hicolor' / '256x256' / 'apps'
    
    # Create directories
    applications_dir.mkdir(parents=True, exist_ok=True)
    icons_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy icon
    icon_src = get_icon_path('png')
    icon_dest = icons_dir / 'physlang.png'
    shutil.copy(icon_src, icon_dest)
    
    # Also copy to assets location for the .desktop file
    local_icon = Path.home() / '.local' / 'share' / 'physlang' / 'icon.png'
    local_icon.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(icon_src, local_icon)
    
    # Create .desktop file
    desktop_entry = f"""[Desktop Entry]
Name=PhysLang IDE
Comment=Write math, run code - Physics DSL IDE
Exec={get_physlang_executable()} --ide
Icon={local_icon}
Terminal=false
Type=Application
Categories=Development;Education;Science;
Keywords=physics;math;python;jax;science;
StartupNotify=true
"""
    
    desktop_file = applications_dir / 'physlang.desktop'
    desktop_file.write_text(desktop_entry)
    desktop_file.chmod(0o755)
    
    # Update desktop database
    try:
        subprocess.run(['update-desktop-database', str(applications_dir)], 
                      capture_output=True, check=False)
    except FileNotFoundError:
        pass
    
    # Also create desktop shortcut
    desktop_dir = Path.home() / 'Desktop'
    if desktop_dir.exists():
        desktop_shortcut = desktop_dir / 'PhysLang IDE.desktop'
        shutil.copy(desktop_file, desktop_shortcut)
        desktop_shortcut.chmod(0o755)
        # Mark as trusted on GNOME
        try:
            subprocess.run(['gio', 'set', str(desktop_shortcut), 
                          'metadata::trusted', 'true'], capture_output=True, check=False)
        except FileNotFoundError:
            pass
    
    print(f"✓ Desktop entry created: {desktop_file}")
    print(f"✓ Icon installed: {icon_dest}")
    if desktop_dir.exists():
        print(f"✓ Desktop shortcut created")
    
    return True


def install_desktop_macos() -> bool:
    """Install application on macOS."""
    applications_dir = Path.home() / 'Applications'
    app_dir = applications_dir / 'PhysLang IDE.app'
    contents_dir = app_dir / 'Contents'
    macos_dir = contents_dir / 'MacOS'
    resources_dir = contents_dir / 'Resources'
    
    # Create app bundle structure
    macos_dir.mkdir(parents=True, exist_ok=True)
    resources_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy icon (convert to icns if possible, otherwise use png)
    icon_src = get_icon_path('png')
    icon_dest = resources_dir / 'icon.png'
    shutil.copy(icon_src, icon_dest)
    
    # Try to create icns
    icns_path = resources_dir / 'AppIcon.icns'
    try:
        # Create iconset
        iconset_dir = resources_dir / 'AppIcon.iconset'
        iconset_dir.mkdir(exist_ok=True)
        
        assets = get_assets_dir()
        size_map = {
            'icon_16x16.png': 16,
            'icon_16x16@2x.png': 32,
            'icon_32x32.png': 32,
            'icon_32x32@2x.png': 64,
            'icon_128x128.png': 128,
            'icon_128x128@2x.png': 256,
            'icon_256x256.png': 256,
            'icon_256x256@2x.png': 512,
            'icon_512x512.png': 512,
        }
        
        for name, size in size_map.items():
            src = assets / f'icon_{size}.png'
            if src.exists():
                shutil.copy(src, iconset_dir / name)
        
        # Convert to icns
        subprocess.run(['iconutil', '-c', 'icns', str(iconset_dir)], 
                      capture_output=True, check=True)
        shutil.rmtree(iconset_dir)
    except (subprocess.CalledProcessError, FileNotFoundError):
        # iconutil not available, use png
        pass
    
    # Create launcher script
    launcher = macos_dir / 'PhysLang'
    launcher_content = f"""#!/bin/bash
{get_physlang_executable()} --ide
"""
    launcher.write_text(launcher_content)
    launcher.chmod(0o755)
    
    # Create Info.plist
    plist_content = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>PhysLang IDE</string>
    <key>CFBundleDisplayName</key>
    <string>PhysLang IDE</string>
    <key>CFBundleIdentifier</key>
    <string>com.physlang.ide</string>
    <key>CFBundleVersion</key>
    <string>0.1.0</string>
    <key>CFBundleShortVersionString</key>
    <string>0.1.0</string>
    <key>CFBundleExecutable</key>
    <string>PhysLang</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.13</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
"""
    (contents_dir / 'Info.plist').write_text(plist_content)
    
    print(f"✓ Application created: {app_dir}")

    # Create Desktop alias so the user sees it immediately
    desktop_dir = Path.home() / 'Desktop'
    if desktop_dir.exists():
        desktop_link = desktop_dir / 'PhysLang IDE'
        try:
            if desktop_link.exists() or desktop_link.is_symlink():
                desktop_link.unlink()
            os.symlink(str(app_dir), str(desktop_link))
            print(f"✓ Desktop shortcut created: {desktop_link}")
        except OSError:
            print("  You can find PhysLang IDE in your Applications folder")

    return True


def install_desktop_windows() -> bool:
    """Install desktop shortcut on Windows."""
    try:
        import winreg
        from win32com.client import Dispatch
    except ImportError:
        # Try alternative method using PowerShell
        return install_desktop_windows_powershell()
    
    desktop = Path.home() / 'Desktop'
    start_menu = Path(os.environ.get('APPDATA', '')) / 'Microsoft' / 'Start Menu' / 'Programs'
    
    # Copy icon to local folder
    local_dir = Path.home() / 'AppData' / 'Local' / 'PhysLang'
    local_dir.mkdir(parents=True, exist_ok=True)
    
    icon_src = get_icon_path('ico')
    icon_dest = local_dir / 'icon.ico'
    shutil.copy(icon_src, icon_dest)
    
    # Create shortcut using COM
    shell = Dispatch('WScript.Shell')
    
    for location in [desktop, start_menu]:
        if location.exists():
            shortcut_path = location / 'PhysLang IDE.lnk'
            shortcut = shell.CreateShortCut(str(shortcut_path))
            shortcut.Targetpath = sys.executable
            shortcut.Arguments = '-m physlang.repl --ide'
            shortcut.WorkingDirectory = str(Path.home())
            shortcut.IconLocation = str(icon_dest)
            shortcut.Description = 'PhysLang IDE - Write math, run code'
            shortcut.save()
            print(f"✓ Shortcut created: {shortcut_path}")
    
    return True


def install_desktop_windows_powershell() -> bool:
    """Install desktop shortcut on Windows using PowerShell."""
    desktop = Path.home() / 'Desktop'
    
    # Copy icon
    local_dir = Path.home() / 'AppData' / 'Local' / 'PhysLang'
    local_dir.mkdir(parents=True, exist_ok=True)
    
    icon_src = get_icon_path('ico')
    icon_dest = local_dir / 'icon.ico'
    shutil.copy(icon_src, icon_dest)
    
    # PowerShell script to create shortcut
    shortcut_path = desktop / 'PhysLang IDE.lnk'
    ps_script = f'''
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
$Shortcut.TargetPath = "{sys.executable}"
$Shortcut.Arguments = "-m physlang.repl --ide"
$Shortcut.WorkingDirectory = "{Path.home()}"
$Shortcut.IconLocation = "{icon_dest}"
$Shortcut.Description = "PhysLang IDE - Write math, run code"
$Shortcut.Save()
'''
    
    try:
        subprocess.run(['powershell', '-Command', ps_script], 
                      capture_output=True, check=True)
        print(f"✓ Desktop shortcut created: {shortcut_path}")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Warning: Could not create shortcut automatically: {e}")
        print(f"You can manually create a shortcut to: physlang --ide")
        return False


def install_desktop(quiet: bool = False) -> bool:
    """
    Install PhysLang IDE desktop shortcut/application.
    
    Automatically detects the operating system and installs appropriately.
    
    Args:
        quiet: Suppress output messages
    
    Returns:
        True if successful, False otherwise
    """
    if not quiet:
        print("Installing PhysLang IDE desktop integration...")
        print()
    
    system = sys.platform
    
    try:
        if system == 'linux':
            return install_desktop_linux()
        elif system == 'darwin':
            return install_desktop_macos()
        elif system == 'win32':
            return install_desktop_windows()
        else:
            print(f"Unsupported platform: {system}")
            print("You can still run the IDE with: physlang --ide")
            return False
    except Exception as e:
        print(f"Error installing desktop integration: {e}")
        print("You can still run the IDE with: physlang --ide")
        return False


def uninstall_desktop(quiet: bool = False) -> bool:
    """Remove PhysLang IDE desktop integration."""
    if not quiet:
        print("Removing PhysLang IDE desktop integration...")
    
    system = sys.platform
    removed = []
    
    try:
        if system == 'linux':
            paths = [
                Path.home() / '.local' / 'share' / 'applications' / 'physlang.desktop',
                Path.home() / 'Desktop' / 'PhysLang IDE.desktop',
                Path.home() / '.local' / 'share' / 'icons' / 'hicolor' / '256x256' / 'apps' / 'physlang.png',
                Path.home() / '.local' / 'share' / 'physlang',
            ]
        elif system == 'darwin':
            paths = [
                Path.home() / 'Applications' / 'PhysLang IDE.app',
            ]
        elif system == 'win32':
            paths = [
                Path.home() / 'Desktop' / 'PhysLang IDE.lnk',
                Path(os.environ.get('APPDATA', '')) / 'Microsoft' / 'Start Menu' / 'Programs' / 'PhysLang IDE.lnk',
                Path.home() / 'AppData' / 'Local' / 'PhysLang',
            ]
        else:
            return False
        
        for path in paths:
            if path.exists():
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
                removed.append(path)
                if not quiet:
                    print(f"✓ Removed: {path}")
        
        if not removed and not quiet:
            print("Nothing to remove.")
        
        return True
        
    except Exception as e:
        print(f"Error: {e}")
        return False


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='PhysLang desktop integration')
    parser.add_argument('--uninstall', action='store_true', help='Remove desktop integration')
    args = parser.parse_args()
    
    if args.uninstall:
        uninstall_desktop()
    else:
        install_desktop()
