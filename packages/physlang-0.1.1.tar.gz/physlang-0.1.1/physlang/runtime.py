"""
PhysLang Runtime

Executes compiled PhysLang code in a safe environment.
"""

import sys
from typing import Any, Dict, Optional
from io import StringIO


def execute(code: str, context: Optional[Dict[str, Any]] = None) -> Any:
    """
    Execute compiled Python code and return the result.
    
    Args:
        code: Python code to execute
        context: Optional dictionary of variables to include
        
    Returns:
        The result of the last expression, or the value of _result_
    """
    # Create execution namespace with standard imports
    namespace = {
        '__builtins__': __builtins__,
    }
    
    # Add any provided context
    if context:
        namespace.update(context)
    
    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = captured = StringIO()
    
    result = None
    
    try:
        # Execute the code
        exec(code, namespace)
        
        # Check for explicit result
        if '_result_' in namespace:
            result = namespace['_result_']
        
        # Get any printed output
        output = captured.getvalue()
        if output:
            # Parse "Result: <value>" from compute statements
            for line in output.strip().split('\n'):
                if line.startswith('Result: '):
                    try:
                        result = eval(line[8:], namespace)
                    except:
                        pass
        
    except Exception as e:
        raise RuntimeError(f"Execution error: {e}")
    
    finally:
        sys.stdout = old_stdout
    
    return result


def execute_safe(code: str, timeout: float = 5.0) -> Any:
    """
    Execute code with a timeout (for safety).
    
    Note: Timeout not implemented in basic version.
    Use execute() for now.
    """
    return execute(code)


def create_runtime_context() -> Dict[str, Any]:
    """
    Create a runtime context with standard physics/math tools.
    
    Returns:
        Dictionary with numpy, scipy, and helper functions
    """
    import numpy as np
    from scipy import integrate
    
    context = {
        'np': np,
        'numpy': np,
        'pi': np.pi,
        'e': np.e,
        'inf': np.inf,
        'sin': np.sin,
        'cos': np.cos,
        'tan': np.tan,
        'exp': np.exp,
        'log': np.log,
        'sqrt': np.sqrt,
        'abs': np.abs,
        'integrate': integrate,
    }
    
    return context


class PhysLangRuntime:
    """
    Runtime environment for PhysLang execution.
    
    Maintains state across multiple executions.
    """
    
    def __init__(self, backend: str = "numpy"):
        self.backend = backend
        self.namespace = create_runtime_context()
        self.history = []
    
    def execute(self, code: str) -> Any:
        """Execute code in the runtime environment."""
        result = execute(code, self.namespace)
        self.history.append(code)
        return result
    
    def set_variable(self, name: str, value: Any):
        """Set a variable in the runtime namespace."""
        self.namespace[name] = value
    
    def get_variable(self, name: str) -> Any:
        """Get a variable from the runtime namespace."""
        return self.namespace.get(name)
    
    def clear(self):
        """Clear the runtime state."""
        self.namespace = create_runtime_context()
        self.history = []
    
    def list_variables(self) -> Dict[str, Any]:
        """List user-defined variables."""
        builtins = {'np', 'numpy', 'pi', 'e', 'inf', 'sin', 'cos', 'tan', 
                    'exp', 'log', 'sqrt', 'abs', 'integrate', '__builtins__'}
        return {k: v for k, v in self.namespace.items() if k not in builtins}
