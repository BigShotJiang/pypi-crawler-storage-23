"""
PhysLang REPL

Interactive command-line interface with LaTeX auto-completion.
"""

import sys
import argparse
import webbrowser
import tempfile
import shutil
from pathlib import Path
from typing import Optional

from .parser import expand_latex, LATEX_TO_UNICODE


# ============================================================================
# IDE Launcher
# ============================================================================

def get_ide_path() -> Path:
    """Get the path to the bundled IDE HTML file."""
    return Path(__file__).parent / 'ide.html'


def launch_ide(serve: bool = False, port: int = 8765) -> None:
    """
    Launch the PhysLang IDE in a web browser.
    
    Args:
        serve: If True, start a local HTTP server (useful for some browsers)
        port: Port for the local server (default 8765)
    """
    ide_path = get_ide_path()
    
    if not ide_path.exists():
        print("Error: IDE file not found. Try reinstalling physlang.", file=sys.stderr)
        sys.exit(1)
    
    if serve:
        # Start a simple HTTP server
        import http.server
        import socketserver
        import threading
        
        class Handler(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=str(ide_path.parent), **kwargs)
            
            def log_message(self, format, *args):
                pass  # Suppress logging
        
        with socketserver.TCPServer(("", port), Handler) as httpd:
            url = f"http://localhost:{port}/ide.html"
            print(f"PhysLang IDE running at: {url}")
            print("Press Ctrl+C to stop the server")
            
            # Open browser
            webbrowser.open(url)
            
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\nServer stopped.")
    else:
        # Just open the file directly
        url = f"file://{ide_path.absolute()}"
        print(f"Opening PhysLang IDE...")
        webbrowser.open(url)


# ============================================================================
# Readline Setup (Tab Completion)
# ============================================================================

try:
    import readline
    
    class LatexCompleter:
        """Tab completion for LaTeX symbols."""
        
        def __init__(self):
            self.matches = []
            self.latex_commands = list(LATEX_TO_UNICODE.keys())
        
        def complete(self, text: str, state: int) -> Optional[str]:
            if state == 0:
                self.matches = []
                
                # Find LaTeX completions starting with text
                if text.startswith('\\'):
                    for cmd in self.latex_commands:
                        if cmd.startswith(text):
                            # Return the Unicode symbol
                            self.matches.append(LATEX_TO_UNICODE[cmd])
                
                # Also complete for ^ and _ shortcuts
                elif text.startswith('^') or text.startswith('_'):
                    for cmd in self.latex_commands:
                        if cmd.startswith(text):
                            self.matches.append(LATEX_TO_UNICODE[cmd])
            
            if state < len(self.matches):
                return self.matches[state]
            return None
    
    readline.set_completer(LatexCompleter().complete)
    readline.parse_and_bind('tab: complete')
    readline.set_completer_delims(' \t\n;')
    
    HAS_READLINE = True
except ImportError:
    HAS_READLINE = False


# ============================================================================
# Help Text
# ============================================================================

HELP_TEXT = """
PhysLang Commands:
  help        Show this help
  symbols     Show LaTeX to Unicode mappings
  python      Show generated Python for next expression
  jax         Show generated JAX for next expression
  examples    Show example expressions
  clear       Clear runtime state
  quit/exit   Exit the REPL

LaTeX Input (type, then press Tab or just type):
  \\alpha     -->  alpha
  \\beta      -->  beta
  \\sum       -->  (summation)
  \\int       -->  (integral)
  \\pi        -->  pi
  ^2          -->  superscript 2
  _1          -->  subscript 1
  \\dagger    -->  dagger (Hermitian conjugate)
  \\infty     -->  infinity

Syntax:
  let x = 5                 Define variable
  let f(x) = x^2            Define function
  compute expr              Evaluate and print result
  sum(i, 1, n, expr)        Summation
  integrate(f, x, a, b)     Definite integral
  operator c[i] : fermion   Declare operator

Example:
  > let x = 5
  > compute x^2 + 2*x + 1
  Result: 36
"""

EXAMPLES_TEXT = """
Examples:

# Basic arithmetic
compute 3 + 4 * 2
compute sqrt(2)
compute sin(pi/2)

# Variables
let x = 10
let y = x^2
compute y

# Functions
let f(x) = x^2 + 2*x + 1
compute f(5)

# Greek letters (type \\alpha or just paste alpha)
let alpha = 0.5
let beta = 1.0
compute exp(-beta * alpha)

# Summation
compute sum(n, 1, 100, n)          # 1 + 2 + ... + 100 = 5050
compute sum(k, 1, 10, k^2)         # sum of squares

# Integration  
compute integrate(sin(x), x, 0, pi)    # = 2.0
compute integrate(x^2, x, 0, 1)        # = 1/3

# Linear algebra
let A = array(1, 2, 3, 4)
compute det(matrix([[1, 2], [3, 4]]))
compute norm(array(3, 4))              # = 5.0

# Quantum notation
# (requires full runtime)
# operator c[i, sigma] : fermion
# compute Tr(rho * H)
"""

SYMBOLS_TEXT = """
LaTeX Symbol Reference (type LaTeX, press Tab or Enter):

Greek:
  \\alpha alpha   \\beta beta    \\gamma gamma   \\delta delta
  \\epsilon epsilon \\zeta zeta    \\eta eta     \\theta theta
  \\lambda lambda  \\mu mu      \\nu nu      \\xi xi
  \\pi pi      \\rho rho     \\sigma sigma   \\tau tau
  \\phi phi     \\chi chi     \\psi psi     \\omega omega
  
  \\Gamma Gamma   \\Delta Delta   \\Theta Theta   \\Lambda Lambda
  \\Sigma Sigma   \\Phi Phi     \\Psi Psi     \\Omega Omega

Calculus:
  \\sum (summation)      \\prod (product)      \\int (integral)
  \\partial (partial)   \\nabla (nabla)    \\infty (infinity)

Operators:
  \\pm (plus-minus)    \\times (times)    \\cdot (dot)
  \\div (division)    \\sqrt (square root)

Relations:
  \\leq (less-equal)   \\geq (greater-equal)  \\neq (not-equal)
  \\approx (approx)   \\equiv (equivalent)  \\propto (proportional)

Sets:
  \\in (element-of)   \\subset (subset)    \\cup (union)
  \\cap (intersection) \\emptyset (empty-set) \\forall (for-all)
  \\exists (exists)

Quantum:
  \\dagger (dagger)    \\langle (left-angle)  \\rangle (right-angle)
  \\otimes (tensor)   \\oplus (direct-sum)  \\hbar (h-bar)

Superscripts:  ^0 ^1 ^2 ^3 ^4 ^5 ^6 ^7 ^8 ^9 ^n
Subscripts:    _0 _1 _2 _3 _4 _5 _6 _7 _8 _9 _i _j _n

Number Sets:
  \\RR (reals)  \\CC (complex)  \\ZZ (integers)  \\NN (naturals)  \\QQ (rationals)
"""


# ============================================================================
# REPL Implementation
# ============================================================================

def repl(backend: str = "numpy"):
    """Start the interactive PhysLang REPL."""
    from . import parse, compile_to_python, compile_to_jax, execute
    
    print("PhysLang v0.1.1")
    print("Type 'help' for commands, 'quit' to exit.")
    if HAS_READLINE:
        print("Tab completion enabled for LaTeX symbols.")
    print()
    
    show_python = False
    show_jax = False
    
    while True:
        try:
            # Read input
            prompt = "jax> " if backend == "jax" else "> "
            line = input(prompt).strip()
            
            if not line:
                continue
            
            # Expand LaTeX
            line = expand_latex(line)
            
            # Commands
            cmd = line.lower()
            
            if cmd in ('quit', 'exit', 'q'):
                print("Goodbye.")
                break
            
            if cmd == 'help':
                print(HELP_TEXT)
                continue
            
            if cmd == 'examples':
                print(EXAMPLES_TEXT)
                continue
            
            if cmd == 'symbols':
                print(SYMBOLS_TEXT)
                continue
            
            if cmd == 'python':
                show_python = True
                show_jax = False
                print("Next expression will show Python code.")
                continue
            
            if cmd == 'jax':
                show_jax = True
                show_python = False
                print("Next expression will show JAX code.")
                continue
            
            if cmd == 'clear':
                print("Runtime cleared.")
                continue
            
            # Parse and compile
            try:
                ast = parse(line)
                
                if show_python:
                    code = compile_to_python(ast)
                    print("\n# Python:\n")
                    print(code)
                    print()
                    show_python = False
                    continue
                
                if show_jax:
                    code = compile_to_jax(ast)
                    print("\n# JAX:\n")
                    print(code)
                    print()
                    show_jax = False
                    continue
                
                # Execute
                if backend == "jax":
                    code = compile_to_jax(ast)
                else:
                    code = compile_to_python(ast)
                
                result = execute(code)
                
                if result is not None:
                    print(f"  = {result}")
            
            except SyntaxError as e:
                print(f"Syntax error: {e}")
            
            except Exception as e:
                print(f"Error: {e}")
                if '--debug' in sys.argv:
                    import traceback
                    traceback.print_exc()
        
        except KeyboardInterrupt:
            print("\n(Use 'quit' to exit)")
        
        except EOFError:
            print("\nGoodbye.")
            break


# ============================================================================
# Command Line Interface
# ============================================================================

def first_run_check():
    """Check if this is the first run and install desktop if so."""
    import os
    from pathlib import Path
    
    # Skip in CI/headless environments
    if os.environ.get('PHYSLANG_NO_DESKTOP') or os.environ.get('CI'):
        return
    
    # Check marker file
    marker_dir = Path.home() / '.physlang'
    marker_file = marker_dir / '.installed'
    
    if marker_file.exists():
        return  # Already installed
    
    # First run - install desktop
    try:
        # Only if we have a display/terminal
        if not sys.stdout.isatty():
            return
        
        print()
        print("=" * 55)
        print("  Welcome to PhysLang! Setting up desktop shortcut...")
        print("=" * 55)
        print()
        
        from .desktop import install_desktop
        success = install_desktop(quiet=False)
        
        # Create marker
        marker_dir.mkdir(parents=True, exist_ok=True)
        marker_file.write_text("installed")
        
        if success:
            print()
            print("Desktop shortcut created! Look for the H-hat icon.")
            print()
    except Exception as e:
        # Don't fail - just skip desktop install
        pass


def main():
    """Main entry point for the physlang command."""
    
    # Check for first run - auto-install desktop shortcut
    first_run_check()
    
    parser = argparse.ArgumentParser(
        prog='physlang',
        description='PhysLang: Write math, run code.'
    )
    
    parser.add_argument(
        'file',
        nargs='?',
        help='PhysLang source file to execute (.phi)'
    )
    
    parser.add_argument(
        '-c', '--command',
        help='Execute a single expression'
    )
    
    parser.add_argument(
        '-p', '--python',
        action='store_true',
        help='Show generated Python code'
    )
    
    parser.add_argument(
        '-j', '--jax',
        action='store_true',
        help='Use JAX backend (GPU + autodiff)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='PhysLang 0.1.1'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Show debug information'
    )
    
    parser.add_argument(
        '--ide',
        action='store_true',
        help='Launch the web-based PhysLang IDE'
    )
    
    parser.add_argument(
        '--serve',
        action='store_true',
        help='Start a local server for the IDE (use with --ide)'
    )
    
    parser.add_argument(
        '--install',
        action='store_true',
        help='Install desktop shortcut/application for the IDE'
    )
    
    parser.add_argument(
        '--uninstall',
        action='store_true',
        help='Remove desktop shortcut/application'
    )
    
    args = parser.parse_args()
    
    # Handle desktop installation
    if args.install:
        from .desktop import install_desktop
        install_desktop()
        return
    
    if args.uninstall:
        from .desktop import uninstall_desktop
        uninstall_desktop()
        return
    
    # Launch IDE if requested
    if args.ide:
        launch_ide(serve=args.serve)
        return
    
    from . import parse, compile_to_python, compile_to_jax, execute
    
    backend = "jax" if args.jax else "numpy"
    compile_fn = compile_to_jax if args.jax else compile_to_python
    
    # Execute single command
    if args.command:
        try:
            source = expand_latex(args.command)
            ast = parse(source)
            code = compile_fn(ast)
            
            if args.python or args.jax:
                print(code)
            else:
                result = execute(code)
                if result is not None:
                    print(result)
        
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            if args.debug:
                import traceback
                traceback.print_exc()
            sys.exit(1)
    
    # Execute file
    elif args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                source = f.read()
            
            source = expand_latex(source)
            ast = parse(source)
            code = compile_fn(ast)
            
            if args.python or (args.jax and args.python):
                print(code)
            else:
                result = execute(code)
                if result is not None:
                    print(result)
        
        except FileNotFoundError:
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            sys.exit(1)
        
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            if args.debug:
                import traceback
                traceback.print_exc()
            sys.exit(1)
    
    # Start REPL
    else:
        repl(backend=backend)


if __name__ == '__main__':
    main()
