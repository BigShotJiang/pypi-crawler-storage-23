"""
PhysLang Test Suite
"""

import pytest
import math


class TestParser:
    """Test the parser."""
    
    def test_expand_latex_greek(self):
        from physlang.parser import expand_latex
        
        assert expand_latex("\\alpha") == "α"
        assert expand_latex("\\beta") == "β"
        assert expand_latex("\\pi") == "π"
        assert expand_latex("\\Sigma") == "Σ"
    
    def test_expand_latex_operators(self):
        from physlang.parser import expand_latex
        
        assert expand_latex("\\sum") == "∑"
        assert expand_latex("\\int") == "∫"
        assert expand_latex("\\infty") == "∞"
        assert expand_latex("\\partial") == "∂"
    
    def test_expand_latex_superscripts(self):
        from physlang.parser import expand_latex
        
        assert expand_latex("x^2") == "x²"
        assert expand_latex("x^3") == "x³"
        assert expand_latex("x^n") == "xⁿ"
    
    def test_expand_latex_subscripts(self):
        from physlang.parser import expand_latex
        
        assert expand_latex("x_1") == "x₁"
        assert expand_latex("x_i") == "xᵢ"
    
    def test_parse_number(self):
        from physlang import parse
        from physlang.parser import Number
        
        ast = parse("42")
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], Number)
        assert ast.statements[0].value == 42
    
    def test_parse_variable(self):
        from physlang import parse
        from physlang.parser import Variable
        
        ast = parse("x")
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], Variable)
        assert ast.statements[0].name == "x"
    
    def test_parse_greek_variable(self):
        from physlang import parse
        from physlang.parser import Variable
        
        ast = parse("α")
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], Variable)
        assert ast.statements[0].name == "α"
    
    def test_parse_addition(self):
        from physlang import parse
        from physlang.parser import BinOp, Number
        
        ast = parse("3 + 4")
        assert len(ast.statements) == 1
        expr = ast.statements[0]
        assert isinstance(expr, BinOp)
        assert expr.op == "+"
    
    def test_parse_let_binding(self):
        from physlang import parse
        from physlang.parser import LetBinding
        
        ast = parse("let x = 5")
        assert len(ast.statements) == 1
        stmt = ast.statements[0]
        assert isinstance(stmt, LetBinding)
        assert stmt.name == "x"
    
    def test_parse_function_def(self):
        from physlang import parse
        from physlang.parser import LetBinding
        
        ast = parse("let f(x) = x + 1")
        assert len(ast.statements) == 1
        stmt = ast.statements[0]
        assert isinstance(stmt, LetBinding)
        assert stmt.name == "f"
        assert stmt.params == ["x"]
    
    def test_parse_compute(self):
        from physlang import parse
        from physlang.parser import Compute
        
        ast = parse("compute 3 + 4")
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], Compute)
    
    def test_parse_power(self):
        from physlang import parse
        from physlang.parser import Power
        
        ast = parse("x^2")
        expr = ast.statements[0]
        assert isinstance(expr, Power)
    
    def test_parse_function_call(self):
        from physlang import parse
        from physlang.parser import FunctionCall
        
        ast = parse("sin(x)")
        expr = ast.statements[0]
        assert isinstance(expr, FunctionCall)
        assert expr.name == "sin"


class TestCompiler:
    """Test the compiler."""
    
    def test_compile_number(self):
        from physlang import parse, compile_to_python
        
        ast = parse("42")
        code = compile_to_python(ast)
        assert "42" in code
    
    def test_compile_addition(self):
        from physlang import parse, compile_to_python
        
        ast = parse("3 + 4")
        code = compile_to_python(ast)
        assert "(3 + 4)" in code
    
    def test_compile_let_binding(self):
        from physlang import parse, compile_to_python
        
        ast = parse("let x = 5")
        code = compile_to_python(ast)
        assert "x = 5" in code
    
    def test_compile_greek_letters(self):
        from physlang import parse, compile_to_python
        
        ast = parse("let α = 1")
        code = compile_to_python(ast)
        assert "alpha = 1" in code
    
    def test_compile_power(self):
        from physlang import parse, compile_to_python
        
        ast = parse("x²")
        code = compile_to_python(ast)
        assert "**2" in code
    
    def test_compile_sum_function(self):
        from physlang import parse, compile_to_python
        
        ast = parse("sum(n, 1, 10, n)")
        code = compile_to_python(ast)
        assert "for n in range" in code
    
    def test_compile_integrate_function(self):
        from physlang import parse, compile_to_python
        
        ast = parse("integrate(x, x, 0, 1)")
        code = compile_to_python(ast)
        assert "integrate.quad" in code
    
    def test_compile_to_jax(self):
        from physlang import parse, compile_to_jax
        
        ast = parse("let x = 5")
        code = compile_to_jax(ast)
        assert "jax" in code
        assert "jnp" in code


class TestRuntime:
    """Test execution."""
    
    def test_run_number(self):
        from physlang import run
        
        result = run("42")
        assert result is None  # standalone number doesn't return
    
    def test_run_compute(self):
        from physlang import run
        
        result = run("compute 3 + 4")
        assert result == 7
    
    def test_run_sum(self):
        from physlang import run
        
        result = run("compute sum(n, 1, 100, n)")
        assert result == 5050
    
    def test_run_sum_of_squares(self):
        from physlang import run
        
        result = run("compute sum(k, 1, 10, k^2)")
        assert result == 385
    
    def test_run_integrate(self):
        from physlang import run
        
        result = run("compute integrate(x, x, 0, 1)")
        assert abs(result - 0.5) < 0.001
    
    def test_run_sin(self):
        from physlang import run
        
        result = run("compute sin(0)")
        assert abs(result - 0.0) < 0.001
    
    def test_run_pi(self):
        from physlang import run
        
        result = run("compute pi")
        assert abs(result - math.pi) < 0.001
    
    def test_run_sqrt(self):
        from physlang import run
        
        result = run("compute sqrt(4)")
        assert result == 2.0
    
    def test_run_exp(self):
        from physlang import run
        
        result = run("compute exp(0)")
        assert result == 1.0


class TestIntegration:
    """Integration tests."""
    
    def test_gauss_sum(self):
        from physlang import run
        
        result = run("compute sum(n, 1, 100, n)")
        assert result == 100 * 101 // 2
    
    def test_geometric_series(self):
        from physlang import run
        
        # sum of 1 + 2 + 4 + 8 + 16 = 31
        result = run("compute sum(k, 0, 4, 2^k)")
        assert result == 31
    
    def test_integrate_sin(self):
        from physlang import run
        
        result = run("compute integrate(sin(x), x, 0, pi)")
        assert abs(result - 2.0) < 0.001
    
    def test_integrate_x_squared(self):
        from physlang import run
        
        result = run("compute integrate(x^2, x, 0, 1)")
        assert abs(result - 1/3) < 0.001
    
    def test_nested_expression(self):
        from physlang import run
        
        result = run("compute sqrt(3^2 + 4^2)")
        assert result == 5.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


class TestIDE:
    """Test IDE integration."""
    
    def test_ide_path_exists(self):
        """Test that IDE HTML file exists in package."""
        from physlang.repl import get_ide_path
        assert get_ide_path().exists()
    
    def test_launch_ide_importable(self):
        """Test that launch_ide is importable from main module."""
        from physlang import launch_ide
        assert callable(launch_ide)

    def test_icon_exists(self):
        """Test that icon files exist in package."""
        from physlang.desktop import get_icon_path, get_assets_dir
        assert get_icon_path('png').exists()
        assert get_icon_path('svg').exists()
        assert get_icon_path('ico').exists()
        assert get_assets_dir().exists()
    
    def test_install_desktop_importable(self):
        """Test that install_desktop is importable."""
        from physlang import install_desktop, uninstall_desktop
        assert callable(install_desktop)
        assert callable(uninstall_desktop)
