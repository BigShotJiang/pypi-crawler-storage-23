"""
Setup script for PhysLang with automatic desktop integration.
"""

import sys
import os
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop


class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        self.execute_post_install()
    
    def execute_post_install(self):
        # Import here to ensure package is installed
        try:
            # Add the install location to path
            if self.install_lib:
                sys.path.insert(0, self.install_lib)
            
            from physlang.post_install import post_install
            post_install()
        except Exception as e:
            print(f"Note: Post-install script skipped ({e})")


class PostDevelopCommand(develop):
    """Post-installation for development mode."""
    def run(self):
        develop.run(self)
        self.execute_post_install()
    
    def execute_post_install(self):
        try:
            from physlang.post_install import post_install
            post_install()
        except Exception as e:
            print(f"Note: Post-install script skipped ({e})")


# Only override if not building wheel
if 'bdist_wheel' not in sys.argv:
    cmdclass = {
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    }
else:
    cmdclass = {}


setup(cmdclass=cmdclass)
