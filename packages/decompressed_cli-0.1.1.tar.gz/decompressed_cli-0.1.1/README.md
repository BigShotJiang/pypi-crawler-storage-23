# Decompressed CLI

Git-like version control for vector datasets.

## Installation

```bash
pip install decompressed-cli
```

Or install from source:
```bash
cd sdk/cli
pip install -e .
```

## Quick Start

```bash
# Configure your API key
dcp config set api_key YOUR_API_KEY
dcp config set base_url https://api.decompressed.io

# List your datasets
dcp datasets list

# Get dataset info
dcp datasets info my-dataset

# Version control commands
dcp log my-dataset                    # Show version history
dcp checkout my-dataset --version 3   # Pin to version 3
dcp commit my-dataset -m "Added data" # Create new version
dcp tag my-dataset v3 production      # Tag version as 'production'
dcp diff my-dataset 2 3               # Compare versions

# Data commands
dcp pull my-dataset -o ./data/        # Download dataset
dcp push ./vectors.npy my-dataset     # Upload/append vectors
```

## Commands

### Configuration
- `dcp config set <key> <value>` - Set config value
- `dcp config get <key>` - Get config value
- `dcp config list` - List all config

### Datasets
- `dcp datasets list` - List all datasets
- `dcp datasets info <dataset>` - Show dataset details
- `dcp datasets delete <dataset>` - Delete a dataset

### Versioning
- `dcp log <dataset>` - Show version history
- `dcp checkout <dataset> --version <n>` - Pin to specific version
- `dcp commit <dataset> -m <message>` - Commit pending changes
- `dcp tag <dataset> <version> <name>` - Create named ref
- `dcp diff <dataset> <v1> <v2>` - Compare two versions

### Data
- `dcp pull <dataset> -o <path>` - Download dataset vectors
- `dcp push <file> <dataset>` - Upload/append vectors

## Configuration

Config is stored in `~/.decompressed/config.json`:

```json
{
  "api_key": "dcp_xxx",
  "base_url": "https://api.decompressed.io"
}
```
