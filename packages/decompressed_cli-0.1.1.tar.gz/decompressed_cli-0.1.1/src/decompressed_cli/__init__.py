"""Decompressed CLI - Git-like version control for vector datasets."""

__version__ = "0.1.0"
