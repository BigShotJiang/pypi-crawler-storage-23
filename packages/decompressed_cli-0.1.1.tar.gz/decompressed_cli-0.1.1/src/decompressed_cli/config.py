"""Configuration management for Decompressed CLI."""

import json
from pathlib import Path
from typing import Any, Dict, Optional

CONFIG_DIR = Path.home() / ".decompressed"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "api_key": None,
    "base_url": "http://localhost:8000",
}


def ensure_config_dir() -> None:
    """Ensure config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Dict[str, Any]:
    """Load config from file, creating defaults if needed."""
    ensure_config_dir()
    
    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    
    try:
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)
        # Merge with defaults for any missing keys
        for key, value in DEFAULT_CONFIG.items():
            if key not in config:
                config[key] = value
        return config
    except (json.JSONDecodeError, IOError):
        return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]) -> None:
    """Save config to file."""
    ensure_config_dir()
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_config_value(key: str) -> Optional[Any]:
    """Get a single config value."""
    config = load_config()
    return config.get(key)


def set_config_value(key: str, value: Any) -> None:
    """Set a single config value."""
    config = load_config()
    config[key] = value
    save_config(config)


def get_client():
    """Get configured SDK client."""
    from decompressed_sdk import DecompressedClient
    
    config = load_config()
    api_key = config.get("api_key")
    base_url = config.get("base_url", "http://localhost:8000")
    
    if not api_key:
        raise ValueError(
            "API key not configured. Run: dcp config set api_key YOUR_KEY"
        )
    
    return DecompressedClient(base_url=base_url, api_key=api_key)
