"""Main CLI entry point."""

import typer
from rich.console import Console

from . import __version__
from .commands import config_cmd, datasets_cmd, versions_cmd, data_cmd, imports_cmd

app = typer.Typer(
    name="dcp",
    help="Decompressed CLI - Git-like version control for vector datasets",
    no_args_is_help=True,
)
console = Console()

# Register command groups
app.add_typer(config_cmd.app, name="config", help="Manage CLI configuration")
app.add_typer(datasets_cmd.app, name="datasets", help="Manage datasets")
app.add_typer(data_cmd.app, name="data", help="Pull/push data (alias)")
app.add_typer(imports_cmd.app, name="imports", help="Import vectors from external databases")

# Register top-level versioning commands
app.command("log")(versions_cmd.log)
app.command("checkout")(versions_cmd.checkout)
app.command("commit")(versions_cmd.commit)
app.command("tag")(versions_cmd.tag)
app.command("diff")(versions_cmd.diff)

# Shortcuts for common operations
app.command("pull")(data_cmd.pull)
app.command("push")(data_cmd.push)


@app.command()
def version():
    """Show CLI version."""
    console.print(f"dcp version {__version__}")


@app.callback()
def main_callback():
    """Decompressed CLI - Git-like version control for vector datasets."""
    pass


if __name__ == "__main__":
    app()
