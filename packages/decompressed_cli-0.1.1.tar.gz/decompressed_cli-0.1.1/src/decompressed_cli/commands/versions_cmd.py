"""Version control commands - the core git-like functionality."""

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from typing import Optional

from ..config import get_client

console = Console()


def log(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of versions to show"),
):
    """Show version history for a dataset (like git log)."""
    try:
        client = get_client()
        events = client.datasets.history(dataset, limit=limit)
        
        if not events:
            console.print("[yellow]No version history found.[/yellow]")
            return
        
        console.print(f"[bold]Version history for {dataset}[/bold]\n")
        
        for event in events:
            # Format like git log
            version_str = f"v{event.version}" if event.version else "?"
            
            console.print(f"[yellow]commit {version_str}[/yellow]")
            if event.created_at:
                console.print(f"Date:   {event.created_at}")
            if event.action:
                console.print(f"Action: {event.action}")
            if event.description:
                console.print(f"\n    {event.description}")
            console.print()
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def checkout(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    version: int = typer.Option(..., "--version", "-v", help="Version number to checkout"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
):
    """
    Pin to a specific dataset version (like git checkout).
    
    This sets the working version for subsequent operations.
    """
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        # Verify version exists
        pinned = ds.version(version)
        info = pinned.info()
        
        # Handle both dict and dataclass responses
        num_vectors = info.get('num_vectors') if isinstance(info, dict) else getattr(info, 'num_vectors', None)
        num_blocks = info.get('num_blocks') if isinstance(info, dict) else getattr(info, 'num_blocks', None)
        
        console.print(f"[green]✓[/green] Checked out {dataset} @ v{version}")
        console.print(f"  Vectors: {num_vectors:,}" if num_vectors else "  Vectors: unknown")
        console.print(f"  Blocks: {num_blocks}" if num_blocks else "  Blocks: unknown")
        
        # Note: In a full implementation, we'd store this in local state
        console.print(f"\n[dim]Tip: Use --version {version} in other commands to use this version[/dim]")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def commit(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    message: str = typer.Option(..., "--message", "-m", help="Commit message"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
):
    """
    Commit pending changes to create a new version (like git commit).
    
    Note: In Decompressed, versions are created automatically when you
    push data. This command is for adding a description to the current version.
    """
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        # For now, just show current version info
        # In a full implementation, this would finalize a draft version
        console.print(f"[green]✓[/green] Current version: v{ds.current_version}")
        console.print(f"  Message: {message}")
        console.print(f"\n[dim]Note: Versions are created automatically when pushing data.[/dim]")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def tag(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    version: int = typer.Argument(..., help="Version number to tag"),
    name: str = typer.Argument(..., help="Tag name (e.g., 'production', 'stable')"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
):
    """
    Create a named ref for a version (like git tag).
    
    Example: dcp tag my-dataset 3 production
    """
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        # Get the version and promote it
        pinned = ds.version(version)
        pinned.promote(name)
        
        console.print(f"[green]✓[/green] Tagged {dataset} v{version} as '{name}'")
        console.print(f"\n[dim]Access via: dataset.ref('{name}')[/dim]")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def diff(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    version1: int = typer.Argument(..., help="First version"),
    version2: int = typer.Argument(..., help="Second version"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
):
    """
    Compare two versions of a dataset (like git diff).
    
    Example: dcp diff my-dataset 2 3
    """
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        # Get info for both versions
        v1 = ds.version(version1)
        v2 = ds.version(version2)
        
        info1 = v1.info()
        info2 = v2.info()
        
        # Helper to get value from dict or dataclass
        def get_val(info, key, default=0):
            if isinstance(info, dict):
                return info.get(key, default)
            return getattr(info, key, default) or default
        
        console.print(f"[bold]Comparing {dataset}: v{version1} → v{version2}[/bold]\n")
        
        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column(f"v{version1}", justify="right")
        table.add_column(f"v{version2}", justify="right")
        table.add_column("Change", justify="right")
        
        # Vectors
        v1_vecs = get_val(info1, "num_vectors", 0)
        v2_vecs = get_val(info2, "num_vectors", 0)
        vec_diff = v2_vecs - v1_vecs
        vec_change = f"[green]+{vec_diff:,}[/green]" if vec_diff > 0 else f"[red]{vec_diff:,}[/red]" if vec_diff < 0 else "0"
        table.add_row("Vectors", f"{v1_vecs:,}", f"{v2_vecs:,}", vec_change)
        
        # Blocks
        v1_blocks = get_val(info1, "num_blocks", 0)
        v2_blocks = get_val(info2, "num_blocks", 0)
        block_diff = v2_blocks - v1_blocks
        block_change = f"[green]+{block_diff}[/green]" if block_diff > 0 else f"[red]{block_diff}[/red]" if block_diff < 0 else "0"
        table.add_row("Blocks", str(v1_blocks), str(v2_blocks), block_change)
        
        console.print(table)
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
