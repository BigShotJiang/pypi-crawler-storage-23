"""Configuration commands."""

import typer
from rich.console import Console
from rich.table import Table

from ..config import load_config, set_config_value, get_config_value, CONFIG_FILE

app = typer.Typer(no_args_is_help=True)
console = Console()


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (api_key, base_url)"),
    value: str = typer.Argument(..., help="Config value"),
):
    """Set a configuration value."""
    valid_keys = ["api_key", "base_url"]
    if key not in valid_keys:
        console.print(f"[red]Unknown config key: {key}[/red]")
        console.print(f"Valid keys: {', '.join(valid_keys)}")
        raise typer.Exit(1)
    
    set_config_value(key, value)
    
    # Mask API key in output
    display_value = value[:8] + "..." if key == "api_key" and len(value) > 8 else value
    console.print(f"[green]✓[/green] Set {key} = {display_value}")


@app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to get"),
):
    """Get a configuration value."""
    value = get_config_value(key)
    if value is None:
        console.print(f"[yellow]Not set:[/yellow] {key}")
    else:
        # Mask API key
        display_value = value[:8] + "..." if key == "api_key" and len(str(value)) > 8 else value
        console.print(f"{key} = {display_value}")


@app.command("list")
def config_list():
    """List all configuration values."""
    config = load_config()
    
    table = Table(title=f"Config ({CONFIG_FILE})")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")
    
    for key, value in config.items():
        if value is None:
            display_value = "[dim]not set[/dim]"
        elif key == "api_key" and len(str(value)) > 8:
            display_value = value[:8] + "..."
        else:
            display_value = str(value)
        table.add_row(key, display_value)
    
    console.print(table)


@app.command("path")
def config_path():
    """Show config file path."""
    console.print(str(CONFIG_FILE))
