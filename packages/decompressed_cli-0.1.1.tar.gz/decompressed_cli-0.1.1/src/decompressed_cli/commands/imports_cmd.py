"""Import commands for pulling vectors from external databases."""

import time
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from ..config import get_client

app = typer.Typer(no_args_is_help=True)
console = Console()


@app.command("pull")
def pull(
    connector: str = typer.Argument(..., help="Connector name or ID to import from"),
    dataset_name: str = typer.Argument(..., help="Name for the new dataset"),
    project: str = typer.Option(None, "--project", "-p", help="Project name or ID"),
    no_metadata: bool = typer.Option(False, "--no-metadata", help="Skip importing metadata"),
    batch_size: int = typer.Option(100, "--batch-size", "-b", help="Vectors per batch"),
    no_wait: bool = typer.Option(False, "--no-wait", help="Don't wait for completion"),
):
    """
    Pull vectors from an external database into a new dataset.
    
    Example:
        dcp imports pull pinecone-prod my-backup
        dcp imports pull qdrant-index imported-vectors --project ml-team
    """
    try:
        client = get_client()
        
        console.print(f"[cyan]Connecting to connector:[/cyan] {connector}")
        
        # Initialize import
        session = client.imports.init(
            connector_id=connector,
            dataset_name=dataset_name,
            project=project,
            include_metadata=not no_metadata,
            batch_size=batch_size,
        )
        
        console.print(Panel(
            f"[green]✓[/green] Connected to [cyan]{session.connector_type}[/cyan]\n"
            f"[dim]Estimated vectors:[/dim] {session.estimated_vectors:,}\n"
            f"[dim]Dimension:[/dim] {session.dimension}\n"
            f"[dim]Dataset ID:[/dim] {session.dataset_id}",
            title="Import Initialized",
            border_style="green"
        ))
        
        # Start the import
        result = client.imports.start(session.import_session_id)
        console.print(f"[cyan]Import job started:[/cyan] {result.job_id[:8]}...")
        
        if no_wait:
            console.print(f"\n[yellow]Import running in background.[/yellow]")
            console.print(f"Check status: [cyan]dcp imports status {session.import_session_id}[/cyan]")
            return
        
        # Wait with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console,
        ) as progress:
            task = progress.add_task("Importing vectors...", total=100)
            
            while True:
                job = client.imports.status(session.import_session_id)
                
                if job.progress:
                    progress.update(task, completed=job.progress)
                
                if job.status == "completed":
                    progress.update(task, completed=100)
                    break
                elif job.status == "failed":
                    console.print(f"\n[red]✗ Import failed:[/red] {job.error_message}")
                    raise typer.Exit(1)
                
                time.sleep(2)
        
        console.print(Panel(
            f"[green]✓[/green] Import complete!\n"
            f"[dim]Dataset:[/dim] {dataset_name}\n"
            f"[dim]Dataset ID:[/dim] {session.dataset_id}",
            title="Success",
            border_style="green"
        ))
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("append")
def append(
    connector: str = typer.Argument(..., help="Connector name or ID to import from"),
    dataset: str = typer.Argument(..., help="Existing dataset name or ID to append to"),
    no_metadata: bool = typer.Option(False, "--no-metadata", help="Skip importing metadata"),
    batch_size: int = typer.Option(100, "--batch-size", "-b", help="Vectors per batch"),
    no_wait: bool = typer.Option(False, "--no-wait", help="Don't wait for completion"),
):
    """
    Append vectors from an external database to an existing dataset.
    
    Example:
        dcp imports append pinecone-prod my-dataset
    """
    try:
        client = get_client()
        
        # Resolve dataset ID
        ds = client.datasets.get(dataset)
        
        console.print(f"[cyan]Connecting to connector:[/cyan] {connector}")
        console.print(f"[cyan]Appending to dataset:[/cyan] {ds.name} (v{ds.current_version})")
        
        # Initialize append import
        session = client.imports.init_append(
            connector_id=connector,
            dataset_id=ds.id,
            include_metadata=not no_metadata,
            batch_size=batch_size,
        )
        
        console.print(Panel(
            f"[green]✓[/green] Connected to [cyan]{session.connector_type}[/cyan]\n"
            f"[dim]Estimated vectors:[/dim] {session.estimated_vectors:,}\n"
            f"[dim]Dimension:[/dim] {session.dimension}",
            title="Append Import Initialized",
            border_style="green"
        ))
        
        # Start the import
        result = client.imports.start(session.import_session_id)
        console.print(f"[cyan]Import job started:[/cyan] {result.job_id[:8]}...")
        
        if no_wait:
            console.print(f"\n[yellow]Import running in background.[/yellow]")
            console.print(f"Check status: [cyan]dcp imports status {session.import_session_id}[/cyan]")
            return
        
        # Wait with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console,
        ) as progress:
            task = progress.add_task("Importing vectors...", total=100)
            
            while True:
                job = client.imports.status(session.import_session_id)
                
                if job.progress:
                    progress.update(task, completed=job.progress)
                
                if job.status == "completed":
                    progress.update(task, completed=100)
                    break
                elif job.status == "failed":
                    console.print(f"\n[red]✗ Import failed:[/red] {job.error_message}")
                    raise typer.Exit(1)
                
                time.sleep(2)
        
        console.print(f"[green]✓[/green] Appended vectors to [cyan]{ds.name}[/cyan]")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("status")
def status(
    session_id: str = typer.Argument(..., help="Import session ID"),
):
    """Check status of an import job."""
    try:
        client = get_client()
        job = client.imports.status(session_id)
        
        status_color = {
            "initialized": "yellow",
            "in_progress": "cyan",
            "completed": "green",
            "failed": "red",
        }.get(job.status, "white")
        
        panel_content = f"""[cyan]Session ID:[/cyan] {job.import_session_id}
[cyan]Dataset ID:[/cyan] {job.dataset_id or 'N/A'}
[cyan]Status:[/cyan] [{status_color}]{job.status}[/{status_color}]
[cyan]Progress:[/cyan] {job.progress or 0}%
[cyan]Job ID:[/cyan] {job.job_id or 'N/A'}"""
        
        if job.error_message:
            panel_content += f"\n[red]Error:[/red] {job.error_message}"
        
        console.print(Panel(panel_content, title="Import Status", border_style=status_color))
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
