"""Dataset management commands."""

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from ..config import get_client

app = typer.Typer(no_args_is_help=True)
console = Console()


@app.command("list")
def list_datasets():
    """List all datasets."""
    try:
        client = get_client()
        datasets = client.datasets.list()
        
        if not datasets:
            console.print("[yellow]No datasets found.[/yellow]")
            return
        
        table = Table(title="Datasets")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Vectors", justify="right")
        table.add_column("Dims", justify="right")
        table.add_column("Version", justify="right", style="green")
        
        for ds in datasets:
            table.add_row(
                ds.name,
                ds.id[:8] + "...",
                f"{ds.num_vectors:,}" if ds.num_vectors else "-",
                str(ds.dimensions) if ds.dimensions else "-",
                f"v{ds.current_version}" if ds.current_version else "-",
            )
        
        console.print(table)
        console.print(f"\n[dim]{len(datasets)} dataset(s)[/dim]")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("info")
def info(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
):
    """Show detailed dataset information."""
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        panel_content = f"""[cyan]Name:[/cyan] {ds.name}
[cyan]ID:[/cyan] {ds.id}
[cyan]Vectors:[/cyan] {ds.num_vectors:,} vectors
[cyan]Dimensions:[/cyan] {ds.dimensions}
[cyan]Current Version:[/cyan] v{ds.current_version}
[cyan]Created:[/cyan] {ds.created_at or 'Unknown'}
[cyan]Updated:[/cyan] {ds.updated_at or 'Unknown'}"""
        
        console.print(Panel(panel_content, title=f"Dataset: {ds.name}", border_style="green"))
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command("delete")
def delete(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a dataset."""
    try:
        client = get_client()
        
        if not force:
            confirm = typer.confirm(f"Delete dataset '{dataset}'? This cannot be undone")
            if not confirm:
                console.print("[yellow]Cancelled.[/yellow]")
                raise typer.Exit(0)
        
        client.datasets.delete(dataset, project=project, delete_file=True)
        console.print(f"[green]✓[/green] Deleted dataset: {dataset}")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
