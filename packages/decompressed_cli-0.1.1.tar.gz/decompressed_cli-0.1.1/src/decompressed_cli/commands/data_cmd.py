"""Data pull/push commands."""

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from pathlib import Path
from typing import Optional

from ..config import get_client

app = typer.Typer(no_args_is_help=True)
console = Console()


def pull(
    dataset: str = typer.Argument(..., help="Dataset name or ID"),
    output: Path = typer.Option(
        Path("./"), "--output", "-o", help="Output directory"
    ),
    version: Optional[int] = typer.Option(
        None, "--version", "-v", help="Specific version (default: latest)"
    ),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
    format: str = typer.Option("npy", "--format", "-f", help="Output format (npy, csv)"),
):
    """
    Download dataset vectors to local files.
    
    Example:
        dcp pull my-dataset -o ./data/
        dcp pull my-dataset --version 3 -o ./data/
    """
    try:
        client = get_client()
        ds = client.datasets.get(dataset, project=project)
        
        target_version = version or ds.current_version
        output.mkdir(parents=True, exist_ok=True)
        
        console.print(f"Pulling {dataset} v{target_version}...")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Downloading blocks...", total=None)
            
            block_count = 0
            vector_count = 0
            
            for block in client.datasets.iter_blocks(
                dataset, 
                project=project,
                version=target_version,
                include_metadata=True,
                prefetch=True,
            ):
                block_count += 1
                vector_count += block.num_vectors
                progress.update(
                    task, 
                    description=f"Block {block.block_index + 1}/{block.total_blocks} ({vector_count:,} vectors)"
                )
                
                # Save block
                import numpy as np
                block_file = output / f"{block.block_id}.npy"
                np.save(block_file, block.vectors)
                
                # Save metadata if present
                if block.metadata and any(block.metadata):
                    import json
                    meta_file = output / f"{block.block_id}_metadata.json"
                    with open(meta_file, "w") as f:
                        json.dump(block.metadata, f)
        
        console.print(f"\n[green]✓[/green] Downloaded {vector_count:,} vectors in {block_count} blocks")
        console.print(f"  Output: {output.absolute()}")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def push(
    file: Path = typer.Argument(..., help="File to upload (.npy, .csv, .parquet)"),
    dataset: str = typer.Argument(..., help="Dataset name (creates new or appends)"),
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
    message: str = typer.Option(None, "--message", "-m", help="Version message"),
    compression: str = typer.Option(None, "--compression", "-c", help="Compression (fp16, int8)"),
):
    """
    Upload vectors to a dataset (creates new or appends).
    
    Example:
        dcp push ./vectors.npy my-dataset
        dcp push ./vectors.npy my-dataset -m "Added January data"
    """
    try:
        if not file.exists():
            console.print(f"[red]Error:[/red] File not found: {file}")
            raise typer.Exit(1)
        
        client = get_client()
        
        # Check if dataset exists
        try:
            existing = client.datasets.get(dataset, project=project)
            is_append = True
            console.print(f"Appending to existing dataset: {dataset} (v{existing.current_version})")
        except Exception:
            is_append = False
            console.print(f"Creating new dataset: {dataset}")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Uploading...", total=None)
            
            if is_append:
                progress.update(task, description="Appending vectors...")
                result = client.datasets.append(
                    file,
                    dataset,
                    project=project,
                    compression=compression,
                    description=message,
                )
                new_version = result.new_version
            else:
                progress.update(task, description="Uploading new dataset...")
                result = client.datasets.upload(
                    file,
                    dataset,
                    project=project,
                    compression=compression,
                )
                new_version = 1
        
        console.print(f"\n[green]✓[/green] {'Appended to' if is_append else 'Created'} {dataset}")
        console.print(f"  Version: v{new_version}")
        if message:
            console.print(f"  Message: {message}")
        
    except ValueError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


# Register commands on the app
app.command("pull")(pull)
app.command("push")(push)
