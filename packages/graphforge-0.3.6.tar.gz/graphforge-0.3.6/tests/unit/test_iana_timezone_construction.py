"""Unit tests for CypherDateTime IANA timezone construction (issue #272)."""

import pytest

from graphforge.types.values import CypherDateTime


@pytest.mark.unit
class TestCypherDateTimeIANAConstruction:
    """Direct CypherDateTime construction with IANA timezone strings."""

    def test_basic_iana_zone(self):
        """CypherDateTime('2015-07-21T21:40:32[Europe/London]') is timezone-aware."""
        dt = CypherDateTime("2015-07-21T21:40:32[Europe/London]").value
        assert dt.year == 2015
        assert dt.hour == 21
        assert dt.tzinfo is not None

    def test_historical_second_precision_offset(self):
        """Second-precision UTC offset stripped; IANA zone applied instead."""
        dt = CypherDateTime("1818-07-21T21:40:32.142+00:53:28[Europe/Stockholm]").value
        assert dt.year == 1818
        assert dt.hour == 21
        assert dt.tzinfo is not None

    def test_z_offset_with_iana_zone(self):
        """Z offset is stripped; IANA zone (UTC) is authoritative."""
        dt = CypherDateTime("2015-07-21T21:40:32Z[UTC]").value
        assert dt.hour == 21
        assert dt.tzinfo is not None

    def test_invalid_iana_zone_raises(self):
        """Unknown IANA zone name raises ValueError."""
        with pytest.raises(ValueError, match="Unknown IANA timezone"):
            CypherDateTime("2015-07-21T21:40:32[Invalid/Zone]")
