"""Unit tests for WHERE n:Label label predicate parsing (issue #259)."""

import pytest

from graphforge.ast.expression import LabelPredicate
from graphforge.parser.parser import CypherParser


@pytest.fixture
def parser():
    return CypherParser()


@pytest.mark.unit
class TestLabelPredicateParsing:
    """Parser emits LabelPredicate AST nodes for WHERE n:Label syntax."""

    def test_single_label(self, parser):
        """WHERE n:Person produces LabelPredicate with one label."""
        ast = parser.parse("MATCH (n) WHERE n:Person RETURN n")
        where = ast.clauses[1]  # WhereClause is a separate clause after MatchClause
        assert isinstance(where.predicate, LabelPredicate)
        assert where.predicate.variable == "n"
        assert where.predicate.labels == ["Person"]

    def test_multiple_labels(self, parser):
        """WHERE n:Person:Employee produces LabelPredicate with two labels."""
        ast = parser.parse("MATCH (n) WHERE n:Person:Employee RETURN n")
        where = ast.clauses[1]
        assert isinstance(where.predicate, LabelPredicate)
        assert where.predicate.variable == "n"
        assert where.predicate.labels == ["Person", "Employee"]

    def test_label_in_and_expression(self, parser):
        """WHERE a:A AND b:B parses both sides as LabelPredicate."""
        from graphforge.ast.expression import BinaryOp

        ast = parser.parse("MATCH (a), (b) WHERE a:A AND b:B RETURN a, b")
        condition = ast.clauses[1].predicate
        assert isinstance(condition, BinaryOp)
        assert condition.op == "AND"
        assert isinstance(condition.left, LabelPredicate)
        assert condition.left.variable == "a"
        assert condition.left.labels == ["A"]
        assert isinstance(condition.right, LabelPredicate)
        assert condition.right.variable == "b"
        assert condition.right.labels == ["B"]

    def test_label_in_or_expression(self, parser):
        """WHERE n:Person OR n:Robot parses correctly."""
        from graphforge.ast.expression import BinaryOp

        ast = parser.parse("MATCH (n) WHERE n:Person OR n:Robot RETURN n")
        condition = ast.clauses[1].predicate
        assert isinstance(condition, BinaryOp)
        assert condition.op == "OR"

    def test_label_in_not_expression(self, parser):
        """WHERE NOT n:Robot parses correctly."""
        from graphforge.ast.expression import UnaryOp

        ast = parser.parse("MATCH (n) WHERE NOT n:Robot RETURN n")
        condition = ast.clauses[1].predicate
        assert isinstance(condition, UnaryOp)
        assert condition.op == "NOT"
        assert isinstance(condition.operand, LabelPredicate)
        assert condition.operand.labels == ["Robot"]

    def test_label_combined_with_property(self, parser):
        """WHERE n:Person AND n.age > 25 parses correctly."""
        from graphforge.ast.expression import BinaryOp

        ast = parser.parse("MATCH (n) WHERE n:Person AND n.age > 25 RETURN n")
        condition = ast.clauses[1].predicate
        assert isinstance(condition, BinaryOp)
        assert condition.op == "AND"
        assert isinstance(condition.left, LabelPredicate)
