"""Tests for query executor."""
