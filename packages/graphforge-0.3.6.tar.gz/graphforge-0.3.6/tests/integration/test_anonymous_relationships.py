"""Integration tests for anonymous relationship patterns (issue #260)."""

import pytest

from graphforge import GraphForge


@pytest.mark.integration
class TestAnonymousRelationshipPatterns:
    """Anonymous relationship patterns: -->, <--, --, <-->."""

    def _graph(self):
        gf = GraphForge()
        gf.execute("CREATE (:A {name: 'a'})-[:KNOWS]->(:B {name: 'b'})")
        return gf

    def test_anon_outgoing(self):
        """(a)-->(b) matches outgoing edges."""
        gf = self._graph()
        r = gf.execute("MATCH (a)-->(b) RETURN a.name AS a, b.name AS b")
        assert len(r) == 1
        assert r[0]["a"].value == "a"
        assert r[0]["b"].value == "b"

    def test_anon_incoming(self):
        """(a)<--(b) matches edges in reverse."""
        gf = self._graph()
        r = gf.execute("MATCH (a)<--(b) RETURN a.name AS a, b.name AS b")
        assert len(r) == 1
        assert r[0]["a"].value == "b"
        assert r[0]["b"].value == "a"

    def test_anon_undirected(self):
        """(a)--(b) matches edges in both directions."""
        gf = self._graph()
        r = gf.execute("MATCH (a)--(b) RETURN a.name AS a, b.name AS b ORDER BY a.name")
        assert len(r) == 2
        names = [(row["a"].value, row["b"].value) for row in r]
        assert ("a", "b") in names
        assert ("b", "a") in names

    def test_anon_bidirectional(self):
        """(a)<-->(b) matches edges regardless of direction (same as --)."""
        gf = self._graph()
        r = gf.execute("MATCH (a)<-->(b) RETURN a.name AS a, b.name AS b ORDER BY a.name")
        assert len(r) == 2

    def test_anon_outgoing_no_match(self):
        """(a)-->(b) returns empty when direction is wrong."""
        gf = self._graph()
        r = gf.execute("MATCH (b:B)-->(a:A) RETURN b, a")
        assert len(r) == 0

    def test_anon_chained_hops(self):
        """(a)-->(b)-->(c) matches a chain of anonymous hops."""
        gf = GraphForge()
        gf.execute("CREATE (:X {n: 1})-[:R]->(:X {n: 2})-[:R]->(:X {n: 3})")
        r = gf.execute("MATCH (a)-->(b)-->(c) RETURN a.n AS a, b.n AS b, c.n AS c")
        assert len(r) == 1
        assert r[0]["a"].value == 1
        assert r[0]["b"].value == 2
        assert r[0]["c"].value == 3

    def test_anon_with_label_filter(self):
        """(a)-->(b:B) anonymous hop with label filter on target."""
        gf = self._graph()
        r = gf.execute("MATCH (a)-->(b:B) RETURN b.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "b"

    def test_anon_outgoing_returns_no_match_for_reverse(self):
        """(a:B)-->(b:A) should return nothing (edge goes A->B)."""
        gf = self._graph()
        r = gf.execute("MATCH (a:B)-->(b:A) RETURN a, b")
        assert len(r) == 0
