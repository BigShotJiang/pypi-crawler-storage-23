"""Integration tests for IANA timezone names in datetime strings (issue #272)."""

import pytest

from graphforge import GraphForge


@pytest.mark.integration
class TestIANATimezoneInStrings:
    """datetime() and localdatetime() parsing of [Region/City] timezone suffix."""

    def test_basic_iana_timezone(self):
        """datetime('2015-07-21T21:40:32.142[Europe/London]') is UTC+1 in summer (BST)."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-07-21T21:40:32.142[Europe/London]') AS dt")
        dt = r[0]["dt"].value
        assert dt.year == 2015
        assert dt.month == 7
        assert dt.day == 21
        assert dt.hour == 21
        assert dt.minute == 40
        assert dt.second == 32
        assert dt.tzinfo is not None

    def test_iana_timezone_with_offset(self):
        """IANA zone is authoritative when both offset and zone name present."""
        # Use a deliberately conflicting offset (+05:00) with Europe/Berlin (UTC+2 in July)
        # to prove that the IANA zone is used and the explicit offset is discarded.
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-07-21T21:40:32+05:00[Europe/Berlin]') AS dt")
        dt = r[0]["dt"].value
        assert dt.year == 2015
        assert dt.hour == 21  # wall-clock time preserved (offset stripped, IANA applied)
        assert dt.tzinfo is not None
        # Europe/Berlin in July is UTC+2, not UTC+5
        from datetime import timedelta

        assert dt.utcoffset() == timedelta(hours=2)

    def test_iana_timezone_utc(self):
        """datetime string with [UTC] timezone zone."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-07-21T21:40:32[UTC]') AS dt")
        dt = r[0]["dt"].value
        assert dt.year == 2015
        assert dt.hour == 21
        assert dt.tzinfo is not None

    def test_iana_timezone_us(self):
        """datetime with US/Eastern timezone name."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-07-21T21:40:32[America/New_York]') AS dt")
        dt = r[0]["dt"].value
        assert dt.year == 2015
        assert dt.hour == 21
        assert dt.tzinfo is not None

    def test_iana_timezone_stored_as_property(self):
        """datetime with IANA zone can be stored and retrieved as a node property."""
        gf = GraphForge()
        gf.execute("CREATE (:Event {ts: datetime('2015-07-21T21:40:32[Europe/Paris]')})")
        r = gf.execute("MATCH (e:Event) RETURN e.ts AS ts")
        dt = r[0]["ts"].value
        assert dt.year == 2015
        assert dt.tzinfo is not None

    def test_iana_timezone_with_compact_date(self):
        """IANA zone combined with compact week-date format."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-W30-2T21:40:32[Europe/London]') AS dt")
        dt = r[0]["dt"].value
        # 2015-W30-2 = 2015-07-21
        assert dt.year == 2015
        assert dt.month == 7
        assert dt.day == 21
        assert dt.hour == 21

    def test_iana_timezone_with_compact_time(self):
        """IANA zone combined with compact time (no colons)."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime('2015-07-21T214032[Europe/London]') AS dt")
        dt = r[0]["dt"].value
        assert dt.hour == 21
        assert dt.minute == 40
        assert dt.second == 32

    def test_iana_timezone_historical_offset(self):
        """Datetime with historical second-precision offset + IANA zone is handled."""
        # 1818-07-21T21:40:32.142+00:53:28[Europe/Stockholm] — dateutil cannot
        # parse +00:53:28 directly; our code strips the offset, uses the IANA zone.
        gf = GraphForge()
        r = gf.execute(
            "RETURN datetime('1818-07-21T21:40:32.142+00:53:28[Europe/Stockholm]') AS dt"
        )
        dt = r[0]["dt"].value
        assert dt.year == 1818
        assert dt.month == 7
        assert dt.day == 21
        assert dt.hour == 21
        assert dt.minute == 40
        assert dt.second == 32
        assert dt.tzinfo is not None
