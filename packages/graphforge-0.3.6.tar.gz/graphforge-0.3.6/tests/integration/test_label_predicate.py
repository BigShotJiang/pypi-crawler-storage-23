"""Integration tests for WHERE n:Label label predicate syntax (issue #259)."""

import pytest

from graphforge import GraphForge


@pytest.mark.integration
class TestLabelPredicate:
    """WHERE n:Label syntax in MATCH and WITH clauses."""

    def test_single_label_match(self):
        """WHERE n:Person filters correctly."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {name: 'Alice'}), (:Robot {name: 'R2D2'})")
        r = gf.execute("MATCH (n) WHERE n:Person RETURN n.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "Alice"

    def test_non_matching_label(self):
        """WHERE n:NonExistent returns nothing."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {name: 'Alice'})")
        r = gf.execute("MATCH (n) WHERE n:NonExistent RETURN n")
        assert len(r) == 0

    def test_multiple_labels_conjunction(self):
        """WHERE n:Person:Employee requires all labels."""
        gf = GraphForge()
        gf.execute(
            "CREATE (:Person {name: 'Alice'}), "
            "(:Person:Employee {name: 'Bob'}), "
            "(:Employee {name: 'Carol'})"
        )
        r = gf.execute("MATCH (n) WHERE n:Person:Employee RETURN n.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "Bob"

    def test_label_or(self):
        """WHERE n:Person OR n:Robot matches either label."""
        gf = GraphForge()
        gf.execute(
            "CREATE (:Person {name: 'Alice'}), (:Robot {name: 'R2D2'}), (:Animal {name: 'Rex'})"
        )
        r = gf.execute("MATCH (n) WHERE n:Person OR n:Robot RETURN n.name AS name ORDER BY n.name")
        names = [row["name"].value for row in r]
        assert names == ["Alice", "R2D2"]

    def test_label_not(self):
        """WHERE NOT n:Robot excludes that label."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {name: 'Alice'}), (:Robot {name: 'R2D2'})")
        r = gf.execute("MATCH (n) WHERE NOT n:Robot RETURN n.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "Alice"

    def test_label_and_property(self):
        """WHERE n:Person AND n.age > 25 combines label and property filter."""
        gf = GraphForge()
        gf.execute(
            "CREATE (:Person {name: 'Alice', age: 30}), (:Person {name: 'Bob', age: 20}), (:Robot {name: 'R2D2', age: 99})"
        )
        r = gf.execute("MATCH (n) WHERE n:Person AND n.age > 25 RETURN n.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "Alice"

    def test_label_predicate_two_node_match(self):
        """WHERE a:A AND b:B on a cartesian product."""
        gf = GraphForge()
        gf.execute("CREATE (:A {v: 1}), (:B {v: 2}), (:C {v: 3})")
        r = gf.execute("MATCH (a), (b) WHERE a:A AND b:B RETURN a.v AS a, b.v AS b")
        assert len(r) == 1
        assert r[0]["a"].value == 1
        assert r[0]["b"].value == 2

    def test_label_predicate_with_anonymous_rel(self):
        """WHERE label predicate combined with anonymous relationship pattern."""
        gf = GraphForge()
        gf.execute("CREATE (:A {name: 'a'})-[:R]->(:B {name: 'b'})")
        r = gf.execute("MATCH (a)-->(b) WHERE a:A RETURN b.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "b"

    def test_label_predicate_in_with_where(self):
        """Label predicate works in WITH ... WHERE syntax."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {name: 'Alice'}), (:Robot {name: 'R2D2'})")
        r = gf.execute("MATCH (n) WITH n WHERE n:Person RETURN n.name AS name")
        assert len(r) == 1
        assert r[0]["name"].value == "Alice"

    def test_label_predicate_null_propagation(self):
        """WHERE x:Label returns null (not false) when x is null (three-valued logic)."""
        from graphforge.types.values import CypherNull

        gf = GraphForge()
        # OPTIONAL MATCH on a non-existent pattern produces null for unmatched variable
        gf.execute("CREATE (:Person {name: 'Alice'})")
        r = gf.execute(
            "MATCH (n) OPTIONAL MATCH (n)-[:KNOWS]->(m) "
            "RETURN n.name AS name, m:Person AS is_person"
        )
        assert len(r) == 1
        assert r[0]["name"].value == "Alice"
        # m is null because no KNOWS relationship exists; m:Person should be null
        assert isinstance(r[0]["is_person"], CypherNull)
