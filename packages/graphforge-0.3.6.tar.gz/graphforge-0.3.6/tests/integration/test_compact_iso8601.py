"""Integration tests for compact ISO 8601 date/datetime string formats (issue #273)."""

import pytest

from graphforge import GraphForge


@pytest.mark.integration
class TestCompactISO8601Date:
    """date() function with compact ISO 8601 string formats."""

    def test_year_only(self):
        """date('2015') → 2015-01-01."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015') AS d")
        assert r[0]["d"].value.isoformat() == "2015-01-01"

    def test_year_month_separator(self):
        """date('2015-07') → 2015-07-01."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015-07') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-01"

    def test_year_month_compact(self):
        """date('201507') → 2015-07-01."""
        gf = GraphForge()
        r = gf.execute("RETURN date('201507') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-01"

    def test_ordinal_separator(self):
        """date('2015-202') → 2015-07-21."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015-202') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-21"

    def test_ordinal_compact(self):
        """date('2015202') → 2015-07-21."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015202') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-21"

    def test_week_date_with_day_separator(self):
        """date('2015-W30-2') → 2015-07-21."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015-W30-2') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-21"

    def test_week_date_with_day_compact(self):
        """date('2015W302') → 2015-07-21."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015W302') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-21"

    def test_week_date_no_day_separator(self):
        """date('2015-W30') → 2015-07-20 (Monday)."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015-W30') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-20"

    def test_week_date_no_day_compact(self):
        """date('2015W30') → 2015-07-20 (Monday)."""
        gf = GraphForge()
        r = gf.execute("RETURN date('2015W30') AS d")
        assert r[0]["d"].value.isoformat() == "2015-07-20"


@pytest.mark.integration
class TestCompactISO8601LocalDateTime:
    """localdatetime() with compact date and/or compact time components."""

    def test_week_date_with_compact_time(self):
        """localdatetime('2015-W30-2T214032.142') → 2015-07-21T21:40:32.142."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime('2015-W30-2T214032.142') AS dt")
        assert r[0]["dt"].value.isoformat() == "2015-07-21T21:40:32.142000"

    def test_ordinal_with_normal_time(self):
        """localdatetime('2015-202T21:40:32') → 2015-07-21T21:40:32."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime('2015-202T21:40:32') AS dt")
        assert r[0]["dt"].value.isoformat() == "2015-07-21T21:40:32"

    def test_year_only_with_compact_time(self):
        """localdatetime('2015T214032') → 2015-01-01T21:40:32."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime('2015T214032') AS dt")
        assert r[0]["dt"].value.isoformat() == "2015-01-01T21:40:32"

    def test_week_date_no_day_with_compact_time(self):
        """localdatetime('2015-W30T2140') → 2015-07-20T21:40:00."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime('2015-W30T2140') AS dt")
        assert r[0]["dt"].value.isoformat() == "2015-07-20T21:40:00"

    def test_ordinal_compact_with_hour_only(self):
        """localdatetime('2015202T21') → 2015-07-21T21:00:00."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime('2015202T21') AS dt")
        assert r[0]["dt"].value.isoformat() == "2015-07-21T21:00:00"


@pytest.mark.integration
class TestCompactISO8601Validation:
    """Invalid compact formats are rejected with clear errors."""

    def test_ordinal_zero_rejected(self):
        """date('2015-000') raises ValueError — ordinal 0 is out of range."""
        from graphforge.types.values import _parse_iso_date_part

        with pytest.raises(ValueError, match="ordinal 0 is out of range"):
            _parse_iso_date_part("2015-000")

    def test_ordinal_too_large_non_leap_rejected(self):
        """date('2015-366') raises ValueError — 2015 has only 365 days."""
        from graphforge.types.values import _parse_iso_date_part

        with pytest.raises(ValueError, match="ordinal 366 is out of range"):
            _parse_iso_date_part("2015-366")

    def test_ordinal_366_accepted_on_leap_year(self):
        """date('2016-366') is valid — 2016 is a leap year."""
        from graphforge.types.values import _parse_iso_date_part

        d = _parse_iso_date_part("2016-366")
        assert d.isoformat() == "2016-12-31"

    def test_compact_time_bad_length_rejected(self):
        """_normalize_compact_time raises ValueError for 3-digit time."""
        from graphforge.types.values import _normalize_compact_time

        with pytest.raises(ValueError, match="unsupported compact time length 3"):
            _normalize_compact_time("214")
