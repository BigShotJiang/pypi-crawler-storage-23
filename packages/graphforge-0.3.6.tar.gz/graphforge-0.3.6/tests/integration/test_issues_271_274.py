"""Regression tests verifying issues #271 and #274 are resolved."""

import pytest

from graphforge import GraphForge
from graphforge.types.values import CypherBool, CypherDate, CypherDateTime, CypherDuration


@pytest.mark.integration
class TestIssue271DurationFixes:
    """Issue #271: duration serialization, comparison, multiplication, fractional arithmetic."""

    # --- 1. Serialization with mixed-sign components ---

    def test_serialize_negative_seconds_positive_millis(self):
        """duration({seconds: -2, milliseconds: 1}) serializes as PT-1.999S."""
        gf = GraphForge()
        r = gf.execute("RETURN toString(duration({seconds: -2, milliseconds: 1})) AS s")
        assert r[0]["s"].value == "PT-1.999S"

    def test_serialize_positive_seconds_negative_millis(self):
        """duration({seconds: 2, milliseconds: -1}) serializes as PT1.999S."""
        gf = GraphForge()
        r = gf.execute("RETURN toString(duration({seconds: 2, milliseconds: -1})) AS s")
        assert r[0]["s"].value == "PT1.999S"

    def test_serialize_positive_days_negative_millis(self):
        """duration({days: 1, milliseconds: -1}) serializes as P1DT-0.001S."""
        gf = GraphForge()
        r = gf.execute("RETURN toString(duration({days: 1, milliseconds: -1})) AS s")
        assert r[0]["s"].value == "P1DT-0.001S"

    # --- 2. Cross-type equality ---

    def test_duration_not_equal_to_date(self):
        """duration({years: 12}) = date('1984-10-11') must return false (cross-type)."""
        gf = GraphForge()
        r = gf.execute("RETURN duration({years: 12}) = date('1984-10-11') AS eq")
        assert isinstance(r[0]["eq"], CypherBool)
        assert r[0]["eq"].value is False

    # --- 3. Multiplication ---

    def test_duration_multiply_integer(self):
        """duration * integer returns scaled duration."""
        gf = GraphForge()
        r = gf.execute("RETURN duration({years: 1}) * 2 AS d")
        assert isinstance(r[0]["d"], CypherDuration)
        assert r[0]["d"]._components[0] == 2  # 2 years

    def test_duration_multiply_float(self):
        """duration * float returns fractionally scaled duration."""
        gf = GraphForge()
        r = gf.execute("RETURN duration({months: 4}) * 1.5 AS d")
        assert isinstance(r[0]["d"], CypherDuration)
        assert r[0]["d"]._components[1] == 6  # 4 * 1.5 = 6 months

    # --- 4. Fractional arithmetic ---

    def test_fractional_months_in_constructor(self):
        """duration({years: 1, months: 1.5}) fractional months cascade to time."""
        gf = GraphForge()
        r = gf.execute("RETURN duration({years: 1, months: 1.5}) AS d")
        assert isinstance(r[0]["d"], CypherDuration)
        # 1 whole month, 0.5 month cascades to ~15.2 days
        assert r[0]["d"]._components[0] == 1  # 1 year
        assert r[0]["d"]._components[1] == 1  # 1 whole month


@pytest.mark.integration
class TestIssue274DatetimeCoercionAndLabel:
    """Issue #274: datetime() type coercion and :E label parser ambiguity."""

    # --- 1. datetime() type coercion ---

    def test_datetime_from_datetime(self):
        """datetime(datetime_value) returns the same datetime."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime(datetime('2020-01-01T12:00:00Z')) AS d")
        assert isinstance(r[0]["d"], CypherDateTime)
        assert r[0]["d"].value.isoformat() == "2020-01-01T12:00:00+00:00"

    def test_localdatetime_from_datetime(self):
        """localdatetime(datetime_value) strips the timezone."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime(datetime('2020-01-01T12:00:00Z')) AS d")
        assert isinstance(r[0]["d"], CypherDateTime)
        assert r[0]["d"].value.tzinfo is None
        assert r[0]["d"].value.isoformat() == "2020-01-01T12:00:00"

    def test_datetime_from_localdatetime(self):
        """datetime(localdatetime_value) adds UTC timezone."""
        gf = GraphForge()
        r = gf.execute("RETURN datetime(localdatetime('2020-01-01T12:00:00')) AS d")
        assert isinstance(r[0]["d"], CypherDateTime)
        assert r[0]["d"].value.tzinfo is not None

    def test_localdatetime_from_localdatetime(self):
        """localdatetime(localdatetime_value) returns the same localdatetime."""
        gf = GraphForge()
        r = gf.execute("RETURN localdatetime(localdatetime('2020-01-01T12:00:00')) AS d")
        assert isinstance(r[0]["d"], CypherDateTime)
        assert r[0]["d"].value.tzinfo is None
        assert r[0]["d"].value.isoformat() == "2020-01-01T12:00:00"

    # --- 2. :E label parser ambiguity ---

    def test_label_e_not_parsed_as_exponent(self):
        """Nodes with label :E can be created and queried without parser error."""
        gf = GraphForge()
        gf.execute("CREATE (:E {value: 42})")
        r = gf.execute("MATCH (n:E) RETURN n.value AS v")
        assert len(r) == 1
        assert r[0]["v"].value == 42

    def test_label_e_with_temporal_property(self):
        """CREATE (:E {date: date(...)}) reproduces the exact scenario from issue #274."""
        gf = GraphForge()
        gf.execute("CREATE (:E {date: date({year: 1980, month: 10, day: 24})})")
        r = gf.execute("MATCH (n:E) RETURN n.date AS d ORDER BY n.date")
        assert len(r) == 1
        assert isinstance(r[0]["d"], CypherDate)
        assert r[0]["d"].value.isoformat() == "1980-10-24"
