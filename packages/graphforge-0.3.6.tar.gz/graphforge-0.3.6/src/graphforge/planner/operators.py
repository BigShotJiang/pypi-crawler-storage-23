"""Logical plan operators for query execution.

This module defines the operators used in logical query plans:
- ScanNodes: Scan nodes by label
- ExpandEdges: Traverse relationships
- OptionalExpandEdges: Optional relationship expansion (left outer join)
- Filter: Apply predicates
- Project: Select return items
- With: Pipeline boundary for query chaining
- Limit: Limit result rows
- Skip: Skip result rows
- Create: Create nodes and relationships
- Set: Update properties
- Remove: Remove properties and labels
- Delete: Delete nodes and relationships
- Merge: Create or match patterns
- Unwind: Expand lists into rows
- Union: Combine results from multiple queries
- Subquery: Nested query expressions (EXISTS, COUNT)
"""

from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


class AggregationHint(BaseModel):
    """Hint for incremental aggregation during traversal.

    Used by the optimizer to push aggregations into traversal operators
    for improved performance. Only safe for certain aggregation patterns.

    Attributes:
        func: Aggregation function name ("COUNT", "SUM", "MIN", "MAX")
        expr: Expression to aggregate (None for COUNT(*))
        group_by: List of variable names to group by
        result_var: Variable name to bind aggregation result to
    """

    func: str = Field(..., description="Aggregation function name")
    expr: Any | None = Field(default=None, description="Expression to aggregate")
    group_by: list[str] = Field(..., description="Variables to group by")
    result_var: str = Field(..., min_length=1, description="Result variable name")

    @field_validator("func")
    @classmethod
    def validate_func(cls, v: str) -> str:
        """Validate aggregation function."""
        valid_funcs = {"COUNT", "SUM", "MIN", "MAX"}
        v_upper = v.upper()
        if v_upper not in valid_funcs:
            raise ValueError(f"Function must be one of {valid_funcs}, got {v}")
        return v_upper

    @field_validator("result_var")
    @classmethod
    def validate_result_var(cls, v: str) -> str:
        """Validate result variable name."""
        if not v[0].isalpha() and v[0] != "_":
            raise ValueError(f"Variable must start with letter or underscore: {v}")
        return v

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class ScanNodes(BaseModel):
    """Operator for scanning nodes.

    Scans all nodes or filters by labels.

    Attributes:
        variable: Variable name to bind nodes to
        labels: Optional list of label groups (disjunction of conjunctions)
               Example: [['Person']] - must have 'Person'
               Example: [['Person', 'Employee']] - must have both
               Example: [['Person'], ['Company']] - must have Person OR Company
        path_var: Variable name to bind single-node path to (None if not needed)
        predicate: WHERE predicate expression to filter nodes (None if not specified)
    """

    variable: str = Field(..., min_length=1, description="Variable name to bind nodes")
    labels: list[list[str]] | None = Field(
        default=None, description="Optional label filter (disjunction of conjunctions)"
    )
    path_var: str | None = Field(default=None, description="Path variable name")
    predicate: Any | None = Field(
        default=None, description="WHERE predicate expression to filter nodes"
    )

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        """Validate variable name."""
        if not v[0].isalpha() and v[0] != "_":
            raise ValueError(f"Variable must start with letter or underscore: {v}")
        return v

    model_config = {"frozen": True}


class OptionalScanNodes(BaseModel):
    """Operator for scanning nodes with OPTIONAL semantics.

    Like ScanNodes but preserves input rows with NULL binding when no nodes match.
    Used for single-node OPTIONAL MATCH patterns.

    Attributes:
        variable: Variable name to bind nodes to
        labels: Optional list of label groups (disjunction of conjunctions)
        path_var: Variable name to bind single-node path to (None if not needed)
    """

    variable: str = Field(..., min_length=1, description="Variable name to bind nodes")
    labels: list[list[str]] | None = Field(
        default=None, description="Optional label filter (disjunction of conjunctions)"
    )
    path_var: str | None = Field(default=None, description="Path variable name")

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        """Validate variable name."""
        if not v[0].isalpha() and v[0] != "_":
            raise ValueError(f"Variable must start with letter or underscore: {v}")
        return v

    model_config = {"frozen": True}


class ExpandEdges(BaseModel):
    """Operator for expanding (traversing) relationships.

    Follows relationships from source nodes to destination nodes.

    Attributes:
        src_var: Variable name for source nodes
        edge_var: Variable name to bind edges to
        dst_var: Variable name to bind destination nodes to
        path_var: Variable name to bind full path to (None if not needed)
        edge_types: List of edge types to match
        direction: Direction to traverse ('OUT', 'IN', 'UNDIRECTED')
        predicate: WHERE predicate expression to filter edges (None if not specified)
        agg_hint: Optional hint for incremental aggregation during traversal
    """

    src_var: str = Field(..., min_length=1, description="Source variable name")
    edge_var: str | None = Field(default=None, description="Edge variable name")
    dst_var: str = Field(..., min_length=1, description="Destination variable name")
    path_var: str | None = Field(default=None, description="Path variable name")
    edge_types: list[str] = Field(..., description="Edge types to match")
    direction: str = Field(..., description="Traversal direction")
    predicate: Any | None = Field(
        default=None, description="WHERE predicate expression to filter edges"
    )
    agg_hint: AggregationHint | None = Field(
        default=None, description="Optional hint for incremental aggregation"
    )

    @field_validator("direction")
    @classmethod
    def validate_direction(cls, v: str) -> str:
        """Validate direction is valid."""
        valid_dirs = {"OUT", "IN", "UNDIRECTED"}
        if v not in valid_dirs:
            raise ValueError(f"Direction must be one of {valid_dirs}, got {v}")
        return v

    model_config = {"frozen": True}


class ExpandVariableLength(BaseModel):
    """Operator for variable-length path expansion.

    Performs recursive traversal to find paths of varying lengths.

    Attributes:
        src_var: Variable name for source nodes
        edge_var: Variable name to bind edge list to (None for anonymous)
        dst_var: Variable name to bind destination nodes to
        path_var: Variable name to bind full path to (None if not needed)
        edge_types: List of edge types to match
        direction: Direction to traverse ('OUT', 'IN', 'UNDIRECTED')
        min_hops: Minimum number of hops (1 by default)
        max_hops: Maximum number of hops (None for unbounded)
        predicate: WHERE predicate expression to filter edges (None if not specified)
        agg_hint: Optional hint for incremental aggregation during traversal
    """

    src_var: str = Field(..., min_length=1, description="Source variable name")
    edge_var: str | None = Field(default=None, description="Edge variable name for list")
    dst_var: str = Field(..., min_length=1, description="Destination variable name")
    path_var: str | None = Field(default=None, description="Path variable name")
    edge_types: list[str] = Field(..., description="Edge types to match")
    direction: str = Field(..., description="Traversal direction")
    min_hops: int = Field(default=1, description="Minimum hops")
    max_hops: int | None = Field(default=None, description="Maximum hops (None=unbounded)")
    predicate: Any | None = Field(
        default=None, description="WHERE predicate expression to filter edges"
    )
    agg_hint: AggregationHint | None = Field(
        default=None, description="Optional hint for incremental aggregation"
    )

    @field_validator("direction")
    @classmethod
    def validate_direction(cls, v: str) -> str:
        """Validate direction is valid."""
        valid_dirs = {"OUT", "IN", "UNDIRECTED"}
        if v not in valid_dirs:
            raise ValueError(f"Direction must be one of {valid_dirs}, got {v}")
        return v

    @field_validator("min_hops")
    @classmethod
    def validate_min_hops(cls, v: int) -> int:
        """Validate minimum hops."""
        if v < 0:
            raise ValueError(f"Minimum hops must be non-negative, got {v}")
        return v

    @field_validator("max_hops")
    @classmethod
    def validate_max_hops(cls, v: int | None) -> int | None:
        """Validate maximum hops."""
        if v is not None and v < 0:
            raise ValueError(f"Maximum hops must be non-negative, got {v}")
        return v

    @model_validator(mode="after")
    def validate_hop_range(self) -> "ExpandVariableLength":
        """Validate that max_hops >= min_hops when both are specified."""
        if self.max_hops is not None and self.max_hops < self.min_hops:
            raise ValueError(
                f"Maximum hops ({self.max_hops}) must be >= minimum hops ({self.min_hops})"
            )
        return self

    model_config = {"frozen": True}


class ExpandMultiHop(BaseModel):
    """Operator for multi-hop fixed-length path expansion.

    Traverses a chain of relationships with specific types in sequence.
    Used for patterns like: (a)-[:R1]->(b)-[:R2]->(c)-[:R3]->(d)

    Attributes:
        src_var: Variable name for source node
        hops: List of (edge_var, edge_types, direction, dst_var) tuples for each hop
        path_var: Variable name to bind full path to (None if not needed)
    """

    src_var: str = Field(..., min_length=1, description="Source variable name")
    hops: list[tuple[str | None, list[str], str, str]] = Field(
        ..., min_length=1, description="List of (edge_var, edge_types, direction, dst_var)"
    )
    path_var: str | None = Field(default=None, description="Path variable name")

    @field_validator("hops")
    @classmethod
    def validate_hops(
        cls, v: list[tuple[str | None, list[str], str, str]]
    ) -> list[tuple[str | None, list[str], str, str]]:
        """Validate hop specifications."""
        for i, hop in enumerate(v):
            if not isinstance(hop, tuple) or len(hop) != 4:
                raise ValueError(
                    f"Hop {i} must be tuple of "
                    f"(edge_var, edge_types, direction, dst_var), got {hop}"
                )
            _edge_var, _edge_types, direction, _dst_var = hop
            # Validate direction
            valid_dirs = {"OUT", "IN", "UNDIRECTED"}
            if direction not in valid_dirs:
                raise ValueError(f"Hop {i} direction must be one of {valid_dirs}, got {direction}")
        return v

    model_config = {"frozen": True}


class Filter(BaseModel):
    """Operator for filtering rows based on a predicate.

    Evaluates a boolean expression and keeps only rows where it's true.

    Attributes:
        predicate: Expression AST node to evaluate
    """

    predicate: Any = Field(..., description="Filter predicate expression")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Project(BaseModel):
    """Operator for projecting (selecting) return items.

    Evaluates expressions and returns specified columns with optional aliases.

    Attributes:
        items: List of ReturnItem AST nodes (expression + optional alias)
    """

    items: list[Any] = Field(..., min_length=1, description="List of ReturnItems")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Limit(BaseModel):
    """Operator for limiting the number of result rows.

    Attributes:
        count: Maximum number of rows to return
    """

    count: int = Field(..., ge=0, description="Maximum number of rows")

    model_config = {"frozen": True}


class Skip(BaseModel):
    """Operator for skipping result rows.

    Attributes:
        count: Number of rows to skip
    """

    count: int = Field(..., ge=0, description="Number of rows to skip")

    model_config = {"frozen": True}


class Sort(BaseModel):
    """Operator for sorting result rows.

    Sorts rows by one or more expressions with specified directions.
    Can reference RETURN aliases if return_items is provided.

    Attributes:
        items: List of OrderByItem AST nodes (expression + ascending flag)
        return_items: Optional list of ReturnItem AST nodes for alias resolution
    """

    items: list[Any] = Field(..., min_length=1, description="List of OrderByItems")
    return_items: list[Any] | None = Field(
        default=None, description="Optional ReturnItems for alias resolution"
    )

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Aggregate(BaseModel):
    """Operator for aggregating rows.

    Groups rows by grouping expressions and computes aggregation functions.

    Attributes:
        grouping_exprs: List of expressions to group by (non-aggregated RETURN items)
        agg_exprs: List of aggregation function calls (FunctionCall nodes)
        return_items: All ReturnItems from RETURN clause (for result projection)
    """

    grouping_exprs: list[Any] = Field(..., description="Grouping expressions")
    agg_exprs: list[Any] = Field(..., description="Aggregation functions")
    return_items: list[Any] = Field(..., min_length=1, description="All ReturnItems")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class With(BaseModel):
    """Operator for WITH clause (query chaining and subqueries).

    Acts as a pipeline boundary between query parts. Projects columns
    (like RETURN) and optionally filters, sorts, and paginates.

    The WITH clause allows chaining multiple query parts together:
        MATCH (n) WITH n ORDER BY n.age LIMIT 10 MATCH (n)-[r]->(m) RETURN n, m

    Attributes:
        items: List of ReturnItem AST nodes (expressions to project)
        distinct: True for WITH DISTINCT (deduplication)
        predicate: Optional filter predicate (WHERE after WITH)
        sort_items: Optional list of OrderByItem AST nodes
        skip_count: Optional number of rows to skip
        limit_count: Optional maximum number of rows
    """

    items: list[Any] = Field(..., min_length=1, description="List of ReturnItems")
    distinct: bool = Field(default=False, description="True for WITH DISTINCT")
    predicate: Any | None = Field(default=None, description="Optional WHERE expression")
    sort_items: list[Any] | None = Field(default=None, description="Optional OrderByItem list")
    skip_count: int | None = Field(default=None, ge=0, description="Optional SKIP count")
    limit_count: int | None = Field(default=None, gt=0, description="Optional LIMIT count")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Distinct(BaseModel):
    """Operator for deduplication.

    Removes duplicate rows from input by comparing all bound variables.
    Used to implement RETURN DISTINCT and WITH DISTINCT.
    """

    model_config = {"frozen": True}


class Create(BaseModel):
    """Operator for creating graph elements.

    Creates nodes and relationships from patterns.

    Attributes:
        patterns: List of patterns to create (from CREATE clause)
    """

    patterns: list[Any] = Field(..., min_length=1, description="Patterns to create")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Set(BaseModel):
    """Operator for updating properties.

    Updates properties on nodes and relationships.

    Attributes:
        items: List of (property_access, expression) tuples
    """

    items: list[tuple[Any, Any]] = Field(
        ..., min_length=1, description="List of (property, expression) tuples"
    )

    @field_validator("items")
    @classmethod
    def validate_items(cls, v: list[tuple[Any, Any]]) -> list[tuple[Any, Any]]:
        """Validate SET items format."""
        for i, item in enumerate(v):
            if not isinstance(item, tuple) or len(item) != 2:
                raise ValueError(
                    f"SET item {i} must be a tuple of (property_access, expression), got {item}"
                )
        return v

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Remove(BaseModel):
    """Operator for removing properties and labels.

    Removes properties from nodes/relationships or labels from nodes.

    Attributes:
        items: List of RemoveItem objects (from AST)
    """

    items: list[Any] = Field(..., min_length=1, description="List of RemoveItems")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Delete(BaseModel):
    """Operator for deleting graph elements.

    Removes nodes and relationships from the graph.

    Attributes:
        variables: List of variable names to delete
        detach: If True, delete relationships before deleting nodes (DETACH DELETE)
    """

    variables: list[str] = Field(..., min_length=1, description="Variables to delete")
    detach: bool = Field(default=False, description="True for DETACH DELETE")

    model_config = {"frozen": True}


class Merge(BaseModel):
    """Operator for merging patterns with conditional SET support.

    Creates patterns if they don't exist, or matches them if they do.
    Optionally executes SET operations when creating (ON CREATE SET) or
    matching (ON MATCH SET).

    Attributes:
        patterns: List of patterns to merge
        on_create: Optional SetClause to execute when creating new elements
        on_match: Optional SetClause to execute when matching existing elements
    """

    patterns: list[Any] = Field(..., min_length=1, description="Patterns to merge")
    on_create: Any = Field(default=None, description="Optional SetClause for ON CREATE SET")
    on_match: Any = Field(default=None, description="Optional SetClause for ON MATCH SET")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Unwind(BaseModel):
    """Operator for expanding lists into rows.

    Takes a list expression and expands it into multiple rows, binding each
    element to a variable. Similar to SQL UNNEST or array unnesting.

    Example:
        UNWIND [1, 2, 3] AS num
        -> Creates 3 rows with num=1, num=2, num=3

    Attributes:
        expression: Expression that evaluates to a list
        variable: Variable name to bind each list element to
    """

    expression: Any = Field(..., description="Expression that evaluates to a list")
    variable: str = Field(..., min_length=1, description="Variable name for each element")

    @field_validator("variable")
    @classmethod
    def validate_variable(cls, v: str) -> str:
        """Validate variable name."""
        if not v[0].isalpha() and v[0] != "_":
            raise ValueError(f"Variable must start with letter or underscore: {v}")
        return v

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Union(BaseModel):
    """Operator for UNION/UNION ALL query combination.

    Combines results from multiple query branches. Each branch is a complete
    execution pipeline (list of operators).

    Example:
        MATCH (p:Person) RETURN p.name
        UNION
        MATCH (c:Company) RETURN c.name

    Attributes:
        branches: List of operator pipelines (each branch is a list of operators)
        all: False for UNION (deduplicate), True for UNION ALL (keep duplicates)
    """

    branches: list[list[Any]] = Field(..., min_length=2, description="List of operator pipelines")
    all: bool = Field(default=False, description="True for UNION ALL, False for UNION")

    @field_validator("branches")
    @classmethod
    def validate_branches(cls, v: list[list[Any]]) -> list[list[Any]]:
        """Validate that we have at least 2 branches."""
        if len(v) < 2:
            raise ValueError("Union must have at least 2 branches")
        return v

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Call(BaseModel):
    """Operator for CALL { } subqueries.

    Executes a nested query pipeline and returns rows with combined bindings from
    outer and inner scopes (correlated subquery).

    Example:
        MATCH (p:Person)
        CALL { MATCH (p)-[:KNOWS]->(f) RETURN f }
        RETURN p.name, f.name

    Attributes:
        operators: List of operators in the subquery pipeline
    """

    operators: list[Any] = Field(..., min_length=1, description="Nested query pipeline")

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class Subquery(BaseModel):
    """Operator for subquery expressions (EXISTS, COUNT, etc.).

    Executes a nested query pipeline and returns a result for use in expressions.

    Example:
        WHERE EXISTS { MATCH (n)-[:KNOWS]->(m) WHERE m.age > 30 }

    Attributes:
        operators: List of operators in the subquery pipeline
        expression_type: Type of subquery expression ("EXISTS", "COUNT")
        correlated_vars: Variables from outer scope that the subquery references
    """

    operators: list[Any] = Field(..., min_length=1, description="Subquery pipeline")
    expression_type: str = Field(..., description="Subquery type (EXISTS, COUNT)")
    correlated_vars: list[str] = Field(
        default_factory=list, description="Variables from outer scope"
    )

    @field_validator("expression_type")
    @classmethod
    def validate_expression_type(cls, v: str) -> str:
        """Validate expression type."""
        valid_types = {"EXISTS", "COUNT"}
        if v not in valid_types:
            raise ValueError(f"Subquery expression type must be one of {valid_types}, got {v}")
        return v

    model_config = {"frozen": True, "arbitrary_types_allowed": True}


class OptionalExpandEdges(BaseModel):
    """Operator for optional relationship expansion (left outer join).

    Like ExpandEdges, but preserves rows with NULL bindings when no matches found.
    Used to implement OPTIONAL MATCH.

    Example:
        MATCH (p:Person)
        OPTIONAL MATCH (p)-[:KNOWS]->(f)
        -> If p has no KNOWS edges, returns (p, f=NULL)

    Attributes:
        src_var: Variable name for source nodes
        edge_var: Variable name to bind edges to (None if not specified)
        dst_var: Variable name to bind destination nodes to
        edge_types: List of edge types to match (empty = all types)
        direction: Direction to traverse ('OUT', 'IN', 'UNDIRECTED')
    """

    src_var: str = Field(..., min_length=1, description="Source variable name")
    edge_var: str | None = Field(default=None, description="Edge variable name")
    dst_var: str = Field(..., min_length=1, description="Destination variable name")
    edge_types: list[str] = Field(..., description="Edge types to match")
    direction: str = Field(..., description="Traversal direction")

    @field_validator("direction")
    @classmethod
    def validate_direction(cls, v: str) -> str:
        """Validate direction is valid."""
        valid_dirs = {"OUT", "IN", "UNDIRECTED"}
        if v not in valid_dirs:
            raise ValueError(f"Direction must be one of {valid_dirs}, got {v}")
        return v

    model_config = {"frozen": True}
