"""Runtime value types for openCypher.

This module implements the openCypher type system including:
- Scalar types: NULL, BOOLEAN, INTEGER, FLOAT, STRING
- Temporal types: DATE, DATETIME, TIME, DURATION
- Collection types: LIST, MAP, PATH

Values follow openCypher semantics including:
- NULL propagation in comparisons and operations
- Type-aware equality and comparison
- Conversion to/from Python types
"""

import datetime
from enum import Enum
import re
from typing import TYPE_CHECKING, Any

from dateutil import parser as dateutil_parser
from dateutil import tz as dateutil_tz
import isodate  # type: ignore[import-untyped]

if TYPE_CHECKING:
    from graphforge.types.graph import EdgeRef, NodeRef


class CypherType(Enum):
    """openCypher value types."""

    NULL = "NULL"
    BOOLEAN = "BOOLEAN"
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    STRING = "STRING"
    DATE = "DATE"
    DATETIME = "DATETIME"
    TIME = "TIME"
    DURATION = "DURATION"
    POINT = "POINT"
    DISTANCE = "DISTANCE"
    LIST = "LIST"
    MAP = "MAP"
    PATH = "PATH"


class CypherValue:
    """Base class for all openCypher values.

    All comparison operations follow openCypher semantics:
    - NULL in any operation propagates NULL
    - Type-aware comparisons
    """

    def __init__(self, value: Any, cypher_type: CypherType):
        self.value = value
        self.type = cypher_type

    def equals(self, other: "CypherValue") -> "CypherValue":
        """Check equality following openCypher semantics.

        Returns:
            CypherBool(True) if equal
            CypherBool(False) if not equal
            CypherNull if either operand is NULL
        """
        # NULL propagation
        if isinstance(self, CypherNull) or isinstance(other, CypherNull):
            return CypherNull()

        # Numeric types can be compared across int/float
        if self._is_numeric() and other._is_numeric():
            return CypherBool(self.value == other.value)

        # Same type comparison
        if self.type == other.type:
            if self.type in (CypherType.LIST, CypherType.MAP, CypherType.PATH):
                return self._deep_equals(other)
            return CypherBool(self.value == other.value)

        # Different types are not equal
        return CypherBool(False)

    def less_than(self, other: "CypherValue") -> "CypherValue":
        """Check if this value is less than another.

        Returns:
            CypherBool(True/False) for comparable types
            CypherNull if either operand is NULL
        """
        # NULL propagation
        if isinstance(self, CypherNull) or isinstance(other, CypherNull):
            return CypherNull()

        # Numeric comparison
        if self._is_numeric() and other._is_numeric():
            return CypherBool(self.value < other.value)

        # String comparison
        if self.type == CypherType.STRING and other.type == CypherType.STRING:
            return CypherBool(self.value < other.value)

        # Boolean comparison (False < True)
        if self.type == CypherType.BOOLEAN and other.type == CypherType.BOOLEAN:
            return CypherBool(self.value < other.value)

        # List comparison (lexicographic)
        if self.type == CypherType.LIST and other.type == CypherType.LIST:
            for a, b in zip(self.value, other.value):
                a_lt_b = a.less_than(b)
                if isinstance(a_lt_b, CypherNull):
                    return CypherNull()
                if a_lt_b.value:
                    return CypherBool(True)
                b_lt_a = b.less_than(a)
                if isinstance(b_lt_a, CypherNull):
                    return CypherNull()
                if b_lt_a.value:
                    return CypherBool(False)
            # All elements equal so far, shorter list is less
            return CypherBool(len(self.value) < len(other.value))

        # Temporal comparison (DATE, DATETIME, TIME, DURATION)
        if self._is_temporal() and other._is_temporal():
            # Only allow comparison of same temporal types
            if self.type == other.type:
                return CypherBool(self.value < other.value)
            return CypherBool(False)

        # Other comparisons are not supported in this simplified model
        return CypherBool(False)

    def _is_numeric(self) -> bool:
        """Check if this value is a numeric type."""
        return self.type in (CypherType.INTEGER, CypherType.FLOAT)

    def _is_temporal(self) -> bool:
        """Check if this value is a temporal type."""
        return self.type in (
            CypherType.DATE,
            CypherType.DATETIME,
            CypherType.TIME,
            CypherType.DURATION,
        )

    def _deep_equals(self, other: "CypherValue") -> "CypherValue":
        """Deep equality check for collections."""
        if self.type == CypherType.LIST:
            if len(self.value) != len(other.value):
                return CypherBool(False)
            for a, b in zip(self.value, other.value):
                result = a.equals(b)
                if isinstance(result, CypherNull):
                    return CypherNull()
                if not result.value:
                    return CypherBool(False)
            return CypherBool(True)

        if self.type == CypherType.MAP:
            if set(self.value.keys()) != set(other.value.keys()):
                return CypherBool(False)
            for key in self.value:
                result = self.value[key].equals(other.value[key])
                if isinstance(result, CypherNull):
                    return CypherNull()
                if not result.value:
                    return CypherBool(False)
            return CypherBool(True)

        if self.type == CypherType.PATH:
            # Path equality: same nodes and relationships in same order
            # Cast to CypherPath for type safety
            if not isinstance(other, CypherPath):
                return CypherBool(False)
            self_path = self if isinstance(self, CypherPath) else None
            other_path = other if isinstance(other, CypherPath) else None
            if self_path is None or other_path is None:
                return CypherBool(False)

            # Compare lengths first
            if len(self_path.nodes) != len(other_path.nodes):
                return CypherBool(False)

            # Compare node IDs (identity-based)
            for n1, n2 in zip(self_path.nodes, other_path.nodes):
                if n1.id != n2.id:
                    return CypherBool(False)

            # Compare relationship IDs (identity-based)
            for r1, r2 in zip(self_path.relationships, other_path.relationships):
                if r1.id != r2.id:
                    return CypherBool(False)

            return CypherBool(True)

        return CypherBool(False)

    def to_python(self) -> Any:
        """Convert this Cypher value to a Python value."""
        if self.type == CypherType.NULL:
            return None
        if self.type == CypherType.LIST:
            return [item.to_python() for item in self.value]
        if self.type == CypherType.MAP:
            return {key: val.to_python() for key, val in self.value.items()}
        if self.type == CypherType.PATH:
            # Return dict with nodes and relationships
            if isinstance(self, CypherPath):
                return {"nodes": self.nodes, "relationships": self.relationships}
            return self.value
        # Temporal types already store Python datetime/timedelta objects
        return self.value

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.value!r})"


class CypherNull(CypherValue):
    """Represents NULL in openCypher."""

    def __init__(self):
        super().__init__(None, CypherType.NULL)


class CypherBool(CypherValue):
    """Represents a boolean value in openCypher."""

    def __init__(self, value: bool):
        super().__init__(value, CypherType.BOOLEAN)


class CypherInt(CypherValue):
    """Represents an integer value in openCypher."""

    def __init__(self, value: int):
        super().__init__(value, CypherType.INTEGER)


class CypherFloat(CypherValue):
    """Represents a floating-point value in openCypher."""

    def __init__(self, value: float):
        super().__init__(value, CypherType.FLOAT)


class CypherString(CypherValue):
    """Represents a string value in openCypher."""

    def __init__(self, value: str):
        super().__init__(value, CypherType.STRING)


def _parse_iso_date_part(s: str) -> datetime.date:
    """Parse a (possibly compact) ISO 8601 date string to datetime.date.

    Handles all openCypher date string formats including compact variants
    not supported by dateutil: ordinal (YYYYDDD), week (YYYYWww[D]),
    year-month (YYYYMM), and year-only (YYYY).
    """
    # Standard extended form YYYY-MM-DD or basic 8-digit YYYYMMDD — let dateutil handle
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s) or re.match(r"^\d{8}$", s):
        return dateutil_parser.parse(s).date()

    # Year-only: YYYY
    if re.match(r"^\d{4}$", s):
        return datetime.date(int(s), 1, 1)

    # Year-month with separator: YYYY-MM
    m = re.match(r"^(\d{4})-(\d{2})$", s)
    if m:
        return datetime.date(int(m.group(1)), int(m.group(2)), 1)

    # Year-month compact: YYYYMM (exactly 6 digits)
    m = re.match(r"^(\d{4})(\d{2})$", s)
    if m:
        return datetime.date(int(m.group(1)), int(m.group(2)), 1)

    # Ordinal with separator: YYYY-DDD
    m = re.match(r"^(\d{4})-(\d{3})$", s)
    if m:
        year, ordinal = int(m.group(1)), int(m.group(2))
        max_ordinal = 366 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 365
        if ordinal < 1 or ordinal > max_ordinal:
            raise ValueError(f"ordinal {ordinal} is out of range for year {year} (1-{max_ordinal})")
        return datetime.date(year, 1, 1) + datetime.timedelta(days=ordinal - 1)

    # Ordinal compact: YYYYDDD (exactly 7 digits)
    m = re.match(r"^(\d{4})(\d{3})$", s)
    if m:
        year, ordinal = int(m.group(1)), int(m.group(2))
        max_ordinal = 366 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 365
        if ordinal < 1 or ordinal > max_ordinal:
            raise ValueError(f"ordinal {ordinal} is out of range for year {year} (1-{max_ordinal})")
        return datetime.date(year, 1, 1) + datetime.timedelta(days=ordinal - 1)

    # Week date with separators and day: YYYY-Www-D
    m = re.match(r"^(\d{4})-W(\d{2})-(\d)$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    # Week date compact with day: YYYYWwwD
    m = re.match(r"^(\d{4})W(\d{2})(\d)$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    # Week date with separator, no day: YYYY-Www → Monday of that week
    m = re.match(r"^(\d{4})-W(\d{2})$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)

    # Week date compact, no day: YYYYWww → Monday of that week
    m = re.match(r"^(\d{4})W(\d{2})$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)

    # Fall back to dateutil for anything else
    return dateutil_parser.parse(s).date()


def _normalize_compact_time(t: str) -> str:
    """Expand a compact ISO 8601 time string to HH:MM:SS[.fff][tz] form.

    Handles: HH, HHMM, HHMMSS, HHMMSS.fff (with optional trailing timezone).
    Strings already containing ':' are returned unchanged.
    """
    # Extract trailing timezone: Z, +HH:MM, +HHMM, -HH, etc.
    tz_match = re.search(r"([+-]\d{2}:?\d{2}|[+-]\d{2}|Z)$", t)
    tz = tz_match.group(0) if tz_match else ""
    if tz_match is not None:
        t = t[: tz_match.start()]

    # Normalize compact offsets: +HHMM → +HH:MM, +HH → +HH:00
    if tz and tz != "Z":
        off_m = re.match(r"^([+-])(\d{2})(\d{2})?$", tz)
        if off_m:
            tz = f"{off_m.group(1)}{off_m.group(2)}:{off_m.group(3) or '00'}"

    # If already colon-separated, leave the time digits alone
    if ":" in t:
        return t + tz

    # Split fractional seconds
    frac = ""
    if "." in t:
        t, frac_part = t.split(".", 1)
        frac = "." + frac_part

    if len(t) == 2:  # HH
        return f"{t}:00:00{frac}{tz}"
    if len(t) == 4:  # HHMM
        return f"{t[:2]}:{t[2:4]}:00{frac}{tz}"
    if len(t) == 6:  # HHMMSS
        return f"{t[:2]}:{t[2:4]}:{t[4:6]}{frac}{tz}"
    raise ValueError(f"unsupported compact time length {len(t)} for input: {t!r}")


class CypherDate(CypherValue):
    """Represents a date value in openCypher.

    Stores a Python datetime.date object. Supports ISO 8601 date strings.
    """

    def __init__(self, value: datetime.date | str):
        if isinstance(value, str):
            value = _parse_iso_date_part(value)
        elif isinstance(value, datetime.datetime):
            # Extract date component if datetime passed
            value = value.date()
        super().__init__(value, CypherType.DATE)

    def __repr__(self) -> str:
        return f"CypherDate({self.value.isoformat()!r})"


class CypherDateTime(CypherValue):
    """Represents a datetime value in openCypher.

    Stores a Python datetime.datetime object with timezone support.
    Supports ISO 8601 datetime strings including compact variants.
    """

    def __init__(self, value: datetime.datetime | str):
        if isinstance(value, str):
            # Strip optional IANA timezone name suffix: e.g. [Europe/Stockholm]
            iana_name: str | None = None
            iana_m = re.search(r"\[([A-Za-z][A-Za-z0-9/_+\-]*)\]$", value)
            if iana_m:
                iana_name = iana_m.group(1)
                value = value[: iana_m.start()]

            if "T" in value:
                date_str, time_str = value.split("T", 1)
                date_part = _parse_iso_date_part(date_str)

                if iana_name is not None:
                    # IANA zone is authoritative; strip any explicit offset so we can
                    # parse as a naive local time and then attach the named zone.
                    # Handles: Z, ±HH, ±HHMM, ±HH:MM, ±HH:MM:SS (e.g. +00:53:28)
                    time_local = re.sub(r"(?:[+-]\d{2}(?::?\d{2}(?::\d{2})?)?|Z)$", "", time_str)
                    normalized_time = (
                        _normalize_compact_time(time_local) if time_local else "00:00:00"
                    )
                else:
                    normalized_time = _normalize_compact_time(time_str)

                normalized = date_part.isoformat() + "T" + normalized_time
                value = dateutil_parser.parse(normalized)

                if iana_name is not None:
                    iana_tz = dateutil_tz.gettz(iana_name)
                    if iana_tz is None:
                        raise ValueError(f"Unknown IANA timezone: {iana_name!r}")
                    value = value.replace(tzinfo=iana_tz)
            else:
                value = dateutil_parser.parse(value)

        super().__init__(value, CypherType.DATETIME)

    def __repr__(self) -> str:
        return f"CypherDateTime({self.value.isoformat()!r})"


class CypherTime(CypherValue):
    """Represents a time value in openCypher.

    Stores a Python datetime.time object with timezone support.
    Supports ISO 8601 time strings.
    """

    def __init__(self, value: datetime.time | datetime.datetime | str):
        if isinstance(value, str):
            # Parse ISO 8601 time string
            parsed = dateutil_parser.parse(value)
            # Use timetz() to preserve timezone information
            value = parsed.timetz()
        elif isinstance(value, datetime.datetime):
            # Extract time component with timezone if datetime passed
            value = value.timetz()
        super().__init__(value, CypherType.TIME)

    def __repr__(self) -> str:
        return f"CypherTime({self.value.isoformat()!r})"


def _parse_neg_component_duration_str(s: str) -> "datetime.timedelta | isodate.Duration":
    """Parse ISO 8601 duration strings that have per-component negative signs.

    isodate only handles a leading overall sign (e.g. -PT1S).  openCypher uses
    per-component signs (e.g. PT-1S, P1DT-0.001S).  Returns a timedelta or
    isodate.Duration.
    """
    import math
    import re

    m = re.match(
        r"^(-?)P"
        r"(?:(-?\d+(?:\.\d+)?)Y)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)W)?"
        r"(?:(-?\d+(?:\.\d+)?)D)?"
        r"(?:T"
        r"(?:(-?\d+(?:\.\d+)?)H)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)S)?"
        r")?$",
        s,
    )
    if not m:
        raise ValueError(f"Unrecognised ISO 8601 duration format: {s!r}")
    overall_sign = -1 if m.group(1) == "-" else 1
    years = float(m.group(2) or 0) * overall_sign
    months = float(m.group(3) or 0) * overall_sign
    weeks = float(m.group(4) or 0) * overall_sign
    days = float(m.group(5) or 0) * overall_sign
    hours = float(m.group(6) or 0) * overall_sign
    minutes = float(m.group(7) or 0) * overall_sign
    seconds = float(m.group(8) or 0) * overall_sign
    years_i = math.trunc(years)
    months_i = math.trunc(months)
    if years_i != 0 or months_i != 0:
        # Fractional parts of years/months cascade into the time component,
        # using the same average-month/year convention as the map constructor.
        frac_years = years - years_i
        frac_months = months - months_i
        frac_seconds = (frac_years * 365.2425 + frac_months * (365.2425 / 12)) * 86400
        total_us = round(
            ((weeks * 7 + days) * 86400 + hours * 3600 + minutes * 60 + seconds + frac_seconds)
            * 1_000_000
        )
        td = datetime.timedelta(microseconds=total_us)
        return isodate.Duration(
            years=years_i,
            months=months_i,
            days=td.days,
            seconds=td.seconds,
            microseconds=td.microseconds,
        )
    total_us = round(
        ((weeks * 7 + days) * 86400 + hours * 3600 + minutes * 60 + seconds) * 1_000_000
    )
    return datetime.timedelta(microseconds=total_us)


def _trunc_div(total: int, unit: int) -> "tuple[int, int]":
    """Truncation-toward-zero division with remainder sharing the sign of total."""
    if total >= 0:
        return divmod(total, unit)
    q_abs, r_abs = divmod(-total, unit)
    return (-q_abs, 0) if r_abs == 0 else (-q_abs, -r_abs)


def _components_from_string(s: str) -> "tuple[int, int, int, int, int, int, int] | None":
    """Derive canonical components directly from an ISO 8601 duration string.

    Unlike _components_from_value, this preserves the days/time boundary as
    written in the string and handles per-component negative signs correctly
    (e.g. ``PT-59.999S`` → seconds=-59, us=-999000, NOT days=-1, hours=23…).
    Returns None if the string cannot be parsed.
    """
    import math
    import re

    m = re.match(
        r"^(-?)P"
        r"(?:(-?\d+(?:\.\d+)?)Y)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)W)?"
        r"(?:(-?\d+(?:\.\d+)?)D)?"
        r"(?:T"
        r"(?:(-?\d+(?:\.\d+)?)H)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)S)?"
        r")?$",
        s,
    )
    if not m:
        return None
    overall_sign = -1 if m.group(1) == "-" else 1
    years_f = float(m.group(2) or 0) * overall_sign
    months_f = float(m.group(3) or 0) * overall_sign
    weeks_f = float(m.group(4) or 0) * overall_sign
    days_f = float(m.group(5) or 0) * overall_sign
    hours_f = float(m.group(6) or 0) * overall_sign
    minutes_f = float(m.group(7) or 0) * overall_sign
    seconds_f = float(m.group(8) or 0) * overall_sign

    years_i = math.trunc(years_f)
    months_f += (years_f - years_i) * 12.0
    months_i = math.trunc(months_f)
    days_f += (months_f - months_i) * 30.436875 + weeks_f * 7.0
    days_i = math.trunc(days_f)

    # Time part: fractional days cascade into hours/minutes/seconds
    time_us = round(
        ((days_f - days_i) * 86_400 + hours_f * 3_600 + minutes_f * 60 + seconds_f) * 1_000_000
    )
    canon_h, rem_us = _trunc_div(time_us, 3_600_000_000)
    canon_m, rem_us = _trunc_div(rem_us, 60_000_000)
    canon_s, canon_us = _trunc_div(rem_us, 1_000_000)
    return (years_i, months_i, days_i, canon_h, canon_m, canon_s, canon_us)


def _components_from_value(
    value: "datetime.timedelta | isodate.Duration",
) -> tuple[int, int, int, int, int, int, int]:
    """Derive canonical (years, months, days, hours, minutes, seconds, microseconds)
    from a timedelta or isodate.Duration.

    The days/time boundary is preserved as stored in the timedelta.days field.
    Time is normalised within the time part (seconds→minutes→hours) but hours
    are NOT absorbed into days.  This matches openCypher equality semantics
    where 13D+40H != 14D+16H.
    """
    if isinstance(value, isodate.Duration):
        years = int(getattr(value, "years", 0) or 0)
        months = int(getattr(value, "months", 0) or 0)
        td = value.tdelta if hasattr(value, "tdelta") else datetime.timedelta()
    else:
        years = 0
        months = 0
        td = value
    # td.days: integer days (timedelta-normalised, so hours already absorbed)
    # td.seconds: 0-86399 — decompose into hours/minutes/seconds
    d = td.days
    s = td.seconds
    us = td.microseconds
    hours = s // 3600
    minutes = (s % 3600) // 60
    seconds = s % 60
    return (years, months, d, hours, minutes, seconds, us)


class CypherDuration(CypherValue):
    """Represents a duration value in openCypher.

    Stores a Python datetime.timedelta or isodate.Duration object.
    Supports ISO 8601 duration strings. When parsing ISO 8601 strings with
    years/months (e.g., "P1Y2M"), stores an isodate.Duration; otherwise stores
    a datetime.timedelta.

    The ``_components`` attribute holds (years, months, days, hours, minutes, seconds,
    microseconds) where ``days`` is NOT normalized from hours.  This is used for
    component-wise equality per the openCypher spec.
    """

    def __init__(
        self,
        value: "datetime.timedelta | isodate.Duration | str",
        _components: "tuple[int,int,int,int,int,int,int] | None" = None,
    ):
        if isinstance(value, str):
            # Parse ISO 8601 duration string.  isodate does not support per-component
            # negative signs (e.g. "P1DT-0.001S"), so we fall back to a manual parser.
            # Derive _components directly from the string to preserve the days/time
            # boundary and per-component signs (Python timedelta normalisation loses
            # these for negative durations like PT-59.999S).
            original_str = value
            if _components is None:
                _components = _components_from_string(original_str)
            try:
                value = isodate.parse_duration(value)
            except (ValueError, isodate.isoerror.ISO8601Error):
                value = _parse_neg_component_duration_str(value)
        super().__init__(value, CypherType.DURATION)
        # Store canonical components for equality.  Caller may supply them
        # explicitly to preserve the original days/hours boundary.
        self._components: tuple[int, int, int, int, int, int, int] = (
            _components if _components is not None else _components_from_value(value)
        )
        # When the canonical components have no years or months (e.g. "P0.75M"
        # normalises to days only) but the stored value is still an isodate.Duration
        # with fractional months, replace it with a plain timedelta so that
        # value-based comparisons (used by the TCK harness) return the right result.
        if (
            isinstance(self.value, isodate.Duration)
            and self._components[0] == 0  # years
            and self._components[1] == 0  # months
        ):
            _, _, d, h, m, s, us = self._components
            self.value = datetime.timedelta(days=d, hours=h, minutes=m, seconds=s, microseconds=us)

    def equals(self, other: "CypherValue") -> "CypherValue":
        """Duration equality is component-wise per openCypher spec.

        Two durations are equal only if all canonical components match:
        years, months, days, hours, minutes, seconds, microseconds.
        Unlike elapsed-time equality, 13D+40H != 14D+16H.
        """
        if isinstance(other, CypherNull):
            return CypherNull()
        if not isinstance(other, CypherDuration):
            return CypherBool(False)
        return CypherBool(self._components == other._components)

    def __repr__(self) -> str:
        return f"CypherDuration({isodate.duration_isoformat(self.value)!r})"


class CypherPoint(CypherValue):
    """Represents a point value in openCypher.

    Stores a dictionary with coordinate information. Supports:
    - 2D Cartesian: {"x": float, "y": float, "crs": "cartesian"}
    - 3D Cartesian: {"x": float, "y": float, "z": float, "crs": "cartesian-3d"}
    - WGS84 Geographic: {"latitude": float, "longitude": float, "crs": "wgs-84"}

    The coordinate reference system (crs) is optional and inferred from keys.
    """

    def __init__(self, coordinates: dict[str, float]):
        """Initialize a point from coordinate dictionary.

        Args:
            coordinates: Dict with coordinate keys (x/y or latitude/longitude)

        Raises:
            ValueError: If coordinates are invalid or incomplete
        """
        # Validate and normalize coordinates
        if "x" in coordinates and "y" in coordinates:
            # Cartesian coordinates
            x = float(coordinates["x"])
            y = float(coordinates["y"])
            if "z" in coordinates:
                # 3D Cartesian
                z = float(coordinates["z"])
                value = {"x": x, "y": y, "z": z, "crs": "cartesian-3d"}
            else:
                # 2D Cartesian
                value = {"x": x, "y": y, "crs": "cartesian"}
        elif "latitude" in coordinates and "longitude" in coordinates:
            # Geographic coordinates (WGS-84)
            lat = float(coordinates["latitude"])
            lon = float(coordinates["longitude"])
            # Validate latitude/longitude ranges
            if not -90 <= lat <= 90:
                raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
            if not -180 <= lon <= 180:
                raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
            value = {"latitude": lat, "longitude": lon, "crs": "wgs-84"}
        else:
            raise ValueError(
                "Point requires either (x, y) or (latitude, longitude) coordinates, "
                f"got: {list(coordinates.keys())}"
            )

        super().__init__(value, CypherType.POINT)

    def __repr__(self) -> str:
        return f"CypherPoint({self.value!r})"


class CypherDistance(CypherValue):
    """Represents a distance value in openCypher.

    Stores a float representing the Euclidean distance between two points.
    For WGS-84 points, uses the Haversine formula to compute great-circle distance.
    """

    def __init__(self, value: float):
        """Initialize a distance value.

        Args:
            value: Distance as a float (must be non-negative)

        Raises:
            ValueError: If distance is negative
        """
        if value < 0:
            raise ValueError(f"Distance must be non-negative, got {value}")
        super().__init__(float(value), CypherType.DISTANCE)

    def __repr__(self) -> str:
        return f"CypherDistance({self.value})"


class CypherList(CypherValue):
    """Represents a list value in openCypher."""

    def __init__(self, value: list["CypherValue"]):
        super().__init__(value, CypherType.LIST)


class CypherMap(CypherValue):
    """Represents a map (dictionary) value in openCypher."""

    def __init__(self, value: dict[str, "CypherValue"]):
        super().__init__(value, CypherType.MAP)


class CypherPath(CypherValue):
    """Represents a path through the graph.

    A path consists of an alternating sequence of nodes and relationships:
    node -> edge -> node -> edge -> node

    Attributes:
        nodes: List of NodeRef objects in the path (N nodes)
        relationships: List of EdgeRef objects connecting the nodes (N-1 relationships)

    The path structure ensures that:
    - len(relationships) == len(nodes) - 1
    - relationships[i] connects nodes[i] to nodes[i+1]

    Examples:
        >>> # Path with 3 nodes: A -> B -> C
        >>> path = CypherPath(
        ...     nodes=[node_a, node_b, node_c],
        ...     relationships=[edge_ab, edge_bc]
        ... )
        >>> path.length()  # Number of relationships
        2
        >>> len(path.nodes)
        3
    """

    def __init__(self, nodes: list["NodeRef"], relationships: list["EdgeRef"]):
        """Initialize a path from nodes and relationships.

        Args:
            nodes: List of NodeRef objects in the path
            relationships: List of EdgeRef objects connecting the nodes

        Raises:
            ValueError: If path structure is invalid
        """
        from graphforge.types.graph import EdgeRef, NodeRef

        # Validate types
        if not all(isinstance(n, NodeRef) for n in nodes):
            raise TypeError("All nodes must be NodeRef instances")
        if not all(isinstance(r, EdgeRef) for r in relationships):
            raise TypeError("All relationships must be EdgeRef instances")

        # Validate path structure
        if len(nodes) == 0:
            raise ValueError("Path must contain at least one node")
        if len(relationships) != len(nodes) - 1:
            raise ValueError(
                f"Path must have exactly len(nodes)-1 relationships: "
                f"got {len(nodes)} nodes and {len(relationships)} relationships"
            )

        # Validate connectivity
        for i, rel in enumerate(relationships):
            node_a = nodes[i]
            node_b = nodes[i + 1]
            # Check that relationship connects consecutive nodes
            # Allow traversal in either direction (for undirected or reversed patterns)
            forward_match = rel.src.id == node_a.id and rel.dst.id == node_b.id
            reverse_match = rel.src.id == node_b.id and rel.dst.id == node_a.id

            if not (forward_match or reverse_match):
                raise ValueError(
                    f"Relationship at index {i} does not connect nodes {i} and {i + 1}: "
                    f"relationship goes from {rel.src.id} to {rel.dst.id}, "
                    f"but path expects connection between {node_a.id} and {node_b.id}"
                )

        # Store as tuple for immutability
        self.nodes = nodes
        self.relationships = relationships

        # Store tuple of (nodes, relationships) as value for compatibility
        super().__init__((tuple(nodes), tuple(relationships)), CypherType.PATH)

    def length(self) -> int:
        """Return the length of the path (number of relationships)."""
        return len(self.relationships)

    def __repr__(self) -> str:
        """Readable string representation."""
        node_ids = " -> ".join(str(n.id) for n in self.nodes)
        return f"CypherPath([{node_ids}], length={self.length()})"


def from_python(value: Any) -> CypherValue:
    """Convert a Python value to a CypherValue.

    Args:
        value: Python value to convert

    Returns:
        Appropriate CypherValue subclass

    Raises:
        TypeError: If the value type is not supported
    """
    if value is None:
        return CypherNull()
    if isinstance(value, bool):
        return CypherBool(value)
    if isinstance(value, int):
        return CypherInt(value)
    if isinstance(value, float):
        return CypherFloat(value)
    if isinstance(value, str):
        return CypherString(value)
    # Temporal types (check datetime before date since datetime is subclass of date)
    if isinstance(value, datetime.datetime):
        return CypherDateTime(value)
    if isinstance(value, datetime.date):
        return CypherDate(value)
    if isinstance(value, datetime.time):
        return CypherTime(value)
    if isinstance(value, datetime.timedelta):
        return CypherDuration(value)
    # Collections
    if isinstance(value, list):
        return CypherList([from_python(item) for item in value])
    if isinstance(value, dict):
        return CypherMap({key: from_python(val) for key, val in value.items()})

    raise TypeError(f"Cannot convert Python type {type(value).__name__} to CypherValue")
