"""Query executor that executes logical plans.

This module implements the execution engine that runs logical plan operators
against a graph store.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    FunctionCall,
    ListComprehension,
    Literal,
    PropertyAccess,
    QuantifierExpression,
    SubqueryExpression,
    UnaryOp,
    Variable,
)
from graphforge.executor.evaluator import ExecutionContext, evaluate_expression
from graphforge.planner.operators import (
    Aggregate,
    Create,
    Delete,
    Distinct,
    ExpandEdges,
    ExpandMultiHop,
    ExpandVariableLength,
    Filter,
    Limit,
    Merge,
    OptionalExpandEdges,
    OptionalScanNodes,
    Project,
    Remove,
    ScanNodes,
    Set,
    Skip,
    Sort,
    Subquery,
    Union,
    Unwind,
    With,
)
from graphforge.storage.memory import Graph
from graphforge.types.values import (
    CypherBool,
    CypherFloat,
    CypherInt,
    CypherList,
    CypherMap,
    CypherNull,
    CypherValue,
)

if TYPE_CHECKING:
    from graphforge.types.graph import NodeRef


def _cypher_to_python(cypher_val: CypherValue) -> Any:
    """Convert CypherValue to Python value for storage.

    Recursively converts CypherList and CypherMap to Python list and dict.

    Args:
        cypher_val: CypherValue to convert

    Returns:
        Python value (None, bool, int, float, str, list, dict)
    """
    if isinstance(cypher_val, CypherNull):
        return None
    elif isinstance(cypher_val, (CypherBool, CypherInt, CypherFloat)):
        return cypher_val.value
    elif isinstance(cypher_val, CypherList):
        return [_cypher_to_python(item) for item in cypher_val.value]
    elif isinstance(cypher_val, CypherMap):
        return {k: _cypher_to_python(v) for k, v in cypher_val.value.items()}
    else:
        # CypherString or any other type
        return cypher_val.value


def _expression_to_string(expr: Any, fallback_index: int | None = None) -> str:
    """Convert AST expression to its Cypher string representation.

    Used for generating column names when no explicit alias is provided.

    Args:
        expr: AST expression node
        fallback_index: Optional index to append to ambiguous/fallback names
                       for uniqueness (e.g., "CASE ... END_0", "expr_1")

    Returns:
        String representation of the expression
    """
    # Variable reference
    if isinstance(expr, Variable):
        return expr.name

    # Property access
    if isinstance(expr, PropertyAccess):
        return f"{expr.variable}.{expr.property}"

    # Literal value
    if isinstance(expr, Literal):
        value = expr.value
        if value is None:
            return "null"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif isinstance(value, str):
            # Use single quotes for string literals in Cypher
            return f"'{value}'"
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, list):
            # List literal - format items directly
            def format_item(item: Any) -> str:
                if item is None:
                    return "null"
                elif isinstance(item, bool):
                    return "true" if item else "false"
                elif isinstance(item, str):
                    return f"'{item}'"
                else:
                    return str(item)

            items = [format_item(item) for item in value]
            return f"[{', '.join(items)}]"
        elif isinstance(value, dict):
            # Map literal - format values directly
            def format_value(v: Any) -> str:
                if v is None:
                    return "null"
                elif isinstance(v, bool):
                    return "true" if v else "false"
                elif isinstance(v, str):
                    return f"'{v}'"
                else:
                    return str(v)

            pairs = [f"{k}: {format_value(v)}" for k, v in value.items()]
            return f"{{{', '.join(pairs)}}}"
        else:
            return str(value)

    # Function call
    if isinstance(expr, FunctionCall):
        func_name = expr.name.lower()
        if not expr.args:
            # COUNT(*) special case
            return f"{func_name}(*)"
        args = [_expression_to_string(arg) for arg in expr.args]
        distinct_prefix = "DISTINCT " if expr.distinct else ""
        return f"{func_name}({distinct_prefix}{', '.join(args)})"

    # Binary operation
    if isinstance(expr, BinaryOp):
        left_str = _expression_to_string(expr.left)
        right_str = _expression_to_string(expr.right)
        # openCypher column names use the expression as-written: no outer parens.
        # Only inner binary operands that are themselves binary ops get parens so
        # that operator precedence is visible (e.g. "(a + b) * c").
        if isinstance(expr.left, BinaryOp):
            left_str = f"({left_str})"
        if isinstance(expr.right, BinaryOp):
            right_str = f"({right_str})"
        return f"{left_str} {expr.op} {right_str}"

    # Unary operation
    if isinstance(expr, UnaryOp):
        operand_str = _expression_to_string(expr.operand)
        if expr.op == "IS NULL":
            return f"{operand_str} IS NULL"
        elif expr.op == "IS NOT NULL":
            return f"{operand_str} IS NOT NULL"
        elif expr.op == "NOT":
            return f"NOT {operand_str}"
        elif expr.op == "-":
            return f"-{operand_str}"
        else:
            return f"{expr.op} {operand_str}"

    # CASE expression
    if isinstance(expr, CaseExpression):
        base = "CASE ... END"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # List comprehension
    if isinstance(expr, ListComprehension):
        base = "[...]"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Quantifier expression
    if isinstance(expr, QuantifierExpression):
        base = f"{expr.quantifier}(...)"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Subquery expression
    if isinstance(expr, SubqueryExpression):
        base = f"{expr.type} {{ ... }}"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Fallback for unknown expression types
    base = "expr"
    return f"{base}_{fallback_index}" if fallback_index is not None else base


class QueryExecutor:
    """Executes logical query plans against a graph.

    The executor processes a pipeline of operators, streaming rows through
    each stage of the query.
    """

    def __init__(self, graph: Graph, graphforge=None, planner=None):
        """Initialize executor with a graph.

        Args:
            graph: The graph to query
            graphforge: Optional GraphForge instance for CREATE operations
            planner: Optional QueryPlanner instance for subquery execution
        """
        self.graph = graph
        self.graphforge = graphforge
        self.planner = planner
        self.custom_functions: dict[str, Any] = {}

    def execute(self, operators: list) -> list[dict]:
        """Execute a pipeline of operators.

        Args:
            operators: List of logical plan operators

        Returns:
            List of result rows (dicts mapping column names to values)
        """
        # Start with empty context
        rows: list[Any] = [ExecutionContext()]

        # Execute each operator in sequence
        for i, op in enumerate(operators):
            rows = self._execute_operator(op, rows, i, len(operators))

        # If there's no Project or Aggregate operator in the pipeline (no RETURN clause),
        # return empty results (Cypher semantics: queries without RETURN produce no output)
        # Exception: Union operators contain their own RETURN clauses in branches
        if operators and not any(isinstance(op, (Project, Aggregate, Union)) for op in operators):
            return []

        # At this point, rows has been converted to list[dict] by Project/Aggregate operator
        # (or Union operator which also returns list[dict])
        return rows

    def _execute_operator(
        self,
        op,
        input_rows: list[Any],
        op_index: int,
        total_ops: int,
    ) -> list[Any]:
        """Execute a single operator.

        Args:
            op: Logical plan operator
            input_rows: Input execution contexts
            op_index: Index of current operator in pipeline
            total_ops: Total number of operators in pipeline

        Returns:
            Output execution contexts or dicts (for final Project/Aggregate)
        """
        if isinstance(op, ScanNodes):
            return self._execute_scan(op, input_rows)

        if isinstance(op, OptionalScanNodes):
            return self._execute_optional_scan(op, input_rows)

        if isinstance(op, ExpandEdges):
            return self._execute_expand(op, input_rows)

        from graphforge.planner.operators import ExpandVariableLength

        if isinstance(op, ExpandVariableLength):
            return self._execute_variable_expand(op, input_rows)

        if isinstance(op, ExpandMultiHop):
            return self._execute_multi_hop(op, input_rows)

        if isinstance(op, OptionalExpandEdges):
            return self._execute_optional_expand(op, input_rows)

        if isinstance(op, Filter):
            return self._execute_filter(op, input_rows)

        if isinstance(op, Project):
            return self._execute_project(op, input_rows)

        if isinstance(op, Limit):
            return self._execute_limit(op, input_rows)

        if isinstance(op, Skip):
            return self._execute_skip(op, input_rows)

        if isinstance(op, Sort):
            return self._execute_sort(op, input_rows)

        if isinstance(op, Aggregate):
            # Determine if we're in WITH context (more operators follow)
            # In WITH, return ExecutionContexts; in RETURN, return dicts
            for_with = op_index < total_ops - 1
            return self._execute_aggregate(op, input_rows, for_with=for_with)

        if isinstance(op, Create):
            return self._execute_create(op, input_rows)

        if isinstance(op, Set):
            return self._execute_set(op, input_rows)

        if isinstance(op, Remove):
            return self._execute_remove(op, input_rows)

        if isinstance(op, Delete):
            return self._execute_delete(op, input_rows)

        if isinstance(op, Merge):
            return self._execute_merge(op, input_rows)

        if isinstance(op, Unwind):
            return self._execute_unwind(op, input_rows)

        if isinstance(op, With):
            return self._execute_with(op, input_rows)

        if isinstance(op, Distinct):
            return self._execute_distinct(op, input_rows)

        if isinstance(op, Union):
            return self._execute_union(op, input_rows)

        from graphforge.planner.operators import Call

        if isinstance(op, Call):
            return self._execute_call(op, input_rows)

        if isinstance(op, Subquery):
            return self._execute_subquery(op, input_rows)

        raise TypeError(f"Unknown operator type: {type(op).__name__}")

    def _node_matches_labels(self, node: NodeRef | CypherNull, label_spec: list[list[str]]) -> bool:
        """Check if a node matches a label specification.

        Args:
            node: The node to check (or CypherNull from OPTIONAL MATCH)
            label_spec: List of label groups (disjunction of conjunctions)
                       Example: [['Person']] - node must have 'Person'
                       Example: [['Person', 'Employee']] - node must have both
                       Example: [['Person'], ['Company']] - node must have Person OR Company

        Returns:
            True if node matches any label group, False otherwise (including if node is null)
        """
        # Handle null nodes (from OPTIONAL MATCH)
        if isinstance(node, CypherNull):
            return False

        # Check if ANY label group matches (OR between groups)
        for label_group in label_spec:
            # Check if ALL labels in this group are present (AND within group)
            if all(label in node.labels for label in label_group):
                return True
        return False

    def _execute_scan(
        self, op: ScanNodes, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ScanNodes operator.

        If the variable is already bound in the input context (e.g., from WITH),
        validate that the bound node matches the pattern instead of doing a full scan.
        """
        result = []

        # For each input row
        for ctx in input_rows:
            # Check if variable is already bound (e.g., from WITH clause)
            if op.variable in ctx.bindings:
                # Variable already bound - validate it matches the pattern
                bound_node = ctx.get(op.variable)

                # Check if bound node has required labels
                if op.labels:
                    if self._node_matches_labels(bound_node, op.labels):
                        # Node matches pattern - check predicate
                        # Prepare context for predicate evaluation
                        eval_ctx = ctx
                        if op.path_var:
                            from graphforge.types import CypherPath

                            eval_ctx = ExecutionContext()
                            eval_ctx.bindings = dict(ctx.bindings)
                            path = CypherPath(nodes=[bound_node], relationships=[])
                            eval_ctx.bind(op.path_var, path)

                        # Apply pattern predicate if specified
                        if op.predicate is not None:
                            predicate_result = evaluate_expression(op.predicate, eval_ctx, self)
                            # Only include node if predicate evaluates to true
                            if not (
                                isinstance(predicate_result, CypherBool) and predicate_result.value
                            ):
                                continue  # Skip this node if predicate is not true

                        # Predicate passed - add result
                        result.append(eval_ctx)
                # No label requirements - check predicate
                elif op.path_var or op.predicate is not None:
                    from graphforge.types import CypherPath

                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    if op.path_var:
                        path = CypherPath(nodes=[bound_node], relationships=[])
                        new_ctx.bind(op.path_var, path)

                    # Apply pattern predicate if specified
                    if op.predicate is not None:
                        predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                        if not (
                            isinstance(predicate_result, CypherBool) and predicate_result.value
                        ):
                            continue  # Skip if predicate fails

                    result.append(new_ctx)
                else:
                    result.append(ctx)
            else:
                # Variable not bound - do normal scan
                if op.labels:
                    # Collect nodes from all label groups (disjunction)
                    all_nodes = set()
                    for label_group in op.labels:
                        # Scan by first label in the group for efficiency
                        group_nodes = self.graph.get_nodes_by_label(label_group[0])

                        # Filter to nodes with ALL labels in this group (conjunction)
                        if len(label_group) > 1:
                            group_nodes = [
                                node
                                for node in group_nodes
                                if all(label in node.labels for label in label_group)
                            ]

                        # Add to result set
                        all_nodes.update(group_nodes)

                    nodes = list(all_nodes)
                else:
                    # Scan all nodes
                    nodes = self.graph.get_all_nodes()

                # Bind each node
                for node in nodes:
                    new_ctx = ExecutionContext()
                    # Copy existing bindings
                    new_ctx.bindings = dict(ctx.bindings)
                    # Bind new node
                    new_ctx.bind(op.variable, node)
                    # Bind path variable if requested (single-node path)
                    if op.path_var:
                        from graphforge.types import CypherPath

                        path = CypherPath(nodes=[node], relationships=[])
                        new_ctx.bind(op.path_var, path)

                    # Apply pattern predicate if specified
                    if op.predicate is not None:
                        predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                        # Only include node if predicate evaluates to true
                        if not (
                            isinstance(predicate_result, CypherBool) and predicate_result.value
                        ):
                            continue  # Skip this node if predicate is not true

                    result.append(new_ctx)

        return result

    def _execute_optional_scan(
        self, op: OptionalScanNodes, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute OptionalScanNodes operator with LEFT JOIN semantics.

        Like ScanNodes but preserves input rows with NULL binding when no match found.
        """
        result = []

        # For each input row
        for ctx in input_rows:
            # Check if variable is already bound (e.g., from WITH clause)
            if op.variable in ctx.bindings:
                # Variable already bound - validate it matches the pattern
                bound_node = ctx.get(op.variable)

                # Check if bound node has required labels
                if op.labels:
                    if self._node_matches_labels(bound_node, op.labels):
                        # Node matches pattern - keep the context
                        result.append(ctx)
                    else:
                        # Node doesn't match - OPTIONAL preserves row with NULL
                        new_ctx = ExecutionContext()
                        new_ctx.bindings = dict(ctx.bindings)
                        new_ctx.bind(op.variable, CypherNull())
                        result.append(new_ctx)
                else:
                    # No label requirements - keep the context
                    result.append(ctx)
            else:
                # Variable not bound - do normal scan
                if op.labels:
                    # Collect nodes from all label groups (disjunction)
                    all_nodes = set()
                    for label_group in op.labels:
                        # Scan by first label in the group for efficiency
                        group_nodes = self.graph.get_nodes_by_label(label_group[0])

                        # Filter to nodes with ALL labels in this group (conjunction)
                        if len(label_group) > 1:
                            group_nodes = [
                                node
                                for node in group_nodes
                                if all(label in node.labels for label in label_group)
                            ]

                        # Add to result set
                        all_nodes.update(group_nodes)

                    nodes = list(all_nodes)
                else:
                    # Scan all nodes
                    nodes = self.graph.get_all_nodes()

                if nodes:
                    # Bind each node
                    for node in nodes:
                        new_ctx = ExecutionContext()
                        new_ctx.bindings = dict(ctx.bindings)
                        new_ctx.bind(op.variable, node)
                        result.append(new_ctx)
                else:
                    # OPTIONAL semantics: No nodes found - preserve row with NULL
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    new_ctx.bind(op.variable, CypherNull())
                    result.append(new_ctx)

        return result

    def _execute_expand(
        self, op: ExpandEdges, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandEdges operator."""
        # Check if we need to do incremental aggregation
        if op.agg_hint is not None:
            return self._execute_expand_with_aggregation(op, input_rows)

        # Standard expansion without aggregation
        result = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED
                # For undirected, get both outgoing and incoming edges
                # BUT: self-loops will appear in both lists, so deduplicate them
                outgoing = self.graph.get_outgoing_edges(src_node.id)
                incoming = self.graph.get_incoming_edges(src_node.id)

                # Deduplicate edges - self-loops (src==dst) will appear in both lists
                # Use edge ID to identify duplicates
                seen_edge_ids = set()
                edges = []
                for edge in outgoing + incoming:
                    if edge.id not in seen_edge_ids:
                        edges.append(edge)
                        seen_edge_ids.add(edge.id)

            # Filter by type if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # Bind edge and dst node
            for edge in edges:
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)

                if op.edge_var:
                    new_ctx.bind(op.edge_var, edge)

                # Determine dst node based on direction
                if op.direction == "OUT":
                    dst_node = edge.dst
                elif op.direction == "IN":
                    dst_node = edge.src
                else:  # UNDIRECTED - use whichever is not src
                    dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                new_ctx.bind(op.dst_var, dst_node)

                # Bind path variable if requested (single-hop path)
                if op.path_var:
                    from graphforge.types import CypherPath

                    path = CypherPath(nodes=[src_node, dst_node], relationships=[edge])
                    new_ctx.bind(op.path_var, path)

                # Apply pattern predicate if specified
                if op.predicate is not None:
                    predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                    # Only include edge if predicate evaluates to true
                    if not (isinstance(predicate_result, CypherBool) and predicate_result.value):
                        continue  # Skip this edge if predicate is not true

                result.append(new_ctx)

        return result

    def _execute_expand_with_aggregation(
        self, op: ExpandEdges, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandEdges with incremental aggregation.

        Instead of materializing all edges, computes aggregations incrementally
        during traversal and yields one result per group.

        Args:
            op: ExpandEdges operator with agg_hint set
            input_rows: Input execution contexts

        Returns:
            List of execution contexts with aggregation results
        """
        hint = op.agg_hint
        assert hint is not None, "agg_hint must be set when calling this method"
        func_name = hint.func.upper()

        # Map: (group_key_tuple) -> aggregate_value
        # Group key is tuple of values for group_by variables
        aggregates: dict[tuple, Any] = {}

        # Map: (group_key_tuple) -> ExecutionContext (for binding group variables)
        group_contexts: dict[tuple, ExecutionContext] = {}

        # Process all expansions, accumulating aggregates
        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED
                outgoing = self.graph.get_outgoing_edges(src_node.id)
                incoming = self.graph.get_incoming_edges(src_node.id)
                seen_edge_ids = set()
                edges = []
                for edge in outgoing + incoming:
                    if edge.id not in seen_edge_ids:
                        edges.append(edge)
                        seen_edge_ids.add(edge.id)

            # Filter by type if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # Process each edge and update aggregates
            for edge in edges:
                # Create temporary context for expression evaluation
                temp_ctx = ExecutionContext()
                temp_ctx.bindings = dict(ctx.bindings)

                if op.edge_var:
                    temp_ctx.bind(op.edge_var, edge)

                # Determine dst node
                if op.direction == "OUT":
                    dst_node = edge.dst
                elif op.direction == "IN":
                    dst_node = edge.src
                else:  # UNDIRECTED
                    dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                temp_ctx.bind(op.dst_var, dst_node)

                # Apply pattern predicate if specified
                if op.predicate is not None:
                    predicate_result = evaluate_expression(op.predicate, temp_ctx, self)
                    if not (isinstance(predicate_result, CypherBool) and predicate_result.value):
                        continue  # Skip this edge

                # Compute group key from group_by variables
                group_key_values = []
                for var_name in hint.group_by:
                    val = temp_ctx.get(var_name)
                    # Use the existing hashable conversion helper
                    hashable_val = self._value_to_hashable(val)
                    group_key_values.append(hashable_val)
                group_key = tuple(group_key_values)

                # Initialize aggregate for this group if needed
                if group_key not in aggregates:
                    aggregates[group_key] = self._initial_aggregate_value(func_name)
                    # Store the first context for this group (for binding group vars)
                    group_contexts[group_key] = temp_ctx

                # Update aggregate
                if func_name == "COUNT":
                    if hint.expr is not None:
                        # COUNT(expr) - only count non-NULL values
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            aggregates[group_key] += 1
                    else:
                        # COUNT(*) - count all rows
                        aggregates[group_key] += 1
                elif func_name == "SUM":
                    # Evaluate expression and add to sum
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            # Extract numeric value
                            if hasattr(value, "value"):
                                aggregates[group_key] += value.value
                elif func_name == "MIN":
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            val = value.value if hasattr(value, "value") else value
                            if aggregates[group_key] is None or val < aggregates[group_key]:
                                aggregates[group_key] = val
                elif func_name == "MAX":
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            val = value.value if hasattr(value, "value") else value
                            if aggregates[group_key] is None or val > aggregates[group_key]:
                                aggregates[group_key] = val

        # Yield one context per group with aggregation result
        result = []
        for group_key, agg_value in aggregates.items():
            # Start with the context from this group
            ctx = group_contexts[group_key]
            new_ctx = ExecutionContext()

            # Bind group variables
            for var_name in hint.group_by:
                new_ctx.bind(var_name, ctx.get(var_name))

            # Bind aggregate result
            wrapped_value = self._wrap_aggregate_value(func_name, agg_value)
            new_ctx.bind(hint.result_var, wrapped_value)

            result.append(new_ctx)

        return result

    def _initial_aggregate_value(self, func_name: str) -> Any:
        """Get initial value for an aggregate function.

        Args:
            func_name: Aggregation function name

        Returns:
            Initial value for the aggregate
        """
        if func_name in {"COUNT", "SUM"}:
            return 0
        elif func_name in ("MIN", "MAX"):
            return None  # No value yet
        else:
            raise ValueError(f"Unsupported aggregate function: {func_name}")

    def _wrap_aggregate_value(self, func_name: str, value: Any) -> Any:
        """Wrap aggregate result as CypherValue.

        Args:
            func_name: Aggregation function name
            value: Raw aggregate value

        Returns:
            Wrapped CypherValue
        """
        from graphforge.types.values import CypherFloat, CypherInt, CypherNull

        if func_name == "COUNT":
            return CypherInt(value)
        elif func_name == "SUM":
            # Sum could be int or float
            if isinstance(value, float):
                return CypherFloat(value)
            else:
                return CypherInt(value)
        elif func_name in ("MIN", "MAX"):
            if value is None:
                return CypherNull()
            elif isinstance(value, float):
                return CypherFloat(value)
            elif isinstance(value, int):
                return CypherInt(value)
            else:
                # For other types, return as-is (could be string, etc.)
                from graphforge.types.values import CypherString

                return CypherString(str(value))
        else:
            raise ValueError(f"Unsupported aggregate function: {func_name}")

    def _execute_variable_expand(
        self, op: ExpandVariableLength, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandVariableLength operator with recursive traversal and cycle detection."""
        result = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Perform depth-first search with cycle detection
            from graphforge.types.graph import EdgeRef

            stack: list[tuple[NodeRef, list[EdgeRef], int, set[str | int]]] = [
                (src_node, [], 0, {src_node.id})
            ]

            while stack:
                current_node, edge_path, depth, visited_in_path = stack.pop()

                # Check if we've reached valid depth range
                if op.min_hops <= depth <= (op.max_hops if op.max_hops else float("inf")):
                    # Yield this path
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)

                    new_ctx.bind(op.dst_var, current_node)

                    # Bind edge list if variable provided
                    # Note: Binding raw list of EdgeRef objects (not wrapped in CypherList)
                    # since EdgeRef is not a CypherValue and individual edges are bound directly
                    if op.edge_var:
                        new_ctx.bind(op.edge_var, edge_path)

                    # Bind path if path variable is specified
                    if op.path_var:
                        from graphforge.types import CypherPath

                        # Build node list from edge path
                        # Start with source node, then add destination of each edge
                        nodes = [src_node]
                        for edge in edge_path:
                            # Add the destination node of each edge
                            # (accounting for direction)
                            if op.direction == "OUT":
                                nodes.append(edge.dst)
                            elif op.direction == "IN":
                                nodes.append(edge.src)
                            else:  # UNDIRECTED
                                # Add whichever node we haven't visited yet
                                prev_node = nodes[-1]
                                next_node = edge.dst if edge.src.id == prev_node.id else edge.src
                                nodes.append(next_node)

                        path = CypherPath(nodes=nodes, relationships=edge_path)
                        new_ctx.bind(op.path_var, path)

                    result.append(new_ctx)

                # Continue exploration if we haven't exceeded max depth
                if op.max_hops is None or depth < op.max_hops:
                    # Get edges based on direction
                    if op.direction == "OUT":
                        edges = self.graph.get_outgoing_edges(current_node.id)
                    elif op.direction == "IN":
                        edges = self.graph.get_incoming_edges(current_node.id)
                    else:  # UNDIRECTED
                        # For undirected, get both outgoing and incoming edges
                        # BUT: self-loops will appear in both lists, so deduplicate them
                        outgoing = self.graph.get_outgoing_edges(current_node.id)
                        incoming = self.graph.get_incoming_edges(current_node.id)

                        # Deduplicate edges - self-loops (src==dst) will appear in both lists
                        # Use edge ID to identify duplicates
                        seen_edge_ids = set()
                        edges = []
                        for edge in outgoing + incoming:
                            if edge.id not in seen_edge_ids:
                                edges.append(edge)
                                seen_edge_ids.add(edge.id)

                    # Filter by type if specified
                    if op.edge_types:
                        edges = [e for e in edges if e.type in op.edge_types]

                    # Apply pattern predicate to filter edges if specified
                    if op.predicate is not None:
                        filtered_edges = []
                        for edge in edges:
                            # Create a temporary context with the edge bound
                            temp_ctx = ExecutionContext()
                            temp_ctx.bindings = dict(ctx.bindings)
                            if op.edge_var:
                                temp_ctx.bind(op.edge_var, edge)
                            # Evaluate predicate
                            predicate_result = evaluate_expression(op.predicate, temp_ctx, self)
                            # Only include edge if predicate evaluates to true
                            if isinstance(predicate_result, CypherBool) and predicate_result.value:
                                filtered_edges.append(edge)
                        edges = filtered_edges

                    # Add edges to stack for exploration
                    for edge in edges:
                        # Determine next node
                        if op.direction == "OUT":
                            next_node = edge.dst
                        elif op.direction == "IN":
                            next_node = edge.src
                        else:  # UNDIRECTED
                            next_node = edge.dst if edge.src.id == current_node.id else edge.src

                        # Cycle detection - don't revisit nodes in current path
                        if next_node.id not in visited_in_path:
                            new_visited = visited_in_path | {next_node.id}
                            stack.append((next_node, [*edge_path, edge], depth + 1, new_visited))

        return result

    def _execute_multi_hop(
        self, op: ExpandMultiHop, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandMultiHop operator for fixed multi-hop patterns.

        Traverses a chain of relationships with specific types in sequence,
        building the complete path as it goes.
        """
        result = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Track paths through the multi-hop traversal
            # Each state: (current_node, path_nodes, path_edges, hop_index)
            from graphforge.types.graph import EdgeRef

            states: list[tuple[NodeRef, list[NodeRef], list[EdgeRef], int]] = [
                (src_node, [src_node], [], 0)
            ]

            while states:
                current_node, path_nodes, path_edges, hop_idx = states.pop()

                # If we've completed all hops, emit result
                if hop_idx >= len(op.hops):
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)

                    # Bind all intermediate node variables
                    # path_nodes[0] is src (already bound)
                    # path_nodes[1..] are destinations from each hop
                    for i, (edge_var, _, _, dst_var) in enumerate(op.hops):
                        # Bind destination variable for this hop
                        new_ctx.bind(dst_var, path_nodes[i + 1])

                        # Bind edge variable if specified
                        if edge_var:
                            new_ctx.bind(edge_var, path_edges[i])

                    # Bind path variable if specified
                    if op.path_var:
                        from graphforge.types import CypherPath

                        path = CypherPath(nodes=path_nodes, relationships=path_edges)
                        new_ctx.bind(op.path_var, path)

                    result.append(new_ctx)
                    continue

                # Process current hop
                edge_var, edge_types, direction, dst_var = op.hops[hop_idx]

                # Get edges based on direction
                if direction == "OUT":
                    edges = self.graph.get_outgoing_edges(current_node.id)
                elif direction == "IN":
                    edges = self.graph.get_incoming_edges(current_node.id)
                else:  # UNDIRECTED
                    edges = self.graph.get_outgoing_edges(
                        current_node.id
                    ) + self.graph.get_incoming_edges(current_node.id)

                # Filter by type if specified
                if edge_types:
                    edges = [e for e in edges if e.type in edge_types]

                # For each matching edge, continue traversal
                for edge in edges:
                    # Determine next node based on direction
                    if direction == "OUT":
                        next_node = edge.dst
                    elif direction == "IN":
                        next_node = edge.src
                    else:  # UNDIRECTED
                        next_node = edge.dst if edge.src.id == current_node.id else edge.src

                    # Add state for next hop
                    new_path_nodes = [*path_nodes, next_node]
                    new_path_edges = [*path_edges, edge]
                    states.append((next_node, new_path_nodes, new_path_edges, hop_idx + 1))

        return result

    def _execute_filter(
        self, op: Filter, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute Filter operator."""
        result = []

        for ctx in input_rows:
            # Evaluate predicate
            value = evaluate_expression(op.predicate, ctx, self)

            # Keep row if predicate is true
            if isinstance(value, CypherBool) and value.value:
                result.append(ctx)

        return result

    def _execute_project(self, op: Project, input_rows: list[ExecutionContext]) -> list[dict]:
        """Execute Project operator."""
        from graphforge.ast.expression import Wildcard

        result = []

        for ctx in input_rows:
            row = {}
            for i, return_item in enumerate(op.items):
                # Handle Wildcard (*) - return all variables from context
                # Exclude planner-generated anonymous variables (starting with "__anon_")
                if isinstance(return_item.expression, Wildcard):
                    filtered_bindings = {
                        k: v for k, v in ctx.bindings.items() if not k.startswith("__anon_")
                    }
                    row.update(filtered_bindings)
                    continue

                # Extract expression and alias from ReturnItem
                value = evaluate_expression(return_item.expression, ctx, self)

                # Determine column name
                if return_item.alias:
                    # Explicit alias provided - use it
                    key = return_item.alias
                else:
                    # No alias - generate column name from expression
                    # Pass index for uniqueness in case of ambiguous expressions
                    key = _expression_to_string(return_item.expression, fallback_index=i)

                row[key] = value
            result.append(row)

        return result

    def _execute_with(self, op: With, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute WITH operator.

        WITH acts as a pipeline boundary, projecting specified columns and
        optionally filtering, sorting, and paginating.

        Unlike Project, WITH returns ExecutionContexts (not final dicts) so the
        query can continue with more clauses.

        Args:
            op: WITH operator with items, predicate, sort_items, skip_count, limit_count
            input_rows: Input execution contexts

        Returns:
            List of ExecutionContexts with only the projected variables
        """
        from graphforge.ast.expression import Variable, Wildcard

        # Step 1: Project items into new contexts
        result = []

        for ctx in input_rows:
            new_ctx = ExecutionContext()
            bound_vars = set()  # Track variables to detect duplicates

            for return_item in op.items:
                # Handle Wildcard (*) - copy all variables from current context
                # Exclude planner-generated anonymous variables (starting with "__anon_")
                if isinstance(return_item.expression, Wildcard):
                    for var_name, value in ctx.bindings.items():
                        if not var_name.startswith("__anon_"):
                            # Check for duplicate with explicit aliases
                            if var_name in bound_vars:
                                raise ValueError(
                                    f"ColumnNameConflict: Variable '{var_name}' from wildcard "
                                    f"expansion conflicts with explicitly aliased column"
                                )
                            new_ctx.bind(var_name, value)
                            bound_vars.add(var_name)
                    continue

                # Evaluate expression
                value = evaluate_expression(return_item.expression, ctx, self)

                # Determine variable name to bind
                if return_item.alias:
                    # Explicit alias provided
                    var_name = return_item.alias
                elif isinstance(return_item.expression, Variable):
                    # No alias, but expression is a variable - use variable name
                    var_name = return_item.expression.name
                else:
                    # Complex expression without alias - skip binding
                    # (This is technically invalid Cypher, but we'll allow it)
                    continue

                # Check for duplicate
                if var_name in bound_vars:
                    raise ValueError(
                        f"ColumnNameConflict: Multiple result columns with the same "
                        f"name '{var_name}' are not supported"
                    )

                # Bind the value in the new context
                new_ctx.bind(var_name, value)
                bound_vars.add(var_name)

            result.append(new_ctx)

        # Step 2: Apply optional WHERE filter
        if op.predicate:
            filtered = []
            for ctx in result:
                value = evaluate_expression(op.predicate, ctx, self)
                if isinstance(value, CypherBool) and value.value:
                    filtered.append(ctx)
            result = filtered

        # Step 3: Apply optional ORDER BY sort
        if op.sort_items:
            # Similar to _execute_sort but simpler since WITH items are already projected
            from functools import cmp_to_key

            def compare_values(val1, val2, ascending):
                """Compare two CypherValues."""
                # Handle NULLs
                is_null1 = isinstance(val1, CypherNull)
                is_null2 = isinstance(val2, CypherNull)

                if is_null1 and is_null2:
                    return 0
                if is_null1:
                    return 1 if ascending else -1  # NULLs last in ASC, first in DESC
                if is_null2:
                    return -1 if ascending else 1

                # Compare non-NULL values
                comp_result = val1.less_than(val2)
                if isinstance(comp_result, CypherBool):
                    if comp_result.value:
                        return -1 if ascending else 1
                    comp_result2 = val2.less_than(val1)
                    if isinstance(comp_result2, CypherBool) and comp_result2.value:
                        return 1 if ascending else -1
                    return 0
                return 0

            def compare_rows(ctx1, ctx2):
                """Compare two contexts by evaluating sort expressions."""
                for sort_item in op.sort_items:  # type: ignore[union-attr]
                    val1 = evaluate_expression(sort_item.expression, ctx1, self)
                    val2 = evaluate_expression(sort_item.expression, ctx2, self)
                    cmp = compare_values(val1, val2, sort_item.ascending)
                    if cmp != 0:
                        return cmp
                return 0

            result = sorted(result, key=cmp_to_key(compare_rows))

        # Step 4: Apply optional SKIP
        if op.skip_count is not None:
            result = result[op.skip_count :]

        # Step 5: Apply optional LIMIT
        if op.limit_count is not None:
            result = result[: op.limit_count]

        return result

    def _execute_limit(self, op: Limit, input_rows: list) -> list:
        """Execute Limit operator."""
        return input_rows[: op.count]

    def _execute_skip(self, op: Skip, input_rows: list) -> list:
        """Execute Skip operator."""
        return input_rows[op.count :]

    def _execute_distinct(self, op: Distinct, input_rows: list) -> list:
        """Execute DISTINCT operator.

        Removes duplicate rows by comparing all bound variables.
        Handles both ExecutionContext objects (before projection) and
        dict objects (after projection).
        """
        if not input_rows:
            return input_rows

        seen = set()
        result = []

        for ctx in input_rows:
            # Create hashable key from all bindings
            # Handle both ExecutionContext and dict types
            if isinstance(ctx, dict):
                # After projection - ctx is a dict
                keys = sorted(ctx.keys())
                key_items = []
                for var_name in keys:
                    value = ctx[var_name]
                    hashable = self._value_to_hashable(value)
                    key_items.append((var_name, hashable))
            else:
                # Before projection - ctx is ExecutionContext
                key_items = []
                for var_name in sorted(ctx.bindings.keys()):
                    value = ctx.bindings[var_name]
                    hashable = self._value_to_hashable(value)
                    key_items.append((var_name, hashable))

            key = tuple(key_items)
            if key not in seen:
                seen.add(key)
                result.append(ctx)

        return result

    def _execute_sort(self, op: Sort, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute Sort operator.

        Sorts rows by evaluating sort expressions and applying directions.
        NULL values are handled according to Cypher semantics:
        - ASC: NULLs last
        - DESC: NULLs first

        Supports referencing RETURN aliases by pre-evaluating RETURN expressions.
        """
        if not input_rows:
            return input_rows

        # Pre-evaluate RETURN expressions with aliases and extend contexts
        # This allows ORDER BY to reference aliases defined in RETURN
        # Keep mapping from extended context to original context
        # Note: Skip aggregate functions - they can't be evaluated until after Aggregate operator

        # Check if ORDER BY expressions can already be evaluated from input context
        # This happens after aggregation where aliases are already bound
        skip_return_items_eval = False
        if input_rows and op.items:
            try:
                # Try to evaluate all ORDER BY expressions from first context
                for order_item in op.items:
                    evaluate_expression(order_item.expression, input_rows[0], self)
                # If we got here, all ORDER BY expressions are available - skip return_items eval
                skip_return_items_eval = True
            except (KeyError, AttributeError):
                # ORDER BY references something not in context - need return_items eval
                skip_return_items_eval = False

        extended_rows = []
        context_mapping = {}  # Maps id(extended_ctx) -> original_ctx

        for ctx in input_rows:
            extended_ctx = ExecutionContext()
            extended_ctx.bindings = dict(ctx.bindings)

            # Add RETURN aliases to context (only if not after aggregation)
            if op.return_items and not skip_return_items_eval:
                for return_item in op.return_items:
                    if return_item.alias:
                        # Skip aggregate functions (COUNT, SUM, AVG, etc.)
                        # They must be evaluated by the Aggregate operator
                        from graphforge.executor.evaluator import is_aggregate_function

                        if not is_aggregate_function(return_item.expression):
                            # Evaluate the expression and bind it with the alias name
                            value = evaluate_expression(return_item.expression, ctx, self)
                            extended_ctx.bind(return_item.alias, value)

            extended_rows.append(extended_ctx)
            context_mapping[id(extended_ctx)] = ctx

        def compare_values(val1, val2, ascending):
            """Compare two CypherValues."""
            # Handle NULLs
            is_null1 = isinstance(val1, CypherNull)
            is_null2 = isinstance(val2, CypherNull)

            if is_null1 and is_null2:
                return 0
            if is_null1:
                return 1 if ascending else -1  # NULLs last in ASC, first in DESC
            if is_null2:
                return -1 if ascending else 1

            # Compare non-NULL values using less_than
            result = val1.less_than(val2)
            if isinstance(result, CypherBool):
                if result.value:
                    return -1 if ascending else 1
                # Check if val2 < val1
                result2 = val2.less_than(val1)
                if isinstance(result2, CypherBool) and result2.value:
                    return 1 if ascending else -1
                return 0  # Equal
            return 0  # NULL comparison result, treat as equal

        from functools import cmp_to_key

        def multi_key_compare(ctx1, ctx2):
            """Compare two contexts by all sort keys."""
            for order_item in op.items:
                val1 = evaluate_expression(order_item.expression, ctx1, self)
                val2 = evaluate_expression(order_item.expression, ctx2, self)
                cmp_result = compare_values(val1, val2, order_item.ascending)
                if cmp_result != 0:
                    return cmp_result
            return 0  # All keys equal

        sorted_extended_rows = sorted(extended_rows, key=cmp_to_key(multi_key_compare))

        # Map back to original contexts maintaining the sorted order
        result_rows = []
        for sorted_ctx in sorted_extended_rows:
            original_ctx = context_mapping[id(sorted_ctx)]
            result_rows.append(original_ctx)

        return result_rows

    def _expressions_match(self, expr1, expr2) -> bool:
        """Check if two expressions are semantically equivalent.

        Args:
            expr1: First expression
            expr2: Second expression

        Returns:
            True if expressions are semantically equivalent
        """
        from graphforge.ast.expression import Literal, PropertyAccess, Variable

        # Same object
        if expr1 is expr2:
            return True

        # Different types
        if not isinstance(expr1, type(expr2)):
            return False

        # Variable: compare by name
        if isinstance(expr1, Variable) and isinstance(expr2, Variable):
            return expr1.name == expr2.name

        # PropertyAccess: compare variable and property
        if isinstance(expr1, PropertyAccess) and isinstance(expr2, PropertyAccess):
            return (
                self._expressions_match(expr1.variable, expr2.variable)
                and expr1.property == expr2.property
            )

        # Literal: compare values
        if isinstance(expr1, Literal) and isinstance(expr2, Literal):
            return bool(expr1.value == expr2.value)

        # FunctionCall: compare function name and arguments
        if isinstance(expr1, FunctionCall) and isinstance(expr2, FunctionCall):
            if expr1.name.lower() != expr2.name.lower():
                return False
            if len(expr1.args) != len(expr2.args):
                return False
            return all(self._expressions_match(a1, a2) for a1, a2 in zip(expr1.args, expr2.args))

        # For other types, fall back to object identity
        return False

    def _execute_aggregate(
        self, op: Aggregate, input_rows: list[ExecutionContext], for_with: bool = False
    ) -> list[dict] | list[ExecutionContext]:
        """Execute Aggregate operator.

        Groups rows by grouping expressions and computes aggregation functions.

        Args:
            op: Aggregate operator
            input_rows: Input execution contexts
            for_with: If True, return ExecutionContexts for WITH; if False, return dicts for RETURN

        Returns:
            List of dicts (for RETURN) or ExecutionContexts (for WITH)
        """
        from collections import defaultdict

        # Handle empty input
        if not input_rows:
            # If no grouping (only aggregates), return one row with NULL/0 aggregates
            if not op.grouping_exprs:
                if for_with:
                    # Return ExecutionContext for WITH
                    ctx = ExecutionContext()
                    for agg_expr in op.agg_exprs:
                        for item in op.return_items:
                            if item.expression == agg_expr:
                                var_name = item.alias if item.alias else "col_0"
                                result_value = self._compute_aggregation(agg_expr, [])
                                ctx.bind(var_name, result_value)
                                break
                    return [ctx]
                else:
                    return [self._compute_aggregates_for_group(op, [])]
            return []

        # Group rows by grouping expressions
        if op.grouping_exprs:
            # Multiple groups
            groups = defaultdict(list)
            for ctx in input_rows:
                # Compute grouping key
                key_values = tuple(
                    self._value_to_hashable(evaluate_expression(expr, ctx, self))
                    for expr in op.grouping_exprs
                )
                groups[key_values].append(ctx)
        else:
            # No grouping - single group with all rows
            groups = {(): input_rows}  # type: ignore[assignment]

        # Compute aggregates for each group
        result: list[Any] = []
        for group_key, group_rows in groups.items():
            if for_with:
                # Return ExecutionContext for WITH clauses
                ctx = ExecutionContext()

                # Bind grouping values
                for i, (expr, val) in enumerate(zip(op.grouping_exprs, group_key)):
                    # Find alias from return_items
                    for item in op.return_items:
                        if self._expressions_match(item.expression, expr):
                            # Determine variable name
                            if item.alias:
                                var_name = item.alias
                            elif isinstance(expr, Variable):
                                # No alias, but expression is a variable - use variable name
                                var_name = expr.name
                            else:
                                # Complex expression without alias - use column index
                                var_name = f"col_{i}"
                            ctx.bind(var_name, self._hashable_to_cypher_value(val))
                            break

                # Compute and bind aggregates
                for agg_expr in op.agg_exprs:
                    # Find alias from return_items
                    for item in op.return_items:
                        if self._expressions_match(item.expression, agg_expr):
                            var_name = item.alias if item.alias else "col_0"
                            result_value = self._compute_aggregation(agg_expr, group_rows)
                            ctx.bind(var_name, result_value)
                            break

                result.append(ctx)
            else:
                # Return dict for RETURN clauses (existing behavior)
                row = self._compute_aggregates_for_group(op, group_rows, group_key)
                result.append(row)

        return result

    def _value_to_hashable(self, value):
        """Convert CypherValue to hashable key for grouping.

        Recursively handles CypherList and CypherMap to produce stable,
        hashable representations for use with COLLECT DISTINCT and grouping.
        """
        from graphforge.types.values import CypherList, CypherMap

        if isinstance(value, CypherNull):
            return None
        if isinstance(value, (CypherInt, CypherFloat, CypherBool)):
            return (type(value).__name__, value.value)
        if isinstance(value, CypherList):
            # Recursively convert list elements to hashable tuple
            return (type(value).__name__, tuple(self._value_to_hashable(v) for v in value.value))
        if isinstance(value, CypherMap):
            # Convert map to tuple of sorted (key, hashable-value) pairs
            return (
                type(value).__name__,
                tuple(sorted((k, self._value_to_hashable(v)) for k, v in value.value.items())),
            )
        if hasattr(value, "value"):
            # CypherString, etc.
            return (type(value).__name__, value.value)
        # NodeRef, EdgeRef have their own hash
        return value

    def _hashable_to_cypher_value(self, hashable_val):
        """Convert hashable representation back to CypherValue.

        Recursively reconstructs CypherList and CypherMap from their
        hashable tuple representations.
        """
        from graphforge.types.values import CypherList, CypherMap, CypherString

        if hashable_val is None:
            return CypherNull()
        elif isinstance(hashable_val, tuple) and len(hashable_val) == 2:
            type_name, val = hashable_val
            if type_name == "CypherInt":
                return CypherInt(val)
            elif type_name == "CypherFloat":
                return CypherFloat(val)
            elif type_name == "CypherBool":
                return CypherBool(val)
            elif type_name == "CypherString":
                return CypherString(val)
            elif type_name == "CypherList":
                # Recursively reconstruct list from tuple of hashable items
                reconstructed_items = [self._hashable_to_cypher_value(item) for item in val]
                return CypherList(reconstructed_items)
            elif type_name == "CypherMap":
                # Recursively reconstruct map from tuple of (key, hashable-value) pairs
                reconstructed_map = {k: self._hashable_to_cypher_value(v) for k, v in val}
                return CypherMap(reconstructed_map)

        # NodeRef, EdgeRef, or already a CypherValue
        return hashable_val

    def _compute_aggregates_for_group(
        self, op: Aggregate, group_rows: list[ExecutionContext], group_key=None
    ) -> dict:
        """Compute aggregates for a single group.

        Args:
            op: Aggregate operator
            group_rows: Rows in this group
            group_key: Tuple of grouping values (or None)

        Returns:
            Dict with both grouping values and aggregate results
        """
        row: dict[str, Any] = {}

        # Add grouping values to result
        if group_key:
            for i, expr in enumerate(op.grouping_exprs):
                # Find the corresponding ReturnItem to get the alias
                for j, return_item in enumerate(op.return_items):
                    if return_item.expression == expr:
                        # Use alias if provided, otherwise generate from expression
                        key = (
                            return_item.alias
                            if return_item.alias
                            else _expression_to_string(return_item.expression, fallback_index=j)
                        )
                        # Convert back from hashable to CypherValue
                        hashable_val = group_key[i]
                        row[key] = self._hashable_to_cypher_value(hashable_val)
                        break

        # Compute aggregates
        for agg_expr in op.agg_exprs:
            assert isinstance(agg_expr, FunctionCall)

            # Find the corresponding ReturnItem to get the alias
            for j, return_item in enumerate(op.return_items):
                if return_item.expression == agg_expr:
                    # Use alias if provided, otherwise generate from expression
                    key = (
                        return_item.alias
                        if return_item.alias
                        else _expression_to_string(return_item.expression, fallback_index=j)
                    )

                    # Compute the aggregation
                    result_value = self._compute_aggregation(agg_expr, group_rows)
                    row[key] = result_value
                    break

        return row

    def _compute_aggregation(self, func_call: FunctionCall, group_rows: list[ExecutionContext]):
        """Compute a single aggregation function over a group.

        Args:
            func_call: FunctionCall node with aggregation function
            group_rows: Rows in the group

        Returns:
            CypherValue result of the aggregation
        """
        func_name = func_call.name.upper()

        # COUNT(*) or COUNT(expr)
        if func_name == "COUNT":
            if not func_call.args:  # COUNT(*)
                return CypherInt(len(group_rows))

            # COUNT(expr) - count non-NULL values
            count = 0
            seen: set[Any] | None = set() if func_call.distinct else None

            for ctx in group_rows:
                value = evaluate_expression(func_call.args[0], ctx, self)
                if not isinstance(value, CypherNull):
                    if func_call.distinct and seen is not None:
                        hashable = self._value_to_hashable(value)
                        if hashable not in seen:
                            seen.add(hashable)
                            count += 1
                    else:
                        count += 1

            return CypherInt(count)

        # COLLECT - always return a list (even if empty, unlike other aggregations)
        if func_name == "COLLECT":
            from graphforge.types.values import CypherList

            collected_values: list[CypherValue] = []
            seen_hashes: set[Any] = set()

            for ctx in group_rows:
                value = evaluate_expression(func_call.args[0], ctx, self)
                # Skip NULL values
                if not isinstance(value, CypherNull):
                    if func_call.distinct:
                        hashable = self._value_to_hashable(value)
                        if hashable not in seen_hashes:
                            seen_hashes.add(hashable)
                            collected_values.append(value)
                    else:
                        collected_values.append(value)

            return CypherList(collected_values)

        # SUM, AVG, MIN, MAX require evaluating the expression
        values: list[Any] = []
        for ctx in group_rows:
            value = evaluate_expression(func_call.args[0], ctx, self)
            if not isinstance(value, CypherNull):
                if func_call.distinct:
                    hashable = self._value_to_hashable(value)
                    if hashable not in (self._value_to_hashable(v) for v in values):
                        values.append(value)
                else:
                    values.append(value)

        # If no non-NULL values, return NULL for most functions
        if not values:
            return CypherNull()

        # SUM
        if func_name == "SUM":
            total: int | float = 0
            is_float = False
            for val in values:
                if isinstance(val, CypherFloat):
                    is_float = True
                    total += val.value
                elif isinstance(val, CypherInt):
                    total += val.value
            return CypherFloat(total) if is_float else CypherInt(int(total))

        # AVG
        if func_name == "AVG":
            total = 0.0
            for val in values:
                if isinstance(val, (CypherInt, CypherFloat)):
                    total += val.value
            return CypherFloat(total / len(values))

        # MIN
        if func_name == "MIN":
            min_val = values[0]
            for val in values[1:]:
                result = val.less_than(min_val)
                if isinstance(result, CypherBool) and result.value:
                    min_val = val
            return min_val

        # MAX
        if func_name == "MAX":
            max_val = values[0]
            for val in values[1:]:
                result = max_val.less_than(val)
                if isinstance(result, CypherBool) and result.value:
                    max_val = val
            return max_val

        # PERCENTILEDISC - discrete percentile (no interpolation)
        if func_name == "PERCENTILEDISC":
            # Second argument is the percentile value (0.0 to 1.0)
            if len(func_call.args) != 2:
                raise TypeError(f"percentileDisc expects 2 arguments, got {len(func_call.args)}")

            # Get percentile value from second argument
            percentile_expr = func_call.args[1]
            context = group_rows[0] if group_rows else ExecutionContext()
            percentile_val = evaluate_expression(percentile_expr, context, self)

            if isinstance(percentile_val, CypherNull):
                return CypherNull()

            if not isinstance(percentile_val, (CypherInt, CypherFloat)):
                raise TypeError("percentileDisc percentile must be a number")

            percentile = float(percentile_val.value)
            if not 0.0 <= percentile <= 1.0:
                raise ValueError("percentileDisc percentile must be between 0.0 and 1.0")

            if not values:
                return CypherNull()

            # Convert values to floats and sort
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    val_type = type(val).__name__
                    raise TypeError(f"percentileDisc requires numeric values, got {val_type}")

            numeric_values.sort()

            # Calculate index (discrete - no interpolation)
            if percentile == 1.0:
                index = len(numeric_values) - 1
            else:
                index = int(percentile * len(numeric_values))

            return CypherFloat(numeric_values[index])

        # PERCENTILECONT - continuous percentile (with linear interpolation)
        if func_name == "PERCENTILECONT":
            # Second argument is the percentile value (0.0 to 1.0)
            if len(func_call.args) != 2:
                raise TypeError(f"percentileCont expects 2 arguments, got {len(func_call.args)}")

            # Get percentile value from second argument
            percentile_expr = func_call.args[1]
            context = group_rows[0] if group_rows else ExecutionContext()
            percentile_val = evaluate_expression(percentile_expr, context, self)

            if isinstance(percentile_val, CypherNull):
                return CypherNull()

            if not isinstance(percentile_val, (CypherInt, CypherFloat)):
                raise TypeError("percentileCont percentile must be a number")

            percentile = float(percentile_val.value)
            if not 0.0 <= percentile <= 1.0:
                raise ValueError("percentileCont percentile must be between 0.0 and 1.0")

            if not values:
                return CypherNull()

            # Convert values to floats and sort
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    val_type = type(val).__name__
                    raise TypeError(f"percentileCont requires numeric values, got {val_type}")

            numeric_values.sort()

            # Calculate position with linear interpolation
            if percentile == 0.0:
                return CypherFloat(numeric_values[0])
            if percentile == 1.0:
                return CypherFloat(numeric_values[-1])

            # Linear interpolation between adjacent values
            position = percentile * (len(numeric_values) - 1)
            lower_index = int(position)
            upper_index = lower_index + 1

            if upper_index >= len(numeric_values):
                return CypherFloat(numeric_values[-1])

            # Interpolate
            fraction = position - lower_index
            lower_value = numeric_values[lower_index]
            upper_value = numeric_values[upper_index]
            result = lower_value + fraction * (upper_value - lower_value)

            return CypherFloat(result)

        # STDEV - sample standard deviation
        if func_name == "STDEV":
            if len(values) < 2:
                return CypherNull()

            # Convert to numeric values
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    raise TypeError(f"stDev requires numeric values, got {type(val).__name__}")

            # Calculate mean
            mean = sum(numeric_values) / len(numeric_values)

            # Calculate sample variance: sum((x - mean)^2) / (n - 1)
            variance = sum((x - mean) ** 2 for x in numeric_values) / (len(numeric_values) - 1)

            # Standard deviation is square root of variance
            import math

            std_dev = math.sqrt(variance)

            return CypherFloat(std_dev)

        # STDEVP - population standard deviation
        if func_name == "STDEVP":
            if not values:
                return CypherNull()

            # Convert to numeric values
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    raise TypeError(f"stDevP requires numeric values, got {type(val).__name__}")

            # Calculate mean
            mean = sum(numeric_values) / len(numeric_values)

            # Calculate population variance: sum((x - mean)^2) / n
            variance = sum((x - mean) ** 2 for x in numeric_values) / len(numeric_values)

            # Standard deviation is square root of variance
            import math

            std_dev = math.sqrt(variance)

            return CypherFloat(std_dev)

        raise ValueError(f"Unknown aggregation function: {func_name}")

    def _validate_pattern_variables(self, pattern_parts):
        """Validate pattern variables in CREATE pattern.

        Per openCypher semantics:
        - Node variables can appear multiple times (e.g., self-loops: CREATE (a)-[:R]->(a))
        - Relationship variables must be unique
        - A variable cannot be used for both a node and a relationship

        Args:
            pattern_parts: List of NodePattern/RelationshipPattern objects from pattern

        Raises:
            ValueError: If validation fails
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        node_vars = []
        rel_vars = []

        for part in pattern_parts:
            if hasattr(part, "variable") and part.variable:
                var_name = part.variable if isinstance(part.variable, str) else part.variable.name

                if isinstance(part, NodePattern):
                    node_vars.append(var_name)
                elif isinstance(part, RelationshipPattern):
                    rel_vars.append(var_name)

        # Check: relationship variables must be unique
        seen_rel_vars = set()
        for var in rel_vars:
            if var in seen_rel_vars:
                raise ValueError(
                    f"Variable '{var}' used multiple times for relationships in CREATE pattern. "
                    f"Each relationship variable must be unique."
                )
            seen_rel_vars.add(var)

        # Check: a variable cannot be both a node and a relationship
        node_var_set = set(node_vars)
        rel_var_set = set(rel_vars)
        overlap = node_var_set & rel_var_set
        if overlap:
            var = next(iter(overlap))
            raise ValueError(
                f"Variable '{var}' used for both node and relationship in CREATE pattern. "
                f"A variable must refer to only one type of entity."
            )

    def _execute_create(
        self, op: Create, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute CREATE operator.

        Creates nodes and relationships from patterns.

        Args:
            op: Create operator with patterns
            input_rows: Input execution contexts

        Returns:
            Execution contexts with created elements bound to variables
        """
        if not self.graphforge:
            raise RuntimeError("CREATE requires GraphForge instance")

        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        result = []

        # Process each input row (usually just one for CREATE)
        for ctx in input_rows:
            new_ctx = ExecutionContext()
            new_ctx.bindings = ctx.bindings.copy()

            # Process each pattern
            for pattern in op.patterns:
                if not pattern:
                    continue

                # Extract pattern parts from new format (dict with path_variable and parts)
                # or use pattern directly if it's old format (list)
                # Note: CREATE and MERGE do not support path binding
                if isinstance(pattern, dict) and "parts" in pattern:
                    pattern_parts = pattern["parts"]
                else:
                    # Old format: pattern is already a list
                    pattern_parts = pattern

                # Validate no duplicate variables in pattern
                self._validate_pattern_variables(pattern_parts)

                # Handle simple node pattern: CREATE (n:Person {name: 'Alice'})
                if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                    node_pattern = pattern_parts[0]
                    node = self._create_node_from_pattern(node_pattern, new_ctx)
                    if node_pattern.variable:
                        new_ctx.bindings[node_pattern.variable] = node

                # Handle node-relationship-node pattern: CREATE (a)-[r:KNOWS]->(b)
                elif len(pattern_parts) >= 3:
                    # First node
                    if isinstance(pattern_parts[0], NodePattern):
                        src_pattern = pattern_parts[0]
                        # Check if variable already bound (for connecting existing nodes)
                        if src_pattern.variable and src_pattern.variable in new_ctx.bindings:
                            src_node = new_ctx.bindings[src_pattern.variable]
                        else:
                            src_node = self._create_node_from_pattern(src_pattern, new_ctx)
                            if src_pattern.variable:
                                new_ctx.bindings[src_pattern.variable] = src_node

                    # Process all relationships in the pattern (multi-hop support)
                    # Pattern structure: node, rel, node, rel, node, ...
                    # Process pairs: (node[0], rel[1], node[2]), (node[2], rel[3], node[4]), ...
                    # Keep track of the last destination node for chaining
                    last_dst_node = src_node

                    for i in range(1, len(pattern_parts), 2):
                        if i + 1 >= len(pattern_parts):
                            break  # Need both relationship and destination node

                        if not isinstance(pattern_parts[i], RelationshipPattern):
                            continue  # Skip if not a relationship

                        rel_pattern = pattern_parts[i]
                        dst_pattern = pattern_parts[i + 1]

                        # Source node is the last created destination node from previous iteration
                        # (or the initial src_node for i==1)
                        src_node = last_dst_node

                        # Check if destination variable already bound
                        if dst_pattern.variable and dst_pattern.variable in new_ctx.bindings:
                            dst_node = new_ctx.bindings[dst_pattern.variable]
                        else:
                            dst_node = self._create_node_from_pattern(dst_pattern, new_ctx)
                            if dst_pattern.variable:
                                new_ctx.bindings[dst_pattern.variable] = dst_node

                        # Create relationship
                        rel_type = rel_pattern.types[0] if rel_pattern.types else "RELATED_TO"
                        edge = self._create_relationship_from_pattern(
                            src_node, dst_node, rel_type, rel_pattern, new_ctx
                        )
                        if rel_pattern.variable:
                            new_ctx.bindings[rel_pattern.variable] = edge

                        # Update last_dst_node for next iteration
                        last_dst_node = dst_node

            result.append(new_ctx)

        return result

    def _create_node_from_pattern(self, node_pattern, ctx: ExecutionContext):
        """Create a node from a NodePattern.

        Args:
            node_pattern: NodePattern from AST
            ctx: Execution context for evaluating property expressions

        Returns:
            Created NodeRef
        """
        # Validate no disjunctive labels in CREATE
        if node_pattern.labels and len(node_pattern.labels) > 1:
            raise ValueError(
                "Disjunctive labels (using '|') are not allowed in CREATE patterns. "
                "Use multiple CREATE statements or specify only conjunction of labels."
            )

        # Extract labels - flatten label groups for CREATE
        # For CREATE, we apply all labels from all groups (only one group allowed)
        labels = []
        if node_pattern.labels:
            for label_group in node_pattern.labels:
                labels.extend(label_group)

        # Extract and evaluate properties
        properties = {}
        if node_pattern.properties:
            for key, value_expr in node_pattern.properties.items():
                # Evaluate the expression to get the value
                cypher_value = evaluate_expression(value_expr, ctx, self)
                # Per openCypher spec, NULL means "no value" - skip NULL properties
                if not isinstance(cypher_value, CypherNull):
                    # Convert CypherValue to Python value (handles nested lists/maps)
                    properties[key] = _cypher_to_python(cypher_value)

        # Create node using GraphForge API
        node = self.graphforge.create_node(labels, **properties)
        return node

    def _create_relationship_from_pattern(
        self, src_node, dst_node, rel_type, rel_pattern, ctx: ExecutionContext
    ):
        """Create a relationship from a RelationshipPattern.

        Args:
            src_node: Source NodeRef
            dst_node: Destination NodeRef
            rel_type: Relationship type string
            rel_pattern: RelationshipPattern from AST
            ctx: Execution context for evaluating property expressions

        Returns:
            Created EdgeRef
        """
        # Extract and evaluate properties
        properties = {}
        if hasattr(rel_pattern, "properties") and rel_pattern.properties:
            for key, value_expr in rel_pattern.properties.items():
                # Evaluate the expression to get the value
                cypher_value = evaluate_expression(value_expr, ctx, self)
                # Per openCypher spec, NULL means "no value" - skip NULL properties
                if not isinstance(cypher_value, CypherNull):
                    # Convert CypherValue to Python value (handles nested lists/maps)
                    properties[key] = _cypher_to_python(cypher_value)

        # Create relationship using GraphForge API
        edge = self.graphforge.create_relationship(src_node, dst_node, rel_type, **properties)
        return edge

    def _execute_set(self, op: Set, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute SET operator.

        Updates properties on nodes and relationships.

        Args:
            op: Set operator with property assignments
            input_rows: Input execution contexts

        Returns:
            Updated execution contexts
        """
        result = []

        for ctx in input_rows:
            self._execute_set_items(op.items, ctx)
            result.append(ctx)

        return result

    def _execute_remove(
        self, op: Remove, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute REMOVE operator.

        Removes properties from nodes/relationships or labels from nodes.

        Args:
            op: Remove operator with items to remove
            input_rows: Input execution contexts

        Returns:
            Updated execution contexts
        """
        from graphforge.types.graph import NodeRef

        result = []

        for ctx in input_rows:
            # Process each REMOVE item
            for item in op.items:
                var_name = item.variable
                name = item.name

                # Get the element from context
                if var_name in ctx.bindings:
                    element = ctx.bindings[var_name]

                    if item.item_type == "property":
                        # Remove property if it exists
                        if hasattr(element, "properties") and name in element.properties:
                            del element.properties[name]
                    elif item.item_type == "label":
                        # Remove label if it exists
                        # NodeRef is immutable, so we need to create a new one with updated labels
                        if hasattr(element, "labels") and name in element.labels:
                            # Create new labels set without the removed label
                            new_labels = set(element.labels)
                            new_labels.discard(name)

                            # Create new NodeRef with updated labels
                            new_node = NodeRef(
                                id=element.id,
                                labels=frozenset(new_labels),
                                properties=element.properties,
                            )

                            # Update the node in the graph
                            self.graph.add_node(new_node)

                            # Update the binding to reference the new node
                            ctx.bindings[var_name] = new_node

            result.append(ctx)

        return result

    def _execute_delete(
        self, op: Delete, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute DELETE operator.

        Removes nodes and relationships from the graph.

        Args:
            op: Delete operator with variables to delete
            input_rows: Input execution contexts

        Returns:
            Empty list (DELETE produces no output rows)

        Raises:
            ValueError: If trying to delete a node with relationships without DETACH
        """
        from graphforge.types.graph import EdgeRef, NodeRef

        for ctx in input_rows:
            for var_name in op.variables:
                if var_name in ctx.bindings:
                    element = ctx.bindings[var_name]

                    # Skip NULL values - they don't exist in the graph
                    if isinstance(element, CypherNull):
                        continue

                    # Delete from graph
                    if isinstance(element, NodeRef):
                        # Get all edges connected to this node
                        outgoing = self.graph.get_outgoing_edges(element.id)
                        incoming = self.graph.get_incoming_edges(element.id)
                        all_edges = outgoing + incoming

                        # Check if node has relationships
                        if all_edges and not op.detach:
                            raise ValueError(
                                "Cannot delete node with relationships. "
                                "Use DETACH DELETE to delete relationships first."
                            )

                        # Remove all connected edges first (if DETACH)
                        if op.detach:
                            for edge in all_edges:
                                self.graph._edges.pop(edge.id, None)
                                # Remove from adjacency lists
                                if edge.src.id in self.graph._outgoing:
                                    self.graph._outgoing[edge.src.id] = [
                                        e
                                        for e in self.graph._outgoing[edge.src.id]
                                        if e.id != edge.id
                                    ]
                                if edge.dst.id in self.graph._incoming:
                                    self.graph._incoming[edge.dst.id] = [
                                        e
                                        for e in self.graph._incoming[edge.dst.id]
                                        if e.id != edge.id
                                    ]
                                # Remove from type index
                                if edge.type in self.graph._type_index:
                                    self.graph._type_index[edge.type].discard(edge.id)

                        # Remove node
                        self.graph._nodes.pop(element.id, None)
                        # Remove from label index
                        for label in element.labels:
                            if label in self.graph._label_index:
                                self.graph._label_index[label].discard(element.id)
                        # Remove adjacency lists
                        self.graph._outgoing.pop(element.id, None)
                        self.graph._incoming.pop(element.id, None)

                    elif isinstance(element, EdgeRef):
                        # Remove edge
                        self.graph._edges.pop(element.id, None)
                        # Remove from adjacency lists
                        if element.src.id in self.graph._outgoing:
                            self.graph._outgoing[element.src.id] = [
                                e
                                for e in self.graph._outgoing[element.src.id]
                                if e.id != element.id
                            ]
                        if element.dst.id in self.graph._incoming:
                            self.graph._incoming[element.dst.id] = [
                                e
                                for e in self.graph._incoming[element.dst.id]
                                if e.id != element.id
                            ]
                        # Remove from type index
                        if element.type in self.graph._type_index:
                            self.graph._type_index[element.type].discard(element.id)

        # DELETE produces no output rows
        return []

    def _execute_merge(
        self, op: Merge, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute MERGE operator with ON CREATE SET and ON MATCH SET support.

        Creates patterns if they don't exist, or matches them if they do.
        Conditionally executes SET operations based on whether elements were created or matched.

        Args:
            op: Merge operator with patterns, on_create, and on_match clauses
            input_rows: Input execution contexts

        Returns:
            Execution contexts with matched or created elements
        """
        if not self.graphforge:
            raise RuntimeError("MERGE requires GraphForge instance")

        from graphforge.ast.pattern import NodePattern

        result = []

        # Process each input row
        for ctx in input_rows:
            new_ctx = ExecutionContext()
            new_ctx.bindings = ctx.bindings.copy()

            # Track whether we created anything (for ON CREATE SET)
            was_created = False

            # Process each pattern
            for pattern in op.patterns:
                if not pattern:
                    continue

                # Extract pattern parts from new format (dict with path_variable and parts)
                # or use pattern directly if it's old format (list)
                # Note: CREATE and MERGE do not support path binding
                if isinstance(pattern, dict) and "parts" in pattern:
                    pattern_parts = pattern["parts"]
                else:
                    # Old format: pattern is already a list
                    pattern_parts = pattern

                # Handle simple node pattern: MERGE (n:Person {name: 'Alice'})
                if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                    node_pattern = pattern_parts[0]

                    # Validate no disjunctive labels in MERGE
                    if node_pattern.labels and len(node_pattern.labels) > 1:
                        raise ValueError(
                            "Disjunctive labels (using '|') are not allowed in MERGE patterns. "
                            "Use multiple MERGE statements or specify only conjunction of labels."
                        )

                    # Try to find existing node
                    found_node = None

                    if node_pattern.labels:
                        # Collect candidate nodes from all label groups (disjunction)
                        all_candidates = set()
                        for label_group in node_pattern.labels:
                            # Get nodes by first label in the group
                            group_candidates = self.graph.get_nodes_by_label(label_group[0])

                            # Filter to nodes with ALL labels in this group (conjunction)
                            if len(label_group) > 1:
                                group_candidates = [
                                    node
                                    for node in group_candidates
                                    if all(label in node.labels for label in label_group)
                                ]

                            all_candidates.update(group_candidates)

                        candidates = list(all_candidates)

                        for node in candidates:
                            # Node already matches labels (filtered above)

                            # Check if properties match
                            if node_pattern.properties:
                                match = True
                                for key, value_expr in node_pattern.properties.items():
                                    expected_value = evaluate_expression(value_expr, new_ctx, self)

                                    # NULL in pattern never matches (per openCypher spec)
                                    # NULL = anything returns NULL (unknown, not true)
                                    if isinstance(expected_value, CypherNull):
                                        match = False
                                        break

                                    if key not in node.properties:
                                        match = False
                                        break

                                    # Compare CypherValue objects using equality
                                    node_value = node.properties[key]

                                    # NULL in node property never matches
                                    if isinstance(node_value, CypherNull):
                                        match = False
                                        break

                                    comparison_result = node_value.equals(expected_value)

                                    # Comparison should return CypherBool (both non-NULL)
                                    if not isinstance(comparison_result, CypherBool):
                                        # Unexpected NULL (shouldn't happen after checks)
                                        match = False
                                        break

                                    if not comparison_result.value:
                                        match = False
                                        break

                                if match:
                                    # Found matching node
                                    found_node = node
                                    break
                            else:
                                # No properties specified, just match on labels
                                found_node = node
                                break

                    # Bind found node or create new one
                    if found_node:
                        was_created = False
                        if node_pattern.variable:
                            new_ctx.bindings[node_pattern.variable] = found_node
                    else:
                        was_created = True
                        node = self._create_node_from_pattern(node_pattern, new_ctx)
                        if node_pattern.variable:
                            new_ctx.bindings[node_pattern.variable] = node

                # Handle node-relationship-node pattern: MERGE (a)-[r:KNOWS]->(b)
                elif len(pattern_parts) >= 3:
                    was_created = self._merge_relationship_pattern(pattern_parts, new_ctx)

            # Execute conditional SET operations
            if was_created and op.on_create:
                # Execute ON CREATE SET
                self._execute_set_items(op.on_create.items, new_ctx)
            elif not was_created and op.on_match:
                # Execute ON MATCH SET
                self._execute_set_items(op.on_match.items, new_ctx)

            result.append(new_ctx)

        return result

    def _merge_relationship_pattern(self, pattern_parts: list, ctx: ExecutionContext) -> bool:
        """Merge a relationship pattern (node-rel-node).

        Args:
            pattern_parts: List of pattern parts (nodes and relationships)
            ctx: Execution context

        Returns:
            True if pattern was created, False if matched
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        # For now, only support simple 3-part patterns: (a)-[r]->(b)
        # TODO: Support multi-hop patterns in the future
        if len(pattern_parts) != 3:
            raise ValueError(
                "MERGE currently only supports simple relationship patterns: (a)-[r]->(b)"
            )

        src_pattern = pattern_parts[0]
        rel_pattern = pattern_parts[1]
        dst_pattern = pattern_parts[2]

        if not isinstance(src_pattern, NodePattern):
            raise ValueError("First element of relationship pattern must be a node")
        if not isinstance(rel_pattern, RelationshipPattern):
            raise ValueError("Second element of relationship pattern must be a relationship")
        if not isinstance(dst_pattern, NodePattern):
            raise ValueError("Third element of relationship pattern must be a node")

        # Step 1: Resolve or create source node
        src_node = self._merge_node_in_context(src_pattern, ctx)

        # Step 2: Resolve or create destination node
        dst_node = self._merge_node_in_context(dst_pattern, ctx)

        # Step 3: Try to find existing relationship
        from graphforge.ast.pattern import Direction

        rel_type = rel_pattern.types[0] if rel_pattern.types else "RELATED_TO"
        found_rel = None

        # Get edges based on direction
        edges_to_check = []
        if rel_pattern.direction == Direction.OUT:
            # Outgoing: (src)-[r]->(dst)
            edges_to_check = self.graph.get_outgoing_edges(src_node.id)
        elif rel_pattern.direction == Direction.IN:
            # Incoming: (src)<-[r]-(dst), so check incoming edges of src_node
            edges_to_check = self.graph.get_incoming_edges(src_node.id)
        elif rel_pattern.direction == Direction.UNDIRECTED:
            # Undirected: (src)-[r]-(dst), check both directions
            outgoing = self.graph.get_outgoing_edges(src_node.id)
            incoming = self.graph.get_incoming_edges(src_node.id)
            # Deduplicate by edge ID
            seen_ids = set()
            for edge in outgoing + incoming:
                if edge.id not in seen_ids:
                    seen_ids.add(edge.id)
                    edges_to_check.append(edge)

        for edge in edges_to_check:
            # Check if edge connects to destination node (direction-aware)
            if rel_pattern.direction == Direction.OUT:
                if edge.dst.id != dst_node.id:
                    continue
            elif rel_pattern.direction == Direction.IN:
                if edge.src.id != dst_node.id:
                    continue
            elif rel_pattern.direction == Direction.UNDIRECTED:
                # For undirected, dst_node can be on either end
                if dst_node.id not in (edge.dst.id, edge.src.id):
                    continue

            # Check if edge type matches
            if edge.type != rel_type:
                continue

            # Check if edge properties match
            if rel_pattern.properties:
                match = True
                for key, value_expr in rel_pattern.properties.items():
                    expected_value = evaluate_expression(value_expr, ctx, self)

                    # NULL in pattern never matches
                    if isinstance(expected_value, CypherNull):
                        match = False
                        break

                    if key not in edge.properties:
                        match = False
                        break

                    # Compare CypherValue objects using equality
                    edge_value = edge.properties[key]

                    # NULL in edge property never matches
                    if isinstance(edge_value, CypherNull):
                        match = False
                        break

                    comparison_result = edge_value.equals(expected_value)

                    if not isinstance(comparison_result, CypherBool):
                        match = False
                        break

                    if not comparison_result.value:
                        match = False
                        break

                if match:
                    found_rel = edge
                    break
            else:
                # No properties specified, just match on type
                found_rel = edge
                break

        # Step 4: Bind or create relationship
        if found_rel:
            # Relationship exists - bind and return False (was_created = False)
            if rel_pattern.variable:
                ctx.bindings[rel_pattern.variable] = found_rel
            return False
        else:
            # Relationship doesn't exist - create it and return True (was_created = True)
            # For IN direction, swap src and dst so stored edge direction is correct
            if rel_pattern.direction == Direction.IN:
                # Pattern: (src)<-[r]-(dst) means dst->src in storage
                edge = self._create_relationship_from_pattern(
                    dst_node, src_node, rel_type, rel_pattern, ctx
                )
            else:
                # OUT and UNDIRECTED: (src)-[r]->(dst) or (src)-[r]-(dst)
                edge = self._create_relationship_from_pattern(
                    src_node, dst_node, rel_type, rel_pattern, ctx
                )
            if rel_pattern.variable:
                ctx.bindings[rel_pattern.variable] = edge
            return True

    def _merge_node_in_context(self, node_pattern, ctx: ExecutionContext):
        """Merge a single node (find or create) and bind to context.

        Args:
            node_pattern: NodePattern from AST
            ctx: Execution context

        Returns:
            NodeRef (found or created)
        """

        # Check if variable is already bound (from MATCH clause)
        if node_pattern.variable and node_pattern.variable in ctx.bindings:
            return ctx.bindings[node_pattern.variable]

        # Validate no disjunctive labels in MERGE
        if node_pattern.labels and len(node_pattern.labels) > 1:
            raise ValueError(
                "Disjunctive labels (using '|') are not allowed in MERGE patterns. "
                "Use multiple MERGE statements or specify only conjunction of labels."
            )

        # Try to find existing node
        found_node = None

        if node_pattern.labels:
            # Collect candidate nodes from all label groups
            all_candidates = set()
            for label_group in node_pattern.labels:
                # Get nodes by first label in the group
                group_candidates = self.graph.get_nodes_by_label(label_group[0])

                # Filter to nodes with ALL labels in this group (conjunction)
                if len(label_group) > 1:
                    group_candidates = [
                        node
                        for node in group_candidates
                        if all(label in node.labels for label in label_group)
                    ]

                all_candidates.update(group_candidates)

            candidates = list(all_candidates)

            for node in candidates:
                # Check if properties match
                if node_pattern.properties:
                    match = True
                    for key, value_expr in node_pattern.properties.items():
                        expected_value = evaluate_expression(value_expr, ctx, self)

                        # NULL in pattern never matches
                        if isinstance(expected_value, CypherNull):
                            match = False
                            break

                        if key not in node.properties:
                            match = False
                            break

                        # Compare CypherValue objects using equality
                        node_value = node.properties[key]

                        # NULL in node property never matches
                        if isinstance(node_value, CypherNull):
                            match = False
                            break

                        comparison_result = node_value.equals(expected_value)

                        if not isinstance(comparison_result, CypherBool):
                            match = False
                            break

                        if not comparison_result.value:
                            match = False
                            break

                    if match:
                        found_node = node
                        break
                else:
                    # No properties specified, just match on labels
                    found_node = node
                    break

        # Bind found node or create new one
        if found_node:
            if node_pattern.variable:
                ctx.bindings[node_pattern.variable] = found_node
            return found_node
        else:
            node = self._create_node_from_pattern(node_pattern, ctx)
            if node_pattern.variable:
                ctx.bindings[node_pattern.variable] = node
            return node

    def _execute_set_items(self, items: list, ctx: ExecutionContext) -> None:
        """Execute SET items on a context (helper for conditional SET).

        Args:
            items: List of (property_access, expression) tuples
            ctx: Execution context to update
        """
        for property_access, value_expr in items:
            # Evaluate the target (should be a PropertyAccess node)
            if hasattr(property_access, "variable") and hasattr(property_access, "property"):
                var_name = (
                    property_access.variable.name
                    if hasattr(property_access.variable, "name")
                    else property_access.variable
                )
                prop_name = property_access.property

                # Get the node or edge from context
                if var_name in ctx.bindings:
                    element = ctx.bindings[var_name]

                    # Evaluate the new value
                    new_value = evaluate_expression(value_expr, ctx, self)

                    # Update the property on the element
                    element.properties[prop_name] = new_value

    def _execute_unwind(
        self, op: Unwind, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute UNWIND operator.

        Expands a list into multiple rows, binding each element to a variable.

        Args:
            op: Unwind operator with expression and variable
            input_rows: Input execution contexts

        Returns:
            Expanded execution contexts (one per list element per input row)
        """
        result = []

        # If no input rows, start with one empty context
        if not input_rows:
            input_rows = [ExecutionContext()]

        for ctx in input_rows:
            # Evaluate the list expression
            value = evaluate_expression(op.expression, ctx, self)

            # Handle NULL - treated as empty list (produces no rows)
            if isinstance(value, CypherNull):
                continue

            # Handle CypherList
            if isinstance(value, CypherList):
                # Expand each list item into a new row
                for item in value.value:
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    new_ctx.bind(op.variable, item)
                    result.append(new_ctx)
            else:
                # If not a list or NULL, wrap in a list
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)
                new_ctx.bind(op.variable, value)
                result.append(new_ctx)

        return result

    def _execute_optional_expand(
        self, op: OptionalExpandEdges, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute OptionalExpandEdges operator (left outer join).

        Like ExpandEdges, but preserves rows with NULL bindings when no matches found.
        This implements OPTIONAL MATCH semantics.

        Args:
            op: OptionalExpandEdges operator
            input_rows: Input execution contexts

        Returns:
            Execution contexts with expanded relationships or NULL bindings
        """
        from graphforge.types.graph import NodeRef

        result = []

        for ctx in input_rows:
            # Get source node
            if op.src_var not in ctx.bindings:
                # OPTIONAL MATCH: Source variable not bound - preserve row with NULL bindings
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)
                new_ctx.bind(op.dst_var, CypherNull())
                if op.edge_var:
                    new_ctx.bind(op.edge_var, CypherNull())
                result.append(new_ctx)
                continue

            src_node = ctx.get(op.src_var)
            if not isinstance(src_node, NodeRef):
                # OPTIONAL MATCH: Source is not a node - preserve row with NULL bindings
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)
                new_ctx.bind(op.dst_var, CypherNull())
                if op.edge_var:
                    new_ctx.bind(op.edge_var, CypherNull())
                result.append(new_ctx)
                continue

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED
                edges = self.graph.get_outgoing_edges(src_node.id) + self.graph.get_incoming_edges(
                    src_node.id
                )

            # Filter by edge types if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # LEFT JOIN behavior
            if not edges:
                # No edges found - preserve row with NULL bindings
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)
                new_ctx.bind(op.dst_var, CypherNull())
                if op.edge_var:
                    new_ctx.bind(op.edge_var, CypherNull())
                result.append(new_ctx)
            else:
                # INNER JOIN behavior - bind actual values
                for edge in edges:
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)

                    # Bind edge if variable specified
                    if op.edge_var:
                        new_ctx.bind(op.edge_var, edge)

                    # Determine destination node based on direction
                    if op.direction == "OUT":
                        dst_node = edge.dst
                    elif op.direction == "IN":
                        dst_node = edge.src
                    else:  # UNDIRECTED - check which end is the source
                        dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                    new_ctx.bind(op.dst_var, dst_node)
                    result.append(new_ctx)

        return result

    def _extract_column_names_from_branch(self, branch: list) -> set[str] | None:
        """Extract column names from a branch plan.

        Used for UNION validation when branches return no rows.

        Args:
            branch: List of operators in the branch

        Returns:
            Set of column names, or None if no Project/Aggregate operator found
        """
        # Find the last Project or Aggregate operator in the branch
        for op in reversed(branch):
            if isinstance(op, Project):
                # Extract column names from Project operator
                columns = set()
                for i, return_item in enumerate(op.items):
                    if return_item.alias:
                        columns.add(return_item.alias)
                    else:
                        # Generate column name same way as _execute_project
                        columns.add(_expression_to_string(return_item.expression, fallback_index=i))
                return columns
            elif isinstance(op, Aggregate):
                # Extract column names from Aggregate operator
                columns = set()
                for j, return_item in enumerate(op.return_items):
                    if return_item.alias:
                        columns.add(return_item.alias)
                    else:
                        # Generate column name same way as _compute_aggregates_for_group
                        columns.add(_expression_to_string(return_item.expression, fallback_index=j))
                return columns
        return None

    def _execute_union(self, op: Union, input_rows: list[ExecutionContext]) -> list[Any]:
        """Execute Union operator.

        Combines results from multiple query branches. Each branch is executed
        independently and results are merged.

        Args:
            op: Union operator with branches
            input_rows: Input execution contexts (typically empty for UNION at query level)

        Returns:
            Combined results from all branches (list of dicts or ExecutionContexts)

        Raises:
            ValueError: If branches have incompatible column sets
        """
        all_results: list[Any] = []
        branch_columns: list[tuple[int, set[str]]] = []

        # Execute each branch independently
        for branch_idx, branch in enumerate(op.branches):
            # Execute this branch's pipeline
            branch_results: list[Any] = input_rows if input_rows else [ExecutionContext()]
            for op_index, branch_op in enumerate(branch):
                branch_results = self._execute_operator(
                    branch_op, branch_results, op_index, len(branch)
                )

            # Track column names for validation
            columns: set[str] | None = None

            if branch_results and isinstance(branch_results[0], dict):
                # Non-empty results - extract columns from first row
                columns = set(branch_results[0].keys())
            elif not branch_results:
                # Empty results - extract column schema from branch plan
                columns = self._extract_column_names_from_branch(branch)

            # Add to branch_columns if we successfully extracted a schema
            # Store as (branch_index, columns) tuple to preserve original branch numbering
            if columns is not None:
                branch_columns.append((branch_idx, columns))

            all_results.extend(branch_results)

        # Validate that all branches have the same column names
        if branch_columns and len(branch_columns) > 1:
            first_branch_idx, first_columns = branch_columns[0]
            for branch_idx, cols in branch_columns[1:]:
                if cols != first_columns:
                    # Column mismatch - raise error
                    # Use 1-based numbering for user-facing error messages
                    first_branch_num = first_branch_idx + 1
                    current_branch_num = branch_idx + 1
                    missing_in_branch = first_columns - cols
                    extra_in_branch = cols - first_columns
                    error_parts = []
                    if missing_in_branch:
                        msg = (
                            f"missing columns {sorted(missing_in_branch)} "
                            f"in branch {current_branch_num}"
                        )
                        error_parts.append(msg)
                    if extra_in_branch:
                        msg = (
                            f"extra columns {sorted(extra_in_branch)} "
                            f"in branch {current_branch_num}"
                        )
                        error_parts.append(msg)
                    error_msg = (
                        f"All sub queries in an UNION must have the same column names "
                        f"(branch {first_branch_num} vs branch {current_branch_num}): "
                        f"{'; '.join(error_parts)}"
                    )
                    raise ValueError(error_msg)

        # UNION (not UNION ALL) requires deduplication
        if not op.all:
            # Convert to hashable representations for deduplication
            seen: set[tuple[Any, ...]] = set()
            deduplicated: list[Any] = []
            for row in all_results:
                key: tuple[Any, ...]
                if isinstance(row, ExecutionContext):
                    # Hash based on bindings
                    key = tuple(
                        sorted((k, self._value_to_hashable(v)) for k, v in row.bindings.items())
                    )
                else:
                    # Dict result (from RETURN)
                    key = tuple(sorted((k, self._value_to_hashable(v)) for k, v in row.items()))

                if key not in seen:
                    seen.add(key)
                    deduplicated.append(row)
            return deduplicated

        return all_results

    def _execute_call(self, op, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute Call operator (for CALL { } subqueries).

        Executes a nested query pipeline for each input row, with variable scoping:
        - Correlated: Subquery inherits outer scope bindings and can return new variables
        - Used for CALL { } clauses that produce rows

        Args:
            op: Call operator with nested pipeline
            input_rows: Input execution contexts (outer query context)

        Returns:
            Execution contexts with combined bindings from outer and inner queries
        """
        from graphforge.planner.operators import Aggregate, Union

        result = []

        # Detect if this is a unit subquery (no Project/Aggregate/Union)
        # Unit subqueries produce exactly 1 row per input (execute side effects only)
        is_unit_subquery = not any(
            isinstance(nested_op, (Project, Aggregate, Union)) for nested_op in op.operators
        )

        for outer_ctx in input_rows:
            # Create subquery context with inherited bindings (correlated subquery)
            sub_ctx = ExecutionContext()
            sub_ctx.bindings = dict(outer_ctx.bindings)

            # Execute nested query pipeline
            sub_rows = [sub_ctx]
            for i, nested_op in enumerate(op.operators):
                sub_rows = self._execute_operator(nested_op, sub_rows, i, len(op.operators))

            if is_unit_subquery:
                # Unit subquery: always produce exactly 1 output row per input row
                # (Ignore sub_rows cardinality - just preserve outer bindings)
                combined_ctx = ExecutionContext()
                combined_ctx.bindings = dict(outer_ctx.bindings)
                result.append(combined_ctx)
            else:
                # Row-producing subquery: merge each sub_row with outer bindings
                # Dict from Project: merge returned columns into outer scope
                # ExecutionContext (non-unit): preserve cardinality
                for sub_row in sub_rows:
                    combined_ctx = ExecutionContext()
                    if isinstance(sub_row, dict):
                        # Dict from Project - merge returned columns into outer bindings
                        combined_ctx.bindings = {**outer_ctx.bindings, **sub_row}
                    else:
                        # ExecutionContext (no RETURN) - preserve outer bindings only
                        combined_ctx.bindings = dict(outer_ctx.bindings)
                    result.append(combined_ctx)

        return result

    def _execute_subquery(
        self, _op: Subquery, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute Subquery operator (for EXISTS/COUNT expressions).

        NOTE: This is a placeholder - subqueries are evaluated in expression context
        via evaluator.py, not as standalone operators.

        Args:
            _op: Subquery operator with nested pipeline (unused - placeholder)
            input_rows: Input execution contexts

        Returns:
            Input contexts unchanged
        """
        # Subqueries are evaluated as expressions, not operators
        return input_rows
