"""Tests for the Cavendo Python SDK."""
