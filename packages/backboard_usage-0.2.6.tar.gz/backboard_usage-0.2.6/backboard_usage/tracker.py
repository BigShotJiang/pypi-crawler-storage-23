"""
UsageTracker — send Backboard usage to the local UI with one line per agent.
"""
import asyncio
import json
import logging
import os

from .cost import estimate_cost

logger = logging.getLogger("backboard_usage")

try:
    import websockets
except ImportError:
    websockets = None

WS_URL = os.environ.get("USAGE_WS_URL", "ws://localhost:8765")
_SERVER_WARNED = False


class UsageTracker:
    """
    Use in your Backboard app to send usage to the local UI.

    Usage:
        tracker = UsageTracker()
        for agent_name, prompt in agents:
            response = await client.add_message(...)
            await tracker.record(response, agent=agent_name)
        await tracker.finish()
    """

    def __init__(self, ws_url: str | None = None):
        self.ws_url = ws_url or WS_URL
        self._ws = None
        self.by_agent: dict = {}
        self.by_model: dict = {}
        self.total_tokens = 0
        self.total_cost = 0.0

    async def _connect(self):
        global _SERVER_WARNED
        if self._ws is not None and getattr(self._ws, "open", True):
            return
        if websockets is None:
            raise RuntimeError("Install websockets: pip install websockets")
        try:
            self._ws = await websockets.connect(self.ws_url)
            _SERVER_WARNED = False
        except Exception:
            self._ws = None
            if not _SERVER_WARNED:
                _SERVER_WARNED = True
                logger.warning(
                    "Usage server not running at %s. Start with: backboard-usage-server",
                    self.ws_url,
                )

    def _extract(self, response, agent: str) -> tuple[int, float, str | None]:
        """Extract tokens, cost, and model from Backboard MessageResponse or similar."""

        def _get(obj, key, default=None):
            if obj is None:
                return default
            if hasattr(obj, "get") and callable(getattr(obj, "get")):
                v = obj.get(key, default)
                return default if v is None else v
            v = getattr(obj, key, default)
            return default if v is None else v

        inp = out = 0
        usage = _get(response, "usage")

        # 1. Check response.usage first (Backboard MessageResponse)
        if usage is not None:
            inp = _get(usage, "input_tokens") or _get(usage, "prompt_tokens") or 0
            out = _get(usage, "output_tokens") or _get(usage, "completion_tokens") or 0

        # 2. Fallback to top-level fields
        if inp == 0 and out == 0:
            inp = _get(response, "input_tokens") or _get(response, "prompt_tokens") or 0
            out = _get(response, "output_tokens") or _get(response, "completion_tokens") or 0

        tok = _get(response, "total_tokens") or (inp + out) or 0

        # Model: response.model_name, response.model_provider, llm_provider, or response.model (nested)
        model_name = _get(response, "model_name") or _get(response, "model")
        model_provider = _get(response, "model_provider") or _get(response, "llm_provider")
        if model_name is None and hasattr(response, "model") and response.model is not None:
            m = response.model
            model_name = _get(m, "name") or _get(m, "model_name")
            model_provider = model_provider or _get(m, "provider") or _get(m, "model_provider")
        model = None
        if model_name or model_provider:
            model = f"{model_provider}/{model_name}".strip("/") if model_provider and model_name else (model_name or model_provider)

        cost = _get(response, "cost")
        if cost is None:
            cost = estimate_cost(model, inp, out)
        return tok, cost, model

    async def record(self, response, agent: str):
        """Call after each add_message. Sends usage to the UI. Falls back to agent name only if extraction fails."""
        try:
            tok, cost, model = self._extract(response, agent)
        except Exception:
            await self.record_manual(agent)
            return
        if tok or cost:
            self.total_tokens += tok
            self.total_cost += cost
            self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
            self.by_agent[agent]["tokens"] += tok
            self.by_agent[agent]["cost"] += cost
            if model:
                self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})
                self.by_model[model]["tokens"] += tok
                self.by_model[model]["cost"] += cost
        else:
            self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
            if model:
                self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})

        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "usage",
                    "agent": agent,
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
            except Exception:
                pass

    async def record_manual(
        self,
        agent: str,
        tokens: int = 0,
        cost: float = 0.0,
        model: str | None = None,
    ):
        """Record usage when the Backboard response shape doesn't match. Use agent name + optional tokens/cost/model."""
        if tokens or cost:
            self.total_tokens += tokens
            self.total_cost += cost
        self.by_agent[agent] = self.by_agent.get(agent, {"tokens": 0, "cost": 0.0})
        self.by_agent[agent]["tokens"] += tokens
        self.by_agent[agent]["cost"] += cost
        if model:
            self.by_model[model] = self.by_model.get(model, {"tokens": 0, "cost": 0.0})
            self.by_model[model]["tokens"] += tokens
            self.by_model[model]["cost"] += cost
        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "usage",
                    "agent": agent,
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
            except Exception:
                pass

    async def finish(self):
        """Call at the end of your run."""
        await self._connect()
        if self._ws:
            try:
                await self._ws.send(json.dumps({
                    "event": "done",
                    "total_tokens": self.total_tokens,
                    "total_cost": round(self.total_cost, 4),
                    "by_agent": self.by_agent,
                    "by_model": self.by_model,
                }))
                await self._ws.close(code=1000)
            except Exception:
                pass
            self._ws = None
            await asyncio.sleep(0.15)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.finish()


def run_with_tracker(async_main):
    """
    Run an async function with a UsageTracker for Streamlit and other sync frameworks.
    Your async_main must accept (tracker, *args, **kwargs). finish() is called automatically.

    Example:
        async def my_flow(tracker, prompt):
            response = await client.add_message(prompt)
            await tracker.record(response, agent="Analyzer")
            return response
        result = run_with_tracker(my_flow)("Hello")
    """
    def sync_wrapper(*args, **kwargs):
        async def _run():
            tracker = UsageTracker()
            try:
                return await async_main(tracker, *args, **kwargs)
            finally:
                await tracker.finish()
        return asyncio.run(_run())
    return sync_wrapper
