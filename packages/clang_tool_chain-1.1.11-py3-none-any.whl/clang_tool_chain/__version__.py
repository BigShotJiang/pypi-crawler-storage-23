"""Version information for clang-tool-chain."""

__version__ = "1.1.11"
