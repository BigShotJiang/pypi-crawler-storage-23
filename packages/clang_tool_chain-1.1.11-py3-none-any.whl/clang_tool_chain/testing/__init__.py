"""Testing utilities for clang-tool-chain diagnostic tests."""

from clang_tool_chain.testing.diagnostic_runner import DiagnosticTest, DiagnosticTestSuite

__all__ = ["DiagnosticTest", "DiagnosticTestSuite"]
