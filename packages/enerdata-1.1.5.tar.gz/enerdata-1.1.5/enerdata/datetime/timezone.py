from pytz import timezone

TIMEZONE = timezone('Europe/Madrid')
