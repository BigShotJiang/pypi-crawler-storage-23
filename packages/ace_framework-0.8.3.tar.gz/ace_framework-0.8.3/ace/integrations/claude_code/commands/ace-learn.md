Learn from your latest Claude Code session.

Run ACE learning on the current session to extract reusable strategies:
```bash
ace-learn
```

This analyzes the full conversation and updates the project's skillbook with new insights.
The learned strategies will be automatically available in future sessions.

Show the user the output so they can see what was learned.
