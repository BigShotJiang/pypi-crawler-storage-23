Show ACE learned strategies.

Display all strategies that ACE has learned from your coding sessions:
```bash
ace-learn insights
```

This shows:
- All learned strategies organized by category
- Effectiveness scores (helpful/harmful counts)
- Strategy IDs (useful for removing specific strategies)

Show the user the output so they can review their learned strategies.
