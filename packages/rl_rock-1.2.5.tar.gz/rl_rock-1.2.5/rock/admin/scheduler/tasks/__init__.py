# rock/admin/scheduler/tasks/__init__.py
from rock.admin.scheduler.tasks.image_cleanup_task import ImageCleanupTask

__all__ = ["ImageCleanupTask"]
