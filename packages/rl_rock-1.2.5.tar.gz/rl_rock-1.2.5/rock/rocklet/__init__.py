__version__ = "1.2.17"


REMOTE_EXECUTABLE_NAME = "rocklet-remote"
PACKAGE_NAME = "rock"
