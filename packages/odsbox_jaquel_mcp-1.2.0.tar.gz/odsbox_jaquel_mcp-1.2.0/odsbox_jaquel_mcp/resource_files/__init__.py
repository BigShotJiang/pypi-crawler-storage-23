"""Resource files module."""
