import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="misty.zouwu",
    version="0.1.3",
    author="Misty.Paabo",
    author_email="d4e8@live.com",
    description="驺吾其形似虎，身具五彩斑纹，尾长过身，骑乘可日行千里，且不食活物。集成FastAPI、SQLModel 实现标准CRUD 操作API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/MistyPaabo/zuowu",
    packages=setuptools.find_packages(),
    entry_points={},
    python_requires='>=3.11',
)
