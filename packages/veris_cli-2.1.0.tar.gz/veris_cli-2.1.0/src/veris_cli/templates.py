"""Static file templates for veris init."""

DOCKERFILE_SANDBOX = """# Extends veris-gvisor base with your agent code
FROM gcr.io/veris-ai-dev/veris-gvisor:latest

# Copy agent code and dependencies
# NOTE: Build context is project root, so paths are relative to project root
# (even though this Dockerfile is in .veris/)
# TODO: Update these paths to match your project structure

# Copy dependency files (adjust based on your package manager)
COPY pyproject.toml /agent/
# COPY uv.lock /agent/  # Uncomment if using uv with lockfile
# COPY requirements.txt /agent/  # Or use requirements.txt
# COPY poetry.lock /agent/  # Or use poetry

# Copy your agent code
COPY app /agent/app

# Install dependencies
WORKDIR /agent
RUN uv sync --no-dev
# Or use: pip install -r requirements.txt
# Or use: poetry install --no-dev

# Copy veris configuration
COPY .veris/veris.yaml /config/veris.yaml

# Copy scenarios if you have any
# COPY scenarios /scenarios

WORKDIR /app
"""

VERIS_YAML = """# Veris simulation configuration
version: "1.0"

services:
  # TODO: Configure services your agent uses
  # Example:
  # - name: calendar
  #   dns_aliases:
  #     - www.googleapis.com
  #     - calendar.google.com

persona:
  modality:
    type: http  # or: ws, email
    # url: http://localhost:8000  # if needed

agent:
  code_path: /agent
  entry_point: app.main:app  # TODO: Update this
  port: 8000  # TODO: Update this
  environment: {}  # Environment variables loaded from .env.simulation
"""

ENV_SIMULATION = """# Environment variables for your agent
# These are loaded into the container at runtime

OPENAI_API_KEY=sk-your-key-here
# Add other env vars your agent needs
"""


def get_dockerfile_sandbox() -> str:
    """Get Dockerfile.sandbox template."""
    return DOCKERFILE_SANDBOX.strip()


def get_veris_yaml() -> str:
    """Get veris.yaml template."""
    return VERIS_YAML.strip()


def get_env_simulation() -> str:
    """Get .env.simulation template."""
    return ENV_SIMULATION.strip()
