#!/usr/bin/env bash
set -e

# Docker push script for Veris CLI
# Usage: docker_push.sh <image_uri> <registry> <username> <password>

IMAGE_URI="$1"
REGISTRY="$2"
USERNAME="$3"
PASSWORD="$4"

if [ -z "$IMAGE_URI" ] || [ -z "$REGISTRY" ] || [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "Usage: $0 <image_uri> <registry> <username> <password>"
    exit 1
fi

echo "Logging in to Docker registry..."
echo "  Registry: $REGISTRY"
echo "  Username: $USERNAME"
echo ""

# Login to registry
echo "$PASSWORD" | docker login -u "$USERNAME" --password-stdin "$REGISTRY"

echo ""
echo "Pushing Docker image..."
echo "  Image: $IMAGE_URI"
echo ""

# Push image
docker push "$IMAGE_URI"

echo ""
echo "✓ Image pushed successfully: $IMAGE_URI"
echo ""
echo "Note: Push credentials expire in 1 hour"
