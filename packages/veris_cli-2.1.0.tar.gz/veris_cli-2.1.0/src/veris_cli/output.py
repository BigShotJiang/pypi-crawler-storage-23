"""Rich formatting and output utilities."""

from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()


def print_success(message: str) -> None:
    """Print success message in green."""
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str) -> None:
    """Print error message in red."""
    console.print(f"[red]✗[/red] {message}")


def print_info(message: str) -> None:
    """Print info message."""
    console.print(message)


def print_environments_table(environments: list[dict[str, Any]]) -> None:
    """Print environments in a table."""
    table = Table(title="Environments")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Image Tag", style="blue")
    table.add_column("Created", style="magenta")

    for env in environments:
        table.add_row(
            env.get("id", ""),
            env.get("name", ""),
            env.get("status", ""),
            env.get("image_tag", ""),
            env.get("created_at", ""),
        )

    console.print(table)


def print_scenarios_table(scenarios: list[dict[str, Any]]) -> None:
    """Print scenarios in a table."""
    table = Table(title="Scenarios")
    table.add_column("ID", style="cyan")
    table.add_column("Title", style="green")
    table.add_column("Visibility", style="yellow")
    table.add_column("Description", style="white")

    for scenario in scenarios:
        desc = scenario.get("description") or ""
        table.add_row(
            scenario.get("id", ""),
            scenario.get("title", ""),
            scenario.get("visibility", ""),
            desc[:50] + "..." if len(desc) > 50 else desc,
        )

    console.print(table)


def print_runs_table(runs: list[dict[str, Any]]) -> None:
    """Print runs in a table."""
    table = Table(title="Runs")
    table.add_column("ID", style="cyan")
    table.add_column("Scenario", style="green")
    table.add_column("Environment", style="blue")
    table.add_column("Status", style="yellow")
    table.add_column("Created", style="magenta")

    for run in runs:
        table.add_row(
            run.get("id", ""),
            run.get("scenario_id", ""),
            run.get("environment_id", ""),
            run.get("status", ""),
            run.get("created_at", ""),
        )

    console.print(table)


def print_run_details(run: dict[str, Any]) -> None:
    """Print detailed run information."""
    console.print("\n[bold]Run Details[/bold]")
    console.print(f"ID: [cyan]{run.get('id', '')}[/cyan]")
    console.print(f"Scenario: [green]{run.get('scenario_id', '')}[/green]")
    console.print(f"Environment: [blue]{run.get('environment_id', '')}[/blue]")
    console.print(f"Status: [yellow]{run.get('status', '')}[/yellow]")
    console.print(f"Concurrency: {run.get('concurrency', '')}")
    console.print(f"Created: [magenta]{run.get('created_at', '')}[/magenta]")
    if run.get("completed_at"):
        console.print(f"Completed: [magenta]{run.get('completed_at', '')}[/magenta]")


def print_run_events(events: list[dict[str, Any]]) -> None:
    """Print run events/logs."""
    console.print("\n[bold]Run Events[/bold]\n")
    for event in events:
        timestamp = event.get("timestamp", "")
        event_type = event.get("event_type", "INFO")
        service = event.get("service", "")
        data = event.get("data", {})

        level_color = {
            "INFO": "blue",
            "WARNING": "yellow",
            "ERROR": "red",
            "SUCCESS": "green",
        }.get(event_type.upper(), "white")

        console.print(
            f"[dim]{timestamp}[/dim] [{level_color}]{service}:{event_type}[/{level_color}] {data}"
        )
