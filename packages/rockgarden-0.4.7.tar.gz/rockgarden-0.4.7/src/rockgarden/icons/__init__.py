"""Build-time icon resolution."""

from rockgarden.icons.resolver import configure_icons_dir, resolve_icon

__all__ = ["configure_icons_dir", "resolve_icon"]
