__version__ = "74.20260224"
GIT_REF = "df99000"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/df99000"