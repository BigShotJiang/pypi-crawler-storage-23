core-https
===============================================================================

This project/library contains common elements related to HTTP...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-https.svg
    :target: https://pypi.org/project/core-https/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-https/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-https/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-https/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-https/badge/?version=latest
    :target: https://readthedocs.org/projects/core-https/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-https
    uv pip install core-https  # Or using UV...


Features
===============================================================================

* **HTTP Status Codes & Methods** - Comprehensive enums with backward compatibility for Python < 3.11, including utility methods for status checking (is_success, is_error, etc.) and method properties (is_safe, is_idempotent, is_cacheable)
* **Status Classification** - ``StatusInfo`` enum for categorizing HTTP responses as success (1xx-3xx), error (4xx), or failure (5xx)
* **Exception Hierarchy** - Structured exception classes for handling HTTP errors with automatic status code mapping: ``AuthenticationException`` (401), ``AuthorizationException`` (403), ``RateLimitException`` (429), and ``RetryableException`` for temporary failures
* **HTTP Requesters** - Abstract interface (``IRequester``) with concrete implementations for multiple HTTP libraries (``requests``, ``urllib3``, ``aiohttp``), supporting connection pooling, timeouts, retries, and backoff strategies
* **Testing Utilities** - Base test classes and decorators for mocking HTTP requests/responses across different HTTP client libraries


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-https
    uv pip install core-https  # Or using UV...
    pip install -e ".[dev]"    # For development...

Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: shell

    # Unit tests (mocked, no network):
    python manager.py run-tests

    # Functional tests (real HTTP requests — requires network):
    python manager.py run-tests --test-type functional --pattern "*.py"

    # Coverage:
    python manager.py run-coverage


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_https``
6. Run security checks: ``bandit -r core_https``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-https.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-https
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-https/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-https/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-https/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
