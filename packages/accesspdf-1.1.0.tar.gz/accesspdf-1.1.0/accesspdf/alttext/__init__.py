"""Alt text management — sidecar files, injection, caching."""
