"""TUI review interface for alt text approval."""
