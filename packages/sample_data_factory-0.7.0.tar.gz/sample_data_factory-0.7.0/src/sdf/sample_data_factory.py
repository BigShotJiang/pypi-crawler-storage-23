from __future__ import annotations

import csv
import io
import tempfile
import zipfile
from datetime import date
from pathlib import Path
from typing import Any
from typing import Protocol
from xml.etree import ElementTree as ET

GOOGLE_DRIVE_FOLDER_MIME = "application/vnd.google-apps.folder"


class GoogleDriveInterface(Protocol):
    service: Any

    def list_children(self, folder_id: str) -> list[dict[str, str]]:
        pass

    def upload_file(self, local_path: Path, folder_id: str | None) -> str:
        pass


class SampleDataFactory:
    """Test helper for generating publication archives for URS and FIDE test flows."""

    def __init__(
        self,
        data_structure: dict,
        drive: GoogleDriveInterface | None,
        file_prefix: str,
        out_file_date: date,
        target_folder_id: str | None,
        sub_folder_name: Path | None,
    ):
        self.data_structure = data_structure
        self.drive = drive
        self.file_date = out_file_date
        self.file_prefix = file_prefix
        self.sub_folder_name = sub_folder_name
        self.target_folder_id = target_folder_id

        if self.drive is None and self.sub_folder_name is not None:
            raise ValueError("sub_folder_name requires a drive instance")
        if self.drive is None and self.target_folder_id is not None:
            raise ValueError("target_folder_id requires a drive instance")
        if self.drive is not None and self.target_folder_id is None:
            raise ValueError("target_folder_id is required when drive is provided")
        if self.sub_folder_name is not None and not isinstance(self.sub_folder_name, Path):
            raise TypeError("sub_folder_name must be a Path or None")

    def _build_csv_bytes(self) -> bytes:
        headers = self.data_structure["headers"]
        rows = self.data_structure["rows"]
        buffer = io.StringIO(newline="")
        writer = csv.writer(buffer, lineterminator="\n")
        writer.writerow(headers)
        writer.writerows(rows)
        return buffer.getvalue().encode("utf-8")

    def _build_fide_players_xml_bytes(self) -> bytes:
        players = self.data_structure["players"]
        root = ET.Element("playerslist")
        xml_filename = "players_list_xml_foa.xml"

        for player_data in players:
            player_element = ET.SubElement(root, "player")
            for key in sorted(player_data.keys()):
                value = player_data[key]
                field = ET.SubElement(player_element, key)
                field.text = value

        xml_bytes = ET.tostring(root, encoding="utf-8")
        output_buffer = io.BytesIO()
        with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as output_zip:
            output_zip.writestr(xml_filename, xml_bytes)
        return output_buffer.getvalue()

    def _create_sub_folder_if_needed(self, parent_folder_id: str, sub_folder_name: Path) -> str:
        current_parent_id = parent_folder_id
        folder_parts = [part for part in sub_folder_name.parts if part not in {"", "."}]

        for folder_name in folder_parts:
            subfolder_id = None
            for item in self.drive.list_children(current_parent_id):
                if item.get("name") == folder_name and item.get("mimeType") == GOOGLE_DRIVE_FOLDER_MIME:
                    subfolder_id = item.get("id")
                    break

            if not subfolder_id:
                folder_metadata = {
                    "mimeType": GOOGLE_DRIVE_FOLDER_MIME,
                    "name": folder_name,
                    "parents": [current_parent_id],
                }
                folder = (
                    self.drive.service.files()
                    .create(body=folder_metadata, fields="id", supportsAllDrives=True)
                    .execute()
                )
                subfolder_id = folder.get("id")

            current_parent_id = subfolder_id

        return current_parent_id

    def _csv_name(self) -> str:
        return f"{self.file_prefix}_{self._yymmdd()}.csv"

    def _upload_or_return_bytes(self, archive_bytes: bytes, archive_filename: str) -> str | bytes:
        if self.drive is None:
            return archive_bytes

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            zip_path = temp_path / archive_filename
            zip_path.write_bytes(archive_bytes)
            upload_folder_id = self.target_folder_id

            if self.sub_folder_name is not None:
                upload_folder_id = self._create_sub_folder_if_needed(upload_folder_id, self.sub_folder_name)

            file_id = self.drive.upload_file(local_path=zip_path, folder_id=upload_folder_id)

        return file_id

    def _yymmdd(self) -> str:
        return self.file_date.strftime("%y%m%d")

    def _zip_name(self) -> str:
        return f"{self.file_prefix}_{self._yymmdd()}.zip"

    def build(self) -> str | bytes:
        return self.build_urs_rating_pub_zip()

    def build_fide_players_list_zip(self) -> str | bytes:
        archive_bytes = self._build_fide_players_xml_bytes()
        archive_filename = "players_list_xml.zip"
        return self._upload_or_return_bytes(archive_bytes=archive_bytes, archive_filename=archive_filename)

    def build_urs_rating_pub_zip(self) -> str | bytes:
        archive_filename = self._zip_name()
        csv_bytes = self._build_csv_bytes()
        csv_filename = self._csv_name()
        output_buffer = io.BytesIO()

        with zipfile.ZipFile(output_buffer, "w", compression=zipfile.ZIP_DEFLATED) as output_zip:
            output_zip.writestr(csv_filename, csv_bytes)

        return self._upload_or_return_bytes(archive_bytes=output_buffer.getvalue(), archive_filename=archive_filename)
