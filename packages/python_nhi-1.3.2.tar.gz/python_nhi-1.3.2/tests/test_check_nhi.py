# Copyright 2025 NHI contributors
# 
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
# 
#      http://www.apache.org/licenses/LICENSE-2.0
# 
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import unittest

from nhi import is_nhi


class TestCheckNHI(unittest.TestCase):
    def test_valid_old_format_production_NHI_number(self):
        self.assertTrue(is_nhi("JBX3656"))
        self.assertTrue(is_nhi("AAA1116"))
        self.assertTrue(is_nhi("BBB2221"))

    def test_valid_old_format_NHI_test_number(self):
        self.assertTrue(is_nhi("JBX3656", allow_test_values=True))
        self.assertTrue(is_nhi("AAA1116", allow_test_values=True))
        self.assertTrue(is_nhi("BBB2221", allow_test_values=True))
        self.assertTrue(is_nhi("ZZZ0016", allow_test_values=True))
        self.assertTrue(is_nhi("ZZZ0024", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0067", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0075", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0083", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0091", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0105", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0113", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0121", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0130", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0148", allow_test_values=True))
        self.assertTrue(is_nhi("ZAA0156", allow_test_values=True))
        self.assertTrue(is_nhi("ZAC5361", allow_test_values=True))

    def test_valid_old_format_NHI_test_numbers_are_rejected(self):
        self.assertFalse(is_nhi("ZZZ0016"))
        self.assertFalse(is_nhi("ZZZ0024"))
        self.assertFalse(is_nhi("ZAA0067"))
        self.assertFalse(is_nhi("ZAA0075"))
        self.assertFalse(is_nhi("ZAA0083"))
        self.assertFalse(is_nhi("ZAA0091"))
        self.assertFalse(is_nhi("ZAA0105"))
        self.assertFalse(is_nhi("ZAA0113"))
        self.assertFalse(is_nhi("ZAA0121"))
        self.assertFalse(is_nhi("ZAA0130"))
        self.assertFalse(is_nhi("ZAA0148"))
        self.assertFalse(is_nhi("ZAA0156"))
        self.assertFalse(is_nhi("ZAC5361"))

    def test_valid_new_format_production_NHI_number(self):
        self.assertTrue(is_nhi("ABC12DS"))
        self.assertTrue(is_nhi("AAA11AU"))
        self.assertTrue(is_nhi("BBB22BQ"))
        self.assertTrue(is_nhi("XYZ89AK"))

    def test_valid_new_format_test_NHI_number(self):
        self.assertTrue(is_nhi("ABC12DS", allow_test_values=True))
        self.assertTrue(is_nhi("AAA11AU", allow_test_values=True))
        self.assertTrue(is_nhi("BBB22BQ", allow_test_values=True))
        self.assertTrue(is_nhi("XYZ89AK", allow_test_values=True))
        self.assertTrue(is_nhi("ZBN77VL", allow_test_values=True))
        self.assertTrue(is_nhi("ZZZ00AC", allow_test_values=True))
        self.assertTrue(is_nhi("ZDR69YX", allow_test_values=True))
        self.assertTrue(is_nhi("ZSC21TN", allow_test_values=True))
        self.assertTrue(is_nhi("ZZB30NH", allow_test_values=True))
        self.assertTrue(is_nhi("ZYZ81ZV", allow_test_values=True))
        self.assertTrue(is_nhi("ZVB97XQ", allow_test_values=True))
        self.assertTrue(is_nhi("ZRA29VA", allow_test_values=True))
        self.assertTrue(is_nhi("ZYX61YS", allow_test_values=True))

    def test_valid_new_format_test_NHI_numbers_are_rejected(self):
        self.assertFalse(is_nhi("ZBN77VL"))
        self.assertFalse(is_nhi("ZZZ00AC"))
        self.assertFalse(is_nhi("ZDR69YX"))
        self.assertFalse(is_nhi("ZSC21TN"))
        self.assertFalse(is_nhi("ZZB30NH"))
        self.assertFalse(is_nhi("ZYZ81ZV"))
        self.assertFalse(is_nhi("ZVB97XQ"))
        self.assertFalse(is_nhi("ZRA29VA"))
        self.assertFalse(is_nhi("ZYX61YS"))

    def test_no_digit_can_be_added_to_an_old_format_NHI_with_a_checksum_of_0_to_make_it_valid(self):
        for i in range(10):
            with self.subTest(i=i):
                self.assertFalse(is_nhi(f"AAA002{i}"))

    def test_invalid_old_format_NHI_numbers(self):
        self.assertFalse(is_nhi("ZZZ0044"))
        self.assertFalse(is_nhi("ZZZ0017"))
        self.assertFalse(is_nhi("DAB8233"))

        # Needs a checkdigit of 6
        self.assertFalse(is_nhi("JBX3650"))
        self.assertFalse(is_nhi("JBX3651"))
        self.assertFalse(is_nhi("JBX3652"))
        self.assertFalse(is_nhi("JBX3653"))
        self.assertFalse(is_nhi("JBX3654"))
        self.assertFalse(is_nhi("JBX3655"))
        self.assertFalse(is_nhi("JBX3657"))
        self.assertFalse(is_nhi("JBX3658"))
        self.assertFalse(is_nhi("JBX3659"))

    def test_invalid_new_format_NHI_numbers(self):
        self.assertFalse(is_nhi("ZZZ00AA", allow_test_values=True))
        self.assertFalse(is_nhi("ZZZ00AY", allow_test_values=True))
        self.assertFalse(is_nhi("ZVU27KY", allow_test_values=True))
        self.assertFalse(is_nhi("ZVU27KA", allow_test_values=True))

        self.assertFalse(is_nhi("ABC12DA"))
        self.assertFalse(is_nhi("AAA11AA"))
        self.assertFalse(is_nhi("BBB22BA"))
        self.assertFalse(is_nhi("XYZ89AA"))

    def test_random_strings_are_invalid(self):
        self.assertFalse(is_nhi("not an NHI"))
        self.assertFalse(is_nhi("!@#$%&*"))
        self.assertFalse(is_nhi("AAANNNC"))
        self.assertFalse(is_nhi("AAANNAC"))
        self.assertFalse(is_nhi("ZVU27K"))
        self.assertFalse(is_nhi("JBX365"))

        self.assertFalse(is_nhi("not an NHI", allow_test_values=True))
        self.assertFalse(is_nhi("!@#$%&*", allow_test_values=True))
        self.assertFalse(is_nhi("AAANNNC", allow_test_values=True))
        self.assertFalse(is_nhi("AAANNAC", allow_test_values=True))
        self.assertFalse(is_nhi("ZVU27K", allow_test_values=True))
        self.assertFalse(is_nhi("JBX365", allow_test_values=True))

    def test_is_nhi_is_case_insensitive(self):
        # Valid Cases
        self.assertTrue(is_nhi("jbX3656"))
        self.assertTrue(is_nhi("aaA1116"))
        self.assertTrue(is_nhi("bbB2221"))
        self.assertTrue(is_nhi("jbX3656", allow_test_values=True))
        self.assertTrue(is_nhi("aaA1116", allow_test_values=True))
        self.assertTrue(is_nhi("bbB2221", allow_test_values=True))
        self.assertTrue(is_nhi("zzZ0016", allow_test_values=True))
        self.assertTrue(is_nhi("zzZ0024", allow_test_values=True))
        self.assertTrue(is_nhi("zaA0067", allow_test_values=True))
        self.assertTrue(is_nhi("zaA0075", allow_test_values=True))
        self.assertTrue(is_nhi("zaA0083", allow_test_values=True))

        # Valid but test value
        self.assertFalse(is_nhi("zzZ0016"))
        self.assertFalse(is_nhi("zzZ0024"))
        self.assertFalse(is_nhi("zaA0067"))
        self.assertFalse(is_nhi("zaA0075"))
        self.assertFalse(is_nhi("zaA0083"))

        # Invalid cases
        self.assertFalse(is_nhi("zzZ00AA", allow_test_values=True))
        self.assertFalse(is_nhi("zzZ00AY", allow_test_values=True))
        self.assertFalse(is_nhi("zvU27KY", allow_test_values=True))
        self.assertFalse(is_nhi("zvU27KA", allow_test_values=True))

        # Wrong check digits
        self.assertFalse(is_nhi("abC12DA"))
        self.assertFalse(is_nhi("aaA11AA"))
        self.assertFalse(is_nhi("bbB22BA"))
        self.assertFalse(is_nhi("xyZ89AA"))


if __name__ == '__main__':
    unittest.main()
