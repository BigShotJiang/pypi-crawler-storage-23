# NHI

[![Repository](https://img.shields.io/badge/jamesansley%2Fnhi-102335?logo=codeberg&labelColor=07121A)](https://codeberg.org/jamesansley/nhi)
[![License](https://img.shields.io/badge/Apache--2.0-002d00?label=license)](https://codeberg.org/jamesansley/nhi/src/branch/main/LICENSE)
[![PyPi](https://img.shields.io/pypi/v/python-nhi)](https://pypi.org/project/python-nhi/)

A function to check strings against the New Zealand Ministry of Health NHI
Validation Routine.
Supports the old and new NHI number formats specified in
[HISO 10046:2025](https://www.tewhatuora.govt.nz/publications/hiso-100462025-consumer-health-identity-standard/).

## Install

```
pip install python-nhi
```

For the other versions of this library, see:
- [nhi on Hex (Elixir)](https://hex.pm/packages/nhi/0.0.1)
- [nhi on JSR (JavaScript)](https://jsr.io/@ansley/nhi)
- [nhi on Crates (Rust)](https://crates.io/crates/nhi)
- [nhi with Pkl](https://codeberg.org/jamesansley/nhi/src/branch/main/pkl)

## Usage

New format NHI values:

```python
from nhi import is_nhi

is_nhi("ABC12DS")  # True
is_nhi("ABC12D0")  # False
```

Old format NHI values:

```python
from nhi import is_nhi

is_nhi("AAA1116")  # True
is_nhi("AAA1110")  # False
```

By default, test NHI values (starting with 'Z') are rejected:

```python
from nhi import is_nhi

is_nhi("ZZZ00AC")  # False
```

Test values can be allowed with the allow_test_values flag:

```python
from nhi import is_nhi

is_nhi("ZZZ00AC", allow_test_values=True)  # True
```

## See Also

- https://www.tewhatuora.govt.nz/publications/hiso-100462025-consumer-health-identity-standard/
