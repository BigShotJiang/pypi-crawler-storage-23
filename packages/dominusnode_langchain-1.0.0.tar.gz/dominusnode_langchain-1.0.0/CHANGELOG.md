# Changelog

## 1.0.0 (2026-03-01)

- Initial release
- 5 LangChain tools: proxy fetch, wallet balance, top-up (Stripe), top-up (PayPal), usage stats
- DominusNodeToolkit for easy integration
- SSRF protection, credential scrubbing, OFAC compliance
