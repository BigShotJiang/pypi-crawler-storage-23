---
change: "clarify-ask-and-research"
updated: "2026-02-25T11:55"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Template Changes ✅
- [x] Fix `ask_service.py::create_ask_template` bug (`template` var scoping) `src/sspec/services/ask_service.py`
- [x] Update `src/sspec/templates/AGENTS.md` §3: rewrite consultation table (question-type-based)
- [x] Update `src/sspec/templates/skills/sspec-research/SKILL.md`: add "Consultation During Research" section
- [x] Update `.github/skills/sspec-research/SKILL.md`: sync dev skill with template
- [x] Reinstall (`uv pip install -e .`)
**Verification**: Files updated, ruff check passes, `sspec ask create` works

---

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |

**Recent**:
- All tasks completed 2026-02-25
