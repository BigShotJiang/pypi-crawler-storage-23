---
name: clarify-ask-and-research
status: DONE
type: ''
change-type: single
created: 2026-02-25 11:32:13
reference:
- source: .sspec/requests/26-02-25T10-55_ask.md
  type: request
  note: Linked from request
---
<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: single | sub
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>

Sub-change MUST link root:
reference:
  - source: ".sspec/changes/<root-change-dir>"
    type: "root-change"
    note: "Phase <n>: <phase-name>"

Single-change common reference:
reference:
  - source: ".sspec/requests/<request-file>.md"
    type: "request"
-->

# clarify-ask-and-research

## A. Problem Statement

The SSPEC protocol had two gaps in its `@ask` guidance:

1. **§3 Consultation decision rule was misleading**: The key "Need persistent record?" is mechanistic and fails to explain *why* one tool is chosen over another. The real distinction is question type/complexity — simple bounded questions → `question` tool; complex design-grade questions → `sspec ask`.

2. **Research phase had no consultation pattern**: The `sspec-research` SKILL described a "curious + thorough" stance but gave no guidance on what to do when ambiguities arise *during* research. The only hint was at the exit criteria — far too late when a fundamental requirement is unclear.

## B. Proposed Solution

### Approach

Two targeted template edits with no code changes needed (except a bug fix discovered along the way).

### Key Design

**AGENTS.md §3**: Replace the "Need persistent record?" decision table with a question-type-based guide:
- Simple/bounded → `question` tool
- Complex/design-grade/tradeoffs → `sspec ask`
- Phase gates → `sspec ask` (mandatory)
- Mid-research → `question` tool
- Clarify "write to tmp" rule: for complex reusable content/context, not just long questions

**sspec-research SKILL.md**: Add "Consultation During Research" section:
- Explicitly describe when to ask mid-research (ambiguous requirements, unclear intent, etc.)
- Pattern: `question` for in-flight; batch with `sspec ask` at end
- Key rule: never defer critical ambiguity to design phase

**Bug fix (incidental)**: `ask_service.py::create_ask_template` — `template` variable was defined inside `if yml_path.exists():` block but used after it, causing `UnboundLocalError` for new (non-conflicting) filenames.
