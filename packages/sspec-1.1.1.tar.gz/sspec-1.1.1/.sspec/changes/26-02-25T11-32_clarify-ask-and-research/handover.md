# Handover: clarify-ask-and-research

**Updated**: 2026-02-25T11:55

---

## Background

Clarified `@ask` tooling guidance in SSPEC: rewrote §3 Consultation from record-based to question-type-based decision, and added mid-research consultation patterns to the `sspec-research` SKILL. Also fixed a bug in `ask_service.py`.

## This Session

### Accomplished
- Fixed `ask_service.py` bug: `template` var was scoped inside `if` block, causing `UnboundLocalError` for all new asks
- Updated `src/sspec/templates/AGENTS.md` §3: new question-type table, clarified "write to tmp" rule, updated Research row in phase table and lifecycle diagram
- Updated `src/sspec/templates/skills/sspec-research/SKILL.md`: added "Consultation During Research" section
- Updated `.github/skills/sspec-research/SKILL.md`: synced dev skill

### Next Steps
- DONE — change complete. Archive when convenient: `sspec change archive .sspec/changes/26-02-25T11-32_clarify-ask-and-research`

## Working Memory

### Key Files
- `src/sspec/templates/AGENTS.md` — §3 Consultation fully rewritten
- `src/sspec/templates/skills/sspec-research/SKILL.md` — added consultation section at end
- `src/sspec/services/ask_service.py` — bug fix at line ~215: moved `template` assignment outside `if` block

### Decisions
- **Question-type vs record-based**: Chose to pivot the decision criteria from "persistent record?" to "question type/complexity" — better captures the real reason for choosing one tool over the other
- **"Write to tmp" rule**: Clarified it's for complex reusable content/context (design drafts, analysis), not just question length

### Notes
- The bug in `ask_service.py` was discovered when trying to run `sspec ask create` during this session
- `.github/skills/` = dev-time skills (for agents working on sspec itself); `src/sspec/templates/skills/` = user-facing (distributed via `sspec project init`). Both updated to stay in sync.
