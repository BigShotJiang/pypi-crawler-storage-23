# Handover: tools

**Updated**: 2026-02-12

---

## Background

Implemented `sspec tool` command group with minimal interface specification. First tool: `patch` for applying SEARCH/REPLACE patches. Enables CLI access to builtin development utilities with rich interactive UX.

## Accomplished This Session

1. Designed minimal Tool Interface 1.0 (via 3 rounds of `sspec ask` discussion)
2. Modified `src/sspec/builtin_tools/apply_patch.py` (renamed from apply-patch.py):
   - Added TOOL_NAME, TOOL_DESCRIPTION, TOOL_PROMPT constants
   - Implemented register_command() with full CLI logic
3. Created `src/sspec/commands/tool.py` with manual tool registration
4. Registered tool command group in `src/sspec/cli.py`
5. Created write-patch SKILL (`.github/skills/write-patch/SKILL.md`)
6. Created test files and verified all features work
7. Created spec-doc at `.sspec/spec-docs/builtin-tools.md` for future tool authors

## Current Status

**DONE** — All implementation complete, spec-doc created, user approved

## Next Steps

Change complete. No further action needed.

## References & Memory

### Key Files

- `src/sspec/builtin_tools/apply_patch.py` — Core patch engine + Tool Interface implementation (register_command, TOOL_* constants)
- `src/sspec/commands/tool.py` — CLI command group, manual tool registration
- `src/sspec/cli.py` — Registered tool command in main CLI
- `.github/skills/write-patch/SKILL.md` — SKILL guiding Agents to use patch workflow
- `.sspec/changes/archive/26-02-12T01-19_tools/reference/` — Design philosophy and interface spec docs
- `.sspec/asks/archive/260212013642_tool_interface_spec.md` — Final approved interface design

### Decisions & Rationale

- **No registration mechanism, direct hardcoded subcommands**
  **Why**: YAGNI principle — only 1 tool now, no need for plugin system. Future extensibility via simple pattern: import + `tool.register_command()`. Separates from cmd's data-driven approach (YAML registry) → concepts stay clear.

- **Tool Interface 1.0: TOOL_NAME/DESCRIPTION/PROMPT + register_command()**
  **Why**: Minimal but extensible. Now gets simplicity, future gets 3-line switch to auto-discovery. Each tool is self-contained module. Balances current needs with future expansion.

- **--prompt flag instead of embedding in --help**
  **Why**: TOOL_PROMPT can be long (specification + examples). Embedding in help clutters output. Separate flag keeps help concise while making spec accessible for LLM copy-paste.

- **find_sspec_root() returns .sspec dir, need .parent for project root**
  **Why**: Common gotcha — find_sspec_root() returns `.sspec/` path, but patch engine needs project root. Fixed in register_command with `sspec_root.parent`.

- **SKILL focuses on workflow, not format details**
  **Why**: User feedback — SKILL must guide Agents to *use* patches for multi-file changes, not just teach format. Format details available via `--prompt`. SKILL emphasizes "generate patch file → apply with CLI → verify".

### Gotchas & Context

- File renamed: `apply-patch.py` → `apply_patch.py` (user correction during session)
- Windows terminal encoding issue with Rich output (✓ ✗ characters fail in GBK) — not critical, users can set PYTHONIOENCODING=utf-8
- Rich output dependencies: Console, Table — imported inside register_command() to avoid top-level import cycles
- Test files in `tmp/test_tool_patch/` (success.patch, failure.patch, mixed.patch)
- Failed patches auto-saved to `.sspec/tmp/failed-patches/<timestamp>/` with reconstructed SEARCH/REPLACE blocks
