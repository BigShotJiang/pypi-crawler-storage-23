# Tool 接口规范（Minimal 1.0）

## 设计原则

**Minimal but extensible**:
- 现在保持最简（only patch tool）
- 接口设计为可扩展（future: auto-discovery, multi-tool）

## Proposed Interface

每个 tool 模块（`builtin_tools/<name>.py`）提供：

### 1. Module Attributes（必需）

```python
# builtin_tools/apply_patch.py

# Tool metadata
TOOL_NAME = "patch"
TOOL_DESCRIPTION = "Apply SEARCH/REPLACE format patches to files"

# Full specification (shown with --prompt option)
TOOL_PROMPT = """
<DETAILED SPECIFICATION HERE>
Including:
- Format examples
- Usage patterns
- Rules and constraints
"""
```

### 2. Registration Function（必需）

```python
def register_command(group: click.Group) -> None:
    """Register this tool as a Click subcommand."""

    @group.command(name=TOOL_NAME, help=TOOL_DESCRIPTION)
    @click.argument('patch_file', type=click.Path(exists=True, path_type=Path))
    @click.option('--dry-run', is_flag=True, help='Preview without applying')
    @click.option('--output-failed', type=click.Path(path_type=Path))
    @click.option('--yes', is_flag=True, help='Skip confirmation')
    @click.option('--prompt', is_flag=True, help='Show format specification')
    def patch_command(patch_file, dry_run, output_failed, yes, prompt):
        if prompt:
            from rich.console import Console
            Console().print(TOOL_PROMPT)
            return

        # Actual logic
        ...
```

### 3. Core Functions（实现细节）

工具的核心逻辑函数（如 `apply_patches()`），不强制命名，自由设计。

## Tool Discovery（当前 & 未来）

### 当前（Manual）
```python
# commands/tool.py
from sspec.builtin_tools import apply_patch

@click.group()
def tool():
    """Builtin development tools."""
    pass

# Manually register
apply_patch.register_command(tool)
```

### 未来（Auto-discovery，可选扩展）
```python
# commands/tool.py
from pathlib import Path
import importlib

@click.group()
def tool():
    """Builtin development tools."""
    pass

# Auto-discover and register all tools
tools_dir = Path(__file__).parent.parent / 'builtin_tools'
for module_file in tools_dir.glob('*.py'):
    if module_file.stem.startswith('_'):
        continue

    module = importlib.import_module(f'sspec.builtin_tools.{module_file.stem}')
    if hasattr(module, 'register_command'):
        module.register_command(tool)
```

**判断**: 现在手动注册就够，未来需要时 3 行代码切换到自动发现。

## Prompt Display Design

### Option A: In --help
```bash
$ sspec tool patch --help

Usage: sspec tool patch [OPTIONS] PATCH_FILE

  Apply SEARCH/REPLACE format patches to files

  Format Specification:
  ... (TOOL_PROMPT content)
```

❌ **问题**: --help 内容过长（TOOL_PROMPT 可能很长）

### Option B: Separate --prompt flag
```bash
$ sspec tool patch --help
... (normal help, concise)

$ sspec tool patch --prompt
<Full TOOL_PROMPT specification>
```

✅ **推荐**: 分离关注点，用户按需获取详细规范

### Option C: Hybrid
```bash
$ sspec tool patch --help
...
Options:
  --prompt  Show detailed format specification and examples
```

✅ **最佳**: 在 --help 中提示 --prompt，保持清晰

## Summary

**Minimal Interface (现在实现)**:
```python
# 每个 tool 模块提供：
TOOL_NAME: str
TOOL_DESCRIPTION: str
TOOL_PROMPT: str (详细规范)
register_command(group: click.Group) -> None
```

**Registration (现在手动，未来可扩展)**:
```python
# commands/tool.py
apply_patch.register_command(tool)  # 手动，清晰
```

**Prompt Display (混合方式)**:
- `--help`: 简洁帮助 + 提示 --prompt
- `--prompt`: 完整规范（TOOL_PROMPT）

## 实现要点

### builtin_tools/apply_patch.py 需要改动

```python
# 文件头部添加
TOOL_NAME = "patch"
TOOL_DESCRIPTION = "Apply SEARCH/REPLACE format patches to files"
TOOL_PROMPT = PATCH_PROMPT  # 已有的 PATCH_PROMPT 常量

# 文件底部添加
def register_command(group: click.Group) -> None:
    """Register patch command."""
    import click
    from pathlib import Path
    from rich.console import Console

    @group.command(name=TOOL_NAME, help=TOOL_DESCRIPTION)
    @click.argument('patch_file', type=click.Path(exists=True, path_type=Path))
    @click.option('--dry-run', is_flag=True, help='Preview without applying')
    @click.option('--output-failed', type=click.Path(path_type=Path),
                  help='Directory for failed patches (default: .sspec/tmp/failed-patches/<timestamp>)')
    @click.option('--yes', is_flag=True, help='Skip confirmation')
    @click.option('--prompt', is_flag=True, help='Show detailed format specification')
    def patch_command(patch_file, dry_run, output_failed, yes, prompt):
        # 实现逻辑（见下）
        ...
```

### commands/tool.py 简洁清晰

```python
"""sspec tool command - builtin development tools."""

import click
from sspec.builtin_tools import apply_patch

@click.group()
def tool() -> None:
    """Builtin development tools."""
    pass

# Register tools (manual for now, clear and explicit)
apply_patch.register_command(tool)
```

未来添加新工具：
```python
from sspec.builtin_tools import apply_patch, code_gen, refactor

apply_patch.register_command(tool)
code_gen.register_command(tool)
refactor.register_command(tool)
```

## Benefit Analysis

### 现在得到什么
1. ✅ 清晰的最小接口（4 个属性/函数）
2. ✅ 工具自包含（metadata + CLI + logic）
3. ✅ Prompt 规范可访问（--prompt）
4. ✅ 手动注册简单明了

### 未来可扩展什么
1. 🔮 自动发现工具（3 行代码切换）
2. 🔮 工具列表命令（`sspec tool list`）
3. 🔮 工具验证（check TOOL_* 属性存在）
4. 🔮 插件机制（third-party tools）

**判断**: Minimal 1 设计正确，未来 +1 水到渠成。
