# Tool 设计哲学重新思考

## 第一性原理分析

### 问题本质
1. **现状**: `builtin_tools/apply-patch.py` 存在但无 CLI 入口
2. **需求**: 用户希望通过 `sspec tool patch <file>` 使用它
3. **未来**: 可能添加更多通用开发工具

### 核心问题（用户反馈）
1. Tool 是否需要注册机制？
2. Tool 和 cmd 的区别是什么？会不会概念混淆？

## 深入分析

### Option A: 无注册机制，直接硬编码
```python
# commands/tool.py
@click.group()
def tool():
    """Builtin development tools."""
    pass

@tool.command()
@click.argument('patch_file')
def patch(patch_file):
    """Apply SEARCH/REPLACE patch."""
    from sspec.builtin_tools.apply_patch import apply_patches
    # ... 直接调用
```

**优点**:
- 简单直接，KISS 原则
- 无需额外抽象
- 添加新工具 = 添加新子命令

**缺点**:
- 每个工具都要手写 Click boilerplate
- 如果未来工具很多（>10个），commands/tool.py 会很长

### Option B: 插件/注册机制
```
builtin_tools/
├── __init__.py  # 注册表
├── apply_patch.py
└── code_gen.py  # 未来的工具
```

每个工具模块提供 `register_command(group)` 函数。

**优点**:
- 扩展性强
- 工具自包含（命令 + 逻辑）

**缺点**:
- 过度设计（现在只有 1 个工具）
- 复杂度高
- 和 cmd 的机制相似但独立，概念混乱

### 我的判断: **Option A 足够**

理由：
1. **YAGNI**: 现在只有 patch，不需要为"未来可能"过度设计
2. **简单优先**: 直接子命令清晰明了
3. **和 cmd 的区别清晰**:
   - `cmd`: 用户注册的 project-specific 命令（数据在 `.sspec/commands.yaml`）
   - `tool`: 硬编码的 builtin 子命令（代码在 `commands/tool.py`）
   - 完全不同的机制，不会混淆

## Redesign: Tool = 简单的子命令集合

### 架构
- `commands/tool.py`: 包含所有 tool 子命令（硬编码，无注册）
- 每个子命令直接调用对应的 `builtin_tools/` 模块
- **无需** service 层（过度封装）
- **无需** 注册机制

### Patch 命令详细设计

#### CLI 接口
```bash
sspec tool patch <patch-file> [OPTIONS]

Arguments:
  patch-file  Path to the patch file (SEARCH/REPLACE format)

Options:
  --dry-run              Show what would be changed without applying
  --output-failed DIR    Save failed patches to custom directory
                         (default: .sspec/tmp/failed-patches/<timestamp>)
  --yes / --no-yes       Skip confirmation prompt (default: --no-yes)
  -h, --help            Show this message and exit
```

#### 交互流程
1. **读取 patch 文件**
   - 验证文件存在
   - 读取内容

2. **解析 patches**（调用 `apply-patch.py:parse_patches()`）
   - 如果解析失败 → 显示错误，退出

3. **显示预览**（如果 --dry-run 或不带 --yes）
   ```
   Found 3 patches:
     ✓ src/core.py (L10-L25)
     ✓ src/utils.py
     ✓ tests/test_core.py (L50-L60)

   Apply these patches? [y/N]:
   ```

4. **应用 patches**（调用 `apply-patch.py:apply_patches()`）
   - 显示进度条（Rich）
   - 收集结果

5. **显示结果**
   - 成功表格（绿色 ✓）
   - 失败表格（红色 ✗）
   - 保存失败的 patches 到 output 目录，显示路径

6. **退出码**
   - 0: 全部成功
   - 1: 部分或全部失败

#### 示例输出
```
Parsing patch file: patches/fix-typo.md
✓ Found 3 patches

Applying patches...
  [████████████████████░░░░] 60% (2/3)

Results:
┏━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ File               ┃ Status  ┃ Note                          ┃
┡━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ src/core.py        │ ✓       │ Applied                       │
│ src/utils.py       │ ✗       │ No match found                │
│ tests/test_core.py │ ✓       │ Applied                       │
└────────────────────┴─────────┴───────────────────────────────┘

Summary: 2 succeeded, 1 failed
Failed patches saved to: .sspec/tmp/failed-patches/2026-02-12T01-30-45/
```

## 实现要点

### commands/tool.py（改进后）
```python
import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.progress import track
from sspec.builtin_tools.apply_patch import apply_patches, PatchApplyResult

console = Console()

@click.group()
def tool():
    """Builtin development tools."""
    pass

@tool.command()
@click.argument('patch_file', type=click.Path(exists=True, path_type=Path))
@click.option('--dry-run', is_flag=True, help='Preview without applying')
@click.option('--output-failed', type=click.Path(path_type=Path),
              help='Custom directory for failed patches')
@click.option('--yes', is_flag=True, help='Skip confirmation')
def patch(patch_file: Path, dry_run: bool, output_failed: Path | None, yes: bool):
    """Apply SEARCH/REPLACE format patches."""

    # 1. 读取 patch 文件
    patch_text = patch_file.read_text(encoding='utf-8')

    # 2. 解析 patches
    from sspec.builtin_tools.apply_patch import parse_patches
    parse_result = parse_patches(patch_text)

    if parse_result.errors:
        console.print("[red]Parsing errors:[/red]")
        for err in parse_result.errors:
            console.print(f"  • {err}")
        raise click.Abort()

    console.print(f"[green]✓[/green] Found {len(parse_result.patches)} patches\n")

    # 3. 预览（如果需要）
    if not yes and not dry_run:
        # 显示预览表格
        # ...
        if not click.confirm("Apply these patches?"):
            raise click.Abort()

    if dry_run:
        console.print("[yellow]Dry-run mode: no changes will be applied[/yellow]")
        return

    # 4. 应用 patches
    results = apply_patches(patch_text)

    # 5. 显示结果 + 保存失败的 patches
    _display_results(results)
    _save_failed_patches(results, output_failed)
```

### 关键函数
- `_display_results(results)`: 使用 Rich Table 显示结果
- `_save_failed_patches(results, output_dir)`: 保存失败的 patches 到文件
- 无需 service 层，逻辑直接在 command 中

## 总结

**最简设计**:
1. Tool = 硬编码的 Click 子命令集合
2. 无注册机制，无 service 层
3. 直接调用 builtin_tools 模块
4. 详细的交互设计（预览、进度、结果表格）

**和 cmd 的区别**:
- cmd: 用户数据驱动（YAML 注册表）
- tool: 代码驱动（硬编码子命令）

完全不同的实现方式，概念清晰，不会混淆。
