---
change: "tools"
updated: ""
---

# Implementation Tasks

## Legend
`[ ]` Todo | `[x]` Done (implemented + verified)

## Tasks

### Phase 1: Tool Interface in apply_patch.py ✅
- [x] Add `TOOL_NAME`, `TOOL_DESCRIPTION`, `TOOL_PROMPT` constants to apply_patch.py
- [x] Create `register_command(group)` function skeleton in apply_patch.py
**Verification**: Module loads without errors, constants accessible

### Phase 2: CLI Command Group ✅
- [x] Create `src/sspec/commands/tool.py` with Click group
- [x] Import and register apply_patch tool in tool.py
- [x] Register tool command group in `src/sspec/cli.py`
**Verification**: `uv run sspec tool --help` works

### Phase 3: Rich Output & Error Handling ✅
- [x] Implement full patch command logic in register_command()
- [x] Add Rich progress bar and summary table
- [x] Implement failed patch output to `.sspec/tmp/failed-patches/<timestamp>/`
- [x] Add all CLI options: --dry-run, --output-failed, --yes, --prompt
**Verification**: Apply test patch, verify all features work

### Phase 4: Write-Patch SKILL ✅
- [x] Read skill-creator and existing sspec skills for style reference
- [x] Create `.github/skills/write-patch/SKILL.md`
- [x] Fill in description, triggers, content (based on PATCH_PROMPT)
**Verification**: SKILL is clear and follows conventions

### Phase 5: Testing & Validation ✅
- [x] Create test patch files in `tmp/test_tool_patch/`
- [x] Test success scenario
- [x] Test failure scenario with output verification
- [x] Test --dry-run mode
- [x] Test --prompt option
**Verification**: All scenarios work as expected

---

## Progress
<!-- @REPLACE -->

<!-- @RULE: Update percentage and status after EACH task completion.
Use 🚧 (in progress), ✅ (done), ⏳ (pending).
CLI `sspec change status` auto-calculates from checkboxes — keep tasks.md as source of truth. -->

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |
| Phase 5 | 100% | ✅ |

**Recent**:
- 2026-02-12: All phases completed, testing verified, SKILL refined
