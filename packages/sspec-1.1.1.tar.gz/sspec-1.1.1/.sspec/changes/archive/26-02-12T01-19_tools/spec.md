---
name: tools
status: DONE
type: ''
change-type: single
created: 2026-02-12 01:19:25
reference:
- source: .sspec/requests/archive/26-02-12T00-50_tools.md
  type: request
  note: Archived request
- source: .sspec/asks/archive/260212012158_tools_design_approval.md
  type: ask
  note: Initial design discussion
- source: .sspec/asks/archive/260212012656_tools_redesign_philosophy.md
  type: ask
  note: Tool positioning and architecture clarification
- source: .sspec/asks/archive/260212013642_tool_interface_spec.md
  type: ask
  note: Minimal interface specification approval
- source: .sspec/asks/archive/260212021901_tools_completion_review.md
  type: ask
  note: Final completion review and approval
- source: .sspec/spec-docs/builtin-tools.md
  type: doc
  note: Tool mechanism specification for future tool authors
archived: '2026-02-24T23:38:34'
---
<!-- @RULE: Frontmatter Type
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: single | sub (sub if part of a root change);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
 -->

# tools

## A. Problem Statement

### Current Situation
- `apply-patch.py` exists in `builtin_tools/` but lacks CLI entry point — users must import it programmatically
- No unified discovery mechanism for builtin tools — tools are scattered and not easily accessible
- Future tools (code generators, refactoring helpers) will face same discoverability issue

### User Requirement
- Unified `sspec tool` command to access builtin development utilities
- Strong interactivity: friendly prompts, rich progress output, clear failure reporting
- Strong specification: standardized tool interfaces, not ad-hoc scripts
- Distinct from `sspec cmd` (project-level lightweight scripts) — tools are builtin, cross-project, with enhanced UX

## B. Proposed Solution

### Approach
Create `sspec tool` command group with a **minimal but extensible interface specification**. First tool: `patch` for applying SEARCH/REPLACE patches.

**Tool Interface 1.0** (each tool module provides):
- `TOOL_NAME`, `TOOL_DESCRIPTION`, `TOOL_PROMPT`: metadata and specification
- `register_command(group)`: Click command registration function
- Tools are self-contained (metadata + CLI + logic in one module)

**Why this interface?**
- **Now**: Simple (4 interfaces), clear, hand-coded registration
- **Future**: 3-line switch to auto-discovery, plugin system, tool listing

**Registration Strategy**:
- Current: Manual registration in `commands/tool.py` (explicit, clear)
- Future: Auto-discovery via importlib (when needed, minimal change)

**Prompt Display**:
- `sspec tool patch --help`: Concise help
- `sspec tool patch --prompt`: Full TOOL_PROMPT specification (for LLM consumption)
- Separates concerns, keeps help clean

**Additional Deliverable**:
- Write-patch SKILL (`.github/skills/write-patch/SKILL.md`) for LLM guidance

### Key Changes
- **Modify**: `src/sspec/builtin_tools/apply_patch.py` — Add TOOL_* constants and register_command()
- **New**: `src/sspec/commands/tool.py` — CLI command group with manual registration
- **Modify**: `src/sspec/cli.py` — Register tool command group
- **New**: `.github/skills/write-patch/SKILL.md` — SKILL for writing patches

## C. Implementation Strategy

### Phase 1: Tool Interface in apply_patch.py
- `src/sspec/builtin_tools/apply_patch.py` — modify, add TOOL_NAME/DESCRIPTION/PROMPT constants
- `src/sspec/builtin_tools/apply_patch.py` — modify, add register_command() function with full CLI implementation

### Phase 2: CLI Command Group
- `src/sspec/commands/tool.py` — create, Click group + manual tool registration
- `src/sspec/cli.py` — modify, register tool command group

### Phase 3: Rich Output & Error Handling
- `src/sspec/builtin_tools/apply_patch.py` — enhance register_command() with:
  - Rich progress display
  - Success/failure summary table
  - Failed patch output to `.sspec/tmp/failed-patches/<timestamp>/`
  - `--dry-run`, `--output-failed`, `--yes`, `--prompt` options

### Phase 4: Write-Patch SKILL
- `.github/skills/write-patch/SKILL.md` — create, guide for writing patches (reference PATCH_PROMPT + skill-creator style)

### Phase 5: Testing & Validation
- `tmp/test_tool_patch/` — create test scenarios (success, failure, dry-run)
- Verify all options work correctly

### Risks & Dependencies
- **None**: Reuses existing apply-patch logic
- **Note**: `.sspec/tmp/` auto-creation already handled in other commands

## D. Blockers & Feedback

(none yet)
