---
name: built-in-toc
status: REVIEW
type: ''
change-type: single
created: 2026-02-22 15:11:27
reference:
- source: .sspec/requests/archive/26-02-22T15-02_built-in-toc.md
  type: request
  note: Linked from request
archived: '2026-02-24T23:38:33'
---
<!-- @RULE: Frontmatter Schema
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: single | sub (sub if part of a root change);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
📚 Full schema details: sspec-change SKILL → doc-standards.md
 -->

# built-in-toc

## A. Problem Statement

Agents reading Markdown documents lack outline information — no way to know document size or structure before reading. This causes inefficient chunked reads without context.

## B. Proposed Solution

### Approach

Add `mdtoc` as a builtin tool under `sspec tool mdtoc`. It accepts a `source` (file, directory, or glob) and outputs per-file: path, char/line counts, and a TOC with 1-based line numbers (`L<n>` format). Enables Agents to pre-scan docs before reading.

### Interface Design

```
sspec tool mdtoc <source> [--depth N] [--prompt]
```

- `source`: file path | directory (glob all .md) | glob pattern
- `--depth`: max heading level (default 6)
- Output: file path header, `chars: X | lines: Y`, then indented TOC entries

### Key Changes

- `src/sspec/builtin_tools/mdtoc.py` — new module
- `src/sspec/commands/tool.py` — register mdtoc
- `src/sspec/templates/skills/sspec-mdtoc/SKILL.md` — new skill template

## C. Implementation Strategy

### Phase 1: Tool Implementation
- `src/sspec/builtin_tools/mdtoc.py` — create with TOOL_NAME/DESCRIPTION/PROMPT/register_command
- `src/sspec/commands/tool.py` — modify, add mdtoc import + registration
- `src/sspec/templates/skills/sspec-mdtoc/SKILL.md` — create skill template

## D. Blockers & Feedback

