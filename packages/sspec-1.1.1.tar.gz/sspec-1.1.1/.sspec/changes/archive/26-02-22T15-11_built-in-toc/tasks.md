---
change: "built-in-toc"
updated: ""
---

# Implementation Tasks

## Legend
`[ ]` Todo | `[x]` Done (implemented + verified)

## Tasks

### Phase 1: Tool Implementation ✅
- [x] Create `src/sspec/builtin_tools/mdtoc.py`
- [x] Register mdtoc in `src/sspec/commands/tool.py`
- [x] Create `src/sspec/templates/skills/sspec-mdtoc/SKILL.md`

**Verification**: `sspec tool mdtoc --help` ✓; `sspec tool mdtoc README.md` outputs TOC ✓

---

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|---------|
| Phase 1 | 100% | ✅ |

**Recent**:
- 2026-02-22: Implemented mdtoc.py, registered in tool.py, created SKILL template
