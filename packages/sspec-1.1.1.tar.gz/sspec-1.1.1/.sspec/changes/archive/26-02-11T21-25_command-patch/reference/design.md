```python
# patch_handler.py
"""
SEARCH/REPLACE Patch Handler

解析并应用 SEARCH/REPLACE 格式的代码补丁。

格式规范：
```
# path/to/file.py[:L10-L25]
<<<<<<< SEARCH
old code here
=======
new code here
>>>>>>> REPLACE
```
"""

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Optional


# ============ 数据结构 ============

@dataclass
class PatchBlock:
    """单个 patch 块"""
    file_path: Path
    line_range: Optional[tuple[int, int]]  # (start, end) 1-based, inclusive
    search_content: str
    replace_content: str
    source_line_start: int  # patch 在源文本中的起始行号（用于错误报告）


@dataclass
class PatchParseResult:
    """解析结果"""
    patches: list[PatchBlock]
    errors: list[str]


@dataclass
class PatchApplyResult:
    """单个 patch 应用结果"""
    patch: PatchBlock
    success: bool
    error: Optional[str] = None


@dataclass
class BatchApplyResult:
    """批量应用结果"""
    results: list[PatchApplyResult]

    @property
    def all_success(self) -> bool:
        return all(r.success for r in self.results)

    @property
    def failed_patches(self) -> list[PatchApplyResult]:
        return [r for r in self.results if not r.success]


# ============ LRR Phase 1: 行分类 ============

FILE_PATH_PATTERN = re.compile(r'^#\s+(\S+?)(?::L?(\d+)-L?(\d+))?$')


def classify_line(line: str) -> str:
    """
    分类规则：
    F - File path (# path/to/file[:L10-L25])
    S - Search marker (<<<<<<< SEARCH)
    D - Delimiter (=======)
    R - Replace marker (>>>>>>> REPLACE)
    B - Blank line
    C - Content (其他所有内容)
    """
    stripped = line.rstrip('\n')

    # 检查文件路径行（必须精确匹配格式）
    if FILE_PATH_PATTERN.match(stripped):
        return 'F'

    # 检查标记行（需要精确匹配）
    if stripped == '<<<<<<< SEARCH':
        return 'S'
    if stripped == '=======':
        return 'D'
    if stripped == '>>>>>>> REPLACE':
        return 'R'

    # 空行
    if stripped == '':
        return 'B'

    return 'C'


@dataclass
class LRRResult:
    lines: list[str]
    roles: list[str]
    schema: str

    def find(self, pattern: str | re.Pattern) -> list[re.Match]:
        if isinstance(pattern, str):
            pattern = re.compile(pattern)
        return list(pattern.finditer(self.schema))

    def extract_lines(self, match: re.Match, group: int | str = 0) -> list[str]:
        start, end = match.span(group)
        return self.lines[start:end]

    def extract_line_range(self, match: re.Match, group: int | str = 0) -> tuple[int, int]:
        return match.span(group)


def lrr_scan(text: str) -> LRRResult:
    lines = text.splitlines(keepends=True)
    roles = [classify_line(line) for line in lines]
    schema = ''.join(roles)
    return LRRResult(lines=lines, roles=roles, schema=schema)


# ============ LRR Phase 2: 匹配 Patch 块 ============

# 匹配模式：文件路径 → SEARCH（紧挨着）→ 内容 → 分隔符 → 内容 → REPLACE
PATCH_PATTERN = re.compile(r'FS(?P<search>[BC]*?)D(?P<replace>[BC]*?)R')


def parse_patches(patch_text: str) -> PatchParseResult:
    """解析 patch 文本，提取所有 patch 块"""
    lrr = lrr_scan(patch_text)
    patches = []
    errors = []

    for match in lrr.find(PATCH_PATTERN):
        try:
            # 提取文件路径行（F 的位置）
            file_line_idx, _ = lrr.extract_line_range(match, 0)
            file_line = lrr.lines[file_line_idx].rstrip('\n')

            # 解析文件路径和行范围
            m = FILE_PATH_PATTERN.match(file_line)
            if not m:
                errors.append(f"Line {file_line_idx + 1}: 无法解析文件路径: {file_line}")
                continue

            file_path_str, start_str, end_str = m.groups()
            file_path = Path(file_path_str)

            # 检查文件是否存在
            if not file_path.exists():
                errors.append(f"Line {file_line_idx + 1}: 文件不存在: {file_path}")
                continue

            line_range = None
            if start_str and end_str:
                line_range = (int(start_str), int(end_str))

            # 提取 SEARCH 和 REPLACE 内容（不包括标记行）
            search_lines = lrr.extract_lines(match, 'search')
            replace_lines = lrr.extract_lines(match, 'replace')

            search_content = ''.join(search_lines)
            replace_content = ''.join(replace_lines)

            patches.append(PatchBlock(
                file_path=file_path,
                line_range=line_range,
                search_content=search_content,
                replace_content=replace_content,
                source_line_start=file_line_idx + 1
            ))

        except Exception as e:
            errors.append(f"解析 patch 块失败: {e}")

    return PatchParseResult(patches=patches, errors=errors)


# ============ Patch 应用逻辑 ============

def normalize_for_matching(text: str) -> str:
    """
    规范化文本用于匹配：
    - 移除每行行尾空格
    - 将纯空白行转为空行
    - 保留行首缩进
    """
    lines = text.splitlines(keepends=True)
    normalized = []
    for line in lines:
        stripped = line.rstrip()
        if stripped:  # 非空行
            normalized.append(stripped + '\n' if line.endswith('\n') else stripped)
        else:  # 纯空白行
            normalized.append('\n' if line.endswith('\n') else '')
    return ''.join(normalized)


def apply_patch(patch: PatchBlock) -> PatchApplyResult:
    """应用单个 patch"""
    try:
        content = patch.file_path.read_text(encoding='utf-8')

        # 确定搜索范围
        if patch.line_range:
            lines = content.splitlines(keepends=True)
            start_idx = patch.line_range[0] - 1
            end_idx = patch.line_range[1]

            if start_idx < 0 or end_idx > len(lines):
                return PatchApplyResult(
                    patch=patch,
                    success=False,
                    error=f"行范围 {patch.line_range} 超出文件范围 (1-{len(lines)})"
                )

            search_region = ''.join(lines[start_idx:end_idx])
            prefix = ''.join(lines[:start_idx])
            suffix = ''.join(lines[end_idx:])
        else:
            search_region = content
            prefix = ''
            suffix = ''

        # 先尝试精确匹配
        if patch.search_content in search_region:
            count = search_region.count(patch.search_content)
            if count > 1:
                return PatchApplyResult(
                    patch=patch,
                    success=False,
                    error=f"找到 {count} 处精确匹配，存在歧义"
                )
            new_region = search_region.replace(patch.search_content, patch.replace_content, 1)
        else:
            # 精确匹配失败，尝试容忍空白差异的匹配
            normalized_search = normalize_for_matching(patch.search_content)
            normalized_region = normalize_for_matching(search_region)

            if normalized_search not in normalized_region:
                return PatchApplyResult(
                    patch=patch,
                    success=False,
                    error="未找到匹配的 SEARCH 内容"
                )

            count = normalized_region.count(normalized_search)
            if count > 1:
                return PatchApplyResult(
                    patch=patch,
                    success=False,
                    error=f"找到 {count} 处匹配（忽略空白后），存在歧义"
                )

            # 找到匹配位置，在原始文本中定位并替换
            search_lines = patch.search_content.splitlines(keepends=True)
            region_lines = search_region.splitlines(keepends=True)

            match_start = None
            for i in range(len(region_lines) - len(search_lines) + 1):
                # 检查从 i 开始的 len(search_lines) 行是否匹配
                match = True
                for j, search_line in enumerate(search_lines):
                    region_line = region_lines[i + j]
                    if normalize_for_matching(search_line) != normalize_for_matching(region_line):
                        match = False
                        break
                if match:
                    match_start = i
                    break

            if match_start is None:
                return PatchApplyResult(
                    patch=patch,
                    success=False,
                    error="无法定位匹配位置"
                )

            # 执行替换
            match_end = match_start + len(search_lines)
            new_lines = (
                region_lines[:match_start] +
                patch.replace_content.splitlines(keepends=True) +
                region_lines[match_end:]
            )
            new_region = ''.join(new_lines)

        # 重建文件内容
        new_content = prefix + new_region + suffix
        patch.file_path.write_text(new_content, encoding='utf-8')

        return PatchApplyResult(patch=patch, success=True)

    except Exception as e:
        return PatchApplyResult(
            patch=patch,
            success=False,
            error=f"应用 patch 失败: {e}"
        )


def apply_patches(patch_text: str) -> BatchApplyResult:
    """解析并批量应用 patches"""
    parse_result = parse_patches(patch_text)

    if parse_result.errors:
        # 如果有解析错误，创建失败结果
        results = [
            PatchApplyResult(
                patch=PatchBlock(
                    file_path=Path(""),
                    line_range=None,
                    search_content="",
                    replace_content="",
                    source_line_start=0
                ),
                success=False,
                error=error
            )
            for error in parse_result.errors
        ]
        return BatchApplyResult(results=results)

    # 应用所有 patches
    results = [apply_patch(patch) for patch in parse_result.patches]
    return BatchApplyResult(results=results)


# ============ Prompt 模板 ============

PATCH_PROMPT = """请返回代码更改的 patch，遵循如下的 SEARCH/REPLACE 规范：

## 格式规范

每个 patch 块由两部分组成：

1. **文件路径行**（必须紧挨着 SEARCH 标记）
```
# path/to/file.py[:L10-L25]
```
- 以 `#` 开头 + 空格
- 文件路径相对于项目根目录
- 可选的行范围限定：`:L起始行-L结束行` 或 `:起始行-结束行`
- 行范围用于避免多重匹配，只在指定行内搜索

2. **SEARCH/REPLACE 块**（紧接着文件路径行）
```
<<<<<<< SEARCH
要替换的原始代码
=======
替换后的新代码
>>>>>>> REPLACE
```

## 完整示例

```
# src/utils.py:L15-L30
<<<<<<< SEARCH
def old_function(x):
    return x * 2
=======
def new_function(x, y):
    return x * y
>>>>>>> REPLACE

# tests/test_utils.py
<<<<<<< SEARCH
def test_old():
    assert old_function(5) == 10
=======
def test_new():
    assert new_function(5, 3) == 15
>>>>>>> REPLACE
```

## 重要规则

1. **精确匹配**：SEARCH 内容必须与文件中的代码完全一致（包括缩进）
2. **空白容忍**：行尾空格和纯空白行会被忽略，但行首缩进必须精确
3. **唯一匹配**：如果 SEARCH 内容匹配到多处，patch 会失败（使用行范围限定来避免）
4. **标记行精确**：`<<<<<<< SEARCH`、`=======`、`>>>>>>> REPLACE` 必须独占一行，不能有额外空格
5. **文件存在性**：patch 应用前会检查文件是否存在

## 多个 patch

一个文档中可以包含多个 patch 块，它们会按顺序应用。你可以在 patch 块之间添加说明文字。
"""


# ============ CLI 入口（可选）============

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        print("Usage: python patch_handler.py <patch_file>")
        sys.exit(1)

    patch_file = Path(sys.argv[1])
    if not patch_file.exists():
        print(f"Error: File not found: {patch_file}")
        sys.exit(1)

    patch_text = patch_file.read_text(encoding='utf-8')
    result = apply_patches(patch_text)

    if result.all_success:
        print(f"✓ Successfully applied {len(result.results)} patch(es)")
    else:
        print(f"✗ Failed to apply {len(result.failed_patches)} patch(es):")
        for failed in result.failed_patches:
            print(f"  - {failed.patch.file_path}: {failed.error}")
        sys.exit(1)
```

使用示例：

```python
# 作为模块使用
from patch_handler import apply_patches, PATCH_PROMPT

# 应用 patch
patch_text = """
# example.py
<<<<<<< SEARCH
def hello():
    print("world")
=======
def hello():
    print("universe")
>>>>>>> REPLACE
"""

result = apply_patches(patch_text)
if result.all_success:
    print("All patches applied successfully")
else:
    for failed in result.failed_patches:
        print(f"Failed: {failed.error}")

# 在提示词中使用
prompt = f"""
修改这个函数的实现。

{PATCH_PROMPT}
"""
```

命令行使用：
```bash
python patch_handler.py changes.patch
```