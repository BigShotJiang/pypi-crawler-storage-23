# 评估 sspec 重构对 Agentic Coding 的友好度对比

**Session ID:** ses_36faeb3c6ffeIOBRjNDsXWg0CM
**Created:** 2026/2/24 23:42:52
**Updated:** 2026/2/25 00:27:47

---

## User

当前我正在重构 sspec 项目，参考当前正在活跃的 change；现在我需要你来评价重构前后，对Agentic Coding的友好程度；方案是，你到 @tmp/ 目录下，有两个对比，legacy-sspec-8.0 和 new-sspec-9.0 的目录（注意他们在 gitignore 中，所以你用 glob 工具不一定能找到）；请你分析这两个目录，假设两个独立 Agent 分别使用这两个方案，哪个效果会更好；并且分析改版之后的新版对比旧版有没有什么损失和缺陷，是否能构成帕累托优势；SKILL 在 .claude/skills 下，是一个Junction 链接，指向了 .sspec/skills

---

## Assistant (Build · gpt-5.3-codex · 11.2s)

_Thinking:_

**Planning exploratory glob scans**

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/legacy-sspec-8.0/**",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
No files found
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/new-sspec-9.0/**",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
No files found
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/*sspec-8.0*",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
No files found
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/*sspec-9.0*",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
No files found
```
```

---

## Assistant (Build · gpt-5.3-codex · 4.9s)

_Thinking:_

**Switching to shell listing to find files**

```
Tool: bash

**Input:**
```json
{
  "command": "ls -Force",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Lists all files including hidden"
}
```
**Output:**
```
ls: unknown option -- e
Try 'ls --help' for more information.

```
```

---

## Assistant (Build · gpt-5.3-codex · 3.6s)

_Thinking:_

**Adjusting directory listing command**

```
Tool: bash

**Input:**
```json
{
  "command": "ls -a",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Lists all entries in workspace"
}
```
**Output:**
```
.
..
.claude
.env
.git
.github
.gitignore
.pytest_cache
.ruff_cache
.sspec
.venv
.vscode
AGENTS.md
DEBUG.md
LICENSE
README.md
README_zh-CN.md
dist
i18n-glossary.md
node_modules
pyproject.toml
requests_test
sample
scripts
src
sspec.zip
tests
tmp
uv.lock

```
```

---

## Assistant (Build · gpt-5.3-codex · 3.1s)

_Thinking:_

**Inspecting temporary directories**

```
Tool: bash

**Input:**
```json
{
  "command": "ls -a",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp",
  "description": "Lists temporary workspace directories"
}
```
**Output:**
```
.
..
.gitignore
Agents.md
agent-prompt-guide.md
legacy-sspec-8.0
list_style_unification.md
new-sspec-9.0
sspec-completion.ps1
test-replace-archive-link-project
test_refactor
tests.zip

```
```

---

## Assistant (Build · gpt-5.3-codex · 4.5s)

_Thinking:_

**Planning directory content inspection**

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/*",
  "path": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\.meta.json
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\.gitignore
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\AGENTS.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\spec-docs\README.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\.gitignore
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\project.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\.gitignore
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\.gitignore
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\write-spec-doc\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\write-spec-doc\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\write-patch\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\write-patch\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\use-powershell\references\patterns.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\use-powershell\references\patterns.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\use-powershell\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\use-powershell\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-memory\references\handover-standards.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-memory\references\handover-standards.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-memory\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-memory\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-mdtoc\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-mdtoc\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-change\references\multi-change.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-change\references\multi-change.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-change\references\doc-standards.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-change\references\doc-examples.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-change\references\doc-standards.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-change\references\doc-examples.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-change\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-change\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.sspec\skills\sspec-ask\SKILL.md
H:\SrcCode\playground\sspec\tmp\legacy-sspec-8.0\.claude\skills\sspec-ask\SKILL.md
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "**/*",
  "path": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\AGENTS.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\.meta.json
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\.gitignore
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\.gitignore
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\spec-docs\README.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\project.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\.gitignore
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\.gitignore
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-review\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-review\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-handover\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-handover\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-design\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-design\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-ask\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-ask\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-mdtoc\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-mdtoc\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-implement\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-implement\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-research\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\sspec-plan\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-plan\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\sspec-research\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\write-patch\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\write-patch\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\write-spec-doc\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\write-spec-doc\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\use-powershell\references\patterns.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\use-powershell\references\patterns.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.sspec\skills\use-powershell\SKILL.md
H:\SrcCode\playground\sspec\tmp\new-sspec-9.0\.claude\skills\use-powershell\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 10.6s)

_Thinking:_

**Planning systematic directory comparison**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\AGENTS.md"
}
```
**Output:**
```
<file>
00001| <!-- SSPEC:START -->
00002| # .sspec Agent Protocol
00003| 
00004| SSPEC_SCHEMA::8.0
00005| 
00006| ## 0. Overview
00007| 
00008| SSPEC is a document-driven AI collaboration framework. All planning, tracking, and handover lives in `.sspec/`.
00009| 
00010| **Goal**: Any Agent resumes work within 30 seconds by reading `.sspec/` files.
00011| 
00012| ```
00013| .sspec/
00014| ├── project.md     # Identity, conventions, notes
00015| ├── spec-docs/     # Formal specs (architecture, APIs)
00016| ├── changes/<n>/   # spec.md | tasks.md | handover.md [+ reference/]
00017| ├── requests/      # User intent records
00018| ├── tmp/           # Informal drafts for review
00019| └── asks/          # Q&A decision evidence
00020| ```
00021| 
00022| ---
00023| 
00024| ## 1. Agent Procedure
00025| 
00026| `read(project.md)` → classify input → dispatch:
00027| 
00028| ```
00029| DISPATCH(input):
00030|   directive(d)    → exec(d)                # → Shortcuts 4.3
00031|   request(r)      → scale(r) → workflow(r) # → Change 2.1; includes attached request files
00032|   resume(change)  → load(change) → continue
00033|   micro(≤3f,≤30m,obvious) → do_directly
00034|   new_work        → scale(input) → workflow # → Change 2.1
00035| 
00036| load(change):
00037|   read(handover→tasks→spec) → output(status, progress, next_3_actions)
00038| 
00039| scale(input):
00040|   micro  → do_directly | track_in_request
00041|   single → create_change(standard)
00042|   multi(>1w|>15f|>20t) → create_root
00043| 
00044| BACKGROUND (always active during session):
00045|   discovery    → persist(handover.md)    # → Memory 2.3
00046|   long_session → checkpoint(handover.md) # compression is silent
00047|   uncertain    → @ask                    # → Consult 2.2; 30s < rework
00048|   session_end  → handover_full()         # → Memory 2.3; MANDATORY
00049|   user_rejects → STOP → assess_scope    # → Reactive 3
00050| ```
00051| 
00052| Unfamiliar subsystem? → read `spec-docs/` | `project.md` | `<change>/handover.md` first
00053| 
00054| ---
00055| 
00056| ## 2. Core Workflows
00057| 
00058| ### 2.1 Change Lifecycle
00059| 
00060| Changes live in `.sspec/changes/<n>/` (dir name: `<time>_<change-name>`).
00061| 
00062| | File | Contains |
00063| |------|----------|
00064| | spec.md | Problem (A), Solution (B), Implementation plan (C), Blockers (D) |
00065| | tasks.md | Task checklist `[ ]`/`[x]` + progress tracking |
00066| | handover.md | Session memory + agent working memory across sessions |
00067| 
00068| **Request → Change Workflow** (most common path):
00069| 
00070| 1. **Assess scale** → Micro (≤3 files, ≤30min: do directly) / Single (standard) / Multi (>1 week OR >15 files OR >20 tasks: `--root` + sub-changes)
00071| 2. **Create**: `sspec change new --from <request>` (auto-links + derives name) or `sspec change new <name>`
00072| 3. **Research**: First-principles — find the real problem, not the surface ask. Read project.md + relevant code. Unclear → use `@ask`. Wrong direction costs more than extra questions.
00073| 4. **Design**: Fill spec.md A/B/C. Complex → `@ask` about splitting
00074| 5. **Confirm**: `@ask` to present plan. Wait for approval before executing
00075| 6. **Execute**: Implement. Update tasks.md after **each** task — not in batches
00076| 
00077| **Locate**: `sspec change find <name>` (fuzzy) | `sspec change list` | read `.sspec/changes/`
00078| 
00079| **Status transitions**:
00080| 
00081| | From | Trigger | To |
00082| |------|---------|-----|
00083| | PLANNING | user approves | DOING |
00084| | DOING | all tasks `[x]` | REVIEW |
00085| | DOING | missing info | BLOCKED |
00086| | DOING | scope changed | PLANNING |
00087| | BLOCKED | resolved | DOING |
00088| | REVIEW | accepted | DONE |
00089| | REVIEW | needs changes | DOING |
00090| 
00091| **FORBIDDEN**: PLANNING→DONE, DOING→DONE, BLOCKED→DONE — never skip REVIEW.
00092| 
00093| 📚 `sspec-change` SKILL (MUST consult): doc standards, CLI ref, multi-change, edge cases.
00094| 
00095| ### 2.2 Consultation (@ask)
00096| 
00097| When Agent needs user input, route by archival need:
00098| 
00099| | Need persistent record? | Tool | Use when |
00100| |--------------------------|------|----------|
00101| | Yes | `sspec ask create <topic>` → fill → `sspec ask prompt <file>` | Plan approval, architecture choice, direction decision |
00102| | No | Agent env question tool | Session-end check, quick yes/no |
00103| 
00104| **Default to sspec ask** when uncertain — record > no record. Batch related questions in one ask.
00105| Long content MUST NOT go in ASK file → write in `.sspec/tmp/`, reference in QUESTION.
00106| 
00107| **Mandatory ask points** (when user specified `@sspec-ask`): plan completion before execution, tool call rejected (ask reason), all tasks complete before ending.
00108| 
00109| 📚 Triggers, patterns, error handling: `sspec-ask` SKILL
00110| 
00111| ### 2.3 Memory & Handover
00112| 
00113| Knowledge persists at four levels:
00114| 
00115| | Level | Carrier | Write timing |
00116| |-------|---------|-------------|
00117| | Record | `requests/` + `asks/` | On creation (CLI-managed) |
00118| | Change | `handover.md` | During work + session end |
00119| | Project | `project.md` Notes | Promoted from handover at session end |
00120| | Spec | `spec-docs/` | On architecture changes → `sspec doc new` |
00121| 
00122| **End-of-session handover (mandatory)**:
00123| 1. Update handover.md: Accomplished, Next Steps, References & Memory
00124| 2. Promote project-wide learnings to `project.md` Notes
00125| 3. Verify tasks.md progress matches reality
00126| 
00127| **Mid-session** (proactive): Important decision, key file discovered, session long (>50 exchanges) → append to handover.md References & Memory immediately. Self-check: "Would I struggle to reconstruct this after context compression?" → if yes, write it NOW.
00128| 
00129| 📚 Knowledge routing, handover quality, memory lifecycle: `sspec-memory` SKILL
00130| 
00131| ---
00132| 
00133| ## 3. Rejection Protocol
00134| 
00135| When user disagrees (`@argue` or equivalent) — **STOP immediately**. Assess scope:
00136| 
00137| | Rejection scope | Action |
00138| |----------------|--------|
00139| | Implementation detail | Update tasks.md only |
00140| | Design decision | Revise spec.md B + regenerate tasks.md |
00141| | Requirement itself | Revise spec.md A, mark PIVOT in D, transition DOING→PLANNING |
00142| 
00143| 📚 Edge cases and assessment guidance: `sspec-change` SKILL
00144| 
00145| ---
00146| 
00147| ## 4. Reference
00148| 
00149| ### Template Markers in `<change>` template files
00150| 
00151| | Marker | Meaning | Action |
00152| |--------|---------|--------|
00153| | `<!-- @RULE: ... -->` | Inline standards reminder | Read and follow. DO NOT delete |
00154| | `<!-- @REPLACE -->` | Anchor for first edit | Replace with content |
00155| | `[ ]` / `[x]` | Task todo / done | Update as work progresses |
00156| 
00157| **Authority**: SKILLs are source of truth. @RULE markers are quick reminders.
00158| 
00159| ### Scope Quick Reference
00160| 
00161| | Scope | Location | Key actions |
00162| |-------|----------|-------------|
00163| | Changes | `.sspec/changes/<n>/` | `sspec change new/find/list/archive/validate` |
00164| | Requests | `.sspec/requests/` | `sspec request new/find/link`. Request = "I want X" → Change = "Here's how we do X". Micro → track in request directly |
00165| | Spec-Docs | `.sspec/spec-docs/` | `sspec doc new "<name>"`. For knowledge too complex for project.md AND surviving beyond any single change. 📚 `write-spec-doc` SKILL |
00166| | Asks | `.sspec/asks/` | `sspec ask create/prompt/list`. Decision evidence chain |
00167| 
00168| ### Directive Shortcuts
00169| 
00170| Optional convenience shortcuts. Agent MUST respond to equivalent natural language identically.
00171| 
00172| | Shortcut | Equivalent intent | Procedure |
00173| |----------|-------------------|-----------|
00174| | `@change <n>` | "Work on change N" | **Existing**: load per procedure §1. **New**: create via §2.1 |
00175| | `@resume` | "Continue last work" | Same as `@change` for current active change |
00176| | `@handover` | "Save progress, end session" | Execute handover (Section 2.3) |
00177| | `@sync` | "I coded without tracking, update status" | Identify changes → update tasks.md/handover.md → suggest REVIEW if complete |
00178| | `@argue` | "I disagree" | **STOP immediately** → assess rejection scope (Reactive Rules Section 3) |
00179| 
00180| ---
00181| 
00182| ## 5. SKILL System
00183| 
00184| SSPEC core SKILLs: `sspec-change`, `sspec-memory`, `sspec-ask`, `sspec-mdtoc`, `write-spec-doc`, `write-patch`
00185| 
00186| **Progressive disclosure**: `SKILL.md` is the entry point; reference subfiles contain detailed standards and examples.
00187| 
00188| ```
00189| <skills-dir>/<name>/
00190| ├── SKILL.md     ← Read this first
00191| └── references/  ← Contains detailed standards, examples, patterns
00192| ```
00193| 
00194| **Critical**: When `SKILL.md` instructs to read a reference file (e.g. "read [doc-standards](./references/doc-standards.md)") → you **MUST** read it. Stopping at `SKILL.md` alone misses essential standards.
00195| For large md, use `sspec-mdtoc` for pre-scanning.
00196| <!-- SSPEC:END -->

(End of file - total 196 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\AGENTS.md"
}
```
**Output:**
```
<file>
00001| <!-- SSPEC:START -->
00002| # .sspec Agent Protocol
00003| 
00004| SSPEC_SCHEMA::9.0
00005| 
00006| ## 0. Overview
00007| 
00008| SSPEC is a document-driven AI collaboration framework. All planning, tracking, and handover lives in `.sspec/`.
00009| 
00010| **Goal**: Any Agent resumes work within 30 seconds by reading `.sspec/` files.
00011| 
00012| ```
00013| .sspec/
00014| ├── project.md     # Identity, conventions, notes
00015| ├── spec-docs/     # Formal specs (architecture, APIs)
00016| ├── changes/<n>/   # spec.md | tasks.md | handover.md [+ reference/]
00017| ├── requests/      # User intent records
00018| ├── tmp/           # Informal drafts
00019| └── asks/          # Q&A decision records
00020| ```
00021| 
00022| ---
00023| 
00024| ## 1. Agent Procedure
00025| 
00026| `read(project.md)` → classify → dispatch:
00027| 
00028| | Input | Action |
00029| |-------|--------|
00030| | Directive (`@resume`, `@handover`, etc.) | Execute → §5 Shortcuts |
00031| | Request (attached or described) | Assess scale → Change Workflow §2 |
00032| | Resume existing change | `read(handover→tasks→spec)` → continue from where left off |
00033| | Micro task (≤3 files, ≤30min, obvious) | Do directly, no change needed |
00034| 
00035| **Background rules** (always active):
00036| - Important discovery → write to `handover.md` immediately
00037| - Long session (>20 exchanges) → checkpoint `handover.md`
00038| - Uncertain → `@ask` (30s question < hours of rework)
00039| - User rejects tool call → STOP → `@ask` reason
00040| 
00041| ---
00042| 
00043| ## 2. Change Workflow
00044| 
00045| ### Development Lifecycle
00046| 
00047| Each phase has a dedicated SKILL. Read the SKILL before starting the phase.
00048| 
00049| ```
00050| Request ─→ research ─→ design ──→ plan ──→ implement ──→ review ──→ handover
00051|               │           │          │          │            │          │
00052|            understand   @ask       @ask      execute      @ask      persist
00053|            problem      align      approve   tasks       feedback   session
00054|            space        design     tasks                  loop      state
00055| ```
00056| 
00057| **Handover** is not just session-end cleanup — it's a lifecycle participant. Trigger it:
00058| - At session end (MANDATORY)
00059| - Mid-session when context is long (>30 exchanges)
00060| - When switching between major phases
00061| - Before any context-losing event (compression, interruption)
00062| 
00063| ### Phase → SKILL → Files
00064| 
00065| | Phase | SKILL | Reads | Writes | Checkpoint |
00066| |-------|-------|-------|--------|------------|
00067| | **Research** | `sspec-research` | code, project.md, spec-docs | reference/, handover.md | @ask "ready to design?" |
00068| | **Design** | `sspec-design` | research findings, code | spec.md (A+B) | **@ask align** (MANDATORY) |
00069| | **Plan** | `sspec-plan` | spec.md B | tasks.md | **@ask approve** (MANDATORY) |
00070| | **Implement** | `sspec-implement` | spec.md B, tasks.md | code, tasks.md progress | **@ask "done, please review"** |
00071| | **Review** | `sspec-review` | user feedback | tasks.md (feedback tasks) | @ask "satisfied?" |
00072| | **Handover** | `sspec-handover` | everything | handover.md, project.md | — |
00073| 
00074| **MANDATORY checkpoints**: Design and Plan phases MUST @ask user before proceeding. Never skip.
00075| 
00076| ### Scale Assessment (in Design phase)
00077| 
00078| | Scale | Criteria | Path |
00079| |-------|----------|------|
00080| | Micro | ≤3 files, ≤30min, trivially reversible | Do directly |
00081| | Single | ≤1 week, ≤15 files, ≤20 tasks | `sspec change new <name>` |
00082| | Multi | >1 week OR >15 files OR >20 tasks | `sspec change new <name> --root` → sub-changes |
00083| 
00084| ### Status Transitions
00085| 
00086| | From | Trigger | To |
00087| |------|---------|-----|
00088| | PLANNING | user approves design+plan | DOING |
00089| | DOING | all tasks `[x]` | REVIEW |
00090| | DOING | missing info | BLOCKED |
00091| | DOING | scope changed | PLANNING |
00092| | REVIEW | accepted | DONE |
00093| | REVIEW | needs changes | DOING |
00094| 
00095| **FORBIDDEN**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
00096| 
00097| ---
00098| 
00099| ## 3. Consultation (@ask)
00100| 
00101| | Need persistent record? | Tool | Use when |
00102| |--------------------------|------|----------|
00103| | Yes | `sspec ask create` → fill → `sspec ask prompt` | Plan approval, architecture choice, direction decision |
00104| | No | Agent env question tool | Quick yes/no, session-end check |
00105| 
00106| Default to `sspec ask` when uncertain — a record beats no record.
00107| Long content → write to `.sspec/tmp/`, reference path in question body.
00108| 
00109| 📚 Full workflow, patterns, and content rules: `sspec-ask` SKILL
00110| 
00111| ---
00112| 
00113| ## 4. Spec-Docs
00114| 
00115| Spec-docs capture architecture knowledge that survives beyond any single change.
00116| 
00117| **When to create/update spec-docs**:
00118| - After a change produces architectural knowledge (new interfaces, data models, design patterns)
00119| - When the agent discovers knowledge too complex for `project.md` Notes
00120| - When user explicitly requests documentation
00121| 
00122| **Two scenarios**:
00123| 
00124| | Scenario | Trigger | Action |
00125| |----------|---------|--------|
00126| | Post-change update | Change is DONE, produced architectural knowledge | Agent proactively `@ask`: "Should I update/create spec-doc for X?" |
00127| | User-initiated | User requests spec-doc creation | If small → do directly; if large → may need its own change |
00128| 
00129| 📚 Full guidelines: `write-spec-doc` SKILL
00130| 
00131| ---
00132| 
00133| ## 5. Reference
00134| 
00135| ### Directive Shortcuts
00136| 
00137| | Shortcut | Equivalent | Procedure |
00138| |----------|-----------|-----------|
00139| | `@change <n>` | "Work on change N" | Load: `read(handover→tasks→spec)` → continue |
00140| | `@resume` | "Continue last work" | Same as `@change` for active change |
00141| | `@handover` | "Save and end" | Execute `sspec-handover` procedure |
00142| | `@sync` | "I coded without tracking" | Update tasks.md/handover.md to match reality |
00143| | `@argue` | "I disagree" | **STOP** → assess scope (§2 Review) |
00144| 
00145| ### CLI Quick Reference
00146| 
00147| Common `sspec` commands. Run `sspec <command> --help` for full options.
00148| 
00149| | Command | Purpose | Example |
00150| |---------|---------|---------|
00151| | `sspec change new <name>` | Create single change | `sspec change new fix-auth` |
00152| | `sspec change new <name> --root` | Create root (multi) change | `sspec change new refactor --root` |
00153| | `sspec change new --from <req>` | Create from request (auto-link) | `sspec change new --from .sspec/requests/...` |
00154| | `sspec change find <name>` | Fuzzy-find change dir | `sspec change find auth` |
00155| | `sspec change list` | List all active changes | |
00156| | `sspec change archive <path>` | Archive completed change | |
00157| | `sspec request list` | List requests | |
00158| | `sspec doc new "<name>"` | Create spec-doc | `sspec doc new "auth-design"` |
00159| | `sspec ask create <topic>` | Create ask file | `sspec ask create cache_approach` |
00160| | `sspec ask prompt <path>` | Collect user answer | Combo: create → edit → prompt |
00161| | `sspec ask list` | List asks | |
00162| | `sspec tool mdtoc <file>` | Pre-scan Markdown (headings + sizes) | |
00163| 
00164| ### Scope Quick Reference
00165| 
00166| | Scope | Location | Key Actions |
00167| |-------|----------|-------------|
00168| | Changes | `.sspec/changes/<n>/` | `new`, `find`, `list`, `archive` |
00169| | Requests | `.sspec/requests/` | `new`, `find`, `link` |
00170| | Spec-Docs | `.sspec/spec-docs/` | `new` |
00171| | Asks | `.sspec/asks/` | `create` → `prompt`, `list` |
00172| 
00173| ### SKILL System
00174| 
00175| Each SKILL is self-contained — read the one you need for the current phase, no chaining required.
00176| When a SKILL.md says "read [reference](./references/file.md)" → you **MUST** follow and read it.
00177| 
00178| | SKILL | When to Read |
00179| |-------|-------------|
00180| | `sspec-research` | Starting investigation of a problem |
00181| | `sspec-design` | Creating a change, filling spec.md |
00182| | `sspec-plan` | Breaking design into tasks |
00183| | `sspec-implement` | Executing tasks |
00184| | `sspec-review` | Handling user feedback |
00185| | `sspec-handover` | Saving session state (end-of-session or mid-session) |
00186| | `sspec-ask` | Consulting user mid-work |
00187| | `sspec-mdtoc` | Pre-scanning large Markdown files |
00188| | `write-spec-doc` | Creating spec-docs |
00189| | `write-patch` | Patch-based code modifications |
00190| 
00191| ### Template Markers
00192| 
00193| | Marker | Meaning | Action |
00194| |--------|---------|--------|
00195| | `<!-- @RULE: ... -->` | Standards reminder | Read and follow. DO NOT delete |
00196| | `<!-- @REPLACE -->` | Anchor for first edit | Replace with content |
00197| | `[ ]` / `[x]` | Task todo / done | Update as work progresses |
00198| <!-- SSPEC:END -->

(End of file - total 198 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\project.md"
}
```
**Output:**
```
<file>
00001| # Project Context
00002| 
00003| **Name**: 
00004| **Description**: 
00005| **Repo**: 
00006| 
00007| ## Project Overview
00008| <!-- [Describe project's purpose and overview design] -->
00009| 
00010| ## Tech Stack
00011| - [List primary technologies, e.g. TypeScript, React, Node.js]
00012| 
00013| ## Key Paths
00014| <!-- @RULE: Most important directories/files for quick navigation.
00015| Keep ≤10 entries. Agent uses this to orient in the codebase. -->
00016| 
00017| | Path | Purpose |
00018| |------|---------|
00019| | `src/` | Source code |
00020| | `tests/` | Test files |
00021| 
00022| ## Conventions
00023| <!-- @RULE: Coding rules that apply across ALL work in this project.
00024| One-liners only. If a convention needs multi-paragraph explanation → write a spec-doc.
00025| Examples: "snake_case for Python, camelCase for JS", "All API routes: /api/v1/*",
00026| "Never commit .env files", "Prefer composition over inheritance" -->
00027| 
00028| **Architecture Patterns**
00029| **Domain Context**
00030| **Important Constraints**
00031| 
00032| ## Notes
00033| <!-- @RULE: Project-level memory. Append-only log of learnings, gotchas, preferences.
00034| Agent appends here during @handover when a discovery is project-wide (not change-specific).
00035| Format each entry as: `- YYYY-MM-DD: <learning>`
00036| Prune entries that become outdated or graduate to Conventions/spec-docs. -->
00037| 

(End of file - total 37 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\project.md"
}
```
**Output:**
```
<file>
00001| # Project Context
00002| 
00003| **Name**: 
00004| **Description**: 
00005| **Repo**: 
00006| 
00007| ## Project Overview
00008| <!-- [Describe project's purpose and overview design] -->
00009| 
00010| ## Tech Stack
00011| - [List primary technologies, e.g. TypeScript, React, Node.js]
00012| 
00013| ## Key Paths
00014| <!-- @RULE: Most important directories/files for quick navigation.
00015| Keep ≤10 entries. Agent uses this to orient in the codebase. -->
00016| 
00017| | Path | Purpose |
00018| |------|---------|
00019| | `src/` | Source code |
00020| | `tests/` | Test files |
00021| 
00022| ## Conventions
00023| <!-- @RULE: Coding rules that apply across ALL work in this project.
00024| One-liners only. If a convention needs multi-paragraph explanation → write a spec-doc.
00025| Examples: "snake_case for Python, camelCase for JS", "All API routes: /api/v1/*",
00026| "Never commit .env files", "Prefer composition over inheritance" -->
00027| 
00028| **Architecture Patterns**
00029| **Domain Context**
00030| **Important Constraints**
00031| 
00032| ## Spec-Docs Index
00033| <!-- @RULE: Quick reference to formal specs in `.sspec/spec-docs/`.
00034| Agent reads this to know what architecture knowledge exists before starting work.
00035| Keep entries in sync with actual spec-doc files. Format: `- [name](spec-docs/<file>) — one-line description` -->
00036| 
00037| (none yet — create spec-docs with `sspec doc new "<name>"`)
00038| 
00039| ## Notes
00040| <!-- @RULE: Project-level memory. Append-only log of learnings, gotchas, preferences.
00041| Agent appends here during @handover when a discovery is project-wide (not change-specific).
00042| Format each entry as: `- YYYY-MM-DD: <learning>`
00043| Prune entries that become outdated or graduate to Conventions/spec-docs. -->
00044| 

(End of file - total 44 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\.meta.json"
}
```
**Output:**
```
<file>
00001| {
00002|   "schema_version": "8.0",
00003|   "sspec_version": "0.22.0.dev1",
00004|   "created_at": "2026-02-24T22:43:58.111821",
00005|   "updated_at": "2026-02-24T22:43:58.111821",
00006|   "file_hashes": {
00007|     "skills/sspec-ask": "f30affe23e728e27",
00008|     "skills/sspec-change": "40633c42387b8f42",
00009|     "skills/sspec-mdtoc": "a9d3dea08e9d0c62",
00010|     "skills/sspec-memory": "381420fc6c23b91c",
00011|     "skills/use-powershell": "c14a032ce16697b8",
00012|     "skills/write-patch": "53a7cb880be7ee69",
00013|     "skills/write-spec-doc": "e82f5bb62b549e30"
00014|   },
00015|   "managed_skills": [
00016|     "sspec-ask",
00017|     "sspec-change",
00018|     "sspec-mdtoc",
00019|     "sspec-memory",
00020|     "use-powershell",
00021|     "write-patch",
00022|     "write-spec-doc"
00023|   ],
00024|   "skill_locations": [
00025|     ".github/skills",
00026|     ".sspec\\skills"
00027|   ],
00028|   "skill_install_strategies": {
00029|     ".sspec/skills": "copy",
00030|     ".github/skills": "junction"
00031|   }
00032| }

(End of file - total 32 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\.meta.json"
}
```
**Output:**
```
<file>
00001| {
00002|   "schema_version": "9.0",
00003|   "sspec_version": "0.22.1.dev1+gc9cadd702.d20260224",
00004|   "created_at": "2026-02-24T23:37:17.741259",
00005|   "updated_at": "2026-02-24T23:37:17.741259",
00006|   "file_hashes": {
00007|     "skills/sspec-ask": "b0f30504c3d543d3",
00008|     "skills/sspec-design": "2c35ada1aef56b0f",
00009|     "skills/sspec-handover": "962bcb3d353aed61",
00010|     "skills/sspec-implement": "e251676af61bc9ef",
00011|     "skills/sspec-mdtoc": "b9fdfc4a23d816e0",
00012|     "skills/sspec-plan": "5cd0c2570b11ee33",
00013|     "skills/sspec-research": "1843e48cf8e212be",
00014|     "skills/sspec-review": "c70ea452cbc7f078",
00015|     "skills/use-powershell": "c14a032ce16697b8",
00016|     "skills/write-patch": "53a7cb880be7ee69",
00017|     "skills/write-spec-doc": "e82f5bb62b549e30"
00018|   },
00019|   "managed_skills": [
00020|     "sspec-ask",
00021|     "sspec-design",
00022|     "sspec-handover",
00023|     "sspec-implement",
00024|     "sspec-mdtoc",
00025|     "sspec-plan",
00026|     "sspec-research",
00027|     "sspec-review",
00028|     "use-powershell",
00029|     "write-patch",
00030|     "write-spec-doc"
00031|   ],
00032|   "skill_locations": [
00033|     ".claude/skills",
00034|     ".sspec\\skills"
00035|   ],
00036|   "skill_install_strategies": {
00037|     ".sspec/skills": "copy",
00038|     ".claude/skills": "junction"
00039|   }
00040| }

(End of file - total 40 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 12.7s)

_Thinking:_

**Planning skill file inspection**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-ask\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-ask
00003| description: "Mid-execution user consultation via persistent Q&A. USE ACTIVELY — especially in agent scenarios where @ask extends single-session effectiveness."
00004| metadata:
00005|   author: frostime
00006|   version: 5.0.0
00007| ---
00008| 
00009| # SSPEC Ask Skill
00010| 
00011| **USE ACTIVELY** — Guessing wastes more tokens than one ask. When in doubt, ask.
00012| 
00013| ---
00014| 
00015| ## Why @ask Matters
00016| 
00017| In agent/copilot scenarios, the interaction model is: Agent works autonomously → hits a decision point → needs user input.
00018| 
00019| Some platforms offer basic tools like `vscode Question` in copilot or `question` in opencode. However, these solutions are insufficient for handling complex, multi-turn consultations.
00020| 
00021| Without `@ask`: Agent guesses, potentially wastes an entire implementation cycle. Or stops and loses context while waiting.
00022| 
00023| With `@ask`: Agent persists the question to disk, collects the answer via terminal, and continues — all within the same session. The ask record also serves as permanent decision documentation.
00024| 
00025| **Cost equation**: One ask ≈ 30 seconds of user time. One wrong guess ≈ full rework cycle.
00026| 
00027| ---
00028| 
00029| ## When to Trigger (Critical Decision Points)
00030| 
00031| **REQUIRED use cases** — Agent MUST use sspec ask when:
00032| 
00033| 1. **User explicitly requested** — User mentions ask/confirmation in their request
00034| 2. **Information missing** — Cannot proceed reliably without user clarification
00035| 3. **Directional choice needed** — Multiple valid approaches exist (not minor tweaks)
00036| 4. **Work completion check** — Agent believes task is done, needs user verification
00037| 5. **Repeated failures** — Multiple attempts failed, need user insight
00038| 
00039| ### When NOT to Ask
00040| 
00041| Don't create an ask for trivial decisions where:
00042| - Only one reasonable approach exists
00043| - The choice is easily reversible (e.g., variable naming)
00044| - The answer is available in project.md or existing spec-docs
00045| 
00046| **Use question tool (if exists) for simple question**.
00047| 
00048| ---
00049| 
00050| ## Workflow
00051| 
00052| ### CLI Commands (Agent-Driven)
00053| 
00054| | Command | When | Notes |
00055| |---------|------|-------|
00056| | `sspec ask create <topic>` | Need to ask user something | `<topic>` is a slug: `auth_approach`, `redis_vs_db` |
00057| | `sspec ask prompt <file.py>` | Collect user's answer | Pass the `.py` file path from create output |
00058| | `sspec ask list` | Check pending/completed asks | Shows `.py` (pending) and `.md` (answered) |
00059| 
00060| **Ergonomics**:
00061| - `create` generates the `.py` template → Agent fills REASON + QUESTION → runs `prompt`
00062| - `prompt` opens terminal for user input OR get the user prefilled answer before `prompt` is approvaed to run → auto-converts to `.md` record → deletes `.py`
00063| - The entire cycle happens within one agent session — no context loss
00064| 
00065| ### Step-by-Step
00066| 
00067| **Step 1**: Create template
00068| ```bash
00069| sspec ask create <topic>
00070| ```
00071| Creates `.sspec/asks/<timestamp>_<topic>.py`
00072| 
00073| **Step 2**: Edit the `.py` file
00074| - Fill `REASON` (why asking — for future reference and memory)
00075| - Fill `QUESTION` (be specific, provide options when possible)
00076| - Do NOT edit `USER_ANSWER`
00077| 
00078| **Step 3**: Execute
00079| ```bash
00080| sspec ask prompt <path-to-py-file>
00081| ```
00082| 
00083| **Step 4**: Automatic lifecycle
00084| After execution: user's answer appended → file converted to `.md` → `.py` deleted.
00085| 
00086| ### Error Handling
00087| 
00088| If `sspec ask prompt` reports file not found:
00089| - The ask may have already been answered. Check if `<timestamp>_<topic>.md` exists in `.sspec/asks/`, or use `sspec ask list`.
00090| - If the `.md` file exists, read the answer from it directly.
00091| 
00092| ---
00093| 
00094| ## Patterns
00095| 
00096| ### Single Decision Ask
00097| 
00098| ```python
00099| REASON = r"""
00100| Multiple valid approaches for caching layer refactor
00101| """
00102| 
00103| QUESTION = r"""
00104| I've identified 3 approaches:
00105| 
00106| **A) Redis + In-Memory Fallback**
00107| - Pros: High performance, resilient
00108| - Cons: Operational complexity
00109| 
00110| **B) Pure In-Memory (LRU)**
00111| - Pros: Simple, no external deps
00112| - Cons: Lost on restart
00113| 
00114| **C) SQLite Cache**
00115| - Pros: Persistent, zero-config
00116| - Cons: Slower than Redis
00117| 
00118| Which aligns with project priorities?
00119| """
00120| ```
00121| 
00122| ### Batched Questions
00123| 
00124| When multiple related questions arise, **batch them in a single ask**:
00125| 
00126| ```python
00127| REASON = r"""
00128| Starting auth module implementation, several design decisions needed
00129| """
00130| 
00131| QUESTION = r"""
00132| Before starting the auth module, I need a few decisions:
00133| 
00134| 1. **Token format**: JWT (stateless, standard) or opaque tokens (revocable, simpler)?
00135| 2. **Session storage**: Redis (fast, needs infra) or DB table (simpler, slower)?
00136| 3. **Password hashing**: bcrypt (proven) or argon2 (newer, more resistant)?
00137| 
00138| For each, my recommendation is in bold if it helps. Override any as you see fit.
00139| """
00140| ```
00141| 
00142| ### Plan Confirmation (Most Common)
00143| 
00144| ```python
00145| REASON = r"""
00146| Change plan ready for review before starting implementation
00147| """
00148| 
00149| QUESTION = r"""
00150| Here's my plan for <change-name>:
00151| 
00152| **Problem**: <one-line summary>
00153| **Approach**: <core idea>
00154| **Key files**: <list>
00155| **Estimated tasks**: <count>
00156| 
00157| Proceed with this plan? Any adjustments?
00158| """
00159| ```
00160| 
00161| ### Confirmation Before Major Action
00162| 
00163| ```python
00164| REASON = r"""
00165| About to delete and recreate the database schema — irreversible action
00166| """
00167| 
00168| QUESTION = r"""
00169| I'm about to run the migration that drops and recreates the `users` table.
00170| This will delete all existing user data in dev.
00171| 
00172| Proceed? (yes/no)
00173| """
00174| ```
00175| 
00176| ---
00177| 
00178| ## Long Content Handling
00179| 
00180| If long reusable design doc / research finding / other drafts need to be attached:
00181| 
00182| 1. Write them in `.sspec/tmp/` as standalone files
00183| 2. Reference the file path in QUESTION
00184| 3. After user reply: move useful drafts to `change/reference/`, or discard
00185| 
00186| **Why**: Ask files should stay focused. Long content in QUESTION makes the `.md` record hard to review later.
00187| 
00188| ---
00189| 
00190| ## Memory Integration
00191| 
00192| Ask records serve as permanent decision documentation:
00193| 
00194| - Link completed ask `.md` files in handover.md Key Files when the decision is important
00195| - The ask record preserves context that handover.md summaries may lose (exact user wording, full option analysis)
00196| - Future agents can trace: handover says "chose Redis" → ask record explains the full discussion
00197| 
00198| ---
00199| 
00200| ## Guidelines
00201| 
00202| | Do | Don't |
00203| |----|-------|
00204| | Use descriptive topic name (`auth_approach`) | Use generic names (`q1`, `ask`, `question`) |
00205| | Keep topic name to letters and underscores only | Use non-ASCII or special characters |
00206| | Fill `REASON` with context for future reference | Leave `REASON` empty or vague |
00207| | Ask early when uncertain | Guess and risk rework |
00208| | Provide options when choices exist | Leave open-ended if you have candidates |
00209| | Batch related questions in one ask | Create 3 separate asks for related decisions |
00210| | Check project.md/spec-docs before asking | Ask for info that's already documented |
00211| | Link important ask records in handover.md | Let ask records become disconnected from change context |
00212| 

(End of file - total 212 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-change\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-change
00003| description: "Change lifecycle — scale assessment, document standards, status transitions, multi-change coordination. Consult when creating, filling, reviewing, or transitioning changes."
00004| metadata:
00005|   author: frostime
00006|   version: 1.0.0
00007| ---
00008| 
00009| # SSPEC Change Skill
00010| 
00011| Change lifecycle management. From scale assessment to archiving.
00012| 
00013| ## Playbook
00014| 
00015| ```
00016| IF need to assess scale                → Assess Scale
00017| IF creating spec.md/tasks.md           → [doc-standard](./references/doc-standards.md) + [doc-examples](./references/doc-examples.md)
00018| IF setting up multi-change             → [multi-change](./references/multi-change.md)
00019| 
00020| IF checking before PLANNING→DOING      → Pre-Execution Checklist
00021| IF checking before DOING→REVIEW        → Pre-Review Checklist
00022| IF handling blockers/rejection         → Edge Cases
00023| 
00024| IF updating handover.md                → Read SKILL `sspec-memory`
00025| IF uncertain about splitting           → @ask
00026| ```
00027| 
00028| ---
00029| 
00030| ## Assess Scale
00031| 
00032| **Micro** — ALL of: ≤3 files, ≤30min, no design decisions, trivially reversible.
00033| → Do directly or track in request file (`## Plan` / `## Done`). No change needed.
00034| 
00035| **Single** — ALL of: ≤1 week, ≤15 files in one subsystem, ≤20 tasks, low risk.
00036| → Standard change workflow. Fill spec.md / tasks.md / handover.md.
00037| 
00038| **Multi** — ANY of: >1 week, >15 files across subsystems, >20 tasks, high risk.
00039| → Root change (`--root`) + sub-changes. Read [multi-change](./references/multi-change.md) first.
00040| 
00041| **Uncertain?** Use `@ask` (`sspec ask create`) to consult user on splitting.
00042| 
00043| ---
00044| 
00045| ## Request → Change Flow
00046| 
00047| This is the most common workflow. Steps:
00048| 
00049| 1. **Link**: `sspec change new --from <request>` (auto-links and derives name)
00050| 2. **Understand**: First-principles — find the real problem, not the surface ask
00051| 3. **Research**: Read `project.md` + relevant code + `spec-docs/`. If unclear → **`sspec ask create`**
00052| 4. **Design**:
00053|    - Simple: Draft spec.md mentally, fill directly
00054|    - Complex (multi-scale): **`sspec ask create`** about splitting → `sspec change new <n> --root`
00055|    - Finalize: Distill into spec.md A/B/C. Follow [doc-standards](./references/doc-standards.md).
00056| 5. **Confirm**: **`sspec ask create`** to present plan. Wait for user approval.
00057| 6. **Execute**: Implement tasks. Update tasks.md after **each** task, not in batches.
00058| 
00059| **Principle**: Understand before acting. Wrong direction costs more than extra questions.
00060| 
00061| ### CLI Commands (Agent-Driven)
00062| 
00063| These commands are designed for Agent autonomous execution:
00064| 
00065| | Command | When | Input Notes |
00066| |---------|------|-------------|
00067| | `sspec change new <name>` | Creating a new change | `<name>` is a slug, e.g. `auth-refactor` |
00068| | `sspec change new --from <request>` | Creating from a request | `<request>` accepts name (fuzzy) or file path |
00069| | `sspec change new <name> --root` | Multi-change root | Generates root templates (milestones, not file-tasks) |
00070| | `sspec change find <name>` | Locating a change | Fuzzy match; returns details of change |
00071| | `sspec change list` | When can't locate change | Lists all active changes with status |
00072| 
00073| **Ergonomics**: `--from` is the most common path — Agent typically has a request to start from. The name derivation means Agent doesn't need to invent a name.
00074| 
00075| ---
00076| 
00077| ## Document Standards Summary
00078| 
00079| Templates use `@RULE` markers as inline reminders.
00080| 
00081| 📚 **Standards & rules**: [doc-standards.md](./references/doc-standards.md)
00082| 📚 **Detailed examples**: [doc-examples.md](./references/doc-examples.md)
00083| 
00084| **Quick Reference**:
00085| 
00086| ### spec.md Quick Reference
00087| 
00088| | Section | Key Requirement | Content |
00089| |---------|----------------|---------|
00090| | A. Problem | Quantify impact | "[metric] causing [impact]" — not "need to refactor" |
00091| | B. Solution | Design doc — What & Why | Approach + rationale + interfaces/data/logic (don't repeat in C) |
00092| | C. Implementation | Execution plan — How | Reference B, list phases/files, don't repeat B's design |
00093| | D. Blockers | Dated entries | "Blocker (YYYY-MM-DD): what \| needed" |
00094| 
00095| **Core Distinction**:
00096| - **B = Design** (interfaces, data models, key logic) — explain WHY and HOW it works
00097| - **C = Plan** (phases, file scope) — organize execution, reference B not repeat
00098| - **tasks.md = Checklist** (file-level tasks, verification) — actionable items
00099| 
00100| **Frontmatter**: `status` (PLANNING|DOING|REVIEW|DONE|BLOCKED), `change-type` (single|sub|root), `reference` (array of links).
00101| 
00102| ### tasks.md Quick Reference
00103| 
00104| | Criterion | Standard |
00105| |-----------|----------|
00106| | Granularity | Each task <2h, independently testable |
00107| | Verification | Each task/phase has explicit pass criteria |
00108| | Progress | Update after completing **EACH** task |
00109| | Phase Emoji | 🚧 in progress, ✅ done, ⏳ pending |
00110| 
00111| ### handover.md
00112| 
00113| handover.md standards are owned by `sspec-memory` SKILL. But as a change author, remember:
00114| - Fill Background on first session (write-once unless scope changes)
00115| - Update "Accomplished" and "Next Steps" at minimum at session end
00116| - Update "References & Memory" proactively during work
00117| - 📚 Full handover quality guidance: Consult `sspec-memory` SKILL
00118| 
00119| ---
00120| 
00121| ## Edge Cases
00122| 
00123| ### Partial Blockers
00124| 
00125| - Blocked tasks are dependencies for remaining → BLOCKED, document in spec.md D
00126| - Blocked tasks are non-critical → Continue others, note in spec.md D
00127| - Ambiguous → `@ask` or split into two changes
00128| 
00129| ### REVIEW Across Sessions
00130| 
00131| Keep status REVIEW. Note "Awaiting review since \<date\>" in handover. Can start other work. Next session: prompt user for review first.
00132| 
00133| ### Rejection (@argue)
00134| 
00135| AGENTS.md says STOP. Then assess scope of rejection:
00136| - Implementation detail → update tasks.md only
00137| - Design decision → revise spec.md B + regenerate tasks.md
00138| - Requirement itself → revise spec.md A, mark PIVOT in D, transition DOING→PLANNING
00139| 
00140| ### Multiple Active Changes
00141| 
00142| ≤2 in DOING simultaneously. Switch: `@handover` current → `@change <other>` → read other's handover.
00143| 
00144| ### Design Iteration Loop
00145| 
00146| spec.md keeps being revised → Archive current to `reference/spec-v1.md` → Brainstorm in `reference/` → Iterate via `@ask` → Write final to spec.md.
00147| 
00148| ---
00149| 
00150| ## Pre-Execution Checklist
00151| 
00152| Before transitioning PLANNING → DOING (user has approved):
00153| 
00154| - [ ] spec.md A: problem quantified?
00155| - [ ] spec.md B: approach + rationale present?
00156| - [ ] spec.md C: file-level tasks listed (single/sub) or phases listed (root)?
00157| - [ ] tasks.md: each task <2h with pass criteria?
00158| - [ ] spec.md reference field: linked to originating request?
00159| - [ ] If sub-change: linked to root via `type: "root-change"`?
00160| 
00161| ## Pre-Review Checklist
00162| 
00163| Before transitioning DOING → REVIEW:
00164| 
00165| - [ ] All tasks `[x]` in tasks.md?
00166| - [ ] Verification criteria met per task?
00167| - [ ] spec.md D: no undocumented blockers?
00168| - [ ] Code tested and passing?
00169| - [ ] Architecture change? → spec-doc updated?
00170| - [ ] handover.md reflects completion state?
00171| - [ ] tasks.md progress shows 100%?
00172| 
00173| ---
00174| 
00175| ## Anti-Patterns
00176| 
00177| | Bad | Correct |
00178| |-----|---------|
00179| | Skip spec.md, jump to coding | Fill A/B/C first — even brief is better than nothing |
00180| | Mark `[x]` without testing | Done = coded **AND** verified |
00181| | No file paths in spec.md C | List specific `path/file:function()` per task |
00182| | Stay DOING when blocked | BLOCKED immediately + document in D |
00183| | Skip REVIEW status | DOING → REVIEW → DONE, no shortcuts |
00184| | Batch progress updates | Update tasks.md after **each** task |
00185| | Create change for trivial fix | Micro: do directly or track in request |
00186| | Start coding before `@ask` approval | Confirm plan first — wrong direction costs more |
00187| 
00188| ---
00189| 
00190| ## References
00191| 
00192| | When | Load |
00193| |------|------|
00194| | Filling or reviewing spec.md / tasks.md | [doc-standards.md](./references/doc-standards.md) |
00195| | Need concrete examples | [doc-examples.md](./references/doc-examples.md) |
00196| | Setting up multi-change structure | [multi-change.md](./references/multi-change.md) |
00197| | Filling or reviewing handover.md | 📚 `sspec-memory` SKILL |
00198| 

(End of file - total 198 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-memory\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-memory
00003| description: "Knowledge persistence across sessions — routing, handover quality, long-session memory, project-level notes. Consult when deciding where knowledge goes, performing handover, or managing memory proactively."
00004| metadata:
00005|   author: frostime
00006|   version: 1.0.0
00007| ---
00008| 
00009| # SSPEC Memory Skill
00010| 
00011| Knowledge persistence and handover management. Where knowledge goes, how it's maintained, when to write it.
00012| 
00013| ## Playbook
00014| 
00015| | You need to... | Action |
00016| |----------------|--------|
00017| | Decide where knowledge belongs | Knowledge Routing below |
00018| | Fill or review handover.md | Read [handover-standards] |
00019| | Perform end-of-session handover | @handover Procedure below |
00020| | Preserve important info mid-session | Long Session Memory below |
00021| | Promote learning to project level | Memory Lifecycle below |
00022| | Create/update a spec-doc | 📚 Consult `write-spec-doc` SKILL |
00023| 
00024| ---
00025| 
00026| ## Memory Hierarchy
00027| 
00028| sspec maintains knowledge at four levels. Each has different scope and lifecycle:
00029| 
00030| | Level | Carrier | Lifecycle | Write Timing | Example |
00031| |-------|---------|-----------|-------------|---------|
00032| | **Record-level** | `requests/` + `asks/` | Permanent audit trail | On creation (CLI-managed) | Why we started this work; what user decided |
00033| | **Change-level** | `handover.md` | Created with change, archived with change | During work + session end | "Redis chosen over Memcached for per-key TTL" |
00034| | **Project-level** | `project.md` Notes & Conventions | Project lifetime | Promoted from handover at session end | "2026-02-10: ruff format breaks multiline strings in templates" |
00035| | **Specification-level** | `spec-docs/` | Survives beyond any single change | On architecture changes | Full auth system design document |
00036| 
00037| ### Record-Level: requests/ and asks/
00038| 
00039| These are often overlooked but serve critical memory functions:
00040| 
00041| - **requests/**: The "why" record. When a change is archived, the originating request remains as evidence of user intent. Future agents can trace back: "Why did we build this?" → read the request.
00042| - **asks/**: The decision evidence chain. `handover.md` Decisions & Rationale captures conclusions; the original ask `.md` preserves the full discussion process (question framing, user's exact words, context at time of decision).
00043| 
00044| **Practical use**: When resuming work or reviewing past decisions, check `asks/` for the discussion record, not just handover.md for the summary.
00045| 
00046| ---
00047| 
00048| ## Knowledge Routing
00049| 
00050| Where does a piece of knowledge go?
00051| 
00052| | Test | → Destination |
00053| |------|---------------|
00054| | One-liner, applies across all work | `project.md` **Conventions** |
00055| | Project-wide gotcha, preference, learning | `project.md` **Notes** (append with date) |
00056| | Needs paragraphs, diagrams, or sections | `spec-docs/` → 📚 `write-spec-doc` SKILL |
00057| | File path critical to current work | `handover.md` **Key Files** |
00058| | Non-trivial decision with reasoning | `handover.md` **Decisions & Rationale** |
00059| | Edge case, implicit knowledge, gotcha | `handover.md` **Gotchas & Context** |
00060| | Why we're doing this work at all | Already in `requests/` — just link via reference field |
00061| | User's exact decision on a design question | Already in `asks/` — link in handover Key Files |
00062| 
00063| **Decision principle**: If unsure between handover and project.md → write to handover first. Promote to project.md at session end if it's truly project-wide.
00064| 
00065| ---
00066| 
00067| ## @handover Procedure
00068| 
00069| ### End-of-Session (Mandatory)
00070| 
00071| Before ending any session:
00072| 
00073| 1. **Accomplished**: List what got done this session (specific, not "made progress")
00074| 2. **Next Steps**: 1-3 specific file-level actions for the next agent
00075| 3. **References & Memory**: Review and update all three sub-sections:
00076|    - Key Files — all critical files listed?
00077|    - Decisions & Rationale — non-obvious choices captured with full reasoning?
00078|    - Gotchas & Context — edge cases, risks, implicit knowledge recorded?
00079| 4. **Project-level promotion**: Append project-wide learnings to `project.md` Notes
00080| 5. **Progress sync**: Verify tasks.md progress percentage matches reality
00081| 
00082| ### Mid-Session (Proactive)
00083| 
00084| **Trigger** — update handover.md immediately when ANY of:
00085| - Session getting long (>50 exchanges or complex multi-file work)
00086| - Important decision just made with non-trivial reasoning
00087| - Key file discovered that future work depends on
00088| - Design tradeoff resolved after discussion
00089| 
00090| **Action**: Append to "References & Memory" only. Quick, targeted, no ceremony.
00091| 
00092| **Principle**: If you'd struggle to reconstruct info after context compression, write it to handover NOW. Context compression is silent — you won't notice lost information until it's too late.
00093| 
00094| ---
00095| 
00096| ## Long Session Memory Management
00097| 
00098| Context window has hard limits; compression is silent and lossy — Agent won't notice lost context.
00099| 
00100| ### When to Act
00101| 
00102| - Session feels long (>50 exchanges)
00103| - Multi-file complex work in progress
00104| - Extensive design discussion has occurred
00105| - You're about to switch between files/topics
00106| 
00107| ### What to Do
00108| 
00109| 1. Write key decisions, file refs, and gotchas to handover.md "References & Memory"
00110| 2. Continue working — handover.md is the safety net against compression
00111| 3. If previously-discussed info seems missing from memory, **re-read handover.md**
00112| 
00113| ### Memory Check
00114| 
00115| At any point during a long session, quickly verify:
00116| 
00117| - Any important decision in recent messages not yet in handover?
00118| - Any key file paths discussed but not recorded in Key Files?
00119| - Any design rationale that would be hard to reconstruct?
00120| - Any gotcha or edge case discovered but not written down?
00121| 
00122| → If yes to any: update handover.md now. Quick append, no ceremony.
00123| 
00124| ---
00125| 
00126| ## Memory Lifecycle
00127| 
00128| ```
00129| Discovery
00130|     ↓
00131| Write to handover.md immediately
00132|     ↓
00133| At session end: promote project-wide items to project.md
00134|     ↓
00135| Next session start: prune stale handover entries
00136|     ↓
00137| If architecture-level: create/update spec-doc
00138| ```
00139| 
00140| ### Promotion Rules
00141| 
00142| | From | To | Condition |
00143| |------|----|-----------|
00144| | handover.md Gotchas | project.md Notes | Applies beyond this change |
00145| | handover.md Decisions | project.md Conventions | Becomes a project-wide rule |
00146| | handover.md (complex) | spec-docs/ | Needs paragraphs, diagrams, or is referenceable across changes |
00147| | project.md Notes | project.md Conventions | Confirmed as permanent rule |
00148| | project.md Notes | (pruned) | Becomes outdated or irrelevant |
00149| 
00150| ### Session Start Review
00151| 
00152| When resuming work:
00153| 
00154| 1. Read `project.md` — check Notes for recent additions
00155| 2. Read `handover.md` — especially References & Memory
00156| 3. Check if any handover entries are now stale (resolved blockers, completed tasks)
00157| 4. Clean up stale entries to keep handover focused
00158| 
00159| ---
00160| 
00161| ## handover.md Quality Standards
00162| 
00163| Full quality criteria in [handover-standards.md](./references/handover-standards.md).
00164| 
00165| Quick quality test:
00166| 1. **Cross-session**: Can a new Agent resume in <30 seconds?
00167| 2. **Intra-session**: If context were compressed right now, could you continue from handover.md alone?
00168| 
00169| If either answer is "no" → update handover immediately.
00170| 
00171| ---
00172| 
00173| ## References
00174| 
00175| | When | Load |
00176| |------|------|
00177| | Filling or reviewing handover.md | [handover-standards.md](./references/handover-standards.md) |
00178| | Creating or updating spec-docs | 📚 `write-spec-doc` SKILL |
00179| 

(End of file - total 179 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-mdtoc\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-mdtoc
00003| description: "Pre-scan Markdown files before reading. Use `sspec tool mdtoc` to get file size + heading structure with line numbers (L<n> format) before reading long docs, SKILLs, or spec-docs. Eliminates blind reads."
00004| ---
00005| 
00006| # sspec-mdtoc — Markdown Pre-scan Skill
00007| 
00008| ## When to Use
00009| 
00010| Before reading ANY Markdown file you haven't seen before:
00011| - Long spec-docs, SKILL files, or AGENTS.md
00012| - README or documentation files
00013| - Any `.md` you need to understand structurally first
00014| 
00015| **Rule**: If you'd read a file top-to-bottom without knowing its size, run mdtoc first.
00016| 
00017| ## Command
00018| 
00019| ```
00020| sspec tool mdtoc <source> [--depth N]
00021| ```
00022| 
00023| | Source Type | Example | Behavior |
00024| |-------------|---------|----------|
00025| | File path | `sspec tool mdtoc README.md` | Analyzes single file |
00026| | Directory | `sspec tool mdtoc docs/` | Globs all `*.md` recursively |
00027| | Glob | `sspec tool mdtoc "**/*.md"` | Matches pattern |
00028| | Default | `sspec tool mdtoc` | Current directory |
00029| 
00030| `--depth N`: Limit heading depth (1-6, default: 6)
00031| 
00032| ## Output Format
00033| 
00034| ```
00035| === path/to/file.md ===
00036| chars: 4,523 | lines: 120
00037| 
00038| L1     # Document Title
00039| L5       ## Section One
00040| L12      ## Section Two
00041| L18        ### Subsection A
00042| L25        ### Subsection B
00043| L30      ## Section Three
00044| ```
00045| 
00046| - `L<n>` — 1-based line number of the heading
00047| - Indent reflects heading hierarchy
00048| - `chars` and `lines` tell you how large the file is before you read it
00049| 
00050| ## Typical Workflow
00051| 
00052| ```
00053| 1. sspec tool mdtoc <file>     # Get outline + line ranges
00054| 2. Identify sections of interest
00055| 3. read_file(startLine=<Ln>, endLine=<next_Ln>)  # Targeted read
00056| ```
00057| 
00058| **Multi-file summary** is shown automatically when scanning a directory:
00059| ```
00060| Found 8 files | total chars: 42,310 | total lines: 1,205 | headings: 87
00061| ```
00062| 
00063| ## Example: Analyzing a SKILL before reading
00064| 
00065| ```bash
00066| # Instead of blindly reading the entire skill:
00067| sspec tool mdtoc .sspec/skills/sspec-change/SKILL.md
00068| 
00069| # Output shows it has 198 lines with these sections:
00070| # L1   # SSPEC Change Skill
00071| # L8     ## Playbook
00072| # L24    ## Assess Scale
00073| # L35    ## Request → Change Flow
00074| # ...
00075| 
00076| # Now read only the section you need:
00077| # read_file(startLine=35, endLine=55)
00078| ```
00079| 
00080| ## Full Specification
00081| 
00082| To get the complete LLM-optimized specification:
00083| ```
00084| sspec tool mdtoc --prompt
00085| ```
00086| 

(End of file - total 86 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\write-spec-doc\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: write-spec-doc
00003| description: Guide for writing project specifications in .sspec/spec-docs/. Use when creating or updating spec documents.
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # Write-Spec
00010| 
00011| This skill covers:
00012| - [When to Create](#when-to-create) (L25-42) - Decision criteria
00013| - [Frontmatter](#frontmatter) (L43-69) - Required metadata fields
00014| - [Body Structure](#body-structure) (L70-107) - Template and organization
00015| - [Scope Definition](#scope-definition) (L108-123) - File path patterns
00016| - [Style Guide](#style-guide) (L124-154) - What to include/exclude
00017| - [Diagramming](#diagramming) (L155-179) - Mermaid examples
00018| - [Relationship to Changes](#relationship-to-changes) (L180-198) - Keeping specs current
00019| - [Deprecation](#deprecation) (L199-207) - Archiving obsolete specs
00020| - [Multi-File Specs](#multi-file-specs) (L208-225) - Complex subsystems
00021| - [Examples](#examples) (L226-235) - Good vs bad specs
00022| - [Maintenance Checklist](#maintenance-checklist) (L236-END) - Review triggers
00023| 
00024| 
00025| ## When to Create
00026| 
00027| Create a spec-doc when:
00028| - A subsystem has design decisions that aren't obvious from code alone
00029| - Multiple changes will touch the same area and need shared context
00030| - The architecture involves non-trivial component interactions
00031| - API contracts need to be documented for external consumers
00032| - A convention or standard applies across multiple files/modules
00033| 
00034| **Don't create** when:
00035| - Code comments and type signatures adequately capture the design
00036| - The topic is a single-file implementation detail
00037| - The information would duplicate framework/library documentation
00038| 
00039| **Rule of thumb**: If a new developer would need 10+ minutes to understand the design intent from code alone, it deserves a spec-doc.
00040| 
00041| ---
00042| 
00043| ## Frontmatter
00044| 
00045| ```yaml
00046| ---
00047| name: Authentication System
00048| description: JWT-based auth with refresh tokens and rate limiting
00049| updated: 2026-01-27
00050| scope:
00051|   - /src/auth/**
00052|   - /src/middleware/auth.ts
00053|   - /config/security.ts
00054| deprecated: false
00055| replacement: ""
00056| ---
00057| ```
00058| 
00059| | Field | Required | Description |
00060| |-------|----------|-------------|
00061| | `name` | Yes | Spec title |
00062| | `description` | Yes | One-sentence summary |
00063| | `updated` | Yes | Last modification (YYYY-MM-DD) |
00064| | `scope` | Yes | File paths this spec covers (glob patterns) |
00065| | `deprecated` | No | `true` if spec is obsolete |
00066| | `replacement` | No | Path to new spec (if deprecated) |
00067| 
00068| ---
00069| 
00070| ## Body Structure
00071| 
00072| The structure should match the **type of spec**:
00073| 
00074| ### Architecture Spec
00075| ```markdown
00076| # <System Name>
00077| ## Overview
00078| ## Architecture (with Mermaid diagram)
00079| ## Components
00080| ## Key Decisions
00081| ## Configuration
00082| ## Testing Requirements
00083| ```
00084| 
00085| ### API Contract Spec
00086| ```markdown
00087| # <API Name>
00088| ## Overview (Base URL, Auth)
00089| ## Endpoints
00090| ## Data Models
00091| ## Rate Limits
00092| ## Versioning Policy
00093| ```
00094| 
00095| ### Convention / Standard Spec
00096| ```markdown
00097| # <Convention Name>
00098| ## Overview (Purpose, Applies to)
00099| ## Rules
00100| ## Examples
00101| ## Exceptions
00102| ```
00103| 
00104| Key principle: **structure serves content**. Don't force an architecture template on an API contract.
00105| 
00106| ---
00107| 
00108| ## Scope Definition
00109| 
00110| Agents use `scope` to find relevant files. Use glob patterns:
00111| 
00112| ```yaml
00113| scope:
00114|   - /src/auth/**           # All files in directory
00115|   - /src/middleware/auth.ts # Specific file
00116|   - /tests/auth/**         # Tests
00117| ```
00118| 
00119| **Include**: Primary implementation, tests, config.
00120| **Omit**: Generic utilities unless domain-specific.
00121| 
00122| ---
00123| 
00124| ## Style Guide
00125| 
00126| ### MUST Include
00127| 1. File paths for every component
00128| 2. Concrete values ("15min expiry" not "short expiry")
00129| 3. Decision rationale (why this design, what trade-offs)
00130| 4. Diagrams for architecture and flows
00131| 
00132| ### MUST NOT Include
00133| 1. Change logs (history lives in git)
00134| 2. Multiple unrelated topics
00135| 3. Marketing language
00136| 4. Vague statements — quantify everything
00137| 5. Common knowledge (don't explain REST, HTTP)
00138| 
00139| ### Language
00140| - **Imperative mood**: "Validate tokens" not "The system should validate"
00141| - **Direct**: Avoid "It's worth noting...", "As mentioned earlier..."
00142| - **Precise**: "Use Redis (5min TTL)" not "Consider using Redis"
00143| 
00144| ### File Links
00145| 
00146| 1. **Simple Relative Paths**: For same-level, sub-directories, or up to 2 levels of parent.
00147|    - `[Link](./other-spec.md)`
00148|    - `[Link](../../base.md)` (Max two `../`)
00149| 2. **Workspace-Relative Paths**: For different branches or >2 parent levels. Start with `/`.
00150|    - `[Link](/src/core.py)`
00151| 3. Use forward slashes `/` for cross-platform compatibility.
00152| 
00153| ---
00154| 
00155| ## Diagramming
00156| 
00157| Use Mermaid. Architecture example:
00158| ```mermaid
00159| graph TD
00160|     A[Client] -->|HTTPS| B[Load Balancer]
00161|     B --> C[App Server 1]
00162|     B --> D[App Server 2]
00163|     C --> E[(Database)]
00164|     D --> E
00165| ```
00166| 
00167| Sequence example:
00168| ```mermaid
00169| sequenceDiagram
00170|     Client->>+API: POST /login
00171|     API->>+Auth: validate(email, password)
00172|     Auth-->>-API: JWT token
00173|     API-->>-Client: {accessToken}
00174| ```
00175| 
00176| Avoid ASCII art.
00177| 
00178| ---
00179| 
00180| ## Relationship to Changes
00181| 
00182| ### Change Creates a Spec-Doc
00183| Link via reference field:
00184| ```yaml
00185| reference:
00186|   - source: "spec-docs/auth-system.md"
00187|     type: "doc"
00188| ```
00189| 
00190| ### Change Modifies an Existing Spec-Doc
00191| 1. Add task in tasks.md: "Update spec-doc `spec-docs/<n>.md`"
00192| 2. Update the spec-doc's `updated` field and affected sections
00193| 3. Verify `scope` still matches actual files
00194| 
00195| **Principle**: Spec-docs should never be silently outdated by a change.
00196| 
00197| ---
00198| 
00199| ## Deprecation
00200| 
00201| 1. Mark: `deprecated: true`, `replacement: /path/to/new.md`
00202| 2. Move to `spec-docs/archive/`
00203| 3. Add notice: `> ⚠️ **DEPRECATED**: Replaced by [New Spec](../new.md)`
00204| 4. Strip details, keep only: what it was, why deprecated, link to replacement
00205| 
00206| ---
00207| 
00208| ## Multi-File Specs
00209| 
00210| ```
00211| spec-docs/payment-system/
00212| ├── index.md          # Entry point
00213| ├── gateway.md
00214| ├── webhooks.md
00215| └── reconciliation.md
00216| ```
00217| 
00218| Rules:
00219| - index.md is the entry point with overview + navigation
00220| - Each sub-file has its own frontmatter with narrowed scope
00221| - Cross-references use relative paths
00222| - Shared concepts go in index.md
00223| 
00224| ---
00225| 
00226| ## Examples
00227| 
00228| ### Good Spec
00229| Concrete, quantified, has file paths, diagrams, and configuration tables.
00230| 
00231| ### Bad Spec
00232| "Welcome to our revolutionary API!" — marketing fluff, no concrete info, no file paths, includes unbuilt features.
00233| 
00234| ---
00235| 
00236| ## Maintenance Checklist
00237| - [ ] `updated` field current
00238| - [ ] `scope` matches actual files
00239| - [ ] Diagrams reflect current architecture
00240| - [ ] Code examples compile
00241| - [ ] Links to other specs valid
00242| 

(End of file - total 242 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\write-patch\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: write-patch
00003| description: Use patch files + `sspec tool patch` for code modifications instead of direct file edits. Trigger when user requests patch-based workflow.
00004| metadata:
00005|   author: frostime
00006|   version: 1.0.0
00007| ---
00008| 
00009| # Write-Patch Skill
00010| 
00011| ## Workflow
00012| 
00013| 1. **Generate patch file** (e.g., `fix-typo.patch.md`)
00014| 2. **Apply**: `sspec tool patch fix-typo.patch.md`
00015| 3. **Verify**: Check output, inspect failed patches if any
00016| 
00017| ### Example Session
00018| 
00019| ```
00020| Agent: I'll create a patch file for these changes.
00021| 
00022| # fix-imports.patch.md
00023| # src/utils.py
00024| <<<<<<< SEARCH
00025| from typing import List
00026| =======
00027| from typing import List, Dict
00028| >>>>>>> REPLACE
00029| 
00030| # src/config.py
00031| <<<<<<< SEARCH
00032| DEBUG = True
00033| =======
00034| DEBUG = False
00035| >>>>>>> REPLACE
00036| 
00037| Agent: Apply with: `sspec tool patch fix-imports.patch.md`
00038| ```
00039| 
00040| ## Patch Format
00041| 
00042| Each patch block consists of:
00043| 
00044| 1. **File path line** (required, precedes SEARCH marker)
00045| 2. **SEARCH/REPLACE block** (markers must be alone on their line)
00046| 
00047| ### Simple Patch (No Line Range)
00048| 
00049| ```text
00050| # path/to/file.py
00051| <<<<<<< SEARCH
00052| old_code_here()
00053| =======
00054| new_code_here()
00055| >>>>>>> REPLACE
00056| ```
00057| 
00058| ### With Line Range (Reduce Ambiguity)
00059| 
00060| ```text
00061| # src/utils.py:10-25
00062| <<<<<<< SEARCH
00063| old_code_here()
00064| =======
00065| new_code_here()
00066| >>>>>>> REPLACE
00067| ```
00068| 
00069| Line range formats: `:10-25` or `:L10-L25` (both 1-based, inclusive)
00070| 
00071| ## Critical Rules
00072| 
00073| 1. **Exact Match Required**: SEARCH content must match file exactly (including indentation)
00074| 2. **Unique Match**: If SEARCH matches multiple locations → patch fails (use line range)
00075| 3. **Non-Empty SEARCH**: Empty SEARCH blocks are rejected (avoid accidental changes)
00076| 4. **Relative Paths Only**: Must be relative to project root or absolute path, no `..` traversal
00077| 5. **Marker Precision**: Markers `<<<<<<< SEARCH`, `=======`, `>>>>>>> REPLACE` must be alone on their line
00078| 
00079| ## Common Patterns
00080| 
00081| ### Adding Code
00082| 
00083| ```text
00084| # src/app.py
00085| <<<<<<< SEARCH
00086| def main():
00087|     setup()
00088|     return 0
00089| =======
00090| def main():
00091|     setup()
00092|     init_logging()    # Added
00093|     return 0
00094| >>>>>>> REPLACE
00095| ```
00096| 
00097| ### Removing Code
00098| 
00099| ```text
00100| # config.py
00101| <<<<<<< SEARCH
00102| DEBUG = True
00103| VERBOSE = True
00104| =======
00105| DEBUG = True
00106| >>>>>>> REPLACE
00107| ```
00108| 
00109| ### Multiple Changes in One File
00110| 
00111| Create separate SEARCH/REPLACE blocks:
00112| 
00113| ```text
00114| # server.py:10-20
00115| <<<<<<< SEARCH
00116| PORT = 8080
00117| =======
00118| PORT = 3000
00119| >>>>>>> REPLACE
00120| 
00121| # server.py:45-60
00122| <<<<<<< SEARCH
00123| log.info("Starting")
00124| =======
00125| log.info("Server starting on port %d", PORT)
00126| >>>>>>> REPLACE
00127| ```
00128| 
00129| ## Matching Behavior
00130| 
00131| 1. **Exact match** (preferred): Whitespace and content match perfectly
00132| 2. **Loose match** (fallback): Ignores trailing spaces/tabs, collapses blank lines
00133| 3. **If multiple matches found**: Patch fails → add line range
00134| 
00135| ## Best Practices
00136| 
00137| ### Include Context Lines
00138| 
00139| **Bad** (too short, ambiguous):
00140| ```text
00141| <<<<<<< SEARCH
00142| return x
00143| =======
00144| return x * 2
00145| >>>>>>> REPLACE
00146| ```
00147| 
00148| **Good** (sufficient context):
00149| ```text
00150| <<<<<<< SEARCH
00151| def compute(x):
00152|     result = validate(x)
00153|     return x
00154| =======
00155| def compute(x):
00156|     result = validate(x)
00157|     return x * 2
00158| >>>>>>> REPLACE
00159| ```
00160| 
00161| ### Use Line Ranges for Ambiguous Searches
00162| 
00163| When the same code pattern appears multiple times:
00164| ```text
00165| # utils.py:42-50
00166| <<<<<<< SEARCH
00167| if value is None:
00168|     return default
00169| =======
00170| if value is None:
00171|     raise ValueError("Value required")
00172| >>>>>>> REPLACE
00173| ```
00174| 
00175| ### Preserve Indentation
00176| 
00177| Match the file's indentation style exactly:
00178| ```text
00179| # main.py
00180| <<<<<<< SEARCH
00181|     def process(self):
00182|         data = self.load()
00183|         return data
00184| =======
00185|     def process(self):
00186|         data = self.load()
00187|         validated = self.validate(data)
00188|         return validated
00189| >>>>>>> REPLACE
00190| ```
00191| 
00192| ## Anti-Patterns
00193| 
00194| ❌ **Don't use placeholders or ellipsis**:
00195| ```text
00196| # BAD
00197| <<<<<<< SEARCH
00198| def foo():
00199|     ... existing code ...
00200|     return result
00201| =======
00202| ```
00203| 
00204| ✅ **Include actual code**:
00205| ```text
00206| # GOOD
00207| <<<<<<< SEARCH
00208| def foo():
00209|     x = compute()
00210|     y = transform(x)
00211|     return result
00212| =======
00213| ```
00214| 
00215| ❌ **Don't mix line endings** (if file uses `\r\n`, SEARCH should too)
00216| 
00217| ## Tool Options
00218| 
00219| ```bash
00220| sspec tool patch [PATCH_FILE] [OPTIONS]
00221| 
00222| --dry-run              # Preview without applying
00223| --yes                  # Skip confirmation
00224| --output-failed DIR    # Custom dir for failed patches
00225| --file, -f PATH        # Read patch text from file (alternative to positional PATCH_FILE)
00226| --input, -i            # Enter patch text interactively (default when no file is provided)
00227| --prompt               # Show format specification
00228| ```
00229| 
00230| ## See Also
00231| 
00232| - `sspec tool patch --prompt` — Full specification
00233| - `sspec tool patch --help` — Command options
00234| 

(End of file - total 234 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.2s)

_Thinking:_

**Reviewing legacy reference handling**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-change\\references\\doc-standards.md"
}
```
**Output:**
```
<file>
00001| # Document Standards: spec.md & tasks.md
00002| 
00003| Quality criteria and filling guidance. Load when writing or reviewing these documents.
00004| 
00005| ## Table of Contents
00006| 
00007| - [spec.md](#specmd) (L14-167) — Frontmatter, Sections A/B/C/D
00008| - [tasks.md](#tasksmd) (L168-229) — Granularity, phases, verification
00009| - [Optional Directories](#optional-directories) (L230-258) — reference/ etc.
00010| - [Anti-Patterns](#anti-patterns) (L259-END)
00011| 
00012| ---
00013| 
00014| ## spec.md
00015| 
00016| ### Frontmatter Schema
00017| 
00018| ```yaml
00019| ---
00020| name: <change-name>           # Auto-filled by CLI
00021| status: PLANNING               # PLANNING | DOING | REVIEW | DONE | BLOCKED
00022| type: ""                       # User-defined label (optional)
00023| change-type: single            # single | sub | root
00024| created: <iso-timestamp>       # Auto-filled by CLI
00025| reference: null                # Array<{source, type, note?}> or null
00026| ---
00027| ```
00028| 
00029| **`change-type`**:
00030| - `single`: Standalone change (default)
00031| - `sub`: Part of a multi-change; must have `reference` linking to root
00032| - `root`: Coordinator for sub-changes; spec.md C lists phases, not file-level tasks
00033| 
00034| **`reference`** field types:
00035| 
00036| | RefType | Meaning | Example |
00037| |---------|---------|---------|
00038| | `request` | Originating user request | `{source: "requests/26-02-05_auth.md", type: "request"}` |
00039| | `root-change` | Parent root change (used in sub) | `{source: "changes/auth-root", type: "root-change"}` |
00040| | `sub-change` | Child sub-change (used in root) | `{source: "changes/auth-phase1", type: "sub-change"}` |
00041| | `doc` | Related spec-doc | `{source: "spec-docs/auth-system.md", type: "doc"}` |
00042| 
00043| ### Section Standards
00044| 
00045| #### A. Problem Statement
00046| 
00047| **Standard**: Quantify impact. Format: "[metric] causing [impact]".
00048| 
00049| | Scenario | Approach |
00050| |----------|----------|
00051| | Simple change (≤5 files, clear scope) | Single paragraph. No sub-headings needed. |
00052| | Complex change (ambiguous scope, multiple stakeholders) | Split into "Current Situation" + "User Requirement" sub-headings |
00053| 
00054| | ❌ Fail | ✅ Pass |
00055| |---------|---------|
00056| | "Need to refactor" | "Auth takes 5s → 12% conversion drop" |
00057| | "Improve the UI" | "Form completion rate 23% → target 60%" |
00058| 
00059| #### B. Proposed Solution
00060| 
00061| **Standard**: Design document — What & Why. Includes approach, rationale, interface design, data models, and key logic.
00062| 
00063| **Core Purpose**: Describe the solution at the design level, not the execution level. This is where architectural decisions live.
00064| 
00065| **Required Sub-sections**:
00066| - **Approach**: Core idea (1-3 paragraphs) + why this over alternatives
00067| - **Key Changes**: Major modules, interfaces, dependencies affected
00068| 
00069| **Optional Sub-sections** (use when applicable):
00070| 
00071| | Sub-section | When to Include | Content |
00072| |-------------|-----------------|---------|
00073| | **Interface Design** | New/modified APIs, functions, classes | Function signatures, class structures, API contracts |
00074| | **Data Model** | New/modified data structures | Core data types, state machines, data flow diagrams |
00075| | **Key Logic** | Non-trivial algorithms or workflows | Pseudocode, edge cases, critical decision points |
00076| 
00077| **Complexity Scaling**:
00078| 
00079| | Complexity | Approach |
00080| |------------|----------|
00081| | **Simple** (≤5 files, clear logic) | Interface/data model inline in "Approach", brief mention |
00082| | **Medium** (5-15 files, cross-module) | Dedicated sub-sections (### Interface Design, ### Data Model) |
00083| | **Complex** (>15 files, architectural) | Detailed design in `reference/design.md` (follow write-spec-doc SKILL), link from Section B |
00084| 
00085| 📚 **Detailed examples**: See [doc-examples.md](./doc-examples.md)
00086| 
00087| **What NOT to include in B**:
00088| - Execution order (that's Section C)
00089| - File-level task lists (that's Section C or tasks.md)
00090| - Verification criteria (that's tasks.md)
00091| 
00092| #### C. Implementation Strategy
00093| 
00094| **Standard**: Execution plan — How to implement the design from Section B. Focus on phase division, file scope, dependencies, and risks.
00095| 
00096| **Core Purpose**: Break down the design (from B) into executable phases. Reference B's design decisions; don't re-describe them.
00097| 
00098| **Required Content**:
00099| 
00100| 1. **Phase Division**: Organize work into logical phases
00101| 2. **File Scope per Phase**: Which files are affected + brief "what" (not detailed "how" — that's in tasks.md)
00102| 3. **Dependencies** (if applicable): What must complete first
00103| 4. **Risks & Mitigations**: Technical risks + how to handle them
00104| 
00105| **Complexity Scaling**:
00106| 
00107| | Change Type | Phase Content |
00108| |-------------|---------------|
00109| | **single/sub** | File-level mentions: `path/file.py` — create/modify, brief what |
00110| | **root** | Milestone-level: one phase per sub-change, with goal/scope/dependencies |
00111| 
00112| **Key Principle**: **Reference Section B's design instead of repeating it**.
00113| 
00114| - ✅ "Implement Tool Interface per B"
00115| - ✅ "按 B 中描述的三种场景逻辑实现"
00116| - ❌ Re-listing all function signatures (that's in B)
00117| - ❌ Re-describing core algorithm (that's in B)
00118| 
00119| 📚 **Detailed examples**: See [doc-examples.md](./doc-examples.md)
00120| 
00121| **What NOT to include in C**:
00122| - Interface definitions (that's Section B)
00123| - Data model details (that's Section B)
00124| - Core algorithm logic (that's Section B)
00125| - Task-level verification criteria (that's tasks.md)
00126| 
00127| ---
00128| 
00129| ### spec.md vs tasks.md: When to Write What
00130| 
00131| **Core Distinction**:
00132| - **spec.md** (Sections B + C) = **Design + Plan** (What to build, Why this way, How to organize phases)
00133| - **tasks.md** = **Execution Checklist** (File-level tasks, check-off items, verification)
00134| 
00135| | Aspect | spec.md Section B | spec.md Section C | tasks.md |
00136| |--------|-------------------|-------------------|----------|
00137| | **Purpose** | Design doc — What & Why | Execution plan — Phase organization | Task checklist — What to do |
00138| | **Granularity** | Approach + Interfaces + Data + Logic | Phase-level file mentions | File/function-level tasks |
00139| | **Content** | Interface signatures, data models, core algorithms, design rationale | Phase division, file scope per phase, dependencies, risks | Actionable tasks (<2h each), verification criteria |
00140| | **Why vs What** | Why this approach, what's the design | How to organize execution | What files to change, what to verify |
00141| | **Complexity Scaling** | More design detail (interface/data/logic) as complexity grows | More phase breakdown as complexity grows | More task breakdown as complexity grows |
00142| | **Relationship** | Standalone design document | References B, doesn't repeat design | References C phases, distills into tasks |
00143| 
00144| **Rule of Thumb**:
00145| - If explaining **why** or **"how it works"** (design) → **spec.md Section B**
00146| - If organizing **phases** and **file scope** (plan) → **spec.md Section C**
00147| - If listing **actionable file-level steps** (checklist) → **tasks.md**
00148| - If uncertain → Write in spec.md B first, distill execution in C & tasks.md later
00149| 
00150| 📚 **Complete example flow** (Medium complexity): See [doc-examples.md](./doc-examples.md#complete-example-flow)
00151| 
00152| ---
00153| 
00154| #### D. Blockers & Feedback
00155| 
00156| **Standard**: Dated, actionable entries.
00157| 
00158| ```markdown
00159| ### Blocker (2026-02-10)
00160| **Blocked**: Redis connection pooling | **Needed**: DevOps to provide host:port
00161| 
00162| ### PIVOT (2026-02-12)
00163| Direction change: switched from JWT to session-based auth. Reason: client requires server-side revocation.
00164| ```
00165| 
00166| ---
00167| 
00168| ## tasks.md
00169| 
00170| ### Frontmatter
00171| 
00172| ```yaml
00173| ---
00174| change: "<change-name>"
00175| updated: ""                  # ISO date, updated by agent
00176| ---
00177| ```
00178| 
00179| Root changes additionally have `change-type: root`.
00180| 
00181| ### Task Granularity
00182| 
00183| | Change Type | Task Level | Example |
00184| |-------------|-----------|---------|
00185| | single / sub | File-level, <2h each | `- [ ] Create src/auth/jwt.py — refresh_token()` |
00186| | root | Milestone-level (one per sub-change) | `- [ ] Phase 1 sub-change completed and archived` |
00187| 
00188| ### Phase Structure
00189| 
00190| ```markdown
00191| ### Phase 1: <name> 🚧
00192| - [ ] Task description `path/file.py`
00193| - [ ] Task description `path/file.py`
00194| **Verification**: <how to verify this phase>
00195| ```
00196| 
00197| ### Phase Emoji Convention
00198| 
00199| | Emoji | Meaning |
00200| |-------|---------|
00201| | 🚧 | In progress — actively working |
00202| | ✅ | Done — all tasks completed and verified |
00203| | ⏳ | Pending — not yet started |
00204| 
00205| ### Progress Table
00206| 
00207| ```markdown
00208| **Overall**: 40%
00209| 
00210| | Phase | Progress | Status |
00211| |-------|----------|--------|
00212| | Phase 1 | 100% | ✅ |
00213| | Phase 2 | 30% | 🚧 |
00214| | Phase 3 | 0% | ⏳ |
00215| ```
00216| 
00217| **Critical Rule**: Update percentage and status after **EACH** task completion, not in batches. `sspec change status` auto-calculates from checkboxes — keep tasks.md as the single source of truth.
00218| 
00219| ### Verification Criteria
00220| 
00221| Each task (or at minimum each phase) must have explicit pass criteria:
00222| 
00223| | ❌ Vague | ✅ Specific |
00224| |----------|------------|
00225| | "Add tests" | "Add tests in `tests/test_jwt.py`, cover: valid token, expired token, malformed token" |
00226| | "Update config" | "Add `REDIS_URL` to `.env.example`, verify `config.py` reads it with fallback" |
00227| 
00228| ---
00229| 
00230| ## Optional Directories
00231| 
00232| ### reference/ (Design Iteration & Complex Designs)
00233| 
00234| **Purpose**: Store detailed design documents, research notes, and architectural exploration.
00235| 
00236| **Common Files**:
00237| 
00238| | File | Purpose | When to Create |
00239| |------|---------|----------------|
00240| | `design.md` | Detailed architecture spec (follow write-spec-doc SKILL) | Complex changes (>15 files, cross-module) |
00241| | `research.md` | Code investigation, dependency analysis, technical findings | Before design, after code exploration |
00242| | `comparison.md` | Technology/approach evaluation (pros/cons, tradeoffs) | Multiple viable solutions exist |
00243| | `benchmark.md` | Performance test results, stress test data | Performance-critical changes |
00244| | `spec-v*.md` | Design iteration history | When pivoting direction |
00245| 
00246| **Use Cases**:
00247| 1. **Complex Design**: Create `design.md` (follow write-spec-doc SKILL) → Link from spec.md Section B
00248| 2. **Research**: Explore codebase → Document findings in `research.md` → Inform design in spec.md B
00249| 3. **Iteration**: Draft in reference/ → `@ask` → Revise → Finalize to spec.md → Keep reference/ for record
00250| 
00251| **Workflow**:
00252| - **Complex**: `reference/design.md` → spec.md B links it → Keep for record
00253| - **Research**: `reference/research.md` → summarize in spec.md A (Problem) or B (Approach)
00254| - **Comparison**: `reference/comparison.md` → final choice in spec.md B
00255| - **Simple changes** (≤5 files): Skip reference/ entirely
00256| 
00257| ---
00258| 
00259| ## Anti-Patterns
00260| 
00261| | Bad Practice | Correct Approach |
00262| |--------------|------------------|
00263| | Missing interface design in B | Always define interfaces/data models in Section B, even if brief |
00264| | Repeating interface signatures in C | Reference Section B ("implement interface per B"), don't duplicate |
00265| | Repeating core logic in tasks.md | tasks.md lists tasks, not logic — logic lives in spec.md B |
00266| | No file mentions in C | Each phase should mention key files affected, even if not exhaustive |
00267| | Task list in spec.md C | Section C organizes phases, tasks.md has the checklist |
00268| | Mark `[x]` without testing | Done = coded **AND** verified |
00269| | Stay DOING when blocked | BLOCKED immediately + document in D |
00270| | Skip REVIEW status | DOING → REVIEW → DONE, no shortcuts |
00271| | Batch progress updates | Update tasks.md after **each** task |
00272| | Over-structure simple changes | Simple = brief inline design in B, flat phase list in C |
00273| | Forget reference field | Always link to originating request |
00274| 

(End of file - total 274 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-change\\references\\doc-examples.md"
}
```
**Output:**
```
<file>
00001| # Document Examples: spec.md & tasks.md
00002| 
00003| Detailed examples for spec.md and tasks.md standards. Load when you need concrete examples of how to write these documents.
00004| 
00005| **📚 For standards and rules**: See [doc-standards.md](./doc-standards.md)
00006| 
00007| ---
00008| 
00009| ## Table of Contents
00010| 
00011| - [Section B Examples](#section-b-examples) (L18-99) — Simple, Medium, Complex
00012| - [Section C Examples](#section-c-examples) (L100-155) — single/sub, root
00013| - [Complete Example Flow](#complete-example-flow) (L156-272) — B → C → tasks.md
00014| - [Duplication Avoidance](#duplication-avoidance) (L273-END)
00015| 
00016| ---
00017| 
00018| ## Section B Examples
00019| 
00020| ### Example 1: Simple (≤5 files, clear logic)
00021| 
00022| Interface/data model inline in Approach:
00023| 
00024| ```markdown
00025| ## B. Proposed Solution
00026| ### Approach
00027| Add JWT token refresh mechanism to reduce re-auth friction.
00028| 
00029| **Interface**: Modify `src/auth/jwt.py:validate_token()` to accept optional `refresh=True` param.
00030| Returns new token if expiry <5min.
00031| 
00032| **Why**: Refresh-on-expire simpler than standalone refresh endpoint; no client changes needed.
00033| 
00034| ### Key Changes
00035| - `src/auth/jwt.py` — token validation + refresh logic
00036| - `src/middleware/auth.py` — integrate refreshed token in response header
00037| ```
00038| 
00039| ---
00040| 
00041| ### Example 2: Medium (5-15 files, cross-module)
00042| 
00043| Dedicated sub-sections for Interface Design, Data Model, Key Logic:
00044| 
00045| ```markdown
00046| ## B. Proposed Solution
00047| ### Approach
00048| Implement Redis-based auth cache to reduce DB load (500 QPS → <50 QPS).
00049| 
00050| ### Interface Design
00051| **New Module**: `src/services/cache.py`
00052| - `get_cached_user(user_id: str) -> Optional[User]`
00053| - `set_cached_user(user: User, ttl: int = 300)`
00054| - `invalidate_user_cache(user_id: str)`
00055| 
00056| **Modified**: `src/services/auth.py`
00057| - `authenticate(token: str) -> User`: Add cache lookup before DB query
00058| 
00059| ### Data Model
00060| **Cache Key Format**: `user:<user_id>` → JSON serialized User
00061| **TTL**: 5 minutes (300s)
00062| 
00063| ### Key Logic
00064| 1. Check cache: `get_cached_user(user_id)`
00065| 2. If miss → query DB → `set_cached_user()`
00066| 3. On user update → `invalidate_user_cache()`
00067| 
00068| ### Key Changes
00069| - `src/services/cache.py` — new caching layer
00070| - `src/services/auth.py` — cache integration
00071| - `src/services/user.py` — cache invalidation on update
00072| ```
00073| 
00074| ---
00075| 
00076| ### Example 3: Complex (>15 files, architectural)
00077| 
00078| Link to detailed design in reference/:
00079| 
00080| ```markdown
00081| ## B. Proposed Solution
00082| ### Approach
00083| Refactor auth system to support multi-tenancy with role-based access control (RBAC).
00084| 
00085| **Design**: See `reference/auth-rbac-design.md` for full architecture, data model, and API contracts.
00086| 
00087| **Core Changes**:
00088| - Tenant isolation layer
00089| - Role-permission matrix
00090| - Token claims extension (tenant_id, roles)
00091| 
00092| ### Key Changes
00093| - `src/auth/` — complete refactor (see reference/)
00094| - `src/models/` — new Tenant, Role, Permission models
00095| - `src/middleware/` — tenant context injection
00096| ```
00097| 
00098| ---
00099| 
00100| ## Section C Examples
00101| 
00102| ### Example 1: single/sub change
00103| 
00104| File-level mentions, references Section B:
00105| 
00106| ```markdown
00107| ## C. Implementation Strategy
00108| 
00109| ### Phase 1: Cache Module
00110| - `src/services/cache.py` — create, implement interface per Section B
00111| - Uses Redis client from existing `config.py`
00112| 
00113| ### Phase 2: Auth Integration
00114| - `src/services/auth.py` — modify `authenticate()`, add cache lookup per B's Key Logic step 1-3
00115| - `src/services/user.py` — modify `update_user()`, add cache invalidation
00116| 
00117| ### Phase 3: Testing & Validation
00118| - `tests/test_cache.py` — create, cover get/set/invalidate
00119| - `tests/test_auth.py` — add cache hit/miss scenarios
00120| 
00121| ### Dependencies
00122| - Phase 2 depends on Phase 1 (cache module must exist)
00123| 
00124| ### Risks & Mitigations
00125| - **Risk**: Redis unavailable → **Mitigation**: Fallback to direct DB (try-except wrapper in cache.py)
00126| - **Risk**: Cache stampede on popular users → **Mitigation**: Add TTL jitter (±10%)
00127| ```
00128| 
00129| ---
00130| 
00131| ### Example 2: root change
00132| 
00133| Milestone-level (one phase per sub-change):
00134| 
00135| ```markdown
00136| ## C. Implementation Strategy
00137| 
00138| ### Phase 1: Tenant Isolation Layer
00139| - **Sub-change**: (filled when created via `sspec change new --from <root>`)
00140| - **Goal**: Tenant-scoped queries working in auth + user modules
00141| - **Dependencies**: None (foundational)
00142| - **Scope**: `src/models/tenant.py`, `src/auth/context.py`, `src/services/auth.py`, `src/services/user.py`
00143| 
00144| ### Phase 2: RBAC Layer
00145| - **Sub-change**: (filled when created)
00146| - **Goal**: Role-permission matrix functional, token claims extended
00147| - **Dependencies**: Phase 1 (requires tenant context)
00148| - **Scope**: `src/models/role.py`, `src/auth/jwt.py`, `src/middleware/rbac.py`
00149| 
00150| ### Risks
00151| - Phase 1 failure blocks entire change → Mitigation: Allocate extra buffer for Phase 1
00152| ```
00153| 
00154| ---
00155| 
00156| ## Complete Example Flow
00157| 
00158| Medium complexity change: Redis auth cache
00159| 
00160| ### Step 1: Section B (Design)
00161| 
00162| ```markdown
00163| ## B. Proposed Solution
00164| ### Approach
00165| Implement Redis-based auth cache to reduce DB load (500 QPS → <50 QPS).
00166| 
00167| ### Interface Design
00168| **New Module**: `src/services/cache.py`
00169| - `get_cached_user(user_id: str) -> Optional[User]`
00170| - `set_cached_user(user: User, ttl: int = 300)`
00171| - `invalidate_user_cache(user_id: str)`
00172| 
00173| **Modified**: `src/services/auth.py`
00174| - `authenticate(token: str) -> User`: Add cache lookup before DB query
00175| 
00176| ### Data Model
00177| **Cache Key Format**: `user:<user_id>` → JSON serialized User
00178| **TTL**: 5 minutes (300s)
00179| 
00180| ### Key Logic
00181| 1. Check cache: `get_cached_user(user_id)`
00182| 2. If miss → query DB → `set_cached_user()`
00183| 3. On user update → `invalidate_user_cache()`
00184| 
00185| ### Key Changes
00186| - `src/services/cache.py` — new caching layer
00187| - `src/services/auth.py` — cache integration
00188| - `src/services/user.py` — cache invalidation on update
00189| ```
00190| 
00191| ---
00192| 
00193| ### Step 2: Section C (Plan)
00194| 
00195| ```markdown
00196| ## C. Implementation Strategy
00197| 
00198| ### Phase 1: Cache Module
00199| - `src/services/cache.py` — create, implement interface per Section B
00200| - Uses Redis client from existing `config.py`
00201| 
00202| ### Phase 2: Auth Integration
00203| - `src/services/auth.py` — modify `authenticate()`, add cache lookup per B's Key Logic
00204| - `src/services/user.py` — modify `update_user()`, add cache invalidation
00205| 
00206| ### Phase 3: Testing & Validation
00207| - `tests/test_cache.py` — create, cover get/set/invalidate
00208| - `tests/test_auth.py` — add cache hit/miss scenarios
00209| 
00210| ### Dependencies
00211| - Phase 2 depends on Phase 1 (cache module must exist)
00212| 
00213| ### Risks & Mitigations
00214| - **Risk**: Redis unavailable → **Mitigation**: Fallback to direct DB (try-except in cache.py)
00215| - **Risk**: Cache stampede → **Mitigation**: Add TTL jitter (±10%)
00216| ```
00217| 
00218| ---
00219| 
00220| ### Step 3: tasks.md (Execution)
00221| 
00222| ```markdown
00223| ---
00224| change: "auth-cache"
00225| updated: ""
00226| ---
00227| 
00228| # Implementation Tasks
00229| 
00230| ## Legend
00231| `[ ]` Todo | `[x]` Done (implemented + verified)
00232| 
00233| ## Tasks
00234| 
00235| ### Phase 1: Cache Module 🚧
00236| - [ ] Create `src/services/cache.py` — implement `get_cached_user()`
00237| - [ ] Implement `set_cached_user()` with TTL jitter
00238| - [ ] Implement `invalidate_user_cache()`
00239| - [ ] Add Redis config to `config.py` with fallback
00240| **Verification**: `pytest tests/test_cache.py` passes
00241| 
00242| ### Phase 2: Auth Integration ⏳
00243| - [ ] Modify `src/services/auth.py` — add cache lookup in `authenticate()`
00244| - [ ] Add fallback to DB query if cache miss
00245| - [ ] Modify `src/services/user.py` — add cache invalidation in `update_user()`
00246| **Verification**: Auth flow works with cache enabled/disabled
00247| 
00248| ### Phase 3: Testing & Validation ⏳
00249| - [ ] Create `tests/test_cache.py` — cover get/set/invalidate
00250| - [ ] Add cache hit scenario in `tests/test_auth.py`
00251| - [ ] Add cache miss scenario in `tests/test_auth.py`
00252| - [ ] Add Redis unavailable fallback test
00253| **Verification**: All tests pass, coverage >90%
00254| 
00255| ---
00256| 
00257| ## Progress
00258| 
00259| **Overall**: 0%
00260| 
00261| | Phase | Progress | Status |
00262| |-------|----------|--------|
00263| | Phase 1 | 0% | 🚧 |
00264| | Phase 2 | 0% | ⏳ |
00265| | Phase 3 | 0% | ⏳ |
00266| 
00267| **Recent**:
00268| - (none yet)
00269| ```
00270| 
00271| ---
00272| 
00273| ## Duplication Avoidance
00274| 
00275| **Key Principle**: Define once, reference elsewhere.
00276| 
00277| | Where | Content |
00278| |-------|---------|
00279| | **Section B** | Define `CacheService` interface (4 methods), data model, logic |
00280| | **Section C** | "implement interface per Section B" — no copy-paste |
00281| | **tasks.md** | "implement `get_cached_user()`" — break into atomic tasks |
00282| 
00283| **❌ Bad** (repeating interface in C):
00284| ```markdown
00285| ## C. Implementation Strategy
00286| ### Phase 1: Cache Module
00287| - `src/services/cache.py` — create with:
00288|   - `get_cached_user(user_id: str) -> Optional[User]`  ← Repeated from B!
00289|   - `set_cached_user(user: User, ttl: int = 300)`      ← Repeated from B!
00290| ```
00291| 
00292| **✅ Good** (referencing B):
00293| ```markdown
00294| ## C. Implementation Strategy
00295| ### Phase 1: Cache Module
00296| - `src/services/cache.py` — create, implement interface per Section B
00297| ```
00298| 

(End of file - total 298 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-change\\references\\multi-change.md"
}
```
**Output:**
```
<file>
00001| # Multi-Change Coordination
00002| 
00003| Patterns for projects that need a root change + sub-changes. Load when Assess Scale → Multi.
00004| 
00005| ---
00006| 
00007| ## Root vs Sub
00008| 
00009| | Aspect | Root Change | Sub-Change |
00010| |--------|------------|------------|
00011| | Create | `sspec change new <n> --root` | `sspec change new <n>` |
00012| | spec.md C | Phase/sub-change breakdown | File-level task breakdown |
00013| | tasks.md | Milestones (one per sub-change) | Atomic tasks (<2h each) |
00014| | handover.md | Sub-change status tracking | File-level next steps |
00015| | Lifecycle | Active until all subs complete | Normal: PLANNING→DONE |
00016| 
00017| ## Structure
00018| 
00019| ```
00020| changes/<root>/
00021| ├── spec.md          # Overall vision (change-type: root)
00022| ├── tasks.md         # Milestones per sub-change
00023| ├── handover.md      # Sub-change status tracking
00024| ├── reference/       # Shared design docs
00025| └── script/          # Shared scripts
00026| 
00027| changes/<sub>/
00028| ├── spec.md          # Focused scope (change-type: sub)
00029| ├── tasks.md         # File-level tasks
00030| ├── handover.md
00031| └── reference/       # Design docs for complex change task
00032| ```
00033| 
00034| ## Workflow
00035| 
00036| 1. `sspec change new <n> --root` → design phases in spec.md C
00037| 2. `sspec change new <sub>` → link to root via reference field
00038| 3. Execute sub: normal PLANNING→DOING→REVIEW→DONE
00039| 4. Archive sub → create next sub
00040| 5. All subs done → archive root
00041| 
00042| ## Reference Linking
00043| 
00044| Sub → Root:
00045| ```yaml
00046| reference:
00047|   - source: "changes/<root>"
00048|     type: "root-change"
00049|     note: "Phase 1 of auth overhaul"
00050| ```
00051| 
00052| Root → Sub:
00053| ```yaml
00054| reference:
00055|   - source: "changes/<sub>"
00056|     type: "sub-change"
00057| ```
00058| 
00059| ## Archiving Root
00060| 
00061| Before archiving root change:
00062| 
00063| - [ ] All sub-changes archived?
00064| - [ ] Root tasks.md: all milestones `[x]`?
00065| - [ ] Valuable coordination notes preserved in reference/?
00066| - [ ] Linked spec-docs up to date?
00067| 
00068| ## Pitfalls
00069| 
00070| | Mistake | Fix |
00071| |---------|-----|
00072| | File-level tasks in root | Root is coordinator — milestone-level only |
00073| | Skip root, jump to subs | Root provides vision and phase coordination |
00074| | Forget to link root ↔ sub | Use reference field in both directions |
00075| | Archive root before subs done | Root stays active until all subs complete |
00076| 

(End of file - total 76 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\sspec-memory\\references\\handover-standards.md"
}
```
**Output:**
```
<file>
00001| # Handover Standards
00002| 
00003| Quality criteria for handover.md — serving both cross-session handover AND intra-session working memory.
00004| 
00005| ---
00006| 
00007| ## Core Fields
00008| 
00009| | Field | Purpose | ❌ Bad | ✅ Good |
00010| |-------|---------|--------|---------|
00011| | Background | One-sentence overview of this change | "Doing auth" | "JWT+Redis cache: 5s→<1s auth response" |
00012| | Accomplished | This session's concrete work | "Made progress" | "Redis pool + middleware done, tests passing" |
00013| | Current Status | Match spec.md frontmatter status | (missing) | "DOING — 60% complete" |
00014| | Next Steps | 1-3 specific file-level actions | "Continue" | "1. Code `src/auth/jwt.py:refresh_token()`" |
00015| 
00016| ### Background Field Rules
00017| 
00018| - **Write once** on first session. Update only if scope fundamentally changes.
00019| - Keep to 1-3 sentences. Details belong in spec.md, not here.
00020| - Purpose: instant orientation for any agent loading this change.
00021| 
00022| ---
00023| 
00024| ## References & Memory Fields
00025| 
00026| These fields serve as the Agent's external working memory — surviving both context compression and session boundaries.
00027| 
00028| ### Key Files
00029| 
00030| Critical file references for understanding and continuing this change.
00031| 
00032| **What to include**: Source files being modified, reference docs consulted, sspec ask records that drove decisions, related requests.
00033| 
00034| **Format**:
00035| ```markdown
00036| - `src/auth/jwt.py` — token generation + validation logic
00037| - `asks/260207_auth_approach.md` — confirmed JWT over session-based (user decision)
00038| - `spec-docs/auth-system.md` — overall auth architecture reference
00039| ```
00040| 
00041| **When to write**: Immediately when a critical file is identified or discovered.
00042| 
00043| ### Decisions & Rationale
00044| 
00045| Important decisions and the **full reasoning chain**. This is the most compression-vulnerable information — conclusions survive in memory but reasoning gets lost.
00046| 
00047| **Format (simple)**:
00048| ```markdown
00049| - **Redis over Memcached**: Need per-key TTL + persistence. Memcached faster but no TTL granularity → stale tokens.
00050| ```
00051| 
00052| **Format (complex)**:
00053| ```markdown
00054| #### 1. Why current approach fails?
00055| **Root cause**: Format too strict for model output...
00056| **Evidence**: 3/10 attempts produce valid format...
00057| 
00058| #### 2. Why SEARCH/REPLACE over alternatives?
00059| **Three advantages**: (1) simpler format (2) model familiarity (3) token savings...
00060| **Tradeoff**: Less precise than line-based diff, acceptable because...
00061| ```
00062| 
00063| **When to write**: Immediately when a non-trivial decision is made.
00064| 
00065| ### Gotchas & Context
00066| 
00067| Non-obvious findings, edge cases, implicit knowledge from discussions, implementation cautions, risk warnings.
00068| 
00069| **Key principle**: Things you'd need to re-derive or re-discover if context were lost.
00070| 
00071| **When to write**: Immediately when discovered.
00072| 
00073| **Project-wide gotchas**: If a gotcha applies beyond this change → ALSO append to `project.md` Notes.
00074| 
00075| ---
00076| 
00077| ## Depth Guidance
00078| 
00079| **Thin memory** (simple change, ≤5 files, clear scope):
00080| - 3-5 bullet points total across Key Files / Decisions / Gotchas
00081| - Don't force content where there's nothing to record
00082| 
00083| **Rich memory** (complex change with many decisions, multi-file, design exploration):
00084| - Organize Decisions into numbered items with sub-structure
00085| - Include evidence and tradeoff analysis
00086| - Cross-reference related ask records
00087| 
00088| Let content grow organically — don't pre-structure sections you don't need yet.
00089| 
00090| ---
00091| 
00092| ## Update Frequency
00093| 
00094| | Content | When to Write |
00095| |---------|---------------|
00096| | Key Files | Immediately when a critical file is identified |
00097| | Decisions & Rationale | Immediately when a non-trivial decision is made |
00098| | Gotchas & Context | Immediately when discovered |
00099| | Accomplished & Next Steps | At session end (minimum); mid-session for long sessions |
00100| | Background | Once, on first session |
00101| 
00102| **Core Rule**: If you'd struggle to reconstruct this information after context compression, write it down NOW.
00103| 
00104| ---
00105| 
00106| ## Quality Tests
00107| 
00108| Apply these tests at session end:
00109| 
00110| 1. **Cross-session test**: A brand-new Agent reads only handover.md. Can they resume meaningful work within 30 seconds?
00111| 2. **Compression test**: If your context window were compressed right now and you lost the last 20 exchanges, could you continue working from handover.md alone?
00112| 3. **Decision trace test**: For each major decision in this change, can you find the "why" in handover.md without re-reading ask records?
00113| 
00114| If any test fails → update before ending session.
00115| 
00116| ---
00117| 
00118| ## Root Change handover.md
00119| 
00120| Root change handover has different emphasis:
00121| 
00122| | Standard Field | Root Variant |
00123| |---------------|--------------|
00124| | Background | What this root coordinates (1-3 sentences) |
00125| | Accomplished | Work across sub-changes this session |
00126| | Next Steps | Which sub-change to work on next, coordination needed |
00127| 
00128| Additional root-specific sections:
00129| 
00130| - **Sub-Change Status**: Table tracking each sub-change's progress
00131| - **Cross-Phase Decisions**: Decisions affecting multiple sub-changes
00132| - **Coordination Notes**: Shared interfaces, integration points, cross-phase gotchas
00133| 
00134| ---
00135| 
00136| ## Anti-Patterns
00137| 
00138| | Bad Practice | Correct Approach |
00139| |--------------|------------------|
00140| | Skip `@handover` at session end | **ALWAYS** handover before ending — no exceptions |
00141| | Only update handover at session end | Update References & Memory **during** work |
00142| | Record decision without reasoning | Capture full chain: problem → alternatives → conclusion |
00143| | No file paths in Key Files | List files you'd need to re-find after compression |
00144| | Forget project.md Notes | Append project-level learnings during @handover |
00145| | Put architecture docs in project.md | project.md ≤10s scan; use spec-docs for detailed content |
00146| | Copy entire discussion into handover | Summarize; link to ask record for full discussion |
00147| 

(End of file - total 147 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\use-powershell\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: use-powershell
00003| description: "Use PowerShell to analyze, process, search, and manipulate files on Windows systems. Trigger when operating in a Windows environment and the task involves any of: (1) Searching file contents (grep-like operations), (2) Listing or finding files by name, size, date, or pattern, (3) Reading, comparing, or inspecting file contents, (4) Batch file operations (rename, move, copy, transform), (5) Extracting metadata (size, hash, timestamps, permissions), (6) Processing large files or directories efficiently. This skill provides Windows-specific workflows and non-obvious patterns that complement Claude's general PowerShell knowledge."
00004| ---
00005| 
00006| # PowerShell File Operations (Windows)
00007| 
00008| ## Task Routing
00009| 
00010| Determine the task type, then follow the corresponding workflow:
00011| 
00012| **Content search** (find text in files) → `Select-String` workflow
00013| **File search** (find files by name/attribute) → `Get-ChildItem` workflow
00014| **Read & inspect** (view file contents or metadata) → `Get-Content` / `Get-Item` workflow
00015| **Batch transform** (rename, move, copy at scale) → Pipeline workflow
00016| **Compare** (diff two files) → `Compare-Object` workflow
00017| 
00018| For detailed command patterns and examples, see [references/patterns.md](./references/patterns.md).
00019| 
00020| ## Critical Windows Gotchas
00021| 
00022| These are the high-impact pitfalls that cause silent failures or wrong results on Windows.
00023| 
00024| ### Encoding
00025| 
00026| Windows files frequently use non-UTF-8 encodings. Always consider encoding when reading text:
00027| 
00028| ```powershell
00029| # Detect BOM to determine encoding
00030| $bytes = Get-Content -Path "file.txt" -AsByteStream -TotalCount 4
00031| # EF BB BF = UTF-8 BOM, FF FE = UTF-16 LE, FE FF = UTF-16 BE
00032| 
00033| # Explicit encoding prevents mojibake
00034| $content = Get-Content -Path "file.txt" -Encoding UTF8
00035| ```
00036| 
00037| When writing output, default to UTF-8 with `-Encoding UTF8` to avoid producing UTF-16 files (PowerShell 5.1 default for `Out-File` / `Set-Content`).
00038| 
00039| ### Path Handling
00040| 
00041| ```powershell
00042| # ALWAYS use Join-Path — never string concatenation
00043| $path = Join-Path $folder $filename
00044| 
00045| # Use -LiteralPath for paths with brackets or wildcards
00046| Get-Content -LiteralPath "log[2025].txt"
00047| 
00048| # Quote paths with spaces
00049| Get-Item -Path "C:\Program Files\My App\config.json"
00050| ```
00051| 
00052| Windows 260-character path limit causes silent failures. For deep directory trees:
00053| 
00054| ```powershell
00055| # Use \\?\ prefix for long paths
00056| Get-ChildItem -LiteralPath "\\?\C:\Very\Deep\Path" -Recurse
00057| ```
00058| 
00059| ### Execution Policy
00060| 
00061| Scripts may be blocked by default. Check and adjust if needed:
00062| 
00063| ```powershell
00064| Get-ExecutionPolicy
00065| Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
00066| ```
00067| 
00068| ### Line Endings
00069| 
00070| Windows uses CRLF (`\r\n`). When comparing or processing cross-platform files:
00071| 
00072| ```powershell
00073| $content = (Get-Content "file.txt" -Raw) -replace "`r`n", "`n"
00074| ```
00075| 
00076| ## Workflow: Content Search
00077| 
00078| The primary tool is `Select-String` (Windows equivalent of grep).
00079| 
00080| ```powershell
00081| # Basic: search for pattern in files
00082| Select-String -Path "*.log" -Pattern "error"
00083| 
00084| # Recursive: search all .cs files under current directory
00085| Get-ChildItem -Recurse -Filter "*.cs" | Select-String -Pattern "class\s+\w+"
00086| 
00087| # With context lines (like grep -C)
00088| Select-String -Path "app.log" -Pattern "exception" -Context 3,3
00089| 
00090| # Extract only matched text (not full lines)
00091| Select-String -Path "data.csv" -Pattern "\d{3}-\d{4}" -AllMatches |
00092|     ForEach-Object { $_.Matches.Value }
00093| ```
00094| 
00095| Key flags:
00096| - `-SimpleMatch` — literal string (disable regex)
00097| - `-CaseSensitive` — exact case match
00098| - `-AllMatches` — multiple matches per line
00099| - `-Context N,M` — show N lines before, M after
00100| 
00101| ## Workflow: File Search
00102| 
00103| ```powershell
00104| # By name pattern (fast: -Filter is provider-level)
00105| Get-ChildItem -Path "C:\Projects" -Recurse -Filter "*.config" -File
00106| 
00107| # By regex on filename
00108| Get-ChildItem -Recurse -File |
00109|     Where-Object { $_.Name -match "^\d{4}-\d{2}-\d{2}" }
00110| 
00111| # By date range
00112| Get-ChildItem -Recurse -File |
00113|     Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) }
00114| 
00115| # By size threshold
00116| Get-ChildItem -Recurse -File |
00117|     Where-Object { $_.Length -gt 1MB }
00118| 
00119| # Limit recursion depth
00120| Get-ChildItem -Recurse -Depth 3 -Filter "*.json"
00121| ```
00122| 
00123| **Performance rule:** Always prefer `-Filter` over `-Include` or `Where-Object` for name patterns — `-Filter` operates at the filesystem provider level, significantly faster on large trees.
00124| 
00125| ## Workflow: Large File Processing
00126| 
00127| Avoid loading entire files into memory. Use streaming patterns:
00128| 
00129| ```powershell
00130| # Read first/last N lines without loading full file
00131| Get-Content "huge.log" -TotalCount 100    # first 100 lines
00132| Get-Content "huge.log" -Tail 50           # last 50 lines
00133| 
00134| # Batch streaming (1000 lines per batch)
00135| Get-Content "huge.log" -ReadCount 1000 | ForEach-Object {
00136|     $batch = $_
00137|     # process batch
00138| }
00139| 
00140| # .NET StreamReader for maximum efficiency
00141| $reader = [System.IO.File]::OpenText("huge.csv")
00142| try {
00143|     while ($null -ne ($line = $reader.ReadLine())) {
00144|         if ($line -match "target") { Write-Output $line }
00145|     }
00146| } finally { $reader.Close() }
00147| ```
00148| 
00149| ## Workflow: File Comparison
00150| 
00151| ```powershell
00152| # Line-by-line diff
00153| Compare-Object (Get-Content "v1.txt") (Get-Content "v2.txt")
00154| # <= means only in v1, => means only in v2
00155| 
00156| # Hash comparison (binary-safe)
00157| $h1 = (Get-FileHash "file1.bin").Hash
00158| $h2 = (Get-FileHash "file2.bin").Hash
00159| $h1 -eq $h2  # True if identical
00160| ```
00161| 
00162| ## Safety Checklist
00163| 
00164| Before destructive operations (delete, overwrite, bulk rename):
00165| 
00166| 1. **Preview first** — use `-WhatIf` to see what would happen
00167| 2. **Count targets** — `(Get-ChildItem -Filter "*.tmp").Count`
00168| 3. **Test on subset** — pipe through `Select-Object -First 5` before full run
00169| 4. **Use -Confirm** for interactive verification on critical operations
00170| 

(End of file - total 170 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\use-powershell\\references\\patterns.md"
}
```
**Output:**
```
<file>
00001| # PowerShell Command Patterns Reference
00002| 
00003| Detailed patterns organized by task type. Load this file when the task requires patterns beyond what SKILL.md covers.
00004| 
00005| ## Table of Contents
00006| 
00007| - [Content Reading Patterns](#content-reading-patterns) (L17-48) — Get-Content, Select-String
00008| - [Advanced Search Patterns](#advanced-search-patterns) (L51-86) — Regex, context, multi-file
00009| - [File Discovery Patterns](#file-discovery-patterns) (L89-123) — Get-ChildItem, filtering
00010| - [Metadata & Inspection](#metadata--inspection) (L126-163) — Properties, hashing, comparing
00011| - [Batch Operations](#batch-operations) (L166-198) — Renaming, moving, transforming
00012| - [Output Formatting](#output-formatting) (L201-235) — Tables, custom objects, export
00013| - [Performance Patterns](#performance-patterns) (L238-END) — Optimization, parallelization
00014| 
00015| ---
00016| 
00017| ## Content Reading Patterns
00018| 
00019| ### Partial reads
00020| 
00021| ```powershell
00022| # Specific line range (lines 10–20)
00023| Get-Content "file.txt" | Select-Object -Skip 9 -First 11
00024| 
00025| # Single line by index (0-based array)
00026| (Get-Content "file.txt")[14]  # line 15
00027| 
00028| # Read as single string (preserves newlines)
00029| $raw = Get-Content "file.txt" -Raw
00030| ```
00031| 
00032| ### Binary reads
00033| 
00034| ```powershell
00035| # PowerShell 7+
00036| $bytes = Get-Content "image.png" -AsByteStream
00037| 
00038| # PowerShell 5.1
00039| $bytes = Get-Content "image.png" -Encoding Byte
00040| ```
00041| 
00042| ### Encoding conversion
00043| 
00044| ```powershell
00045| Get-Content "source.txt" -Encoding UTF8 |
00046|     Set-Content "target.txt" -Encoding ASCII
00047| ```
00048| 
00049| ---
00050| 
00051| ## Advanced Search Patterns
00052| 
00053| ### Multi-file with exclusions
00054| 
00055| ```powershell
00056| Get-ChildItem -Recurse -Include "*.log" -Exclude "debug.log" |
00057|     Select-String -Pattern "exception"
00058| ```
00059| 
00060| ### Capture group extraction
00061| 
00062| ```powershell
00063| $results = Select-String -Path "config.ini" -Pattern "(\w+)=(.+)"
00064| foreach ($m in $results) {
00065|     $key   = $m.Matches.Groups[1].Value
00066|     $value = $m.Matches.Groups[2].Value
00067|     Write-Host "${key}: ${value}"
00068| }
00069| ```
00070| 
00071| ### Match counting
00072| 
00073| ```powershell
00074| # Lines containing pattern
00075| (Select-String -Path "app.log" -Pattern "error").Count
00076| 
00077| # Total occurrences (multiple per line)
00078| (Select-String -Path "app.log" -Pattern "error" -AllMatches).Matches.Count
00079| ```
00080| 
00081| ### Inverted search (lines NOT matching)
00082| 
00083| ```powershell
00084| Select-String -Path "app.log" -Pattern "DEBUG" -NotMatch
00085| ```
00086| 
00087| ---
00088| 
00089| ## File Discovery Patterns
00090| 
00091| ### Multiple extensions
00092| 
00093| ```powershell
00094| Get-ChildItem -Recurse -Include "*.txt","*.log","*.csv"
00095| ```
00096| 
00097| ### Regex on full path
00098| 
00099| ```powershell
00100| Get-ChildItem -Recurse -File |
00101|     Where-Object { $_.FullName -match "src\\models\\.+\.py$" }
00102| ```
00103| 
00104| ### Date range filter
00105| 
00106| ```powershell
00107| $start = Get-Date "2025-01-01"
00108| $end   = Get-Date "2025-01-31"
00109| Get-ChildItem -File |
00110|     Where-Object { $_.LastWriteTime -ge $start -and $_.LastWriteTime -le $end }
00111| ```
00112| 
00113| ### Empty files / directories
00114| 
00115| ```powershell
00116| # Zero-byte files
00117| Get-ChildItem -Recurse -File | Where-Object { $_.Length -eq 0 }
00118| 
00119| # Empty directories
00120| Get-ChildItem -Recurse -Directory |
00121|     Where-Object { (Get-ChildItem $_.FullName -File -Recurse).Count -eq 0 }
00122| ```
00123| 
00124| ---
00125| 
00126| ## Metadata & Inspection
00127| 
00128| ### Key properties
00129| 
00130| ```powershell
00131| $f = Get-Item "document.pdf"
00132| $f.Name            # filename
00133| $f.FullName        # absolute path
00134| $f.Length          # bytes
00135| $f.Extension       # .pdf
00136| $f.CreationTime    # created
00137| $f.LastWriteTime   # modified
00138| $f.Attributes      # ReadOnly, Hidden, etc.
00139| ```
00140| 
00141| ### Existence checks
00142| 
00143| ```powershell
00144| Test-Path "file.txt"                       # exists?
00145| Test-Path "file.txt" -PathType Leaf        # is file?
00146| Test-Path "folder"   -PathType Container   # is directory?
00147| ```
00148| 
00149| ### Hash computation
00150| 
00151| ```powershell
00152| Get-FileHash "release.zip"                           # SHA256 (default)
00153| Get-FileHash "release.zip" -Algorithm MD5             # MD5
00154| Get-ChildItem *.dll | Get-FileHash | Select-Object Hash, Path  # batch
00155| ```
00156| 
00157| ### Toggle read-only
00158| 
00159| ```powershell
00160| Set-ItemProperty "file.txt" -Name IsReadOnly -Value $true   # lock
00161| Set-ItemProperty "file.txt" -Name IsReadOnly -Value $false  # unlock
00162| ```
00163| 
00164| ---
00165| 
00166| ## Batch Operations
00167| 
00168| ### Bulk rename
00169| 
00170| ```powershell
00171| # Add prefix
00172| Get-ChildItem -Filter "*.jpg" |
00173|     Rename-Item -NewName { "photo_" + $_.Name }
00174| 
00175| # Regex replace in filename
00176| Get-ChildItem -Filter "*.log" |
00177|     Rename-Item -NewName { $_.Name -replace "old", "new" }
00178| ```
00179| 
00180| ### Bulk copy / move
00181| 
00182| ```powershell
00183| # Pipeline is faster than foreach loop
00184| Get-ChildItem -Filter "*.txt" | Copy-Item -Destination "backup\"
00185| Get-ChildItem -Filter "*.tmp" | Move-Item -Destination "archive\"
00186| ```
00187| 
00188| ### Conditional processing
00189| 
00190| ```powershell
00191| Get-ChildItem -Recurse -File | Where-Object {
00192|     $_.Length -gt 10MB -and $_.Extension -eq ".log"
00193| } | ForEach-Object {
00194|     Compress-Archive -Path $_.FullName -DestinationPath "$($_.FullName).zip"
00195|     Remove-Item $_.FullName
00196| }
00197| ```
00198| 
00199| ---
00200| 
00201| ## Output Formatting
00202| 
00203| ### Table view
00204| 
00205| ```powershell
00206| Get-ChildItem | Format-Table Name, Length, LastWriteTime -AutoSize
00207| 
00208| # Custom columns
00209| Get-ChildItem -File | Select-Object Name,
00210|     @{Name="SizeKB"; Expression={[math]::Round($_.Length/1KB,2)}},
00211|     LastWriteTime
00212| ```
00213| 
00214| ### Sorted output
00215| 
00216| ```powershell
00217| Get-ChildItem -File | Sort-Object Length -Descending      # by size
00218| Get-ChildItem | Sort-Object LastWriteTime -Descending      # by date
00219| 
00220| # Natural sort for numbered filenames
00221| Get-ChildItem | Sort-Object {
00222|     [regex]::Replace($_.Name, '\d+', { $args[0].Value.PadLeft(20) })
00223| }
00224| ```
00225| 
00226| ### Tree-like listing
00227| 
00228| ```powershell
00229| # Quick recursive directory names
00230| Get-ChildItem -Recurse -Directory | ForEach-Object { $_.FullName }
00231| 
00232| # Or use built-in tree command
00233| tree /F  # includes files
00234| ```
00235| 
00236| ---
00237| 
00238| ## Performance Patterns
00239| 
00240| ### Filter early, pipe late
00241| 
00242| ```powershell
00243| # SLOW: filter after enumeration
00244| Get-ChildItem -Recurse | Where-Object { $_.Extension -eq ".log" }
00245| 
00246| # FAST: provider-level filter
00247| Get-ChildItem -Recurse -Filter "*.log"
00248| ```
00249| 
00250| ### Cache repeated lookups
00251| 
00252| ```powershell
00253| # SLOW: Get-Item called every iteration
00254| Get-Content "file.txt" | ForEach-Object { (Get-Item "file.txt").Length }
00255| 
00256| # FAST: single lookup
00257| $file = Get-Item "file.txt"
00258| Get-Content "file.txt" | ForEach-Object { $file.Length }
00259| ```
00260| 
00261| ### Limit recursion scope
00262| 
00263| ```powershell
00264| # Scan only 2 levels deep instead of full tree
00265| Get-ChildItem -Recurse -Depth 2 -Filter "*.json" -File
00266| ```
00267| 
00268| ### Parallel processing (PowerShell 7+)
00269| 
00270| ```powershell
00271| Get-ChildItem -Recurse -Filter "*.log" | ForEach-Object -Parallel {
00272|     Select-String -Path $_.FullName -Pattern "error"
00273| } -ThrottleLimit 4
00274| ```
00275| 

(End of file - total 275 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 8.3s)

_Thinking:_

**Scheduling parallel reads**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-research\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-research
00003| description: "Investigate the problem space, read code, build understanding. Use when starting new work or when context is insufficient."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Research
00010| 
00011| Explore and investigate before designing. This phase is about **understanding**, not solving.
00012| 
00013| ---
00014| 
00015| ## When to Use
00016| 
00017| - Starting work on a new request/change
00018| - Context is insufficient to make design decisions
00019| - Unclear problem boundary or multiple possible interpretations
00020| - Need to understand existing code before modifying
00021| 
00022| ## Stance
00023| 
00024| - **Curious**: Ask questions that emerge naturally from what you find
00025| - **Thorough**: Read actual code, don't just theorize
00026| - **Visual**: Use diagrams when they clarify thinking
00027| - **Grounded**: Follow evidence in the codebase, challenge assumptions
00028| - **No implementation**: Do NOT write code or modify files (except notes)
00029| 
00030| ## What to Do
00031| 
00032| **Explore the problem space**:
00033| - Read request/issue description carefully
00034| - Identify what's actually being asked vs surface description
00035| - Challenge assumptions — find the real problem
00036| 
00037| **Investigate the codebase**:
00038| - Map existing architecture relevant to the work
00039| - Find integration points, patterns already in use
00040| - Surface hidden complexity or edge cases
00041| - Read `project.md`, `spec-docs/`, existing change handovers
00042| 
00043| **Compare approaches** (if multiple paths visible):
00044| - Brainstorm options, build comparison tables
00045| - Sketch tradeoffs with ASCII diagrams
00046| - Identify risks and unknowns
00047| 
00048| ## Outputs
00049| 
00050| Research findings go to:
00051| 
00052| | Output | Where |
00053| |--------|-------|
00054| | Research notes, analysis | `<change>/reference/` or `.sspec/tmp/` |
00055| | Key file discoveries | `handover.md` Working Memory → Key Files |
00056| | Important realizations | `handover.md` Working Memory → Notes |
00057| 
00058| ## Exit Criteria
00059| 
00060| Research is sufficient when you can articulate:
00061| 1. What the actual problem is (first principles, not surface symptom)
00062| 2. What parts of the codebase are affected
00063| 3. What approach(es) could work
00064| 
00065| → Then transition to `sspec-design` phase.
00066| 
00067| If uncertain whether research is complete → `@ask` user: "Here's my understanding. Is this sufficient to proceed to design?"
00068| 

(End of file - total 68 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-design\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-design
00003| description: "Assess scale, create change, fill spec.md, align with user. Use after research when ready to define the solution."
00004| metadata:
00005|   author: frostime
00006|   version: 3.0.0
00007| ---
00008| 
00009| # SSPEC Design
00010| 
00011| Define the problem and design the solution. Create the change. **Align with user before planning.**
00012| 
00013| This is a **user-in-the-loop** phase — like review, the user must confirm your design before you proceed. Never auto-advance to planning.
00014| 
00015| ---
00016| 
00017| ## Workflow
00018| 
00019| ```
00020| 1. Assess scale → micro / single / multi
00021| 2. Create change (CLI)
00022| 3. Fill spec.md
00023| 4. @ask user for alignment (MANDATORY)
00024| ```
00025| 
00026| ## Step 1: Assess Scale
00027| 
00028| | Scale | Criteria | Action |
00029| |-------|----------|--------|
00030| | **Micro** | ≤3 files, ≤30min, no design decisions, trivially reversible | Do directly. No change needed. Track in request if useful. |
00031| | **Single** | ≤1 week, ≤15 files, one subsystem, ≤20 tasks | Standard change → Step 2 Single |
00032| | **Multi** | >1 week OR >15 files across subsystems OR >20 tasks OR high risk | Root change → Step 2 Root |
00033| 
00034| **Uncertain?** → `@ask` user about scope/splitting.
00035| 
00036| ## Step 2: Create Change
00037| 
00038| ### Single Path
00039| 
00040| ```bash
00041| sspec change new <name>                        # standalone
00042| sspec change new --from <request>              # from request (auto-link)
00043| sspec change new <name> --from <request>       # explicit name + request link
00044| ```
00045| 
00046| ### Root Path (Multi-Change)
00047| 
00048| ```bash
00049| sspec change new <name> --root                 # creates root coordinator
00050| sspec change new <name> --root --from <req>    # root from request
00051| ```
00052| 
00053| Root change creates a coordinator with different templates:
00054| - Root `spec.md`: Phase overview, not file-level detail
00055| - Root `tasks.md`: Milestones, not individual tasks
00056| 
00057| ## Step 3: Fill spec.md
00058| 
00059| ### What Users Care About Most
00060| 
00061| Users review designs for: **interfaces**, **data types**, **data flow**, and **logic flow**.
00062| Prioritize these in Section B. Abstract hand-waving ("we'll handle it later") erodes trust.
00063| 
00064| ### Single Change
00065| 
00066| **Section A — Problem Statement**:
00067| - Quantify impact: "[metric] causing [impact]"
00068| - Simple changes: single paragraph
00069| - Complex changes: split "Current Situation" + "User Requirement"
00070| 
00071| | ❌ Bad | ✅ Good |
00072| |--------|---------|
00073| | "Need to refactor" | "Auth takes 5s → 12% conversion drop" |
00074| | "Improve the UI" | "Form completion rate 23% → target 60%" |
00075| 
00076| **Section B — Proposed Solution**:
00077| 
00078| `### Approach`: Core idea (1-3 paragraphs) + why this over alternatives.
00079| 
00080| `### Key Design`: Scale by complexity:
00081| 
00082| | Complexity | Design Depth |
00083| |------------|-------------|
00084| | Simple (≤5 files) | Inline in Approach, brief mention |
00085| | Medium (5-15 files) | Sub-sections: `### Interface Design`, `### Data Model`, `### Key Logic` |
00086| | Complex (>15 files) | Detailed design in `reference/design.md`, link from B |
00087| 
00088| **What MUST appear in B** (by priority):
00089| 1. **Interfaces** — function signatures, API contracts, class interfaces
00090| 2. **Data types** — models, schemas, type definitions
00091| 3. **Data flow** — how data moves through the system (input → transform → output)
00092| 4. **Logic flow** — key algorithms, decision trees, state machines
00093| 5. **Design rationale** — why this approach over alternatives
00094| 
00095| **What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).
00096| 
00097| ### Section B Example (Medium Complexity)
00098| 
00099| ```markdown
00100| ## B. Proposed Solution
00101| 
00102| ### Approach
00103| Add token refresh via middleware. Background refresh prevents expired tokens from blocking requests.
00104| 
00105| Why middleware: intercepting at HTTP layer avoids modifying every API call site.
00106| 
00107| ### Key Design
00108| 
00109| #### Interface
00110| - `TokenService.refresh(token: str) -> TokenPair`
00111| - `AuthMiddleware.intercept(request: Request) -> Request`
00112| - `TokenPair = TypedDict('TokenPair', {'access': str, 'refresh': str, 'expires_at': int})`
00113| 
00114| #### Data Flow
00115| ```
00116| Request → AuthMiddleware → check expiry
00117|   → if valid: pass through
00118|   → if expiring (<5min): background refresh + pass through
00119|   → if expired: block, refresh, retry with new token
00120| ```
00121| 
00122| #### Key Logic
00123| Refresh uses sliding window: if token expires within `REFRESH_WINDOW` (default 5min),
00124| trigger background refresh. Concurrent requests share one refresh via lock.
00125| ```
00126| 
00127| ### Root Change
00128| 
00129| **Section A**: Overall problem — full scope, not a single module.
00130| 
00131| **Section B**:
00132| - `### Overall Approach`: High-level strategy, delivery order
00133| - `### Phase Overview`: Each phase with goal, scope, dependencies
00134| 
00135| ```markdown
00136| - **Phase 1: Auth Backend** — JWT + Redis cache, goal: <1s auth response
00137| - **Phase 2: Auth Frontend** — Login/signup UI, depends on Phase 1
00138| - **Phase 3: Migration** — Migrate existing sessions, depends on Phase 1+2
00139| ```
00140| 
00141| After defining phases → create sub-changes:
00142| ```bash
00143| sspec change new <phase-name>    # for each phase, link to root via reference
00144| ```
00145| 
00146| Each sub-change then goes through its own design → plan → implement → review cycle.
00147| 
00148| ## Step 4: @ask for Alignment (MANDATORY)
00149| 
00150| **Never skip this step.** This is a user-in-the-loop confirmation — like review phase, the user must sign off.
00151| 
00152| Present the design to user for confirmation:
00153| - Problem statement summary
00154| - Proposed approach and rationale
00155| - Key interfaces and data types
00156| - (Root) Phase breakdown
00157| 
00158| Wait for user approval before proceeding to `sspec-plan`.
00159| 
00160| After user confirms → transition status `PLANNING → DOING` in spec.md frontmatter.
00161| 

(End of file - total 161 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-plan\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-plan
00003| description: "Break design into concrete tasks. Fill tasks.md with file-level execution plan. Use after design alignment."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Plan
00010| 
00011| Turn the approved design (spec.md B) into a concrete, file-level execution plan in tasks.md.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (approved design)
00019| 2. Break into phases + file-level tasks
00020| 3. Fill tasks.md
00021| 4. @ask user for final review
00022| ```
00023| 
00024| ## Task Standards
00025| 
00026| ### Granularity
00027| 
00028| | Change Type | Task Level | Example |
00029| |-------------|-----------|---------|
00030| | Single / Sub | File-level, <2h each | `- [ ] Create src/auth/jwt.py — refresh_token()` |
00031| | Root | Milestone-level (one per sub-change) | `- [ ] Phase 1 sub-change completed` |
00032| 
00033| Each task should be:
00034| - **Independently testable** — can verify without completing other tasks
00035| - **Specific** — mentions exact file path and what to do
00036| - **Small** — <2 hours of work
00037| 
00038| ### Phase Structure
00039| 
00040| ```markdown
00041| ### Phase 1: <name> ⏳
00042| - [ ] Task description `path/file.py`
00043| - [ ] Task description `path/file.py`
00044| **Verification**: <how to verify this phase>
00045| 
00046| ### Phase 2: <name> ⏳
00047| - [ ] Task description `path/file.py`
00048| **Verification**: <how to verify>
00049| ```
00050| 
00051| ### Phase Emoji
00052| 
00053| | Emoji | Meaning |
00054| |-------|---------|
00055| | ⏳ | Pending — not started |
00056| | 🚧 | In progress — actively working |
00057| | ✅ | Done — all tasks complete and verified |
00058| 
00059| ### Verification
00060| 
00061| Each phase MUST have explicit verification criteria:
00062| - What to check (test commands, expected output, manual verification)
00063| - How to know it's done (not "it works" but specific criteria)
00064| 
00065| ## Reference Section B, Don't Repeat
00066| 
00067| tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.
00068| 
00069| - ✅ "Implement Tool Interface per spec.md B"
00070| - ✅ "Create handler following the data flow in spec.md B"
00071| - ❌ Re-listing all function signatures
00072| - ❌ Re-describing the algorithm
00073| 
00074| ## Root Change Planning
00075| 
00076| For root changes, tasks.md contains milestones, not file-level tasks:
00077| 
00078| ```markdown
00079| ### Phase 1: Auth Backend ⏳
00080| - [ ] Sub-change created and linked
00081| - [ ] Sub-change completed and archived
00082| **Deliverable**: JWT auth with <1s response time
00083| **Sub-change**: (link when created)
00084| ```
00085| 
00086| The active sub-change gets its own tasks.md with file-level detail.
00087| 
00088| ## Progress Tracking
00089| 
00090| Update the Progress section after filling tasks:
00091| 
00092| ```markdown
00093| ## Progress
00094| 
00095| **Overall**: 0%
00096| 
00097| | Phase | Progress | Status |
00098| |-------|----------|--------|
00099| | Phase 1 | 0% | ⏳ |
00100| | Phase 2 | 0% | ⏳ |
00101| ```
00102| 
00103| ## Exit: @ask User Review (MANDATORY)
00104| 
00105| Present the task breakdown to user:
00106| - Number of phases and total tasks
00107| - Key verification criteria
00108| - Estimated scope
00109| 
00110| Wait for user approval before starting `sspec-implement`.
00111| 

(End of file - total 111 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-implement\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-implement
00003| description: "Execute tasks from tasks.md. Implement code changes, update progress. Use after plan approval."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Implement
00010| 
00011| Execute the approved plan. Work through tasks.md systematically.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (design context) + tasks.md (execution plan)
00019| 2. For each pending task: implement → verify → mark done
00020| 3. Update progress after EACH task
00021| 4. @ask user when all tasks complete
00022| ```
00023| 
00024| ## Execution Rules
00025| 
00026| ### Task Loop
00027| 
00028| For each pending task:
00029| 1. Announce which task you're working on
00030| 2. Make the code changes
00031| 3. Verify the change works
00032| 4. Mark task complete: `- [ ]` → `- [x]`
00033| 5. Update Progress section
00034| 6. Continue to next task
00035| 
00036| **Update after EACH task** — not in batches.
00037| 
00038| ### When to Pause
00039| 
00040| | Situation | Action |
00041| |-----------|--------|
00042| | Task is ambiguous | → `@ask` for clarification |
00043| | Implementation reveals design issue | → Suggest returning to `sspec-design` |
00044| | Blocker encountered | → Record in `handover.md` Notes, `@ask` user |
00045| | Multiple valid approaches for a task | → Pick the simpler one, note in handover |
00046| | Design assumption was wrong | → `@ask` user: "Design says X but I found Y. Revise?" |
00047| 
00048| **Don't guess on blockers.** One `@ask` < one rework cycle.
00049| 
00050| ### Keep Changes Focused
00051| 
00052| - Only modify files relevant to the current task
00053| - Preserve existing code style, comments, and structure
00054| - Don't refactor unrelated code
00055| - If a task grows beyond scope → split it, add new tasks to tasks.md
00056| 
00057| ## Progress Updates
00058| 
00059| After completing each task, update the Progress section:
00060| 
00061| ```markdown
00062| **Overall**: 40%
00063| 
00064| | Phase | Progress | Status |
00065| |-------|----------|--------|
00066| | Phase 1 | 100% | ✅ |
00067| | Phase 2 | 25% | 🚧 |
00068| 
00069| **Recent**:
00070| - Completed: Create auth middleware `src/middleware/auth.py`
00071| - Completed: Add JWT validation `src/auth/jwt.py`
00072| ```
00073| 
00074| ## Handover During Implementation
00075| 
00076| For long implementation sessions (>50 exchanges or multi-file work):
00077| - Write key decisions to `handover.md` Working Memory → Decisions
00078| - Record discovered gotchas to → Notes
00079| - Update Key Files as you discover important files
00080| 
00081| **Test**: "Would I struggle to continue if context was compressed right now?" → Write to handover.
00082| 
00083| ## Exit: @ask User (MANDATORY)
00084| 
00085| When all tasks are complete:
00086| 
00087| 1. Update Progress to show 100%
00088| 2. Summarize what was implemented
00089| 3. `@ask` user: "Implementation complete. Please review. Any issues or feedback?"
00090| 
00091| → Transition to `sspec-review` phase.
00092| 

(End of file - total 92 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-review\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-review
00003| description: "User acceptance and feedback loop. Handle argue-improve cycles until user is satisfied."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Review
00010| 
00011| Collect user feedback, iterate improvements, close the loop.
00012| 
00013| ---
00014| 
00015| ## When This Phase Starts
00016| 
00017| After `sspec-implement` completes and user begins reviewing:
00018| - User tests the implementation
00019| - User examines code changes
00020| - User provides feedback (approval, issues, or rejection)
00021| 
00022| ## Feedback Loop
00023| 
00024| ```
00025| User feedback ─→ Assess scope ─→ Act ─→ @ask "Fixed. Check again?"
00026|                                   ↑                    │
00027|                                   └────────────────────┘
00028|                             (repeat until user satisfied)
00029| ```
00030| 
00031| ### Assess Feedback Scope
00032| 
00033| When user provides feedback or disagrees:
00034| 
00035| | Scope | Signal | Action |
00036| |-------|--------|--------|
00037| | **Implementation detail** | "This variable name", "Move this function", "Fix this edge case" | Fix directly, update tasks.md |
00038| | **Design decision** | "I don't want Redis, use SQLite", "Wrong approach for this module" | Revise spec.md B → regenerate affected tasks → re-implement |
00039| | **Requirement itself** | "Actually I don't need this feature", "The real problem is different" | Revise spec.md A, mark scope change in handover.md, return to `sspec-design` |
00040| 
00041| ### Adding Feedback Tasks
00042| 
00043| When fixes require non-trivial work, add them to tasks.md:
00044| 
00045| ```markdown
00046| ### Feedback Tasks 🚧
00047| - [ ] Fix edge case in `src/auth/jwt.py` — handle expired refresh tokens
00048| - [ ] Rename `process()` to `validate_token()` per user feedback
00049| **Verification**: User confirms fixes are satisfactory
00050| ```
00051| 
00052| Then implement these tasks following `sspec-implement` workflow.
00053| 
00054| ## Rejection Protocol
00055| 
00056| If user strongly disagrees (`@argue`):
00057| 
00058| 1. **STOP immediately** — don't continue current work
00059| 2. **Assess scope** using the table above
00060| 3. **Acknowledge** the disagreement explicitly
00061| 4. **Act** based on scope:
00062|    - Implementation: fix and continue
00063|    - Design: return to `sspec-design`, `@ask` for new direction
00064|    - Requirement: return to `sspec-design`, reassess from problem statement
00065| 
00066| ## Close Loop
00067| 
00068| When user is satisfied:
00069| 
00070| 1. Ensure all tasks (including feedback tasks) are marked `[x]`
00071| 2. Update spec.md frontmatter: `status: REVIEW → DONE`
00072| 3. If change produced architectural knowledge → `@ask` user: "Should I create/update a spec-doc for X?" (use `write-spec-doc` SKILL if yes)
00073| 4. Suggest next actions:
00074|    - Archive the change if work is complete
00075|    - `@handover` if session is ending
00076| 
00077| **FORBIDDEN transitions**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
00078| 
00079| ## Status Flow
00080| 
00081| ```
00082| DOING (implement complete) → REVIEW (user reviewing)
00083|   → DONE (user satisfied)
00084|   → DOING (needs more work → implement feedback tasks → REVIEW again)
00085|   → PLANNING (requirement/design changed → back to design)
00086| ```
00087| 

(End of file - total 87 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-handover\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-handover
00003| description: "Save session state. Update handover.md, project.md, and spec-docs index. MANDATORY at session end, recommended mid-session."
00004| metadata:
00005|   author: frostime
00006|   version: 3.0.0
00007| ---
00008| 
00009| # SSPEC Handover
00010| 
00011| Persist session knowledge so any agent can resume within 30 seconds.
00012| 
00013| **Handover is a lifecycle participant, not just cleanup.** It preserves context across sessions, context compressions, and agent switches.
00014| 
00015| ---
00016| 
00017| ## When to Trigger
00018| 
00019| ### End of Session (MANDATORY)
00020| 
00021| Before ending ANY session, perform the full procedure below. No exceptions.
00022| 
00023| ### Mid-Session (Proactive)
00024| 
00025| Update handover.md Working Memory when:
00026| - Session is long (>50 exchanges or complex multi-file work)
00027| - Important decision just made with non-trivial reasoning
00028| - Key file discovered that future work depends on
00029| - Design tradeoff resolved after discussion
00030| - About to switch between major phases (e.g. design → plan)
00031| 
00032| **Rule**: If you'd struggle to reconstruct info after context compression → write it NOW.
00033| 
00034| ## Procedure
00035| 
00036| ### 1. Update handover.md
00037| 
00038| **This Session → Accomplished**: List specific work done (not "made progress").
00039| **This Session → Next Steps**: 1-3 specific file-level actions for next agent.
00040| 
00041| **Working Memory**:
00042| - **Key Files**: All critical file paths listed?
00043| - **Decisions**: Non-obvious choices captured with reasoning?
00044| - **Notes**: Edge cases, gotchas, risks recorded?
00045| 
00046| ### 2. Sync tasks.md
00047| 
00048| Verify tasks.md progress percentage matches reality. All completed tasks marked `[x]`.
00049| 
00050| ### 3. Promote to project.md (if applicable)
00051| 
00052| Two promotion targets:
00053| 
00054| **Notes section**: If any discovery applies beyond this change → append with date.
00055| - Format: `- YYYY-MM-DD: <learning>`
00056| 
00057| **Spec-Docs Index section**: If spec-docs were created or updated during this session → update the index.
00058| - Format: `- [name](spec-docs/<file>) — one-line description`
00059| 
00060| ### 4. Suggest spec-doc update (if applicable)
00061| 
00062| If the change produced architectural knowledge (new interfaces, data models, patterns):
00063| - `@ask` user: "This change produced knowledge about X. Should I create/update a spec-doc?"
00064| - If yes → use `write-spec-doc` SKILL
00065| 
00066| ### 5. Quick Quality Check
00067| 
00068| | Test | Pass? |
00069| |------|-------|
00070| | New agent reads only handover.md — can resume in <30s? | |
00071| | If context compressed right now — could you continue from handover.md alone? | |
00072| | For each major decision — can you find the "why" in handover? | |
00073| 
00074| If any test fails → update handover before ending.
00075| 
00076| ## handover.md Quality
00077| 
00078| **Thin** (simple change, ≤5 files): 3-5 bullet points across Working Memory sections.
00079| **Rich** (complex change, many decisions): Numbered items with sub-structure, evidence, tradeoff analysis.
00080| 
00081| Let content grow organically — don't pre-structure sections you don't need yet.
00082| 
00083| ### Anti-Patterns
00084| 
00085| | Bad | Good |
00086| |-----|------|
00087| | Skip handover at session end | ALWAYS handover — no exceptions |
00088| | Only update at session end | Update Working Memory DURING work |
00089| | Record decision without reasoning | Capture full chain: problem → alternatives → conclusion |
00090| | No file paths in Key Files | List files you'd need to re-find after compression |
00091| | Put architecture docs in project.md | project.md ≤10s scan; use spec-docs for detailed content |
00092| 

(End of file - total 92 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 11.1s)

_Thinking:_

**Comparing new and legacy skill versions**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-ask\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-ask
00003| description: "Mid-execution user consultation via persistent Q&A. USE ACTIVELY — guessing wastes more tokens than asking."
00004| metadata:
00005|   author: frostime
00006|   version: 7.0.0
00007| ---
00008| 
00009| # SSPEC Ask
00010| 
00011| Persist questions to disk, collect answers via terminal, continue — all within one session.
00012| 
00013| **Cost equation**: One ask ≈ 30 seconds. One wrong guess ≈ full rework cycle.
00014| 
00015| ---
00016| 
00017| ## sspec ask vs Built-in Question Tool
00018| 
00019| Two tools, different purposes. Choose correctly:
00020| 
00021| | | `sspec ask` (CLI) | Built-in question tool (e.g. VS Code Question) |
00022| |---|---|---|
00023| | **Record** | Persists as `.md` file in `.sspec/asks/` | Gone after session |
00024| | **Use when** | Architecture decisions, plan approval, direction choices, anything worth recording | Quick yes/no, mode switch confirmation, session-end check |
00025| | **Content** | Structured (REASON + QUESTION with options) | One-liner |
00026| | **Default** | **Prefer this** when uncertain | Only when answer is ephemeral |
00027| 
00028| **Rule**: If the question involves a decision that future agents might need to understand → use `sspec ask`.
00029| 
00030| ---
00031| 
00032| ## CLI Workflow
00033| 
00034| ```bash
00035| sspec ask create <topic>         # Create .py template
00036| # → Edit: fill REASON + QUESTION
00037| sspec ask prompt <path-to-py>    # Collect user answer → auto-converts to .md
00038| sspec ask list                   # Check pending/completed asks
00039| ```
00040| 
00041| ### Steps
00042| 
00043| 1. `sspec ask create <topic>` — creates `.sspec/asks/<timestamp>_<topic>.py`
00044| 2. Edit the `.py`: fill `REASON` (why asking) and `QUESTION` (specific, with options)
00045| 3. `sspec ask prompt <path>` — user answers → file converts to `.md` → `.py` deleted
00046| 4. Read the `.md` for user's answer, continue work
00047| 
00048| ### Error Handling
00049| 
00050| If `prompt` says file not found → check if `.md` already exists (`sspec ask list`).
00051| 
00052| ---
00053| 
00054| ## Content Rules
00055| 
00056| **Keep ask files focused.** The QUESTION field is for the question itself, not for long analysis.
00057| 
00058| | Content type | Where to put it |
00059| |---|---|
00060| | The question + brief options | QUESTION field in `.py` |
00061| | Long analysis, draft plans, design docs | Write to `.sspec/tmp/<topic>.md`, reference path in QUESTION |
00062| | Code samples or large tables | Write to file, reference path |
00063| 
00064| **Anti-pattern**: Stuffing 200+ lines of analysis into QUESTION field.
00065| **Correct**: Write analysis to `.sspec/tmp/design-draft.md`, then in QUESTION: "See draft at `.sspec/tmp/design-draft.md`. Does this approach work?"
00066| 
00067| ---
00068| 
00069| ## Patterns
00070| 
00071| ### Plan Confirmation (Most Common)
00072| 
00073| ```python
00074| REASON = r"""Change plan ready for review"""
00075| QUESTION = r"""
00076| Here's my plan for <change-name>:
00077| **Problem**: <summary>
00078| **Approach**: <core idea>
00079| **Key files**: <list>
00080| **Tasks**: <count>
00081| Proceed? Adjustments?
00082| """
00083| ```
00084| 
00085| ### Decision with Options
00086| 
00087| ```python
00088| REASON = r"""Multiple valid approaches for caching"""
00089| QUESTION = r"""
00090| **A) Redis** — fast, needs infra
00091| **B) SQLite** — persistent, zero-config
00092| **C) In-Memory** — simple, lost on restart
00093| Which aligns with project priorities?
00094| """
00095| ```
00096| 
00097| ### Batched Questions
00098| 
00099| ```python
00100| REASON = r"""Several design decisions needed before starting"""
00101| QUESTION = r"""
00102| 1. **Token format**: JWT or opaque?
00103| 2. **Session storage**: Redis or DB?
00104| 3. **Password hashing**: bcrypt or argon2?
00105| """
00106| ```
00107| 
00108| ---
00109| 
00110| ## Guidelines
00111| 
00112| | Do | Don't |
00113| |----|-------|
00114| | Descriptive topic (`auth_approach`) | Generic name (`q1`) |
00115| | Fill REASON with context | Leave REASON empty |
00116| | Provide options when possible | Leave open-ended if you have candidates |
00117| | Batch related questions | Create separate asks for related items |
00118| | Link important asks in handover.md | Let records become disconnected |
00119| | Long content → write to file, reference in QUESTION | Stuff everything into QUESTION field |
00120| 

(End of file - total 120 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\sspec-mdtoc\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-mdtoc
00003| description: "Pre-scan Markdown files before reading. Use `sspec tool mdtoc` to get file size + heading structure with line numbers (L<n> format) before reading long docs, SKILLs, or spec-docs. Eliminates blind reads."
00004| ---
00005| 
00006| # sspec-mdtoc — Markdown Pre-scan Skill
00007| 
00008| ## When to Use
00009| 
00010| Before reading ANY Markdown file you haven't seen before:
00011| - Long spec-docs, SKILL files, or AGENTS.md
00012| - README or documentation files
00013| - Any `.md` you need to understand structurally first
00014| 
00015| **Rule**: If you'd read a file top-to-bottom without knowing its size, run mdtoc first.
00016| 
00017| ## Command
00018| 
00019| ```
00020| sspec tool mdtoc <source> [--depth N]
00021| ```
00022| 
00023| | Source Type | Example | Behavior |
00024| |-------------|---------|----------|
00025| | File path | `sspec tool mdtoc README.md` | Analyzes single file |
00026| | Directory | `sspec tool mdtoc docs/` | Globs all `*.md` recursively |
00027| | Glob | `sspec tool mdtoc "**/*.md"` | Matches pattern |
00028| | Default | `sspec tool mdtoc` | Current directory |
00029| 
00030| `--depth N`: Limit heading depth (1-6, default: 6)
00031| 
00032| ## Output Format
00033| 
00034| ```
00035| === path/to/file.md ===
00036| chars: 4,523 | lines: 120
00037| 
00038| L1     # Document Title
00039| L5       ## Section One
00040| L12      ## Section Two
00041| L18        ### Subsection A
00042| L25        ### Subsection B
00043| L30      ## Section Three
00044| ```
00045| 
00046| - `L<n>` — 1-based line number of the heading
00047| - Indent reflects heading hierarchy
00048| - `chars` and `lines` tell you how large the file is before you read it
00049| 
00050| ## Typical Workflow
00051| 
00052| ```
00053| 1. sspec tool mdtoc <file>     # Get outline + line ranges
00054| 2. Identify sections of interest
00055| 3. read_file(startLine=<Ln>, endLine=<next_Ln>)  # Targeted read
00056| ```
00057| 
00058| **Multi-file summary** is shown automatically when scanning a directory:
00059| ```
00060| Found 8 files | total chars: 42,310 | total lines: 1,205 | headings: 87
00061| ```
00062| 
00063| ## Example: Analyzing a SKILL before reading
00064| 
00065| ```bash
00066| # Instead of blindly reading the entire skill:
00067| sspec tool mdtoc .sspec/skills/sspec-design/SKILL.md
00068| 
00069| # Output shows sections with line numbers:
00070| # L1   # SSPEC Design
00071| # L8     ## Workflow
00072| # L16    ## Step 1: Assess Scale
00073| # ...
00074| 
00075| # Now read only the section you need:
00076| # read_file(startLine=16, endLine=30)
00077| ```
00078| 
00079| ## Full Specification
00080| 
00081| To get the complete LLM-optimized specification:
00082| ```
00083| sspec tool mdtoc --prompt
00084| ```
00085| 

(End of file - total 85 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\use-powershell\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: use-powershell
00003| description: "Use PowerShell to analyze, process, search, and manipulate files on Windows systems. Trigger when operating in a Windows environment and the task involves any of: (1) Searching file contents (grep-like operations), (2) Listing or finding files by name, size, date, or pattern, (3) Reading, comparing, or inspecting file contents, (4) Batch file operations (rename, move, copy, transform), (5) Extracting metadata (size, hash, timestamps, permissions), (6) Processing large files or directories efficiently. This skill provides Windows-specific workflows and non-obvious patterns that complement Claude's general PowerShell knowledge."
00004| ---
00005| 
00006| # PowerShell File Operations (Windows)
00007| 
00008| ## Task Routing
00009| 
00010| Determine the task type, then follow the corresponding workflow:
00011| 
00012| **Content search** (find text in files) → `Select-String` workflow
00013| **File search** (find files by name/attribute) → `Get-ChildItem` workflow
00014| **Read & inspect** (view file contents or metadata) → `Get-Content` / `Get-Item` workflow
00015| **Batch transform** (rename, move, copy at scale) → Pipeline workflow
00016| **Compare** (diff two files) → `Compare-Object` workflow
00017| 
00018| For detailed command patterns and examples, see [references/patterns.md](./references/patterns.md).
00019| 
00020| ## Critical Windows Gotchas
00021| 
00022| These are the high-impact pitfalls that cause silent failures or wrong results on Windows.
00023| 
00024| ### Encoding
00025| 
00026| Windows files frequently use non-UTF-8 encodings. Always consider encoding when reading text:
00027| 
00028| ```powershell
00029| # Detect BOM to determine encoding
00030| $bytes = Get-Content -Path "file.txt" -AsByteStream -TotalCount 4
00031| # EF BB BF = UTF-8 BOM, FF FE = UTF-16 LE, FE FF = UTF-16 BE
00032| 
00033| # Explicit encoding prevents mojibake
00034| $content = Get-Content -Path "file.txt" -Encoding UTF8
00035| ```
00036| 
00037| When writing output, default to UTF-8 with `-Encoding UTF8` to avoid producing UTF-16 files (PowerShell 5.1 default for `Out-File` / `Set-Content`).
00038| 
00039| ### Path Handling
00040| 
00041| ```powershell
00042| # ALWAYS use Join-Path — never string concatenation
00043| $path = Join-Path $folder $filename
00044| 
00045| # Use -LiteralPath for paths with brackets or wildcards
00046| Get-Content -LiteralPath "log[2025].txt"
00047| 
00048| # Quote paths with spaces
00049| Get-Item -Path "C:\Program Files\My App\config.json"
00050| ```
00051| 
00052| Windows 260-character path limit causes silent failures. For deep directory trees:
00053| 
00054| ```powershell
00055| # Use \\?\ prefix for long paths
00056| Get-ChildItem -LiteralPath "\\?\C:\Very\Deep\Path" -Recurse
00057| ```
00058| 
00059| ### Execution Policy
00060| 
00061| Scripts may be blocked by default. Check and adjust if needed:
00062| 
00063| ```powershell
00064| Get-ExecutionPolicy
00065| Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
00066| ```
00067| 
00068| ### Line Endings
00069| 
00070| Windows uses CRLF (`\r\n`). When comparing or processing cross-platform files:
00071| 
00072| ```powershell
00073| $content = (Get-Content "file.txt" -Raw) -replace "`r`n", "`n"
00074| ```
00075| 
00076| ## Workflow: Content Search
00077| 
00078| The primary tool is `Select-String` (Windows equivalent of grep).
00079| 
00080| ```powershell
00081| # Basic: search for pattern in files
00082| Select-String -Path "*.log" -Pattern "error"
00083| 
00084| # Recursive: search all .cs files under current directory
00085| Get-ChildItem -Recurse -Filter "*.cs" | Select-String -Pattern "class\s+\w+"
00086| 
00087| # With context lines (like grep -C)
00088| Select-String -Path "app.log" -Pattern "exception" -Context 3,3
00089| 
00090| # Extract only matched text (not full lines)
00091| Select-String -Path "data.csv" -Pattern "\d{3}-\d{4}" -AllMatches |
00092|     ForEach-Object { $_.Matches.Value }
00093| ```
00094| 
00095| Key flags:
00096| - `-SimpleMatch` — literal string (disable regex)
00097| - `-CaseSensitive` — exact case match
00098| - `-AllMatches` — multiple matches per line
00099| - `-Context N,M` — show N lines before, M after
00100| 
00101| ## Workflow: File Search
00102| 
00103| ```powershell
00104| # By name pattern (fast: -Filter is provider-level)
00105| Get-ChildItem -Path "C:\Projects" -Recurse -Filter "*.config" -File
00106| 
00107| # By regex on filename
00108| Get-ChildItem -Recurse -File |
00109|     Where-Object { $_.Name -match "^\d{4}-\d{2}-\d{2}" }
00110| 
00111| # By date range
00112| Get-ChildItem -Recurse -File |
00113|     Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-7) }
00114| 
00115| # By size threshold
00116| Get-ChildItem -Recurse -File |
00117|     Where-Object { $_.Length -gt 1MB }
00118| 
00119| # Limit recursion depth
00120| Get-ChildItem -Recurse -Depth 3 -Filter "*.json"
00121| ```
00122| 
00123| **Performance rule:** Always prefer `-Filter` over `-Include` or `Where-Object` for name patterns — `-Filter` operates at the filesystem provider level, significantly faster on large trees.
00124| 
00125| ## Workflow: Large File Processing
00126| 
00127| Avoid loading entire files into memory. Use streaming patterns:
00128| 
00129| ```powershell
00130| # Read first/last N lines without loading full file
00131| Get-Content "huge.log" -TotalCount 100    # first 100 lines
00132| Get-Content "huge.log" -Tail 50           # last 50 lines
00133| 
00134| # Batch streaming (1000 lines per batch)
00135| Get-Content "huge.log" -ReadCount 1000 | ForEach-Object {
00136|     $batch = $_
00137|     # process batch
00138| }
00139| 
00140| # .NET StreamReader for maximum efficiency
00141| $reader = [System.IO.File]::OpenText("huge.csv")
00142| try {
00143|     while ($null -ne ($line = $reader.ReadLine())) {
00144|         if ($line -match "target") { Write-Output $line }
00145|     }
00146| } finally { $reader.Close() }
00147| ```
00148| 
00149| ## Workflow: File Comparison
00150| 
00151| ```powershell
00152| # Line-by-line diff
00153| Compare-Object (Get-Content "v1.txt") (Get-Content "v2.txt")
00154| # <= means only in v1, => means only in v2
00155| 
00156| # Hash comparison (binary-safe)
00157| $h1 = (Get-FileHash "file1.bin").Hash
00158| $h2 = (Get-FileHash "file2.bin").Hash
00159| $h1 -eq $h2  # True if identical
00160| ```
00161| 
00162| ## Safety Checklist
00163| 
00164| Before destructive operations (delete, overwrite, bulk rename):
00165| 
00166| 1. **Preview first** — use `-WhatIf` to see what would happen
00167| 2. **Count targets** — `(Get-ChildItem -Filter "*.tmp").Count`
00168| 3. **Test on subset** — pipe through `Select-Object -First 5` before full run
00169| 4. **Use -Confirm** for interactive verification on critical operations
00170| 

(End of file - total 170 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.5s)

_Thinking:_

**Inspecting template changes**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\spec-docs\\README.md"
}
```
**Output:**
```
<file>
00001| # Project Specifications
00002| 
00003| 此目录存放 **项目级技术规范** 的持久性文档。
00004| 
00005| 
00006| ## 项目规范文档
00007| 
00008| <!-- 以下内容仅为示例，实际规范类型由项目需求决定
00009| | 类型 | 示例 | 用途 |
00010| |------|------|------|
00011| | 架构设计 | `architecture.md` | 系统架构、模块划分 |
00012| | 开发规范 | `coding-standards.md` | 命名、代码风格 |
00013| | API 规格 | `api/` | 接口定义、数据格式 |
00014| | 技术决策 | `adr/` | Architecture Decision Records |
00015| | 数据模型 | `data-model.md` | Schema、实体关系 |
00016| -->
00017| 
00018| ## SPEC DOC 规范
00019| 
00020| 请参考 write-spec-doc SKILL.
00021| 
00022| ## 文件规范
00023| 
00024| ### 单文件规范
00025| 
00026| ```markdown
00027| ---
00028| name: API 规格
00029| description: 定义所有 REST API 的请求/响应格式
00030| updated: 2026-01-27
00031| ---
00032| 
00033| （正文内容）
00034| ```
00035| 
00036| **必需字段**：
00037| - `name`: 规范名称
00038| - `description`: 一句话描述
00039| - `updated`: 最后更新日期
00040| 
00041| ### 多文件规范（目录）
00042| 
00043| 当规范内容较多时，使用目录组织：
00044| 
00045| ```
00046| spec-docs/
00047| └── api/
00048|     ├── index.md        # 入口，包含 frontmatter
00049|     ├── authentication.md
00050|     ├── users.md
00051|     └── orders.md
00052| ```
00053| 
00054| **index.md 结构**：
00055| ```markdown
00056| ---
00057| name: API 规格
00058| description: 完整的 REST API 文档
00059| updated: 2026-01-27
00060| files:
00061|   - authentication.md
00062|   - users.md
00063|   - orders.md
00064| ---
00065| 
00066| 本目录包含完整的 API 文档。
00067| 
00068| - [认证](authentication.md)
00069| - [用户](users.md)
00070| - [订单](orders.md)
00071| 
00072| （正文内容）
00073| ```
00074| 
00075| ## Agent 指南
00076| 
00077| - 实现新功能前，检查此目录是否有相关规范
00078| - 需要项目级决策时，建议创建规范文档
00079| - 更新规范时，**务必更新 frontmatter 的 updated 字段**
00080| 

(End of file - total 80 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\spec-docs\\README.md"
}
```
**Output:**
```
<file>
00001| # Project Specifications
00002| 
00003| 此目录存放 **项目级技术规范** 的持久性文档。
00004| 
00005| 
00006| ## 项目规范文档
00007| 
00008| <!-- 以下内容仅为示例，实际规范类型由项目需求决定
00009| | 类型 | 示例 | 用途 |
00010| |------|------|------|
00011| | 架构设计 | `architecture.md` | 系统架构、模块划分 |
00012| | 开发规范 | `coding-standards.md` | 命名、代码风格 |
00013| | API 规格 | `api/` | 接口定义、数据格式 |
00014| | 技术决策 | `adr/` | Architecture Decision Records |
00015| | 数据模型 | `data-model.md` | Schema、实体关系 |
00016| -->
00017| 
00018| ## SPEC DOC 规范
00019| 
00020| 请参考 write-spec-doc SKILL.
00021| 
00022| ## 文件规范
00023| 
00024| ### 单文件规范
00025| 
00026| ```markdown
00027| ---
00028| name: API 规格
00029| description: 定义所有 REST API 的请求/响应格式
00030| updated: 2026-01-27
00031| ---
00032| 
00033| （正文内容）
00034| ```
00035| 
00036| **必需字段**：
00037| - `name`: 规范名称
00038| - `description`: 一句话描述
00039| - `updated`: 最后更新日期
00040| 
00041| ### 多文件规范（目录）
00042| 
00043| 当规范内容较多时，使用目录组织：
00044| 
00045| ```
00046| spec-docs/
00047| └── api/
00048|     ├── index.md        # 入口，包含 frontmatter
00049|     ├── authentication.md
00050|     ├── users.md
00051|     └── orders.md
00052| ```
00053| 
00054| **index.md 结构**：
00055| ```markdown
00056| ---
00057| name: API 规格
00058| description: 完整的 REST API 文档
00059| updated: 2026-01-27
00060| files:
00061|   - authentication.md
00062|   - users.md
00063|   - orders.md
00064| ---
00065| 
00066| 本目录包含完整的 API 文档。
00067| 
00068| - [认证](authentication.md)
00069| - [用户](users.md)
00070| - [订单](orders.md)
00071| 
00072| （正文内容）
00073| ```
00074| 
00075| ## Agent 指南
00076| 
00077| - 实现新功能前，检查此目录是否有相关规范
00078| - 需要项目级决策时，建议创建规范文档
00079| - 更新规范时，**务必更新 frontmatter 的 updated 字段**
00080| 

(End of file - total 80 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.0s)

_Thinking:_

**Comparing ignore files for differences**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.claude\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| skills
00003| # <<< sspec-managed skills <<<
00004| 

(End of file - total 4 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.claude\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| skills
00003| # <<< sspec-managed skills <<<
00004| 

(End of file - total 4 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\.gitignore"
}
```
**Output:**
```
<file>
00001| !project.md
00002| !spec-docs/**
00003| !commands/**
00004| !.meta.json
00005| changes/**
00006| requests/**
00007| skills/**
00008| asks/**
00009| tmp/**

(End of file - total 9 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\.gitignore"
}
```
**Output:**
```
<file>
00001| !project.md
00002| !spec-docs/**
00003| !commands/**
00004| !.meta.json
00005| changes/**
00006| requests/**
00007| skills/**
00008| asks/**
00009| tmp/**

(End of file - total 9 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.0s)

_Thinking:_

**Comparing agent and skill directories**

```
Tool: bash

**Input:**
```json
{
  "command": "git diff --no-index --stat -- \"tmp/legacy-sspec-8.0\" \"tmp/new-sspec-9.0\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Shows file-level diff stats between two versions"
}
```
**Output:**
```
warning: in the working copy of 'tmp/legacy-sspec-8.0/.claude/skills/use-powershell/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/new-sspec-9.0/.claude/skills/use-powershell/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.claude/skills/use-powershell/references/patterns.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/new-sspec-9.0/.claude/skills/use-powershell/references/patterns.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.sspec/skills/use-powershell/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/new-sspec-9.0/.sspec/skills/use-powershell/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.sspec/skills/use-powershell/references/patterns.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/new-sspec-9.0/.sspec/skills/use-powershell/references/patterns.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.sspec/skills/sspec-change/references/doc-standards.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.claude/skills/sspec-change/references/doc-standards.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.claude/skills/sspec-change/references/doc-standards.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'tmp/legacy-sspec-8.0/.sspec/skills/sspec-change/references/doc-standards.md', LF will be replaced by CRLF the next time Git touches it
 .../.claude/skills/.gitignore                      |   8 +-
 .../.claude/skills/sspec-ask/SKILL.md              | 214 +++++----------
 .../skills/sspec-change/SKILL.md => /dev/null      | 197 --------------
 .../references/doc-examples.md => /dev/null        | 297 ---------------------
 .../references/doc-standards.md => /dev/null       | 273 -------------------
 .../references/multi-change.md => /dev/null        |  75 ------
 .../.claude/skills/sspec-design/SKILL.md           | 160 +++++++++++
 .../.claude/skills/sspec-handover/SKILL.md         |  91 +++++++
 .../.claude/skills/sspec-implement/SKILL.md        |  91 +++++++
 .../.claude/skills/sspec-mdtoc/SKILL.md            |  13 +-
 .../skills/sspec-memory/SKILL.md => /dev/null      | 178 ------------
 .../references/handover-standards.md => /dev/null  | 146 ----------
 .../.claude/skills/sspec-plan/SKILL.md             | 110 ++++++++
 .../.claude/skills/sspec-research/SKILL.md         |  67 +++++
 .../.claude/skills/sspec-review/SKILL.md           |  86 ++++++
 .../.sspec/.meta.json                              |  32 ++-
 .../.sspec/project.md                              |   7 +
 .../.sspec/skills/.gitignore                       |   8 +-
 .../.sspec/skills/sspec-ask/SKILL.md               | 214 +++++----------
 .../skills/sspec-change/SKILL.md => /dev/null      | 197 --------------
 .../references/doc-examples.md => /dev/null        | 297 ---------------------
 .../references/doc-standards.md => /dev/null       | 273 -------------------
 .../references/multi-change.md => /dev/null        |  75 ------
 .../.sspec/skills/sspec-design/SKILL.md            | 160 +++++++++++
 .../.sspec/skills/sspec-handover/SKILL.md          |  91 +++++++
 .../.sspec/skills/sspec-implement/SKILL.md         |  91 +++++++
 .../.sspec/skills/sspec-mdtoc/SKILL.md             |  13 +-
 .../skills/sspec-memory/SKILL.md => /dev/null      | 178 ------------
 .../references/handover-standards.md => /dev/null  | 146 ----------
 .../.sspec/skills/sspec-plan/SKILL.md              | 110 ++++++++
 .../.sspec/skills/sspec-research/SKILL.md          |  67 +++++
 .../.sspec/skills/sspec-review/SKILL.md            |  86 ++++++
 tmp/{legacy-sspec-8.0 => new-sspec-9.0}/AGENTS.md  | 256 +++++++++---------
 33 files changed, 1512 insertions(+), 2795 deletions(-)

```
```

---

## Assistant (Build · gpt-5.3-codex · 6.5s)

_Thinking:_

**Inspecting large AGENTS diff**

```
Tool: bash

**Input:**
```json
{
  "command": "git diff --no-index -- \"tmp/legacy-sspec-8.0/AGENTS.md\" \"tmp/new-sspec-9.0/AGENTS.md\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Shows AGENTS protocol differences"
}
```
**Output:**
```
diff --git a/tmp/legacy-sspec-8.0/AGENTS.md b/tmp/new-sspec-9.0/AGENTS.md
index 09a54b8..1cbedb0 100644
--- a/tmp/legacy-sspec-8.0/AGENTS.md
+++ b/tmp/new-sspec-9.0/AGENTS.md
@@ -1,7 +1,7 @@
-﻿<!-- SSPEC:START -->
+<!-- SSPEC:START -->
 # .sspec Agent Protocol
 
-SSPEC_SCHEMA::8.0
+SSPEC_SCHEMA::9.0
 
 ## 0. Overview
 
@@ -15,182 +15,184 @@ SSPEC is a document-driven AI collaboration framework. All planning, tracking, a
 ├── spec-docs/     # Formal specs (architecture, APIs)
 ├── changes/<n>/   # spec.md | tasks.md | handover.md [+ reference/]
 ├── requests/      # User intent records
-├── tmp/           # Informal drafts for review
-└── asks/          # Q&A decision evidence
+├── tmp/           # Informal drafts
+└── asks/          # Q&A decision records
 ```
 
 ---
 
 ## 1. Agent Procedure
 
-`read(project.md)` → classify input → dispatch:
+`read(project.md)` → classify → dispatch:
 
-```
-DISPATCH(input):
-  directive(d)    → exec(d)                # → Shortcuts 4.3
-  request(r)      → scale(r) → workflow(r) # → Change 2.1; includes attached request files
-  resume(change)  → load(change) → continue
-  micro(≤3f,≤30m,obvious) → do_directly
-  new_work        → scale(input) → workflow # → Change 2.1
-
-load(change):
-  read(handover→tasks→spec) → output(status, progress, next_3_actions)
-
-scale(input):
-  micro  → do_directly | track_in_request
-  single → create_change(standard)
-  multi(>1w|>15f|>20t) → create_root
-
-BACKGROUND (always active during session):
-  discovery    → persist(handover.md)    # → Memory 2.3
-  long_session → checkpoint(handover.md) # compression is silent
-  uncertain    → @ask                    # → Consult 2.2; 30s < rework
-  session_end  → handover_full()         # → Memory 2.3; MANDATORY
-  user_rejects → STOP → assess_scope    # → Reactive 3
-```
+| Input | Action |
+|-------|--------|
+| Directive (`@resume`, `@handover`, etc.) | Execute → §5 Shortcuts |
+| Request (attached or described) | Assess scale → Change Workflow §2 |
+| Resume existing change | `read(handover→tasks→spec)` → continue from where left off |
+| Micro task (≤3 files, ≤30min, obvious) | Do directly, no change needed |
 
-Unfamiliar subsystem? → read `spec-docs/` | `project.md` | `<change>/handover.md` first
+**Background rules** (always active):
+- Important discovery → write to `handover.md` immediately
+- Long session (>20 exchanges) → checkpoint `handover.md`
+- Uncertain → `@ask` (30s question < hours of rework)
+- User rejects tool call → STOP → `@ask` reason
 
 ---
 
-## 2. Core Workflows
+## 2. Change Workflow
+
+### Development Lifecycle
 
-### 2.1 Change Lifecycle
+Each phase has a dedicated SKILL. Read the SKILL before starting the phase.
 
-Changes live in `.sspec/changes/<n>/` (dir name: `<time>_<change-name>`).
+```
+Request ─→ research ─→ design ──→ plan ──→ implement ──→ review ──→ handover
+              │           │          │          │            │          │
+           understand   @ask       @ask      execute      @ask      persist
+           problem      align      approve   tasks       feedback   session
+           space        design     tasks                  loop      state
+```
 
-| File | Contains |
-|------|----------|
-| spec.md | Problem (A), Solution (B), Implementation plan (C), Blockers (D) |
-| tasks.md | Task checklist `[ ]`/`[x]` + progress tracking |
-| handover.md | Session memory + agent working memory across sessions |
+**Handover** is not just session-end cleanup — it's a lifecycle participant. Trigger it:
+- At session end (MANDATORY)
+- Mid-session when context is long (>30 exchanges)
+- When switching between major phases
+- Before any context-losing event (compression, interruption)
 
-**Request → Change Workflow** (most common path):
+### Phase → SKILL → Files
 
-1. **Assess scale** → Micro (≤3 files, ≤30min: do directly) / Single (standard) / Multi (>1 week OR >15 files OR >20 tasks: `--root` + sub-changes)
-2. **Create**: `sspec change new --from <request>` (auto-links + derives name) or `sspec change new <name>`
-3. **Research**: First-principles — find the real problem, not the surface ask. Read project.md + relevant code. Unclear → use `@ask`. Wrong direction costs more than extra questions.
-4. **Design**: Fill spec.md A/B/C. Complex → `@ask` about splitting
-5. **Confirm**: `@ask` to present plan. Wait for approval before executing
-6. **Execute**: Implement. Update tasks.md after **each** task — not in batches
+| Phase | SKILL | Reads | Writes | Checkpoint |
+|-------|-------|-------|--------|------------|
+| **Research** | `sspec-research` | code, project.md, spec-docs | reference/, handover.md | @ask "ready to design?" |
+| **Design** | `sspec-design` | research findings, code | spec.md (A+B) | **@ask align** (MANDATORY) |
+| **Plan** | `sspec-plan` | spec.md B | tasks.md | **@ask approve** (MANDATORY) |
+| **Implement** | `sspec-implement` | spec.md B, tasks.md | code, tasks.md progress | **@ask "done, please review"** |
+| **Review** | `sspec-review` | user feedback | tasks.md (feedback tasks) | @ask "satisfied?" |
+| **Handover** | `sspec-handover` | everything | handover.md, project.md | — |
 
-**Locate**: `sspec change find <name>` (fuzzy) | `sspec change list` | read `.sspec/changes/`
+**MANDATORY checkpoints**: Design and Plan phases MUST @ask user before proceeding. Never skip.
 
-**Status transitions**:
+### Scale Assessment (in Design phase)
+
+| Scale | Criteria | Path |
+|-------|----------|------|
+| Micro | ≤3 files, ≤30min, trivially reversible | Do directly |
+| Single | ≤1 week, ≤15 files, ≤20 tasks | `sspec change new <name>` |
+| Multi | >1 week OR >15 files OR >20 tasks | `sspec change new <name> --root` → sub-changes |
+
+### Status Transitions
 
 | From | Trigger | To |
 |------|---------|-----|
-| PLANNING | user approves | DOING |
+| PLANNING | user approves design+plan | DOING |
 | DOING | all tasks `[x]` | REVIEW |
 | DOING | missing info | BLOCKED |
 | DOING | scope changed | PLANNING |
-| BLOCKED | resolved | DOING |
 | REVIEW | accepted | DONE |
 | REVIEW | needs changes | DOING |
 
-**FORBIDDEN**: PLANNING→DONE, DOING→DONE, BLOCKED→DONE — never skip REVIEW.
+**FORBIDDEN**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
 
-📚 `sspec-change` SKILL (MUST consult): doc standards, CLI ref, multi-change, edge cases.
-
-### 2.2 Consultation (@ask)
+---
 
-When Agent needs user input, route by archival need:
+## 3. Consultation (@ask)
 
 | Need persistent record? | Tool | Use when |
 |--------------------------|------|----------|
-| Yes | `sspec ask create <topic>` → fill → `sspec ask prompt <file>` | Plan approval, architecture choice, direction decision |
-| No | Agent env question tool | Session-end check, quick yes/no |
+| Yes | `sspec ask create` → fill → `sspec ask prompt` | Plan approval, architecture choice, direction decision |
+| No | Agent env question tool | Quick yes/no, session-end check |
 
-**Default to sspec ask** when uncertain — record > no record. Batch related questions in one ask.
-Long content MUST NOT go in ASK file → write in `.sspec/tmp/`, reference in QUESTION.
+Default to `sspec ask` when uncertain — a record beats no record.
+Long content → write to `.sspec/tmp/`, reference path in question body.
 
-**Mandatory ask points** (when user specified `@sspec-ask`): plan completion before execution, tool call rejected (ask reason), all tasks complete before ending.
+📚 Full workflow, patterns, and content rules: `sspec-ask` SKILL
 
-📚 Triggers, patterns, error handling: `sspec-ask` SKILL
+---
 
-### 2.3 Memory & Handover
+## 4. Spec-Docs
 
-Knowledge persists at four levels:
+Spec-docs capture architecture knowledge that survives beyond any single change.
 
-| Level | Carrier | Write timing |
-|-------|---------|-------------|
-| Record | `requests/` + `asks/` | On creation (CLI-managed) |
-| Change | `handover.md` | During work + session end |
-| Project | `project.md` Notes | Promoted from handover at session end |
-| Spec | `spec-docs/` | On architecture changes → `sspec doc new` |
+**When to create/update spec-docs**:
+- After a change produces architectural knowledge (new interfaces, data models, design patterns)
+- When the agent discovers knowledge too complex for `project.md` Notes
+- When user explicitly requests documentation
 
-**End-of-session handover (mandatory)**:
-1. Update handover.md: Accomplished, Next Steps, References & Memory
-2. Promote project-wide learnings to `project.md` Notes
-3. Verify tasks.md progress matches reality
+**Two scenarios**:
 
-**Mid-session** (proactive): Important decision, key file discovered, session long (>50 exchanges) → append to handover.md References & Memory immediately. Self-check: "Would I struggle to reconstruct this after context compression?" → if yes, write it NOW.
+| Scenario | Trigger | Action |
+|----------|---------|--------|
+| Post-change update | Change is DONE, produced architectural knowledge | Agent proactively `@ask`: "Should I update/create spec-doc for X?" |
+| User-initiated | User requests spec-doc creation | If small → do directly; if large → may need its own change |
 
-📚 Knowledge routing, handover quality, memory lifecycle: `sspec-memory` SKILL
+📚 Full guidelines: `write-spec-doc` SKILL
 
 ---
 
-## 3. Rejection Protocol
-
-When user disagrees (`@argue` or equivalent) — **STOP immediately**. Assess scope:
+## 5. Reference
 
-| Rejection scope | Action |
-|----------------|--------|
-| Implementation detail | Update tasks.md only |
-| Design decision | Revise spec.md B + regenerate tasks.md |
-| Requirement itself | Revise spec.md A, mark PIVOT in D, transition DOING→PLANNING |
-
-📚 Edge cases and assessment guidance: `sspec-change` SKILL
+### Directive Shortcuts
 
----
+| Shortcut | Equivalent | Procedure |
+|----------|-----------|-----------|
+| `@change <n>` | "Work on change N" | Load: `read(handover→tasks→spec)` → continue |
+| `@resume` | "Continue last work" | Same as `@change` for active change |
+| `@handover` | "Save and end" | Execute `sspec-handover` procedure |
+| `@sync` | "I coded without tracking" | Update tasks.md/handover.md to match reality |
+| `@argue` | "I disagree" | **STOP** → assess scope (§2 Review) |
+
+### CLI Quick Reference
+
+Common `sspec` commands. Run `sspec <command> --help` for full options.
+
+| Command | Purpose | Example |
+|---------|---------|---------|
+| `sspec change new <name>` | Create single change | `sspec change new fix-auth` |
+| `sspec change new <name> --root` | Create root (multi) change | `sspec change new refactor --root` |
+| `sspec change new --from <req>` | Create from request (auto-link) | `sspec change new --from .sspec/requests/...` |
+| `sspec change find <name>` | Fuzzy-find change dir | `sspec change find auth` |
+| `sspec change list` | List all active changes | |
+| `sspec change archive <path>` | Archive completed change | |
+| `sspec request list` | List requests | |
+| `sspec doc new "<name>"` | Create spec-doc | `sspec doc new "auth-design"` |
+| `sspec ask create <topic>` | Create ask file | `sspec ask create cache_approach` |
+| `sspec ask prompt <path>` | Collect user answer | Combo: create → edit → prompt |
+| `sspec ask list` | List asks | |
+| `sspec tool mdtoc <file>` | Pre-scan Markdown (headings + sizes) | |
 
-## 4. Reference
+### Scope Quick Reference
 
-### Template Markers in `<change>` template files
+| Scope | Location | Key Actions |
+|-------|----------|-------------|
+| Changes | `.sspec/changes/<n>/` | `new`, `find`, `list`, `archive` |
+| Requests | `.sspec/requests/` | `new`, `find`, `link` |
+| Spec-Docs | `.sspec/spec-docs/` | `new` |
+| Asks | `.sspec/asks/` | `create` → `prompt`, `list` |
+
+### SKILL System
+
+Each SKILL is self-contained — read the one you need for the current phase, no chaining required.
+When a SKILL.md says "read [reference](./references/file.md)" → you **MUST** follow and read it.
+
+| SKILL | When to Read |
+|-------|-------------|
+| `sspec-research` | Starting investigation of a problem |
+| `sspec-design` | Creating a change, filling spec.md |
+| `sspec-plan` | Breaking design into tasks |
+| `sspec-implement` | Executing tasks |
+| `sspec-review` | Handling user feedback |
+| `sspec-handover` | Saving session state (end-of-session or mid-session) |
+| `sspec-ask` | Consulting user mid-work |
+| `sspec-mdtoc` | Pre-scanning large Markdown files |
+| `write-spec-doc` | Creating spec-docs |
+| `write-patch` | Patch-based code modifications |
+
+### Template Markers
 
 | Marker | Meaning | Action |
 |--------|---------|--------|
-| `<!-- @RULE: ... -->` | Inline standards reminder | Read and follow. DO NOT delete |
+| `<!-- @RULE: ... -->` | Standards reminder | Read and follow. DO NOT delete |
 | `<!-- @REPLACE -->` | Anchor for first edit | Replace with content |
 | `[ ]` / `[x]` | Task todo / done | Update as work progresses |
-
-**Authority**: SKILLs are source of truth. @RULE markers are quick reminders.
-
-### Scope Quick Reference
-
-| Scope | Location | Key actions |
-|-------|----------|-------------|
-| Changes | `.sspec/changes/<n>/` | `sspec change new/find/list/archive/validate` |
-| Requests | `.sspec/requests/` | `sspec request new/find/link`. Request = "I want X" → Change = "Here's how we do X". Micro → track in request directly |
-| Spec-Docs | `.sspec/spec-docs/` | `sspec doc new "<name>"`. For knowledge too complex for project.md AND surviving beyond any single change. 📚 `write-spec-doc` SKILL |
-| Asks | `.sspec/asks/` | `sspec ask create/prompt/list`. Decision evidence chain |
-
-### Directive Shortcuts
-
-Optional convenience shortcuts. Agent MUST respond to equivalent natural language identically.
-
-| Shortcut | Equivalent intent | Procedure |
-|----------|-------------------|-----------|
-| `@change <n>` | "Work on change N" | **Existing**: load per procedure §1. **New**: create via §2.1 |
-| `@resume` | "Continue last work" | Same as `@change` for current active change |
-| `@handover` | "Save progress, end session" | Execute handover (Section 2.3) |
-| `@sync` | "I coded without tracking, update status" | Identify changes → update tasks.md/handover.md → suggest REVIEW if complete |
-| `@argue` | "I disagree" | **STOP immediately** → assess rejection scope (Reactive Rules Section 3) |
-
----
-
-## 5. SKILL System
-
-SSPEC core SKILLs: `sspec-change`, `sspec-memory`, `sspec-ask`, `sspec-mdtoc`, `write-spec-doc`, `write-patch`
-
-**Progressive disclosure**: `SKILL.md` is the entry point; reference subfiles contain detailed standards and examples.
-
-```
-<skills-dir>/<name>/
-├── SKILL.md     ← Read this first
-└── references/  ← Contains detailed standards, examples, patterns
-```
-
-**Critical**: When `SKILL.md` instructs to read a reference file (e.g. "read [doc-standards](./references/doc-standards.md)") → you **MUST** read it. Stopping at `SKILL.md` alone misses essential standards.
-For large md, use `sspec-mdtoc` for pre-scanning.
 <!-- SSPEC:END -->
\ No newline at end of file

```
```

```
Tool: bash

**Input:**
```json
{
  "command": "git diff --no-index -- \"tmp/legacy-sspec-8.0/.sspec/skills/sspec-ask/SKILL.md\" \"tmp/new-sspec-9.0/.sspec/skills/sspec-ask/SKILL.md\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Shows sspec-ask skill differences"
}
```
**Output:**
```
diff --git a/tmp/legacy-sspec-8.0/.sspec/skills/sspec-ask/SKILL.md b/tmp/new-sspec-9.0/.sspec/skills/sspec-ask/SKILL.md
index 7391051..a544f19 100644
--- a/tmp/legacy-sspec-8.0/.sspec/skills/sspec-ask/SKILL.md
+++ b/tmp/new-sspec-9.0/.sspec/skills/sspec-ask/SKILL.md
@@ -1,199 +1,109 @@
 ---
 name: sspec-ask
-description: "Mid-execution user consultation via persistent Q&A. USE ACTIVELY — especially in agent scenarios where @ask extends single-session effectiveness."
+description: "Mid-execution user consultation via persistent Q&A. USE ACTIVELY — guessing wastes more tokens than asking."
 metadata:
   author: frostime
-  version: 5.0.0
+  version: 7.0.0
 ---
 
-# SSPEC Ask Skill
+# SSPEC Ask
 
-**USE ACTIVELY** — Guessing wastes more tokens than one ask. When in doubt, ask.
+Persist questions to disk, collect answers via terminal, continue — all within one session.
 
----
-
-## Why @ask Matters
-
-In agent/copilot scenarios, the interaction model is: Agent works autonomously → hits a decision point → needs user input.
-
-Some platforms offer basic tools like `vscode Question` in copilot or `question` in opencode. However, these solutions are insufficient for handling complex, multi-turn consultations.
-
-Without `@ask`: Agent guesses, potentially wastes an entire implementation cycle. Or stops and loses context while waiting.
-
-With `@ask`: Agent persists the question to disk, collects the answer via terminal, and continues — all within the same session. The ask record also serves as permanent decision documentation.
-
-**Cost equation**: One ask ≈ 30 seconds of user time. One wrong guess ≈ full rework cycle.
+**Cost equation**: One ask ≈ 30 seconds. One wrong guess ≈ full rework cycle.
 
 ---
 
-## When to Trigger (Critical Decision Points)
-
-**REQUIRED use cases** — Agent MUST use sspec ask when:
+## sspec ask vs Built-in Question Tool
 
-1. **User explicitly requested** — User mentions ask/confirmation in their request
-2. **Information missing** — Cannot proceed reliably without user clarification
-3. **Directional choice needed** — Multiple valid approaches exist (not minor tweaks)
-4. **Work completion check** — Agent believes task is done, needs user verification
-5. **Repeated failures** — Multiple attempts failed, need user insight
+Two tools, different purposes. Choose correctly:
 
-### When NOT to Ask
+| | `sspec ask` (CLI) | Built-in question tool (e.g. VS Code Question) |
+|---|---|---|
+| **Record** | Persists as `.md` file in `.sspec/asks/` | Gone after session |
+| **Use when** | Architecture decisions, plan approval, direction choices, anything worth recording | Quick yes/no, mode switch confirmation, session-end check |
+| **Content** | Structured (REASON + QUESTION with options) | One-liner |
+| **Default** | **Prefer this** when uncertain | Only when answer is ephemeral |
 
-Don't create an ask for trivial decisions where:
-- Only one reasonable approach exists
-- The choice is easily reversible (e.g., variable naming)
-- The answer is available in project.md or existing spec-docs
-
-**Use question tool (if exists) for simple question**.
+**Rule**: If the question involves a decision that future agents might need to understand → use `sspec ask`.
 
 ---
 
-## Workflow
-
-### CLI Commands (Agent-Driven)
-
-| Command | When | Notes |
-|---------|------|-------|
-| `sspec ask create <topic>` | Need to ask user something | `<topic>` is a slug: `auth_approach`, `redis_vs_db` |
-| `sspec ask prompt <file.py>` | Collect user's answer | Pass the `.py` file path from create output |
-| `sspec ask list` | Check pending/completed asks | Shows `.py` (pending) and `.md` (answered) |
-
-**Ergonomics**:
-- `create` generates the `.py` template → Agent fills REASON + QUESTION → runs `prompt`
-- `prompt` opens terminal for user input OR get the user prefilled answer before `prompt` is approvaed to run → auto-converts to `.md` record → deletes `.py`
-- The entire cycle happens within one agent session — no context loss
+## CLI Workflow
 
-### Step-by-Step
-
-**Step 1**: Create template
 ```bash
-sspec ask create <topic>
+sspec ask create <topic>         # Create .py template
+# → Edit: fill REASON + QUESTION
+sspec ask prompt <path-to-py>    # Collect user answer → auto-converts to .md
+sspec ask list                   # Check pending/completed asks
 ```
-Creates `.sspec/asks/<timestamp>_<topic>.py`
-
-**Step 2**: Edit the `.py` file
-- Fill `REASON` (why asking — for future reference and memory)
-- Fill `QUESTION` (be specific, provide options when possible)
-- Do NOT edit `USER_ANSWER`
 
-**Step 3**: Execute
-```bash
-sspec ask prompt <path-to-py-file>
-```
+### Steps
 
-**Step 4**: Automatic lifecycle
-After execution: user's answer appended → file converted to `.md` → `.py` deleted.
+1. `sspec ask create <topic>` — creates `.sspec/asks/<timestamp>_<topic>.py`
+2. Edit the `.py`: fill `REASON` (why asking) and `QUESTION` (specific, with options)
+3. `sspec ask prompt <path>` — user answers → file converts to `.md` → `.py` deleted
+4. Read the `.md` for user's answer, continue work
 
 ### Error Handling
 
-If `sspec ask prompt` reports file not found:
-- The ask may have already been answered. Check if `<timestamp>_<topic>.md` exists in `.sspec/asks/`, or use `sspec ask list`.
-- If the `.md` file exists, read the answer from it directly.
+If `prompt` says file not found → check if `.md` already exists (`sspec ask list`).
 
 ---
 
-## Patterns
-
-### Single Decision Ask
-
-```python
-REASON = r"""
-Multiple valid approaches for caching layer refactor
-"""
-
-QUESTION = r"""
-I've identified 3 approaches:
+## Content Rules
 
-**A) Redis + In-Memory Fallback**
-- Pros: High performance, resilient
-- Cons: Operational complexity
+**Keep ask files focused.** The QUESTION field is for the question itself, not for long analysis.
 
-**B) Pure In-Memory (LRU)**
-- Pros: Simple, no external deps
-- Cons: Lost on restart
+| Content type | Where to put it |
+|---|---|
+| The question + brief options | QUESTION field in `.py` |
+| Long analysis, draft plans, design docs | Write to `.sspec/tmp/<topic>.md`, reference path in QUESTION |
+| Code samples or large tables | Write to file, reference path |
 
-**C) SQLite Cache**
-- Pros: Persistent, zero-config
-- Cons: Slower than Redis
+**Anti-pattern**: Stuffing 200+ lines of analysis into QUESTION field.
+**Correct**: Write analysis to `.sspec/tmp/design-draft.md`, then in QUESTION: "See draft at `.sspec/tmp/design-draft.md`. Does this approach work?"
 
-Which aligns with project priorities?
-"""
-```
-
-### Batched Questions
-
-When multiple related questions arise, **batch them in a single ask**:
-
-```python
-REASON = r"""
-Starting auth module implementation, several design decisions needed
-"""
-
-QUESTION = r"""
-Before starting the auth module, I need a few decisions:
-
-1. **Token format**: JWT (stateless, standard) or opaque tokens (revocable, simpler)?
-2. **Session storage**: Redis (fast, needs infra) or DB table (simpler, slower)?
-3. **Password hashing**: bcrypt (proven) or argon2 (newer, more resistant)?
+---
 
-For each, my recommendation is in bold if it helps. Override any as you see fit.
-"""
-```
+## Patterns
 
 ### Plan Confirmation (Most Common)
 
 ```python
-REASON = r"""
-Change plan ready for review before starting implementation
-"""
-
+REASON = r"""Change plan ready for review"""
 QUESTION = r"""
 Here's my plan for <change-name>:
-
-**Problem**: <one-line summary>
+**Problem**: <summary>
 **Approach**: <core idea>
 **Key files**: <list>
-**Estimated tasks**: <count>
-
-Proceed with this plan? Any adjustments?
+**Tasks**: <count>
+Proceed? Adjustments?
 """
 ```
 
-### Confirmation Before Major Action
+### Decision with Options
 
 ```python
-REASON = r"""
-About to delete and recreate the database schema — irreversible action
-"""
-
+REASON = r"""Multiple valid approaches for caching"""
 QUESTION = r"""
-I'm about to run the migration that drops and recreates the `users` table.
-This will delete all existing user data in dev.
-
-Proceed? (yes/no)
+**A) Redis** — fast, needs infra
+**B) SQLite** — persistent, zero-config
+**C) In-Memory** — simple, lost on restart
+Which aligns with project priorities?
 """
 ```
 
----
-
-## Long Content Handling
-
-If long reusable design doc / research finding / other drafts need to be attached:
-
-1. Write them in `.sspec/tmp/` as standalone files
-2. Reference the file path in QUESTION
-3. After user reply: move useful drafts to `change/reference/`, or discard
-
-**Why**: Ask files should stay focused. Long content in QUESTION makes the `.md` record hard to review later.
-
----
-
-## Memory Integration
-
-Ask records serve as permanent decision documentation:
+### Batched Questions
 
-- Link completed ask `.md` files in handover.md Key Files when the decision is important
-- The ask record preserves context that handover.md summaries may lose (exact user wording, full option analysis)
-- Future agents can trace: handover says "chose Redis" → ask record explains the full discussion
+```python
+REASON = r"""Several design decisions needed before starting"""
+QUESTION = r"""
+1. **Token format**: JWT or opaque?
+2. **Session storage**: Redis or DB?
+3. **Password hashing**: bcrypt or argon2?
+"""
+```
 
 ---
 
@@ -201,11 +111,9 @@ Ask records serve as permanent decision documentation:
 
 | Do | Don't |
 |----|-------|
-| Use descriptive topic name (`auth_approach`) | Use generic names (`q1`, `ask`, `question`) |
-| Keep topic name to letters and underscores only | Use non-ASCII or special characters |
-| Fill `REASON` with context for future reference | Leave `REASON` empty or vague |
-| Ask early when uncertain | Guess and risk rework |
-| Provide options when choices exist | Leave open-ended if you have candidates |
-| Batch related questions in one ask | Create 3 separate asks for related decisions |
-| Check project.md/spec-docs before asking | Ask for info that's already documented |
-| Link important ask records in handover.md | Let ask records become disconnected from change context |
+| Descriptive topic (`auth_approach`) | Generic name (`q1`) |
+| Fill REASON with context | Leave REASON empty |
+| Provide options when possible | Leave open-ended if you have candidates |
+| Batch related questions | Create separate asks for related items |
+| Link important asks in handover.md | Let records become disconnected |
+| Long content → write to file, reference in QUESTION | Stuff everything into QUESTION field |

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.2s)

_Thinking:_

**Comparing config file changes**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.claude\\skills\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| sspec-ask
00003| sspec-change
00004| sspec-mdtoc
00005| sspec-memory
00006| use-powershell
00007| write-patch
00008| write-spec-doc
00009| # <<< sspec-managed skills <<<
00010| 

(End of file - total 10 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.claude\\skills\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| sspec-ask
00003| sspec-design
00004| sspec-handover
00005| sspec-implement
00006| sspec-mdtoc
00007| sspec-plan
00008| sspec-research
00009| sspec-review
00010| use-powershell
00011| write-patch
00012| write-spec-doc
00013| # <<< sspec-managed skills <<<
00014| 

(End of file - total 14 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0\\.sspec\\skills\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| sspec-ask
00003| sspec-change
00004| sspec-mdtoc
00005| sspec-memory
00006| use-powershell
00007| write-patch
00008| write-spec-doc
00009| # <<< sspec-managed skills <<<
00010| 

(End of file - total 10 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\new-sspec-9.0\\.sspec\\skills\\.gitignore"
}
```
**Output:**
```
<file>
00001| # >>> sspec-managed skills >>>
00002| sspec-ask
00003| sspec-design
00004| sspec-handover
00005| sspec-implement
00006| sspec-mdtoc
00007| sspec-plan
00008| sspec-research
00009| sspec-review
00010| use-powershell
00011| write-patch
00012| write-spec-doc
00013| # <<< sspec-managed skills <<<
00014| 

(End of file - total 14 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 10.9s)

_Thinking:_

**Planning file metrics analysis**

```
Tool: bash

**Input:**
```json
{
  "command": "python -c \"from pathlib import Path\nbase=Path('H:/SrcCode/playground/sspec/tmp')\nfor name in ['legacy-sspec-8.0','new-sspec-9.0']:\n p=base/name\n files=[p/'AGENTS.md']+sorted((p/'.sspec/skills').rglob('*.md'))+[p/'.sspec/project.md']\n total_lines=0\n total_chars=0\n print(name)\n for f in files:\n  txt=f.read_text(encoding='utf-8')\n  lines=txt.count('\\n')+1\n  chars=len(txt)\n  total_lines+=lines\n  total_chars+=chars\n print(' files',len(files),'lines',total_lines,'chars',total_chars)\n print()\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Calculates documentation size metrics by version"
}
```
**Output:**
```
legacy-sspec-8.0
 files 14 lines 2624 chars 82828

new-sspec-9.0
 files 14 lines 1979 chars 56548


```
```

---

## Assistant (Build · gpt-5.3-codex · 12.6s)

_Thinking:_

**Planning skill line counts**

```
Tool: bash

**Input:**
```json
{
  "command": "python -c \"from pathlib import Path\nbase=Path('H:/SrcCode/playground/sspec/tmp')\nsets={\n 'legacy-sspec-8.0':['sspec-ask/SKILL.md','sspec-change/SKILL.md','sspec-change/references/doc-standards.md','sspec-change/references/doc-examples.md','sspec-change/references/multi-change.md','sspec-memory/SKILL.md','sspec-memory/references/handover-standards.md','sspec-mdtoc/SKILL.md'],\n 'new-sspec-9.0':['sspec-ask/SKILL.md','sspec-research/SKILL.md','sspec-design/SKILL.md','sspec-plan/SKILL.md','sspec-implement/SKILL.md','sspec-review/SKILL.md','sspec-handover/SKILL.md','sspec-mdtoc/SKILL.md']\n}\nfor ver,paths in sets.items():\n print(ver)\n total=0\n for rel in paths:\n  f=base/ver/'.sspec/skills'/rel\n  txt=f.read_text(encoding='utf-8')\n  lines=txt.count('\\n')+1\n  total+=lines\n  print(f' {rel:45} {lines:4d}')\n print(' total',total) \n print()\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Reports line counts for core workflow skills"
}
```
**Output:**
```
legacy-sspec-8.0
 sspec-ask/SKILL.md                             212
 sspec-change/SKILL.md                          198
 sspec-change/references/doc-standards.md       274
 sspec-change/references/doc-examples.md        298
 sspec-change/references/multi-change.md         76
 sspec-memory/SKILL.md                          179
 sspec-memory/references/handover-standards.md  147
 sspec-mdtoc/SKILL.md                            86
 total 1470

new-sspec-9.0
 sspec-ask/SKILL.md                             120
 sspec-research/SKILL.md                         68
 sspec-design/SKILL.md                          161
 sspec-plan/SKILL.md                            111
 sspec-implement/SKILL.md                        92
 sspec-review/SKILL.md                           87
 sspec-handover/SKILL.md                         92
 sspec-mdtoc/SKILL.md                            85
 total 816


```
```

---

## Assistant (Build · gpt-5.3-codex · 26.1s)

_Thinking:_

**Analyzing skill inconsistencies and losses**

```
Tool: bash

**Input:**
```json
{
  "command": "python -c \"from pathlib import Path\nimport re\nbase=Path('H:/SrcCode/playground/sspec/tmp')\nfor ver in ['legacy-sspec-8.0','new-sspec-9.0']:\n files=[base/ver/'AGENTS.md']+list((base/ver/'.sspec/skills').rglob('*.md'))\n txt='\\n'.join(f.read_text(encoding='utf-8') for f in files)\n print(ver)\n for kw in ['MANDATORY','MUST','FORBIDDEN','@ask','checklist','reference']:\n  c=len(re.findall(re.escape(kw),txt))\n  print(f' {kw:<10} {c}')\n print()\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Counts key governance terms in both versions"
}
```
**Output:**
```
legacy-sspec-8.0
 MANDATORY  1
 MUST       7
 FORBIDDEN  1
 @ask       15
 checklist  5
 reference  63

new-sspec-9.0
 MANDATORY  10
 MUST       6
 FORBIDDEN  2
 @ask       30
 checklist  1
 reference  17


```
```

---

## Assistant (Build · gpt-5.3-codex · 21.9s)

_Thinking:_

**Comparing legacy vs new spec-doc approach**

```
Tool: bash

**Input:**
```json
{
  "command": "ls -a",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\legacy-sspec-8.0",
  "description": "Lists top-level entries in legacy comparison directory"
}
```
**Output:**
```
.
..
.claude
.sspec
AGENTS.md

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.3s)

_Thinking:_

**Verifying symlink junction for skills directory**

```
Tool: bash

**Input:**
```json
{
  "command": "python -c \"from pathlib import Path\nfor ver in ['legacy-sspec-8.0','new-sspec-9.0']:\n p=Path(f'H:/SrcCode/playground/sspec/tmp/{ver}/.claude/skills')\n print(ver, 'exists',p.exists(),'is_symlink',p.is_symlink())\"",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Checks if skills path is symlink or junction"
}
```
**Output:**
```
legacy-sspec-8.0 exists True is_symlink False
new-sspec-9.0 exists True is_symlink False

```
```

---

## Assistant (Build · gpt-5.3-codex · 43.3s)

_Thinking:_

**Planning detailed evaluation report**

我看完了 `tmp/legacy-sspec-8.0` 和 `tmp/new-sspec-9.0` 两套协议与 SKILL（按你提示，以 `.sspec/skills` 为主，`.claude/skills` 视为镜像载体）。

**结论**
- 若两个独立 Agent 都“按文档严格执行”，`new-sspec-9.0` 在 **Agentic Coding 的整体执行效果** 上更好：上手更快、phase 更清晰、用户对齐点更明确。
- 但它 **不是帕累托优势**：9.0 在“规范深度/复杂变更防错”上有可见退化，并且存在几处规则冲突。

**为什么 9.0 效果更好**
- 流程从“通用 change/memory 大文档”改成 phase 化：`research → design → plan → implement → review → handover`，可执行性更强，见 `tmp/new-sspec-9.0/AGENTS.md:50`。
- 每个 phase 显式绑定 SKILL、读写文件、checkpoint，降低 Agent 走偏概率，见 `tmp/new-sspec-9.0/AGENTS.md:63`。
- 用户对齐机制更前置：Design/Plan 强制 @ask，减少“做完才发现方向错”，见 `tmp/new-sspec-9.0/AGENTS.md:74`。
- 文档负担显著下降（我做了行数统计）：核心工作流技能从约 **1470 行**（8.0）降到 **816 行**（9.0），更适合上下文受限 Agent。
- `project.md` 新增 Spec-Docs Index，长期知识入口更清楚，见 `tmp/new-sspec-9.0/.sspec/project.md:32`。

**9.0 的损失与缺陷（关键）**
- 规则冲突 1：Design 技能写“设计确认后 PLANNING→DOING”，见 `tmp/new-sspec-9.0/.sspec/skills/sspec-design/SKILL.md:160`；但总协议写“design+plan 都批准后才进 DOING”，见 `tmp/new-sspec-9.0/AGENTS.md:88`。
- 规则冲突 2：长会话阈值不一致（>20、>30、>50 三套），见 `tmp/new-sspec-9.0/AGENTS.md:37`、`tmp/new-sspec-9.0/AGENTS.md:59`、`tmp/new-sspec-9.0/.sspec/skills/sspec-handover/SKILL.md:26`。
- 状态机信息缺口：9.0 表里缺少 `BLOCKED → DOING` 恢复路径（8.0 有），见 `tmp/new-sspec-9.0/AGENTS.md:86` 对比 `tmp/legacy-sspec-8.0/AGENTS.md:87`。
- 规范深度下降：8.0 的 spec/tasks 严格标准与案例（frontmatter、B/C 去重、检查清单）被移除，见 `tmp/legacy-sspec-8.0/.sspec/skills/sspec-change/references/doc-standards.md:16`、`tmp/legacy-sspec-8.0/.sspec/skills/sspec-change/SKILL.md:150`。
- 复杂多变更治理弱化：8.0 有 root/sub 双向 reference 和归档检查细则，9.0 只有简化说明，见 `tmp/legacy-sspec-8.0/.sspec/skills/sspec-change/references/multi-change.md:42`。
- 记忆路由细粒度减少：8.0 明确 record/change/project/spec 四层与提升规则，9.0 handover 更轻但约束更少，见 `tmp/legacy-sspec-8.0/.sspec/skills/sspec-memory/SKILL.md:28`。

**是否构成帕累托优势**
- 结论：**不构成**。  
- 原因：9.0 在“速度/清晰度”提升的同时，牺牲了部分“文档严谨性/复杂场景防错”，且有协议自冲突，至少一个维度变差。

如果你愿意，我下一步可以给你一版“9.0 补丁建议”（最小改动），目标是保留 phase 化优势，同时补回 8.0 的关键防错能力。

---

## User

感谢你的审查。

1. 规则冲突这个似乎存在；请以 design+plning -> DOING 为准
2. 以 30 为阈值
3. 这个路径比较少见；BLOCKED -> DOING 不要也 Ok
4. frontmatter 规范化确认很有必要！ 至于 BC 冲突——哈哈，新版里面 spec.md 里面已经没有 C 了..
5. root/sub 的双向 ref 有必要讲清楚，这个涉及到 yaml ，需要精准
6. 记忆粒度减少是故意的；因为旧版本的四层提升方案太扯淡了，根本不切实际

你可以回到上层 sspec 开发目录，按照这些决策建议微调 @src/sspec/templates/

此外旧版本这么复杂很大程度是为了确保编写的 change 内文档足够专业；我像请问：在用 9.0 版本的规范下，Agent 能编写出规范的文档吗？是否有必要给部分的 SKILL 内再增加一些参考文档？（可以考虑不用分 reference，直接放在 SKILL.md 旁边也行）


---

## Assistant (Build · gpt-5.3-codex · 15.9s)

_Thinking:_

**Planning template edits and doc updates**

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/**/AGENTS.md",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\src\sspec\templates\AGENTS.md
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/skills/**/SKILL.md",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-review\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-handover\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-design\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-ask\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-mdtoc\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-implement\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-plan\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-research\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\write-patch\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\write-spec-doc\SKILL.md
H:\SrcCode\playground\sspec\src\sspec\templates\skills\use-powershell\SKILL.md
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/change/**",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\src\sspec\templates\change\tasks.md
H:\SrcCode\playground\sspec\src\sspec\templates\change\spec.md
H:\SrcCode\playground\sspec\src\sspec\templates\change\handover.md
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/change-root/**",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\src\sspec\templates\change-root\tasks.md
H:\SrcCode\playground\sspec\src\sspec\templates\change-root\handover.md
H:\SrcCode\playground\sspec\src\sspec\templates\change-root\spec.md
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/project.md",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\src\sspec\templates\project.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 10.8s)

_Thinking:_

**Planning parallel file inspection**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\AGENTS.md"
}
```
**Output:**
```
<file>
00001| <!-- SSPEC:START -->
00002| # .sspec Agent Protocol
00003| 
00004| SSPEC_SCHEMA::{{SCHEMA_VERSION}}
00005| 
00006| ## 0. Overview
00007| 
00008| SSPEC is a document-driven AI collaboration framework. All planning, tracking, and handover lives in `.sspec/`.
00009| 
00010| **Goal**: Any Agent resumes work within 30 seconds by reading `.sspec/` files.
00011| 
00012| ```
00013| .sspec/
00014| ├── project.md     # Identity, conventions, notes
00015| ├── spec-docs/     # Formal specs (architecture, APIs)
00016| ├── changes/<n>/   # spec.md | tasks.md | handover.md [+ reference/]
00017| ├── requests/      # User intent records
00018| ├── tmp/           # Informal drafts
00019| └── asks/          # Q&A decision records
00020| ```
00021| 
00022| ---
00023| 
00024| ## 1. Agent Procedure
00025| 
00026| `read(project.md)` → classify → dispatch:
00027| 
00028| | Input | Action |
00029| |-------|--------|
00030| | Directive (`@resume`, `@handover`, etc.) | Execute → §5 Shortcuts |
00031| | Request (attached or described) | Assess scale → Change Workflow §2 |
00032| | Resume existing change | `read(handover→tasks→spec)` → continue from where left off |
00033| | Micro task (≤3 files, ≤30min, obvious) | Do directly, no change needed |
00034| 
00035| **Background rules** (always active):
00036| - Important discovery → write to `handover.md` immediately
00037| - Long session (>20 exchanges) → checkpoint `handover.md`
00038| - Uncertain → `@ask` (30s question < hours of rework)
00039| - User rejects tool call → STOP → `@ask` reason
00040| 
00041| ---
00042| 
00043| ## 2. Change Workflow
00044| 
00045| ### Development Lifecycle
00046| 
00047| Each phase has a dedicated SKILL. Read the SKILL before starting the phase.
00048| 
00049| ```
00050| Request ─→ research ─→ design ──→ plan ──→ implement ──→ review ──→ handover
00051|               │           │          │          │            │          │
00052|            understand   @ask       @ask      execute      @ask      persist
00053|            problem      align      approve   tasks       feedback   session
00054|            space        design     tasks                  loop      state
00055| ```
00056| 
00057| **Handover** is not just session-end cleanup — it's a lifecycle participant. Trigger it:
00058| - At session end (MANDATORY)
00059| - Mid-session when context is long (>30 exchanges)
00060| - When switching between major phases
00061| - Before any context-losing event (compression, interruption)
00062| 
00063| ### Phase → SKILL → Files
00064| 
00065| | Phase | SKILL | Reads | Writes | Checkpoint |
00066| |-------|-------|-------|--------|------------|
00067| | **Research** | `sspec-research` | code, project.md, spec-docs | reference/, handover.md | @ask "ready to design?" |
00068| | **Design** | `sspec-design` | research findings, code | spec.md (A+B) | **@ask align** (MANDATORY) |
00069| | **Plan** | `sspec-plan` | spec.md B | tasks.md | **@ask approve** (MANDATORY) |
00070| | **Implement** | `sspec-implement` | spec.md B, tasks.md | code, tasks.md progress | **@ask "done, please review"** |
00071| | **Review** | `sspec-review` | user feedback | tasks.md (feedback tasks) | @ask "satisfied?" |
00072| | **Handover** | `sspec-handover` | everything | handover.md, project.md | — |
00073| 
00074| **MANDATORY checkpoints**: Design and Plan phases MUST @ask user before proceeding. Never skip.
00075| 
00076| ### Scale Assessment (in Design phase)
00077| 
00078| | Scale | Criteria | Path |
00079| |-------|----------|------|
00080| | Micro | ≤3 files, ≤30min, trivially reversible | Do directly |
00081| | Single | ≤1 week, ≤15 files, ≤20 tasks | `sspec change new <name>` |
00082| | Multi | >1 week OR >15 files OR >20 tasks | `sspec change new <name> --root` → sub-changes |
00083| 
00084| ### Status Transitions
00085| 
00086| | From | Trigger | To |
00087| |------|---------|-----|
00088| | PLANNING | user approves design+plan | DOING |
00089| | DOING | all tasks `[x]` | REVIEW |
00090| | DOING | missing info | BLOCKED |
00091| | DOING | scope changed | PLANNING |
00092| | REVIEW | accepted | DONE |
00093| | REVIEW | needs changes | DOING |
00094| 
00095| **FORBIDDEN**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
00096| 
00097| ---
00098| 
00099| ## 3. Consultation (@ask)
00100| 
00101| | Need persistent record? | Tool | Use when |
00102| |--------------------------|------|----------|
00103| | Yes | `sspec ask create` → fill → `sspec ask prompt` | Plan approval, architecture choice, direction decision |
00104| | No | Agent env question tool | Quick yes/no, session-end check |
00105| 
00106| Default to `sspec ask` when uncertain — a record beats no record.
00107| Long content → write to `.sspec/tmp/`, reference path in question body.
00108| 
00109| 📚 Full workflow, patterns, and content rules: `sspec-ask` SKILL
00110| 
00111| ---
00112| 
00113| ## 4. Spec-Docs
00114| 
00115| Spec-docs capture architecture knowledge that survives beyond any single change.
00116| 
00117| **When to create/update spec-docs**:
00118| - After a change produces architectural knowledge (new interfaces, data models, design patterns)
00119| - When the agent discovers knowledge too complex for `project.md` Notes
00120| - When user explicitly requests documentation
00121| 
00122| **Two scenarios**:
00123| 
00124| | Scenario | Trigger | Action |
00125| |----------|---------|--------|
00126| | Post-change update | Change is DONE, produced architectural knowledge | Agent proactively `@ask`: "Should I update/create spec-doc for X?" |
00127| | User-initiated | User requests spec-doc creation | If small → do directly; if large → may need its own change |
00128| 
00129| 📚 Full guidelines: `write-spec-doc` SKILL
00130| 
00131| ---
00132| 
00133| ## 5. Reference
00134| 
00135| ### Directive Shortcuts
00136| 
00137| | Shortcut | Equivalent | Procedure |
00138| |----------|-----------|-----------|
00139| | `@change <n>` | "Work on change N" | Load: `read(handover→tasks→spec)` → continue |
00140| | `@resume` | "Continue last work" | Same as `@change` for active change |
00141| | `@handover` | "Save and end" | Execute `sspec-handover` procedure |
00142| | `@sync` | "I coded without tracking" | Update tasks.md/handover.md to match reality |
00143| | `@argue` | "I disagree" | **STOP** → assess scope (§2 Review) |
00144| 
00145| ### CLI Quick Reference
00146| 
00147| Common `sspec` commands. Run `sspec <command> --help` for full options.
00148| 
00149| | Command | Purpose | Example |
00150| |---------|---------|---------|
00151| | `sspec change new <name>` | Create single change | `sspec change new fix-auth` |
00152| | `sspec change new <name> --root` | Create root (multi) change | `sspec change new refactor --root` |
00153| | `sspec change new --from <req>` | Create from request (auto-link) | `sspec change new --from .sspec/requests/...` |
00154| | `sspec change find <name>` | Fuzzy-find change dir | `sspec change find auth` |
00155| | `sspec change list` | List all active changes | |
00156| | `sspec change archive <path>` | Archive completed change | |
00157| | `sspec request list` | List requests | |
00158| | `sspec doc new "<name>"` | Create spec-doc | `sspec doc new "auth-design"` |
00159| | `sspec ask create <topic>` | Create ask file | `sspec ask create cache_approach` |
00160| | `sspec ask prompt <path>` | Collect user answer | Combo: create → edit → prompt |
00161| | `sspec ask list` | List asks | |
00162| | `sspec tool mdtoc <file>` | Pre-scan Markdown (headings + sizes) | |
00163| 
00164| ### Scope Quick Reference
00165| 
00166| | Scope | Location | Key Actions |
00167| |-------|----------|-------------|
00168| | Changes | `.sspec/changes/<n>/` | `new`, `find`, `list`, `archive` |
00169| | Requests | `.sspec/requests/` | `new`, `find`, `link` |
00170| | Spec-Docs | `.sspec/spec-docs/` | `new` |
00171| | Asks | `.sspec/asks/` | `create` → `prompt`, `list` |
00172| 
00173| ### SKILL System
00174| 
00175| Each SKILL is self-contained — read the one you need for the current phase, no chaining required.
00176| When a SKILL.md says "read [reference](./references/file.md)" → you **MUST** follow and read it.
00177| 
00178| | SKILL | When to Read |
00179| |-------|-------------|
00180| | `sspec-research` | Starting investigation of a problem |
00181| | `sspec-design` | Creating a change, filling spec.md |
00182| | `sspec-plan` | Breaking design into tasks |
00183| | `sspec-implement` | Executing tasks |
00184| | `sspec-review` | Handling user feedback |
00185| | `sspec-handover` | Saving session state (end-of-session or mid-session) |
00186| | `sspec-ask` | Consulting user mid-work |
00187| | `sspec-mdtoc` | Pre-scanning large Markdown files |
00188| | `write-spec-doc` | Creating spec-docs |
00189| | `write-patch` | Patch-based code modifications |
00190| 
00191| ### Template Markers
00192| 
00193| | Marker | Meaning | Action |
00194| |--------|---------|--------|
00195| | `<!-- @RULE: ... -->` | Standards reminder | Read and follow. DO NOT delete |
00196| | `<!-- @REPLACE -->` | Anchor for first edit | Replace with content |
00197| | `[ ]` / `[x]` | Task todo / done | Update as work progresses |
00198| <!-- SSPEC:END -->
00199| 

(End of file - total 199 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-design\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-design
00003| description: "Assess scale, create change, fill spec.md, align with user. Use after research when ready to define the solution."
00004| metadata:
00005|   author: frostime
00006|   version: 3.0.0
00007| ---
00008| 
00009| # SSPEC Design
00010| 
00011| Define the problem and design the solution. Create the change. **Align with user before planning.**
00012| 
00013| This is a **user-in-the-loop** phase — like review, the user must confirm your design before you proceed. Never auto-advance to planning.
00014| 
00015| ---
00016| 
00017| ## Workflow
00018| 
00019| ```
00020| 1. Assess scale → micro / single / multi
00021| 2. Create change (CLI)
00022| 3. Fill spec.md
00023| 4. @ask user for alignment (MANDATORY)
00024| ```
00025| 
00026| ## Step 1: Assess Scale
00027| 
00028| | Scale | Criteria | Action |
00029| |-------|----------|--------|
00030| | **Micro** | ≤3 files, ≤30min, no design decisions, trivially reversible | Do directly. No change needed. Track in request if useful. |
00031| | **Single** | ≤1 week, ≤15 files, one subsystem, ≤20 tasks | Standard change → Step 2 Single |
00032| | **Multi** | >1 week OR >15 files across subsystems OR >20 tasks OR high risk | Root change → Step 2 Root |
00033| 
00034| **Uncertain?** → `@ask` user about scope/splitting.
00035| 
00036| ## Step 2: Create Change
00037| 
00038| ### Single Path
00039| 
00040| ```bash
00041| sspec change new <name>                        # standalone
00042| sspec change new --from <request>              # from request (auto-link)
00043| sspec change new <name> --from <request>       # explicit name + request link
00044| ```
00045| 
00046| ### Root Path (Multi-Change)
00047| 
00048| ```bash
00049| sspec change new <name> --root                 # creates root coordinator
00050| sspec change new <name> --root --from <req>    # root from request
00051| ```
00052| 
00053| Root change creates a coordinator with different templates:
00054| - Root `spec.md`: Phase overview, not file-level detail
00055| - Root `tasks.md`: Milestones, not individual tasks
00056| 
00057| ## Step 3: Fill spec.md
00058| 
00059| ### What Users Care About Most
00060| 
00061| Users review designs for: **interfaces**, **data types**, **data flow**, and **logic flow**.
00062| Prioritize these in Section B. Abstract hand-waving ("we'll handle it later") erodes trust.
00063| 
00064| ### Single Change
00065| 
00066| **Section A — Problem Statement**:
00067| - Quantify impact: "[metric] causing [impact]"
00068| - Simple changes: single paragraph
00069| - Complex changes: split "Current Situation" + "User Requirement"
00070| 
00071| | ❌ Bad | ✅ Good |
00072| |--------|---------|
00073| | "Need to refactor" | "Auth takes 5s → 12% conversion drop" |
00074| | "Improve the UI" | "Form completion rate 23% → target 60%" |
00075| 
00076| **Section B — Proposed Solution**:
00077| 
00078| `### Approach`: Core idea (1-3 paragraphs) + why this over alternatives.
00079| 
00080| `### Key Design`: Scale by complexity:
00081| 
00082| | Complexity | Design Depth |
00083| |------------|-------------|
00084| | Simple (≤5 files) | Inline in Approach, brief mention |
00085| | Medium (5-15 files) | Sub-sections: `### Interface Design`, `### Data Model`, `### Key Logic` |
00086| | Complex (>15 files) | Detailed design in `reference/design.md`, link from B |
00087| 
00088| **What MUST appear in B** (by priority):
00089| 1. **Interfaces** — function signatures, API contracts, class interfaces
00090| 2. **Data types** — models, schemas, type definitions
00091| 3. **Data flow** — how data moves through the system (input → transform → output)
00092| 4. **Logic flow** — key algorithms, decision trees, state machines
00093| 5. **Design rationale** — why this approach over alternatives
00094| 
00095| **What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).
00096| 
00097| ### Section B Example (Medium Complexity)
00098| 
00099| ```markdown
00100| ## B. Proposed Solution
00101| 
00102| ### Approach
00103| Add token refresh via middleware. Background refresh prevents expired tokens from blocking requests.
00104| 
00105| Why middleware: intercepting at HTTP layer avoids modifying every API call site.
00106| 
00107| ### Key Design
00108| 
00109| #### Interface
00110| - `TokenService.refresh(token: str) -> TokenPair`
00111| - `AuthMiddleware.intercept(request: Request) -> Request`
00112| - `TokenPair = TypedDict('TokenPair', {'access': str, 'refresh': str, 'expires_at': int})`
00113| 
00114| #### Data Flow
00115| ```
00116| Request → AuthMiddleware → check expiry
00117|   → if valid: pass through
00118|   → if expiring (<5min): background refresh + pass through
00119|   → if expired: block, refresh, retry with new token
00120| ```
00121| 
00122| #### Key Logic
00123| Refresh uses sliding window: if token expires within `REFRESH_WINDOW` (default 5min),
00124| trigger background refresh. Concurrent requests share one refresh via lock.
00125| ```
00126| 
00127| ### Root Change
00128| 
00129| **Section A**: Overall problem — full scope, not a single module.
00130| 
00131| **Section B**:
00132| - `### Overall Approach`: High-level strategy, delivery order
00133| - `### Phase Overview`: Each phase with goal, scope, dependencies
00134| 
00135| ```markdown
00136| - **Phase 1: Auth Backend** — JWT + Redis cache, goal: <1s auth response
00137| - **Phase 2: Auth Frontend** — Login/signup UI, depends on Phase 1
00138| - **Phase 3: Migration** — Migrate existing sessions, depends on Phase 1+2
00139| ```
00140| 
00141| After defining phases → create sub-changes:
00142| ```bash
00143| sspec change new <phase-name>    # for each phase, link to root via reference
00144| ```
00145| 
00146| Each sub-change then goes through its own design → plan → implement → review cycle.
00147| 
00148| ## Step 4: @ask for Alignment (MANDATORY)
00149| 
00150| **Never skip this step.** This is a user-in-the-loop confirmation — like review phase, the user must sign off.
00151| 
00152| Present the design to user for confirmation:
00153| - Problem statement summary
00154| - Proposed approach and rationale
00155| - Key interfaces and data types
00156| - (Root) Phase breakdown
00157| 
00158| Wait for user approval before proceeding to `sspec-plan`.
00159| 
00160| After user confirms → transition status `PLANNING → DOING` in spec.md frontmatter.
00161| 

(End of file - total 161 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-plan\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-plan
00003| description: "Break design into concrete tasks. Fill tasks.md with file-level execution plan. Use after design alignment."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Plan
00010| 
00011| Turn the approved design (spec.md B) into a concrete, file-level execution plan in tasks.md.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (approved design)
00019| 2. Break into phases + file-level tasks
00020| 3. Fill tasks.md
00021| 4. @ask user for final review
00022| ```
00023| 
00024| ## Task Standards
00025| 
00026| ### Granularity
00027| 
00028| | Change Type | Task Level | Example |
00029| |-------------|-----------|---------|
00030| | Single / Sub | File-level, <2h each | `- [ ] Create src/auth/jwt.py — refresh_token()` |
00031| | Root | Milestone-level (one per sub-change) | `- [ ] Phase 1 sub-change completed` |
00032| 
00033| Each task should be:
00034| - **Independently testable** — can verify without completing other tasks
00035| - **Specific** — mentions exact file path and what to do
00036| - **Small** — <2 hours of work
00037| 
00038| ### Phase Structure
00039| 
00040| ```markdown
00041| ### Phase 1: <name> ⏳
00042| - [ ] Task description `path/file.py`
00043| - [ ] Task description `path/file.py`
00044| **Verification**: <how to verify this phase>
00045| 
00046| ### Phase 2: <name> ⏳
00047| - [ ] Task description `path/file.py`
00048| **Verification**: <how to verify>
00049| ```
00050| 
00051| ### Phase Emoji
00052| 
00053| | Emoji | Meaning |
00054| |-------|---------|
00055| | ⏳ | Pending — not started |
00056| | 🚧 | In progress — actively working |
00057| | ✅ | Done — all tasks complete and verified |
00058| 
00059| ### Verification
00060| 
00061| Each phase MUST have explicit verification criteria:
00062| - What to check (test commands, expected output, manual verification)
00063| - How to know it's done (not "it works" but specific criteria)
00064| 
00065| ## Reference Section B, Don't Repeat
00066| 
00067| tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.
00068| 
00069| - ✅ "Implement Tool Interface per spec.md B"
00070| - ✅ "Create handler following the data flow in spec.md B"
00071| - ❌ Re-listing all function signatures
00072| - ❌ Re-describing the algorithm
00073| 
00074| ## Root Change Planning
00075| 
00076| For root changes, tasks.md contains milestones, not file-level tasks:
00077| 
00078| ```markdown
00079| ### Phase 1: Auth Backend ⏳
00080| - [ ] Sub-change created and linked
00081| - [ ] Sub-change completed and archived
00082| **Deliverable**: JWT auth with <1s response time
00083| **Sub-change**: (link when created)
00084| ```
00085| 
00086| The active sub-change gets its own tasks.md with file-level detail.
00087| 
00088| ## Progress Tracking
00089| 
00090| Update the Progress section after filling tasks:
00091| 
00092| ```markdown
00093| ## Progress
00094| 
00095| **Overall**: 0%
00096| 
00097| | Phase | Progress | Status |
00098| |-------|----------|--------|
00099| | Phase 1 | 0% | ⏳ |
00100| | Phase 2 | 0% | ⏳ |
00101| ```
00102| 
00103| ## Exit: @ask User Review (MANDATORY)
00104| 
00105| Present the task breakdown to user:
00106| - Number of phases and total tasks
00107| - Key verification criteria
00108| - Estimated scope
00109| 
00110| Wait for user approval before starting `sspec-implement`.
00111| 

(End of file - total 111 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-handover\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-handover
00003| description: "Save session state. Update handover.md, project.md, and spec-docs index. MANDATORY at session end, recommended mid-session."
00004| metadata:
00005|   author: frostime
00006|   version: 3.0.0
00007| ---
00008| 
00009| # SSPEC Handover
00010| 
00011| Persist session knowledge so any agent can resume within 30 seconds.
00012| 
00013| **Handover is a lifecycle participant, not just cleanup.** It preserves context across sessions, context compressions, and agent switches.
00014| 
00015| ---
00016| 
00017| ## When to Trigger
00018| 
00019| ### End of Session (MANDATORY)
00020| 
00021| Before ending ANY session, perform the full procedure below. No exceptions.
00022| 
00023| ### Mid-Session (Proactive)
00024| 
00025| Update handover.md Working Memory when:
00026| - Session is long (>50 exchanges or complex multi-file work)
00027| - Important decision just made with non-trivial reasoning
00028| - Key file discovered that future work depends on
00029| - Design tradeoff resolved after discussion
00030| - About to switch between major phases (e.g. design → plan)
00031| 
00032| **Rule**: If you'd struggle to reconstruct info after context compression → write it NOW.
00033| 
00034| ## Procedure
00035| 
00036| ### 1. Update handover.md
00037| 
00038| **This Session → Accomplished**: List specific work done (not "made progress").
00039| **This Session → Next Steps**: 1-3 specific file-level actions for next agent.
00040| 
00041| **Working Memory**:
00042| - **Key Files**: All critical file paths listed?
00043| - **Decisions**: Non-obvious choices captured with reasoning?
00044| - **Notes**: Edge cases, gotchas, risks recorded?
00045| 
00046| ### 2. Sync tasks.md
00047| 
00048| Verify tasks.md progress percentage matches reality. All completed tasks marked `[x]`.
00049| 
00050| ### 3. Promote to project.md (if applicable)
00051| 
00052| Two promotion targets:
00053| 
00054| **Notes section**: If any discovery applies beyond this change → append with date.
00055| - Format: `- YYYY-MM-DD: <learning>`
00056| 
00057| **Spec-Docs Index section**: If spec-docs were created or updated during this session → update the index.
00058| - Format: `- [name](spec-docs/<file>) — one-line description`
00059| 
00060| ### 4. Suggest spec-doc update (if applicable)
00061| 
00062| If the change produced architectural knowledge (new interfaces, data models, patterns):
00063| - `@ask` user: "This change produced knowledge about X. Should I create/update a spec-doc?"
00064| - If yes → use `write-spec-doc` SKILL
00065| 
00066| ### 5. Quick Quality Check
00067| 
00068| | Test | Pass? |
00069| |------|-------|
00070| | New agent reads only handover.md — can resume in <30s? | |
00071| | If context compressed right now — could you continue from handover.md alone? | |
00072| | For each major decision — can you find the "why" in handover? | |
00073| 
00074| If any test fails → update handover before ending.
00075| 
00076| ## handover.md Quality
00077| 
00078| **Thin** (simple change, ≤5 files): 3-5 bullet points across Working Memory sections.
00079| **Rich** (complex change, many decisions): Numbered items with sub-structure, evidence, tradeoff analysis.
00080| 
00081| Let content grow organically — don't pre-structure sections you don't need yet.
00082| 
00083| ### Anti-Patterns
00084| 
00085| | Bad | Good |
00086| |-----|------|
00087| | Skip handover at session end | ALWAYS handover — no exceptions |
00088| | Only update at session end | Update Working Memory DURING work |
00089| | Record decision without reasoning | Capture full chain: problem → alternatives → conclusion |
00090| | No file paths in Key Files | List files you'd need to re-find after compression |
00091| | Put architecture docs in project.md | project.md ≤10s scan; use spec-docs for detailed content |
00092| 

(End of file - total 92 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: {{CHANGE_NAME}}
00003| status: PLANNING
00004| type: ""
00005| change-type: single
00006| created: {{TIME}}
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: single | sub
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| -->
00015| 
00016| # {{CHANGE_NAME}}
00017| 
00018| ## A. Problem Statement
00019| <!-- @REPLACE -->
00020| 
00021| <!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
00022| Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->
00023| 
00024| ## B. Proposed Solution
00025| <!-- @REPLACE -->
00026| 
00027| ### Approach
00028| <!-- Core idea (1-3 paragraphs) + why this over alternatives -->
00029| 
00030| ### Key Design
00031| <!-- Interfaces, data models, key logic — scale by complexity:
00032| Simple (≤5 files): inline in Approach, brief mention
00033| Medium (5-15 files): dedicated sub-sections (### Interface, ### Data Model)
00034| Complex (>15 files): detailed design here or in reference/design.md -->
00035| 

(End of file - total 35 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change-root\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: {{CHANGE_NAME}}
00003| status: PLANNING
00004| type: ""
00005| change-type: root
00006| created: {{TIME}}
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: root (coordinator for sub-changes)
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| -->
00015| 
00016| # {{CHANGE_NAME}}
00017| 
00018| ## A. Problem Statement
00019| <!-- @REPLACE -->
00020| 
00021| <!-- @RULE: Overall impact. This is the root coordinator — describe the FULL scope. -->
00022| 
00023| ## B. Proposed Solution
00024| <!-- @REPLACE -->
00025| 
00026| ### Overall Approach
00027| <!-- High-level strategy. How will this be broken into phases? Delivery order? -->
00028| 
00029| ### Phase Overview
00030| <!-- @RULE: List phases with goals. Each phase becomes a sub-change.
00031| 
00032| Format:
00033| - **Phase 1: <name>** — goal, measurable deliverable, scope (subsystems/modules)
00034| - **Phase 2: <name>** — goal, measurable deliverable, dependencies on Phase 1
00035| 
00036| Coordination Notes:
00037| - Cross-phase dependencies, shared interfaces, integration points -->
00038| 

(End of file - total 38 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 8.8s)

_Thinking:_

**Inspecting task templates and frontmatter**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change\\tasks.md"
}
```
**Output:**
```
<file>
00001| ---
00002| change: "{{CHANGE_NAME}}"
00003| updated: ""
00004| ---
00005| 
00006| # Tasks
00007| 
00008| ## Legend
00009| `[ ]` Todo | `[x]` Done
00010| 
00011| ## Tasks
00012| <!-- @REPLACE -->
00013| 
00014| <!-- @RULE: Organize by phases. Each task <2h, independently testable.
00015| Phase emoji: ⏳ pending | 🚧 in progress | ✅ done
00016| 
00017| ### Phase 1: <name> ⏳
00018| - [ ] Task description `path/file.py`
00019| - [ ] Task description `path/file.py`
00020| **Verification**: <how to verify this phase>
00021| 
00022| ### Feedback Tasks
00023| Use this section for tasks added during review/feedback loop.
00024| -->
00025| 
00026| ---
00027| 
00028| ## Progress
00029| <!-- @REPLACE -->
00030| 
00031| **Overall**: 0%
00032| 
00033| | Phase | Progress | Status |
00034| |-------|----------|--------|
00035| | Phase 1 | 0% | ⏳ |
00036| 
00037| **Recent**:
00038| - (none yet)
00039| 

(End of file - total 39 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change-root\\tasks.md"
}
```
**Output:**
```
<file>
00001| ---
00002| change: "{{CHANGE_NAME}}"
00003| change-type: root
00004| updated: ""
00005| ---
00006| 
00007| # Milestones
00008| 
00009| ## Legend
00010| `[ ]` Todo | `[x]` Done (sub-change completed + verified)
00011| 
00012| ## Milestones
00013| <!-- @REPLACE -->
00014| 
00015| <!-- @RULE: Each milestone maps to a sub-change. Track at phase level, not file level.
00016| Phase emoji: ⏳ pending | 🚧 in progress | ✅ done
00017| 
00018| ### Phase 1: <name> ⏳
00019| - [ ] Sub-change created and linked
00020| - [ ] Sub-change completed and archived
00021| **Deliverable**: <what Phase 1 delivers>
00022| **Sub-change**: <link when created>
00023| -->
00024| 
00025| ---
00026| 
00027| ## Progress
00028| 
00029| **Overall**: 0%
00030| 
00031| | Phase | Sub-Change | Status | Deliverable |
00032| |-------|------------|--------|-------------|
00033| | Phase 1 | (pending) | ⏳ | |
00034| 
00035| **Recent**:
00036| - (none yet)
00037| 

(End of file - total 37 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-review\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-review
00003| description: "User acceptance and feedback loop. Handle argue-improve cycles until user is satisfied."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Review
00010| 
00011| Collect user feedback, iterate improvements, close the loop.
00012| 
00013| ---
00014| 
00015| ## When This Phase Starts
00016| 
00017| After `sspec-implement` completes and user begins reviewing:
00018| - User tests the implementation
00019| - User examines code changes
00020| - User provides feedback (approval, issues, or rejection)
00021| 
00022| ## Feedback Loop
00023| 
00024| ```
00025| User feedback ─→ Assess scope ─→ Act ─→ @ask "Fixed. Check again?"
00026|                                   ↑                    │
00027|                                   └────────────────────┘
00028|                             (repeat until user satisfied)
00029| ```
00030| 
00031| ### Assess Feedback Scope
00032| 
00033| When user provides feedback or disagrees:
00034| 
00035| | Scope | Signal | Action |
00036| |-------|--------|--------|
00037| | **Implementation detail** | "This variable name", "Move this function", "Fix this edge case" | Fix directly, update tasks.md |
00038| | **Design decision** | "I don't want Redis, use SQLite", "Wrong approach for this module" | Revise spec.md B → regenerate affected tasks → re-implement |
00039| | **Requirement itself** | "Actually I don't need this feature", "The real problem is different" | Revise spec.md A, mark scope change in handover.md, return to `sspec-design` |
00040| 
00041| ### Adding Feedback Tasks
00042| 
00043| When fixes require non-trivial work, add them to tasks.md:
00044| 
00045| ```markdown
00046| ### Feedback Tasks 🚧
00047| - [ ] Fix edge case in `src/auth/jwt.py` — handle expired refresh tokens
00048| - [ ] Rename `process()` to `validate_token()` per user feedback
00049| **Verification**: User confirms fixes are satisfactory
00050| ```
00051| 
00052| Then implement these tasks following `sspec-implement` workflow.
00053| 
00054| ## Rejection Protocol
00055| 
00056| If user strongly disagrees (`@argue`):
00057| 
00058| 1. **STOP immediately** — don't continue current work
00059| 2. **Assess scope** using the table above
00060| 3. **Acknowledge** the disagreement explicitly
00061| 4. **Act** based on scope:
00062|    - Implementation: fix and continue
00063|    - Design: return to `sspec-design`, `@ask` for new direction
00064|    - Requirement: return to `sspec-design`, reassess from problem statement
00065| 
00066| ## Close Loop
00067| 
00068| When user is satisfied:
00069| 
00070| 1. Ensure all tasks (including feedback tasks) are marked `[x]`
00071| 2. Update spec.md frontmatter: `status: REVIEW → DONE`
00072| 3. If change produced architectural knowledge → `@ask` user: "Should I create/update a spec-doc for X?" (use `write-spec-doc` SKILL if yes)
00073| 4. Suggest next actions:
00074|    - Archive the change if work is complete
00075|    - `@handover` if session is ending
00076| 
00077| **FORBIDDEN transitions**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
00078| 
00079| ## Status Flow
00080| 
00081| ```
00082| DOING (implement complete) → REVIEW (user reviewing)
00083|   → DONE (user satisfied)
00084|   → DOING (needs more work → implement feedback tasks → REVIEW again)
00085|   → PLANNING (requirement/design changed → back to design)
00086| ```
00087| 

(End of file - total 87 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-implement\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-implement
00003| description: "Execute tasks from tasks.md. Implement code changes, update progress. Use after plan approval."
00004| metadata:
00005|   author: frostime
00006|   version: 2.0.0
00007| ---
00008| 
00009| # SSPEC Implement
00010| 
00011| Execute the approved plan. Work through tasks.md systematically.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (design context) + tasks.md (execution plan)
00019| 2. For each pending task: implement → verify → mark done
00020| 3. Update progress after EACH task
00021| 4. @ask user when all tasks complete
00022| ```
00023| 
00024| ## Execution Rules
00025| 
00026| ### Task Loop
00027| 
00028| For each pending task:
00029| 1. Announce which task you're working on
00030| 2. Make the code changes
00031| 3. Verify the change works
00032| 4. Mark task complete: `- [ ]` → `- [x]`
00033| 5. Update Progress section
00034| 6. Continue to next task
00035| 
00036| **Update after EACH task** — not in batches.
00037| 
00038| ### When to Pause
00039| 
00040| | Situation | Action |
00041| |-----------|--------|
00042| | Task is ambiguous | → `@ask` for clarification |
00043| | Implementation reveals design issue | → Suggest returning to `sspec-design` |
00044| | Blocker encountered | → Record in `handover.md` Notes, `@ask` user |
00045| | Multiple valid approaches for a task | → Pick the simpler one, note in handover |
00046| | Design assumption was wrong | → `@ask` user: "Design says X but I found Y. Revise?" |
00047| 
00048| **Don't guess on blockers.** One `@ask` < one rework cycle.
00049| 
00050| ### Keep Changes Focused
00051| 
00052| - Only modify files relevant to the current task
00053| - Preserve existing code style, comments, and structure
00054| - Don't refactor unrelated code
00055| - If a task grows beyond scope → split it, add new tasks to tasks.md
00056| 
00057| ## Progress Updates
00058| 
00059| After completing each task, update the Progress section:
00060| 
00061| ```markdown
00062| **Overall**: 40%
00063| 
00064| | Phase | Progress | Status |
00065| |-------|----------|--------|
00066| | Phase 1 | 100% | ✅ |
00067| | Phase 2 | 25% | 🚧 |
00068| 
00069| **Recent**:
00070| - Completed: Create auth middleware `src/middleware/auth.py`
00071| - Completed: Add JWT validation `src/auth/jwt.py`
00072| ```
00073| 
00074| ## Handover During Implementation
00075| 
00076| For long implementation sessions (>50 exchanges or multi-file work):
00077| - Write key decisions to `handover.md` Working Memory → Decisions
00078| - Record discovered gotchas to → Notes
00079| - Update Key Files as you discover important files
00080| 
00081| **Test**: "Would I struggle to continue if context was compressed right now?" → Write to handover.
00082| 
00083| ## Exit: @ask User (MANDATORY)
00084| 
00085| When all tasks are complete:
00086| 
00087| 1. Update Progress to show 100%
00088| 2. Summarize what was implemented
00089| 3. `@ask` user: "Implementation complete. Please review. Any issues or feedback?"
00090| 
00091| → Transition to `sspec-review` phase.
00092| 

(End of file - total 92 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\project.md"
}
```
**Output:**
```
<file>
00001| # Project Context
00002| 
00003| **Name**: {{TODO}}
00004| **Description**: {{TODO}}
00005| **Repo**: {{TODO}}
00006| 
00007| ## Project Overview
00008| <!-- [Describe project's purpose and overview design] -->
00009| 
00010| ## Tech Stack
00011| - [List primary technologies, e.g. TypeScript, React, Node.js]
00012| 
00013| ## Key Paths
00014| <!-- @RULE: Most important directories/files for quick navigation.
00015| Keep ≤10 entries. Agent uses this to orient in the codebase. -->
00016| 
00017| | Path | Purpose |
00018| |------|---------|
00019| | `src/` | Source code |
00020| | `tests/` | Test files |
00021| 
00022| ## Conventions
00023| <!-- @RULE: Coding rules that apply across ALL work in this project.
00024| One-liners only. If a convention needs multi-paragraph explanation → write a spec-doc.
00025| Examples: "snake_case for Python, camelCase for JS", "All API routes: /api/v1/*",
00026| "Never commit .env files", "Prefer composition over inheritance" -->
00027| 
00028| **Architecture Patterns**
00029| **Domain Context**
00030| **Important Constraints**
00031| 
00032| ## Spec-Docs Index
00033| <!-- @RULE: Quick reference to formal specs in `.sspec/spec-docs/`.
00034| Agent reads this to know what architecture knowledge exists before starting work.
00035| Keep entries in sync with actual spec-doc files. Format: `- [name](spec-docs/<file>) — one-line description` -->
00036| 
00037| (none yet — create spec-docs with `sspec doc new "<name>"`)
00038| 
00039| ## Notes
00040| <!-- @RULE: Project-level memory. Append-only log of learnings, gotchas, preferences.
00041| Agent appends here during @handover when a discovery is project-wide (not change-specific).
00042| Format each entry as: `- YYYY-MM-DD: <learning>`
00043| Prune entries that become outdated or graduate to Conventions/spec-docs. -->
00044| 

(End of file - total 44 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.9s)

_Thinking:_

**Inspecting skill spec templates**

```
Tool: glob

**Input:**
```json
{
  "pattern": "src/sspec/templates/**/*.json",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
No files found
```
```

---

## Assistant (Build · gpt-5.3-codex · 10.9s)

_Thinking:_

**Inspecting template and threshold updates**

```
Tool: grep

**Input:**
```json
{
  "pattern": ">\\s*(20|30|50)\\s*exchanges|long \\(>",
  "path": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates",
  "include": "*.md"
}
```
**Output:**
```
Found 4 matches
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-handover\SKILL.md:
  Line 26: - Session is long (>50 exchanges or complex multi-file work)

H:\SrcCode\playground\sspec\src\sspec\templates\AGENTS.md:
  Line 37: - Long session (>20 exchanges) → checkpoint `handover.md`
  Line 59: - Mid-session when context is long (>30 exchanges)

H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-implement\SKILL.md:
  Line 76: For long implementation sessions (>50 exchanges or multi-file work):
```
```

---

## Assistant (Build · gpt-5.3-codex · 17.0s)

_Thinking:_

**Planning frontmatter normalization**

```
Tool: grep

**Input:**
```json
{
  "pattern": "managed_skills|file_hashes|skills/|SKILL.md|references",
  "path": "H:\\SrcCode\\playground\\sspec\\src",
  "include": "*.py"
}
```
**Output:**
```
Found 59 matches
H:\SrcCode\playground\sspec\src\sspec\libs\path_refs.py:
  Line 1: """Utilities for updating file path references across multiple files."""
  Line 8: def update_file_references(
  Line 42: def update_references_in_dirs(
  Line 49:     """Update path references in all matching files across multiple directories.

H:\SrcCode\playground\sspec\src\sspec\commands\change.py:
  Line 51:     """Parse linked active requests from change frontmatter references."""
  Line 54:     references = change_info.frontmatter.get('reference', [])
  Line 55:     if not isinstance(references, list):
  Line 61:     for ref in references:

H:\SrcCode\playground\sspec\src\sspec\core.py:
  Line 38: PROTECTED_PATTERNS = ['changes/*', 'requests/*', 'skills/*', 'spec-docs/*']
  Line 217:     """List skill template directories that contain SKILL.md."""
  Line 223:     return [d for d in template_skills_dir.iterdir() if d.is_dir() and (d / 'SKILL.md').exists()]

H:\SrcCode\playground\sspec\src\sspec\commands\skill.py:
  Line 30:     """Create a new skill under `.sspec/skills/<name>`."""
  Line 59:     console.print('  └── SKILL.md')
  Line 62:     console.print('  1. Edit SKILL.md to define your skill')

H:\SrcCode\playground\sspec\src\sspec\services\skill_service.py:
  Line 37:     """Parse YAML front matter from a SKILL.md file."""
  Line 120:             skill_file = entry / 'SKILL.md'
  Line 126:                         'file': f'{entry.name}/SKILL.md',
  Line 239:         if not child.is_dir() or not (child / 'SKILL.md').exists():
  Line 359:     """Create a new skill under `.sspec/skills/<name>`.
  Line 373:     skill_file = hub_dir / 'SKILL.md'

H:\SrcCode\playground\sspec\src\sspec\services\project_update_service.py:
  Line 71:     - `.claude/skills/<skill-a>` (symlink)
  Line 72:     - `.claude/skills/<skill-b>` (symlink)
  Line 188:     managed: set[str] = set(meta.get('managed_skills', []) or [])
  Line 234:     old_hashes: dict[str, str] = meta.get('file_hashes', {}) or {}
  Line 296:         template_skill_file = skill_dir / 'SKILL.md'
  Line 302:         hash_key = f'skills/{skill_name}'
  Line 303:         legacy_hash_key = f'skills/{skill_name}/SKILL.md'
  Line 311:             skill_dest_file = skill_dest_dir / 'SKILL.md'

H:\SrcCode\playground\sspec\src\sspec\services\ask_service.py:
  Line 14: from sspec.libs.path_refs import update_references_in_dirs
  Line 60:     Also updates references in requests/, changes/, asks/, tmp/ directories,
  Line 77:     # Update references after moving
  Line 87:     update_references_in_dirs(

H:\SrcCode\playground\sspec\src\sspec\services\request_service.py:
  Line 22: from sspec.libs.path_refs import update_references_in_dirs
  Line 250:             '<!-- Any constraints, preferences, references -->\n\n'
  Line 323:     and updates cross-references in the linked change.
  Line 350:     # Update cross-references in linked change
  Line 351:     _rewrite_references_after_request_archive(
  Line 360: def _rewrite_references_after_request_archive(
  Line 365:     """Update references after archiving a request.
  Line 367:     When request is moved to archive/, all references to it need updated paths.
  Line 378:     update_references_in_dirs(

H:\SrcCode\playground\sspec\src\sspec\services\change_service.py:
  Line 25: from sspec.libs.path_refs import update_references_in_dirs
  Line 229:     # Update cross-references: any request pointing to this change should point to archive
  Line 230:     _rewrite_references_after_change_archive(sspec_root, name, archive_path)
  Line 235: def _rewrite_references_after_change_archive(
  Line 238:     """Update references after archiving a change.
  Line 240:     When change is moved to archive/, all references to it need updated paths.
  Line 254:     update_references_in_dirs(

H:\SrcCode\playground\sspec\src\sspec\services\project_init_service.py:
  Line 85: skills/**
  Line 181:         if not (skill_dir / 'SKILL.md').exists():
  Line 184:         skill_hashes[f'skills/{skill_name}'] = compute_dir_hash(skill_dir, common_replacements)
  Line 192:         'file_hashes': skill_hashes,
  Line 193:         'managed_skills': sorted(managed_skill_names),
  Line 210:             meta_data['file_hashes'][file_path] = compute_hash(

H:\SrcCode\playground\sspec\src\sspec\commands\project.py:
  Line 119:     console.print('  [green]+[/green] Installed core skills to .sspec/skills/ (copy)')
  Line 249:     old_hashes = meta.get('file_hashes', {}) or {}
  Line 310:                     if key.startswith(f'skills/{orphan.skill_name}'):
  Line 428:         meta['file_hashes'] = new_hashes
  Line 429:         meta['managed_skills'] = sorted(d.name for d in list_template_skills())
```
```

---

## Assistant (Build · gpt-5.3-codex · 16.1s)

_Thinking:_

**Planning nuanced template and doc edits**

```
Tool: grep

**Input:**
```json
{
  "pattern": "Section C|## C\\.|spec\\.md C|C\\)",
  "path": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates",
  "include": "*.md"
}
```
**Output:**
```
Found 2 matches
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-ask\SKILL.md:
  Line 92: **C) In-Memory** — simple, lost on restart

H:\SrcCode\playground\sspec\src\sspec\templates\skills\use-powershell\SKILL.md:
  Line 87: # With context lines (like grep -C)
```
```

---

## Assistant (Build · gpt-5.3-codex · 27.1s)

_Thinking:_

**Planning multi-file spec patches**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\AGENTS.md\n@@\n-**Background rules** (always active):\n-- Important discovery → write to `handover.md` immediately\n-- Long session (>20 exchanges) → checkpoint `handover.md`\n-- Uncertain → `@ask` (30s question < hours of rework)\n-- User rejects tool call → STOP → `@ask` reason\n+**Background rules** (always active):\n+- Important discovery → write to `handover.md` immediately\n+- Long session (>30 exchanges) → checkpoint `handover.md`\n+- Uncertain → `@ask` (30s question < hours of rework)\n+- User rejects tool call → STOP → `@ask` reason\n*** End Patch"
}
```
**Error:**
```
Error: apply_patch verification failed: Failed to read file to update: H:\SrcCode\playground\sspec\H
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.9s)

_Thinking:_

**Deciding on relative paths for patches**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/AGENTS.md\n@@\n-**Background rules** (always active):\n-- Important discovery → write to `handover.md` immediately\n-- Long session (>20 exchanges) → checkpoint `handover.md`\n-- Uncertain → `@ask` (30s question < hours of rework)\n-- User rejects tool call → STOP → `@ask` reason\n+**Background rules** (always active):\n+- Important discovery → write to `handover.md` immediately\n+- Long session (>30 exchanges) → checkpoint `handover.md`\n+- Uncertain → `@ask` (30s question < hours of rework)\n+- User rejects tool call → STOP → `@ask` reason\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\AGENTS.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 17.4s)

_Thinking:_

**Designing multi-section patch**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/skills/sspec-design/SKILL.md\n@@\n metadata:\n   author: frostime\n-  version: 3.0.0\n+  version: 3.1.0\n@@\n Root change creates a coordinator with different templates:\n - Root `spec.md`: Phase overview, not file-level detail\n - Root `tasks.md`: Milestones, not individual tasks\n+\n+## Step 2.5: Normalize spec.md Frontmatter (MANDATORY)\n+\n+Use this schema exactly:\n+\n+```yaml\n+---\n+name: <change-name>\n+status: PLANNING\n+type: \"\"\n+change-type: single|sub|root\n+created: <iso-timestamp>\n+reference: null|[]\n+---\n+```\n+\n+### Sub-Change Must Link Root (Required)\n+\n+```yaml\n+change-type: sub\n+reference:\n+  - source: \"changes/<root-change-dir>\"\n+    type: \"root-change\"\n+    note: \"Phase <n>: <phase-name>\"\n+```\n+\n+### Root Should Link Request + Sub-Changes (Bidirectional Tracking)\n+\n+```yaml\n+change-type: root\n+reference:\n+  - source: \"requests/<request-file>.md\"\n+    type: \"request\"\n+  - source: \"changes/<sub-change-dir>\"\n+    type: \"sub-change\"\n+    note: \"Phase <n>: <phase-name>\"\n+```\n+\n+Use workspace-relative paths without `./` prefix.\n@@\n After defining phases → create sub-changes:\n ```bash\n sspec change new <phase-name>    # for each phase, link to root via reference\n ```\n+\n+For each sub-change, ensure two-way references:\n+- Sub `spec.md` has `type: root-change` entry pointing to root\n+- Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change\n \n Each sub-change then goes through its own design → plan → implement → review cycle.\n@@\n Wait for user approval before proceeding to `sspec-plan`.\n \n-After user confirms → transition status `PLANNING → DOING` in spec.md frontmatter.\n+After user confirms design, proceed to `sspec-plan`.\n+Only after user also approves the task plan, transition status `PLANNING → DOING`.\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\skills\sspec-design\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.0s)

_Thinking:_

**Clarifying frontmatter entry type**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/skills/sspec-plan/SKILL.md\n@@\n metadata:\n   author: frostime\n-  version: 2.0.0\n+  version: 2.1.0\n@@\n ## Task Standards\n+\n+### tasks.md Frontmatter (MANDATORY)\n+\n+Single/sub change:\n+\n+```yaml\n+---\n+change: \"<change-name>\"\n+updated: \"\"\n+---\n+```\n+\n+Root change:\n+\n+```yaml\n+---\n+change: \"<change-name>\"\n+change-type: root\n+updated: \"\"\n+---\n+```\n+\n+Keep `change` exactly aligned with `spec.md` `name`.\n \n ### Granularity\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\skills\sspec-plan\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 12.3s)

_Thinking:_

**Implementing threshold and version patch**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/skills/sspec-implement/SKILL.md\n@@\n metadata:\n   author: frostime\n-  version: 2.0.0\n+  version: 2.1.0\n@@\n-For long implementation sessions (>50 exchanges or multi-file work):\n+For long implementation sessions (>30 exchanges or multi-file work):\n - Write key decisions to `handover.md` Working Memory → Decisions\n - Record discovered gotchas to → Notes\n - Update Key Files as you discover important files\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\skills\sspec-implement\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 8.7s)

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/skills/sspec-handover/SKILL.md\n@@\n metadata:\n   author: frostime\n-  version: 3.0.0\n+  version: 3.1.0\n@@\n Update handover.md Working Memory when:\n-- Session is long (>50 exchanges or complex multi-file work)\n+- Session is long (>30 exchanges or complex multi-file work)\n - Important decision just made with non-trivial reasoning\n - Key file discovered that future work depends on\n - Design tradeoff resolved after discussion\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\skills\sspec-handover\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.5s)

_Thinking:_

**Editing spec comments for clarity**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/change/spec.md\n@@\n <!-- @RULE: Frontmatter\n status: PLANNING | DOING | REVIEW | DONE | BLOCKED\n change-type: single | sub\n reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>\n+\n+Sub-change MUST link root:\n+reference:\n+  - source: \"changes/<root-change-dir>\"\n+    type: \"root-change\"\n+    note: \"Phase <n>: <phase-name>\"\n+\n+Single-change common reference:\n+reference:\n+  - source: \"requests/<request-file>.md\"\n+    type: \"request\"\n -->\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\change\spec.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 9.0s)

_Thinking:_

**Updating documentation comments**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/change-root/spec.md\n@@\n <!-- @RULE: Frontmatter\n status: PLANNING | DOING | REVIEW | DONE | BLOCKED\n change-type: root (coordinator for sub-changes)\n reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>\n+\n+Root reference SHOULD include request + sub-changes:\n+reference:\n+  - source: \"requests/<request-file>.md\"\n+    type: \"request\"\n+  - source: \"changes/<sub-change-dir>\"\n+    type: \"sub-change\"\n+    note: \"Phase <n>: <phase-name>\"\n -->\n@@\n ### Phase Overview\n <!-- @RULE: List phases with goals. Each phase becomes a sub-change.\n@@\n Coordination Notes:\n-- Cross-phase dependencies, shared interfaces, integration points -->\n+- Cross-phase dependencies, shared interfaces, integration points\n+\n+When a sub-change is created, sync references in BOTH directions:\n+- Root `spec.md` adds `type: sub-change` entry for the sub-change\n+- Sub `spec.md` adds `type: root-change` entry back to this root -->\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\change-root\spec.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 8.8s)

_Thinking:_

**Checking frontmatter normalization**

```
Tool: grep

**Input:**
```json
{
  "pattern": ">\\s*(20|50)\\s*exchanges|>20 exchanges|>50 exchanges",
  "path": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates",
  "include": "*.md"
}
```
**Output:**
```
No files found
```
```

---

## Assistant (Build · gpt-5.3-codex · 5.4s)

_Thinking:_

**Confirming threshold limits**

```
Tool: grep

**Input:**
```json
{
  "pattern": ">30 exchanges",
  "path": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates",
  "include": "*.md"
}
```
**Output:**
```
Found 4 matches
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-handover\SKILL.md:
  Line 26: - Session is long (>30 exchanges or complex multi-file work)

H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-implement\SKILL.md:
  Line 76: For long implementation sessions (>30 exchanges or multi-file work):

H:\SrcCode\playground\sspec\src\sspec\templates\AGENTS.md:
  Line 37: - Long session (>30 exchanges) → checkpoint `handover.md`
  Line 59: - Mid-session when context is long (>30 exchanges)
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.7s)

_Thinking:_

**Verifying status transitions**

```
Tool: grep

**Input:**
```json
{
  "pattern": "PLANNING.?→.?DOING|PLANNING->DOING",
  "path": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates",
  "include": "*.md"
}
```
**Output:**
```
Found 1 matches
H:\SrcCode\playground\sspec\src\sspec\templates\skills\sspec-design\SKILL.md:
  Line 204: Only after user also approves the task plan, transition status `PLANNING → DOING`.
```
```

---

## Assistant (Build · gpt-5.3-codex · 9.8s)

_Thinking:_

**Verifying edits and consistency**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-design\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-design
00003| description: "Assess scale, create change, fill spec.md, align with user. Use after research when ready to define the solution."
00004| metadata:
00005|   author: frostime
00006|   version: 3.1.0
00007| ---
00008| 
00009| # SSPEC Design
00010| 
00011| Define the problem and design the solution. Create the change. **Align with user before planning.**
00012| 
00013| This is a **user-in-the-loop** phase — like review, the user must confirm your design before you proceed. Never auto-advance to planning.
00014| 
00015| ---
00016| 
00017| ## Workflow
00018| 
00019| ```
00020| 1. Assess scale → micro / single / multi
00021| 2. Create change (CLI)
00022| 3. Fill spec.md
00023| 4. @ask user for alignment (MANDATORY)
00024| ```
00025| 
00026| ## Step 1: Assess Scale
00027| 
00028| | Scale | Criteria | Action |
00029| |-------|----------|--------|
00030| | **Micro** | ≤3 files, ≤30min, no design decisions, trivially reversible | Do directly. No change needed. Track in request if useful. |
00031| | **Single** | ≤1 week, ≤15 files, one subsystem, ≤20 tasks | Standard change → Step 2 Single |
00032| | **Multi** | >1 week OR >15 files across subsystems OR >20 tasks OR high risk | Root change → Step 2 Root |
00033| 
00034| **Uncertain?** → `@ask` user about scope/splitting.
00035| 
00036| ## Step 2: Create Change
00037| 
00038| ### Single Path
00039| 
00040| ```bash
00041| sspec change new <name>                        # standalone
00042| sspec change new --from <request>              # from request (auto-link)
00043| sspec change new <name> --from <request>       # explicit name + request link
00044| ```
00045| 
00046| ### Root Path (Multi-Change)
00047| 
00048| ```bash
00049| sspec change new <name> --root                 # creates root coordinator
00050| sspec change new <name> --root --from <req>    # root from request
00051| ```
00052| 
00053| Root change creates a coordinator with different templates:
00054| - Root `spec.md`: Phase overview, not file-level detail
00055| - Root `tasks.md`: Milestones, not individual tasks
00056| 
00057| ## Step 2.5: Normalize spec.md Frontmatter (MANDATORY)
00058| 
00059| Use this schema exactly:
00060| 
00061| ```yaml
00062| ---
00063| name: <change-name>
00064| status: PLANNING
00065| type: ""
00066| change-type: single|sub|root
00067| created: <iso-timestamp>
00068| reference: null|[]
00069| ---
00070| ```
00071| 
00072| ### Sub-Change Must Link Root (Required)
00073| 
00074| ```yaml
00075| change-type: sub
00076| reference:
00077|   - source: "changes/<root-change-dir>"
00078|     type: "root-change"
00079|     note: "Phase <n>: <phase-name>"
00080| ```
00081| 
00082| ### Root Should Link Request + Sub-Changes (Bidirectional Tracking)
00083| 
00084| ```yaml
00085| change-type: root
00086| reference:
00087|   - source: "requests/<request-file>.md"
00088|     type: "request"
00089|   - source: "changes/<sub-change-dir>"
00090|     type: "sub-change"
00091|     note: "Phase <n>: <phase-name>"
00092| ```
00093| 
00094| Use workspace-relative paths without `./` prefix.
00095| 
00096| ## Step 3: Fill spec.md
00097| 
00098| ### What Users Care About Most
00099| 
00100| Users review designs for: **interfaces**, **data types**, **data flow**, and **logic flow**.
00101| Prioritize these in Section B. Abstract hand-waving ("we'll handle it later") erodes trust.
00102| 
00103| ### Single Change
00104| 
00105| **Section A — Problem Statement**:
00106| - Quantify impact: "[metric] causing [impact]"
00107| - Simple changes: single paragraph
00108| - Complex changes: split "Current Situation" + "User Requirement"
00109| 
00110| | ❌ Bad | ✅ Good |
00111| |--------|---------|
00112| | "Need to refactor" | "Auth takes 5s → 12% conversion drop" |
00113| | "Improve the UI" | "Form completion rate 23% → target 60%" |
00114| 
00115| **Section B — Proposed Solution**:
00116| 
00117| `### Approach`: Core idea (1-3 paragraphs) + why this over alternatives.
00118| 
00119| `### Key Design`: Scale by complexity:
00120| 
00121| | Complexity | Design Depth |
00122| |------------|-------------|
00123| | Simple (≤5 files) | Inline in Approach, brief mention |
00124| | Medium (5-15 files) | Sub-sections: `### Interface Design`, `### Data Model`, `### Key Logic` |
00125| | Complex (>15 files) | Detailed design in `reference/design.md`, link from B |
00126| 
00127| **What MUST appear in B** (by priority):
00128| 1. **Interfaces** — function signatures, API contracts, class interfaces
00129| 2. **Data types** — models, schemas, type definitions
00130| 3. **Data flow** — how data moves through the system (input → transform → output)
00131| 4. **Logic flow** — key algorithms, decision trees, state machines
00132| 5. **Design rationale** — why this approach over alternatives
00133| 
00134| **What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).
00135| 
00136| ### Section B Example (Medium Complexity)
00137| 
00138| ```markdown
00139| ## B. Proposed Solution
00140| 
00141| ### Approach
00142| Add token refresh via middleware. Background refresh prevents expired tokens from blocking requests.
00143| 
00144| Why middleware: intercepting at HTTP layer avoids modifying every API call site.
00145| 
00146| ### Key Design
00147| 
00148| #### Interface
00149| - `TokenService.refresh(token: str) -> TokenPair`
00150| - `AuthMiddleware.intercept(request: Request) -> Request`
00151| - `TokenPair = TypedDict('TokenPair', {'access': str, 'refresh': str, 'expires_at': int})`
00152| 
00153| #### Data Flow
00154| ```
00155| Request → AuthMiddleware → check expiry
00156|   → if valid: pass through
00157|   → if expiring (<5min): background refresh + pass through
00158|   → if expired: block, refresh, retry with new token
00159| ```
00160| 
00161| #### Key Logic
00162| Refresh uses sliding window: if token expires within `REFRESH_WINDOW` (default 5min),
00163| trigger background refresh. Concurrent requests share one refresh via lock.
00164| ```
00165| 
00166| ### Root Change
00167| 
00168| **Section A**: Overall problem — full scope, not a single module.
00169| 
00170| **Section B**:
00171| - `### Overall Approach`: High-level strategy, delivery order
00172| - `### Phase Overview`: Each phase with goal, scope, dependencies
00173| 
00174| ```markdown
00175| - **Phase 1: Auth Backend** — JWT + Redis cache, goal: <1s auth response
00176| - **Phase 2: Auth Frontend** — Login/signup UI, depends on Phase 1
00177| - **Phase 3: Migration** — Migrate existing sessions, depends on Phase 1+2
00178| ```
00179| 
00180| After defining phases → create sub-changes:
00181| ```bash
00182| sspec change new <phase-name>    # for each phase, link to root via reference
00183| ```
00184| 
00185| For each sub-change, ensure two-way references:
00186| - Sub `spec.md` has `type: root-change` entry pointing to root
00187| - Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change
00188| 
00189| Each sub-change then goes through its own design → plan → implement → review cycle.
00190| 
00191| ## Step 4: @ask for Alignment (MANDATORY)
00192| 
00193| **Never skip this step.** This is a user-in-the-loop confirmation — like review phase, the user must sign off.
00194| 
00195| Present the design to user for confirmation:
00196| - Problem statement summary
00197| - Proposed approach and rationale
00198| - Key interfaces and data types
00199| - (Root) Phase breakdown
00200| 
00201| Wait for user approval before proceeding to `sspec-plan`.
00202| 
00203| After user confirms design, proceed to `sspec-plan`.
00204| Only after user also approves the task plan, transition status `PLANNING → DOING`.
00205| 

(End of file - total 205 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: {{CHANGE_NAME}}
00003| status: PLANNING
00004| type: ""
00005| change-type: single
00006| created: {{TIME}}
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: single | sub
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Sub-change MUST link root:
00016| reference:
00017|   - source: "changes/<root-change-dir>"
00018|     type: "root-change"
00019|     note: "Phase <n>: <phase-name>"
00020| 
00021| Single-change common reference:
00022| reference:
00023|   - source: "requests/<request-file>.md"
00024|     type: "request"
00025| -->
00026| 
00027| # {{CHANGE_NAME}}
00028| 
00029| ## A. Problem Statement
00030| <!-- @REPLACE -->
00031| 
00032| <!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
00033| Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->
00034| 
00035| ## B. Proposed Solution
00036| <!-- @REPLACE -->
00037| 
00038| ### Approach
00039| <!-- Core idea (1-3 paragraphs) + why this over alternatives -->
00040| 
00041| ### Key Design
00042| <!-- Interfaces, data models, key logic — scale by complexity:
00043| Simple (≤5 files): inline in Approach, brief mention
00044| Medium (5-15 files): dedicated sub-sections (### Interface, ### Data Model)
00045| Complex (>15 files): detailed design here or in reference/design.md -->
00046| 

(End of file - total 46 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\change-root\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: {{CHANGE_NAME}}
00003| status: PLANNING
00004| type: ""
00005| change-type: root
00006| created: {{TIME}}
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: root (coordinator for sub-changes)
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Root reference SHOULD include request + sub-changes:
00016| reference:
00017|   - source: "requests/<request-file>.md"
00018|     type: "request"
00019|   - source: "changes/<sub-change-dir>"
00020|     type: "sub-change"
00021|     note: "Phase <n>: <phase-name>"
00022| -->
00023| 
00024| # {{CHANGE_NAME}}
00025| 
00026| ## A. Problem Statement
00027| <!-- @REPLACE -->
00028| 
00029| <!-- @RULE: Overall impact. This is the root coordinator — describe the FULL scope. -->
00030| 
00031| ## B. Proposed Solution
00032| <!-- @REPLACE -->
00033| 
00034| ### Overall Approach
00035| <!-- High-level strategy. How will this be broken into phases? Delivery order? -->
00036| 
00037| ### Phase Overview
00038| <!-- @RULE: List phases with goals. Each phase becomes a sub-change.
00039| 
00040| Format:
00041| - **Phase 1: <name>** — goal, measurable deliverable, scope (subsystems/modules)
00042| - **Phase 2: <name>** — goal, measurable deliverable, dependencies on Phase 1
00043| 
00044| Coordination Notes:
00045| - Cross-phase dependencies, shared interfaces, integration points
00046| 
00047| When a sub-change is created, sync references in BOTH directions:
00048| - Root `spec.md` adds `type: sub-change` entry for the sub-change
00049| - Sub `spec.md` adds `type: root-change` entry back to this root -->
00050| 

(End of file - total 50 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\templates\\skills\\sspec-plan\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-plan
00003| description: "Break design into concrete tasks. Fill tasks.md with file-level execution plan. Use after design alignment."
00004| metadata:
00005|   author: frostime
00006|   version: 2.1.0
00007| ---
00008| 
00009| # SSPEC Plan
00010| 
00011| Turn the approved design (spec.md B) into a concrete, file-level execution plan in tasks.md.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (approved design)
00019| 2. Break into phases + file-level tasks
00020| 3. Fill tasks.md
00021| 4. @ask user for final review
00022| ```
00023| 
00024| ## Task Standards
00025| 
00026| ### tasks.md Frontmatter (MANDATORY)
00027| 
00028| Single/sub change:
00029| 
00030| ```yaml
00031| ---
00032| change: "<change-name>"
00033| updated: ""
00034| ---
00035| ```
00036| 
00037| Root change:
00038| 
00039| ```yaml
00040| ---
00041| change: "<change-name>"
00042| change-type: root
00043| updated: ""
00044| ---
00045| ```
00046| 
00047| Keep `change` exactly aligned with `spec.md` `name`.
00048| 
00049| ### Granularity
00050| 
00051| | Change Type | Task Level | Example |
00052| |-------------|-----------|---------|
00053| | Single / Sub | File-level, <2h each | `- [ ] Create src/auth/jwt.py — refresh_token()` |
00054| | Root | Milestone-level (one per sub-change) | `- [ ] Phase 1 sub-change completed` |
00055| 
00056| Each task should be:
00057| - **Independently testable** — can verify without completing other tasks
00058| - **Specific** — mentions exact file path and what to do
00059| - **Small** — <2 hours of work
00060| 
00061| ### Phase Structure
00062| 
00063| ```markdown
00064| ### Phase 1: <name> ⏳
00065| - [ ] Task description `path/file.py`
00066| - [ ] Task description `path/file.py`
00067| **Verification**: <how to verify this phase>
00068| 
00069| ### Phase 2: <name> ⏳
00070| - [ ] Task description `path/file.py`
00071| **Verification**: <how to verify>
00072| ```
00073| 
00074| ### Phase Emoji
00075| 
00076| | Emoji | Meaning |
00077| |-------|---------|
00078| | ⏳ | Pending — not started |
00079| | 🚧 | In progress — actively working |
00080| | ✅ | Done — all tasks complete and verified |
00081| 
00082| ### Verification
00083| 
00084| Each phase MUST have explicit verification criteria:
00085| - What to check (test commands, expected output, manual verification)
00086| - How to know it's done (not "it works" but specific criteria)
00087| 
00088| ## Reference Section B, Don't Repeat
00089| 
00090| tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.
00091| 
00092| - ✅ "Implement Tool Interface per spec.md B"
00093| - ✅ "Create handler following the data flow in spec.md B"
00094| - ❌ Re-listing all function signatures
00095| - ❌ Re-describing the algorithm
00096| 
00097| ## Root Change Planning
00098| 
00099| For root changes, tasks.md contains milestones, not file-level tasks:
00100| 
00101| ```markdown
00102| ### Phase 1: Auth Backend ⏳
00103| - [ ] Sub-change created and linked
00104| - [ ] Sub-change completed and archived
00105| **Deliverable**: JWT auth with <1s response time
00106| **Sub-change**: (link when created)
00107| ```
00108| 
00109| The active sub-change gets its own tasks.md with file-level detail.
00110| 
00111| ## Progress Tracking
00112| 
00113| Update the Progress section after filling tasks:
00114| 
00115| ```markdown
00116| ## Progress
00117| 
00118| **Overall**: 0%
00119| 
00120| | Phase | Progress | Status |
00121| |-------|----------|--------|
00122| | Phase 1 | 0% | ⏳ |
00123| | Phase 2 | 0% | ⏳ |
00124| ```
00125| 
00126| ## Exit: @ask User Review (MANDATORY)
00127| 
00128| Present the task breakdown to user:
00129| - Number of phases and total tasks
00130| - Key verification criteria
00131| - Estimated scope
00132| 
00133| Wait for user approval before starting `sspec-implement`.
00134| 

(End of file - total 134 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 18.1s)

_Thinking:_

**Cleaning redundant lines and planning docs**

```
Tool: bash

**Input:**
```json
{
  "command": "uv pip install -e .",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Reinstalls package in editable mode"
}
```
**Output:**
```
Resolved 13 packages in 4.63s
   Building sspec @ file:///H:/SrcCode/playground/sspec
      Built sspec @ file:///H:/SrcCode/playground/sspec
Prepared 1 package in 722ms
Uninstalled 1 package in 2ms
Installed 1 package in 13ms
 - sspec==0.22.1.dev1+gc9cadd702.d20260224 (from file:///H:/SrcCode/playground/sspec)
 + sspec==0.22.1.dev3+gbab205dc3.d20260224 (from file:///H:/SrcCode/playground/sspec)

```
```

---

## Assistant (Build · gpt-5.3-codex · 12.5s)

_Thinking:_

**Testing init in new temp directory**

```
Tool: bash

**Input:**
```json
{
  "command": "ls -a",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp",
  "description": "Lists tmp directory before creating test workspace"
}
```
**Output:**
```
.
..
.gitignore
Agents.md
agent-prompt-guide.md
legacy-sspec-8.0
list_style_unification.md
new-sspec-9.0
sspec-completion.ps1
test-replace-archive-link-project
test_refactor
tests.zip

```
```

---

## Assistant (Build · gpt-5.3-codex · 5.9s)

_Thinking:_

**Creating directory**

```
Tool: bash

**Input:**
```json
{
  "command": "mkdir \"test_template_tuning_20260224\"",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp",
  "description": "Creates isolated directory for template init test"
}
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.6s)

_Thinking:_

**Running initialization**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run sspec project init",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Initializes sspec project from updated templates"
}
```
**Output:**
```

+ Initialized sspec project in .sspec/
  + Installed core skills to .sspec/skills/ (copy)
  + Created/Updated root AGENTS.md

Skill Installation Location Selection

Traceback (most recent call last):
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 196, in _run_module_as_main
    return _run_code(code, main_globals, None,
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 86, in _run_code
    exec(code, run_globals)
  File "H:\SrcCode\playground\sspec\.venv\Scripts\sspec.exe\__main__.py", line 10, in <module>
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1485, in __call__
    return self.main(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1406, in main
    rv = self.invoke(ctx)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1269, in invoke
    return ctx.invoke(self.callback, **ctx.params)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 824, in invoke
    return callback(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\src\sspec\commands\project.py", line 125, in init
    skill_locations = list(skill_loc) if skill_loc else _interactive_skill_selection(project_root)
  File "H:\SrcCode\playground\sspec\src\sspec\commands\project.py", line 62, in _interactive_skill_selection
    selected = questionary.checkbox(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\questionary\prompts\checkbox.py", line 225, in checkbox
    layout = common.create_inquirer_layout(ic, get_prompt_tokens, **kwargs)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\questionary\prompts\common.py", line 609, in create_inquirer_layout
    ps: PromptSession = PromptSession(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\shortcuts\prompt.py", line 483, in __init__
    self.app = self._create_application(editing_mode, erase_when_done)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\shortcuts\prompt.py", line 744, in _create_application
    application: Application[_T] = Application(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\application\application.py", line 267, in __init__
    self.output = output or session.output
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\application\current.py", line 67, in output
    self._output = create_output()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\defaults.py", line 91, in create_output
    return Win32Output(stdout, default_color_depth=color_depth_from_env)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\win32.py", line 115, in __init__
    info = self.get_win32_screen_buffer_info()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\win32.py", line 219, in get_win32_screen_buffer_info
    raise NoConsoleScreenBufferError
prompt_toolkit.output.win32.NoConsoleScreenBufferError: Found xterm-256color, while expecting a Windows console. Maybe try to run this program using "winpty" or run it in cmd.exe instead. Or otherwise, in case of Cygwin, use the Python executable that is compiled for Cygwin.

```
```

---

## Assistant (Build · gpt-5.3-codex · 8.0s)

_Thinking:_

**Checking init command options**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run sspec project init --help",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Shows init command options for non-interactive run"
}
```
**Output:**
```
Usage: sspec project init [OPTIONS]

  Initialize .sspec directory in current project.

Options:
  --force                         Overwrite existing .sspec directory
  --skill-loc [.claude|.github|.agent]
                                  Skill installation locations (can specify
                                  multiple, or use interactive mode)
  --help                          Show this message and exit.

```
```

---

## Assistant (Build · gpt-5.3-codex · 6.4s)

_Thinking:_

**Planning forced reinitialize**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run sspec project init --force --skill-loc .claude",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Reinitializes project non-interactively with claude skills"
}
```
**Output:**
```

+ Initialized sspec project in .sspec/
  + Installed core skills to .sspec/skills/ (copy)
Traceback (most recent call last):
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 196, in _run_module_as_main
    return _run_code(code, main_globals, None,
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 86, in _run_code
    exec(code, run_globals)
  File "H:\SrcCode\playground\sspec\.venv\Scripts\sspec.exe\__main__.py", line 10, in <module>
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1485, in __call__
    return self.main(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1406, in main
    rv = self.invoke(ctx)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1269, in invoke
    return ctx.invoke(self.callback, **ctx.params)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 824, in invoke
    return callback(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\src\sspec\commands\project.py", line 130, in init
    elevated_choice = questionary.confirm(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\questionary\prompts\confirm.py", line 130, in confirm
    PromptSession(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\shortcuts\prompt.py", line 483, in __init__
    self.app = self._create_application(editing_mode, erase_when_done)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\shortcuts\prompt.py", line 744, in _create_application
    application: Application[_T] = Application(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\application\application.py", line 267, in __init__
    self.output = output or session.output
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\application\current.py", line 67, in output
    self._output = create_output()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\defaults.py", line 91, in create_output
    return Win32Output(stdout, default_color_depth=color_depth_from_env)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\win32.py", line 115, in __init__
    info = self.get_win32_screen_buffer_info()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\prompt_toolkit\output\win32.py", line 219, in get_win32_screen_buffer_info
    raise NoConsoleScreenBufferError
prompt_toolkit.output.win32.NoConsoleScreenBufferError: Found xterm-256color, while expecting a Windows console. Maybe try to run this program using "winpty" or run it in cmd.exe instead. Or otherwise, in case of Cygwin, use the Python executable that is compiled for Cygwin.

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.5s)

_Thinking:_

**Inspecting elevation bypass options**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\commands\\project.py",
  "offset": 1,
  "limit": 240
}
```
**Output:**
```
<file>
00002| 
00003| import sys
00004| from datetime import datetime
00005| from pathlib import Path
00006| 
00007| import click
00008| import questionary
00009| from rich.console import Console
00010| from rich.table import Table
00011| 
00012| from sspec import __version__
00013| from sspec.core import (
00014|     SCHEMA_VERSION,
00015|     ChangeStatus,
00016|     SspecNotFoundError,
00017|     get_sspec_root,
00018|     get_template_dir,
00019|     list_template_skills,
00020| )
00021| from sspec.services.agents_service import update_root_agents_block
00022| from sspec.services.change_service import list_changes
00023| from sspec.services.meta_service import load_meta, save_meta
00024| from sspec.services.project_init_service import (
00025|     ProjectAlreadyInitializedError,
00026|     initialize_project,
00027|     sync_skill_locations,
00028| )
00029| from sspec.services.project_update_service import (
00030|     apply_skill_update,
00031|     collect_orphaned_skills,
00032|     collect_update_candidates,
00033|     migrate_legacy_skill_layouts,
00034|     remove_orphaned_skill,
00035| )
00036| 
00037| console = Console()
00038| 
00039| 
00040| def _interactive_skill_selection(project_root: Path) -> list[str]:
00041|     """Interactive skill location selection.
00042| 
00043|     Detects existing workspace directories and prompts user to select skill
00044|     installation locations.
00045|     """
00046|     available_locations = ['.claude', '.github', '.agent']
00047|     existing_dirs = [loc for loc in available_locations if (project_root / loc).is_dir()]
00048| 
00049|     console.print()
00050|     console.print('[bold cyan]Skill Installation Location Selection[/bold cyan]')
00051|     console.print()
00052| 
00053|     choices = [
00054|         questionary.Choice(
00055|             title=f"{loc} {' (existing)' if loc in existing_dirs else ''}",
00056|             value=loc,
00057|             checked=loc in existing_dirs,
00058|         )
00059|         for loc in available_locations
00060|     ]
00061| 
00062|     selected = questionary.checkbox(
00063|         'Select skill installation locations:',
00064|         choices=choices,
00065|         instruction='(Use arrow keys, space to toggle, enter to confirm)',
00066|     ).ask()
00067| 
00068|     if selected is None:  # User cancelled
00069|         forced = project_root / '.agent'
00070|         forced.mkdir(parents=True, exist_ok=True)
00071|         console.print('[yellow]Selection cancelled, force fallback to .agent[/yellow]')
00072|         console.print('[dim]You can switch to .claude/.github later by re-sync/update.[/dim]')
00073|         return ['.agent']
00074| 
00075|     if not selected:
00076|         forced = project_root / '.agent'
00077|         forced.mkdir(parents=True, exist_ok=True)
00078|         console.print('[yellow]No locations selected, force fallback to .agent[/yellow]')
00079|         console.print('[dim]You can switch to .claude/.github later by re-sync/update.[/dim]')
00080|         return ['.agent']
00081| 
00082|     return selected
00083| 
00084| 
00085| @click.group()
00086| def project() -> None:
00087|     """Project-level operations (init, status, update)."""
00088|     pass
00089| 
00090| 
00091| @project.command()
00092| @click.option('--force', is_flag=True, help='Overwrite existing .sspec directory')
00093| @click.option(
00094|     '--skill-loc',
00095|     multiple=True,
00096|     type=click.Choice(['.claude', '.github', '.agent'], case_sensitive=False),
00097|     help='Skill installation locations (can specify multiple, or use interactive mode)',
00098| )
00099| def init(force: bool, skill_loc: tuple[str, ...]) -> None:
00100|     """Initialize .sspec directory in current project."""
00101|     project_root = Path.cwd()
00102| 
00103|     try:
00104|         result = initialize_project(
00105|             project_root=project_root,
00106|             force=force,
00107|             skill_locations=[],
00108|             prefer_symlink=True,
00109|         )
00110|     except ProjectAlreadyInitializedError as e:
00111|         raise click.ClickException(
00112|             f"{e} Or run 'sspec project update' to update templates."
00113|         ) from None
00114| 
00115|     rel_path = result.sspec_path.relative_to(Path.cwd())
00116| 
00117|     console.print()
00118|     console.print(f'[green]+[/green] Initialized sspec project in {rel_path}/')
00119|     console.print('  [green]+[/green] Installed core skills to .sspec/skills/ (copy)')
00120| 
00121|     if result.created_or_updated_agents:
00122|         console.print('  [green]+[/green] Created/Updated root AGENTS.md')
00123| 
00124|     # Resolve requested external locations after core init
00125|     skill_locations = list(skill_loc) if skill_loc else _interactive_skill_selection(project_root)
00126|     allow_elevation = True
00127|     prefer_junction_on_windows = False
00128| 
00129|     if skill_locations and sys.platform == 'win32':
00130|         elevated_choice = questionary.confirm(
00131|             'Try admin elevation to create symbolic links on Windows?',
00132|             default=False,
00133|         ).ask()
00134|         if not elevated_choice:
00135|             allow_elevation = False
00136|             prefer_junction_on_windows = True
00137| 
00138|     if skill_locations:
00139|         sync_result = sync_skill_locations(
00140|             project_root=project_root,
00141|             locations=skill_locations,
00142|             prefer_symlink=True,
00143|             allow_elevation=allow_elevation,
00144|             prefer_junction_on_windows=prefer_junction_on_windows,
00145|         )
00146| 
00147|         for target_dir in sync_result.skill_targets:
00148|             if not target_dir.exists():
00149|                 continue
00150|             rel_target = target_dir.relative_to(project_root)
00151|             location_key = rel_target.as_posix()
00152|             strategy = sync_result.skill_install_strategies.get(location_key, 'copy')
00153|             console.print(f'  [green]+[/green] Synced skills to {rel_target}/ ({strategy})')
00154| 
00155|     console.print()
00156|     console.print('[cyan]Structure:[/cyan]')
00157|     console.print('  .sspec/')
00158|     console.print('  ├── project.md      # Project overview')
00159|     console.print('  ├── spec-docs/      # Project-level specification documents')
00160|     console.print('  ├── changes/        # Active change proposals')
00161|     console.print('  └── requests/       # Ad-hoc AI requests')
00162|     console.print()
00163|     console.print('[yellow]Next:[/yellow]')
00164|     console.print('  1. Edit .sspec/project.md (project context)')
00165|     console.print('  2. Create a change: sspec change new <name>')
00166|     console.print('  3. Check status: sspec project status')
00167| 
00168| 
00169| @project.command()
00170| def status() -> None:
00171|     """Show project overview and status."""
00172|     try:
00173|         sspec_root = get_sspec_root()
00174|     except SspecNotFoundError:
00175|         raise click.ClickException("Not a sspec project. Run 'sspec project init' first.") from None
00176| 
00177|     _show_overview(sspec_root)
00178| 
00179| 
00180| def _show_overview(sspec_root: Path) -> None:
00181|     """Show project overview."""
00182|     changes = list_changes(sspec_root)
00183|     active = [c for c in changes if not c.archived]
00184| 
00185|     console.print()
00186|     console.print('[bold]sspec Status[/bold]')
00187|     console.print()
00188| 
00189|     if not active:
00190|         console.print('[dim]No active changes[/dim]')
00191|     else:
00192|         for change in active:
00193|             # status = change.get('status', '')
00194|             status = change.status or ''
00195|             status_icon = _get_status_icon(status)
00196|             # name = change['name']
00197|             name = change.name
00198| 
00199|             console.print(
00200|                 f'{status_icon} [bold]{name}[/bold] ' f'[{_get_status_color(status)}]{status}[/]'
00201|             )
00202| 
00203|             # if change.get('description'):
00204|             #     console.print(f'  [dim]{change["description"]}[/dim]')
00205|             console.print(f'  [dim]{change.description}[/dim]')
00206|             console.print()
00207| 
00208|     console.print(f'[dim]{len(active)} active, {len(changes) - len(active)} archived[/dim]')
00209|     console.print()
00210| 
00211| 
00212| def _get_status_icon(status: str) -> str:
00213|     """Get icon for status."""
00214|     icons = {
00215|         ChangeStatus.PLANNING.value: '📝',
00216|         ChangeStatus.DOING.value: '🔄',
00217|         ChangeStatus.BLOCKED.value: '🚧',
00218|         ChangeStatus.REVIEW.value: '👀',
00219|         ChangeStatus.DONE.value: '✅',
00220|     }
00221|     return icons.get(status, '•')
00222| 
00223| 
00224| def _get_status_color(status: str) -> str:
00225|     """Get color for status."""
00226|     colors = {
00227|         ChangeStatus.PLANNING.value: 'yellow',
00228|         ChangeStatus.DOING.value: 'cyan',
00229|         ChangeStatus.BLOCKED.value: 'red',
00230|         ChangeStatus.REVIEW.value: 'magenta',
00231|         ChangeStatus.DONE.value: 'green',
00232|     }
00233|     return colors.get(status, 'white')
00234| 
00235| 
00236| @project.command()
00237| @click.option('--dry-run', is_flag=True, help='Show what would be updated without making changes')
00238| @click.option('--force', is_flag=True, help='Force update even if files were modified')
00239| @click.option('--interactive', '-i', is_flag=True, help='Prompt for each file')
00240| def update(dry_run: bool, force: bool, interactive: bool) -> None:
00241|     """Update project templates while preserving user changes."""

(File has more lines. Use 'offset' parameter to read beyond line 241)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 15.5s)

_Thinking:_

**Bypassing interactive prompts in initialization**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run python -c \"from pathlib import Path; from sspec.services.project_init_service import initialize_project; initialize_project(project_root=Path('.'), force=True, skill_locations=[], prefer_symlink=True); print('ok')\"",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Initializes project through service without interactive prompts"
}
```
**Output:**
```
ok

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.3s)

_Thinking:_

**Verifying generated change files**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run sspec change new test-frontmatter",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Creates change to validate generated spec template"
}
```
**Output:**
```
Traceback (most recent call last):
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 196, in _run_module_as_main
    return _run_code(code, main_globals, None,
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 86, in _run_code
    exec(code, run_globals)
  File "H:\SrcCode\playground\sspec\.venv\Scripts\sspec.exe\__main__.py", line 10, in <module>
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1485, in __call__
    return self.main(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1406, in main
    rv = self.invoke(ctx)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1269, in invoke
    return ctx.invoke(self.callback, **ctx.params)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 824, in invoke
    return callback(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\src\sspec\commands\change.py", line 202, in new
    console.print(
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\console.py", line 1697, in print
    with self:
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\console.py", line 870, in __exit__
    self._exit_buffer()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\console.py", line 826, in _exit_buffer
    self._check_buffer()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\console.py", line 2038, in _check_buffer
    self._write_buffer()
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\console.py", line 2074, in _write_buffer
    legacy_windows_render(buffer, LegacyWindowsTerm(self.file))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\_windows_renderer.py", line 17, in legacy_windows_render
    term.write_styled(text, style)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\_win32_console.py", line 441, in write_styled
    self.write_text(text)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\rich\_win32_console.py", line 402, in write_text
    self.write(text)
UnicodeEncodeError: 'gbk' codec can't encode character '\u2713' in position 0: illegal multibyte sequence

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.3s)

_Thinking:_

**Setting UTF-8 encoding environment**

```
Tool: bash

**Input:**
```json
{
  "command": "PYTHONIOENCODING=utf-8 uv run sspec change new test-frontmatter",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Creates change with UTF-8 output encoding workaround"
}
```
**Output:**
```
Error: Change '26-02-25T00-00_test-frontmatter' already exists

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.1s)

_Thinking:_

**Creating root template test**

```
Tool: bash

**Input:**
```json
{
  "command": "PYTHONIOENCODING=utf-8 uv run sspec change new test-root-frontmatter --root",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Creates root change to validate root spec template"
}
```
**Output:**
```
✓ Created root change: 26-02-25T00-00_test-root-frontmatter

Files:
  .sspec\changes\26-02-25T00-00_test-root-frontmatter/
  ├── spec.md      # Proposal and context
  ├── tasks.md     # Executable tasks and progress
  ├── handover.md  # Session continuity (update every session!)
  └── reference/   # Use if need to keep auxiliary design/research files

Next:
  0. Read sspec-design skill for standards and best practices
  1. Read spec.md / tasks.md, follow templates format and @RULE Hints
  2. Fill spec.md/tasks.md, run `sspec ask create` for validation
  3. Update handover.md at end of each session (Consult sspec-handover skill)

```
```

---

## Assistant (Build · gpt-5.3-codex · 9.4s)

_Thinking:_

**Verifying generated files**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\AGENTS.md"
}
```
**Output:**
```
<file>
00001| <!-- SSPEC:START -->
00002| # .sspec Agent Protocol
00003| 
00004| SSPEC_SCHEMA::9.0
00005| 
00006| ## 0. Overview
00007| 
00008| SSPEC is a document-driven AI collaboration framework. All planning, tracking, and handover lives in `.sspec/`.
00009| 
00010| **Goal**: Any Agent resumes work within 30 seconds by reading `.sspec/` files.
00011| 
00012| ```
00013| .sspec/
00014| ├── project.md     # Identity, conventions, notes
00015| ├── spec-docs/     # Formal specs (architecture, APIs)
00016| ├── changes/<n>/   # spec.md | tasks.md | handover.md [+ reference/]
00017| ├── requests/      # User intent records
00018| ├── tmp/           # Informal drafts
00019| └── asks/          # Q&A decision records
00020| ```
00021| 
00022| ---
00023| 
00024| ## 1. Agent Procedure
00025| 
00026| `read(project.md)` → classify → dispatch:
00027| 
00028| | Input | Action |
00029| |-------|--------|
00030| | Directive (`@resume`, `@handover`, etc.) | Execute → §5 Shortcuts |
00031| | Request (attached or described) | Assess scale → Change Workflow §2 |
00032| | Resume existing change | `read(handover→tasks→spec)` → continue from where left off |
00033| | Micro task (≤3 files, ≤30min, obvious) | Do directly, no change needed |
00034| 
00035| **Background rules** (always active):
00036| - Important discovery → write to `handover.md` immediately
00037| - Long session (>30 exchanges) → checkpoint `handover.md`
00038| - Uncertain → `@ask` (30s question < hours of rework)
00039| - User rejects tool call → STOP → `@ask` reason
00040| 
00041| ---
00042| 
00043| ## 2. Change Workflow
00044| 
00045| ### Development Lifecycle
00046| 
00047| Each phase has a dedicated SKILL. Read the SKILL before starting the phase.
00048| 
00049| ```
00050| Request ─→ research ─→ design ──→ plan ──→ implement ──→ review ──→ handover
00051|               │           │          │          │            │          │
00052|            understand   @ask       @ask      execute      @ask      persist
00053|            problem      align      approve   tasks       feedback   session
00054|            space        design     tasks                  loop      state
00055| ```
00056| 
00057| **Handover** is not just session-end cleanup — it's a lifecycle participant. Trigger it:
00058| - At session end (MANDATORY)
00059| - Mid-session when context is long (>30 exchanges)
00060| - When switching between major phases
00061| - Before any context-losing event (compression, interruption)
00062| 
00063| ### Phase → SKILL → Files
00064| 
00065| | Phase | SKILL | Reads | Writes | Checkpoint |
00066| |-------|-------|-------|--------|------------|
00067| | **Research** | `sspec-research` | code, project.md, spec-docs | reference/, handover.md | @ask "ready to design?" |
00068| | **Design** | `sspec-design` | research findings, code | spec.md (A+B) | **@ask align** (MANDATORY) |
00069| | **Plan** | `sspec-plan` | spec.md B | tasks.md | **@ask approve** (MANDATORY) |
00070| | **Implement** | `sspec-implement` | spec.md B, tasks.md | code, tasks.md progress | **@ask "done, please review"** |
00071| | **Review** | `sspec-review` | user feedback | tasks.md (feedback tasks) | @ask "satisfied?" |
00072| | **Handover** | `sspec-handover` | everything | handover.md, project.md | — |
00073| 
00074| **MANDATORY checkpoints**: Design and Plan phases MUST @ask user before proceeding. Never skip.
00075| 
00076| ### Scale Assessment (in Design phase)
00077| 
00078| | Scale | Criteria | Path |
00079| |-------|----------|------|
00080| | Micro | ≤3 files, ≤30min, trivially reversible | Do directly |
00081| | Single | ≤1 week, ≤15 files, ≤20 tasks | `sspec change new <name>` |
00082| | Multi | >1 week OR >15 files OR >20 tasks | `sspec change new <name> --root` → sub-changes |
00083| 
00084| ### Status Transitions
00085| 
00086| | From | Trigger | To |
00087| |------|---------|-----|
00088| | PLANNING | user approves design+plan | DOING |
00089| | DOING | all tasks `[x]` | REVIEW |
00090| | DOING | missing info | BLOCKED |
00091| | DOING | scope changed | PLANNING |
00092| | REVIEW | accepted | DONE |
00093| | REVIEW | needs changes | DOING |
00094| 
00095| **FORBIDDEN**: PLANNING→DONE, DOING→DONE — never skip REVIEW.
00096| 
00097| ---
00098| 
00099| ## 3. Consultation (@ask)
00100| 
00101| | Need persistent record? | Tool | Use when |
00102| |--------------------------|------|----------|
00103| | Yes | `sspec ask create` → fill → `sspec ask prompt` | Plan approval, architecture choice, direction decision |
00104| | No | Agent env question tool | Quick yes/no, session-end check |
00105| 
00106| Default to `sspec ask` when uncertain — a record beats no record.
00107| Long content → write to `.sspec/tmp/`, reference path in question body.
00108| 
00109| 📚 Full workflow, patterns, and content rules: `sspec-ask` SKILL
00110| 
00111| ---
00112| 
00113| ## 4. Spec-Docs
00114| 
00115| Spec-docs capture architecture knowledge that survives beyond any single change.
00116| 
00117| **When to create/update spec-docs**:
00118| - After a change produces architectural knowledge (new interfaces, data models, design patterns)
00119| - When the agent discovers knowledge too complex for `project.md` Notes
00120| - When user explicitly requests documentation
00121| 
00122| **Two scenarios**:
00123| 
00124| | Scenario | Trigger | Action |
00125| |----------|---------|--------|
00126| | Post-change update | Change is DONE, produced architectural knowledge | Agent proactively `@ask`: "Should I update/create spec-doc for X?" |
00127| | User-initiated | User requests spec-doc creation | If small → do directly; if large → may need its own change |
00128| 
00129| 📚 Full guidelines: `write-spec-doc` SKILL
00130| 
00131| ---
00132| 
00133| ## 5. Reference
00134| 
00135| ### Directive Shortcuts
00136| 
00137| | Shortcut | Equivalent | Procedure |
00138| |----------|-----------|-----------|
00139| | `@change <n>` | "Work on change N" | Load: `read(handover→tasks→spec)` → continue |
00140| | `@resume` | "Continue last work" | Same as `@change` for active change |
00141| | `@handover` | "Save and end" | Execute `sspec-handover` procedure |
00142| | `@sync` | "I coded without tracking" | Update tasks.md/handover.md to match reality |
00143| | `@argue` | "I disagree" | **STOP** → assess scope (§2 Review) |
00144| 
00145| ### CLI Quick Reference
00146| 
00147| Common `sspec` commands. Run `sspec <command> --help` for full options.
00148| 
00149| | Command | Purpose | Example |
00150| |---------|---------|---------|
00151| | `sspec change new <name>` | Create single change | `sspec change new fix-auth` |
00152| | `sspec change new <name> --root` | Create root (multi) change | `sspec change new refactor --root` |
00153| | `sspec change new --from <req>` | Create from request (auto-link) | `sspec change new --from .sspec/requests/...` |
00154| | `sspec change find <name>` | Fuzzy-find change dir | `sspec change find auth` |
00155| | `sspec change list` | List all active changes | |
00156| | `sspec change archive <path>` | Archive completed change | |
00157| | `sspec request list` | List requests | |
00158| | `sspec doc new "<name>"` | Create spec-doc | `sspec doc new "auth-design"` |
00159| | `sspec ask create <topic>` | Create ask file | `sspec ask create cache_approach` |
00160| | `sspec ask prompt <path>` | Collect user answer | Combo: create → edit → prompt |
00161| | `sspec ask list` | List asks | |
00162| | `sspec tool mdtoc <file>` | Pre-scan Markdown (headings + sizes) | |
00163| 
00164| ### Scope Quick Reference
00165| 
00166| | Scope | Location | Key Actions |
00167| |-------|----------|-------------|
00168| | Changes | `.sspec/changes/<n>/` | `new`, `find`, `list`, `archive` |
00169| | Requests | `.sspec/requests/` | `new`, `find`, `link` |
00170| | Spec-Docs | `.sspec/spec-docs/` | `new` |
00171| | Asks | `.sspec/asks/` | `create` → `prompt`, `list` |
00172| 
00173| ### SKILL System
00174| 
00175| Each SKILL is self-contained — read the one you need for the current phase, no chaining required.
00176| When a SKILL.md says "read [reference](./references/file.md)" → you **MUST** follow and read it.
00177| 
00178| | SKILL | When to Read |
00179| |-------|-------------|
00180| | `sspec-research` | Starting investigation of a problem |
00181| | `sspec-design` | Creating a change, filling spec.md |
00182| | `sspec-plan` | Breaking design into tasks |
00183| | `sspec-implement` | Executing tasks |
00184| | `sspec-review` | Handling user feedback |
00185| | `sspec-handover` | Saving session state (end-of-session or mid-session) |
00186| | `sspec-ask` | Consulting user mid-work |
00187| | `sspec-mdtoc` | Pre-scanning large Markdown files |
00188| | `write-spec-doc` | Creating spec-docs |
00189| | `write-patch` | Patch-based code modifications |
00190| 
00191| ### Template Markers
00192| 
00193| | Marker | Meaning | Action |
00194| |--------|---------|--------|
00195| | `<!-- @RULE: ... -->` | Standards reminder | Read and follow. DO NOT delete |
00196| | `<!-- @REPLACE -->` | Anchor for first edit | Replace with content |
00197| | `[ ]` / `[x]` | Task todo / done | Update as work progresses |
00198| <!-- SSPEC:END -->

(End of file - total 198 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\skills\\sspec-design\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-design
00003| description: "Assess scale, create change, fill spec.md, align with user. Use after research when ready to define the solution."
00004| metadata:
00005|   author: frostime
00006|   version: 3.1.0
00007| ---
00008| 
00009| # SSPEC Design
00010| 
00011| Define the problem and design the solution. Create the change. **Align with user before planning.**
00012| 
00013| This is a **user-in-the-loop** phase — like review, the user must confirm your design before you proceed. Never auto-advance to planning.
00014| 
00015| ---
00016| 
00017| ## Workflow
00018| 
00019| ```
00020| 1. Assess scale → micro / single / multi
00021| 2. Create change (CLI)
00022| 3. Fill spec.md
00023| 4. @ask user for alignment (MANDATORY)
00024| ```
00025| 
00026| ## Step 1: Assess Scale
00027| 
00028| | Scale | Criteria | Action |
00029| |-------|----------|--------|
00030| | **Micro** | ≤3 files, ≤30min, no design decisions, trivially reversible | Do directly. No change needed. Track in request if useful. |
00031| | **Single** | ≤1 week, ≤15 files, one subsystem, ≤20 tasks | Standard change → Step 2 Single |
00032| | **Multi** | >1 week OR >15 files across subsystems OR >20 tasks OR high risk | Root change → Step 2 Root |
00033| 
00034| **Uncertain?** → `@ask` user about scope/splitting.
00035| 
00036| ## Step 2: Create Change
00037| 
00038| ### Single Path
00039| 
00040| ```bash
00041| sspec change new <name>                        # standalone
00042| sspec change new --from <request>              # from request (auto-link)
00043| sspec change new <name> --from <request>       # explicit name + request link
00044| ```
00045| 
00046| ### Root Path (Multi-Change)
00047| 
00048| ```bash
00049| sspec change new <name> --root                 # creates root coordinator
00050| sspec change new <name> --root --from <req>    # root from request
00051| ```
00052| 
00053| Root change creates a coordinator with different templates:
00054| - Root `spec.md`: Phase overview, not file-level detail
00055| - Root `tasks.md`: Milestones, not individual tasks
00056| 
00057| ## Step 2.5: Normalize spec.md Frontmatter (MANDATORY)
00058| 
00059| Use this schema exactly:
00060| 
00061| ```yaml
00062| ---
00063| name: <change-name>
00064| status: PLANNING
00065| type: ""
00066| change-type: single|sub|root
00067| created: <iso-timestamp>
00068| reference: null|[]
00069| ---
00070| ```
00071| 
00072| ### Sub-Change Must Link Root (Required)
00073| 
00074| ```yaml
00075| change-type: sub
00076| reference:
00077|   - source: "changes/<root-change-dir>"
00078|     type: "root-change"
00079|     note: "Phase <n>: <phase-name>"
00080| ```
00081| 
00082| ### Root Should Link Request + Sub-Changes (Bidirectional Tracking)
00083| 
00084| ```yaml
00085| change-type: root
00086| reference:
00087|   - source: "requests/<request-file>.md"
00088|     type: "request"
00089|   - source: "changes/<sub-change-dir>"
00090|     type: "sub-change"
00091|     note: "Phase <n>: <phase-name>"
00092| ```
00093| 
00094| Use workspace-relative paths without `./` prefix.
00095| 
00096| ## Step 3: Fill spec.md
00097| 
00098| ### What Users Care About Most
00099| 
00100| Users review designs for: **interfaces**, **data types**, **data flow**, and **logic flow**.
00101| Prioritize these in Section B. Abstract hand-waving ("we'll handle it later") erodes trust.
00102| 
00103| ### Single Change
00104| 
00105| **Section A — Problem Statement**:
00106| - Quantify impact: "[metric] causing [impact]"
00107| - Simple changes: single paragraph
00108| - Complex changes: split "Current Situation" + "User Requirement"
00109| 
00110| | ❌ Bad | ✅ Good |
00111| |--------|---------|
00112| | "Need to refactor" | "Auth takes 5s → 12% conversion drop" |
00113| | "Improve the UI" | "Form completion rate 23% → target 60%" |
00114| 
00115| **Section B — Proposed Solution**:
00116| 
00117| `### Approach`: Core idea (1-3 paragraphs) + why this over alternatives.
00118| 
00119| `### Key Design`: Scale by complexity:
00120| 
00121| | Complexity | Design Depth |
00122| |------------|-------------|
00123| | Simple (≤5 files) | Inline in Approach, brief mention |
00124| | Medium (5-15 files) | Sub-sections: `### Interface Design`, `### Data Model`, `### Key Logic` |
00125| | Complex (>15 files) | Detailed design in `reference/design.md`, link from B |
00126| 
00127| **What MUST appear in B** (by priority):
00128| 1. **Interfaces** — function signatures, API contracts, class interfaces
00129| 2. **Data types** — models, schemas, type definitions
00130| 3. **Data flow** — how data moves through the system (input → transform → output)
00131| 4. **Logic flow** — key algorithms, decision trees, state machines
00132| 5. **Design rationale** — why this approach over alternatives
00133| 
00134| **What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).
00135| 
00136| ### Section B Example (Medium Complexity)
00137| 
00138| ```markdown
00139| ## B. Proposed Solution
00140| 
00141| ### Approach
00142| Add token refresh via middleware. Background refresh prevents expired tokens from blocking requests.
00143| 
00144| Why middleware: intercepting at HTTP layer avoids modifying every API call site.
00145| 
00146| ### Key Design
00147| 
00148| #### Interface
00149| - `TokenService.refresh(token: str) -> TokenPair`
00150| - `AuthMiddleware.intercept(request: Request) -> Request`
00151| - `TokenPair = TypedDict('TokenPair', {'access': str, 'refresh': str, 'expires_at': int})`
00152| 
00153| #### Data Flow
00154| ```
00155| Request → AuthMiddleware → check expiry
00156|   → if valid: pass through
00157|   → if expiring (<5min): background refresh + pass through
00158|   → if expired: block, refresh, retry with new token
00159| ```
00160| 
00161| #### Key Logic
00162| Refresh uses sliding window: if token expires within `REFRESH_WINDOW` (default 5min),
00163| trigger background refresh. Concurrent requests share one refresh via lock.
00164| ```
00165| 
00166| ### Root Change
00167| 
00168| **Section A**: Overall problem — full scope, not a single module.
00169| 
00170| **Section B**:
00171| - `### Overall Approach`: High-level strategy, delivery order
00172| - `### Phase Overview`: Each phase with goal, scope, dependencies
00173| 
00174| ```markdown
00175| - **Phase 1: Auth Backend** — JWT + Redis cache, goal: <1s auth response
00176| - **Phase 2: Auth Frontend** — Login/signup UI, depends on Phase 1
00177| - **Phase 3: Migration** — Migrate existing sessions, depends on Phase 1+2
00178| ```
00179| 
00180| After defining phases → create sub-changes:
00181| ```bash
00182| sspec change new <phase-name>    # for each phase, link to root via reference
00183| ```
00184| 
00185| For each sub-change, ensure two-way references:
00186| - Sub `spec.md` has `type: root-change` entry pointing to root
00187| - Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change
00188| 
00189| Each sub-change then goes through its own design → plan → implement → review cycle.
00190| 
00191| ## Step 4: @ask for Alignment (MANDATORY)
00192| 
00193| **Never skip this step.** This is a user-in-the-loop confirmation — like review phase, the user must sign off.
00194| 
00195| Present the design to user for confirmation:
00196| - Problem statement summary
00197| - Proposed approach and rationale
00198| - Key interfaces and data types
00199| - (Root) Phase breakdown
00200| 
00201| Wait for user approval before proceeding to `sspec-plan`.
00202| 
00203| After user confirms design, proceed to `sspec-plan`.
00204| Only after user also approves the task plan, transition status `PLANNING → DOING`.
00205| 

(End of file - total 205 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\skills\\sspec-plan\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-plan
00003| description: "Break design into concrete tasks. Fill tasks.md with file-level execution plan. Use after design alignment."
00004| metadata:
00005|   author: frostime
00006|   version: 2.1.0
00007| ---
00008| 
00009| # SSPEC Plan
00010| 
00011| Turn the approved design (spec.md B) into a concrete, file-level execution plan in tasks.md.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (approved design)
00019| 2. Break into phases + file-level tasks
00020| 3. Fill tasks.md
00021| 4. @ask user for final review
00022| ```
00023| 
00024| ## Task Standards
00025| 
00026| ### tasks.md Frontmatter (MANDATORY)
00027| 
00028| Single/sub change:
00029| 
00030| ```yaml
00031| ---
00032| change: "<change-name>"
00033| updated: ""
00034| ---
00035| ```
00036| 
00037| Root change:
00038| 
00039| ```yaml
00040| ---
00041| change: "<change-name>"
00042| change-type: root
00043| updated: ""
00044| ---
00045| ```
00046| 
00047| Keep `change` exactly aligned with `spec.md` `name`.
00048| 
00049| ### Granularity
00050| 
00051| | Change Type | Task Level | Example |
00052| |-------------|-----------|---------|
00053| | Single / Sub | File-level, <2h each | `- [ ] Create src/auth/jwt.py — refresh_token()` |
00054| | Root | Milestone-level (one per sub-change) | `- [ ] Phase 1 sub-change completed` |
00055| 
00056| Each task should be:
00057| - **Independently testable** — can verify without completing other tasks
00058| - **Specific** — mentions exact file path and what to do
00059| - **Small** — <2 hours of work
00060| 
00061| ### Phase Structure
00062| 
00063| ```markdown
00064| ### Phase 1: <name> ⏳
00065| - [ ] Task description `path/file.py`
00066| - [ ] Task description `path/file.py`
00067| **Verification**: <how to verify this phase>
00068| 
00069| ### Phase 2: <name> ⏳
00070| - [ ] Task description `path/file.py`
00071| **Verification**: <how to verify>
00072| ```
00073| 
00074| ### Phase Emoji
00075| 
00076| | Emoji | Meaning |
00077| |-------|---------|
00078| | ⏳ | Pending — not started |
00079| | 🚧 | In progress — actively working |
00080| | ✅ | Done — all tasks complete and verified |
00081| 
00082| ### Verification
00083| 
00084| Each phase MUST have explicit verification criteria:
00085| - What to check (test commands, expected output, manual verification)
00086| - How to know it's done (not "it works" but specific criteria)
00087| 
00088| ## Reference Section B, Don't Repeat
00089| 
00090| tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.
00091| 
00092| - ✅ "Implement Tool Interface per spec.md B"
00093| - ✅ "Create handler following the data flow in spec.md B"
00094| - ❌ Re-listing all function signatures
00095| - ❌ Re-describing the algorithm
00096| 
00097| ## Root Change Planning
00098| 
00099| For root changes, tasks.md contains milestones, not file-level tasks:
00100| 
00101| ```markdown
00102| ### Phase 1: Auth Backend ⏳
00103| - [ ] Sub-change created and linked
00104| - [ ] Sub-change completed and archived
00105| **Deliverable**: JWT auth with <1s response time
00106| **Sub-change**: (link when created)
00107| ```
00108| 
00109| The active sub-change gets its own tasks.md with file-level detail.
00110| 
00111| ## Progress Tracking
00112| 
00113| Update the Progress section after filling tasks:
00114| 
00115| ```markdown
00116| ## Progress
00117| 
00118| **Overall**: 0%
00119| 
00120| | Phase | Progress | Status |
00121| |-------|----------|--------|
00122| | Phase 1 | 0% | ⏳ |
00123| | Phase 2 | 0% | ⏳ |
00124| ```
00125| 
00126| ## Exit: @ask User Review (MANDATORY)
00127| 
00128| Present the task breakdown to user:
00129| - Number of phases and total tasks
00130| - Key verification criteria
00131| - Estimated scope
00132| 
00133| Wait for user approval before starting `sspec-implement`.
00134| 

(End of file - total 134 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\skills\\sspec-handover\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-handover
00003| description: "Save session state. Update handover.md, project.md, and spec-docs index. MANDATORY at session end, recommended mid-session."
00004| metadata:
00005|   author: frostime
00006|   version: 3.1.0
00007| ---
00008| 
00009| # SSPEC Handover
00010| 
00011| Persist session knowledge so any agent can resume within 30 seconds.
00012| 
00013| **Handover is a lifecycle participant, not just cleanup.** It preserves context across sessions, context compressions, and agent switches.
00014| 
00015| ---
00016| 
00017| ## When to Trigger
00018| 
00019| ### End of Session (MANDATORY)
00020| 
00021| Before ending ANY session, perform the full procedure below. No exceptions.
00022| 
00023| ### Mid-Session (Proactive)
00024| 
00025| Update handover.md Working Memory when:
00026| - Session is long (>30 exchanges or complex multi-file work)
00027| - Important decision just made with non-trivial reasoning
00028| - Key file discovered that future work depends on
00029| - Design tradeoff resolved after discussion
00030| - About to switch between major phases (e.g. design → plan)
00031| 
00032| **Rule**: If you'd struggle to reconstruct info after context compression → write it NOW.
00033| 
00034| ## Procedure
00035| 
00036| ### 1. Update handover.md
00037| 
00038| **This Session → Accomplished**: List specific work done (not "made progress").
00039| **This Session → Next Steps**: 1-3 specific file-level actions for next agent.
00040| 
00041| **Working Memory**:
00042| - **Key Files**: All critical file paths listed?
00043| - **Decisions**: Non-obvious choices captured with reasoning?
00044| - **Notes**: Edge cases, gotchas, risks recorded?
00045| 
00046| ### 2. Sync tasks.md
00047| 
00048| Verify tasks.md progress percentage matches reality. All completed tasks marked `[x]`.
00049| 
00050| ### 3. Promote to project.md (if applicable)
00051| 
00052| Two promotion targets:
00053| 
00054| **Notes section**: If any discovery applies beyond this change → append with date.
00055| - Format: `- YYYY-MM-DD: <learning>`
00056| 
00057| **Spec-Docs Index section**: If spec-docs were created or updated during this session → update the index.
00058| - Format: `- [name](spec-docs/<file>) — one-line description`
00059| 
00060| ### 4. Suggest spec-doc update (if applicable)
00061| 
00062| If the change produced architectural knowledge (new interfaces, data models, patterns):
00063| - `@ask` user: "This change produced knowledge about X. Should I create/update a spec-doc?"
00064| - If yes → use `write-spec-doc` SKILL
00065| 
00066| ### 5. Quick Quality Check
00067| 
00068| | Test | Pass? |
00069| |------|-------|
00070| | New agent reads only handover.md — can resume in <30s? | |
00071| | If context compressed right now — could you continue from handover.md alone? | |
00072| | For each major decision — can you find the "why" in handover? | |
00073| 
00074| If any test fails → update handover before ending.
00075| 
00076| ## handover.md Quality
00077| 
00078| **Thin** (simple change, ≤5 files): 3-5 bullet points across Working Memory sections.
00079| **Rich** (complex change, many decisions): Numbered items with sub-structure, evidence, tradeoff analysis.
00080| 
00081| Let content grow organically — don't pre-structure sections you don't need yet.
00082| 
00083| ### Anti-Patterns
00084| 
00085| | Bad | Good |
00086| |-----|------|
00087| | Skip handover at session end | ALWAYS handover — no exceptions |
00088| | Only update at session end | Update Working Memory DURING work |
00089| | Record decision without reasoning | Capture full chain: problem → alternatives → conclusion |
00090| | No file paths in Key Files | List files you'd need to re-find after compression |
00091| | Put architecture docs in project.md | project.md ≤10s scan; use spec-docs for detailed content |
00092| 

(End of file - total 92 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\skills\\sspec-implement\\SKILL.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: sspec-implement
00003| description: "Execute tasks from tasks.md. Implement code changes, update progress. Use after plan approval."
00004| metadata:
00005|   author: frostime
00006|   version: 2.1.0
00007| ---
00008| 
00009| # SSPEC Implement
00010| 
00011| Execute the approved plan. Work through tasks.md systematically.
00012| 
00013| ---
00014| 
00015| ## Workflow
00016| 
00017| ```
00018| 1. Read spec.md B (design context) + tasks.md (execution plan)
00019| 2. For each pending task: implement → verify → mark done
00020| 3. Update progress after EACH task
00021| 4. @ask user when all tasks complete
00022| ```
00023| 
00024| ## Execution Rules
00025| 
00026| ### Task Loop
00027| 
00028| For each pending task:
00029| 1. Announce which task you're working on
00030| 2. Make the code changes
00031| 3. Verify the change works
00032| 4. Mark task complete: `- [ ]` → `- [x]`
00033| 5. Update Progress section
00034| 6. Continue to next task
00035| 
00036| **Update after EACH task** — not in batches.
00037| 
00038| ### When to Pause
00039| 
00040| | Situation | Action |
00041| |-----------|--------|
00042| | Task is ambiguous | → `@ask` for clarification |
00043| | Implementation reveals design issue | → Suggest returning to `sspec-design` |
00044| | Blocker encountered | → Record in `handover.md` Notes, `@ask` user |
00045| | Multiple valid approaches for a task | → Pick the simpler one, note in handover |
00046| | Design assumption was wrong | → `@ask` user: "Design says X but I found Y. Revise?" |
00047| 
00048| **Don't guess on blockers.** One `@ask` < one rework cycle.
00049| 
00050| ### Keep Changes Focused
00051| 
00052| - Only modify files relevant to the current task
00053| - Preserve existing code style, comments, and structure
00054| - Don't refactor unrelated code
00055| - If a task grows beyond scope → split it, add new tasks to tasks.md
00056| 
00057| ## Progress Updates
00058| 
00059| After completing each task, update the Progress section:
00060| 
00061| ```markdown
00062| **Overall**: 40%
00063| 
00064| | Phase | Progress | Status |
00065| |-------|----------|--------|
00066| | Phase 1 | 100% | ✅ |
00067| | Phase 2 | 25% | 🚧 |
00068| 
00069| **Recent**:
00070| - Completed: Create auth middleware `src/middleware/auth.py`
00071| - Completed: Add JWT validation `src/auth/jwt.py`
00072| ```
00073| 
00074| ## Handover During Implementation
00075| 
00076| For long implementation sessions (>30 exchanges or multi-file work):
00077| - Write key decisions to `handover.md` Working Memory → Decisions
00078| - Record discovered gotchas to → Notes
00079| - Update Key Files as you discover important files
00080| 
00081| **Test**: "Would I struggle to continue if context was compressed right now?" → Write to handover.
00082| 
00083| ## Exit: @ask User (MANDATORY)
00084| 
00085| When all tasks are complete:
00086| 
00087| 1. Update Progress to show 100%
00088| 2. Summarize what was implemented
00089| 3. `@ask` user: "Implementation complete. Please review. Any issues or feedback?"
00090| 
00091| → Transition to `sspec-review` phase.
00092| 

(End of file - total 92 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\changes\\26-02-25T00-00_test-frontmatter\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: test-frontmatter
00003| status: PLANNING
00004| type: ""
00005| change-type: single
00006| created: 2026-02-25T00:00:33
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: single | sub
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Sub-change MUST link root:
00016| reference:
00017|   - source: "changes/<root-change-dir>"
00018|     type: "root-change"
00019|     note: "Phase <n>: <phase-name>"
00020| 
00021| Single-change common reference:
00022| reference:
00023|   - source: "requests/<request-file>.md"
00024|     type: "request"
00025| -->
00026| 
00027| # test-frontmatter
00028| 
00029| ## A. Problem Statement
00030| <!-- @REPLACE -->
00031| 
00032| <!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
00033| Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->
00034| 
00035| ## B. Proposed Solution
00036| <!-- @REPLACE -->
00037| 
00038| ### Approach
00039| <!-- Core idea (1-3 paragraphs) + why this over alternatives -->
00040| 
00041| ### Key Design
00042| <!-- Interfaces, data models, key logic — scale by complexity:
00043| Simple (≤5 files): inline in Approach, brief mention
00044| Medium (5-15 files): dedicated sub-sections (### Interface, ### Data Model)
00045| Complex (>15 files): detailed design here or in reference/design.md -->
00046| 

(End of file - total 46 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\changes\\26-02-25T00-00_test-root-frontmatter\\spec.md"
}
```
**Output:**
```
<file>
00001| ---
00002| name: test-root-frontmatter
00003| status: PLANNING
00004| type: ""
00005| change-type: root
00006| created: 2026-02-25T00:00:51
00007| reference: null
00008| ---
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: root (coordinator for sub-changes)
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Root reference SHOULD include request + sub-changes:
00016| reference:
00017|   - source: "requests/<request-file>.md"
00018|     type: "request"
00019|   - source: "changes/<sub-change-dir>"
00020|     type: "sub-change"
00021|     note: "Phase <n>: <phase-name>"
00022| -->
00023| 
00024| # test-root-frontmatter
00025| 
00026| ## A. Problem Statement
00027| <!-- @REPLACE -->
00028| 
00029| <!-- @RULE: Overall impact. This is the root coordinator — describe the FULL scope. -->
00030| 
00031| ## B. Proposed Solution
00032| <!-- @REPLACE -->
00033| 
00034| ### Overall Approach
00035| <!-- High-level strategy. How will this be broken into phases? Delivery order? -->
00036| 
00037| ### Phase Overview
00038| <!-- @RULE: List phases with goals. Each phase becomes a sub-change.
00039| 
00040| Format:
00041| - **Phase 1: <name>** — goal, measurable deliverable, scope (subsystems/modules)
00042| - **Phase 2: <name>** — goal, measurable deliverable, dependencies on Phase 1
00043| 
00044| Coordination Notes:
00045| - Cross-phase dependencies, shared interfaces, integration points
00046| 
00047| When a sub-change is created, sync references in BOTH directions:
00048| - Root `spec.md` adds `type: sub-change` entry for the sub-change
00049| - Sub `spec.md` adds `type: root-change` entry back to this root -->
00050| 

(End of file - total 50 lines)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.9s)

_Thinking:_

**Fixing design file duplication**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/skills/sspec-design/SKILL.md\n@@\n For each sub-change, ensure two-way references:\n-- Sub `spec.md` has `type: root-change` entry pointing to root\n+- Sub `spec.md` has a `reference` item with `type: root-change` pointing to root\n - Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change\n@@\n-Wait for user approval before proceeding to `sspec-plan`.\n-\n After user confirms design, proceed to `sspec-plan`.\n Only after user also approves the task plan, transition status `PLANNING → DOING`.\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\skills\sspec-design\SKILL.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 23.2s)

_Thinking:_

**Refining root spec comment**

```
Tool: apply_patch

**Input:**
```json
{
  "patchText": "*** Begin Patch\n*** Update File: src/sspec/templates/change-root/spec.md\n@@\n-Root reference SHOULD include request + sub-changes:\n+Root reference rules:\n+- If created from a request, include a `type: request` entry.\n+- For every created sub-change, append one `type: sub-change` entry.\n+\n+Example:\n reference:\n   - source: \"requests/<request-file>.md\"\n     type: \"request\"\n   - source: \"changes/<sub-change-dir>\"\n     type: \"sub-change\"\n*** End Patch"
}
```
**Output:**
```
Success. Updated the following files:
M src\sspec\templates\change-root\spec.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 13.8s)

_Thinking:_

**Planning test regeneration and init rerun**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run python -c \"from pathlib import Path; from sspec.services.project_init_service import initialize_project; initialize_project(project_root=Path('.'), force=True, skill_locations=[], prefer_symlink=True); print('ok')\" && PYTHONIOENCODING=utf-8 uv run sspec change new test-frontmatter-2 && PYTHONIOENCODING=utf-8 uv run sspec change new test-root-frontmatter-2 --root",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Reinitialize and recreate sample changes for validation"
}
```
**Output:**
```
ok
✓ Created single change: 26-02-25T00-01_test-frontmatter-2

Files:
  .sspec\changes\26-02-25T00-01_test-frontmatter-2/
  ├── spec.md      # Proposal and context
  ├── tasks.md     # Executable tasks and progress
  ├── handover.md  # Session continuity (update every session!)
  └── reference/   # Use if need to keep auxiliary design/research files

Next:
  0. Read sspec-design skill for standards and best practices
  1. Read spec.md / tasks.md, follow templates format and @RULE Hints
  2. Fill spec.md/tasks.md, run `sspec ask create` for validation
  3. Update handover.md at end of each session (Consult sspec-handover skill)
✓ Created root change: 26-02-25T00-01_test-root-frontmatter-2

Files:
  .sspec\changes\26-02-25T00-01_test-root-frontmatter-2/
  ├── spec.md      # Proposal and context
  ├── tasks.md     # Executable tasks and progress
  ├── handover.md  # Session continuity (update every session!)
  └── reference/   # Use if need to keep auxiliary design/research files

Next:
  0. Read sspec-design skill for standards and best practices
  1. Read spec.md / tasks.md, follow templates format and @RULE Hints
  2. Fill spec.md/tasks.md, run `sspec ask create` for validation
  3. Update handover.md at end of each session (Consult sspec-handover skill)

```
```

---

## Assistant (Build · gpt-5.3-codex · 6.8s)

_Thinking:_

**Verifying changes with minimal reads**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\skills\\sspec-design\\SKILL.md",
  "offset": 176,
  "limit": 40
}
```
**Output:**
```
<file>
00177| - **Phase 3: Migration** — Migrate existing sessions, depends on Phase 1+2
00178| ```
00179| 
00180| After defining phases → create sub-changes:
00181| ```bash
00182| sspec change new <phase-name>    # for each phase, link to root via reference
00183| ```
00184| 
00185| For each sub-change, ensure two-way references:
00186| - Sub `spec.md` has a `reference` item with `type: root-change` pointing to root
00187| - Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change
00188| 
00189| Each sub-change then goes through its own design → plan → implement → review cycle.
00190| 
00191| ## Step 4: @ask for Alignment (MANDATORY)
00192| 
00193| **Never skip this step.** This is a user-in-the-loop confirmation — like review phase, the user must sign off.
00194| 
00195| Present the design to user for confirmation:
00196| - Problem statement summary
00197| - Proposed approach and rationale
00198| - Key interfaces and data types
00199| - (Root) Phase breakdown
00200| 
00201| After user confirms design, proceed to `sspec-plan`.
00202| Only after user also approves the task plan, transition status `PLANNING → DOING`.
00203| 

(End of file - total 203 lines)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\changes\\26-02-25T00-01_test-root-frontmatter-2\\spec.md",
  "offset": 8,
  "limit": 24
}
```
**Output:**
```
<file>
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: root (coordinator for sub-changes)
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Root reference rules:
00016| - If created from a request, include a `type: request` entry.
00017| - For every created sub-change, append one `type: sub-change` entry.
00018| 
00019| Example:
00020| reference:
00021|   - source: "requests/<request-file>.md"
00022|     type: "request"
00023|   - source: "changes/<sub-change-dir>"
00024|     type: "sub-change"
00025|     note: "Phase <n>: <phase-name>"
00026| -->
00027| 
00028| # test-root-frontmatter-2
00029| 
00030| ## A. Problem Statement
00031| <!-- @REPLACE -->
00032| 

(File has more lines. Use 'offset' parameter to read beyond line 32)
</file>
```
```

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224\\.sspec\\changes\\26-02-25T00-01_test-frontmatter-2\\spec.md",
  "offset": 8,
  "limit": 22
}
```
**Output:**
```
<file>
00009| 
00010| <!-- @RULE: Frontmatter
00011| status: PLANNING | DOING | REVIEW | DONE | BLOCKED
00012| change-type: single | sub
00013| reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
00014| 
00015| Sub-change MUST link root:
00016| reference:
00017|   - source: "changes/<root-change-dir>"
00018|     type: "root-change"
00019|     note: "Phase <n>: <phase-name>"
00020| 
00021| Single-change common reference:
00022| reference:
00023|   - source: "requests/<request-file>.md"
00024|     type: "request"
00025| -->
00026| 
00027| # test-frontmatter-2
00028| 
00029| ## A. Problem Statement
00030| <!-- @REPLACE -->

(File has more lines. Use 'offset' parameter to read beyond line 30)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 4.6s)

_Thinking:_

**Planning to verify modified files**

```
Tool: bash

**Input:**
```json
{
  "command": "git status --short",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Shows current modified files"
}
```
**Output:**
```
 M src/sspec/templates/AGENTS.md
 M src/sspec/templates/change-root/spec.md
 M src/sspec/templates/change/spec.md
 M src/sspec/templates/skills/sspec-design/SKILL.md
 M src/sspec/templates/skills/sspec-handover/SKILL.md
 M src/sspec/templates/skills/sspec-implement/SKILL.md
 M src/sspec/templates/skills/sspec-plan/SKILL.md

```
```

---

## Assistant (Build · gpt-5.3-codex · 10.6s)

_Thinking:_

**Running dry-run test update**

```
Tool: bash

**Input:**
```json
{
  "command": "PYTHONIOENCODING=utf-8 uv run sspec project update --dry-run",
  "workdir": "H:\\SrcCode\\playground\\sspec\\tmp\\test_template_tuning_20260224",
  "description": "Dry-runs project update to validate template update flow"
}
```
**Output:**
```

                        Update Status                        
┌────────────────────────────────────────┬─────────┬────────┐
│ File                                   │ Status  │ Action │
├────────────────────────────────────────┼─────────┼────────┤
│ .sspec\skills\sspec-ask\SKILL.md       │ current │ skip   │
│ .sspec\skills\sspec-design\SKILL.md    │ current │ skip   │
│ .sspec\skills\sspec-handover\SKILL.md  │ current │ skip   │
│ .sspec\skills\sspec-implement\SKILL.md │ current │ skip   │
│ .sspec\skills\sspec-mdtoc\SKILL.md     │ current │ skip   │
│ .sspec\skills\sspec-plan\SKILL.md      │ current │ skip   │
│ .sspec\skills\sspec-research\SKILL.md  │ current │ skip   │
│ .sspec\skills\sspec-review\SKILL.md    │ current │ skip   │
│ .sspec\skills\use-powershell\SKILL.md  │ current │ skip   │
│ .sspec\skills\write-patch\SKILL.md     │ current │ skip   │
│ .sspec\skills\write-spec-doc\SKILL.md  │ current │ skip   │
└────────────────────────────────────────┴─────────┴────────┘

+ All files are up to date

```
```

---

## Assistant (Build · gpt-5.3-codex · 13.3s)

_Thinking:_

**Assessing docs addition and recommendations**

```
Tool: bash

**Input:**
```json
{
  "command": "git diff -- src/sspec/templates/AGENTS.md src/sspec/templates/skills/sspec-design/SKILL.md src/sspec/templates/skills/sspec-plan/SKILL.md src/sspec/templates/skills/sspec-implement/SKILL.md src/sspec/templates/skills/sspec-handover/SKILL.md src/sspec/templates/change/spec.md src/sspec/templates/change-root/spec.md",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Shows final template adjustments for review"
}
```
**Output:**
```
warning: in the working copy of 'src/sspec/templates/AGENTS.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/change-root/spec.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/change/spec.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/skills/sspec-design/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/skills/sspec-handover/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/skills/sspec-implement/SKILL.md', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'src/sspec/templates/skills/sspec-plan/SKILL.md', LF will be replaced by CRLF the next time Git touches it
diff --git a/src/sspec/templates/AGENTS.md b/src/sspec/templates/AGENTS.md
index b3b0aba..d133922 100644
--- a/src/sspec/templates/AGENTS.md
+++ b/src/sspec/templates/AGENTS.md
@@ -34,7 +34,7 @@ SSPEC is a document-driven AI collaboration framework. All planning, tracking, a
 
 **Background rules** (always active):
 - Important discovery → write to `handover.md` immediately
-- Long session (>20 exchanges) → checkpoint `handover.md`
+- Long session (>30 exchanges) → checkpoint `handover.md`
 - Uncertain → `@ask` (30s question < hours of rework)
 - User rejects tool call → STOP → `@ask` reason
 
diff --git a/src/sspec/templates/change-root/spec.md b/src/sspec/templates/change-root/spec.md
index 4b751f1..3d939b8 100644
--- a/src/sspec/templates/change-root/spec.md
+++ b/src/sspec/templates/change-root/spec.md
@@ -11,6 +11,18 @@ reference: null
 status: PLANNING | DOING | REVIEW | DONE | BLOCKED
 change-type: root (coordinator for sub-changes)
 reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
+
+Root reference rules:
+- If created from a request, include a `type: request` entry.
+- For every created sub-change, append one `type: sub-change` entry.
+
+Example:
+reference:
+  - source: "requests/<request-file>.md"
+    type: "request"
+  - source: "changes/<sub-change-dir>"
+    type: "sub-change"
+    note: "Phase <n>: <phase-name>"
 -->
 
 # {{CHANGE_NAME}}
@@ -34,4 +46,8 @@ Format:
 - **Phase 2: <name>** — goal, measurable deliverable, dependencies on Phase 1
 
 Coordination Notes:
-- Cross-phase dependencies, shared interfaces, integration points -->
+- Cross-phase dependencies, shared interfaces, integration points
+
+When a sub-change is created, sync references in BOTH directions:
+- Root `spec.md` adds `type: sub-change` entry for the sub-change
+- Sub `spec.md` adds `type: root-change` entry back to this root -->
diff --git a/src/sspec/templates/change/spec.md b/src/sspec/templates/change/spec.md
index fb32de7..230f365 100644
--- a/src/sspec/templates/change/spec.md
+++ b/src/sspec/templates/change/spec.md
@@ -11,6 +11,17 @@ reference: null
 status: PLANNING | DOING | REVIEW | DONE | BLOCKED
 change-type: single | sub
 reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>
+
+Sub-change MUST link root:
+reference:
+  - source: "changes/<root-change-dir>"
+    type: "root-change"
+    note: "Phase <n>: <phase-name>"
+
+Single-change common reference:
+reference:
+  - source: "requests/<request-file>.md"
+    type: "request"
 -->
 
 # {{CHANGE_NAME}}
diff --git a/src/sspec/templates/skills/sspec-design/SKILL.md b/src/sspec/templates/skills/sspec-design/SKILL.md
index 30c0d28..ec0a10f 100644
--- a/src/sspec/templates/skills/sspec-design/SKILL.md
+++ b/src/sspec/templates/skills/sspec-design/SKILL.md
@@ -3,7 +3,7 @@ name: sspec-design
 description: "Assess scale, create change, fill spec.md, align with user. Use after research when ready to define the solution."
 metadata:
   author: frostime
-  version: 3.0.0
+  version: 3.1.0
 ---
 
 # SSPEC Design
@@ -54,6 +54,45 @@ Root change creates a coordinator with different templates:
 - Root `spec.md`: Phase overview, not file-level detail
 - Root `tasks.md`: Milestones, not individual tasks
 
+## Step 2.5: Normalize spec.md Frontmatter (MANDATORY)
+
+Use this schema exactly:
+
+```yaml
+---
+name: <change-name>
+status: PLANNING
+type: ""
+change-type: single|sub|root
+created: <iso-timestamp>
+reference: null|[]
+---
+```
+
+### Sub-Change Must Link Root (Required)
+
+```yaml
+change-type: sub
+reference:
+  - source: "changes/<root-change-dir>"
+    type: "root-change"
+    note: "Phase <n>: <phase-name>"
+```
+
+### Root Should Link Request + Sub-Changes (Bidirectional Tracking)
+
+```yaml
+change-type: root
+reference:
+  - source: "requests/<request-file>.md"
+    type: "request"
+  - source: "changes/<sub-change-dir>"
+    type: "sub-change"
+    note: "Phase <n>: <phase-name>"
+```
+
+Use workspace-relative paths without `./` prefix.
+
 ## Step 3: Fill spec.md
 
 ### What Users Care About Most
@@ -143,6 +182,10 @@ After defining phases → create sub-changes:
 sspec change new <phase-name>    # for each phase, link to root via reference
 ```
 
+For each sub-change, ensure two-way references:
+- Sub `spec.md` has a `reference` item with `type: root-change` pointing to root
+- Root `spec.md` appends a `type: sub-change` entry pointing to that sub-change
+
 Each sub-change then goes through its own design → plan → implement → review cycle.
 
 ## Step 4: @ask for Alignment (MANDATORY)
@@ -155,6 +198,5 @@ Present the design to user for confirmation:
 - Key interfaces and data types
 - (Root) Phase breakdown
 
-Wait for user approval before proceeding to `sspec-plan`.
-
-After user confirms → transition status `PLANNING → DOING` in spec.md frontmatter.
+After user confirms design, proceed to `sspec-plan`.
+Only after user also approves the task plan, transition status `PLANNING → DOING`.
diff --git a/src/sspec/templates/skills/sspec-handover/SKILL.md b/src/sspec/templates/skills/sspec-handover/SKILL.md
index 398da49..786ffdb 100644
--- a/src/sspec/templates/skills/sspec-handover/SKILL.md
+++ b/src/sspec/templates/skills/sspec-handover/SKILL.md
@@ -3,7 +3,7 @@ name: sspec-handover
 description: "Save session state. Update handover.md, project.md, and spec-docs index. MANDATORY at session end, recommended mid-session."
 metadata:
   author: frostime
-  version: 3.0.0
+  version: 3.1.0
 ---
 
 # SSPEC Handover
@@ -23,7 +23,7 @@ Before ending ANY session, perform the full procedure below. No exceptions.
 ### Mid-Session (Proactive)
 
 Update handover.md Working Memory when:
-- Session is long (>50 exchanges or complex multi-file work)
+- Session is long (>30 exchanges or complex multi-file work)
 - Important decision just made with non-trivial reasoning
 - Key file discovered that future work depends on
 - Design tradeoff resolved after discussion
diff --git a/src/sspec/templates/skills/sspec-implement/SKILL.md b/src/sspec/templates/skills/sspec-implement/SKILL.md
index 13c0fef..3bd4fe6 100644
--- a/src/sspec/templates/skills/sspec-implement/SKILL.md
+++ b/src/sspec/templates/skills/sspec-implement/SKILL.md
@@ -3,7 +3,7 @@ name: sspec-implement
 description: "Execute tasks from tasks.md. Implement code changes, update progress. Use after plan approval."
 metadata:
   author: frostime
-  version: 2.0.0
+  version: 2.1.0
 ---
 
 # SSPEC Implement
@@ -73,7 +73,7 @@ After completing each task, update the Progress section:
 
 ## Handover During Implementation
 
-For long implementation sessions (>50 exchanges or multi-file work):
+For long implementation sessions (>30 exchanges or multi-file work):
 - Write key decisions to `handover.md` Working Memory → Decisions
 - Record discovered gotchas to → Notes
 - Update Key Files as you discover important files
diff --git a/src/sspec/templates/skills/sspec-plan/SKILL.md b/src/sspec/templates/skills/sspec-plan/SKILL.md
index 59caf0c..72605e9 100644
--- a/src/sspec/templates/skills/sspec-plan/SKILL.md
+++ b/src/sspec/templates/skills/sspec-plan/SKILL.md
@@ -3,7 +3,7 @@ name: sspec-plan
 description: "Break design into concrete tasks. Fill tasks.md with file-level execution plan. Use after design alignment."
 metadata:
   author: frostime
-  version: 2.0.0
+  version: 2.1.0
 ---
 
 # SSPEC Plan
@@ -23,6 +23,29 @@ Turn the approved design (spec.md B) into a concrete, file-level execution plan
 
 ## Task Standards
 
+### tasks.md Frontmatter (MANDATORY)
+
+Single/sub change:
+
+```yaml
+---
+change: "<change-name>"
+updated: ""
+---
+```
+
+Root change:
+
+```yaml
+---
+change: "<change-name>"
+change-type: root
+updated: ""
+---
+```
+
+Keep `change` exactly aligned with `spec.md` `name`.
+
 ### Granularity
 
 | Change Type | Task Level | Example |

```
```

---

## Assistant (Build · gpt-5.3-codex · 8.3s)

_Thinking:_

**Planning targeted test runs**

```
Tool: glob

**Input:**
```json
{
  "pattern": "tests/**/*.py",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\tests\test_project_init_skill_sync.py
H:\SrcCode\playground\sspec\tests\test_archive_linked_commands.py
H:\SrcCode\playground\sspec\tests\test_skill_dominate_service.py
H:\SrcCode\playground\sspec\tests\test_editor_service.py
H:\SrcCode\playground\sspec\tests\test_tmp_service.py
H:\SrcCode\playground\sspec\tests\test_config.py
H:\SrcCode\playground\sspec\tests\test_change_service.py
H:\SrcCode\playground\sspec\tests\test_request_service.py
H:\SrcCode\playground\sspec\tests\test_ask_service.py
H:\SrcCode\playground\sspec\tests\test_skill_installer.py
H:\SrcCode\playground\sspec\tests\test_project_update_service.py
H:\SrcCode\playground\sspec\tests\test_project_init_service.py
H:\SrcCode\playground\sspec\tests\test_core.py
H:\SrcCode\playground\sspec\tests\test_cmd_service.py
H:\SrcCode\playground\sspec\tests\test_meta_service.py
H:\SrcCode\playground\sspec\tests\test_agents_service.py
H:\SrcCode\playground\sspec\tests\test_hashing.py
H:\SrcCode\playground\sspec\tests\test_md_yaml.py
H:\SrcCode\playground\sspec\tests\__init__.py
H:\SrcCode\playground\sspec\tests\conftest.py
```
```

---

## Assistant (Build · gpt-5.3-codex · 9.1s)

_Thinking:_

**Running targeted service tests**

```
Tool: bash

**Input:**
```json
{
  "command": "uv run pytest tests/test_project_init_service.py tests/test_project_update_service.py tests/test_agents_service.py",
  "workdir": "H:\\SrcCode\\playground\\sspec",
  "description": "Runs template-related project and agents tests"
}
```
**Output:**
```
============================= test session starts =============================
platform win32 -- Python 3.10.0, pytest-9.0.2, pluggy-1.6.0
rootdir: H:\SrcCode\playground\sspec
configfile: pyproject.toml
collected 27 items

tests\test_project_init_service.py .............                         [ 48%]
tests\test_project_update_service.py ........                            [ 77%]
tests\test_agents_service.py ......                                      [100%]

============================= 27 passed in 1.22s ==============================

```
```

---

## Assistant (Build · gpt-5.3-codex · 30.7s)

_Thinking:_

**Summarizing changes and doc strategy**

已按你这 6 条决策把模板做了微调，重点是统一状态流、统一阈值、补强 frontmatter 和 root/sub 引用规范。

- 把长会话阈值统一为 `>30 exchanges`，见 `src/sspec/templates/AGENTS.md:37`、`src/sspec/templates/AGENTS.md:59`、`src/sspec/templates/skills/sspec-handover/SKILL.md:26`、`src/sspec/templates/skills/sspec-implement/SKILL.md:76`。
- 修复 Design 阶段状态冲突：改为“设计确认后进入 plan，计划也确认后再 `PLANNING → DOING`”，见 `src/sspec/templates/skills/sspec-design/SKILL.md:201`。
- 在 design skill 里新增 frontmatter 规范段，明确 single/sub/root 基础 schema 与用法，见 `src/sspec/templates/skills/sspec-design/SKILL.md:57`。
- 补充 root/sub 双向引用规则（含 YAML 示例），见 `src/sspec/templates/skills/sspec-design/SKILL.md:72`、`src/sspec/templates/skills/sspec-design/SKILL.md:185`。
- 在 change 模板中强化 frontmatter 注释：sub 必须挂 root，single 常见 request 引用，见 `src/sspec/templates/change/spec.md:10`。
- 在 root change 模板中写清“request + sub-change”维护规则和双向同步要求，见 `src/sspec/templates/change-root/spec.md:10`、`src/sspec/templates/change-root/spec.md:37`。
- 在 plan skill 增加 `tasks.md` frontmatter 规范化段，见 `src/sspec/templates/skills/sspec-plan/SKILL.md:26`。

我也做了验证：

- 重新安装：`uv pip install -e .`
- 用服务层非交互初始化模板（CLI 在当前终端会触发 questionary 控制台限制）
- 实际创建 single/root change 检查生成内容
- `uv run sspec project update --dry-run` 通过
- `uv run pytest tests/test_project_init_service.py tests/test_project_update_service.py tests/test_agents_service.py`，27/27 通过

关于你最后的问题：**9.0 能写出规范文档，但“复杂变更的一致性”仍比 8.0 更依赖 agent 水平**。  
我建议补“轻量参考”而不是回到旧版厚文档：

1. `sspec-design` 旁加一个 frontmatter + reference 的 quick examples（single/sub/root 各 1 个正例 + 1 个反例）
2. `sspec-plan` 旁加一个 tasks 质量清单（粒度、验证语句写法、完成定义）
3. 可选再加一个 root/sub 双向链接速查页（创建时和归档前各检查什么）

这样能保留 9.0 的简洁性，同时把你关心的“专业度下限”锁住。

---

## User

另一个问题：当前这个框架能不能用在比如编写文章这种非 coding 项目上？请你分析一下。

---

## Assistant (Build · gpt-5.3-codex · 30.6s)

_Thinking:_

**结论**

- 该框架以代码开发流程为核心，阶段明晰（设计、实现、测试、审查），适合编码任务；对非编写类项目需适度调整。
- 术语需重命名：例如“代码”“接口”“数据模型”替换为“信息源”“提纲”“论证结构”。
- 可新增写作相关技能标签，如“提纲设计”“初稿撰写”“编辑润色”“事实核查”等，以匹配写作流程。
- 完成标准由代码测试转为风格检查、原创性验证、事实准确度，符合写作质量要求。
- 架构上的变更管理应涵盖参考文献、资料清单等非代码文本（如`reference/sources.md`）。
- 保持项目根目录及子目录结构，方便写作材料和版本管理。
- 微任务目标调整为 ≤3节内容，时间控制在30分钟以内，更适合写作节奏。
- 项目说明应纳入发表指南、受众定位、语调要求，为写作过程提供全面支持。
- 直接应用风险包括：  
  - 框架默认偏向技术实现，可能导致生成过度技术化的产物；  
  - 审阅阶段假定有代码差异和测试，写作时需修改评审内容；  
  - 规格说明和稿件文档存在重复风险，可能增加不必要的流程复杂性；  
  - 状态管理与请求系统或引起写作流程的繁琐控制。
- 总体属于可迁移但非即插即用框架，适合有一定调整能力的写作团队。
- 可参考写作常见阶段（研究、设计、撰写、审校、交付）映射现有阶段，命令保持泛化。
- 建议制定轻量级适配方案，包含阶段、技能、完成标准的表格映射，降低迁移成本。

适配成本评估：中等。需人工调整术语、技能、完成判定和资料管理，才能自然融入写作场景。

| 原框架         | 写作适配               | 说明                           |
| -------------- | ---------------------- | ------------------------------ |
| 代码、接口     | 信息源、提纲、论证结构 | 术语系统整体替换               |
| 测试、实现     | 风格检查、事实核查     | 完成标准调整                   |
| 代码变更       | 文稿版本和引用管理     | 变更管理扩展至非代码文档       |
| 技能标签       | 写作相关定制技能       | 增加写作专业化操作             |
| 设计-实现-测试 | 研究-设计-撰写-审校   | 阶段通用化，适配写作生命周期   |

下一步可选方向：

- 制作适配示例模板，演示写作项目流程管理  
- 设计轻量化写作用命令集，简化指令复杂度  
- 针对写作阶段定义具体验收标准和产物格式

@ask 是否需要继续深入细化适配方案？

可以用，但**不是开箱即用**。

**结论**
- 这个框架本质是“变更驱动 + 持久记忆 + 人在环确认”，这些机制对写作项目同样有价值。
- 但当前模板和 SKILL 明显偏 `coding` 语义（代码、接口、测试、文件路径），直接套到文章项目会有“流程对了、语言不对”的摩擦。
- 所以它更像一个“通用 Agent 协作骨架”，需要一层“写作域适配”。

**为什么可迁移**
- `research → design → plan → implement → review → handover` 对应写作也成立：调研→立意→提纲→起草→审校→交接。
- `@ask` 的决策留痕对写作尤其好用（选题、受众、口吻、篇幅、发布日期）。
- `change/tasks/handover` 对多轮写作和多人接力非常友好。

**当前版本直接用于写作的主要问题**
- 术语偏代码：`interfaces/data model/logic flow`、`test commands`、`path/file.py` 示例会误导 Agent。
- 完成标准偏工程：容易强调“实现完成”，但写作需要“论证完整、事实可核、风格一致”。
- spec-doc 定位偏架构文档，和“文章素材库/风格手册”的映射还不直观。

**建议的最小适配（保留 9.0 主干）**
- 把 `sspec-design` 中 “Key Design” 改成写作版三要素：`Audience & Goal`、`Outline & Argument Flow`、`Evidence & Sources`。
- 给 `sspec-plan` 增加写作任务示例：资料收集、提纲、初稿、二稿、事实核查、终稿排版。
- 给 `sspec-review` 增加写作验收标准：结构、可读性、事实准确、语气一致、字数约束。
- 新增 2-3 个写作专用 SKILL（可不建 references）：`sspec-outline`、`sspec-draft`、`sspec-factcheck`。
- 在 `project.md` 里明确写作约束：目标读者、品牌语气、禁用表达、引用规范。

**是否值得做**
- 如果你希望 sspec 成为“泛 Agent 工作流框架”：值得，且改动不大（模板和 SKILL 文案为主）。
- 如果目标仍是“Agentic Coding 最优”：建议把写作适配做成可选 profile（如 `--profile writing`），避免污染 coding 默认体验。

---

## User

再问：请分析 @src\sspec\commands\ask.py  和相关的 @src\sspec\services\ask_service.py ；当前使用 *.py 文档然后翻译成 md 文件的做法是否合适？

---

## Assistant (Build · gpt-5.3-codex · 9.9s)

_Thinking:_

**Inspecting service tests for analysis**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\tests\\test_ask_service.py"
}
```
**Output:**
```
<file>
00001| """Tests for sspec.services.ask_service — ask creation, name normalization, conversion."""
00002| 
00003| from __future__ import annotations
00004| 
00005| import importlib.util
00006| from pathlib import Path
00007| 
00008| import pytest
00009| 
00010| from sspec.services.ask_service import (
00011|     archive_ask,
00012|     convert_ask_to_md,
00013|     create_ask_template,
00014|     execute_ask_prompt,
00015|     extract_ask_name_from_filename,
00016|     find_ask_matches,
00017|     normalize_ask_name,
00018|     save_ask_answer,
00019| )
00020| 
00021| # ---------------------------------------------------------------------------
00022| # normalize_ask_name
00023| # ---------------------------------------------------------------------------
00024| 
00025| 
00026| class TestNormalizeAskName:
00027|     def test_hyphens_to_underscores(self):
00028|         name, _ = normalize_ask_name('my-question')
00029|         assert name == 'my_question'
00030| 
00031|     def test_special_chars_removed(self):
00032|         name, _ = normalize_ask_name('what@about#this?')
00033|         assert name == 'what_about_this'
00034| 
00035|     def test_returns_warning_when_changed(self):
00036|         _, warning = normalize_ask_name('my-question')
00037|         assert warning is not None
00038|         assert 'converted' in warning.lower()
00039| 
00040|     def test_no_warning_when_unchanged(self):
00041|         _, warning = normalize_ask_name('already_ok')
00042|         assert warning is None
00043| 
00044|     def test_empty_name_raises(self):
00045|         with pytest.raises(ValueError):
00046|             normalize_ask_name('!!!')
00047| 
00048|     def test_collapses_underscores(self):
00049|         name, _ = normalize_ask_name('a---b___c')
00050|         assert '__' not in name
00051|         assert name == 'a_b_c'
00052| 
00053| 
00054| # ---------------------------------------------------------------------------
00055| # extract_ask_name_from_filename
00056| # ---------------------------------------------------------------------------
00057| 
00058| 
00059| class TestExtractAskName:
00060|     def test_timestamped_format(self):
00061|         assert extract_ask_name_from_filename('260101120000_my_question') == 'my_question'
00062| 
00063|     def test_plain_name(self):
00064|         assert extract_ask_name_from_filename('plain') == 'plain'
00065| 
00066| 
00067| # ---------------------------------------------------------------------------
00068| # create_ask_template
00069| # ---------------------------------------------------------------------------
00070| 
00071| 
00072| class TestCreateAskTemplate:
00073|     def test_creates_py_file(self, sspec_root: Path):
00074|         path, _ = create_ask_template(sspec_root, 'token-storage')
00075|         assert path.exists()
00076|         assert path.suffix == '.py'
00077| 
00078|     def test_template_content_structure(self, sspec_root: Path):
00079|         path, _ = create_ask_template(sspec_root, 'design-choice')
00080|         content = path.read_text(encoding='utf-8')
00081|         assert 'CREATED' in content
00082|         assert 'REASON' in content
00083|         assert 'QUESTION' in content
00084|         assert 'USER_ANSWER' in content
00085| 
00086|     def test_name_conversion_warning(self, sspec_root: Path):
00087|         _, warning = create_ask_template(sspec_root, 'my-question')
00088|         assert warning is not None
00089| 
00090|     def test_conflict_handling(self, sspec_root: Path):
00091|         p1, _ = create_ask_template(sspec_root, 'same-name')
00092|         p2, _ = create_ask_template(sspec_root, 'same-name')
00093|         assert p1 != p2
00094|         assert p2.exists()
00095| 
00096| 
00097| # ---------------------------------------------------------------------------
00098| # execute_ask_prompt with pre-filled answer
00099| # ---------------------------------------------------------------------------
00100| 
00101| 
00102| class TestExecuteAskPrompt:
00103|     def test_prefilled_answer_returned(self, sspec_root: Path):
00104|         path, _ = create_ask_template(sspec_root, 'prefilled')
00105|         # Modify the template to have a pre-filled answer
00106|         content = path.read_text(encoding='utf-8')
00107|         content = content.replace('USER_ANSWER = r""""""', 'USER_ANSWER = r"""Use Redis"""')
00108|         path.write_text(content, encoding='utf-8')
00109| 
00110|         answer = execute_ask_prompt(path)
00111|         assert answer == 'Use Redis'
00112| 
00113|     def test_missing_file_with_md_fallback(self, sspec_root: Path):
00114|         """If .py is missing but .md exists, return a warning message."""
00115|         asks_dir = sspec_root / 'asks'
00116|         py_path = asks_dir / 'completed.py'
00117|         md_path = asks_dir / 'completed.md'
00118|         md_path.write_text('---\nname: completed\n---\n', encoding='utf-8')
00119| 
00120|         result = execute_ask_prompt(py_path)
00121|         assert 'already completed' in result.lower() or 'Warning' in result
00122| 
00123|     def test_truly_missing_file_raises(self, sspec_root: Path):
00124|         with pytest.raises(FileNotFoundError):
00125|             execute_ask_prompt(sspec_root / 'asks' / 'nonexistent.py')
00126| 
00127| 
00128| # ---------------------------------------------------------------------------
00129| # save_ask_answer + convert_ask_to_md
00130| # ---------------------------------------------------------------------------
00131| 
00132| 
00133| class TestSaveAndConvert:
00134|     def test_save_appends_answer(self, sspec_root: Path):
00135|         path, _ = create_ask_template(sspec_root, 'save-test')
00136|         # Fill in QUESTION for the template to be valid
00137|         content = path.read_text(encoding='utf-8')
00138|         content = content.replace('<YOUR_QUESTION_HERE>', 'What DB to use?')
00139|         path.write_text(content, encoding='utf-8')
00140| 
00141|         save_ask_answer(path, 'PostgreSQL')
00142|         updated = path.read_text(encoding='utf-8')
00143|         assert 'ANSWER' in updated
00144|         assert 'PostgreSQL' in updated
00145| 
00146|     def test_convert_to_md(self, sspec_root: Path):
00147|         path, _ = create_ask_template(sspec_root, 'convert-test')
00148|         content = path.read_text(encoding='utf-8')
00149|         content = content.replace('<YOUR_QUESTION_HERE>', 'Which framework?')
00150|         content = content.replace('<brief_reason>', 'Need to decide')
00151|         path.write_text(content, encoding='utf-8')
00152|         save_ask_answer(path, 'FastAPI')
00153| 
00154|         md_path = convert_ask_to_md(path)
00155|         assert md_path.exists()
00156|         assert md_path.suffix == '.md'
00157|         assert not path.exists()  # .py should be deleted
00158| 
00159|         md_content = md_path.read_text(encoding='utf-8')
00160|         assert 'FastAPI' in md_content
00161|         assert 'Which framework?' in md_content
00162| 
00163| 
00164| # ---------------------------------------------------------------------------
00165| # find_ask_matches
00166| # ---------------------------------------------------------------------------
00167| 
00168| 
00169| class TestFindAskMatches:
00170|     def test_exact_match(self, sspec_root: Path):
00171|         asks_dir = sspec_root / 'asks'
00172|         f = asks_dir / 'my_question.md'
00173|         f.write_text('---\n---\n', encoding='utf-8')
00174|         assert f in find_ask_matches(asks_dir, 'my_question')
00175| 
00176|     def test_suffix_match(self, sspec_root: Path):
00177|         asks_dir = sspec_root / 'asks'
00178|         f = asks_dir / '260101120000_topic.md'
00179|         f.write_text('', encoding='utf-8')
00180|         assert f in find_ask_matches(asks_dir, 'topic')
00181| 
00182|     def test_strips_md_extension(self, sspec_root: Path):
00183|         asks_dir = sspec_root / 'asks'
00184|         f = asks_dir / 'q.md'
00185|         f.write_text('', encoding='utf-8')
00186|         assert f in find_ask_matches(asks_dir, 'q.md')
00187| 
00188|     def test_no_match(self, sspec_root: Path):
00189|         assert find_ask_matches(sspec_root / 'asks', 'nonexistent') == []
00190| 
00191| 
00192| # ---------------------------------------------------------------------------
00193| # archive_ask
00194| # ---------------------------------------------------------------------------
00195| 
00196| 
00197| class TestArchiveAsk:
00198|     def test_moves_to_archive(self, sspec_root: Path):
00199|         asks_dir = sspec_root / 'asks'
00200|         f = asks_dir / 'done.md'
00201|         f.write_text('completed ask', encoding='utf-8')
00202| 
00203|         dest = archive_ask(sspec_root, asks_dir, f)
00204|         assert dest.exists()
00205|         assert not f.exists()
00206|         assert 'archive' in str(dest)
00207| 
00208|     def test_conflict_resolution(self, sspec_root: Path):
00209|         asks_dir = sspec_root / 'asks'
00210|         archive_dir = asks_dir / 'archive'
00211|         archive_dir.mkdir(parents=True, exist_ok=True)
00212|         (archive_dir / 'dup.md').write_text('old', encoding='utf-8')
00213| 
00214|         f = asks_dir / 'dup.md'
00215|         f.write_text('new', encoding='utf-8')
00216|         dest = archive_ask(sspec_root, asks_dir, f)
00217|         assert dest.exists()
00218|         assert dest.name != 'dup.md'  # counter appended
00219| 
00220|     def test_updates_references_inside_archive_dirs(self, sspec_root: Path):
00221|         asks_dir = sspec_root / 'asks'
00222|         request_archive = sspec_root / 'requests' / 'archive'
00223|         change_archive = sspec_root / 'changes' / 'archive' / '26-02-15T00-00_demo'
00224|         request_archive.mkdir(parents=True, exist_ok=True)
00225|         change_archive.mkdir(parents=True, exist_ok=True)
00226| 
00227|         ask_file = asks_dir / 'topic.md'
00228|         ask_file.write_text('ask content', encoding='utf-8')
00229| 
00230|         old_path = '.sspec/asks/topic.md'
00231|         req_file = request_archive / 'r.md'
00232|         change_spec = change_archive / 'spec.md'
00233|         req_file.write_text(f'link: {old_path}\n', encoding='utf-8')
00234|         change_spec.write_text(f'link: {old_path}\n', encoding='utf-8')
00235| 
00236|         dest = archive_ask(sspec_root, asks_dir, ask_file)
00237|         new_path = dest.relative_to(sspec_root.parent).as_posix()
00238| 
00239|         assert new_path in req_file.read_text(encoding='utf-8')
00240|         assert new_path in change_spec.read_text(encoding='utf-8')
00241| 

(End of file - total 241 lines)
</file>
```
```

```
Tool: glob

**Input:**
```json
{
  "pattern": "tests/**/*ask*.py",
  "path": "H:\\SrcCode\\playground\\sspec"
}
```
**Output:**
```
H:\SrcCode\playground\sspec\tests\test_ask_service.py
```
```

---

## Assistant (Build · gpt-5.3-codex · 6.8s)

_Thinking:_

**Checking for existing command tests**

```
Tool: grep

**Input:**
```json
{
  "pattern": "ask prompt|ask create|ask archive|ask_group",
  "path": "H:\\SrcCode\\playground\\sspec\\tests",
  "include": "*.py"
}
```
**Output:**
```
No files found
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.2s)

_Thinking:_

**Inspecting answer parsing approach**

```
Tool: grep

**Input:**
```json
{
  "pattern": "User Answer|Agent Question History|why:|asks/.*\\.md|ask.*md",
  "path": "H:\\SrcCode\\playground\\sspec\\src",
  "include": "*.py"
}
```
**Output:**
```
Found 29 matches
H:\SrcCode\playground\sspec\src\sspec\commands\change.py:
  Line 209:     console.print('  ├── tasks.md     # Executable tasks and progress')
  Line 217:     console.print('  1. Read spec.md / tasks.md, follow templates format and @RULE Hints')
  Line 218:     console.print('  2. Fill spec.md/tasks.md, run `sspec ask create` for validation')
  Line 391:             if line.startswith('## ') and in_why:

H:\SrcCode\playground\sspec\src\sspec\core.py:
  Line 34: CHANGE_TEMPLATE_FILES = ['spec.md', 'tasks.md', 'handover.md']
  Line 35: CHANGE_ROOT_TEMPLATE_FILES: list[str] = ['spec.md', 'tasks.md', 'handover.md']

H:\SrcCode\playground\sspec\src\sspec\cli.py:
  Line 6: from sspec.commands import ask, change, cmd, doc, project, request, skill, tmp, tool

H:\SrcCode\playground\sspec\src\sspec\services\ask_service.py:
  Line 42:     exact_path = asks_dir / f'{normalized}.md'
  Line 46:     matches = list(asks_dir.glob(f'*_{normalized}.md'))
  Line 50:     contains = [p for p in asks_dir.glob('*.md') if normalized in p.stem]
  Line 58:     """Archive a completed ask (.md) by moving it into asks/archive/.
  Line 72:         dest_path = archive_dir / f'{ask_path.stem}_{counter}.md'
  Line 236:         md_file_path = ask_file_path.with_suffix('.md')
  Line 288: def convert_ask_to_md(py_path: Path) -> Path:
  Line 290:     Convert ask .py file to .md format and delete the .py file.
  Line 333:         '# User Answer #',
  Line 337:         '# Agent Question History #',

H:\SrcCode\playground\sspec\src\sspec\services\change_service.py:
  Line 83:     tasks_file = change_path / 'tasks.md'
  Line 111:         # See src/sspec/templates/change/tasks.md
  Line 133:     """Create a new change directory with spec.md, tasks.md, and handover.md.
  Line 302:     tasks_file = change_path / 'tasks.md'
  Line 308:             issues.append('tasks.md: No tasks defined (still template)')

H:\SrcCode\playground\sspec\src\sspec\commands\ask.py:
  Line 16:     convert_ask_to_md,
  Line 99:     """Execute ask prompt, collect answer, and convert to .md."""
  Line 105:         md_file = ask_file.with_suffix('.md')
  Line 118:         md_path = convert_ask_to_md(py_path=ask_file)
  Line 153:     completed_files = sorted(asks_dir.glob('*.md'))
  Line 235:     active = sorted(asks_dir.glob('*.md')) if asks_dir.exists() else []

H:\SrcCode\playground\sspec\src\sspec\builtin_tools\prompt.py:
  Line 434: sspec tool prompt -o .sspec/asks/new-feature.md
```
```

---

## Assistant (Build · gpt-5.3-codex · 9.8s)

_Thinking:_

**Inspecting command parsing for 'why' frontmatter**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\commands\\change.py",
  "offset": 340,
  "limit": 120
}
```
**Output:**
```
<file>
00341| # def status(name: str | None = None) -> None:
00342| #     """Show detailed status of a change."""
00343| #     try:
00344| #         sspec_root = get_sspec_root()
00345| #     except SspecNotFoundError:
00346| #         raise click.ClickException(
00347| #             "Not a sspec project. Run 'sspec project init' first."
00348| #         ) from None
00349| 
00350| #     if not name:
00351| #         _list_changes(sspec_root, include_all=False)
00352| #         return
00353| 
00354| #     # Fuzzy lookup
00355| #     changes_dir = sspec_root / 'changes'
00356| #     matches = find_change_matches(changes_dir, name)
00357| 
00358| #     if not matches:
00359| #         raise click.ClickException(f"Change '{name}' not found")
00360| 
00361| #     if len(matches) > 1:
00362| #         change_path = _interactive_select_change(matches, name)
00363| #     else:
00364| #         change_path = matches[0]
00365| 
00366| #     _show_change_detail(change_path)
00367| 
00368| 
00369| def _show_change_detail(change_path: Path) -> None:
00370|     """Show detailed status of a single change."""
00371|     from sspec.libs.md_yaml import parse_frontmatter
00372| 
00373|     change = parse_change(change_path)
00374| 
00375|     spec_file = change_path / 'spec.md'
00376|     summary = ''
00377|     status = 'PLANNING'
00378| 
00379|     if spec_file.exists():
00380|         content = spec_file.read_text(encoding='utf-8')
00381|         meta, body = parse_frontmatter(content)
00382|         status = meta.get('status', 'PLANNING')
00383|         in_why = False
00384|         for line in body.split('\n'):
00385|             if line.startswith('## A.'):
00386|                 in_why = True
00387|                 continue
00388|             if in_why and line.strip() and not line.startswith('<!--'):
00389|                 summary = line.strip()[:100]
00390|                 break
00391|             if line.startswith('## ') and in_why:
00392|                 break
00393| 
00394|     console.print()
00395|     console.print(
00396|         Panel(
00397|             f'[bold]{change.name}[/bold]\n'
00398|             f'Status: {change.status}\n'
00399|             f'Progress: {change.progress["done"]}/{change.progress["total"]}\n'
00400|             f'{summary}',
00401|             title='Change Details',
00402|         )
00403|     )
00404| 
00405|     if status == 'PLANNING':
00406|         console.print(
00407|             '\n[dim]Next: Fill spec.md sections A/B/C, then transition to DOING[/dim]'
00408|         )
00409|     elif status == 'DOING':
00410|         console.print(
00411|             "\n[dim]Next: Continue tasks. Run 'sspec change status' for progress[/dim]"
00412|         )
00413|     elif status == 'REVIEW':
00414|         console.print(
00415|             '\n[dim]Next: Awaiting user review. After approval → DONE → archive[/dim]'
00416|         )
00417| 
00418| 
00419| @change.command()
00420| @click.argument('query')
00421| def find(query: str) -> None:
00422|     """Find changes by name (fuzzy matching)."""
00423|     try:
00424|         sspec_root = get_sspec_root()
00425|     except SspecNotFoundError:
00426|         raise click.ClickException(
00427|             "Not a sspec project. Run 'sspec project init' first."
00428|         ) from None
00429| 
00430|     changes_dir = sspec_root / 'changes'
00431|     matches = find_change_matches(changes_dir, query, include_archived=True)
00432| 
00433|     if not matches:
00434|         console.print(f"[yellow]No changes found matching '{query}'[/yellow]")
00435|         return
00436| 
00437|     # Exact match check
00438|     # exact_match = next((m for m in matches if m.name.lower() == query.lower()), None)
00439| 
00440|     if len(matches) > 1:
00441|         console.print(f'[cyan]Found {len(matches)} matches for "{query}":[/cyan]\n')
00442|     else:
00443|         console.print(f'[cyan]Match for "{query}":[/cyan]\n')
00444| 
00445|     for match_path in matches:
00446|         is_archived = match_path.parent.name == ARCHIVE_DIR
00447|         change_info = parse_change(match_path, archived=is_archived)
00448|         _display_change(change_info, dim=is_archived, in_detail=True)
00449|         console.print()
00450| 
00451| 
00452| # ============================================================================
00453| # Subcommand: archive
00454| # ============================================================================
00455| 
00456| 
00457| @change.command()
00458| @click.argument('name', required=False)
00459| @click.option('--yes', '-y', is_flag=True, help='Skip confirmation')
00460| @click.option(

(File has more lines. Use 'offset' parameter to read beyond line 460)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 7.5s)

_Thinking:_

**Inspecting question format usage**

```
Tool: read

**Input:**
```json
{
  "filePath": "H:\\SrcCode\\playground\\sspec\\src\\sspec\\builtin_tools\\prompt.py",
  "offset": 380,
  "limit": 120
}
```
**Output:**
```
<file>
00381| # ============================================================================
00382| 
00383| TOOL_PROMPT = """# prompt - Interactive Command Editor
00384| 
00385| ## Purpose
00386| Edit multi-line text with file path auto-completion and command mode.
00387| 
00388| ## Usage
00389| 
00390| ### Basic
00391| ```bash
00392| # Output to stdout
00393| sspec tool prompt
00394| 
00395| # Save to file
00396| sspec tool prompt -o instruction.md
00397| ```
00398| 
00399| ### File Path Completion
00400| Type `@` to trigger file path completion:
00401| - `@src` → shows files matching "src"
00402| - `@util` → fuzzy matches files containing "util"
00403| - Use arrow keys to navigate, Tab/Enter to confirm
00404| 
00405| ### Command Mode
00406| Press **Esc** (alone) to open the bottom command line (Vim-like),
00407| then type a command and press Enter:
00408| 
00409| | Command | Description |
00410| |---------|-------------|
00411| | `/exit` | Finish editing and output text |
00412| | `/clear` | Clear the editing buffer |
00413| | `/output <path>` | Set/change output file path |
00414| | `/help` | Show available commands |
00415| 
00416| ### Keybindings
00417| - **Esc + Enter**: Submit editor content
00418| - **Esc** (alone): Open command line
00419| - **Enter** (in command line): Run command
00420| - **Ctrl+C**: Cancel
00421| 
00422| ### Options
00423| ```bash
00424| --output, -o PATH   Save to file (default: stdout)
00425| --root PATH         Project root for file completion
00426| --single-line       Single-line mode (no @ completion, no commands)
00427| --prompt           Show this help message
00428| ```
00429| 
00430| ## Examples
00431| 
00432| ### Write instruction for AI
00433| ```bash
00434| sspec tool prompt -o .sspec/asks/new-feature.md
00435| # Type: Please implement @src/auth.py with ...
00436| # Press Esc+Enter to save
00437| ```
00438| 
00439| ### Dynamic output
00440| ```bash
00441| sspec tool prompt
00442| # Type some text...
00443| # Press Esc → /output notes.md
00444| # Continue typing...
00445| # Press Esc+Enter to save to notes.md
00446| ```
00447| 
00448| ## Notes
00449| - File paths are relative to project root
00450| - Completion skips .git, __pycache__, node_modules, .sspec
00451| - Works best in terminals with UTF-8 support
00452| - The Esc key may have a brief delay (terminal escape sequence timeout)
00453| """
00454| 
00455| 
00456| # ============================================================================
00457| # CLI Registration
00458| # ============================================================================
00459| 
00460| 
00461| def register_command(group):
00462|     """Register prompt command to the tool group."""
00463|     import click
00464|     from rich.console import Console
00465| 
00466|     from sspec.core import find_sspec_root
00467| 
00468|     console = Console()
00469| 
00470|     @group.command(name=TOOL_NAME, help=TOOL_DESCRIPTION)
00471|     @click.option(
00472|         '-o',
00473|         '--output',
00474|         type=click.Path(path_type=Path),
00475|         help='Save to file (default: stdout)',
00476|     )
00477|     @click.option(
00478|         '--root',
00479|         type=click.Path(exists=True, file_okay=False, path_type=Path),
00480|         help='Project root directory (default: current sspec project or cwd)',
00481|     )
00482|     @click.option(
00483|         '--single-line',
00484|         is_flag=True,
00485|         help='Single-line mode (no file completion, no commands)',
00486|     )
00487|     @click.option('--prompt', 'show_prompt', is_flag=True, help='Show tool usage guide')
00488|     def prompt_command(
00489|         output: Path | None, root: Path | None, single_line: bool, show_prompt: bool
00490|     ):
00491|         """Interactive command editor with file path completion."""
00492| 
00493|         if show_prompt:
00494|             console.print(TOOL_PROMPT)
00495|             return
00496| 
00497|         # Determine root directory
00498|         if root is None:
00499|             sspec_root = find_sspec_root()
00500|             if sspec_root:

(File has more lines. Use 'offset' parameter to read beyond line 500)
</file>
```
```

---

## Assistant (Build · gpt-5.3-codex · 59.7s)

_Thinking:_

**Analyzing ask file design risks**

结论先说：**当前 `.py -> .md` 方案“能用”，但从稳健性和安全性看不太合适作为长期默认方案**。  
更准确地说：它是一个快速 MVP 设计，不是最佳的持久格式设计。

**主要问题（按严重度）**
- `高`：执行 ask 文件使用动态导入，等于执行任意 Python 代码，风险面太大，见 `src/sspec/services/ask_service.py:246`、`src/sspec/services/ask_service.py:251`、`src/sspec/services/ask_service.py:307`。
- `高`：答案直接拼进 `r"""..."""`，若用户输入含 `"""` 会破坏语法，后续转换会炸，见 `src/sspec/services/ask_service.py:282`。
- `中`：`ask prompt` 只捕获了少量异常，`SyntaxError` 等解析错误会直接抛栈，不够产品化，见 `src/sspec/commands/ask.py:133`。
- `中`：名称被强制正则化为 `[a-z0-9_]`，中文/多语言 topic 体验差，见 `src/sspec/services/ask_service.py:122`。
- `低`：以 `.py` 作为“数据载体”可读性和可移植性不如纯文本/YAML，对非 coding 项目不友好，入口也被硬编码为 `.py`，见 `src/sspec/commands/ask.py:101`。

**它的优点（不是一无是处）**
- pending/completed 状态用扩展名区分，流程简单直观。
- `REASON/QUESTION/USER_ANSWER` 结构对 Agent 填写很友好。
- 归档时自动更新引用，这点做得不错，见 `src/sspec/services/ask_service.py:87`。

**是否合适（结论）**
- 短期：可接受（尤其在高信任、本地单机场景）。
- 中长期：不建议继续以“执行 Python 文件”作为核心机制。

**建议路线**
1. **最小改动路线（保留 `.py`）**：改为 `ast` 解析常量，不执行模块；并修复答案序列化（避免三引号注入）+ 补 `SyntaxError` 友好报错。  
2. **更优路线（推荐）**：改成 `.md/.yaml` 作为 pending 载体（frontmatter + body），`prompt` 只读写文本，不执行代码；保留对旧 `.py` 的兼容转换。  

如果你愿意，我可以下一步给你一份“兼容迁移方案”（包括 CLI 行为不变、数据格式平滑升级、回归测试点）。

---

## User

---

## Assistant (Compaction · gpt-5.3-codex · 34.2s)

_Thinking:_

**Providing detailed continuation prompt**

Paste this into the next session:

```text
We are working on the `sspec` project refactor and comparing old/new agent workflows for Agentic Coding quality.

Project root:
`H:\SrcCode\playground\sspec`

What we already did:

1) Compared protocol versions
- Compared:
  - `tmp/legacy-sspec-8.0`
  - `tmp/new-sspec-9.0`
- Conclusion:
  - 9.0 is generally better for agent execution (clearer phase flow, lower cognitive load, better user checkpoints).
  - Not Pareto-superior yet because some rigor/regression exists (rule conflicts and reduced deep standards).

2) Captured user decisions (must persist)
- Status transition must be: design + plan approval -> `DOING`
- Long-session threshold should be unified at `30` exchanges
- `BLOCKED -> DOING` path can remain omitted
- Frontmatter normalization is important
- Root/sub bidirectional references are important and must be YAML-precise
- 8.0-style four-layer memory promotion was intentionally reduced; do not restore that complexity

3) Applied template changes under `src/sspec/templates/`
Modified files:
- `src/sspec/templates/AGENTS.md`
- `src/sspec/templates/change/spec.md`
- `src/sspec/templates/change-root/spec.md`
- `src/sspec/templates/skills/sspec-design/SKILL.md`
- `src/sspec/templates/skills/sspec-plan/SKILL.md`
- `src/sspec/templates/skills/sspec-implement/SKILL.md`
- `src/sspec/templates/skills/sspec-handover/SKILL.md`

What changed:
- Unified long-session threshold to `>30 exchanges` in protocol + relevant skills
- Fixed design-flow conflict:
  - Design approval no longer directly triggers `PLANNING -> DOING`
  - Now only after plan approval do we transition to `DOING`
- Added frontmatter normalization guidance in `sspec-design` skill (single/sub/root schema)
- Added/clarified root-sub bidirectional reference requirements (with YAML examples)
- Strengthened frontmatter guidance comments in change templates
- Added `tasks.md` frontmatter normalization section in `sspec-plan`

4) Validation done
- Ran package reinstall: `uv pip install -e .`
- Ran tests:
  - `uv run pytest tests/test_project_init_service.py tests/test_project_update_service.py tests/test_agents_service.py`
  - Result: 27 passed
- Did template generation sanity checks in:
  - `tmp/test_template_tuning_20260224`
- Note: interactive `sspec project init` in this terminal had `questionary/prompt_toolkit` console issues, so initialization was also tested through service-level invocation.

5) Also discussed non-coding use
- Framework can work for non-coding workflows (e.g., writing), but needs profile-specific language/skills
- Recommended optional profile strategy rather than polluting coding defaults

6) Latest topic analyzed (not implemented yet):
- Reviewed:
  - `src/sspec/commands/ask.py`
  - `src/sspec/services/ask_service.py`
- Current `.py -> .md` ask flow assessment:
  - Works as MVP
  - But has important risks:
    - Dynamic import executes arbitrary code from ask files
    - Triple-quote answer injection can break `.py` parsing
    - Incomplete error handling in CLI path for syntax/import issues
    - Name normalization is overly restrictive for non-ASCII topics
- Recommendation direction:
  - Prefer moving pending ask format to text (`.md`/YAML/frontmatter), avoid executing Python
  - Keep backward compatibility for existing `.py` ask files
  - If staying `.py` temporarily, replace exec-import with safe parser (`ast`) and fix answer serialization

What we are doing now:
- Deciding whether to redesign ask storage/workflow from Python-template files to markdown/yaml pending format.
- Potentially adding lightweight documentation aids so 9.0 keeps concise style while preserving professional doc quality.

Next steps to continue:
1) Propose and agree migration design for ask workflow:
   - Preferred target format (pending file + completed file)
   - Backward compatibility strategy
   - CLI behavior compatibility (`ask create`, `ask prompt`, `ask list`, `ask archive`)
2) Implement safely in:
   - `src/sspec/services/ask_service.py`
   - `src/sspec/commands/ask.py`
3) Add/adjust tests in:
   - `tests/test_ask_service.py`
   - (add command-level tests if needed)
4) Optionally add small “quality aid” docs for 9.0 skills (frontmatter/reference examples + task quality checklist), but keep concise style.

Important constraints/preferences from user:
- Keep 9.0 simplicity; do not reintroduce heavy 8.0 complexity wholesale
- Preserve strict frontmatter/reference quality
- Root/sub YAML linkage clarity is critical
- Threshold consistency matters (`30`)
```

If you want, I can now directly draft the migration spec for `ask` (format, compatibility, rollout plan) as the next actionable step.

---

