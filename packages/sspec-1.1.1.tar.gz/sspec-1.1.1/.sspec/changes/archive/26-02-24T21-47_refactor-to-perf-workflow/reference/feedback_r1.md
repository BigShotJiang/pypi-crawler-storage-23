由于 copilot 限制，刚刚中断了，现在请你继续

---

不过我观察到 context window 快满了，所以建议你更新 .sspec/changes/archive/26-02-24T21-47_refactor-to-perf-workflow/handover.md 避免把重要的信息给压缩掉了

---

此外我还有一些额外提议：

**@ask**
@ask 可以分为两种： 1) `sspec ask` 这个一般式问复杂问题；2） Agent 系统内置的 question 类工具，但是有的 Agent 系统可能没有相关内置；
如果是简单问题，比如 END 时候问是否满意，更推荐用后者（前提是存在）
以及一个要点：不要在 @ask 的 body 中写过于复杂的内容，特别是后者；复杂、可以复用的内容，写入独立文件中（reference/ 或者 tmp/）然后在 question 中引用路径

**CLI 使用**
感觉目前缺乏一个对 sspec cli 使用规范的说明地方；或者在 Agents.md 或者在 SKILL 中
此外：在编写这个的过程中，如果你对 CLI 有什么疑问也可以问我

其实最核心而就是：
sspec change new
sspec change find | list | link
sspec request list
sspec doc new
sspec ask create + sspec ask prompt （注意这是一套连招，因为 sspec ask 的核心支撑点就是，CLI 工具运行需要审批，这样用时可以在 ask create 之后填写内容然后许可 ask prompt 的运行，从 Agent 时间看就是只要连续执行两条命令就能直接获得用户回答）
部分实用的 sspec tool

---

**design**
在设计的时候要强调一下编写的规范，由于旧版的 sspec-change 都被删了，我建议还是增加一些案例，并强调用户在意的接口、数据类型、数据流、逻辑流等；避免 Agent 忽略
并且 desing 也是一个 user-in-loop 的过程， 和最后的 review 一样

---

**doc**
Agent 似乎缺少了对 spec-doc 的说明，这样流程也是，先咨询相关 SKILL，做调研，然后 Agent 给出 spec-doc 的方案给 user 审查
如果是更新，也需要给出更新的规划
spec-doc 可能在集中情况下被更新：
- change 完毕，并且过程中涉及到某个 spec-doc，这个 spec-doc 在 change 发生之后需要更改，请 Agent 主动咨询用户是否更改
- 用户主动发起，编写或更新 spec doc，这种情况下如果工作量大甚至有必要创建一个独立的 change

---

**SKILL**
有些 Agent 系统死脑筋，只会阅读 SKILL.md 不知道怎么运用 SKILL.md 中提到的引用，需要你稍微强调一下


---

**handover要强调**
当前 handover 被 Agents.md 写在 Background rules 中，而非高度参与 life cycle；个人认为这个不妥
这个文档非常重要，是 change session 的 memroy

---

**重新想象 project.md**

由于 sspec-memory 被删了，现在需要再次考虑 project.md 的定位、还有默认的模板
另外，把 project.md 内填入 spec-doc 的索引是否会 Ok?
