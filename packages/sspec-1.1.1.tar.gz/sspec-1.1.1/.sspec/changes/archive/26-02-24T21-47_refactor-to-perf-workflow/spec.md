---
name: refactor-to-perf-workflow
status: DOING
type: template-refactor
change-type: root
created: 2026-02-24 21:47:56
reference:
- source: .sspec/requests/archive/26-02-24T21-19_refactor-to-perf-workflow.md
  type: request
  note: Linked from request
archived: '2026-02-25T01:09:27'
---
<!-- @RULE: Frontmatter Schema
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: single | sub (sub if part of a root change);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
📚 Full schema details: sspec-change SKILL → doc-standards.md
 -->

# refactor-to-perf-workflow

## A. Problem Statement

### Current Situation

SSPEC 的 SKILL 架构和 AGENTS.md 流程引导存在结构性问题，导致用户在实际使用中认知负荷过高：

1. **sspec-change 是单体巨兽** — 1 个 SKILL.md (198行) + 3 个 reference 文件 (doc-standards 274行, doc-examples, multi-change)，试图覆盖 change 的整个生命周期，Agent 需要跳 3-4 层引用才能找到需要的信息
2. **缺少强制 user-in-the-loop 检查点** — 用户反复需要手动提示"先规划不要执行"、"做完先问我"。AGENTS.md 把 Confirm 作为建议步骤而非强制，导致 Agent 经常跳过
3. **sspec-memory 的 4 层晋升体系不实用** — Record → Change → Project → Spec 概念完美但 Agent 几乎不主动做 promotion，实际有用的只有 "更新 handover.md" 和 "偶尔更新 project.md Notes"
4. **深层引用链** — AGENTS.md → SKILL.md → references/doc-standards.md → doc-examples.md，Agent 被要求在不同阶段读同一组文件，但每个阶段实际只需要其中一小部分
5. **Root change 引导不足** — 模板缺乏足够指引，Agent 不知道如何有效拆分多阶段工作

### User Requirement

重新设计 AGENTS.md 和 SKILL 体系，使得：
- Agent 在每个工作阶段只需读取一个轻量 SKILL
- 工作流中有明确的 user-confirmation 检查点，不需要用户手动提示
- 减少引用深度，消除"AGENTS.md → A → B → C" 的嵌套
- Root change 有足够引导

## B. Proposed Solution

### Approach: Phase-as-Skill + 模板重构

两个支柱：
1. **Phase-as-Skill**: 将 change 生命周期拆为阶段性 SKILL，每个 SKILL 只负责一个清晰的工作阶段
2. **模板重构**: 从第一性原理重新设计 change 目录下的文件结构

#### 开发工作流程

```
Request ─→ [research] ─→ [design] ──→ [plan] ──→ [implement] ──→ [review]
               │             │            │            │              │
             理解问题     @ask 方案    @ask 任务     逐项执行     @ask 验收
             空间         对齐确认     审核确认     更新进度     反馈循环
```

每个阶段明确定义：读什么文件、写什么文件、什么条件结束。

#### 为什么这样设计

**Phase-as-Skill vs 当前 Function-as-Skill**：
- 当前 sspec-change 像百科全书 — Agent 在 research 阶段不需要知道 tasks.md 格式
- 新架构中 Agent 只在当前阶段加载对应 SKILL (~80-120 行)
- 消除深层引用链：每个 SKILL 是 self-contained 的

**不完全复制 OpenSpec**：
- SSPEC 有自己的 CLI、文件体系，不用 artifact graph
- SSPEC 的 ask 机制更成熟
- Skill 命名避免和 openspec 重复

### 新 SKILL 体系

| 新 SKILL | 替代什么 | 职责 | 阶段文件写入 |
|---|---|---|---|
| `sspec-research` | 新增 | 调研探索代码，理解问题空间。不做设计不做实现 | `reference/` 研究笔记, `handover.md` 发现 |
| `sspec-design` | sspec-change 设计部分 | **Scale 评估** + 创建 change (single/root) + 填写 spec.md A+B, @ask 和用户对齐方案 | `spec.md` |
| `sspec-plan` | sspec-change 规划部分 | 填写 tasks.md 具体任务，@ask 最终审核 | `tasks.md` |
| `sspec-implement` | sspec-change 执行部分 | 按 tasks.md 逐项执行，遇问题暂停 @ask | 代码, `tasks.md` 进度 |
| `sspec-review` | 新增 | 用户验收 + argue-improve 循环 | `tasks.md` 新任务, `handover.md` 反馈记录 |
| `sspec-handover` | sspec-memory (精简) | Session 保存：更新 handover.md + 必要时 project.md Notes | `handover.md`, `project.md` |
| `sspec-ask` | 保留精简 | 用户咨询工具 | `.sspec/asks/` |

**删除**: `sspec-change`, `sspec-memory`
**保留**: `sspec-mdtoc`, `write-spec-doc`, `write-patch`, `sspec-patch`, `use-powershell`

### sspec-design 的 Single/Root 分支

Scale assessment 必须发生在 design 阶段（创建 change 之前），因为 single 和 root 使用不同的 CLI 命令和模板：

```
sspec-design SKILL 内部流程:

1. Assess Scale
   micro  → do directly, no change needed
   single → sspec change new <name>       → fill single spec.md (A+B detailed design)
   multi  → sspec change new <name> --root → fill root spec.md (A problem, B phase overview)

2. Single path:
   - A: 具体问题描述
   - B: 详细设计（approach + key design）
   - @ask 用户确认

3. Root path:
   - A: 整体问题描述
   - B: 分阶段概览 (Phase 1 goal/scope, Phase 2 goal/scope, ...)
   - @ask 用户确认分阶段方案
   - 然后为每个 phase 创建 sub-change (sspec change new <sub-name>)
     每个 sub-change 也经历 design → plan → implement → review 子循环
```

这解决了 multi-change.md 的归属问题：multi-change 的逻辑直接写在 `sspec-design` 的 root 分支中。

### sspec-plan 的 Single/Root 分支

```
sspec-plan SKILL 内部流程:

1. Single path:
   - 填写 tasks.md: 文件级任务，<2h 粒度，有验证标准

2. Root path:
   - 填写 root tasks.md: 里程碑级（每个 sub-change 一个 milestone）
   - 当前 active sub-change: 填写该 sub-change 的 tasks.md（文件级）
```

### Change 模板重构

#### 第一性原理分析

每个阶段产出什么？

| 阶段 | 产出 | 对应文件 |
|---|---|---|
| Research | 问题理解、代码发现、背景知识 | `reference/` 笔记 |
| Design | 问题定义 + 解决方案设计 | `spec.md` (A: Problem, B: Design) |
| Plan | 具体执行计划 | `tasks.md` (phases + file-level tasks) |
| Implement | 代码变更 | 代码 + `tasks.md` 进度更新 |
| Review | 反馈改进 | `tasks.md` 新增反馈任务 |
| 全程 | Session 记忆 | `handover.md` |

#### 新 spec.md 结构

**砍掉 Section C 和 D**：
- Section C (Implementation Strategy) 和 tasks.md 高度重复 → 合并到 tasks.md
- Section D (Blockers & Feedback) 几乎无人用 → Blockers 放 handover.md; Pivots 放 spec.md A 中标注

新结构：
```
spec.md
├── A. Problem Statement     # 问题，量化影响
└── B. Proposed Solution      # 设计：方案 + 关键设计细节
    ├── Approach              # 核心思路，为什么
    └── Key Design            # 接口、数据模型、核心逻辑（按复杂度伸缩）
```

简洁，只做两件事：**定义问题** + **设计解决方案**。

#### 新 tasks.md 结构

吸收 spec.md C 的 phase 概念，成为唯一的执行规划文件：
```
tasks.md
├── Phase 1: <name>           # 阶段划分（来自设计）
│   ├── [ ] Task `file.py`    # 文件级任务
│   └── Verification          # 阶段验证标准
├── Phase 2: ...
├── Feedback Tasks            # Review 阶段新增的改进任务
└── Progress                  # 进度追踪
```

#### 新 handover.md 结构

精简，砍掉花哨的层级：
```
handover.md
├── Background                # 一次性写入
├── This Session
│   ├── Accomplished          # 本次做了什么
│   └── Next Steps            # 下 1-3 步
└── Working Memory
    ├── Key Files             # 关键文件
    ├── Decisions             # 决定及原因
    └── Notes                 # 坑、发现、风险
```

不再有 "Current Status"（在 spec.md frontmatter 中）、不再有 "Gotchas & Context" 的复杂命名。

#### Reference 文件处理策略

SKILL 系统不支持跨 SKILL 共享 reference。方案：将各 reference 的核心内容 inline 到对应 SKILL 中。

| 原 Reference | 处理方式 |
|---|---|
| `doc-standards.md` (274行) | spec.md A+B 标准 → inline 到 `sspec-design`；tasks.md 标准 → inline 到 `sspec-plan` |
| `doc-examples.md` | 精选关键示例 inline 到 `sspec-design` 和 `sspec-plan` |
| `multi-change.md` | root change 流程 → inline 到 `sspec-design` 的 Root 分支 |
| `handover-standards.md` | 精简后 inline 到 `sspec-handover` |

这样每个 SKILL 是 **self-contained** 的——Agent 只读一个 SKILL.md 就获得该阶段所需的全部标准。
模板文件中的 @RULE 注释提供基础引导，SKILL 提供完整标准，二者互补。

### AGENTS.md 重设计

目标：从 ~200 行精简到 ~130 行。

核心变更：
1. 工作流程图直接展示阶段 + 强制检查点
2. 顶层列出所有 SKILL 入口（一个表格，不嵌套引用）
3. 精简 background rules
4. 明确 Phase → SKILL → 文件写入 的三级映射

### Phase 1: Change 模板重构
- **Goal**: 新的 spec.md / tasks.md / handover.md 模板（single + root）
- **Scope**: `src/sspec/templates/change/`, `src/sspec/templates/change-root/`
- **Deliverable**: 精简的模板，spec.md 只有 A+B，tasks.md 吸收 phases

### Phase 2: 新 SKILL 创建
- **Goal**: 创建 research / design / plan / implement / review / handover 六个新 SKILL
- **Scope**: `src/sspec/templates/skills/` 下新建 6 个目录
- **Deliverable**: 每个 SKILL 一个 SKILL.md (~80-120 行)
- **Dependencies**: Phase 1（模板结构确定后 SKILL 才能引用正确的文件名）

### Phase 3: AGENTS.md 重写
- **Goal**: 轻量化 AGENTS.md，清晰工作流 + SKILL 入口表
- **Scope**: `src/sspec/templates/AGENTS.md`
- **Dependencies**: Phase 2（SKILL 名称和职责确定）

### Phase 4: 旧 SKILL 清理 + Reference 整理
- **Goal**: 删除 sspec-change / sspec-memory，精简 sspec-ask，整理共享 reference
- **Scope**: `src/sspec/templates/skills/sspec-change/`, `sspec-memory/`, `sspec-ask/`
- **Dependencies**: Phase 3 完成

### Phase 5: 代码适配 + 测试
- **Goal**: 更新 managed_skills、SCHEMA_VERSION，安装测试
- **Scope**: `src/sspec/core.py`, `src/sspec/services/project_init_service.py`
- **Dependencies**: Phase 4 完成

### Coordination Notes
- Phase 1-3 是核心设计工作，需要用户逐步确认
- Phase 4-5 是机械性清理工作，风险较低
- 每个 SKILL 中引用模板文件名必须与 Phase 1 保持一致

## D. Blockers & Feedback

（暂无）
