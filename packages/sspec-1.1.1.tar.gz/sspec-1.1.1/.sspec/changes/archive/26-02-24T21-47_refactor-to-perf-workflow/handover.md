# Handover: refactor-to-perf-workflow

**Updated**: 2026-02-25

---

## Background

Refactor SSPEC's SKILL architecture from monolithic (sspec-change + sspec-memory) to phase-based SKILLs, each covering one development lifecycle stage. Root change — spans template files, SKILL files, and AGENTS.md.

## This Session

### Accomplished

**Session 1 (completed):**
1. Created new change templates (single + root) for spec.md, tasks.md, handover.md — spec.md simplified to A+B only
2. Created 6 new phase SKILLs: sspec-research, sspec-design, sspec-plan, sspec-implement, sspec-review, sspec-handover
3. Rewrote AGENTS.md (~200→~130 lines) with workflow diagram and Phase→SKILL→Files table
4. Deleted old sspec-change/ and sspec-memory/ dirs, simplified sspec-ask (212→~80 lines)
5. Bumped SCHEMA_VERSION 8.0→9.0, reinstalled, sandbox tested (init + change new + root change new all pass)
6. Updated request template and sspec-mdtoc SKILL references

**Session 2 (in progress) — User Round 2 feedback, 7 categories:**
- [ ] sspec-ask: add "sspec ask vs built-in question tool" distinction + complex content → write to file
- [ ] CLI reference: missing centralized CLI usage guide in AGENTS.md or SKILL
- [ ] sspec-design: needs examples, emphasis on interfaces/data types/data flow, user-in-loop emphasis
- [ ] spec-doc: no guidance on spec-doc lifecycle (post-change update, user-initiated creation)
- [ ] SKILL refs: some agents need explicit instruction to follow SKILL.md references
- [ ] handover: should be lifecycle participant, not just background rule
- [ ] project.md: rethink template since sspec-memory deleted; consider spec-doc index

### Next Steps

1. Fix CLI output in `src/sspec/commands/change.py` (lines 216/219 still say "sspec-change"/"sspec-memory")
2. Apply all 7 user feedback categories to template files
3. Clean .bak files, run tests, final sandbox verification

## Working Memory

### Key Files

- `src/sspec/templates/AGENTS.md` — root protocol, needs CLI ref section and handover elevation
- `src/sspec/templates/skills/sspec-design/SKILL.md` — needs examples + interface/data flow emphasis
- `src/sspec/templates/skills/sspec-ask/SKILL.md` — needs sspec-ask vs question-tool distinction
- `src/sspec/templates/skills/sspec-handover/SKILL.md` — lifecycle elevation candidate
- `src/sspec/templates/skills/sspec-review/SKILL.md` — add spec-doc update guidance at close
- `src/sspec/templates/project.md` — consider spec-doc index section
- `src/sspec/commands/change.py` — lines 216, 219 reference old skill names
- `src/sspec/core.py:21` — SCHEMA_VERSION already bumped to 9.0
- `.sspec/changes/archive/26-02-24T21-47_refactor-to-perf-workflow/spec.md` — active root change spec

### Decisions

- **Phase-as-Skill architecture**: Each dev phase gets its own SKILL (~80-120 lines). No shared reference files — each SKILL is self-contained. Reason: Claude SKILL system doesn't support cross-SKILL shared references; deep reference chains were the #1 user complaint.
- **Scale assessment in design phase**: Must happen before `sspec change new` because single vs root use different CLI commands/templates. This was a critical fix from user feedback in Round 1.
- **spec.md A+B only**: Removed Section C (redundant with tasks.md) and D (rarely used). Blockers → handover.md. Pivots → inline notes in spec.md A.
- **sspec-memory deleted**: Its useful parts (handover quality, knowledge routing) were inlined into sspec-handover. The 4-level promotion hierarchy was dropped — only handover.md and project.md Notes remain.
- **Old skill .bak files**: Still exist in templates dir, need cleanup before final commit.

### Notes

- `list_template_skills()` in core.py auto-discovers skill dirs by scanning for SKILL.md — no manual registration needed
- `.bak` files of old templates still exist and need deletion
- `uv run pytest ./tests/ -q` failed (exit code 1) in last session — not yet investigated
- UPDATABLE_FILES and USER_FILES in core.py may need checking if template structure changed
- User emphasized: design SKILL should highlight what users care about most: interfaces, data types, data flow, logic flow
- User wants handover to be a visible lifecycle node, not just a background rule in AGENTS.md
