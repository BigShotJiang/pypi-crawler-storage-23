# Handover: replace-archived-link-path

**Updated**: 2026-02-14

---

## Background

扩展 archive 操作时的引用更新范围，从原来只在 request ↔ change 的 frontmatter 字段更新，扩大到搜索 requests/ + changes/ + tmp/ 目录下的所有 .md 文件。

## Accomplished This Session

- ✅ Phase 1: 扩展 change archive 引用更新 (change_service.py)
- ✅ Phase 2: 扩展 request archive 引用更新 (request_service.py)
- ✅ Phase 3: 添加 ask archive 引用更新 (ask_service.py)
- ✅ Phase 4: 测试验证通过
- ✅ 补齐 first-principles 行为：归档后引用更新覆盖 archive 子目录，消除顺序归档残留死链
- ✅ 补充回归保障：新增/更新单测与 `scripts/test-replace-link.ps1` 严格模式验证

## Current Status

DONE

## Next Steps

无；如后续扩展 archive 规则，优先复用 `update_references_in_dirs` 并补回归测试。

## References & Memory

### Key Files

- `src/sspec/services/change_service.py:_rewrite_references_after_change_archive` — 归档 change 时更新引用
- `src/sspec/services/request_service.py:_rewrite_references_after_request_archive` — 归档 request 时更新引用
- `src/sspec/services/ask_service.py:archive_ask` — 归档 ask 时更新引用
- `tests/test_change_service.py` / `tests/test_request_service.py` / `tests/test_ask_service.py` — archive 目录引用更新回归测试
- `scripts/test-replace-link.ps1` — 端到端 smoke test（默认严格检查 archive 残留）

### Decisions & Rationale

- **Decision**: 只使用完整路径匹配，避免部分匹配导致嵌套替换
  - **Why**: 测试中发现简单的字符串替换会导致路径被重复替换（如 `.sspec/changes/test-change` 被替换后变成 `.sspec/.sspec/changes/archive/...`）

### Gotchas & Context

- 路径替换逻辑使用从长到短排序，防止短模式匹配到已替换的长模式
- 为消除顺序归档残留问题，引用更新应覆盖 archive 子目录
