---
name: replace-archived-link-path
status: DONE
type: ''
change-type: single
created: 2026-02-14 15:18:27
reference:
- source: .sspec/requests/archive/26-02-14T15-12_replace-archived-link-path.md
  type: request
  note: Linked from request
archived: '2026-02-24T23:38:34'
---
<!-- @RULE: Frontmatter Schema
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: single | sub (sub if part of a root change);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
📚 Full schema details: sspec-change SKILL → doc-standards.md
 -->

# replace-archived-link-path

## A. Problem Statement

当前 change/request/ask 支持 archive 指令，会把 .sspec 下相关文件移动到 archive 目录。现有实现只更新了部分 cross-reference：

- `archive_change`: 只更新 request 文件中的 `attach-change` 字段
- `archive_request`: 只更新 change 文件中的 `reference` 字段  
- `archive_ask`: 完全没有更新任何引用

**影响**：其他文件（如 tmp 下的文件、其他 change 的 handover.md、spec.md 正文中的路径引用等）中引用被归档文件的路径不会被更新，导致死链。

## B. Proposed Solution

### Approach

在 archive 操作时，搜索相关目录下所有 .md 文件，替换旧路径为新路径。

**搜索范围**：
- `archive_change`: `requests/` + `changes/` + `tmp/`
- `archive_request`: `requests/` + `changes/` + `tmp/`
- `archive_ask`: `asks/` + `tmp/`

**替换逻辑**：直接字符串替换（路径格式固定为 `.sspec/requests/...` 等）

**优势**：简单直接，现有的 cross-reference 更新逻辑已经处理了 request ↔ change 之间在对方 frontmatter 字段的引用，只需扩大到这些目录下的所有文件。

## C. Implementation Strategy

### Phase 1: 扩展 change archive 引用更新

- `src/sspec/services/change_service.py` — modify
  - 现有 `_update_requests_after_change_archive` 只更新 requests/ 下的 frontmatter
  - 扩展为：遍历 `requests/` + `changes/` + `tmp/` 下所有 .md 文件，替换旧路径为新路径
  - 使用 `old_name` 和新 archive 路径的相对路径进行字符串替换

### Phase 2: 扩展 request archive 引用更新

- `src/sspec/services/request_service.py` — modify
  - 现有 `_update_change_after_request_archive` 只更新 change 的 frontmatter
  - 扩展为：遍历 `requests/` + `changes/` + `tmp/` 下所有 .md 文件，替换旧路径为新路径

### Phase 3: 添加 ask archive 引用更新

- `src/sspec/services/ask_service.py` — modify
  - 添加引用更新逻辑，遍历 `asks/` + `tmp/` 下所有 .md 文件，替换旧路径为新路径

### Phase 4: 测试验证

- 在 tmp 目录创建测试场景，验证归档后所有引用都被正确更新

### Risks & Dependencies

- 风险：替换路径时可能误替换不相关的字符串 → 使用完整相对路径匹配（如 `.sspec/changes/xxx`）
- 依赖：无外部依赖

## D. Blockers & Feedback
<!-- @REPLACE -->

<!-- @RULE: Record with dates. Format:
### Blocker (YYYY-MM-DD)
**Blocked**: <what> | **Needed**: <to unblock>

### PIVOT (YYYY-MM-DD)
<direction change and reason>
-->
