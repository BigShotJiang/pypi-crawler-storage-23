这个请求（参考 request）我委托另一个 Agent 完成，效果我还不是太满意。
请你帮我整理分析（更改存在 git staged 中，你可以查看 git diff --staged）当前实现的代码，回答：

- 当前的程序代码实现是否正确？
- 代码设计质量、接口质量是否优质？
- 新的功能是否能直接替代旧版本的双向更新功能（被我注释掉的部分）

以及最重要的，为了验证当前的代码是否正确，我需要一个自动化测试手段，请你编写一个 test-replace-link.ps1 脚本，我想的测试功能逻辑如下：

1. ensure project : tmp/test-replace-archive-link-project
   1. 如果不存在就创建，并运行 uv run sspec project init
2. 创建一个 requests
   1. uv run sspec request new <random-name>
3. 创建一个 change
   1. uv run sspec change new --from <request-name>
4. 创建一个随意的 ask 文件
   1. 直接在 .sspec/asks 下创建一个 Markdown 文档；可以参考 src/sspec/services/ask_service.py 中的 MD 文档
5. 在 ask, requests, change 当中各自互相引用对方的链接，包括 ASK request 的文件，change 下的 spec.md, handover.md， 还有 change/reference 等
6. 依次运行 archive，看看最终链接是否能被正确更新
