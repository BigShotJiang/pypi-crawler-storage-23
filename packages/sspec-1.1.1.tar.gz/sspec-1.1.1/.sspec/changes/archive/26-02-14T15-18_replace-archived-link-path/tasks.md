---
change: "replace-archived-link-path"
updated: ""
---

# Implementation Tasks

## Legend
`[ ]` Todo | `[x]` Done (implemented + verified)

## Tasks

### Phase 1: 扩展 change archive 引用更新 🚧

- [x] 修改 `src/sspec/services/change_service.py` — `_update_requests_after_change_archive`
  - 扩展为遍历 `requests/` + `changes/` + `tmp/` 下所有 .md 文件
  - 替换 old_name 和旧路径为新路径
- [x] **Verification**: 创建测试场景验证

### Phase 2: 扩展 request archive 引用更新

- [x] 修改 `src/sspec/services/request_service.py` — `_update_change_after_request_archive`
  - 扩展为遍历 `requests/` + `changes/` + `tmp/` 下所有 .md 文件
- [x] **Verification**: 创建测试场景验证

### Phase 3: 添加 ask archive 引用更新

- [x] 修改 `src/sspec/services/ask_service.py` — `archive_ask`
  - 添加遍历 `asks/` + `tmp/` 下所有 .md 文件的更新逻辑
- [x] **Verification**: 创建测试场景验证

### Phase 4: 测试验证 🚧

- [x] 在 tmp 目录创建完整测试场景
- [x] **Verification**: 符合 request 中定义的 Success Criteria

---

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |

**Recent**:
- ✅ 修正归档顺序问题：引用更新覆盖 archive 子目录，避免残留死链
- ✅ 增加回归测试：验证 archive 目录内引用也会被更新
