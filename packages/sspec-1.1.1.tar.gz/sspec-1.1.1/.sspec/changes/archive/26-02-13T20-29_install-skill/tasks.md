---
change: "install-skill"
updated: ""
---

# Implementation Tasks

## Legend
`[ ]` Todo | `[x]` Done (implemented + verified)

## Tasks
<!-- @REPLACE -->
<!-- @RULE: Organize by phases from spec.md Section C. Each phase has verification.
Phase emoji: 🚧 in progress | ✅ done | ⏳ pending
Update progress after EACH task — not in batches.
📚 Standards: sspec-change SKILL → doc-standards.md
-->
### Phase 1: Research & Planning ✅
- [x] 完成现有实现调研（init/update/installer）并识别核心痛点
- [x] 输出优化方案草案到 `reference/skill-sync-research.md`
- [x] 完成 `spec.md` A/B/C/D 规划并对齐 request 目标
- [x] 生成 `sspec ask` 审查问题模板
- [x] 执行 `sspec ask prompt` 并记录用户审查反馈
**Verification**: `spec/tasks/handover/reference/ask` 文件均已存在且内容完整，方案覆盖 init/update/migration 三类场景

### Phase 2: Sync Skills Core Refactor ⏳
- [x] 在 `src/sspec/skill_installer.py` 增加 `check_path_link`（symlink+junction）与安全 link 清理逻辑
- [x] 在 `src/sspec/services/project_init_service.py` 调整核心安装与外部同步顺序
- [x] 在 `src/sspec/skill_installer.py` 将自动写入 `.gitignore` 改为 fence managed block
- [x] 在 `src/sspec/commands/project.py` 更新 init 交互流程（先安装再询问同步）
**Verification**: 新项目 init 可完成 `.sspec/skills` 安装，并可按选择同步到外部位置

### Phase 3: Update & Migration Path ⏳
- [x] 在 `src/sspec/services/project_update_service.py` 接入 link-aware 检测（symlink+junction）
- [x] 在 `src/sspec/services/project_init_service.py` 将外部同步改为目录级 hub→spoke（`xx/skills` 直连）
- [x] 更新 metadata 写入规则（locations/strategies/managed_skills）
	- location key 统一为 posix；
	- strategy 支持 `symlink/junction/copy`。
- [x] 兼容旧项目（既有 `.claude/.github` skills 或历史链接）迁移到 hub-spoke（备份+合并）
**Verification**: 在旧样本项目运行 `sspec project update` 后，skills 状态可达成预期且无数据丢失

### Phase 4: Tests & Validation ⏳
- [x] 补充/更新 `tests/test_project_init_service.py`
- [x] 补充/更新 `tests/test_project_update_service.py`
- [x] 新增 `tests/test_skill_installer.py` 覆盖 link 类型与回退路径
- [x] 新增 `tests/test_project_init_skill_sync.py` 覆盖 deferred sync + fenced gitignore
**Verification**: `uv run pytest` 相关测试通过；关键分支（symlink/junction/copy）有覆盖

---

## Progress
<!-- @REPLACE -->

<!-- @RULE: Update percentage and status after EACH task completion.
sspec change status auto-calculates from checkboxes — keep tasks.md as source of truth. -->

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |

**Recent**:
- 2026-02-13: 完成 request→change 建链，并产出调研与优化方案草案，等待用户审查确认
- 2026-02-13: 已收到用户审查反馈（Q2/Q3/Q4 同意），剩余 Junction 默认策略与 gitignore 规则待定
- 2026-02-13: 已实现 `check_path_link` + `.gitignore` fence block，并接入 update service
- 2026-02-13: 已完成 init deferred sync 重构，并通过 `test_skill_installer + test_project_init_skill_sync`
- 2026-02-13: 完成目录级 sync、junction 回退、提权失败降噪、init 输出时序重排；`ruff` + `pytest` 共 13 项通过
- 2026-02-13: 按用户追加反馈完成强制 `.agent` 回退策略、Windows 提权选择分支、legacy update 迁移逻辑；当前相关测试 27 项通过
- 2026-02-13: 修复 legacy 迁移备份在 Windows 下 `copytree(symlinks=True)` 触发 1314 权限报错，手动复现 `project update` 已通过
- 2026-02-13: 完成深度源码审计并输出 `.sspec/tmp/skill-install-cleanup-analysis.md`，按审计结果清理历史残留逻辑
- 2026-02-13: 新增 `.sspec/spec-docs/skill-installation.md`，记录当前方案与旧方案对照及迁移回溯路径
- 2026-02-14: 用户验收通过并要求进入 DONE，同时保留对后续 Agent 的代码巡检交接说明
