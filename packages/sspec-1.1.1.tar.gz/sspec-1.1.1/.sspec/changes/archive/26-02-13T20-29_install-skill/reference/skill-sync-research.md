# Skill Sync 调研与优化报告

## 1. 目标与范围
- 目标：把 SKILL 安装与更新统一为 `sync skills` 体系，确保 `.sspec/skills` 为权威来源，外部位置（`.claude/.github/.agent`）按需同步。
- 范围：`project init`、`project update`、`skill_installer` 与相关 metadata。
- 非目标：本报告不直接修改生产代码，仅形成可执行设计方案。

## 2. 现状调研摘要

### 2.1 init 当前行为
- 入口：`src/sspec/commands/project.py:init()`。
- 默认行为：若未提供 `--skill-loc`，先弹交互选择安装位置。
- 执行：`initialize_project()` 里采用 hub-spoke 批量安装：hub 复制到 `.sspec/skills/<name>`，spoke 尝试 symlink，失败回退 copy。

### 2.2 update 当前行为
- 入口：`src/sspec/commands/project.py:update()` + `collect_update_candidates()`。
- 现状：对 symlink skill 目录直接跳过；对普通目录按 copy 策略比对目录 hash 并更新。
- 风险：symlink/junction/copy 的状态识别和迁移路径不统一，升级行为可预测性不足。

### 2.3 installer 当前行为
- `SkillInstaller.install_batch()`：先尝试 symlink；失败后 Windows 提权批量重试；仍失败 copy。
- 已有优点：批量能力和回退机制已具备。
- 现缺口：无“目标已存在普通目录时的备份、合并、重建”逻辑。

## 3. 核心问题
- 交互时序不佳：init 一开始强制选位置，和“先完成核心安装”目标冲突。
- 状态模型不完整：仅区分 symlink/copy，不足以覆盖历史目录与 junction。
- 迁移路径缺失：旧项目已有目录时，缺少标准化“保留用户技能 + 切换到 hub-spoke”的流程。

## 4. 设计方案（拟）

### 4.1 总体架构
- Hub：`.sspec/skills`（唯一权威源）。
- Spoke：`.claude/skills`、`.github/skills`、`.agent/skills`（按需同步）。
- 同步流程：`detect -> backup -> merge -> relink/copy -> verify -> persist metadata`。

### 4.2 init 交互改造
1. 先初始化 `.sspec` 核心目录与 hub skills；
2. 打印安装成功摘要；
3. 询问是否同步到外部位置以及目标位置；
4. 执行 sync，并给出每个位置策略结果（symlink/junction/copy）。

### 4.3 目标目录存在时的迁移策略
- 若是“已指向 hub 的链接”：跳过。
- 若是普通目录：
  - 备份到 `.sspec/tmp/skills-backup/<timestamp>/<location>/`；
  - 将 hub 不存在的 skill 合并到 hub（避免用户自定义 skill 丢失）；
  - 删除旧目录并按标准流程重建链接或 copy。

### 4.4 Windows 链接策略
- 优先：目录符号链接（symlink）。
- 失败：可选提权重试创建 symlink。
- 再失败：
  - 可选使用 Junction（仅限 Windows）；
  - 最终回退 copy。
- 注意：Junction 不应直接用 `Path.is_symlink()` 判定“是否链接成功”，需独立检测 reparse-point 类型。

## 5. metadata 方案（建议）
- 保留并强化：`skill_locations`、`skill_install_strategies`、`managed_skills`。
- 新增建议（可选）：`skill_link_types`（symlink/junction/copy）用于 update 精准判定。

## 6. 迁移与回归验证

### 6.1 新项目 init 验证
- 在 `tmp/` 新建项目后执行 `sspec project init`；
- 验证 `.sspec/skills` 正确安装；
- 验证外部同步结果与策略输出一致。

### 6.2 旧项目 update 验证
- 准备含历史 `.claude/.github` skill 目录的样本；
- 执行 `sspec project update`；
- 验证：用户自定义 skill 被保留（已迁移/备份），最终目录结构符合 hub-spoke。

### 6.3 自动化测试建议
- 新增 `tests/test_skill_installer.py`：覆盖 detect/backup/merge/relink/copy/junction。
- 更新 init/update 测试：覆盖交互时序变更与 metadata 一致性。

## 7. 风险与缓解
- 风险：Windows link 类型识别错误导致误更新。
  - 缓解：引入统一 `link_type` 检测函数 + 单测覆盖。
- 风险：迁移时误删用户目录。
  - 缓解：强制先备份并输出备份路径。
- 风险：交互步骤过多影响体验。
  - 缓解：给默认推荐选项，并支持 `--skill-loc` 非交互执行。

## 8. 结论
该方案可在不改变 SSPEC 核心工作流的前提下，把 skill 管理从“分散安装动作”升级为“统一同步系统”，并兼顾 Windows 兼容、旧项目迁移、以及未来维护成本。建议经 `sspec ask` 审查确认后进入执行阶段。