# Handover: install-skill

**Updated**: 2026-02-14T00:35:00

---

## Background
<!-- @RULE: Write once on first session, update only if scope changes.
One sentence: what this change does and why. Details are in spec.md.
📚 Standards: sspec-memory SKILL → handover-standards.md -->
重构 SKILL 安装/更新流程为以 `.sspec/skills` 为 hub 的统一 sync 体系，解决现有 init/update 交互割裂、Windows 链接失败路径复杂、旧项目迁移不顺滑的问题。

## Accomplished This Session
<!-- Specific list of what got done -->
- 从 request 创建并关联 change：`26-02-13T20-29_install-skill`
- 调研 `project init` / `project update` / `skill_installer` 现状实现
- 完成 `spec.md` 的问题、方案、实施策略、风险与开放问题
- 产出调研报告 `reference/skill-sync-research.md`（待审阅）
- 创建 `sspec ask` 模板用于方案确认：`260213203325_skill_sync_strategy.py`
- 执行 ask 并收到用户反馈：Q2/Q3/Q4 同意，新增 Junction 与 gitignore 策略疑问
- 根据用户补充要求，已开始执行并完成首批代码改动（link 检测 + gitignore fence）
- 已完成第二批代码改动（init deferred sync）并通过新增测试
- 已完成第三批修复：目录级 skills 链接、junction 回退链、提权取消报错降噪、init 输出时序调整
- 已根据用户最新反馈补齐：空选择强制 `.agent`、Windows 提权选择分支、update 旧布局迁移
- 完成深度审计（subagent + tmp 草案），并按 clean-code 方向清理残留逻辑
- 新增 spec-doc：`.sspec/spec-docs/skill-installation.md`

## Current Status
<!-- PLANNING / DOING / BLOCKED / REVIEW -->
DONE

## Next Steps
<!-- 1-3 specific file-level actions. Example:
1. Implement `src/auth/jwt.py:refresh_token()`
2. Add tests in `tests/test_jwt.py`
-->
1. 下个 Agent 进行“残留旧逻辑巡检”（建议新建 follow-up change）
2. 重点检查兼容静态 API 的退场可行性与潜在无用分支
3. 若发现问题，基于 `.sspec/tmp/skill-install-cleanup-analysis.md` 扩展清理

## References & Memory
<!-- @RULE: Agent's external working memory. Two purposes:
1. INTRA-SESSION: Survive context window compression in long conversations
2. CROSS-SESSION: Let next Agent resume with full context

Update PROACTIVELY as you work — don't wait until session end.
Trigger: important decision made, key file found, non-obvious insight gained.
Test: "Would I struggle to reconstruct this after context compression?" → Write it NOW.
📚 Full quality standards: sspec-memory SKILL → handover-standards.md -->

### Key Files
<!-- Files critical to understanding/continuing this change.
Include: source files, reference docs, sspec ask records, related requests.
Format:
- `path/file` — what it contains, why it matters -->
- `.sspec/requests/26-02-13T20-04_install-skill.md` — 原始需求与期望流程
- `.sspec/changes/archive/26-02-13T20-29_install-skill/spec.md` — 当前正式方案（PLANNING）
- `.sspec/changes/archive/26-02-13T20-29_install-skill/tasks.md` — 分阶段任务与验证标准
- `.sspec/changes/archive/26-02-13T20-29_install-skill/reference/skill-sync-research.md` — 调研与优化报告
- `.sspec/asks/archive/260213203325_skill_sync_strategy.md` — 已记录用户审查反馈与新增问题
- `src/sspec/skill_installer.py` — 链接/复制/提权主逻辑
- `src/sspec/services/project_init_service.py` — init 的 hub-spoke 安装入口
- `src/sspec/services/project_update_service.py` — update 的候选收集与技能更新策略
- `src/sspec/commands/project.py` — init/update 交互与执行编排
- `tests/test_skill_installer.py` — 新增测试：link check 与 gitignore fence
- `tests/test_project_init_skill_sync.py` — 新增测试：init 先 core 后 external sync
- `tests/test_project_update_service.py` — 已修复旧签名并通过
- `.sspec/asks/archive/260213220331_install_skill_repair_review_v2.md` — 用户反馈与新增要求
- `.sspec/tmp/skill-install-cleanup-analysis.md` — 深度审计草案与清理计划
- `.sspec/spec-docs/skill-installation.md` — SKILL 安装/更新/迁移规范文档
- `.sspec/asks/archive/260214002722_install_skill_cleanup_review_v5.md` — 用户确认 DONE 并要求后续 Agent 巡检

### Decisions & Rationale
<!-- Important decisions and the FULL reasoning chain. This is the most
compression-vulnerable info — conclusions survive but reasoning gets lost.
For complex decisions, capture: problem → alternatives → analysis → conclusion.
Format:
- **Decision**: <what was decided>
  **Why**: <reasoning, alternatives considered, tradeoffs> -->
- **Decision**: 本轮只做调研与规划，不直接改业务代码。
  **Why**: request 明确要求先出“调研和优化报告”并通过 `/sspec-ask` 审查，避免方向偏差导致返工。
- **Decision**: `.sspec/skills` 作为唯一权威 hub，其他位置统一归类为 spoke 同步。
  **Why**: 当前 update 对 symlink/copy 判断分散，统一 hub 可显著降低状态分叉与迁移复杂度。
- **Decision**: Junction 仅作为 Windows 兼容手段，不能按 symlink 语义直接复用。
  **Why**: 现代码大量依赖 `Path.is_symlink()`；Junction 在该判断下不稳定，若混用会造成“已链接”误判。
- **Decision**: 在进入 DOING 前先解答用户对 Junction/Agent 识别与 gitignore 的顾虑。
  **Why**: 这两个问题直接影响策略默认值与 update 行为，属于方向性决策。
- **Decision**: 实现 `check_path_link` 作为统一入口，避免逻辑直接依赖 `Path.is_symlink()`。
  **Why**: 这样可兼容 symlink 与 junction，且便于后续把迁移决策集中到一个判定函数。
- **Decision**: `.gitignore` 改为 fence managed block。
  **Why**: 避免散落追加导致难维护，且方便 update 时幂等管理。
- **Decision**: `project init` 改为 deferred sync（core 先行）。
  **Why**: 符合 request 指定的交互顺序，减少初始化前置打断。
- **Decision**: 外部同步由“逐 skill 链接”改为“`xx/skills` 目录级链接”。
  **Why**: 与用户预期一致，且结构更简洁，便于 Agent/工具统一识别。
- **Decision**: Windows 回退链固定为 `symlink -> elevated symlink -> junction -> copy`。
  **Why**: 平衡无管理员场景可用性与链接优先策略。
- **Decision**: 外部位置未选择时强制 `.agent` 作为默认目录。
  **Why**: 用户要求“不允许不指定目录”，并希望给出可后续迁移的明确默认。
- **Decision**: update 候选新增 `is_skill` 语义，并对 copy-skill 引入 `modified` 保护。
  **Why**: 避免用 `strategy` 混用候选类型语义，并防止无 force 覆盖用户改动。
- **Decision**: 服务层改为调用安装器主实例接口，兼容静态 API 仅保留向后兼容角色。
  **Why**: 降低历史耦合，便于后续退场计划。
- **Decision**: 本 change 按用户确认标记 DONE，同时明确下个 Agent 继续做“代码巡检型”清理。
  **Why**: 当前目标已达成且已验收，但用户希望继续压缩历史残留风险。

### Gotchas & Context
<!-- Non-obvious findings, edge cases, implicit knowledge from discussions,
implementation cautions, and risk warnings.
Things you'd need to re-derive or re-discover if context were lost.
Project-wide learnings → ALSO append to project.md Notes. -->
- `project init` 当前在安装前强制交互选位置，和用户期望“先完成基本安装再询问”相反。
- `project update` 中 skills 候选目前默认按 copy 路径处理，且直接跳过 symlink 目录；迁移逻辑需单独设计。
- installer 已具备批量接口与提权尝试，但缺少“已存在目录迁移 + 备份 + 合并”的完整闭环。
- ask 结果已确认整体方向，可进入实现；但 Junction 与 gitignore 策略要先定稿再编码。
- 已完成目标中的两项明确要求：check_path_link 与 fenced .gitignore。
- `tests/test_project_update_service.py` 当前失败主要来自旧参数 `default_gitignore`，与本次改动并非同一问题域。
- 本轮已解决上述旧测试漂移问题，当前定向测试集共 13 项通过。
- 当前相关测试集（init/update/installer）共 27 项通过，lint 全绿。
- very-legacy 场景中已修复“需两次 update 才迁移”的问题；当前首轮即可迁移并完成 orphan 清理。
- 建议下个 Agent 按以下 checklist 巡检：
  1) 是否仍存在仅为兼容而长期未用的接口；
  2) update 候选状态在 force/non-force 下是否完全一致；
  3) docs 与 CLI 输出是否存在术语漂移（symlink/junction/link）；
  4) tests 是否覆盖 Windows 拒绝提权与 very-legacy 混合态。
