---
name: install-skill
status: DONE
type: ''
change-type: single
created: 2026-02-13 20:29:54
reference:
- source: .sspec/requests/archive/26-02-13T20-04_install-skill.md
  type: request
  note: Archived request
- source: .sspec/spec-docs/skill-installation.md
  type: doc
  note: Current SKILL installation architecture and migration spec
archived: '2026-02-24T23:38:34'
---
<!-- @RULE: Frontmatter Schema
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: single | sub (sub if part of a root change);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
📚 Full schema details: sspec-change SKILL → doc-standards.md
 -->

# install-skill

## A. Problem Statement
当前 SKILL 安装流程在 `project init` 阶段先进入交互式位置选择，再对每个 target 单独执行“尝试符号链接 → 失败复制”操作；在 Windows 下还会触发提权尝试，导致安装体验前置打断、失败路径分散、迁移逻辑难统一。该行为在多位置（`.claude/.github/.agent`）和历史项目迁移场景下，会放大为“安装策略不一致 + 更新行为不透明”的维护风险，直接影响 init/update 的可预测性与可回归性。

<!-- @RULE: Quantify pain. Format: "[metric] causing [impact]".
Simple changes: single paragraph. Complex: split "Current Situation" + "User Requirement".
📚 Standards: sspec-change SKILL → doc-standards.md -->

## B. Proposed Solution
本 change 采用“先稳定核心、再扩展安装位置”的两阶段方案：

1. 将 `.sspec/skills` 定义为唯一权威 hub，其他位置统一视为 spoke；
2. 将 spoke 逻辑升级为 `sync skills`（含识别、迁移、回退），而不是“仅创建链接”；
3. `project init` 先完成 `.sspec` 核心初始化并输出结果，再询问是否同步到外部位置；
4. `project update` 与 `init` 共用同一套 sync 决策与迁移逻辑，减少分叉实现。

该方案优于“继续堆叠单点安装分支”的原因：它把复杂度收敛到 installer/service 层，命令层只负责交互与展示，可显著降低后续升级和兼容成本。

### Approach
以 `src/sspec/skill_installer.py` 为中心引入“状态感知同步”：

- 目标路径不存在：优先 symlink；Windows 下失败后提供可选提权重试；仍失败则 copy。
- 目标路径已存在且是指向 hub 的链接：直接跳过。
- 目标路径是普通目录：先备份到 `.sspec/tmp/skills-backup/<timestamp>/`，合并第三方技能到 hub，再重建为链接/复制。

对 Windows Junction 的结论：
- Agent/文件遍历通常可“读取” Junction 目录内容；
- 但 Python `Path.is_symlink()` 对 Junction 不可靠（通常返回 `False`），会影响当前“是否链接”判定分支；
- 因此 Junction 可作为兼容回退，但必须显式用 reparse-point 检测并单独建模，不能假设它等价 symlink。

### Key Changes
- `src/sspec/commands/project.py`：调整 init 交互时序，核心初始化后再询问外部 skill sync。
- `src/sspec/services/project_init_service.py`：抽离“核心初始化”与“外部位置同步”，写入统一 metadata。
- `src/sspec/services/project_update_service.py`：复用 sync 识别/迁移逻辑，支持旧版项目平滑迁移。
- `src/sspec/skill_installer.py`：新增/重构 sync API（detect → backup/merge → relink/fallback）。
- `tests/test_project_init_service.py`、`tests/test_project_update_service.py`、`tests/test_skill_installer.py(新增)`：覆盖 symlink/junction/copy 与迁移路径。

## C. Implementation Strategy
### Phase 1: Research & Design（本轮）
- `.sspec/changes/archive/26-02-13T20-29_install-skill/reference/skill-sync-research.md` — create，记录现状调研、Windows link 语义、目标架构与迁移策略。
- `.sspec/changes/archive/26-02-13T20-29_install-skill/spec.md` — modify，固化问题定义与实施分解。
- `.sspec/changes/archive/26-02-13T20-29_install-skill/tasks.md` — modify，建立可执行任务与验证标准。
- `.sspec/changes/archive/26-02-13T20-29_install-skill/handover.md` — modify，沉淀本轮关键决策与后续切入点。
- `.sspec/asks/260213203325_skill_sync_strategy.py` — modify，向用户发起方案审查问询。

### Phase 2: Execution（待审查后）
- `src/sspec/skill_installer.py` — modify，实现统一 sync skills pipeline（detect/migrate/link/copy）。
- `src/sspec/services/project_init_service.py` — modify，拆分核心安装与外部同步流程。
- `src/sspec/services/project_update_service.py` — modify，新增旧项目迁移入口与策略复用。
- `src/sspec/commands/project.py` — modify，调整交互节奏与提示文案。
- `tests/test_project_init_service.py` — modify，验证 init 新交互与安装结果。
- `tests/test_project_update_service.py` — modify，验证 update 迁移与回退行为。
- `tests/test_skill_installer.py` — create，验证 symlink/junction/copy 及备份合并分支。

### Risks & Dependencies
- Windows Junction 与 symlink 判定差异需要明确 API 边界，否则会误判“已链接”。
- 提权交互若放在错误时机会再次破坏 init 体验；必须延后且可跳过。
- 目录迁移涉及用户已有 skill，必须先备份再清理，避免数据丢失。
- 依赖用户对方案确认（`sspec ask`）后再进入执行。

<!-- @RULE: File-level breakdown. Format:
### Phase N: <n>
- `path/file.py` — create|modify, <what>

### Risks & Dependencies
- <external deps, risks, mitigation>
📚 Standards: sspec-change SKILL → doc-standards.md -->

## D. Blockers & Feedback
### Feedback (2026-02-13)
用户要求：先完成 request → change，随后做“深入调研 + 优化报告”，并通过 `/sspec-ask` 发起方案审查后再执行代码改动。

### Feedback (2026-02-13, ask: 260213203325_skill_sync_strategy)
用户已确认：
- 目录存在时先备份并合并迁移（Q2）
- init 改为“先安装核心再询问同步”（Q3）
- 审查后可进入执行（Q4）

用户新增关切：
- Junction 是否应默认启用，以及 Agent 对 Junction 目录识别可靠性
- 更新后 `skills` 与 `.copilot/.agent/...` 的 `.gitignore` 策略

### Feedback (2026-02-13, ask: 260213232710_install_skill_bugfix_review_v4)
用户在 very-legacy 场景复测发现：首次 update 仅完成 orphan 处理，第二次才迁移外部 skills 布局。
已定位并修复迁移检测条件与备份策略，确保首轮即可迁移，并避免 Windows 1314 权限错误。

### Feedback (2026-02-13, deep cleanup)
按用户要求完成源码深度审计，清理历史残留：
- 服务层改用安装器主接口，降低对兼容静态 API 的耦合；
- update 候选语义补齐 `is_skill` 与 `modified` 保护；
- 形成项目级 spec-doc 记录新旧方案与迁移策略。

### Feedback (2026-02-14, ask: 260214002722_install_skill_cleanup_review_v5)
用户确认本 change 可完成（"可以，请标注 DONE"），并要求在 handover 中明确交接给下个 Agent 继续做代码巡检与潜在旧逻辑清理。

### Open Question (2026-02-13)
**Question**: Windows Junction 是否应作为正式策略。
**Current Position**: 可作为兼容回退，但需要独立检测分支，不与 symlink 混用判定。

### Open Question (2026-02-13)
**Question**: `.gitignore` 在 hub 与 spoke 位置如何统一。
**Current Position**: 待在执行前固定规则（建议只忽略目录名 `skills/`，不忽略父目录）。

<!-- @RULE: Record with dates. Format:
### Blocker (YYYY-MM-DD)
**Blocked**: <what> | **Needed**: <to unblock>

### PIVOT (YYYY-MM-DD)
<direction change and reason>
-->
