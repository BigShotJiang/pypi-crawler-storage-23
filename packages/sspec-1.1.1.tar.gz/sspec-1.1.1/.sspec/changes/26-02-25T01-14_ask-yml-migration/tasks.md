---
change: "ask-yml-migration"
updated: "2026-02-25T01:32:00"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks
### Phase 1: Service layer migration (`ask_service`) 🚧
- [x] Replace `create_ask_template` output from `.py` to `.yml` in `src/sspec/services/ask_service.py`
- [x] Add YAML read/write path for prompt and answer persistence in `src/sspec/services/ask_service.py`
- [x] Keep legacy `.py` compatibility path in `src/sspec/services/ask_service.py`
- [x] Support `.yml/.py` conversion in `convert_ask_to_md` in `src/sspec/services/ask_service.py`
**Verification**: `tests/test_ask_service.py` passes for yml primary flow and legacy py compatibility.

### Phase 2: CLI behavior update (`ask` command) ⏳
- [x] Allow `.yml` prompt input and keep `.py` legacy support in `src/sspec/commands/ask.py`
- [x] Update list output to include `.yml` pending files in `src/sspec/commands/ask.py`
- [x] Update CLI text/help to reflect yml workflow in `src/sspec/commands/ask.py`
**Verification**: local CLI flow `ask create -> ask prompt -> ask list` matches expected behavior.

### Phase 3: Tests + docs sync ⏳
- [x] Update ask service tests to yml-first with legacy py compatibility in `tests/test_ask_service.py`
- [x] Update user docs for ask format change in `README.md` and `README_zh-CN.md`
- [x] Update template skill docs in `src/sspec/templates/skills/sspec-ask/SKILL.md`
**Verification**: `uv run pytest tests/test_ask_service.py` and relevant doc references show `.yml` as primary.

<!-- @RULE: Organize by phases. Each task <2h, independently testable.
Phase emoji: ⏳ pending | 🚧 in progress | ✅ done

### Phase 1: <name> ⏳
- [ ] Task description `path/file.py`
- [ ] Task description `path/file.py`
**Verification**: <how to verify this phase>

### Feedback Tasks
Use this section for tasks added during review/feedback loop.
-->

---

## Progress
**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |

**Recent**:
- Implemented yml-first ask service with py legacy compatibility.
- Updated ask CLI for `.yml/.py` prompt and pending list behavior.
- Updated tests and docs; validation passed (ruff + pytest focused run).
- Completed sandbox smoke test: `sspec project init` and `sspec ask create/prompt` with `.yml` pending ask file.
