# Handover: ask-yml-migration

**Updated**: 2026-02-25T01:32:00

---

## Background
Migrate sspec ask pending file format from executable `.py` to data-only `.yml`, while preserving final `.md` ask records and backward compatibility for legacy `.py` asks. The goal is lower risk and better maintainability without breaking current workflows.

## This Session

### Accomplished
- Created change `26-02-25T01-14_ask-yml-migration`.
- Completed design and implementation plan in `spec.md` and `tasks.md`.
- Implemented yml-first ask flow in `src/sspec/services/ask_service.py` with legacy py support.
- Updated CLI behavior in `src/sspec/commands/ask.py` for `.yml/.py` prompt input and pending file list.
- Updated docs in `README.md`, `README_zh-CN.md`, and template skill `src/sspec/templates/skills/sspec-ask/SKILL.md`.
- Updated regression coverage in `tests/test_ask_service.py`.
- Verification completed: `uv run ruff check ...` and `uv run pytest tests/test_ask_service.py` both pass.
- Template workflow verification completed: `uv pip install -e .`, sandbox `sspec project init`, and sandbox `sspec ask create/prompt` smoke test confirm `.yml -> .md` flow.

### Next Steps
1. User review and acceptance.
2. If accepted, move change status to `REVIEW`/`DONE` per workflow and archive when appropriate.
3. Optional: add CLI integration tests for `ask create/prompt/list` command path.

## Working Memory
<!-- Agent's external memory. Survives context compression and session boundaries.
Update PROACTIVELY: important decision, key file found, non-obvious insight.
Test: "Would I struggle to reconstruct this after losing context?" → Write NOW. -->

### Key Files
- `.sspec/changes/26-02-25T01-14_ask-yml-migration/spec.md` — approved migration design and compatibility policy.
- `.sspec/changes/26-02-25T01-14_ask-yml-migration/tasks.md` — phased execution checklist and verification gates.
- `src/sspec/services/ask_service.py` — core ask format parsing and conversion logic.
- `src/sspec/commands/ask.py` — user-facing ask CLI behavior.
- `tests/test_ask_service.py` — primary regression and behavior validation for migration.

### Decisions
- **Decision**: Use `.yml` as primary pending ask format, retain `.py` support during transition.
  **Why**: remove executable-file dependency immediately while avoiding breaking in-flight legacy ask files.
- **Decision**: keep completed ask record format `.md` unchanged.
  **Why**: preserve existing archive and link-update behavior, minimizing migration surface.

### Notes
- Docs and skill template currently hard-code `.py` workflow, so migration is incomplete unless template docs are updated.
- `ask_service` now handles unsupported suffixes explicitly and keeps `.md` fallback behavior when pending file is already converted.
