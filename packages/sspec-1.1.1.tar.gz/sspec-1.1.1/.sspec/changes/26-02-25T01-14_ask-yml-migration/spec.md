---
name: ask-yml-migration
status: REVIEW
type: "enhancement"
change-type: single
created: 2026-02-25T01:14:22
reference: null
---

<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: single | sub
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>

Sub-change MUST link root:
reference:
  - source: ".sspec/changes/<root-change-dir>"
    type: "root-change"
    note: "Phase <n>: <phase-name>"

Single-change common reference:
reference:
  - source: ".sspec/requests/<request-file>.md"
    type: "request"
-->

# ask-yml-migration

## A. Problem Statement
Current ask workflow stores pending ask files as Python modules (`.py`) and executes them via dynamic import in `ask_service.py`. This makes a data record depend on code execution and raises avoidable risk in self-hosting and user projects. At the same time, user-facing docs and SKILL guidance currently describe `.py` ask files, causing tooling and documentation coupling around executable files.

User requirement is to complete this task under sspec workflow: migrate ask pending files to YAML while preserving existing CLI behavior (`create -> prompt -> record .md`) and keeping compatibility with historical `.py` asks during transition.

<!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->

## B. Proposed Solution
### Approach
Switch pending ask format from executable `.py` to structured `.yml` and treat ask files strictly as data. `sspec ask create` generates a YAML template with fields (`created`, `reason`, `question`, `user_answer`). `sspec ask prompt` loads YAML safely, collects answer or reuses `user_answer`, persists answer back to YAML, then converts to `.md` and removes pending file as before.

Keep legacy compatibility in service layer: existing `.py` asks can still be prompted and converted. This avoids breaking in-flight users and allows gradual migration without separate one-shot conversion command.

### Key Design
#### Interface Design
- `create_ask_template(sspec_root, name) -> (Path, warning)` now creates `.yml` pending files.
- `execute_ask_prompt(ask_file_path)` supports `.yml` as primary and `.py` as legacy.
- `save_ask_answer(ask_file_path, answer)` writes `answer` into YAML or appends legacy `ANSWER` for `.py`.
- `convert_ask_to_md(ask_path)` supports `.yml/.py` and outputs same `.md` structure.

#### Data Model
Pending YAML schema:
- `created: str` ISO timestamp
- `reason: str`
- `question: str`
- `user_answer: str` (optional prefill)
- `answer: str` (written at prompt stage)

Completed `.md` schema remains unchanged (`created`, `name`, `why` frontmatter + answer/question history body).

#### Logic Flow
1. `ask create <name>` creates `.sspec/asks/<timestamp>_<name>.yml`.
2. User edits `reason/question` and may prefill `user_answer`.
3. `ask prompt <file>` resolves format:
  - `.yml`: parse with `yaml.safe_load`
  - `.py`: legacy dynamic import path
4. Answer determined by `user_answer` or terminal input.
5. Persist answer to pending file, convert to `.md`, delete pending source.
6. `ask list` shows pending `.yml` and legacy `.py`.
