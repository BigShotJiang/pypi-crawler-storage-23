---
created: '2026-02-15T21:46:03'
name: spec_redesign_b_vs_c
why: '用户指出了根本问题：问题不在于 C vs tasks.md，而在于 B vs C 的边界不清晰。

  特别是"接口定义、数据模型"应该放在哪里？Design 是 B 还是 C？'
---

**Ask**: spec_redesign_b_vs_c

# User Answer #

看起来 Ok

请你尝试修改相关的 template, skill 等
注意：可以增加一点，如果设计复杂，可以在 reference 下创建详细的 spec design（参考 write spec doc 的写作风格）然后在 spec.md 中引用
以及 Part C 每个 Phase 就算复杂还是至少要提到大致会修改哪些相关文档，只是不会如 task 那样明确细分拆解

---

我不清楚这个改动了有多大，如果需要你可以发起一个 change，或者是在 request file 中的 micro change

# Agent Question History #

# spec.md 整体重新设计 — B vs C 边界

## 核心洞察

你的质疑完全正确！我之前的分析有根本性遗漏：

**问题不在于 C vs tasks.md，而在于 B vs C 的边界不清晰。**

## 重新调研结果

我重新分析了实际案例（tools, install-skill）和当前标准，发现：

### 良好实践（tools 案例）

**Section B** 包含了：
- Tool Interface 1.0 定义（明确列出 4 个接口）
- 为什么选这个接口（Why this interface?）
- 注册策略（当前 vs 未来）

**Section C** 只是：
- 执行拆解："add TOOL_* constants"（引用 B 的设计，不重复）

### 当前标准的问题

doc-standards.md 对 B 的标准太简单：
- 只说"Approach + rationale"
- **没有明确说"接口定义、数据模型、核心算法"应该在 B 中**

## 修正后的定位

### Section B: Proposed Solution (Design)

**职责**：设计文档 — What & Why

**应该包含**：
1. **Approach**: 核心方案思路
2. **Why this approach**: 为什么选这个方案
3. **🔑 Interface Design**: 函数签名、类结构、API contracts
4. **🔑 Data Model**: 核心数据结构、状态机、数据流
5. **🔑 Key Logic**: 关键算法、边界条件、伪代码
6. **Key Changes**: 主要模块变更

**复杂度分级**：
- 简单（≤5 files）: 接口/数据模型简述在 Approach 中
- 复杂（>5 files）: 专门小节（### Interface Design）
- 超复杂（>15 files）: 放在 reference/design.md，B 中引用

---

### Section C: Implementation Strategy (Execution Plan)

**职责**：执行计划 — How to execute

**应该包含**：
1. **Phase Division**: 如何拆分实施步骤
2. **File Scope per Phase**: 每个 phase 涉及哪些文件 + 简述做什么
3. **Dependencies**: phases 之间的依赖
4. **Risks & Mitigations**: 技术风险

**不应该包含**：
- 接口定义的细节（这在 B 中）
- 数据模型的细节（这在 B 中）
- 核心算法的逻辑（这在 B 中）

**应该引用 B**：
- "实现 B 中定义的 Tool Interface 1.0"
- "按 B 中描述的三种场景逻辑实现"

---

## 修正方案

详见：`.sspec/tmp/spec-redesign-b-vs-c.md`（包含完整示例对比）

核心调整：
1. **扩展 Section B 标准** — 明确说"接口/数据模型/核心逻辑"应该在 B 中
2. **明确 B vs C 边界** — B = Design (What & Why), C = Plan (How to execute)
3. **更新模板 @RULE** — B 中提示接口/数据模型，C 中提示引用 B
4. **提供对比示例** — Before/After，简单/复杂场景

## 问题

1. **这个定位是否符合你的预期**？
   - Section B 包含接口/数据模型/核心算法
   - Section C 引用 B 的设计，只描述执行拆解

2. **复杂度分级是否合理**？
   - 简单：inline in Approach
   - 复杂：dedicated subsection in B
   - 超复杂：reference/ + link from B

3. **还有其他遗漏的设计元素吗**？（除了接口/数据模型/核心逻辑）

详细分析和示例见：`.sspec/tmp/spec-redesign-b-vs-c.md`