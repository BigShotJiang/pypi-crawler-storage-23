---
created: '2026-02-12T01:26:56'
name: tools_redesign_philosophy
why: 'User feedback: need deeper thinking on Tool''s positioning and registration
  mechanism.

  Redesigned from first principles, need validation.'
---

**Ask**: tools_redesign_philosophy

# User Answer #

看起来基本可行，但是我建议：
最好设计一套 Tool 统一遵守的数据模型接口规范；不用太复杂，关键在于如果日后用得上可以从这个基础上扩展，也就是做好 minmal 的 1，日后才能逐步 +1

此外，建议这个工具在 --help 的时候打印规范 PROMPT，这样用户可以 copy 进去让外部 LLM 按照相同规范来编写 patch

此外还可以做一个独立的 write-patch SKILL （注意需要参考 skill creator skill 和当前 sspec 内置 SKILL 的写作风格）

不知你觉得如何

# Agent Question History #

我重新从第一性原理思考了 Tool 的定位，得出了一个更简单的设计。

## 核心判断：Tool 不需要注册机制

**理由**:
1. YAGNI: 现在只有 patch，不需为"未来可能"过度设计
2. KISS: 直接硬编码子命令清晰明了
3. tool 和 cmd 的区别本质上是实现机制不同：
   - `cmd`: 数据驱动（用户的 YAML 注册表，project-specific）
   - `tool`: 代码驱动（硬编码的 Click 子命令，builtin cross-project）
   - 完全不同的机制，概念清晰不混淆

## 简化后的架构

```python
# commands/tool.py (全部逻辑)
@click.group()
def tool():
    """Builtin development tools."""
    pass

@tool.command()
@click.argument('patch_file', type=click.Path(exists=True))
@click.option('--dry-run', is_flag=True)
@click.option('--output-failed', type=click.Path())
@click.option('--yes', is_flag=True)
def patch(patch_file, dry_run, output_failed, yes):
    """Apply SEARCH/REPLACE patches."""
    from sspec.builtin_tools.apply_patch import apply_patches
    # 直接调用，Rich 输出，保存失败的 patches
```

- **无需** service 层（过度封装）
- **无需** 注册机制
- 未来添加工具 = 添加新子命令

## Patch 命令详细设计（之前缺失的）

### CLI 接口
```bash
sspec tool patch <patch-file> [OPTIONS]

Options:
  --dry-run              Preview without applying
  --output-failed DIR    Custom dir for failed patches
                         (default: .sspec/tmp/failed-patches/<timestamp>)
  --yes                  Skip confirmation
```

### 交互流程
1. 读取 + 解析 patch 文件（失败 → 显示错误退出）
2. 显示预览（如果不带 --yes）：
   ```
   Found 3 patches:
     ✓ src/core.py (L10-L25)
     ✓ src/utils.py
     ✓ tests/test_core.py
   Apply? [y/N]:
   ```
3. 应用 patches（Rich 进度条）
4. 显示结果表格（Rich Table）：成功 ✓ 绿色，失败 ✗ 红色
5. 保存失败的 patches 到 output 目录，显示路径

### 示例输出
```
✓ Found 3 patches

Applying... [████████░░] 60% (2/3)

Results:
┏━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┓
┃ File         ┃ Status ┃ Note         ┃
┡━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━┩
│ src/core.py  │ ✓      │ Applied      │
│ src/utils.py │ ✗      │ No match     │
└──────────────┴────────┴──────────────┘

Failed patches → .sspec/tmp/failed-patches/2026-02-12T01-30-45/
```

**详细设计文档**: .sspec/changes/archive/26-02-12T01-19_tools/reference/redesign-philosophy.md

## 问题

1. 同意这个"无注册机制，直接硬编码子命令"的简化设计吗？
2. Patch 命令的交互流程是否符合预期？
3. 还有其他需要考虑的边界情况吗？