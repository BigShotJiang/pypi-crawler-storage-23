---
created: '2026-02-05T15:22:05'
name: skill_update_design
why: '完成 Phase 1-4 后，进入关键的 Phase 5 文档更新阶段。

  已详细阅读 skill-creator SKILL 和 Claude 官方最佳实践。

  现在需要和用户确认 SKILL 更新方案设计。'
---

# Ask: skill_update_design

## Question

# SSPEC SKILL 更新设计方案

我已完成前4个阶段（md_yaml库、命名规范、reference系统、ask UX），现在进入 Phase 5 文档更新。基于阅读的 skill-creator SKILL 和 Claude Best Practices，我设计了以下方案：

---

## 1. 设计原则（遵循 Claude Best Practices）

### ✅ Progressive Disclosure
- **SKILL.md**: 保持 <500 行，作为总览和导航
- **Separate files**: 复杂内容分离到独立文件
- **One-level deep**: 所有 reference 直接从 SKILL.md 链接，避免嵌套

### ✅ Conciseness
- 假设 Claude 很聪明，只提供非显然的信息
- 用具体示例代替冗长解释
- 挑战每句话："这真的必要吗？"

---

## 2. 当前 sspec SKILL 分析

**现状**:
- [src/sspec/templates/skills/sspec/SKILL.md](../../src/sspec/templates/skills/sspec/SKILL.md): ~198 行
- 内容: 文档质量标准、辅助目录、状态转换规则、边缘情况

**问题**:
- ❌ 缺少 multi-change 管理指导
- ❌ Frontmatter reference 规则没有明确说明
- ❌ 部分内容可能过于冗长

---

## 3. 提议的更新方案

### 方案 A：在 SKILL.md 中增加 Multi-Change 小节（推荐）

**结构**:
```markdown
src/sspec/templates/skills/sspec/
├── SKILL.md (~300 lines)
│   ├── [现有内容]
│   ├── **NEW: Multi-Change Management** (~50 lines)
│   └── **NEW: Frontmatter Reference Rules** (~30 lines)
└── [现有其他部分保持不变]
```

**Multi-Change Management 小节内容**:
```markdown
## Multi-Change Management

**When to use**: Complex features requiring >3 weeks, multiple sub-systems, or >30 tasks.

### Pattern: Root + Sub-Changes

1. **Create root change** to coordinate overall effort:
   - Tasks.md: High-level phases
   - Reference/: Design docs, architecture diagrams
   - Script/: Shared migration scripts

2. **Create sub-changes** for each phase:
   - Link via `reference` field: `{source: "changes/<root>", type: "sup-change"}`
   - Each sub-change: focused, archivable independently

3. **Workflow**:
   - Complete sub-change → archive → create next
   - Root change stays active until all subs done

### Example
Root: `26-02-05T14-00_auth-overhaul` (coordinator)
- reference/: `design.md`, `api-migration.md`
- tasks.md: "Phase 1: JWT impl → Phase 2: LDAP → Phase 3: Migrate"

Sub-1: `26-02-10T09-00_jwt-implementation` (focused)
- reference: `[{source: "changes/26-02-05T14-00_auth-overhaul", type: "sup-change"}]`

Sub-2: `26-02-17T14-00_ldap-integration`
- reference: `[{source: "changes/26-02-05T14-00_auth-overhaul", type: "sup-change"}]`
```

**Frontmatter Reference Rules**:
```markdown
## Frontmatter Reference Field

### Structure
```yaml
reference:
  - source: "requests/26-02-05T14-00_feature-request.md"  # Relative to .sspec/
    type: "request"  # 'request' | 'sub-change' | 'sup-change' | 'doc'
    note: "Original feature proposal"  # Optional
```

### Auto-populated by CLI
- `sspec request link <req> <chg>`: Adds request reference to change
- `sspec change new --from <req>`: Creates change with request reference

### Manual usage
- Link to related changes: `type: "sub-change"` or `"sup-change"`
- Link to spec-docs: `type: "doc"`
```

**优点**:
- ✅ 保持在500行内（现有198 + 新增80 ≈ 278 行）
- ✅ 单文件，查找方便
- ✅ 符合 "simple skill = single SKILL.md" 原则

**缺点**:
- ⚠️ 如果未来继续扩展，可能需要分离

---

### 方案 B：Progressive Disclosure（分离文件）

**结构**:
```markdown
src/sspec/templates/skills/sspec/
├── SKILL.md (~220 lines)
│   ├── [现有核心内容]
│   └── Links to:
│       - "Multi-change: See [multi-change.md](multi-change.md)"
│       - "Reference rules: See [frontmatter.md](frontmatter.md)"
├── multi-change.md (~80 lines)
└── frontmatter.md (~50 lines)
```

**优点**:
- ✅ 符合 progressive disclosure 原则
- ✅ 未来可扩展

**缺点**:
- ⚠️ 增加文件数量（当前只需简单指导）
- ⚠️ 对于简单场景可能过度设计

---

## 4. AGENTS.md 更新内容

无论选哪个方案，AGENTS.md 都需要简要提及 reference：

**Section 2.2 Directives - @change**:
```markdown
#### `@change <name>`

If `.sspec/changes/<name>/` exists:
- Read handover.md → tasks.md → spec.md
- **Check `reference` field for linked requests/changes**  # NEW
- If reference/ exists: Scan for context
- ...
```

**Section 2.3 Edit Rules** (table):
```markdown
| Marker | Meaning | Action |
|--------|---------|--------|
| `<!-- @RULE: Frontmatter ... -->` | **NEW** | Follow rules for frontmatter fields like `reference` |
```

---

## 5. 我的推荐

**选择方案 A** (在 SKILL.md 中增加小节)

**理由**:
1. 当前内容简单，不需要文件分离
2. Multi-change 和 frontmatter 规则是核心知识，应该在主文件
3. 总行数 <300，远低于500行限制
4. 符合 "默认简单，需要时才分离" 原则

---

## 你的决定

请选择：
1. **方案 A** (SKILL.md 增加小节) - 我推荐
2. **方案 B** (分离文件)
3. **其他建议**

同时，请检查：
- Multi-Change Management 小节的内容是否合适？需要调整吗？
- Frontmatter Reference Rules 是否清晰？
- AGENTS.md 的更新是否足够？还是需要更多细节？

## Answer

我也觉得 A 更好。
而且我建议在 sspec skill 开头就提醒，如果是复杂的任务，建议分拆多个 change , 参考 blablabla
（或者可以在 强化 change 的工作量规范定义？比如 < threshold -> single change, else -> multi change)

第二，">3 weeks" 可以缩窄到 1 weeks

第三，Agents.md 中可以提及，如果是复杂变更，可以使用 sspec ask 建议用户拆分多个 change

就 SKILL 改动而言，我不建议放在最后。可以放在更前面的地方，开头再说 change 里面文档应该如何编写，后面说 single vs multi 之类的

不成熟的想法："Document Quality Standards" + "Auxiliary Directories" 可以合并成一个叫 "Single Change Specification" 专门说 change 要怎么写。后面增加一个 change system（可以换个名称，这个意思感觉不到位），告诉 Agent 如何决策管理 change 系统，包括 multi change

以及请审阅后面的 Edge Cases， Anti pattern, check list 等看是否值得优化

此外：尽管官方说 "假设 Claude 很聪明，只提供非显然的信息"，但是我们不一定总是使用最好的 Claude，可以稍微下降一点点的标准，允许 Deepseek Gemini-Flash 这种次顶级模型也能利用 SKILL（但也不能降低标准太严重）

我的回答比较混乱可能不成体系，请深入思考，从第一性原理出发梳理我的表达的意图
