---
created: '2026-02-13T22:57:19'
name: install_skill_final_review_v3
why: 'User requested continuous improvement in /auto mode and asked to run another

  ask after implementing the newly raised issues.'
---

**Ask**: install_skill_final_review_v3

# User Answer #

测试发现存在问题
```
uv run sspec project update
❯❯❯ uv run sspec project update
Traceback (most recent call last):
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 196, in _run_module_as_main
    return _run_code(code, main_globals, None,
  File "G:\Enviroment\Python\Python310\lib\runpy.py", line 86, in _run_code
    exec(code, run_globals)
  File "H:\SrcCode\playground\sspec\.venv\Scripts\sspec.exe\__main__.py", line 10, in <module>
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1485, in __call__
    return self.main(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1406, in main
    rv = self.invoke(ctx)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1873, in invoke
    return _process_result(sub_ctx.command.invoke(sub_ctx))
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 1269, in invoke
    return ctx.invoke(self.callback, **ctx.params)
  File "H:\SrcCode\playground\sspec\.venv\lib\site-packages\click\core.py", line 824, in invoke
    return callback(*args, **kwargs)
  File "H:\SrcCode\playground\sspec\src\sspec\commands\project.py", line 256, in update
    migrations = migrate_legacy_skill_layouts(
  File "H:\SrcCode\playground\sspec\src\sspec\services\project_update_service.py", line 111, in migrate_legacy_skill_layouts
    shutil.copytree(location_path, backup_path, symlinks=True)
  File "G:\Enviroment\Python\Python310\lib\shutil.py", line 556, in copytree
    return _copytree(entries=entries, src=src, dst=dst, symlinks=symlinks,
  File "G:\Enviroment\Python\Python310\lib\shutil.py", line 512, in _copytree
    raise Error(errors)
shutil.Error: [('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\sspec-ask', 'H:\\SrcCode\\playground\\sspe
c\\tmp\\sspec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\sspec-ask', "[WinError 1314] 客户端没有所需的特权。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\sspec-ask' -> 'H:\\\\SrcCode\\\\p
layground\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\sspec-ask'"), ('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\sspec-change', 'H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\sspec-change', "[WinError 1314] 客户端没有所需的特权。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\sspec-change' -> 'H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\sspec-change'"), ('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\sspec-memory', 'H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\sspec-memory', "[WinError 1314] 客户端没有所需的特权。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\sspec-memory' -> 'H:\\\\SrcCode\\\\playgr
ound\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\sspec-memory'"), ('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\use-powershell', 'H:\\SrcCode\\playground\\sspec\\tmp\\ss
pec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\use-powershell', "[WinError 1314] 客户端没有所需的特权 。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\use-powershell' -> 'H:\\\\SrcCode\\\\
playground\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\use-powershell'"), ('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\write-patch', 'H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\write-patch', "[WinError 1314] 客户端没有所需的特 权。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\write-patch' -> 'H:\\\\SrcCode\\\\p
layground\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\write-patch'"), ('H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.claude\\skills\\write-spec-doc', 'H:\\SrcCode\\playground\\sspec\\tmp\\sspec-legacy-project\\.sspec\\tmp\\skills-backup\\20260213225644\\.claude_skills\\write-spec-doc', "[WinError 1314] 客户端没有所需的 特权。: '\\\\\\\\?\\\\H:\\\\SrcCode\\\\playground\\\\sspec\\\\tmp\\\\tmp-sspec\\\\.sspec\\\\skills\\\\write-spec-doc' -> 'H:\\\\SrcCode
\\\\playground\\\\sspec\\\\tmp\\\\sspec-legacy-project\\\\.sspec\\\\tmp\\\\skills-backup\\\\20260213225644\\\\.claude_skills\\\\write-spec-doc'")]
```

建议：扫描 skill ，如果有链接，就检查末尾是否指向某个在 .sspec/skill/xxx 的如果是，就直接删除
不知这样是否能解决问题

# Agent Question History #

本轮根据你最新反馈完成了这些修复：

1) Windows 选择策略
- 在选择外部目录后，Windows 会询问是否提权创建 symlink；
- 选择否：不提权，直接走 junction（失败再 copy）。

2) 外部目录不可为空
- 交互里如果未选择任何目录（或取消），会警告并强制使用 `.agent`；
- 同时提示后续可迁移到 `.claude/.github`。

3) update 兼容旧行为
- 新增 legacy 布局迁移：识别旧版“逐 skill 子链接”，
	自动备份到 `.sspec/tmp/skills-backup/...`，
	合并自定义 skill 到 hub，再重建为目录级 spoke。

4) 测试与质量
- 修复了 `tests/test_project_init_service.py` 过时签名问题；
- 当前相关测试：27 passed；
- 相关 lint：all passed。

请确认：
- A. 通过，可进入 REVIEW（若你愿意我再补一轮手工回归记录）
- B. 基本通过，但还要调整（请列点，我继续改）
- C. 不通过（请给复现步骤，我继续修）