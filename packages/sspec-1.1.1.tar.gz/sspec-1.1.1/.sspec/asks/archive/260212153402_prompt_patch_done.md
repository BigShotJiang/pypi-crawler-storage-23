---
created: '2026-02-12T15:34:02'
name: prompt_patch_done
why: 'Work is implemented for:

  - `sspec tool prompt` fullscreen editor + fixed bottom command line

  - `sspec tool patch` new `--input/-i` + `--file/-f` + per-patch detailed output
  with `# header`


  Need your confirmation that the UX matches your expectation, and whether any small
  tweaks are wanted.'
---

**Ask**: prompt_patch_done

# User Answer #

sspec tool patch 看起来是正确的，这个过关

sspec tool prompt 的 UI 很好，但是也有问题：

1. 缺少提示，比如有哪些指令等
2. @ 文件自动补全失效了，之前只要输入就会推荐匹配文件名（类似 claude code 里面的行为）
3. Paste 多行文本出现缩进混乱问题，比如这样

```
┌─────────────────────────────────────────────────────────────────────────| prompt |──────────────────────────────────────────────────────────────────────────┐
│# pyproject.toml                                                                                                                                            ^│
│<<<<<<< SEARCH                                                                                                                                               │
│dependencies = [                                                                                                                                             │
│    "click>=8.0",                                                                                                                                            │
│        "rich>=13.0",                                                                                                                                        │
│            "pyyaml>=6.0",                                                                                                                                   │
│                "python-dotenv>=1.0.0",                                                                                                                      │
│                    "questionary>=2.1.1",                                                                                                                    │
│                        "prompt_toolkit>=3.0.48"                                                                                                             │
│                        ]                                                                                                                                    │
│                        =======                                                                                                                              │
│                        dependencies = [                                                                                                                     │
│                            "click>=8.0",                                                                                                                    │
│                                "rich>=13.0",                                                                                                                │
│                                    "pyyaml>=6.0",                                                                                                           │
│                                        "python-dotenv>=1.0.0",                                                                                              │
│                                            "questionary>=2.1.1",                                                                                            │
│                                                "prompt_toolkit>=3.0.48",                                                                                    │
│                                                    "pathspec>=0.12.0"                                                                                       │
│                                                    ]                                                                                                        │
│                                                    >>>>>>> REPLACE                                                                                          │
│
```

# Agent Question History #

Please confirm:

1) Does `sspec tool prompt` feel “清爽丝滑” now?
	- If not, what 1-2 specific tweaks do you want (e.g. frame/title, status bar text, command-line prompt style)?

2) For `sspec tool patch`:
	- Is the default input behavior correct (no file -> interactive; empty input -> skipped)?
	- Is the per-patch results table sufficient (header/match/delta/note)?

Reply with “OK” if accepted, or list the tweaks.