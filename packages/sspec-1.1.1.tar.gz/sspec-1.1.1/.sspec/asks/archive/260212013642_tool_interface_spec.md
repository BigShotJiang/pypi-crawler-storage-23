---
created: '2026-02-12T01:36:42'
name: tool_interface_spec
why: 'User requested minimal but extensible tool interface specification.

  Need to confirm the proposed design before implementation.'
---

**Ask**: tool_interface_spec

# User Answer #

可以，这个设计我同意

SKILL 也在这个 change 解决，本来也不是太复杂的 change，只不过我们讨论了不少罢了

注：这个 change 的 handover 中引用我们 ask 过的文档

# Agent Question History #

我设计了一个 Minimal Tool Interface 1.0 规范，兼顾当前简单和未来扩展。

## Minimal Interface（每个 tool 模块提供）

```python
# builtin_tools/apply_patch.py

# 1. Metadata
TOOL_NAME = "patch"
TOOL_DESCRIPTION = "Apply SEARCH/REPLACE format patches"
TOOL_PROMPT = """<详细规范和示例>"""  # 现有的 PATCH_PROMPT

# 2. Registration function
def register_command(group: click.Group) -> None:
    @group.command(name=TOOL_NAME, help=TOOL_DESCRIPTION)
    @click.option('--prompt', is_flag=True, help='Show format spec')
    # ... other options
    def patch_command(...):
        if prompt:
            console.print(TOOL_PROMPT)
            return
        # ... actual logic
```

## Registration（现在手动，未来可扩展）

```python
# commands/tool.py
from sspec.builtin_tools import apply_patch

@click.group()
def tool():
    """Builtin development tools."""
    pass

apply_patch.register_command(tool)  # 手动注册，清晰
```

**未来扩展**: 3 行代码切换到自动发现（importlib + 遍历 builtin_tools/）

## Prompt Display（混合方式）

方案 A（❌太长）: 把 TOOL_PROMPT 全部放在 --help 里
方案 B（✅推荐）: 独立的 --prompt 选项显示完整规范

```bash
$ sspec tool patch --help
... (简洁的常规帮助)

$ sspec tool patch --prompt
<完整 PATCH_PROMPT 规范>  # LLM 可 copy 使用
```

## Write-Patch SKILL

另外创建 `.github/skills/write-patch/SKILL.md`:
- 描述: Guide for writing SEARCH/REPLACE patches for code changes
- 内容: 参考 PATCH_PROMPT + skill-creator 风格
- 触发: 当 LLM 需要生成 patch 时

## 核心优势

**现在**:
- ✅ Minimal（4 个接口）、清晰、自包含
- ✅ Prompt 可访问（--prompt）
- ✅ 手动注册简单

**未来**:
- 🔮 自动发现（3 行改动）
- 🔮 工具列表（sspec tool list）
- 🔮 插件机制（third-party tools）

**详细文档**: .sspec/changes/archive/26-02-12T01-19_tools/reference/tool-interface-spec.md

## 问题

1. 这个 Minimal Interface 设计是否符合"做好 minimal 1，未来能 +1"的要求？
2. --prompt 方式显示规范是否合适？还是有更好的方式？
3. Write-patch SKILL 是在这个 change 中一起实现，还是单独创建？