---
created: '2026-02-13T23:27:10'
name: install_skill_bugfix_review_v4
why: 'User reported a concrete runtime crash in `sspec project update`; after fixing,

  I need confirmation whether behavior now matches expectation or needs more work.'
---

**Ask**: install_skill_bugfix_review_v4

# User Answer #

遇到一个怪事，我用在本次重构开始前的版本（真正的旧版）测试，然后发现奇怪现象：要两次才能正确迁移

```powershell
H:\SrcCode\playground\sspec\tmp\sspec-very-legacy                                        refactor/skills  👾  (sspec)  Ⓜ 22GiB/31GiB
❯❯❯ uv run sspec project update

      Orphaned Skills (no longer in templates)
┏━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Skill ┃ Locations                                 ┃
┡━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ sspec │ .github\skills\sspec, .sspec\skills\sspec │
└───────┴───────────────────────────────────────────┘
  - Removed orphaned skill "sspec" (2 location(s))

                        Update Status
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━┓
┃ File                                  ┃ Status    ┃ Action ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━┩
│ .sspec\skills\sspec-ask\SKILL.md      │ updatable │ update │
│ .github\skills\sspec-change\SKILL.md  │ missing   │ create │
│ .sspec\skills\sspec-change\SKILL.md   │ missing   │ create │
│ .github\skills\sspec-memory\SKILL.md  │ missing   │ create │
│ .sspec\skills\sspec-memory\SKILL.md   │ missing   │ create │
│ .sspec\skills\use-powershell\SKILL.md │ current   │ skip   │
│ .sspec\skills\write-patch\SKILL.md    │ current   │ skip   │
│ .sspec\skills\write-spec-doc\SKILL.md │ current   │ skip   │
└───────────────────────────────────────┴───────────┴────────┘

  + Updated .sspec\skills\sspec-ask\SKILL.md
  + Created .github\skills\sspec-change\SKILL.md
  + Created .sspec\skills\sspec-change\SKILL.md
  + Created .github\skills\sspec-memory\SKILL.md
  + Created .sspec\skills\sspec-memory\SKILL.md
  + Updated root AGENTS.md block

- Removed 1 orphaned skill(s)
+ Updated 6 item(s)

H:\SrcCode\playground\sspec\tmp\sspec-very-legacy                                        refactor/skills  👾  (sspec)  Ⓜ 22GiB/31GiB
❯❯❯ uv run sspec project update

                            Legacy Skill Layout Migration
┏━━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Location       ┃ Strategy ┃ Backup                                                 ┃
┡━━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ .github\skills │ junction │ .sspec\tmp\skills-backup\20260213233632\.github_skills │
└────────────────┴──────────┴────────────────────────────────────────────────────────┘

                       Update Status
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┳━━━━━━━━┓
┃ File                                  ┃ Status  ┃ Action ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━╇━━━━━━━━┩
│ .sspec\skills\sspec-ask\SKILL.md      │ current │ skip   │
│ .sspec\skills\sspec-change\SKILL.md   │ current │ skip   │
│ .sspec\skills\sspec-memory\SKILL.md   │ current │ skip   │
│ .sspec\skills\use-powershell\SKILL.md │ current │ skip   │
│ .sspec\skills\write-patch\SKILL.md    │ current │ skip   │
│ .sspec\skills\write-spec-doc\SKILL.md │ current │ skip   │
└───────────────────────────────────────┴─────────┴────────┘


+ Migrated 1 legacy skill location(s)
+ Updated 1 item(s)
```

怀疑是否是旧版本代码作祟。我开了一个测试用目录 H:\SrcCode\playground\sspec\tmp\sspec-very-legacy-2 ，你可以检查分析是怎么回事。

# Agent Question History #

已修复你刚才反馈的 `project update` 崩溃：

- 根因：legacy 迁移备份时 `copytree(..., symlinks=True)` 在 Windows 下尝试重建符号链接，触发 `WinError 1314`。
- 修复：备份阶段改为“跳过指向 hub 的链接节点，仅备份真实目录/自定义内容（`symlinks=False`）”。
- 复测：在你的场景目录执行 `uv run sspec project update` 已通过，成功迁移 `.claude/.github` 两个旧位置到目录级 junction。

请确认：
- A. 该问题已解决，可进入最终收尾
- B. 仍有问题（请贴新复现日志）
- C. 还有额外优化点（请列点，我继续 /auto）