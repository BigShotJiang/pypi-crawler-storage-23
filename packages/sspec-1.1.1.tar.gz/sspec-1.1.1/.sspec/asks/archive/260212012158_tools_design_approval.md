---
created: '2026-02-12T01:21:58'
name: tools_design_approval
why: 'Design phase complete for `sspec tool` command.

  Need confirmation before entering execution phase.'
---

**Ask**: tools_design_approval

# User Answer #

你在 spec 中的设计过于粗略，具体你打算怎么设计 patch 这个指令？参数是啥？要提供什么功能？什么交互？
这些细节都没有说明清楚，我无法批准这个设计。

.sspec/tmp/failed-patches 是 ok 的，--dry-run 这些也行。

此外不需要额外创建 tool_service.py，封装过头了反而不好。

以及我需要你和我仔细思考 Tool 这个东西到底要怎么定位？请从第一性原理触发深入思考。
是不是说我们要设计某种规范，统一声明 Tool 然后通过某种机制注册 Tool？（请独立考虑必要性）
如果是这样和 cmd 关系又混乱起来了。

# Agent Question History #

I've designed the `sspec tool` command for managing builtin development utilities.

## Design Summary

**Architecture**:
- New command group: `sspec tool` with subcommands for builtin tools
- First tool: `sspec tool patch <file>` to apply SEARCH/REPLACE patches
- Clean separation: commands/tool.py (CLI) → services/tool_service.py (logic) → builtin_tools/apply-patch.py (engine)

**Key Features**:
- Rich interactive output: progress bars, colored success/failure summary
- Failed patches auto-saved to `.sspec/tmp/failed-patches/<timestamp>/` for inspection
- Options: `--dry-run` (preview), `--output-failed <dir>` (custom output), `--yes` (skip confirmation)
- Distinct from `sspec cmd`: builtin cross-project tools vs project-specific scripts

**Implementation Plan** (3 phases):
1. CLI structure: commands/tool.py skeleton + cli.py registration
2. Service integration: tool_service.py + full patch command with Rich output
3. Testing: success/failure scenarios, dry-run mode

Full details in: .sspec/changes/archive/26-02-12T01-19_tools/spec.md

**Question**: Does this design meet your requirements? Any adjustments needed?

Options:
A) Approve - proceed with implementation
B) Modify - suggest changes (please specify)
C) Discuss - need more context on specific aspects