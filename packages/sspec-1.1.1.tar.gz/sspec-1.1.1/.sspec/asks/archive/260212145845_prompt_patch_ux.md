---
created: '2026-02-12T14:58:45'
name: prompt_patch_ux
why: 'You asked for UX improvements to two builtin tools:


  1) `sspec tool prompt` — make interactive input smoother/cleaner

  2) `sspec tool patch` — add optional `--input` (enter patch text interactively via
  prompt) and show per-patch detailed results including the `# header` line


  There are a few reasonable implementation choices (keybindings + indexing/caching
  strategy + CLI behavior). I want to confirm your preferences before changing code.'
---

**Ask**: prompt_patch_ux

# User Answer #

1） 你看这样如何，允许 --input 或者 --file <path>，如果两者都提供了，报错；如果没有 --input/-i, --file/-f 就默认走 --input 模式；inut 如何为空，就直接调过；这样是否更好？

2) 保持当前模式

3) 使用方案 A)

4) 你理解错了，我说的不是性能问题；就是单纯的 CLI 交互 UI 设计问题；一个是我觉得当前 `>` 看上去很怪，不够漂亮；再有就是进入 command 模式的时候，当前的性能是换行然后输入，感觉有点奇怪，如果能像 VIM 那种固定特殊的指令区域会更好，但我不知道当前依赖的库是否支持 (pyproject.toml)

# Agent Question History #

Please confirm the desired UX details (pick options / answer briefly):

1) `sspec tool patch --input` vs PATCH_FILE
	A) `--input` and PATCH_FILE are mutually exclusive (error if both provided). (recommended)
	B) Allow both; if both provided, PATCH_FILE wins.

2) How to finish interactive patch input
	A) Keep existing `prompt` behavior: Esc+Enter submits; Esc enters command mode. (recommended)
	B) Add an additional fast-submit hotkey (e.g. Ctrl+S submit/save) while keeping Esc+Enter.

3) `patch` detailed output (per patch)
	A) Table rows per patch with: `# header` (exact line), Status, Match mode (exact/loose), Note (error/applied), and line delta (+N/-N). (recommended)
	B) Minimal per-patch: `# header` + Status + Note only.

4) `prompt` smoothness focus (biggest pain point)
	A) Avoid UI freeze on first `@` completion by indexing files in background and showing “Indexing…” in toolbar until ready. (recommended)
	B) Keep single-threaded but speed up indexing (os.walk + early-pruning) and reduce overhead.
	C) Mainly keybindings/visual polish (less banner noise, nicer toolbar hints); indexing lag is acceptable.

If you have one concrete example of what currently feels “卡/不丝滑” (e.g. first `@` completion freezes for X seconds / Esc delay / flicker), paste it too.