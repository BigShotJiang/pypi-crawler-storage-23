---
created: '2026-02-15T21:28:26'
name: spec_vs_task_solution
why: 'Request: spec-vs-task 问题调研完成，需要确认解决方案是否可行。'
---

**Ask**: spec_vs_task_solution

# User Answer #

思路方向是对的，但是我个人在思考，我非常看重的接口 定义、 数据模型要怎么办？起码你没有提到。

比如但凡涉及到新的模块、 函数，起码要先把接口是啥规范是啥定下来吧？

我在想这个是不是应该放在 Proposed Solution 里面？
Proposed Solution 是整体

Implementation Strategy 是拆分步骤方案，你觉得合适吗？

请在调研分析，整体地考虑 spec.md 的设计；
其实问题在于：design 是啥？是 B OR C？ B 和 C 的区别是啥？

# Agent Question History #

# spec.md vs tasks.md 同质化问题 — 解决方案

## 调研结果

我完成了对 spec.md 和 tasks.md 重复内容问题的调研。详细分析报告见：
`.sspec/tmp/spec-vs-task-analysis.md`

## 问题诊断

**核心问题**：当前文档对 spec.md Section C 的定位为 "file-level breakdown with paths"，
与 tasks.md 的 "file-level tasks" 定位高度重叠，导致代理写作时内容同质化。

**实际案例验证**：
- replace-archived-link-path: spec.md C 和 tasks.md 内容几乎完全一致（高度重复）
- tools: 中度重复，但 tasks 有更细粒度的拆解

## 解决方案

### 核心原则

明确职责边界：
- **spec.md Section C** = 设计文档 (Why, How it works, Architecture)
- **tasks.md** = 执行清单 (What to do, Verification)

### 具体调整

**1. doc-standards.md 重写 Section C 标准**
- 从 "file-level breakdown" 改为 "design-level breakdown focusing on data flow, logic flow, interface design"
- 区分简单场景（brief file mentions OK）和复杂场景（organize by module/layer）
- 添加对比示例（Before/After）

**2. spec.md 模板 @RULE 更新**
- 强调 "focus on design, not task enumeration"
- 明确应包含：impact scope, data flow, logic flow, key interfaces, risks

**3. SKILL 补充**
- 添加 "spec.md vs tasks.md: When to Write What" 对比表
- 提供简单/复杂场景的示例

**4. AGENTS.md 补充**
- 在 2.0 Request → Change Workflow 的 Design 步骤添加 Design Principle

### 预期效果

**简单场景**：spec.md 简短但解释"为什么"，tasks.md 保持任务列表
**复杂场景**：spec.md 像架构文档（按模块组织，描述数据流），tasks.md 是其执行分解

## 问题

1. **方案可行性**：你认为这个解决方案能否有效区分 spec.md 和 tasks.md？有没有遗漏的方面？

2. **实施方式**：
   - 是否需要创建 change？
   - 还是可以直接修改文档（微调整，Micro 级别）？

3. **补充建议**：你有没有其他想法或补充？

详细分析报告和示例见：`.sspec/tmp/spec-vs-task-analysis.md`