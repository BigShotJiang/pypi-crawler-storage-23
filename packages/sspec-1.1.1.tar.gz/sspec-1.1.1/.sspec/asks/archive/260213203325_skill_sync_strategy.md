---
created: '2026-02-13T20:33:25'
name: skill_sync_strategy
why: 'The request explicitly asks for deep research + optimization report first,

  then asks agent to use /sspec-ask for review before implementation.

  This ask confirms key strategy decisions before entering DOING.'
---

**Ask**: skill_sync_strategy

# User Answer #

2 3 4 我现在都 Ok

但是有一点我现在还处于 Confuse 状态: 到底要不要 Junction link?
这个问题可以被分解为几点 concerns:

你在.sspec/changes/archive/26-02-13T20-29_install-skill/reference/skill-sync-research.md中似乎批判了 Junction 的风险，但有同意使用 Junction

然后是最关键的：Agent 系统是否能识别到 Junction link 的 SKILL 目录？如果不行的话，我们所有的前提都不成立；而如果行的话，那是否直接就默认在 windows 下使用 Junction 就好了？
亦或者让用户选择采用哪个方案。

此外还有一个问题：更新之后你觉得应该怎么设置 SKILL 以及 .copilot/.agnet... 中的 gitignore?

# Agent Question History #

已完成 request -> change，并产出调研与优化草案：
- 变更路径: `.sspec/changes/archive/26-02-13T20-29_install-skill/`
- 调研报告: `.sspec/changes/archive/26-02-13T20-29_install-skill/reference/skill-sync-research.md`

拟采用的核心方案：
1) `.sspec/skills` 作为唯一 hub；
2) 其他位置走统一 sync pipeline（detect -> backup -> merge -> relink/copy）；
3) `project init` 先完成核心安装，再询问外部位置同步；
4) `project update` 复用同一套 sync/迁移策略。

请确认以下决策（可逐条回答）：

1. Windows 策略优先级是否同意：`symlink -> (可选提权重试) -> junction -> copy`？
2. 对已存在普通 `xx/skills` 目录，是否同意“先备份到 `.sspec/tmp/skills-backup`，再合并非内置技能到 hub，然后重建 spoke”这一路径？
3. `project init` 是否确认改为“先安装 `.sspec`，后提示是否同步外部位置”？
4. 是否同意我在下一步直接进入执行（重构 installer/init/update + 测试）？