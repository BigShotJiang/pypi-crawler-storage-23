---
created: '2026-02-11T03:32:21'
name: debug_sspec_setup
why: Clarify debug setup preferences to provide the right solution
---

**Ask**: debug_sspec_setup

# User Answer #

Any! 本方案需要一个地方让用户输入要 debug 的命令

只考虑 VsCode UI 内的 debug

别的不需要，只在用户又调试指定某个命令的时候又需求（当然也要能指定根目录，比如在 tmp 下某个测试目录内调式运行）

# Agent Question History #

### Debug Setup Preferences

You want to debug sspec commands with breakpoints. To provide the best solution, please clarify:

**Q1: Which commands do you most frequently debug?**
   - Specific command(s)? (e.g., `sspec change new`, `sspec ask`, etc.)
   - All commands with a unified setup? (recommended)

**Q2: Debug workflow preference:**
   - Option A: VS Code UI (F5 to start, set breakpoints in editor, auto-restart)
   - Option B: Python CLI script (run `python debug_sspec.py 'change new ...'`, set breakpoints in IDE)
   - Option C: Both (maximum flexibility)

**Q3: Additional features:**
   - Auto-reload on file change? (live coding while debugging)
   - Save debug sessions/breakpoints? (session history)
   - Debug specific test files alongside commands?

**Answer format example:**
```
Q1: All commands (unified setup)
Q2: Option A (VS Code UI)
Q3: No special features, just basic debugging
```