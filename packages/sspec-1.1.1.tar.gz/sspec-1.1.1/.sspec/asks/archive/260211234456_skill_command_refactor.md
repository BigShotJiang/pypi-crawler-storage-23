---
created: '2026-02-11T23:44:56'
name: skill_command_refactor
why: Need to confirm intended behavior and edge cases before refactoring `sspec skill`
  commands (remove `list`, add `re-init`, change `new`) so I don't implement the wrong
  semantics for targets/linking/meta updates.
---

**Ask**: skill_command_refactor

# User Answer #

1. 是的，我们限定 sspec skill new 的含义为，创建新的 skill 并兼容多个不同已经投入使用的 SKILL 位置（因为各个厂商 Agent 支持不同的位置）
2. re-init 的时候，如果是已经被安装过的 location，默认在列表中处于选中状态；这意味着我们可以添加新的安装位置，也可以删除之前的位置；注意：re-init 之前已经安装的 SKILL 可能是 copy 也可能是 link，需要都能正常处理
3. 优先尝试创建符号链接，如果失败了才尝试 copy
4. 是的，需要刷新涉及到 SKILL 相关的元信息

不知道我表述清楚我的意思了没有，如果还有疑问可以继续提问

# Agent Question History #

I’ve traced current behavior:

- `project init` installs template skills via a hub-and-spoke pattern:
  - hub: `.sspec/skills/<skill>` is copied from package templates
  - spokes: selected locations (`.claude/.github/.agent` → `<loc>/skills/<skill>`) are symlinked if possible, else copied
  - `.sspec/.meta.json` stores `skill_locations` (e.g. `.github\\skills`, `.sspec\\skills`) and `skill_install_strategies` per location.

Before I change code, please confirm these decisions:

1) Definition of “already linked” targets for `skill new`:
	- Should it mean strictly: locations listed in `.sspec/.meta.json: skill_locations` (excluding `.sspec/skills`), and we only install spokes into those?
	- Or should it also include any existing workspace dirs on disk even if not in meta?

2) `skill re-init` target selection defaults:
	- Default pre-selected options: current meta locations, or auto-detected existing workspace dirs, or always `.github` first?
	- Should `.sspec` always be included (not optional) as the hub?

3) Skill installation strategy:
	- For spokes, should we respect recorded `skill_install_strategies` per location (copy vs symlink), or always “prefer symlink” and fallback to copy?
	- On Windows this may trigger UAC elevation attempt for symlinks — OK to allow, or default to copy to avoid prompts?

4) Meta update behavior during `skill re-init`:
	- Should `re-init` always refresh `.meta.json` fields (`updated_at`, `skill_locations`, `skill_install_strategies`, and template skill hashes),
	  or only update when the selected target set differs from existing meta?

Please answer in 4 numbered points.