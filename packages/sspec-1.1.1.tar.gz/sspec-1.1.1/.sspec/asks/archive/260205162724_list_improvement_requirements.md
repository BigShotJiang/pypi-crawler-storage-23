---
created: '2026-02-05T16:27:24'
name: list_improvement_requirements
why: 'User requested improvements to `sspec change list` and `sspec request list`
  display.

  Need to understand what specific information should be shown/hidden before implementing.'
---

**Ask**: list_improvement_requirements

# User Answer #

当前效果如下:
```bashH:\SrcCode\playground\sspec                                                                                                 main  👾   Ⓜ 23GiB/31GiB
❯❯❯ uv run sspec request list

In Progress
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Name                               ┃ Created    ┃ Changes                      ┃ Summary                                                    ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ 260205014156-add-reference-in-spec │ 2026-02-05 │ reference-system-enhancement │ 我刚刚给 spec.md 的模板增加了 reference 字段，类型为 Array │
└────────────────────────────────────┴────────────┴──────────────────────────────┴────────────────────────────────────────────────────────────┘
Done: 2 (use --all to show)

H:\SrcCode\playground\sspec                                                                                                 main  👾   Ⓜ 23GiB/31GiB
❯❯❯ uv run sspec change list

Active Changes
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━┓
┃ Name                         ┃ Status    ┃ Progress ┃ Flags   ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━┩
│ built-in-ask-prompt          │ 👀 REVIEW │ 12/13    │ ⚡pivot │
│ refactor-ask-mechanism       │ ✅ DONE   │          │ ⚡pivot │
│ reference-system-enhancement │ ✅ DONE   │ 22/22    │         │
└──────────────────────────────┴───────────┴──────────┴─────────┘
```

建议:
- request 的 name 字段去掉前缀的时间；直接 split _ 即可（当前是 - 是因为还没有更改）；然后增加一个 path 指向具体位置
- change 的显示效果就很灾难了
    - 请显示 reference
    - 那个 Flags 莫名奇妙不知道是啥意思

# Agent Question History #

你提到 "sspec change list 和 request list 的展示效果一般，放上去了无用信息但是一些有用信息却没有"

为了改进这两个命令的展示效果，我需要了解：

1. **当前显示了哪些"无用信息"？**
   - 请运行 `sspec change list` 和 `sspec request list` 看看
   - 指出哪些字段/信息你觉得没必要显示

2. **缺少了哪些"有用信息"？**
   - 你希望在列表中看到哪些信息？
   - 例如：创建时间、状态、关联的 request/change、进度百分比等

3. **对展示格式有什么偏好？**
   - 表格形式？
   - 每行一个项目（精简模式）？
   - 分组显示（按状态分组）？

请尽量具体描述，方便我准确实现你的需求。