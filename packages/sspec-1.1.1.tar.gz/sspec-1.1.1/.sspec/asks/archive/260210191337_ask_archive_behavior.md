---
created: '2026-02-10T19:13:37'
name: ask_archive_behavior
why: Need to confirm how ask archive should treat pending vs completed asks and whether
  to add archived timestamps.
---

**Ask**: ask_archive_behavior

# User Answer #

A ) Only md file
B ) No
C ) NO

# Agent Question History #

For the new `sspec ask archive` command, please confirm:

1) Which files should be archivable?
	A) Completed asks only (`.md`)
	B) Both completed (`.md`) and pending (`.py`)

2) When archiving completed `.md` asks, should we add an `archived` timestamp in frontmatter?
	A) Yes
	B) No (just move file)

3) For pending `.py` asks (if allowed), should we add any marker before moving?
	A) No marker (move only)
	B) Append `ARCHIVED = "<timestamp>"` to the file

Please answer in the form: 1)A 2)A 3)A