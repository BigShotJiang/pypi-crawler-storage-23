---
created: '2026-02-12T10:59:44'
name: new_skill_not_installed
why: 已完成新增 SKILL 无法安装的问题分析，需要向用户汇报发现并获得许可执行解决方案。
---

**Ask**: new_skill_not_installed

# User Answer #

可以，请重新安装

# Agent Question History #

## 问题分析报告

### 实际测试结果

我在当前项目中测试了 `project update` 和 `skill re-init` 命令，**两者都能正常工作**，成功检测并安装了新的 `write-patch` SKILL。

测试过程：
1. 运行 `sspec project update --dry-run` → 正确检测到 write-patch 为 "missing" 状态
2. 运行 `sspec project update` → 成功安装到 `.claude/skills`, `.github/skills`, `.sspec/skills`
3. 删除后运行 `sspec skill re-init` → 同样成功安装

### 根本原因分析

代码逻辑**完全正常**，问题可能出在以下几个方面：

**1. 模块缓存问题（最可能）**
- 虽然 sspec 以 editable 模式安装，但 Python 可能缓存了旧的 `list_template_skills()` 结果
- 某些情况下，即使修改了 templates 目录，运行时仍读取旧数据

**2. 环境不一致**
- 您可能在不同的虚拟环境或项目中测试
- 那个环境中的 sspec 可能不是 editable 安装，或版本不同

**3. 命令执行问题**
- 可能只运行了 `--dry-run` 而没有实际执行
- 或者有错误输出被忽略了

### 建议的解决方案

**方案 A：强制重新安装 + 清理缓存（推荐）**
```powershell
# 1. 清理 Python 缓存
Remove-Item -Path src/sspec/__pycache__ -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path src/sspec/services/__pycache__ -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path src/sspec/commands/__pycache__ -Recurse -Force -ErrorAction SilentlyContinue

# 2. 重新安装 sspec
uv pip install -e . --force-reinstall --no-deps

# 3. 运行更新
uv run sspec project update
```

**方案 B：验证诊断信息**
如果方案 A 不行，运行以下命令收集诊断信息：
```powershell
uv run python -c "from sspec.core import list_template_skills; print([s.name for s in list_template_skills()])"
```
这会直接显示 Python 能看到的 template skills 列表。

### 问题

**您遇到的具体情况是什么？**
1. 您是在当前项目（h:\SrcCode\playground\sspec）测试的，还是在其他项目中？
2. 运行 `project update` 和 `skill re-init` 时有看到任何错误或警告吗？
3. 您是否同意我执行方案 A（清理缓存 + 重新安装）来解决问题？

如果您想先自己尝试，也可以直接按上述方案 A 的命令执行。如果问题依然存在，我可以进一步深入调试。