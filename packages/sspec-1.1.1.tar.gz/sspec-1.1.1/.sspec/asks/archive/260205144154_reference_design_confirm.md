---
created: '2026-02-05T14:41:54'
name: reference_design_confirm
why: '完成了代码调研，需要和用户确认 reference 系统的设计方案，包括：

  1. reference 数据结构设计

  2. 命名规范统一方案

  3. md_yaml 工具库设计

  4. 功能范围和优先级'
---

# Ask: reference_design_confirm

## Question

# Reference 系统设计方案确认

我已完成代码调研，现在需要和你确认设计方案。这个需求包含多个方面，我按优先级分为三个阶段：

## 阶段 1：核心 Reference 系统（必须）

### 1.1 Reference 数据结构
```python
# spec.md frontmatter 中的 reference 字段
reference:
  - source: "requests/260205014156-add-reference-in-spec.md"  # 相对于 .sspec/ 的路径
    type: "request"  # 可选值: 'request' | 'sub-change' | 'sup-change' | 'doc'
    note: "Original feature request"  # 可选说明
```

### 1.2 双向链接机制
- `sspec request link <request> <change>` 时：
  - 更新 request 的 `attach-change` 字段 ✅ (已有)
  - **新增**: 同时在 change 的 spec.md 的 `reference` 中添加该 request

- `sspec change new --from <request-name>` （新参数）:
  - 创建 change 时直接建立双向链接
  - 自动填充 spec.md 的 reference 字段

### 1.3 Archive 时记录归档时间
- request archive: 在 frontmatter 写入 `archived: <ISO-datetime>`
- change archive: 在 spec.md frontmatter 写入 `archived: <ISO-datetime>`

**问题 1**: 这个核心设计是否符合你的预期？有需要调整的吗？

---

## 阶段 2：命名规范统一（建议）

### 当前问题
- request: `<yyMMddHHmmss>-<name>.md` (用 `-`)
- change: `<name>` (无时间前缀)
- archive change: `<YYYY-MM-DD>_<name>` (archive 时才加前缀，改名)

### 提议的新规范
统一格式: `<yy-MM-ddTHH-mm>_<name>`
- request: `26-02-05T14-41_add-reference-in-spec.md`
- change: `26-02-05T14-50_reference-system-enhancement/`
- archive 后：移动到 archive/ **但不改名**

### 迁移策略
- **向后兼容**: 新代码同时支持旧命名和新命名
- 添加 `sspec project migrate-naming` 命令辅助迁移
- 文档中标注新规范，建议新项目使用

**问题 2**:
a) 是否采用新的命名规范？
b) 如果采用，是强制迁移还是向后兼容？
c) 我倾向于"向后兼容 + 文档引导"，避免破坏现有项目，你觉得如何？

---

## 阶段 3：辅助功能（可选）

### 3.1 md_yaml 工具库
在 `src/sspec/libs/md_yaml.py` 中提供：
```python
def parse_frontmatter(content: str) -> tuple[dict, str]
def update_frontmatter(content: str, updates: dict) -> str
def add_to_array_field(content: str, field: str, item: Any) -> str
```

**好处**:
- 当前代码中有多处 frontmatter 解析逻辑重复（request_service, core.py 等）
- 统一处理避免不一致

### 3.2 sub-change skill 创建
创建 `src/sspec/templates/skills/sspec-multi-change/SKILL.md`
说明如何管理复杂变更：
- 创建 root change 作为总控
- 分解为多个 sub-change，通过 reference 关联
- 每个 sub-change 完成后归档，继续下一个

**问题 3**:
a) md_yaml 工具库是否需要？还是保持当前各处独立处理？
b) sub-change skill 是否需要现在创建？还是等实际遇到复杂场景再说？

---

## 我的建议执行顺序

**本次实现** (阶段 1):
1. 创建 md_yaml 工具库（方便后续开发）
2. 实现 reference 双向链接
3. `sspec change new --from <request>` 参数
4. archive 时记录时间
5. 更新文档 (AGENTS.md, sspec SKILL)

**后续 PR** (阶段 2, 可选):
- 命名规范统一 (如果你觉得有必要)

**后续按需** (阶段 3):
- sub-change skill (遇到实际需求时再补充)

**你的意见**:
1. 阶段 1 的设计是否 OK？
2. 阶段 2 (命名规范) 要不要做？如何做？
3. 阶段 3 中 md_yaml 我建议做（能简化代码），sub-change skill 可以先不做，你觉得呢？
4. 还有其他考虑吗？

请明确告诉我你的决定，我会据此更新 spec.md 并开始实施。

## Answer

1. 看上去是可行的设计，OK
2. 是的，采用这个命名规范即可； 旧有的记录不管了，也不需要做迁移兼容；也不用增加 migrate name

   1. 本质上这只是更好的风格，旧版本的命名也许看上去不够好，但是不影响功能
   2. sspec 强个人使用属性高，不用太考虑兼容迁移（反而让代码变复杂）
3. md_yaml 是 ok 的，不过我没有理解有必要增加 add_to_array_field 吗？读取 yaml,传入更新的字典不行吗？ 设计这个的必要性在哪里我没有理解 ；
   sub-change skill 我仔细想了一下，也许可以合并到 现有的 sspec skill 中？
   按照 Skill Creator 常用规范；通常简单的 SKILL 只需要一个 SKILL.md 即可，但也可以在内部增加更多文件？ 参考 Claude 的 Skill 实践策略：[https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices) 中提到

   ```md
   Progressive disclosure patterns

   SKILL.md serves as an overview that points Claude to detailed materials as needed, like a table of contents in an onboarding guide. For an explanation of how progressive disclosure works, see How Skills work in the overview.

   Practical guidance:

       Keep SKILL.md body under 500 lines for optimal performance
       Split content into separate files when approaching this limit
       Use the patterns below to organize instructions, code, and resources effectively

   ```

   我们可以调整 sspec skill，优化 change 说明，并提到复杂项目管理可以使用 multi-changes 这样是不是会比增加一个 SKILL 更好？
4. 此外增加一个细节变动：在 sspec ask 的时候 --name 强制要求字母下划线，原因是要创建一个可以被 import 的 python file

   我觉得可以增强易用性，在分析 name 的时候，会兼容 - 数字等符号，但是会把 - 等符号变成 `_`，并在结束的时候打印一个 warning 说明；这样避免 Agent 浪费精力，调用多次 ask
5. 💡 特别注意：我上面提到的优化 `SKILL` 的部分要单独占据一个 Phase，因为编写 SKILL 对最终影响很大！甚至比 CLI 还大。所以在编写 SKILL 前建议你仔细阅读 Create Skill 的 SKill 和上面提到的 Claude 官方文档 best practice
