---
change: "test-root"
change-type: root
updated: ""
---

# Milestones

## Legend
`[ ]` Todo | `[x]` Done (sub-change completed + verified)

## Milestones
<!-- @REPLACE -->
<!-- @RULE: Each milestone maps to a sub-change. Track at phase level, not file level.
Phase emoji: 🚧 in progress | ✅ done | ⏳ pending
📚 Standards: sspec-change SKILL → multi-change.md

### Phase 1: <n> 🚧
- [ ] Sub-change created and linked
- [ ] Sub-change completed and archived
**Deliverable**: <what Phase 1 delivers>
**Sub-change**: <link when created>
-->

---

## Progress
<!-- @REPLACE -->

**Overall**: 0%

| Phase | Sub-Change | Status | Deliverable |
|-------|------------|--------|-------------|
| Phase 1 | (pending) | 🚧 | |

**Recent**:
- (none yet)
