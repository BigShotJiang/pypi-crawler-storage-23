---
name: test-root
status: PLANNING
type: ""
change-type: root
created: 2026-02-25T00:44:20
reference: null
---

<!-- @RULE: Frontmatter Schema
status: PLANNING | DOING | REVIEW | DONE | BLOCKED;
change-type: root (coordinator for sub-changes);
reference?: Array<{source: str; type: RefType; note?}>;
type RefType: 'request' | 'root-change' | 'sub-change' | 'doc';
📚 Full schema details: sspec-change SKILL → doc-standards.md
 -->

# test-root

## A. Problem Statement
<!-- @REPLACE -->

<!-- @RULE: Quantify overall impact. This is the root coordinator — describe the full scope, not a single module.
📚 Standards: sspec-change SKILL → doc-standards.md -->

## B. Proposed Solution
<!-- @REPLACE -->

### Overall Approach
<!-- @RULE: High-level strategy. How will this be broken into phases? What's the delivery order? -->

### Phase Overview
<!-- @RULE: List phases with goals, not file-level details. Format:
- **Phase 1: <n>** — <goal, measurable deliverable>
- **Phase 2: <n>** — <goal, measurable deliverable>
-->

## C. Phased Approach
<!-- @REPLACE -->

<!-- @RULE: Phase-level breakdown. Each phase becomes a sub-change. Format:

### Phase 1: <n>
- **Sub-change**: <will be filled when sub-change created>
- **Goal**: <measurable deliverable>
- **Dependencies**: <what must complete before this phase>
- **Scope**: <which subsystems / modules affected>

### Coordination Notes
- <cross-phase dependencies, shared interfaces, integration points>
📚 Full multi-change patterns: sspec-change SKILL → multi-change.md -->

## D. Blockers & Feedback
<!-- @REPLACE -->

<!-- @RULE: Record with dates. Format:
### Blocker (YYYY-MM-DD)
**Blocked**: <what> | **Needed**: <to unblock>

### PIVOT (YYYY-MM-DD)
<direction change and reason>
-->
