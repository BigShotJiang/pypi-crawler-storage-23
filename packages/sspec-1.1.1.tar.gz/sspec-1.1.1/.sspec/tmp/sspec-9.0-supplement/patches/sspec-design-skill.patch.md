# Patch: sspec-design SKILL.md
# Adds boundary clarification and references to examples

# src/sspec/templates/skills/sspec-design/SKILL.md
<<<<<<< SEARCH
**What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).
=======
**What does NOT belong in B**: Execution order (tasks.md), file-level task lists (tasks.md).

**B vs tasks.md boundary**: B defines *how it should work* (interfaces, data model, logic). tasks.md defines *what to do* (file-level steps, verification). Tasks reference B — e.g. "implement interface per spec.md B" — never copy.
>>>>>>> REPLACE

# src/sspec/templates/skills/sspec-design/SKILL.md
<<<<<<< SEARCH
Each sub-change then goes through its own design → plan → implement → review cycle.
=======
Each sub-change then goes through its own design → plan → implement → review cycle.

**Multi-change pitfalls**:

| Mistake | Fix |
|---------|-----|
| File-level tasks in root tasks.md | Root tracks milestones only — file tasks go in sub-change |
| Skip root, jump straight to sub-changes | Root provides phase vision and coordination |
| Forget bidirectional references | Always link root ↔ sub in both `spec.md` reference fields |
| Archive root before all subs done | Root stays active until every sub-change is archived |
>>>>>>> REPLACE

# src/sspec/templates/skills/sspec-design/SKILL.md
<<<<<<< SEARCH
After user confirms design, proceed to `sspec-plan`.
Only after user also approves the task plan, transition status `PLANNING → DOING`.
=======
After user confirms design, proceed to `sspec-plan`.
Only after user also approves the task plan, transition status `PLANNING → DOING`.

---

## References

| When | Load |
|------|------|
| Need concrete spec.md examples (Simple / Medium / Complex / Root) | [examples.md](./references/examples.md) |
| Need B → tasks.md boundary guidance | [examples.md → B → tasks.md Boundary](./references/examples.md#b--tasksmd-boundary) |
>>>>>>> REPLACE
