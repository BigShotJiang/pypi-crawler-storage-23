# Patch: sspec-plan SKILL.md
# Enhances B/tasks.md boundary guidance and adds references section

# src/sspec/templates/skills/sspec-plan/SKILL.md
<<<<<<< SEARCH
## Reference Section B, Don't Repeat

tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.

- ✅ "Implement Tool Interface per spec.md B"
- ✅ "Create handler following the data flow in spec.md B"
- ❌ Re-listing all function signatures
- ❌ Re-describing the algorithm
=======
## Reference Section B, Don't Repeat

tasks.md references spec.md B's design. Don't re-describe interfaces or algorithms.

| spec.md B (design) | tasks.md (plan) |
|---|---|
| Defines interfaces, data model, logic | Lists file-level actions + verification |
| Explains *how it should work* | Tells agent *what to do next* |
| `get_cached_user(user_id) -> Optional[User]` | `Create cache.py — implement interface per spec.md B` |

- ✅ "Implement Tool Interface per spec.md B"
- ✅ "Create handler following the data flow in spec.md B"
- ❌ Re-listing all function signatures
- ❌ Re-describing the algorithm

📚 Complete B → tasks.md flow example: [examples.md](./references/examples.md#complete-flow-b--tasksmd)
>>>>>>> REPLACE

# src/sspec/templates/skills/sspec-plan/SKILL.md
<<<<<<< SEARCH
Wait for user approval before starting `sspec-implement`.
=======
Wait for user approval before starting `sspec-implement`.

---

## References

| When | Load |
|------|------|
| Need concrete tasks.md examples (Simple / Medium / Root) | [examples.md](./references/examples.md) |
| Need B → tasks.md complete flow example | [examples.md → Complete Flow](./references/examples.md#complete-flow-b--tasksmd) |
>>>>>>> REPLACE
