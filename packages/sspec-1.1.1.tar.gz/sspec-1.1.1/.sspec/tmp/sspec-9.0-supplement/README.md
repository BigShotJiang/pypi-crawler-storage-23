# SSPEC 9.0 补充交付

## 内容

### 独立文件（直接放置）

| 文件 | 放置路径 | 说明 |
|------|---------|------|
| `standalone/.claude/skills/sspec-design/references/examples.md` | `.claude/skills/sspec-design/references/examples.md` | spec.md 设计示例（Simple/Medium/Complex/Root + B→tasks.md 边界指南） |
| `standalone/.claude/skills/sspec-plan/references/examples.md` | `.claude/skills/sspec-plan/references/examples.md` | tasks.md 计划示例（Simple/Medium/Root + 完整 B→tasks.md 流程示例） |

### Patch 文件

| Patch | 目标文件 | 变更内容 |
|-------|---------|---------|
| `patches/sspec-design-skill.patch.md` | `.claude/skills/sspec-design/SKILL.md` | ① B vs tasks.md 边界一句话提醒 ② Multi-change pitfalls 表 ③ References 节指向 examples.md |
| `patches/sspec-plan-skill.patch.md` | `.claude/skills/sspec-plan/SKILL.md` | ① B vs tasks.md 边界对照表 ② References 节指向 examples.md |

## 应用方式

```bash
# 1. 放置独立文件
cp -r standalone/.claude/skills/sspec-design/references/ .claude/skills/sspec-design/references/
cp -r standalone/.claude/skills/sspec-plan/references/ .claude/skills/sspec-plan/references/

# 2. 应用 Patch
sspec tool patch patches/sspec-design-skill.patch.md
sspec tool patch patches/sspec-plan-skill.patch.md

# 3. 同步到 .sspec/skills/（如使用 copy 策略）
sspec sync  # 或手动复制
```

## 体量评估

| 文件 | 大小 |
|------|------|
| sspec-design/references/examples.md | ~5.5 KB |
| sspec-plan/references/examples.md | ~4.5 KB |
| SKILL.md patches 净增量 | ~1.2 KB |
| **总计** | **~11.2 KB** |

Patch 应用后 sspec-design SKILL.md 约 7.6KB（原 6.4KB），sspec-plan SKILL.md 约 3.7KB（原 3.1KB）。

Agent 单阶段最大读取量：sspec-design SKILL.md + examples.md ≈ 13KB。仍远低于 Legacy 8.0 的 ~28KB（sspec-change SKILL + doc-standards + doc-examples）。
