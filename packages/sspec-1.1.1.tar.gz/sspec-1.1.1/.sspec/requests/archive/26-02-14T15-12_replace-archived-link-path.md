---
name: replace-archived-link-path
created: 2026-02-14 15:12:14
status: DONE
attach-change: .sspec/changes/archive/26-02-14T15-18_replace-archived-link-path/spec.md
tldr: archive 时自动更新所有文件中的引用路径
archived: '2026-02-15T00:59:00'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: replace-archived-link-path

## Background
<!-- Current situation, background information -->
当前 change/request/ask 都支持 archive 指令，会把 .sspec 下相关文件移动到 archive 当中

## Problem
<!-- What is not working or missing -->
我们在之前兼容了 change/request 归档的时候会自动更新对方文件中的应用（attach-change / reference）
但是实际上在别的各种文档中也可能会引用这个被归档的文件

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->
一个最简单粗暴而有效的方法也许是这样：
在 archive 一个 change/request/ask 的时候，直接在 .sspec 下全局检索 (grep) 提到他路径的文件，然后替换成新的路径

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->
在 tmp 中测试：
1. 创建 sspec request new <test>
2. 创建 sspec change new --from <test>
3. 在 tmp 下随便创建一个文件
4. 在 change 下 sped.md, handover.md 还有 tmp file 中随便编写引用了 request 和 change 的路径
5. archive request, change ，看路径是否被更新

## Relational Context
<!-- Constraints, preferences, related filelinks -->
- src/sspec/services/request_service.py
- src/sspec/services/change_service.py
- src/sspec/commands/change.py
- src/sspec/commands/request.py
- src/sspec/services/ask_service.py
- src/sspec/commands/ask.py

---

## @AGENT
<!-- What should Agent do to implement this request -->
Please initiate the "request → change" workflow for this request.
(You need to consult `sspec-change` SKILL)

请创建相关 spec.md 确定新的 design  方案之后 ，@ask 我来审查；我同意了才能进一步开始实现

---

<!-- ============================================================
     MICRO-CHANGE ZONE (optional)
     For tiny changes (≤3 files, ≤30min) that don't need a full change.
     Remove these sections if a change is created instead.
     ============================================================ -->

<!--
## Plan
Quick implementation plan (what files to touch, what to do)

## Done
What was actually done + any notes for future reference
-->
