---
created: 2026-02-04 19:19:32
status: CLOSED
attach-change: refactor-ask-mechanism (completed)
tldr: Refactored sspec ask to two-step file-based workflow, added USER_ANSWER feature,
  updated all documentation
archived: '2026-02-05T18:55:44'
---
# Request: modify-sspec-ask

## Context
<!-- What's the current situation? Any background info that helps understand the request. -->
SSPEC Ask 是当前项目中非常重要的组成部分，但是当前的实现方案存在不足

## Problem
<!-- What's not working or missing? Describe the gap or pain point you're experiencing. -->
当前的方案为：直接发起 sspec ask ，但在实际测试中发现存在这些问题：

- 传入的 name 含有复杂字符无法作为文件名
- 传入的 question 多行在 terminal 中不稳定
- 传入的文本存在编码问题，例如 gbk, utf-8 问题

## Initiative / Proposal
<!-- Your initial idea or direction — even rough thoughts are fine. -->
想法：重构 ask 机制，放弃之前一次性让 Agent 调用 sspec ask 命令，改为：

- sspec ask create --name <str> --> 强制要求 --name 是简单的英文 python 文件名，字母 + 下划线；也可以不指定，默认就是 ask
- sspec 自动在 ask 下创建 `asks/<time>_<name>.py`，模板
    ```py
    CREATED="<time>" # 自动生成

    # Please EDIT the reason
    REASON = r"""
    Ask user for <reason>
    """

    # Please EDIT the question
    QUESTION = r"""
    <YOUR_QUESTION>
    """
    ```
    sspec ask 会返回类似这样的信息
    ```
    已经创建 ask 请求, 文件路径 "<path>"
    Next: Edit REASON+QUESTION in <path> --> run "sspec ask prompt <path>"
    ```
- 新的 sspec ask prompt <path>: 逻辑是导入指定文件中的信息，然后执行询问的逻辑，完成之后，在 path 尾部增加 `ANSWER=r""""""`
<!-- If you have specific approaches in mind, sketch them here. -->

请先分析当前情况，再分析这个方案的稳定性，最后做出更改。

再次期间，请使用临时的 Ask Prompt 方案替代 sspec ask 和用户确认，方法是：创建下面的的临时文件例如 temp/ask_xx.py，然后执行

```py
import sys

# TLDR in short
__doc__ = """
Ask user for <tldr reason/question>
"""

def ask(q):
    print(f"\n{'='*60}\n  🤖 Agent needs your input\n{'='*60}\n\n{q}\n", file=sys.stderr)
    print("💡 Enter response (type END on new line to finish):", file=sys.stderr)
    lines = []
    try:
        while (line := input()) != "END":
            lines.append(line)
    except (EOFError, KeyboardInterrupt):
        pass
    result = "\n".join(lines)
    print(f"\n✓ Received ({len(result)} chars)\n{'='*60}\n", file=sys.stderr)
    return result

print(ask(r'''
<YOUR_QUESTION>
'''))
```

## Additional Context
<!-- Constraints, preferences, related links, or anything else worth mentioning. -->

相关可能需要调整的:

- src/sspec/templates/AGENTS.md
- src/sspec/templates/skills/sspec-ask/SKILL.md
- src/sspec/commands/ask.py
- src/sspec/services/ask_service.py
- README.md

---

## Implementation Summary

**Status**: ✅ COMPLETED (2026-02-04)

### What Was Done

**Phase 1: Service Layer** (src/sspec/services/ask_service.py)
- ✅ Implemented `create_ask_template()` - generates .py template files
- ✅ Implemented `execute_ask_prompt()` - imports and executes ask prompts with USER_ANSWER support
- ✅ Implemented `save_ask_answer()` - appends answer to .py file
- ✅ Implemented `convert_ask_to_md()` - converts .py to .md and cleanup
- ✅ Updated `normalize_ask_name()` - strict validation ([a-z_] only)
- ✅ Removed obsolete `write_ask_record()` and `resolve_question()`

**Phase 2: CLI Commands** (src/sspec/commands/ask.py, src/sspec/cli.py)
- ✅ Converted to Click group with `create` and `prompt` subcommands
- ✅ `sspec ask create [--name]` - creates template
- ✅ `sspec ask prompt <path>` - executes and converts to .md
- ✅ Updated CLI registration in cli.py

**Phase 3: Documentation Updates**
- ✅ src/sspec/templates/skills/sspec-ask/SKILL.md - Concise workflow guide with active use emphasis
- ✅ src/sspec/templates/AGENTS.md - Updated all references, added "USE ACTIVELY" principle
- ✅ README.md - Updated user-facing examples
- ✅ README_zh-CN.md - Updated Chinese documentation

**Phase 4: Version & Testing**
- ✅ Updated SCHEMA_VERSION to 5.1 in src/sspec/core.py
- ✅ Tested create/prompt workflow with multiple scenarios
- ✅ Verified Unicode and USER_ANSWER features work correctly

### New Features Beyond Original Request

**USER_ANSWER Enhancement**
- Template includes optional USER_ANSWER field
- Users can pre-fill answers in the file (skip terminal prompt)
- Leverages VS Code's script approval mechanism
- More flexible for complex/long responses

### Files Changed

**Implementation**:
- src/sspec/services/ask_service.py
- src/sspec/commands/ask.py
- src/sspec/cli.py
- src/sspec/core.py (SCHEMA_VERSION 5.0 → 5.1)

**Documentation**:
- src/sspec/templates/skills/sspec-ask/SKILL.md
- src/sspec/templates/AGENTS.md
- README.md
- README_zh-CN.md

**Result**: sspec ask is now a robust, file-based two-step workflow that eliminates all shell escaping and encoding issues.
