---
name: refactor-to-perf-workflow
created: 2026-02-24 21:19:39
status: DOING
attach-change: .sspec/changes/archive/26-02-24T21-47_refactor-to-perf-workflow/spec.md
tldr: ''
archived: '2026-02-25T01:09:27'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: refactor-to-perf-workflow

## Background
<!-- Current situation, background information -->
长久以来我在使用 sspec 的开头总感觉那里怪怪的，最近我又对比了 openspec 的最新版有了一些想法
可以参照 @.sspec/tmp/openspec-v1-demo 特别是内部的 .sspec/tmp/openspec-v1-demo/.github/skills

## Problem
<!-- What is not working or missing -->
我意识到的问题是：当前 SSPEC 的 src/sspec/templates/skills/sspec-change/ 实在太重了。
一方面，在 src/sspec/templates/AGENTS.md 里面，我们把创建一个 change 当成了一个完整原子化的步骤；
同时在 SKILL 中我们也把 change 封装成独立单独的 SKILL

但是实际上不是这样的啊。我仔细思考了一下，按照 sspec 当前的设计，一个 change 的生命周期应该是：
- 用户编写 request
- 发给 agent 作为种子思考
  - 初步判断：是否要创建 change
  - 如果需要就 sspec change new --from <req>
- 调研：Agent 根据请求研究当前的情况；期间可能有反复思考、甚至做一些笔记的情况
- 设计：Agent 给出大致的设计思路方向，这里面最重要的就是各种规范、数据逻辑流、接口类型定义等
- User in loop 的确认：Agent 拿着这个草案给 User 确认是否可行；期间可能 @ask/@question ，询问的要点是留档，所以长的可复用的东西最好写入文档 （参考 src/sspec/templates/skills/sspec-ask/）
- 当确认了设计规划之后，用户应该对最后有什么效果心理有数；然后就是具体的试试方案，也就是具体哪些文件什么，用什么策略、什么顺序来规划工作流程 —— 如有有必要，这里也许也需要 question/ask 用户
- 初步的开发 settled 之后，还需要用户 feedback ，也就是在末尾的 ask
- 这时候用户会自己上手检查代码、测试，看是否和自己想象中一样，然后会进入一个 human-argue-agent-improve 的 loop 流程，直到一切 fine
以上整个过程的每个检点，需要有 handover 做记录，确保在遇到上下文满了需要压缩、或者中断任务开新 session 之后，Agent 都能无损响应
- 用户满足之后，就进入收尾；标记 change DONE，或者如果是有 root change 也在 root change 中更新记录；以及如果用户有需要，可以更新 spec-doc （Agent 可以主动询问）

我认为这样才是最现实合理的开发周期

而我实际工作的时候就发现，我需要不停手动写提示词，比如提醒 Agent 先规划、不要直接执行， 把规划发给我 questioin ，在做完之后不要随便停下来，先咨询我等等 —— 我感觉很多本来应该能自动化形成规范的东西，认知负荷依然在我身上

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->
我认为核心还是：
- AGENTS.md 引导没有做好
- SKILL 拆分的不够好；目前我对 src/sspec/templates/skills/sspec-change/ 和 src/sspec/templates/skills/sspec-memory/ 都不满意；写了一大堆，但是逻辑很混乱（特别是 memory 里面，层层晋升，实际上根本用不上）

我需要 Agent 仔细研究当前的 SSPEC 设计，可以参考 openspec 内部的做法。

我认为应该这样： Agents.md 更加清晰的落实整个流程，SKILL 需要重大的重构，在保留最核心重要的前提下，给出更好的设计方案
避免超重量的单体 SKILL，单个 SKILL 内部核心文件应该只有 SKILL.md ，顶多一两个额外的参考；开发 SKILL 要像封装函数模块一样，只负责一个清晰的逻辑单元
并且当前 change 中，root-change 做的不好，引导不足

并且避免深层次引用，也就是 Agents.md -- 文件 A --提醒要去读文件 B -- 提醒去读文件C；如果 A, B, C 都重要，应该在顶层直接明确指出：并行阅读 A, B, C

## Relational Context
<!-- Constraints, preferences, related filelinks -->
src/sspec/templates/AGENTS.md
src/sspec/templates/skills/
src/sspec/templates/change/
src/sspec/templates/change-root/
.sspec/tmp/openspec-v1-demo

---

## @AGENT
<!-- What should Agent do to implement this request -->
Please initiate the "request → change" workflow for this request.
(You need to consult `sspec-change` SKILL)

请深入分析当前的情况，并给出你的新的规划方案、整体蓝图
积极 question/ask 我
