我来研究代码结构，然后给出明确的设计和更改方案。

🔧 **工具调用:** view

查看当前项目结构

> 💭 思考中...

根据你提供的代码和需求，我来给出完整的设计和更改方案。

---

# SSPEC Skill 系统重构设计方案

## 一、现状分析

### 当前问题

1. **模板结构不符合 Claude Skill 规范**

   * 现有 `templates/skills/*.md` 是扁平文件结构
   * Claude 规范是 `<skill-name>/SKILL.md` 目录结构

2. **Skills 分散且未与工作空间集成**

   * 只复制到 `.sspec/skills/`
   * 未考虑 `.github`、`.claude` 等 AI 工具的工作空间目录

3. **缺少版本管理机制**

   * 无法判断 skill 是否需要更新
   * `UPDATABLE_FILES` 列表手动维护

---

## 二、新设计方案

### 2.1 模板结构重组

**变更前：**

```
templates/skills/
├── sspec-status-guide.md
└── sspec-workflow.md
```

**变更后：**

```
templates/skills/
└── sspec/
    └── SKILL.md    # 合并两个文件
```

### 2.2 SKILL.md 规范格式

```yaml
---
skill: sspec
version: 1.0.0
schema: "3.1"           # 新增：用于 update 命令版本检测
description: SSPEC workflow, status definitions, and best practices
---

# SSPEC Skill

## Purpose
...

## Workflow Guide
(原 sspec-workflow.md 内容)

## Status Guide
(原 sspec-status-guide.md 内容)
```

### 2.3 工作空间目录策略

**核心原则**：sspec 不管理 skills 生命周期，只在 init 时"注入"到存在的工作空间。

```python
# core.py 新增
WORKSPACE_DIRS = ['.github', '.claude']  # 可扩展
SKILL_SUBDIR = 'skills'                  # 工作空间内的 skills 子目录
```

**复制逻辑**：

```
init 时检测:
├── .github/ 存在 → 复制到 .github/skills/sspec/SKILL.md
├── .claude/ 存在 → 复制到 .claude/skills/sspec/SKILL.md
└── .sspec/skills/ → 始终复制（向后兼容）
```

### 2.4 Update 命令的 Skill 更新机制

通过 YAML front matter 中的 `schema` 字段判断是否需要更新：

```python
def should_update_skill(installed_path: Path, template_path: Path) -> bool:
    """比较 schema 版本决定是否更新"""
    installed_schema = parse_skill_schema(installed_path)
    template_schema = parse_skill_schema(template_path)
    return template_schema > installed_schema
```

---

## 三、具体代码更改

### 3.1 `core.py` 变更

```python
# === 新增常量 ===
WORKSPACE_DIRS = ['.github', '.claude']
SKILL_SUBDIR = 'skills'

# === 修改 UPDATABLE_FILES ===
# 移除 skills 相关条目，改用动态检测
UPDATABLE_FILES: list[str] = [
    # 'skills/sspec-workflow.md',      # 删除
    # 'skills/sspec-status-guide.md',  # 删除
]

# === 新增函数 ===
def parse_skill_metadata(skill_path: Path) -> dict:
    """解析 SKILL.md 的 YAML front matter"""
    if not skill_path.exists():
        return {}
    content = skill_path.read_text(encoding='utf-8')
    if not content.startswith('---'):
        return {}
    parts = content.split('---', 2)
    if len(parts) < 3:
        return {}
    try:
        return yaml.safe_load(parts[1]) or {}
    except yaml.YAMLError:
        return {}


def get_workspace_skill_targets(project_root: Path) -> list[Path]:
    """获取所有应该安装 skills 的目标目录"""
    targets = []
    for ws_dir in WORKSPACE_DIRS:
        ws_path = project_root / ws_dir
        if ws_path.is_dir():
            targets.append(ws_path / SKILL_SUBDIR)
    # .sspec/skills 始终包含
    targets.append(project_root / SSPEC_DIR / SKILL_SUBDIR)
    return targets


def list_template_skills() -> list[Path]:
    """列出模板中所有 skill 目录"""
    template_skills_dir = get_template_dir() / 'skills'
    if not template_skills_dir.exists():
        return []
    return [d for d in template_skills_dir.iterdir()
            if d.is_dir() and (d / 'SKILL.md').exists()]
```

### 3.2 `commands/project.py` init 命令变更

```python
@project.command()
@click.option('--force', is_flag=True, help='Overwrite existing .sspec directory')
def init(force: bool) -> None:
    """Initialize .sspec directory in current project."""
    from sspec.core import (
        get_workspace_skill_targets,
        list_template_skills,
    )

    sspec_path = Path.cwd() / SSPEC_DIR
    project_root = Path.cwd()

    if sspec_path.exists() and not force:
        raise click.ClickException(...)

    template_dir = get_template_dir()
    common_replacements = {'SCHEMA_VERSION': SCHEMA_VERSION, 'SCHEMA': SCHEMA_VERSION}

    # 创建 .sspec 目录结构
    sspec_path.mkdir(parents=True, exist_ok=True)
    (sspec_path / 'changes').mkdir(exist_ok=True)
    (sspec_path / 'changes' / 'archive').mkdir(exist_ok=True)
    (sspec_path / 'requests').mkdir(exist_ok=True)
    (sspec_path / 'skills').mkdir(exist_ok=True)

    # === 新增：复制 skills 到所有工作空间 ===
    template_skills = list_template_skills()
    skill_targets = get_workspace_skill_targets(project_root)

    for skill_dir in template_skills:
        skill_name = skill_dir.name
        for target_dir in skill_targets:
            dest_skill_dir = target_dir / skill_name
            dest_skill_dir.mkdir(parents=True, exist_ok=True)
            # 复制整个 skill 目录
            for item in skill_dir.iterdir():
                dest_path = dest_skill_dir / item.name
                if item.is_file():
                    copy_template(item, dest_path, common_replacements)
                else:
                    shutil.copytree(item, dest_path, dirs_exist_ok=True)

    # 输出复制结果
    for target_dir in skill_targets:
        if target_dir.exists():
            rel = target_dir.relative_to(project_root)
            console.print(f'  [green]✓[/green] Installed skills to {rel}/')

    # ... 其余初始化逻辑不变 ...
```

### 3.3 `commands/project.py` update 命令变更

```python
@project.command()
@click.option('--dry-run', is_flag=True, ...)
@click.option('--force', is_flag=True, ...)
@click.option('--interactive', '-i', is_flag=True, ...)
def update(dry_run: bool, force: bool, interactive: bool) -> None:
    """Update project templates while preserving user changes."""
    from sspec.core import (
        get_workspace_skill_targets,
        list_template_skills,
        parse_skill_metadata,
    )

    # ... 原有文件更新逻辑 ...

    # === 新增：Skills 更新检测 ===
    console.print()
    console.print('[bold]Skills Update[/bold]')

    template_skills = list_template_skills()
    skill_targets = get_workspace_skill_targets(sspec_root.parent)
    skill_updates = []

    for skill_dir in template_skills:
        skill_name = skill_dir.name
        template_skill_file = skill_dir / 'SKILL.md'
        template_meta = parse_skill_metadata(template_skill_file)
        template_schema = template_meta.get('schema', '0')

        for target_dir in skill_targets:
            installed_skill_file = target_dir / skill_name / 'SKILL.md'

            if not installed_skill_file.exists():
                status = 'missing'
                action = '[green]create[/green]'
            else:
                installed_meta = parse_skill_metadata(installed_skill_file)
                installed_schema = installed_meta.get('schema', '0')

                if installed_schema == template_schema:
                    status = 'current'
                    action = '[dim]skip[/dim]'
                elif installed_schema < template_schema:
                    status = 'outdated'
                    action = '[yellow]update[/yellow]'
                else:
                    status = 'newer'  # 用户自己升级过
                    action = '[dim]skip (newer)[/dim]'

            skill_updates.append({
                'skill': skill_name,
                'target': target_dir,
                'status': status,
                'action': action,
                'template_dir': skill_dir,
            })

    # 显示 skills 更新表格
    skill_table = Table(title='Skills Status')
    skill_table.add_column('Skill')
    skill_table.add_column('Location')
    skill_table.add_column('Status')
    skill_table.add_column('Action')

    for upd in skill_updates:
        rel_target = upd['target'].relative_to(sspec_root.parent)
        skill_table.add_row(upd['skill'], str(rel_target), upd['status'], upd['action'])

    console.print(skill_table)

    if dry_run:
        return

    # 执行 skill 更新
    for upd in skill_updates:
        if upd['status'] in ('missing', 'outdated'):
            if interactive and not click.confirm(f"Update skill {upd['skill']} in {upd['target']}?"):
                continue
            dest_skill_dir = upd['target'] / upd['skill']
            dest_skill_dir.mkdir(parents=True, exist_ok=True)
            for item in upd['template_dir'].iterdir():
                dest_path = dest_skill_dir / item.name
                copy_template(item, dest_path, common_replacements)
            console.print(f"  [green]✓[/green] Updated {upd['skill']} in {upd['target']}")
```

### 3.4 模板文件变更

**删除：**

* `templates/skills/sspec-status-guide.md`
* `templates/skills/sspec-workflow.md`

**新建：** `templates/skills/sspec/SKILL.md`

```markdown
---
skill: sspec
version: 1.0.0
schema: "3.1"
description: SSPEC workflow, status definitions, and best practices
---

# SSPEC Skill

## Purpose

Provides comprehensive guidance for using sspec to manage AI-assisted development workflows.

## Workflow Guide

### Session Start Patterns

#### Pattern 1: Resume Existing Work
```

User: @resume
Agent:

1. Identifies active change
2. Reads handover.md → tasks.md → spec.md
3. Outputs context summary

```

(... 合并原 sspec-workflow.md 的内容 ...)

## Status Guide

### Change Status Definitions

#### PLANNING
**Meaning**: Defining scope, approach, and creating task plan.

(... 合并原 sspec-status-guide.md 的内容 ...)
```

### 3.5 `commands/skill.py` 调整

简化 `new` 命令，默认使用 complex 模式：

```python
@skill.command()
@click.argument('name')
def new(name: str) -> None:
    """Create a new skill directory with SKILL.md."""
    try:
        sspec_root = get_sspec_root()
    except SspecNotFoundError:
        raise click.ClickException(...) from None

    skills_dir = sspec_root / 'skills'
    skill_dir = skills_dir / name

    if skill_dir.exists():
        raise click.ClickException(f"Skill '{name}' already exists")

    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / 'SKILL.md'

    template_content = f"""---
skill: {name}
version: 1.0.0
schema: "{SCHEMA_VERSION}"
description: ""
---

# {name}

## Purpose

<!-- Describe what this skill helps the AI to accomplish -->

## Guidelines

<!-- Provide specific instructions -->

## Examples

<!-- Show example usage patterns -->
"""
    skill_file.write_text(template_content, encoding='utf-8')

    console.print(f'[green]✓[/green] Created skill: {name}/')
    console.print(f'  {skill_dir.relative_to(sspec_root.parent)}/')
    console.print('  └── SKILL.md')
```

---

## 四、数据流示意

```
sspec project init
        │
        ▼
┌───────────────────────────────────┐
│  检测 templates/skills/ 下的      │
│  <skill-name>/SKILL.md 目录       │
└───────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────┐
│  检测项目根目录下的工作空间目录    │
│  [.github, .claude] 是否存在      │
└───────────────────────────────────┘
        │
        ├──▶ .github/ 存在
        │       └──▶ 复制到 .github/skills/sspec/SKILL.md
        │
        ├──▶ .claude/ 存在
        │       └──▶ 复制到 .claude/skills/sspec/SKILL.md
        │
        └──▶ 始终
                └──▶ 复制到 .sspec/skills/sspec/SKILL.md
```

```
sspec project update
        │
        ▼
┌───────────────────────────────────┐
│  对比每个位置的 SKILL.md          │
│  schema 字段与模板版本            │
└───────────────────────────────────┘
        │
        ├──▶ schema 相同 → skip
        ├──▶ schema 较旧 → update
        └──▶ schema 较新 → skip (用户自定义)
```

---

## 五、迁移策略

对于已有项目的平滑迁移：

```python
# 在 update 命令中添加迁移逻辑
def migrate_legacy_skills(sspec_root: Path) -> None:
    """将旧版扁平 skill 文件迁移为目录结构"""
    skills_dir = sspec_root / 'skills'

    legacy_files = [
        'sspec-workflow.md',
        'sspec-status-guide.md',
    ]

    legacy_found = [f for f in legacy_files if (skills_dir / f).exists()]

    if legacy_found:
        console.print('[yellow]Migrating legacy skills...[/yellow]')
        # 备份后删除，让 update 重新安装
        for f in legacy_found:
            legacy_path = skills_dir / f
            backup_path = skills_dir / f'{f}.bak'
            shutil.move(legacy_path, backup_path)
            console.print(f'  Backed up {f} → {f}.bak')
```

---

## 六、变更文件清单

| 文件                                       | 操作 | 说明                             |
| ---------------------------------------- | -- | ------------------------------ |
| `src/sspec/core.py`                      | 修改 | 新增 `WORKSPACE_DIRS`、skill 解析函数 |
| `src/sspec/commands/project.py`          | 修改 | init/update 命令增加工作空间复制逻辑       |
| `src/sspec/commands/skill.py`            | 修改 | 简化 new 命令，默认 complex 模式        |
| `templates/skills/sspec-workflow.md`     | 删除 | 合并到新结构                         |
| `templates/skills/sspec-status-guide.md` | 删除 | 合并到新结构                         |
| `templates/skills/sspec/SKILL.md`        | 新建 | 合并后的 skill 文件                  |

---

需要我输出完整的变更代码文件吗？
