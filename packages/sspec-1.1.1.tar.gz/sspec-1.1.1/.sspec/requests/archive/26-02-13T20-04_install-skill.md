---
name: install-skill
created: 2026-02-13 20:04:48
status: DOING
attach-change: .sspec/changes/archive/26-02-13T20-29_install-skill/spec.md
tldr: 重构 SKILL 安装为 hub-spoke sync 体系，先完成调研方案并待审查后执行。
archived: '2026-02-14T15:12:29'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: install-skill

## Context
<!-- Current situation, background info -->
当前的 SSPEC 项目支持内置 SKILL ，用来支撑 SSPEC 的流程。
而在安装的时候，会尝试提权，把其他的比如 .github, .claude 等地方也安装 SKILL，方法是先尝试创建符号链接，失败了就 copy 过去。

## Problem
<!-- What's not working or missing -->
目前的做法是一个个创建符号链接，过于麻烦，而且不优雅。
并且当前的做法在交互上也不好，一上来就是强制让选择指定 SKILL 位置。
不好

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->
我打算重构，想法如下

**交互**
先完成基本的安装，打印
然后 prompt 用户需要在指定位置安装 SKILL （必要）
选择需要安装的位置之后，

**安装逻辑** （新的体系下，称为 sync skills）
核心：.sspec/skills 是最核心的 SKILL，其他的都是指向他

- 如果原本位置不存在 xx/skills
  - 首先尝试符号链接 linux 下可能成功，windows 下可能失败
  - 并且是 windows 系统，就 prompt 用户
    - 申请管理员身份创建符号链接
    - 创建 junction link
  - 还是失败，就回退到 copy 安装
- 如果原本的位置有 skills
  - 如果是指向 sspec skills 的链接，就直接调过，说明是 Ok 的
  - 如果是普通目录，就扫描并尝试同步更改
    - 首先备份到 .sspec/tmp 下
    - 将不在 .sspec/skills 下的 SKILL copy 到下面
    - 删除原始 SKILL 目录，走上一种情况

**project update skill**
逻辑和上面的基本一致，由于现在不在关心到底哪些 SKILL 是 sspec 专属，所以也许会简单不少

🤔 我不确定的疑问：需要 Agent 回答
我已经确认了，Agent 系统能正确识别符号链接，那 windows 下的 Junction 链接能正确识别吗？
使用 Junction 链接是正确做法吗？

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->

- 在 tmp 下创建新的 project，init 之后，正确安装，并且 Agent 也能识别
- 更新一个已经存在的项目，能完成任务
- 运行 project update ，能自动顺滑迁移之前版本的 SSPEC 项目
（比如当前项目就是旧版本，.claude, .github 下都有若干指向 .sspec 的链接）

## Relational Context
<!-- Constraints, preferences, related filelinks -->

- src/sspec/commands/project.py
- src/sspec/services/project_init_service.py
- src/sspec/services/project_update_service.py
- src/sspec/skill_installer.py

---

## @AGENT
<!-- What should Agent do to implement this request -->
Please initiate the "request → change" workflow for this request.
(You need to consult `sspec-change` SKILL)

由于当前的 SKILL 安装、 更新逻辑都比较复杂，所以现建议你深入调研，并编写一个调研和优化报告，并给用户审查
/sspec-ask

---
