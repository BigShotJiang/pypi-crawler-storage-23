---
name: fix-skill-install-update
created: 2026-02-11 18:38:31
status: DONE
attach-change: null
tldr: 'Fix SKILL init/update: hub copy + symlink fallback; update skips symlinks'
archived: '2026-02-13T20:05:55'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: fix-skill-install-update

## Context
<!-- Current situation, background info -->

- src/sspec/services/project_init_service.py
- src/sspec/services/project_update_service.py
- src/sspec/skill_installer.py
- Current git status

我刚刚让别的模型尝试完成我想要的功能，但是一团糟

## Problem
<!-- What's not working or missing -->

确保 sspec project init, update 在应对 SKILL 上处理逻辑正确无误

- project init 的时候，对 SKILL 的处理
  - copy --> .sspec/skill
  - 其他的 .github, .agnet etc --> symlink to .sspec/skill
  - 如果 symbol link 创建失败就 fallback 到 copy 逻辑
- project update 的时候，正确处理应该有的逻辑
  - 对于 copy 创建的 SKILL，update 其内容
  - 对于 symbol link，就不管，调过

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->

请分析整体项目和当前代码空间
进入 /auto 模式完成这个任务

/sspec-ask
Micro-change

## Plan
- Fix `project init` skill strategy recording to use consistent location keys and prefer `copy` if any fallback copy occurred.
- Fix `project update` so symlinked skills are skipped and only copied skills are updated.
- Run tests.

## Done
- Updated init meta recording to be consistent and stable.
- Updated update candidate collection: symlinked skill dirs are ignored; copy-installed skills are updated by directory hash.
- Ran `pytest` (one unrelated failing test remains in `tests/test_request_service.py`).


<!-- ============================================================
     MICRO-CHANGE ZONE (optional)
     For tiny changes (≤3 files, ≤30min) that don't need a full change.
     Remove these sections if a change is created instead.
     ============================================================ -->

<!--
## Plan
Quick implementation plan (what files to touch, what to do)

## Done
What was actually done + any notes for future reference
-->
