---
attach-change: built-in-ask-prompt
created: 2026-02-04 15:12:13
status: DONE
tldr: Added sspec ask CLI with persisted Q/A records in .sspec/asks, plus sspec-ask
  skill and AGENTS.md template block.
archived: '2026-02-05T18:55:44'
---
# Request: built-in-ask-prompt

## Context
<!-- What's the current situation? Any background info that helps understand the request. -->
我在开发的过程中很喜欢使用 Ask Prompt，你可以参考 Agents.md 中的定义和 Ask Prompt SKILL.

## Problem
<!-- What's not working or missing? Describe the gap or pain point you're experiencing. -->
当前版本的 Ask Skill 存在的不足是:
- 需要 Agents 自己写 python 代码
- Ask 完了也就没了，而 Ask 的过程记录也很重要，却无法被保留

## Initiative / Proposal
<!-- Your initial idea or direction — even rough thoughts are fine. -->
我的想法是模仿 Ask Prompt，把它内化到 sspec 中。
我创建了一个 src/sspec/services/ask_service.py 在此基础上我们新增一个 CLI command sspec ask
```
sspec ask --name str --question str [--why: str]
```

Agents 可以:在 Bash/Powershell 中运行 sspec ask, 并传入多行字符串 question，例如
```bash
sspec ask --name "test_error" --why "无法理解为何test命令总是出错" --question << 'EOF'
请问...
EOF
```
```powershell
sspec ask --question @'
请问...
'
```

我们就可以运行：
- 运行 ask_service.py 中，获取输入输出时间
- 在 .sspec/asks/ 下创建 `<time>-<name>.md` 里面记录
  - 时间
  - why
  - 提问
  - 回答
- 打印给 Agents: 用户的回答，并且告知可以在 XXX 文件中看到记录

此外，还有必要编写 sspec-ask 的 SKILL （请阅读编写 SKILL 的 SKILL 文档），并在在 Agents.md 中新增一小段，不要太长（请阅读编写 Agents.md 中的规范）
```
<!-- SSPEC-ASK:Start -->
<!-- SSPEC-ASK:END -->
```
