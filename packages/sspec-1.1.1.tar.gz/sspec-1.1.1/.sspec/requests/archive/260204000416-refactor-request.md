---
created: 2026-02-04T00:04:16
status: OPEN
attach-change: refactor-request-cli
tldr: "重构 sspec request 命令，改成子命令模式"
---

# Request: refactor-request

## Context
<!-- What's the current situation? Any background info that helps understand the request. -->

当前的交互 src/sspec/commands/request.py 的 CLI 模式和别人都不同

## Problem
<!-- What's not working or missing? Describe the gap or pain point you're experiencing. -->

当前情况下 sspec request <name> 直接就是发起一个新的 RQ，不像 sspec change new <name> 那样
而一些子命令都被拆分在 --args 当中

我希望重构 sspec request 命令，改成和其他一样的命令 - 子命令

## Initiative / Proposal
<!-- Your initial idea or direction — even rough thoughts are fine. -->

把 request 拆分成子命令
- new
- list
- archive
等

此外如果使用旧版本的 `sspec request <name>` 则打印告知是否要创建一个新的 request，如果是 yes 就执行 new 操作

此外 archive 子命令目前疑似存在 bug，请仔细检查

<!-- If you have specific approaches in mind, sketch them here. -->

