需求：请重构 CLI 体系。

## Proposal | 改为如下方案

- 新增 project 命令
  - spec project init
  - spec project status （拆分自 status）
  - spec project update （拆分自 update）
- new --> change; 多个子命令
  - change new (默认)
  - change list (拆分自 list_cmd)
  - change archive <name>（拆分自 archive）
- request 不变
- init 去掉，合并到 project 命令中
- update 去掉，合并到 project 命令中
- 增加 skill
  - skill list （拆分自 list_cmd）
  - skill new [--mode="simple" | "complex"]
    - 默认 simple：创建一个单 markdown 文件
    - complex 模式：创建 <dir>/SKILL.md

## Agents Requirement

为保证开发连贯性。

请将本文件作为 Working File。在开发过程中，将任务分解、开发状态列在下方，并随着开发实时更新。

<!-- @Agent: Use following during dev -->
## Agent | Progress

✅ Research - 已完成代码调研，理解当前 CLI 结构
✅ Planning - 完成重构方案规划
✅ Execution - 完成所有代码实施
✅ Testing - 完成 CLI 命令测试

**重构完成！** 所有新命令和向后兼容性均正常工作。

## Agent | Tasks

1. ✅ 研究现有 CLI 代码结构
   - 理解 cli.py 主入口
   - 理解各个命令的实现（init, status, update, list_cmd, archive, new）

2. ✅ 创建新的命令文件
   - 创建 commands/project.py（包含 init, status, update 子命令）
   - 创建 commands/change.py（包含 new, list, archive, status 子命令）
   - 创建 commands/skill.py（包含 list, new 子命令）

3. ✅ 迁移代码逻辑
   - 将 init.py 的逻辑迁移到 project.py 的 init 子命令
   - 将 status.py 的逻辑拆分到 project.py 的 status 和 change.py 的 status
   - 将 update.py 的逻辑迁移到 project.py 的 update 子命令
   - 将 new.py 的逻辑迁移到 change.py 的 new 子命令
   - 将 list_cmd.py 的变更列表逻辑迁移到 change.py 的 list 子命令
   - 将 list_cmd.py 的技能列表逻辑迁移到 skill.py 的 list 子命令
   - 将 archive.py 的逻辑迁移到 change.py 的 archive 子命令

4. ✅ 更新 cli.py 主入口
   - 注册新的 project, change, skill 命令组
   - 保留旧命令作为向后兼容别名

5. ✅ 测试工作
   - 测试所有新的命令组（project, change, skill）
   - 测试向后兼容性（init, new, update, list, status, archive）
   - 验证 skill new 的两种模式（simple/complex）

## 重构总结

### 新的 CLI 结构

**主命令组**：
- `sspec project` - 项目级操作
  - `project init` - 初始化项目
  - `project status` - 项目状态概览
  - `project update` - 更新模板

- `sspec change` - 变更管理
  - `change new <name>` - 创建新变更（或直接 `sspec change <name>`）
  - `change list` - 列出变更
  - `change status [name]` - 查看变更详情
  - `change archive [name]` - 归档变更

- `sspec skill` - 技能管理
  - `skill list` - 列出技能
  - `skill new <name>` - 创建技能（支持 --mode simple/complex）

- `sspec request` - 请求管理（保持不变）

**清理完成**：
- ✅ 删除所有旧命令文件（archive.py, init.py, list_cmd.py, new.py, status.py, update.py）
- ✅ 移除向后兼容别名，保持 CLI 清爽
- ✅ 修复所有 ruff lint 错误
- ✅ 更新 imports 使用 collections.abc.Mapping

### 技术实现亮点

1. **命令组设计**：使用 Click 的 `@click.group()` 创建层级化命令结构
2. **默认行为**：`sspec change <name>` 自动调用 `change new`
3. **异常链处理**：所有异常使用 `from None` 或 `from e` 保持清晰的错误追踪
4. **skill 双模式**：支持简单单文件和复杂目录结构两种创建方式
5. **代码质量**：通过 ruff 检查，符合现代 Python 最佳实践

### 最终状态

```
sspec/
├── project (新)
│   ├── init
│   ├── status
│   └── update
├── change (新)
│   ├── new
│   ├── list
│   ├── status
│   └── archive
├── skill (新)
│   ├── list
│   └── new
└── request (保持)
```

所有测试通过 ✅ Ruff 检查通过 ✅
