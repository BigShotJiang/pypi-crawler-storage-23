Background: 当前的 sspec cli 体系中照猫画虎弄了一个 SKILL，却没有很好地集成到规范实践当中。所以这部分需要重构。

## 新设计方案 ##

原则：我们不管理 SKILLS，只是在初始化的时候把 sspec 的 SKILL 插入工作空间（如 .github, claude 等中）

- 遵循 Claude Skill 的规范
- 调整 src/sspec/templates/skills/ 中；改成 <DIR>/SKILL.md 的规范方案
  - 合并成 sspec skill

- 重构 CLI init 的时候的逻辑，把 skills 下的 copy 到正确的路径下
    - 定义 WORKSPACE_DIR ，初始默认 `[.github, .claude]`
    - 如果有，就 copy 到这下面的 skills/ 目录中

- SKILL.md YAML 中增加 schema 字段，给 update 命令用
  - 如果 udpate 的时候最新版本的 skill 更新，就更新 skill


## 方案

我咨询了 Claude 先生，他给出了具体的行动方案建议，见 spec/重构 SKILL 行动方案.md

请评估方案是否可行，如果可行根据方案行动。