---
name: built-in-toc
created: 2026-02-22 15:02:35
status: DOING
attach-change: .sspec/changes/archive/26-02-22T15-11_built-in-toc/spec.md
tldr: ''
archived: '2026-02-24T23:38:34'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: built-in-toc

## Background
<!-- Current situation, background information -->
sspec 支持 built-in tool 作为开发过程中的辅助工具

## Problem
<!-- What is not working or missing -->
在 Agentic 开发过程中，阅读 markdown 是非常常见的需求。
但是 Agent 在阅读 MD 文档时，很容易陷入：不知道文档多大，不知道文档结果，不知道应该阅读哪些 chunk
本质是因为 Markdown 缺乏直接可用的 Outline 信息

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->
请增加一个 mdtoc 的 built-in 工具，并注册到 Tools 中
然后增加一个 sspec-mdtoc 的 SKILL，告诉 Agent 可以用这个指令来分析长 Md

mdtoc 支持参数：<source>, 可以是 file path，也可以是 dir(会自动 glob 下方所有的 md) 也可以是 glob 模式

mdtoc 会打印：
- 文件路径
- 字符数、行数
- TOC 结构 —— 特别是每个标题开始的行号 （1-based），格式为 L<number>
如果是多个文件，也能自动良好的格式化

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->

1. 用户可以直接调用 CLI 了解 md 结构
2. SKILL 对 Agent 友好；并且在 desc 中指出，在分析文档、SKILL 的时候，可以在阅读之前调用这个 tool 进行元信息分析

## Relational Context
<!-- Constraints, preferences, related filelinks -->
- G:\shims\mdtoc.ps1
- .sspec/spec-docs/builtin-tools.md （重要，请阅读）

---

## @AGENT
<!-- What should Agent do to implement this request -->
Please initiate the "request → change" workflow for this request.
(You need to consult `sspec-change` SKILL)

---

<!-- ============================================================
     MICRO-CHANGE ZONE (optional)
     For tiny changes (≤3 files, ≤30min) that don't need a full change.
     Remove these sections if a change is created instead.
     ============================================================ -->

<!--
## Plan
Quick implementation plan (what files to touch, what to do)

## Done
What was actually done + any notes for future reference
-->
