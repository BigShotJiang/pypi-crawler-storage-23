---
attach-change: reference-system-enhancement
created: 2026-02-05 01:41:56
status: DOING
tldr: ''
archived: '2026-02-05T18:13:46'
---
# Request: add-reference-in-spec

## Context
<!-- Current situation, background info -->
我刚刚给 spec.md 的模板增加了 reference 字段，类型为 Array
参考 git diff --cached
src/sspec/templates/change/spec.md

## Problem
<!-- What's not working or missing -->
- 很多 change 是通过 request 发起的，但是在 change 中完全看不出这个信息
- 复杂模式下，多个 change 可能互相关联，比如并列， 上下级关系等，这些信息目前都没体现

## Initiative / Proposal
<!-- Your initial idea or direction — rough thoughts are fine -->
- spec.md 中增加 reference 字段，类型为 Array<{source, type, note}>
- 运行 sspec request link 的时候，也给对应的 change reference 中增加条目
  - 核心就是确保 request ~ change 的双向链接
- sspec change new 增加可选参数 --from <request-path>
- 更新 Agents.md 和 sspec SKILL
  - Agents.md 保持当前风格，简要提及 spec.md frontmatter 注意事项
  - sspec SKILL 中明确规范 sspec frontmatter 的规则，特别是 reference
- 注意：请设计好 reference 的类型
- 引入 sub-change 的概念：对复杂修订生效 ，可能需要 break 为多个 Change
  - 请参考 Create SKILL 的 SKILL，创建一个新的 sspec-multi-change skill
  - 说明对复杂变更的做法：
    - 创建一个 root change，用于管理子 change；root change 的 reference/ script/ 放相关材料
    - 每次创建一个 sub chang 对应 root change 中的 tasks.md 中一环
    - 每个 sub change 完成就归档并发起一个新的 sub change
- 附加: 规范 request, change 的名称
  - 当前: request, change 命名格式不一致
  - archive 的时候, change 还会增加时间前缀，导致名称变化失效
  - 这些不利于引用
  - 统一规范:  request, change 均命名为 `<yy-MM-ddTHH-mm>_<name>`, 其中 name 通常是 \w 和 "-"组合; archive 之后也只是移动不改名目录名称，例如 26-02-06T12-02_check-error
    - ask 无需更名
- 附加: 建议 lib 中统一增加一个 md_yaml 的处理模块，方便做 frontmatter 的解析、写入、更新
- 在 archive request/change 之后，在 request md / spec.md 中写入 archive: <datetime> 记录归档时间

请你深入调研之后，基于这个 request 发起一个 change，并优化 sspec
期间，积极使用 sspec ask (uv run sspec <command>) 和我咨询确认

Note: 请遵循 src/sspec/templates/AGENTS.md 中 request -> change 的规范

## Additional Context
<!-- Constraints, preferences, related links -->
- src/sspec/commands/request.py
- src/sspec/commands/change.py
- src/sspec/templates/skills/
- src/sspec/templates/AGENTS.md
