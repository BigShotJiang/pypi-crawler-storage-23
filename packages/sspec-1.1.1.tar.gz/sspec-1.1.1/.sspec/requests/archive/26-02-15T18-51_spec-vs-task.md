---
name: spec-vs-task
created: 2026-02-15 18:51:27
status: DONE
attach-change: null
tldr: 'Clarified B vs C boundary: B=Design (interfaces/data/logic), C=Plan (phases/files),
  tasks.md=Checklist'
archived: '2026-02-24T23:39:18'
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: spec-vs-task

## Background
<!-- Current situation, background information -->
change 是 sspec 的核心
其中 spec 和 task 又是重点。

目前围绕这两个概念的周边服务有：
- SKILL .sspec/skills/sspec-change/
- 模板  @templates/changes
- 根规则 src/sspec/templates/AGENTS.md

## Problem
<!-- What is not working or missing -->

我注意到，当前在各个文档里，有提到 spec.md 的 Implementation Strategy 里要 file-level
这个本意应该是好的，但是在某些模型下实际造成的效果是 spec.md 和 task.md cover 的内容高度同质化。

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->

也许可以调整，要强调 spec.md 中梳理清楚各个 phase 设计到哪些文件（关键是指定impact scope，而非要细粒度一个个指出文件）
以及最重要的：涉及到的数据流和逻辑流，
如果有要调整、 新增的接口，接口要如何设计也是关键

可以在某个地方，指出如果涉及到复杂接口、 逻辑，可以在 reference 中给出数据、 逻辑层的完整设计，然后在 spec 中引用

然后 task md 更强调细粒度任务拆解和逻辑

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->

从客观的 Agent 的角度，假设你面对一个新的任务，会如何编写 spec.md / tasks.md
（在 RULE 和 SKILL 指导下）

做这样的模拟实验，然后回过头来核验。

## Relational Context
<!-- Constraints, preferences, related filelinks -->
- src/sspec/templates/AGENTS.md
- src/sspec/templates/changes
- 相关的 SKILL

---

## @AGENT
<!-- What should Agent do to implement this request -->
<!-- Please initiate the "request → change" workflow for this request.
(You need to consult `sspec-change` SKILL) -->

先不急着 change
请调研，然后给出一份完整的报告，并给出你的思考和解决方案，并 @ask ，让我看是否可行
如果顺利的话，也许不需要 change 就能解决

---

<!-- ============================================================
     MICRO-CHANGE ZONE (optional)
     For tiny changes (≤3 files, ≤30min) that don't need a full change.
     Remove these sections if a change is created instead.
     ============================================================ -->

## Plan

**Research Phase**:
1. 调研现状：读取 AGENTS.md, SKILL (sspec-change), doc-standards.md, 模板文件
2. 分析实际案例：tools, replace-archived-link-path, install-skill
3. 发现根本问题：用户指出不是 C vs tasks.md，而是 **B vs C 边界不清晰**
4. 关键洞察：接口定义、数据模型应该在 Section B，当前标准没有明确说明

**Solution**:
- **Section B (Proposed Solution)** = Design doc (What & Why)
  - 包含：Approach, Interface Design, Data Model, Key Logic, Key Changes
  - 复杂度分级：Simple (inline), Medium (dedicated subsection), Complex (reference/)
- **Section C (Implementation Strategy)** = Execution plan (How to organize phases)
  - 引用 B 的设计，不重复细节
  - 列出 phases, file scope per phase, dependencies, risks
- **tasks.md** = Execution checklist
  - 引用 C 的 phases，细化为可执行任务

**Implementation**:
1. 更新 `doc-standards.md` — 重写 Section B/C 标准，添加对比表
2. 更新 `spec.md` 模板 — 修改 @RULE (Section B/C)
3. 更新 `AGENTS.md` — 添加 Design Principle

**Asks**:
- `.sspec/asks/archive/260215212826_spec_vs_task_solution.md` — 初步方案确认
- `.sspec/asks/archive/260215214603_spec_redesign_b_vs_c.md` — 修正方案确认（批准）

## Done

**Files Modified**:
1. `.github/skills/sspec-change/references/doc-standards.md`
   - 重写 Section B 标准：明确包含 Interface Design, Data Model, Key Logic
   - 重写 Section C 标准：强调引用 B，不重复设计
   - 添加对比表：spec.md vs tasks.md: When to Write What
   - 更新 Anti-Patterns：反映新的理解
   - 扩展 reference/ 说明：复杂设计可在 reference/design.md（follow write-spec-doc）

2. `src/sspec/templates/change/spec.md`
   - 更新 Section B @RULE：提示接口/数据模型/核心逻辑，复杂度分级
   - 更新 Section C @RULE：提示引用 B，不重复设计，必须提到关键文件

3. `src/sspec/templates/AGENTS.md`
   - 在 2.0 Request → Change Workflow 的 Design 步骤添加 Design Principle
   - 明确 B/C/tasks.md 的职责边界

**Analysis Reports**:
- `.sspec/tmp/spec-vs-task-analysis.md` — 初步分析（C vs tasks.md 角度）
- `.sspec/tmp/spec-redesign-b-vs-c.md` — 修正后分析（B vs C 角度，包含示例）

**Key Insights**:
1. 根本问题不是 C vs tasks.md，而是 **B vs C 边界不清晰**
2. 接口定义、数据模型、核心逻辑应该在 Section B（设计层）
3. Section C 应该引用 B 的设计，组织 phases，不重复细节
4. 复杂设计可以在 reference/design.md 详细描述（follow write-spec-doc SKILL）
5. 避免重复的核心：B=Design (What & Why), C=Plan (How), tasks.md=Checklist (What to do)

**Next Steps**:
- 在实际使用中验证新标准的效果
- 如果发现问题，进一步调整
