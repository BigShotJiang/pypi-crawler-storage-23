---
name: refactor-clean-code
created: 2026-02-05 19:25:08
status: DOING
attach-change: changes/archive/26-02-05T19-28_refactor-clean-code/spec.md
tldr: ''
archived: '2026-02-07T18:47:09'
---
# Request: refactor-clean-code

遵循 Clean Code 原则（SOLID, YAGNI ，参考 clean code skill）当前架构存在不足

## 一、现状问题分析

### 1.1 架构不对称

| 维度 | Change | Request | 问题 |
|------|--------|---------|------|
| 业务逻辑位置 | `core.py` | `services/request_service.py` | Change 缺少独立 service 层 |
| 数据类型 | `ChangeInfo`（TypedDict） | `RequestInfo`（frozen dataclass） | 类型定义风格不统一 |
| 查找方式 | 直接拼接 `sspec_root / 'changes' / name` | `find_request_matches()` 模糊匹配 | Change 无统一查找抽象 |
| 列表函数签名 | `list_changes(sspec_root)` | `list_requests(requests_dir)` | 入参粒度不一致 |
| archive 入参 | `archive_change(sspec_root, change_info)` | `archive_request_file(requests_dir, request_file)` | 一个传 Info 对象，一个传 Path |

### 1.2 具体问题清单

**P1：find_change 无统一抽象**

`commands/change.py` 中多处硬编码路径拼接：

```python
# status 命令
change_path = sspec_root / 'changes' / name

# archive 命令（单个模式）
change_path = sspec_root / 'changes' / name
```

而 Request 侧有 `find_request_matches()` 做模糊匹配 + 时间戳前缀剥离。Change 的文件名同样带时间戳前缀（`25-02-05T14-30_fix-auth`），但查找时要求用户输入完整目录名，体验差。

**P2：业务函数传递 Path 而非 Info 对象**

`archive_request_file` 接收 `request_file: Path`，内部需要重新读取文件解析。而 `archive_change` 接收 `ChangeInfo`，已包含解析结果。Request 侧应对齐 Change 的做法。

**P3：archive 交互逻辑不同**

- **Change archive**：所有 active change 均可选，DONE 的预勾选
- **Request archive**：仅 DONE/CLOSED 的预勾选，其余也列出但不勾选
- Change 用 `ChangeInfo` dict，Request 用 `RequestInfo` dataclass
- Change 单项时直接 confirm，Request 单项也 confirm 但代码路径不同

**P4：link 存储的是 change_name 字符串**

```yaml
# 当前 request frontmatter
attach-change: 25-02-05T14-30_fix-auth
```

用户看到的是一个目录名，无法直接跳转到 spec。应该存储 `changes/<name>/spec.md` 的相对路径。

**P5：archive 时不更新交叉引用**

归档 change 时，其关联 request 的 `attach-change` 仍指向 `changes/<name>`（已不存在）。归档 request 时，其关联 change 的 `reference` 中的 `source` 也失效。

---

## 二、目标架构

### 2.1 统一原则

1. **Service 层承载业务逻辑**：`change_service.py` + `request_service.py`，`core.py` 仅保留共享基础设施
2. **统一数据类型**：Change 和 Request 均使用 frozen dataclass
3. **统一查找抽象**：`find_change_matches()` / `find_request_matches()` 签名对齐
4. **传 Info 对象，不传 Path**：业务函数入参为 dataclass 实例
5. **archive 交互统一**：均使用多选，预勾选 DONE/CLOSED
6. **link 存储 spec.md 路径**
7. **archive 时更新交叉引用**

### 2.2 目标文件结构

```
services/
├── change_service.py    # 新增：从 core.py 抽离 change 业务逻辑
├── request_service.py   # 重构：对齐 change_service 接口风格
├── editor_service.py    # 不变
├── meta_service.py      # 不变
├── ...
core.py                  # 瘦身：仅保留共享类型定义、模板、工具函数
```

---

## 三、执行手册

### Phase 1：统一数据类型（低风险，无行为变更）

**目标**：将 `ChangeInfo` 从 TypedDict 迁移为 frozen dataclass，与 `RequestInfo` 风格一致。

**文件**：`core.py`

**操作**：

```python
# 删除 ChangeInfo TypedDict，替换为：
@dataclass(frozen=True, slots=True)
class ChangeInfo:
    name: str
    path: Path
    status: str
    type: str
    description: str
    progress: dict[str, int]
    has_pivot: bool
    has_blockers: bool
    archived: bool
```

**影响面**：

- `core.py` 内 `parse_change()` 返回值从 dict 构造改为 `ChangeInfo(...)` 构造
- `commands/change.py` 所有 `change['name']` 改为 `change.name`（属性访问）
- `core.py` 内 `list_changes()` 返回类型注解更新
- `core.py` 内 `archive_change()` 参数类型不变（已经是 ChangeInfo）

**验证**：全量测试通过，`sspec change list` / `sspec change archive` 行为不变。

---

### Phase 2：创建 `change_service.py`，抽离业务逻辑

**目标**：将 `core.py` 中 change 相关函数移入 `services/change_service.py`。

**从 `core.py` 移出的函数**：

| 函数 | 目标位置 |
|------|---------|
| `parse_change()` | `change_service.py` |
| `create_change()` | `change_service.py` |
| `archive_change()` | `change_service.py` |
| `list_changes()` | `change_service.py` |

**`core.py` 保留内容**：

- 常量定义（`SSPEC_DIR`, `CHANGES_DIR`, `ARCHIVE_DIR` 等）
- 枚举类型（`ChangeStatus`, `RequestStatus`）
- 数据类（`ChangeInfo`, `SkillInfo`）
- 通用工具函数：`find_sspec_root()`, `get_sspec_root()`, `get_template_dir()`, `copy_template()`, `render_template()`
- `normalize_status()`, `STATUS_ALIASES`
- Skill 相关函数（`list_skills`, `parse_skill_metadata` 等）
- 异常类

**新文件 `services/change_service.py` 框架**：

```python
"""Change-related domain logic (no click/rich/questionary)."""

from __future__ import annotations

import re
import shutil
from datetime import datetime
from pathlib import Path

from sspec.core import (
    ARCHIVE_DIR,
    CHANGE_TEMPLATE_FILES,
    CHANGES_DIR,
    ChangeExistsError,
    ChangeInfo,
    ChangeNotFoundError,
    ChangeStatus,
    InvalidChangeNameError,
    copy_template,
    get_template_dir,
    normalize_status,
)
from sspec.libs.md_yaml import parse_frontmatter, update_frontmatter


def find_change_matches(changes_dir: Path, name: str) -> list[Path]:
    """Find change directory candidates by exact or fuzzy match.

    Supports timestamped format: <yy-MM-ddTHH-mm>_<name>
    """
    # Exact directory match
    exact = changes_dir / name
    if exact.is_dir() and exact.name != ARCHIVE_DIR:
        return [exact]

    # Pattern: *_<name>
    matches = [
        d for d in changes_dir.iterdir()
        if d.is_dir()
        and d.name != ARCHIVE_DIR
        and d.name.endswith(f'_{name}')
    ]
    if matches:
        return sorted(matches)

    # Contains match (fallback)
    contains = [
        d for d in changes_dir.iterdir()
        if d.is_dir()
        and d.name != ARCHIVE_DIR
        and name in d.name
    ]
    return sorted(contains)


def extract_change_name_from_dirname(dirname: str) -> str:
    """Extract pure change name from directory name (remove timestamp prefix).

    Format: <yy-MM-ddTHH-mm>_<name> -> <name>
    """
    if '_' in dirname:
        parts = dirname.split('_', 1)
        if len(parts) > 1:
            return parts[1]
    return dirname


def parse_change(change_path: Path, archived: bool = False) -> ChangeInfo:
    ...  # 从 core.py 搬入，返回 ChangeInfo dataclass

def create_change(sspec_root: Path, change_name: str) -> Path:
    ...  # 从 core.py 搬入

def list_changes(sspec_root: Path, include_archived: bool = False) -> list[ChangeInfo]:
    ...  # 从 core.py 搬入

def archive_change(sspec_root: Path, change_info: ChangeInfo) -> Path:
    ...  # 从 core.py 搬入，增加交叉引用更新逻辑（Phase 5）
```

**`core.py` 兼容层**（可选，降低迁移风险）：

```python
# core.py 末尾添加临时兼容导入
# TODO: Remove after all callers migrate to change_service
from sspec.services.change_service import (  # noqa: E402, F401
    archive_change,
    create_change,
    list_changes,
    parse_change,
)
```

**`commands/change.py` 导入更新**：

```python
# Before
from sspec.core import (
    archive_change, create_change, list_changes, parse_change, ...
)

# After
from sspec.core import (
    ChangeExistsError, ChangeInfo, ChangeNotFoundError,
    ChangeStatus, InvalidChangeNameError, SspecNotFoundError, get_sspec_root,
)
from sspec.services.change_service import (
    archive_change, create_change, find_change_matches,
    list_changes, parse_change,
)
```

**验证**：全量测试通过，行为不变。

---

### Phase 3：统一查找抽象（`find_change_matches`）

**目标**：`commands/change.py` 中所有按名称查找 change 的地方，统一走 `find_change_matches()`。

**当前硬编码位置及改造**：

#### 3a. `change status` 命令

```python
# Before
change_path = sspec_root / 'changes' / name
if not change_path.exists():
    raise click.ClickException(f"Change '{name}' not found")

# After
from sspec.services.change_service import find_change_matches

changes_dir = sspec_root / 'changes'
matches = find_change_matches(changes_dir, name)
if not matches:
    raise click.ClickException(f"Change '{name}' not found")
if len(matches) > 1:
    # 复用 request 侧的交互选择模式
    change_path = _interactive_select_change(matches, name)
else:
    change_path = matches[0]
```

#### 3b. `change archive` 单名称模式

```python
# Before
change_path = sspec_root / 'changes' / name
if not change_path.exists():
    raise click.ClickException(f"Change '{name}' not found")
change_info = parse_change(change_path)

# After
changes_dir = sspec_root / 'changes'
matches = find_change_matches(changes_dir, name)
if not matches:
    raise click.ClickException(f"Change '{name}' not found")
if len(matches) > 1:
    change_path = _interactive_select_change(matches, name)
else:
    change_path = matches[0]
change_info = parse_change(change_path)
```

#### 3c. 新增交互选择辅助函数

```python
def _interactive_select_change(matches: list[Path], name: str) -> Path:
    """Interactive selection when multiple change matches found."""
    choices = [questionary.Choice(title=m.name, value=m) for m in matches]
    console.print(f"\n[yellow]Multiple matches for '{name}':[/yellow]")
    selected = questionary.select('', choices=choices).ask()
    if selected is None:
        raise click.ClickException('Cancelled')
    return selected
```

**验证**：`sspec change status fix-auth` 现在可以模糊匹配到 `25-02-05T14-30_fix-auth`。

---

### Phase 4：统一 archive 交互逻辑

**目标**：Change 和 Request 的 archive 命令采用完全一致的交互流程。

**统一行为规范**：

1. 无参数 → 多选模式，列出所有 active 项，DONE/CLOSED 预勾选
2. 带名称参数 → 通过 `find_*_matches()` 查找 → 单项确认
3. `--yes` 跳过确认
4. archive 后输出归档路径

**`commands/change.py` archive 命令改造**：

```python
@change.command()
@click.argument('name', required=False)
@click.option('--yes', '-y', is_flag=True, help='Skip confirmation')
def archive(name: str | None, yes: bool) -> None:
    """Archive a change."""
    try:
        sspec_root = get_sspec_root()
    except SspecNotFoundError:
        raise click.ClickException("Not a sspec project.") from None

    if not name:
        _archive_changes_interactive(sspec_root)
        return

    # 单名称模式：走统一查找
    changes_dir = sspec_root / 'changes'
    matches = find_change_matches(changes_dir, name)
    if not matches:
        raise click.ClickException(f"Change '{name}' not found")
    if len(matches) > 1:
        change_path = _interactive_select_change(matches, name)
    else:
        change_path = matches[0]

    change_info = parse_change(change_path)
    _archive_single_change(sspec_root, change_info, yes)


def _archive_changes_interactive(sspec_root: Path) -> None:
    """Interactive multi-select for archiving changes.

    与 request archive 逻辑对齐：
    - 列出所有 active 项
    - DONE/CLOSED 预勾选
    """
    changes = list_changes(sspec_root)
    active = [c for c in changes if not c.archived]

    if not active:
        raise click.ClickException('No active changes to archive')

    if len(active) == 1:
        c = active[0]
        if questionary.confirm(f"Archive '{c.name}'?", default=True).ask():
            _archive_single_change(sspec_root, c, yes=True)
        return

    choices = [
        questionary.Choice(
            title=f"{c.name} [{c.status}] - {c.progress['done']}/{c.progress['total']} tasks",
            value=c,
            checked=(c.status in (ChangeStatus.DONE.value, ChangeStatus.CLOSED.value)),
        )
        for c in active
    ]

    console.print('\n[bold]Select changes to archive:[/bold]')
    console.print('[dim](arrow keys, space to toggle, enter to confirm)[/dim]\n')

    selected = questionary.checkbox('', choices=choices).ask()
    if not selected:
        console.print('[yellow]Cancelled[/yellow]')
        return

    archived_count = 0
    for change_info in selected:
        try:
            _archive_single_change(sspec_root, change_info, yes=True)
            archived_count += 1
        except Exception as e:
            console.print(f'[red]Failed to archive {change_info.name}: {e}[/red]')

    console.print(f'\n[green]✓[/green] Archived {archived_count}/{len(selected)} change(s)')
```

**`commands/request.py` archive 对齐改造要点**：

- `_archive_single_request` 入参从 `(requests_dir, name, auto_yes)` 改为 `(sspec_root, request_info, auto_yes)`
- `archive_request_file` 在 `request_service.py` 中入参从 `request_file: Path` 改为 `request_info: RequestInfo`
- 多选逻辑复用现有结构，确保预勾选条件与 change 一致：`DONE` 或 `CLOSED`

---

### Phase 5：link 存储 spec.md 路径

**目标**：`attach-change` 字段存储 change 的 `spec.md` 相对路径，而非目录名。

**改造位置**：`services/request_service.py` → `link_request_to_change()`

```python
def link_request_to_change(
    *,
    sspec_root: Path,
    requests_dir: Path,
    request_file: Path,
    change_name: str,
) -> None:
    change_path = sspec_root / 'changes' / change_name
    if not change_path.exists():
        raise FileNotFoundError(f"Change '{change_name}' not found")

    spec_file = change_path / 'spec.md'
    # 存储 spec.md 的相对路径（相对于 .sspec/）
    spec_relative = spec_file.relative_to(sspec_root).as_posix()
    # e.g. "changes/25-02-05T14-30_fix-auth/spec.md"

    # Update request file
    request_content = request_file.read_text(encoding='utf-8')
    request_content = update_frontmatter(request_content, {
        'attach-change': spec_relative,    # ← 改这里
        'status': RequestStatus.DOING.value,
    })
    request_file.write_text(request_content, encoding='utf-8')

    # Update change spec.md reference（保持不变）
    ...
```

**`change new --from` 中的调用也需同步**：已经调用 `link_request_to_change`，无需额外改动。

**向后兼容**：旧数据中 `attach-change: fix-auth` 仍可通过 `find_change_matches` 定位，但不再是标准格式。可在 `list_requests` 展示时做兼容处理。

---

### Phase 6：archive 时更新交叉引用

**目标**：归档操作触发双向引用路径更新。

#### 6a. 归档 Change 时 → 更新关联 Request 的 `attach-change`

在 `change_service.py` 的 `archive_change()` 末尾添加：

```python
def archive_change(sspec_root: Path, change_info: ChangeInfo) -> Path:
    change_path = change_info.path
    name = change_path.name

    # ... 现有归档逻辑 ...
    shutil.move(str(change_path), str(archive_path))

    # 更新关联 request 的 attach-change
    _update_requests_after_change_archive(sspec_root, name, archive_path)

    return archive_path


def _update_requests_after_change_archive(
    sspec_root: Path,
    old_change_name: str,
    new_archive_path: Path,
) -> None:
    """归档 change 后，扫描 requests/ 更新 attach-change 指向。"""
    from sspec.services.request_service import list_requests, parse_request_file

    requests_dir = sspec_root / 'requests'
    if not requests_dir.exists():
        return

    new_spec_relative = (new_archive_path / 'spec.md').relative_to(sspec_root).as_posix()
    # e.g. "changes/archive/25-02-05T14-30_fix-auth/spec.md"

    for md_file in requests_dir.glob('*.md'):
        content = md_file.read_text(encoding='utf-8')
        meta, body = parse_frontmatter(content)
        attach = meta.get('attach-change', '')

        if not attach:
            continue

        # 匹配条件：旧格式（目录名）或新格式（spec.md 路径）
        should_update = (
            attach == old_change_name
            or attach == f'changes/{old_change_name}/spec.md'
            or old_change_name in str(attach)
        )

        if should_update:
            updated = update_frontmatter(content, {'attach-change': new_spec_relative})
            md_file.write_text(updated, encoding='utf-8')
```

#### 6b. 归档 Request 时 → 更新关联 Change 的 `reference`

在 `request_service.py` 的 `archive_request_file()` 末尾添加：

```python
def archive_request_file(
    *,
    sspec_root: Path,       # ← 新增参数
    requests_dir: Path,
    request_info: RequestInfo,  # ← 从 Path 改为 RequestInfo
) -> Path:
    request_file = request_info.path

    # ... 现有归档逻辑（添加 archived 时间戳 + move）...
    shutil.move(str(request_file), str(dest_path))

    # 更新关联 change 的 reference
    _update_changes_after_request_archive(
        sspec_root, request_file, dest_path, request_info.attach_change
    )

    return dest_path


def _update_changes_after_request_archive(
    sspec_root: Path,
    old_request_path: Path,
    new_archive_path: Path,
    attach_change: str | None,
) -> None:
    """归档 request 后，更新关联 change spec.md 中的 reference。"""
    if not attach_change:
        return

    # 解析 attach_change 找到 change 目录
    # 支持新格式 "changes/xxx/spec.md" 和旧格式 "xxx"
    if 'spec.md' in attach_change:
        spec_path = sspec_root / attach_change
    else:
        spec_path = sspec_root / 'changes' / attach_change / 'spec.md'

    # 也检查 archive 目录
    if not spec_path.exists():
        archive_spec = sspec_root / 'changes' / 'archive' / attach_change / 'spec.md'
        if archive_spec.exists():
            spec_path = archive_spec
        else:
            return  # change 不存在，跳过

    content = spec_path.read_text(encoding='utf-8')
    meta, body = parse_frontmatter(content)
    reference = meta.get('reference') or []
    if not isinstance(reference, list):
        return

    old_relative = old_request_path.relative_to(sspec_root).as_posix()
    new_relative = new_archive_path.relative_to(sspec_root).as_posix()

    updated('source') == old_relative:
            ref['source'] = new_relative
            ref['note'] = 'Archived request'
            updated = True

    if updated:
        content = update_frontmatter(content, {'reference': reference})
        spec_path.write_text(content, encoding='utf-8')
```

---

### Phase 7：清理与收尾

**7a. `core.py` 清理**

- 移除已迁移到 `change_service.py` 的函数体
- 保留兼容导入（带 deprecation 注释），或直接移除并更新所有 caller
- 最终 `core.py` 职责：类型定义、常量、共享工具

**7b. `request_service.py` 签名对齐**

| 函数 | 当前签名 | 目标签名 |
|------|---------|---------|
| `list_requests` | `(requests_dir: Path)` | `(sspec_root: Path, include_archived?)` |
| `archive_request_file` | `(requests_dir, request_file)` | `(sspec_root, request_info)` |
| `find_request_matches` | `(requests_dir, name)` | 不变（但 change 侧新增对应函数） |

**7c. 导入路径统一**

确保 `commands/change.py` 和 `commands/request.py` 的导入模式一致：

```python
# 统一模式
from sspec.core import <类型、常量、异常>
from sspec.services.change_service import <业务函数>
from sspec.services.request_service import <业务函数>
```

---

## 四、执行顺序与风险评估

| Phase | 内容 | 风险 | 预计工作量 |
|-------|------|------|-----------|
| 1 | ChangeInfo → dataclass | 低（纯类型重构） | 0.5h |
| 2 | 创建 change_service.py | 低（搬运 + 兼容层） | 1h |
| 3 | 统一 find_change_matches | 中（行为变更：支持模糊匹配） | 0.5h |
| 4 | 统一 archive 交互 | 中（两端同时改） | 1h |
| 5 | link 存储 spec.md 路径 | 低（单点改动） | 0.5h |
| 6 | archive 更新交叉引用 | 中（新逻辑，需覆盖测试） | 1.5h |
| 7 | 清理收尾 | 低 | 0.5h |

**建议**：按 Phase 顺序执行，每个 Phase 完成后跑一次全量测试。Phase 1-2 是纯重构，可安全先行。Phase 3-6 涉及行为变更，需配合集成测试。

---

## 五、测试检查清单

每个 Phase 完成后验证：

- [ ] `sspec change new test-change` → 创建成功
- [ ] `sspec change list` → 正常列表
- [ ] `sspec change status test-change` → 模糊匹配成功
- [ ] `sspec change archive` → 多选交互，DONE 预勾选
- [ ] `sspec change archive test-change` → 模糊匹配 + 单项确认
- [ ] `sspec request new test-req` → 创建成功
- [ ] `sspec request list` → 正常列表
- [ ] `sspec request link test-req test-change` → attach-change 存储 spec.md 路径
- [ ] `sspec request archive` → 多选交互，DONE/CLOSED 预勾选
- [ ] 归档 change 后 → 关联 request 的 attach-change 已更新
- [ ] 归档 request 后 → 关联 change 的 reference.source 已更新

