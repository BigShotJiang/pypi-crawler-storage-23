---
created: 2026-02-15 00:49:55
name: replace_ask_260215004951e4dbfa
why: test archive link replacement
---

Ask references:
- .sspec/requests/archive/26-02-15T00-49_replace-link-260215004951-e4dbfa.md
- .sspec/changes/26-02-15T00-49_replace-link-260215004951-e4dbfa/spec.md
- .sspec/changes/26-02-15T00-49_replace-link-260215004951-e4dbfa/handover.md
- .sspec/tmp/link-check.md
