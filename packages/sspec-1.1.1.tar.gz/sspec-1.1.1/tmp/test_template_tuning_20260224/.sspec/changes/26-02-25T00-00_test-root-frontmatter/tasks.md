---
change: "test-root-frontmatter"
change-type: root
updated: ""
---

# Milestones

## Legend
`[ ]` Todo | `[x]` Done (sub-change completed + verified)

## Milestones
<!-- @REPLACE -->

<!-- @RULE: Each milestone maps to a sub-change. Track at phase level, not file level.
Phase emoji: ⏳ pending | 🚧 in progress | ✅ done

### Phase 1: <name> ⏳
- [ ] Sub-change created and linked
- [ ] Sub-change completed and archived
**Deliverable**: <what Phase 1 delivers>
**Sub-change**: <link when created>
-->

---

## Progress

**Overall**: 0%

| Phase | Sub-Change | Status | Deliverable |
|-------|------------|--------|-------------|
| Phase 1 | (pending) | ⏳ | |

**Recent**:
- (none yet)
