---
name: test-root-frontmatter
status: PLANNING
type: ""
change-type: root
created: 2026-02-25T00:00:51
reference: null
---

<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: root (coordinator for sub-changes)
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'doc', note?}>

Root reference SHOULD include request + sub-changes:
reference:
  - source: "requests/<request-file>.md"
    type: "request"
  - source: "changes/<sub-change-dir>"
    type: "sub-change"
    note: "Phase <n>: <phase-name>"
-->

# test-root-frontmatter

## A. Problem Statement
<!-- @REPLACE -->

<!-- @RULE: Overall impact. This is the root coordinator — describe the FULL scope. -->

## B. Proposed Solution
<!-- @REPLACE -->

### Overall Approach
<!-- High-level strategy. How will this be broken into phases? Delivery order? -->

### Phase Overview
<!-- @RULE: List phases with goals. Each phase becomes a sub-change.

Format:
- **Phase 1: <name>** — goal, measurable deliverable, scope (subsystems/modules)
- **Phase 2: <name>** — goal, measurable deliverable, dependencies on Phase 1

Coordination Notes:
- Cross-phase dependencies, shared interfaces, integration points

When a sub-change is created, sync references in BOTH directions:
- Root `spec.md` adds `type: sub-change` entry for the sub-change
- Sub `spec.md` adds `type: root-change` entry back to this root -->
