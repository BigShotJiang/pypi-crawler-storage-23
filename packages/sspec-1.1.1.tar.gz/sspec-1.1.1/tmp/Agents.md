<!-- SSPEC:START -->
# .sspec Agent Protocol

SSPEC_SCHEMA::{{SCHEMA_VERSION}}

## 0. Protocol Overview

SSPEC is a document-driven AI collaboration framework. All planning, tracking, and handover lives in `.sspec/`.

**Goal**: Any Agent resumes work within 30 seconds by reading `.sspec/` files.

**Folder Structure**:
```
.sspec/
├── project.md              # Project overview, tech stack, conventions
├── spec-docs/              # Project-level specifications (persistent)
├── changes/<name>/         # Active change proposals
│   ├── spec.md | tasks.md | handover.md # Core files
│   └── reference/ | scripts/ # Optional
├── requests/               # Lightweight proposals
└── asks/                   # Human-in-the-loop Q&A records
```

---

## 1. Cold Start

When entering project or after context reset, execute in order:

```
1. Read .sspec/project.md
2. Run: sspec change list
3. IF active change exists (status != DONE):
     Read: .sspec/changes/<name>/handover.md
     Then: tasks.md → spec.md
     Output: "Resuming <name>: <status>, <progress>, next: <action>"
4. ELSE:
     Output: "No active changes. What would you like to work on?"
```

---

## 2. SCOPE: Changes

Changes live in `.sspec/changes/<name>/`. Each has three files:

| File | Contains | Update When |
|------|----------|-------------|
| spec.md | Problem (A), Solution (B), Implementation change, pivot, blocker |
| tasks.md | Task list with `[ ]`/`[x]` markers + progress | After EACH task completion |
| handover.md | Session context for next Agent | **EVERY session end** |

### 2.1 Status Transitions

| From | Trigger | To |
|------|---------|-----|
| PLANNING | user approves plan | DOING |
| DOING | all tasks `[x]` | REVIEW |
| DOING | missing info/resource | BLOCKED |
| DOING | scope changed | PLANNING |
| BLOCKED | blocker resolved | DOING |
| REVIEW | user accepts | DONE |
| REVIEW | user requests changes | DOING |

**FORBIDDEN**: PLANNING→DONE, DOING→DONE, BLOCKED→DONE

### 2.2 Directives

#### `@change <name>`

```
IF .sspec/changes/<name>/ exists:
    Read handover.md → tasks.md → spec.md
    Output: status, progress percentage, next 3 actions
ELSE:
    Run: sspec change new <name>
    Fill spec.md:
      - Section A: Ask user for problem statement (quantified)
      - Section B: Propose solution, get user confirmation
      - Section C: Break down to file-level tasks
    Generate tasks.md from Section C
    Output: "Plan ready. Approve to start? (y/n)"
    WAIT for explicit "y" before status → DOING
```

#### `@resume`

Same as `@change <current_active_change>`.

#### `@handover`

Execute at session end. No exceptions.

```
1. Update handover.md with:
   - Background: 1-sentence change description
   - Accomplished: List of completed tasks this session
   - Status: Current status (PLANNING/DOING/BLOCKED/REVIEW)
   - Next: 1-3 specific file-level actions
   - Conventions: Patterns/naming discovered (if any)

2. Update tasks.md:
   - Mark completed tasks [x]
   - Update progress percentage

3. IF status changed: Update spec.md frontmatter
```

**Quality check**: Would a new Agent know exactly what to do in <30 seconds?

#### `@sync`

After autonomous coding without tracking:

```
1. Identify changes: git diff or ask user
2. Update tasks.md:
   - Mark completed [x]
   - Add tasks for undocumented work done
3. Check: All tasks done? → Suggest REVIEW
```

#### `@argue`

User disagrees mid-implementation. STOP immediately.

```
1. STOP current work
2. Clarify what's wrong:
   - Implementation detail → Revise task in tasks.md
   - Design decision → Revise spec.md Section B
   - Requirement itself → Revise spec.md Section A, add PIVOT marker
3. Output revised plan
4. WAIT for explicit confirmation before continuing
```

### 2.3 Edit Rules

Templates use `@AGENT:` markers:

| Marker | Meaning | Action |
|--------|---------|--------|
| `@AGENT: RULE/<topic>` | Constraint for this section | Follow the rule when filling |
| `@AGENT: REPLACE-FOR-EDIT/<section>` | Replace entirely | Do NOT append; replace whole section |

**Task markers**: `[ ]` todo, `[x]` done, `[-]` blocked, `[~]` needs rework

📚 For quality standards and edge cases → Consult `sspec` SKILL

---

## 3. SCOPE: Requests

Lightweight proposals before becoming changes. Location: `.sspec/requests/`

```
Create:  sspec request new <name>
Link:    sspec request link <request> <change>  # When ready to implement
Archive: sspec request archive <name>
```

Request = "I want X" (idea)
Change = "Here's how we do X" (plan + execution)

---

## 4. SCOPE: Spec-Docs

Project-level specifications (architecture, API contracts, standards). Location: `.sspec/spec-docs/`

#### `@doc <name>`

```
IF creating new:
    Run: sspec doc new "<name>" [--dir]
    Consult: write-spec-doc SKILL
    Write specification following SKILL guidelines
ELSE IF updating:
    Read existing spec-doc
    Apply changes per write-spec-doc SKILL
    Update frontmatter `updated` field
```

📚 For writing guidelines → Consult `write-spec-doc` SKILL

---

## 5. SCOPE: sspec ask

Use when needing user input mid-execution. Saves cost (1 turn instead of 2), reduces hallucination/directional errors. and persists Q&A record.

**When to use**:
1. Information missing → Cannot proceed reliably
2. Directional choice → Multiple valid approaches
3. Completion check → Confirm task is done
4. Repeated failures → Need user insight

**Syntax**:
```bash
sspec ask --name "<topic>" --why "<reason>" --question "<question>"
```

📚 For multi-line syntax and examples → Consult `sspec-ask` SKILL

---

## 6. Behavior Summary

```
ON user_message:
    IF contains @directive     → Execute directive
    IF active change is DOING  → Continue tasks, update tasks.md after each
    ELSE                       → Ask what to work on

ON need_user_input:
    USE sspec ask              → Persists record, saves cost

ON session_end:
    MUST @handover             → No exceptions

ON uncertainty:
    Consult SKILL              → sspec, sspec-ask, write-spec-doc
    OR use sspec-ask for guidance
```

<!-- SSPEC:END -->

