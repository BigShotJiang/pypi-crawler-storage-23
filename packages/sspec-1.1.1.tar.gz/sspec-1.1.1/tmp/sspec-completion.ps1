Register-ArgumentCompleter -CommandName 'sspec' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $words = @()
    foreach ($element in $commandAst.CommandElements) {
        $text = $element.Extent.Text
        if ($text.StartsWith("'") -and $text.EndsWith("'")) {
            $text = $text.Substring(1, $text.Length - 2)
        } elseif ($text.StartsWith('"') -and $text.EndsWith('"')) {
            $text = $text.Substring(1, $text.Length - 2)
        }
        $words += $text
    }

    if ([string]::IsNullOrEmpty($wordToComplete)) {
        $words += ''
    }

    $env:COMP_WORDS = [string]::Join(' ', $words)
    $env:COMP_CWORD = [string]($words.Count - 1)
    $env:_SSPEC_COMPLETE = 'bash_complete'

    try {
        $results = & sspec 2>$null
    } finally {
        Remove-Item Env:_SSPEC_COMPLETE -ErrorAction SilentlyContinue
        Remove-Item Env:COMP_WORDS -ErrorAction SilentlyContinue
        Remove-Item Env:COMP_CWORD -ErrorAction SilentlyContinue
    }

    foreach ($line in $results) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        $parts = $line -split ',', 2
        if ($parts.Count -lt 2) {
            continue
        }

        $value = $parts[1]
        if ([string]::IsNullOrWhiteSpace($value)) {
            continue
        }

        [System.Management.Automation.CompletionResult]::new(
            $value,
            $value,
            [System.Management.Automation.CompletionResultType]::ParameterValue,
            $value
        )
    }
}
