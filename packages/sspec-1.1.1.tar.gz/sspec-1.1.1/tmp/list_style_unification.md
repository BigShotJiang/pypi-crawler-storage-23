# sspec List Command Style Unification Proposal

## 1. Goal
Unify the output style of `sspec change list`, `sspec request list`, and `sspec ask list` to a structured, multi-line format that avoids truncation and provides clear metadata labels.

## 2. Proposed Visual Style

### Case A: `sspec change list`
```text
[bold]Active Changes[/bold]

🔄 [bold]command-patch[/bold]
  Path: [dim].sspec/changes/26-02-11_command-patch[/dim]
  Progress: 0/10
  Flags: [yellow]⚡pivot[/yellow]

✅ [bold]tools[/bold]
  Path: [dim].sspec/changes/26-02-12_tools[/dim]
  Progress: 17/17

Active: 2 | Archived: 0 (use --all to show)
```

### Case B: `sspec request list`
```text
[bold]Open Requests[/bold]

• [bold]add-cmd[/bold]
  Created: [dim]2026-02-07[/dim]
  Path: [dim].sspec/requests/26-02-07_add-cmd.md[/dim]
  Summary: add new command skill support

• [bold]spec-to-doc[/bold]
  Created: [dim]2026-01-28[/dim]
  Path: [dim].sspec/requests/26-01-28_spec-to-doc.md[/dim]
  Summary: Rename @spec to @doc

[bold]In Progress[/bold]

• [bold]tools[/bold]
  Created: [dim]2026-02-12[/dim]
  Path: [dim].sspec/requests/26-02-12_tools.md[/dim]
  Linked: [cyan]→ 26-02-12_tools[/cyan]
  Summary: Add builtin commands tools

Done: 2 (use --all to show)
```

### Case C: `sspec ask list` (New)
*Currently it's a simple bullet list. We will wrap it in sections like Pending/Answered.*
```text
[bold]Pending Questions[/bold]

? [bold]api-design[/bold]
  Path: [dim].sspec/asks/api-design.py[/dim]

[bold]Answered[/bold]

✓ [bold]cli-naming[/bold]
  Path: [dim].sspec/asks/cli-naming.md[/dim]
```

## 3. Key Improvements
1.  **Explicit Labels**: Use `Path:`, `Created:`, `Linked:`, `Summary:`, `Progress:` to make data self-describing.
2.  **Unification**:
    - Header logic: Bold section titles.
    - Item logic: Leading icon + Bold Name, then indented metadata.
    - Footer logic: Standardized "use --all to show" hint for all.
3.  **Fixes**:
    - Remove the accidental dump of `status: OPEN | DOING | DONE | CLOSED;` from request summaries (likely a parsing error of template placeholders).
    - Ensure `ask.py` follows the same aesthetic instead of a bare list.

## 4. Implementation Plan
-   **change.py**: Update `_display_change` to include labels and footer hint.
-   **request.py**: Update `_display_request` to include labels, fix summary parsing, and update footer hint.
-   **ask.py**: Refactor `list` command to use hierarchical blocks and `_display_ask` helper.

---
*Please approve this plan before I proceed with code edits.*
