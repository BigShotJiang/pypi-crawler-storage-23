<!-- SSPEC:START -->
# Simple-Spec Instructions

These instructions are for AI assistants working in this project.

## When to Read `.sspec/AGENTS.md`

Open `.sspec/AGENTS.md` when the request:
- Involves planning, proposals, or multi-step changes
- Introduces new features, architecture changes, or breaking changes
- Seems ambiguous and you need authoritative context before coding
- Mentions "change", "proposal", "spec", "plan", or "handover"

## Quick Commands

| Command | Purpose |
|---------|---------|
| `/propose <n>` | Create new change proposal |
| `/status` | Report current state |
| `/pivot` | Record direction change |
| `/handover` | Generate session handover |
| `/context` | Reload project context |
| `/archive` | Archive completed change |

## First Session?

1. Read `.sspec/knowledge/index.md` for project context
2. Check `.sspec/changes/` for active work
3. Read relevant `handover.md` for previous state

Keep this block so `sspec update` can refresh instructions.
<!-- SSPEC:END -->