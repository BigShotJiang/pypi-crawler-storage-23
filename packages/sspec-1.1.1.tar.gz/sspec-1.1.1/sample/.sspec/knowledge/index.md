# Knowledge Index

Project knowledge base. AI assistants should read this before starting any work.

---

## Project Overview

<!-- 
Concise description of the project's purpose and goals.
Example: "sspec is a lightweight AI collaboration spec for solo/small projects."
-->

## Core Values

<!-- 
What defines this project's character?
Examples:
- "Simplicity over features"
- "Type safety is non-negotiable"
- "Heavy AI collaboration expected"
-->

## Tech Stack

- **Language**: 
- **Framework**: 
- **Key Dependencies**: 
- **Build Tool**: 
- **Test Framework**: 

## Conventions

<!-- 
Critical for AI consistency. Be explicit.

Naming:
- Variables: camelCase / snake_case
- Files: kebab-case / PascalCase
- Constants: UPPER_SNAKE_CASE

Style:
- Functional / OOP / Mixed
- Error handling pattern
- Logging approach

Structure:
- Directory organization patterns
- Module boundaries
-->

## Quick Context

<!-- 3-5 most critical points an agent must know to avoid breaking things -->

1. 
2. 
3. 

## Constraints

<!-- Technical, business, or regulatory limits -->

<!-- Examples:
- Must run on Python 3.9+
- No external network calls in core module
- All user data encrypted at rest
- Response time < 200ms p95
-->

## Knowledge Files

<!-- Map of specialized knowledge documents -->

| File | Content |
|------|---------|
| `index.md` | This file - project overview |
<!-- 
| `architecture.md` | System design, module structure |
| `conventions.md` | Detailed coding standards |
| `decisions.md` | Historical decisions (ADRs) |
| `domain.md` | Business domain, terminology |
-->

## External References

<!-- Links to docs, APIs, design specs, related repos -->

