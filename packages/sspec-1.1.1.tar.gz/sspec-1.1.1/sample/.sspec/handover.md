# Global Handover

Cross-change state and context. Use when switching between changes or for overall project state.

**Updated**: —

---

## Active Changes

| Change | Status | Progress | Summary |
|--------|--------|----------|---------|
| — | — | — | — |

## Recently Completed

<!-- Last few archived changes with dates and outcomes -->

| Change | Archived | Outcome |
|--------|----------|---------|
| — | — | — |

## Pending Work

<!-- Work identified but not yet started as a change -->

- 

## Cross-Cutting Concerns

<!-- Issues or decisions that affect multiple changes or the project as a whole -->

- 

## Session Notes

<!-- Observations, patterns noticed, context that doesn't fit elsewhere -->

- 

---

<!--
UPDATE TRIGGERS:
- When starting/completing a change
- When discovering cross-cutting issues
- At end of significant work sessions
- When handing off to another person/session
-->
