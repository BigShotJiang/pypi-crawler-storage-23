# i18n Glossary

术语翻译对照表，确保文档翻译一致性。

## Core Concepts

| English | 中文 | Notes |
|---------|------|-------|
| Change | 变更 | 不用"更改" |
| Spec / Specification | 规格/规范 | spec.md 用"规格"，spec-docs 用"规范文档" |
| Handover | 交接 | 不用"移交"、"切换" |
| Request | 请求 | 指 .sspec/requests/ 中的提案 |
| Directive | 指令 | @change, @resume 等 |
| Session | 会话 | 不用"对话" |
| Status | 状态 | |
| Task | 任务 | |
| Blocker | 阻塞项 | 不用"障碍" |
| Workflow | 工作流 | |

## Status Values

<!-- Note: 专业 State Value 不翻译 -->

| English | 中文 |
|---------|------|
| PLANNING | 规划中 |
| DOING | 进行中 |
| BLOCKED | 已核 |
| DONE | 已完成 |

## File/Directory Names

<!-- Note: 文件名不翻译 -->

| English | 中文 | Notes |
|---------|------|-------|
| spec.md | 规格文件 | 不翻译文件名本身，其他同 |
| tasks.md | 任务文件 | |
| handover.md | 交接文件 | |
| spec-docs/ | 规范文档目录 | |
| reference/ | 参考目录 | 用于设计草稿 |
| script/ | 脚本目录 | |
| asks/ | 问答记录目录 | |
| requests/ | 请求目录 | |
| changes/ | 变更目录 | |
| skills/ | 技能目录 | |

## Actions

| English | 中文 |
|---------|------|
| Create | 创建 |
| Archive | 归档 |
| Resume | 恢复 |
| Sync | 同步 |
| Update | 更新 |
| Initialize | 初始化 |

## Workflow Terms

| English | 中文 | Notes |
|---------|------|-------|
| Cold Start | 冷启动 | Agent 首次进入项目 |
| Request Processing | 需求处理 | 从模糊需求到变更的流程 |
| Human-in-the-loop | 人机协作 | sspec ask 的核心理念 |
| First-principles thinking | 第一性原理思考 | |
| Design exploration | 设计探索 | reference/ 中的活动 |

## Technical Terms

| English | 中文 |
|---------|------|
| Context window | 上下文窗口 |
| Token | Token（不翻译） |
| Markdown | Markdown（不翻译） |
| CLI | 命令行 |
| Template | 模板 |

## Phrases

| English | 中文 |
|---------|------|
| document-driven | 文档驱动 |
| cross-session persistence | 跨会话持久化 |
| file-level breakdown | 文件级拆分 |
| quality bar | 质量标准 |
| quantified problem | 量化问题 |
