---
name: {{NAME}}
created: {{TIME}}
status: OPEN
attach-change: null
tldr: ""
---

<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: {{NAME}}

## Background
<!-- Current situation, background information -->

## Problem
<!-- What is not working or missing -->

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->

## Relational Context
<!-- Constraints, preferences, related filelinks -->


---

## @AGENT
<!-- What should Agent do to implement this request -->
Adhere to the SSPEC protocol specifications and commence development from the current Request file, following the SSPEC/Development Lifecycle.
Next step: Read `sspec-research` SKILL + `sspec-design` SKILLs + `sspec change new --from <this>`.

---

<!-- ============================================================
     MICRO-CHANGE ZONE (optional)
     For tiny changes (≤3 files, ≤30min) that don't need a full change.
     Remove these sections if a change is created instead.
     ============================================================ -->

<!--
## Plan
Quick implementation plan (what files to touch, what to do)

## Done
What was actually done + any notes for future reference
-->
