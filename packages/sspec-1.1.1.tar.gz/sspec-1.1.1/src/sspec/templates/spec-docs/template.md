---
name: {{SPEC_NAME}}
description: ""
updated: {{DATE}}
---

# {{SPEC_NAME}}

<!-- @RULE: Specification Document Template

Suggested Structure:
1. Overview - Purpose and scope of this specification
2. Definitions - Key terms and concepts
3. Specification - Specific rules and standards
4. Examples - Correct/incorrect examples
5. References - Related documentation links

IMPORTANT: Update the 'updated' field in frontmatter when modifying.
-->

## Overview

## Specification

## Examples

## References
