---
name: {{SPEC_NAME}}
description: ""
updated: {{DATE}}
files: []
scope: []
---

# {{SPEC_NAME}}

## Overview

## Table of Contents
<!-- Add links to sub-files here -->
