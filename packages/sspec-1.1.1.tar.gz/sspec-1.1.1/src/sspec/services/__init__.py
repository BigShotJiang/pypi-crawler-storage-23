"""Domain services used by CLI commands.

Keep these free of click/rich/questionary when practical.
"""
