# TickFlow Python SDK

高性能行情数据 Python 客户端，支持 A股、美股、港股。

## 安装

```bash
pip install tickflow[all] --upgrade
```

## 快速开始

```python
from tickflow import TickFlow

# 初始化客户端
tf = TickFlow(api_key="your-api-key")

# 获取 K 线数据
df = tf.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
print(df.tail())

# 获取实时行情
quotes = tf.quotes.get(symbols=["600000.SH", "AAPL.US"])
for q in quotes:
    print(f"{q['symbol']}: {q['last_price']}")
```

## 异步使用

```python
import asyncio
from tickflow import AsyncTickFlow

async def main():
    async with AsyncTickFlow(api_key="your-api-key") as tf:
        df = await tf.klines.get("600000.SH", as_dataframe=True)
        print(df.tail())

asyncio.run(main())
```

## 批量获取

```python
# 批量获取大量股票数据，自动分批并发请求
symbols = tf.exchanges.get_symbols("SH")[:500]
df = tf.klines.batch(
    symbols,
    period="1d",
    as_dataframe=True,
    show_progress=True  # 显示进度条
)
```

## 特性

- ✅ 同步/异步双接口
- ✅ DataFrame 原生支持
- ✅ 自动重试（网络错误、服务器错误）
- ✅ 批量请求自动分片
- ✅ 进度条支持
- ✅ 完整类型注解

## 文档

完整文档请访问：https://docs.tickflow.org

## License

MIT
