"""Main client classes for TickFlow API.

This module provides the primary interfaces for interacting with the TickFlow API:
- `TickFlow`: Synchronous client
- `AsyncTickFlow`: Asynchronous client

Both clients provide access to the same resources with consistent method signatures.
"""

from __future__ import annotations

from typing import Any, Optional

from ._base_client import DEFAULT_MAX_RETRIES, AsyncAPIClient, SyncAPIClient
from ._cache import InstrumentNameCache
from ._types import Headers, Timeout
from .resources import (
    AsyncExchanges,
    AsyncInstruments,
    AsyncKlines,
    AsyncQuotes,
    AsyncUniverses,
    Exchanges,
    Instruments,
    Klines,
    Quotes,
    Universes,
)

__all__ = ["TickFlow", "AsyncTickFlow"]


class TickFlow:
    """Synchronous client for TickFlow market data API.

    Provides access to market data including K-lines, quotes, instruments,
    exchanges, and universes.

    Parameters
    ----------
    api_key : str, optional
        API key for authentication. If not provided, reads from TICKFLOW_API_KEY
        environment variable.
    base_url : str, optional
        Base URL for the API. Defaults to https://api.tickflow.org.
        Can also be set via TICKFLOW_BASE_URL environment variable.
    timeout : float, optional
        Request timeout in seconds. Defaults to 30.0.
    default_headers : dict, optional
        Default headers to include in all requests.

    Attributes
    ----------
    klines : Klines
        K-line (OHLCV) data endpoints. Supports DataFrame conversion.
    quotes : Quotes
        Real-time quote endpoints.
    instruments : Instruments
        Instrument metadata endpoints.
    exchanges : Exchanges
        Exchange list endpoints.
    universes : Universes
        Universe (symbol pool) endpoints.

    Examples
    --------
    Basic usage:

    >>> from tickflow import TickFlow
    >>>
    >>> # Initialize client
    >>> client = TickFlow(api_key="your-api-key")
    >>>
    >>> # Get K-line data as DataFrame
    >>> df = client.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
    >>> print(df.tail())
    >>>
    >>> # Get real-time quotes
    >>> quotes = client.quotes.get(symbols=["600000.SH", "AAPL.US"])
    >>> for q in quotes:
    ...     print(f"{q['symbol']}: {q['last_price']}")

    Using context manager:

    >>> with TickFlow(api_key="your-api-key") as client:
    ...     df = client.klines.get("AAPL.US", as_dataframe=True)
    ...     print(df.tail())

    Using environment variable:

    >>> import os
    >>> os.environ["TICKFLOW_API_KEY"] = "your-api-key"
    >>> client = TickFlow()  # Uses TICKFLOW_API_KEY
    """

    klines: Klines
    quotes: Quotes
    instruments: Instruments
    exchanges: Exchanges
    universes: Universes

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: Timeout = 30.0,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
        cache_dir: Optional[str] = None,
    ) -> None:
        self._client = SyncAPIClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )
        self._instrument_cache = InstrumentNameCache(cache_dir=cache_dir)

        # Initialize resources
        self.klines = Klines(self._client, instrument_cache=self._instrument_cache)
        self.quotes = Quotes(self._client)
        self.instruments = Instruments(self._client)
        self.exchanges = Exchanges(self._client)
        self.universes = Universes(self._client)

    def __enter__(self) -> "TickFlow":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client.

        This releases any network resources held by the client.
        Called automatically when using the client as a context manager.
        """
        self._client.close()

    @property
    def instrument_cache(self) -> InstrumentNameCache:
        """The shared instrument name cache."""
        return self._instrument_cache

    @property
    def api_key(self) -> str:
        """The API key used for authentication."""
        return self._client.api_key

    @property
    def base_url(self) -> str:
        """The base URL for API requests."""
        return self._client.base_url


class AsyncTickFlow:
    """Asynchronous client for TickFlow market data API.

    Provides access to market data including K-lines, quotes, instruments,
    exchanges, and universes. All methods are async and must be awaited.

    Parameters
    ----------
    api_key : str, optional
        API key for authentication. If not provided, reads from TICKFLOW_API_KEY
        environment variable.
    base_url : str, optional
        Base URL for the API. Defaults to https://api.tickflow.org.
        Can also be set via TICKFLOW_BASE_URL environment variable.
    timeout : float, optional
        Request timeout in seconds. Defaults to 30.0.
    max_retries : int, optional
        Maximum number of retry attempts for failed requests. Defaults to 3.
        Retries occur on connection errors, timeouts, and server errors (5xx).
    default_headers : dict, optional
        Default headers to include in all requests.

    Attributes
    ----------
    klines : AsyncKlines
        K-line (OHLCV) data endpoints. Supports DataFrame conversion.
    quotes : AsyncQuotes
        Real-time quote endpoints.
    instruments : AsyncInstruments
        Instrument metadata endpoints.
    exchanges : AsyncExchanges
        Exchange list endpoints.
    universes : AsyncUniverses
        Universe (symbol pool) endpoints.

    Examples
    --------
    Basic usage:

    >>> import asyncio
    >>> from tickflow import AsyncTickFlow
    >>>
    >>> async def main():
    ...     async with AsyncTickFlow(api_key="your-api-key") as client:
    ...         # Get K-line data as DataFrame
    ...         df = await client.klines.get("600000.SH", as_dataframe=True)
    ...         print(df.tail())
    ...
    ...         # Get multiple symbols in parallel
    ...         import asyncio
    ...         tasks = [
    ...             client.klines.get(s, as_dataframe=True)
    ...             for s in ["600000.SH", "000001.SZ", "AAPL.US"]
    ...         ]
    ...         results = await asyncio.gather(*tasks)
    >>>
    >>> asyncio.run(main())

    Manual resource management:

    >>> async def main():
    ...     client = AsyncTickFlow(api_key="your-api-key")
    ...     try:
    ...         quotes = await client.quotes.get(symbols=["AAPL.US"])
    ...         print(quotes)
    ...     finally:
    ...         await client.close()
    """

    klines: AsyncKlines
    quotes: AsyncQuotes
    instruments: AsyncInstruments
    exchanges: AsyncExchanges
    universes: AsyncUniverses

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: Timeout = 30.0,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Headers] = None,
        cache_dir: Optional[str] = None,
    ) -> None:
        self._client = AsyncAPIClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )
        self._instrument_cache = InstrumentNameCache(cache_dir=cache_dir)

        # Initialize resources
        self.klines = AsyncKlines(self._client, instrument_cache=self._instrument_cache)
        self.quotes = AsyncQuotes(self._client)
        self.instruments = AsyncInstruments(self._client)
        self.exchanges = AsyncExchanges(self._client)
        self.universes = AsyncUniverses(self._client)

    async def __aenter__(self) -> "AsyncTickFlow":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client.

        This releases any network resources held by the client.
        Called automatically when using the client as an async context manager.
        """
        await self._client.close()

    @property
    def instrument_cache(self) -> InstrumentNameCache:
        """The shared instrument name cache."""
        return self._instrument_cache

    @property
    def api_key(self) -> str:
        """The API key used for authentication."""
        return self._client.api_key

    @property
    def base_url(self) -> str:
        """The base URL for API requests."""
        return self._client.base_url
