# Shared utilities for openhands_cli
