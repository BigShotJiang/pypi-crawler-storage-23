"""Tests for OpenHands CLI authentication functionality."""
