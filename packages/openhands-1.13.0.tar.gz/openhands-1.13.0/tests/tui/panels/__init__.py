"""Tests for TUI panels."""
