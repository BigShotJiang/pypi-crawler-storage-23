"""Tests for the refactored textual UI components."""
