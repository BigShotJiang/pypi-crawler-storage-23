"""Tests for modal components in the refactor UI."""
