"""Tests for MCP functionality."""
