"""E2E snapshot tests for OpenHands CLI."""
