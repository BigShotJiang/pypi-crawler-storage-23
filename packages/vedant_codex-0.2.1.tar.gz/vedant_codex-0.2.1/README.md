# Vedant Codex

A lightweight **AI-powered coding assistant CLI** inspired by tools like Codex and Cursor.

Vedant Codex allows developers to interact with an AI agent directly from the terminal to analyze projects, edit files safely, search codebases, and automate development tasks.

It integrates with **Ollama** and tool-enabled models to provide a local or hybrid AI coding workflow.

---

## Features

- AI coding assistant inside your terminal
- Safe file editing using **unified diff patches**
- File system access restricted to **allowlisted directories**
- Built-in tools:
  - create files
  - read files
  - search files
  - list project structure
  - apply patches
  - run commands
  - open files in browser
  - start development servers
  - web search
- Supports **tool-calling capable models**
- Session logging
- Daily usage quotas
- Cross-platform support

---

## Installation
### Recommended (pipx)

Install using `pipx` for isolated CLI environments.
1. pip install pipx
2. pipx ensurepath
3. pipx install vedant-codex

### Alternative (pip)
1. pip install vedant-codex

## Run 
1. vedant

## Prerequisites
-Python (Python 3.10 or newer is recommended.)

-Ollama (Vedant Codex requires Ollama to run AI models.)

Install Ollama:

https://ollama.com/download

Initialize and download ollama.exe. 

## Usage

## Start the assistant: vedant
## Example prompts: 

Create a login.html page with modern glassmorphism UI
Search for TODO comments in this repository
Start a Python development server
List files in this project

## Configuration

Environment variables can customize behavior.

Example .env (default):
MODEL=qwen3-coder:480b-cloud
OLLAMA_HOST=http://127.0.0.1:11434
ALLOWLIST_ROOTS={{add C:/Users/path/to/workingspace or implicitly give permission to model to use any path you want.}}

## Security

Vedant Codex is designed with safety in mind.

File system access is restricted to allowlisted directories

File edits must use reviewable diff patches

Command execution can be restricted with allowlists

Usage quotas prevent runaway automation

## Development

Clone the repository: git clone https://github.com/Probro-2009/local-codex
Then: cd local-codex
Then: pip install -e .
Then: vedant

## Roadmap

Planned improvements:

persistent memory

improved tool orchestration

better project indexing

model auto-detection

improved Windows / Termux compatibility

plugin system

## Contributing

Pull requests are welcome.

If you find a bug or want a new feature, email at arunakchitre@gmail.com.
