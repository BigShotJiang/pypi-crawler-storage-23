# app/main.py
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn

from app.agent.prompts import SYSTEM_PROMPT
from app.ui import LiveStatus, console

from app.config import AppConfig
from app.ollama_client import OllamaClient
from app.quota import QuotaManager, QuotaExceeded
from app.agent.planner import AgentPlanner
from app.tools import get_tool_registry
from app.tools.quota_hooks import set_patch_quota_callback
from app.tools.fs_guard import FSGuard, set_guard


def _utc_ts() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def _show_quota_hud(qm: QuotaManager) -> None:
    st = qm.status()
    # transient=True makes it disappear before input (Codex-like "HUD flash").
    with Progress(
        TextColumn("[bold]Quota[/bold]"),
        TextColumn(" req "),
        BarColumn(),
        TextColumn(f"{st['requests_used']}/{st['requests_max']}"),
        TextColumn("   patches "),
        BarColumn(),
        TextColumn(f"{st['patches_used']}/{st['patches_max']}"),
        transient=True,
        console=console,
    ) as prog:
        prog.add_task("req", total=st["requests_max"], completed=st["requests_used"])
        prog.add_task("patch", total=st["patches_max"], completed=st["patches_used"])
        # show briefly then exit context


def _session_path_from_cfg(cfg: AppConfig, session_id: str) -> Path:
    # cfg.sessions_path is a file path; reuse its parent folder and store each session as <id>.jsonl
    return cfg.sessions_path.parent / f"{session_id}.jsonl"


def _load_session_messages(session_path: Path) -> List[Dict[str, Any]]:
    """
    Reconstruct model messages from session jsonl:
      - Always start with SYSTEM_PROMPT
      - Replay user + assistant messages
    """
    msgs: List[Dict[str, Any]] = [{"role": "system", "content": SYSTEM_PROMPT}]

    if not session_path.exists():
        return msgs

    try:
        for line in session_path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            role = obj.get("role")
            if role in ("user", "assistant"):
                msgs.append({"role": role, "content": obj.get("content", "") or ""})
    except Exception:
        # If session file is corrupted, just start fresh (but keep system prompt)
        return [{"role": "system", "content": SYSTEM_PROMPT}]

    return msgs


def main(session_id: Optional[str] = None) -> None:
    cfg = AppConfig.load()

    # --- v0.2.0 session memory ---
    if not session_id:
        session_id = uuid.uuid4().hex[:8]

    session_path = _session_path_from_cfg(cfg, session_id)
    session_messages: List[Dict[str, Any]] = _load_session_messages(session_path)

    total_in_tokens = 0
    total_out_tokens = 0

    # Configure FS guard singleton used by tools
    guard = FSGuard(allowlist_roots=cfg.allowlist_roots, max_file_bytes=cfg.max_file_bytes)
    set_guard(guard)

    # Quota manager
    qm = QuotaManager(
        usage_file=cfg.quotas_path,
        daily_max_requests=cfg.daily_max_requests,
        daily_max_patches=cfg.daily_max_patches,
    )
    qm.ensure_storage()

    # Patch quota enforcement: apply_patch will call this callback when it actually writes
    def _consume_one_patch() -> None:
        qm.increment_patches(1)

    set_patch_quota_callback(_consume_one_patch)

    # Ollama client + tools
    client = OllamaClient(host=cfg.ollama_host)
    tools = get_tool_registry()

    # Live status/spinner object (Codex-like)
    live = LiveStatus()

    def on_event(name: str, payload: Dict[str, Any]) -> None:
        nonlocal total_in_tokens, total_out_tokens

        if name == "thinking":
            live.set("Thinking…")

        elif name == "model_request":
            # Count quota per model call
            qm.increment_requests(1)
            live.set("Thinking…")

        elif name == "tool_start":
            tname = payload.get("name", "unknown")
            live.set(f"Running {tname}…")
            console.print(f"[dim]• Running[/dim] [bold]{tname}[/bold]")

        elif name == "tool_end":
            tname = payload.get("name", "unknown")
            ok = payload.get("ok", False)
            if ok:
                console.print(f"[dim]• Done[/dim] [bold]{tname}[/bold]")
            else:
                console.print(f"[dim]• Error[/dim] [bold]{tname}[/bold]")

        elif name == "done":
            live.set("Done")

        elif name == "max_rounds":
            live.set("Max tool rounds reached")

        elif name == "usage":
            # Emitted by AgentPlanner._chat() when Ollama returns token counts
            in_tok = int(payload.get("input_tokens") or 0)
            out_tok = int(payload.get("output_tokens") or 0)
            total_in_tokens += in_tok
            total_out_tokens += out_tok
            _append_jsonl(
                session_path,
                {
                    "ts": _utc_ts(),
                    "role": "usage",
                    "input_tokens": in_tok,
                    "output_tokens": out_tok,
                },
            )

    planner = AgentPlanner(
        ollama_client=client,
        model=cfg.model,
        tool_registry=tools,
        max_tool_rounds=10,
        on_event=on_event,
        # Autopilot defaults (you can tune these later)
        autopilot=True,
        verify_commands=["python -m compileall ."],
    )

    console.print(
        Panel.fit(
            f"[bold]Local Codex[/bold]\n"
            f"Session: [cyan]{session_id}[/cyan]\n"
            f"Model: {cfg.model}\n"
            f"Ollama: {cfg.ollama_host}\n"
            f"Allowlist: {', '.join(str(p) for p in cfg.allowlist_roots)}\n"
            f"Quota: {cfg.daily_max_requests} req/day, {cfg.daily_max_patches} patches/day\n"
            f"Commands: /quota  /config  /exit",
            title="Ready",
        )
    )

    while True:
        # Codex-like HUD before each prompt
        _show_quota_hud(qm)

        try:
            user_text = console.input("\n[bold cyan]>[/bold cyan] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print(
                Panel.fit(
                    f"[bold]Session ended[/bold]\n"
                    f"Session ID: [cyan]{session_id}[/cyan]\n"
                    f"Input tokens: [green]{total_in_tokens}[/green]\n"
                    f"Output tokens: [green]{total_out_tokens}[/green]\n\n"
                    f"To continue this session later:\n"
                    f"[bold cyan]vedant {session_id}[/bold cyan]",
                    title="v0.2.0",
                )
            )
            return

        if not user_text:
            continue

        cmd = user_text.lower().strip()

        if cmd in ("/exit", "exit", "quit", "/quit", "/bye", "bye"):
            console.print(
                Panel.fit(
                    f"[bold]Session ended[/bold]\n"
                    f"Session ID: [cyan]{session_id}[/cyan]\n"
                    f"Input tokens: [green]{total_in_tokens}[/green]\n"
                    f"Output tokens: [green]{total_out_tokens}[/green]\n\n"
                    f"To continue this session later:\n"
                    f"[bold cyan]vedant {session_id}[/bold cyan]",
                    title="v0.2.0",
                )
            )
            return

        if cmd in ("/quota", "quota"):
            console.print(qm.status())
            continue

        if cmd in ("/config", "config"):
            console.print(
                {
                    "cwd": os.getcwd(),
                    "session_id": session_id,
                    "session_path": str(session_path),
                    "model": cfg.model,
                    "ollama_host": cfg.ollama_host,
                    "allowlist_roots": [str(p) for p in cfg.allowlist_roots],
                    "storage_dir": str(cfg.sessions_path.parent.parent),
                }
            )
            continue

        # Log user message (for per-session memory)
        _append_jsonl(session_path, {"ts": _utc_ts(), "role": "user", "content": user_text})

        # If already out of quota, stop early (planner will also increment per model_request)
        try:
            qm.check_request_allowed()
        except QuotaExceeded as e:
            console.print(f"[red]{e}[/red]")
            continue

        # Run agent with live spinner
        try:
            live.set("Thinking…")
            live.start()
            session_messages = planner.run_once(user_text, session_messages=session_messages)
        except QuotaExceeded as e:
            console.print(f"[red]{e}[/red]")
            continue
        finally:
            live.stop()

        # Print the latest assistant content (last non-empty assistant message)
        last_text = ""
        for m in reversed(session_messages):
            if m.get("role") == "assistant" and (m.get("content") or "").strip():
                last_text = (m.get("content") or "").strip()
                break

        if last_text:
            console.print(last_text)
            _append_jsonl(session_path, {"ts": _utc_ts(), "role": "assistant", "content": last_text})