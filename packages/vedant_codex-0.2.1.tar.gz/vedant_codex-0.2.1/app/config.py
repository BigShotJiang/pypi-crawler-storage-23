# app/config.py
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List

from dotenv import load_dotenv


def _split_semicolon_paths(value: str) -> List[str]:
    parts = [p.strip().strip('"') for p in (value or "").split(";")]
    return [p for p in parts if p]


@dataclass(frozen=True)
class AppConfig:
    ollama_host: str
    model: str

    allowlist_roots: List[Path]
    max_file_bytes: int

    daily_max_requests: int
    daily_max_patches: int

    sessions_path: Path
    quotas_path: Path

    cmd_allowlist: List[str]

    @staticmethod
    def load() -> "AppConfig":
        # Load .env if present (safe if missing)
        load_dotenv(override=False)

        ollama_host = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434").strip()
        model = os.getenv("MODEL", "qwen3-coder:480b-cloud").strip()

        roots_raw = os.getenv("ALLOWLIST_ROOTS", "").strip()
        roots = [Path(p) for p in _split_semicolon_paths(roots_raw)]
        if not roots:
            # Default to current working directory (safer than allowing everything)
            roots = [Path.cwd()]

        # Normalize roots to absolute resolved paths
        allowlist_roots = [r.expanduser().resolve(strict=False) for r in roots]

        max_file_bytes = int(os.getenv("MAX_FILE_BYTES", "200000"))

        daily_max_requests = int(os.getenv("DAILY_MAX_REQUESTS", "80"))
        daily_max_patches = int(os.getenv("DAILY_MAX_PATCHES", "20"))

        storage_dir = Path(os.getenv("STORAGE_DIR", str(Path("app") / "storage"))).resolve(strict=False)
        sessions_path = storage_dir / "sessions" / "history.jsonl"
        quotas_path = storage_dir / "quotas" / "usage.json"

        cmd_allowlist = _split_semicolon_paths(os.getenv("CMD_ALLOWLIST", "pytest;python -m pytest;npm test"))

        return AppConfig(
            ollama_host=ollama_host,
            model=model,
            allowlist_roots=allowlist_roots,
            max_file_bytes=max_file_bytes,
            daily_max_requests=daily_max_requests,
            daily_max_patches=daily_max_patches,
            sessions_path=sessions_path,
            quotas_path=quotas_path,
            cmd_allowlist=cmd_allowlist,
        )