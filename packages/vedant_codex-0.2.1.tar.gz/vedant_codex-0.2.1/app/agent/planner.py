# app/agent/planner.py
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .prompts import SYSTEM_PROMPT
from .tool_schema import build_tool_schemas

ToolFn = Callable[..., Any]
EventFn = Callable[[str, Dict[str, Any]], None]


def _extract_assistant_message(resp: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ollama typically returns:
      { "message": {"role":"assistant","content":"...", "tool_calls":[...]} , ... }

    Some wrappers may return tool_calls at top-level.
    Normalize to:
      { role, content, tool_calls? }
    """
    if isinstance(resp, dict) and "message" in resp and isinstance(resp["message"], dict):
        msg = resp["message"]
        out = {
            "role": msg.get("role", "assistant"),
            "content": msg.get("content", "") or "",
        }
        if "tool_calls" in msg and msg["tool_calls"]:
            out["tool_calls"] = msg["tool_calls"]
        elif "tool_calls" in resp and resp["tool_calls"]:
            out["tool_calls"] = resp["tool_calls"]
        return out

    # fallback
    out = {"role": "assistant", "content": resp.get("content", "") or ""} if isinstance(resp, dict) else {
        "role": "assistant",
        "content": "",
    }
    if isinstance(resp, dict) and "tool_calls" in resp:
        out["tool_calls"] = resp["tool_calls"]
    return out


def _normalize_tool_call(tc: Any) -> Tuple[str, Dict[str, Any], str]:
    """
    Normalize a tool call into (name, args_dict, call_id)

    Expected formats:
    - {"id":"...", "type":"function", "function":{"name":"read_file","arguments":"{...}"}}
    - {"id":"...", "function":{"name":"read_file","arguments":{...}}}
    - {"name":"read_file","arguments":{...}}   (no id)
    """
    if not isinstance(tc, dict):
        raise ValueError(f"Tool call is not a dict: {tc!r}")

    call_id = tc.get("id") or tc.get("tool_call_id") or ""

    fn = tc.get("function") or tc.get("tool") or tc
    if not isinstance(fn, dict):
        raise ValueError(f"Tool call function block invalid: {tc!r}")

    name = fn.get("name") or tc.get("name")
    if not name:
        raise ValueError(f"Tool call missing name: {tc!r}")

    args = fn.get("arguments") or tc.get("arguments") or {}
    if isinstance(args, str):
        args = json.loads(args) if args.strip() else {}
    if not isinstance(args, dict):
        raise ValueError(f"Tool call arguments must be object: {tc!r}")

    return name, args, call_id


@dataclass
class AgentPlanner:
    """
    A minimal agent loop:
    - keeps a messages list
    - sends to Ollama with tool schemas
    - executes tool calls using a provided tool registry
    - appends tool results back into messages

    on_event emits Codex-like UI events without exposing chain-of-thought.
    Events:
      - model_request: before each /api/chat call
      - thinking: before each round
      - tool_start / tool_end
      - usage: per model call token usage (if available)
      - done / max_rounds
    """

    ollama_client: Any
    model: str
    tool_registry: Dict[str, ToolFn]
    max_tool_rounds: int = 10
    on_event: Optional[EventFn] = None

    # --- Transactional Autopilot settings ---
    autopilot: bool = False
    verify_commands: Optional[List[str]] = None

    # runtime state
    _last_checkpoint: Optional[Dict[str, Any]] = None

    def _emit(self, name: str, payload: Dict[str, Any]) -> None:
        if not self.on_event:
            return
        try:
            self.on_event(name, payload)
        except Exception:
            # Never let UI callbacks break the agent.
            pass

    def _append_tool_msg(
        self,
        messages: List[Dict[str, Any]],
        name: str,
        payload: Dict[str, Any],
        call_id: str = "",
    ) -> None:
        tool_msg: Dict[str, Any] = {
            "role": "tool",
            "name": name,
            "content": json.dumps(payload, ensure_ascii=False),
        }
        if call_id:
            tool_msg["tool_call_id"] = call_id
        messages.append(tool_msg)

    def _chat(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Calls ollama_client.chat(model=..., messages=..., tools=...)
        """
        tools = build_tool_schemas()
        self._emit("model_request", {"model": self.model})
        resp = self.ollama_client.chat(model=self.model, messages=messages, tools=tools)

        # Ollama often returns:
        # - prompt_eval_count = input tokens
        # - eval_count        = output tokens
        try:
            if isinstance(resp, dict):
                in_tok = resp.get("prompt_eval_count")
                out_tok = resp.get("eval_count")
                if isinstance(in_tok, int) or isinstance(out_tok, int):
                    self._emit(
                        "usage",
                        {
                            "input_tokens": int(in_tok or 0),
                            "output_tokens": int(out_tok or 0),
                        },
                    )
        except Exception:
            pass

        return resp

    def _extract_patch_files(self, args: Dict[str, Any]) -> List[str]:
        """
        Try to extract file paths from apply_patch arguments.
        Supports common shapes:
          - {"patches": [{"file": "...", ...}, ...]}
          - {"edits": [{"file": "...", ...}, ...]}
          - {"file": "...", "patch": "..."}  (single)
        """
        files: List[str] = []

        for key in ("patches", "edits"):
            items = args.get(key)
            if isinstance(items, list):
                for it in items:
                    if isinstance(it, dict) and it.get("file"):
                        files.append(str(it["file"]))

        if not files and isinstance(args.get("file"), str):
            files.append(args["file"])

        # de-dup preserve order
        seen = set()
        out: List[str] = []
        for f in files:
            if f not in seen:
                seen.add(f)
                out.append(f)
        return out

    def run_once(
        self,
        user_text: str,
        session_messages: Optional[List[Dict[str, Any]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Runs one user turn, possibly with multiple tool rounds, and returns updated messages.
        """
        messages = list(session_messages) if session_messages else []
        if not messages:
            messages.append({"role": "system", "content": SYSTEM_PROMPT})

        messages.append({"role": "user", "content": user_text})
        made_mutation = False

        for round_idx in range(self.max_tool_rounds):
            self._emit("thinking", {"round": round_idx + 1})

            resp = self._chat(messages)
            assistant_msg = _extract_assistant_message(resp)

            # Always append assistant message (content may be empty if it only triggers tools)
            msg_to_append: Dict[str, Any] = {
                "role": "assistant",
                "content": assistant_msg.get("content", "") or "",
            }
            if "tool_calls" in assistant_msg:
                msg_to_append["tool_calls"] = assistant_msg["tool_calls"]
            messages.append(msg_to_append)

            tool_calls = assistant_msg.get("tool_calls") or []

            # If the model is done, optionally run autopilot verification
            if not tool_calls:
                if self.autopilot and self.verify_commands and made_mutation:
                    cwd = str(Path.cwd())

                    if "safe_verify" not in self.tool_registry:
                        messages.append(
                            {
                                "role": "assistant",
                                "content": "Autopilot is enabled but safe_verify tool is missing from the registry.",
                            }
                        )
                        self._emit("done", {"rounds": round_idx + 1})
                        return messages

                    try:
                        v = self.tool_registry["safe_verify"](cwd=cwd, commands=self.verify_commands)
                        self._append_tool_msg(messages, "safe_verify", {"ok": True, "result": v})
                    except Exception as e:
                        self._append_tool_msg(
                            messages,
                            "safe_verify",
                            {"ok": False, "error": f"{type(e).__name__}: {e}"},
                        )
                        v = {"ok": False}

                    if not isinstance(v, dict) or not v.get("ok"):
                        # Roll back to last checkpoint if available
                        if self._last_checkpoint:
                            try:
                                manifest = self._last_checkpoint.get("manifest") or {}
                                root = manifest.get("root")
                                checkpoint_id = manifest.get("checkpoint_id")
                                if root and checkpoint_id and "restore_checkpoint" in self.tool_registry:
                                    rb = self.tool_registry["restore_checkpoint"](
                                        root=root, checkpoint_id=checkpoint_id
                                    )
                                    self._append_tool_msg(messages, "restore_checkpoint", {"ok": True, "result": rb})
                            except Exception as e:
                                self._append_tool_msg(
                                    messages,
                                    "restore_checkpoint",
                                    {"ok": False, "error": f"{type(e).__name__}: {e}"},
                                )

                        # Ask the model to fix, then continue the tool rounds
                        messages.append(
                            {
                                "role": "user",
                                "content": "Verification failed. Fix the errors and verify again until it passes.",
                            }
                        )
                        continue

                self._emit("done", {"rounds": round_idx + 1})
                return messages

            # Execute tools in order
            for tc in tool_calls:
                name, args, call_id = _normalize_tool_call(tc)
                self._emit("tool_start", {"name": name, "args": args})

                tool_fn = self.tool_registry.get(name)
                if tool_fn is None:
                    tool_result = {"ok": False, "error": f"Unknown tool: {name}"}
                else:
                    try:
                        # --- Transactional Autopilot: checkpoint before apply_patch ---
                        if self.autopilot and name == "apply_patch" and "checkpoint_files" in self.tool_registry:
                            files = self._extract_patch_files(args)
                            if files:
                                ckpt = self.tool_registry["checkpoint_files"](files=files, label="before apply_patch")
                                if isinstance(ckpt, dict) and ckpt.get("ok") and "manifest" in ckpt:
                                    self._last_checkpoint = ckpt
                                else:
                                    self._last_checkpoint = ckpt if isinstance(ckpt, dict) else None

                        result = tool_fn(**args)

                        # Permission request pattern:
                        # Tool returns {"permission_required": True, "path": "..."} and CLI asks user
                        if isinstance(result, dict) and result.get("permission_required"):
                            path = result.get("path")
                            print(f"\n🔒 Tool requests access to: {path}")
                            ans = input("Allow access? (y/n): ").strip().lower()

                            if ans == "y":
                                # Prefer registry if available
                                if "grant_fs_access" in self.tool_registry:
                                    grant = self.tool_registry["grant_fs_access"](path=path)
                                else:
                                    # fallback import if you didn’t register it
                                    from app.tools.grant_fs_access import grant_fs_access

                                    grant = grant_fs_access(path)
                                tool_result = {"ok": True, "result": grant}
                            else:
                                tool_result = {"ok": False, "error": "User denied directory access"}
                        else:
                            tool_result = {"ok": True, "result": result}

                    except Exception as e:
                        tool_result = {"ok": False, "error": f"{type(e).__name__}: {e}"}

                if tool_result.get("ok") and name in {"apply_patch", "create_file"}:
                    made_mutation = True

                self._emit("tool_end", {"name": name, "ok": bool(tool_result.get("ok"))})

                # Tool message format accepted by Ollama: role=tool with name + content JSON
                self._append_tool_msg(messages, name, tool_result, call_id=call_id)

        # Hit max rounds
        messages.append(
            {
                "role": "assistant",
                "content": "I hit the maximum tool rounds for this request. Try asking in smaller steps.",
            }
        )
        self._emit("max_rounds", {"max_tool_rounds": self.max_tool_rounds})
        return messages
