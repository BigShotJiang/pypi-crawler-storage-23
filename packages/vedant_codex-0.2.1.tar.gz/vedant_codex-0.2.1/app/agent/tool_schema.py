# app/agent/tool_schema.py
from __future__ import annotations

from typing import Any, Dict, List


def build_tool_schemas() -> List[Dict[str, Any]]:
    """
    Returns tool definitions to send to Ollama for tool calling.

    These schemas MUST match the tool functions you implement in app/tools/.
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "list_files",
                "description": "List files and folders under a directory (restricted to allowlisted roots).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "dir_path": {
                            "type": "string",
                            "description": "Directory to list (must be within allowlisted roots).",
                        },
                        "recursive": {
                            "type": "boolean",
                            "description": "If true, list recursively (may be truncated by limits).",
                            "default": False,
                        },
                        "max_entries": {
                            "type": "integer",
                            "description": "Maximum entries to return.",
                            "default": 200,
                        },
                    },
                    "required": ["dir_path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Read a text file safely (size-limited, restricted to allowlisted roots).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to read (must be within allowlisted roots).",
                        },
                        "max_bytes": {
                            "type": "integer",
                            "description": "Maximum bytes to read from the file.",
                            "default": 200000,
                        },
                    },
                    "required": ["file_path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "search_files",
                "description": "Search for a text pattern in files under a directory (restricted).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "root_dir": {
                            "type": "string",
                            "description": "Directory to search under (must be within allowlisted roots).",
                        },
                        "query": {
                            "type": "string",
                            "description": "Text to search for (literal substring match).",
                        },
                        "file_glob": {
                            "type": "string",
                            "description": "Optional glob like '**/*.py' or '*.md'.",
                            "default": "**/*",
                        },
                        "max_matches": {
                            "type": "integer",
                            "description": "Maximum number of matches to return.",
                            "default": 50,
                        },
                    },
                    "required": ["root_dir", "query"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "apply_patch",
                "description": "Apply a unified diff patch to files (the only allowed write operation).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "diff": {
                            "type": "string",
                            "description": "Unified diff. Use --- a/path and +++ b/path headers.",
                        },
                        "dry_run": {
                            "type": "boolean",
                            "description": "If true, validate patch without writing.",
                            "default": False,
                        },
                    },
                    "required": ["diff"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "run_cmd",
                "description": "Run an allowlisted command (optional; typically for tests).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "cmd": {
                            "type": "string",
                            "description": "Command to run (must match allowlist, e.g., 'pytest -q').",
                        },
                        "cwd": {
                            "type": "string",
                            "description": "Working directory (must be within allowlisted roots).",
                        },
                        "timeout_sec": {
                            "type": "integer",
                            "description": "Timeout in seconds.",
                            "default": 60,
                        },
                    },
                    "required": ["cmd", "cwd"],
                },
            },
        },
    ]