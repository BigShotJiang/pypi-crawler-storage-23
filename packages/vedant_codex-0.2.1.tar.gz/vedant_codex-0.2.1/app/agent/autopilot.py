# app/agent/autopilot.py
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

@dataclass
class AutoPilot:
    planner: Any
    verify_commands: List[str]
    max_fix_rounds: int = 5

    def run_task(self, user_text: str, session_messages: Optional[List[Dict[str, Any]]] = None):
        messages = self.planner.run_once(user_text, session_messages=session_messages)

        # Fix loop
        for fix_round in range(self.max_fix_rounds):
            # Ask the agent to verify (via tools)
            verify_prompt = (
                "Now verify the change by running the appropriate verify commands. "
                "If it fails, fix the code and verify again. "
                f"Verify commands: {self.verify_commands}"
            )
            messages = self.planner.run_once(verify_prompt, session_messages=messages)

            # Heuristic: if last assistant message contains “verified” OR no tool calls happened
            # (better: inspect tool outputs for success)
            if self._looks_successful(messages):
                return messages

            # Otherwise continue loop; the verify output will already be in messages

        messages.append({
            "role": "assistant",
            "content": "Autopilot hit the maximum fix rounds. I can continue if you tell me which error to prioritize."
        })
        return messages

    def _looks_successful(self, messages: List[Dict[str, Any]]) -> bool:
        # Minimal heuristic: search recent tool outputs for ok=true and no errors
        recent = messages[-25:]
        tool_msgs = [m for m in recent if m.get("role") == "tool"]
        if not tool_msgs:
            return True
        for tm in tool_msgs[::-1]:
            try:
                payload = json.loads(tm.get("content", "{}"))
            except Exception:
                continue
            if payload.get("ok") is False:
                return False
        return True