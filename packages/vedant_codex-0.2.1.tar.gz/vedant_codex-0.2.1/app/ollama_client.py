# app/ollama_client.py
from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests


class OllamaError(Exception):
    pass


class OllamaClient:
    """
    Minimal Ollama HTTP client for local usage.
    Uses /api/chat endpoint.

    Docs: https://docs.ollama.com/api/introduction
    """

    def __init__(self, host: str = "http://127.0.0.1:11434", timeout_sec: int = 120):
        self.host = host.rstrip("/")
        self.timeout_sec = timeout_sec

    def chat(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = f"{self.host}/api/chat"
        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": False,
        }
        if tools is not None:
            payload["tools"] = tools
        if options is not None:
            payload["options"] = options

        try:
            r = requests.post(url, json=payload, timeout=self.timeout_sec)
        except requests.RequestException as e:
            raise OllamaError(f"Failed to connect to Ollama at {self.host}: {e}")

        if r.status_code != 200:
            raise OllamaError(f"Ollama error {r.status_code}: {r.text}")

        data = r.json()
        return data