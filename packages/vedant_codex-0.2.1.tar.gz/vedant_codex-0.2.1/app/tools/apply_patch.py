# app/tools/apply_patch.py
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .fs_guard import get_guard, FSGuardError
from .quota_hooks import consume_patch_quota

HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*$")


@dataclass
class Hunk:
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    lines: List[str]  # includes leading ' ', '+', '-'


@dataclass
class FilePatch:
    path: str  # diff header path (---/+++)
    hunks: List[Hunk]


def apply_patch(diff: str, dry_run: bool = False) -> Dict[str, Any]:
    """
    Apply a unified diff patch to files. This is the ONLY write operation.
    Restricted to allowlisted roots.

    New feature:
    - Can CREATE new text files from scratch when diff uses:
        --- /dev/null
        +++ b/path/to/newfile.ext
      (Git-style new file patch)

    Notes:
    - For safety, this only supports TEXT content (decoded as utf-8 with replacement).
    - Still validates patch context strictly for existing files.
    - Consumes patch quota ONLY when a real write happens and dry_run=False.
    - Returns a compact preview of changes.
    """
    if not diff or not isinstance(diff, str):
        raise ValueError("diff must be a non-empty string")

    guard = get_guard()
    patches = _parse_unified_diff(diff)

    results: List[Dict[str, Any]] = []

    # Detect whether diff contains "/dev/null" old headers for new files
    # We do this by scanning the raw diff once.
    raw_lines = diff.splitlines()
    new_file_paths: set[str] = set()
    for i in range(len(raw_lines) - 1):
        if raw_lines[i].startswith("--- ") and raw_lines[i][4:].strip() == "/dev/null":
            if raw_lines[i + 1].startswith("+++ "):
                newp = raw_lines[i + 1][4:].strip()
                new_file_paths.add(newp)

    for fp in patches:
        local_rel = _diff_path_to_local(fp.path)
        target = (Path.cwd() / local_rel)

        # Normalize + allowlist check (do NOT require existence now; we may create)
        target = guard.safe_path(str(target), must_exist=False)

        is_new_file = fp.path.strip() in new_file_paths

        if target.exists() and target.is_dir():
            raise FSGuardError(f"Patch target is a directory: {target}")

        if (not target.exists()) and (not is_new_file):
            raise FSGuardError(
                f"Target file does not exist: {target}\n"
                f"To create a new file, the diff must use '--- /dev/null' and '+++ b/{local_rel.as_posix()}'."
            )

        if is_new_file and target.exists():
            # If it's marked as new but already exists, treat as safety error
            raise FSGuardError(f"Refusing to create new file because it already exists: {target}")

        # Load original lines (empty for new file)
        if is_new_file:
            original_lines: List[str] = []
        else:
            original_text = target.read_text(encoding="utf-8", errors="replace")
            original_lines = original_text.splitlines(keepends=True)

        # Apply hunks
        new_lines = _apply_hunks(original_lines, fp.hunks, target)
        changed = new_lines != original_lines
        preview = _build_preview(original_lines, new_lines, max_lines=20)

        if changed and not dry_run:
            # Count toward patch quota only when we actually write
            consume_patch_quota()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("".join(new_lines), encoding="utf-8", newline="")

        results.append(
            {
                "file": str(target),
                "created": bool(is_new_file and (changed or dry_run)),
                "changed": changed,
                "dry_run": dry_run,
                "hunks": len(fp.hunks),
                "old_lines": len(original_lines),
                "new_lines": len(new_lines),
                "preview": preview,
            }
        )

    return {"ok": True, "dry_run": dry_run, "files": results}


def _diff_path_to_local(p: str) -> Path:
    """
    Convert diff path like 'a/src/main.py' or 'src/main.py' to a local Path.
    Strips leading a/ or b/ and keeps the rest.
    """
    p = (p or "").strip()
    if p.startswith("a/") or p.startswith("b/"):
        p = p[2:]
    p = p.replace("/", "\\")
    return Path(p)


def _parse_unified_diff(diff: str) -> List[FilePatch]:
    lines = diff.splitlines()
    i = 0
    patches: List[FilePatch] = []

    while i < len(lines):
        line = lines[i]

        if line.startswith("--- "):
            old_hdr = line
            i += 1
            if i >= len(lines) or not lines[i].startswith("+++ "):
                raise FSGuardError("Invalid diff: missing '+++' header after '---'")
            new_hdr = lines[i]

            old_path = old_hdr[4:].strip()
            new_path = new_hdr[4:].strip()
            path = new_path if new_path and new_path != "/dev/null" else old_path
            i += 1

            hunks: List[Hunk] = []
            while i < len(lines):
                if lines[i].startswith("--- "):
                    break
                if lines[i].startswith("@@ "):
                    hunk, i = _parse_hunk(lines, i)
                    hunks.append(hunk)
                else:
                    i += 1

            patches.append(FilePatch(path=path, hunks=hunks))
            continue

        i += 1

    if not patches:
        raise FSGuardError("No file patches found in diff.")
    return patches


def _parse_hunk(lines: List[str], start: int) -> Tuple[Hunk, int]:
    m = HUNK_RE.match(lines[start])
    if not m:
        raise FSGuardError(f"Invalid hunk header: {lines[start]!r}")

    old_start = int(m.group(1))
    old_count = int(m.group(2) or "1")
    new_start = int(m.group(3))
    new_count = int(m.group(4) or "1")

    i = start + 1
    hunk_lines: List[str] = []
    while i < len(lines):
        s = lines[i]
        if s.startswith("@@ ") or s.startswith("--- "):
            break
        if s.startswith((" ", "+", "-")):
            hunk_lines.append(s)
        elif s.startswith("\\ No newline at end of file"):
            pass
        else:
            raise FSGuardError(f"Unexpected diff line in hunk: {s!r}")
        i += 1

    return (
        Hunk(
            old_start=old_start,
            old_count=old_count,
            new_start=new_start,
            new_count=new_count,
            lines=hunk_lines,
        ),
        i,
    )


def _apply_hunks(original: List[str], hunks: List[Hunk], target: Path) -> List[str]:
    out = original[:]
    line_offset = 0

    for h in hunks:
        idx0 = max(0, (h.old_start - 1) + line_offset)

        expected_old: List[str] = []
        replacement: List[str] = []

        for dl in h.lines:
            tag = dl[:1]
            content = dl[1:]
            content_nl = content + "\n"

            if tag == " ":
                expected_old.append(content_nl)
                replacement.append(content_nl)
            elif tag == "-":
                expected_old.append(content_nl)
            elif tag == "+":
                replacement.append(content_nl)

        current_slice = out[idx0 : idx0 + len(expected_old)]
        if current_slice != expected_old:
            preview_cur = "".join(current_slice[:8])
            preview_exp = "".join(expected_old[:8])
            raise FSGuardError(
                f"Patch context mismatch for {target} at hunk starting line {h.old_start}.\n"
                f"Current (first lines):\n{preview_cur}\n"
                f"Expected (first lines):\n{preview_exp}"
            )

        out[idx0 : idx0 + len(expected_old)] = replacement
        line_offset += (len(replacement) - len(expected_old))

    return out


def _build_preview(old_lines: List[str], new_lines: List[str], max_lines: int = 20) -> List[Dict[str, Any]]:
    preview: List[Dict[str, Any]] = []

    old = [l.rstrip("\n") for l in old_lines]
    new = [l.rstrip("\n") for l in new_lines]

    i = j = 0
    while i < len(old) or j < len(new):
        if len(preview) >= max_lines:
            break

        if i < len(old) and j < len(new) and old[i] == new[j]:
            i += 1
            j += 1
            continue

        if i >= len(old) and j < len(new):
            preview.append({"type": "add", "text": new[j][:200]})
            j += 1
            continue
        if j >= len(new) and i < len(old):
            preview.append({"type": "del", "text": old[i][:200]})
            i += 1
            continue

        preview.append({"type": "del", "text": old[i][:200]})
        if len(preview) >= max_lines:
            break
        preview.append({"type": "add", "text": new[j][:200]})
        i += 1
        j += 1

    if (i < len(old) or j < len(new)) and len(preview) >= max_lines:
        preview.append({"type": "chg", "text": "… (more changes) …"})

    return preview