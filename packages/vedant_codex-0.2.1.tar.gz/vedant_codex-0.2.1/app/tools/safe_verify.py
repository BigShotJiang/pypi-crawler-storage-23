from __future__ import annotations

from typing import Any, Dict, List
from .run_cmd import run_cmd

ALLOWED_PREFIXES = (
    "python -m pytest",
    "python -m compileall",
    "pytest",
    "npm test",
    "npm run build",
    "npm run lint",
    "ruff check",
    "black --check",
)

def safe_verify(commands: List[str]) -> Dict:
    if not commands:
        return {"ok": False, "error": "No verify commands provided"}

    for c in commands:
        c = (c or "").strip()
        if not c.startswith(ALLOWED_PREFIXES):
            return {"ok": False, "error": f"Command not allowed in safe_verify: {c}"}

    results = []
    all_ok = True
    for c in commands:
        out = run_cmd(cmd=c)
        # assume run_cmd returns dict with ok + stdout/stderr/exit_code (adjust if needed)
        results.append({"cmd": c, "result": out})
        if isinstance(out, dict) and out.get("ok") is False:
            all_ok = False

    return {"ok": all_ok, "results": results}

def safe_verify(cwd: str, commands: List[str]) -> Dict[str, Any]:
    """
    Run a series of safe, allowlisted commands via run_cmd and return overall pass/fail.
    """
    if not commands or not isinstance(commands, list):
        raise ValueError("commands must be a non-empty list[str]")

    results = []
    ok = True

    for c in commands:
        out = run_cmd(cmd=c, cwd=cwd)
        results.append(out)
        # run_cmd returns returncode; 0 means success
        if out.get("returncode") not in (0, "0"):
            ok = False

    return {"ok": ok, "cwd": cwd, "results": results}