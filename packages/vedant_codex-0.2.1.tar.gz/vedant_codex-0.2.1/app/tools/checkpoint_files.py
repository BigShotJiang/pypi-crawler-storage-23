from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .fs_guard import get_guard


def _utc_id() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def checkpoint_files(files: List[str], label: str = "") -> Dict[str, Any]:
    """
    Create a checkpoint of specific files (within allowlist) so we can rollback safely.
    Stores copies under: <allowlisted_root>/.local-codex/checkpoints/<id>/

    Returns checkpoint_id and manifest.
    """
    if not files or not isinstance(files, list):
        raise ValueError("files must be a non-empty list of file paths")

    guard = get_guard()

    # Normalize + validate all file paths
    resolved: List[Path] = []
    for f in files:
        p = guard.safe_path(str(f), must_exist=True)
        if p.is_dir():
            raise ValueError(f"checkpoint_files expects files, not directories: {p}")
        resolved.append(p)

    # Put checkpoint folder under the first matching allowlist root
    # (the file is guaranteed to be within SOME allowlisted root)
    root = None
    for r in guard.allowlist_roots:
        r = r.resolve(strict=False)
        for p in resolved:
            try:
                if p == r or p.is_relative_to(r):
                    root = r
                    break
            except AttributeError:
                # py<3.9 fallback not needed for your env usually, keep simple
                if str(p).startswith(str(r)):
                    root = r
                    break
        if root:
            break
    if root is None:
        raise ValueError("Could not determine allowlisted root for checkpoint")

    ckpt_id = _utc_id()
    ckpt_dir = root / ".local-codex" / "checkpoints" / ckpt_id
    data_dir = ckpt_dir / "files"
    data_dir.mkdir(parents=True, exist_ok=True)

    entries = []
    for p in resolved:
        rel = p.relative_to(root)
        dest = data_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
        entries.append({"abs": str(p), "rel": str(rel)})

    manifest = {
        "checkpoint_id": ckpt_id,
        "label": (label or "").strip(),
        "root": str(root),
        "created_utc": ckpt_id,
        "files": entries,
    }
    (ckpt_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    return {"ok": True, "checkpoint_id": ckpt_id, "manifest": manifest}