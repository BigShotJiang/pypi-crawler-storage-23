from __future__ import annotations

import webbrowser
from pathlib import Path
from typing import Any, Dict
from urllib.parse import urlparse

from .fs_guard import get_guard


def open_in_browser(target: str) -> Dict[str, Any]:
    """
    Open a local file (inside allowlisted roots) OR a localhost URL in the default browser.
    Allowed:
      - file paths within allowlisted project folders
      - http(s)://localhost[:port]/... or 127.0.0.1
    """
    if not target or not isinstance(target, str):
        raise ValueError("target must be a non-empty string")

    t = target.strip()
    # If URL, restrict to localhost for safety
    if t.startswith("http://") or t.startswith("https://"):
        u = urlparse(t)
        host = (u.hostname or "").lower()
        if host not in ("localhost", "127.0.0.1"):
            raise ValueError("Only localhost URLs are allowed")
        ok = webbrowser.open(t, new=2)
        return {"ok": bool(ok), "opened": t, "type": "url"}

    # Otherwise treat as a file path
    guard = get_guard()
    p = guard.safe_path(str((Path.cwd() / t).resolve()), must_exist=True)
    ok = webbrowser.open(p.as_uri(), new=2)
    return {"ok": bool(ok), "opened": str(p), "type": "file"}