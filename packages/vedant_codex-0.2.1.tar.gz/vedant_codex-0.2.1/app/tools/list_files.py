# app/tools/list_files.py
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from .fs_guard import get_guard, FSGuardError


def list_files(dir_path: str, recursive: bool = False, max_entries: int = 200) -> Dict[str, Any]:
    """
    List files/folders under a directory. Restricted to allowlisted roots.
    """
    guard = get_guard()
    d = guard.safe_path(dir_path, must_exist=True)
    if not d.is_dir():
        raise FSGuardError(f"Not a directory: {d}")

    entries: List[Dict[str, Any]] = []
    count = 0

    if not recursive:
        for p in sorted(d.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
            entries.append(_entry(p, base=d))
            count += 1
            if count >= max_entries:
                break
    else:
        for p in sorted(d.rglob("*"), key=lambda x: str(x).lower()):
            # Skip very deep hidden/system folders? Keep simple; user can refine via allowlist.
            entries.append(_entry(p, base=d))
            count += 1
            if count >= max_entries:
                break

    return {
        "dir": str(d),
        "recursive": recursive,
        "max_entries": max_entries,
        "returned": len(entries),
        "entries": entries,
        "truncated": len(entries) >= max_entries,
    }


def _entry(p: Path, base: Path) -> Dict[str, Any]:
    rel = None
    try:
        rel = str(p.relative_to(base))
    except Exception:
        rel = p.name

    info: Dict[str, Any] = {
        "name": p.name,
        "path": str(p),
        "relative": rel,
        "type": "dir" if p.is_dir() else "file",
    }
    if p.is_file():
        try:
            info["size_bytes"] = p.stat().st_size
        except Exception:
            pass
    return info