from __future__ import annotations

from typing import Dict

from .apply_patch import apply_patch


def create_file(path: str, content: str, dry_run: bool = False) -> Dict[str, object]:
    """
    Create a NEW text file from scratch.
    Internally uses apply_patch with Git-style new-file headers:
      --- /dev/null
      +++ b/<path>
    """
    if not path or not isinstance(path, str):
        raise ValueError("path must be a non-empty string")
    if content is None:
        content = ""

    p = path.strip().lstrip("/").replace("\\", "/")
    lines = content.splitlines()

    diff_lines = [
        "--- /dev/null",
        f"+++ b/{p}",
        "@@ -0,0 +1,{} @@".format(max(1, len(lines))),
    ]
    diff_lines.extend("+" + ln for ln in lines)

    # Ensure file ends with newline for nicer editing
    if content and not content.endswith("\n"):
        diff_lines.append("+")

    return apply_patch("\n".join(diff_lines), dry_run=dry_run)