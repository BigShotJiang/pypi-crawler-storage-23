# app/tools/search_files.py
from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Any, Dict, List

from .fs_guard import get_guard, FSGuardError


def search_files(
    root_dir: str,
    query: str,
    file_glob: str = "**/*",
    max_matches: int = 50,
) -> Dict[str, Any]:
    """
    Simple substring search in text files under root_dir.
    Restricted to allowlisted roots and file size limits.
    """
    if not query:
        raise ValueError("query must be non-empty")

    guard = get_guard()
    root = guard.safe_path(root_dir, must_exist=True)
    if not root.is_dir():
        raise FSGuardError(f"Not a directory: {root}")

    matches: List[Dict[str, Any]] = []
    scanned_files = 0

    # Normalize glob: allow patterns like "*.py" or "**/*.py"
    pattern = file_glob or "**/*"

    for p in root.rglob("*"):
        if not p.is_file():
            continue

        # Apply glob relative to root, using forward slashes for matching
        rel = p.relative_to(root)
        rel_s = str(rel).replace("\\", "/")
        if not fnmatch.fnmatch(rel_s, pattern.replace("\\", "/")):
            continue

        # Skip huge files
        try:
            if p.stat().st_size > guard.max_file_bytes:
                continue
        except Exception:
            continue

        scanned_files += 1

        try:
            with p.open("rb") as f:
                data = f.read(guard.max_file_bytes + 1)
            if len(data) > guard.max_file_bytes:
                continue
            text = data.decode("utf-8", errors="replace")
        except Exception:
            continue

        # Find matches line-by-line
        for idx, line in enumerate(text.splitlines(), start=1):
            if query in line:
                matches.append(
                    {
                        "file": str(p),
                        "relative": str(rel),
                        "line": idx,
                        "text": line[:500],
                    }
                )
                if len(matches) >= max_matches:
                    return {
                        "root": str(root),
                        "query": query,
                        "file_glob": pattern,
                        "scanned_files": scanned_files,
                        "returned": len(matches),
                        "matches": matches,
                        "truncated": True,
                    }

    return {
        "root": str(root),
        "query": query,
        "file_glob": pattern,
        "scanned_files": scanned_files,
        "returned": len(matches),
        "matches": matches,
        "truncated": False,
    }