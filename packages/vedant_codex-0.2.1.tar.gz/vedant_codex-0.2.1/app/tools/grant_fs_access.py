from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict

from .fs_guard import get_guard


def grant_fs_access(path: str, persist: bool = False) -> Dict[str, Any]:
    """
    Grant filesystem access to a directory by adding it to the FSGuard allowlist roots.

    - `persist=False` means runtime only (recommended).
    - If you want persistence, wire `persist=True` to write into your config file
      (depends on how your AppConfig is implemented).

    NOTE: This requires FSGuard to support dynamically adding roots.
    Add a method like `guard.add_root(Path)` in fs_guard.py.
    """
    if not path or not isinstance(path, str):
        raise ValueError("path must be a non-empty string")

    p = Path(path.strip()).expanduser()
    # If user passes a relative path, treat it relative to current working dir
    if not p.is_absolute():
        p = (Path.cwd() / p).resolve()

    if not p.exists() or not p.is_dir():
        raise ValueError(f"path must be an existing directory: {p}")

    guard = get_guard()
    # You must add this method in FSGuard:
    guard.add_root(p)

    # Optional: persistence hook (only if you implement it)
    persisted = False
    if persist:
        # Implement config persistence if you want:
        # - read config
        # - append root
        # - save config
        persisted = False

    return {
        "ok": True,
        "granted": str(p),
        "persisted": persisted,
        "allowlist_roots_now": [str(x) for x in guard.allowlist_roots],
    }