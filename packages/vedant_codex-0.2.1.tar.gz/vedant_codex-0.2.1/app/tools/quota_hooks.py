# app/tools/quota_hooks.py
from __future__ import annotations

from typing import Callable, Optional

_PATCH_QUOTA_CB: Optional[Callable[[], None]] = None


def set_patch_quota_callback(cb: Callable[[], None]) -> None:
    global _PATCH_QUOTA_CB
    _PATCH_QUOTA_CB = cb


def consume_patch_quota() -> None:
    """
    Called by apply_patch when it performs a real write (not dry-run).
    """
    if _PATCH_QUOTA_CB is not None:
        _PATCH_QUOTA_CB()