from __future__ import annotations

import re
from typing import Any, Dict, List

import requests


def web_search(query: str, max_results: int = 5) -> Dict[str, Any]:
    """
    Simple web search (DuckDuckGo HTML endpoint).
    Returns a small list of {title, url} items.
    """
    if not query or not isinstance(query, str):
        raise ValueError("query must be a non-empty string")
    max_results = max(1, min(int(max_results or 5), 10))

    q = query.strip()
    url = "https://duckduckgo.com/html/"
    r = requests.get(url, params={"q": q}, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    html = r.text

    # Very lightweight parse: find result links
    # DuckDuckGo HTML results typically include <a class="result__a" href="...">Title</a>
    pattern = re.compile(r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.I | re.S)
    out: List[Dict[str, Any]] = []
    for m in pattern.finditer(html):
        href = m.group(1).strip()
        title = re.sub(r"<.*?>", "", m.group(2)).strip()
        if href and title:
            out.append({"title": title, "url": href})
        if len(out) >= max_results:
            break

    return {"ok": True, "query": q, "results": out}