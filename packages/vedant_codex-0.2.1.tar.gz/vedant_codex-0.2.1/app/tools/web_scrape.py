from __future__ import annotations

import re
from html import unescape
from typing import Any, Dict, Optional

import requests


_RE_SCRIPT_STYLE = re.compile(r"(?is)<(script|style|noscript|svg|canvas|iframe)[^>]*>.*?</\1>")
_RE_TAGS = re.compile(r"(?s)<[^>]+>")
_RE_WHITESPACE = re.compile(r"[ \t\r\f\v]+")


def _extract_title(html: str) -> str:
    m = re.search(r"(?is)<title[^>]*>(.*?)</title>", html)
    if not m:
        return ""
    t = unescape(m.group(1))
    t = _RE_TAGS.sub("", t)
    return t.strip()


def _html_to_text(html: str) -> str:
    html = _RE_SCRIPT_STYLE.sub(" ", html)
    html = re.sub(r"(?i)<br\s*/?>", "\n", html)
    html = re.sub(r"(?i)</p\s*>", "\n\n", html)
    html = re.sub(r"(?i)</h[1-6]\s*>", "\n\n", html)

    text = _RE_TAGS.sub(" ", html)
    text = unescape(text)

    # normalize spaces, keep newlines
    lines = []
    for line in text.splitlines():
        line = _RE_WHITESPACE.sub(" ", line).strip()
        if line:
            lines.append(line)
        else:
            # keep paragraph breaks minimal
            if lines and lines[-1] != "":
                lines.append("")
    # collapse multiple blank lines
    out = "\n".join(lines)
    out = re.sub(r"\n{3,}", "\n\n", out).strip()
    return out


def web_scrape(
    url: str,
    max_chars: int = 12000,
    timeout_sec: int = 12,
    user_agent: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Fetch a web page and return extracted readable text.

    Safety defaults:
    - limit max_chars
    - basic content-type handling
    - no JS execution (pure HTTP GET)
    """
    if not url or not isinstance(url, str):
        raise ValueError("url must be a non-empty string")

    u = url.strip()

    headers = {"User-Agent": user_agent or "Mozilla/5.0 (Local-Codex)"}
    r = requests.get(u, timeout=float(timeout_sec), headers=headers)
    r.raise_for_status()

    ctype = (r.headers.get("content-type") or "").lower()
    # allow html-ish responses; still try parsing even if mislabelled
    raw = r.text or ""

    title = _extract_title(raw)
    text = _html_to_text(raw)

    if max_chars and len(text) > int(max_chars):
        text = text[: int(max_chars)] + "\n\n… (truncated) …"

    return {
        "ok": True,
        "url": u,
        "content_type": ctype,
        "title": title,
        "text": text,
        "chars": len(text),
    }