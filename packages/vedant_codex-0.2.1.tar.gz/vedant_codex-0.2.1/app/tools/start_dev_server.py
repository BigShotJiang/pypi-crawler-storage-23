from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path
from typing import Any, Dict, List

from .fs_guard import get_guard, FSGuardError


class CommandNotAllowed(Exception):
    pass


def _split_allowlist(value: str) -> List[str]:
    parts = [p.strip() for p in (value or "").split(";")]
    return [p for p in parts if p]


def _is_allowed(cmd: str, allowlist_prefixes: List[str]) -> bool:
    c = cmd.strip().lower()
    for p in allowlist_prefixes:
        if c.startswith(p.strip().lower()):
            return True
    return False


def start_dev_server(cmd: str, cwd: str) -> Dict[str, Any]:
    """
    Start a long-running dev server in the background (detached).
    - cmd must match allowlist prefix
    - cwd must be within allowlisted roots
    """
    if not cmd or not isinstance(cmd, str):
        raise ValueError("cmd must be a non-empty string")

    guard = get_guard()
    cwd_path = guard.safe_path(cwd, must_exist=True)
    if not cwd_path.is_dir():
        raise FSGuardError(f"cwd is not a directory: {cwd_path}")

    allowlist = _split_allowlist(
        os.getenv(
            "DEV_SERVER_ALLOWLIST",
            "python -m http.server;npm run dev;npm start;yarn dev;pnpm dev",
        )
    )
    if not _is_allowed(cmd, allowlist):
        raise CommandNotAllowed(f"Command not allowed: {cmd!r}. Allowed prefixes: {allowlist}")

    args = shlex.split(cmd, posix=False)

    # Detach cross-platform
    if os.name == "nt":
        creationflags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        p = subprocess.Popen(
            args,
            cwd=str(cwd_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=creationflags,
            close_fds=True,
        )
    else:
        p = subprocess.Popen(
            args,
            cwd=str(cwd_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

    return {"ok": True, "cmd": cmd, "cwd": str(cwd_path), "pid": p.pid}