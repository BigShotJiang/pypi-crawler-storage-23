# app/tools/run_cmd.py
from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path
from typing import Any, Dict, List

from .fs_guard import get_guard, FSGuardError


class CommandNotAllowed(Exception):
    pass


def _split_allowlist(value: str) -> List[str]:
    # Windows-friendly separator ';'
    parts = [p.strip() for p in (value or "").split(";")]
    return [p for p in parts if p]


def run_cmd(cmd: str, cwd: str, timeout_sec: int = 60) -> Dict[str, Any]:
    """
    Run an allowlisted command (OPTIONAL tool).
    Security: command must match allowlist prefix exactly (string startswith).
    cwd must be within allowlisted roots.
    """
    if not cmd or not isinstance(cmd, str):
        raise ValueError("cmd must be a non-empty string")

    guard = get_guard()
    cwd_path = guard.safe_path(cwd, must_exist=True)
    if not cwd_path.is_dir():
        raise FSGuardError(f"cwd is not a directory: {cwd_path}")

    allowlist = _split_allowlist(os.getenv("CMD_ALLOWLIST", "pytest;python -m pytest;npm test"))
    allowlist = _split_allowlist(
        os.getenv(
            "CMD_ALLOWLIST",
            "pytest;python -m pytest;npm test;npm run build;npm run lint;npm run typecheck",
        )
    )

    # Use shell=False for safety. On Windows, split with shlex; it handles quoted args.
    args = shlex.split(cmd, posix=False)

    try:
        completed = subprocess.run(
            args,
            cwd=str(cwd_path),
            capture_output=True,
            text=True,
            timeout=int(timeout_sec),
            shell=False,
        )
        return {
            "cmd": cmd,
            "cwd": str(cwd_path),
            "returncode": completed.returncode,
            "stdout": completed.stdout[-20000:],  # avoid huge outputs
            "stderr": completed.stderr[-20000:],
        }
    except subprocess.TimeoutExpired as e:
        return {
            "cmd": cmd,
            "cwd": str(cwd_path),
            "timeout_sec": timeout_sec,
            "returncode": None,
            "stdout": (e.stdout or "")[-20000:],
            "stderr": (e.stderr or "")[-20000:],
            "error": "timeout",
        }


def _is_allowed(cmd: str, allowlist_prefixes: List[str]) -> bool:
    # Simple, predictable rule: cmd must start with one of the allowed prefixes.
    c = cmd.strip().lower()
    for p in allowlist_prefixes:
        if c.startswith(p.strip().lower()):
            return True
    return False