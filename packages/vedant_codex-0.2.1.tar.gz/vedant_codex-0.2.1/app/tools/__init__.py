from typing import Any, Callable, Dict

from .list_files import list_files
from .read_file import read_file
from .search_files import search_files
from .apply_patch import apply_patch
from .create_file import create_file
from .run_cmd import run_cmd
from .open_in_browser import open_in_browser
from .start_dev_server import start_dev_server
from .web_search import web_search
from .request_fs_access import request_fs_access
from .grant_fs_access import grant_fs_access
from .web_scrape import web_scrape
from .checkpoint_files import checkpoint_files
from .restore_checkpoint import restore_checkpoint
from .safe_verify import safe_verify

def get_tool_registry() -> Dict[str, Callable[..., Any]]:
    return {
        "list_files": list_files,
        "read_file": read_file,
        "search_files": search_files,
        "apply_patch": apply_patch,
        "create_file": create_file,
        "run_cmd": run_cmd,
        "open_in_browser": open_in_browser,
        "start_dev_server": start_dev_server,
        "web_search": web_search,
        "request_fs_access": request_fs_access,
        "grant_fs_access": grant_fs_access,
        "web_scrape": web_scrape,
        "checkpoint_files": checkpoint_files,
        "restore_checkpoint": restore_checkpoint,
        "safe_verify": safe_verify,

    }