from __future__ import annotations

from typing import Any, Dict


def request_fs_access(path: str, reason: str = "") -> Dict[str, Any]:
    """
    Ask the host UI/CLI to request user permission to access a directory.

    IMPORTANT:
    - This tool does NOT grant access by itself.
    - Your CLI should intercept this tool output and prompt the user (y/n).
    - If approved, CLI should call `grant_fs_access`.
    """
    if not path or not isinstance(path, str):
        raise ValueError("path must be a non-empty string")

    p = path.strip()

    return {
        "ok": True,
        "type": "permission_request",
        "permission": "fs_access",
        "path": p,
        "reason": (reason or "").strip(),
        "next_tool": "grant_fs_access",
        "message": f"Requesting permission to access directory: {p}",
    }