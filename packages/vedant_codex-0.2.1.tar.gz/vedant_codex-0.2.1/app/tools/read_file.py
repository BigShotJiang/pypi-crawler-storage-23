# app/tools/read_file.py
from __future__ import annotations

from typing import Any, Dict

from .fs_guard import get_guard, FSGuardError


def read_file(file_path: str, max_bytes: int = 200_000) -> Dict[str, Any]:
    """
    Read a text file safely (size-limited). Restricted to allowlisted roots.
    """
    guard = get_guard()
    p = guard.safe_path(file_path, must_exist=True)
    if p.is_dir():
        raise FSGuardError(f"Not a file: {p}")

    size = p.stat().st_size
    read_limit = min(max_bytes, guard.max_file_bytes)

    # Read bytes then decode (more robust than text read for odd encodings).
    with p.open("rb") as f:
        data = f.read(read_limit + 1)

    truncated = len(data) > read_limit
    if truncated:
        data = data[:read_limit]

    text = data.decode("utf-8", errors="replace")

    return {
        "file": str(p),
        "size_bytes": size,
        "max_bytes": read_limit,
        "truncated": truncated,
        "content": text,
    }