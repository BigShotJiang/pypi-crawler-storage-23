from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, Dict

from .fs_guard import get_guard


def restore_checkpoint(root: str, checkpoint_id: str) -> Dict[str, Any]:
    """
    Restore files from: <root>/.local-codex/checkpoints/<checkpoint_id>/files/
    """
    if not root or not checkpoint_id:
        raise ValueError("root and checkpoint_id are required")

    guard = get_guard()
    root_path = guard.safe_path(root, must_exist=True)
    if not root_path.is_dir():
        raise ValueError(f"root must be a directory: {root_path}")

    ckpt_dir = root_path / ".local-codex" / "checkpoints" / checkpoint_id
    manifest_path = ckpt_dir / "manifest.json"
    data_dir = ckpt_dir / "files"

    if not manifest_path.exists() or not data_dir.exists():
        raise ValueError(f"Checkpoint not found: {ckpt_dir}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    restored = 0

    for entry in manifest.get("files", []):
        rel = Path(entry["rel"])
        src = data_dir / rel
        dst = root_path / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        restored += 1

    return {"ok": True, "restored_files": restored, "checkpoint_id": checkpoint_id, "root": str(root_path)}