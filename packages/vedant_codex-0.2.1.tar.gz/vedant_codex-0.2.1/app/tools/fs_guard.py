# app/tools/fs_guard.py
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List


class FSGuardError(Exception):
    pass


def _split_allowlist(value: str) -> List[str]:
    # Windows-friendly separator is ';' (like PATH).
    parts = [p.strip().strip('"') for p in (value or "").split(";")]
    return [p for p in parts if p]


@dataclass
class FSGuard:
    allowlist_roots: List[Path]
    max_file_bytes: int = 200_000

    @staticmethod
    def from_env() -> "FSGuard":
        roots_raw = os.getenv("ALLOWLIST_ROOTS", "")
        roots = [_ensure_dir_path(p) for p in _split_allowlist(roots_raw)]
        if not roots:
            raise FSGuardError(
                "ALLOWLIST_ROOTS is empty. Set it to one or more folders separated by ';'. "
                "Example: ALLOWLIST_ROOTS=C:\\Users\\you\\projects\\myrepo"
            )
        max_bytes = int(os.getenv("MAX_FILE_BYTES", "200000"))
        return FSGuard(allowlist_roots=roots, max_file_bytes=max_bytes)

    def normalize(self, user_path: str) -> Path:
        if not user_path or not isinstance(user_path, str):
            raise FSGuardError("Path must be a non-empty string.")
        # Expand ~ and env vars; handle forward slashes too.
        expanded = os.path.expandvars(os.path.expanduser(user_path))
        p = Path(expanded)

        # If relative, interpret as relative to current working directory.
        if not p.is_absolute():
            p = (Path.cwd() / p)

        # Resolve without requiring existence (strict=False).
        try:
            rp = p.resolve(strict=False)
        except Exception as e:
            raise FSGuardError(f"Invalid path: {user_path!r} ({type(e).__name__}: {e})")
        return rp

    def ensure_within_allowlist(self, path: Path) -> None:
        for root in self.allowlist_roots:
            try:
                # Python 3.9+: Path.is_relative_to
                if path == root or path.is_relative_to(root):
                    return
            except AttributeError:
                # Fallback for older: compare string prefixes of resolved paths
                root_s = str(root).rstrip("\\/") + "\\"
                path_s = str(path)
                if path_s == str(root) or path_s.startswith(root_s):
                    return
        raise FSGuardError(f"Access denied (outside allowlist): {path}")

    def safe_path(self, user_path: str, must_exist: bool | None = None) -> Path:
        p = self.normalize(user_path)
        self.ensure_within_allowlist(p)
        if must_exist is True and not p.exists():
            raise FSGuardError(f"Path does not exist: {p}")
        if must_exist is False and p.exists() and p.is_dir():
            # For file-only operations, caller can enforce separately.
            pass
        return p


def _ensure_dir_path(p: str) -> Path:
    if not p:
        raise FSGuardError("Empty allowlist root.")
    expanded = os.path.expandvars(os.path.expanduser(p))
    root = Path(expanded)
    if not root.is_absolute():
        root = (Path.cwd() / root)
    root = root.resolve(strict=False)
    return root


# Simple singleton for tools (so tools can be called without passing guard around)
_GUARD: FSGuard | None = None


def get_guard() -> FSGuard:
    global _GUARD
    if _GUARD is None:
        _GUARD = FSGuard.from_env()
    return _GUARD


def set_guard(guard: FSGuard) -> None:
    global _GUARD
    _GUARD = guard

def add_root(self, root: Path) -> None:
    root = root.resolve()
    if root not in self.allowlist_roots:
        self.allowlist_roots.append(root)