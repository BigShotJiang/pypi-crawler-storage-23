# app/ui.py
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

console = Console()


@dataclass
class LiveStatus:
    """
    Codex-like live status:
    - A spinner-like animation (ASCII) + changing status text
    - Can be updated from callbacks (thread-safe enough for our use)
    """
    label: str = "Thinking…"

    def __post_init__(self) -> None:
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._live: Optional[Live] = None
        self._frame = 0

    def set(self, text: str) -> None:
        with self._lock:
            self.label = text

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._live = Live(self._render(), refresh_per_second=10, console=console, transient=True)
        self._live.__enter__()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=1.0)
        if self._live:
            try:
                self._live.__exit__(None, None, None)
            except Exception:
                pass
        self._thread = None
        self._live = None

    def _loop(self) -> None:
        while self._running:
            self._frame = (self._frame + 1) % 4
            if self._live:
                self._live.update(self._render())
            time.sleep(0.12)

    def _render(self):
        frames = ["⠋", "⠙", "⠹", "⠸"]
        with self._lock:
            label = self.label
        txt = Text.assemble((frames[self._frame] + " ", "cyan"), (label, "white"))
        return Panel(txt, border_style="dim", padding=(0, 1))