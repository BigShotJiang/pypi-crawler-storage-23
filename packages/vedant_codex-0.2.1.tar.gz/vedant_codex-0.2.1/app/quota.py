# app/quota.py
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


class QuotaExceeded(Exception):
    pass


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _today_utc_str() -> str:
    return _utc_now().date().isoformat()


@dataclass
class QuotaState:
    date: str
    requests_used: int
    patches_used: int
    last_updated_utc: str


@dataclass
class QuotaManager:
    usage_file: Path
    daily_max_requests: int
    daily_max_patches: int

    def ensure_storage(self) -> None:
        self.usage_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.usage_file.exists():
            self._write_state(
                QuotaState(
                    date=_today_utc_str(),
                    requests_used=0,
                    patches_used=0,
                    last_updated_utc=_utc_now().isoformat(),
                )
            )

    def load_state(self) -> QuotaState:
        self.ensure_storage()
        try:
            data = json.loads(self.usage_file.read_text(encoding="utf-8"))
        except Exception:
            # If corrupted, reset safely
            st = QuotaState(
                date=_today_utc_str(),
                requests_used=0,
                patches_used=0,
                last_updated_utc=_utc_now().isoformat(),
            )
            self._write_state(st)
            return st

        st = QuotaState(
            date=str(data.get("date") or _today_utc_str()),
            requests_used=int(data.get("requests_used") or 0),
            patches_used=int(data.get("patches_used") or 0),
            last_updated_utc=str(data.get("last_updated_utc") or _utc_now().isoformat()),
        )

        # Daily reset if day changed
        today = _today_utc_str()
        if st.date != today:
            st = QuotaState(
                date=today,
                requests_used=0,
                patches_used=0,
                last_updated_utc=_utc_now().isoformat(),
            )
            self._write_state(st)

        return st

    def check_request_allowed(self) -> None:
        st = self.load_state()
        if st.requests_used >= self.daily_max_requests:
            raise QuotaExceeded(
                f"Daily request quota exceeded: {st.requests_used}/{self.daily_max_requests}"
            )

    def check_patch_allowed(self) -> None:
        st = self.load_state()
        if st.patches_used >= self.daily_max_patches:
            raise QuotaExceeded(
                f"Daily patch quota exceeded: {st.patches_used}/{self.daily_max_patches}"
            )

    def increment_requests(self, n: int = 1) -> QuotaState:
        st = self.load_state()
        if st.requests_used + n > self.daily_max_requests:
            raise QuotaExceeded(
                f"Daily request quota exceeded: {st.requests_used}/{self.daily_max_requests}"
            )
        st.requests_used += n
        st.last_updated_utc = _utc_now().isoformat()
        self._write_state(st)
        return st

    def increment_patches(self, n: int = 1) -> QuotaState:
        st = self.load_state()
        if st.patches_used + n > self.daily_max_patches:
            raise QuotaExceeded(
                f"Daily patch quota exceeded: {st.patches_used}/{self.daily_max_patches}"
            )
        st.patches_used += n
        st.last_updated_utc = _utc_now().isoformat()
        self._write_state(st)
        return st

    def status(self) -> Dict[str, Any]:
        st = self.load_state()
        return {
            "date": st.date,
            "requests_used": st.requests_used,
            "requests_max": self.daily_max_requests,
            "patches_used": st.patches_used,
            "patches_max": self.daily_max_patches,
            "last_updated_utc": st.last_updated_utc,
        }

    def _write_state(self, st: QuotaState) -> None:
        payload = {
            "date": st.date,
            "requests_used": st.requests_used,
            "patches_used": st.patches_used,
            "last_updated_utc": st.last_updated_utc,
        }
        self.usage_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")