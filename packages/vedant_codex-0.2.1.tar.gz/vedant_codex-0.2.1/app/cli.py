# app/cli.py
from __future__ import annotations

import importlib.metadata
import os
import platform
import shutil
import subprocess
import sys
import time
import webbrowser

import requests
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from app.config import AppConfig
from app.main import main as run_chat  # reuse your existing chat loop

console = Console()


def _base(host: str) -> str:
    return (host or "").rstrip("/")


def _is_ollama_up(host: str) -> bool:
    """Ollama is considered 'up' if /api/tags responds."""
    try:
        r = requests.get(f"{_base(host)}/api/tags", timeout=1.5)
        return r.status_code == 200
    except requests.RequestException:
        return False


def _start_ollama_serve() -> None:
    """
    Start `ollama serve` in the background (best-effort).
    On Windows use detached flags; on others just Popen with stdio suppressed.
    """
    if platform.system().lower().startswith("win"):
        # Windows: DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        creationflags = 0x00000008 | 0x00000200
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=creationflags,
            close_fds=True,
        )
    else:
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True,
        )


def _wait_for_ollama(host: str, timeout_sec: int = 25) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_sec:
        if _is_ollama_up(host):
            return True
        time.sleep(0.4)
    return False


def _is_cloud_model(model: str) -> bool:
    """
    Cloud models in your setup look like:
      qwen3-coder:480b-cloud
      deepseek-v3.1:671b-cloud
      gpt-oss:120b-cloud

    These typically should NOT be 'pulled' like local models.
    """
    m = (model or "").strip().lower()
    return m.endswith("-cloud") or m.endswith(":cloud") or "-cloud" in m


def _model_exists_in_tags(host: str, model: str) -> bool:
    """For local models, /api/tags lists what exists."""
    try:
        r = requests.get(f"{_base(host)}/api/tags", timeout=3)
        r.raise_for_status()
        data = r.json()
        models = data.get("models", []) or []

        want = (model or "").strip().lower()
        want_prefix = want + ":"
        for m in models:
            name = (m.get("name") or "").strip().lower()
            if name == want or name.startswith(want_prefix):
                return True
        return False
    except Exception:
        return False


def _pull_model(model: str) -> None:
    """Pull a model with progress printed by the Ollama CLI."""
    subprocess.check_call(["ollama", "pull", model])


def _ensure_ollama_installed_or_exit() -> None:
    """If `ollama` isn't available, show OS-specific install instructions and exit."""
    if shutil.which("ollama"):
        return

    sysname = platform.system().lower()
    console.print("[red]Ollama is not installed or not found in PATH.[/red]\n")

    if "windows" in sysname:
        console.print(
            "Windows install:\n"
            "1) Download and run the Ollama installer\n"
            "2) Finish the wizard\n"
            "3) Re-open your terminal\n"
            "4) Run: [cyan]ollama --version[/cyan]\n"
            "5) Then run: [cyan]vedant[/cyan]\n"
        )
        url = "https://ollama.com/download/windows"
    elif "darwin" in sysname or "mac" in sysname:
        console.print(
            "macOS install:\n"
            "1) Download and install Ollama\n"
            "2) Open Ollama once (it runs in the menu bar)\n"
            "3) Re-open your terminal\n"
            "4) Run: [cyan]ollama --version[/cyan]\n"
            "5) Then run: [cyan]vedant[/cyan]\n"
        )
        url = "https://ollama.com/download/mac"
    else:
        console.print(
            "Linux install:\n"
            "1) Follow the official Ollama install steps\n"
            "2) Ensure `ollama` is in PATH\n"
            "3) Run: [cyan]ollama --version[/cyan]\n"
            "4) Then run: [cyan]vedant[/cyan]\n"
        )
        url = "https://ollama.com/download/linux"

    if os.getenv("VEDANT_NO_BROWSER") != "1":
        try:
            webbrowser.open(url, new=2)
            console.print(f"[dim]Opened: {url}[/dim]")
        except Exception:
            console.print(f"[dim]Download: {url}[/dim]")
    else:
        console.print(f"[dim]Download: {url}[/dim]")

    raise SystemExit(1)


def _print_version_and_exit() -> None:
    version = "dev"
    for dist_name in ("vedant-codex", "vedant"):
        try:
            version = importlib.metadata.version(dist_name)
            break
        except importlib.metadata.PackageNotFoundError:
            continue
    print(f"vedant {version}")
    raise SystemExit(0)


def _parse_session_id(argv: list[str]) -> str | None:
    """
    Resume sessions via: `vedant <session_id>`
    We ignore flags like --version, -v, etc.
    """
    for a in argv:
        if not a or a.startswith("-"):
            continue
        return a.strip()
    return None


def main() -> None:
    argv = sys.argv[1:]

    if "--version" in argv or "-v" in argv:
        _print_version_and_exit()

    cfg = AppConfig.load()

    console.print(
        Panel.fit(
            "[bold]Vedant[/bold] — Local Coding Assistant\n"
            f"Model: [cyan]{cfg.model}[/cyan]\n"
            f"Ollama: [cyan]{cfg.ollama_host}[/cyan]",
            title="Boot",
        )
    )

    _ensure_ollama_installed_or_exit()

    # 1) Ensure Ollama server is running
    if not _is_ollama_up(cfg.ollama_host):
        console.print("[yellow]Ollama server not running. Starting `ollama serve`...[/yellow]")
        try:
            _start_ollama_serve()
        except FileNotFoundError:
            console.print(
                "[red]`ollama` not found in PATH.[/red]\n"
                "Install Ollama, then reopen your terminal."
            )
            raise SystemExit(1)

        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            task = progress.add_task("Waiting for Ollama...", total=None)
            ok = _wait_for_ollama(cfg.ollama_host, timeout_sec=30)
            progress.remove_task(task)

        if not ok:
            console.print("[red]Ollama did not start in time.[/red]")
            raise SystemExit(1)

    # 2) Handle local vs cloud models
    if _is_cloud_model(cfg.model):
        console.print(f"[dim]Cloud model detected: {cfg.model} (skipping pull)[/dim]")
    else:
        if not _model_exists_in_tags(cfg.ollama_host, cfg.model):
            console.print(f"[yellow]Model '{cfg.model}' not found locally. Pulling...[/yellow]")
            try:
                _pull_model(cfg.model)
            except subprocess.CalledProcessError:
                console.print("[red]Failed to pull model.[/red]")
                raise SystemExit(1)

    # 3) Launch interactive chat UI (with optional session resume)
    console.print(
        Panel.fit(
            "Hello 👋  What can I help with?\n"
            "[dim]Tips: /quota to view limits, /exit to quit[/dim]\n"
            "[dim]Resume: vedant <session_id>[/dim]",
            title="Ready",
        )
    )

    session_id = _parse_session_id(argv)
    run_chat(session_id=session_id)


if __name__ == "__main__":
    main()
