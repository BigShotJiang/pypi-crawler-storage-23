import os

import pytest

from .conftest import requires_api_key


@pytest.mark.e2e
class TestContextE2ELocal:
    def test_context_current(self, run_cli):
        result = run_cli("context", "current")
        assert result.returncode == 0
        # Either shows "no context" or current context data - both valid
        assert len(result.stdout.strip()) > 0

    def test_context_set_with_endpoint(self, run_cli):
        result = run_cli("context", "set", "--cluster-id", "test-id", "--endpoint", "https://test.example.com")
        assert result.returncode == 0
        assert "test-id" in result.stdout

    def test_context_set_requires_args(self, run_cli):
        result = run_cli("context", "set")
        assert result.returncode != 0


@pytest.mark.e2e
@requires_api_key
class TestContextE2EWithAPI:
    def test_context_set_auto_resolve(self, run_cli):
        cluster_id = os.environ.get("ZILLIZ_CLUSTER_ID")
        if not cluster_id:
            pytest.skip("ZILLIZ_CLUSTER_ID not set")
        result = run_cli("context", "set", "--cluster-id", cluster_id)
        assert result.returncode == 0
        assert cluster_id in result.stdout
