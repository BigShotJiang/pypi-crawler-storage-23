import pytest


@pytest.mark.e2e
class TestConfigureE2E:
    def test_version(self, run_cli):
        result = run_cli("version")
        assert result.returncode == 0
        assert "0.1.0" in result.stdout

    def test_version_json(self, run_cli):
        result = run_cli("version", "--output", "json")
        assert result.returncode == 0
        assert '"version"' in result.stdout

    def test_help(self, run_cli):
        result = run_cli("--help")
        assert result.returncode == 0
        assert "cluster" in result.stdout
        assert "collection" in result.stdout
        assert "vector" in result.stdout
        assert "configure" in result.stdout
        assert "context" in result.stdout

    def test_cluster_help(self, run_cli):
        result = run_cli("cluster", "--help")
        assert result.returncode == 0
        assert "list" in result.stdout
        assert "describe" in result.stdout
        assert "create" in result.stdout
        assert "delete" in result.stdout

    def test_collection_help(self, run_cli):
        result = run_cli("collection", "--help")
        assert result.returncode == 0
        assert "list" in result.stdout
        assert "describe" in result.stdout
        assert "create" in result.stdout

    def test_vector_help(self, run_cli):
        result = run_cli("vector", "--help")
        assert result.returncode == 0
        assert "search" in result.stdout
        assert "query" in result.stdout
        assert "insert" in result.stdout
