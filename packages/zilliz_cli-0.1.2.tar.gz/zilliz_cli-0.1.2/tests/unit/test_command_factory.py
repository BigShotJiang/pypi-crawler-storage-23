# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

from unittest.mock import MagicMock, patch

import click
from click.testing import CliRunner

from zilliz_cli.core.command_factory import (
    _SMART_PARAM_FETCHERS,
    CommandFactory,
    _smart_prompt_param,
)
from zilliz_cli.core.model import CliModel, Param

SAMPLE_MODEL_DICT = {
    "version": "2026-01-27",
    "endpoint": "https://api.example.com",
    "resources": {
        "cluster": {
            "operations": {
                "list": {"http": {"method": "GET", "path": "/v2/clusters"}, "params": []},
                "describe": {
                    "http": {"method": "GET", "path": "/v2/clusters/{clusterId}"},
                    "params": [
                        {
                            "name": "clusterId",
                            "type": "string",
                            "required": True,
                            "cli": "--cluster-id",
                            "position": "path",
                        }
                    ],
                },
                "create": {
                    "http": {"method": "POST", "path": "/v2/clusters/createServerless"},
                    "params": [
                        {"name": "clusterName", "type": "string", "required": True, "cli": "--name"},
                        {"name": "projectId", "type": "string", "required": True, "cli": "--project-id"},
                        {"name": "regionId", "type": "string", "required": True, "cli": "--region"},
                    ],
                },
            }
        }
    },
}


class TestCommandFactoryStructure:
    def test_creates_group(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        assert "cluster" in groups
        assert isinstance(groups["cluster"], click.MultiCommand)

    def test_group_has_commands(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(cluster_group, ["--help"])
        assert "list" in result.output
        assert "describe" in result.output
        assert "create" in result.output

    def test_command_has_options(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(cluster_group, ["describe", "--help"])
        assert "--cluster-id" in result.output

    def test_required_option_enforced(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        result = runner.invoke(
            cluster_group, ["describe"], obj={"api_key": "test", "output_format": "json", "config_dir": None}
        )
        assert result.exit_code != 0


class TestCommandFactoryExecution:
    def test_list_calls_api(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1", "clusterName": "test"}]
            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )
            assert result.exit_code == 0
            assert "c1" in result.output
            mock_instance.call.assert_called_once_with("GET", "/v2/clusters", body={}, path_params={})

    def test_describe_with_path_param(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "c1", "status": "RUNNING"}
            result = runner.invoke(
                cluster_group,
                ["describe", "--cluster-id", "c1"],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )
            assert result.exit_code == 0
            assert "RUNNING" in result.output
            mock_instance.call.assert_called_once_with(
                "GET", "/v2/clusters/{clusterId}", body={}, path_params={"clusterId": "c1"}
            )

    def test_create_with_body_params(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "new-1"}
            result = runner.invoke(
                cluster_group,
                ["create", "--name", "my-cluster", "--project-id", "p1", "--region", "aws-us-east-1"],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )
            assert result.exit_code == 0
            mock_instance.call.assert_called_once_with(
                "POST",
                "/v2/clusters/createServerless",
                body={"clusterName": "my-cluster", "projectId": "p1", "regionId": "aws-us-east-1"},
                path_params={},
            )

    def test_api_error_displayed(self):
        from zilliz_cli.core.exceptions import APIError

        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        factory = CommandFactory(model)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]
        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.side_effect = APIError(80001, "Invalid API key")
            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "bad-key", "output_format": "json", "config_dir": None}
            )
            assert result.exit_code == 1
            assert "80001" in result.output


class TestCommandFactoryEndpointResolver:
    def test_custom_endpoint_resolver(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            return "https://custom-endpoint.example.com"

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"clusterId": "c1"}]

            result = runner.invoke(
                cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
            )

            assert result.exit_code == 0
            MockCaller.assert_called_once_with(api_key="test-key", base_url="https://custom-endpoint.example.com")

    def test_resolver_error_displayed(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)

        def resolver(ctx_obj):
            raise click.ClickException('No context set. Run "zilliz context set --cluster-id <id>" first.')

        factory = CommandFactory(model, endpoint_resolver=resolver)
        groups = factory.create_groups()
        cluster_group = groups["cluster"]

        runner = CliRunner()
        result = runner.invoke(
            cluster_group, ["list"], obj={"api_key": "test-key", "output_format": "json", "config_dir": None}
        )

        assert result.exit_code != 0
        assert "context" in result.output.lower()


VECTOR_MODEL_DICT = {
    "version": "1",
    "resources": {
        "vector": {
            "operations": {
                "search": {
                    "http": {"method": "POST", "path": "/v2/vectordb/entities/search"},
                    "params": [
                        {"name": "collectionName", "type": "string", "required": True, "cli": "--collection"},
                        {"name": "data", "type": "array", "required": True, "cli": "--data"},
                        {"name": "limit", "type": "integer", "default": 10, "cli": "--limit"},
                        {"name": "outputFields", "type": "array", "cli": "--output-fields"},
                    ],
                }
            }
        }
    },
}


def _mock_endpoint_resolver(ctx_obj):
    return "https://test-endpoint.example.com"


class TestCommandFactoryArrayParams:
    def test_array_param_parsed_as_json(self):
        model = CliModel.from_dict(VECTOR_MODEL_DICT)
        factory = CommandFactory(model, endpoint_resolver=_mock_endpoint_resolver)
        groups = factory.create_groups()
        vector_group = groups["vector"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"id": 1, "distance": 0.9}]

            result = runner.invoke(
                vector_group,
                [
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "[[0.1, 0.2, 0.3]]",
                    "--output-fields",
                    '["id", "score"]',
                ],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["data"] == [[0.1, 0.2, 0.3]]
            assert body["outputFields"] == ["id", "score"]

    def test_array_param_invalid_json_error(self):
        model = CliModel.from_dict(VECTOR_MODEL_DICT)
        factory = CommandFactory(model, endpoint_resolver=_mock_endpoint_resolver)
        groups = factory.create_groups()
        vector_group = groups["vector"]

        runner = CliRunner()
        with patch("zilliz_cli.core.command_factory.APICaller"):
            result = runner.invoke(
                vector_group,
                [
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "not-json",
                ],
                obj={"api_key": "test-key", "output_format": "json", "config_dir": None},
            )

            assert result.exit_code != 0
            assert "json" in result.output.lower() or "JSON" in result.output


class TestSmartParamFetchersConfig:
    """Tests for smart parameter fetchers configuration."""

    def test_project_id_config_exists(self):
        """projectId should have smart prompt config."""
        assert "projectId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["projectId"]
        assert config["api"] == "GET /v2/projects"
        assert config["id_field"] == "projectId"
        assert config["name_field"] == "projectName"
        assert "plan" in config.get("extra_fields", [])

    def test_region_id_config_exists(self):
        """regionId should have smart prompt config."""
        assert "regionId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["regionId"]
        assert config["api"] == "GET /v2/regions"

    def test_cluster_id_config_exists(self):
        """clusterId should have smart prompt config."""
        assert "clusterId" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["clusterId"]
        assert config["api"] == "GET /v2/clusters"

    def test_cu_type_static_choices(self):
        """cuType should have static choices (no API)."""
        assert "cuType" in _SMART_PARAM_FETCHERS
        config = _SMART_PARAM_FETCHERS["cuType"]
        assert "choices" in config
        choices = config["choices"]
        assert len(choices) == 2
        # Check both options exist
        values = [c[1] for c in choices]
        assert "Performance-optimized" in values
        assert "Capacity-optimized" in values


class TestSmartPromptParam:
    """Tests for _smart_prompt_param function."""

    def test_returns_none_for_unknown_param(self):
        """Unknown parameters should return None."""
        param = Param(name="unknownParam", type="string", required=True, cli_name="--unknown")
        result = _smart_prompt_param(param, caller=None)
        assert result is None

    def test_returns_none_when_caller_is_none_for_api_param(self):
        """API-based params should return None when caller is None."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        result = _smart_prompt_param(param, caller=None)
        assert result is None

    def test_static_choices_work_without_caller(self):
        """Static choice params (cuType) should work without API caller."""
        param = Param(name="cuType", type="string", required=True, cli_name="--cu-type")
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.select.return_value.ask.return_value = "Performance-optimized"
            mock_q.Choice = MagicMock(side_effect=lambda title, value: {"title": title, "value": value})
            result = _smart_prompt_param(param, caller=None)
            assert result == "Performance-optimized"
            mock_q.select.assert_called_once()

    def test_api_param_fetches_and_presents_choices(self):
        """API-based params should fetch options and present selection."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-1", "projectName": "Project One", "plan": "Enterprise"},
                {"projectId": "proj-2", "projectName": "Project Two", "plan": "Standard"},
            ],
        }
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.select.return_value.ask.return_value = "proj-1"
            mock_q.Choice = MagicMock(side_effect=lambda title, value: {"title": title, "value": value})
            result = _smart_prompt_param(param, caller=mock_caller)
            assert result == "proj-1"
            mock_caller.call.assert_called_once_with("GET", "/v2/projects", return_raw=True)

    def test_auto_select_when_single_option(self):
        """When only one option exists, it should be auto-selected."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-only", "projectName": "Only Project", "plan": "Free"},
            ],
        }
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:
            mock_q.Choice = MagicMock(side_effect=lambda title, value: MagicMock(title=title, value=value))
            result = _smart_prompt_param(param, caller=mock_caller)
            assert result == "proj-only"
            # questionary.select should NOT be called for single option
            mock_q.select.assert_not_called()

    def test_returns_none_on_api_error(self):
        """API errors should return None (fallback to manual input)."""
        from zilliz_cli.core.exceptions import APIError

        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.side_effect = APIError(401, "Unauthorized")
        result = _smart_prompt_param(param, caller=mock_caller)
        assert result is None

    def test_returns_none_when_no_items(self):
        """Empty list should return None."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {"code": 0, "data": []}
        result = _smart_prompt_param(param, caller=mock_caller)
        assert result is None

    def test_extra_fields_displayed(self):
        """Extra fields (like plan) should be included in display."""
        param = Param(name="projectId", type="string", required=True, cli_name="--project-id")
        mock_caller = MagicMock()
        mock_caller.call.return_value = {
            "code": 0,
            "data": [
                {"projectId": "proj-1", "projectName": "My Project", "plan": "Enterprise"},
                {"projectId": "proj-2", "projectName": "Other", "plan": "Standard"},
            ],
        }
        captured_choices = []
        with patch("zilliz_cli.core.command_factory.questionary") as mock_q:

            def capture_choice(title, value):
                captured_choices.append(title)
                return MagicMock(title=title, value=value)

            mock_q.Choice = capture_choice
            mock_q.select.return_value.ask.return_value = "proj-1"
            _smart_prompt_param(param, caller=mock_caller)
            # Check that plan is included in the display
            assert any("Enterprise" in c for c in captured_choices)
            assert any("Standard" in c for c in captured_choices)
