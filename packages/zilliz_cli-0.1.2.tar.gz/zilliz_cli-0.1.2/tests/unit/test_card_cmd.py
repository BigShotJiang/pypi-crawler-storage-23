# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.cli import main


class TestCardBind:
    def setup_method(self):
        self.runner = CliRunner()

    def test_bind_success(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"cardId": "card_1234567890", "method": "insert"}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "billing",
                    "bind-card",
                    "--card-number",
                    "4242424242424242",
                    "--exp-month",
                    "12",
                    "--exp-year",
                    "2025",
                    "--cvc",
                    "123",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["cardId"] == "card_1234567890"
            assert data["method"] == "insert"

    def test_bind_replace_existing(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"cardId": "card_9876543210", "method": "replace"}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "billing",
                    "bind-card",
                    "--card-number",
                    "5555555555554444",
                    "--exp-month",
                    "6",
                    "--exp-year",
                    "2026",
                    "--cvc",
                    "456",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["method"] == "replace"

    def test_bind_missing_card_number(self, config_dir):
        result = self.runner.invoke(
            main,
            [
                "--api-key",
                "test-key",
                "billing",
                "bind-card",
                "--exp-month",
                "12",
                "--exp-year",
                "2025",
                "--cvc",
                "123",
            ],
            obj={"config_dir": config_dir},
        )

        assert result.exit_code != 0
        assert "card-number" in result.output.lower() or "required" in result.output.lower()

    def test_bind_missing_cvc(self, config_dir):
        result = self.runner.invoke(
            main,
            [
                "--api-key",
                "test-key",
                "billing",
                "bind-card",
                "--card-number",
                "4242424242424242",
                "--exp-month",
                "12",
                "--exp-year",
                "2025",
            ],
            obj={"config_dir": config_dir},
        )

        assert result.exit_code != 0
        assert "cvc" in result.output.lower() or "required" in result.output.lower()

    def test_bind_table_output(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"cardId": "card_1234567890", "method": "insert"}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "billing",
                    "bind-card",
                    "--card-number",
                    "4242424242424242",
                    "--exp-month",
                    "12",
                    "--exp-year",
                    "2025",
                    "--cvc",
                    "123",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "card_1234567890" in result.output

    def test_bind_api_call_parameters(self, config_dir):
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"cardId": "card_123", "method": "insert"}

            self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "billing",
                    "bind-card",
                    "--card-number",
                    "4242424242424242",
                    "--exp-month",
                    "12",
                    "--exp-year",
                    "2025",
                    "--cvc",
                    "123",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            mock_instance.call.assert_called_once()
            call_args = mock_instance.call.call_args
            assert call_args[0][0] == "POST"
            assert "/v2/card/bind" in call_args[0][1]
