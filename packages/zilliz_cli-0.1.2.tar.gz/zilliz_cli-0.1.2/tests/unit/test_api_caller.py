import json
from unittest.mock import MagicMock, patch

import httpx
import pytest

from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError


def _mock_response(status_code=200, json_data=None):
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.text = json.dumps(json_data or {})
    resp.headers = {}
    return resp


class TestAPICallerSuccess:
    def test_get_request(self):
        resp = _mock_response(200, {"code": 0, "data": [{"clusterId": "c1"}]})
        with patch.object(httpx.Client, "request", return_value=resp) as mock_req:
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call("GET", "/v2/clusters")

            assert result == [{"clusterId": "c1"}]
            mock_req.assert_called_once()
            call_kwargs = mock_req.call_args
            assert call_kwargs.kwargs["headers"]["Authorization"] == "Bearer test-key"

    def test_post_request_with_body(self):
        resp = _mock_response(200, {"code": 0, "data": {"clusterId": "new-1"}})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call(
                "POST", "/v2/clusters/createServerless", body={"clusterName": "test", "projectId": "p1"}
            )
            assert result["clusterId"] == "new-1"

    def test_path_param_substitution(self):
        resp = _mock_response(200, {"code": 0, "data": {"clusterId": "c1", "status": "RUNNING"}})
        with patch.object(httpx.Client, "request", return_value=resp) as mock_req:
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            caller.call("GET", "/v2/clusters/{clusterId}", path_params={"clusterId": "c1"})
            call_args = mock_req.call_args
            # url is the 2nd positional arg: client.request(method, url, ...)
            assert "/v2/clusters/c1" in call_args.args[1]

    def test_response_with_code_200(self):
        resp = _mock_response(200, {"code": 200, "data": {"clusterId": "c1"}})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="test-key", base_url="https://api.example.com")
            result = caller.call("GET", "/v2/clusters/c1")
            assert result["clusterId"] == "c1"


class TestAPICallerErrors:
    def test_api_error_nonzero_code(self):
        resp = _mock_response(200, {"code": 80001, "message": "Invalid API key"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="bad-key", base_url="https://api.example.com")
            with pytest.raises(APIError) as exc_info:
                caller.call("GET", "/v2/clusters")
            assert exc_info.value.code == 80001
            assert "Invalid API key" in exc_info.value.message

    def test_http_401_error(self):
        resp = _mock_response(401, {"code": 80001, "message": "Unauthorized"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="bad-key", base_url="https://api.example.com")
            with pytest.raises(APIError) as exc_info:
                caller.call("GET", "/v2/clusters")
            assert "API" in str(exc_info.value)

    def test_http_500_error(self):
        resp = _mock_response(500, {"code": 50000, "message": "Internal error"})
        with patch.object(httpx.Client, "request", return_value=resp):
            caller = APICaller(api_key="key", base_url="https://api.example.com")
            with pytest.raises(APIError):
                caller.call("GET", "/v2/clusters")

    def test_network_error(self):
        with patch.object(httpx.Client, "request", side_effect=httpx.ConnectError("Connection refused")):
            caller = APICaller(api_key="key", base_url="https://api.example.com")
            with pytest.raises(APIError, match="connect"):
                caller.call("GET", "/v2/clusters")
