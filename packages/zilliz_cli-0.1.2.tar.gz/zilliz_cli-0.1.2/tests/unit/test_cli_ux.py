# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Tests for CLI UX improvements: sections, --version, grouped options, model fields."""

from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.cli import main
from zilliz_cli.core.model import Param, Resource


class TestSectionGroup:
    def setup_method(self):
        self.runner = CliRunner()

    def test_help_has_cloud_management_section(self):
        result = self.runner.invoke(main, ["--help"])
        assert "Cloud Management:" in result.output

    def test_help_has_data_operations_section(self):
        result = self.runner.invoke(main, ["--help"])
        assert "Data Operations:" in result.output

    def test_help_has_configuration_section(self):
        result = self.runner.invoke(main, ["--help"])
        assert "Configuration:" in result.output

    def test_help_no_other_section(self):
        result = self.runner.invoke(main, ["--help"])
        assert "Other:" not in result.output

    def test_cluster_in_cloud_management(self):
        result = self.runner.invoke(main, ["--help"])
        lines = result.output.split("\n")
        cloud_idx = next(i for i, line in enumerate(lines) if "Cloud Management:" in line)
        data_idx = next(i for i, line in enumerate(lines) if "Data Operations:" in line)
        cluster_lines = lines[cloud_idx:data_idx]
        assert any("cluster" in line for line in cluster_lines)

    def test_collection_in_data_operations(self):
        result = self.runner.invoke(main, ["--help"])
        lines = result.output.split("\n")
        data_idx = next(i for i, line in enumerate(lines) if "Data Operations:" in line)
        config_idx = next(i for i, line in enumerate(lines) if "Configuration:" in line)
        data_lines = lines[data_idx:config_idx]
        assert any("collection" in line for line in data_lines)


class TestVersionFlag:
    def setup_method(self):
        self.runner = CliRunner()

    def test_version_flag(self):
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "zilliz" in result.output
        assert "0.1.0" in result.output

    def test_version_subcommand_still_works(self):
        result = self.runner.invoke(main, ["version"], obj={})
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_version_hidden_from_help(self):
        result = self.runner.invoke(main, ["--help"])
        assert "version     Show CLI version." not in result.output


class TestGroupedCommand:
    def setup_method(self):
        self.runner = CliRunner()

    def test_cluster_create_has_required_section(self):
        result = self.runner.invoke(main, ["cluster", "create", "--help"])
        assert "Required Options:" in result.output

    def test_cluster_create_has_options_section(self):
        result = self.runner.invoke(main, ["cluster", "create", "--help"])
        assert "Options:" in result.output

    def test_cluster_delete_has_required_section(self, config_dir):
        result = self.runner.invoke(main, ["cluster", "delete", "--help"])
        assert "Required Options:" in result.output
        assert "--cluster-id" in result.output


class TestClusterCreateDedicated:
    def setup_method(self):
        self.runner = CliRunner()

    def test_create_dedicated_cluster(self, config_dir):
        with patch("zilliz_cli.core.helpers.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"clusterId": "in01-ded"}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "cluster",
                    "create",
                    "--name",
                    "my-ded",
                    "--type",
                    "dedicated",
                    "--project-id",
                    "p1",
                    "--region",
                    "aws-us-west-2",
                    "--cu-type",
                    "Performance-optimized",
                    "--cu-size",
                    "1",
                    "-o",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            assert "in01-ded" in result.output
            call_args = mock_instance.call.call_args
            assert "/v2/clusters/createDedicated" in call_args[0][1]

    def test_create_dedicated_missing_cu_type(self, config_dir):
        result = self.runner.invoke(
            main,
            [
                "--api-key",
                "test-key",
                "cluster",
                "create",
                "--name",
                "my-ded",
                "--type",
                "dedicated",
                "--project-id",
                "p1",
                "--region",
                "aws-us-west-2",
            ],
            obj={"config_dir": config_dir},
        )
        assert result.exit_code != 0
        assert "cu-type" in result.output.lower()

    def test_create_missing_required(self, config_dir):
        result = self.runner.invoke(
            main,
            ["--api-key", "test-key", "cluster", "create", "--name", "x"],
            obj={"config_dir": config_dir},
        )
        assert result.exit_code != 0
        assert "Missing" in result.output or "missing" in result.output


class TestParamDescriptionAndChoices:
    def test_param_with_description(self):
        p = Param.from_dict(
            {
                "name": "clusterId",
                "type": "string",
                "description": "cluster ID",
                "choices": ["a", "b"],
            }
        )
        assert p.description == "cluster ID"
        assert p.choices == ["a", "b"]

    def test_param_without_description(self):
        p = Param.from_dict({"name": "foo", "type": "string"})
        assert p.description is None
        assert p.choices is None

    def test_resource_with_description(self):
        r = Resource.from_dict(
            {
                "description": "Manage clusters.",
                "operations": {},
            }
        )
        assert r.description == "Manage clusters."

    def test_resource_without_description(self):
        r = Resource.from_dict({"operations": {}})
        assert r.description is None


class TestCommandDescriptions:
    def setup_method(self):
        self.runner = CliRunner()

    def test_help_shows_resource_descriptions(self):
        result = self.runner.invoke(main, ["--help"])
        assert "Create, scale, and manage cloud clusters." in result.output
        assert "Create and manage projects." in result.output
        assert "View usage, invoices, and billing information." in result.output

    def test_cluster_describe_has_param_description(self):
        result = self.runner.invoke(main, ["cluster", "describe", "--help"])
        assert "cluster ID" in result.output

    def test_collection_create_shows_choices(self):
        result = self.runner.invoke(main, ["collection", "create", "--help"])
        assert "COSINE" in result.output
        assert "L2" in result.output
        assert "IP" in result.output

    def test_backup_create_shows_choices(self):
        result = self.runner.invoke(main, ["backup", "create", "--help"])
        assert "full" in result.output
        assert "incremental" in result.output
