# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.cli import main


class TestConfigureInteractive:
    def setup_method(self):
        self.runner = CliRunner()

    def test_interactive_configure(self, config_dir):
        with patch("zilliz_cli.auth.validation.validate_api_key"):
            result = self.runner.invoke(main, ["configure"], input="test-api-key-123\n", obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "configured" in result.output.lower()
        mgr = ConfigManager(config_dir)
        assert mgr.get_credential("api_key") == "test-api-key-123"


class TestConfigureSet:
    def setup_method(self):
        self.runner = CliRunner()

    def test_set_api_key(self, config_dir):
        with patch("zilliz_cli.auth.validation.validate_api_key"):
            result = self.runner.invoke(main, ["configure", "set", "api_key", "my-key"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        mgr = ConfigManager(config_dir)
        assert mgr.get_credential("api_key") == "my-key"

    def test_set_output(self, config_dir):
        result = self.runner.invoke(main, ["configure", "set", "output", "json"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        mgr = ConfigManager(config_dir)
        assert mgr.get_config("default", "output") == "json"


class TestConfigureGet:
    def setup_method(self):
        self.runner = CliRunner()

    def test_get_api_key(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "existing-key")
        result = self.runner.invoke(main, ["configure", "get", "api_key"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "api_key" in result.output
        assert "existing-key" not in result.output
        assert "****" in result.output

    def test_get_missing_key(self, config_dir):
        result = self.runner.invoke(main, ["configure", "get", "api_key"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "not set" in result.output.lower()


class TestConfigureList:
    def setup_method(self):
        self.runner = CliRunner()

    def test_list_all(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "my-key")
        mgr.set_config("default", "output", "json")
        result = self.runner.invoke(main, ["configure", "list"], obj={"config_dir": config_dir})
        assert result.exit_code == 0
        assert "api_key" in result.output
        assert "output" in result.output
