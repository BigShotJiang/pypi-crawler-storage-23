import json
from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.cli import main


def _setup_context(config_dir, cluster_id="in01-abc", endpoint="https://in01-abc.example.com", database="default"):
    mgr = ConfigManager(config_dir)
    mgr.set_context(cluster_id=cluster_id, endpoint=endpoint, database=database)


class TestVectorSearch:
    def setup_method(self):
        self.runner = CliRunner()

    def test_search_basic(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [
                {"id": 1, "distance": 0.95, "name": "doc1"},
                {"id": 2, "distance": 0.87, "name": "doc2"},
            ]

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "vector",
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "[[0.1, 0.2, 0.3]]",
                    "--limit",
                    "5",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert len(data) == 2

            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["collectionName"] == "my_col"
            assert body["data"] == [[0.1, 0.2, 0.3]]
            assert body["limit"] == 5

    def test_search_with_filter_and_output_fields(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [{"id": 1}]

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "vector",
                    "search",
                    "--collection",
                    "my_col",
                    "--data",
                    "[[0.1, 0.2]]",
                    "--filter",
                    "age > 20",
                    "--output-fields",
                    '["id", "name"]',
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["filter"] == "age > 20"
            assert body["outputFields"] == ["id", "name"]

    def test_search_no_context_error(self, config_dir):
        result = self.runner.invoke(
            main,
            ["--api-key", "test-key", "vector", "search", "--collection", "my_col", "--data", "[[0.1]]"],
            obj={"config_dir": config_dir},
        )

        assert result.exit_code != 0
        assert "context" in result.output.lower()


class TestVectorQuery:
    def setup_method(self):
        self.runner = CliRunner()

    def test_query_with_filter(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = [
                {"id": 1, "name": "doc1"},
                {"id": 2, "name": "doc2"},
            ]

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "vector",
                    "query",
                    "--collection",
                    "my_col",
                    "--filter",
                    "id in [1, 2]",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["collectionName"] == "my_col"
            assert body["filter"] == "id in [1, 2]"


class TestVectorInsert:
    def setup_method(self):
        self.runner = CliRunner()

    def test_insert_data(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {"insertCount": 2}

            data_json = json.dumps(
                [
                    {"id": 1, "vector": [0.1, 0.2], "name": "a"},
                    {"id": 2, "vector": [0.3, 0.4], "name": "b"},
                ]
            )

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "vector",
                    "insert",
                    "--collection",
                    "my_col",
                    "--data",
                    data_json,
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["collectionName"] == "my_col"
            assert len(body["data"]) == 2
