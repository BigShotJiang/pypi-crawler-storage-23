import json
from unittest.mock import patch

from click.testing import CliRunner

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.cli import main


def _setup_context(config_dir, cluster_id="in01-abc", endpoint="https://in01-abc.example.com", database="default"):
    mgr = ConfigManager(config_dir)
    mgr.set_context(cluster_id=cluster_id, endpoint=endpoint, database=database)


class TestCollectionList:
    def setup_method(self):
        self.runner = CliRunner()

    def test_collection_list_json(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = ["collection_a", "collection_b"]

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "collection", "list", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            MockCaller.assert_called_once_with(api_key="test-key", base_url="https://in01-abc.example.com")

    def test_collection_list_no_context_error(self, config_dir):
        result = self.runner.invoke(
            main, ["--api-key", "test-key", "collection", "list"], obj={"config_dir": config_dir}
        )

        assert result.exit_code != 0
        assert "context" in result.output.lower()


class TestCollectionDescribe:
    def setup_method(self):
        self.runner = CliRunner()

    def test_describe_collection(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {
                "collectionName": "my_col",
                "shardsNum": 1,
                "fields": [{"name": "id", "type": "Int64"}],
            }

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "collection", "describe", "--name", "my_col", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["collectionName"] == "my_col"


class TestCollectionCreate:
    def setup_method(self):
        self.runner = CliRunner()

    def test_create_quick_setup(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {}

            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "collection",
                    "create",
                    "--name",
                    "my_col",
                    "--dimension",
                    "768",
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["collectionName"] == "my_col"
            assert body["dimension"] == 768

    def test_create_custom_body(self, config_dir):
        _setup_context(config_dir)
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = {}

            body_json = json.dumps(
                {
                    "collectionName": "custom_col",
                    "schema": {"fields": [{"fieldName": "id", "dataType": "Int64", "isPrimary": True}]},
                }
            )

            # --name is still required by click; --body overrides the body payload
            result = self.runner.invoke(
                main,
                [
                    "--api-key",
                    "test-key",
                    "collection",
                    "create",
                    "--name",
                    "custom_col",
                    "--body",
                    body_json,
                    "--output",
                    "json",
                ],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["collectionName"] == "custom_col"
            assert "schema" in body


class TestCollectionDbNameInjection:
    def setup_method(self):
        self.runner = CliRunner()

    def test_dbname_from_context(self, config_dir):
        _setup_context(config_dir, database="mydb")
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = ["col_a"]

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "collection", "list", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body is not None
            assert body["dbName"] == "mydb"

    def test_explicit_database_overrides_context(self, config_dir):
        _setup_context(config_dir, database="mydb")
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = ["col_a"]

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "collection", "list", "--database", "other_db", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            assert body["dbName"] == "other_db"

    def test_default_database_not_injected(self, config_dir):
        """When context database is 'default', don't inject dbName (server default)."""
        _setup_context(config_dir, database="default")
        with patch("zilliz_cli.core.command_factory.APICaller") as MockCaller:
            mock_instance = MockCaller.return_value
            mock_instance.call.return_value = ["col_a"]

            result = self.runner.invoke(
                main,
                ["--api-key", "test-key", "collection", "list", "--output", "json"],
                obj={"config_dir": config_dir},
            )

            assert result.exit_code == 0
            call_args = mock_instance.call.call_args
            body = call_args.kwargs.get("body") or call_args[1].get("body")
            # dbName should not be in body when database is "default"
            assert body is None or "dbName" not in body
