import pytest

from zilliz_cli.auth.config import ConfigManager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.exceptions import CredentialError


class TestResolveApiKey:
    def test_cli_arg_highest_priority(self, config_dir):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "file-key")
        result = resolve_api_key(cli_api_key="cli-key", config_manager=mgr)
        assert result == "cli-key"

    def test_env_var_second_priority(self, config_dir, monkeypatch):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "file-key")
        monkeypatch.setenv("ZILLIZ_API_KEY", "env-key")
        result = resolve_api_key(cli_api_key=None, config_manager=mgr)
        assert result == "env-key"

    def test_file_fallback(self, config_dir, monkeypatch):
        mgr = ConfigManager(config_dir)
        mgr.set_credential("api_key", "file-key")
        monkeypatch.delenv("ZILLIZ_API_KEY", raising=False)
        result = resolve_api_key(cli_api_key=None, config_manager=mgr)
        assert result == "file-key"

    def test_no_credential_raises(self, config_dir, monkeypatch):
        mgr = ConfigManager(config_dir)
        monkeypatch.delenv("ZILLIZ_API_KEY", raising=False)
        with pytest.raises(CredentialError, match="configure"):
            resolve_api_key(cli_api_key=None, config_manager=mgr)
