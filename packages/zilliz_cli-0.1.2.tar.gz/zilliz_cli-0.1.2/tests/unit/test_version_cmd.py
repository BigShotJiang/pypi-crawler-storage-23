from click.testing import CliRunner

from zilliz_cli.cli import main


class TestVersionCommand:
    def setup_method(self):
        self.runner = CliRunner()

    def test_version_default(self):
        result = self.runner.invoke(main, ["version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_version_json(self):
        result = self.runner.invoke(main, ["version", "--output", "json"])
        assert result.exit_code == 0
        assert '"version"' in result.output
        assert "0.1.0" in result.output
