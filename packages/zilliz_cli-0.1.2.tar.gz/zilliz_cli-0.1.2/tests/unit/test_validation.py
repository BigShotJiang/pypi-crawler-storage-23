# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Tests for API key validation."""

from unittest.mock import MagicMock, patch

import click
import httpx
import pytest

from zilliz_cli.auth.validation import validate_api_key


class TestValidateApiKey:
    def test_valid_api_key(self):
        """Valid API key should pass validation."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"code": 0, "data": {"clusters": []}}

        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.return_value = mock_response
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                result = validate_api_key("valid-key", echo=False)
                assert result == {"code": 0, "data": {"clusters": []}}

    def test_invalid_api_key_401(self):
        """Invalid API key should raise ClickException."""
        mock_response = MagicMock()
        mock_response.status_code = 401

        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.return_value = mock_response
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                with pytest.raises(click.ClickException) as exc_info:
                    validate_api_key("invalid-key", echo=False)
                assert "Invalid API key" in str(exc_info.value)

    def test_invalid_api_key_by_code(self):
        """API key with error code in response should raise ClickException."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"code": 21119, "message": "The apikey is illegal"}

        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.return_value = mock_response
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                with pytest.raises(click.ClickException) as exc_info:
                    validate_api_key("bad-key", echo=False)
                assert "illegal" in str(exc_info.value).lower()

    def test_network_error(self):
        """Network errors should raise ClickException."""
        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.side_effect = httpx.RequestError("Connection failed")
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                with pytest.raises(click.ClickException) as exc_info:
                    validate_api_key("any-key", echo=False)
                assert "Network error" in str(exc_info.value)

    def test_timeout_error(self):
        """Timeout errors should raise ClickException."""
        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.side_effect = httpx.TimeoutException("Timeout")
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                with pytest.raises(click.ClickException) as exc_info:
                    validate_api_key("any-key", echo=False)
                assert "timed out" in str(exc_info.value).lower()

    def test_invalid_json_response(self):
        """Invalid JSON response should raise ClickException."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.side_effect = ValueError("Invalid JSON")

        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.return_value = mock_response
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.return_value.endpoint = "https://api.example.com"
                with pytest.raises(click.ClickException) as exc_info:
                    validate_api_key("any-key", echo=False)
                assert "Invalid response" in str(exc_info.value)

    def test_fallback_to_default_endpoint(self):
        """Should use default endpoint when model loading fails."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"code": 0, "data": {}}

        with patch("httpx.Client") as mock_client:
            mock_client.return_value.__enter__.return_value.get.return_value = mock_response
            with patch("zilliz_cli.core.model_loader.ModelLoader") as mock_loader:
                mock_loader.return_value.load.side_effect = FileNotFoundError()
                validate_api_key("valid-key", echo=False)
                # Verify default endpoint was used
                call_args = mock_client.return_value.__enter__.return_value.get.call_args
                assert "api.cloud.zilliz.com" in call_args[0][0]
