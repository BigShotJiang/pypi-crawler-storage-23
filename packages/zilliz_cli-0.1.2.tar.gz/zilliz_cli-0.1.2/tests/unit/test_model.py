from zilliz_cli.core.model import CliModel, Operation, Param, Resource

SAMPLE_MODEL_DICT = {
    "version": "2026-01-26",
    "minCliVersion": "0.1.0",
    "endpoint": "https://api.cloud.zilliz.com",
    "resources": {
        "cluster": {
            "operations": {
                "list": {
                    "http": {"method": "GET", "path": "/v2/clusters"},
                    "params": [],
                    "output": {"dataField": "data"},
                },
                "describe": {
                    "http": {"method": "GET", "path": "/v2/clusters/{clusterId}"},
                    "params": [
                        {
                            "name": "clusterId",
                            "type": "string",
                            "required": True,
                            "cli": "--cluster-id",
                            "position": "path",
                        }
                    ],
                },
                "create": {
                    "http": {"method": "POST", "path": "/v2/clusters/createServerless"},
                    "params": [
                        {"name": "clusterName", "type": "string", "required": True, "cli": "--name"},
                        {"name": "projectId", "type": "string", "required": True, "cli": "--project-id"},
                        {"name": "regionId", "type": "string", "required": True, "cli": "--region"},
                    ],
                },
            }
        }
    },
}


class TestCliModel:
    def test_parse_from_dict(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        assert model.version == "2026-01-26"
        assert model.endpoint == "https://api.cloud.zilliz.com"
        assert "cluster" in model.resources

    def test_resource_operations(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        cluster = model.resources["cluster"]
        assert isinstance(cluster, Resource)
        assert "list" in cluster.operations
        assert "describe" in cluster.operations
        assert "create" in cluster.operations

    def test_operation_http(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        list_op = model.resources["cluster"].operations["list"]
        assert isinstance(list_op, Operation)
        assert list_op.method == "GET"
        assert list_op.path == "/v2/clusters"

    def test_operation_params(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        describe_op = model.resources["cluster"].operations["describe"]
        assert len(describe_op.params) == 1
        p = describe_op.params[0]
        assert isinstance(p, Param)
        assert p.name == "clusterId"
        assert p.type == "string"
        assert p.required is True
        assert p.cli_name == "--cluster-id"
        assert p.position == "path"

    def test_param_defaults(self):
        model = CliModel.from_dict(SAMPLE_MODEL_DICT)
        create_op = model.resources["cluster"].operations["create"]
        p = create_op.params[0]
        assert p.position is None
        assert p.default is None

    def test_operation_body_param(self):
        model_dict = {
            "version": "1",
            "resources": {
                "collection": {
                    "operations": {
                        "create": {
                            "http": {"method": "POST", "path": "/v2/vectordb/collections/create"},
                            "params": [{"name": "collectionName", "type": "string", "required": True, "cli": "--name"}],
                            "bodyParam": "--body",
                        }
                    }
                }
            },
        }
        model = CliModel.from_dict(model_dict)
        op = model.resources["collection"].operations["create"]
        assert op.body_param == "--body"
