import json
import os
import secrets
import subprocess
import time

import pytest

RESOURCE_PREFIX = "zilliz-cli-test-"
COLLECTION_PREFIX = "zilliz_cli_test_"
POLL_INTERVAL = 15
CLUSTER_TIMEOUT = 900  # 15 minutes (Dedicated clusters take longer to provision)
TEARDOWN_RETRIES = 5
TEARDOWN_RETRY_INTERVAL = 10


def _log(msg):
    """Print progress log visible with pytest -s."""
    print(f"\n  [acceptance] {msg}", flush=True)


def _run_cli(*args, config_dir=None, log=True):
    """Run zilliz CLI as subprocess."""
    env = os.environ.copy()
    if config_dir:
        env["ZILLIZ_CONFIG_DIR"] = str(config_dir)
    if log:
        _log_cmd(args)
    result = subprocess.run(
        ["zilliz", *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=60,
    )
    if log:
        _log_result(result)
    return result


def _log_cmd(args):
    """Log the CLI command being executed."""
    # Truncate long args (e.g. JSON data) for readability
    display_args = []
    for a in args:
        if len(str(a)) > 80:
            display_args.append(str(a)[:77] + "...")
        else:
            display_args.append(str(a))
    print(f"  $ zilliz {' '.join(display_args)}", flush=True)


def _log_result(result):
    """Log command result: status and abbreviated output."""
    status = "OK" if result.returncode == 0 else f"FAIL(rc={result.returncode})"
    output = result.stdout.strip()
    if len(output) > 200:
        output = output[:197] + "..."
    if output:
        print(f"    -> {status}: {output}", flush=True)
    else:
        print(f"    -> {status}", flush=True)


@pytest.fixture(scope="session")
def api_key():
    """Gate: skip all acceptance tests if no API key."""
    key = os.environ.get("ZILLIZ_API_KEY")
    if not key:
        pytest.skip("ZILLIZ_API_KEY required for acceptance tests")
    return key


@pytest.fixture(scope="session")
def session_config_dir(tmp_path_factory):
    """Shared config directory for the entire test session."""
    return tmp_path_factory.mktemp("zilliz_config")


@pytest.fixture(scope="session")
def run_cli_session(session_config_dir):
    """Session-scoped CLI runner with shared config directory."""

    def _run(*args):
        return _run_cli(*args, config_dir=session_config_dir)

    return _run


@pytest.fixture
def run_cli(session_config_dir):
    """Function-scoped CLI runner (uses session config dir for context sharing)."""

    def _run(*args):
        return _run_cli(*args, config_dir=session_config_dir)

    return _run


@pytest.fixture(scope="session")
def cloud_info(api_key, run_cli_session):
    """Auto-discover project_id, region, cuType from existing Dedicated cluster."""
    _log("Discovering project, region, and cuType from existing clusters...")
    result = run_cli_session("cluster", "list", "--all", "-o", "json")
    assert result.returncode == 0, f"cluster list failed: {result.stderr}"
    clusters = json.loads(result.stdout)

    if not clusters:
        pytest.skip("No existing clusters found to discover project/region")

    # Find a running Dedicated cluster to determine region and cuType
    dedicated = None
    for c in clusters:
        if c.get("plan") != "Serverless" and c.get("status") == "RUNNING":
            dedicated = c
            break

    if not dedicated:
        pytest.skip(
            "No running Dedicated cluster found. A Dedicated cluster is required "
            "to determine region and cuType for test cluster creation."
        )

    info = {
        "project_id": dedicated["projectId"],
        "region": dedicated["regionId"],
        "existing_cluster_id": dedicated["clusterId"],
        "cu_type": dedicated.get("cuType", "Performance-optimized"),
    }
    _log(
        f"Discovered project={info['project_id']}, region={info['region']}, "
        f"cu_type={info['cu_type']}, reference_cluster={info['existing_cluster_id']}"
    )
    return info


@pytest.fixture(scope="session")
def test_cluster(api_key, cloud_info, run_cli_session):
    """Create a Dedicated cluster, wait until RUNNING, yield its ID, then delete."""
    name = f"{RESOURCE_PREFIX}{secrets.token_hex(4)}"

    # Create Dedicated cluster
    _log(f"Creating Dedicated cluster '{name}' in {cloud_info['region']} (cuType={cloud_info['cu_type']}, cuSize=1)...")
    result = run_cli_session(
        "cluster",
        "create-dedicated",
        "--name",
        name,
        "--project-id",
        cloud_info["project_id"],
        "--region",
        cloud_info["region"],
        "--cu-type",
        cloud_info["cu_type"],
        "--cu-size",
        "1",
        "-o",
        "json",
    )
    assert result.returncode == 0, f"cluster create-dedicated failed: {result.stderr}"
    data = json.loads(result.stdout)
    cluster_id = data["clusterId"]
    _log(f"Dedicated cluster created: {cluster_id}")

    # Poll until RUNNING
    _log(f"Waiting for cluster to reach RUNNING (timeout {CLUSTER_TIMEOUT}s)...")
    deadline = time.time() + CLUSTER_TIMEOUT
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        desc = run_cli_session("cluster", "describe", "--cluster-id", cluster_id, "-o", "json")
        if desc.returncode == 0:
            info = json.loads(desc.stdout)
            status = info.get("status", "UNKNOWN")
            elapsed = int(time.time() - (deadline - CLUSTER_TIMEOUT))
            _log(f"  Poll #{attempt}: status={status} ({elapsed}s elapsed)")
            if status == "RUNNING":
                break
        time.sleep(POLL_INTERVAL)
    else:
        # Timeout - still try to clean up with retry
        _log(f"TIMEOUT: Cluster did not reach RUNNING. Deleting {cluster_id}...")
        for retry in range(1, TEARDOWN_RETRIES + 1):
            r = run_cli_session("cluster", "delete", "--cluster-id", cluster_id)
            if r.returncode == 0:
                break
            _log(f"ERROR: Timeout cleanup attempt {retry}/{TEARDOWN_RETRIES} failed: {r.stderr or r.stdout}")
            if retry < TEARDOWN_RETRIES:
                time.sleep(TEARDOWN_RETRY_INTERVAL)
        else:
            _log(f"RESOURCE LEAK: Failed to delete timed-out cluster {cluster_id}. Manual cleanup required.")
        pytest.fail(f"Cluster {cluster_id} did not reach RUNNING within {CLUSTER_TIMEOUT}s")

    _log(f"Cluster {cluster_id} is RUNNING")
    yield cluster_id

    # Teardown: delete cluster with retry
    _log(f"Deleting cluster {cluster_id}...")
    for attempt in range(1, TEARDOWN_RETRIES + 1):
        delete_result = run_cli_session("cluster", "delete", "--cluster-id", cluster_id)
        if delete_result.returncode == 0:
            _log(f"Cluster {cluster_id} deleted")
            break
        output = delete_result.stderr or delete_result.stdout
        _log(f"ERROR: Delete cluster attempt {attempt}/{TEARDOWN_RETRIES} failed: {output}")
        if attempt < TEARDOWN_RETRIES:
            _log(f"Retrying in {TEARDOWN_RETRY_INTERVAL}s...")
            time.sleep(TEARDOWN_RETRY_INTERVAL)
    else:
        pytest.fail(
            f"RESOURCE LEAK: Failed to delete cluster {cluster_id} "
            f"after {TEARDOWN_RETRIES} attempts. Manual cleanup required."
        )


@pytest.fixture(scope="session")
def test_context(test_cluster, run_cli_session):
    """Set cluster context with auto-resolved endpoint."""
    _log(f"Setting context for cluster {test_cluster}...")
    result = run_cli_session("context", "set", "--cluster-id", test_cluster)
    assert result.returncode == 0, f"context set failed: {result.stderr}"
    _log(f"Context set: {result.stdout.strip()}")
    return test_cluster


@pytest.fixture(scope="session")
def test_collection(test_context, run_cli_session):
    """Create a test collection, yield its name, then drop."""
    name = f"{COLLECTION_PREFIX}{secrets.token_hex(4)}"

    _log(f"Creating collection '{name}' (dim=4, COSINE, autoID=true)...")
    result = run_cli_session(
        "collection",
        "create",
        "--name",
        name,
        "--dimension",
        "4",
        "--metric-type",
        "COSINE",
        "--auto-id",
        "true",
        "-o",
        "json",
    )
    assert result.returncode == 0, f"collection create failed: {result.stderr}"
    _log(f"Collection '{name}' created")

    yield name

    # Teardown: drop aliases first, then drop collection with retry
    _log(f"Dropping collection '{name}'...")
    desc = run_cli_session("collection", "describe", "--name", name, "-o", "json")
    if desc.returncode == 0:
        try:
            info = json.loads(desc.stdout)
            for alias in info.get("aliases", []):
                _log(f"Dropping alias '{alias}' before collection drop...")
                run_cli_session("alias", "drop", "--alias", alias)
        except (json.JSONDecodeError, KeyError):
            pass

    for attempt in range(1, TEARDOWN_RETRIES + 1):
        drop_result = run_cli_session("collection", "drop", "--name", name)
        if drop_result.returncode == 0:
            _log(f"Collection '{name}' dropped")
            break
        output = drop_result.stderr or drop_result.stdout
        _log(f"ERROR: Drop collection attempt {attempt}/{TEARDOWN_RETRIES} failed: {output}")
        if attempt < TEARDOWN_RETRIES:
            _log(f"Retrying in {TEARDOWN_RETRY_INTERVAL}s...")
            time.sleep(TEARDOWN_RETRY_INTERVAL)
    else:
        pytest.fail(
            f"RESOURCE LEAK: Failed to drop collection {name} "
            f"after {TEARDOWN_RETRIES} attempts. Manual cleanup required."
        )
