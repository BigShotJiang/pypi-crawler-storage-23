import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestBackupList:
    """Test backup list (GET /v2/backups) - read-only."""

    def test_backup_list_json(self, run_cli, api_key):
        result = run_cli("backup", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        # Response may contain 'backups' key (paginated) or be a list
        if isinstance(data, dict):
            assert "backups" in data or "count" in data
            count = data.get("count", 0)
            _log(f"Backups: count={count}")
        else:
            _log(f"Backups: {len(data)} items")

    def test_backup_list_by_project(self, run_cli, cloud_info):
        result = run_cli(
            "backup",
            "list",
            "--project-id",
            cloud_info["project_id"],
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Backups for project {cloud_info['project_id']}: OK")


@pytest.mark.acceptance
class TestBackupPolicy:
    """Test backup get-policy (GET) - read-only, requires a Dedicated cluster."""

    def test_get_policy(self, run_cli, cloud_info):
        cluster_id = cloud_info.get("dedicated_cluster_id")
        if not cluster_id:
            pytest.skip("No Dedicated cluster available for backup policy test")
        result = run_cli(
            "backup",
            "get-policy",
            "--cluster-id",
            cluster_id,
            "-o",
            "json",
        )
        assert result.returncode == 0, f"backup get-policy failed: {result.stdout}"
        data = json.loads(result.stdout)
        _log(f"Backup policy for {cluster_id}: enabled={data.get('enabled')}, frequency={data.get('frequency')}")
