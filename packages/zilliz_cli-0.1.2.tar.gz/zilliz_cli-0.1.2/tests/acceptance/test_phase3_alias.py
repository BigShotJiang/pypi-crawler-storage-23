import json
import secrets

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestAliasLifecycle:
    """Test alias create -> list -> describe -> alter -> drop lifecycle."""

    def test_alias_lifecycle(self, run_cli, test_collection):
        alias_name = f"test_alias_{secrets.token_hex(4)}"

        # Create
        result = run_cli(
            "alias",
            "create",
            "--collection",
            test_collection,
            "--alias",
            alias_name,
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Created alias '{alias_name}' -> '{test_collection}'")

        try:
            # List
            result = run_cli(
                "alias",
                "list",
                "--database",
                "default",
                "-o",
                "json",
            )
            assert result.returncode == 0
            data = json.loads(result.stdout)
            assert isinstance(data, list)
            _log(f"Aliases: {data}")

            # Describe
            result = run_cli(
                "alias",
                "describe",
                "--alias",
                alias_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            data = json.loads(result.stdout)
            _log(f"Alias '{alias_name}': collection={data.get('collectionName', data.get('collection'))}")

            # Alter (re-point to same collection - just testing the command works)
            result = run_cli(
                "alias",
                "alter",
                "--collection",
                test_collection,
                "--alias",
                alias_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Altered alias '{alias_name}' -> '{test_collection}'")
        finally:
            # Always clean up: drop alias
            drop_result = run_cli(
                "alias",
                "drop",
                "--alias",
                alias_name,
                "-o",
                "json",
            )
            if drop_result.returncode == 0:
                _log(f"Dropped alias '{alias_name}'")
            else:
                _log(f"WARNING: Failed to drop alias '{alias_name}': {drop_result.stdout}")
