import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestRegionListProviders:
    """Test region list-providers (GET /v2/clouds)."""

    def test_list_providers_json(self, run_cli, api_key):
        result = run_cli("region", "list-providers", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 0
        provider_ids = [p.get("cloudId") for p in data]
        _log(f"Cloud providers: {provider_ids}")

    def test_list_providers_table(self, run_cli, api_key):
        result = run_cli("region", "list-providers", "-o", "table")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0


@pytest.mark.acceptance
class TestRegionList:
    """Test region list (GET /v2/regions)."""

    def test_list_all_regions(self, run_cli, api_key):
        result = run_cli("region", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 0
        _log(f"Total regions: {len(data)}")

    def test_list_regions_by_cloud(self, run_cli, api_key):
        result = run_cli("region", "list", "--cloud-id", "gcp", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        _log(f"GCP regions: {len(data)}")
