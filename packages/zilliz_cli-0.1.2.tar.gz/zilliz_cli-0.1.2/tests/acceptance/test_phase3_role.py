import json
import secrets

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestRoleLifecycle:
    """Test role create -> list -> describe -> grant-privilege -> revoke-privilege -> drop."""

    def test_role_lifecycle(self, run_cli, test_context):
        role_name = f"cli_test_role_{secrets.token_hex(4)}"

        # Create
        result = run_cli(
            "role",
            "create",
            "--name",
            role_name,
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Created role '{role_name}'")

        try:
            # List
            result = run_cli("role", "list", "-o", "json")
            assert result.returncode == 0
            data = json.loads(result.stdout)
            assert isinstance(data, list)
            assert role_name in data or role_name in str(data)
            _log(f"Roles: {data}")

            # Describe
            result = run_cli(
                "role",
                "describe",
                "--name",
                role_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Described role '{role_name}'")

            # Grant privilege
            result = run_cli(
                "role",
                "grant-privilege",
                "--name",
                role_name,
                "--object-type",
                "Collection",
                "--object-name",
                "*",
                "--privilege",
                "Search",
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Granted Search privilege on Collection.* to role '{role_name}'")

            # Verify privilege in describe
            result = run_cli(
                "role",
                "describe",
                "--name",
                role_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Role privileges after grant: {json.loads(result.stdout)}")

            # Revoke privilege
            result = run_cli(
                "role",
                "revoke-privilege",
                "--name",
                role_name,
                "--object-type",
                "Collection",
                "--object-name",
                "*",
                "--privilege",
                "Search",
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Revoked Search privilege from role '{role_name}'")
        finally:
            # Always clean up: drop role
            drop_result = run_cli(
                "role",
                "drop",
                "--name",
                role_name,
                "-o",
                "json",
            )
            if drop_result.returncode == 0:
                _log(f"Dropped role '{role_name}'")
            else:
                _log(f"WARNING: Failed to drop role '{role_name}': {drop_result.stdout}")
