import json
import secrets

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestUserLifecycle:
    """Test user create -> list -> describe -> grant-role -> revoke-role -> drop."""

    def test_user_lifecycle(self, run_cli, test_context):
        user_name = f"cli_test_{secrets.token_hex(4)}"
        password = f"Test_{secrets.token_hex(8)}!"

        # Create
        result = run_cli(
            "user",
            "create",
            "--name",
            user_name,
            "--password",
            password,
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Created user '{user_name}'")

        try:
            # List
            result = run_cli("user", "list", "-o", "json")
            assert result.returncode == 0
            data = json.loads(result.stdout)
            assert isinstance(data, list)
            assert user_name in data or user_name in str(data)
            _log(f"Users: {data}")

            # Describe
            result = run_cli(
                "user",
                "describe",
                "--name",
                user_name,
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Described user '{user_name}'")

            # Update password
            new_password = f"New_{secrets.token_hex(8)}!"
            result = run_cli(
                "user",
                "update-password",
                "--name",
                user_name,
                "--password",
                password,
                "--new-password",
                new_password,
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Updated password for user '{user_name}'")

            # Grant role (use built-in 'db_ro' role)
            result = run_cli(
                "user",
                "grant-role",
                "--name",
                user_name,
                "--role",
                "db_ro",
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Granted role 'db_ro' to user '{user_name}'")

            # Revoke role
            result = run_cli(
                "user",
                "revoke-role",
                "--name",
                user_name,
                "--role",
                "db_ro",
                "-o",
                "json",
            )
            assert result.returncode == 0
            _log(f"Revoked role 'db_ro' from user '{user_name}'")
        finally:
            # Always clean up: drop user
            drop_result = run_cli(
                "user",
                "drop",
                "--name",
                user_name,
                "-o",
                "json",
            )
            if drop_result.returncode == 0:
                _log(f"Dropped user '{user_name}'")
            else:
                _log(f"WARNING: Failed to drop user '{user_name}': {drop_result.stdout}")
