import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestClusterList:
    """Test cluster list with various output formats and pagination."""

    def test_cluster_list_json(self, run_cli, api_key):
        result = run_cli("cluster", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert "count" in data
        assert "clusters" in data
        assert isinstance(data["clusters"], list)
        _log(f"Listed {data['count']} clusters (page returned {len(data['clusters'])})")

    def test_cluster_list_table(self, run_cli, api_key):
        result = run_cli("cluster", "list", "-o", "table")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0

    def test_cluster_list_text(self, run_cli, api_key):
        result = run_cli("cluster", "list", "-o", "text")
        assert result.returncode == 0
        assert len(result.stdout.strip()) > 0

    def test_cluster_list_all(self, run_cli, api_key):
        result = run_cli("cluster", "list", "--all", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 0
        _log(f"Listed ALL {len(data)} clusters")

    def test_cluster_list_pagination(self, run_cli, api_key):
        result = run_cli("cluster", "list", "--page-size", "5", "--page", "1", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["pageSize"] == 5
        assert data["currentPage"] == 1
        assert len(data["clusters"]) <= 5
        _log(f"Page 1: {len(data['clusters'])} clusters (pageSize=5, total={data.get('count', '?')})")


@pytest.mark.acceptance
class TestClusterDescribe:
    """Test cluster describe using existing cluster from cloud_info."""

    def test_cluster_describe_json(self, run_cli, cloud_info):
        cluster_id = cloud_info["existing_cluster_id"]
        result = run_cli("cluster", "describe", "--cluster-id", cluster_id, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["clusterId"] == cluster_id
        assert "status" in data
        assert "connectAddress" in data
        _log(f"Cluster {cluster_id}: name={data['clusterName']}, status={data['status']}, plan={data.get('plan')}")

    def test_cluster_describe_table(self, run_cli, cloud_info):
        cluster_id = cloud_info["existing_cluster_id"]
        result = run_cli("cluster", "describe", "--cluster-id", cluster_id, "-o", "table")
        assert result.returncode == 0
        assert cluster_id in result.stdout


@pytest.mark.acceptance
class TestClusterLifecycle:
    """Verify cluster create and delete via the test_cluster fixture."""

    def test_cluster_create_returned_valid_id(self, run_cli, test_cluster):
        # test_cluster fixture already created the cluster and waited for RUNNING
        assert test_cluster.startswith("in")
        _log(f"Test cluster ID: {test_cluster}")

    def test_cluster_describe_after_create(self, run_cli, test_cluster):
        result = run_cli("cluster", "describe", "--cluster-id", test_cluster, "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert data["status"] == "RUNNING"
        assert data["clusterName"].startswith("zilliz-cli-test-")
        _log(
            f"Test cluster: name={data['clusterName']}, region={data.get('regionId')}, endpoint={data.get('connectAddress', '?')[:60]}"
        )
