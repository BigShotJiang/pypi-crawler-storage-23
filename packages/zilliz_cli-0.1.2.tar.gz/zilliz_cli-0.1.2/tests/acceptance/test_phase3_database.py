import json
import secrets

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestDatabaseLifecycle:
    """Test database create -> list -> describe -> drop lifecycle."""

    def test_database_list(self, run_cli, test_context):
        result = run_cli("database", "list", "-o", "json")
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "default" in data
        _log(f"Databases: {data}")

    def test_database_create_describe_drop(self, run_cli, test_context):
        db_name = f"cli_test_db_{secrets.token_hex(4)}"

        # Create
        result = run_cli("database", "create", "--name", db_name, "-o", "json")
        assert result.returncode == 0
        _log(f"Created database '{db_name}'")

        try:
            # Describe
            result = run_cli("database", "describe", "--name", db_name, "-o", "json")
            assert result.returncode == 0
            data = json.loads(result.stdout)
            _log(f"Database '{db_name}' details: {data}")
        finally:
            # Always clean up: drop database
            drop_result = run_cli("database", "drop", "--name", db_name, "-o", "json")
            if drop_result.returncode == 0:
                _log(f"Dropped database '{db_name}'")
            else:
                _log(f"WARNING: Failed to drop database '{db_name}': {drop_result.stdout}")
