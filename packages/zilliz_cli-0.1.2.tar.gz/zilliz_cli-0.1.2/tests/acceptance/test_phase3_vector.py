import json

import pytest

from tests.acceptance.conftest import _log


@pytest.mark.acceptance
class TestVectorOps:
    """Test vector insert -> search -> query on the test_collection fixture."""

    def test_vector_insert(self, run_cli, test_collection):
        data = json.dumps(
            [
                {"vector": [0.1, 0.2, 0.3, 0.4]},
                {"vector": [0.5, 0.6, 0.7, 0.8]},
                {"vector": [0.9, 1.0, 0.1, 0.2]},
            ]
        )
        result = run_cli(
            "vector",
            "insert",
            "--collection",
            test_collection,
            "--data",
            data,
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert resp.get("insertCount") == 3
        _log(f"Inserted {resp.get('insertCount')} vectors into '{test_collection}', IDs: {resp.get('ids', [])}")

    def test_vector_search_basic(self, run_cli, test_collection):
        data = json.dumps([[0.1, 0.2, 0.3, 0.4]])
        result = run_cli(
            "vector",
            "search",
            "--collection",
            test_collection,
            "--data",
            data,
            "--limit",
            "5",
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert isinstance(resp, list)
        _log(f"Search in '{test_collection}': query=[0.1,0.2,0.3,0.4], limit=5, returned {len(resp)} result groups")
        if resp and isinstance(resp[0], list):
            _log(
                f"  Top results: {[{k: round(v, 4) if isinstance(v, float) else v for k, v in hit.items()} for hit in resp[0][:3]]}"
            )

    def test_vector_search_with_filter(self, run_cli, test_collection):
        data = json.dumps([[0.1, 0.2, 0.3, 0.4]])
        result = run_cli(
            "vector",
            "search",
            "--collection",
            test_collection,
            "--data",
            data,
            "--limit",
            "3",
            "--filter",
            "id >= 0",
            "--output-fields",
            '["vector"]',
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert isinstance(resp, list)
        _log(f"Search with filter='id >= 0', outputFields=['vector']: returned {len(resp)} result groups")
        if resp and isinstance(resp[0], list) and resp[0]:
            first_hit = resp[0][0]
            _log(
                f"  First hit: id={first_hit.get('id')}, distance={first_hit.get('distance')}, "
                f"has_vector={'vector' in first_hit}"
            )

    def test_vector_query_basic(self, run_cli, test_collection):
        result = run_cli(
            "vector",
            "query",
            "--collection",
            test_collection,
            "--filter",
            "id >= 0",
            "--limit",
            "10",
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert isinstance(resp, list)
        _log(f"Query filter='id >= 0', limit=10: returned {len(resp)} entities")
        if resp:
            _log(f"  First entity keys: {list(resp[0].keys())}")

    def test_vector_query_output_fields(self, run_cli, test_collection):
        result = run_cli(
            "vector",
            "query",
            "--collection",
            test_collection,
            "--filter",
            "id >= 0",
            "--output-fields",
            '["vector"]',
            "--limit",
            "3",
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert isinstance(resp, list)
        _log(f"Query with outputFields=['vector'], limit=3: returned {len(resp)} entities")
        if resp:
            _log(f"  First entity: {resp[0]}")


@pytest.mark.acceptance
class TestVectorNewOps:
    """Test new vector operations: upsert, get, delete.

    Note: upsert requires the id field. For autoId collections the server
    rejects rows without an explicit id, so we supply the id ourselves.
    """

    def test_vector_upsert(self, run_cli, test_collection):
        # autoId collection: upsert still requires explicit id
        data = json.dumps(
            [
                {"id": 90001, "vector": [0.2, 0.3, 0.4, 0.5]},
                {"id": 90002, "vector": [0.6, 0.7, 0.8, 0.9]},
            ]
        )
        result = run_cli(
            "vector",
            "upsert",
            "--collection",
            test_collection,
            "--data",
            data,
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        count = resp.get("upsertCount", resp.get("insertCount", 0))
        assert count == 2
        _log(f"Upserted 2 vectors into '{test_collection}'")

    def test_vector_get(self, run_cli, test_collection):
        # First insert a vector to know an ID
        data = json.dumps([{"vector": [0.11, 0.22, 0.33, 0.44]}])
        insert_result = run_cli(
            "vector",
            "insert",
            "--collection",
            test_collection,
            "--data",
            data,
            "-o",
            "json",
        )
        assert insert_result.returncode == 0
        insert_resp = json.loads(insert_result.stdout)
        # Response uses "insertIds" (not "ids")
        ids = insert_resp.get("insertIds", insert_resp.get("ids", []))
        assert len(ids) > 0

        # Get by ID
        result = run_cli(
            "vector",
            "get",
            "--collection",
            test_collection,
            "--id",
            json.dumps(ids[:1]),
            "-o",
            "json",
        )
        assert result.returncode == 0
        resp = json.loads(result.stdout)
        assert isinstance(resp, list)
        _log(f"Got vector by ID {ids[0]}: {len(resp)} result(s)")

    def test_vector_delete(self, run_cli, test_collection):
        # Insert vectors to delete
        data = json.dumps([{"vector": [0.99, 0.88, 0.77, 0.66]}])
        insert_result = run_cli(
            "vector",
            "insert",
            "--collection",
            test_collection,
            "--data",
            data,
            "-o",
            "json",
        )
        assert insert_result.returncode == 0

        # Delete by filter
        result = run_cli(
            "vector",
            "delete",
            "--collection",
            test_collection,
            "--filter",
            "id >= 0",
            "-o",
            "json",
        )
        assert result.returncode == 0
        _log(f"Deleted vectors from '{test_collection}' with filter 'id >= 0'")
