# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import click
from rich.console import Console

from zilliz_cli.core.command_factory import GroupedCommand
from zilliz_cli.core.exceptions import APIError
from zilliz_cli.core.helpers import build_caller
from zilliz_cli.formatter.base import get_formatter

_CLUSTER_TYPE_PATHS = {
    "serverless": "/v2/clusters/createServerless",
    "free": "/v2/clusters/createFree",
    "dedicated": "/v2/clusters/createDedicated",
}

_REQUIRED_OPTIONS = {"--name", "--type", "--project-id", "--region"}


_CREATE_EPILOG = """\b
Examples:
  Dedicated cluster:
    zilliz cluster create --name my-cluster --type dedicated --project-id proj-xxxx --region aws-us-west-2 --cu-type Performance-optimized --cu-size 1

  Serverless cluster:
    zilliz cluster create --name my-cluster --type serverless --project-id proj-xxxx --region aws-us-west-2

  Free-tier cluster:
    zilliz cluster create --name my-cluster --type free --project-id proj-xxxx --region gcp-us-west1"""


@click.command(name="create", cls=GroupedCommand, epilog=_CREATE_EPILOG)
@click.option("--name", help="cluster display name")
@click.option(
    "--type",
    "cluster_type",
    type=click.Choice(["serverless", "free", "dedicated"], case_sensitive=False),
    metavar="[serverless|free|dedicated]",
    help="cluster type",
)
@click.option("--project-id", help="project to create the cluster in")
@click.option("--region", help="cloud region (e.g. aws-us-west-2)")
@click.option(
    "--cu-type",
    type=click.Choice(["Performance-optimized", "Capacity-optimized"], case_sensitive=False),
    metavar="TYPE",
    default=None,
    help="compute unit type (dedicated only)  [Performance-optimized, Capacity-optimized]",
)
@click.option("--cu-size", type=int, default=None, help="number of compute units (dedicated only)")
@click.option(
    "--plan",
    type=click.Choice(["Free", "Serverless", "Standard", "Enterprise"], case_sensitive=False),
    metavar="PLAN",
    default=None,
    help="subscription plan (dedicated only)  [Free, Serverless, Standard, Enterprise]",
)
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None, help="Output format.")
@click.pass_context
def create_cluster(ctx, name, cluster_type, project_id, region, cu_type, cu_size, plan, output):
    """Create a new cluster."""
    # Validate required params
    missing = []
    if not name:
        missing.append("--name")
    if not cluster_type:
        missing.append("--type")
    if not project_id:
        missing.append("--project-id")
    if not region:
        missing.append("--region")
    if missing:
        raise click.ClickException(f"Missing required options: {', '.join(missing)}")

    cluster_type = cluster_type.lower()

    # Validate dedicated-only params
    if cluster_type == "dedicated":
        if not cu_type:
            raise click.ClickException("--cu-type is required for dedicated clusters.")
        if not cu_size:
            raise click.ClickException("--cu-size is required for dedicated clusters.")

    output_format = output or ctx.obj.get("output_format") or "table"
    fmt = get_formatter(output_format)
    caller = build_caller(ctx)

    body = {
        "clusterName": name,
        "projectId": project_id,
        "regionId": region,
    }

    if cluster_type == "dedicated":
        body["cuType"] = cu_type
        body["cuSize"] = cu_size
        if plan:
            body["plan"] = plan

    path = _CLUSTER_TYPE_PATHS[cluster_type]

    stderr_console = Console(stderr=True)
    try:
        with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
            result = caller.call("POST", path, body=body, path_params={})
        click.echo(fmt.format_success(result))
    except APIError as e:
        click.echo(fmt.format_error(e.code, e.message), err=True)
        ctx.exit(1)


# Mark required options for GroupedCommand section grouping
for param in create_cluster.params:
    if isinstance(param, click.Option):
        decls = set(param.opts)
        param._model_required = bool(decls & _REQUIRED_OPTIONS)  # type: ignore[attr-defined]
