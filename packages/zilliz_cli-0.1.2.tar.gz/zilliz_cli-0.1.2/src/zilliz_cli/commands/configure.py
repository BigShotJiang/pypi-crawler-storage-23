# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import click

from zilliz_cli.auth.config import get_config_manager

_CREDENTIAL_KEYS = {"api_key"}


def _mask_value(value: str) -> str:
    return value[:4] + "****" + value[-4:] if len(value) >= 16 else "****"


@click.group(invoke_without_command=True)
@click.pass_context
def configure(ctx):
    """Configure Zilliz Cloud CLI settings."""
    if ctx.invoked_subcommand is not None:
        return
    mgr = get_config_manager(ctx.obj)
    api_key = click.prompt("Zilliz Cloud API Key", hide_input=True).strip()
    try:
        api_key.encode("ascii")
    except UnicodeEncodeError:
        raise click.ClickException(
            "API key contains non-ASCII characters. "
            "Please check your input (on macOS, use Cmd+V to paste, not Option+V)."
        )
    if not api_key:
        raise click.ClickException("API key cannot be empty.")
    from zilliz_cli.auth.validation import validate_api_key

    validate_api_key(api_key)
    mgr.set_credential("api_key", api_key)
    click.echo("API Key configured successfully.")


@configure.command("set")
@click.argument("key")
@click.argument("value", required=False, default=None)
@click.pass_context
def configure_set(ctx, key, value):
    """Set a configuration value.

    For credential keys (e.g. api_key), VALUE can be omitted to enter securely via prompt.
    """
    if value is None:
        if key in _CREDENTIAL_KEYS:
            value = click.prompt(f"Enter {key}", hide_input=True).strip()
        else:
            raise click.UsageError("VALUE is required for non-credential keys.")
    mgr = get_config_manager(ctx.obj)
    if key in _CREDENTIAL_KEYS:
        try:
            value.encode("ascii")
        except UnicodeEncodeError:
            raise click.ClickException(
                f"{key} contains non-ASCII characters. "
                "Please check your input (on macOS, use Cmd+V to paste, not Option+V)."
            )
        if not value:
            raise click.ClickException(f"{key} cannot be empty.")
        if key == "api_key":
            from zilliz_cli.auth.validation import validate_api_key

            validate_api_key(value)
        mgr.set_credential(key, value)
    else:
        mgr.set_config("default", key, value)
    display = _mask_value(value) if key in _CREDENTIAL_KEYS else value
    click.echo(f"{key} = {display}")


@configure.command("clear")
@click.pass_context
def configure_clear(ctx):
    """Clear all stored credentials (logout)."""
    mgr = get_config_manager(ctx.obj)
    mgr.clear_credentials()
    click.echo("Credentials cleared.")


@configure.command("get")
@click.argument("key")
@click.pass_context
def configure_get(ctx, key):
    """Get a configuration value."""
    mgr = get_config_manager(ctx.obj)
    if key in _CREDENTIAL_KEYS:
        value = mgr.get_credential(key)
    else:
        value = mgr.get_config("default", key)
    if value is None:
        click.echo(f"{key}: not set")
    else:
        display = _mask_value(value) if key in _CREDENTIAL_KEYS else value
        click.echo(f"{key} = {display}")


@configure.command("list")
@click.pass_context
def configure_list(ctx):
    """List all configuration values."""
    mgr = get_config_manager(ctx.obj)
    all_config = mgr.list_all()
    for key, value in all_config.get("credentials", {}).items():
        click.echo(f"{key} = {_mask_value(value)}")
    for key, value in all_config.get("config", {}).items():
        click.echo(f"{key} = {value}")
