import click

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError, CredentialError
from zilliz_cli.formatter.base import get_formatter


@click.group()
def context():
    """Manage current cluster context."""
    pass


@context.command("set")
@click.option("--cluster-id", default=None, help="Cluster ID.")
@click.option("--endpoint", default=None, help="Cluster endpoint URL (optional, auto-resolved from cluster-id).")
@click.option("--database", default=None, help="Database name.")
@click.pass_context
def context_set(ctx, cluster_id, endpoint, database):
    """Set the current cluster context."""
    if cluster_id is None and database is None:
        raise click.UsageError("Provide at least --cluster-id or --database.")

    mgr = get_config_manager(ctx.obj)

    if database and not cluster_id:
        mgr.set_context(database=database)
        click.echo(f"Database set to: {database}")
        return

    # Resolve endpoint
    if endpoint is None:
        try:
            api_key = resolve_api_key(ctx.obj.get("api_key"), mgr)
        except CredentialError as e:
            raise click.ClickException(str(e))

        caller = APICaller(api_key=api_key)
        try:
            cluster_info = caller.call("GET", "/v2/clusters/{clusterId}", path_params={"clusterId": cluster_id})
            if not cluster_info:
                raise click.ClickException(f"Cluster {cluster_id} returned no data. Use --endpoint to set manually.")
            endpoint = cluster_info.get("connectAddress", "")
            if not endpoint:
                raise click.ClickException(
                    f"Cluster {cluster_id} has no connectAddress. Use --endpoint to set manually."
                )
        except APIError as e:
            raise click.ClickException(f"Failed to resolve endpoint: {e}")

    db = database or "default"
    mgr.set_context(cluster_id=cluster_id, endpoint=endpoint, database=db)
    click.echo(f"Context set: cluster={cluster_id}, endpoint={endpoint}, database={db}")


@context.command("current")
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None)
@click.pass_context
def context_current(ctx, output):
    """Show the current context."""
    mgr = get_config_manager(ctx.obj)
    context_data = mgr.get_context()
    if context_data["cluster_id"] is None:
        click.echo('No context set. Run "zilliz context set --cluster-id <id>" first.')
        return
    output_format = output or ctx.obj.get("output_format") or "text"
    fmt = get_formatter(output_format)
    click.echo(fmt.format_success(context_data))
