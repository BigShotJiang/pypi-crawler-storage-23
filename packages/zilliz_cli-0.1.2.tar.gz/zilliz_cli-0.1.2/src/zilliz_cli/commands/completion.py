# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Shell completion commands."""

import os
from pathlib import Path

import click

COMPLETION_SCRIPTS = {
    "bash": 'eval "$(_ZILLIZ_COMPLETE=bash_source zilliz)"',
    "zsh": 'eval "$(_ZILLIZ_COMPLETE=zsh_source zilliz)"',
    "fish": "_ZILLIZ_COMPLETE=fish_source zilliz | source",
}

SHELL_RC_FILES = {
    "bash": "~/.bashrc",
    "zsh": "~/.zshrc",
    "fish": "~/.config/fish/config.fish",
}

COMPLETION_MARKER = "# zilliz-cli completion"


def _get_rc_path(shell: str) -> Path:
    """Get the RC file path for the shell."""
    return Path(os.path.expanduser(SHELL_RC_FILES[shell]))


def _is_completion_installed(shell: str) -> bool:
    """Check if completion is already installed."""
    rc_path = _get_rc_path(shell)
    if not rc_path.exists():
        return False
    content = rc_path.read_text()
    return COMPLETION_MARKER in content or "_ZILLIZ_COMPLETE" in content


def _install_completion(shell: str) -> tuple[bool, str]:
    """Install completion to RC file. Returns (success, message)."""
    rc_path = _get_rc_path(shell)
    script = COMPLETION_SCRIPTS[shell]

    # Create parent directories if needed (for fish)
    rc_path.parent.mkdir(parents=True, exist_ok=True)

    # Check if already installed
    if _is_completion_installed(shell):
        return False, f"Completion already installed in {rc_path}"

    # Append completion script
    with open(rc_path, "a") as f:
        f.write(f"\n{COMPLETION_MARKER}\n")
        f.write(f"{script}\n")

    return True, f"Completion installed to {rc_path}"


def _uninstall_completion(shell: str) -> tuple[bool, str]:
    """Remove completion from RC file. Returns (success, message)."""
    rc_path = _get_rc_path(shell)

    if not rc_path.exists():
        return False, f"RC file not found: {rc_path}"

    content = rc_path.read_text()
    lines = content.splitlines()

    # Filter out completion lines
    new_lines = []
    skip_next = False
    removed = False

    for line in lines:
        if COMPLETION_MARKER in line:
            skip_next = True
            removed = True
            continue
        if skip_next and "_ZILLIZ_COMPLETE" in line:
            skip_next = False
            continue
        skip_next = False
        new_lines.append(line)

    if not removed:
        return False, f"Completion not found in {rc_path}"

    # Write back
    rc_path.write_text("\n".join(new_lines))
    return True, f"Completion removed from {rc_path}"


@click.group()
def completion():
    """Shell completion management."""
    pass


@completion.command("install")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]), default=None, required=False)
@click.option("--apply", is_flag=True, help="Automatically write to shell RC file.")
def install_completion(shell: str | None, apply: bool):
    """Install shell completion.

    \b
    Examples:
        zilliz completion install              # Auto-detect shell, show instructions
        zilliz completion install zsh          # Show zsh instructions
        zilliz completion install zsh --apply  # Auto-install to ~/.zshrc
    """
    # Auto-detect shell if not specified
    if shell is None:
        shell = _detect_shell()
        if shell is None:
            raise click.ClickException("Cannot detect shell. Please specify: zilliz completion install [bash|zsh|fish]")
        click.echo(f"Detected shell: {shell}")

    if apply:
        success, message = _install_completion(shell)
        if success:
            click.secho(f"[OK] {message}", fg="green")
            click.echo("\nRun this to activate now:")
            click.secho(f"  source {SHELL_RC_FILES[shell]}", fg="cyan")
        else:
            click.secho(f"[SKIP] {message}", fg="yellow")
    else:
        # Show manual instructions
        click.echo(f"To enable completion for {shell}, add this to {SHELL_RC_FILES[shell]}:\n")
        click.secho(f"  {COMPLETION_SCRIPTS[shell]}", fg="cyan")
        click.echo("\nOr run with --apply to install automatically:")
        click.secho(f"  zilliz completion install {shell} --apply", fg="cyan")


@completion.command("uninstall")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]), default=None, required=False)
def uninstall_completion(shell: str | None):
    """Remove shell completion from RC file.

    \b
    Examples:
        zilliz completion uninstall zsh
    """
    if shell is None:
        shell = _detect_shell()
        if shell is None:
            raise click.ClickException(
                "Cannot detect shell. Please specify: zilliz completion uninstall [bash|zsh|fish]"
            )

    success, message = _uninstall_completion(shell)
    if success:
        click.secho(f"[OK] {message}", fg="green")
        click.echo("\nRun this to apply:")
        click.secho(f"  source {SHELL_RC_FILES[shell]}", fg="cyan")
    else:
        click.secho(f"[SKIP] {message}", fg="yellow")


@completion.command("status")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]), default=None, required=False)
def completion_status(shell: str | None):
    """Check if shell completion is installed.

    \b
    Examples:
        zilliz completion status
        zilliz completion status zsh
    """
    if shell is None:
        shell = _detect_shell()
        if shell is None:
            raise click.ClickException("Cannot detect shell. Please specify: zilliz completion status [bash|zsh|fish]")

    if _is_completion_installed(shell):
        click.secho(f"[OK] Completion is installed for {shell}", fg="green")
    else:
        click.secho(f"[NOT INSTALLED] Completion is not installed for {shell}", fg="yellow")
        click.echo("\nRun to install:")
        click.secho(f"  zilliz completion install {shell} --apply", fg="cyan")


@completion.command("show")
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
def show_completion(shell: str):
    """Show the completion script (for manual installation).

    \b
    Examples:
        zilliz completion show zsh
    """
    click.echo(COMPLETION_SCRIPTS[shell])


def _detect_shell() -> str | None:
    """Detect the current shell."""
    shell_path = os.environ.get("SHELL", "")
    if "zsh" in shell_path:
        return "zsh"
    elif "bash" in shell_path:
        return "bash"
    elif "fish" in shell_path:
        return "fish"
    return None
