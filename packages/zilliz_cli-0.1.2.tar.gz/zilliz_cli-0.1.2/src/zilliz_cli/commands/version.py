# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import click

from zilliz_cli import __version__
from zilliz_cli.formatter.base import get_formatter


@click.command(hidden=True)
@click.option("--output", "-o", type=click.Choice(["json", "table", "text"]), default=None)
@click.pass_context
def version(ctx, output):
    """Show CLI version."""
    output_format = output or ctx.obj.get("output_format") or "text"
    fmt = get_formatter(output_format)
    click.echo(fmt.format_success({"version": __version__}))
