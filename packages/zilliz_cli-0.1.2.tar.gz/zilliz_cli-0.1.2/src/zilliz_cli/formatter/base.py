from abc import ABC, abstractmethod


class BaseFormatter(ABC):
    @abstractmethod
    def format_success(self, data) -> str:
        pass

    @abstractmethod
    def format_error(self, code: int, message: str) -> str:
        pass


def get_formatter(output_format: str) -> BaseFormatter:
    from zilliz_cli.formatter.json import JsonFormatter
    from zilliz_cli.formatter.table import TableFormatter
    from zilliz_cli.formatter.text import TextFormatter

    formatters = {
        "json": JsonFormatter,
        "table": TableFormatter,
        "text": TextFormatter,
    }
    cls = formatters.get(output_format)
    if cls is None:
        raise ValueError(f"Unknown output format: {output_format}")
    return cls()  # type: ignore[abstract]
