# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""Table formatter with rich styling support."""

from __future__ import annotations

import io
import shutil

from rich.console import Console
from rich.table import Table
from rich.text import Text

from zilliz_cli.formatter.base import BaseFormatter
from zilliz_cli.formatter.styles import (
    ERROR_SYMBOL,
    SUCCESS_SYMBOL,
    get_field_style,
    get_status_style,
    is_status_field,
)


class TableFormatter(BaseFormatter):
    def format_success(self, data) -> str:
        if isinstance(data, list):
            return self._format_list(data)
        elif isinstance(data, dict):
            return self._format_dict(data)
        return str(data)

    def format_error(self, code: int, message: str) -> str:
        console = Console(force_terminal=True)
        with console.capture() as capture:
            console.print(f"{ERROR_SYMBOL} Error [{code}]: {message}")
        return capture.get().strip()

    # Priority fields to show in table (in order)
    # Fields not in this list will be hidden when there are too many columns
    _PRIORITY_FIELDS = [
        "clusterName",
        "clusterId",
        "status",
        "plan",
        "regionId",
        "projectName",
        "projectId",
        "backupId",
        "backupName",
        "cuType",
        "cuSize",
        "createTime",
        "cloudId",
        "domain",
    ]
    _MAX_COLUMNS = 8  # Maximum columns to show to prevent truncation

    def _format_list(self, items: list) -> str:
        if not items:
            return "No data"
        if not isinstance(items[0], dict):
            return "\n".join(str(item) for item in items)

        table = Table(show_lines=False)
        all_keys = list(items[0].keys())

        # If too many columns, filter to priority fields only
        if len(all_keys) > self._MAX_COLUMNS:
            keys = [k for k in self._PRIORITY_FIELDS if k in all_keys]
            # If still too many or none matched, take first N
            if not keys or len(keys) > self._MAX_COLUMNS:
                keys = all_keys[: self._MAX_COLUMNS]
        else:
            keys = all_keys

        # Add columns with styling for key fields
        for key in keys:
            style = get_field_style(key)
            table.add_column(key, style=style)

        # Add rows with status highlighting
        for item in items:
            row = []
            for key in keys:
                value = item.get(key, "")
                row.append(self._style_value(key, value))
            table.add_row(*row)

        return self._render(table)

    def _format_dict(self, item: dict) -> str:
        # Empty dict means operation succeeded with no data to return
        if not item:
            console = Console(force_terminal=True)
            with console.capture() as capture:
                console.print(f"{SUCCESS_SYMBOL} Success")
            return capture.get().strip()

        # Check if this is a paginated response with a list field
        list_data, pagination = self._extract_list_from_paginated(item)
        if list_data is not None:
            table_output = self._format_list(list_data)
            # Show pagination info if there are more pages
            if pagination:
                total = pagination.get("count") or pagination.get("total") or 0
                page_size = pagination.get("pageSize", 0)
                current_page = pagination.get("currentPage") or pagination.get("page") or 1
                if total > page_size:
                    table_output += f"\n\nShowing {len(list_data)} of {total} (page {current_page})"
            return table_output

        # Separate fields into simple values and nested lists
        simple_fields = {}
        nested_tables = {}  # list[dict] fields to render as sub-tables

        for k, v in item.items():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                # list[dict] -> render as sub-table
                nested_tables[k] = v
            elif isinstance(v, list):
                # list[str] or empty list -> join with comma
                simple_fields[k] = ", ".join(str(x) for x in v) if v else "-"
            else:
                simple_fields[k] = v

        output_parts = []

        # Render simple fields as key-value table
        if simple_fields:
            table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
            table.add_column("Field", style="bold cyan")
            table.add_column("Value")
            for k, v in simple_fields.items():
                styled_value = self._style_value(k, v)
                table.add_row(str(k), styled_value)
            output_parts.append(self._render(table))

        # Render each nested list[dict] as a sub-table with header
        for field_name, items in nested_tables.items():
            if not items:
                continue
            # Section header
            section_header = f"\n{field_name.capitalize()}:"
            # Build sub-table
            sub_table = Table(show_lines=False)
            keys = list(items[0].keys())
            # Limit columns for readability
            display_keys = keys[:6] if len(keys) > 6 else keys
            for key in display_keys:
                sub_table.add_column(key)
            for row_item in items:
                row = [self._format_nested_value(row_item.get(k, "")) for k in display_keys]
                sub_table.add_row(*row)
            output_parts.append(section_header)
            output_parts.append(self._render(sub_table))

        return "\n".join(output_parts)

    def _format_nested_value(self, value) -> str:
        """Format a value from nested dict for display."""
        if isinstance(value, list):
            if not value:
                return "-"
            # For list of dicts like params: [{"key": "dim", "value": "768"}]
            if isinstance(value[0], dict):
                parts = []
                for item in value:
                    if "key" in item and "value" in item:
                        parts.append(f"{item['key']}={item['value']}")
                    else:
                        parts.append(str(item))
                return ", ".join(parts) if parts else "-"
            return ", ".join(str(x) for x in value)
        elif isinstance(value, bool):
            return "Yes" if value else "No"
        elif value is None or value == "":
            return "-"
        return str(value)

    def _extract_list_from_paginated(self, item: dict) -> tuple[list | None, dict | None]:
        """Extract list data and pagination info from paginated response.

        Detects responses like {count, currentPage, pageSize, clusters/backups/...}
        and returns (list_data, pagination_info).
        """
        # Common pagination metadata fields
        pagination_fields = {"count", "currentPage", "pageSize", "total", "page"}

        # Find the list field (the one that's not pagination metadata)
        list_field = None
        for key, value in item.items():
            if key not in pagination_fields and isinstance(value, list):
                list_field = key
                break

        if list_field is None:
            return None, None

        # Verify this looks like a paginated response (has at least one pagination field)
        if not any(field in item for field in pagination_fields):
            return None, None

        # Extract pagination info
        pagination = {k: v for k, v in item.items() if k in pagination_fields}

        return item[list_field], pagination

    def _style_value(self, field_name: str, value) -> Text | str:
        """Apply styling to a value based on field name and content."""
        str_value = str(value) if value is not None else ""

        # Check if this is a status field
        if is_status_field(field_name):
            status_style = get_status_style(str_value)
            if status_style:
                return Text(str_value, style=status_style)

        # Check if field has special styling
        field_style = get_field_style(field_name)
        if field_style:
            return Text(str_value, style=field_style)

        return str_value

    def _render(self, table: Table) -> str:
        buf = io.StringIO()
        # Use actual terminal width, fallback to 160 for wider display
        term_width = shutil.get_terminal_size((160, 24)).columns
        console = Console(file=buf, force_terminal=True, width=term_width)
        console.print(table)
        return buf.getvalue().strip()
