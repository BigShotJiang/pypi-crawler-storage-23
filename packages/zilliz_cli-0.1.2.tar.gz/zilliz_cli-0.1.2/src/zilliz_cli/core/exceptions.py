class ZillizCLIError(Exception):
    """Base exception for Zilliz CLI."""

    pass


class ConfigError(ZillizCLIError):
    """Configuration related errors."""

    pass


class CredentialError(ZillizCLIError):
    """Credential resolution errors."""

    pass


class ContextError(ZillizCLIError):
    """Context related errors (no cluster set, etc.)."""

    pass


class APIError(ZillizCLIError):
    """API call errors."""

    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")
