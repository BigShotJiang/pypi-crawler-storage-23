import json
from pathlib import Path

from zilliz_cli.core.model import CliModel

_BUILTIN_DIR = Path(__file__).parent.parent / "builtin_models"


class ModelLoader:
    def __init__(self, cache_dir: Path | None = None):
        self.cache_dir = cache_dir
        self.builtin_dir = _BUILTIN_DIR

    def load(self, plane: str) -> CliModel:
        """Load model definition. Currently: builtin only."""
        return self._load_builtin(plane)

    def _load_builtin(self, plane: str) -> CliModel:
        path = self.builtin_dir / f"{plane}.json"
        if not path.exists():
            raise FileNotFoundError(f"No builtin model found: {plane}")
        with open(path) as f:
            data = json.load(f)
        return CliModel.from_dict(data)
