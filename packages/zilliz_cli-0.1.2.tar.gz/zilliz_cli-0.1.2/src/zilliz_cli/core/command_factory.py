# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

import json
import sys
from pathlib import Path

import click
import questionary
from rich.console import Console

from zilliz_cli.auth.config import get_config_manager
from zilliz_cli.auth.credentials import resolve_api_key
from zilliz_cli.core.api_caller import APICaller
from zilliz_cli.core.exceptions import APIError, CredentialError
from zilliz_cli.core.model import CliModel, Operation, Param, Resource
from zilliz_cli.formatter.base import get_formatter


class GroupedCommand(click.Command):
    """Command that groups options into Required and Optional sections in help."""

    def format_epilog(self, ctx, formatter):
        """Write epilog as-is without Click's paragraph wrapping."""
        if self.epilog:
            formatter.write("\n")
            # Strip the \b marker if present
            text = self.epilog.lstrip("\b").rstrip()
            for line in text.split("\n"):
                formatter.write(f"  {line}\n")
            formatter.write("\n")

    def format_options(self, ctx, formatter):
        required = []
        optional = []
        for param in self.get_params(ctx):
            rv = param.get_help_record(ctx)
            if rv is not None:
                if getattr(param, "_model_required", False):
                    required.append(rv)
                else:
                    optional.append(rv)

        if required:
            with formatter.section("Required Options"):
                formatter.write_dl(required)
        if optional:
            with formatter.section("Options"):
                formatter.write_dl(optional)


class CommandFactory:
    def __init__(self, model: CliModel, endpoint_resolver=None, context_provider=None):
        self.model = model
        self.endpoint_resolver = endpoint_resolver
        self.context_provider = context_provider

    def create_groups(self) -> dict[str, click.Group]:
        groups = {}
        for resource_name, resource in self.model.resources.items():
            group = self._build_group(resource_name, resource)
            groups[resource_name] = group
        return groups

    def _build_group(self, name: str, resource: Resource) -> click.Group:
        @click.group(name=name)
        def group():
            pass

        if resource.description:
            group.help = resource.description
        else:
            group.__doc__ = f"Manage {name}s."

        for op_name, operation in resource.operations.items():
            cmd = self._build_command(op_name, operation)
            group.add_command(cmd)
        return group

    def _build_command(self, name: str, operation: Operation) -> click.Command:
        is_dangerous = name in _DANGEROUS_OPERATIONS
        params: list[click.Parameter] = []

        for p in operation.params:
            param_type = _CLICK_TYPE_MAP.get(p.type, click.STRING)
            metavar = f"<{p.cli_name.lstrip('-')}>"

            if p.choices:
                param_type = click.Choice(p.choices, case_sensitive=False)
                choices_str = "|".join(p.choices)
                if len(choices_str) <= 30:
                    # Short enums: show in metavar e.g. [COSINE|L2|IP]
                    metavar = f"[{choices_str}]"
                else:
                    # Long enums: short metavar, values in description
                    metavar = p.cli_name.split("-")[-1].upper()

            # Build help text
            if p.description:
                help_text = p.description
            else:
                help_text = p.name

            if p.required_unless:
                help_text += " (unless --body)"

            if p.default is not None:
                help_text += f" (default: {p.default})"

            # Long enums: append to description in brackets
            if p.choices:
                choices_str = "|".join(p.choices)
                if len(choices_str) > 30:
                    help_text += "  [" + ", ".join(p.choices) + "]"

            # Make params not required at Click level - we'll handle it interactively.
            # Store original required status for section grouping in help output.
            option = click.Option(
                param_decls=[p.cli_name],
                required=False,
                default=p.default,
                type=param_type,
                metavar=metavar,
                help=help_text,
            )
            option._model_required = p.required or (p.required_unless is not None)  # type: ignore[attr-defined]
            params.append(option)

        params.append(
            click.Option(
                ["--output", "-o"],
                type=click.Choice(["json", "table", "text"]),
                default=None,
                help="Output format.",
            )
        )

        if operation.pagination:
            params.append(
                click.Option(
                    ["--all", "-a"],
                    is_flag=True,
                    default=False,
                    help="Fetch all pages.",
                )
            )

        if operation.body_param:
            params.append(
                click.Option(
                    [operation.body_param],
                    type=click.STRING,
                    default=None,
                    metavar="<json>",
                    help="Raw JSON body (or file://path).",
                )
            )

        # Add --yes flag for dangerous operations
        if is_dangerous:
            params.append(
                click.Option(
                    ["--yes", "-y"],
                    is_flag=True,
                    default=False,
                    help="Skip confirmation prompt.",
                )
            )

        def make_callback(op: Operation, op_name: str, body_param_key: str | None = None, dangerous: bool = False):
            @click.pass_context
            def callback(ctx, **kwargs):
                output = kwargs.pop("output", None) or kwargs.pop("o", None)
                raw_body = kwargs.pop(body_param_key, None) if body_param_key else None
                fetch_all = kwargs.pop("all", False) if op.pagination else False
                skip_confirm = kwargs.pop("yes", False) if dangerous else True
                output_format = output or ctx.obj.get("output_format") or "table"
                fmt = get_formatter(output_format)

                mgr = get_config_manager(ctx.obj)
                try:
                    api_key = resolve_api_key(ctx.obj.get("api_key"), mgr)
                except CredentialError as e:
                    raise click.ClickException(str(e))

                if self.endpoint_resolver:
                    endpoint = self.endpoint_resolver(ctx.obj)
                elif self.model.endpoint:
                    endpoint = self.model.endpoint
                else:
                    raise click.ClickException(
                        'No endpoint configured. Set a context with "zilliz context set --cluster-id <id>" first.'
                    )
                caller = APICaller(api_key=api_key, base_url=endpoint)

                # Prompt for missing required parameters (interactive mode)
                # Pass raw_body so we can skip conditionally required params when --body is provided
                kwargs = _prompt_for_missing_params(op.params, kwargs, caller, has_body=bool(raw_body))

                path_params = {}
                body = {}

                if raw_body:
                    body = _parse_body_value(raw_body)

                for p in op.params:
                    cli_key = p.cli_name.lstrip("-").replace("-", "_")
                    value = kwargs.get(cli_key)
                    if value is None:
                        continue
                    if p.position == "path":
                        path_params[p.name] = value
                    elif not raw_body or p.name not in body:
                        if p.type in ("array", "object") and isinstance(value, str):
                            try:
                                value = json.loads(value)
                            except json.JSONDecodeError:
                                raise click.ClickException(f"Invalid JSON for {p.cli_name}: {value}")
                        body[p.name] = value

                # Auto-inject dbName from context
                if self.context_provider and "dbName" not in body:
                    has_dbname_param = any(p.name == "dbName" for p in op.params)
                    if has_dbname_param:
                        ctx_data = self.context_provider(ctx.obj)
                        db = ctx_data.get("database", "default")
                        if db and db != "default":
                            body["dbName"] = db

                # Confirmation for dangerous operations
                if dangerous and not skip_confirm:
                    # Build a description of what will be affected
                    target = (
                        path_params.get("clusterId")
                        or path_params.get("collectionName")
                        or body.get("collectionName")
                        or body.get("clusterId")
                        or "this resource"
                    )
                    click.secho(f"Warning: You are about to {op_name} '{target}'", fg="yellow")
                    if not click.confirm("Are you sure you want to continue?"):
                        click.echo("Aborted.")
                        ctx.exit(0)

                stderr_console = Console(stderr=True)
                try:
                    with stderr_console.status("[cyan]Loading...[/cyan]", spinner="dots"):
                        if fetch_all and op.pagination:
                            result = _fetch_all_pages(caller, op, body, path_params)
                        else:
                            result = caller.call(op.method, op.path, body=body, path_params=path_params)
                    click.echo(fmt.format_success(result))
                except APIError as e:
                    click.echo(fmt.format_error(e.code, e.message), err=True)
                    ctx.exit(1)

            return callback

        bp_key = None
        if operation.body_param:
            bp_key = operation.body_param.lstrip("-").replace("-", "_")

        # Build help text
        help_text = operation.description or f"{name.capitalize()} operation."

        # Build epilog for examples (shown after Options)
        epilog = None
        if operation.examples:
            # \b tells Click not to reformat the following block
            epilog = "\b\nExamples:\n"
            for ex in operation.examples:
                epilog += f"  {ex}\n"

        cmd = GroupedCommand(
            name=name,
            callback=make_callback(operation, op_name=name, body_param_key=bp_key, dangerous=is_dangerous),
            params=params,
            help=help_text,
            epilog=epilog,
        )
        return cmd


def _parse_body_value(value: str) -> dict:
    if value.startswith("file://"):
        path = value[7:]
        if not Path(path).is_file():
            raise click.ClickException(f"File not found: {path}")
        with open(path) as f:
            try:
                return json.load(f)
            except json.JSONDecodeError as e:
                raise click.ClickException(f"Invalid JSON in {path}: {e}")
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid JSON body: {e}")


_CLICK_TYPE_MAP = {
    "string": click.STRING,
    "integer": click.INT,
    "boolean": click.BOOL,
    "array": click.STRING,
    "object": click.STRING,
}

# Dangerous operations that require confirmation
_DANGEROUS_OPERATIONS = {"delete", "drop", "release", "reset", "clear", "remove"}


def _prompt_for_missing_params(
    params: list[Param], kwargs: dict, caller: APICaller | None = None, has_body: bool = False
) -> dict:
    """Prompt user for missing required parameters if running interactively.

    For known parameters like projectId, regionId, clusterId, this function will
    fetch available options from the API and present them as a selection list.

    Args:
        params: List of parameter definitions
        kwargs: Current parameter values
        caller: API caller for smart prompts
        has_body: Whether --body was provided (skips conditionally required params)
    """
    missing = []
    for p in params:
        cli_key = p.cli_name.lstrip("-").replace("-", "_")
        if kwargs.get(cli_key) is not None:
            continue
        # Check if required
        is_required = p.required
        # Check conditional requirement: required unless --body is provided
        if p.required_unless == "body" and not has_body:
            is_required = True
        if is_required:
            missing.append(p)

    if not missing:
        return kwargs

    # Non-interactive mode: raise error
    if not sys.stdin.isatty():
        missing_names = ", ".join(p.cli_name for p in missing)
        raise click.ClickException(f"Missing required options: {missing_names}")

    # Interactive mode: prompt for each missing param
    click.echo("Please provide the required parameters:\n")
    for p in missing:
        cli_key = p.cli_name.lstrip("-").replace("-", "_")

        # Try smart prompt for known parameter types
        value = _smart_prompt_param(p, caller)

        if value is None:
            # Fallback to simple prompt
            prompt_text = f"  {p.name}"
            if p.type == "integer":
                value = click.prompt(prompt_text, type=int)
            elif p.type == "boolean":
                value = click.confirm(prompt_text)
            else:
                value = click.prompt(prompt_text, type=str).strip()

        kwargs[cli_key] = value

    click.echo()  # blank line after prompts
    return kwargs


# Mapping of parameter names to their API fetch configuration
# Each config: {api, data_field, id_field, name_field, extra_fields (optional)}
# Or static choices: {choices: [(display, value), ...]}
_SMART_PARAM_FETCHERS: dict[str, dict] = {
    "projectId": {
        "api": "GET /v2/projects",
        "data_field": "data",
        "id_field": "projectId",
        "name_field": "projectName",
        "extra_fields": ["plan"],
    },
    "regionId": {
        "api": "GET /v2/regions",
        "data_field": "data",
        "id_field": "regionId",
        "name_field": "regionId",
    },
    "clusterId": {
        "api": "GET /v2/clusters",
        "data_field": "clusters",
        "id_field": "clusterId",
        "name_field": "clusterName",
    },
    "cuType": {
        "choices": [
            ("Performance-optimized (recommended)", "Performance-optimized"),
            ("Capacity-optimized (more storage)", "Capacity-optimized"),
        ],
    },
}


def _smart_prompt_param(param: Param, caller: APICaller | None) -> str | int | None:
    """Try to fetch options for known parameters and present a selection.

    Returns the selected value, or None if smart prompt is not available.
    """
    config = _SMART_PARAM_FETCHERS.get(param.name)
    if config is None:
        return None

    # Handle static choices (no API call needed)
    if "choices" in config:
        choices = [questionary.Choice(title=display, value=value) for display, value in config["choices"]]
        selected = questionary.select(
            f"  Select {param.name}:",
            choices=choices,
            use_shortcuts=True,
        ).ask()
        return selected

    # Need API caller for dynamic options
    if caller is None:
        return None

    api_spec = config["api"]
    data_field = config["data_field"]
    id_field = config["id_field"]
    name_field = config["name_field"]
    extra_fields = config.get("extra_fields", [])

    try:
        # Parse API spec
        method, path = api_spec.split(" ", 1)
        result = caller.call(method, path, return_raw=True)

        if not isinstance(result, dict):
            return None

        # Handle response structure: {"code": 0, "data": [...]} or direct data
        response_data = result.get("data", result)

        # Get the list of items
        if isinstance(response_data, list):
            items = response_data
        elif isinstance(response_data, dict):
            items = response_data.get(data_field, [])
            if not isinstance(items, list):
                items = [items] if items else []
        else:
            return None

        if not items:
            click.echo(f"  No {param.name.replace('Id', '')}s found.")
            return None

        # Build choices for questionary
        choices = []
        for item in items:
            item_id = item.get(id_field)
            item_name = item.get(name_field, item_id)
            if item_id:
                # Build display string: "name (id)" or "name [extra1, extra2] (id)"
                extra_parts = []
                for field in extra_fields:
                    val = item.get(field)
                    if val:
                        extra_parts.append(str(val))

                if extra_parts:
                    extra_str = ", ".join(extra_parts)
                    display = f"{item_name} [{extra_str}] ({item_id})"
                elif item_name != item_id:
                    display = f"{item_name} ({item_id})"
                else:
                    display = item_id
                choices.append(questionary.Choice(title=display, value=item_id))

        if not choices:
            return None

        # If only one option, auto-select it
        if len(choices) == 1:
            selected = choices[0].value
            click.echo(f"  {param.name}: {choices[0].title} (auto-selected)")
            return selected

        # Present selection
        selected = questionary.select(
            f"  Select {param.name.replace('Id', '')}:",
            choices=choices,
            use_shortcuts=True,
        ).ask()

        return selected

    except APIError:
        # API error (auth failure, network issue) -> fall back to manual input
        return None
    except (KeyError, TypeError, ValueError):
        # Malformed response -> fall back to manual input
        return None


_MAX_PAGES = 1000


def _fetch_all_pages(caller: APICaller, op: Operation, body: dict, path_params: dict) -> list:
    """Fetch all pages of paginated results."""
    assert op.pagination is not None
    pg = op.pagination
    all_results = []
    page = 1
    page_size = body.get(pg.page_size_param, pg.default_page_size)

    while page <= _MAX_PAGES:
        req_body = body.copy()
        req_body[pg.page_size_param] = page_size
        req_body[pg.page_param] = page

        result = caller.call(
            op.method,
            op.path,
            body=req_body or None,
            path_params=path_params,
            return_raw=True,
        )

        if not isinstance(result, dict):
            raise APIError(0, f"Unexpected response type on page {page}: {type(result).__name__}")

        # return_raw gives {"code": 0, "data": {...}}, extract the data part
        response_data = result.get("data", result)

        data = response_data.get(pg.data_field, [])
        if isinstance(data, list):
            all_results.extend(data)
        else:
            all_results.append(data)

        total = int(response_data.get(pg.count_field, 0) or 0)
        if page * page_size >= total or not data:
            break
        page += 1

    if page > _MAX_PAGES:
        click.echo(f"Warning: Reached max page limit ({_MAX_PAGES}).", err=True)

    return all_results
