import json
from urllib.parse import quote

import httpx

from zilliz_cli.core.exceptions import APIError


class APICaller:
    def __init__(self, api_key: str, base_url: str = "https://api.cloud.zilliz.com"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def call(
        self,
        method: str,
        path: str,
        body: dict | None = None,
        path_params: dict | None = None,
        return_raw: bool = False,
    ) -> dict | list | None:
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", quote(str(value), safe=""))

        url = f"{self.base_url}{path}"
        headers = {"Authorization": f"Bearer {self.api_key}"}

        try:
            with httpx.Client(timeout=30.0) as client:
                if method.upper() == "GET":
                    resp = client.request(method, url, headers=headers, params=body or None)
                else:
                    # POST/PUT/DELETE: always send JSON (at least {}) so httpx
                    # sets Content-Type: application/json -- required by Zilliz API
                    resp = client.request(method, url, headers=headers, json=body if body is not None else {})
        except httpx.ConnectError as e:
            raise APIError(0, f"Failed to connect: {e}")
        except httpx.HTTPError as e:
            raise APIError(0, f"HTTP error: {e}")

        return self._parse_response(resp, return_raw=return_raw)

    def _parse_response(self, resp: httpx.Response, return_raw: bool = False) -> dict | list | None:
        """Parse Zilliz API response envelope: {"code": N, "data": ...}."""
        try:
            data = resp.json()
        except json.JSONDecodeError:
            raise APIError(resp.status_code, f"Invalid JSON response: {resp.text}")

        # Zilliz v2 APIs always return {"code": N, "data": ...} envelope.
        if not isinstance(data, dict):
            raise APIError(resp.status_code, f"Unexpected response format: {resp.text}")

        code = data.get("code", 0)

        if code in (0, 200) and resp.status_code < 400:
            if return_raw:
                return data
            return data.get("data")

        message = data.get("message", "Unknown error")

        if resp.status_code in (401, 403) or code in (80001,):
            message = f'{message}. Check your API Key with "zilliz configure get api_key".'

        raise APIError(code, message)
