# Copyright (c) 2026 Zilliz Inc. All rights reserved.
#
# PROPRIETARY AND CONFIDENTIAL
#
# This file contains proprietary information of Zilliz Inc.
#
# No part of this file may be reproduced, stored, transmitted,
# or disclosed to any third party without the prior written
# permission of Zilliz Inc.
#
# Unauthorized use is strictly prohibited.

"""API key validation utilities."""

import click
import httpx


def validate_api_key(api_key: str, echo: bool = True) -> dict | None:
    """Validate API key by calling the clusters API.

    Args:
        api_key: The API key to validate
        echo: Whether to print status messages

    Returns:
        Response data if successful, None otherwise

    Raises:
        click.ClickException: If validation fails
    """
    from zilliz_cli.core.model_loader import ModelLoader

    # Get endpoint from model config
    try:
        model = ModelLoader().load("control-plane")
        endpoint = model.endpoint or "https://api.cloud.zilliz.com"
    except FileNotFoundError:
        endpoint = "https://api.cloud.zilliz.com"

    if echo:
        click.echo("Validating API key...")

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.get(
                f"{endpoint}/v2/clusters",
                headers={"Authorization": f"Bearer {api_key}"},
            )

        if resp.status_code == 401:
            raise click.ClickException("Invalid API key. Please check and try again.")

        if resp.status_code != 200:
            raise click.ClickException(f"Failed to validate API key: HTTP {resp.status_code}")

        try:
            data = resp.json()
        except ValueError:
            raise click.ClickException("Invalid response from server.")

        code = data.get("code")
        if code not in (0, 200):
            message = data.get("message", "Unknown error")
            raise click.ClickException(f"Invalid API key: {message}")

        return data

    except httpx.TimeoutException:
        raise click.ClickException("Request timed out. Please check your network connection.")
    except httpx.RequestError as e:
        raise click.ClickException(f"Network error: {e}")
