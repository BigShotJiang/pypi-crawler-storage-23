#!/usr/bin/env python3
"""Clean up leftover acceptance test resources (clusters and collections).

Usage:
    ZILLIZ_API_KEY=xxx python scripts/cleanup_test_resources.py           # actual cleanup
    ZILLIZ_API_KEY=xxx python scripts/cleanup_test_resources.py --dry-run  # list only
"""
import argparse
import json
import os
import subprocess
import sys

CLUSTER_PREFIX = "zilliz-cli-test-"
COLLECTION_PREFIX = "zilliz_cli_test_"


def run_cli(*args):
    env = os.environ.copy()
    result = subprocess.run(
        ["zilliz", *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )
    return result


def main():
    parser = argparse.ArgumentParser(description="Clean up test resources")
    parser.add_argument("--dry-run", action="store_true", help="List resources without deleting")
    args = parser.parse_args()

    if not os.environ.get("ZILLIZ_API_KEY"):
        print("Error: ZILLIZ_API_KEY environment variable is required", file=sys.stderr)
        sys.exit(1)

    # Find test clusters
    result = run_cli("cluster", "list", "--all", "-o", "json")
    if result.returncode != 0:
        print(f"Error listing clusters: {result.stderr}", file=sys.stderr)
        sys.exit(1)

    clusters = json.loads(result.stdout)
    test_clusters = [c for c in clusters if c["clusterName"].startswith(CLUSTER_PREFIX)]

    if not test_clusters:
        print("No test resources found.")
        return

    print(f"Found {len(test_clusters)} test cluster(s):")
    for c in test_clusters:
        print(f"  {c['clusterId']} ({c['clusterName']}) - {c['status']}")

    if args.dry_run:
        print("\n[DRY RUN] No resources deleted.")
        return

    # Clean up each cluster
    for c in test_clusters:
        cluster_id = c["clusterId"]
        print(f"\nCleaning up cluster {cluster_id} ({c['clusterName']})...")

        # Try to set context and clean collections
        if c["status"] == "RUNNING":
            ctx_result = run_cli("context", "set", "--cluster-id", cluster_id)
            if ctx_result.returncode == 0:
                col_result = run_cli("collection", "list", "-o", "json")
                if col_result.returncode == 0:
                    collections = json.loads(col_result.stdout)
                    for col_name in collections:
                        if col_name.startswith(COLLECTION_PREFIX):
                            print(f"  Dropping collection: {col_name}")
                            run_cli("collection", "drop", "--name", col_name)

        # Delete cluster
        print(f"  Deleting cluster: {cluster_id}")
        del_result = run_cli("cluster", "delete", "--cluster-id", cluster_id)
        if del_result.returncode == 0:
            print(f"  Deleted: {cluster_id}")
        else:
            print(f"  Failed to delete {cluster_id}: {del_result.stderr}")

    print("\nCleanup complete.")


if __name__ == "__main__":
    main()
