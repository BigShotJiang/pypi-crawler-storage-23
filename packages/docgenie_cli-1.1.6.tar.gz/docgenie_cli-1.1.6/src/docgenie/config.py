"""Configuration management for DocGenie."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_config(root_path: Path) -> dict[str, Any]:
    """
    Load configuration from .docgenie.yaml in the project root.
    Returns a default configuration if the file doesn't exist.
    """
    config_path = root_path / ".docgenie.yaml"
    if not config_path.exists():
        return get_default_config()

    try:
        with open(config_path, encoding="utf-8") as f:
            user_config = yaml.safe_load(f) or {}
            return merge_configs(get_default_config(), user_config)
    except (yaml.YAMLError, OSError):
        # Return default config if loading fails
        return get_default_config()


def get_default_config() -> dict[str, Any]:
    """Return the default configuration."""
    return {
        "ignore_patterns": [
            "*.log",
            "build/",
            "dist/",
            "*.egg-info",
            "__pycache__",
            ".git",
            ".idea",
            ".vscode",
            "node_modules",
            "venv",
            ".venv",
            "env",
        ],
        "analysis": {
            "use_gitignore": True,
            "exclude_generated": True,
            "include_hidden": False,
            "max_file_size_kb": 512,
            "generated_patterns": [],
            "engine": "hybrid_index",
            "incremental": True,
            "parallelism": "auto",
            "hard_file_cap": 300000,
            "full_rescan_interval_runs": 20,
        },
        "monorepo": {
            "mode": "auto",
            "root_doc": True,
            "per_package_docs": True,
            "package_output_dir": ".docgenie/packages",
        },
        "safety": {
            "redaction_mode": "strict",
            "redact_patterns": [],
        },
        "template_customizations": {
            "include_api_docs": True,
            "include_directory_tree": True,
            "max_functions_documented": 10,
            "template_profile": "pro",
            "include_trust_badges": True,
        },
        "diff": {
            "enabled": True,
            "from_ref": None,
            "to_ref": "HEAD",
            "rename_detection": True,
        },
        "review": {
            "enabled": True,
            "risk_weights": {"churn": 0.35, "complexity": 0.35, "surface": 0.30},
            "max_files_per_folder": 50,
        },
        "output_links": {
            "enabled": True,
            "languages": ["python", "javascript", "typescript", "shell"],
            "confidence_threshold": "low",
        },
        "quality": {
            "confidence_enabled": True,
            "include_warnings": True,
            "min_confidence_for_api_docs": "low",
            "readme_replacement_gate": "advisory",
            "required_sections": [
                "#",
                "## Installation",
                "## Usage",
                "## Architecture",
                "## License",
            ],
            "min_confidence": "medium",
        },
    }


def merge_configs(default: dict[str, Any], user: dict[str, Any]) -> dict[str, Any]:
    """Deep merge user config into default config."""
    result = default.copy()
    for key, value in user.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_configs(result[key], value)
        else:
            result[key] = value
    return result
