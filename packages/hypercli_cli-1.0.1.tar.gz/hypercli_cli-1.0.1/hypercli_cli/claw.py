"""HyperClaw inference commands"""
import asyncio
import json
from pathlib import Path
from datetime import datetime, timedelta
import typer
from rich.console import Console
from rich.table import Table

from .onboard import onboard as _onboard_fn
from .voice import app as voice_app

app = typer.Typer(help="HyperClaw inference commands")
console = Console()

# Register subcommands
app.command("onboard")(_onboard_fn)
app.add_typer(voice_app, name="voice")

# Check if wallet dependencies are available
try:
    from x402 import x402Client
    from x402.http.clients import x402HttpxClient
    from x402.mechanisms.evm import EthAccountSigner
    from x402.mechanisms.evm.exact.register import register_exact_evm_client
    X402_AVAILABLE = True
except ImportError:
    X402_AVAILABLE = False

HYPERCLI_DIR = Path.home() / ".hypercli"
CLAW_KEY_PATH = HYPERCLI_DIR / "claw-key.json"
DEV_API_BASE = "https://dev-api.hyperclaw.app"
PROD_API_BASE = "https://api.hyperclaw.app"


def require_x402_deps():
    """Check if x402 dependencies are installed"""
    if not X402_AVAILABLE:
        console.print("[red]❌ HyperClaw commands require wallet dependencies[/red]")
        console.print("\nInstall with:")
        console.print("  [bold]pip install 'hypercli-cli[wallet]'[/bold]")
        raise typer.Exit(1)


@app.command("subscribe")
def subscribe(
    plan_id: str = typer.Argument("1aiu", help="Plan ID: 1aiu, 2aiu, 5aiu, 10aiu (default: 1aiu)"),
    amount: str = typer.Argument(None, help="USDC amount to pay (e.g., '25' for $25). Duration scales proportionally."),
    dev: bool = typer.Option(False, "--dev", help="Use dev API (dev-api.hyperclaw.app)")
):
    """Subscribe to a HyperClaw plan via x402 payment.
    
    Duration scales with payment amount (1aiu: $25 = 32 days):
      - $25 → 32 days
      - $12.50 → 16 days
      - $1 → ~1.3 days
    
    Examples:
      hyper claw subscribe 1aiu 25     # Pay $25 for 32 days
      hyper claw subscribe 1aiu 50     # Pay $50 for 64 days
      hyper claw subscribe 5aiu 100    # Pay $100 for 5aiu plan
    """
    require_x402_deps()
    
    # Import wallet helper
    from .wallet import load_wallet
    
    api_base = DEV_API_BASE if dev else PROD_API_BASE
    
    console.print(f"\n[bold]Subscribing to HyperClaw plan: {plan_id}[/bold]\n")
    console.print(f"API: {api_base}")
    if amount:
        console.print(f"Custom amount: [bold]${amount} USDC[/bold]")
    
    # Load wallet
    account = load_wallet()
    console.print(f"[green]✓[/green] Loaded wallet: {account.address}\n")
    
    # Run async subscribe
    result = asyncio.run(_subscribe_async(account, plan_id, api_base, amount))
    
    if result:
        import yaml
        from datetime import datetime
        
        # Save key (current)
        HYPERCLI_DIR.mkdir(parents=True, exist_ok=True)
        with open(CLAW_KEY_PATH, "w") as f:
            json.dump(result, f, indent=2)
        
        # Build history entry with key info
        tx_hash = result.get("tx_hash", "")
        basescan_url = f"https://basescan.org/tx/{tx_hash}" if tx_hash else ""
        
        history_entry = {
            "key": result["key"],
            "plan": result["plan_id"],
            "amount_usdc": result.get("amount_paid", ""),
            "date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "expires": result.get("expires_at", ""),
            "basescan": basescan_url,
            "tpm_limit": result.get("tpm_limit", 0),
            "rpm_limit": result.get("rpm_limit", 0),
        }
        
        # Load existing keys or start fresh
        keys_history_path = HYPERCLI_DIR / "claw-keys.yaml"
        if keys_history_path.exists():
            with open(keys_history_path) as f:
                keys_data = yaml.safe_load(f) or {"keys": []}
        else:
            keys_data = {"keys": []}
        
        keys_data["keys"].append(history_entry)
        
        with open(keys_history_path, "w") as f:
            yaml.dump(keys_data, f, default_flow_style=False, sort_keys=False)
        
        console.print("\n[green]✅ Subscription successful![/green]\n")
        console.print(f"API Key: [bold]{result['key']}[/bold]")
        console.print(f"Plan: {result['plan_id']}")
        console.print(f"Amount paid: [bold]${result.get('amount_paid', 'N/A')} USDC[/bold]")
        console.print(f"Duration: [bold]{result.get('duration_days', 30):.2f} days[/bold]")
        console.print(f"Expires: {result['expires_at']}")
        console.print(f"Limits: {result['tpm_limit']:,} TPM / {result['rpm_limit']:,} RPM")
        console.print(f"\n[green]✓[/green] Key saved to [bold]{CLAW_KEY_PATH}[/bold]")
        console.print(f"[green]✓[/green] Key history: [bold]{keys_history_path}[/bold]")
        console.print("\nConfigure OpenClaw with: [bold]hyper claw openclaw-setup[/bold]")


async def _subscribe_async(account, plan_id: str, api_base: str, amount: str = None):
    """Async helper for x402 payment.
    
    Args:
        account: Ethereum account for signing
        plan_id: Plan to subscribe to
        api_base: API base URL
        amount: Optional custom USDC amount (as string, e.g., "5.00")
    """
    import httpx
    from decimal import Decimal
    from x402.http import x402HTTPClient
    
    # Setup x402 client
    console.print("[bold]Setting up x402 client...[/bold]")
    client = x402Client()
    register_exact_evm_client(client, EthAccountSigner(account))
    http_client = x402HTTPClient(client)
    
    url = f"{api_base}/api/x402/{plan_id}"
    console.print(f"\n[bold]→ Requesting:[/bold] POST {url}\n")
    
    async with httpx.AsyncClient() as http:
        try:
            # Step 1: Make initial request to get 402 response with payment requirements
            response = await http.post(url)
            
            if response.status_code != 402:
                if response.is_success:
                    return response.json()
                console.print(f"\n[red]❌ Unexpected response: {response.status_code}[/red]")
                console.print(response.text)
                raise typer.Exit(1)
            
            console.print(f"[yellow]→[/yellow] Got 402 Payment Required")
            
            # Step 2: Parse payment requirements
            def get_header(name: str) -> str | None:
                return response.headers.get(name)
            
            try:
                body = response.json()
            except:
                body = None
            
            payment_required = http_client.get_payment_required_response(get_header, body)
            
            # Step 3: Modify amount if custom amount specified
            if amount and payment_required.accepts:
                amount_decimal = Decimal(amount)
                amount_smallest = str(int(amount_decimal * Decimal("1000000")))
                console.print(f"[bold]Custom amount:[/bold] ${amount} USDC ({amount_smallest} smallest units)")
                
                # Modify the amount in payment requirements
                # PaymentRequirements is a Pydantic model, so we can modify it
                for req in payment_required.accepts:
                    req.amount = amount_smallest
            else:
                console.print(f"[dim]Using server-requested amount: {payment_required.accepts[0].amount if payment_required.accepts else 'N/A'}[/dim]")
            
            # Step 4: Create payment payload
            console.print("[bold]Creating payment signature...[/bold]")
            payment_payload = await client.create_payment_payload(payment_required)
            
            # Step 5: Encode payment header
            payment_headers = http_client.encode_payment_signature_header(payment_payload)
            console.print(f"[green]✓[/green] Payment signed")
            
            # Step 6: Retry with payment (include JWT if available from claw login)
            jwt_path = HYPERCLI_DIR / "claw-jwt.json"
            if jwt_path.exists():
                try:
                    with open(jwt_path) as f:
                        jwt_data = json.load(f)
                    jwt_token = jwt_data.get("token", "")
                    if jwt_token:
                        payment_headers["Authorization"] = f"Bearer {jwt_token}"
                        console.print("[green]✓[/green] Attaching user auth (from claw login)")
                except Exception:
                    pass

            console.print("[bold]Sending payment...[/bold]")
            retry_response = await http.post(url, headers=payment_headers)
            
            console.print(f"[green]✓[/green] Response status: {retry_response.status_code}")
            
            if retry_response.is_success:
                data = retry_response.json()
                return data
            else:
                console.print(f"\n[red]❌ Payment failed: {retry_response.status_code}[/red]")
                console.print(retry_response.text)
                raise typer.Exit(1)
                
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"\n[red]❌ Error: {e}[/red]")
            import traceback
            traceback.print_exc()
            raise typer.Exit(1)


@app.command("status")
def status():
    """Show current HyperClaw key status"""
    
    if not CLAW_KEY_PATH.exists():
        console.print("[yellow]No HyperClaw key found.[/yellow]")
        console.print("Subscribe with: [bold]hyper claw subscribe <aiu>[/bold]")
        raise typer.Exit(0)
    
    with open(CLAW_KEY_PATH) as f:
        key_data = json.load(f)
    
    # Parse expiry
    expires_at = datetime.fromisoformat(key_data["expires_at"].replace("Z", "+00:00"))
    now = datetime.now(expires_at.tzinfo)
    time_left = expires_at - now
    days_left = time_left.days
    hours_left = time_left.seconds // 3600
    
    console.print("\n[bold]HyperClaw Subscription Status[/bold]\n")
    console.print(f"Plan: [bold]{key_data['plan_id']}[/bold]")
    console.print(f"Key: [dim]{key_data['key'][:20]}...[/dim]")
    
    # Show amount paid and duration if available
    if "amount_paid" in key_data:
        console.print(f"Paid: [bold]${key_data['amount_paid']} USDC[/bold]")
    if "duration_days" in key_data:
        console.print(f"Duration: {key_data['duration_days']:.2f} days")
    
    console.print(f"Expires: {expires_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    
    if days_left > 1:
        console.print(f"Time left: [green]{days_left} days, {hours_left} hours[/green]")
    elif days_left == 1:
        console.print(f"Time left: [yellow]1 day, {hours_left} hours[/yellow]")
    elif time_left.total_seconds() > 0:
        mins_left = time_left.seconds // 60
        console.print(f"Time left: [yellow]{hours_left} hours, {mins_left % 60} minutes[/yellow]")
    else:
        console.print(f"Time left: [red]EXPIRED[/red]")
    
    console.print(f"\nLimits:")
    console.print(f"  TPM: {key_data['tpm_limit']:,}")
    console.print(f"  RPM: {key_data['rpm_limit']:,}")


@app.command("plans")
def plans(
    dev: bool = typer.Option(False, "--dev", help="Use dev API")
):
    """List available HyperClaw plans"""
    import httpx
    
    api_base = DEV_API_BASE if dev else PROD_API_BASE
    url = f"{api_base}/api/plans"
    
    try:
        response = httpx.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
    except Exception as e:
        console.print(f"[red]❌ Failed to fetch plans: {e}[/red]")
        raise typer.Exit(1)
    
    table = Table(title="HyperClaw Plans")
    table.add_column("Plan ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Price", style="yellow")
    table.add_column("Duration", style="blue")
    table.add_column("TPM", style="magenta")
    table.add_column("RPM", style="magenta")
    
    for plan in data.get("plans", []):
        plan_id = plan.get("id", "")
        name = plan.get("name", "")
        price = f"${plan.get('price', 0)}"
        duration = f"{plan.get('duration_days', 30)} days"
        tpm = f"{plan.get('tpm_limit', 0):,}"
        rpm = f"{plan.get('rpm_limit', 0):,}"
        table.add_row(plan_id, name, price, duration, tpm, rpm)
    
    console.print()
    console.print(table)
    console.print()
    console.print("Subscribe with: [bold]hyper claw subscribe <plan_id> <amount>[/bold]")


@app.command("models")
def models(
    dev: bool = typer.Option(False, "--dev", help="Use dev API"),
    json_output: bool = typer.Option(False, "--json", help="Print raw JSON response"),
):
    """List available HyperClaw models from the public /models endpoint."""
    import httpx

    api_base = DEV_API_BASE if dev else PROD_API_BASE
    url = f"{api_base}/models"

    try:
        response = httpx.get(url, timeout=15)
        response.raise_for_status()
        payload = response.json()
    except Exception as e:
        console.print(f"[red]❌ Failed to fetch models from {url}: {e}[/red]")
        raise typer.Exit(1)

    models_data = payload.get("models")
    if not isinstance(models_data, list):
        console.print("[red]❌ Unexpected /models response shape (expected top-level models list)[/red]")
        if json_output:
            console.print_json(json.dumps(payload))
        raise typer.Exit(1)

    if json_output:
        console.print_json(json.dumps(payload))
        return

    table = Table(title="HyperClaw Models")
    table.add_column("Model ID", style="cyan")
    table.add_column("Context", style="blue")
    table.add_column("Vision", style="green")
    table.add_column("Tools", style="green")
    table.add_column("Reasoning", style="magenta")

    for model in models_data:
        model_id = str(model.get("id", ""))
        context_length = model.get("context_length", "")
        vision = "yes" if model.get("supports_vision") else "no"
        tools = "yes" if model.get("supports_tools") else "no"
        reasoning = "yes" if model.get("supports_reasoning") else "no"
        table.add_row(model_id, str(context_length), vision, tools, reasoning)

    console.print()
    console.print(table)
    console.print()
    console.print(f"Source: {url}")


@app.command("login")
def login(
    api_url: str = typer.Option(None, "--api-url", help="API base URL override"),
):
    """Login to HyperClaw with your wallet.

    Signs a challenge message with your wallet key to authenticate,
    then creates a user-bound API key for agent management.

    Prerequisite: hyper wallet create (if you don't have a wallet yet)

    Flow:
      1. Signs a challenge with your wallet private key
      2. Backend verifies signature, creates/finds your user
      3. Creates an API key bound to your user account
      4. Saves the key to ~/.hypercli/claw-key.json

    After login, you can use:
      hyper agents create    Launch an OpenClaw agent pod
      hyper agents list      List your agents
      hyper claw config      Generate provider configs
    """
    try:
        from eth_account.messages import encode_defunct
        from eth_account import Account
    except ImportError:
        console.print("[red]❌ Wallet dependencies required[/red]")
        console.print("Install with: [bold]pip install 'hypercli-cli[wallet]'[/bold]")
        raise typer.Exit(1)

    import httpx

    # Import wallet loader from wallet module
    from .wallet import load_wallet

    base_url = (api_url or PROD_API_BASE).rstrip("/")

    # Step 1: Load wallet
    account = load_wallet()
    console.print(f"\n[green]✓[/green] Wallet: [bold]{account.address}[/bold]\n")

    # Step 2: Get challenge
    console.print("[bold]Requesting challenge...[/bold]")
    with httpx.Client(timeout=15) as client:
        resp = client.post(
            f"{base_url}/api/auth/wallet/challenge",
            json={"wallet": account.address},
        )
        if resp.status_code != 200:
            console.print(f"[red]❌ Challenge failed: {resp.text}[/red]")
            raise typer.Exit(1)
        challenge = resp.json()

    # Step 3: Sign
    console.print("[bold]Signing...[/bold]")
    message = encode_defunct(text=challenge["message"])
    signed = account.sign_message(message)

    # Step 4: Verify signature and login
    console.print("[bold]Authenticating...[/bold]")
    with httpx.Client(timeout=15) as client:
        resp = client.post(
            f"{base_url}/api/auth/wallet/login",
            json={
                "wallet": account.address,
                "signature": signed.signature.hex(),
                "timestamp": challenge["timestamp"],
            },
        )
        if resp.status_code != 200:
            console.print(f"[red]❌ Login failed: {resp.text}[/red]")
            raise typer.Exit(1)
        login_data = resp.json()
        jwt_token = login_data["token"]

    console.print("[green]✓[/green] Authenticated\n")

    user_id = login_data.get("user_id", "")
    team_id = login_data.get("team_id", "")
    wallet_addr = login_data.get("wallet_address", account.address)

    # Step 5: Create a claw API key using the JWT
    console.print("[bold]Creating API key...[/bold]")
    with httpx.Client(timeout=15) as client:
        resp = client.post(
            f"{base_url}/api/keys",
            json={"name": "claw-cli"},
            headers={"Authorization": f"Bearer {jwt_token}"},
        )
        if resp.status_code != 200:
            # Save JWT anyway so user can still auth
            jwt_path = HYPERCLI_DIR / "claw-jwt.json"
            HYPERCLI_DIR.mkdir(parents=True, exist_ok=True)
            with open(jwt_path, "w") as f:
                json.dump({"token": jwt_token, "user_id": user_id, "team_id": team_id}, f, indent=2)
            console.print(f"[yellow]⚠ Key creation failed: {resp.text}[/yellow]")
            console.print(f"[green]✓[/green] JWT saved to {jwt_path} (use for direct auth)")
            raise typer.Exit(1)

        key_data = resp.json()

    api_key = key_data.get("api_key", key_data.get("key", ""))

    # Step 6: Save as claw key
    HYPERCLI_DIR.mkdir(parents=True, exist_ok=True)
    claw_key_data = {
        "key": api_key,
        "plan_id": login_data.get("plan_id", "free"),
        "user_id": user_id,
        "team_id": team_id,
        "wallet_address": wallet_addr,
        "tpm_limit": 0,
        "rpm_limit": 0,
        "expires_at": "",
    }
    with open(CLAW_KEY_PATH, "w") as f:
        json.dump(claw_key_data, f, indent=2)

    console.print(f"[green]✓[/green] API key saved to [bold]{CLAW_KEY_PATH}[/bold]\n")
    console.print(f"  User:    {user_id[:12]}...")
    console.print(f"  Team:    {team_id[:12]}...")
    console.print(f"  Key:     {api_key[:20]}...")
    console.print(f"  Wallet:  {wallet_addr}")
    console.print(f"\n[green]You're all set![/green]")
    console.print(f"  Launch agent:   [bold]hyper agents create[/bold]")
    console.print(f"  Configure:      [bold]hyper claw config openclaw --apply[/bold]")


OPENCLAW_CONFIG_PATH = Path.home() / ".openclaw" / "openclaw.json"


def fetch_models(api_key: str, api_base: str = PROD_API_BASE) -> list[dict]:
    """Fetch available models from LiteLLM /v1/models (served by HyperClaw)."""
    import httpx
    try:
        resp = httpx.get(
            f"{api_base}/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json().get("data", [])
        # Known model metadata (context windows, reasoning, etc.)
        MODEL_META = {
            "kimi-k2.5": {"name": "Kimi K2.5", "reasoning": False, "contextWindow": 262144},
            "glm-5": {"name": "GLM-5", "reasoning": True, "contextWindow": 202752},
        }
        return [
            {
                "id": m["id"],
                "name": MODEL_META.get(m["id"], {}).get("name", m["id"].replace("-", " ").title()),
                "reasoning": MODEL_META.get(m["id"], {}).get("reasoning", False),
                "input": ["text"],
                "contextWindow": MODEL_META.get(m["id"], {}).get("contextWindow", 200000),
            }
            for m in data
            if m.get("id")
        ]
    except Exception as e:
        console.print(f"[yellow]⚠ Could not fetch models from API: {e}[/yellow]")
        console.print("[yellow]  Using fallback model list[/yellow]")
        return [
            {
                "id": "kimi-k2.5",
                "name": "Kimi K2.5",
                "reasoning": False,
                "input": ["text"],
                "contextWindow": 262144,
            },
            {
                "id": "glm-5",
                "name": "GLM-5",
                "reasoning": True,
                "input": ["text"],
                "contextWindow": 202752,
            },
        ]


@app.command("openclaw-setup")
def openclaw_setup(
    default: bool = typer.Option(False, "--default", help="Set hyperclaw/kimi-k2.5 as the default model"),
):
    """Patch OpenClaw config with your HyperClaw API key.

    Reads key from ~/.hypercli/claw-key.json, patches only the
    models.providers.hyperclaw section in ~/.openclaw/openclaw.json.
    Everything else in the config is left untouched.
    """

    # Load HyperClaw key
    if not CLAW_KEY_PATH.exists():
        console.print("[red]❌ No HyperClaw key found.[/red]")
        console.print("Run: [bold]hyper claw subscribe 1aiu <amount>[/bold]")
        raise typer.Exit(1)

    with open(CLAW_KEY_PATH) as f:
        api_key = json.load(f).get("key", "")

    if not api_key:
        console.print("[red]❌ Invalid key file — missing 'key' field[/red]")
        raise typer.Exit(1)

    # Read existing config (or start empty)
    if OPENCLAW_CONFIG_PATH.exists():
        with open(OPENCLAW_CONFIG_PATH) as f:
            config = json.load(f)
    else:
        config = {}

    # Fetch current model list from LiteLLM via API
    models = fetch_models(api_key)

    # Patch only models.providers.hyperclaw
    config.setdefault("models", {}).setdefault("providers", {})
    config["models"]["providers"]["hyperclaw"] = {
        "baseUrl": "https://api.hyperclaw.app/v1",
        "apiKey": api_key,
        "api": "openai-completions",
        "models": models,
    }

    # Optionally set default model
    if default:
        config.setdefault("agents", {}).setdefault("defaults", {}).setdefault("model", {})
        config["agents"]["defaults"]["model"]["primary"] = f"hyperclaw/{models[0]['id']}"

    # Write back
    OPENCLAW_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OPENCLAW_CONFIG_PATH, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    console.print(f"[green]✅ Patched {OPENCLAW_CONFIG_PATH}[/green]")
    console.print(f"   provider: hyperclaw  key: {api_key[:16]}...")
    for m in models:
        console.print(f"   model: hyperclaw/{m['id']}")
    if default:
        console.print(f"   default model: hyperclaw/{models[0]['id']}")
    console.print("\nRun: [bold]openclaw gateway restart[/bold]")


# ---------------------------------------------------------------------------
# hyper claw config — generate / apply provider configs for various tools
# ---------------------------------------------------------------------------

def _resolve_api_key(key: str | None) -> str:
    """Resolve API key from --key flag or ~/.hypercli/claw-key.json."""
    if key:
        return key
    if CLAW_KEY_PATH.exists():
        with open(CLAW_KEY_PATH) as f:
            k = json.load(f).get("key", "")
        if k:
            return k
    console.print("[red]❌ No API key found.[/red]")
    console.print("Either pass [bold]--key sk-...[/bold] or subscribe first:")
    console.print("  [bold]hyper claw subscribe 1aiu[/bold]")
    raise typer.Exit(1)


def _config_openclaw(api_key: str, models: list[dict]) -> dict:
    """OpenClaw openclaw.json provider snippet."""
    return {
        "models": {
            "mode": "merge",
            "providers": {
                "hyperclaw": {
                    "baseUrl": "https://api.hyperclaw.app/v1",
                    "apiKey": api_key,
                    "api": "openai-completions",
                    "models": models,
                }
            }
        },
        "agents": {
            "defaults": {
                "models": {
                    **{f"hyperclaw/{m['id']}": {"alias": m['id'].split('-')[0]} for m in models}
                }
            }
        }
    }


def _config_opencode(api_key: str, models: list[dict]) -> dict:
    """OpenCode opencode.json provider snippet."""
    model_entries = {}
    for m in models:
        model_entries[m["id"]] = {"name": m["id"]}
    return {
        "$schema": "https://opencode.ai/config.json",
        "provider": {
            "hypercli": {
                "npm": "@ai-sdk/openai-compatible",
                "name": "HyperCLI",
                "options": {
                    "baseURL": "https://api.hyperclaw.app/v1",
                    "apiKey": api_key,
                },
                "models": model_entries,
            }
        }
    }


def _config_env(api_key: str, models: list[dict]) -> str:
    """Shell env vars for generic OpenAI-compatible tools."""
    lines = [
        f'export OPENAI_API_KEY="{api_key}"',
        'export OPENAI_BASE_URL="https://api.hyperclaw.app/v1"',
        f'# Available models: {", ".join(m["id"] for m in models)}',
    ]
    return "\n".join(lines)


FORMAT_CHOICES = ["openclaw", "opencode", "env"]


@app.command("config")
def config_cmd(
    format: str = typer.Argument(
        None,
        help=f"Output format: {', '.join(FORMAT_CHOICES)}. Omit to show all.",
    ),
    key: str = typer.Option(None, "--key", "-k", help="API key (sk-...). Falls back to ~/.hypercli/claw-key.json"),
    apply: bool = typer.Option(False, "--apply", help="Write config to the appropriate file (openclaw/opencode only)"),
    dev: bool = typer.Option(False, "--dev", help="Use dev API"),
):
    """Generate provider configs for OpenClaw, OpenCode, and other tools.

    Examples:
      hyper claw config                          # Show all configs
      hyper claw config openclaw                 # OpenClaw snippet
      hyper claw config opencode --key sk-...    # OpenCode with explicit key
      hyper claw config openclaw --apply         # Write directly to openclaw.json
      hyper claw config env                      # Shell export lines
    """
    api_key = _resolve_api_key(key)
    api_base = DEV_API_BASE if dev else PROD_API_BASE

    # Validate key & fetch models
    console.print(f"[dim]Validating key against {api_base}...[/dim]")
    models = fetch_models(api_key, api_base)
    model_names = ", ".join(m["id"] for m in models)
    console.print(f"[green]✓[/green] Key valid — models: [bold]{model_names}[/bold]\n")

    formats = [format] if format else FORMAT_CHOICES
    for fmt in formats:
        if fmt not in FORMAT_CHOICES:
            console.print(f"[red]Unknown format: {fmt}[/red]")
            console.print(f"Choose from: {', '.join(FORMAT_CHOICES)}")
            raise typer.Exit(1)

    for fmt in formats:
        if fmt == "openclaw":
            snippet = _config_openclaw(api_key, models)
            _show_snippet("OpenClaw", "~/.openclaw/openclaw.json", snippet, apply, OPENCLAW_CONFIG_PATH)
        elif fmt == "opencode":
            snippet = _config_opencode(api_key, models)
            target = Path.cwd() / "opencode.json"
            _show_snippet("OpenCode", "opencode.json", snippet, apply, target)
        elif fmt == "env":
            console.print("[bold]── Shell Environment ──[/bold]")
            console.print(_config_env(api_key, models))
            console.print()


def _show_snippet(name: str, path_hint: str, data: dict, apply: bool, target_path: Path):
    """Print a JSON snippet and optionally apply it."""
    console.print(f"[bold]── {name} ({path_hint}) ──[/bold]")
    formatted = json.dumps(data, indent=2)
    console.print(formatted)
    console.print()

    if apply:
        if target_path.exists():
            with open(target_path) as f:
                existing = json.load(f)
            _deep_merge(existing, data)
            merged = existing
        else:
            merged = data

        target_path.parent.mkdir(parents=True, exist_ok=True)
        with open(target_path, "w") as f:
            json.dump(merged, f, indent=2)
            f.write("\n")
        console.print(f"[green]✅ Written to {target_path}[/green]\n")


def _deep_merge(base: dict, overlay: dict):
    """Recursively merge overlay into base (mutates base)."""
    for k, v in overlay.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
