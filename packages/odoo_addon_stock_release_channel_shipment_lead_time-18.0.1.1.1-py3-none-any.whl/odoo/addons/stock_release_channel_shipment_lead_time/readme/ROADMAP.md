Rename "Shipment date" to "Delivery date" as it is misleading
