- Jacques-Etienne Baudoux (BCIM) \<je@bcim.be\>

- [Trobz](https://trobz.com):

  > - Hoang Diep \<hoang@trobz.com\>
