"""ChukTerm - A terminal library with CLI interface."""

__version__ = "0.1.0"

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

__all__ = [
    "__version__",
]
