from __future__ import annotations


def parse_csv_ints(value: str, flag: str) -> list[int]:
    """Parse a non-empty comma-separated integer list.

    Args:
        value: Raw option value.
        flag: Option name used in error messages.

    Returns:
        Parsed integer list.

    Raises:
        ValueError: If list is empty or contains non-integer tokens.
    """

    out: list[int] = []
    for token in value.split(","):
        item = token.strip()
        if not item:
            continue
        if not item.isdigit():
            raise ValueError(f"{flag} contains non-integer token: {item}")
        out.append(int(item))
    if not out:
        raise ValueError(f"{flag} cannot be empty")
    return out


def parse_csv_strings(value: str, flag: str) -> list[str]:
    """Parse a non-empty comma-separated string list.

    Args:
        value: Raw option value.
        flag: Option name used in error messages.

    Returns:
        Parsed string list.

    Raises:
        ValueError: If list is empty after trimming.
    """

    out = [x.strip() for x in value.split(",") if x.strip()]
    if not out:
        raise ValueError(f"{flag} cannot be empty")
    return out


def parse_positive_float(value: str, flag: str) -> float:
    """Parse a strictly positive float option value.

    Args:
        value: Raw option value.
        flag: Option name used in error messages.

    Returns:
        Parsed positive float.

    Raises:
        ValueError: If value is non-numeric or not positive.
    """

    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"{flag} contains non-numeric value: {value}") from exc
    if number <= 0:
        raise ValueError(f"{flag} requires a positive value: {value}")
    return number
