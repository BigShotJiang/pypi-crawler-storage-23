"""Tests for hytop.net.render helpers."""

from __future__ import annotations

from hytop.net.render import format_iface_name


class TestFormatIfaceName:
    def test_keep_name_when_up(self):
        assert format_iface_name("eth0", "up") == "eth0"

    def test_mark_down_state(self):
        assert format_iface_name("eth0", "down") == "eth0 (down)"

    def test_mark_init_state(self):
        assert format_iface_name("mlx5_0/p1", "init") == "mlx5_0/p1 (down)"
