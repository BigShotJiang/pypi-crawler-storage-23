# Shield Engine API

::: policyshield.shield.engine
    options:
      show_source: true
      members:
        - ShieldEngine

::: policyshield.shield.async_engine
    options:
      show_source: true
      members:
        - AsyncShieldEngine
