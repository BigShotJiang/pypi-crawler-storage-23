# 🔥 Tier 1.5 — Security & Data Protection

Защита от утечки чувствительных данных через все каналы: HTTP responses, логи, файлы, auth.

### Secret/Credential Detection 🔴

Есть PII-детектор (email, SSN, IBAN…), но нет детектора **секретов**. Агент случайно передаёт API key, JWT, AWS access key, private key в аргументах — и они утекают.

```yaml
sanitizer:
  secret_detection:
    enabled: true
    patterns: [aws_key, jwt, private_key, api_key, github_token]
    action: BLOCK
```

- **Усилия**: Маленькие (~80 строк, regex-паттерны по аналогии с PII)
- **Ценность**: 🔥🔥🔥 — отдельная категория утечек, PII её не покрывает

### Admin Token Separation (Read vs Write Auth) 🔴

`/api/v1/reload`, `/api/v1/kill`, `/api/v1/respond-approval` используют тот же `POLICYSHIELD_API_TOKEN` что и `/api/v1/check`. Любой клиент с токеном может перезагрузить правила, активировать kill switch, одобрять approvals. Для production нужно минимум два уровня:

```bash
# Read-only (для агентов): check, post-check, constraints, health
POLICYSHIELD_API_TOKEN=agent-token-xxx

# Admin (для ops): reload, kill, resume, respond-approval
POLICYSHIELD_ADMIN_TOKEN=admin-token-yyy
```

- **Усилия**: Маленькие (~30 строк, второй Depends для admin endpoints)
- **Ценность**: 🔥🔥🔥 — принцип наименьших привилегий, иначе компрометация агента = полный контроль

### Sensitive Data в Error Responses 🔴

При необработанном исключении FastAPI возвращает дефолтный `500` с Python stack traces, которые могут содержать:
- пути к файлам на сервере (`/app/policyshield/shield/pii.py:42`)
- содержимое `args` (PII, секреты, API ключи)
- имена внутренних модулей и версии

**Не покрывается** HTTP Error Handler (который про verdict при ошибке). Это про **утечку внутренней информации** через error responses.

```python
# Сейчас при исключении:
# {"detail": "File /app/policyshield/shield/matcher.py, line 87..."}
#
# Нужно: generic error без деталей в production
# {"error": "internal_error", "message": "Check failed"}
```

- **Усилия**: Маленькие (~20 строк, глобальный exception handler + `debug` flag в конфиге)
- **Ценность**: 🔥🔥🔥 — утечка stack traces = утечка внутренней архитектуры, information disclosure vulnerability

### Logging Sensitive Data (Log Sanitization) 🔴

`base_engine.py` при ошибке матчера: `logger.error("Matcher error: %s", e)` — исключение может содержать аргументы инструмента (PII, секреты). Шире: **нет политики что логировать**. `logger.info`, `logger.warning` в разных модулях могут случайно слить чувствительные данные в серверные логи.

**Не покрывается** "Sensitive Data в Error Responses" (та про HTTP ответы). Это про **серверные логи** — другой канал утечки. Если включить JSON logging (из roadmap) и отправлять в ELK/Datadog — args утекут в лог-систему.

```python
# Сейчас: exception может содержать args с PII/секретами
logger.error("Matcher error: %s", e)
# e.args может включать: {"ssn": "123-45-6789", "api_key": "sk-xxx..."}

# Нужно: log filter/sanitizer
class SensitiveDataFilter(logging.Filter):
    def filter(self, record):
        record.msg = sanitize_log_message(record.msg)
        return True
```

- **Усилия**: Маленькие (~30 строк, logging.Filter + sanitize функция)
- **Ценность**: 🔥🔥🔥 — без этого PII/секреты утекают через логи в лог-агрегаторы

### Trace File Permissions 🔴 `v1.0-blocker`

`TraceRecorder` создаёт JSONL файлы с дефолтными permissions ОС (обычно `644`/`rw-r--r--`). Трейсы содержат `args` (включая PII, если `privacy_mode` off). Любой пользователь на сервере может прочитать audit log. Для compliance (SOC 2, GDPR) audit trail должен быть `600`/`rw-------`.

```python
# При создании файла трейсов:
fd = os.open(trace_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
# или после создания:
os.chmod(trace_path, 0o600)  # owner-only read/write
```

- **Усилия**: 1 строка
- **Ценность**: 🔥🔥🔥 — PII в читаемых файлах = data leak по определению

### Admin Rate Limit / Auth Brute-Force Protection 🔴

Нет rate limit на admin endpoints (`/kill`, `/reload`, `/respond-approval`) и нет защиты от brute-force подбора `POLICYSHIELD_API_TOKEN`. Неограниченное количество auth попыток в секунду. Скомпрометированный агент с токеном может спамить `/reload` 1000 раз/сек.

Отдельно от «Rate Limit на HTTP API» (Tier 2) — тут фокус на **admin-операциях и auth**, а не на `/check`.

```yaml
server:
  admin_rate_limit: 10/min    # макс 10 admin-запросов в минуту
  auth_fail_limit: 5/min      # макс 5 неудачных auth попыток → 429
  auth_fail_lockout: 300s     # lockout после превышения
```

- **Усилия**: Маленькие (~30 строк, counter + middleware)
- **Ценность**: 🔥🔥🔥 — без этого brute-force токена неограничен, admin abuse не контролируется
