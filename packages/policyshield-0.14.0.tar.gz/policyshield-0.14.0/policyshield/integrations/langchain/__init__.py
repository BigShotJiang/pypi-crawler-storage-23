"""LangChain integration for PolicyShield."""

from policyshield.integrations.langchain.wrapper import PolicyShieldTool, shield_all_tools

__all__ = ["PolicyShieldTool", "shield_all_tools"]
