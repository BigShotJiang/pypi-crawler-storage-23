"""Integrations with third-party frameworks."""
