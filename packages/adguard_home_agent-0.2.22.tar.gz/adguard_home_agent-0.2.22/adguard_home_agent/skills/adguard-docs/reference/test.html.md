[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
#  AdGuard diagnostics
##  AdGuard Ad Blocker
The best way to get rid of intrusive ads and online tracking and protect your computer from malware. [Learn more](https://adguard.com/en/welcome.html?utm_source=adblock_test_page)
The best way to get rid of intrusive ads and online tracking and protect your computer from malware
Not running
AdGuard Extra
An extension to solve complicated cases when regular ad-blocking rules aren’t enough
App: running
AdGuard Extra
An extension to solve complicated cases when regular ad-blocking rules aren’t enough
An extension to solve complicated cases when regular ad-blocking rules aren’t enough.  How to install
Ad blocking
Blocks ads on the websites you visit
Tracking protection
Blocks online counters and web analytics tools that can be used to track your online activities
Annoyance blocking
Blocks cookie consent forms, popups, online assistant tools, and mobile app banners
Advanced protection
Advanced protection module allows AdGuard to apply advanced filtering rules, such as CSS rules, CSS selectors, and scriptlets, and therefore to deal even with the complex ads, such as YouTube ads.
Extension: running
AdGuard Extra
An extension to solve complicated cases when regular ad-blocking rules aren’t enough
An extension to solve complicated cases when regular ad-blocking rules aren’t enough.  How to install
Ad blocking
Blocks ads on the websites you visit
Tracking protection
Blocks online counters and web analytics tools that can be used to track your online activities
Annoyance blocking
Blocks cookie consent forms, popups, online assistant tools, and mobile app banners
Upgrade available
A full-fledged AdGuard app blocks ads and trackers before the website loads, warns you about dangerous websites, and offers in-app support. [Compare](https://adguard.com/en/compare.html?utm_source=adblock_test_page)
Try for free
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
Upgrade
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
How to install AdGuard Extra
AdGuard Extra is pre-installed in AdGuard for Android, Mac, and Windows
### Chrome or Chromium-based browser
[Stable version](https://agrd.io/adguard_extra_chrome_release)
[Beta](https://agrd.io/adguard_extra_chrome_beta)
### Firefox
[Stable version](https://agrd.io/adguard_extra_firefox_release)
[Beta](https://agrd.io/adguard_extra_firefox_beta)
### Userscript
Install Tampermonkey.
Open Settings and change the mode to Advanced.
Scroll down to Inject Mode and change it to Instant.
Install AdGuard Extra:
[Stable version](https://userscripts.adtidy.org/release/adguard-extra/1.0/adguard-extra.user.js)
[Beta](https://userscripts.adtidy.org/beta/adguard-extra/1.0/adguard-extra.user.js)
Close
##  AdGuard VPN
The ultimate choice for staying anonymous and safe online while accessing the content you want. [Learn more](https://adguard-vpn.com/welcome.html?utm_source=adblock_test_page&_plc=en)
Not running
IP: 2a09:bac5:bed2:65a::a2:59
Location: United States, Austin
[ Try for free ](https://adguard-vpn.com/download.html?auto=1&utm_source=adblock_test_page&_plc=en)
By downloading the program you accept the terms of the [License agreement](https://adguard-vpn.com/eula.html?_plc=en)
##  AdGuard DNS
An exceptional service that blocks ads and protects every device on your network. [Learn more](https://adguard-dns.io/welcome.html?utm_source=adblock_test_page&_plc=en)
An exceptional service that blocks ads and protects every device on your network
AdGuard DNS can’t recognize your device and apply device-specific rules. Please reconfigure it on your [dashboard](https://adguard-dns.io/dashboard/?_plc=en)
Private server: running
Public server: running
Not running
PQC: enabled
[ View prices ](https://adguard-dns.io/license.html?utm_source=adblock_test_page&_plc=en)[ Try for free ](https://adguard-dns.io/welcome.html?utm_source=adblock_test_page&_plc=en)
[ Check again ](https://adguard.com/en/test.html)
Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
