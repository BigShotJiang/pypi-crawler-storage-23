[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
20,009 20009 user reviews
Excellent!
Surf the Web ad-free and safely. Shields up!
Blocks all kinds of ads  Removes annoying web elements  Saves traffic and speeds up page loading  Works for browsers and apps  Maintains site functionality and appearance
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
App StoreDownload
macOS app  Windows app  Android app  iOS app [](https://adguard.com/en/download-extension/chrome.html)
Watch video
![Agnar](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'/%3E)
AdGuard for WindowsAdGuard for MacAdGuard for AndroidAdGuard for iOSAdGuard Content BlockerAdGuard Browser ExtensionAdGuard AssistantAdGuard HomeAdGuard Pro for iOSAdGuard Mini for MacAdGuard for Android TVAdGuard for LinuxAdGuard Temp MailAdGuard VPNAdGuard DNSAdGuard MailAdGuard Wallet
AdGuard for Windows  AdGuard for Mac  AdGuard for Android  AdGuard for iOS  AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail [ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en) AdGuard Wallet
Windows  Mac  Android  iOS
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail  AdGuard VPN  AdGuard DNS  AdGuard Mail  AdGuard Wallet
Other products
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail [ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en) AdGuard Wallet
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_enabled_light-v2.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_disabled_light-v3.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_statistics_screen_light-v3.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_screen_light-v3.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Windows
AdGuard for Windows is more than an ad blocker. It is a multipurpose tool that blocks ads, controls access to dangerous sites, speeds up page loading, and protects children from inappropriate content.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[](https://agrd.io/msstore)
AdGuard for Windows v7.22, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mac/mac_enabled_light-v2.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mac/mac_disabled_light-v3.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Mac
AdGuard for Mac is a unique ad blocker designed with macOS in mind. In addition to protecting you from annoying ads in browsers and apps, it shields you from tracking, phishing, and fraud.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-mac/overview.html?source=ag_products_page)
AdGuard for Mac v2.18, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_filters_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_statistics_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_incognito_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Android
AdGuard for Android is a perfect solution for Android devices. Unlike most other ad blockers, AdGuard doesn't require root access and provides a wide range of app management options.
Scan QR code
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-android/overview.html?source=ag_products_page)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
Scan to download
Use any QR-code reader available on your device
Close
AdGuard for Android v4.12, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_statistics_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_enabled_light-v5.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_qr_light.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for iOS
The best iOS ad blocker for iPhone and iPad. AdGuard eliminates all kinds of ads in Safari, protects your privacy, and speeds up page loading. AdGuard for iOS ad-blocking technology ensures the highest quality filtering and allows you to use multiple filters at the same time
Scan QR code
App Store
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-ios/overview.html?source=ag_products_page)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_qr_light.svg)
Scan to download
Use any QR-code reader available on your device
Close
AdGuard for iOS v4.5
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/adguard.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/settings.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/filters.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Content Blocker
AdGuard Content Blocker eliminates all kinds of ads in mobile browsers that support content-blocking technology — namely, Samsung Internet and Yandex Browser. Its features are limited compared to AdGuard for Android, but it is free, easy to install, and efficient
Google Play
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-content-blocker/overview.html?source=ag_products_page)
AdGuard Content Blocker v2.8
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/blocked1.svg?nc=1)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/disabled1.svg?nc=1)
20,009 20009 user reviews
Excellent!
##  AdGuard Browser Extension
AdGuard is the fastest and most lightweight ad blocking extension that effectively blocks all types of ads on all web pages! Choose AdGuard for the browser you use and get ad-free, fast and safe browsing.
[ Install ](https://adguard.com/en/download-extension/chrome.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/firefox.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/edge.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/opera.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/yandex.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-browser-extension/overview.html?source=ag_products_page)
[ Read more ](https://adguard.com/en/adguard-browser-extension/overview.html?source=ag_products_page)
AdGuard Browser Extension v5.3
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/assistant/enabled.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/assistant/filtering.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Assistant
A companion browser extension for [AdGuard desktop apps](https://adguard.com/products.html?_plc=en). It allows you to block custom items on websites, add websites to allowlist, and send reports directly from your browser
[ Read more ](https://adguard.com/en/adguard-assistant/overview.html?source=ag_products_page)
AdGuard Assistant v1.4
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/home/adguard_home.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Home
AdGuard Home is a network-based solution for blocking ads and trackers. Install it once on your router to cover all devices on your home network — no additional client software required. This is especially important for various IoT devices that often pose a threat to your privacy
[ Read more ](https://adguard.com/en/adguard-home/overview.html?source=ag_products_page)
AdGuard Home v0.107
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/enabled.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/filters.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/adguard.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Pro for iOS
AdGuard Pro for iOS comes with all the advanced ad-blocking protection features enabled. It offers the same tools as the paid version of AdGuard for iOS. It excels at blocking ads in Safari and lets you customize DNS settings to tailor your protection. It blocks ads in browsers and apps, protects your kids from inappropriate content, and keeps your personal data safe
App Store
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-ios-pro/overview.html?source=ag_products_page)
AdGuard Pro for iOS v4.5
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_create_rule_light.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_extension_light.svg?nc=true)
20,009 20009 user reviews
Excellent!
##  AdGuard Mini for Mac — Safari ad blocker
AdGuard Mini for Mac is a powerful Safari ad blocker. This lightweight app removes ads, blocks trackers, and speeds up page loading. It helps you browse the Web in Safari without distractions and keep your data private
[ Install ](https://agrd.io/adguard_mini_for_mac)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-mini-mac/overview.html?source=ag_products_page)
AdGuard Mini for Mac v2.1
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/enabled.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/ad_blocking.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/settings.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/app_managment.svg?nc=true)
20,009 20009 user reviews
Excellent!
##  AdGuard for Android TV
AdGuard for Android TV is the only app that blocks ads, guards your privacy, and acts as a firewall for your Smart TV. Get warnings about web threats, use secure DNS, and benefit from encrypted traffic. Relax and dive into your favorite shows with top-notch security and zero ads!
[ Read more ](https://adguard.com/en/adguard-android-tv/overview.html?source=ag_products_page)
AdGuard for Android TV v4.12, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/linux/agnar-linux.svg?nc=1)
20,009 20009 user reviews
Excellent!
##  AdGuard for Linux
AdGuard for Linux is the world’s first system-wide Linux ad blocker. Block ads and trackers at the device level, select from pre-installed filters, or add your own — all through the command-line interface
[ Read more ](https://adguard.com/en/adguard-linux/overview.html?source=ag_products_page)
AdGuard for Linux v1.3
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/temp_mail/temp_mail.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Temp Mail
A free temporary email address generator that keeps you anonymous and protects your privacy. No spam in your main inbox!
[ Read more ](https://adguard.com/en/adguard-temp-mail/overview.html?source=ag_products_page)
![](https://cdn.adguardcdn.com/website/adguard.com/products/vpn/connected.png)
![](https://cdn.adguardcdn.com/website/adguard.com/products/vpn/exclusions.png)
20,009 20009 user reviews
Excellent!
##  AdGuard VPN
60 locations worldwide
Access to any content
Strong encryption
No-logging policy
Fastest connection
24/7 support
[ Try for free ](https://adguard-vpn.com/download.html?auto=1&_plc=en)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard-vpn.com/en/what-is-vpn.html?_plc=en&source=ag_products_page)
![](https://cdn.adguardcdn.com/website/adguard.com/products/dns/diana.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/dns/dns.png)
20,009 20009 user reviews
Excellent!
##  AdGuard DNS
AdGuard DNS is a foolproof way to block Internet ads that does not require installing any applications. It is easy to use, absolutely free, easily set up on any device, and provides you with minimal necessary functions to block ads, counters, malicious websites, and adult content.
[ Read more ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mail/aliases2.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Mail
Protect your identity, avoid spam, and keep your inbox secure with our aliases and temporary email addresses. Enjoy our free email forwarding service and apps for all operating systems
[ Use web version ](https://app.adguard-mail.com/?_plc=en)[ Microsoft Store ](https://agrd.io/agmail_msstore)[ App Store ](https://agrd.io/agmail_appstore)[ App Store ](https://agrd.io/agmail_appstore)[ Google Play ](https://agrd.io/agmail_playstore)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/wallet/main1.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Wallet
A secure and private crypto wallet that gives you full control over your assets. Manage multiple wallets and discover thousands of cryptocurrencies to store, send, and swap
[ Read more ](https://adguard.com/en/crypto-wallet/overview.html?source=ag_products_page)
  * **Ad blocking**
AdGuard Ad Blocker wipes out annoying banners, pop-ups, and video ads
  * **Privacy protection**
AdGuard Ad Blocker shields your data from web analytics and online trackers
  * **Browsing security**
AdGuard Ad Blocker protects against phishing and malicious sites
  * **Parental control**
AdGuard Ad Blocker shields children from inappropriate and adult content


# Try AdGuard — it will exceed your expectations
Join the 160 million users who are protecting their privacy with AdGuard products!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[Microsoft Store](https://agrd.io/msstore)
Total app rating 4.7/5
More than 20,000 app reviews! We love our users and they love us back
20,009 20009 user reviews
Excellent!
Flomyir [](https://itunes.apple.com/US/app/id1126386264) Great blocking solution all things considered
Randy Duke [](https://chromewebstore.google.com/detail/adguard-adblocker/bgnkhhnnamicmpeenaelnjfhikgbkllg/reviews) By far, for me, I consider AdGuard THE best ad blocker out there. Great product!
Mulindwa Christian [](https://chromewebstore.google.com/detail/adguard-adblocker/bgnkhhnnamicmpeenaelnjfhikgbkllg/reviews) best extension ever. i recommend it it even tells you want you want it to do all in one.
necrobarista lover19 [](https://itunes.apple.com/US/app/id1126386264) I hate the million of ads while browsing hentai this is what the internet should be
Rimon Dutta  AdGuard works great. It blocks ads well and doesn’t break websites. Browsing feels faster and cleaner. Easy to use and very reliable. Highly recommended.
milly buxx [](https://play.google.com/store/apps/details?id=com.adguard.android.contentblocker) -To Adguard or not to Adguard? that is not even a question! (Anonymous) -It's an unmistakable sign of higher intelligence to Adguard an android-[de]based smartphone. (Anonymous) -Adguard makes cyberspace a better place. (Anonymous)
## Rate AdGuard
BadPoorAverageGreatExcellent!
Your name
Your review
0/511
I accept the [Privacy policy](https://adguard.info/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.info/terms-and-conditions.html?_plc=en) of AdGuard websites
Send
![](https://adguard.com/stcdn/website/adguard.com/agnar/agnar_thumbs_up_raven.svg)
Thank you! You’ve helped us become a bit better
##  Failed to send review
Please try again or contact support
Close
![AdGuard product video](https://cdn.adguardcdn.com/website/adguard.com/video/welcome/video-preview-en.png)
##  Why AdGuard?
App
Extension
Blocks ads on websites
Removes popups, banners, text ads, and video ads
Full-fledged AdGuard app
Yes
Common ad-blocking extension
Yes
Hides empty spaces after ads
Keeps pages looking good after removing ads
Full-fledged AdGuard app
Yes
Common ad-blocking extension
Partly
Prevents tracking
Doesn’t let websites and companies collect your personal data and use it against you
Full-fledged AdGuard app
Yes
Common ad-blocking extension
Partly
Speeds up page loading
Blocks ads and trackers even before the page loads
Full-fledged AdGuard app
Yes
Common ad-blocking extension
Partly
Works in browsers and apps
Eliminates ads, trackers, and annoyances in all browsers and apps on your device
Full-fledged AdGuard app
Yes
Common ad-blocking extension
No
Offers in-app customer support
Lets you contact our helpful support team directly from the app
Full-fledged AdGuard app
Yes
Common ad-blocking extension
No
##  FAQ
  * An ad blocker is a program designed to make the Web cleaner and safer and protect your privacy. AdGuard blocks pop-up ads, banners, and video ads — even on YouTube. It removes cookies and tracking requests. It knows what websites are dangerous and ensures you don’t visit any of them.
  * Most ad blockers are browser extensions that can’t remove all types of ads. If you’re using more than one browser, you’ll need to install an ad-blocking extension for each of them. And if you want to block ads in apps, you just won’t be able to.
AdGuard offers apps for Android, iOS, Windows, and Mac. With them, you can block ads in browsers and apps, prevent websites and companies from tracking you, and protect yourself from phishing and malware. AdGuard also speeds up page loading, allows you to manage DNS servers and web requests, and has in-app support. You can learn more from our [comparison table](https://adguard.com/en/compare.html).
  * We have apps for all popular platforms. AdGuard for Windows, Mac, and Android can be downloaded directly from this page. AdGuard for iOS is available on the App Store. Installation shouldn't be a problem, but you can always check the instructions in our [Knowledge base](https://adguard.com/kb/general/license/activation/).
  * Our full-fledged apps for Windows, Mac, and Android offer you a free trial — that’s how you can discover all the features AdGuard has to offer.
Our apps for Android and iOS also have free versions. They can be helpful as well: the free version of AdGuard for Android can block ads in browsers, and the free version of AdGuard for iOS blocks ads and trackers in Safari. But their functionality is limited: to block ads in apps, control DNS requests, protect yourself from malicious domains, and more, you’ll need a full version.
AdGuard also has completely free browser extensions. To learn more about the difference between the AdGuard extensions and full-fledged apps, check out our [comparison table](https://adguard.com/en/compare.html).
  * Sure! AdGuard supports all popular platforms: Android, iOS, Windows, and Mac. The best way to use AdGuard on multiple devices is to [buy a license](https://adguard.com/en/license.html), download the AdGuard app for the needed platform, and log in to it with your license key or AdGuard account credentials.
  * You don’t necessarily have to buy a license to use AdGuard. But here are some ideas about how it can make your life better:
A license gives you access to advanced features of AdGuard for Android or iOS: ad blocking in apps, DNS protection, firewall, statistics, app management, and others. It also allows you to use AdGuard for Windows and Mac.
With a license, you can use AdGuard on multiple devices and thus protect your family and friends.
If you like AdGuard, that’s how you can support us.


  * Sure! You can buy a license on a [special page](https://adguard.com/en/gift-license.html) and enter the recipient's email — we'll send them a license with a nice gift card. Discounts are applied to gift licenses, too.
  * We’ve been developing privacy-oriented products since 2009 and have more than 160 million users worldwide. We never share your personal information with anyone and only collect strictly necessary data to run our websites and apps. You can read more in our [Privacy policy](https://adguard.com/en/website-privacy.html).
  * If you want to know more about how exactly AdGuard products work, what filters are, how to create your own filtering rules, and more, check out our [Knowledge base](https://adguard.com/kb/). For industry news, AdGuard releases, and promos, you can visit our [blog](https://adguard.com/en/blog/index.html). And if you’d like, you can watch our explanatory videos on AdGuard’s [YouTube channel](https://www.youtube.com/@AdGuardEN) or follow us on social media.
  * You can share AdGuard with your friends. Whether you buy more licenses and connect your loved ones to AdGuard, [buy a license as a gift](https://adguard.com/en/gift-license.html), share our posts on social networks, or just advise our products to someone you care about — we’re always glad to show more people how beautiful the safe and ad-free Web is.
You can rate us in app stores and on our website. That’s how we know we’re on the right track.
You can also [become our contributor](https://adguard.com/en/contribute.html): maybe you’re good at translating, know how to improve our filters or the Knowledge base, or want to become a beta tester? We are grateful to our contributors and reward them in return — with AdGuard licenses and gifts.
  * For any questions, you can always contact us at support@adguard.com.


##  Make your favorite browser ad-free!
Block ads in Chrome with AdGuard
Block ads in Mozilla Firefox with AdGuard
Block ads in Safari with AdGuard
Block ads in Edge with AdGuard
Block ads in Opera with AdGuard
Block ads in Yandex Browser with AdGuard
[ Install ](https://adguard.com/en/download-extension/chrome.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/firefox.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/safari.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/edge.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/opera.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/yandex.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
Why it is worth installing AdGuard for Chrome
Remove pop-up ads, banners, and video ads
Protect your personal data from web trackers
Get alerted about malicious and dangerous websites
Speed up page loading by removing unnecessary elements
Why it is worth installing AdGuard for Firefox
Block all kinds of ads before they’re loaded: annoying banners, popups, and video ads — even on YouTube!
Protect your personal data from online counters and trackers
Block phishing and malicious websites
Speed up page loading by removing unnecessary elements
Why it is worth installing AdGuard for Safari
Remove all kinds of ads: banners, text ads, flash animation, pre-rolls, and popups
Never let anyone track your online activity
Protect yourself from phishing or fraud — get notified about dangerous websites
Reduce page loading time by removing all unnecessary elements
Why it is worth installing AdGuard for Edge
Block banners, text ads, popups, and video ads
Block online counters and tracking mechanisms
Rest assured that you won’t visit pages that may harm your computer or attempt to trick you
Reduce bandwidth usage and boost your web browsing speed
Why it is worth installing AdGuard for Opera
Block all ads in Opera, including popups, banners, videos, and animated ads
Protect your personal data by blocking all known tracking systems
Block spyware and adware installers
Speed up page loading and save bandwidth by blocking ads
Why it is worth installing AdGuard for Yandex Browser
Remove banners, popups, and irritating video preloads on YouTube
Keep your personal data intact by blocking all known counters and analytics
Protect yourself from malicious, phishing, and fraudulent websites
Load web pages faster by blocking ads
[ Install ](https://adguard.com/en/download-extension/chrome.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/firefox.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/safari.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/edge.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/opera.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://adguard.com/en/download-extension/yandex.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
##  Latest news
  * ### [ AdGuard for Windows v7.22.4: Meet SockFilter, our new experimental network driver ](https://adguard.com/en/blog/adguard-for-windows-v7-22-4.html)
Feb 26, 2026
AdGuard for Windows v7.22.4 introduces SockFilter, our new network driver. While still experimental, it has the potential to make AdGuard better.
  * ### [ AdGuard CLI v1.3: DNS filtering and ECH support ](https://adguard.com/en/blog/adguard-v1-3-cli.html)
Feb 26, 2026
DNS filtering and Encrypted ClientHello support, along with userscripts, userstyles, and a more consistent update workflow.
  * ### [ #KeepAndroidOpen: AdGuard urges Google to rethink policy that could restrict independent Android app distribution ](https://adguard.com/en/blog/google-android-app-verification-requirement-petition.html)
Feb 25, 2026
AdGuard urges Google to rethink policy that could restrict independent Android app distribution
  * ### [ YouTube finds a brand new way to bother users of ad blockers ](https://adguard.com/en/blog/youtube-missing-comments-descriptions.html)
Feb 21, 2026
YouTube comes up with a new way to strike at the users of ad blockers — now by hiding the comment and descriptions of all videos. How will ad blockers respond?

[ Read more ](https://adguard.com/en/blog/index.html)
##  All done!  Something went wrong  Subscribe to our news
You’ve successfully subscribed to AdGuard news. Emails will be sent to
You can also subscribe using a different email address
Please try again. If it doesn’t help, please [contact support](https://adguard.com/en/%mailto%)
Be the first to get the latest news about online privacy and ad blocking, AdGuard product releases, upcoming sales, giveaways, and more
Email
Please enter a valid email address
Subscribe
I accept the [Privacy policy](https://adguard.com/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.com/terms-and-conditions.html?_plc=en) of AdGuard websites
Invalid captcha
Captcha is required
Try again
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_all_done.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_something_went_wrong.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_subscription.svg)
##  AdGuard in the news
  * [ Read more ](https://adguard.com/en/press-releases.html)


AdGuard review
AdGuard is a robust, widely compatible ad blocker. We recommend it to anyone seeking a good ad-blocking tool.
[ Learn more ](https://www.techradar.com/reviews/adguard)
Hacked websites could be using your computer to mine cryptocurrency
According to a recent report from AdGuard, more than 200 of the top 100,000 sites on the web were hosting suspicious code. That may not seem like a big deal, but even sites near the bottom of that list draw a huge amount of traffic. The most popular one on AdGuard's list regularly pulls in around 60 million visits every month.
In total, AdGuard discovered cryptocurrency mining code on 220 sites over a three-week period. During that time around 500 million users unknowingly ran that code on their computers.
[ Learn more ](https://www.forbes.com/sites/leemathews/2017/10/31/hacked-websites-could-be-using-your-computer-to-mine-cryptocurrency/#14a46ffa7250)
Bitcoin mining on track to consume all of the world’s energy by 2020
More than half a billion people may be inadvertently mining cryptocurrencies from their computers, smartphones and other devices, according to research conducted earlier this year by ad blocking firm AdGuard.
“How much money have these websites made? We estimate their joint profit at over $43,000,” the AdGuard researchers said in an October blogpost that detailed their discovery. At the time, one bitcoin was worth around $5,000.
[ Learn more ](http://www.newsweek.com/500-million-pcs-secretly-mining-cryptocurrency-research-bitcoin-683982)
Billions of video site visitors unwittingly mine cryptocurrency as they watch
The video sites Openload, Streamango, Rapidvideo and OnlineVideoConverter are allegedly loading mining software on to visitors’ computers, making them generate tokens for the bitcoin-like cryptocurrency Monero, according to security firm Adguard.
“We came across several very popular websites that secretly use the resources of users’ devices for cryptocurrency mining,” said Andrey Meshkov, co-founder of Adguard. “According to SimilarWeb, these four sites register 992m visits monthly.”
[ Learn more ](https://www.theguardian.com/technology/2017/dec/13/video-site-visitors-unwittingly-mine-cryptocurrency-as-they-watch-report-openload-streamango-rapidvideo-onlinevideoconverter-monero)
Why hackers love cryptocurrency miner coinhive
Although the developers aren't saying how much money they've made from their idea, online ad-blocking service AdGuard also found the Coinhive miner on over 30,000 sites and estimates the code generates $150,000 in Monero every month. For Coinhive, which takes a 30 percent cut, that amounts to $540,000 per year.
[ Learn more ](https://www.pcmag.com/news/357535/why-hackers-love-cryptocurrency-miner-coinhive)
You could be secretly mining bitcoins without even knowing it
Popular video sites including Openload, Streamango, Rapidvideo and OnlineVideoConverter are also allegedly loading mining software on to visitors' computers, according to security firm Adguard.
"We came across several very popular websites that secretly use the resources of users’ devices for cryptocurrency mining," said Andrey Meshkov, co-founder of Adguard. "According to SimilarWeb, these four sites register 992m visits monthly."
[ Learn more ](https://www.mirror.co.uk/tech/you-could-secretly-mining-bitcoins-11693723)
4 ad blockers that still work with Chrome
AdGuard will flat-out refuse to connect to websites known to be malicious for phishing attacks or spreading malware, and it’s good at collapsing the elements of the page that normally display ads, making formatting much less cluttered.
[ Learn more ](https://www.pcworld.com/article/2429437/four-ad-blockers-that-still-work-with-chrome.html)
##  More than 160 million users choseAdGuard products
They visit all sorts of websites without compromising their privacy
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[Microsoft Store](https://agrd.io/msstore)
Other AdGuard products
Give a boost to your privacy protection: block ads and trackers, stay anonymous, control your web traffic, or declutter your inbox with AdGuard products
[ AdGuard VPN  Makes you anonymous and your traffic inconspicuous ](https://adguard-vpn.com/welcome.html?source=ag_products_page&_plc=en)[ AdGuard DNS  Helps control web traffic on all your devices ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail  Hides your email address ](https://adguard-mail.com/welcome.html?source=ag_products_page&_plc=en)
Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
