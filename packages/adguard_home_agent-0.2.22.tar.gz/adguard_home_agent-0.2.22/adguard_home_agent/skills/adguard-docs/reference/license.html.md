[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


The promo code [Subscribe to our news](https://adguard.com/en/blog/index.html) to be notified of future sales!
20,009 20009 user reviews
Excellent!
Available platforms:
Protect your device at the system level with AdGuard for Windows
Block pop-up ads, video ads, and banners anywhere on your device with AdGuard for Mac
Get a top-notch tool to block ads and trackers and manage all apps’ traffic with AdGuard for Android
Enjoy an Internet free of ads and trackers with AdGuard for iOS
Watch your favorite movies and TV shows ad-free with AdGuard for Android TV
#  Purchase
Protect all your devices and surf the Web safely!
1 year  Lifetime
Personal Up to 3 devices Up to 9 devices
$2.49 /mo $29.88
Best choice
Billed annually
Billed annually, VAT may apply
One-time payment
VAT may apply, one-time payment
Choose
Family Up to 3 devices Up to 9 devices
$5.49 /mo $65.88 $7.47 /mo $89.64 27% discount
27% discount Best choice
Billed annually
Billed annually, VAT may apply
One-time payment
VAT may apply, one-time payment
Choose
$2.49 /mo$29.88
Billed annually
Billed annually, VAT may apply
One-time payment
VAT may apply, one-time payment
Choose
We accept:
![](https://cdn.adguardcdn.com/website/adguard.com/svg/icons/money_license.svg)![](https://cdn.adguardcdn.com/website/adguard.com/svg/icons/safe_transaction_license.svg)![](https://cdn.adguardcdn.com/website/adguard.com/svg/icons/support_license.svg)
Total app rating 4.7/5
More than 20,000 app reviews! We love our users and they love us back
20,009 20009 user reviews
Excellent!
Flomyir [](https://itunes.apple.com/US/app/id1126386264) Great blocking solution all things considered
Randy Duke [](https://chromewebstore.google.com/detail/adguard-adblocker/bgnkhhnnamicmpeenaelnjfhikgbkllg/reviews) By far, for me, I consider AdGuard THE best ad blocker out there. Great product!
Mulindwa Christian [](https://chromewebstore.google.com/detail/adguard-adblocker/bgnkhhnnamicmpeenaelnjfhikgbkllg/reviews) best extension ever. i recommend it it even tells you want you want it to do all in one.
necrobarista lover19 [](https://itunes.apple.com/US/app/id1126386264) I hate the million of ads while browsing hentai this is what the internet should be
Rimon Dutta  AdGuard works great. It blocks ads well and doesn’t break websites. Browsing feels faster and cleaner. Easy to use and very reliable. Highly recommended.
milly buxx [](https://play.google.com/store/apps/details?id=com.adguard.android.contentblocker) -To Adguard or not to Adguard? that is not even a question! (Anonymous) -It's an unmistakable sign of higher intelligence to Adguard an android-[de]based smartphone. (Anonymous) -Adguard makes cyberspace a better place. (Anonymous)
##  FAQ
  * You can choose how many devices you want to protect:
Personal license covers 3 devices
Family license covers 9 devices
You can also choose between 1-year and lifetime licenses.
AdGuard licenses are universal and work on any device (Windows, macOS, Android, or iOS).
  * We’ve emailed you your license info and further instructions.
The next step is to activate AdGuard on your device. Check out our [Knowledge base](https://adguard.com/kb/general/license/activation/) for detailed instructions.
  * To use your license on a new device, first remove it for the current device in the License section of your app or in your [AdGuard account](https://adguard.com/go?hash=8e1f87f3fe17f92b795f504d97a2c69d&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2Fproduct%2Fadblocker%3F_plc%3Den). Then activate your license on the new device. Check out our [Knowledge base](https://adguard.com/kb/general/license/transfer/#how-to-transfer-a-license-to-another-device) for detailed instructions.
  * If you need to protect more than 3 devices, you can upgrade to the Family license.
Log in to your [AdGuard account](https://adguard.com/go?hash=8d929c4840fd60c0d60c6075e6bdf5c6&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2Flicenses%3F_plc%3Den) and click Increase device limit.
Or go directly to our [Extend or upgrade](https://adguard.com/en/renew.html) page and enter your activation code manually. Then select the license parameters and follow the on-screen instructions.
Alternatively, you can simply purchase another Personal license.
  * You can always see your activation codes in your [AdGuard account](https://adguard.com/go?hash=8d929c4840fd60c0d60c6075e6bdf5c6&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2Flicenses%3F_plc%3Den) linked to the email address you used for the purchase.
  * Subscriptions purchased from the AdGuard website are renewed automatically.
However, if you’d like to manually renew your license, or if you purchased an AdGuard license from a reseller, try one of the following options:
In your AdGuard app, find the License tab and click Renew.
In your AdGuard account, go to [Licenses](https://adguard.com/go?hash=8d929c4840fd60c0d60c6075e6bdf5c6&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2Flicenses%3F_plc%3Den). Find the license that’s about to expire and click Extend.
On our website, go to the [Extend or upgrade](https://adguard.com/en/renew.html) page, enter your activation code, and click Apply.
  * There are several ways to get premium features in AdGuard for iOS:
1. Buy a subscription from the App Store. In the app, tap Try for free and follow the on-screen instructions. You don’t have to pay right away — try Premium for free for 7 days before purchasing a subscription.
2. Use an existing AdGuard license. In AdGuard for iOS, go to Settings → License and click Log in. Enter your AdGuard account credentials. Alternatively, you can enter your activation code directly in the email field.
3. Get AdGuard Pro. This is our paid iOS app that comes with premium features already enabled.
  * Most ad blockers are browser extensions that are not technically capable of removing all types of ads. AdGuard can block ads in all browsers and even apps. In addition to ad blocking, AdGuard gives you a lot of [extra tools](https://adguard.com/en/compare.html).


  * You can cancel your subscription in your AdGuard account:
Go to your [AdGuard account](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den).
Go to the [Licenses](https://adguard.com/go?hash=8d929c4840fd60c0d60c6075e6bdf5c6&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2Flicenses%3F_plc%3Den) tab.
Click Cancel subscription for the subscription you no longer need.
The canceled subscription will be valid until its expiry date.
For information on managing AdGuard subscriptions, please visit our [Knowledge base](https://adguard.com/kb/general/license/what-is/).
  * We have a 60-day money-back guarantee. If you request a refund within 60 days of your purchase, you can get your money back. To request a refund, contact us at support@adguard.com.
  * This is the official AdGuard website, which uses a secure HTTPS connection between you and our servers. You can check the security of your connection in your browser.
All transactions are processed through [Paddle](https://www.paddle.com/) and [PayPro Global](https://payproglobal.com/). You can review their privacy policies for information on data and transaction security.
We also have a money-back guarantee. If you don’t like AdGuard, you can request a refund within 60 days of purchase.
  * To purchase a license for more than 9 devices, please contact us at sales@adguard.com.
  * Follow [our blog](https://adguard.com/en/blog/index.html) for the latest news and announcements. We regularly run promotions with discounts.
  * If you have any questions, you can contact us 24/7 at support@adguard.com. It’s a good idea to check our FAQ first: it contains answers to 90% of user questions.
  * Sure! You can buy a gift license on a [special page](https://adguard.com/en/gift-license.html) of our website. Just enter the recipient’s email address and we’ll send them the license along with a nice gift card. You can also apply discounts to gift licenses.


Back to purchase
USD
EURUSD
Have a promo code? Cancel
Family license  Personal license
By continuing, you accept our [EULA](https://adguard.com/en/eula.html), [Privacy policy](https://adguard.com/en/privacy.html), and [Terms and conditions](https://adguard.com/en/terms-and-conditions.html)
Payment method
Bank cardBank card/AliPayBank card/PayPalCryptocurrency
Bank cardBank card/AliPayBank card/PayPalCryptocurrency
Licenses purchased with cryptocurrency are not auto-renewed. We recommend choosing a longer license term so you don't have to extend it too often
Enter your email — your license key and receipt will be sent there.  Your license will be sent to this email
gmail.comoutlook.comyahoo.com
Please check the email: it looks incorrect  Please fill out the field
Did you mean:
Proceed
Receive emails about AdGuard sales, product releases, and industry news
Your license
Total **undefined**
Proceed
Payments may take up to 1 hour to process. You’ll get an email confirmation once the payment gets posted to your account.
You will be billed in dollars
Upgrade
Have a promo code?
Promo code
Promo code doesn't exist
Promo code is not valid for this type of purchase
Apply
Payment error
We couldn’t accept your payment. The reason might be one of the following:
System error
Mistake in the card number
Not enough money
Other
Please try again or contact support
Close
##  Subscribe to our news
Get news about online privacy and ad blocking, AdGuard product releases, upcoming sales, giveaways, and more.
Email
Please check the email: it looks incorrect
Something went wrong
I accept the [Privacy policy](https://adguard.com/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.com/terms-and-conditions.html?_plc=en) of AdGuard websites
Invalid captcha
Captcha is required
Subscribe
![](https://cdn.adguardcdn.com/website/adguard.com/agnar.png)
##  You’re subscribed
News, promos, and special offers: you won’t miss out.
Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Terms of sale  EULA  Privacy policy  Uninstall instructions
