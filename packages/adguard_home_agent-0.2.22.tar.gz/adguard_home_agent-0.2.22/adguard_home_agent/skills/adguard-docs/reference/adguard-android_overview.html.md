[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
AdGuard for WindowsAdGuard for MacAdGuard for AndroidAdGuard for iOSAdGuard Content BlockerAdGuard Browser ExtensionAdGuard AssistantAdGuard HomeAdGuard Pro for iOSAdGuard Mini for MacAdGuard for Android TVAdGuard for LinuxAdGuard Temp MailAdGuard VPNAdGuard DNSAdGuard Mail β
[ AdGuard for Windows ](https://adguard.com/en/adguard-windows/overview.html)[ AdGuard for Mac ](https://adguard.com/en/adguard-mac/overview.html)[ AdGuard for Android ](https://adguard.com/en/adguard-android/overview.html)[ AdGuard for iOS ](https://adguard.com/en/adguard-ios/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
[ Windows ](https://adguard.com/en/adguard-windows/overview.html)[ Mac ](https://adguard.com/en/adguard-mac/overview.html)[ Android ](https://adguard.com/en/adguard-android/overview.html)[ iOS ](https://adguard.com/en/adguard-ios/overview.html)
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail  AdGuard VPN  AdGuard DNS  AdGuard Mail
Other products
[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_filters_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_statistics_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_incognito_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
20,009 20009 user reviews
Excellent!
#  AdGuard for Android
AdGuard for Android is a perfect solution for Android devices. Unlike most other ad blockers, AdGuard doesn't require root access and provides a wide range of app management options.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Samsung Galaxy Store ](https://agrd.io/samsung)
[](https://agrd.io/samsung)[](https://agrd.io/xiaomi)[](https://agrd.io/huawei)
Scan QR code
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
Scan to download
Use any QR-code reader available on your device
Close
AdGuard for Android v4.12, 14-day trial period
  * **Blocks ads everywhere**
Block ads everywhere on your device, including all types of ads in your apps, browsers, games, and websites. AdGuard has dozens of ad filters that are constantly updated to ensure the best filtering quality
  * **Protects your privacy**
Protecting your data is our top priority. With AdGuard, you and your sensitive information are safe from any online tracker and analytics system that tries to spy on you while you surf the Web
  * **Saves traffic and battery**
More ads blocked means fewer ads loaded. Fewer ads loaded means more traffic and battery life saved. Simple math by AdGuard! Download the apk file, install the app, and spend your traffic on things you like instead of wasting it on voracious ads
  * **Gives you control**
You decide what to filter and block on your device. A wide range of settings, from basic to advanced, and an app management tool help you tailor the filtering to your needs and control how apps consume traffic and access the Internet


## Try AdGuard — it will exceed your expectations
Join the 160 million users who are protecting their privacy with AdGuard products!
Scan QR code
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
##  Latest news
  * ### [ #KeepAndroidOpen: AdGuard urges Google to rethink policy that could restrict independent Android app distribution ](https://adguard.com/en/blog/google-android-app-verification-requirement-petition.html)
Feb 25, 2026
AdGuard urges Google to rethink policy that could restrict independent Android app distribution
  * ### [ AdGuard for Android v4.12: Share settings and enjoy landscape mode ](https://adguard.com/en/blog/adguard-for-android-v4-12.html)
Oct 1, 2025
AdGuard for Android v4.12 introduces landscape mode for tablets and a Share settings feature, making the app simpler and more comfortable to use.
  * ### [ The Android gate just got a lock: Google’s new rule could limit app access ](https://adguard.com/en/blog/android-play-store-verification-sideloading.html)
Sep 9, 2025
Google will require developers who distribute their apps outside of the Play Store to verify their identity in the name of user protection.
  * ### [ AdGuard for Android v4.11: A small update with bug fixes ](https://adguard.com/en/blog/adguard-for-android-v4-11.html)
Aug 27, 2025
This release includes some under-the-hood improvements, a substantial number of bug fixes, and a CoreLibs update.

[ Read more ](https://adguard.com/en/blog/tag/adguard-for-android.html)
##  All done!  Something went wrong  Subscribe to our news
You’ve successfully subscribed to AdGuard news. Emails will be sent to
You can also subscribe using a different email address
Please try again. If it doesn’t help, please [contact support](https://adguard.com/en/adguard-android/%mailto%)
Be the first to get the latest news about online privacy and ad blocking, AdGuard product releases, upcoming sales, giveaways, and more
Email
Please enter a valid email address
Subscribe
I accept the [Privacy policy](https://adguard.com/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.com/terms-and-conditions.html?_plc=en) of AdGuard websites
Invalid captcha
Captcha is required
Try again
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_all_done.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_something_went_wrong.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_subscription.svg)
##  AdGuard for Android in app stores
  * [ Huawei Store ](https://agrd.io/huawei)
  * [ Xiaomi Store ](https://agrd.io/xiaomi)
  * [ Samsung Store ](https://agrd.io/samsung)


Total app rating 4.7/5
More than 20,000 app reviews! We love our users and they love us back
20,009 20009 user reviews
Excellent!
Rinan  Draining battery on OS Android 10,
on Android 9, battery save
(Realme C3)
Minecar [](https://play.google.com/store/apps/details?id=com.adguard.android.contentblocker) Best app for Android users
A. Serban [](https://www.trustpilot.com/reviews/5fc68fe15e693f0604743816) Best full adblocker for Android.
Chamidu kanishka  English language input android device
harsha  it works perfectly in android.
MaríaCarmen  Date recibiré Android Google Driver
## Rate AdGuard
BadPoorAverageGreatExcellent!
Your name
Your review
0/511
I accept the [Privacy policy](https://adguard.info/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.info/terms-and-conditions.html?_plc=en) of AdGuard websites
Send
![](https://adguard.com/stcdn/website/adguard.com/agnar/agnar_thumbs_up_raven.svg)
Thank you! You’ve helped us become a bit better
##  Failed to send review
Please try again or contact support
Close
![AdGuard product video](https://cdn.adguardcdn.com/website/adguard.com/video/how-it-work/video-preview-en.png)
##  FAQ
  * Content blockers are usually limited to a specific browser and have much less powerful ad-fighting tools. AdGuard for Android is a standalone app that can block ads and trackers in both browsers and apps. Its filtering quality is much better.
  * Google Play doesn’t allow apps that can block ads across the device. This policy only leaves room for browser-specific content blockers. That’s why AdGuard, a full-featured ad blocker for Android, [was removed](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html) from the store.
  * The free version is excellent at removing ads from browsers, but it can’t filter apps and doesn’t have features like Browsing Security, Tracking protection, and Userscripts. To enjoy the advanced features that will help you block trackers and dangerous websites, [get the paid version](https://adguard.com/en/license.html).
  * Visit our [Knowledge base](https://adguard.com/kb/adguard-for-android/installation/) to learn how to install AdGuard Ad Blocker for Android.


  * To learn more about the key features of AdGuard for Android and how to get rid of ads on your device, read [our Knowledge base article](https://adguard.com/kb/adguard-for-android/overview/).
  * No, you don’t. Unlike many other ad blockers, AdGuard uses a so-called local VPN to block ads on non-rooted devices.
  * You can easily use AdGuard with [AdGuard VPN](https://adguard-vpn.com/welcome.html?_plc=en). Their integration is automatically enabled once both apps are up and running.
As for third-party VPN apps, there may be problems. AdGuard Ad Blocker runs a local VPN on your device to filter properly. Android doesn't allow running two VPNs at the same time, but there are workarounds. For rooted devices, we recommend switching AdGuard to Automatic proxy. This will allow your device to use another VPN app.
Also, VPNs like PIA VPN or Nord VPN allow you to use an upstream proxy — check if your VPN has this option.
  * If you have any questions, you can contact us 24/7 at support@adguard.com. It’s a good idea to check [our FAQ](https://adguard.com/en/support/adguard_for_android.html) first: it contains answers to 90% of user questions.


AdGuard for WindowsAdGuard for MacAdGuard for AndroidAdGuard for iOSAdGuard Content BlockerAdGuard Browser ExtensionAdGuard AssistantAdGuard HomeAdGuard Pro for iOSAdGuard Mini for MacAdGuard for Android TVAdGuard for LinuxAdGuard Temp MailAdGuard VPNAdGuard DNSAdGuard Mail β
AdGuard for Windows  AdGuard for Mac  AdGuard for Android  AdGuard for iOS  AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail [ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
Windows  Mac  Android  iOS
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail  AdGuard VPN  AdGuard DNS  AdGuard Mail
Other products
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail [ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_enabled_light-v2.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_disabled_light-v3.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_statistics_screen_light-v3.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/windows/windows_protection_screen_light-v3.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Windows
AdGuard for Windows is more than an ad blocker. It is a multipurpose tool that blocks ads, controls access to dangerous sites, speeds up page loading, and protects children from inappropriate content.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-windows/overview.html?source=ag_products_page)
AdGuard for Windows v7.22, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mac/mac_enabled_light-v2.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mac/mac_disabled_light-v3.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Mac
AdGuard for Mac is a unique ad blocker designed with macOS in mind. In addition to protecting you from annoying ads in browsers and apps, it shields you from tracking, phishing, and fraud.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-mac/overview.html?source=ag_products_page)
AdGuard for Mac v2.18, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_filters_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_statistics_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_incognito_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for Android
AdGuard for Android is a perfect solution for Android devices. Unlike most other ad blockers, AdGuard doesn't require root access and provides a wide range of app management options.
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Samsung Galaxy Store ](https://agrd.io/samsung)
[](https://agrd.io/samsung)[](https://agrd.io/xiaomi)[](https://agrd.io/huawei)
Scan QR code
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android/android_qr_light.svg)
Scan to download
Use any QR-code reader available on your device
Close
AdGuard for Android v4.12, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_statistics_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_enabled_light-v5.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_qr_light.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard for iOS
The best iOS ad blocker for iPhone and iPad. AdGuard eliminates all kinds of ads in Safari, protects your privacy, and speeds up page loading. AdGuard for iOS ad-blocking technology ensures the highest quality filtering and allows you to use multiple filters at the same time
Scan QR code
App Store
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
App Store
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/ios_qr_light.svg)
Scan to download
Use any QR-code reader available on your device
Close
AdGuard for iOS v4.5
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/adguard.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/settings.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/content_blocker/filters.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Content Blocker
AdGuard Content Blocker eliminates all kinds of ads in mobile browsers that support content-blocking technology — namely, Samsung Internet and Yandex Browser. Its features are limited compared to AdGuard for Android, but it is free, easy to install, and efficient
Google Play
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Read more ](https://adguard.com/en/adguard-content-blocker/overview.html?source=ag_products_page)
AdGuard Content Blocker v2.8
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/blocked1.svg?nc=1)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/disabled1.svg?nc=1)
20,009 20009 user reviews
Excellent!
##  AdGuard Browser Extension
AdGuard is the fastest and most lightweight ad blocking extension that effectively blocks all types of ads on all web pages! Choose AdGuard for the browser you use and get ad-free, fast and safe browsing.
[](https://adguard.com/en/adguard-browser-extension/chrome/overview.html)
[](https://adguard.com/en/adguard-browser-extension/firefox/overview.html)
[](https://adguard.com/en/adguard-browser-extension/edge/overview.html)
[](https://adguard.com/en/adguard-browser-extension/opera/overview.html)
[](https://adguard.com/en/adguard-browser-extension/yandex/overview.html)
Browser extension for Chrome Is it your current browser?
[ Install ](https://adguard.com/en/download-extension/chrome.html)
AdGuard Browser Extension v5.3
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/assistant/enabled.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/assistant/filtering.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Assistant
A companion browser extension for [AdGuard desktop apps](https://adguard.com/products.html?_plc=en). It allows you to block custom items on websites, add websites to allowlist, and send reports directly from your browser
[ Install ](https://agrd.io/assistant_chrome_release)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://agrd.io/assistant_firefox_release)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://agrd.io/assistant_edge_release)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://agrd.io/assistant_chrome_release)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ Install ](https://agrd.io/assistant_chrome_release)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
Included with [AdGuard for macOS](https://adguard.com/en/adguard-mac/overview.html)
If you can't find your browser, try the old legacy Assistant version, which you can find in AdGuard extension settings.
AdGuard Assistant v1.4
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/home/adguard_home.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Home
AdGuard Home is a network-based solution for blocking ads and trackers. Install it once on your router to cover all devices on your home network — no additional client software required. This is especially important for various IoT devices that often pose a threat to your privacy
[ Get started ](https://adguard-dns.io/kb/adguard-home/getting-started/)
AdGuard Home v0.107
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/enabled.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/filters.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/ios/adguard.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Pro for iOS
AdGuard Pro for iOS comes with all the advanced ad-blocking protection features enabled. It offers the same tools as the paid version of AdGuard for iOS. It excels at blocking ads in Safari and lets you customize DNS settings to tailor your protection. It blocks ads in browsers and apps, protects your kids from inappropriate content, and keeps your personal data safe
App Store
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
AdGuard Pro for iOS v4.5
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_protection_light.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_create_rule_light.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/safari/mini_extension_light.svg?nc=true)
20,009 20009 user reviews
Excellent!
##  AdGuard Mini for Mac — Safari ad blocker
AdGuard Mini for Mac is a powerful Safari ad blocker. This lightweight app removes ads, blocks trackers, and speeds up page loading. It helps you browse the Web in Safari without distractions and keep your data private
[ Install ](https://agrd.io/adguard_mini_for_mac)
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
[ App Store ](https://adguard.com/en/download-extension/safari.html)
Are you looking for [AdGuard for Mac](https://adguard.com/en/adguard-mac/overview.html) or [AdGuard for iOS](https://adguard.com/en/adguard-ios/overview.html)?
AdGuard Mini for Mac v2.1
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/enabled.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/ad_blocking.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/settings.svg?nc=true)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/android_tv/app_managment.svg?nc=true)
20,009 20009 user reviews
Excellent!
##  AdGuard for Android TV
AdGuard for Android TV is the only app that blocks ads, guards your privacy, and acts as a firewall for your Smart TV. Get warnings about web threats, use secure DNS, and benefit from encrypted traffic. Relax and dive into your favorite shows with top-notch security and zero ads!
[ Buy AdGuard ](https://adguard.com/en/license.html) How to install
AdGuard for Android TV v4.12, 14-day trial period
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/linux/agnar-linux.svg?nc=1)
20,009 20009 user reviews
Excellent!
##  AdGuard for Linux
AdGuard for Linux is the world’s first system-wide Linux ad blocker. Block ads and trackers at the device level, select from pre-installed filters, or add your own — all through the command-line interface
[ Buy AdGuard ](https://adguard.com/en/license.html) How to install
AdGuard for Linux v1.3
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/temp_mail/temp_mail.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Temp Mail
A free temporary email address generator that keeps you anonymous and protects your privacy. No spam in your main inbox!
![](https://cdn.adguardcdn.com/website/adguard.com/products/vpn/connected.png)
![](https://cdn.adguardcdn.com/website/adguard.com/products/vpn/exclusions.png)
20,009 20009 user reviews
Excellent!
##  AdGuard VPN
60 locations worldwide
Access to any content
Strong encryption
No-logging policy
Fastest connection
24/7 support
![](https://cdn.adguardcdn.com/website/adguard.com/products/dns/diana.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/products/dns/dns.png)
20,009 20009 user reviews
Excellent!
##  AdGuard DNS
AdGuard DNS is a foolproof way to block Internet ads that does not require installing any applications. It is easy to use, absolutely free, easily set up on any device, and provides you with minimal necessary functions to block ads, counters, malicious websites, and adult content.
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/mail/aliases2.svg)
20,009 20009 user reviews
Excellent!
##  AdGuard Mail β
Protect your identity, avoid spam, and keep your inbox secure with our aliases and temporary email addresses. Enjoy our free email forwarding service and apps for all operating systems
[GitHub repository](https://github.com/AdguardTeam/AdguardForAndroid)
[Discuss](https://adguard.com/en/discuss.html)
[Recent versions](https://adguard.com/en/versions/android/release.html)
[All products](https://adguard.com/en/products.html)
How AdGuard works
Desktop apps  Android  iOS
Desktop apps  Android  iOS
Desktop apps  Android  iOS
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Browsers
Apps
System
DNS filtering
Network filtering
HTTPS filtering
Content filtering
WWW
WWW
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
Network filtering
AdGuard needs to work on a network level to control all apps on your device. To do so, we use a special network driver, which activates the actual transmission and receipt of data over the network.
HTTPS filtering
The encrypted connections are filtered right on your device. To do that, AdGuard generates a unique root certificate and installs it in the system. Then, each connection is decrypted and trackers and ads are removed locally. The connection is encrypted again for the "communication" with the server. No unencrypted data ever leaves your device. [Learn more here](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/).
Content filtering
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. In browsers, it also applies additional cosmetic rules when blocking or hiding advertising elements (so that you see a nicely processed page rather than just blank spaces where ads just were).
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
Network filtering
AdGuard needs to work on a network level to control all apps on your device. To do so, we use a special network driver, which activates the actual transmission and receipt of data over the network.
HTTPS filtering
The encrypted connections are filtered right on your device. To do that, AdGuard generates a unique root certificate and installs it in the system. Then, each connection is decrypted and trackers and ads are removed locally. The connection is encrypted again for the "communication" with the server. No unencrypted data ever leaves your device. [Learn more here](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/).
Content filtering
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. In browsers, it also applies additional cosmetic rules when blocking or hiding advertising elements (so that you see a nicely processed page rather than just blank spaces where ads just were).
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Browsers
Apps
System
DNS filtering
Local VPN
HTTPS filtering
Content filtering
WWW
WWW
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
Local VPN
Network connections’ filtering is achieved by using a so called Local VPN. This approach means that a small VPN server is launched right on your device, and then it blocks tracking and advertising requests.
HTTPS filtering
The encrypted connections are filtered right on your device. To do that, AdGuard generates a unique root certificate and installs it in the system. Then, each connection is decrypted and trackers and ads are removed locally. The connection is encrypted again for the "communication" with the server. No unencrypted data ever leaves your device. [Learn more here](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/).
Content filtering
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. In browsers, it also applies additional cosmetic rules when blocking or hiding advertising elements (so that you see a nicely processed page rather than just blank spaces where ads just were).
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
Local VPN
Network connections’ filtering is achieved by using a so called Local VPN. This approach means that a small VPN server is launched right on your device, and then it blocks tracking and advertising requests.
HTTPS filtering
The encrypted connections are filtered right on your device. To do that, AdGuard generates a unique root certificate and installs it in the system. Then, each connection is decrypted and trackers and ads are removed locally. The connection is encrypted again for the "communication" with the server. No unencrypted data ever leaves your device. [Learn more here](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/).
Content filtering
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. In browsers, it also applies additional cosmetic rules when blocking or hiding advertising elements (so that you see a nicely processed page rather than just blank spaces where ads just were).
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Safari
Apps
System
Content Blocking
Local VPN
DNS filtering
WWW
WWW
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
Content Blocking
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. Thanks to its advanced technology, AdGuard is able to use 300k filtering rules (which is a lot, compared to only 50k rules that other ad blockers exploit).
Local VPN
Network connections’ filtering is achieved by using a so called Local VPN. This approach means that a small VPN server is launched right on your device, and then it blocks tracking and advertising requests.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Browsers
AdGuard "intercepts" the traffic of your browsers and leads it via its own filtering engine. Chrome, Firefox or any browser you like — you don't need to install any specific extensions to block ads there. AdGuard program works EVERYWHERE. (Although, you might want to additionally install AdGuard Browser Assistant — a small extension to the program to help you manage the filtering right in the browser).
Apps
Being a full-fledged software AdGuard is not limited in technical capabilities (while most ad blocking extensions are) and can filter outside browsers as well. AdGuard "intercepts" the traffic of all apps and leads it via its own filtering engine, so that you get them free of ads and trackers.
System
Operating system might sometimes track you and collect all kinds of telemetry (a bunch of diagnostic data). AdGuard can also prevent this.
Content Blocking
AdGuard filters the content of web pages and removes all tracking and advertising requests from there. Thanks to its advanced technology, AdGuard is able to use 300k filtering rules (which is a lot, compared to only 50k rules that other ad blockers exploit).
Local VPN
Network connections’ filtering is achieved by using a so called Local VPN. This approach means that a small VPN server is launched right on your device, and then it blocks tracking and advertising requests.
DNS filtering
AdGuard intercepts DNS requests and can block them if it is an address of a known advertising or tracking server that is being requested. AdGuard can also automatically encrypt your DNS traffic.
World Wide Web
Next, websites or apps are connecting to the servers on the Internet. As all tracking and advertising requests were blocked, you don't connect to them. Thus, you get ad-free, safe, fast (as there are no extra elements to load) Web, and also save traffic.
System changes
To perform filtering, AdGuard installs its network driver. If you decide to use [HTTPS filtering](https://adguard.com/kb/general/https-filtering/what-is-https-filtering/), AdGuard will generate a unique root certificate and install it in the system. All changes made by AdGuard in the system will be reset after uninstalling the app
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
