[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
#  AdGuard for Linux – Release – AdGuard versions
[ AdGuard for Linux 1.3 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1335)
Release date: February 26, 2026
AdGuard CLI continues to expand its capabilities and move closer to our full-featured desktop apps. With v1.3, it becomes more powerful, more flexible, and easier to manage.
This release introduces DNS filtering and Encrypted ClientHello (ECH) support, adds userscripts and userstyles, and refines the update workflow to make it clearer and more consistent.
## Added DNS filtering support
With DNS-level filtering enabled, unwanted domains, including ads, trackers, and malicious websites, are blocked before a connection is established. This adds an extra layer of protection and stops unwanted traffic at the earliest stage, preventing it from reaching your device.
Please note: DNS filtering is disabled by default.
To enable it, run the following command:
`adguard-cli config set dns_filtering.enabled true`
To disable it, run the following command:
`adguard-cli config set dns_filtering.enabled false`
Please note: By default, AdGuard CLI uses the system DNS server or AdGuard Non-filtering DNS server. You can manually choose a different server with the following command:
`adguard-cli config set dns_filtering.upstream '[server address]'`
To switch back to the default server, run the following command:
`adguard-cli config set dns_filtering.upstream default`
## Encrypted Client Hello
Although HTTPS encrypts the content of your traffic, the name of the server you are communicating with is usually still visible. ECH encrypts this part of the connection as well, helping to prevent ISPs, DPI systems, and other intermediaries from seeing which domains you access.
## Added userscript and userstyle support
You can install and manage [userscripts](https://adguard.com/kb/general/extensions/#userscripts) and [userstyles](https://adguard.com/kb/general/extensions/#userstyles) directly from the command line. Management commands follow the same logic as filters, so enabling, disabling, and removing userscripts works in a familiar way.
## Other improvements
We’ve also made several minor fixes and unified the logic behind `adguard-cli filters update` and `adguard-cli check-update`. Both commands now use the same update-check mechanism and provide detailed, human-readable progress output.
## Changelog
### Improvements
Added DNS filtering support [#90](https://github.com/AdguardTeam/AdGuardCLI/issues/90)
Added full userscripts/userstyles support [#118](https://github.com/AdguardTeam/AdGuardCLI/issues/118)
Added Encrypted Client Hello (ECH) support [#111](https://github.com/AdguardTeam/AdGuardCLI/issues/111)
### CoreLibs (Filtering engine)
Updated CoreLibs to v1.21.6
#### Improvements
Enabled HTTP/3 filtering by default [#2015](https://github.com/AdguardTeam/CoreLibs/issues/2015)
#### Fixes
Do Not Track feature sends both DNT and GPC even on browsers which does not support them [#1982](https://github.com/AdguardTeam/CoreLibs/issues/1982)
Do not leak `local.adguard.org` resolution after enabling protection [#1854](https://github.com/AdguardTeam/CoreLibs/issues/1854)
MWITools does not work in AdGuard [#2001](https://github.com/AdguardTeam/CoreLibs/issues/2001)
### Scriptlets (JavaScript enhancement for filtering rules)
Updated Scriptlets to v2.2.15
#### Improvements
`trusted-click-element` — added support for React elements that don’t respond to native clicks [#542](https://github.com/AdguardTeam/Scriptlets/issues/542)
#### Fixes
`prevent-addEventListener` scriptlet throws error when `null` is used as event type [#539](https://github.com/AdguardTeam/Scriptlets/issues/539)
[ AdGuard for Linux 1.2.2 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1232)
Release date: December 29, 2025
We fixed an [issue reported by users](https://github.com/AdguardTeam/AdguardForWindows/issues/5793) and updated our libraries while we were at it. Now, nothing will interfere with ad blocking.
[ AdGuard for Linux 1.2.1 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1227)
Release date: December 22, 2025
The app now runs more smoothly thanks to this minor update, which fixes a number of bugs.
[ AdGuard for Linux 1.2 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1217)
Release date: December 8, 2025
Protecting you from online dangers is a never-ending job — and we’re proud to be good at it. In this update, we’ve strengthened protection against malicious and phishing websites and added support for CRLite, a technology that speeds up and improves certificate validation. We’ve also enhanced the stability of AdGuard for Linux by refining the way requests are processed, ensuring smoother and more reliable performance.
## Changelog
### Improvements
Updated FLM to v2.3 [#101](https://github.com/AdguardTeam/AdGuardCLI/issues/101)
### Fixes
Segfault when handling configuration [#97](https://github.com/AdguardTeam/AdGuardCLI/issues/97)
Proxy server failed to start [#93](https://github.com/AdguardTeam/AdGuardCLI/issues/93)
### CoreLibs (Filtering engine)
Updated CoreLibs to v1.20.53
#### Improvements
Added an option to decode URL in `$urltransform`[#1915](https://github.com/AdguardTeam/CoreLibs/issues/1915)
Enabled HTTP/3 filtering by default in AdGuard beta/nightly versions [#2014](https://github.com/AdguardTeam/CoreLibs/issues/2014)
Added support for the new `$reason` modifier [#1986](https://github.com/AdguardTeam/CoreLibs/issues/1986)
#### Fixes
`@connect` does not work as expected [#1985](https://github.com/AdguardTeam/CoreLibs/issues/1985)
HAR file is not fully compiled [#2002](https://github.com/AdguardTeam/CoreLibs/issues/2002)
Destination address displays as 127.0.0.1 when AdGuard VPN Integration mode is enabled [#2021](https://github.com/AdguardTeam/CoreLibs/issues/2021)
Incorrect handling of HTTP 10x status codes for HTTP/1.1 [#2013](https://github.com/AdguardTeam/CoreLibs/issues/2013)
Userscript cannot be added to AdGuard for Android due to BOM (Byte Order Mark) [#2009](https://github.com/AdguardTeam/CoreLibs/issues/2009)
Userscript runner adds a source map [#1984](https://github.com/AdguardTeam/CoreLibs/issues/1984)
`GM.xmlHttpRequest` and `GM_xmlhttpRequest` are implemented incorrectly [#1983](https://github.com/AdguardTeam/CoreLibs/issues/1983)
Cosmetic filtering, scriptlets, and Stealth Mode don’t work when FakeDNS is enabled in proxy settings [#2017](https://github.com/AdguardTeam/CoreLibs/issues/2017)
Localhost is unreachable in manual proxy mode in version 1.19 [#2019](https://github.com/AdguardTeam/CoreLibs/issues/2019)
CRLite is not used as an alternative to OCSP [#1997](https://github.com/AdguardTeam/CoreLibs/issues/1997)
[ AdGuard for Linux 1.1 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1145)
Release date: October 6, 2025
This update brings CoreLibs, our filtering engine, up to v1.19 and the Filter List Manager up to v2.0, so your filters are fully taken care of!
As for what’s new, this version is mainly a system update to keep everything stable. Plus, we fixed bugs and made little improvements here and there to make ad blocking on Linux even more reliable.
## Changelog
### Improvements
Added a more convenient way to configure `outbound_proxy`
Added the ability to export and import settings
Added the option to set a custom data directory
Added support for `cli` platform filters
Updated FLM to v2.0
Added automatic activation of language-specific filters
Added optional support for notifications
Added UDP filtering support for Linux [#46](https://github.com/AdguardTeam/AdGuardCLI/issues/46)
### Fixes
AdGuard CLI with a beta license does not update when a different update channel is selected
AdGuard cannot add CA certificate in Arch Linux
The error page `Web page is not available` appears in Russian instead of the system language
Default value for `filter_ev_certificates` is incorrect
Running a parallel instance of Firefox triggers an HTTPS CA warning
Scriptlets fail to work
`/usr/local/bin/` directory is missing on Ubuntu
`adguard-cli` fails to start if filter metadata is not updated
Error occurs during certificate creation and update
Installer does not support multiple browser profiles
### CoreLibs (Filtering engine)
CoreLibs updated to v1.19
#### Improvements
Added support for ABP’s CSS injection syntax [#1927](https://github.com/AdguardTeam/CoreLibs/issues/1927)
Improved content script performance by using the browser cache more effectively [#1929](https://github.com/AdguardTeam/CoreLibs/issues/1929)
Improved overall content-script loading performance [#1930](https://github.com/AdguardTeam/CoreLibs/issues/1930)
Added the ability to remove content with an empty attribute [#1934](https://github.com/AdguardTeam/CoreLibs/issues/1934)
Added wildcard and regular expression support for the `$app` modifier [#1906](https://github.com/AdguardTeam/CoreLibs/issues/1906)
Removed complex heuristics from the `$domain` modifier [#1875](https://github.com/AdguardTeam/CoreLibs/issues/1875)
Added support for “zstd” encoding [#1976](https://github.com/AdguardTeam/CoreLibs/issues/1976)
Added support for the ALPS extension [#1987](https://github.com/AdguardTeam/CoreLibs/issues/1987)
#### Fixes
Content-type modifiers cannot be used with the `$urltransform` modifier [#1978](https://github.com/AdguardTeam/CoreLibs/issues/1978)
Filtering is disabled because it may affect website performance [#1994](https://github.com/AdguardTeam/CoreLibs/issues/1994)
Some React-based websites fail to load correctly due to `Minified React error`[#1953](https://github.com/AdguardTeam/CoreLibs/issues/1953)
Some extensions stopped working with CoreLibs 1.18 [#1993](https://github.com/AdguardTeam/CoreLibs/issues/1993)
XHR timeout occurs with the `immersivetranslate` userscript [#2000](https://github.com/AdguardTeam/CoreLibs/issues/2000)
`$removeparam` does not work in combination with the `$domain` modifier [#1999](https://github.com/AdguardTeam/CoreLibs/issues/1999)
`$urltransform` combined with `~3p` does not modify the request URL if opened directly in the address bar [#1931](https://github.com/AdguardTeam/CoreLibs/issues/1931)
[ AdGuard for Linux 1.0 ![](https://cdn.adguardcdn.com/website/adguard.com/svg/anchor-link.svg) ](https://adguard.com/en/versions/linux/release.html#version-1016)
Release date: April 29, 2025
This release marks the beginning of something huge: AdGuard for Linux is here to give our Linux users the protection AdGuard is known and trusted for, now on their OS!
For years, Linux users have been asking for their own version of AdGuard — that’s why we’ve poured our time and energy into making the Linux experience a powerful one. With AdGuard v1.0 for Linux, you now have access to a broad range of features and a complete, flexible way to stay protected on Linux.
If you tested [AdGuard v1.0 for Linux nightly](https://adguard.com/en/blog/adguard-for-linux-nightly.html), you’ll love the stable version — it adds even more features to enhance performance and usability.
### App exclusions
This feature drastically improves the usability of AdGuard for Linux. If you’re not familiar with it yet — it lets you selectively route traffic from specific apps, skipping AdGuard’s filtering when you don’t need it. Whether you’re troubleshooting or just want to keep seeing the ads from a certain service, this can come in handy.
And to make your life even easier, we’ve put together two pre-built lists of browsers and apps to be excluded from HTTPS filtering — so setting up exclusions is faster and way less manual.
The list can be edited in the files `proxy.yaml` (for app exclusions) and `browsers.yaml` (for browser exclusions). You can edit them using the built-in terminal editor (or any other text editor) by entering `nano [path to the file]`, and then restart the protection. To see the location of the file, check the output of the `config` command.
### Differential filter update
In this version, we have replaced the filter update method with a differential one. To put it simply, instead of fetching the entire filter list, AdGuard for Linux will only download the changes that were made to the list since the last update. Less traffic will be spent on updating and filters will be updated faster. You will always have the most current versions of filters and a more accurate ad blocking.
AdGuard for Windows
[ Release ](https://adguard.com/en/versions/windows/release.html)[ Beta ](https://adguard.com/en/versions/windows/beta.html)[ Nightly ](https://adguard.com/en/versions/windows/nightly.html)
AdGuard for Android
[ Release ](https://adguard.com/en/versions/android/release.html)[ Beta ](https://adguard.com/en/versions/android/beta.html)[ Nightly ](https://adguard.com/en/versions/android/nightly.html)
AdGuard for Android TV
[ Release ](https://adguard.com/en/versions/android-tv/release.html)[ Beta ](https://adguard.com/en/versions/android-tv/beta.html)
AdGuard for Mac
[ Release ](https://adguard.com/en/versions/mac/release.html)[ Beta ](https://adguard.com/en/versions/mac/beta.html)[ Nightly ](https://adguard.com/en/versions/mac/nightly.html)
AdGuard for iOS
[ Release ](https://adguard.com/en/versions/ios/release.html)[ Beta ](https://adguard.com/en/versions/ios/beta.html)
AdGuard Pro for iOS
[ Release ](https://adguard.com/en/versions/ios-pro/release.html)
AdGuard Browser Extension
[ Release ](https://adguard.com/en/versions/browser-extension/release.html)
AdGuard Mini for Mac
[ Release ](https://adguard.com/en/versions/mini-mac/release.html)
AdGuard for Linux
[ Release ](https://adguard.com/en/versions/linux/release.html)[ Beta ](https://adguard.com/en/versions/linux/beta.html)[ Nightly ](https://adguard.com/en/versions/linux/nightly.html)
AdGuard Assistant
[ Release ](https://adguard.com/en/versions/assistant/release.html)
AdGuard Content Blocker
[ Release ](https://adguard.com/en/versions/content-blocker/release.html)
AdGuard Home
[ Release ](https://adguard.com/en/versions/home/release.html)
Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
