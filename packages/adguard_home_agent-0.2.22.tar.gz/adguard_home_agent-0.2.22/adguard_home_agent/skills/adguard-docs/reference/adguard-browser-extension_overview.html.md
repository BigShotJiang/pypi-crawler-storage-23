[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
AdGuard for WindowsAdGuard for MacAdGuard for AndroidAdGuard for iOSAdGuard Content BlockerAdGuard Browser ExtensionAdGuard AssistantAdGuard HomeAdGuard Pro for iOSAdGuard Mini for MacAdGuard for Android TVAdGuard for LinuxAdGuard Temp MailAdGuard VPNAdGuard DNSAdGuard Mail β
[ AdGuard for Windows ](https://adguard.com/en/adguard-windows/overview.html)[ AdGuard for Mac ](https://adguard.com/en/adguard-mac/overview.html)[ AdGuard for Android ](https://adguard.com/en/adguard-android/overview.html)[ AdGuard for iOS ](https://adguard.com/en/adguard-ios/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
[ Windows ](https://adguard.com/en/adguard-windows/overview.html)[ Mac ](https://adguard.com/en/adguard-mac/overview.html)[ Android ](https://adguard.com/en/adguard-android/overview.html)[ iOS ](https://adguard.com/en/adguard-ios/overview.html)
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail  AdGuard VPN  AdGuard DNS  AdGuard Mail
Other products
[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/disabled1.svg?nc=1)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/blocked1.svg?nc=1)
20,009 20009 user reviews
Excellent!
#  AdGuard Browser Extension
The fastest and lightest adblocker extension that effectively blocks all types of ads and trackers on all websites! Install it for your browser and get an ad-free and safe web experience
[](https://adguard.com/en/adguard-browser-extension/chrome/overview.html)
[](https://adguard.com/en/adguard-browser-extension/firefox/overview.html)
[](https://adguard.com/en/adguard-browser-extension/edge/overview.html)
[](https://adguard.com/en/adguard-browser-extension/opera/overview.html)
[](https://adguard.com/en/adguard-browser-extension/yandex/overview.html)
Browser extension for Chrome Is it your current browser?
[ Install ](https://adguard.com/en/download-extension/chrome.html)
AdGuard Browser Extension v5.3
  * **Block ads in browsers**
AdGuard extension blocks all types of browser ads, including video, full-screen, floating, popups, banners, and text. Its element-blocking feature allows you to remove any unwanted item on a webpage
  * **Protect your privacy and be safe**
AdGuard protects your personal data by blocking third-party trackers, spyware, and adware. It also alerts you when you are about to visit a potentially malicious or phishing website
  * **Handle ad blocker detectors**
AdGuard handles ad blocker detection scripts on websites, so you don’t have to disable your adblocker extension to visit those websites
  * **Check out AdGuard Assistant**
If you use our desktop app, such as AdGuard for Windows or AdGuard for Mac, you don’t need our browser extension. Instead, use our [AdGuard Assistant](https://adguard.com/en/adguard-assistant/overview.html), a companion extension that helps you manage filtering directly from your browser


## Protect all your devices with a single license
Protect multiple devices at once with just one AdGuard license key! Valid for all major platforms: Windows, macOS, iOS, and Android
[ Buy now ](https://adguard.com/en/license.html)
##  Latest news
  * ### [ AdGuard Browser Extension v5.3: A stronger core, a smoother experience ](https://adguard.com/en/blog/adguard-browser-extension-v5-3.html)
Feb 13, 2026
AdGuard Browser Extension v5.3 delivers key improvements to speed and stability, with a faster, more reliable filtering engine.
  * ### [ AdGuard Browser Extension v5.2: Your Web, your rules with User Scripts API ](https://adguard.com/en/blog/adguard-browser-extension-v5-2.html)
Oct 16, 2025
AdGuard Browser Extension v5.2 is here with a ton of changes that significantly enhance usability and bring you more customization options.
  * ### [ uBlock Origin is forever disabled in Chrome. Why it happened and what to use instead ](https://adguard.com/en/blog/ublock-origin-disabled-chrome.html)
Jul 17, 2025
uBlock Origin got forever disabled in Chrome due to the browser's transition to MV3. What does it mean for the extension's many users and what are the alternatives?
  * ### [ AdGuard is among the first ad blockers to feature its browser extension in Edge for Android ](https://adguard.com/en/blog/adguard-ad-blocker-ms-edge-collab.html)
Jul 14, 2025
AdGuard is one of the first browser extension ad blockers featured in Edge for Android! Learn how to get it in just a few taps if you're already using the desktop Edge extension.

[ Read more ](https://adguard.com/en/blog/tag/adguard-extensions.html)
##  All done!  Something went wrong  Subscribe to our news
You’ve successfully subscribed to AdGuard news. Emails will be sent to
You can also subscribe using a different email address
Please try again. If it doesn’t help, please [contact support](https://adguard.com/en/adguard-browser-extension/%mailto%)
Be the first to get the latest news about online privacy and ad blocking, AdGuard product releases, upcoming sales, giveaways, and more
Email
Please enter a valid email address
Subscribe
I accept the [Privacy policy](https://adguard.com/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.com/terms-and-conditions.html?_plc=en) of AdGuard websites
Invalid captcha
Captcha is required
Try again
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_all_done.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_something_went_wrong.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_subscription.svg)
Total app rating 4.7/5
More than 20,000 app reviews! We love our users and they love us back
20,009 20009 user reviews
Excellent!
Claver M.  Uma das melhores extensões para Firefox, Google Chrome, Opera, e derivados.
PedantMac  Funguje a blokuje opravdu skvěle, jen rozšíření do Opera a Edge kolabuje. Stále musím dávat "opravit". Na Safari OK.
Keith White [](https://play.google.com/store/apps/details?id=com.adguard.android.contentblocker) AdGuard: Content Blocker does work like advertised the only real drawback is it only works with Samsung Internet Browser, Samsung Browser Lite, Samsung Browser Beta, Yandex Browser and every other version of Yandex Browser. It should have universal1
Carsten Blume  Just great for Safari ... i completely switched from Chrome/Firefox, it's fast, adfree now and saves cpu/battery time
resat999  chrome da çok başarılı şimdi firefox da deniycem
Bhavish Nadar [](https://itunes.apple.com/IN/app/id1047223162) Which there is support for other browsers like firefox and edge
## Rate AdGuard
BadPoorAverageGreatExcellent!
Your name
Your review
0/511
I accept the [Privacy policy](https://adguard.info/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.info/terms-and-conditions.html?_plc=en) of AdGuard websites
Send
![](https://adguard.com/stcdn/website/adguard.com/agnar/agnar_thumbs_up_raven.svg)
Thank you! You’ve helped us become a bit better
##  Failed to send review
Please try again or contact support
Close
![AdGuard product video](https://cdn.adguardcdn.com/website/adguard.com/video/how-it-work/video-preview-en.png)
## Installation
Install the latest stable version of AdGuard Ad Blocker for Chrome from the Chrome Web Store.
To check out the experimental features and help us with testing, download the latest beta.
[ Install ](https://adguard.com/en/download-extension/chrome.html)[ Get beta ](https://agrd.io/extension_chrome_beta)
## Installation
You can install the latest version of AdGuard Ad Blocker for Firefox from Firefox Add-ons or download it [directly](https://addons.mozilla.org/firefox/downloads/latest/520576/addon-520576-latest.xpi).
To check out the evolving features and help us test AdGuard, you can install the current standalone beta, which is free of some of the limitations imposed by the browser.
[ Install ](https://adguard.com/en/download-extension/firefox.html)[ Get beta ](https://agrd.io/extension_firefox_beta)
## Installation
You can install the latest version of AdGuard Ad Blocker for Edge from Microsoft Edge Add-ons.
To check out the experimental features and help us test, download the latest beta.
[ Install ](https://adguard.com/en/download-extension/edge.html)[ Get beta ](https://agrd.io/extension_edge_beta)
## Installation
You can install the latest version of AdGuard Ad Blocker for Opera from Opera Add-ons.
To check out the experimental features and help us test AdGuard, download the latest beta.
[ Install ](https://adguard.com/en/download-extension/opera.html)[ Get beta ](https://agrd.io/extension_opera_beta)
## Installation
Install the latest version of AdGuard Ad Blocker for Yandex Browser from the Chrome Web Store.
To check out the experimental features and help us with testing, download the latest beta.
[ Install ](https://adguard.com/en/download-extension/yandex.html)[ Get beta ](https://agrd.io/extension_chrome_beta)
##  FAQ
  * The most obvious difference is that our extension only works for the browser it's installed in. It also has technical limitations that don't allow it to block certain types of web requests.
  * To learn more about the key features of AdGuard Browser Extension, read [our Knowledge base article](https://adguard.com/kb/adguard-browser-extension/overview/).


  * If you have any questions, you can contact us 24/7 at support@adguard.com. It’s a good idea to check [our FAQ](https://adguard.com/en/support/adguard_for_mac.html) first: it contains answers to 90% of user questions.


AdGuard for WindowsAdGuard for MacAdGuard for AndroidAdGuard for iOSAdGuard Content BlockerAdGuard Browser ExtensionAdGuard AssistantAdGuard HomeAdGuard Pro for iOSAdGuard Mini for MacAdGuard for Android TVAdGuard for LinuxAdGuard Temp MailAdGuard VPNAdGuard DNSAdGuard Mail β
[ AdGuard for Windows ](https://adguard.com/en/adguard-windows/overview.html)[ AdGuard for Mac ](https://adguard.com/en/adguard-mac/overview.html)[ AdGuard for Android ](https://adguard.com/en/adguard-android/overview.html)[ AdGuard for iOS ](https://adguard.com/en/adguard-ios/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
[ Windows ](https://adguard.com/en/adguard-windows/overview.html)[ Mac ](https://adguard.com/en/adguard-mac/overview.html)[ Android ](https://adguard.com/en/adguard-android/overview.html)[ iOS ](https://adguard.com/en/adguard-ios/overview.html)
AdGuard Content Blocker  AdGuard Browser Extension  AdGuard Assistant  AdGuard Home  AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard for Android TV  AdGuard for Linux  AdGuard Temp Mail  AdGuard VPN  AdGuard DNS  AdGuard Mail
Other products
[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Browser Extension ](https://adguard.com/en/adguard-browser-extension/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard for Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ AdGuard for Linux ](https://adguard.com/en/adguard-linux/overview.html)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?source=ag_products_page&_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/disabled1.svg?nc=1)
![](https://cdn.adguardcdn.com/website/adguard.com/products/screenshots/browser_extension/blocked1.svg?nc=1)
20,009 20009 user reviews
Excellent!
##  AdGuard Browser Extension
Our state-of-the-art adblocker extension quickly and effectively blocks all types of ads and trackers in your browser! Get it for your browser and enjoy ad-free, fast, and safe surfing!
[](https://adguard.com/en/adguard-browser-extension/chrome/overview.html)
[](https://adguard.com/en/adguard-browser-extension/firefox/overview.html)
[](https://adguard.com/en/adguard-browser-extension/edge/overview.html)
[](https://adguard.com/en/adguard-browser-extension/opera/overview.html)
[](https://adguard.com/en/adguard-browser-extension/yandex/overview.html)
Browser extension for Chrome Is it your current browser?
[ Install ](https://adguard.com/en/download-extension/chrome.html)
AdGuard Browser Extension v5.3
[GitHub repository](https://github.com/AdguardTeam/AdguardBrowserExtension)
[Discuss](https://adguard.com/en/discuss.html)
[Recent versions](https://adguard.com/en/versions/browser-extension/release.html)
[All products](https://adguard.com/en/products.html)
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
