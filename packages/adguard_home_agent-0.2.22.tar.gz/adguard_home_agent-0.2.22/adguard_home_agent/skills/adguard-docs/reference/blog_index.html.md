[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
[AdGuard](https://adguard.com/en/welcome.html)Blog
#  Blog
[RSS](https://adguard.com/blog/rss-en.xml)
Search
  * [![AdGuard for Windows v7.22.4: Meet SockFilter, our new experimental network driver](https://cdn.adtidy.org/blog/new/0pt88agw-7224-sock.jpg?mw=976&mh=656)](https://adguard.com/en/blog/adguard-for-windows-v7-22-4.html)
February 26, 2026  3 min read [ AdGuard for Windows ](https://adguard.com/en/blog/tag/adguard-for-windows.html)[ New version ](https://adguard.com/en/blog/tag/new-version-2.html)[ Release notes ](https://adguard.com/en/blog/tag/release-notes.html)
### [AdGuard for Windows v7.22.4: Meet SockFilter, our new experimental network driver](https://adguard.com/en/blog/adguard-for-windows-v7-22-4.html)
With AdGuard for Windows v7.22.4, we’re introducing SockFilter, our new network driver. While still experimental, it has the potential to make AdGuard better now and in the future.
[![Pamela Puglieri](https://cdn.adtidy.org/blog/2022/09/WhatsApp-Image-2022-09-05-at-17.59.36-2.jpeg?mw=32&mh=32)Pamela Puglieri](https://adguard.com/en/blog/author/pamelapuglieri.html)
  * [![AdGuard CLI v1.3: DNS filtering and ECH support](https://cdn.adtidy.org/blog/new/k9uwofcli.png?mw=976&mh=656)](https://adguard.com/en/blog/adguard-v1-3-cli.html)
February 26, 2026  3 min read [ AdGuard for Linux ](https://adguard.com/en/blog/tag/adguard-for-linux.html)[ New version ](https://adguard.com/en/blog/tag/new-version-2.html)[ Release notes ](https://adguard.com/en/blog/tag/release-notes.html)
### [AdGuard CLI v1.3: DNS filtering and ECH support](https://adguard.com/en/blog/adguard-v1-3-cli.html)
This update adds DNS filtering and Encrypted ClientHello (ECH) support, along with userscripts, userstyles, and a more consistent update workflow.
[![Darya Bugayova](https://cdn.adtidy.org/blog/2020/06/photo.jpg?mw=32&mh=32)Darya Bugayova](https://adguard.com/en/blog/author/darya.html)
  * [![#KeepAndroidOpen: AdGuard urges Google to rethink policy that could restrict independent Android app distribution](https://cdn.adtidy.org/blog/new/lhvabno-entry-android-app.png?mw=976&mh=656)](https://adguard.com/en/blog/google-android-app-verification-requirement-petition.html)
February 25, 2026  7 min read [ AdGuard for Android ](https://adguard.com/en/blog/tag/adguard-for-android.html)[ Industry news ](https://adguard.com/en/blog/tag/industry-news.html)
### [#KeepAndroidOpen: AdGuard urges Google to rethink policy that could restrict independent Android app distribution](https://adguard.com/en/blog/google-android-app-verification-requirement-petition.html)
AdGuard is proud to be among the signatories of a newly published open letter opposing Google’s upcoming developer verification policy. The campaign was spearheaded by F-Droid, which launched it last year and has been rallying support ever since
[![Ekaterina Kachalova](https://cdn.adtidy.org/blog/2022/07/100kb.jpg?mw=32&mh=32)Ekaterina Kachalova](https://adguard.com/en/blog/author/ekaterina.html)
  * [![YouTube finds a brand new way to bother users of ad blockers](https://cdn.adtidy.org/blog/new/mooadyt-comments.jpg?mw=976&mh=656)](https://adguard.com/en/blog/youtube-missing-comments-descriptions.html)
February 21, 2026  7 min read [ Ad Blocking ](https://adguard.com/en/blog/tag/ad-blocking.html)[ YouTube ](https://adguard.com/en/blog/tag/youtube.html)
### [YouTube finds a brand new way to bother users of ad blockers](https://adguard.com/en/blog/youtube-missing-comments-descriptions.html)
YouTube comes up with a new way to strike at the users of ad blockers — now by hiding the comment and descriptions of all videos. How will ad blockers respond?
[![Vasily Bagirov](https://cdn.adtidy.org/blog/2020/06/bw_av_small.jpg?mw=32&mh=32)Vasily Bagirov](https://adguard.com/en/blog/author/vasilybagirov.html)
  * [![Navigating the future of ad blocking: Interview with Andrey Meshkov on TechLore Talks](https://cdn.adtidy.org/blog/new/6yl3bam-cover.jpg?mw=976&mh=656)](https://adguard.com/en/blog/andrey-meshkov-techlore-talks-interview.html)
Upd: February 17, 2026  34 min read [ AdGuard news ](https://adguard.com/en/blog/tag/adguard-news.html)[ The History of Ad Blocking ](https://adguard.com/en/blog/tag/the-history-of-ad-blocking.html)
### [Navigating the future of ad blocking: Interview with Andrey Meshkov on TechLore Talks](https://adguard.com/en/blog/andrey-meshkov-techlore-talks-interview.html)
Andrey Meshkov, Co-Founder and CTO of AdGuard, sat down with Henry Fisher from TechLore to talk about the past, the present, and the future of ad blocking in general and the AdGuard’s role in it.
[![Andrey Meshkov](https://cdn.adtidy.org/blog/2019/05/5947035--1-.jpeg?mw=32&mh=32)Andrey Meshkov](https://adguard.com/en/blog/author/andrey.html)[![Vasily Bagirov](https://cdn.adtidy.org/blog/2020/06/bw_av_small.jpg?mw=32&mh=32)Vasily Bagirov](https://adguard.com/en/blog/author/vasilybagirov.html)
  * [![AdGuard Browser Extension v5.3: A stronger core, a smoother experience](https://cdn.adtidy.org/blog/new/4ftu1engine.png?mw=976&mh=656)](https://adguard.com/en/blog/adguard-browser-extension-v5-3.html)
February 13, 2026  2 min read [ AdGuard Browser Extensions ](https://adguard.com/en/blog/tag/adguard-extensions.html)[ New version ](https://adguard.com/en/blog/tag/new-version-2.html)[ Release notes ](https://adguard.com/en/blog/tag/release-notes.html)
### [AdGuard Browser Extension v5.3: A stronger core, a smoother experience](https://adguard.com/en/blog/adguard-browser-extension-v5-3.html)
AdGuard Browser Extension v5.3 delivers key improvements to speed and stability, with a faster, more reliable filtering engine.
[![Nata Kiseleva](https://cdn.adtidy.org/blog/2020/08/nata.png?mw=32&mh=32)Nata Kiseleva](https://adguard.com/en/blog/author/nata.html)
  * [![Claude-linked Google ads dupe macOS users into installing malware](https://cdn.adtidy.org/blog/new/vvzmccommand.jpg?mw=976&mh=656)](https://adguard.com/en/blog/claude-google-ads-malware-poisoning-macos.html)
Upd: February 19, 2026  11 min read [ Industry news ](https://adguard.com/en/blog/tag/industry-news.html)
### [Claude-linked Google ads dupe macOS users into installing malware](https://adguard.com/en/blog/claude-google-ads-malware-poisoning-macos.html)
When searching for “brew macos”, a sponsored result (supposedly verified by Google) leads to an official ClaudeAI page containing user-generated instructions that appear to distribute malware.
[![Ekaterina Kachalova](https://cdn.adtidy.org/blog/2022/07/100kb.jpg?mw=32&mh=32)Ekaterina Kachalova](https://adguard.com/en/blog/author/ekaterina.html)
  * [![Anthropic tears into ChatGPT with new anti-ad ad, and sparks an important conversation](https://cdn.adtidy.org/blog/new/kuz1arobots-fight.jpg?mw=976&mh=656)](https://adguard.com/en/blog/superbowl-ad-anthropic-claude-openai-chatgpt-attack.html)
Upd: February 19, 2026  6 min read [ AI ](https://adguard.com/en/blog/tag/ai.html)[ Industry news ](https://adguard.com/en/blog/tag/industry-news.html)
### [Anthropic tears into ChatGPT with new anti-ad ad, and sparks an important conversation](https://adguard.com/en/blog/superbowl-ad-anthropic-claude-openai-chatgpt-attack.html)
Anthropic, an OpenAI rival best known for its Claude chatbot, has seized on the ad debate — and the way it chose to do so says a lot about how intransigent the AI arms race has become.
[![Ekaterina Kachalova](https://cdn.adtidy.org/blog/2022/07/100kb.jpg?mw=32&mh=32)Ekaterina Kachalova](https://adguard.com/en/blog/author/ekaterina.html)
  * [![ChatGPT ads hit the Web — let’s have a look](https://cdn.adtidy.org/blog/new/m5c23tsquare.jpg?mw=976&mh=656)](https://adguard.com/en/blog/openai-chatgpt-ads-web-android-beta.html)
Upd: February 9, 2026  3 min read [ Ad Blocking ](https://adguard.com/en/blog/tag/ad-blocking.html)[ AI ](https://adguard.com/en/blog/tag/ai.html)[ Industry news ](https://adguard.com/en/blog/tag/industry-news.html)
### [ChatGPT ads hit the Web — let’s have a look](https://adguard.com/en/blog/openai-chatgpt-ads-web-android-beta.html)
The ads recently promised by OpenAI have arrived in ChatGPT, both in beta Android app and the web app. Let’s see what they look like and if AdGuard will be able to block them.
[![Vasily Bagirov](https://cdn.adtidy.org/blog/2020/06/bw_av_small.jpg?mw=32&mh=32)Vasily Bagirov](https://adguard.com/en/blog/author/vasilybagirov.html)
  * [![TechTok #12. Navigating privacy in a data-driven world: Simple steps for protecting your data and fine-tuning your VPN](https://cdn.adtidy.org/blog/new/y1m9ctechtok.png?mw=976&mh=656)](https://adguard.com/en/blog/techtok-12-navigating-privacy-in-data-driven-world.html)
Upd: February 6, 2026  6 min read [ TechTok ](https://adguard.com/en/blog/tag/techtok.html)
### [TechTok #12. Navigating privacy in a data-driven world: Simple steps for protecting your data and fine-tuning your VPN](https://adguard.com/en/blog/techtok-12-navigating-privacy-in-data-driven-world.html)
In this new edition of TechTok, we’re tackling two very different questions. One is incredibly broad in scope, while the other is much narrower. But what ties them together is that the answers to both may seem more straightforward than they actually are.
[![Ekaterina Kachalova](https://cdn.adtidy.org/blog/2022/07/100kb.jpg?mw=32&mh=32)Ekaterina Kachalova](https://adguard.com/en/blog/author/ekaterina.html)


[1](https://adguard.com/en/blog/index.html)[2](https://adguard.com/en/blog/index.html?page=2)[3](https://adguard.com/en/blog/index.html?page=3)…[90](https://adguard.com/en/blog/index.html?page=90)[](https://adguard.com/en/blog/index.html?page=2)
##  All done!  Something went wrong  Subscribe to our news
You’ve successfully subscribed to AdGuard news. Emails will be sent to
You can also subscribe using a different email address
Please try again. If it doesn’t help, please [contact support](https://adguard.com/en/blog/%mailto%)
Be the first to get the latest news about online privacy and ad blocking, AdGuard product releases, upcoming sales, giveaways, and more
Email
Please enter a valid email address
Subscribe
I accept the [Privacy policy](https://adguard.com/website-privacy.html?_plc=en) and [Terms and conditions](https://adguard.com/terms-and-conditions.html?_plc=en) of AdGuard websites
Invalid captcha
Captcha is required
Try again
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_all_done.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_something_went_wrong.svg)
![](https://cdn.adguardcdn.com/website/adguard.com/pictures/agnar_subscription.svg)
## Recommended articles
  * [![AdGuard for iOS](https://cdn.adguardcdn.com/website/adguard.com/social/og-main.png?mw=512&mh=348) AdGuard for iOS AdGuard adblock for iOS is able to eliminate all kinds of ads in Safari, protect your privacy, and reduce page loading time.  Read more ](https://adguard.info/en/adguard-ios/overview.html)
  * [![How to block pop-ups in Safari or allow them](https://cdn.adguardcdn.com/website/adguard.com/img/social/2.jpg?mw=512&mh=348) How to block pop-ups in Safari or allow them If you want to get rid of pop-ups in Safari, you need to install AdGuard. It removes not only virus pop-ups, but also all kinds of ads and trackers. Learn how to block or allow pop-ups in this article.  Read more ](https://adguard.info/en/article/safari-pop-up-blocker.html)
  * [![AdGuard Browser extension for Chrome](https://cdn.adguardcdn.com/website/adguard.com/social/og-main.png?mw=512&mh=348) AdGuard Browser extension for Chrome Our ad-blocking extension allows you to block all known types of ads: popups, banners, video ads and much more ✅  Read more ](https://adguard.info/en/article/adblock-adguard-chrome.html)
  * [![How to block ads on YouTube: quick insight and things to know](https://cdn.adguardcdn.com/website/adguard.com/img/social/3.jpg?mw=512&mh=348) How to block ads on YouTube: quick insight and things to know Get a comprehensive overview of how to block ads on YouTube and reasons why your adblock is not working on it.  Read more ](https://adguard.info/en/article/how-to-block-ads-on-youtube.html)


Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
