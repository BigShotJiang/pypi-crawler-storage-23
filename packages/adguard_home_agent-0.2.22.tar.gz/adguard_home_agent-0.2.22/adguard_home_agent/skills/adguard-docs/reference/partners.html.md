[](https://adguard.com/en/welcome.html)
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/Agnar_thinking.svg)
Looking for our logo?
Our media kits include all versions of the logo and other branding materials. Download them in just a few clicks
[ Open media kits ](https://adguard.com/en/media-materials.html) Cancel
  * [ Home ](https://adguard.com/en/welcome.html)
  * Products
    * AdGuard Ad Blocker  AdGuard Ad Blocker  Blocks ads, trackers, phishing, and web annoyances
      * [ For Windows ](https://adguard.com/en/adguard-windows/overview.html)
      * [ For Mac ](https://adguard.com/en/adguard-mac/overview.html)
      * [ For Android ](https://adguard.com/en/adguard-android/overview.html)
      * [ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)
      * [ For iOS ](https://adguard.com/en/adguard-ios/overview.html)
      * [ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)
      * [ For Linux ](https://adguard.com/en/adguard-linux/overview.html)
    * AdGuard VPN  AdGuard VPN  Makes you anonymous and your traffic inconspicuous
      * [ Official site ](https://adguard-vpn.com/welcome.html?_plc=en)
      * [ For Windows ](https://adguard-vpn.com/windows/overview.html?_plc=en)
      * [ For Mac ](https://adguard-vpn.com/mac/overview.html?_plc=en)
      * [ For Android ](https://adguard-vpn.com/android/overview.html?_plc=en)
      * [ For Android TV ](https://adguard-vpn.com/android-tv/overview.html?_plc=en)
      * [ For iOS ](https://adguard-vpn.com/ios/overview.html?_plc=en)
      * [ For browsers ](https://adguard-vpn.com/browser-extension/overview.html?_plc=en)
      * [ For routers ](https://adguard-vpn.com/router/overview.html?_plc=en)
      * [ For Linux ](https://adguard-vpn.com/linux/overview.html?_plc=en)
      * [ All products ](https://adguard-vpn.com/products.html?_plc=en)
      * [ Blog ](https://adguard-vpn.com/en/blog/index.html?_plc=en)
    * AdGuard DNS  AdGuard DNS  A cloud-based DNS service that blocks ads and protects your privacy
      * [ Official site ](https://adguard-dns.io/welcome.html?_plc=en)
      * [ Dashboard ](https://adguard-dns.io/dashboard/?_plc=en)
      * [ Public DNS ](https://adguard-dns.io/public-dns.html?_plc=en)
      * [ Enterprise DNS ](https://adguard-dns.io/enterprise.html?_plc=en)
      * [ Knowledge base ](https://adguard-dns.io/kb/)
      * [ Blog ](https://adguard-dns.io/en/blog/index.html?_plc=en)
    * Other products  Other products  Other tools for content blocking
      * [ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)
      * [ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)
      * [ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)
      * [ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)
      * [ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)
      * [ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)
      * [ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)
      * [ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)
      * [ All products ](https://adguard.com/en/products.html)
  * [ Blog ](https://adguard.com/en/blog/index.html)
  * [ Support ](https://adguard.com/en/support.html)
  * [ Partners ](https://adguard.com/en/partners.html)
  * [ Purchase ](https://adguard.com/en/license.html)
  * EN
    * Dansk
    * Deutsch
    * English
    * Español
    * Français
    * Hrvatski
    * Indonesia
    * Italiano
    * Magyar
    * Nederlands
    * Norsk
    * Polski
    * Português (BR)
    * Português (PT)
    * Română
    * Slovenčina
    * Slovenščina
    * Srpski
    * Suomi
    * Svenska
    * Tiếng Việt
    * Türkçe
    * Český
    * Беларуская
    * Русский
    * Українська
    * فارسی
    * 中文 (简体)
    * 中文 (繁體)
    * 日本語
    * 한국어
  * [ Log in ](https://adguard.com/go?hash=100c187263d27d7886fb846249ea66ea&url=https%3A%2F%2Fadguardaccount.com%2Faccount%2F%3F_plc%3Den)


EN
  * Dansk
  * Deutsch
  * English
  * Español
  * Français
  * Hrvatski
  * Indonesia
  * Italiano
  * Magyar
  * Nederlands
  * Norsk
  * Polski
  * Português (BR)
  * Português (PT)
  * Română
  * Slovenčina
  * Slovenščina
  * Srpski
  * Suomi
  * Svenska
  * Tiếng Việt
  * Türkçe
  * Český
  * Беларуская
  * Русский
  * Українська
  * فارسی
  * 中文 (简体)
  * 中文 (繁體)
  * 日本語
  * 한국어


![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Blocks ads and trackers in browsers and apps. Protects from phishing and malware.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Windows**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Designed with macOS specifics in mind. Blocks ads and trackers. Protects your privacy.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Mac**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Doesn’t need root access to block ads in browsers and apps. Fights trackers and phishing.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Android**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Blocks ads in browsers and supports DNS filtering. Blocks trackers and dangerous sites.
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for iOS Pro**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Chrome**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Firefox**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Safari**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Edge**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Opera**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Free the Web from ads and protect your privacy with AdGuard Browser Extension
20,009 20009 user reviews
Excellent!
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**Block ads in Yandex.Browser**
Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
World’s first system-wide Linux ad blocker. Blocks ads and trackers.
20,009 20009 user reviews
Excellent!
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
![](https://cdn.adguardcdn.com/website/adguard.com/svg/agnar-top-line.svg)
**AdGuard for Linux**
[ How to install ](https://adguard.com/en/adguard-linux/overview.html#instructions)
#  Drive your business forward with AdGuard
Partner with AdGuard, a trusted leader in online protection. With over 165 million users worldwide, we are the go-to solution for ad blocking, privacy protection, and safe browsing
We have flexible partnership programs to meet your unique needs, helping you monetize your audience, integrate cutting-edge privacy protection solutions, and expand or enhance your offerings
Join us in building a better, ad-free Internet!
![](https://cdn.adguardcdn.com/website/adguard.com/distribution/partners/agnar_join_us.svg)
##  Affiliate
Link to us and earn up to 50% of each license sale and renewal
Our affiliate program is an easy and rewarding way to monetize your online presence. Share your referral links and earn generous commissions on every sale, including renewals
Perfect for
Influencers
Bloggers
Website owners
Online communities
Anyone with an engaged audience who wants to earn passive income by promoting AdGuard’s top-rated products
[ Sign up ](https://adguardpartner.com/dashboard/registration?_plc=en)[ Learn more ](https://adguard.com/en/partners/affiliate.html)
![](https://cdn.adguardcdn.com/website/adguard.com/distribution/partners/treasure_chest.svg)
##  Reseller
Deliver powerful privacy and security solutions to your customers
Become an authorized reseller of AdGuard products and offer your customers the ultimate toolkit to combat online threats and improve their online experience
Perfect for
Online and retail stores and marketplaces
Telcos
Mobile operators
ISPs
Value-added resellers
Any company looking to expand their product line with AdGuard’s cutting-edge software
[ Send request ](https://surveys.adguard.com/reseller_request/form.html?_plc=en)[ Learn more ](https://adguard.com/en/partners/reseller.html)
![](https://cdn.adguardcdn.com/website/adguard.com/distribution/partners/agnar_free_license_key.svg)
##  Technology partner
Integrate AdGuard’s cutting-edge tech into your products
Enhance your products and services with our advanced ad-blocking, VPN, and DNS solutions. We offer flexible integration options, including white-labeling, co-branding, and powerful SDKs
Perfect for
Developers
Companies looking to enhance their offerings with the latest ad-blocking and VPN technology
[ Send request ](https://surveys.adguard.com/sdk_request/form.html?_plc=en)[ Learn more ](https://adguard.com/en/partners/technology.html)
![](https://cdn.adguardcdn.com/website/adguard.com/distribution/partners/tengu_and_agnar.svg)
##  Service partner
Enhance your service offerings with AdGuard’s robust tools
Equip your team with the best tools to optimize, secure, and streamline your customers’ online experience. AdGuard’s products are ideal for delivering a seamless, ad-free, and protected web environment
Perfect for
IT professionals
Managed service providers (MSPs)
Cybersecurity consultants
Any business looking to enhance their offerings with premium online protection and privacy solutions
[ Send request ](https://surveys.adguard.com/service_request/form.html?_plc=en)[ Learn more ](https://adguard.com/en/partners/service.html)
![](https://cdn.adguardcdn.com/website/adguard.com/distribution/partners/tengu_service_partner.svg)
## Want to partner in a different way?
We’re always open to new opportunities. Contact us to discuss how we can work together for mutual success
[ Send request ](https://surveys.adguard.com/other_business_inquiries/form.html?_plc=en)
##  AdGuard in the news
  * [ Read more ](https://adguard.com/en/press-releases.html)


AdGuard review
AdGuard is a robust, widely compatible ad blocker. We recommend it to anyone seeking a good ad-blocking tool.
[ Learn more ](https://www.techradar.com/reviews/adguard)
Hacked websites could be using your computer to mine cryptocurrency
According to a recent report from AdGuard, more than 200 of the top 100,000 sites on the web were hosting suspicious code. That may not seem like a big deal, but even sites near the bottom of that list draw a huge amount of traffic. The most popular one on AdGuard's list regularly pulls in around 60 million visits every month.
In total, AdGuard discovered cryptocurrency mining code on 220 sites over a three-week period. During that time around 500 million users unknowingly ran that code on their computers.
[ Learn more ](https://www.forbes.com/sites/leemathews/2017/10/31/hacked-websites-could-be-using-your-computer-to-mine-cryptocurrency/#14a46ffa7250)
Bitcoin mining on track to consume all of the world’s energy by 2020
More than half a billion people may be inadvertently mining cryptocurrencies from their computers, smartphones and other devices, according to research conducted earlier this year by ad blocking firm AdGuard.
“How much money have these websites made? We estimate their joint profit at over $43,000,” the AdGuard researchers said in an October blogpost that detailed their discovery. At the time, one bitcoin was worth around $5,000.
[ Learn more ](http://www.newsweek.com/500-million-pcs-secretly-mining-cryptocurrency-research-bitcoin-683982)
Billions of video site visitors unwittingly mine cryptocurrency as they watch
The video sites Openload, Streamango, Rapidvideo and OnlineVideoConverter are allegedly loading mining software on to visitors’ computers, making them generate tokens for the bitcoin-like cryptocurrency Monero, according to security firm Adguard.
“We came across several very popular websites that secretly use the resources of users’ devices for cryptocurrency mining,” said Andrey Meshkov, co-founder of Adguard. “According to SimilarWeb, these four sites register 992m visits monthly.”
[ Learn more ](https://www.theguardian.com/technology/2017/dec/13/video-site-visitors-unwittingly-mine-cryptocurrency-as-they-watch-report-openload-streamango-rapidvideo-onlinevideoconverter-monero)
Why hackers love cryptocurrency miner coinhive
Although the developers aren't saying how much money they've made from their idea, online ad-blocking service AdGuard also found the Coinhive miner on over 30,000 sites and estimates the code generates $150,000 in Monero every month. For Coinhive, which takes a 30 percent cut, that amounts to $540,000 per year.
[ Learn more ](https://www.pcmag.com/news/357535/why-hackers-love-cryptocurrency-miner-coinhive)
You could be secretly mining bitcoins without even knowing it
Popular video sites including Openload, Streamango, Rapidvideo and OnlineVideoConverter are also allegedly loading mining software on to visitors' computers, according to security firm Adguard.
"We came across several very popular websites that secretly use the resources of users’ devices for cryptocurrency mining," said Andrey Meshkov, co-founder of Adguard. "According to SimilarWeb, these four sites register 992m visits monthly."
[ Learn more ](https://www.mirror.co.uk/tech/you-could-secretly-mining-bitcoins-11693723)
4 ad blockers that still work with Chrome
AdGuard will flat-out refuse to connect to websites known to be malicious for phishing attacks or spreading malware, and it’s good at collapsing the elements of the page that normally display ads, making formatting much less cluttered.
[ Learn more ](https://www.pcworld.com/article/2429437/four-ad-blockers-that-still-work-with-chrome.html)
Downloading AdGuard  To install AdGuard, click the file indicated by the arrow  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, drag the AdGuard icon to the "Applications" folder. Thank you for choosing AdGuard!  Select "Open" and click "OK", then wait for the file to be downloaded. In the opened window, click "Install". Thank you for choosing AdGuard!
Install AdGuard on your mobile device
Installation
AdGuard for Android is available in the following app stores:
[AppGallery](https://agrd.io/huawei)
[Mi Store](https://agrd.io/xiaomi)
[Samsung Galaxy Store](https://agrd.io/samsung)
AdGuard can’t be published on Google Play. For more details, [check out our blog](https://adguard.com/en/blog/google-removes-adguard-android-app-google-play.html). If you’re using Google Play, follow these instructions to manually install AdGuard for Android.
## 1. Allow downloading
If your browser displays a warning, allow downloading adguard.apk.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen1.jpg)
### Installation permissions
If installations from your browser are not allowed, you’ll get a notification. In this notification, tap Settings → Allow from this source.
### Note for Samsung users with One UI 6 (Android 14) and newer
On some Samsung devices, the Auto Blocker feature may prevent APK installations. To install the app:
Open your device settings.
Go to Security and privacy.
Scroll down and tap Auto Blocker.
Disable the setting.
You can re-enable this feature after the installation.
## 2. Install the app
In the pop-up dialog, tap Install.
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen2.jpg)
## 3. Launch the app
Wait for the installation to complete and tap Open. All done!
![](https://cdn.adguardcdn.com/website/adguard.com/download/Android/screen3.jpg)
Close
Scan to download
Use any QR-code reader available on your device
Scan to download
Use any QR-code reader available on your device
![](https://cdn.adguardcdn.com/website/adguard.com/agnar/agnar_old.svg)
Download an older AdGuard version?
This OS version isn’t supported. You can use an older version of AdGuard, but it won't receive updates
Download  Download
By downloading the program you accept the terms of the [License agreement](https://adguard.com/en/eula.html)
System theme  Light theme  Dark theme
System theme  Light theme  Dark theme
© 2009–2026 Adguard Software Ltd.
Site map
Social Media
AdGuard
[ Homepage ](https://adguard.com/en/welcome.html)[ About ](https://adguard.com/en/contacts.html)[ In the press ](https://adguard.com/en/press-releases.html)[ Media kits ](https://adguard.com/en/media-materials.html)[ Awards ](https://adguard.com/en/awards.html)[ Acknowledgements ](https://adguard.com/kb/miscellaneous/acknowledgements/)[ Blog ](https://adguard.com/en/blog/index.html)[ Articles ](https://adguard.com/en/article/index.html)[ Discuss ](https://adguard.com/en/discuss.html)[ Support AdGuard ](https://adguard.com/en/support-adguard.html)[ AdGuard promo activities ](https://adguard.com/en/promopages.html)
Products
[ For Windows ](https://adguard.com/en/adguard-windows/overview.html)[ For Mac ](https://adguard.com/en/adguard-mac/overview.html)[ For Android ](https://adguard.com/en/adguard-android/overview.html)[ For Android TV ](https://adguard.com/en/adguard-android-tv/overview.html)[ For iOS ](https://adguard.com/en/adguard-ios/overview.html)[ For Linux ](https://adguard.com/en/adguard-linux/overview.html)[ For browsers ](https://adguard.com/en/adguard-browser-extension/overview.html)[ Version history ](https://adguard.com/en/versions.html)
Other products
[ AdGuard Pro for iOS ](https://adguard.com/en/adguard-ios-pro/overview.html)[ AdGuard Mini for Mac ](https://adguard.com/en/adguard-mini-mac/overview.html)[ AdGuard Assistant ](https://adguard.com/en/adguard-assistant/overview.html)[ AdGuard Content Blocker ](https://adguard.com/en/adguard-content-blocker/overview.html)[ AdGuard Home ](https://adguard.com/en/adguard-home/overview.html)[ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html)[ All products ](https://adguard.com/en/products.html)
Support
[ Support center ](https://adguard.com/en/support.html)[ Knowledge base ](https://adguard.com/kb/)[ Report an issue ](https://reports.adguard.com/new_issue.html?_plc=en)[ Check any website ](https://reports.adguard.com/welcome.html?_plc=en)[ AdGuard status ](https://status.adguard.com/)[ AdGuard diagnostics ](https://adguard.com/en/test.html)
License
[ Purchase license ](https://adguard.com/en/license.html)[ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den)[ Recover license ](https://adguard.com/kb/general/license/what-is/#how-to-recover-a-license-key)[ Get free license ](https://adguard.com/en/get-adguard-for-free.html)[ Partner with AdGuard ](https://adguard.com/en/partners.html)[ Contribute to AdGuard ](https://adguard.com/en/contribute.html)[ Licenses for developers ](https://adguard.com/en/rewards.html)[ AdGuard for schools and colleges ](https://adguard.com/en/adguard-for-schools.html)[ Beta testing program ](https://adguard.com/en/beta.html)
Legal documents
[ EULA ](https://adguard.com/en/eula.html)[ EULA of AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/eula.html)[ Privacy policy ](https://adguard.com/en/privacy.html)[ Privacy policy of AdGuard websites ](https://adguard.com/en/website-privacy.html)[ Terms and conditions ](https://adguard.com/en/terms-and-conditions.html)[ Terms of sale ](https://adguard.com/en/terms-of-sale.html)[ Data processing agreement ](https://adguard.com/en/data-processing-agreement.html)
AdGuard
Homepage  About [ In the press ](https://adguard.com/en/press-releases.html) Media kits [ Awards ](https://adguard.com/en/awards.html) Acknowledgements  Blog  Articles  Discuss  Support AdGuard  AdGuard promo activities
Products
For Windows  For Mac  For Android  For Android TV  For iOS  For Linux  For browsers  Version history
Other products
AdGuard Pro for iOS  AdGuard Mini for Mac  AdGuard Assistant  AdGuard Content Blocker  AdGuard Home [ AdGuard DNS ](https://adguard-dns.io/welcome.html?_plc=en)[ AdGuard VPN ](https://adguard-vpn.com/welcome.html?_plc=en)[ AdGuard Mail ](https://adguard-mail.com/welcome.html?_plc=en)[ AdGuard Temp Mail ](https://adguard.com/en/adguard-temp-mail/overview.html)[ AdGuard Wallet ](https://adguard.com/en/crypto-wallet/overview.html) All products
Support
Support center  Knowledge base  Report an issue  Check any website  AdGuard status  AdGuard diagnostics
License
Purchase license [ Bind license ](https://adguard.com/go?hash=df20abeb2d26adb1a01ff6625e07cd7a&url=https%3A%2F%2Fadguardaccount.com%2Fredeem%2Fadguard%3F_plc%3Den) Recover license  Get free license  Partner with AdGuard  Contribute to AdGuard  Licenses for developers  AdGuard for schools and colleges  Beta testing program
Legal documents
EULA  EULA of AdGuard Temp Mail  Privacy policy  Privacy policy of AdGuard websites  Terms and conditions  Terms of sale  Data processing agreement
