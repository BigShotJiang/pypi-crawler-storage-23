import re
import itertools
from yt_dlp.extractor.common import InfoExtractor, SearchInfoExtractor
from yt_dlp.utils import int_or_none, urljoin


class AnimeInBase:
    """
    Base class untuk semua AnimeInWeb extractors.
    Berisi shared methods untuk API calls dan data processing.
    """

    # ----------------------------------------------------------------------
    # API UTILITIES
    # ----------------------------------------------------------------------

    def call_api(self, base_url='https://animeinweb.com',
                 path_url=None, item=None, query=None,
                 fatal=True, note='Downloading ANIMEIN API JSON'):
        """
        Universal method untuk memanggil API AnimeInWeb.

        Args:
            base_url: Base URL API (default: animeinweb.com)
            path_url: Path endpoint API
            item: Video ID untuk logging
            query: Query parameters dictionary
            fatal: Jika True, raise error pada failure
            note: Pesan untuk logging

        Returns:
            JSON response dari API
        """
        return self._download_json(
            urljoin(base_url, path_url),
            video_id=item,
            query=query,
            note=note,
            fatal=fatal
        )

    # ----------------------------------------------------------------------
    # METADATA EXTRACTION
    # ----------------------------------------------------------------------

    def _extract_anime_metadata(self, anime_id):
        """
        Ekstrak metadata dasar anime (judul, deskripsi, dll).

        Args:
            anime_id: ID anime dari URL

        Returns:
            Dictionary berisi metadata anime
        """
        response = self.call_api(
            path_url=f'/api/proxy/3/2/movie/detail/{anime_id}',
            item=anime_id,
            note='Downloading anime metadata'
        )

        # Return movie data atau empty dict jika tidak ditemukan
        return response.get('data', {}).get('movie', {})

    def _extract_anime_title(self, anime_id):
        """
        Ambil judul anime saja (convenience method).

        Args:
            anime_id: ID anime

        Returns:
            String judul anime atau fallback title
        """
        metadata = self._extract_anime_metadata(anime_id)
        return metadata.get('title', f'Anime {anime_id}')

    # ----------------------------------------------------------------------
    # EPISODE LIST EXTRACTION (PAGINATION)
    # ----------------------------------------------------------------------

    def _fetch_episode_list_page(self, anime_id, page_num):
        """
        Fetch satu halaman daftar episode dari API.

        Args:
            anime_id: ID anime
            page_num: Nomor halaman (0-indexed)

        Returns:
            List episode dalam halaman tersebut
        """
        response = self.call_api(
            path_url=f'/api/proxy/3/2/movie/episode/{anime_id}',
            item=anime_id,
            query={'page': page_num},
            note=f'Downloading episode list page {page_num}'
        )

        return response.get('data', {}).get('episode', [])

    def _extract_all_episodes(self, anime_id):
        """
        Ekstrak SEMUA episode dengan handle pagination.

        Args:
            anime_id: ID anime

        Returns:
            Generator yang yield setiap episode data
        """
        for page_num in itertools.count(0):
            episodes = self._fetch_episode_list_page(anime_id, page_num)

            # Stop jika halaman kosong (tidak ada episode lagi)
            if not episodes:
                self.to_screen('Tidak ada episode lagi di halaman berikutnya')
                break

            # Yield setiap episode dalam halaman ini
            for episode_data in episodes:
                yield episode_data

    # ----------------------------------------------------------------------
    # STREAM / FORMAT EXTRACTION
    # ----------------------------------------------------------------------

    def _fetch_stream_data(self, episode_id, episode):
        """
        Fetch data stream untuk satu episode.

        Args:
            episode_id: ID episode

        Returns:
            List server/stream data untuk episode tersebut
        """
        response = self.call_api(
            path_url=f'/api/proxy/3/2/episode/streamnew/{episode_id}',
            item=episode_id,
            note=f'Downloading stream data for episode {episode}'
        )

        return response.get('data', {}).get('server', [])

    def _parse_quality_string(self, quality_str):
        """
        Parse string kualitas (e.g., '720p', '1080p') menjadi height integer.

        Args:
            quality_str: String kualitas

        Returns:
            Integer height atau None jika invalid
        """
        if not quality_str:
            return None

        # Match pattern seperti '720', '720p', '1080', '1080p'
        match = re.match(r'^(\d+)p?$', quality_str, re.IGNORECASE)
        if match:
            return int(match.group(1))

        return None

    def _calculate_width_from_height(self, height):
        """
        Hitung width berdasarkan height dengan aspek rasio 16:9.

        Args:
            height: Video height

        Returns:
            Width yang sesuai atau None
        """
        if not height:
            return None
        return int((height * 16) / 9)

    def _parse_filesize(self, size_str):
        """
        Parse string filesize (e.g., '1.2') menjadi bytes.
        Asumsi: API memberikan size dalam MB.

        Args:
            size_str: String filesize dalam MB

        Returns:
            Filesize dalam bytes atau None
        """
        try:
            if not size_str:
                return None
            # Convert MB to bytes
            return int(float(size_str) * 1024 * 1024)
        except (ValueError, TypeError):
            return None

    def _build_format_entry(self, stream_data):
        """
        Build satu format entry dari stream data.

        Args:
            stream_data: Dictionary data stream dari API

        Returns:
            Format dictionary sesuai spesifikasi yt-dlp
        """
        stream_type = stream_data.get('type', '').lower()
        quality_str = stream_data.get('quality', '')
        stream_url = stream_data.get('link')

        # Hanya proses direct streams
        if stream_type != 'direct' or not stream_url:
            return None

        # Parse quality untuk mendapatkan height
        height = self._parse_quality_string(quality_str)
        if not height:
            return None

        return {
            'url': stream_url,
            'ext': 'mp4',  # Asumsi format video
            'format_id': quality_str,
            'height': height,
            'width': self._calculate_width_from_height(height),
            'filesize': self._parse_filesize(stream_data.get('key_file_size')),
            'quality': quality_str,
            'vcodec': 'h264',  # Asumsi codec umum
        }

    def _extract_formats(self, episode_id, episode):
        """
        Ekstrak semua format yang tersedia untuk satu episode.

        Args:
            episode_id: ID episode

        Returns:
            List format dictionaries
        """
        streams = self._fetch_stream_data(episode_id, episode)
        formats = []

        for stream in streams:
            format_entry = self._build_format_entry(stream)
            if format_entry:
                formats.append(format_entry)

        return formats

    # ----------------------------------------------------------------------
    # THUMBNAIL HANDLING
    # ----------------------------------------------------------------------

    def _process_thumbnail_url(self, image_url, base_url='https://api.animein.net'):
        """
        Process thumbnail URL dari berbagai format ke URL yang valid.

        Args:
            image_url: URL gambar dari API (bisa relative/absolute)
            base_url: Base URL untuk relative paths

        Returns:
            Valid thumbnail URL atau None
        """
        if not image_url:
            return None

        # Jika sudah absolute URL
        if image_url.startswith(('http://', 'https://')):
            # Tambah _full.jpg jika belum ada
            if not image_url.endswith('_full.jpg'):
                return f'{image_url}_full.jpg'
            return image_url

        # Jika relative path
        if image_url.startswith(('/', '/assets')):
            return f'{base_url}{image_url}'

        # Format tidak dikenali
        return None

    # ----------------------------------------------------------------------
    # SEARCH FUNCTIONALITY
    # ----------------------------------------------------------------------

    def _search_anime(self, query):
        """
        Search anime berdasarkan keyword.

        Args:
            query: Search keyword

        Returns:
            List hasil search
        """
        # NOTE: Saat ini hanya mengambil halaman pertama
        # TODO: Implement pagination jika diperlukan
        response = self.call_api(
            path_url='/api/proxy/3/2/explore/movie',
            item=query,
            query={
                'page': 0,
                'sort': 'views',
                'keyword': query
            },
            note=f'Searching for: {query}'
        )

        return response.get('data', {}).get('movie', [])


class AnimeInWebIE(AnimeInBase, InfoExtractor):
    """
    Extractor untuk halaman anime individual di AnimeInWeb.
    URL format: https://animeinweb.com/anime/{id}
    """

    IE_NAME = 'animeinweb'
    IE_DESC = 'AnimeInWeb Anime Extractor'
    _VALID_URL = r'https?://animeinweb\.com/anime/(?P<id>\d+)'

    def _build_episode_entry(self, episode_data, anime_title, base_url):
        """
        Build entry dictionary untuk satu episode.

        Args:
            episode_data: Raw episode data dari API
            anime_title: Judul anime (untuk metadata)
            base_url: URL asli anime

        Returns:
            Episode entry dictionary sesuai spesifikasi yt-dlp
        """
        episode_id = episode_data.get('id')
        episode_title = episode_data.get('title', '')
        episode_index = episode_data.get('index')

        return {
            'id': episode_id,
            'title': f'{anime_title} - {episode_title}',
            'series': anime_title,
            'playlist_title': anime_title,
            'episode': episode_title,
            'episode_number': int_or_none(episode_index),
            'thumbnail': self._process_thumbnail_url(
                image_url=episode_data.get('image')
            ),
            'formats': self._extract_formats(episode_id, episode_title),
            'webpage_url': base_url,
            'uploader_url': 'https://animeinweb.com',
        }

    def _real_extract(self, url):
        """
        Main extraction method untuk anime playlist.

        Workflow:
        1. Extract anime ID dari URL
        2. Fetch anime metadata (judul)
        3. Extract semua episode dengan pagination
        4. Build episode entries dengan format extraction
        5. Return playlist result

        Args:
            url: Anime URL

        Returns:
            Playlist dictionary sesuai spesifikasi yt-dlp
        """
        # Debug message
        self.to_screen('Memulai ekstraksi anime...')

        # Step 1: Extract anime ID dari URL
        anime_id = self._match_id(url)
        self.to_screen(f'Anime ID: {anime_id}')

        # Step 2: Fetch anime metadata
        anime_title = self._extract_anime_title(anime_id)
        self.to_screen(f'Judul anime: {anime_title}')

        # Step 3: Extract semua episode
        entries = []
        episode_count = 0

        for episode_data in self._extract_all_episodes(anime_id):
            # Step 4: Build entry untuk setiap episode
            entry = self._build_episode_entry(
                episode_data=episode_data,
                anime_title=anime_title,
                base_url=url
            )

            entries.append(entry)
            episode_count += 1

            # Progress logging setiap 5 episode
            if episode_count % 5 == 0:
                self.to_screen(f'Memproses episode ke-{episode_count}...')

        self.to_screen(f'Selesai! Ditemukan {episode_count} episode.')

        # Step 5: Return playlist result
        # NOTE: API return episode terbaru duluan, jadi perlu di-reverse
        return {
            '_type': 'playlist',
            'id': anime_id,
            'title': anime_title,
            'description': f'Playlist untuk {anime_title}',
            'channel': 'AnimeInWeb',
            'channel_url': 'https://animeinweb.com',
            'channel_id': 'animeinweb',
            'entries': list(reversed(entries)),  # Urutkan dari episode 1
            'playlist_count': len(entries),
        }


class AnimeInSearchIE(SearchInfoExtractor, AnimeInBase):
    """
    Search extractor untuk AnimeInWeb.
    Mendukung pencarian anime melalui yt-dlp.
    """

    IE_NAME = 'animeinweb:search'
    IE_DESC = 'AnimeInWeb Search Extractor'
    _SEARCH_KEY = 'animein'

    def _search_results(self, query):
        """
        Yield search results untuk query.

        Args:
            query: Search keyword

        Yields:
            url_result untuk setiap anime yang ditemukan
        """
        search_results = self._search_anime(query)

        if not search_results:
            return

        self.to_screen(f'Ditemukan {len(search_results)} hasil untuk: {query}')

        for anime_data in search_results:
            anime_id = anime_data.get('id')
            anime_title = anime_data.get('title', f'Anime {anime_id}')

            self.to_screen(f'  → {anime_title} (ID: {anime_id})')

            # Yield URL result untuk diproses oleh AnimeInWebIE
            yield self.url_result(
                url=f'https://animeinweb.com/anime/{anime_id}',
                ie=AnimeInWebIE,
                video_id=anime_id,
                video_title=anime_title,
            )
