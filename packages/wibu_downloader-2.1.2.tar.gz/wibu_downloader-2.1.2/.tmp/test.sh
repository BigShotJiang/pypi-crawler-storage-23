#!/usr/bin/env bash


venv="$PWD/.venv"
if [ -z "$VIRTUAL_ENV" ]; then
    if [ -d "$venv" ]; then
        source "$venv/bin/activate"
    else
        python3 -m venv $venv
        source "$venv/bin/activate"
    fi
fi


if ! command -v yt-dlp >/dev/null; then
    pip install 'yt-dlp[default]'
fi

case "$1" in
    -i|i) pip install .;;
    -m|m) mpv 'https://animeinweb.com/anime/1280';;
    # *)yt-dlp -sv 'animein:jujutsu kaisen';;
    *)yt-dlp -sv 'https://animeinweb.com/anime/1280';;
esac