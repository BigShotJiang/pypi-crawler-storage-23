"""Invoke plugin for sphinx."""

from __future__ import annotations

from invoke_plugin_for_sphinx._plugin import setup

__all__ = ("setup",)
