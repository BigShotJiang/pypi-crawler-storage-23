# Changelog

<!-- towncrier release notes start -->

## 4.2.0 (2026-02-20)

### Changes

- Updated the release actions


# 4.1.0
* Add support for sphinx 9

# 4.0.0
* Removed support for python 3.9

# 3.1.0
* Support python 3.14

# 3.0.0
* Support python 3.13
* Dropped support for python 3.8

## 2.1.0

* Add support for sphinx 8

## 2.0.0

* Drop support for sphinx 4, 5 and 6
* Drop support for python 3.7
* Drop support for invoke 1
* Add support for python 3.12

## 1.1.0

* Support sphinx 7.*

## 1.0.0

* Initial version
