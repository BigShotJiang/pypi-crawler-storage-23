from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

READ_FILE_TOOL_DESCRIPTION: str

class ReadFileInput(BaseModel):
    """Input schema for read_file tool."""
    path: str
    offset: int
    limit: int

class ReadFileTool(BaseTool):
    """Tool for reading file contents with optional pagination."""
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
