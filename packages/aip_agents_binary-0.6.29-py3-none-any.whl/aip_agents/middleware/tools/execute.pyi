from aip_agents.middleware.backends.protocol import ExecuteResult as ExecuteResult
from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

class ExecuteInput(BaseModel):
    """Input schema for the execute tool.

    Attributes:
        command: The shell command to execute.
        timeout: Timeout in seconds (optional, defaults to 30).
    """
    command: str
    timeout: int

class ExecuteTool(BaseTool):
    '''Tool for executing shell commands via backend.

    This tool wraps backend command execution with proper timeout handling,
    output formatting, and graceful error handling for unsupported backends.

    Attributes:
        name: Tool name ("execute").
        description: Tool description for LLM.
        args_schema: Input schema class.
        backend: BackendProtocol instance for execution.
        max_execute_timeout: Maximum allowed timeout in seconds.
    '''
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
    max_execute_timeout: int
