"""Execute tool for running shell commands.

This module provides the ExecuteTool class that wraps backend command execution
with a LangChain tool interface, including timeout handling and output formatting.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

import inspect
from functools import lru_cache
from typing import Annotated, Any

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, SkipValidation

from aip_agents.middleware.backends.protocol import ExecuteResult


class ExecuteInput(BaseModel):
    """Input schema for the execute tool.

    Attributes:
        command: The shell command to execute.
        timeout: Timeout in seconds (optional, defaults to 30).
    """

    command: str = Field(description="Shell command to execute")
    timeout: int = Field(default=30, description="Timeout in seconds", ge=1)


class ExecuteTool(BaseTool):
    """Tool for executing shell commands via backend.

    This tool wraps backend command execution with proper timeout handling,
    output formatting, and graceful error handling for unsupported backends.

    Attributes:
        name: Tool name ("execute").
        description: Tool description for LLM.
        args_schema: Input schema class.
        backend: BackendProtocol instance for execution.
        max_execute_timeout: Maximum allowed timeout in seconds.
    """

    name: str = "execute"
    description: str = (
        "Execute a shell command. Returns stdout/stderr with exit code. "
        "Use timeout parameter for long-running commands."
    )
    args_schema: type[BaseModel] = ExecuteInput
    backend: Annotated[Any, SkipValidation()]  # BackendProtocol - skip validation for Protocol type
    max_execute_timeout: int = 300

    def _run(self, command: str, timeout: int = 30) -> str:
        """Execute a command with the configured backend.

        Args:
            command: Shell command to execute.
            timeout: Timeout in seconds (clamped to 1-max_execute_timeout).

        Returns:
            Formatted execution result or error message.
        """
        timeout = self._clamp_timeout(timeout)

        if not self._backend_supports_execution():
            return (
                "Error: Execution not available. This agent's backend "
                "does not support command execution. "
                "To use the execute tool, provide a backend that implements "
                "the execute() method."
            )

        backend_class = type(self.backend)
        if not ExecuteTool._execute_accepts_timeout(backend_class):
            return (
                "Error: This backend does not support per-command timeout "
                "overrides. Update your backend package or omit the timeout parameter."
            )

        try:
            result = self.backend.execute(command, timeout=timeout)
            return self._format_result(result)
        except NotImplementedError as e:
            return f"Error: Execution not available. {e}"
        except ValueError as e:
            return f"Error: Invalid parameter. {e}"
        except Exception as e:
            return f"Error: Execution failed. {str(e)}"

    def _clamp_timeout(self, timeout: int) -> int:
        """Clamp timeout to valid range.

        Args:
            timeout: Requested timeout in seconds.

        Returns:
            Timeout clamped between 1 and max_execute_timeout.
        """
        return max(1, min(timeout, self.max_execute_timeout))

    def _backend_supports_execution(self) -> bool:
        """Check if backend supports execution.

        Returns:
            True if backend has callable execute method.
        """
        return hasattr(self.backend, "execute") and callable(getattr(self.backend, "execute"))

    @staticmethod
    @lru_cache(maxsize=128)
    def _execute_accepts_timeout(backend_class: type) -> bool:
        """Check if backend's execute accepts timeout parameter.

        Args:
            backend_class: The backend class to inspect.

        Returns:
            True if execute method accepts timeout parameter.
        """
        if not hasattr(backend_class, "execute"):
            return False
        try:
            sig = inspect.signature(backend_class.execute)
            return "timeout" in sig.parameters
        except (ValueError, TypeError):
            return False

    def _format_result(self, result: ExecuteResult) -> str:
        """Format execution result for LLM consumption.

        Args:
            result: ExecuteResult from backend.

        Returns:
            Formatted output string with stdout, stderr, exit code.
        """
        parts: list[str] = []

        if result.stdout:
            parts.append(f"STDOUT:\n{result.stdout}")
        if result.stderr:
            parts.append(f"STDERR:\n{result.stderr}")

        status = "succeeded" if result.exit_code == 0 else "failed"
        parts.append(f"\n[Command {status} with exit code {result.exit_code}]")

        if result.truncated:
            parts.append("\n[Output was truncated due to size limits]")

        return "\n".join(parts)
