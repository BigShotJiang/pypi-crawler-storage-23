from langchain_core.tools import BaseTool as BaseTool
from typing import Any, Protocol, TypedDict

class ModelRequest(TypedDict, total=False):
    """Represents parameters for a model invocation that middleware can modify.

    This TypedDict defines the structure of requests passed to the LLM, allowing
    middleware to add tools or modify prompts before each invocation.

    Attributes:
        messages: List of messages in the conversation.
        tools: List of tools available to the model.
        system_prompt: System-level instruction for the model.
    """
    messages: list[Any]
    tools: list[BaseTool]
    system_prompt: str

class AgentMiddleware(Protocol):
    """Protocol defining the interface for composable agent middleware.

    Middleware components can contribute tools, enhance system prompts, and provide
    lifecycle hooks that execute before, during, and after model invocations.

    All middleware must implement this protocol to be compatible with MiddlewareManager.

    Attributes:
        tools: List of tools contributed by this middleware.
        system_prompt_additions: Optional text to append to the agent's system prompt.
    """
    tools: list[BaseTool]
    system_prompt_additions: str | None
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed before each model invocation.

        Use this hook to prepare state, log context, or perform setup tasks
        before the model is called.

        Args:
            state: Current agent state containing messages and other context.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous version of before_model hook."""
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Hook to modify the model request before invocation.

        Use this hook to add tools, modify the system prompt, adjust model parameters,
        or change tool selection strategy.

        Args:
            request: The model request that will be sent to the LLM.
            state: Current agent state for context.

        Returns:
            Modified ModelRequest. Can return the same request if no changes needed.
        """
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Hook executed after each model invocation.

        Use this hook for cleanup, logging, state updates, or post-processing
        of model outputs.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Dict of state updates to merge into the agent state. Return empty dict
            if no updates are needed.
        """
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronous version of after_model hook."""
    def before_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Hook executed before each agent run.

        Use this hook for run-level setup like memory recall or audit logging.

        Args:
            state: Initial agent state.
            config: Optional run configuration.

        Returns:
            Dict of state updates to merge. Return empty dict if no updates needed.
        """
    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Asynchronous version of before_run hook."""
    def after_run(self, *, final_state: dict[str, Any], output: str | None, config: dict[str, Any] | None, error: Exception | None) -> None | dict[str, Any]:
        """Hook executed after each agent run.

        Use this hook for run-level cleanup like memory persistence.

        Args:
            final_state: Final agent state after run completion.
            output: The final output string from the agent, or None if failed.
            config: Optional run configuration.
            error: Exception if the run failed, None if successful.

        Returns:
            Optional dict of state updates. None if no updates needed.
        """
    async def aafter_run(self, *, final_state: dict[str, Any], output: str | None, config: dict[str, Any] | None, error: Exception | None) -> None | dict[str, Any]:
        """Asynchronous version of after_run hook."""
    def on_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Hook executed when streaming final response is captured.

        This hook is invoked during A2A streaming when a FINAL_RESPONSE event is emitted.
        It enables early side effects (e.g. fire-and-forget persistence) without waiting
        for the stream consumer to finish reading.

        Args:
            content: Final response text content.
            context: Context dict (agent name, thread id, original query, etc.).
        """
    async def aon_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Asynchronous version of on_final_response hook."""
