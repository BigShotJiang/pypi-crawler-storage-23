from aip_agents.middleware.backends.protocol import BackendProtocol as BackendProtocol
from aip_agents.skills.errors import SkillValidationError as SkillValidationError
from aip_agents.skills.models import Skill as Skill
from collections.abc import Sequence
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class StagedSkill:
    """Represents the result of staging a single skill.

    Attributes:
        name (str): Skill name.
        backend_root (str): Backend root directory for the staged skill.
        staged_files (tuple[str, ...]): Backend file paths written.
    """
    name: str
    backend_root: str
    staged_files: tuple[str, ...]

class SkillStager:
    """Stage local skills into a backend storage namespace."""
    def __init__(self, *, backend: BackendProtocol, destination_root: str = ...) -> None:
        '''Initialize SkillStager.

        Args:
            backend (BackendProtocol): Backend used for writes.
            destination_root (str, optional): Backend root under which skills are staged. Defaults to "/skills".

        Returns:
            None: This initializer returns None.
        '''
    def stage(self, skills: Sequence[Skill]) -> list[StagedSkill]:
        """Stage a collection of skills into the backend.

        Args:
            skills (Sequence[Skill]): Skills to stage.

        Returns:
            list[StagedSkill]: Staging results for each skill.

        Raises:
            SkillValidationError: If a provided skill is missing required files.
        """
    def stage_one(self, skill: Skill) -> StagedSkill:
        """Stage a single skill into the backend.

        Files are written under:
            /skills/<skill-name>/<relative-path>

        Binary files are skipped in prompt-only milestones.

        Args:
            skill (Skill): Skill to stage.

        Returns:
            StagedSkill: Staging result.

        Raises:
            SkillValidationError: If SKILL.md is missing.
        """
