import os
from _typeshed import Incomplete
from aip_agents.skills.installer import SkillInstaller as SkillInstaller
from aip_agents.skills.validation import validate_skill_root as validate_skill_root
from pathlib import Path
from pydantic import BaseModel

class Skill(BaseModel):
    """Represents an installed skill.

    Attributes:
        name (str): Skill name (derived from folder name).
        description (str | None): Optional metadata. Defaults to None.
        version (str | None): Optional metadata. Defaults to None.
        tags (tuple[str, ...]): Optional metadata. Defaults to ().
        triggers (tuple[str, ...]): Optional metadata. Defaults to ().
        source (str | None): The install source, when applicable. Defaults to None.
        local_root_path (Path): Local filesystem path to the skill root.
        backend_root (str): Deterministic backend root path (`/skills/<name>`).
    """
    name: str
    local_root_path: Path
    source: str | None
    description: str | None
    version: str | None
    tags: tuple[str, ...]
    triggers: tuple[str, ...]
    model_config: Incomplete
    class Config:
        """Pydantic v1 fallback config for Skill."""
        allow_mutation: bool
    @property
    def local_root(self) -> str:
        """Local filesystem root as a string path.

        Returns:
            str: Local skill root path.
        """
    @property
    def backend_root(self) -> str:
        """Backend root path used for staging (`/skills/<skill-name>`).

        Returns:
            str: Backend root path.
        """
    @property
    def skill_md_path(self) -> Path:
        """Return the path to the required SKILL.md file.

        Returns:
            Path: SKILL.md file path.
        """
    @classmethod
    def from_path(cls, path: str | os.PathLike[str]) -> Skill:
        """Create a Skill object from an already-installed local directory.

        Args:
            path (str | os.PathLike[str]): Path to a skill directory.

        Returns:
            Skill: The validated skill object.

        Raises:
            SkillValidationError: If the path is not a valid skill.
        """
    @classmethod
    async def from_github(cls, *, source: str, destination_root: str | os.PathLike[str], token: str | None = None) -> Skill:
        """Install a skill from GitHub and return a Skill object.

        Args:
            source (str): GitHub tree URL pointing at a skill directory.
            destination_root (str | os.PathLike[str]): Installation destination root
                (e.g. `.agents/skills`).
            token (str | None, optional): GitHub token used for private repos. Defaults to None.

        Returns:
            Skill: The installed and validated skill.

        Raises:
            SkillInstallError: If installation fails.
            SkillValidationError: If the installed result is invalid.
        """
