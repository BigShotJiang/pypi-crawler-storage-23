from langchain_core.tools import BaseTool
from pydantic import BaseModel

class MultiplyToolInput(BaseModel):
    """Input schema for the MultiplyTool."""
    a: int
    b: int

class MultiplyToolConfig(BaseModel):
    """Configuration for MultiplyTool."""
    offset: int

class MultiplyTool(BaseTool):
    """Tool to multiply two integers."""
    name: str
    description: str
    args_schema: type[BaseModel]
    tool_config_schema: type[BaseModel]
