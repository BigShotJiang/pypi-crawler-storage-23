from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

InvokeWithTimeout = Callable[[float], Awaitable[Any]]

@dataclass(frozen=True)
class ResilienceRequest:
    """Execution request shared by resilience executors.

    Attributes:
        operation_name: Stable operation identity, for example a tool name.
        operation_source: Source label used in diagnostics and user metadata.
        metadata: Optional runtime metadata containing resilience overrides.
        invoke_with_timeout: Async callable that executes one attempt with an effective timeout.
    """
    operation_name: str
    operation_source: str
    metadata: dict[str, Any] | None
    invoke_with_timeout: InvokeWithTimeout

class BaseResilienceExecutor(ABC):
    """Base contract for reusable resilience executors."""
    @abstractmethod
    async def execute(self, request: ResilienceRequest) -> Any:
        """Execute one operation request with resilience behavior.

        Args:
            request: Shared execution request with metadata and invocation callback.

        Returns:
            Operation output or structured error payload.
        """
