from aip_agents.ptc.custom_tools import PTCFileToolDef as PTCFileToolDef, PTCPackageToolDef as PTCPackageToolDef
from typing import Any

def package_tool(name: str, *, import_path: str, class_name: str, package_path: str | None = None, description: str | None = None, input_schema: dict[str, Any] | None = None) -> PTCPackageToolDef:
    '''Create a package-based tool definition.

    Args:
        name: Tool name (will be sanitized for Python compatibility).
        import_path: Python import path (e.g., "aip_agents.tools.time_tool").
        class_name: Tool class name to instantiate.
        package_path: Optional local package path for bundling.
        description: Optional tool description (auto-derived from tool if not provided).
        input_schema: Optional JSON schema (auto-derived from tool if not provided).

    Returns:
        PTCPackageToolDef dict ready for use in PTCCustomToolConfig.tools.

    Example:
        >>> package_tool("time_tool", import_path="aip_agents.tools.time_tool", class_name="TimeTool")
        {\'name\': \'time_tool\', \'kind\': \'package\', \'import_path\': \'aip_agents.tools.time_tool\', \'class_name\': \'TimeTool\'}
    '''
def file_tool(name: str, *, file_path: str, class_name: str, description: str | None = None, input_schema: dict[str, Any] | None = None) -> PTCFileToolDef:
    '''Create a file-based tool definition.

    Args:
        name: Tool name (will be sanitized for Python compatibility).
        file_path: Absolute path to the Python file containing the tool.
        class_name: Tool class name to instantiate.
        description: Optional tool description (auto-derived from tool if not provided).
        input_schema: Optional JSON schema (auto-derived from tool if not provided).

    Returns:
        PTCFileToolDef dict ready for use in PTCCustomToolConfig.tools.

    Example:
        >>> file_tool("multiply", file_path="/path/to/multiply_tool.py", class_name="MultiplyTool")
        {\'name\': \'multiply\', \'kind\': \'file\', \'file_path\': \'/path/to/multiply_tool.py\', \'class_name\': \'MultiplyTool\'}
    '''
