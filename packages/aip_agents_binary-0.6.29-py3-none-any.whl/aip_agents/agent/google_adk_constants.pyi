__all__ = ['DEFAULT_AUTH_URL']

DEFAULT_AUTH_URL: str
