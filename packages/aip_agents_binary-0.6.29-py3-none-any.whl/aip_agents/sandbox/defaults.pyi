from aip_agents.mcp.client.base_mcp_client import BaseMCPClient as BaseMCPClient
from aip_agents.ptc.custom_tools import PTCCustomToolConfig as PTCCustomToolConfig

DEFAULT_PTC_TEMPLATE: str
AIP_AGENTS_BINARY_LOCAL: str
DEFAULT_PTC_PACKAGES: tuple[str, ...]

def select_sandbox_packages(*, mcp_client: BaseMCPClient | None, custom_tools_config: PTCCustomToolConfig | None, template: str | None, user_ptc_packages: list[str] | None) -> list[str] | None:
    """Select minimal packages to install in sandbox based on tool types.

    This function implements the smart package selection logic:
    - DEFAULT_PTC_TEMPLATE + no user packages: Skip install (template has all deps)
    - DEFAULT_PTC_TEMPLATE + user packages: User packages + PTCCustomToolConfig.requirements
    - Other template + no user packages: Build packages from tool types
    - Other template + user packages: User packages + tool-type packages + PTCCustomToolConfig.requirements

    Key principle: Tools won't work without their required packages. Always ensure:
    - MCP tools → mcp + httpx installed
    - Custom LangChain tools → langchain + gllm-plugin-binary installed
    - Native AIP tools → aip-agents-binary[local] installed

    Args:
        mcp_client: The MCP client (check if has servers for MCP tools).
        custom_tools_config: Custom tools configuration (includes tools list and .requirements field).
        template: Sandbox template being used.
        user_ptc_packages: Explicitly provided packages by user (None if not set).

    Returns:
        List of packages to install, or None to skip installation.
    """
