# nw-platform-architect-reviewer

Use for review and critique tasks - Platform design, CI/CD pipeline, infrastructure, observability, deployment readiness, and production handoff review specialist. Runs on Haiku for cost efficiency.

**Wave:** DESIGN
**Model:** haiku
**Max turns:** 30
**Tools:** Read, Glob, Grep, Task

## Commands

- [`/nw:review`](../commands/index.md)

## Skills

- [critique-dimensions](../../../nWave/skills/acceptance-designer/critique-dimensions.md) — Review dimensions for acceptance test quality - happy path bias, GWT compliance, business language purity, coverage completeness, walking skeleton user-centricity, and priority validation
- [critique-dimensions](../../../nWave/skills/agent-builder/critique-dimensions.md) — Review dimensions for validating agent quality - template compliance, safety, testing, and priority validation
- [critique-dimensions](../../../nWave/skills/platform-architect-reviewer/critique-dimensions.md) — Platform design review critique dimensions and severity levels. Load when reviewing CI/CD pipelines, infrastructure, deployment strategies, observability, or security designs.
- [critique-dimensions](../../../nWave/skills/researcher-reviewer/critique-dimensions.md) — Critique dimensions and scoring for research document reviews
- [critique-dimensions](../../../nWave/skills/solution-architect/critique-dimensions.md) — Architecture quality critique dimensions for peer review. Load when invoking solution-architect-reviewer or performing self-review of architecture documents.
- [review-criteria](../../../nWave/skills/data-engineer-reviewer/review-criteria.md) — Evaluation criteria and scoring for data engineering artifact reviews
- [review-criteria](../../../nWave/skills/documentarist-reviewer/review-criteria.md) — Critique dimensions, severity framework, verdict decision matrix, and review output format for documentation assessment reviews
- [review-criteria](../../../nWave/skills/platform-architect-reviewer/review-criteria.md) — Quality dimensions and review checklist for devop reviews
- [review-criteria](../../../nWave/skills/product-discoverer-reviewer/review-criteria.md) — Evidence quality validation and decision gate criteria for product discovery reviews
- [review-criteria](../../../nWave/skills/product-owner-reviewer/review-criteria.md) — Review dimensions and bug patterns for journey artifact reviews
- [review-criteria](../../../nWave/skills/troubleshooter-reviewer/review-criteria.md) — Review dimensions and scoring for root cause analysis quality assessment
- [review-output-format](../../../nWave/skills/platform-architect-reviewer/review-output-format.md) — YAML output format and approval criteria for platform design reviews. Load when generating review feedback.
