# nw-functional-software-crafter

DELIVER wave - Outside-In TDD with functional paradigm. Pure functions, pipeline composition, types as documentation, property-based testing. Use when the project follows a functional-first approach (F#, Haskell, Scala, Clojure, Elixir, or FP-heavy TypeScript/Python/Kotlin).

**Wave:** DELIVER
**Model:** inherit
**Max turns:** 50
**Tools:** Read, Write, Edit, Bash, Glob, Grep, Task

## Commands

- [`/nw:deliver`](../commands/index.md)
- [`/nw:design`](../commands/index.md)

## Skills

- [collaboration-and-handoffs](../../../nWave/skills/software-crafter/collaboration-and-handoffs.md) — Cross-agent collaboration protocols, workflow handoff patterns, and commit message formats for TDD/Mikado/refactoring workflows
- [fp-algebra-driven-design](../../../nWave/skills/functional-software-crafter/fp-algebra-driven-design.md) — Algebraic thinking for API design. Discover the right API before implementing by specifying rules (equations) that operations must satisfy.
- [fp-domain-modeling](../../../nWave/skills/functional-software-crafter/fp-domain-modeling.md) — Domain modeling with types. Make illegal states unrepresentable, workflows as pipelines, error handling at the type level.
- [fp-hexagonal-architecture](../../../nWave/skills/functional-software-crafter/fp-hexagonal-architecture.md) — Ports and adapters in functional programming. Structure applications with a pure core and side-effect shell.
- [fp-principles](../../../nWave/skills/functional-software-crafter/fp-principles.md) — Core functional programming thinking patterns. Language-agnostic.
- [fp-usable-design](../../../nWave/skills/functional-software-crafter/fp-usable-design.md) — Make functional code usable. The developer is the user of your design. Apply usability thinking to code organization, naming, and architecture.
- [hexagonal-testing](../../../nWave/skills/software-crafter/hexagonal-testing.md) — 5-layer agent output validation, I/O contract specification, vertical slice development, and test doubles policy with per-layer examples
- [pbt-fundamentals](../../../nWave/skills/functional-software-crafter/pbt-fundamentals.md) — Core property-based testing knowledge, language-agnostic. Load language-specific skills for framework syntax.
- [pbt-stateful](../../../nWave/skills/functional-software-crafter/pbt-stateful.md) — Stateful property-based testing for systems with mutable state. Language-agnostic concepts; load language skills for framework syntax.
- [progressive-refactoring](../../../nWave/skills/software-crafter/progressive-refactoring.md) — Progressive L1-L6 refactoring hierarchy, 22 code smell taxonomy, atomic transformations, test code smells, and Fowler refactoring catalog
- [property-based-testing](../../../nWave/skills/software-crafter/property-based-testing.md) — Property-based testing strategies, mutation testing, shrinking, and combined PBT+mutation workflow for test quality validation
- [quality-framework](../../../nWave/skills/software-crafter/quality-framework.md) — Quality gates - 11 commit readiness gates, build/test protocol, validation checkpoints, and quality metrics
- [review-dimensions](../../../nWave/skills/product-owner/review-dimensions.md) — Requirements quality critique dimensions for peer review - confirmation bias detection, completeness validation, clarity checks, testability assessment, and priority validation
- [review-dimensions](../../../nWave/skills/software-crafter/review-dimensions.md) — Reviewer critique dimensions for peer review - implementation bias detection, test quality validation, completeness checks, and priority validation
- [tdd-methodology](../../../nWave/skills/software-crafter/tdd-methodology.md) — Deep knowledge for Outside-In TDD - double-loop architecture, ATDD integration, port-to-port testing, walking skeletons, and test doubles policy
- [test-refactoring-catalog](../../../nWave/skills/software-crafter/test-refactoring-catalog.md) — Detailed refactoring mechanics with step-by-step procedures, and test code smell catalog with detection patterns and before/after examples
