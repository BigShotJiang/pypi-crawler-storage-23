# Carpeta de herramientas (Sincronizada con el sistema de Skills)
# Solo tool_manager.py permanece aquí como orquestador.
