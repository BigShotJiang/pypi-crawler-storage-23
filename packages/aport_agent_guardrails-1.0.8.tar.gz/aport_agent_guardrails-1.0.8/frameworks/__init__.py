"""Framework adapters: base, LangChain, CrewAI."""

from aport_guardrails.frameworks.base import BaseAdapter

__all__ = ["BaseAdapter"]
