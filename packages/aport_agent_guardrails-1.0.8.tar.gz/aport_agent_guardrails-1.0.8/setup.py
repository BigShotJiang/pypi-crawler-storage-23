"""Setup script for editable install (pip < 21.3); pyproject.toml is canonical."""
from setuptools import setup

setup()
