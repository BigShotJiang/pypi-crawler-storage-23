class InvalidConfigClassError(TypeError):
    pass


class MultipleTopLevelConfigError(TypeError):
    pass
