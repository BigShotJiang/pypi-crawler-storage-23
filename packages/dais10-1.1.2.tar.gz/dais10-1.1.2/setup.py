"""
DAIS-10 Setup Configuration
Production-ready packaging configuration
"""

from setuptools import setup, find_packages
from pathlib import Path

# --------------------------------------------------
# Load Version Metadata
# --------------------------------------------------

version = {}
version_file = Path("dais10/version.py")

if version_file.exists():
    exec(version_file.read_text(encoding="utf-8"), version)

# --------------------------------------------------
# Load README
# --------------------------------------------------

readme_path = Path("README.md")
long_description = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

# --------------------------------------------------
# Setup Configuration
# --------------------------------------------------

setup(
    name="dais10",
    version=version.get("__version__", "0.0.1"),
    author=version.get("__author__", "Usman Zafar"),
    author_email=version.get("__email__", "usman19zafar@gmail.com"),
    description="DAIS-10 Governance & Semantic Intelligence Engine",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/dais10",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.10",

    # --------------------------------------------------
    # CLI ENTRY POINT (CRITICAL FIX)
    # --------------------------------------------------
    entry_points={
        "console_scripts": [
            "dais10=dais10.cli:main",
        ],
    },

    # Optional but recommended for industry-grade packaging
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)