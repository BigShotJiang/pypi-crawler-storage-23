"""
DAIS-10 Policy Engine
Enforce governance policies based on semantic tiers and business rules

Author: Dr. Usman Zafar, Muz Consultancy
Version: 1.1.0
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime


class GovernanceAction(Enum):
    """Governance actions to take based on policy violations"""
    ALLOW = "allow"
    WARN = "warn"
    BLOCK = "block"
    QUARANTINE = "quarantine"
    ALERT = "alert"
    AUDIT = "audit"


@dataclass
class GovernancePolicy:
    """Definition of a governance policy"""
    name: str
    description: str
    tier_requirement: str  # E, EC, C, CN, N
    min_score: float
    action_on_violation: GovernanceAction
    severity: str  # critical, high, medium, low
    enabled: bool = True
    
    def __str__(self):
        return f"Policy({self.name}, tier={self.tier_requirement}, score≥{self.min_score})"


class PolicyEngine:
    """
    DAIS-10 Policy Engine
    
    Enforces governance policies based on semantic classification results.
    
    Example:
        engine = PolicyEngine()
        engine.add_policy(GovernancePolicy(
            name="E-Tier Protection",
            description="Block operations on missing E-tier columns",
            tier_requirement="E",
            min_score=90.0,
            action_on_violation=GovernanceAction.BLOCK,
            severity="critical"
        ))
        
        results = engine.evaluate(descriptors)
    """
    
    def __init__(self):
        self.policies: List[GovernancePolicy] = []
        self.violation_log: List[Dict] = []
        self._default_policies()
    
    def _default_policies(self):
        """Load default governance policies"""
        
        # E-Tier: Essential - Missing is catastrophic
        self.add_policy(GovernancePolicy(
            name="E-Tier Mandatory",
            description="E-tier columns must be present and valid",
            tier_requirement="E",
            min_score=90.0,
            action_on_violation=GovernanceAction.BLOCK,
            severity="critical"
        ))
        
        # EC-Tier: Semi-Essential - Missing is serious
        self.add_policy(GovernancePolicy(
            name="EC-Tier High Priority",
            description="EC-tier columns should be present",
            tier_requirement="EC",
            min_score=70.0,
            action_on_violation=GovernanceAction.WARN,
            severity="high"
        ))
        
        # C-Tier: Contextual - Missing is notable
        self.add_policy(GovernancePolicy(
            name="C-Tier Context Required",
            description="C-tier columns provide important context",
            tier_requirement="C",
            min_score=50.0,
            action_on_violation=GovernanceAction.AUDIT,
            severity="medium"
        ))
    
    def add_policy(self, policy: GovernancePolicy):
        """Add a governance policy"""
        self.policies.append(policy)
    
    def remove_policy(self, policy_name: str):
        """Remove a policy by name"""
        self.policies = [p for p in self.policies if p.name != policy_name]
    
    def get_policy(self, policy_name: str) -> Optional[GovernancePolicy]:
        """Get a policy by name"""
        for policy in self.policies:
            if policy.name == policy_name:
                return policy
        return None
    
    def evaluate(self, descriptors: List[Any]) -> Dict[str, Any]:
        """
        Evaluate governance policies against semantic descriptors
        
        Args:
            descriptors: List of SemanticDescriptor objects
            
        Returns:
            Dictionary with evaluation results
        """
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'total_attributes': len(descriptors),
            'violations': [],
            'warnings': [],
            'alerts': [],
            'overall_status': 'PASS',
            'recommended_action': GovernanceAction.ALLOW
        }
        
        # Evaluate each descriptor against policies
        for descriptor in descriptors:
            for policy in self.policies:
                if not policy.enabled:
                    continue
                
                # Check if policy applies to this descriptor
                if descriptor.tier.value != policy.tier_requirement:
                    continue
                
                # Check if score meets requirement
                if descriptor.score < policy.min_score:
                    violation = {
                        'attribute': descriptor.attribute_name,
                        'policy': policy.name,
                        'tier': descriptor.tier.value,
                        'score': descriptor.score,
                        'required_score': policy.min_score,
                        'action': policy.action_on_violation.value,
                        'severity': policy.severity,
                        'description': policy.description
                    }
                    
                    # Log violation
                    self.violation_log.append(violation)
                    
                    # Categorize by action
                    if policy.action_on_violation == GovernanceAction.BLOCK:
                        results['violations'].append(violation)
                        results['overall_status'] = 'FAIL'
                        results['recommended_action'] = GovernanceAction.BLOCK
                    
                    elif policy.action_on_violation == GovernanceAction.WARN:
                        results['warnings'].append(violation)
                        if results['overall_status'] == 'PASS':
                            results['overall_status'] = 'WARN'
                            results['recommended_action'] = GovernanceAction.WARN
                    
                    elif policy.action_on_violation == GovernanceAction.ALERT:
                        results['alerts'].append(violation)
        
        results['violation_count'] = len(results['violations'])
        results['warning_count'] = len(results['warnings'])
        results['alert_count'] = len(results['alerts'])
        
        return results
    
    def get_violations(self, severity: Optional[str] = None) -> List[Dict]:
        """Get violation log, optionally filtered by severity"""
        if severity:
            return [v for v in self.violation_log if v['severity'] == severity]
        return self.violation_log
    
    def clear_violations(self):
        """Clear the violation log"""
        self.violation_log = []
    
    def summary(self) -> str:
        """Get a summary of the policy engine status"""
        enabled_count = sum(1 for p in self.policies if p.enabled)
        return (
            f"PolicyEngine: {enabled_count} policies active, "
            f"{len(self.violation_log)} violations logged"
        )
    
    def __repr__(self):
        return self.summary()


def enforce_governance(descriptors: List[Any], 
                      custom_policies: Optional[List[GovernancePolicy]] = None) -> Dict[str, Any]:
    """
    Convenience function to enforce governance policies
    
    Args:
        descriptors: List of SemanticDescriptor objects
        custom_policies: Optional list of custom policies to add
        
    Returns:
        Governance evaluation results
    """
    
    engine = PolicyEngine()
    
    if custom_policies:
        for policy in custom_policies:
            engine.add_policy(policy)
    
    return engine.evaluate(descriptors)
