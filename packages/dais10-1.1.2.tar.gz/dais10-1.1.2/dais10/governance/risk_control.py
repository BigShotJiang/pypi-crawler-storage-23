"""
DAIS-10 Risk Control
Risk assessment and control mechanisms for safety-critical decisions

Author: Dr. Usman Zafar, Muz Consultancy
Version: 1.1.0
"""

from enum import Enum
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


class RiskLevel(Enum):
    """Risk level classification"""
    CRITICAL = "critical"    # Immediate action required
    HIGH = "high"            # Urgent attention needed
    MEDIUM = "medium"        # Monitor closely
    LOW = "low"              # Routine monitoring
    MINIMAL = "minimal"      # No immediate concern


@dataclass
class RiskAssessment:
    """Result of risk assessment"""
    level: RiskLevel
    score: float  # 0-100, higher = more risk
    factors: List[str]
    recommendations: List[str]
    affected_attributes: List[str]
    
    def is_critical(self) -> bool:
        return self.level == RiskLevel.CRITICAL
    
    def is_high(self) -> bool:
        return self.level in (RiskLevel.CRITICAL, RiskLevel.HIGH)
    
    def __str__(self):
        return f"Risk: {self.level.value.upper()} (score: {self.score:.1f})"


class RiskController:
    """
    DAIS-10 Risk Controller
    
    Assesses and manages risk levels based on semantic analysis results.
    
    Example:
        controller = RiskController()
        risk = controller.assess(descriptors)
        
        if risk.is_critical():
            print("CRITICAL RISK - Take immediate action")
            for rec in risk.recommendations:
                print(f"  - {rec}")
    """
    
    def __init__(self):
        self.risk_thresholds = {
            RiskLevel.CRITICAL: 80.0,
            RiskLevel.HIGH: 60.0,
            RiskLevel.MEDIUM: 40.0,
            RiskLevel.LOW: 20.0,
            RiskLevel.MINIMAL: 0.0
        }
        
        self.tier_risk_weights = {
            'E': 100.0,   # Essential - maximum risk if issues
            'EC': 75.0,   # Semi-Essential - high risk
            'C': 50.0,    # Contextual - medium risk
            'CN': 25.0,   # Semi-Contextual - low risk
            'N': 10.0     # Enrichment - minimal risk
        }
    
    def assess(self, descriptors: List[Any]) -> RiskAssessment:
        """
        Assess overall risk based on semantic descriptors
        
        Args:
            descriptors: List of SemanticDescriptor objects
            
        Returns:
            RiskAssessment object
        """
        
        factors = []
        recommendations = []
        affected = []
        risk_scores = []
        
        # Assess each descriptor
        for desc in descriptors:
            tier = desc.tier.value
            score = desc.score
            name = desc.attribute_name
            
            tier_weight = self.tier_risk_weights.get(tier, 50.0)
            
            # Calculate risk (inverse of quality score, weighted by tier)
            quality_deficit = 100.0 - score
            attribute_risk = (quality_deficit / 100.0) * tier_weight
            risk_scores.append(attribute_risk)
            
            # Check for critical issues
            if tier == 'E' and score < 90:
                factors.append(f"E-tier '{name}' below critical threshold (score: {score:.1f})")
                recommendations.append(f"Immediately address '{name}' - essential for operations")
                affected.append(name)
            
            elif tier == 'EC' and score < 70:
                factors.append(f"EC-tier '{name}' below acceptable level (score: {score:.1f})")
                recommendations.append(f"Prioritize improvement of '{name}'")
                affected.append(name)
            
            elif tier in ('C', 'CN') and score < 50:
                factors.append(f"{tier}-tier '{name}' has quality concerns (score: {score:.1f})")
                affected.append(name)
        
        # Calculate overall risk score
        if risk_scores:
            # Weighted average, but emphasize maximum risk
            avg_risk = sum(risk_scores) / len(risk_scores)
            max_risk = max(risk_scores)
            overall_risk = (avg_risk * 0.6) + (max_risk * 0.4)  # Blend average and max
        else:
            overall_risk = 0.0
        
        # Determine risk level
        level = self._determine_level(overall_risk)
        
        # Add general recommendations if no specific ones
        if not recommendations:
            if level == RiskLevel.CRITICAL:
                recommendations.append("URGENT: Critical data quality issues detected")
                recommendations.append("Review all E-tier and EC-tier attributes immediately")
            elif level == RiskLevel.HIGH:
                recommendations.append("High-priority: Address data quality gaps")
                recommendations.append("Focus on essential and semi-essential attributes")
            elif level == RiskLevel.MEDIUM:
                recommendations.append("Monitor: Some data quality concerns present")
                recommendations.append("Plan improvements for affected attributes")
            elif level == RiskLevel.LOW:
                recommendations.append("Routine: Maintain current data quality levels")
            else:
                recommendations.append("No immediate concerns - data quality is good")
        
        # Add summary factor if none exist
        if not factors:
            factors.append(f"Overall data quality assessment: {100-overall_risk:.1f}%")
        
        return RiskAssessment(
            level=level,
            score=overall_risk,
            factors=factors,
            recommendations=recommendations,
            affected_attributes=affected
        )
    
    def _determine_level(self, risk_score: float) -> RiskLevel:
        """Determine risk level from score"""
        
        if risk_score >= self.risk_thresholds[RiskLevel.CRITICAL]:
            return RiskLevel.CRITICAL
        elif risk_score >= self.risk_thresholds[RiskLevel.HIGH]:
            return RiskLevel.HIGH
        elif risk_score >= self.risk_thresholds[RiskLevel.MEDIUM]:
            return RiskLevel.MEDIUM
        elif risk_score >= self.risk_thresholds[RiskLevel.LOW]:
            return RiskLevel.LOW
        else:
            return RiskLevel.MINIMAL
    
    def set_threshold(self, level: RiskLevel, threshold: float):
        """Set custom threshold for risk level"""
        self.risk_thresholds[level] = threshold
    
    def set_tier_weight(self, tier: str, weight: float):
        """Set custom risk weight for tier"""
        self.tier_risk_weights[tier] = weight


def assess_risk(descriptors: List[Any]) -> RiskAssessment:
    """
    Convenience function to assess risk
    
    Args:
        descriptors: List of SemanticDescriptor objects
        
    Returns:
        RiskAssessment object
    """
    
    controller = RiskController()
    return controller.assess(descriptors)


def generate_risk_report(risk: RiskAssessment) -> str:
    """
    Generate a formatted risk report
    
    Args:
        risk: RiskAssessment object
        
    Returns:
        Formatted report string
    """
    
    report = []
    report.append("=" * 60)
    report.append("DAIS-10 RISK ASSESSMENT REPORT")
    report.append("=" * 60)
    report.append("")
    
    # Risk level with visual indicator
    level_icons = {
        RiskLevel.CRITICAL: "🔴 CRITICAL",
        RiskLevel.HIGH: "🟠 HIGH",
        RiskLevel.MEDIUM: "🟡 MEDIUM",
        RiskLevel.LOW: "🟢 LOW",
        RiskLevel.MINIMAL: "⚪ MINIMAL"
    }
    
    report.append(f"Risk Level: {level_icons.get(risk.level, risk.level.value.upper())}")
    report.append(f"Risk Score: {risk.score:.1f}/100")
    report.append("")
    
    # Factors
    if risk.factors:
        report.append("Risk Factors:")
        for factor in risk.factors:
            report.append(f"  • {factor}")
        report.append("")
    
    # Affected attributes
    if risk.affected_attributes:
        report.append(f"Affected Attributes ({len(risk.affected_attributes)}):")
        for attr in risk.affected_attributes:
            report.append(f"  • {attr}")
        report.append("")
    
    # Recommendations
    if risk.recommendations:
        report.append("Recommendations:")
        for i, rec in enumerate(risk.recommendations, 1):
            report.append(f"  {i}. {rec}")
        report.append("")
    
    report.append("=" * 60)
    
    return "\n".join(report)
