"""
DAIS-10 Validation Framework
Data quality + governance signal validation

Author: Dr. Usman Zafar
Version: 1.1.0
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


# ============================================================
# Validation Status
# ============================================================

class ValidationStatus(Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


# ============================================================
# Validation Result Container
# ============================================================

@dataclass
class ValidationResult:
    status: ValidationStatus
    message: str
    attribute: Optional[str] = None
    expected: Optional[Any] = None
    actual: Optional[Any] = None
    severity: str = "medium"

    def is_pass(self):
        return self.status == ValidationStatus.PASS

    def is_fail(self):
        return self.status == ValidationStatus.FAIL

    def __str__(self):
        icon_map = {
            ValidationStatus.PASS: "✓",
            ValidationStatus.WARN: "⚠",
            ValidationStatus.FAIL: "✗"
        }

        icon = icon_map.get(self.status, "?")

        if self.attribute:
            return f"{icon} {self.attribute}: {self.message}"

        return f"{icon} {self.message}"


# ============================================================
# Core Validator Engine
# ============================================================

class DataValidator:
    """
    DAIS-10 Governance Validator

    Provides:
    - Structural integrity checking
    - Schema compliance enforcement
    - Quality signal scoring
    - Semantic governance thresholding
    """

    def __init__(self):
        self.results: List[ValidationResult] = []

    # --------------------------------------------------------
    # Public API
    # --------------------------------------------------------

    def validate_data(self, rows: List[Dict], schema: Optional[Dict] = None):
        self.results = []

        if not rows:
            self.results.append(
                ValidationResult(
                    status=ValidationStatus.FAIL,
                    message="No data rows provided",
                    severity="critical"
                )
            )
            return self.results

        self._validate_structure(rows)

        if schema:
            self._validate_schema_compliance(rows, schema)

        self._validate_data_quality(rows)

        return self.results

    # --------------------------------------------------------
    # Structure Validation
    # --------------------------------------------------------

    def _validate_structure(self, rows: List[Dict]):

        if not rows:
            return

        base_columns = set(rows[0].keys())

        for index, row in enumerate(rows[1:], start=1):

            row_columns = set(row.keys())

            if row_columns != base_columns:

                missing = base_columns - row_columns
                extra = row_columns - base_columns

                if missing:
                    self.results.append(
                        ValidationResult(
                            status=ValidationStatus.WARN,
                            message=f"Row {index} missing columns: {missing}",
                            severity="medium"
                        )
                    )

                if extra:
                    self.results.append(
                        ValidationResult(
                            status=ValidationStatus.WARN,
                            message=f"Row {index} has extra columns: {extra}",
                            severity="low"
                        )
                    )

    # --------------------------------------------------------
    # Schema Governance Compliance
    # --------------------------------------------------------

    def _validate_schema_compliance(self, rows: List[Dict], schema: Dict):

        schema_cols = set(schema.get("columns", {}).keys())
        data_cols = set(rows[0].keys())

        # Essential Tier Enforcement (E-tier = critical existence)
        e_tier_cols = {
            col for col, meta in schema.get("columns", {}).items()
            if meta.get("tier") == "E"
        }

        missing_essential = e_tier_cols - data_cols

        for col in missing_essential:
            self.results.append(
                ValidationResult(
                    status=ValidationStatus.FAIL,
                    message="Essential governance attribute missing",
                    attribute=col,
                    severity="critical"
                )
            )

        # -------------------------------
        # Safe Coverage Mathematics
        # -------------------------------

        schema_count = len(schema_cols)

        if schema_count > 0:

            matched_count = len(schema_cols.intersection(data_cols))
            coverage = (matched_count / schema_count) * 100

        else:
            coverage = 0.0

        # Governance Signal Decision
        if coverage < 100:

            self.results.append(
                ValidationResult(
                    status=ValidationStatus.WARN,
                    message=f"Schema coverage: {coverage:.1f}% "
                            f"({len(schema_cols & data_cols)}/{len(schema_cols)})",
                    severity="medium"
                )
            )
        else:
            self.results.append(
                ValidationResult(
                    status=ValidationStatus.PASS,
                    message="100% schema governance coverage"
                )
            )

    # --------------------------------------------------------
    # Data Quality Signal Layer
    # --------------------------------------------------------

    def _validate_data_quality(self, rows: List[Dict]):

        if not rows:
            return

        columns = list(rows[0].keys())
        total_rows = len(rows)

        for col in columns:

            missing_count = sum(
                1 for row in rows
                if not row.get(col) or str(row.get(col)).strip() == ""
            )

            missing_pct = (missing_count / total_rows) * 100

            if missing_pct > 50:
                self.results.append(
                    ValidationResult(
                        status=ValidationStatus.WARN,
                        message=f"High missing rate: {missing_pct:.1f}%",
                        attribute=col,
                        severity="medium"
                    )
                )

            elif missing_pct > 10:
                self.results.append(
                    ValidationResult(
                        status=ValidationStatus.WARN,
                        message=f"Missing values: {missing_pct:.1f}%",
                        attribute=col,
                        severity="low"
                    )
                )

    # --------------------------------------------------------
    # Result Queries
    # --------------------------------------------------------

    def has_failures(self):
        return any(r.is_fail() for r in self.results)

    def has_warnings(self):
        return any(r.status == ValidationStatus.WARN for r in self.results)

    def summary(self):

        passes = sum(1 for r in self.results if r.is_pass())
        warns = sum(1 for r in self.results if r.status == ValidationStatus.WARN)
        fails = sum(1 for r in self.results if r.is_fail())

        return f"Validation → PASS={passes}, WARN={warns}, FAIL={fails}"


# ============================================================
# Functional Wrapper
# ============================================================

def validate_data(rows: List[Dict], schema: Optional[Dict] = None):
    engine = DataValidator()
    return engine.validate_data(rows, schema)