def main():
    print("DAIS-10 CLI active")
setup(
    name="dais10",
    version="1.1.1",  # Bump version
    # ... existing fields ...
    
    entry_points={
        'console_scripts': [
            'dais10=dais10.cli:main',
        ],
    },
)