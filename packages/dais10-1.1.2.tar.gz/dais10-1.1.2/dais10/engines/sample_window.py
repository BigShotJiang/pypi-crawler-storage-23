"""
DAIS-10 v1.1 - Feature 3: Deterministic 20-Row Sample Window

NEW: Every analysis must output best 10 + worst 10 rows

Author: Dr. Usman Zafar
Version: 1.1.0
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class RowStatus(Enum):
    """Status classification for rows"""
    PRIME = "PRIME"        # Score ≥ 90
    STRONG = "STRONG"      # Score 70-89
    WEAK = "WEAK"          # Score 30-69
    FAILURE = "FAILURE"    # Score < 30


@dataclass
class RowSample:
    """Single row in sample window"""
    row_id: Any
    score: float
    governance: str
    status: RowStatus
    top_contributors: List[Dict[str, Any]]
    row_data: Optional[Dict[str, Any]] = None  # Optional: full row data


@dataclass
class SummaryStatistics:
    """Summary statistics for entire dataset"""
    total_rows: int
    average_score: float
    median_score: float
    min_score: float
    max_score: float
    
    # Score distribution
    rows_above_90: int
    rows_70_to_90: int
    rows_50_to_70: int
    rows_30_to_50: int
    rows_below_30: int
    
    # Governance distribution
    fail_count: int
    warn_count: int
    info_count: int


@dataclass
class SampleWindow:
    """
    Deterministic 20-row sample window
    
    NEW in v1.1: MANDATORY for every analysis
    
    Contains:
    - Best 10 rows (highest scores)
    - Worst 10 rows (lowest scores)
    - Summary statistics
    
    Indestructible principle:
    > Scoring level ≠ Observability level
    > Full dataset scored, deterministic sample shown
    """
    summary: SummaryStatistics
    best_10: List[RowSample]
    worst_10: List[RowSample]
    
    # Metadata
    analysis_timestamp: str
    dais_version: str = "1.1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON output"""
        return {
            'metadata': {
                'dais_version': self.dais_version,
                'analysis_timestamp': self.analysis_timestamp
            },
            'summary': {
                'total_rows': self.summary.total_rows,
                'average_score': round(self.summary.average_score, 2),
                'median_score': round(self.summary.median_score, 2),
                'min_score': round(self.summary.min_score, 2),
                'max_score': round(self.summary.max_score, 2),
                'score_distribution': {
                    'prime_90_plus': self.summary.rows_above_90,
                    'strong_70_to_90': self.summary.rows_70_to_90,
                    'moderate_50_to_70': self.summary.rows_50_to_70,
                    'weak_30_to_50': self.summary.rows_30_to_50,
                    'failure_below_30': self.summary.rows_below_30
                },
                'governance_distribution': {
                    'FAIL': self.summary.fail_count,
                    'WARN': self.summary.warn_count,
                    'INFO': self.summary.info_count
                }
            },
            'sample_window': {
                'best_10': [
                    {
                        'row_id': sample.row_id,
                        'score': round(sample.score, 2),
                        'status': sample.status.value,
                        'governance': sample.governance,
                        'top_contributors': sample.top_contributors
                    }
                    for sample in self.best_10
                ],
                'worst_10': [
                    {
                        'row_id': sample.row_id,
                        'score': round(sample.score, 2),
                        'status': sample.status.value,
                        'governance': sample.governance,
                        'top_contributors': sample.top_contributors
                    }
                    for sample in self.worst_10
                ]
            }
        }


class SampleWindowGenerator:
    """
    NEW in v1.1: Generates deterministic sample window
    
    Mandatory for every DAIS-10 analysis
    """
    
    def generate(
        self,
        results: List[Dict[str, Any]],
        n: int = 10,
        analysis_timestamp: Optional[str] = None
    ) -> SampleWindow:
        """
        Generate deterministic 20-row sample
        
        Args:
            results: List of all row scoring results
            n: Number of best/worst to include (default: 10)
            analysis_timestamp: ISO timestamp of analysis
            
        Returns:
            SampleWindow with best n, worst n, and summary
            
        Example:
            >>> generator = SampleWindowGenerator()
            >>> results = [
            ...     {
            ...         'row_id': 1,
            ...         'row_score': 98.5,
            ...         'governance': 'INFO',
            ...         'top_contributors': [...]
            ...     },
            ...     # ... more results
            ... ]
            >>> window = generator.generate(results)
            >>> print(len(window.best_10))  # 10
            >>> print(len(window.worst_10))  # 10
        """
        if not results:
            raise ValueError("Cannot generate sample window from empty results")
        
        if analysis_timestamp is None:
            from datetime import datetime
            analysis_timestamp = datetime.now().isoformat()
        
        # Sort by score (descending)
        sorted_results = sorted(results, key=lambda x: x['row_score'], reverse=True)
        
        # Extract best and worst
        best_n = sorted_results[:n]
        worst_n = sorted_results[-n:]
        
        # Create row samples
        best_samples = [
            self._create_row_sample(r)
            for r in best_n
        ]
        
        worst_samples = [
            self._create_row_sample(r)
            for r in worst_n
        ]
        
        # Calculate summary statistics
        summary = self._calculate_summary(results)
        
        return SampleWindow(
            summary=summary,
            best_10=best_samples,
            worst_10=worst_samples,
            analysis_timestamp=analysis_timestamp
        )
    
    def _create_row_sample(self, result: Dict[str, Any]) -> RowSample:
        """Create RowSample from result"""
        score = result['row_score']
        
        # Classify status
        if score >= 90:
            status = RowStatus.PRIME
        elif score >= 70:
            status = RowStatus.STRONG
        elif score >= 30:
            status = RowStatus.WEAK
        else:
            status = RowStatus.FAILURE
        
        return RowSample(
            row_id=result.get('row_id', result.get('index', 'unknown')),
            score=score,
            governance=result['governance'],
            status=status,
            top_contributors=result.get('top_contributors', []),
            row_data=result.get('row_data')  # Optional full data
        )
    
    def _calculate_summary(self, results: List[Dict[str, Any]]) -> SummaryStatistics:
        """Calculate summary statistics"""
        scores = [r['row_score'] for r in results]
        governances = [r['governance'] for r in results]
        
        # Sort for median
        sorted_scores = sorted(scores)
        median_idx = len(sorted_scores) // 2
        median = sorted_scores[median_idx]
        
        # Score distribution
        rows_above_90 = sum(1 for s in scores if s >= 90)
        rows_70_to_90 = sum(1 for s in scores if 70 <= s < 90)
        rows_50_to_70 = sum(1 for s in scores if 50 <= s < 70)
        rows_30_to_50 = sum(1 for s in scores if 30 <= s < 50)
        rows_below_30 = sum(1 for s in scores if s < 30)
        
        # Governance distribution
        fail_count = governances.count('FAIL')
        warn_count = governances.count('WARN')
        info_count = governances.count('INFO')
        
        return SummaryStatistics(
            total_rows=len(results),
            average_score=sum(scores) / len(scores),
            median_score=median,
            min_score=min(scores),
            max_score=max(scores),
            rows_above_90=rows_above_90,
            rows_70_to_90=rows_70_to_90,
            rows_50_to_70=rows_50_to_70,
            rows_30_to_50=rows_30_to_50,
            rows_below_30=rows_below_30,
            fail_count=fail_count,
            warn_count=warn_count,
            info_count=info_count
        )


# Example usage
if __name__ == "__main__":
    print("DAIS-10 v1.1: Deterministic Sample Window Demo")
    print("=" * 60)
    
    # Generate mock results
    import random
    random.seed(42)
    
    results = []
    for i in range(1000):
        # Simulate different quality levels
        if i < 100:  # 10% excellent
            score = random.uniform(90, 100)
            gov = 'INFO'
        elif i < 300:  # 20% good
            score = random.uniform(70, 90)
            gov = 'INFO'
        elif i < 700:  # 40% moderate
            score = random.uniform(50, 70)
            gov = 'WARN'
        elif i < 950:  # 25% poor
            score = random.uniform(30, 50)
            gov = 'WARN'
        else:  # 5% failure
            score = random.uniform(0, 30)
            gov = 'FAIL'
        
        results.append({
            'row_id': i + 1,
            'row_score': score,
            'governance': gov,
            'top_contributors': [
                {
                    'column': 'example',
                    'impact': 50.0,
                    'reason': 'Example reason'
                }
            ]
        })
    
    # Generate sample window
    generator = SampleWindowGenerator()
    window = generator.generate(results)
    
    print(f"\n📊 Analysis Summary:")
    print(f"   Total Rows: {window.summary.total_rows:,}")
    print(f"   Average Score: {window.summary.average_score:.1f}")
    print(f"   Median Score: {window.summary.median_score:.1f}")
    
    print(f"\n📈 Score Distribution:")
    print(f"   PRIME (≥90): {window.summary.rows_above_90:,} rows")
    print(f"   STRONG (70-89): {window.summary.rows_70_to_90:,} rows")
    print(f"   MODERATE (50-69): {window.summary.rows_50_to_70:,} rows")
    print(f"   WEAK (30-49): {window.summary.rows_30_to_50:,} rows")
    print(f"   FAILURE (<30): {window.summary.rows_below_30:,} rows")
    
    print(f"\n⚖️  Governance Distribution:")
    print(f"   FAIL: {window.summary.fail_count:,}")
    print(f"   WARN: {window.summary.warn_count:,}")
    print(f"   INFO: {window.summary.info_count:,}")
    
    print(f"\n🏆 Best 3 Rows:")
    for i, sample in enumerate(window.best_10[:3], 1):
        print(f"   {i}. Row {sample.row_id}: {sample.score:.1f} ({sample.status.value})")
    
    print(f"\n⚠️  Worst 3 Rows:")
    for i, sample in enumerate(window.worst_10[:3], 1):
        print(f"   {i}. Row {sample.row_id}: {sample.score:.1f} ({sample.status.value})")
    
    print("\n" + "=" * 60)
    print("✅ Sample window generated successfully!")
    print("\nThis deterministic output is MANDATORY for every analysis.")
    print("Perfect for demos, audits, and trust-building.")
