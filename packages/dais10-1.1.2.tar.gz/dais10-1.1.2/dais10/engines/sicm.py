"""
SICM-10: Semantic Intensity Continuum Model

Engine 4 of 8 in DAIS-10 pipeline.
Calculates precise importance scores (0-100) within tier ranges.

Type signature: T × Context → [0,100] (tier + context → score)

This is where tiers become precise numerical values.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from dais10.core.types import Tier, Context
import random


class SICM10:
    """
    SICM-10: Semantic Intensity Continuum Model
    
    Engine 4 of 8 in DAIS-10 pipeline.
    
    Base Scores (center of tier ranges):
    - E (Essential): 90.0 in range [80, 100]
    - EC (Semi-Essential): 77.5 in range [70, 85]
    - C (Contextual): 59.5 in range [40, 79]
    - CN (Semi-Contextual): 40.0 in range [30, 50]
    - N (Enrichment): 19.5 in range [0, 39]
    
    Contextual Adjustment:
    Base score can be adjusted ±10-20 points based on:
    - Regulatory requirements
    - Criticality levels
    - Domain-specific factors
    
    Score must remain within valid tier range.
    
    Complexity: O(1) per attribute
    """
    
    # Base scores (center of each tier range)
    BASE_SCORES = {
        Tier.E: 90.0,
        Tier.EC: 77.5,
        Tier.C: 59.5,
        Tier.CN: 40.0,
        Tier.N: 19.5,
    }
    
    def __init__(self, deterministic: bool = True):
        """
        Initialize SICM-10 engine.
        
        Args:
            deterministic: If True, use base scores without variation.
                          If False, add small random variation for realism.
        """
        self.deterministic = deterministic
    
    def calculate_score(
        self,
        tier: Tier,
        context: Context,
    ) -> float:
        """
        Calculate importance score for an attribute.
        
        Args:
            tier: Tier from TIER-10
            context: Domain context
            
        Returns:
            Importance score (0.0-100.0)
            
        Algorithm:
        1. Start with base score for tier
        2. Apply contextual adjustments
        3. Ensure score stays within tier range
        4. Return final score
        
        Complexity: O(1)
        """
        # Get base score
        base_score = self.BASE_SCORES[tier]
        
        # Apply contextual adjustments
        adjustment = self._calculate_adjustment(tier, context)
        
        # Calculate final score
        score = base_score + adjustment
        
        # Ensure within valid tier range
        min_score, max_score = tier.score_range
        score = max(min_score, min(score, max_score))
        
        # Add small variation if non-deterministic
        if not self.deterministic:
            variation = random.uniform(-2.0, 2.0)
            score = max(min_score, min(score + variation, max_score))
        
        return round(score, 2)
    
    def _calculate_adjustment(
        self,
        tier: Tier,
        context: Context,
    ) -> float:
        """
        Calculate contextual adjustment to base score.
        
        Returns adjustment in range [-20, +20].
        
        Factors:
        - Regulatory requirements: +5 to +15
        - High criticality: +5 to +10
        - Domain-specific: +/-5
        """
        adjustment = 0.0
        
        # Regulatory frameworks increase importance
        if context.regulatory:
            regulatory_boost = {
                'HIPAA': 15.0,  # Healthcare critical
                'SOX': 12.0,    # Financial critical
                'PCI-DSS': 12.0,  # Payment security
                'GDPR': 10.0,   # Privacy
            }.get(context.regulatory, 5.0)
            
            adjustment += regulatory_boost
        
        # Criticality level
        if context.criticality:
            criticality_boost = {
                'high': 10.0,
                'medium': 5.0,
                'low': 0.0,
            }.get(context.criticality, 0.0)
            
            adjustment += criticality_boost
        
        # Domain-specific adjustments
        if context.domain == 'healthcare':
            # Healthcare: bias towards higher importance
            if tier in (Tier.E, Tier.EC):
                adjustment += 5.0
        
        elif context.domain == 'finance':
            # Finance: bias towards higher importance for critical
            if tier == Tier.E:
                adjustment += 5.0
        
        # Cap adjustment at ±20
        adjustment = max(-20.0, min(adjustment, 20.0))
        
        return adjustment
    
    def get_score_interpretation(self, score: float) -> str:
        """
        Get qualitative interpretation of score.
        
        Args:
            score: Importance score
            
        Returns:
            Interpretation string
        """
        if 90 <= score <= 100:
            return "Critical: Required for system operation"
        elif 80 <= score < 90:
            return "Very High: Essential in most contexts"
        elif 70 <= score < 80:
            return "High: Important for clarity"
        elif 60 <= score < 70:
            return "Moderate-High: Recommended"
        elif 50 <= score < 60:
            return "Moderate: Useful for interpretation"
        elif 40 <= score < 50:
            return "Moderate-Low: Optional but helpful"
        elif 30 <= score < 40:
            return "Low: Minimal impact if missing"
        else:
            return "Minimal: Analytical only"
    
    def __repr__(self) -> str:
        mode = "deterministic" if self.deterministic else "stochastic"
        return f"SICM10(Semantic Intensity Continuum Model, {mode})"
