"""
SIS-10: Semantic Interpretation System

The first engine in the DAIS-10 pipeline.
Interprets what a data attribute means by analyzing its name and values.

Type signature: A × V^k → Σ (attribute + values → semantic descriptor)

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from typing import List, Any, Dict, Optional, Pattern
from dataclasses import dataclass
import re
from collections import Counter


@dataclass(frozen=True)
class AttributeMetadata:
    """
    Metadata extracted from attribute name.
    
    Immutable for composition safety.
    """
    name: str
    normalized_name: str  # lowercase, underscores
    tokens: List[str]  # split by underscore/camelCase
    suffix: Optional[str]  # _id, _code, _key, etc.
    prefix: Optional[str]  # created_, updated_, etc.
    contains_date_marker: bool
    contains_id_marker: bool
    contains_metadata_marker: bool
    domain_hints: List[str]  # medical, financial, etc.


@dataclass(frozen=True)
class ValuePatterns:
    """
    Patterns detected in sample values.
    
    Used to infer semantic meaning.
    """
    sample_size: int
    non_null_count: int
    unique_count: int
    cardinality_ratio: float  # unique/total
    
    # Type patterns
    has_numeric: bool
    has_string: bool
    has_date: bool
    has_boolean: bool
    
    # Content patterns
    has_email_pattern: bool
    has_phone_pattern: bool
    has_url_pattern: bool
    has_uuid_pattern: bool
    
    # Statistical properties
    avg_length: float
    max_length: int
    min_length: int
    
    # Domain-specific patterns
    medical_terms: List[str]
    financial_terms: List[str]


class SIS10:
    """
    SIS-10: Semantic Interpretation System
    
    Engine 1 of 8 in DAIS-10 pipeline.
    
    Responsibilities:
    - Parse attribute names for semantic clues
    - Analyze value patterns
    - Extract metadata for downstream engines
    
    Does NOT:
    - Assign semantic roles (that's MCM-10)
    - Assign tiers (that's TIER-10)
    - Calculate scores (that's SICM-10)
    
    Pure interpretation only.
    """
    
    # Regex patterns for semantic detection
    ID_PATTERNS: List[Pattern] = [
        re.compile(r'(_id|_key|_code|_number|_identifier)$', re.I),
        re.compile(r'^(id|key|code)_', re.I),
        re.compile(r'\b(uuid|guid)\b', re.I),
    ]
    
    METADATA_PATTERNS: List[Pattern] = [
        re.compile(r'(created|updated|modified|deleted)_(at|on|date|time|by)', re.I),
        re.compile(r'(inserted|recorded|logged)_(at|on|date|time)', re.I),
        re.compile(r'(_timestamp|_version|_hash)$', re.I),
    ]
    
    DATE_PATTERNS: List[Pattern] = [
        re.compile(r'(date|time|timestamp|datetime|year|month|day)$', re.I),
        re.compile(r'^(dob|birth)', re.I),
    ]
    
    MEDICAL_TERMS: List[str] = [
        'patient', 'allergy', 'allergies', 'diagnosis', 'medication', 'prescription',
        'blood', 'surgery', 'treatment', 'symptom', 'doctor', 'physician',
        'hospital', 'clinic', 'medical', 'health', 'condition',
    ]
    
    FINANCIAL_TERMS: List[str] = [
        'transaction', 'payment', 'account', 'balance', 'amount', 'price',
        'currency', 'card', 'invoice', 'receipt', 'credit', 'debit',
        'merchant', 'customer', 'revenue', 'cost', 'profit',
    ]
    
    EMAIL_PATTERN: Pattern = re.compile(
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    )
    
    PHONE_PATTERN: Pattern = re.compile(
        r'^(\+\d{1,3}[-.]?)?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}$'
    )
    
    URL_PATTERN: Pattern = re.compile(
        r'^https?://[^\s]+$', re.I
    )
    
    UUID_PATTERN: Pattern = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I
    )
    
    def __init__(self):
        """Initialize SIS-10 engine."""
        pass  # Stateless engine
    
    def interpret(
        self,
        attribute_name: str,
        sample_values: List[Any],
    ) -> tuple[AttributeMetadata, ValuePatterns]:
        """
        Full interpretation: metadata + patterns.
        
        Args:
            attribute_name: Name of the attribute
            sample_values: Sample of values (recommend 100-1000)
            
        Returns:
            (metadata, patterns) tuple
            
        Example:
            >>> sis = SIS10()
            >>> meta, patterns = sis.interpret('patient_id', ['P001', 'P002', ...])
            >>> meta.contains_id_marker
            True
        """
        metadata = self.extract_metadata(attribute_name)
        patterns = self.analyze_patterns(sample_values)
        
        return metadata, patterns
    
    def extract_metadata(self, attribute_name: str) -> AttributeMetadata:
        """
        Extract semantic metadata from attribute name.
        
        Args:
            attribute_name: Attribute name to analyze
            
        Returns:
            AttributeMetadata with all detected patterns
            
        Algorithm:
        1. Normalize name (lowercase, underscores)
        2. Tokenize (split by underscore/camelCase)
        3. Detect suffixes/prefixes
        4. Match against known patterns
        5. Extract domain hints
        
        Complexity: O(n) where n = length of attribute name
        """
        # Normalize
        normalized = attribute_name.lower().strip()
        
        # Convert camelCase to snake_case
        normalized = re.sub(r'([a-z])([A-Z])', r'\1_\2', normalized)
        normalized = normalized.lower()
        
        # Tokenize
        tokens = [t for t in normalized.split('_') if t]
        
        # Extract suffix (last token if it matches patterns)
        suffix = None
        if tokens:
            last_token = tokens[-1]
            if last_token in ('id', 'key', 'code', 'number', 'date', 'time', 'at', 'by'):
                suffix = last_token
        
        # Extract prefix (first token if it matches patterns)
        prefix = None
        if tokens:
            first_token = tokens[0]
            if first_token in ('created', 'updated', 'modified', 'deleted', 'is', 'has'):
                prefix = first_token
        
        # Detect patterns
        contains_id = any(pattern.search(normalized) for pattern in self.ID_PATTERNS)
        contains_metadata = any(pattern.search(normalized) for pattern in self.METADATA_PATTERNS)
        contains_date = any(pattern.search(normalized) for pattern in self.DATE_PATTERNS)
        
        # Detect domain hints
        domain_hints = []
        
        for term in self.MEDICAL_TERMS:
            if term in normalized:
                if 'medical' not in domain_hints:
                    domain_hints.append('medical')
                break
        
        for term in self.FINANCIAL_TERMS:
            if term in normalized:
                if 'financial' not in domain_hints:
                    domain_hints.append('financial')
                break
        
        return AttributeMetadata(
            name=attribute_name,
            normalized_name=normalized,
            tokens=tokens,
            suffix=suffix,
            prefix=prefix,
            contains_date_marker=contains_date,
            contains_id_marker=contains_id,
            contains_metadata_marker=contains_metadata,
            domain_hints=domain_hints,
        )
    
    def analyze_patterns(self, sample_values: List[Any]) -> ValuePatterns:
        """
        Analyze value patterns in sample data.
        
        Args:
            sample_values: Sample of values to analyze
            
        Returns:
            ValuePatterns with detected patterns
            
        Algorithm:
        1. Filter non-null values
        2. Compute statistics (cardinality, uniqueness)
        3. Detect data types
        4. Match content patterns (email, phone, etc.)
        5. Extract domain-specific terms
        
        Complexity: O(n) where n = len(sample_values)
        """
        # Handle empty samples
        if not sample_values:
            return ValuePatterns(
                sample_size=0,
                non_null_count=0,
                unique_count=0,
                cardinality_ratio=0.0,
                has_numeric=False,
                has_string=False,
                has_date=False,
                has_boolean=False,
                has_email_pattern=False,
                has_phone_pattern=False,
                has_url_pattern=False,
                has_uuid_pattern=False,
                avg_length=0.0,
                max_length=0,
                min_length=0,
                medical_terms=[],
                financial_terms=[],
            )
        
        # Filter non-null
        non_null = [v for v in sample_values if v is not None and str(v).strip()]
        non_null_count = len(non_null)
        
        if non_null_count == 0:
            # All null
            return ValuePatterns(
                sample_size=len(sample_values),
                non_null_count=0,
                unique_count=0,
                cardinality_ratio=0.0,
                has_numeric=False,
                has_string=False,
                has_date=False,
                has_boolean=False,
                has_email_pattern=False,
                has_phone_pattern=False,
                has_url_pattern=False,
                has_uuid_pattern=False,
                avg_length=0.0,
                max_length=0,
                min_length=0,
                medical_terms=[],
                financial_terms=[],
            )
        
        # Compute uniqueness
        unique_count = len(set(str(v) for v in non_null))
        cardinality_ratio = unique_count / non_null_count
        
        # Type detection
        has_numeric = any(isinstance(v, (int, float)) for v in non_null)
        has_string = any(isinstance(v, str) for v in non_null)
        has_boolean = any(isinstance(v, bool) for v in non_null)
        has_date = any(self._looks_like_date(v) for v in non_null)
        
        # Content patterns (for string values only)
        string_values = [str(v) for v in non_null if isinstance(v, str)]
        
        has_email = any(self.EMAIL_PATTERN.match(v) for v in string_values[:100])
        has_phone = any(self.PHONE_PATTERN.match(v) for v in string_values[:100])
        has_url = any(self.URL_PATTERN.match(v) for v in string_values[:100])
        has_uuid = any(self.UUID_PATTERN.match(v) for v in string_values[:100])
        
        # Length statistics
        lengths = [len(str(v)) for v in non_null]
        avg_length = sum(lengths) / len(lengths) if lengths else 0.0
        max_length = max(lengths) if lengths else 0
        min_length = min(lengths) if lengths else 0
        
        # Domain-specific term detection
        all_text = ' '.join(str(v).lower() for v in non_null[:100])
        
        medical_found = [term for term in self.MEDICAL_TERMS if term in all_text]
        financial_found = [term for term in self.FINANCIAL_TERMS if term in all_text]
        
        return ValuePatterns(
            sample_size=len(sample_values),
            non_null_count=non_null_count,
            unique_count=unique_count,
            cardinality_ratio=cardinality_ratio,
            has_numeric=has_numeric,
            has_string=has_string,
            has_date=has_date,
            has_boolean=has_boolean,
            has_email_pattern=has_email,
            has_phone_pattern=has_phone,
            has_url_pattern=has_url,
            has_uuid_pattern=has_uuid,
            avg_length=avg_length,
            max_length=max_length,
            min_length=min_length,
            medical_terms=medical_found[:5],  # Top 5
            financial_terms=financial_found[:5],
        )
    
    def _looks_like_date(self, value: Any) -> bool:
        """Check if value looks like a date/datetime."""
        from datetime import datetime, date
        
        # Already a date/datetime object
        if isinstance(value, (datetime, date)):
            return True
        
        # Try parsing common date formats
        if isinstance(value, str):
            date_patterns = [
                r'^\d{4}-\d{2}-\d{2}',  # YYYY-MM-DD
                r'^\d{2}/\d{2}/\d{4}',  # MM/DD/YYYY
                r'^\d{4}/\d{2}/\d{2}',  # YYYY/MM/DD
            ]
            return any(re.match(p, value) for p in date_patterns)
        
        return False
    
    def __repr__(self) -> str:
        return "SIS10(Semantic Interpretation System)"
