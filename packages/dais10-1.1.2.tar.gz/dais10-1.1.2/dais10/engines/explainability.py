"""
DAIS-10 v1.1 - Feature 2: Explainability Vector

NEW: Every score includes top-k contributors with impact calculation

Author: Dr. Usman Zafar
Version: 1.1.0
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class ContributionReason(Enum):
    """Reasons for contribution to row score"""
    MISSING_CRITICAL = "Missing critical field (E-tier)"
    MISSING_OPTIONAL = "Missing optional field"
    INVALID_FORMAT = "Invalid format"
    DECAYED = "Decayed (old data)"
    VALID_RECENT = "Valid and recent"
    VALID_AGED = "Valid but aged"
    PLACEHOLDER = "Placeholder value"


@dataclass
class CellContribution:
    """
    Contribution of a single cell to row score
    
    NEW in v1.1: Mandatory for every cell
    """
    column: str
    cell_score: float  # 0-100
    importance: float  # 0-100 (from schema)
    impact: float  # Percentage contribution to row score
    reason: str  # Human-readable explanation
    reason_code: ContributionReason
    
    # Optional details
    days_old: Optional[int] = None
    validity_score: Optional[float] = None
    freshness_score: Optional[float] = None
    cap_applied: bool = False
    cap_reason: Optional[str] = None


@dataclass
class ExplainabilityVector:
    """
    Complete explanation of row score
    
    NEW in v1.1: Mandatory output for every row
    """
    row_score: float
    governance_action: str  # FAIL/WARN/INFO
    
    # Top-k contributors (sorted by impact)
    top_contributors: List[CellContribution]
    
    # All cell contributions (optional, for detailed view)
    all_contributions: Optional[List[CellContribution]] = None
    
    # Summary stats
    total_weighted_score: float = 0.0
    total_importance: float = 0.0
    
    def get_top_k(self, k: int = 3) -> List[CellContribution]:
        """Get top-k contributors"""
        return self.top_contributors[:k]
    
    def get_failing_columns(self) -> List[CellContribution]:
        """Get all columns that caused governance failure"""
        if not self.all_contributions:
            return []
        
        return [
            c for c in self.all_contributions
            if c.reason_code == ContributionReason.MISSING_CRITICAL
        ]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON output"""
        return {
            'row_score': self.row_score,
            'governance_action': self.governance_action,
            'top_contributors': [
                {
                    'column': c.column,
                    'impact': round(c.impact, 2),
                    'reason': c.reason,
                    'cell_score': round(c.cell_score, 2),
                    'importance': c.importance,
                    'days_old': c.days_old,
                    'cap_applied': c.cap_applied,
                    'cap_reason': c.cap_reason
                }
                for c in self.top_contributors
            ]
        }


class ExplainabilityEngine:
    """
    NEW in v1.1: Calculates impact and generates explanations
    
    Mandatory for every row score calculation
    """
    
    def calculate_impact(
        self,
        cell_results: List[Dict[str, Any]]
    ) -> List[CellContribution]:
        """
        Calculate impact (percentage contribution) for each cell
        
        Impact Formula:
            impact_i = (cell_score_i × importance_i) / Σ(cell_score_j × importance_j) × 100
        
        Args:
            cell_results: List of cell scoring results
            
        Returns:
            List of CellContribution with impact calculated
            
        Example:
            >>> engine = ExplainabilityEngine()
            >>> cells = [
            ...     {
            ...         'column': 'patient_id',
            ...         'score': 100,
            ...         'importance': 100,
            ...         'reason': 'Valid and recent',
            ...         'days_old': 3
            ...     },
            ...     {
            ...         'column': 'allergies',
            ...         'score': 0,
            ...         'importance': 95,
            ...         'reason': 'Missing E-tier field',
            ...         'cap_applied': True
            ...     }
            ... ]
            >>> contributions = engine.calculate_impact(cells)
            >>> print(contributions[0].impact)  # ~51.3%
        """
        # Calculate total weighted score
        total_weighted = sum(
            c['score'] * c['importance']
            for c in cell_results
        )
        
        if total_weighted == 0:
            # All cells failed - equal impact
            impact_per_cell = 100.0 / len(cell_results)
            
            return [
                self._create_contribution(c, impact_per_cell)
                for c in cell_results
            ]
        
        # Calculate impact for each cell
        contributions = []
        for cell in cell_results:
            contribution = cell['score'] * cell['importance']
            impact = (contribution / total_weighted) * 100
            
            contributions.append(
                self._create_contribution(cell, impact)
            )
        
        # Sort by impact (highest first)
        contributions.sort(key=lambda x: x.impact, reverse=True)
        
        return contributions
    
    def _create_contribution(
        self,
        cell_result: Dict[str, Any],
        impact: float
    ) -> CellContribution:
        """Create CellContribution from cell result"""
        
        # Determine reason code
        reason_code = self._classify_reason(cell_result['reason'])
        
        return CellContribution(
            column=cell_result['column'],
            cell_score=cell_result['score'],
            importance=cell_result['importance'],
            impact=impact,
            reason=cell_result['reason'],
            reason_code=reason_code,
            days_old=cell_result.get('days_old'),
            validity_score=cell_result.get('validity_score'),
            freshness_score=cell_result.get('freshness_score'),
            cap_applied=cell_result.get('cap_applied', False),
            cap_reason=cell_result.get('cap_reason')
        )
    
    def _classify_reason(self, reason_text: str) -> ContributionReason:
        """Classify reason into enum"""
        reason_lower = reason_text.lower()
        
        if 'missing' in reason_lower and 'e-tier' in reason_lower:
            return ContributionReason.MISSING_CRITICAL
        elif 'missing' in reason_lower:
            return ContributionReason.MISSING_OPTIONAL
        elif 'invalid' in reason_lower:
            return ContributionReason.INVALID_FORMAT
        elif 'decayed' in reason_lower:
            return ContributionReason.DECAYED
        elif 'placeholder' in reason_lower:
            return ContributionReason.PLACEHOLDER
        elif 'aged' in reason_lower:
            return ContributionReason.VALID_AGED
        else:
            return ContributionReason.VALID_RECENT
    
    def create_explainability_vector(
        self,
        row_score: float,
        governance_action: str,
        cell_results: List[Dict[str, Any]],
        top_k: int = 3
    ) -> ExplainabilityVector:
        """
        Create complete explainability vector
        
        NEW in v1.1: Mandatory for every row
        
        Args:
            row_score: Final row score
            governance_action: FAIL/WARN/INFO
            cell_results: All cell scoring results
            top_k: Number of top contributors to include
            
        Returns:
            ExplainabilityVector with top-k and full details
        """
        # Calculate impact for all cells
        all_contributions = self.calculate_impact(cell_results)
        
        # Get top-k
        top_contributors = all_contributions[:top_k]
        
        # Calculate summary stats
        total_weighted = sum(
            c.cell_score * c.importance
            for c in all_contributions
        )
        total_importance = sum(c.importance for c in all_contributions)
        
        return ExplainabilityVector(
            row_score=row_score,
            governance_action=governance_action,
            top_contributors=top_contributors,
            all_contributions=all_contributions,
            total_weighted_score=total_weighted,
            total_importance=total_importance
        )


# Example usage
if __name__ == "__main__":
    print("DAIS-10 v1.1: Explainability Vector Demo")
    print("=" * 60)
    
    engine = ExplainabilityEngine()
    
    # Sample cell results
    cells = [
        {
            'column': 'patient_id',
            'score': 100,
            'importance': 100,
            'reason': 'Valid and recent (3 days old)',
            'days_old': 3,
            'validity_score': 1.0,
            'freshness_score': 0.997
        },
        {
            'column': 'allergies',
            'score': 0,
            'importance': 95,
            'reason': 'Missing E-tier field (required)',
            'cap_applied': True,
            'cap_reason': 'HIPAA_REQUIRED_FIELD_MISSING'
        },
        {
            'column': 'email',
            'score': 45,
            'importance': 60,
            'reason': 'Decayed (730 days old)',
            'days_old': 730,
            'validity_score': 1.0,
            'freshness_score': 0.45
        },
        {
            'column': 'marketing_consent',
            'score': 8,
            'importance': 10,
            'reason': 'Valid but aged (180 days old)',
            'days_old': 180
        }
    ]
    
    # Create explainability vector
    vector = engine.create_explainability_vector(
        row_score=45.3,
        governance_action='FAIL',
        cell_results=cells,
        top_k=3
    )
    
    print(f"\nRow Score: {vector.row_score:.1f}")
    print(f"Governance: {vector.governance_action}")
    print(f"\nTop 3 Contributors:")
    
    for i, contrib in enumerate(vector.top_contributors, 1):
        print(f"\n{i}. {contrib.column}")
        print(f"   Impact: {contrib.impact:.1f}%")
        print(f"   Reason: {contrib.reason}")
        print(f"   Score: {contrib.cell_score:.1f} (importance: {contrib.importance})")
        if contrib.cap_applied:
            print(f"   ⚠️  Cap Applied: {contrib.cap_reason}")
    
    print("\n" + "=" * 60)
    print("✅ Explainability vector generated successfully!")
    print("\nJSON Output:")
    import json
    print(json.dumps(vector.to_dict(), indent=2))
