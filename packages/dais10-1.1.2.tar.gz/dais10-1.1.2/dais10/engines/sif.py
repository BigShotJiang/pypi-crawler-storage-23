"""
SIF-10: Semantic Influence Framework

Engine 6 of 8 in DAIS-10 pipeline.
Computes normalized influence weights for tier-weighted completeness.

Type signature: Σⁿ → [0,1]ⁿ (descriptors → weights) where Σwᵢ = 1

Formula: wᵢ = g(σᵢ) / Σⱼ g(σⱼ)
Where: g(r,t,s) = α(r) · β(t) · h(s)

This is where attributes get their relative importance.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from typing import List
from dais10.core.types import SemanticDescriptor, SemanticRole, Tier


class SIF10:
    """
    SIF-10: Semantic Influence Framework
    
    Engine 6 of 8 in DAIS-10 pipeline.
    
    Influence Weight Computation:
    
    wᵢ = g(σᵢ) / Σⱼ g(σⱼ)
    
    Where g(role, tier, score) = α(role) · β(tier) · h(score)
    
    Components:
    - α(role): Role weight
      MD: 1.0, ME: 0.7, MX: 0.4, MN: 0.1
    
    - β(tier): Tier weight
      E: 1.00, EC: 0.85, C: 0.60, CN: 0.35, N: 0.10
    
    - h(score): Score transformation
      h(s) = (s/100)²  (quadratic for emphasis)
    
    Properties:
    - Σwᵢ = 1 (probability distribution)
    - wᵢ > 0 for all i (all attributes contribute)
    - Essential attributes dominate (Theorem 1: Tier Dominance)
    
    Complexity: O(n) where n = number of attributes
    """
    
    # Role weights (α mapping)
    ROLE_WEIGHTS = {
        SemanticRole.MD: 1.0,  # Meaning-Defining
        SemanticRole.ME: 0.7,  # Meaning-Enhancing
        SemanticRole.MX: 0.4,  # Meaning-Extending
        SemanticRole.MN: 0.1,  # Meaning-Neutral
    }
    
    # Tier weights (β mapping)
    # Note: Same as tier.weight property, but explicit here
    TIER_WEIGHTS = {
        Tier.E: 1.00,
        Tier.EC: 0.85,
        Tier.C: 0.60,
        Tier.CN: 0.35,
        Tier.N: 0.10,
    }
    
    def __init__(self):
        """Initialize SIF-10 engine."""
        pass  # Stateless
    
    def compute_weights(
        self,
        descriptors: List[SemanticDescriptor],
    ) -> List[float]:
        """
        Compute normalized influence weights.
        
        Args:
            descriptors: List of semantic descriptors
            
        Returns:
            List of normalized weights (sum = 1.0)
            
        Algorithm:
        1. For each descriptor, compute g(σ) = α · β · h(s)
        2. Sum all g values: Z = Σg(σⱼ)
        3. Normalize: wᵢ = g(σᵢ) / Z
        
        Complexity: O(n)
        
        Example:
            >>> from dais10 import SIF10, SemanticDescriptor, Tier, SemanticRole
            >>> sif = SIF10()
            >>> descriptors = [
            ...     SemanticDescriptor('id', SemanticRole.MD, Tier.E, 98),
            ...     SemanticDescriptor('email', SemanticRole.ME, Tier.EC, 78),
            ...     SemanticDescriptor('marketing', SemanticRole.MX, Tier.N, 15),
            ... ]
            >>> weights = sif.compute_weights(descriptors)
            >>> sum(weights)
            1.0
            >>> weights[0] > weights[1] > weights[2]
            True
        """
        if not descriptors:
            return []
        
        # Compute g(σ) for each descriptor
        g_values = [self._compute_g(desc) for desc in descriptors]
        
        # Compute normalization constant
        total = sum(g_values)
        
        if total == 0:
            # Edge case: all zero weights (shouldn't happen)
            # Distribute equally
            return [1.0 / len(descriptors)] * len(descriptors)
        
        # Normalize
        weights = [g / total for g in g_values]
        
        return weights
    
    def _compute_g(self, descriptor: SemanticDescriptor) -> float:
        """
        Compute influence component g(σ).
        
        g(role, tier, score) = α(role) · β(tier) · h(score)
        
        Args:
            descriptor: Semantic descriptor
            
        Returns:
            Influence component (before normalization)
        """
        # Get role weight
        alpha = self.ROLE_WEIGHTS[descriptor.role]
        
        # Get tier weight
        beta = self.TIER_WEIGHTS[descriptor.tier]
        
        # Compute score transformation
        h_score = self._score_transform(descriptor.score)
        
        # Compute product
        g = alpha * beta * h_score
        
        return g
    
    def _score_transform(self, score: float) -> float:
        """
        Transform score for influence calculation.
        
        h(s) = (s/100)²
        
        Quadratic transformation amplifies differences:
        - h(50) = 0.25
        - h(90) = 0.81 (3.24× larger)
        
        Linear would only give 1.8× difference.
        
        Args:
            score: Importance score (0-100)
            
        Returns:
            Transformed score (0-1)
        """
        normalized = score / 100.0
        return normalized ** 2
    
    def compute_completeness(
        self,
        descriptors: List[SemanticDescriptor],
        present_attributes: List[str],
    ) -> float:
        """
        Compute tier-weighted completeness score.
        
        Completeness = Σᵢ [wᵢ · present(aᵢ)]
        
        Where present(a) = 1 if a is present, 0 if missing
        
        Args:
            descriptors: Semantic descriptors
            present_attributes: List of attribute names that are present
            
        Returns:
            Completeness score (0.0-1.0)
            
        Example:
            >>> completeness = sif.compute_completeness(
            ...     descriptors=[desc1, desc2, desc3],
            ...     present_attributes=['id', 'email']  # marketing missing
            ... )
            >>> # completeness ≈ 0.95 (Essential + Semi-Essential present)
        """
        if not descriptors:
            return 0.0
        
        # Compute weights
        weights = self.compute_weights(descriptors)
        
        # Compute weighted completeness
        completeness = 0.0
        
        for desc, weight in zip(descriptors, weights):
            if desc.attribute_name in present_attributes:
                completeness += weight
        
        return round(completeness, 4)
    
    def get_weight_breakdown(
        self,
        descriptor: SemanticDescriptor,
    ) -> dict:
        """
        Get detailed breakdown of weight components.
        
        Args:
            descriptor: Semantic descriptor
            
        Returns:
            Dict with component breakdown
            
        Example:
            >>> breakdown = sif.get_weight_breakdown(descriptor)
            >>> print(breakdown)
            {
                'role': 'MD',
                'role_weight': 1.0,
                'tier': 'E',
                'tier_weight': 1.0,
                'score': 98,
                'score_transform': 0.9604,
                'g_value': 0.9604
            }
        """
        alpha = self.ROLE_WEIGHTS[descriptor.role]
        beta = self.TIER_WEIGHTS[descriptor.tier]
        h_score = self._score_transform(descriptor.score)
        g = self._compute_g(descriptor)
        
        return {
            'role': descriptor.role.value,
            'role_weight': alpha,
            'tier': descriptor.tier.value,
            'tier_weight': beta,
            'score': descriptor.score,
            'score_transform': round(h_score, 4),
            'g_value': round(g, 4),
        }
    
    def verify_tier_dominance(
        self,
        essential_desc: SemanticDescriptor,
        enrichment_desc: SemanticDescriptor,
    ) -> bool:
        """
        Verify Theorem 1 (Tier Dominance).
        
        Essential attributes should dominate Enrichment,
        even with minimum Essential score (80) vs maximum Enrichment (39).
        
        Args:
            essential_desc: Essential-tier descriptor
            enrichment_desc: Enrichment-tier descriptor
            
        Returns:
            True if tier dominance holds
            
        Example:
            >>> e_desc = SemanticDescriptor('id', MD, E, 80)
            >>> n_desc = SemanticDescriptor('marketing', MX, N, 39)
            >>> sif.verify_tier_dominance(e_desc, n_desc)
            True  # Essential always dominates
        """
        g_essential = self._compute_g(essential_desc)
        g_enrichment = self._compute_g(enrichment_desc)
        
        return g_essential > g_enrichment
    
    def __repr__(self) -> str:
        return "SIF10(Semantic Influence Framework)"
