"""
DIFS-10: Drift & Fading Subzones

Engine 5 of 8 in DAIS-10 pipeline.
Models temporal importance decay using exponential functions.

Type signature: Score × Tier × Time → Score' (score + tier + time → faded_score)

Formula: s(t) = s₀ · exp(-λt)

This is where DAIS-10 understands that data ages.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

import math
from dais10.core.types import Tier


class DIFS10:
    """
    DIFS-10: Drift & Fading Subzones
    
    Engine 5 of 8 in DAIS-10 pipeline.
    
    Temporal Decay Model:
    s(t) = s₀ · exp(-λ · t)
    
    Where:
    - s₀: Initial importance score
    - λ: Decay rate (tier-dependent)
    - t: Time elapsed (days)
    - s(t): Faded importance score
    
    Decay Rates by Tier:
    - E (Essential): λ = 0.001 (half-life: 693 days)
    - EC (Semi-Essential): λ = 0.005 (half-life: 139 days)
    - C (Contextual): λ = 0.010 (half-life: 69 days)
    - CN (Semi-Contextual): λ = 0.020 (half-life: 35 days)
    - N (Enrichment): λ = 0.050 (half-life: 14 days)
    
    Rationale:
    - Essential data (IDs, keys) decays slowly
    - Contextual data (contact info) decays medium
    - Enrichment data (analytics) decays quickly
    
    Complexity: O(1) per attribute
    """
    
    # Decay rates (lambda values)
    DECAY_RATES = {
        Tier.E: 0.001,   # Slow decay (identity data)
        Tier.EC: 0.005,  # Medium-slow decay
        Tier.C: 0.010,   # Medium decay
        Tier.CN: 0.020,  # Medium-fast decay
        Tier.N: 0.050,   # Fast decay (analytical)
    }
    
    def __init__(self):
        """Initialize DIFS-10 engine."""
        pass  # Stateless
    
    def apply_decay(
        self,
        initial_score: float,
        tier: Tier,
        days_elapsed: float,
    ) -> float:
        """
        Apply temporal decay to importance score.
        
        Args:
            initial_score: Original importance score
            tier: Attribute tier
            days_elapsed: Days since data creation
            
        Returns:
            Faded importance score
            
        Formula:
            s(t) = s₀ · exp(-λt)
        
        Example:
            >>> difs = DIFS10()
            >>> difs.apply_decay(score=78, tier=Tier.EC, days=730)
            2.03  # 97.4% decayed after 2 years
        
        Complexity: O(1)
        """
        # Get decay rate for tier
        lambda_value = self.DECAY_RATES[tier]
        
        # Apply exponential decay
        faded_score = initial_score * math.exp(-lambda_value * days_elapsed)
        
        return round(faded_score, 2)
    
    def calculate_half_life(self, tier: Tier) -> float:
        """
        Calculate half-life for a tier.
        
        Half-life: Time for importance to decay to 50% of original.
        
        Formula: t_half = ln(2) / λ
        
        Args:
            tier: Tier to calculate for
            
        Returns:
            Half-life in days
            
        Example:
            >>> difs = DIFS10()
            >>> difs.calculate_half_life(Tier.E)
            693.15  # ~2 years
        """
        lambda_value = self.DECAY_RATES[tier]
        half_life = math.log(2) / lambda_value
        return round(half_life, 2)
    
    def calculate_decay_percentage(
        self,
        initial_score: float,
        tier: Tier,
        days_elapsed: float,
    ) -> float:
        """
        Calculate percentage of importance that has decayed.
        
        Args:
            initial_score: Original importance
            tier: Attribute tier
            days_elapsed: Days elapsed
            
        Returns:
            Decay percentage (0-100)
            
        Example:
            >>> difs = DIFS10()
            >>> difs.calculate_decay_percentage(78, Tier.EC, 730)
            97.4  # 97.4% decayed
        """
        faded = self.apply_decay(initial_score, tier, days_elapsed)
        decay_pct = ((initial_score - faded) / initial_score) * 100
        return round(decay_pct, 2)
    
    def get_refresh_recommendation(
        self,
        initial_score: float,
        tier: Tier,
        days_elapsed: float,
        threshold: float = 50.0,
    ) -> tuple[bool, str]:
        """
        Recommend whether data needs refresh.
        
        Args:
            initial_score: Original importance
            tier: Attribute tier
            days_elapsed: Days elapsed
            threshold: Refresh if faded below this score
            
        Returns:
            (needs_refresh, reason)
            
        Example:
            >>> difs = DIFS10()
            >>> difs.get_refresh_recommendation(78, Tier.EC, 730)
            (True, "Score faded to 2.03 (97.4% decay). Refresh recommended.")
        """
        faded = self.apply_decay(initial_score, tier, days_elapsed)
        decay_pct = self.calculate_decay_percentage(initial_score, tier, days_elapsed)
        
        if faded < threshold:
            reason = (
                f"Score faded to {faded:.2f} ({decay_pct:.1f}% decay). "
                f"Refresh recommended."
            )
            return (True, reason)
        else:
            reason = (
                f"Score at {faded:.2f} ({decay_pct:.1f}% decay). "
                f"Still above threshold ({threshold})."
            )
            return (False, reason)
    
    def predict_future_score(
        self,
        current_score: float,
        tier: Tier,
        future_days: float,
    ) -> float:
        """
        Predict score after future time period.
        
        Args:
            current_score: Current importance
            tier: Attribute tier
            future_days: Days in future to predict
            
        Returns:
            Predicted score
            
        Example:
            >>> difs = DIFS10()
            >>> difs.predict_future_score(78, Tier.EC, 365)
            14.89  # After 1 year
        """
        return self.apply_decay(current_score, tier, future_days)
    
    def calculate_time_to_threshold(
        self,
        initial_score: float,
        tier: Tier,
        threshold: float,
    ) -> float:
        """
        Calculate days until score falls below threshold.
        
        Args:
            initial_score: Original importance
            tier: Attribute tier
            threshold: Threshold score
            
        Returns:
            Days until threshold reached
            
        Formula:
            Solve s₀ · exp(-λt) = threshold for t
            t = -ln(threshold/s₀) / λ
        
        Example:
            >>> difs = DIFS10()
            >>> difs.calculate_time_to_threshold(78, Tier.EC, 50)
            91.6  # ~3 months until refresh needed
        """
        if threshold >= initial_score:
            return 0.0  # Already below threshold
        
        lambda_value = self.DECAY_RATES[tier]
        
        # Solve exponential decay equation for t
        days = -math.log(threshold / initial_score) / lambda_value
        
        return round(days, 2)
    
    def get_tier_decay_comparison(self, days: float) -> dict[Tier, float]:
        """
        Compare decay across all tiers for a given time period.
        
        Args:
            days: Time period to compare
            
        Returns:
            Dict of tier -> decay percentage
            
        Example:
            >>> difs = DIFS10()
            >>> difs.get_tier_decay_comparison(365)
            {
                Tier.E: 31.1%,
                Tier.EC: 84.6%,
                Tier.C: 97.0%,
                Tier.CN: 99.8%,
                Tier.N: 100.0%
            }
        """
        # Use score of 100 for comparison
        initial = 100.0
        
        results = {}
        for tier in [Tier.E, Tier.EC, Tier.C, Tier.CN, Tier.N]:
            decay_pct = self.calculate_decay_percentage(initial, tier, days)
            results[tier] = decay_pct
        
        return results
    
    def __repr__(self) -> str:
        return "DIFS10(Drift & Fading Subzones, Temporal Decay Model)"
