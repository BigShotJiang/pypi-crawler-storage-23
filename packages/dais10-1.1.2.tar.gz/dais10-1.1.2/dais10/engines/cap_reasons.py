"""
DAIS-10 v1.1 - Feature 4: E-Tier Cap Reasons

NEW: Every E-tier hard cap must include legal justification

Author: Dr. Usman Zafar
Version: 1.1.0
"""

from typing import Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum


class RegulatoryFramework(Enum):
    """Supported regulatory frameworks"""
    HIPAA = "HIPAA"
    SOX = "SOX"
    PCI_DSS = "PCI-DSS"
    GDPR = "GDPR"
    CCPA = "CCPA"
    CUSTOM = "CUSTOM"


@dataclass
class CapReason:
    """
    Legal justification for E-tier hard cap
    
    NEW in v1.1: MANDATORY for all E-tier failures
    """
    code: str  # Machine-readable code
    message: str  # Human-readable message
    legal_reference: Optional[str] = None  # Legal citation
    regulatory_framework: Optional[RegulatoryFramework] = None
    remediation_action: Optional[str] = None
    severity: str = "CRITICAL"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'cap_applied': True,
            'cap_reason_code': self.code,
            'cap_reason_message': self.message,
            'legal_reference': self.legal_reference,
            'regulatory_framework': self.regulatory_framework.value if self.regulatory_framework else None,
            'remediation_action': self.remediation_action,
            'severity': self.severity
        }


class CapReasonGenerator:
    """
    NEW in v1.1: Generates legal justifications for E-tier caps
    
    Mandatory for audit compliance
    """
    
    # Predefined cap reason templates
    REASON_TEMPLATES = {
        # HIPAA
        'HIPAA_PATIENT_ID_MISSING': CapReason(
            code='HIPAA_PATIENT_ID_MISSING',
            message='Patient identifier is missing (HIPAA required field)',
            legal_reference='45 CFR 164.312(a)(1) - Unique User Identification',
            regulatory_framework=RegulatoryFramework.HIPAA,
            remediation_action='Obtain patient ID from medical records system',
            severity='CRITICAL'
        ),
        'HIPAA_MEDICAL_RECORDS_MISSING': CapReason(
            code='HIPAA_MEDICAL_RECORDS_MISSING',
            message='Critical medical records field is missing',
            legal_reference='45 CFR 164.316(b)(1) - Medical Records Retention',
            regulatory_framework=RegulatoryFramework.HIPAA,
            remediation_action='Complete medical history during patient visit',
            severity='CRITICAL'
        ),
        'HIPAA_PHI_INCOMPLETE': CapReason(
            code='HIPAA_PHI_INCOMPLETE',
            message='Protected Health Information (PHI) is incomplete',
            legal_reference='45 CFR 164.502 - PHI Requirements',
            regulatory_framework=RegulatoryFramework.HIPAA,
            remediation_action='Verify and complete all PHI fields',
            severity='CRITICAL'
        ),
        
        # SOX
        'SOX_TRANSACTION_ID_MISSING': CapReason(
            code='SOX_TRANSACTION_ID_MISSING',
            message='Transaction identifier is missing (SOX audit requirement)',
            legal_reference='SOX Section 404 - Internal Controls',
            regulatory_framework=RegulatoryFramework.SOX,
            remediation_action='Assign unique transaction ID from financial system',
            severity='CRITICAL'
        ),
        'SOX_FINANCIAL_RECORD_INCOMPLETE': CapReason(
            code='SOX_FINANCIAL_RECORD_INCOMPLETE',
            message='Required financial record field is missing',
            legal_reference='SOX Section 802 - Record Retention',
            regulatory_framework=RegulatoryFramework.SOX,
            remediation_action='Complete financial record with all required fields',
            severity='CRITICAL'
        ),
        
        # PCI-DSS
        'PCI_CARDHOLDER_DATA_MISSING': CapReason(
            code='PCI_CARDHOLDER_DATA_MISSING',
            message='Cardholder data field is missing (PCI-DSS requirement)',
            legal_reference='PCI-DSS Requirement 3.1 - Data Retention',
            regulatory_framework=RegulatoryFramework.PCI_DSS,
            remediation_action='Verify cardholder data storage compliance',
            severity='CRITICAL'
        ),
        
        # GDPR
        'GDPR_CONSENT_MISSING': CapReason(
            code='GDPR_CONSENT_MISSING',
            message='Data processing consent is missing (GDPR Article 6)',
            legal_reference='GDPR Article 6 - Lawfulness of Processing',
            regulatory_framework=RegulatoryFramework.GDPR,
            remediation_action='Obtain explicit consent for data processing',
            severity='CRITICAL'
        ),
        
        # Generic
        'REQUIRED_FIELD_MISSING': CapReason(
            code='REQUIRED_FIELD_MISSING',
            message='Essential field is missing (business requirement)',
            legal_reference=None,
            regulatory_framework=None,
            remediation_action='Complete required field',
            severity='CRITICAL'
        ),
        'E_TIER_VALIDATION_FAILED': CapReason(
            code='E_TIER_VALIDATION_FAILED',
            message='Essential field failed validation rules',
            legal_reference=None,
            regulatory_framework=None,
            remediation_action='Correct field value to meet validation criteria',
            severity='CRITICAL'
        )
    }
    
    def generate_cap_reason(
        self,
        column_name: str,
        tier: str,
        failure_type: str,
        column_config: Optional[Dict[str, Any]] = None
    ) -> Optional[CapReason]:
        """
        Generate cap reason for E-tier failure
        
        Args:
            column_name: Name of failing column
            tier: Tier (must be 'E' for cap)
            failure_type: Type of failure (missing, invalid, etc.)
            column_config: Optional column configuration with legal_reference
            
        Returns:
            CapReason if tier is E, None otherwise
            
        Example:
            >>> generator = CapReasonGenerator()
            >>> config = {
            ...     'legal_reference': '45 CFR 164.312(a)(1)',
            ...     'regulatory_framework': 'HIPAA'
            ... }
            >>> reason = generator.generate_cap_reason(
            ...     'patient_id', 'E', 'missing', config
            ... )
            >>> print(reason.code)
            'HIPAA_PATIENT_ID_MISSING'
        """
        # Only generate for E-tier
        if tier != 'E':
            return None
        
        # Try to match predefined templates
        cap_reason = self._match_template(column_name, failure_type, column_config)
        
        if cap_reason:
            return cap_reason
        
        # Generate custom cap reason
        return self._generate_custom(column_name, failure_type, column_config)
    
    def _match_template(
        self,
        column_name: str,
        failure_type: str,
        column_config: Optional[Dict[str, Any]]
    ) -> Optional[CapReason]:
        """Try to match predefined template"""
        
        # Get regulatory framework from config
        framework = None
        if column_config and 'regulatory_framework' in column_config:
            framework_str = column_config['regulatory_framework'].upper()
            try:
                framework = RegulatoryFramework[framework_str]
            except KeyError:
                pass
        
        # Match HIPAA patterns
        if framework == RegulatoryFramework.HIPAA:
            if 'patient' in column_name.lower() and 'id' in column_name.lower():
                return self.REASON_TEMPLATES['HIPAA_PATIENT_ID_MISSING']
            elif any(term in column_name.lower() for term in ['allergy', 'medication', 'diagnosis']):
                return self.REASON_TEMPLATES['HIPAA_MEDICAL_RECORDS_MISSING']
            else:
                return self.REASON_TEMPLATES['HIPAA_PHI_INCOMPLETE']
        
        # Match SOX patterns
        elif framework == RegulatoryFramework.SOX:
            if 'transaction' in column_name.lower() and 'id' in column_name.lower():
                return self.REASON_TEMPLATES['SOX_TRANSACTION_ID_MISSING']
            else:
                return self.REASON_TEMPLATES['SOX_FINANCIAL_RECORD_INCOMPLETE']
        
        # Match PCI-DSS patterns
        elif framework == RegulatoryFramework.PCI_DSS:
            return self.REASON_TEMPLATES['PCI_CARDHOLDER_DATA_MISSING']
        
        # Match GDPR patterns
        elif framework == RegulatoryFramework.GDPR:
            if 'consent' in column_name.lower():
                return self.REASON_TEMPLATES['GDPR_CONSENT_MISSING']
        
        # No match
        return None
    
    def _generate_custom(
        self,
        column_name: str,
        failure_type: str,
        column_config: Optional[Dict[str, Any]]
    ) -> CapReason:
        """Generate custom cap reason"""
        
        # Extract legal reference if provided
        legal_ref = None
        framework = None
        if column_config:
            legal_ref = column_config.get('legal_reference')
            framework_str = column_config.get('regulatory_framework')
            if framework_str:
                try:
                    framework = RegulatoryFramework[framework_str.upper()]
                except KeyError:
                    framework = RegulatoryFramework.CUSTOM
        
        # Generate code
        if framework:
            code = f"{framework.value}_{column_name.upper()}_{failure_type.upper()}"
        else:
            code = f"E_TIER_{column_name.upper()}_{failure_type.upper()}"
        
        # Generate message
        if failure_type == 'missing':
            message = f"Essential field '{column_name}' is missing"
        elif failure_type == 'invalid':
            message = f"Essential field '{column_name}' failed validation"
        else:
            message = f"Essential field '{column_name}' failed: {failure_type}"
        
        # Add regulatory context
        if framework and legal_ref:
            message += f" ({framework.value} requirement)"
        elif framework:
            message += f" ({framework.value} required)"
        
        return CapReason(
            code=code,
            message=message,
            legal_reference=legal_ref,
            regulatory_framework=framework,
            remediation_action=f"Complete or correct '{column_name}' field",
            severity='CRITICAL'
        )


# Example usage
if __name__ == "__main__":
    print("DAIS-10 v1.1: E-Tier Cap Reasons Demo")
    print("=" * 60)
    
    generator = CapReasonGenerator()
    
    # Example 1: HIPAA patient ID
    print("\n1. HIPAA Patient ID (Missing):")
    config_hipaa = {
        'regulatory_framework': 'HIPAA',
        'legal_reference': '45 CFR 164.312(a)(1)'
    }
    reason1 = generator.generate_cap_reason(
        'patient_id', 'E', 'missing', config_hipaa
    )
    print(f"   Code: {reason1.code}")
    print(f"   Message: {reason1.message}")
    print(f"   Legal Ref: {reason1.legal_reference}")
    print(f"   Remediation: {reason1.remediation_action}")
    
    # Example 2: SOX transaction ID
    print("\n2. SOX Transaction ID (Missing):")
    config_sox = {
        'regulatory_framework': 'SOX',
        'legal_reference': 'SOX Section 404'
    }
    reason2 = generator.generate_cap_reason(
        'transaction_id', 'E', 'missing', config_sox
    )
    print(f"   Code: {reason2.code}")
    print(f"   Message: {reason2.message}")
    print(f"   Legal Ref: {reason2.legal_reference}")
    
    # Example 3: Custom requirement
    print("\n3. Custom Business Requirement:")
    config_custom = {
        'legal_reference': 'Company Policy XYZ-123'
    }
    reason3 = generator.generate_cap_reason(
        'approval_code', 'E', 'missing', config_custom
    )
    print(f"   Code: {reason3.code}")
    print(f"   Message: {reason3.message}")
    print(f"   Legal Ref: {reason3.legal_reference}")
    
    # Example 4: No cap for non-E tier
    print("\n4. Non-E Tier (No Cap):")
    reason4 = generator.generate_cap_reason(
        'email', 'C', 'missing', None
    )
    print(f"   Cap Applied: {reason4 is not None}")
    
    print("\n" + "=" * 60)
    print("✅ Cap reasons generated successfully!")
    print("\nJSON Output Example:")
    import json
    print(json.dumps(reason1.to_dict(), indent=2))
