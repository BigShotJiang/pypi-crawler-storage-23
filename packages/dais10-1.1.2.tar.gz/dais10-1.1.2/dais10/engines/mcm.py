"""
MCM-10: Meaning Classification Model

Engine 2 of 8 in DAIS-10 pipeline.
Assigns semantic roles: MD (Meaning-Defining), ME (Meaning-Enhancing),
MX (Meaning-Extending), MN (Meaning-Neutral)

Type signature: A → R (attribute → role)

This is where DAIS-10 understands WHAT data means.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from dais10.core.types import SemanticRole, Context
from dais10.engines.sis import AttributeMetadata, ValuePatterns


class MCM10:
    """
    MCM-10: Meaning Classification Model
    
    Engine 2 of 8 in DAIS-10 pipeline.
    
    Classification Rules (in priority order):
    
    1. IDENTITY RULE → MD
       - Attribute defines record identity (patient_id, transaction_id)
       - High cardinality (unique per record)
       - Name contains: _id, _key, _code, _number
    
    2. SAFETY RULE → MD
       - Attribute critical for safety/security
       - Domain: medical_safety, financial_security, physical_safety
       - Examples: allergies, blood_type, transaction_amount
    
    3. ENHANCEMENT RULE → ME
       - Attribute enhances interpretation
       - Not identity-defining
       - Provides context (email, phone, address)
    
    4. EXTENSION RULE → MX
       - Attribute adds analytical depth
       - Used for analysis, not interpretation
       - Examples: loyalty_score, risk_rating, segment
    
    5. METADATA RULE → MN
       - Attribute is metadata only
       - Tracking/auditing purposes
       - Examples: created_at, updated_by, version
    
    Complexity: O(1) per attribute
    """
    
    # Safety-critical field names (domain-specific)
    SAFETY_CRITICAL_MEDICAL = {
        'allergy', 'allergies', 'blood_type', 'blood_group',
        'medication', 'prescription', 'diagnosis', 'condition',
    }
    
    SAFETY_CRITICAL_FINANCIAL = {
        'transaction_id', 'account_number', 'routing_number',
        'amount', 'balance', 'transaction_amount',
    }
    
    # Analytical field markers
    ANALYTICAL_MARKERS = {
        'score', 'rating', 'rank', 'segment', 'category',
        'cluster', 'propensity', 'likelihood', 'probability',
        'flag', 'indicator', 'metric',
    }
    
    def __init__(self):
        """Initialize MCM-10 engine."""
        pass  # Stateless
    
    def classify_role(
        self,
        attribute_name: str,
        metadata: AttributeMetadata,
        patterns: ValuePatterns,
        context: Context,
    ) -> SemanticRole:
        """
        Classify semantic role of an attribute.
        
        Args:
            attribute_name: Attribute name
            metadata: SIS-10 metadata
            patterns: SIS-10 value patterns
            context: Domain context
            
        Returns:
            SemanticRole (MD/ME/MX/MN)
            
        Algorithm:
        Apply classification rules in priority order.
        First matching rule wins.
        
        Complexity: O(1)
        """
        # RULE 1: METADATA RULE (highest priority for metadata)
        if self._is_metadata(metadata):
            return SemanticRole.MN
        
        # RULE 2: IDENTITY RULE
        if self._is_identity_defining(metadata, patterns):
            return SemanticRole.MD
        
        # RULE 3: SAFETY RULE
        if self._is_safety_critical(metadata, context):
            return SemanticRole.MD
        
        # RULE 4: ANALYTICAL RULE
        if self._is_analytical(metadata, patterns):
            return SemanticRole.MX
        
        # RULE 5: ENHANCEMENT RULE (default for remaining)
        return SemanticRole.ME
    
    def _is_metadata(self, metadata: AttributeMetadata) -> bool:
        """
        Check if attribute is metadata.
        
        Metadata markers:
        - created_at, updated_at, modified_at, deleted_at
        - created_by, updated_by
        - version, hash, checksum
        - inserted_at, recorded_at, logged_at
        """
        if metadata.contains_metadata_marker:
            return True
        
        # Additional checks
        name_lower = metadata.normalized_name
        
        metadata_patterns = [
            '_timestamp', '_hash', '_checksum', '_version',
            '_etag', '_revision', '_audit',
        ]
        
        return any(pattern in name_lower for pattern in metadata_patterns)
    
    def _is_identity_defining(
        self,
        metadata: AttributeMetadata,
        patterns: ValuePatterns,
    ) -> bool:
        """
        Check if attribute defines record identity.
        
        Identity indicators:
        - Name contains: _id, _key, _code, _number, _identifier
        - High cardinality (≈ 1.0 = unique per record)
        - UUID/GUID pattern
        - Name is literally 'id' or 'key'
        """
        # Check name patterns
        if metadata.contains_id_marker:
            return True
        
        # Check if name is literally identity
        if metadata.normalized_name in ('id', 'key', 'code', 'identifier'):
            return True
        
        # Check cardinality (high uniqueness = likely identity)
        if patterns.cardinality_ratio >= 0.95:  # 95%+ unique
            # AND name suggests identity
            if any(token in ('id', 'key', 'code', 'number', 'identifier') 
                   for token in metadata.tokens):
                return True
        
        # Check UUID pattern
        if patterns.has_uuid_pattern:
            return True
        
        return False
    
    def _is_safety_critical(
        self,
        metadata: AttributeMetadata,
        context: Context,
    ) -> bool:
        """
        Check if attribute is safety-critical.
        
        Safety-critical attributes are Meaning-Defining because
        they define operational requirements (medical, financial, etc.)
        """
        name_lower = metadata.normalized_name
        
        # Domain-specific safety checks
        if context.domain in ('healthcare', 'medical'):
            if any(term in name_lower for term in self.SAFETY_CRITICAL_MEDICAL):
                return True
        
        if context.domain in ('finance', 'financial', 'banking'):
            if any(term in name_lower for term in self.SAFETY_CRITICAL_FINANCIAL):
                return True
        
        # General safety markers
        safety_markers = ['emergency', 'critical', 'alert', 'warning']
        if any(marker in name_lower for marker in safety_markers):
            return True
        
        return False
    
    def _is_analytical(
        self,
        metadata: AttributeMetadata,
        patterns: ValuePatterns,
    ) -> bool:
        """
        Check if attribute is analytical.
        
        Analytical indicators:
        - Name contains: score, rating, rank, segment, category
        - Name contains: flag, indicator, metric
        - Derived/computed values (typically numeric)
        """
        name_lower = metadata.normalized_name
        
        # Check name patterns
        if any(marker in name_lower for marker in self.ANALYTICAL_MARKERS):
            return True
        
        # Check for computed/derived field patterns
        computed_prefixes = ['calculated_', 'computed_', 'derived_', 'is_', 'has_']
        if any(name_lower.startswith(prefix) for prefix in computed_prefixes):
            return True
        
        return False
    
    def get_classification_rationale(
        self,
        role: SemanticRole,
        attribute_name: str,
        metadata: AttributeMetadata,
    ) -> str:
        """
        Generate human-readable rationale for classification.
        
        Args:
            role: Assigned semantic role
            attribute_name: Attribute name
            metadata: Attribute metadata
            
        Returns:
            Explanation string
        """
        if role == SemanticRole.MD:
            if metadata.contains_id_marker:
                return f"Defines record identity (contains ID marker)"
            elif metadata.normalized_name in self.SAFETY_CRITICAL_MEDICAL:
                return f"Safety-critical field (medical domain)"
            elif metadata.normalized_name in self.SAFETY_CRITICAL_FINANCIAL:
                return f"Safety-critical field (financial domain)"
            else:
                return f"Meaning-defining attribute"
        
        elif role == SemanticRole.ME:
            return f"Enhances record interpretation"
        
        elif role == SemanticRole.MX:
            return f"Extends analytical capability"
        
        else:  # MN
            if metadata.contains_metadata_marker:
                return f"Metadata tracking field"
            else:
                return f"Metadata/audit field"
    
    def __repr__(self) -> str:
        return "MCM10(Meaning Classification Model)"
