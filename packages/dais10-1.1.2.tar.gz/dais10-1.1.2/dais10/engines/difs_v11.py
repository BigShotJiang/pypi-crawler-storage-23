"""
DAIS-10 v1.1 - Feature 1: Column-Anchored Freshness

NEW: Each column has its own event_time_source for decay calculation

Author: Dr. Usman Zafar
Version: 1.1.0
"""

import math
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Union
from dataclasses import dataclass


@dataclass
class FreshnessResult:
    """Result of freshness calculation"""
    freshness_score: float  # 0.0 - 1.0
    days_old: int
    event_date: datetime
    decay_rate: float
    half_life_days: float


class DIFS10_v11:
    """
    DIFS-10 v1.1: Drift & Fading Subzones with Column-Anchored Freshness
    
    NEW in v1.1:
    - Each column specifies its own event_time_source
    - No more row-level timestamps (legally indefensible)
    - Explicit validation of timestamp availability
    
    Changes from v1.0:
    - apply_decay() now requires event_time_column
    - Raises error if timestamp missing (no silent defaults)
    - Returns FreshnessResult with full context
    """
    
    def calculate_freshness(
        self,
        row_data: Dict[str, Any],
        event_time_source: str,
        decay_rate: float,
        current_date: Optional[datetime] = None
    ) -> FreshnessResult:
        """
        Calculate freshness score with column-specific timestamp
        
        NEW in v1.1: Requires explicit event_time_source per column
        
        Args:
            row_data: Complete row data
            event_time_source: Column name containing timestamp
            decay_rate: Decay rate (λ) for this column
            current_date: Reference date (default: now)
            
        Returns:
            FreshnessResult with score and context
            
        Raises:
            ValueError: If event_time_source missing from row_data
            
        Example:
            >>> row = {
            ...     'patient_id': 'P001',
            ...     'created_at': datetime(2024, 1, 1),
            ...     'last_visit_date': datetime(2025, 2, 10),
            ...     'email_updated_at': datetime(2023, 1, 1)
            ... }
            >>> 
            >>> # Different freshness for different columns
            >>> difs = DIFS10_v11()
            >>> 
            >>> # patient_id uses created_at
            >>> id_fresh = difs.calculate_freshness(
            ...     row, 'created_at', decay_rate=0.0001
            ... )
            >>> 
            >>> # allergies uses last_visit_date
            >>> allergy_fresh = difs.calculate_freshness(
            ...     row, 'last_visit_date', decay_rate=0.001
            ... )
            >>> 
            >>> # email uses email_updated_at
            >>> email_fresh = difs.calculate_freshness(
            ...     row, 'email_updated_at', decay_rate=0.010
            ... )
        """
        if current_date is None:
            current_date = datetime.now()
        
        # CRITICAL: Validate timestamp exists
        if event_time_source not in row_data:
            raise ValueError(
                f"Column-anchored freshness requires '{event_time_source}' "
                f"but it's missing from row data. Available columns: {list(row_data.keys())}"
            )
        
        event_date = row_data[event_time_source]
        
        # Validate event_date is datetime
        if not isinstance(event_date, datetime):
            if isinstance(event_date, str):
                # Try to parse string date
                try:
                    event_date = datetime.fromisoformat(event_date.replace('Z', '+00:00'))
                except:
                    raise ValueError(
                        f"Cannot parse '{event_time_source}' as datetime: {event_date}"
                    )
            else:
                raise ValueError(
                    f"'{event_time_source}' must be datetime, got {type(event_date)}"
                )
        
        # Calculate age in days
        delta = current_date - event_date
        days_old = max(0, delta.days)  # Prevent negative age
        
        # Apply exponential decay: s(t) = exp(-λt)
        freshness_score = math.exp(-decay_rate * days_old)
        
        # Calculate half-life
        half_life = math.log(2) / decay_rate if decay_rate > 0 else float('inf')
        
        return FreshnessResult(
            freshness_score=freshness_score,
            days_old=days_old,
            event_date=event_date,
            decay_rate=decay_rate,
            half_life_days=half_life
        )
    
    def apply_decay_v11(
        self,
        score: float,
        row_data: Dict[str, Any],
        event_time_source: str,
        decay_rate: float,
        current_date: Optional[datetime] = None
    ) -> float:
        """
        Apply decay to score using column-specific timestamp
        
        NEW in v1.1: Replaces v1.0 apply_decay() which used row-level timestamp
        
        Args:
            score: Initial score (0-100)
            row_data: Complete row data
            event_time_source: Column name for timestamp
            decay_rate: Decay rate (λ)
            current_date: Reference date
            
        Returns:
            Decayed score
            
        Example:
            >>> difs = DIFS10_v11()
            >>> row = {'created_at': datetime(2020, 1, 1)}
            >>> 
            >>> # After 5 years with slow decay
            >>> decayed = difs.apply_decay_v11(
            ...     score=100,
            ...     row_data=row,
            ...     event_time_source='created_at',
            ...     decay_rate=0.0001,
            ...     current_date=datetime(2025, 1, 1)
            ... )
            >>> print(decayed)  # ~86.07
        """
        freshness = self.calculate_freshness(
            row_data, event_time_source, decay_rate, current_date
        )
        
        return score * freshness.freshness_score
    
    def get_decay_explanation(
        self,
        row_data: Dict[str, Any],
        event_time_source: str,
        decay_rate: float,
        current_date: Optional[datetime] = None
    ) -> str:
        """
        Get human-readable explanation of decay
        
        Returns:
            Explanation string
            
        Example:
            >>> "Data is 730 days old (50.8% decayed, half-life 693 days)"
        """
        freshness = self.calculate_freshness(
            row_data, event_time_source, decay_rate, current_date
        )
        
        decay_pct = (1 - freshness.freshness_score) * 100
        
        return (
            f"Data is {freshness.days_old} days old "
            f"({decay_pct:.1f}% decayed, "
            f"half-life {freshness.half_life_days:.0f} days)"
        )


# Backward compatibility wrapper (deprecated)
class DIFS10:
    """
    DEPRECATED: v1.0 interface
    
    Use DIFS10_v11 instead for proper column-anchored freshness
    """
    
    def __init__(self):
        self._v11 = DIFS10_v11()
        import warnings
        warnings.warn(
            "DIFS10 v1.0 interface is deprecated. "
            "Use DIFS10_v11 with event_time_source for each column.",
            DeprecationWarning
        )
    
    def apply_decay(self, score: float, tier, days_elapsed: int) -> float:
        """DEPRECATED: Use apply_decay_v11 with event_time_source instead"""
        # Fallback to old behavior (but warn user)
        decay_rate = tier.decay_rate
        freshness = math.exp(-decay_rate * days_elapsed)
        return score * freshness


# Example usage
if __name__ == "__main__":
    import doctest
    doctest.testmod()
    
    # Demo
    print("DAIS-10 v1.1: Column-Anchored Freshness Demo")
    print("=" * 60)
    
    difs = DIFS10_v11()
    
    # Sample row with multiple timestamps
    row = {
        'patient_id': 'P001',
        'created_at': datetime(2020, 1, 1),
        'last_visit_date': datetime(2025, 2, 10),
        'email_updated_at': datetime(2023, 1, 1),
    }
    
    current = datetime(2025, 2, 15)
    
    # Different freshness for each column
    print("\nPatient ID (uses created_at):")
    id_fresh = difs.calculate_freshness(row, 'created_at', 0.0001, current)
    print(f"  Age: {id_fresh.days_old} days")
    print(f"  Freshness: {id_fresh.freshness_score*100:.1f}%")
    
    print("\nAllergies (uses last_visit_date):")
    allergy_fresh = difs.calculate_freshness(row, 'last_visit_date', 0.001, current)
    print(f"  Age: {allergy_fresh.days_old} days")
    print(f"  Freshness: {allergy_fresh.freshness_score*100:.1f}%")
    
    print("\nEmail (uses email_updated_at):")
    email_fresh = difs.calculate_freshness(row, 'email_updated_at', 0.010, current)
    print(f"  Age: {email_fresh.days_old} days")
    print(f"  Freshness: {email_fresh.freshness_score*100:.1f}%")
    
    print("\n✅ Column-anchored freshness working correctly!")
    print("Each column has its own timestamp source.")
