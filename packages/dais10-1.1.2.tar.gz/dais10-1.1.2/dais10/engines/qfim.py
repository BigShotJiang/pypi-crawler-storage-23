"""
QFIM-10: Qualified Interpretation Model

Engine 7 of 8 in DAIS-10 pipeline.
Translates importance scores into qualitative categories and governance recommendations.

Type signature: [0,100] → Interpretation (score → actionable recommendation)

This is where numbers become decisions.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from dataclasses import dataclass
from dais10.core.types import SemanticDescriptor, GovernanceLevel, QualitativeCategory


@dataclass(frozen=True)
class QualifiedInterpretation:
    """
    Complete interpretation of an importance score.
    
    Immutable for composition safety.
    """
    score: float
    category: QualitativeCategory
    governance: GovernanceLevel
    recommendation: str
    rationale: str


class QFIM10:
    """
    QFIM-10: Qualified Interpretation Model
    
    Engine 7 of 8 in DAIS-10 pipeline.
    
    Score → Category Mapping:
    - 90-100: Critical
    - 70-90:  High
    - 50-70:  Moderate
    - 30-50:  Low
    - 0-30:   Minimal
    
    Category → Governance Mapping:
    - Critical:  FAIL (halt system)
    - High:      FAIL (halt system)
    - Moderate:  WARN (log and continue)
    - Low:       INFO (monitor)
    - Minimal:   INFO (ignore)
    
    Provides:
    - Qualitative interpretation
    - Governance recommendation
    - Action guidance
    - Human-readable rationale
    
    Complexity: O(1) per attribute
    """
    
    def __init__(self):
        """Initialize QFIM-10 engine."""
        pass  # Stateless
    
    def interpret(
        self,
        descriptor: SemanticDescriptor,
    ) -> QualifiedInterpretation:
        """
        Generate qualified interpretation for a descriptor.
        
        Args:
            descriptor: Semantic descriptor with score
            
        Returns:
            QualifiedInterpretation with category, governance, recommendation
            
        Example:
            >>> qfim = QFIM10()
            >>> desc = SemanticDescriptor('allergies', MD, E, 92)
            >>> interp = qfim.interpret(desc)
            >>> interp.category
            QualitativeCategory.CRITICAL
            >>> interp.governance
            GovernanceLevel.FAIL
        """
        score = descriptor.score
        
        # Determine category
        category = self._categorize_score(score)
        
        # Determine governance level
        governance = self._determine_governance(category, descriptor.tier)
        
        # Generate recommendation
        recommendation = self._generate_recommendation(
            category, governance, descriptor
        )
        
        # Generate rationale
        rationale = self._generate_rationale(
            descriptor, category, governance
        )
        
        return QualifiedInterpretation(
            score=score,
            category=category,
            governance=governance,
            recommendation=recommendation,
            rationale=rationale,
        )
    
    def _categorize_score(self, score: float) -> QualitativeCategory:
        """
        Categorize importance score.
        
        Args:
            score: Importance score (0-100)
            
        Returns:
            Qualitative category
        """
        if 90 <= score <= 100:
            return QualitativeCategory.CRITICAL
        elif 70 <= score < 90:
            return QualitativeCategory.HIGH
        elif 50 <= score < 70:
            return QualitativeCategory.MODERATE
        elif 30 <= score < 50:
            return QualitativeCategory.LOW
        else:
            return QualitativeCategory.MINIMAL
    
    def _determine_governance(
        self,
        category: QualitativeCategory,
        tier: 'Tier',
    ) -> GovernanceLevel:
        """
        Determine governance level.
        
        Uses both category and tier for decision.
        
        Args:
            category: Qualitative category
            tier: Attribute tier
            
        Returns:
            Governance level (FAIL/WARN/INFO)
        """
        # Essential tier: Always FAIL
        if tier.value in ('E', 'EC'):
            return GovernanceLevel.FAIL
        
        # Category-based for other tiers
        if category in (QualitativeCategory.CRITICAL, QualitativeCategory.HIGH):
            return GovernanceLevel.FAIL
        
        elif category == QualitativeCategory.MODERATE:
            return GovernanceLevel.WARN
        
        else:
            return GovernanceLevel.INFO
    
    def _generate_recommendation(
        self,
        category: QualitativeCategory,
        governance: GovernanceLevel,
        descriptor: SemanticDescriptor,
    ) -> str:
        """
        Generate actionable recommendation.
        
        Args:
            category: Qualitative category
            governance: Governance level
            descriptor: Full descriptor
            
        Returns:
            Recommendation string
        """
        attr_name = descriptor.attribute_name
        
        if governance == GovernanceLevel.FAIL:
            if category == QualitativeCategory.CRITICAL:
                return (
                    f"HALT system if '{attr_name}' is missing. "
                    f"Critical for operation. Implement strict validation."
                )
            else:
                return (
                    f"Block pipeline if '{attr_name}' is missing. "
                    f"Required for data integrity."
                )
        
        elif governance == GovernanceLevel.WARN:
            return (
                f"Log warning if '{attr_name}' is missing. "
                f"Reduces data clarity but not critical. Continue processing."
            )
        
        else:  # INFO
            if category == QualitativeCategory.MINIMAL:
                return (
                    f"Ignore if '{attr_name}' is missing. "
                    f"Analytical only, no operational impact."
                )
            else:
                return (
                    f"Monitor '{attr_name}' completeness. "
                    f"Optional but useful for analysis."
                )
    
    def _generate_rationale(
        self,
        descriptor: SemanticDescriptor,
        category: QualitativeCategory,
        governance: GovernanceLevel,
    ) -> str:
        """
        Generate human-readable rationale.
        
        Args:
            descriptor: Semantic descriptor
            category: Qualitative category
            governance: Governance level
            
        Returns:
            Rationale string
        """
        parts = []
        
        # Score interpretation
        parts.append(f"Importance score: {descriptor.score}/100 ({category.value})")
        
        # Tier contribution
        parts.append(f"Tier: {descriptor.tier.value} ({descriptor.tier.description})")
        
        # Role contribution
        role_desc = {
            'MD': "Defines record identity",
            'ME': "Enhances interpretation",
            'MX': "Extends analysis",
            'MN': "Metadata only",
        }[descriptor.role.value]
        parts.append(f"Role: {descriptor.role.value} ({role_desc})")
        
        # Governance decision
        gov_desc = {
            GovernanceLevel.FAIL: "Critical enforcement",
            GovernanceLevel.WARN: "Warning only",
            GovernanceLevel.INFO: "Monitoring",
        }[governance]
        parts.append(f"Governance: {governance.value} ({gov_desc})")
        
        return ". ".join(parts) + "."
    
    def get_validation_sql_snippet(
        self,
        descriptor: SemanticDescriptor,
        interpretation: QualifiedInterpretation,
    ) -> str:
        """
        Generate SQL validation snippet.
        
        Args:
            descriptor: Semantic descriptor
            interpretation: Qualified interpretation
            
        Returns:
            SQL CASE statement for validation
            
        Example:
            >>> snippet = qfim.get_validation_sql_snippet(desc, interp)
            >>> print(snippet)
            CASE
                WHEN patient_id IS NULL THEN 'FAIL'
                ELSE 'PASS'
            END AS patient_id_validation
        """
        attr_name = descriptor.attribute_name
        governance = interpretation.governance.value
        
        return f"""CASE
    WHEN {attr_name} IS NULL THEN '{governance}'
    ELSE 'PASS'
END AS {attr_name}_validation"""
    
    def batch_interpret(
        self,
        descriptors: list[SemanticDescriptor],
    ) -> list[QualifiedInterpretation]:
        """
        Interpret multiple descriptors at once.
        
        Args:
            descriptors: List of semantic descriptors
            
        Returns:
            List of interpretations
        """
        return [self.interpret(desc) for desc in descriptors]
    
    def get_governance_summary(
        self,
        descriptors: list[SemanticDescriptor],
    ) -> dict[GovernanceLevel, int]:
        """
        Get summary of governance levels across all attributes.
        
        Args:
            descriptors: List of semantic descriptors
            
        Returns:
            Count of each governance level
            
        Example:
            >>> summary = qfim.get_governance_summary(descriptors)
            >>> print(summary)
            {
                GovernanceLevel.FAIL: 5,
                GovernanceLevel.WARN: 8,
                GovernanceLevel.INFO: 12
            }
        """
        interpretations = self.batch_interpret(descriptors)
        
        summary = {
            GovernanceLevel.FAIL: 0,
            GovernanceLevel.WARN: 0,
            GovernanceLevel.INFO: 0,
        }
        
        for interp in interpretations:
            summary[interp.governance] += 1
        
        return summary
    
    def __repr__(self) -> str:
        return "QFIM10(Qualified Interpretation Model)"
