"""
TIER-10: Tier Assignment System

Engine 3 of 8 in DAIS-10 pipeline.
Maps semantic roles to importance tiers based on context.

Type signature: R × Context → T (role + context → tier)

This is where meaning becomes actionable governance.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from dais10.core.types import SemanticRole, Tier, Context


class TIER10:
    """
    TIER-10: Tier Assignment System
    
    Engine 3 of 8 in DAIS-10 pipeline.
    
    Assignment Logic:
    
    MD (Meaning-Defining) → E or EC
        If critical context: E (Essential)
        If conditional context: EC (Semi-Essential)
    
    ME (Meaning-Enhancing) → C or CN
        If high importance: C (Contextual)
        If medium importance: CN (Semi-Contextual)
    
    MX (Meaning-Extending) → CN or N
        If useful: CN (Semi-Contextual)
        If optional: N (Enrichment)
    
    MN (Meaning-Neutral) → N
        Always: N (Enrichment)
    
    Context influences tier assignment:
    - Regulatory frameworks (HIPAA, SOX) → higher tiers
    - Criticality levels → tier adjustment
    - Domain requirements → specific rules
    
    Complexity: O(1) per attribute
    """
    
    def __init__(self):
        """Initialize TIER-10 engine."""
        pass  # Stateless
    
    def assign_tier(
        self,
        role: SemanticRole,
        context: Context,
    ) -> Tier:
        """
        Assign tier based on semantic role and context.
        
        Args:
            role: Semantic role from MCM-10
            context: Domain context
            
        Returns:
            Tier (E/EC/C/CN/N)
            
        Algorithm:
        1. Check role
        2. Apply context modifiers
        3. Return tier
        
        Complexity: O(1)
        """
        # MN (Meaning-Neutral) → Always N
        if role == SemanticRole.MN:
            return Tier.N
        
        # MD (Meaning-Defining) → E or EC
        if role == SemanticRole.MD:
            return self._assign_md_tier(context)
        
        # ME (Meaning-Enhancing) → C or CN
        if role == SemanticRole.ME:
            return self._assign_me_tier(context)
        
        # MX (Meaning-Extending) → CN or N
        if role == SemanticRole.MX:
            return self._assign_mx_tier(context)
        
        # Fallback (should never reach)
        return Tier.N
    
    def _assign_md_tier(self, context: Context) -> Tier:
        """
        Assign tier for Meaning-Defining attributes.
        
        MD attributes are critical by definition.
        Context determines if Essential (E) or Semi-Essential (EC).
        
        Rules:
        - High criticality → E
        - Regulatory requirement → E
        - Healthcare/Finance domains → E (default)
        - Other domains → EC (conditional)
        """
        # Critical context → Essential
        if context.criticality == 'high':
            return Tier.E
        
        # Regulatory frameworks → Essential
        if context.regulatory in ('HIPAA', 'SOX', 'PCI-DSS', 'GDPR'):
            return Tier.E
        
        # Domain-specific defaults
        if context.domain in ('healthcare', 'medical'):
            return Tier.E  # Patient safety critical
        
        if context.domain in ('finance', 'financial', 'banking'):
            return Tier.E  # Financial security critical
        
        if context.domain in ('manufacturing', 'industrial'):
            return Tier.E  # Operational safety critical
        
        # Default for MD: Semi-Essential (conditional)
        return Tier.EC
    
    def _assign_me_tier(self, context: Context) -> Tier:
        """
        Assign tier for Meaning-Enhancing attributes.
        
        ME attributes enhance interpretation.
        Context determines if Contextual (C) or Semi-Contextual (CN).
        
        Rules:
        - High criticality → C
        - Regulatory requirement → C
        - Healthcare → C (enhanced context needed)
        - Default → CN (semi-contextual)
        """
        # High criticality → Contextual
        if context.criticality == 'high':
            return Tier.C
        
        # Regulatory frameworks may require enhanced context
        if context.regulatory in ('HIPAA', 'SOX'):
            return Tier.C
        
        # Healthcare domain → higher tier for context
        if context.domain in ('healthcare', 'medical'):
            return Tier.C
        
        # Default: Semi-Contextual
        return Tier.CN
    
    def _assign_mx_tier(self, context: Context) -> Tier:
        """
        Assign tier for Meaning-Extending attributes.
        
        MX attributes add analytical depth.
        Context determines if Semi-Contextual (CN) or Enrichment (N).
        
        Rules:
        - Analytics-heavy domains → CN (useful)
        - Default → N (optional)
        """
        # Analytics-focused contexts
        if context.domain in ('analytics', 'data_science', 'ml'):
            return Tier.CN
        
        # E-commerce (analytics important)
        if context.domain in ('ecommerce', 'retail'):
            return Tier.CN
        
        # Default: Enrichment (optional)
        return Tier.N
    
    def get_tier_rationale(
        self,
        role: SemanticRole,
        tier: Tier,
        context: Context,
    ) -> str:
        """
        Generate human-readable rationale for tier assignment.
        
        Args:
            role: Semantic role
            tier: Assigned tier
            context: Context used
            
        Returns:
            Explanation string
        """
        role_name = {
            SemanticRole.MD: "Meaning-Defining",
            SemanticRole.ME: "Meaning-Enhancing",
            SemanticRole.MX: "Meaning-Extending",
            SemanticRole.MN: "Meaning-Neutral",
        }[role]
        
        tier_name = {
            Tier.E: "Essential",
            Tier.EC: "Semi-Essential",
            Tier.C: "Contextual",
            Tier.CN: "Semi-Contextual",
            Tier.N: "Enrichment",
        }[tier]
        
        # Build rationale
        parts = [f"{role_name} → {tier_name}"]
        
        # Add context factors
        if context.criticality:
            parts.append(f"criticality={context.criticality}")
        
        if context.regulatory:
            parts.append(f"regulatory={context.regulatory}")
        
        if context.domain:
            parts.append(f"domain={context.domain}")
        
        return ", ".join(parts)
    
    def __repr__(self) -> str:
        return "TIER10(Tier Assignment System)"
