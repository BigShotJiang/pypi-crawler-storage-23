"""
AMD-10: Automated Meaning Diagnostics

Engine 8 of 8 in DAIS-10 pipeline.
Validates semantic classifications with 22 systematic diagnostic tests.

Type signature: Σ × Context → DiagnosticReport (descriptor → validation report)

This is where DAIS-10 validates itself.

Author: Dr. Usman Zafar
Implementation: Claude (Anthropic)
"""

from __future__ import annotations

from typing import List
from dais10.core.types import (
    SemanticDescriptor,
    Context,
    DiagnosticReport,
    DiagnosticTest,
    Tier,
    SemanticRole,
)


class AMD10:
    """
    AMD-10: Automated Meaning Diagnostics
    
    Engine 8 of 8 in DAIS-10 pipeline.
    
    22 Diagnostic Tests across 5 Categories:
    
    1. Meaning Diagnostics (5 tests)
       - M1: Is meaning-defining correct?
       - M2: Is meaning-enhancing correct?
       - M3: Is meaning-extending correct?
       - M4: Detect meaning ambiguity
       - M5: Validate domain alignment
    
    2. Tier Diagnostics (4 tests)
       - T1: Is tier boundary appropriate?
       - T2: Is tier consistent with role?
       - T3: Detect tier conflict
       - T4: Detect tier drift
    
    3. Continuum Diagnostics (5 tests)
       - C1: Is score in valid range?
       - C2: Is score justified?
       - C3: Is score stable?
       - C4: Validate overlap zone
       - C5: Validate subzone assignment
    
    4. Governance Diagnostics (4 tests)
       - G1: Is enforcement aligned?
       - G2: Is documentation complete?
       - G3: Validate exceptions
       - G4: Detect governance drift
    
    5. Scoring Diagnostics (4 tests)
       - S1: Is weight accurate?
       - S2: Validate score contribution
       - S3: Validate scoring threshold
       - S4: Is scoring stable?
    
    Severity Levels:
    - CRITICAL: Must fix (blocks production)
    - MAJOR: Should fix (quality issue)
    - MINOR: Nice to fix (optimization)
    - INFO: Informational only
    
    Complexity: O(1) per attribute (22 constant-time tests)
    """
    
    def __init__(self):
        """Initialize AMD-10 engine."""
        pass  # Stateless
    
    def run_diagnostics(
        self,
        descriptor: SemanticDescriptor,
        context: Context,
        historical_data: dict | None = None,
    ) -> DiagnosticReport:
        """
        Run all 22 diagnostic tests on a classification.
        
        Args:
            descriptor: Semantic descriptor to validate
            context: Domain context
            historical_data: Optional historical classifications for drift detection
            
        Returns:
            DiagnosticReport with all test results
            
        Example:
            >>> amd = AMD10()
            >>> desc = SemanticDescriptor('patient_id', MD, E, 98)
            >>> report = amd.run_diagnostics(desc, context)
            >>> report.overall_status
            'VALID'
        """
        findings: List[DiagnosticTest] = []
        
        # Category 1: Meaning Diagnostics
        findings.extend(self._meaning_diagnostics(descriptor, context))
        
        # Category 2: Tier Diagnostics
        findings.extend(self._tier_diagnostics(descriptor, context))
        
        # Category 3: Continuum Diagnostics
        findings.extend(self._continuum_diagnostics(descriptor))
        
        # Category 4: Governance Diagnostics
        findings.extend(self._governance_diagnostics(descriptor, context))
        
        # Category 5: Scoring Diagnostics
        findings.extend(self._scoring_diagnostics(descriptor, historical_data))
        
        # Summarize results
        passed = sum(1 for f in findings if f.result == "PASS")
        warnings = sum(1 for f in findings if f.result == "WARNING")
        failed = sum(1 for f in findings if f.result == "FAIL")
        
        # Determine overall status
        critical_failures = [f for f in findings if f.severity == "CRITICAL" and f.result == "FAIL"]
        
        if critical_failures:
            overall_status = "INVALID"
        elif failed > 0 or warnings > 5:
            overall_status = "NEEDS_REVIEW"
        else:
            overall_status = "VALID"
        
        return DiagnosticReport(
            attribute_name=descriptor.attribute_name,
            classification=descriptor,
            tests_run=len(findings),
            passed=passed,
            warnings=warnings,
            failed=failed,
            findings=findings,
            overall_status=overall_status,
        )
    
    # =============================================================================
    # CATEGORY 1: MEANING DIAGNOSTICS
    # =============================================================================
    
    def _meaning_diagnostics(
        self,
        descriptor: SemanticDescriptor,
        context: Context,
    ) -> List[DiagnosticTest]:
        """Run 5 meaning diagnostic tests."""
        tests = []
        
        # M1: Is meaning-defining correct?
        tests.append(self._m1_is_meaning_defining_correct(descriptor))
        
        # M2: Is meaning-enhancing correct?
        tests.append(self._m2_is_meaning_enhancing_correct(descriptor))
        
        # M3: Is meaning-extending correct?
        tests.append(self._m3_is_meaning_extending_correct(descriptor))
        
        # M4: Detect meaning ambiguity
        tests.append(self._m4_detect_ambiguity(descriptor))
        
        # M5: Validate domain alignment
        tests.append(self._m5_validate_domain_alignment(descriptor, context))
        
        return tests
    
    def _m1_is_meaning_defining_correct(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """M1: Validate MD classification."""
        if desc.role == SemanticRole.MD:
            # Should be in E or EC tier
            if desc.tier not in (Tier.E, Tier.EC):
                return DiagnosticTest(
                    test_name="M1: Meaning-Defining Tier Check",
                    category="Meaning",
                    result="FAIL",
                    severity="MAJOR",
                    explanation=f"MD role should be E or EC tier, got {desc.tier.value}",
                    recommendation="Review tier assignment for meaning-defining attribute",
                )
        
        return DiagnosticTest(
            test_name="M1: Meaning-Defining Tier Check",
            category="Meaning",
            result="PASS",
            severity="INFO",
            explanation="Meaning-defining classification is appropriate",
        )
    
    def _m2_is_meaning_enhancing_correct(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """M2: Validate ME classification."""
        if desc.role == SemanticRole.ME:
            # Should be in C or CN tier
            if desc.tier not in (Tier.C, Tier.CN):
                return DiagnosticTest(
                    test_name="M2: Meaning-Enhancing Tier Check",
                    category="Meaning",
                    result="WARNING",
                    severity="MINOR",
                    explanation=f"ME role typically maps to C or CN, got {desc.tier.value}",
                    recommendation="Review if this attribute truly enhances meaning",
                )
        
        return DiagnosticTest(
            test_name="M2: Meaning-Enhancing Tier Check",
            category="Meaning",
            result="PASS",
            severity="INFO",
            explanation="Meaning-enhancing classification is appropriate",
        )
    
    def _m3_is_meaning_extending_correct(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """M3: Validate MX classification."""
        if desc.role == SemanticRole.MX:
            # Should be in CN or N tier
            if desc.tier not in (Tier.CN, Tier.N):
                return DiagnosticTest(
                    test_name="M3: Meaning-Extending Tier Check",
                    category="Meaning",
                    result="WARNING",
                    severity="MINOR",
                    explanation=f"MX role typically maps to CN or N, got {desc.tier.value}",
                    recommendation="Review if analytical attribute is over-weighted",
                )
        
        return DiagnosticTest(
            test_name="M3: Meaning-Extending Tier Check",
            category="Meaning",
            result="PASS",
            severity="INFO",
            explanation="Meaning-extending classification is appropriate",
        )
    
    def _m4_detect_ambiguity(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """M4: Detect semantic ambiguity."""
        # Check if score is near tier boundary (within 5 points)
        min_score, max_score = desc.tier.score_range
        
        near_lower = abs(desc.score - min_score) < 5
        near_upper = abs(desc.score - max_score) < 5
        
        if near_lower or near_upper:
            return DiagnosticTest(
                test_name="M4: Semantic Ambiguity Detection",
                category="Meaning",
                result="WARNING",
                severity="MINOR",
                explanation=f"Score {desc.score} near tier boundary, may indicate ambiguity",
                recommendation="Review attribute classification, consider overlap zone documentation",
            )
        
        return DiagnosticTest(
            test_name="M4: Semantic Ambiguity Detection",
            category="Meaning",
            result="PASS",
            severity="INFO",
            explanation="No semantic ambiguity detected",
        )
    
    def _m5_validate_domain_alignment(self, desc: SemanticDescriptor, context: Context) -> DiagnosticTest:
        """M5: Validate domain alignment."""
        # Healthcare-specific checks
        if context.domain == 'healthcare':
            critical_terms = ['allergy', 'allergies', 'blood', 'medication']
            if any(term in desc.attribute_name.lower() for term in critical_terms):
                if desc.tier != Tier.E:
                    return DiagnosticTest(
                        test_name="M5: Domain Alignment Check",
                        category="Meaning",
                        result="FAIL",
                        severity="CRITICAL",
                        explanation=f"Safety-critical healthcare field should be Essential tier",
                        recommendation=f"Upgrade {desc.attribute_name} to Essential tier",
                    )
        
        return DiagnosticTest(
            test_name="M5: Domain Alignment Check",
            category="Meaning",
            result="PASS",
            severity="INFO",
            explanation="Domain alignment validated",
        )
    
    # =============================================================================
    # CATEGORY 2: TIER DIAGNOSTICS
    # =============================================================================
    
    def _tier_diagnostics(
        self,
        descriptor: SemanticDescriptor,
        context: Context,
    ) -> List[DiagnosticTest]:
        """Run 4 tier diagnostic tests."""
        tests = []
        
        # T1: Is tier boundary appropriate?
        tests.append(self._t1_tier_boundary_check(descriptor))
        
        # T2: Is tier consistent with role?
        tests.append(self._t2_tier_role_consistency(descriptor))
        
        # T3: Detect tier conflict
        tests.append(self._t3_detect_tier_conflict(descriptor, context))
        
        # T4: Detect tier drift (placeholder - requires historical data)
        tests.append(self._t4_detect_tier_drift(descriptor))
        
        return tests
    
    def _t1_tier_boundary_check(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """T1: Check if tier boundaries are appropriate."""
        min_score, max_score = desc.tier.score_range
        
        if not (min_score <= desc.score <= max_score):
            return DiagnosticTest(
                test_name="T1: Tier Boundary Check",
                category="Tier",
                result="FAIL",
                severity="CRITICAL",
                explanation=f"Score {desc.score} outside tier range [{min_score}, {max_score}]",
                recommendation="Score violates tier boundaries - recalculate",
            )
        
        return DiagnosticTest(
            test_name="T1: Tier Boundary Check",
            category="Tier",
            result="PASS",
            severity="INFO",
            explanation="Score within valid tier range",
        )
    
    def _t2_tier_role_consistency(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """T2: Check tier-role consistency."""
        # Define expected tier ranges for each role
        expected = {
            SemanticRole.MD: [Tier.E, Tier.EC],
            SemanticRole.ME: [Tier.C, Tier.CN],
            SemanticRole.MX: [Tier.CN, Tier.N],
            SemanticRole.MN: [Tier.N],
        }
        
        if desc.tier not in expected[desc.role]:
            return DiagnosticTest(
                test_name="T2: Tier-Role Consistency",
                category="Tier",
                result="WARNING",
                severity="MINOR",
                explanation=f"{desc.role.value} typically maps to {[t.value for t in expected[desc.role]]}, got {desc.tier.value}",
                recommendation="Review classification - may be valid but unusual",
            )
        
        return DiagnosticTest(
            test_name="T2: Tier-Role Consistency",
            category="Tier",
            result="PASS",
            severity="INFO",
            explanation="Tier consistent with semantic role",
        )
    
    def _t3_detect_tier_conflict(self, desc: SemanticDescriptor, context: Context) -> DiagnosticTest:
        """T3: Detect tier conflicts with context."""
        # High criticality context with low tier = conflict
        if context.criticality == 'high' and desc.tier in (Tier.CN, Tier.N):
            return DiagnosticTest(
                test_name="T3: Tier Conflict Detection",
                category="Tier",
                result="WARNING",
                severity="MAJOR",
                explanation="Low tier in high-criticality context may indicate classification error",
                recommendation="Review if attribute should have higher tier given criticality",
            )
        
        return DiagnosticTest(
            test_name="T3: Tier Conflict Detection",
            category="Tier",
            result="PASS",
            severity="INFO",
            explanation="No tier conflicts detected",
        )
    
    def _t4_detect_tier_drift(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """T4: Detect tier drift over time."""
        # Placeholder - would compare against historical classifications
        return DiagnosticTest(
            test_name="T4: Tier Drift Detection",
            category="Tier",
            result="PASS",
            severity="INFO",
            explanation="No historical data for drift detection",
        )
    
    # =============================================================================
    # CATEGORY 3: CONTINUUM DIAGNOSTICS
    # =============================================================================
    
    def _continuum_diagnostics(self, descriptor: SemanticDescriptor) -> List[DiagnosticTest]:
        """Run 5 continuum diagnostic tests."""
        tests = []
        
        # C1: Is score in valid range?
        tests.append(self._c1_score_range_check(descriptor))
        
        # C2: Is score justified?
        tests.append(self._c2_score_justification(descriptor))
        
        # C3: Is score stable?
        tests.append(self._c3_score_stability(descriptor))
        
        # C4: Validate overlap zone
        tests.append(self._c4_validate_overlap_zone(descriptor))
        
        # C5: Validate subzone
        tests.append(self._c5_validate_subzone(descriptor))
        
        return tests
    
    def _c1_score_range_check(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """C1: Validate score is in valid range."""
        if not (0 <= desc.score <= 100):
            return DiagnosticTest(
                test_name="C1: Score Range Check",
                category="Continuum",
                result="FAIL",
                severity="CRITICAL",
                explanation=f"Score {desc.score} outside valid range [0, 100]",
                recommendation="Score calculation error - must be 0-100",
            )
        
        return DiagnosticTest(
            test_name="C1: Score Range Check",
            category="Continuum",
            result="PASS",
            severity="INFO",
            explanation="Score within valid range [0, 100]",
        )
    
    def _c2_score_justification(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """C2: Check if score has justification."""
        if not desc.rationale:
            return DiagnosticTest(
                test_name="C2: Score Justification",
                category="Continuum",
                result="WARNING",
                severity="MINOR",
                explanation="No rationale provided for score",
                recommendation="Add rationale to improve auditability",
            )
        
        return DiagnosticTest(
            test_name="C2: Score Justification",
            category="Continuum",
            result="PASS",
            severity="INFO",
            explanation="Score has documented rationale",
        )
    
    def _c3_score_stability(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """C3: Check score stability."""
        # Placeholder - would compare against historical scores
        return DiagnosticTest(
            test_name="C3: Score Stability Check",
            category="Continuum",
            result="PASS",
            severity="INFO",
            explanation="No historical data for stability check",
        )
    
    def _c4_validate_overlap_zone(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """C4: Validate overlap zone handling."""
        # Check if in overlap zone (EC or CN tiers)
        if desc.tier in (Tier.EC, Tier.CN):
            # Should have documentation explaining position
            if not desc.rationale or len(desc.rationale) < 20:
                return DiagnosticTest(
                    test_name="C4: Overlap Zone Validation",
                    category="Continuum",
                    result="WARNING",
                    severity="MINOR",
                    explanation="Overlap zone classification needs detailed rationale",
                    recommendation="Document why attribute is in overlap zone",
                )
        
        return DiagnosticTest(
            test_name="C4: Overlap Zone Validation",
            category="Continuum",
            result="PASS",
            severity="INFO",
            explanation="Overlap zone handling appropriate",
        )
    
    def _c5_validate_subzone(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """C5: Validate subzone assignment."""
        # Check if score aligns with tier center
        base_score = desc.tier.base_score
        deviation = abs(desc.score - base_score)
        
        # Large deviation (>15 points) may indicate issue
        if deviation > 15:
            return DiagnosticTest(
                test_name="C5: Subzone Assignment",
                category="Continuum",
                result="WARNING",
                severity="MINOR",
                explanation=f"Score {desc.score} deviates {deviation:.1f} points from tier base {base_score}",
                recommendation="Review if score should be in different tier or if deviation is justified",
            )
        
        return DiagnosticTest(
            test_name="C5: Subzone Assignment",
            category="Continuum",
            result="PASS",
            severity="INFO",
            explanation="Subzone assignment appropriate",
        )
    
    # =============================================================================
    # CATEGORY 4: GOVERNANCE DIAGNOSTICS
    # =============================================================================
    
    def _governance_diagnostics(
        self,
        descriptor: SemanticDescriptor,
        context: Context,
    ) -> List[DiagnosticTest]:
        """Run 4 governance diagnostic tests."""
        tests = []
        
        # G1: Is enforcement aligned?
        tests.append(self._g1_enforcement_alignment(descriptor))
        
        # G2: Is documentation complete?
        tests.append(self._g2_documentation_completeness(descriptor))
        
        # G3: Validate exceptions
        tests.append(self._g3_validate_exceptions(descriptor))
        
        # G4: Detect governance drift
        tests.append(self._g4_detect_governance_drift(descriptor, context))
        
        return tests
    
    def _g1_enforcement_alignment(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """G1: Check enforcement alignment with tier."""
        expected_governance = desc.governance_level
        
        # Essential should be FAIL
        if desc.tier == Tier.E and expected_governance != "FAIL":
            return DiagnosticTest(
                test_name="G1: Enforcement Alignment",
                category="Governance",
                result="FAIL",
                severity="CRITICAL",
                explanation="Essential tier must have FAIL governance",
                recommendation="Update governance to FAIL for Essential attributes",
            )
        
        return DiagnosticTest(
            test_name="G1: Enforcement Alignment",
            category="Governance",
            result="PASS",
            severity="INFO",
            explanation="Enforcement level aligned with tier",
        )
    
    def _g2_documentation_completeness(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """G2: Check documentation completeness."""
        # High-importance attributes should have documentation
        if desc.tier in (Tier.E, Tier.EC):
            if not desc.rationale or len(desc.rationale) < 30:
                return DiagnosticTest(
                    test_name="G2: Documentation Completeness",
                    category="Governance",
                    result="WARNING",
                    severity="MINOR",
                    explanation="Essential/Semi-Essential attributes need detailed documentation",
                    recommendation="Add comprehensive rationale for governance decisions",
                )
        
        return DiagnosticTest(
            test_name="G2: Documentation Completeness",
            category="Governance",
            result="PASS",
            severity="INFO",
            explanation="Documentation adequate",
        )
    
    def _g3_validate_exceptions(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """G3: Validate governance exceptions."""
        # Placeholder - would check exception log
        return DiagnosticTest(
            test_name="G3: Exception Validation",
            category="Governance",
            result="PASS",
            severity="INFO",
            explanation="No exceptions to validate",
        )
    
    def _g4_detect_governance_drift(self, desc: SemanticDescriptor, context: Context) -> DiagnosticTest:
        """G4: Detect governance drift."""
        # Placeholder - would compare against governance history
        return DiagnosticTest(
            test_name="G4: Governance Drift Detection",
            category="Governance",
            result="PASS",
            severity="INFO",
            explanation="No governance drift detected",
        )
    
    # =============================================================================
    # CATEGORY 5: SCORING DIAGNOSTICS
    # =============================================================================
    
    def _scoring_diagnostics(
        self,
        descriptor: SemanticDescriptor,
        historical_data: dict | None,
    ) -> List[DiagnosticTest]:
        """Run 4 scoring diagnostic tests."""
        tests = []
        
        # S1: Is weight accurate?
        tests.append(self._s1_weight_accuracy(descriptor))
        
        # S2: Validate score contribution
        tests.append(self._s2_score_contribution(descriptor))
        
        # S3: Validate thresholds
        tests.append(self._s3_validate_thresholds(descriptor))
        
        # S4: Is scoring stable?
        tests.append(self._s4_scoring_stability(descriptor, historical_data))
        
        return tests
    
    def _s1_weight_accuracy(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """S1: Check influence weight accuracy."""
        # Weight component should be reasonable
        weight_component = desc.influence_weight_component
        
        if weight_component < 0 or weight_component > 1:
            return DiagnosticTest(
                test_name="S1: Weight Accuracy",
                category="Scoring",
                result="FAIL",
                severity="CRITICAL",
                explanation=f"Weight component {weight_component} outside valid range [0, 1]",
                recommendation="Weight calculation error - check SIF-10 formula",
            )
        
        return DiagnosticTest(
            test_name="S1: Weight Accuracy",
            category="Scoring",
            result="PASS",
            severity="INFO",
            explanation="Weight calculation accurate",
        )
    
    def _s2_score_contribution(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """S2: Validate score contribution."""
        # Essential with low score = problem
        if desc.tier == Tier.E and desc.score < 85:
            return DiagnosticTest(
                test_name="S2: Score Contribution Validation",
                category="Scoring",
                result="WARNING",
                severity="MINOR",
                explanation=f"Essential tier with relatively low score {desc.score}",
                recommendation="Review if Essential classification is correct",
            )
        
        return DiagnosticTest(
            test_name="S2: Score Contribution Validation",
            category="Scoring",
            result="PASS",
            severity="INFO",
            explanation="Score contribution appropriate",
        )
    
    def _s3_validate_thresholds(self, desc: SemanticDescriptor) -> DiagnosticTest:
        """S3: Validate scoring thresholds."""
        # Check if score near critical thresholds
        critical_thresholds = [90, 70, 50, 30]
        
        for threshold in critical_thresholds:
            if abs(desc.score - threshold) < 2:
                return DiagnosticTest(
                    test_name="S3: Threshold Validation",
                    category="Scoring",
                    result="WARNING",
                    severity="MINOR",
                    explanation=f"Score {desc.score} very close to threshold {threshold}",
                    recommendation="Review if score should cross threshold",
                )
        
        return DiagnosticTest(
            test_name="S3: Threshold Validation",
            category="Scoring",
            result="PASS",
            severity="INFO",
            explanation="Score thresholds validated",
        )
    
    def _s4_scoring_stability(self, desc: SemanticDescriptor, historical: dict | None) -> DiagnosticTest:
        """S4: Check scoring stability over time."""
        # Placeholder - would compare against historical scores
        return DiagnosticTest(
            test_name="S4: Scoring Stability",
            category="Scoring",
            result="PASS",
            severity="INFO",
            explanation="No historical data for stability check",
        )
    
    def __repr__(self) -> str:
        return "AMD10(Automated Meaning Diagnostics, 22 tests)"
