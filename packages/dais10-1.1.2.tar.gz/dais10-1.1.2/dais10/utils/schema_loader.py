"""Schema loading and validation utilities"""
import yaml
from pathlib import Path
from typing import Dict, Any, Union

def load_schema(path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load executive schema from YAML file
    
    Args:
        path: Path to schema YAML file
        
    Returns:
        Schema dictionary
    """
    path = Path(path)
    
    if not path.exists():
        raise FileNotFoundError(f"Schema file not found: {path}")
    
    with open(path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Return columns section if exists, otherwise full config
    return config.get('columns', config)

def validate_schema(schema: Dict[str, Any]) -> bool:
    """
    Validate schema has required fields
    
    Args:
        schema: Schema dictionary
        
    Returns:
        True if valid
        
    Raises:
        ValueError if invalid
    """
    required_fields = ['importance', 'tier']
    
    for column, config in schema.items():
        for field in required_fields:
            if field not in config:
                raise ValueError(
                    f"Column '{column}' missing required field '{field}'"
                )
        
        # v1.1: Check for event_time_source
        if config['tier'] != 'MN' and 'event_time_source' not in config:
            raise ValueError(
                f"Column '{column}' missing 'event_time_source' (required in v1.1)"
            )
    
    return True
