#!/usr/bin/env python3
"""
DAIS-10 Command Line Interface
Main entry point for running DAIS-10 from command line

Author: Dr. Usman Zafar
Version: 1.1.1
"""

import sys
import argparse
import csv
from pathlib import Path


# ==========================================================
# SAFE IMPORTS
# ==========================================================

try:
    from dais10.version import __version__
    from dais10.core.types import Context, SemanticDescriptor, Tier
    from dais10.engines.sis import SIS10
    from dais10.engines.mcm import MCM10
    from dais10.engines.tier import TIER10
    from dais10.engines.sicm import SICM10
    from dais10.utils.schema_loader import load_schema
except ImportError as e:
    print(f"[FATAL] Import error: {e}")
    print("Ensure DAIS-10 is installed correctly: pip install -e .")
    sys.exit(1)


VALID_MODES = {"inference", "sovereign", "hybrid"}


# ==========================================================
# ANALYZE CSV
# ==========================================================

def analyze_csv(csv_file, domain="general", mode="inference", schema_file=None):

    if mode not in VALID_MODES:
        print(f"[ERROR] Invalid mode '{mode}'. Valid: {', '.join(VALID_MODES)}")
        return 1

    print(f"DAIS-10 v{__version__}")
    print("=" * 60)

    csv_path = Path(csv_file)
    if not csv_path.exists():
        print(f"[ERROR] CSV not found: {csv_file}")
        return 1

    try:
        with csv_path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
    except Exception as e:
        print(f"[ERROR] CSV read failure: {e}")
        return 1

    if not rows:
        print("[ERROR] CSV is empty.")
        return 1

    columns = list(rows[0].keys())
    print(f"Columns: {len(columns)} | Rows: {len(rows)}")
    print()

    executive_schema = None
    if mode in {"sovereign", "hybrid"}:
        if not schema_file:
            print("[ERROR] Schema required for sovereign/hybrid mode.")
            return 1
        if not Path(schema_file).exists():
            print(f"[ERROR] Schema not found: {schema_file}")
            return 1
        executive_schema = load_schema(schema_file)

    sis = SIS10()
    mcm = MCM10()
    tier_engine = TIER10()
    sicm = SICM10()

    context = Context(domain=domain, purpose=f"{domain}_analysis")
    descriptors = []

    print("=" * 60)
    print("COLUMN ANALYSIS")
    print("=" * 60)

    for col in columns:
        try:
            sample_values = [r[col] for r in rows[:100] if r.get(col)]

            in_schema = (
                executive_schema
                and col in executive_schema.get("columns", {})
            )

            if mode == "sovereign" and not in_schema:
                continue

            metadata, patterns = sis.interpret(col, sample_values)
            role = mcm.classify_role(col, metadata, patterns, context)

            if in_schema:
                entry = executive_schema["columns"][col]
                tier = Tier(entry.get("tier", "C"))
                score = float(entry.get("importance", 50.0))
                source = " [EXECUTIVE]"
            else:
                tier = tier_engine.assign_tier(role, context)
                score = sicm.calculate_score(tier, context)
                source = ""

            descriptor = SemanticDescriptor(
                attribute_name=col,
                role=role,
                tier=tier,
                score=score,
            )

            descriptors.append(descriptor)

            print(f"{col}{source}")
            print(
                f"  Role: {role.value:15} "
                f"Tier: {tier.value:3} "
                f"Score: {score:5.1f}/100"
            )
            print()

        except Exception as e:
            print(f"[ERROR] Column '{col}' failed: {e}")

    if not descriptors:
        print("[WARNING] No descriptors generated.")
        return 1

    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)

    tier_counts = {}
    for d in descriptors:
        tier_counts[d.tier.value] = tier_counts.get(d.tier.value, 0) + 1

    for tier, count in sorted(tier_counts.items()):
        print(f"{tier}: {count}")

    avg = sum(d.score for d in descriptors) / len(descriptors)
    print(f"\nAverage Score: {avg:.1f}/100")
    print()

    return 0


# ==========================================================
# SCHEMA TEMPLATE
# ==========================================================

def create_schema_template(output_file):

    template = """# DAIS-10 Executive Schema Template

metadata:
  organization: YOUR_ORGANIZATION
  version: 1.0

columns:
  example_id:
    importance: 95.0
    tier: E
    decay_rate: 0.001
    rationale: "Primary governance identifier"
"""

    try:
        Path(output_file).write_text(template, encoding="utf-8")
        print(f"Schema template created: {output_file}")
        return 0
    except Exception as e:
        print(f"[ERROR] Template creation failed: {e}")
        return 1


# ==========================================================
# VALIDATE
# ==========================================================

def validate_schema(csv_file, schema_file):

    try:
        schema = load_schema(schema_file)
    except Exception as e:
        print(f"[ERROR] Schema load failed: {e}")
        return 1

    try:
        with open(csv_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            first_row = next(reader)
            csv_cols = set(first_row.keys())
    except Exception as e:
        print(f"[ERROR] CSV load failed: {e}")
        return 1

    schema_cols = set(schema.get("columns", {}).keys())

    missing_in_csv = schema_cols - csv_cols
    missing_in_schema = csv_cols - schema_cols

    if not missing_in_csv and not missing_in_schema:
        print("✓ Perfect match")
        return 0

    if missing_in_csv:
        print("Missing in CSV:")
        for c in sorted(missing_in_csv):
            print(f"  - {c}")

    if missing_in_schema:
        print("Missing in Schema:")
        for c in sorted(missing_in_schema):
            print(f"  - {c}")

    return 1


# ==========================================================
# VERSION
# ==========================================================

def show_version():
    print(f"DAIS-10 v{__version__}")
    print("Executive-Controlled Semantic Data Governance")
    return 0


# ==========================================================
# MAIN
# ==========================================================

def main():

    parser = argparse.ArgumentParser(
        description="DAIS-10 Governance Engine"
    )

    subparsers = parser.add_subparsers(dest="command")

    analyze = subparsers.add_parser("analyze")
    analyze.add_argument("csv_file")
    analyze.add_argument("--domain", default="general")
    analyze.add_argument("--mode", default="inference")
    analyze.add_argument("--schema")

    schema = subparsers.add_parser("schema")
    schema_sub = schema.add_subparsers(dest="schema_command")
    create = schema_sub.add_parser("create")
    create.add_argument("output_file")

    validate = subparsers.add_parser("validate")
    validate.add_argument("csv_file")
    validate.add_argument("schema_file")

    subparsers.add_parser("version")

    args = parser.parse_args()

    if args.command == "analyze":
        return analyze_csv(
            args.csv_file,
            args.domain,
            args.mode,
            args.schema,
        )

    if args.command == "schema" and args.schema_command == "create":
        return create_schema_template(args.output_file)

    if args.command == "validate":
        return validate_schema(args.csv_file, args.schema_file)

    if args.command == "version":
        return show_version()

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())