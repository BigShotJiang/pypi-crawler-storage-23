"""
DAIS-10 Core Types

All type definitions for the DAIS-10 framework.

Author: Dr. Usman Zafar
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, List, Any, Literal
from datetime import datetime


# =============================================================================
# SEMANTIC ROLE TYPES
# =============================================================================

class SemanticRole(str, Enum):
    """Semantic roles: MD, ME, MX, MN"""
    MD = "MD"  # Meaning-Defining
    ME = "ME"  # Meaning-Enhancing
    MX = "MX"  # Meaning-Extending
    MN = "MN"  # Meaning-Neutral

    def __str__(self) -> str:
        return self.value


# =============================================================================
# TIER TYPES
# =============================================================================

class Tier(str, Enum):
    """Importance tiers: E, EC, C, CN, N"""
    E = "E"    # Essential
    EC = "EC"  # Semi-Essential
    C = "C"    # Contextual
    CN = "CN"  # Semi-Contextual
    N = "N"    # Enrichment

    def __str__(self) -> str:
        return self.value

    @property
    def score_range(self) -> tuple[float, float]:
        """Valid score range for tier."""
        ranges = {
            "E": (80.0, 100.0),
            "EC": (70.0, 85.0),
            "C": (40.0, 79.0),
            "CN": (30.0, 50.0),
            "N": (0.0, 39.0),
        }
        return ranges[self.value]

    @property
    def base_score(self) -> float:
        """Center score for tier."""
        bases = {"E": 90.0, "EC": 77.5, "C": 59.5, "CN": 40.0, "N": 19.5}
        return bases[self.value]

    @property
    def weight(self) -> float:
        """Tier weight for influence."""
        weights = {"E": 1.00, "EC": 0.85, "C": 0.60, "CN": 0.35, "N": 0.10}
        return weights[self.value]

    @property
    def decay_rate(self) -> float:
        """Temporal decay rate (λ)."""
        rates = {"E": 0.001, "EC": 0.005, "C": 0.010, "CN": 0.020, "N": 0.050}
        return rates[self.value]

    @property
    def description(self) -> str:
        """Human-readable description."""
        descs = {
            "E": "Essential: Required for existence",
            "EC": "Semi-Essential: Conditionally required",
            "C": "Contextual: Enhances interpretation",
            "CN": "Semi-Contextual: Optionally enhances",
            "N": "Enrichment: Analytical only",
        }
        return descs[self.value]


# =============================================================================
# GOVERNANCE TYPES
# =============================================================================

class GovernanceLevel(str, Enum):
    """Governance enforcement levels."""
    FAIL = "FAIL"
    WARN = "WARN"
    INFO = "INFO"

    def __str__(self) -> str:
        return self.value


class QualitativeCategory(str, Enum):
    """Qualitative interpretation categories."""
    CRITICAL = "Critical"
    HIGH = "High"
    MODERATE = "Moderate"
    LOW = "Low"
    MINIMAL = "Minimal"

    def __str__(self) -> str:
        return self.value


# =============================================================================
# CORE DATA STRUCTURES
# =============================================================================

@dataclass(frozen=True)
class Context:
    """Domain context for classification."""
    domain: str
    purpose: str
    regulatory: Optional[str] = None
    criticality: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SemanticDescriptor:
    """Complete semantic descriptor σ = (role, tier, score)."""
    attribute_name: str
    role: SemanticRole
    tier: Tier
    score: float
    rationale: Optional[str] = None
    confidence: float = 1.0

    @property
    def governance_level(self) -> GovernanceLevel:
        """Governance level from tier."""
        if self.tier in (Tier.E, Tier.EC):
            return GovernanceLevel.FAIL
        elif self.tier == Tier.C:
            return GovernanceLevel.WARN
        else:
            return GovernanceLevel.INFO

    @property
    def influence_weight_component(self) -> float:
        """Weight component before normalization."""
        role_weights = {
            SemanticRole.MD: 1.0,
            SemanticRole.ME: 0.7,
            SemanticRole.MX: 0.4,
            SemanticRole.MN: 0.1,
        }
        role_weight = role_weights[self.role]
        tier_weight = self.tier.weight
        score_factor = (self.score / 100.0) ** 2
        return role_weight * tier_weight * score_factor

    def apply_temporal_decay(self, days_elapsed: float) -> SemanticDescriptor:
        """Apply DIFS-10 temporal decay."""
        import math
        lambda_value = self.tier.decay_rate
        faded_score = self.score * math.exp(-lambda_value * days_elapsed)
        
        return SemanticDescriptor(
            attribute_name=self.attribute_name,
            role=self.role,
            tier=self.tier,
            score=faded_score,
            rationale=f"Faded from {self.score:.2f} after {days_elapsed} days",
            confidence=self.confidence,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "attribute_name": self.attribute_name,
            "role": self.role.value,
            "tier": self.tier.value,
            "score": self.score,
            "rationale": self.rationale,
            "confidence": self.confidence,
            "governance_level": self.governance_level.value,
        }


@dataclass(frozen=True)
class ValidationResult:
    """Result of validating a record."""
    record_id: Any
    completeness_score: float
    status: Literal["VALID", "MEANING_INVALID", "NEEDS_REVIEW"]
    missing_essential: List[str] = field(default_factory=list)
    missing_contextual: List[str] = field(default_factory=list)
    missing_enrichment: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class DiagnosticTest:
    """Single AMD-10 diagnostic test result."""
    test_name: str
    category: Literal["Meaning", "Tier", "Continuum", "Governance", "Scoring"]
    result: Literal["PASS", "WARNING", "FAIL"]
    severity: Literal["CRITICAL", "MAJOR", "MINOR", "INFO"]
    explanation: str
    recommendation: Optional[str] = None


@dataclass(frozen=True)
class DiagnosticReport:
    """Complete AMD-10 diagnostic report."""
    attribute_name: str
    classification: SemanticDescriptor
    tests_run: int
    passed: int
    warnings: int
    failed: int
    findings: List[DiagnosticTest] = field(default_factory=list)
    overall_status: Literal["VALID", "NEEDS_REVIEW", "INVALID"] = "VALID"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "attribute_name": self.attribute_name,
            "classification": self.classification.to_dict(),
            "tests_run": self.tests_run,
            "passed": self.passed,
            "warnings": self.warnings,
            "failed": self.failed,
            "overall_status": self.overall_status,
            "findings": [
                {
                    "test_name": f.test_name,
                    "category": f.category,
                    "result": f.result,
                    "severity": f.severity,
                    "explanation": f.explanation,
                    "recommendation": f.recommendation,
                }
                for f in self.findings
            ],
        }
