"""DAIS-10 Core Types"""
# These will be imported from your existing types.py file
