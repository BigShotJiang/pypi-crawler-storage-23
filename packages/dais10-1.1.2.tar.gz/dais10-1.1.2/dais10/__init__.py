"""DAIS-10 Core Package Initialization"""

__version__ = "1.1.1"

# Governance exports (fail-safe import)
try:
    from dais10.governance.policy_engine import PolicyEngine
    from dais10.governance.validation import validate_data
    from dais10.governance.risk_control import assess_risk
except ImportError:
    # Optional modules — package should still load
    PolicyEngine = None
    validate_data = None
    assess_risk = None