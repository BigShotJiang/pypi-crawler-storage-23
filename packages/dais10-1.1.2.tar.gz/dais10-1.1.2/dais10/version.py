"""
DAIS-10 Version Information
"""

__version__ = "1.1.2"
__author__ = "Dr. Usman Zafar"
__email__ = "usman19zafar@gmail.com"
__status__ = "Production"

VERSION_INFO = {
    'major': 1,
    'minor': 1,
    'patch': 0,
    'release': 'stable',
    'build': '20250215'
}

RELEASE_NOTES = """
DAIS-10 v1.1.0 - Stability Release

New Features:
- Column-anchored freshness (audit-safe temporal decay)
- Explainability vector (transparent scoring)
- Deterministic 20-row sample window (mandatory output)
- E-tier cap reasons (legal justifications)

Breaking Changes:
- None (100% backward compatible with v1.0)

Deprecated:
- Row-level timestamps (use column-specific event_time_source)

Requirements:
- Python 3.10+
- pandas >= 2.0.0
- pyyaml >= 6.0
"""

def get_version():
    """Get version string"""
    return __version__

def get_version_info():
    """Get detailed version information"""
    return VERSION_INFO

def print_version():
    """Print version information"""
    print(f"DAIS-10 v{__version__}")
    print(f"Author: {__author__}")
    print(f"Status: {__status__}")
    print(f"\n{RELEASE_NOTES}")

if __name__ == "__main__":
    print_version()
