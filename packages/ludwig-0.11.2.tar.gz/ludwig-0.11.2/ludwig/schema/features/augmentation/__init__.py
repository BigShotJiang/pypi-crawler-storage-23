# Register all augmentation schemas
import ludwig.schema.features.augmentation.image  # noqa: F401
