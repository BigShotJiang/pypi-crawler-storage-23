# Register all decoders
import ludwig.schema.decoders.base
import ludwig.schema.decoders.image_decoders  # noqa
import ludwig.schema.decoders.llm_decoders  # noqa
import ludwig.schema.decoders.sequence_decoders  # noqa
