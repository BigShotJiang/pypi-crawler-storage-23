# Changelog

## 1.0.0 (2026-03-01)

- Initial release
- 4 CrewAI tools: proxy fetch, wallet balance, top-up (Stripe), top-up (PayPal)
- SSRF protection, credential scrubbing, OFAC compliance
