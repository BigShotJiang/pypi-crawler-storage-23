"""antaris CLI entry point."""
import sys
from antaris_suite import __version__


def main():
    print(f"antaris-suite v{__version__}")
    print("Components: memory | guard | context | router | pipeline | contracts")
    print("")
    print("Commands:")
    print("  python -m antaris_memory init          Initialize memory store")
    print("  python -m antaris_memory status        Show memory stats")
    print("  python -m antaris_memory serve         Start MCP server")
    print("  python -m antaris_memory rebuild-graph Rebuild graph index")
    print("")
    print("Docs: https://docs.antarisanalytics.ai")


if __name__ == "__main__":
    main()
