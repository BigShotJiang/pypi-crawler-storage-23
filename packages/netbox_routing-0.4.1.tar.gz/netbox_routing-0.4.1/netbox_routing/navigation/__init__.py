from netbox.plugins import PluginMenu

from .bfd import BFD_MENU
from .objects import OBJECT_MENU
from .ospf import MENUITEMS as OSPF_MENU
from .eigrp import eigrp
from .static import MENUITEMS as STATIC_MENU
from .bgp import BGP_MENU
from .community import COMMUNITY_MENU

__all__ = ('menu',)

menu = PluginMenu(
    label='Netbox Routing',
    groups=(
        ('Routing Objects', COMMUNITY_MENU + OBJECT_MENU),
        ('BFD', BFD_MENU),
        ('Static', STATIC_MENU),
        ('BGP', BGP_MENU),
        ('OSPF', OSPF_MENU),
        ('EIGRP', eigrp),
    ),
    icon_class='mdi mdi-router',
)
