from django.test import TestCase

from netbox_routing.models import *

__all__ = (
    'OSPFInstanceTestCase',
    'OSPFAreaTestCase',
    'OSPFInterfaceTestCase',
)


class OSPFInstanceTestCase(TestCase):
    pass


class OSPFAreaTestCase(TestCase):
    pass


class OSPFInterfaceTestCase(TestCase):
    pass
