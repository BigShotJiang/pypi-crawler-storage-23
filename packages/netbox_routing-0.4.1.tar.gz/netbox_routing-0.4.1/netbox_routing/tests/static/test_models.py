from django.test import TestCase

__all__ = ('StaticRouteTestCase',)


class StaticRouteTestCase(TestCase):
    pass
