# Copyright (c) 2026 Veritas Aequitas Holdings LLC. All rights reserved.
"""Allow running malwar as a module: python -m malwar."""

from malwar.cli.app import app

app()
