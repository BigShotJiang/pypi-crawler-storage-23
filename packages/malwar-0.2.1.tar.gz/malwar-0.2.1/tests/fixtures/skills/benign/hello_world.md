---
name: Hello World
description: A minimal greeting skill that demonstrates basic SKILL.md structure.
author: Jane Smith
version: "1.0.0"
tags:
  - demo
  - beginner
---

# Hello World Skill

This skill provides a simple greeting tool for new users.

## Usage

Say hello to the user by name:

```bash
echo "Hello, $USER! Welcome to the skill system."
```

## Notes

- This is a minimal example skill.
- It does not require any external dependencies.
