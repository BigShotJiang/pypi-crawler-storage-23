---
name: zapper
description: Placeholder for Zapper skill.
---
