"""
Core Bukkit wrapper classes for convenient Minecraft server interaction.

This module provides high-level interfaces to Bukkit APIs, making it easier
to write Paper server plugins in Python.
"""

from typing import Callable, Optional, List, Any, Dict
from java.util import UUID, HashMap
from org.bukkit import Bukkit, Material, event, plugin
from org.bukkit.entity import Player
from org.bukkit.command import CommandSender, Command
from org.yaml.snakeyaml import Yaml


class BukkitServer:
    """Static utility class for accessing Bukkit server functionality."""

    @staticmethod
    def get_server():
        """Get the Bukkit server instance.
        
        Returns:
            The Bukkit Server instance.
        """
        return Bukkit.getServer()

    @staticmethod
    def get_plugin_manager():
        """Get the plugin manager.
        
        Returns:
            The Bukkit PluginManager instance.
        """
        return Bukkit.getPluginManager()

    @staticmethod
    def get_world(name: str):
        """Get a world by name.
        
        Args:
            name: The world name.
            
        Returns:
            The World instance or None if not found.
        """
        return Bukkit.getWorld(name)

    @staticmethod
    def get_player(name: str) -> Optional[Player]:
        """Get a player by name.
        
        Args:
            name: The player name.
            
        Returns:
            The Player instance or None if not found.
        """
        return Bukkit.getPlayer(name)

    @staticmethod
    def get_all_players() -> List[Player]:
        """Get all online players.
        
        Returns:
            List of online Player instances.
        """
        return list(Bukkit.getOnlinePlayers())

    @staticmethod
    def broadcast(message: str, permission: Optional[str] = None) -> int:
        """Broadcast a message to all players.
        
        Args:
            message: The message to broadcast.
            permission: Optional permission required to receive the message.
            
        Returns:
            Number of players who received the message.
        """
        if permission:
            return Bukkit.broadcast(message, permission)
        else:
            Bukkit.broadcastMessage(message)
            return len(Bukkit.getOnlinePlayers())

    @staticmethod
    def schedule_sync_task(plugin, task: Callable, delay: int = 0):
        """Schedule a synchronous task.
        
        Args:
            plugin: The plugin instance.
            task: Callable to execute.
            delay: Ticks to wait before execution (0 = next tick).
            
        Returns:
            Task ID.
        """
        return plugin.getServer().getScheduler().scheduleSyncDelayedTask(
            plugin, task, delay
        )

    @staticmethod
    def schedule_async_task(plugin, task: Callable, delay: int = 0):
        """Schedule an asynchronous task.
        
        Args:
            plugin: The plugin instance.
            task: Callable to execute asynchronously.
            delay: Ticks to wait before execution (0 = next tick).
            
        Returns:
            Task ID.
        """
        return plugin.getServer().getScheduler().scheduleAsyncDelayedTask(
            plugin, task, delay
        )

    @staticmethod
    def schedule_repeating_task(plugin, task: Callable, delay: int, period: int):
        """Schedule a repeating task.
        
        Args:
            plugin: The plugin instance.
            task: Callable to execute repeatedly.
            delay: Ticks to wait before first execution.
            period: Ticks between executions.
            
        Returns:
            Task ID.
        """
        return plugin.getServer().getScheduler().scheduleSyncRepeatingTask(
            plugin, task, delay, period
        )


class Logger:
    """Wrapper around Java Logger for server logging.
    
    Message format:
        [PluginName] Message
    """

    def __init__(self, plugin_logger):
        """Initialize logger with a Java logger instance."""
        self._logger = plugin_logger

    @staticmethod
    def create(plugin):
        """Create a logger for a plugin.
        
        Args:
            plugin: The plugin instance.
            
        Returns:
            Logger instance.
        """
        return Logger(plugin.getLogger())

    def info(self, message: str):
        """Log an info message."""
        self._logger.info(message)

    def warning(self, message: str):
        """Log a warning message."""
        self._logger.warning(message)

    def error(self, message: str):
        """Log an error message."""
        self._logger.severe(message)

    def debug(self, message: str):
        """Log a debug message."""
        self._logger.fine(message)

    def trace(self, message: str):
        """Log a trace message."""
        self._logger.finest(message)


class EventListener:
    """Helper class for registering event listeners."""

    @staticmethod
    def register(plugin, event_class: type, priority: str = "NORMAL"):
        """Register an event listener.
        
        Args:
            plugin: The plugin instance.
            event_class: The event class to listen for.
            priority: Event priority (LOWEST, LOW, NORMAL, HIGH, HIGHEST).
            
        Returns:
            Decorator function.
        """
        def decorator(handler: Callable):
            # Implementation depends on GraalVM polyglot capabilities
            # Simple version stores handler reference
            if not hasattr(plugin, '_event_handlers'):
                plugin._event_handlers = {}
            
            event_name = event_class.__name__
            if event_name not in plugin._event_handlers:
                plugin._event_handlers[event_name] = []
            
            plugin._event_handlers[event_name].append({
                'handler': handler,
                'priority': priority
            })
            return handler
        
        return decorator

    @staticmethod
    def call(plugin, event_name: str, *args, **kwargs):
        """Manually call event handlers."""
        if hasattr(plugin, '_event_handlers'):
            handlers = plugin._event_handlers.get(event_name, [])
            for handler_info in handlers:
                try:
                    handler_info['handler'](*args, **kwargs)
                except Exception as e:
                    Logger.create(plugin).error(f"Error in event handler: {e}")


class PythonPluginCommand:
    """Helper class for command registration."""

    @staticmethod
    def register(plugin, name: str, description: str = "", usage: str = ""):
        """Register a command for a plugin.
        
        Args:
            plugin: The plugin instance.
            name: The command name.
            description: Command description.
            usage: Command usage string.
            
        Returns:
            Decorator function.
        """
        def decorator(handler: Callable):
            if not hasattr(plugin, '_commands'):
                plugin._commands = {}
            
            plugin._commands[name.lower()] = {
                'handler': handler,
                'description': description,
                'usage': usage
            }
            return handler
        
        return decorator

    @staticmethod
    def execute(plugin, cmd_name: str, sender: CommandSender, args: List[str]) -> bool:
        """Execute a registered command."""
        if hasattr(plugin, '_commands'):
            cmd_info = plugin._commands.get(cmd_name.lower())
            if cmd_info:
                try:
                    return cmd_info['handler'](sender, args)
                except Exception as e:
                    sender.sendMessage(f"§cCommand error: {e}")
                    return False
        return False


class Config:
    """YAML configuration file manager."""

    def __init__(self, config_file: str):
        """Initialize config manager.
        
        Args:
            config_file: Path to YAML configuration file.
        """
        self.config_file = config_file
        self.data: Dict[str, Any] = {}
        self._yaml = Yaml()

    def load(self):
        """Load configuration from file."""
        try:
            with open(self.config_file, 'r') as f:
                self.data = self._yaml.load(f) or {}
        except FileNotFoundError:
            self.data = {}

    def save(self):
        """Save configuration to file."""
        with open(self.config_file, 'w') as f:
            self._yaml.dump(self.data, f)

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value.
        
        Args:
            key: Configuration key (supports dot notation for nested keys).
            default: Default value if key not found.
            
        Returns:
            Configuration value or default.
        """
        keys = key.split('.')
        value = self.data
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value if value is not None else default

    def set(self, key: str, value: Any):
        """Set configuration value.
        
        Args:
            key: Configuration key (supports dot notation).
            value: Value to set.
        """
        keys = key.split('.')
        current = self.data
        
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        current[keys[-1]] = value

    def has(self, key: str) -> bool:
        """Check if configuration key exists."""
        return self.get(key) is not None
