"""
papermc_bukkit - Convenient Python wrapper for Bukkit API

This library provides a convenient Python interface for developing plugins
for Paper Minecraft servers using Python 3.12 via GraalVM.
"""

from .bukkit import (
    BukkitServer,
    Logger,
    EventListener,
    PythonPluginCommand,
    Config,
)

__version__ = "1.0.0"
__author__ = "Paper Community"
__all__ = [
    "BukkitServer",
    "Logger",
    "EventListener",
    "PythonPluginCommand",
    "Config",
]
