#	digtick - Digital systems toolkit: simplify, minimize and transform Boolean expressions, draw KV-maps, etc.
#	Copyright (C) 2022-2026 Johannes Bauer
#
#	This file is part of digtick.
#
#	digtick is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; this program is ONLY licensed under
#	version 3 of the License, later versions are explicitly excluded.
#
#	digtick is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with digtick; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#	Johannes Bauer <JohannesBauer@gmx.de>

from .MultiCommand import BaseAction
from .ValueTable import ValueTable
from .Tools import open_file
from .KVDiagram import KVDiagram

class ActionKVDiagram(BaseAction):
	def run(self):
		with open_file(self._args.filename) as f:
			vt = ValueTable.parse_from_file(f, set_undefined_values_to = self._args.unused_value_is)
		if self._args.literal_order is None:
			variable_order = None
		else:
			if "," in self._args.literal_order:
				variable_order = ",".split(self._args.literal_order)
			else:
				variable_order = list(self._args.literal_order)

			if len(set(variable_order)) != len(variable_order):
				raise ValueError("Literal order has duplicate literal")
			if set(variable_order) != set(vt.input_variable_names):
				raise ValueError(f"The specified literal order variables ({', '.join(variable_order)}) does not match the variables present in the input file ({', '.join(vt.input_variable_names)}).")

		kvd = KVDiagram(value_table = vt, output_variable_name = self._args.output_variable_name, variable_order = variable_order, x_offset = self._args.x_offset, y_offset = self._args.y_offset, x_invert = self._args.x_invert, y_invert = self._args.y_invert, row_heavy = self._args.row_heavy, render_indices = self._args.render_indices)
		if self._args.output_filename is None:
			kvd.print_text()
		else:
			svg = kvd.render_svg()
			svg.writefile(self._args.output_filename)
