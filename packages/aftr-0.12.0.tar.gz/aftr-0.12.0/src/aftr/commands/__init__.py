"""aftr commands."""
