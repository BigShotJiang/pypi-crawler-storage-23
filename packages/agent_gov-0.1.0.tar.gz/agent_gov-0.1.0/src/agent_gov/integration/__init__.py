"""Integration bridges for external agent frameworks."""
from __future__ import annotations

from agent_gov.integration.agentcore_bridge import AgentCoreBridge

__all__ = ["AgentCoreBridge"]
