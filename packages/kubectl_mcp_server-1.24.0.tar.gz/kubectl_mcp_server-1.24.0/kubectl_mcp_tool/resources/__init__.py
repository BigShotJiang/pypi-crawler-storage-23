from .resources import register_resources

__all__ = [
    "register_resources",
]
