"""
Tests for consumer method aliases - SDK parity with TypeScript/Go.
"""

from unittest.mock import MagicMock, patch


class TestConsumerMethodAliases:
    """Tests that alias methods correctly delegate to their canonical implementations."""

    def test_list_my_subscription_requests_is_alias_for_list_subscription_requests(self):
        """
        Verify list_my_subscription_requests() delegates to list_subscription_requests().
        This alias exists for SDK naming consistency with TypeScript/Go SDKs.
        """
        # Import inside test to avoid AWS credential validation at import time
        from helix_connect.consumer import HelixConsumer

        # Create a mock consumer without triggering credential validation
        with patch.object(HelixConsumer, "_validate_credentials"):
            with patch("boto3.Session"):
                consumer = HelixConsumer(
                    aws_access_key_id="test-key",
                    aws_secret_access_key="test-secret",
                    customer_id="test-customer",
                )

        # Mock the canonical method
        mock_response = {"requests": [{"id": "req-123", "status": "pending"}], "count": 1}
        consumer.list_subscription_requests = MagicMock(return_value=mock_response)

        # Call the alias without arguments
        result = consumer.list_my_subscription_requests()

        # Verify it delegates to the canonical method
        consumer.list_subscription_requests.assert_called_once_with()
        assert result == mock_response

    def test_list_my_subscription_requests_passes_status_argument(self):
        """Verify the alias correctly passes the status argument."""
        from helix_connect.consumer import HelixConsumer

        with patch.object(HelixConsumer, "_validate_credentials"):
            with patch("boto3.Session"):
                consumer = HelixConsumer(
                    aws_access_key_id="test-key",
                    aws_secret_access_key="test-secret",
                    customer_id="test-customer",
                )

        mock_response = {"requests": [], "count": 0}
        consumer.list_subscription_requests = MagicMock(return_value=mock_response)

        # Call with status argument
        result = consumer.list_my_subscription_requests(status="approved")

        # Verify status is passed through
        consumer.list_subscription_requests.assert_called_once_with(status="approved")
        assert result == mock_response

    def test_list_my_subscription_requests_passes_kwargs(self):
        """Verify the alias correctly passes arbitrary kwargs."""
        from helix_connect.consumer import HelixConsumer

        with patch.object(HelixConsumer, "_validate_credentials"):
            with patch("boto3.Session"):
                consumer = HelixConsumer(
                    aws_access_key_id="test-key",
                    aws_secret_access_key="test-secret",
                    customer_id="test-customer",
                )

        mock_response = {"requests": [], "count": 0}
        consumer.list_subscription_requests = MagicMock(return_value=mock_response)

        # Call with multiple kwargs
        result = consumer.list_my_subscription_requests(status="pending")

        # Verify kwargs are passed through
        consumer.list_subscription_requests.assert_called_once_with(status="pending")
        assert result == mock_response
