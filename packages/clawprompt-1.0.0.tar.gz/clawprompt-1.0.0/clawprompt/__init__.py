"""ClawPrompt - Smart teleprompter with mobile remote control."""
__version__ = "1.0.0"
