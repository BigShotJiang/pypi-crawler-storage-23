# ClawPrompt 🦞📝

Smart teleprompter with mobile remote control for video recording.

## Features

- 🖥️ **Fullscreen teleprompter** — black background, white text, top-center aligned
- 📱 **Mobile remote control** — scan QR code, phone becomes a page-turner
- 🔄 **Dual-screen sync** — computer and phone show the same text in real-time
- 📝 **Upload from either device** — paste text on computer or phone
- 🎬 **ClawCut integration** — import AI-generated 9-scene scripts directly
- ⏱️ **Countdown start** — 3-second countdown before prompting begins
- 🔤 **Adjustable font size** — +/- keys to resize on the fly

## Quick Start

```bash
npm install
node server.js
```

Open `http://localhost:7870` on your computer.  
Scan the QR code with your phone (same WiFi).

## Usage

1. **Computer**: Paste your script → click "开始提词" → fullscreen mode
2. **Phone**: Scan QR → tap "下一句" to advance, "上一句" to go back
3. **Recording**: Speaker looks at camera, reads text with peripheral vision. Another person controls the phone.

### Keyboard Shortcuts (Computer)

| Key | Action |
|-----|--------|
| Space / ↓ | Next sentence |
| ↑ | Previous sentence |
| + / - | Increase / decrease font size |
| ESC | Exit fullscreen |

## Use Case

Perfect for video recording where the speaker needs to focus on camera eye contact, gestures, and expression — while a director/assistant controls the script pacing from their phone.

## Configuration

| Env Var | Default | Description |
|---------|---------|-------------|
| `PORT` | `7870` | Server port |

## Requirements

- Node.js 18+
- `ws` npm package (auto-installed)
- `qrcode` npm package (auto-installed)
- Computer and phone on the same WiFi

## License

MIT
