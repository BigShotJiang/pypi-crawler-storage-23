# IndieStack MCP Server

Search 356+ vetted indie SaaS tools from your AI coding assistant. Before your AI writes code, it checks what's already built.

<!-- mcp-name: io.github.Pattyboi101/indiestack -->

## Quick Start

```bash
pip install indiestack
claude mcp add indiestack -- python -m indiestack.mcp_server
```

That's it. Your AI will now search IndieStack before building common functionality from scratch.

## Works with

- **Claude Code** — `claude mcp add indiestack -- python -m indiestack.mcp_server`
- **Cursor** — Add to your MCP config
- **Windsurf** — Add to your MCP config

## What it does

When you ask your AI to "build invoicing" or "add analytics", it checks IndieStack first and suggests existing indie tools instead of writing thousands of lines of code.

### Tools

- `search_indie_tools(query, category?)` — Search for tools by problem, optionally filtered by category
- `get_tool_details(slug)` — Get full details including integration snippets
- `list_categories()` — Browse all 21 categories with tool counts
- `compare_tools(slug_a, slug_b)` — Side-by-side comparison table
- `submit_tool(...)` — Submit a new tool to the marketplace

### Resources

- `indiestack://categories` — All categories with slugs (auto-loaded into context)
- `indiestack://trending` — Top 10 trending tools this week

### Prompts

- `before-you-build` — Check IndieStack before building common functionality
- `find-alternatives` — Find indie alternatives to mainstream SaaS products

## Links

- [IndieStack](https://indiestack.fly.dev)
- [Browse Tools](https://indiestack.fly.dev/explore)
- [Submit Your Tool](https://indiestack.fly.dev/submit)
