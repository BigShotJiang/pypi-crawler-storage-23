"""Admin business intelligence dashboard — analytics, funnels, search, growth."""

from datetime import datetime, timedelta
from html import escape

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from indiestack.routes.components import page_shell
from indiestack.db import (
    get_revenue_timeseries,
    get_pro_subscriber_stats,
    get_platform_funnel,
    get_top_tools_by_metric,
    get_maker_leaderboard,
    get_search_gaps,
    get_search_trends,
    get_subscriber_growth,
    get_subscriber_count,
    get_purchase_stats,
)
from indiestack.auth import check_admin_session

router = APIRouter()


# ── Helpers ──────────────────────────────────────────────────────────────

def _nav_bar() -> str:
    """Top navigation bar linking to admin sections."""
    return """
    <div style="display:flex;gap:8px;margin-bottom:24px;">
        <a href="/admin" class="btn" style="background:var(--cream-dark);color:var(--ink-light);border:1px solid var(--border);padding:8px 20px;font-size:13px;font-weight:600;text-decoration:none;">Dashboard</a>
        <a href="/admin/analytics" class="btn" style="background:var(--terracotta);color:white;padding:8px 20px;font-size:13px;font-weight:600;text-decoration:none;">Analytics</a>
        <a href="/admin/outreach" class="btn" style="background:var(--cream-dark);color:var(--ink-light);border:1px solid var(--border);padding:8px 20px;font-size:13px;font-weight:600;text-decoration:none;">Outreach</a>
    </div>
    """


def _sub_tabs(current: str) -> str:
    """Sub-tab pill navigation."""
    tabs = [('overview', 'Overview'), ('funnels', 'Funnels'), ('search', 'Search'), ('growth', 'Growth')]
    html = '<div style="display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;">'
    for slug, label in tabs:
        active = 'background:var(--terracotta);color:white;' if slug == current else 'background:var(--cream-dark);color:var(--ink-light);border:1px solid var(--border);'
        html += f'<a href="/admin/analytics?tab={slug}" class="btn" style="{active}padding:6px 16px;font-size:13px;border-radius:999px;text-decoration:none;font-weight:600;">{label}</a>'
    html += '</div>'
    return html


def _bar_chart(data: list, title: str, value_prefix: str = "", value_suffix: str = "") -> str:
    """Reusable bar chart. data = [(label, value), ...]."""
    if not data:
        return f"""
        <div class="card" style="padding:24px;margin-bottom:32px;">
            <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">{title}</h2>
            <p style="color:var(--ink-muted);font-size:14px;">No data yet</p>
        </div>
        """
    max_val = max((d[1] for d in data), default=1) or 1
    bars = ""
    for label, count in data:
        pct = (count / max_val) * 100
        display_val = f"{value_prefix}{count}{value_suffix}" if isinstance(count, int) else f"{value_prefix}{count:.2f}{value_suffix}"
        bars += f"""
        <div style="display:flex;flex-direction:column;align-items:center;flex:1;min-width:0;">
            <span style="font-size:11px;color:var(--ink);font-weight:600;margin-bottom:4px;">{display_val}</span>
            <div style="width:100%;max-width:40px;height:120px;display:flex;align-items:flex-end;">
                <div style="width:100%;height:{max(pct, 2):.0f}%;background:var(--terracotta);border-radius:4px 4px 0 0;min-height:2px;"></div>
            </div>
            <span style="font-size:10px;color:var(--ink-muted);margin-top:4px;white-space:nowrap;">{label}</span>
        </div>
        """
    return f"""
    <div class="card" style="padding:24px;margin-bottom:32px;">
        <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">{title}</h2>
        <div style="display:flex;gap:4px;align-items:flex-end;">
            {bars}
        </div>
    </div>
    """


def _table(title: str, headers: list, rows_html: str, empty_msg: str = "No data yet") -> str:
    """Reusable table card."""
    head_cells = ""
    for h in headers:
        head_cells += f'<th style="padding:8px 12px;text-align:left;font-size:13px;color:var(--ink-muted);font-weight:600;">{h}</th>'
    content = rows_html if rows_html else f'<tr><td colspan="{len(headers)}" style="padding:12px;color:var(--ink-muted);font-size:14px;">{empty_msg}</td></tr>'
    return f"""
    <div class="card" style="padding:24px;margin-bottom:32px;">
        <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">{title}</h2>
        <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr style="border-bottom:2px solid var(--border);">
                        {head_cells}
                    </tr>
                </thead>
                <tbody>{content}</tbody>
            </table>
        </div>
    </div>
    """


def _kpi_card(label: str, value: str, sublabel: str = "") -> str:
    sub = f'<div style="color:var(--ink-muted);font-size:12px;margin-top:2px;">{sublabel}</div>' if sublabel else ''
    return f"""
    <div class="card" style="text-align:center;padding:16px;">
        <div style="color:var(--ink-muted);font-size:14px;">{label}</div>
        <div style="font-family:var(--font-display);font-size:28px;margin-top:4px;color:var(--terracotta);">{value}</div>
        {sub}
    </div>
    """


# ── Tab renderers ────────────────────────────────────────────────────────

async def _tab_overview(db, request) -> str:
    """Overview tab — KPIs, traffic, pages, referrers, recent visitors."""
    period = request.query_params.get("period", "7")
    now = datetime.utcnow()

    if period == "today":
        since = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        period_label = "Today"
    elif period == "30":
        since = (now - timedelta(days=30)).isoformat()
        period_label = "Last 30 days"
    elif period == "all":
        since = "2000-01-01T00:00:00"
        period_label = "All time"
    else:
        period = "7"
        since = (now - timedelta(days=7)).isoformat()
        period_label = "Last 7 days"

    # ── KPI queries ──
    cursor = await db.execute(
        "SELECT COUNT(*) as total FROM page_views WHERE timestamp >= ?", (since,)
    )
    total_views = (await cursor.fetchone())['total']

    cursor = await db.execute(
        "SELECT COUNT(DISTINCT visitor_id) as uniques FROM page_views WHERE timestamp >= ?", (since,)
    )
    unique_visitors = (await cursor.fetchone())['uniques']

    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM outbound_clicks WHERE created_at >= ?", (since,)
    )
    outbound_clicks = (await cursor.fetchone())['cnt']

    purchase_stats = await get_purchase_stats(db)
    total_revenue_pence = purchase_stats.get('total_revenue', 0) or 0

    pro_stats = await get_pro_subscriber_stats(db)
    pro_count = pro_stats.get('active_count', 0) or 0
    mrr_pence = pro_stats.get('mrr_pence', 0) or 0

    # Period filter pills
    pills = ""
    for val, label in [("today", "Today"), ("7", "Last 7 days"), ("30", "Last 30 days"), ("all", "All time")]:
        active_style = "background:var(--terracotta);color:white;" if val == period else "background:var(--cream-dark);color:var(--ink-light);border:1px solid var(--border);"
        pills += f'<a href="/admin/analytics?tab=overview&period={val}" class="btn" style="{active_style}padding:6px 16px;font-size:13px;border-radius:999px;text-decoration:none;font-weight:600;">{label}</a>'

    # ── 14-day traffic bar chart ──
    chart_days = 14
    daily_data = []
    for i in range(chart_days - 1, -1, -1):
        day = now - timedelta(days=i)
        day_start = day.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        day_end = (day.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)).isoformat()
        cursor = await db.execute(
            "SELECT COUNT(*) as cnt FROM page_views WHERE timestamp >= ? AND timestamp < ?",
            (day_start, day_end)
        )
        cnt = (await cursor.fetchone())['cnt']
        daily_data.append((day.strftime("%b %d"), cnt))

    traffic_chart = _bar_chart(daily_data, "Daily Traffic (Last 14 Days)")

    # ── Revenue time series ──
    rev_data = await get_revenue_timeseries(db, days=30)
    rev_chart = ""
    if rev_data:
        rev_points = [(r['date'], r['revenue_pence'] / 100) for r in rev_data]
        rev_chart = _bar_chart(rev_points, "Daily Revenue (Last 30 Days)", value_prefix="\u00a3")

    # ── Top pages ──
    cursor = await db.execute(
        """SELECT page, COUNT(*) as views FROM page_views
           WHERE timestamp >= ? GROUP BY page ORDER BY views DESC LIMIT 10""",
        (since,)
    )
    top_pages = await cursor.fetchall()
    max_page_views = top_pages[0]['views'] if top_pages else 1

    top_pages_rows = ""
    for p in top_pages:
        pg = escape(str(p['page']))
        v = p['views']
        bar_pct = (v / max_page_views) * 100
        top_pages_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                <a href="{pg}" style="color:var(--ink);text-decoration:none;">{pg}</a>
            </td>
            <td style="padding:10px 12px;width:50%;min-width:120px;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <div style="flex:1;height:18px;background:var(--cream-dark);border-radius:4px;overflow:hidden;">
                        <div style="height:100%;width:{bar_pct:.0f}%;background:var(--terracotta);border-radius:4px;"></div>
                    </div>
                    <span style="font-size:13px;font-weight:600;color:var(--ink);min-width:40px;text-align:right;">{v}</span>
                </div>
            </td>
        </tr>
        """

    top_pages_table = _table("Top Pages", ["Page", "Views"], top_pages_rows)

    # ── Top referrers ──
    cursor = await db.execute(
        """SELECT referrer, COUNT(*) as views FROM page_views
           WHERE timestamp >= ? AND referrer != '' AND referrer NOT LIKE '%indiestack%'
           GROUP BY referrer ORDER BY views DESC LIMIT 10""",
        (since,)
    )
    top_referrers = await cursor.fetchall()

    referrer_rows = ""
    if top_referrers:
        max_ref_views = top_referrers[0]['views']
        for r in top_referrers:
            ref = escape(str(r['referrer']))
            ref_display = ref if len(ref) <= 60 else ref[:57] + "..."
            rv = r['views']
            bar_pct = (rv / max_ref_views) * 100
            referrer_rows += f"""
            <tr style="border-bottom:1px solid var(--border);">
                <td style="padding:10px 12px;font-size:14px;color:var(--ink);max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                    title="{ref}">
                    <a href="{ref}" target="_blank" rel="noopener" style="color:var(--ink);text-decoration:none;">{ref_display}</a>
                </td>
                <td style="padding:10px 12px;width:40%;min-width:100px;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <div style="flex:1;height:18px;background:var(--cream-dark);border-radius:4px;overflow:hidden;">
                            <div style="height:100%;width:{bar_pct:.0f}%;background:var(--terracotta);border-radius:4px;"></div>
                        </div>
                        <span style="font-size:13px;font-weight:600;color:var(--ink);min-width:40px;text-align:right;">{rv}</span>
                    </div>
                </td>
            </tr>
            """

    referrers_table = _table("Top Referrers", ["Source", "Views"], referrer_rows, empty_msg="No external referrers yet.")

    # ── Recent visitors ──
    cursor = await db.execute(
        "SELECT timestamp, page, referrer FROM page_views ORDER BY timestamp DESC LIMIT 20"
    )
    recent = await cursor.fetchall()

    recent_rows = ""
    for rv in recent:
        ts_raw = str(rv['timestamp'])
        try:
            ts_dt = datetime.fromisoformat(ts_raw)
            ts_display = ts_dt.strftime("%b %d, %H:%M")
        except Exception:
            ts_display = ts_raw[:16]
        pg = escape(str(rv['page']))
        ref = escape(str(rv.get('referrer', '') or ''))
        ref_short = ref if len(ref) <= 40 else ref[:37] + "..."
        source = f'<a href="{ref}" target="_blank" rel="noopener" style="color:var(--ink-muted);text-decoration:none;" title="{ref}">{ref_short}</a>' if ref else '<span style="color:var(--ink-muted);">direct</span>'
        recent_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:8px 12px;font-size:13px;color:var(--ink-muted);white-space:nowrap;">{ts_display}</td>
            <td style="padding:8px 12px;font-size:13px;color:var(--ink);">{pg}</td>
            <td style="padding:8px 12px;font-size:13px;">{source}</td>
        </tr>
        """

    recent_table = _table("Recent Visitors", ["Time", "Page", "Source"], recent_rows)

    return f"""
        <!-- Period filter -->
        <div style="display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;">
            {pills}
        </div>

        <!-- KPI cards -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:32px;">
            {_kpi_card("Page Views", f"{total_views:,}", period_label)}
            {_kpi_card("Unique Visitors", f"{unique_visitors:,}", period_label)}
            {_kpi_card("Outbound Clicks", f"{outbound_clicks:,}", period_label)}
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:32px;">
            {_kpi_card("Total Revenue", f"&pound;{total_revenue_pence / 100:.2f}")}
            {_kpi_card("Pro Subscribers", f"{pro_count:,}")}
            {_kpi_card("MRR", f"&pound;{mrr_pence / 100:.2f}")}
        </div>

        {traffic_chart}
        {rev_chart}
        {top_pages_table}
        {referrers_table}
        {recent_table}
    """


async def _tab_funnels(db) -> str:
    """Funnels tab — platform funnel, per-tool funnel, maker leaderboard."""
    funnel_data = await get_platform_funnel(db, days=30)

    # Aggregate totals
    total_views = sum(t.get('views', 0) or 0 for t in funnel_data)
    total_clicks = sum(t.get('clicks', 0) or 0 for t in funnel_data)
    total_wishlists = sum(t.get('wishlists', 0) or 0 for t in funnel_data)
    total_purchases = sum(t.get('purchases', 0) or 0 for t in funnel_data)

    # Funnel summary bar
    stages = [
        ("Views", total_views, "#1A2D4A"),
        ("Clicks", total_clicks, "#00D4F5"),
        ("Wishlists", total_wishlists, "#16a34a"),
        ("Purchases", total_purchases, "#EA580C"),
    ]
    funnel_bar = ""
    if total_views > 0:
        segments = ""
        for label, count, color in stages:
            pct = (count / total_views) * 100 if total_views else 0
            segments += f'<div style="flex:{max(pct, 2)};background:{color};height:36px;display:flex;align-items:center;justify-content:center;color:white;font-size:12px;font-weight:600;min-width:60px;" title="{label}: {count:,}">{label} {count:,}</div>'

        drop_labels = ""
        if total_views > 0 and total_clicks > 0:
            drop_labels += f'<span style="font-size:12px;color:var(--ink-muted);">Views&rarr;Clicks: {total_clicks/total_views*100:.1f}%</span>'
        if total_clicks > 0 and total_wishlists > 0:
            drop_labels += f'<span style="font-size:12px;color:var(--ink-muted);">Clicks&rarr;Wishlists: {total_wishlists/total_clicks*100:.1f}%</span>'
        if total_wishlists > 0 and total_purchases > 0:
            drop_labels += f'<span style="font-size:12px;color:var(--ink-muted);">Wishlists&rarr;Purchases: {total_purchases/total_wishlists*100:.1f}%</span>'

        funnel_bar = f"""
        <div class="card" style="padding:24px;margin-bottom:32px;">
            <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">Platform Funnel (30 Days)</h2>
            <div style="display:flex;border-radius:var(--radius-sm);overflow:hidden;margin-bottom:12px;">
                {segments}
            </div>
            <div style="display:flex;gap:16px;flex-wrap:wrap;">
                {drop_labels}
            </div>
        </div>
        """
    else:
        funnel_bar = """
        <div class="card" style="padding:24px;margin-bottom:32px;">
            <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">Platform Funnel (30 Days)</h2>
            <p style="color:var(--ink-muted);font-size:14px;">No funnel data yet</p>
        </div>
        """

    # Per-tool funnel table
    tool_rows = ""
    sorted_tools = sorted(funnel_data, key=lambda t: t.get('views', 0) or 0, reverse=True)
    for t in sorted_tools:
        name = escape(str(t.get('name', '')))
        slug = escape(str(t.get('slug', '')))
        views = t.get('views', 0) or 0
        clicks = t.get('clicks', 0) or 0
        wishlists = t.get('wishlists', 0) or 0
        purchases = t.get('purchases', 0) or 0
        ctr = f"{clicks / views * 100:.1f}%" if views > 0 else "0%"
        tool_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:10px 12px;font-size:14px;"><a href="/tool/{slug}" style="color:var(--terracotta);text-decoration:none;font-weight:600;">{name}</a></td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{views:,}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{clicks:,}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{ctr}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{wishlists:,}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{purchases:,}</td>
        </tr>
        """

    tool_funnel_table = _table("Per-Tool Funnel (30 Days)", ["Tool", "Views", "Clicks", "CTR%", "Wishlists", "Purchases"], tool_rows)

    # Maker leaderboard
    makers = await get_maker_leaderboard(db, days=30)
    maker_rows = ""
    for m in makers:
        name = escape(str(m.get('name', '')))
        slug = escape(str(m.get('slug', '')))
        tool_count = m.get('tool_count', 0) or 0
        views = m.get('total_views', 0) or 0
        clicks = m.get('total_clicks', 0) or 0
        last_update = m.get('last_update', '')

        # Status badge
        badge = '<span style="color:#16a34a;font-weight:600;font-size:12px;">Active</span>'
        if last_update:
            try:
                lu_dt = datetime.fromisoformat(str(last_update))
                days_ago = (datetime.utcnow() - lu_dt).days
                if days_ago > 60:
                    badge = '<span style="color:#dc2626;font-weight:600;font-size:12px;">Dormant</span>'
                elif days_ago > 14:
                    badge = '<span style="color:#EA580C;font-weight:600;font-size:12px;">Idle</span>'
            except Exception:
                badge = '<span style="color:var(--ink-muted);font-size:12px;">Unknown</span>'
        else:
            badge = '<span style="color:#dc2626;font-weight:600;font-size:12px;">Dormant</span>'

        lu_display = ""
        if last_update:
            try:
                lu_display = datetime.fromisoformat(str(last_update)).strftime("%b %d, %Y")
            except Exception:
                lu_display = str(last_update)[:10]
        else:
            lu_display = "Never"

        maker_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:10px 12px;font-size:14px;"><a href="/maker/{slug}" style="color:var(--terracotta);text-decoration:none;font-weight:600;">{name}</a></td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{tool_count}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{views:,}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{clicks:,}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink-muted);text-align:right;">{lu_display}</td>
            <td style="padding:10px 12px;text-align:center;">{badge}</td>
        </tr>
        """

    maker_table = _table("Maker Leaderboard (30 Days)", ["Name", "Tools", "Views", "Clicks", "Last Update", "Status"], maker_rows)

    return f"""
        {funnel_bar}
        {tool_funnel_table}
        {maker_table}
    """


async def _tab_search(db) -> str:
    """Search tab — gap analysis, top queries, volume."""
    now = datetime.utcnow()
    since_30 = (now - timedelta(days=30)).isoformat()

    # Search volume
    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM search_logs WHERE created_at >= ?", (since_30,)
    )
    search_volume = (await cursor.fetchone())['cnt']

    # Search gaps
    gaps = await get_search_gaps(db, limit=30)
    gap_rows = ""
    for g in gaps:
        query = escape(str(g.get('query', '')))
        count = g.get('count', 0) or 0
        last_searched = g.get('last_searched', '')
        ls_display = ""
        if last_searched:
            try:
                ls_display = datetime.fromisoformat(str(last_searched)).strftime("%b %d, %Y")
            except Exception:
                ls_display = str(last_searched)[:10]
        gap_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);font-family:var(--font-mono);">{query}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{count}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink-muted);text-align:right;">{ls_display}</td>
        </tr>
        """

    gaps_table = _table(
        "\u26a0\ufe0f Search Gap Analysis",
        ["Query", "Times Searched", "Last Searched"],
        gap_rows,
        empty_msg="No zero-result searches recorded yet."
    )

    # Top search queries
    trends = await get_search_trends(db, days=30, limit=20)
    trend_rows = ""
    for t in trends:
        query = escape(str(t.get('query', '')))
        count = t.get('count', 0) or 0
        avg_results = t.get('avg_results', 0) or 0
        trend_rows += f"""
        <tr style="border-bottom:1px solid var(--border);">
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);font-family:var(--font-mono);">{query}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{count}</td>
            <td style="padding:10px 12px;font-size:14px;color:var(--ink);text-align:right;">{avg_results:.1f}</td>
        </tr>
        """

    trends_table = _table("Top Search Queries (30 Days)", ["Query", "Searches", "Avg Results"], trend_rows)

    volume_card = _kpi_card("Search Volume (30 Days)", f"{search_volume:,}")

    return f"""
        <div style="display:grid;grid-template-columns:1fr;gap:16px;margin-bottom:32px;">
            {volume_card}
        </div>
        {gaps_table}
        {trends_table}
    """


async def _tab_growth(db) -> str:
    """Growth tab — subscriber count, growth chart, user signups, claim conversion."""

    # Subscriber count
    sub_count = await get_subscriber_count(db)

    # Subscriber growth
    growth_data = await get_subscriber_growth(db)
    growth_points = [(g['date'], g.get('cumulative', 0) or 0) for g in growth_data] if growth_data else []
    growth_chart = _bar_chart(growth_points, "Subscriber Growth (Cumulative)")

    # User signup stats
    cursor = await db.execute("SELECT COUNT(*) as cnt FROM users")
    total_users = (await cursor.fetchone())['cnt']

    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM users WHERE created_at >= datetime('now', '-30 days')"
    )
    new_users_30d = (await cursor.fetchone())['cnt']

    # Claim conversion
    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM tools WHERE maker_id IS NOT NULL AND status='approved'"
    )
    claimed_tools = (await cursor.fetchone())['cnt']

    cursor = await db.execute(
        "SELECT COUNT(*) as cnt FROM tools WHERE status='approved'"
    )
    total_tools = (await cursor.fetchone())['cnt']

    claim_pct = f"{claimed_tools / total_tools * 100:.1f}%" if total_tools > 0 else "0%"

    return f"""
        <!-- KPI cards -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:32px;">
            {_kpi_card("Email Subscribers", f"{sub_count:,}")}
            {_kpi_card("Total Users", f"{total_users:,}")}
            {_kpi_card("New Users (30d)", f"{new_users_30d:,}")}
        </div>

        {growth_chart}

        <!-- Claim conversion -->
        <div class="card" style="padding:24px;margin-bottom:32px;">
            <h2 style="font-family:var(--font-display);font-size:20px;color:var(--ink);margin-bottom:16px;">Tool Claim Conversion</h2>
            <div style="display:flex;align-items:center;gap:16px;">
                <div style="flex:1;height:24px;background:var(--cream-dark);border-radius:var(--radius-sm);overflow:hidden;">
                    <div style="height:100%;width:{claimed_tools / total_tools * 100 if total_tools else 0:.0f}%;background:#16a34a;border-radius:var(--radius-sm);"></div>
                </div>
                <span style="font-size:14px;font-weight:600;color:var(--ink);">{claim_pct}</span>
            </div>
            <div style="display:flex;gap:24px;margin-top:12px;">
                <span style="font-size:13px;color:var(--ink-muted);">Claimed: <strong style="color:var(--ink);">{claimed_tools}</strong></span>
                <span style="font-size:13px;color:var(--ink-muted);">Total approved: <strong style="color:var(--ink);">{total_tools}</strong></span>
            </div>
        </div>
    """


# ── Main route ───────────────────────────────────────────────────────────

@router.get("/admin/analytics", response_class=HTMLResponse)
async def admin_analytics(request: Request):
    if not check_admin_session(request):
        return RedirectResponse(url="/admin", status_code=303)

    db = request.state.db
    tab = request.query_params.get("tab", "overview")

    if tab == "funnels":
        tab_content = await _tab_funnels(db)
    elif tab == "search":
        tab_content = await _tab_search(db)
    elif tab == "growth":
        tab_content = await _tab_growth(db)
    else:
        tab = "overview"
        tab_content = await _tab_overview(db, request)

    body = f"""
    <div class="container" style="padding:48px 24px;max-width:960px;">
        <h1 style="font-family:var(--font-display);font-size:32px;color:var(--ink);margin-bottom:24px;">Analytics</h1>

        {_nav_bar()}
        {_sub_tabs(tab)}

        {tab_content}
    </div>
    """

    return HTMLResponse(page_shell("Analytics", body, user=request.state.user))
