# in utils/safe_shutdown.py
def safe_shutdown():
    """Placeholder for safe shutdown procedures."""
    print("Safe shutdown procedure called.")
    # In the future, you can add database connection closing,
    # saving state, etc. here.
    exit()
