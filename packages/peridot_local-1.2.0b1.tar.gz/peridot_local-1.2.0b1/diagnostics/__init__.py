from .selftest import run_self_test, run_self_tests

__all__ = ["run_self_test", "run_self_tests"]
