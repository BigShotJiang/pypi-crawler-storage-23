"""
Govee LAN API implementations (UDP protocol).
Each module corresponds to a specific command type.
"""
from govee.api.lan import discovery

__all__ = ["discovery"]
