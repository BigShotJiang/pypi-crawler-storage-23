# ipeds-wrangler

## What it does

The United States National Center for Education Statistics (NCES) maintains the Integrated Postsecondary Education Data System (IPEDS). Each year, IPEDS collects data from approximately 6,000 institutions, representing more than 15 million students. These data can enable many institutional research projects, such as: benchmarking against peer institutions, tracking enrollment trends, and analyzing graduation rates. However, IPEDS data can be challenging to wrangle into actionable insights - especially for Python users.

This package is new, but ipeds-wrangler will enable Python users to:

- Webscrape IPEDS databases from NCES.
- Search IPEDS databases efficiently.
- Read .accdb tables into pd.DataFrame() format.
- Convert numerical categorical variables into user-friendly text.

## Get started

Install the package:
```bash
pip install ipeds-wrangler
```

Download IPEDS databases:
```python
from ipeds_wrangler import download_ipeds_databases

# Download the most recent 4 years of IPEDS databases to your Desktop
download_ipeds_databases()

# Or specify a custom directory name
download_ipeds_databases(download_directory="my_ipeds_data")
```