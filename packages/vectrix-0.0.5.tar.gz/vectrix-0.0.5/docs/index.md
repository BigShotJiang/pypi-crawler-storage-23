---
template: home.html
title: "Vectrix — Zero-Config Time Series Forecasting for Python"
description: "Production-ready time series forecasting library. 30+ models, auto model selection, flat-line defense, Forecast DNA — all in one line of code. Pure NumPy + SciPy."
hide:
  - navigation
  - toc
---
