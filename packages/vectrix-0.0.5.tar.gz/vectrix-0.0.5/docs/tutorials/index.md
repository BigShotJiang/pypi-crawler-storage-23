# Tutorials

Interactive [marimo](https://marimo.io) notebooks. Run locally for full interactivity.

## How to Run

```bash
pip install "vectrix[tutorials]"
marimo run docs/tutorials/en/01_quickstart.py
```

## Available Tutorials

| # | Topic | English | Korean |
|---|-------|---------|--------|
| 01 | Quickstart | `en/01_quickstart.py` | `ko/01_quickstart.py` |
| 02 | Analysis & DNA | `en/02_analyze.py` | `ko/02_analyze.py` |
| 03 | Regression | `en/03_regression.py` | `ko/03_regression.py` |
| 04 | 30+ Models | `en/04_models.py` | `ko/04_models.py` |
| 05 | Adaptive Intelligence | `en/05_adaptive.py` | `ko/05_adaptive.py` |
| 06 | Business Intelligence | `en/06_business.py` | `ko/06_business.py` |

## Tutorial Descriptions

### 01 — Quickstart
Forecast from lists, DataFrames, and CSV files. Explore results with `.predictions`, `.plot()`, `.to_csv()`.

### 02 — Analysis & DNA
Automatic time series profiling: difficulty, category, fingerprint, changepoints, anomalies.

### 03 — Regression
R-style formula regression with OLS, Ridge, Lasso, Huber, Quantile. Full diagnostics.

### 04 — 30+ Models
Direct `Vectrix` class usage. Compare all models, understand Flat Defense system.

### 05 — Adaptive Intelligence
Regime detection, Forecast DNA, self-healing forecasts, business constraints.

### 06 — Business Intelligence
Anomaly detection, what-if scenarios, backtesting, business metrics.
