# 파이프라인 API

## ForecastPipeline

::: vectrix.pipeline.ForecastPipeline

## 변환기

### BaseTransformer

::: vectrix.pipeline.BaseTransformer

### Scaler

::: vectrix.pipeline.Scaler

### LogTransformer

::: vectrix.pipeline.LogTransformer

### BoxCoxTransformer

::: vectrix.pipeline.BoxCoxTransformer

### Differencer

::: vectrix.pipeline.Differencer

### Deseasonalizer

::: vectrix.pipeline.Deseasonalizer

### Detrend

::: vectrix.pipeline.Detrend

### OutlierClipper

::: vectrix.pipeline.OutlierClipper

### MissingValueImputer

::: vectrix.pipeline.MissingValueImputer
