# 회귀분석

R 스타일 수식 회귀분석과 진단.

## 선형 회귀

::: vectrix.regression.linear.LinearRegressor

::: vectrix.regression.linear.RidgeRegressor

::: vectrix.regression.linear.LassoRegressor

## 강건 회귀

::: vectrix.regression.robust.HuberRegressor

::: vectrix.regression.robust.QuantileRegressor

## 진단

::: vectrix.regression.diagnostics.RegressionDiagnostics
