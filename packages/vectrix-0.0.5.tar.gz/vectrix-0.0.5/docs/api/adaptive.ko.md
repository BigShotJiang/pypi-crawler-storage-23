# 적응형 예측

레짐 감지, 자가 치유 예측, 비즈니스 제약조건, Forecast DNA.

## 레짐 감지

::: vectrix.adaptive.regime.RegimeDetector

::: vectrix.adaptive.regime.RegimeAwareForecaster

## Forecast DNA

::: vectrix.adaptive.dna.ForecastDNA

## 자가 치유

::: vectrix.adaptive.healing.SelfHealingForecast

## 제약조건

::: vectrix.adaptive.constraints.ConstraintAwareForecaster

::: vectrix.adaptive.constraints.Constraint
