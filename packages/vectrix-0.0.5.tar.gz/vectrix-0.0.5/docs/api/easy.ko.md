# Easy API

Vectrix를 사용하는 가장 간단한 방법입니다. 각 작업에 함수 하나만 호출하면 됩니다.

## 함수

::: vectrix.easy.forecast

::: vectrix.easy.analyze

::: vectrix.easy.regress

::: vectrix.easy.quick_report

## 결과 클래스

::: vectrix.easy.EasyForecastResult

::: vectrix.easy.EasyAnalysisResult

::: vectrix.easy.EasyRegressionResult
