# Foundation Models API

## Chronos

### ChronosForecaster

::: vectrix.ml.chronos_model.ChronosForecaster

## TimesFM

### TimesFMForecaster

::: vectrix.ml.timesfm_model.TimesFMForecaster

## NeuralForecast

### NeuralForecaster

::: vectrix.ml.neuralforecast_model.NeuralForecaster

### NBEATSForecaster

::: vectrix.ml.neuralforecast_model.NBEATSForecaster

### NHITSForecaster

::: vectrix.ml.neuralforecast_model.NHITSForecaster

### TFTForecaster

::: vectrix.ml.neuralforecast_model.TFTForecaster

## Availability Flags

```python
from vectrix import CHRONOS_AVAILABLE, TIMESFM_AVAILABLE, NEURALFORECAST_AVAILABLE
```

These boolean flags indicate whether the optional dependencies are installed.
