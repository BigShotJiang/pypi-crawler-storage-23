# Regression

R-style formula regression with full diagnostics.

## Linear Regression

::: vectrix.regression.linear.LinearRegressor

::: vectrix.regression.linear.RidgeRegressor

::: vectrix.regression.linear.LassoRegressor

## Robust Regression

::: vectrix.regression.robust.HuberRegressor

::: vectrix.regression.robust.QuantileRegressor

## Diagnostics

::: vectrix.regression.diagnostics.RegressionDiagnostics
