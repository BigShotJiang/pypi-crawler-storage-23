# Business

Anomaly detection, what-if analysis, backtesting, and business metrics.

## Anomaly Detection

::: vectrix.business.anomaly.AnomalyDetector

## What-If Analysis

::: vectrix.business.whatif.WhatIfAnalyzer

## Backtesting

::: vectrix.business.backtest.Backtester

## Business Metrics

::: vectrix.business.metrics.BusinessMetrics
