# 다변량 API

## VARModel

::: vectrix.engine.var.VARModel

## VECMModel

::: vectrix.engine.var.VECMModel

## 확률적 분포

### ForecastDistribution

::: vectrix.intervals.distributions.ForecastDistribution

### DistributionFitter

::: vectrix.intervals.distributions.DistributionFitter

### empiricalCRPS

::: vectrix.intervals.distributions.empiricalCRPS

## 이벤트 효과

### EventEffect

::: vectrix.engine.events.EventEffect
