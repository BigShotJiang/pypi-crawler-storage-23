# Vectrix Class

The full-featured forecasting engine with model comparison and selection.

::: vectrix.vectrix.Vectrix
