# Multivariate API

## VARModel

::: vectrix.engine.var.VARModel

## VECMModel

::: vectrix.engine.var.VECMModel

## Probabilistic Distributions

### ForecastDistribution

::: vectrix.intervals.distributions.ForecastDistribution

### DistributionFitter

::: vectrix.intervals.distributions.DistributionFitter

### empiricalCRPS

::: vectrix.intervals.distributions.empiricalCRPS

## Event Effects

### EventEffect

::: vectrix.engine.events.EventEffect
