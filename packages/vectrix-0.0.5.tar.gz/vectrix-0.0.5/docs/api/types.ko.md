# 타입

핵심 데이터 타입과 결과 객체.

::: vectrix.types
