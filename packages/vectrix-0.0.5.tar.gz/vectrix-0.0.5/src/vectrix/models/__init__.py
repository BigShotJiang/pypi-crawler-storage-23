"""
Models module
"""

from .selector import AdaptiveModelSelector

__all__ = ["AdaptiveModelSelector"]
