"""
Data Analysis Module
"""

from .autoAnalyzer import AutoAnalyzer

__all__ = ["AutoAnalyzer"]
