# xapian-store

A Python package providing the `XStore` model class for managing store data using Xapian as the underlying storage engine.

## Features

- Built on top of `xapian_model.base.BaseXapianModel`
- Comprehensive store schema with support for multiple store types
- Type-safe field definitions with validation
- Support for soft deletes and timestamps
- Configurable store attributes (slug, domain, name, owner, type, etc.)
- Visual customization fields (photo, header, color)

## Requirements

- Python 3.12 or higher
- xapian-model >= 0.4.0
- pyxapiand >= 2.1.0

## Installation

```bash
pip install xapian-store
```

## Quick Start

```python
from xstore import XStore, STORE_TYPE_AFFILIATE, get_store_schema

# XStore comes with a default INDEX_TEMPLATE and SCHEMA;
# override them in a subclass if your application requires it.
class MyStore(XStore):
    INDEX_TEMPLATE = "my_stores"

# Create a store instance
store = MyStore()

# Access the schema directly
schema = get_store_schema(foreign_schema='.schema/store')
```

## Store Types

The package supports the following store types:

- `STORE_TYPE_NONE` - No specific type
- `STORE_TYPE_AFFILIATE` - Affiliate store
- `STORE_TYPE_AFFINITY` - Affinity store
- `STORE_TYPE_FRANCHISE` - Franchise store
- `STORE_TYPE_SUPPLIER` - Supplier store
- `STORE_TYPE_MASHUP` - Mashup store

## Schema Configuration

The store schema includes the following main fields:

- **Identification**: `id`, `slug`, `domain`, `canonical_url`
- **Metadata**: `name`, `owner`, `supplier`, `store_type`
- **Visual**: `photo`, `header`, `color`, `base_color`
- **Status**: `is_published`, `hidden`, `is_deleted`, `is_root_affinity_store`
- **Timestamps**: `created_at`, `updated_at`, `deleted_at`
- **Contact**: `from_email`, `address`

### Security Note

For security reasons, the following values should be reviewed and overridden per application:

- `INDEX_TEMPLATE` — defaults to `'stores'`; override in a subclass if needed
- `foreign_schema` — passed as a parameter to `get_store_schema()`

## Configuration Example

```python
from xstore import XStore, get_store_schema

# Override INDEX_TEMPLATE and SCHEMA for your application
class MyStore(XStore):
    INDEX_TEMPLATE = "my_stores"
    SCHEMA = get_store_schema(foreign_schema='.schema/my_store')

# Use your store
store = MyStore()
```

## Development

### Setup

The project uses `direnv` to automatically create and activate a virtual environment:

```bash
# With direnv installed, simply cd into the project
cd xstore

# Or manually create the environment
python3 -m venv .venv
source .venv/bin/activate
```

### Running Tests

The integration tests require a running Xapiand server at `localhost:8880`. They skip gracefully when the server is unavailable.

```bash
# Install test dependencies
pip install -e ".[test]"

# Run integration tests (requires xapiand at localhost:8880)
pytest tests/ -v

# Tests skip automatically if the server is not running
```

All test indices are namespaced under the `tests/` prefix so they don't interfere with production data and can be cleaned up manually.

### Project Structure

```
xstore/
├── src/
│   └── xstore/
│       ├── __init__.py     # Public API exports
│       ├── models.py       # XStore model class
│       └── schemas.py      # Schema definitions
├── tests/
│   ├── conftest.py         # Shared fixtures and server check
│   └── test_integration.py # Integration test suite
├── pyproject.toml          # Project configuration
└── README.md               # This file
```

## License

MIT License - see LICENSE file for details.

## Links

- **Homepage**: https://github.com/dubalu/xstore
- **Repository**: https://github.com/dubalu/xstore
- **Bug Reports**: https://github.com/dubalu/xstore/issues

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Authors

- Dubalu <info@dubalu.com>
