# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.4] - 2026-03-03

### Changed
- Added day-to-year accuracy to `created_at` date field

## [0.2.3] - 2026-02-26

### Added
- Integration test suite (19 tests) covering CRUD, validation, defaults, and schema auto-provisioning
- Test dependencies as optional `[test]` extra: pytest, pytest-asyncio, httpx
- pytest configuration in pyproject.toml with async and integration marker support
- Testing documentation in README.md and CLAUDE.md

## [0.2.2] - 2026-02-26

### Changed
- Updated `xapian-model` dependency to >= 0.4.0

## [0.2.1] - 2026-02-19

### Changed
- Updated `xapian-model` dependency to >= 0.3.1
- Updated `pyxapiand` dependency to >= 2.1.0

## [0.2.0] - 2026-02-17

### Changed
- Updated `xapian-model` dependency to >= 0.3.0
- Updated `pyxapiand` dependency to >= 2.0.0

## [0.1.2] - 2026-02-17

### Improved
- Added strict type annotations to all public functions and methods in models and schemas
- Updated docstrings to follow Google-style conventions across the codebase
- Updated CLAUDE.md and README.md to match current code

## [0.1.1] - 2026-02-16

### Fixed
- Corrected import from `pyxapiand` to `xapiand` (the actual module name installed by the pyxapiand package)

## [0.1.0] - 2026-02-16

### Added
- Initial release of xapian-store package
- XStore model class based on BaseXapianModel
- Comprehensive store schema with field definitions
- Support for multiple store types (affiliate, affinity, franchise, supplier, mashup)
- Store fields for identification, metadata, visual customization, and status
- Soft delete support with is_deleted and deleted_at fields
- Timestamp tracking (created_at, updated_at)
- Type hints and Google-style docstrings
- Python 3.12+ support with modern syntax

[0.2.4]: https://github.com/dubalu/xstore/releases/tag/v0.2.4
[0.2.3]: https://github.com/dubalu/xstore/releases/tag/v0.2.3
[0.2.2]: https://github.com/dubalu/xstore/releases/tag/v0.2.2
[0.2.1]: https://github.com/dubalu/xstore/releases/tag/v0.2.1
[0.2.0]: https://github.com/dubalu/xstore/releases/tag/v0.2.0
[0.1.2]: https://github.com/dubalu/xstore/releases/tag/v0.1.2
[0.1.1]: https://github.com/dubalu/xstore/releases/tag/v0.1.1
[0.1.0]: https://github.com/dubalu/xstore/releases/tag/v0.1.0
