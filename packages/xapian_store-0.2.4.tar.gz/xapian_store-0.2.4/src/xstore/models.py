"""Store model built on Xapian.

Provides the XStore model class that extends BaseXapianModel with
store-specific schema and indexing configuration.
"""
from __future__ import annotations

from xapian_model.base import BaseXapianModel

from .schemas import get_store_schema


class XStore(BaseXapianModel):
    """Model class for managing store data in Xapian.

    Extends BaseXapianModel to provide store-specific functionality
    with a predefined schema for store attributes like slug, domain, name, owner,
    store type, and publication status.

    Attributes:
        INDEX_TEMPLATE: Xapian index template name for stores.
        SCHEMA: Dictionary containing the store field definitions and their types.
    """

    INDEX_TEMPLATE: str = 'stores'
    SCHEMA: dict[str, dict[str, object]] = get_store_schema(foreign_schema='.schemas/store')
