from .core import VoiceSystem

__all__ = ["VoiceSystem"]
