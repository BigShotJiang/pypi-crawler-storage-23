"""Network data models for TUI display.

These models are populated from RPC responses and provide
display-friendly representations of network data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


@dataclass
class Route:
    """Network route information."""

    dst: str
    gateway: str | None
    scope: Literal["universe", "link"]
    proto: Literal["static", "kernel"]
    link: str
    prefsrc: str | None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Route:
        """Create Route from RPC response dict."""
        return cls(
            dst=data.get("dst", ""),
            gateway=data.get("gateway"),
            scope=data.get("scope", "universe"),
            proto=data.get("proto", "static"),
            link=data.get("link", ""),
            prefsrc=data.get("prefsrc"),
        )

    @property
    def is_default(self) -> bool:
        """Check if this is a default route."""
        return self.dst == "0.0.0.0/0" and bool(self.gateway)

    @property
    def data_row(self) -> list[str | None]:
        """Get values as list for DataTable row."""
        return [self.dst, self.gateway, self.scope, self.proto, self.link, self.prefsrc]

    def __hash__(self) -> int:
        return hash(self.dst) + hash(self.link) + hash(self.gateway)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Route):
            return False
        return (
            self.dst == other.dst
            and self.link == other.link
            and self.gateway == other.gateway
        )


@dataclass
class ResolvedDnsServer:
    """DNS server information."""

    address: str
    interface_name: str
    family: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResolvedDnsServer:
        """Create from RPC response dict."""
        return cls(
            address=data.get("address", ""),
            interface_name=data.get("interface_name", ""),
            family=data.get("family", "IPv4"),
        )

    @property
    def data_row(self) -> list[str]:
        """Get values as list for DataTable row."""
        return [self.address, self.interface_name, self.family]

    def __hash__(self) -> int:
        return hash(self.address) + hash(self.interface_name) + hash(self.family)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ResolvedDnsServer):
            return False
        return (
            self.address == other.address
            and self.interface_name == other.interface_name
            and self.family == other.family
        )

    def __str__(self) -> str:
        return self.address


@dataclass
class ResolvedHostname:
    """DNS resolution result for a hostname."""

    name: str
    address: str | None = None
    interface_name: str | None = None
    family: str | None = None
    canonical_name: str | None = None
    elapsed: str | None = None
    error: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResolvedHostname:
        """Create from RPC response dict."""
        return cls(
            name=data.get("name", ""),
            address=data.get("address"),
            interface_name=data.get("interface_name"),
            family=data.get("family"),
            canonical_name=data.get("canonical_name"),
            elapsed=data.get("elapsed"),
            error=data.get("error"),
        )

    @property
    def data_row(self) -> list[str | None]:
        """Get values as list for DataTable row."""
        return [
            self.name,
            self.address,
            self.interface_name,
            self.family,
            self.canonical_name,
            self.elapsed,
            self.error,
        ]

    @property
    def resolved(self) -> bool:
        """Check if hostname was successfully resolved."""
        return bool(self.address)
