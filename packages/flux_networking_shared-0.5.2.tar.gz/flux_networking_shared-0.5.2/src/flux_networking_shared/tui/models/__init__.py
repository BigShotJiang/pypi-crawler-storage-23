"""Network TUI models."""

from flux_networking_shared.tui.models.interface_config_result import (
    InterfaceConfigResult,
    InterfaceShapingPolicy,
)
from flux_networking_shared.tui.models.network import (
    ResolvedDnsServer,
    ResolvedHostname,
    Route,
)
from flux_networking_shared.tui.models.upnp import (
    FLUX_API_PORTS,
    AddMappingResult,
    FluxApiPorts,
    UpnpLease,
    UpnpStatus,
)

__all__ = [
    "AddMappingResult",
    "FLUX_API_PORTS",
    "FluxApiPorts",
    "InterfaceConfigResult",
    "InterfaceShapingPolicy",
    "ResolvedDnsServer",
    "ResolvedHostname",
    "Route",
    "UpnpLease",
    "UpnpStatus",
]
