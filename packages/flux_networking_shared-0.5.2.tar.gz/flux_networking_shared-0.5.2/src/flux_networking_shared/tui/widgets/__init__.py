"""Network TUI widgets."""

from flux_networking_shared.tui.widgets.address_builder import Layer3Builder
from flux_networking_shared.tui.widgets.connectivity import Connectivity
from flux_networking_shared.tui.widgets.dns import Dns
from flux_networking_shared.tui.widgets.dns_summary import DnsSummary
from flux_networking_shared.tui.widgets.field_set import FieldSet
from flux_networking_shared.tui.widgets.flux_connectivity import FluxConnectivity
from flux_networking_shared.tui.widgets.focus_label import FocusLabel
from flux_networking_shared.tui.widgets.interface import Interface
from flux_networking_shared.tui.widgets.interface_group import InterfaceGroup
from flux_networking_shared.tui.widgets.label_switch import LabelSwitch
from flux_networking_shared.tui.widgets.labels import InvalidLabel, WarningLabel
from flux_networking_shared.tui.widgets.loading import Loading
from flux_networking_shared.tui.widgets.name_resolution import NameResolution
from flux_networking_shared.tui.widgets.network_overview import NetworkOverview
from flux_networking_shared.tui.widgets.network_summary import NetworkSummary
from flux_networking_shared.tui.widgets.route_summary import RouteSummary
from flux_networking_shared.tui.widgets.routing import Routing
from flux_networking_shared.tui.widgets.upnp_action_bar import UpnpActionBar
from flux_networking_shared.tui.widgets.upnp_builder import UpnpBuilder
from flux_networking_shared.tui.widgets.validate_blur_input import ValidateBlurInput

__all__ = [
    "Connectivity",
    "Dns",
    "DnsSummary",
    "FieldSet",
    "FluxConnectivity",
    "FocusLabel",
    "Interface",
    "InterfaceGroup",
    "InvalidLabel",
    "LabelSwitch",
    "Layer3Builder",
    "Loading",
    "NameResolution",
    "NetworkOverview",
    "NetworkSummary",
    "RouteSummary",
    "Routing",
    "UpnpActionBar",
    "UpnpBuilder",
    "ValidateBlurInput",
    "WarningLabel",
]
