"""Asynchronous CortexOS client for the v2 verification API."""

from __future__ import annotations

from typing import Any

from cortexos._http import AsyncHTTP
from cortexos.client import _DEFAULT_BASE_URL, _DEFAULT_TIMEOUT, _DEFAULT_RETRIES
from cortexos.models import CheckResult, GateResult


class AsyncCortex:
    """
    Asynchronous CortexOS SDK client.

    Usage::

        from cortexos import AsyncCortex

        async with AsyncCortex(api_key="cx-...") as cx:
            result = await cx.check(
                response="The return window is 30 days",
                sources=["Return policy: 30-day window for all items."],
            )
            print(result.hallucination_index)
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        agent_id: str = "default",
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_RETRIES,
    ):
        self.agent_id = agent_id
        self._http = AsyncHTTP(base_url, api_key, timeout, max_retries)

    async def __aenter__(self) -> "AsyncCortex":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.aclose()

    async def check(
        self,
        response: str,
        sources: list[str],
        *,
        agent_id: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> CheckResult:
        """
        Run full verification: decompose -> numerical -> fuzzy -> NLI.

        Args:
            response: The text to verify.
            sources:  Ground-truth source documents.
            agent_id: Override the client-level agent_id.
            config:   Optional overrides.

        Returns:
            CheckResult with per-claim verdicts and hallucination index.
        """
        payload: dict[str, Any] = {
            "response": response,
            "sources": sources,
            "agent_id": agent_id or self.agent_id,
        }
        if config:
            payload["config"] = config
        resp = await self._http.post("/v1/check", json=payload)
        return CheckResult._from_api(resp.json())

    async def gate(
        self,
        memory: str,
        sources: list[str],
        *,
        agent_id: str | None = None,
    ) -> GateResult:
        """
        Gate check: should this memory be stored?

        Args:
            memory:   The candidate memory text.
            sources:  Source documents to verify against.
            agent_id: Override the client-level agent_id.

        Returns:
            GateResult with grounded flag and flagged claims.
        """
        payload: dict[str, Any] = {
            "candidate_memory": memory,
            "sources": sources,
            "agent_id": agent_id or self.agent_id,
        }
        resp = await self._http.post("/v1/gate", json=payload)
        return GateResult._from_api(resp.json())

    async def health(self) -> dict:
        """Check server health."""
        resp = await self._http.get("/healthz")
        return resp.json()
