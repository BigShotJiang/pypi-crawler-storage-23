# config_reader_python
A reader for yaml and json file in python
