"""Analyzers package."""

from skill_scanner.analyzers.pipeline import run_scan

__all__ = ["run_scan"]
