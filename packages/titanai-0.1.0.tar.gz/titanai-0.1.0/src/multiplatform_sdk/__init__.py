"""Multi-platform SDK Python bindings"""

__version__ = "0.1.0"

from .multiplatform_sdk import MultiplatformSDK, process_data

__all__ = ["MultiplatformSDK", "process_data", "__version__"]
