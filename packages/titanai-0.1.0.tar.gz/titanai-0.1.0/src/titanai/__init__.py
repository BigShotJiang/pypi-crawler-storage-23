"""TitanAI SDK - Multi-platform AI toolkit"""

__version__ = "0.1.0"

from .core import TitanAI, process_data

__all__ = ["TitanAI", "process_data", "__version__"]
