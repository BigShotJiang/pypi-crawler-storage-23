#!/usr/bin/env python
import importlib
import importlib.util
import os
import sys
import subprocess
import json
from socket import AF_UNIX, SOCK_STREAM, SocketIO, socket
from typing import IO, Any, Dict, List, Optional
from tempfile import NamedTemporaryFile
from uuid import uuid4
import traceback


def create_get_work_item_json(worker_id: int) -> str:
    return json.dumps({"type": "GET_WORK_ITEM", "worker_id": worker_id})


def create_get_execution_props_json(worker_id: int) -> str:
    return json.dumps({"type": "GET_AUTOMATION_EXECUTION_PROPS", "worker_id": worker_id})


def create_work_item_json(automation_name: str, argument: Any, from_work_id: str, sequence: List[int]) -> str:
    new_work_id = str(uuid4())
    return json.dumps(
        {
            "type": "WORK_ITEM",
            "work_id": new_work_id,
            "automation_name": automation_name,
            "argument": argument,
            "from_work_id": from_work_id,
            "sequence": sequence
        }
    )


def create_worker_publish_result_json(work_id_str: str, result: Any) -> str:
    return json.dumps(
        {"type": "PUBLISH_RESULT", "work_id": work_id_str, "result": result}
    )


def create_worker_error_json(
    work_id_str: Optional[str], error: str, traceback_str: str
) -> str:
    return json.dumps(
        {
            "type": "WORKER_ERROR",
            "error": error,
            "traceback": traceback_str,
            "work_id": work_id_str,
        }
    )


def create_worker_mark_as_idle_json(worker_id: int) -> str:
    return json.dumps({"type": "MARK_AS_IDLE", "worker_id": worker_id})


unix_socket = "/tmp/datallog_worker.sock"
my_id = int(sys.argv[1])

sock: Optional[socket] = None


def import_module_from_path(file_path: str):
    spec = importlib.util.spec_from_file_location("*", file_path)
    if spec is None:
        raise Exception(f"Failed to create spec for module: {file_path}")
    module = importlib.util.module_from_spec(spec)

    if spec.loader is None:
        raise Exception(f"Failed to get loader for module: {file_path}")

    spec.loader.exec_module(module)
    return module


def connect_to_conteiner_server():
    global sock
    sock = socket(AF_UNIX, SOCK_STREAM)
    sock.connect(unix_socket)
    return SocketIO(sock, "rwb")


sockio = connect_to_conteiner_server()


def send_message_to_conteiner_server(data: str):
    sockio.write(data.encode() + b"\n")
    sockio.flush()


def send_mark_as_idle_to_conteiner_server():
    json_payload = create_worker_mark_as_idle_json(worker_id=my_id)
    send_message_to_conteiner_server(json_payload)


def receive_message_from_conteiner_server():
    response_bytes = sockio.readline()
    if (
        not response_bytes
    ):  # Handle case where readline returns empty bytes (e.g. server closed connection)
        raise ConnectionAbortedError("Server closed connection or sent empty response.")
    response_str = response_bytes.decode().strip()
    if (
        not response_str
    ):  # Handle case where the line was just whitespace or empty after strip
        raise ValueError("Received an empty message from server.")
    return json.loads(response_str)


def get_work_item_from_conteiner_server():
    json_payload = create_get_work_item_json(worker_id=my_id)
    send_message_to_conteiner_server(json_payload)
    return receive_message_from_conteiner_server()


def get_execution_props_from_conteiner_server():
    json_payload = create_get_execution_props_json(worker_id=my_id)
    send_message_to_conteiner_server(json_payload)
    return receive_message_from_conteiner_server()


def send_worker_error_to_conteiner_server(
    work_id_str: Optional[str], error: str, traceback_str: str
):
    json_payload = create_worker_error_json(
        work_id_str=work_id_str, error=error, traceback_str=traceback_str
    )
    send_message_to_conteiner_server(json_payload)


def close_connection_to_conteiner_server():
    if sockio:
        sockio.close()
    if sock:
        sock.close()


def start_worker(automation_path: str, automation_argument: Any, env: dict, output_log_file: IO[str], error_log_file: IO[str]) -> Dict[str, Any]:
    with NamedTemporaryFile() as output_file:
        with NamedTemporaryFile() as input_file:
            data_to_process_payload = json.dumps({
                "automation_argument": automation_argument,
                "automation_path": automation_path,
                "output_file": output_file.name
            }, default=str)
            input_file.write(data_to_process_payload.encode())
            input_file.flush()
            subprocess.run(
                [
                    sys.executable, '-m', 'datallog.utils.cloud_worker', str(input_file.name)
                ],
                env=env,
                stdout=output_log_file,
                stderr=error_log_file
            )
        output_file.seek(0)
        result = json.load(output_file)
        return result

def rgb(r: int, g: int, b: int) -> str:
    return f"\033[38;2;{r};{g};{b}m"

def execute_automations():
    original_stderr = sys.stderr
    original_stdout = sys.stdout
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = rgb(248, 81, 73)
    YELLOW = rgb(242, 204, 96)
    GREEN = rgb(52, 211, 153)
    BLUE = rgb(73, 143, 255)
    """
    Manages the execution lifecycle of automations for a single application instance
    within a dedicated worker process.

    This function runs continuously within a worker process, handling multiple
    automations sequentially as directed by the container server for a specific
    application execution. It loads the user's application code once and then
    enters a loop, processing work items received from the server. It supports
    optional arguments for automations and allows execution paths to branch based on
    automation results, provided the automation is explicitly marked for branching. The
    worker also notifies the server about its idle status to aid in efficient
    worker pool management.

    The execution flow is as follows:
    1.  **Initialization:**
        a. Fetches initial application execution properties (like code file path)
           from the container server (`get_execution_props_from_conteiner_server`).
        b. Dynamically loads the user's application module. Decorator information
           (including branching flags) is gathered. (Decorator state persists).

    2.  **Automation Execution Loop:**
        a. Enters a loop (with a safety break) to continuously poll for and
           execute automations.
        b. Fetches the next work item from the container server
           (`get_work_item_from_conteiner_server`).
        c. **Exit Condition:** If the received item indicates no more work
           (e.g., type is "NO_MORE_WORK_ITEMS"), closes the server connection
           and exits the loop/function.
        d. **Automation Processing (within try...except block):**
            i.  If automation index is 0, performs initial sequence validation.
            ii. Identifies the automation function (callable) based on the index.
            iii. **Log Redirection:** Redirects stdout and stderr to a log file
                 specific to this automation instance (`logs/{automation_name}-{work_id}.log`)
                 for the duration of the automation execution.
            iv. **Flexible Argument Handling:** Calls the automation function correctly
                 based on whether an argument is provided and whether the automation
                 requires mandatory arguments.
            v.  Executes the automation function. Flushes stdout/stderr before restoring.
            vi. **Idle Notification:** If the automation completed successfully and a
                `next_automation` exists (meaning this is not the final automation), the
                worker immediately notifies the container server that it is
                momentarily idle (`send_mark_as_idle_to_conteiner_server`). This
                signal allows the server to optimize the allocation of pending
                tasks to available workers before this worker submits its
                follow-up task(s).
            vii.**Result Handling & Branching:** (Formerly 2.d.vi)
                - Checks if a `next_automation` is defined for the current automation.
                - If a `next_automation` exists (idle notification was already sent):
                    - If the `automation_result` is a list *and* the automation is explicitly
                      marked for branching (`get_automation_branching`):
                      Iterates through the list. For *each item*, sends a new
                      `WorkItem` payload to the server (`send_work_item_to_conteiner_server`)
                      for the `next_automation`, using the item as the argument.
                    - Otherwise: Sends a single `WorkItem` payload for the
                      `next_automation`, using the entire `automation_result` as the argument.
                - If no `next_automation` exists: Sends a final `WorkerPublishResult`
                  payload to the server (`send_result_to_conteiner_server`).
        e.  **Error Handling:** Catches other exceptions during automation processing,
            reports them as a `WorkerPublishError` payload
            (`send_result_to_conteiner_server` handles both results and errors),
            and continues the loop to await the next work item or exit signal.
    """
    # 1. Initialization
    try:
        execution_props = get_execution_props_from_conteiner_server()
    except (ConnectionAbortedError, ValueError, json.JSONDecodeError) as e:
        print(f"Failed to get execution properties: {e}", file=sys.stderr)
        # Optionally send a specific error type if the protocol supports it before exiting
        # For now, just close and exit.
        if sock:  # Ensure sock is defined before trying to close
            close_connection_to_conteiner_server()
        return

    # 2. Automation Execution Loop
    for _ in range(1000):  # Safeguard
        try:
            work_item = get_work_item_from_conteiner_server()
        except (ConnectionAbortedError, ValueError, json.JSONDecodeError) as e:

            send_worker_error_to_conteiner_server(
                work_id_str=None,
                error=str(e),
                traceback_str=traceback.format_exc(),
            )
            close_connection_to_conteiner_server()
            return

        if (
            isinstance(work_item, dict)
            and work_item.get("type") == "NO_MORE_WORK_ITEMS"
        ):
            close_connection_to_conteiner_server()
            return

        if (
            not isinstance(work_item, dict)
            or work_item.get("type") != "WORK_ITEM"
            or "automation_index" not in work_item
            or "work_id" not in work_item
        ):
            print(
                f"Received unexpected or malformed message: {work_item}",
                file=sys.stderr,
            )
            # Optionally, send an error to the server about the malformed message.
            # For now, we'll try to get another message.
            error_payload = create_worker_error_json(
                work_id_str=(
                    work_item.get("work_id") if isinstance(work_item, dict) else None
                ),
                error="Received malformed work item from server",
                traceback_str=f"Message: {work_item}",
            )
            send_message_to_conteiner_server(error_payload)
            continue

        current_work_id_str = work_item["work_id"]  # Assumed present for WORK_ITEM type

        try:
            automation_name = work_item["automation_name"]
            log_file = None
            log_to_dir = execution_props.get("log_to_dir", False)
            automation_argument = work_item.get("argument")
            sequence = work_item.get("sequence", [])
            sequence_str = "-".join(map(str, sequence))
            if log_to_dir:
                # Ensure logs directory exists
                if not os.path.exists("logs"):
                    os.makedirs("logs")
                log_file_path = (
                    f"logs/{automation_name}-{sequence_str}.log"
                )

                log_file = open(log_file_path, "w")
                sys.stdout = log_file
                sys.stderr = log_file

                print(f"{GREEN}{BOLD}▶ Executing automation:{RESET} {automation_name}")
                if automation_argument is not None:
                    print(f"{BLUE}{BOLD}Argument:{RESET}")
                    print(f"{YELLOW}" + "-" * 40 + f"{RESET}")
                    print(json.dumps(automation_argument, indent=4))
                    print(f"{YELLOW}" + "-" * 40 + f"{RESET}")
            else:
                print(f"{GREEN}{BOLD}▶ Executing automation:{RESET} {automation_name}")

                result = start_worker(
                    automation_path=work_item["file_path"],
                    automation_argument=automation_argument,
                    env=execution_props.get("environment_variables", {}),
                    output_log_file=original_stdout,
                    error_log_file=original_stderr
                )

                if result.get("type") == "error":
                    title_text = f"  EXECUTION ERROR ON AUTOMATION: {automation_name}  "
                    message = result.get("message", "Unknown error")
                    traceback_str = result.get("traceback", "No traceback available")
                    width = len(title_text)
                    TOP = f"{RED}{BOLD}┏{'━' * width}┓{RESET}"
                    TITLE = f"{RED}{BOLD}┃{title_text}┃{RESET}"
                    BOTTOM = f"{RED}{BOLD}┗{'━' * width}┛{RESET}"
                    print(TOP)
                    print(TITLE)
                    print(BOTTOM)
                    print(f"{RED}{BOLD}Error Message:{RESET} {message}")
                    for line in traceback_str.splitlines():
                        print(f"{RED}{line}{RESET}")
                    error_payload_json = create_worker_error_json(
                        work_id_str=current_work_id_str,
                        error=message,   
                        traceback_str=traceback_str,
                    )
                    send_message_to_conteiner_server(error_payload_json)
                if result.get("type") == "result":
                    automation_result = result.get("step_result")
                    if log_to_dir:
                        print(f"{BLUE}{BOLD}Result:{RESET}")
                        print(f"{YELLOW}" + "-" * 40 + f"{RESET}")
                        print(json.dumps(automation_result, indent=4))
                        print(f"{YELLOW}" + "-" * 40 + f"{RESET}")
                    result_payload_json = create_worker_publish_result_json(
                        work_id_str=current_work_id_str, result=automation_result
                    )
                    send_message_to_conteiner_server(result_payload_json)
        except Exception as e:
            formatted_traceback = traceback.format_exc()
            title_text = f"  EXECUTION ERROR ON AUTOMATION: {automation_name}  "
            width = len(title_text)
            TOP = f"{RED}{BOLD}┏{'━' * width}┓{RESET}"
            TITLE = f"{RED}{BOLD}┃{title_text}┃{RESET}"
            BOTTOM = f"{RED}{BOLD}┗{'━' * width}┛{RESET}"
            print(TOP)
            print(TITLE)
            print(BOTTOM)
            for line in formatted_traceback.splitlines():
                print(f"{RED}{line}{RESET}")
            error_payload_json = create_worker_error_json(
                work_id_str=current_work_id_str,
                error=str(e),
                traceback_str=formatted_traceback,
            )
            send_message_to_conteiner_server(error_payload_json)

        finally:
            if log_to_dir:
                if log_file:
                    log_file.close()


if __name__ == "__main__":
    
    try:
        execute_automations()
    except Exception as e:
        # Catch-all for any unhandled exceptions during worker setup or main loop
        print(
            f"Unhandled exception in worker (worker_id: {my_id}): {e}", file=sys.stderr
        )

        # Attempt to notify the server about a critical failure if connection is still possible
        try:
            # work_id might not be available or relevant here, send None
            send_worker_error_to_conteiner_server(
                work_id_str=None, error=str(e), traceback_str=traceback.format_exc()
            )
        except Exception as final_e:
            traceback.print_exc(file=sys.stderr)
            print(
                f"Failed to send final thread error to server: {final_e}",
                file=sys.stderr,
            )
    finally:
        close_connection_to_conteiner_server()
