"""AnimeSeg - Anime Character Segmentation using DINOv2 + U-Net++"""

from .pipeline import AnimeSegPipeline

__version__ = "0.2.4"

__all__ = ["AnimeSegPipeline"]
