"""Test utility functions for the cvx.simulator package.

This package contains tests for the utility functions in the cvx.simulator package,
including interpolation, data processing, and other helper functions.
"""
