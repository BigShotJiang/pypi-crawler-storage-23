"""Init file for utils"""

from .example_general import *
