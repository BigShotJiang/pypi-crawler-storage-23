*[API]: Application Programming Interface
*[SDK]: Software Development Kit
*[VQA]: Visual Question Answering
*[ML]: Machine Learning
*[AI]: Artificial Intelligence
*[CV]: Computer Vision
*[VLM]: Vision Language Model
*[REST]: Representational State Transfer
*[HTTP]: Hypertext Transfer Protocol
*[HTTPS]: Hypertext Transfer Protocol Secure
*[JSON]: JavaScript Object Notation
*[JSONL]: JSON Lines
*[CRC32C]: Cyclic Redundancy Check 32-bit with Castagnoli polynomial
*[UUID]: Universally Unique Identifier
*[RGB]: Red Green Blue
*[MIME]: Multipurpose Internet Mail Extensions
*[URL]: Uniform Resource Locator
*[URI]: Uniform Resource Identifier
*[CLI]: Command Line Interface
*[OS]: Operating System
*[I/O]: Input/Output
