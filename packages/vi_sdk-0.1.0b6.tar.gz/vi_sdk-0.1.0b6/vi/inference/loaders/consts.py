#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   consts.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK HuggingFace loader constants module.
"""

import os


def get_optimal_worker_count(
    fraction: float = 0.75, min_workers: int = 4, max_workers: int = 32
) -> int:
    """Calculate optimal number of workers based on CPU threads.

    Args:
        fraction: Fraction of CPU threads to use (default: 0.75 = 75%)
        min_workers: Minimum number of workers to use
        max_workers: Maximum number of workers to use

    Returns:
        Optimal number of workers for CPU-bound operations

    """
    cpu_count = os.cpu_count() or min_workers
    optimal = max(min_workers, int(cpu_count * fraction))
    return min(optimal, max_workers)


DEFAULT_CONFIG_FILE_NAME = "config.json"
DEFAULT_ATTN_IMPLEMENTATION = "sdpa"
DEFAULT_DEVICE_MAP = "auto"
MAX_THREADS = get_optimal_worker_count(fraction=0.75, min_workers=4, max_workers=32)
