#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   __init__.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK config init module with lazy loading.
"""

import importlib
from pathlib import Path

from vi.inference.config.base_config import ViGenerationConfig

__all__ = ["ViGenerationConfig"]


def __getattr__(name: str):
    """Lazy load generation config classes.

    Automatically discovers and imports generation config classes based on
    naming convention: <Model>GenerationConfig maps to config/<model>.py

    This eliminates the need to manually register new configs in __init__.py.
    """
    if name.endswith("GenerationConfig") and name != "ViGenerationConfig":
        # Convert class name to module name
        # E.g., "QwenVLGenerationConfig" -> "qwenvl"
        module_name = name.replace("GenerationConfig", "").lower()

        # Check if module exists
        config_dir = Path(__file__).parent
        module_file = config_dir / f"{module_name}.py"

        if module_file.exists():
            try:
                module = importlib.import_module(f"vi.inference.config.{module_name}")
                config_class = getattr(module, name)
                return config_class
            except (ImportError, AttributeError):
                pass

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
