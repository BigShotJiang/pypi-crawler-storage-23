# Vi Inference Module

Auto-discovery system for model loaders and predictors. Add new models by simply creating decorated classes - no manual registry updates needed.

## Adding a New Model

### 1. Create Generation Config

Create `config/mymodel.py`:

```python
from vi.inference.config.base_config import ViGenerationConfig

class MyModelGenerationConfig(ViGenerationConfig):
    temperature: float = 0.7
    max_new_tokens: int = 1024
    # Add model-specific parameters
```

### 2. Create Loader

Create `loaders/architectures/mymodel.py`:

```python
from vi.inference.loaders.hf import HFLoader
from vi.inference.loaders.registry import LoaderRegistry
from vi.inference.utils.module_import import check_imports

# Check dependencies before importing them
check_imports(
    packages=["torch", "transformers"],
    dependency_group="mymodel",
)

# Imports below are safe after dependency check
from transformers import AutoModelForVision2Seq, AutoProcessor
from vi.inference.config.mymodel import MyModelGenerationConfig

@LoaderRegistry.register(
    loader_key="mymodel",
    model_types=["my_model_type"],
    architectures=["MyModelForVision2Seq"],
)
class MyModelLoader(HFLoader):
    _model_class = AutoModelForVision2Seq
    _processor_class = AutoProcessor
    _generation_config_class = MyModelGenerationConfig
```

### 3. Create Predictor

Create `predictors/architectures/mymodel.py`:

```python
from vi.inference.predictors.hf import HFPredictor
from vi.inference.predictors.registry import PredictorRegistry
from vi.inference.utils.module_import import check_imports

# Check dependencies before importing them
check_imports(
    packages=["torch", "transformers"],
    dependency_group="mymodel",
)

# Imports below are safe after dependency check
from vi.inference.config.mymodel import MyModelGenerationConfig

@PredictorRegistry.register(
    predictor_key="mymodel",
    loader_types=["MyModelLoader"],
)
class MyModelPredictor(HFPredictor[MyModelGenerationConfig]):
    def get_generation_config_class(self):
        return MyModelGenerationConfig

    def __call__(self, image_path: str, user_prompt: str = "", **kwargs):
        # Inference logic here
        pass
```

### 4. Done!

No manual registry updates needed. The system auto-discovers your classes.

## Directory Structure

```
inference/
├── config/              # Generation configs
├── loaders/
│   ├── architectures/   # Model loaders (auto-discovered)
│   └── registry.py      # Loader registry
├── predictors/
│   ├── architectures/   # Model predictors (auto-discovered)
│   └── registry.py      # Predictor registry
└── README.md           # This file
```

## Usage

```python
from vi.inference.loaders import ViLoader
from vi.inference.predictors import ViPredictor

# Auto-detect from HuggingFace config
loader = ViLoader(model="org/my-model")
predictor = ViPredictor(loader=loader)

# Or specify explicitly
loader = ViLoader(model="org/my-model", loader_key="mymodel")
predictor = ViPredictor(loader=loader, predictor_key="mymodel")
```
