#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   freeform.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK freeform text assistant type module.
"""

from pydantic import BaseModel, Field

from vi.inference.task_types.assistant import PredictionResponse, TaskAssistant


class FreeformCaption(BaseModel):
    """Freeform caption object.

    Simple caption-only response for pretrained models or when no specific
    task structure is required.

    Attributes:
        caption: The generated text caption/response.

    """

    caption: str = Field(..., min_length=1)


class FreeformAssistant(TaskAssistant):
    """Structured model output for freeform text generation.

    Freeform is a simple task type that generates a text caption without
    any additional structure. This is the default for pretrained models
    from HuggingFace or when no response_format is specified.

    Attributes:
        freeform: The freeform caption result.

    """

    freeform: FreeformCaption


class FreeformResponse(PredictionResponse):
    """Freeform response object.

    Attributes:
        result: The freeform caption result.

    """

    result: FreeformCaption
