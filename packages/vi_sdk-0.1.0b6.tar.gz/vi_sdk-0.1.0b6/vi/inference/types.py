#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   types.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Type definitions for inference module.
"""

from enum import Enum


class SourceType(str, Enum):
    """Type of source input for inference.

    Attributes:
        PATH: Local file path to an image or video file
        URL: HTTP or HTTPS URL pointing to an image or video
        DATA_URI: Data URI containing base64-encoded image or video data
            (e.g., "data:image/jpeg;base64,...")

    """

    PATH = "path"
    URL = "url"
    DATA_URI = "data_uri"
