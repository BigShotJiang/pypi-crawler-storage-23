#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   __init__.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK local deployment module.
"""

from vi.deployment.local.backends.base import InferenceBackend
from vi.deployment.local.backends.vi_backend import ViBackend
from vi.deployment.local.server import app, create_server

__all__ = [
    "InferenceBackend",
    "ViBackend",
    "app",
    "create_server",
]
