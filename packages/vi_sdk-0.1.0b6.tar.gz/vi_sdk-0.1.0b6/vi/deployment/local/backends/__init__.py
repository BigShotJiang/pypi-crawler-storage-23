#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   __init__.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK local deployment backends module.
"""

from vi.deployment.local.backends.base import GenerationResult, InferenceBackend
from vi.deployment.local.backends.vi_backend import ViBackend

__all__ = [
    "InferenceBackend",
    "GenerationResult",
    "ViBackend",
]
