#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   consts.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Constants for NIM deployment.
"""

# API and Registry Configuration
API_KEY_PREFIX = "nvapi-"
DEFAULT_NIM_REGISTRY = "nvcr.io/nim/nvidia"
DEFAULT_SERVICE_TIMEOUT = 600  # 10 minutes

# Supported NIM Model Images
SUPPORTED_MODEL_IMAGES = [
    "cosmos-reason1-7b",
    "cosmos-reason2-2b",
    "cosmos-reason2-8b",
]

# Video File Extensions
VIDEO_EXTENSIONS = {
    ".mp4",
    ".avi",
    ".mov",
    ".mkv",
    ".webm",
    ".flv",
    ".wmv",
    ".mpeg",
    ".mpg",
    ".3gp",
    ".m4v",
    ".ogv",
}

# Video MIME Type Mappings
VIDEO_MIME_TYPES = {
    ".mp4": "video/mp4",
    ".avi": "video/x-msvideo",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".webm": "video/webm",
    ".flv": "video/x-flv",
    ".wmv": "video/x-ms-wmv",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpeg",
    ".3gp": "video/3gpp",
    ".m4v": "video/x-m4v",
    ".ogv": "video/ogg",
}

# Image MIME Type Mappings
IMAGE_MIME_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
}
