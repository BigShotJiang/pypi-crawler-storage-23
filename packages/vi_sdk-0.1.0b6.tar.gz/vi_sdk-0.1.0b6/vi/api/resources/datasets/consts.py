#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   consts.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK datasets constants module.
"""

# File processing constants
DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024  # 8MB
MIME_DETECTION_BUFFER_SIZE = 8192  # 8KB buffer for MIME type detection
