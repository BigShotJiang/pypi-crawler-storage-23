#!/usr/bin/env python

"""████
 ██    ██    Datature
   ██  ██    Powering Breakthrough AI
     ██

@File    :   links.py
@Author  :   Wei Loon Cheng
@Contact :   developers@datature.io
@License :   Apache License 2.0
@Desc    :   Datature Vi SDK training projects links module.
"""

import re

from vi.client.http.links import LinkBuilder, ResourceLinkParser

TRAINING_PROJECT_LINK_RE = re.compile(
    r"^/workspaces/(?P<organization_id>[^/]+)/trainingProjects"
    r"(?:/(?P<training_project_id>[^/]+))?$"
)


class TrainingProjectLinkParser(ResourceLinkParser):
    """Parse a training project link."""

    _organization_id: str

    def __init__(self, organization_id: str):
        """Initialize the training project link parser.

        Args:
            organization_id: Organization ID for constructing training project links.

        """
        self._organization_id = organization_id
        self._base_link = (
            LinkBuilder("/workspaces")
            .add_segment(self._organization_id)
            .add_segment("trainingProjects")
            .build()
        )

    def __call__(self, training_project_id_or_link: str = "") -> str:
        """Parse the training project link.

        Args:
            training_project_id_or_link: Training project ID or full link path.

        Returns:
            The parsed training project link path.

        """
        if TRAINING_PROJECT_LINK_RE.match(training_project_id_or_link):
            return training_project_id_or_link

        return (
            LinkBuilder(self._base_link)
            .add_segment(training_project_id_or_link)
            .build()
        )

    def aggregation_insights(self, training_project_id: str) -> str:
        """Build the aggregation insights link.

        Args:
            training_project_id: Training project ID.

        Returns:
            The aggregation insights link path.

        """
        return (
            LinkBuilder(self._base_link)
            .add_segment(training_project_id)
            .add_segment("aggregationInsights")
            .build()
        )

    def generate_aggregation_insights(self, training_project_id: str) -> str:
        """Build the generate aggregation insights link.

        Args:
            training_project_id: Training project ID.

        Returns:
            The generate aggregation insights link path.

        """
        return (
            LinkBuilder(self._base_link)
            .add_segment(training_project_id)
            .add_segment("aggregationInsights:generate")
            .build()
        )

    def dry_run(self) -> str:
        """Build the dry run link.

        Returns:
            The dry run link path.

        """
        return (
            LinkBuilder("/dryRuns/workspaces")
            .add_segment(self._organization_id)
            .add_segment("trainingProjects")
            .build()
        )
