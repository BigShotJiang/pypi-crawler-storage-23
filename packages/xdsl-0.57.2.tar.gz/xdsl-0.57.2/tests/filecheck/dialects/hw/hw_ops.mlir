// RUN: XDSL_ROUNDTRIP

"builtin.module"() ({
  "test.op"() { "test" = #hw.innerNameRef<@Foo::@Bar> } : () -> ()
  // CHECK:  "test.op"() {test = #hw.innerNameRef<@Foo::@Bar>} : () -> ()

  "test.op"() { "test" = #hw<innerSym[<@x_1,4,public>, <@y,5,public>]> } : () -> ()
  // CHECK-NEXT:  "test.op"() {test = #hw<innerSym[<@x_1,4,public>, <@y,5,public>]>} : () -> ()

  "test.op"() { "test" = #hw<innerSym@sym> } : () -> ()
  // CHECK-NEXT:  "test.op"() {test = #hw<innerSym@sym>} : () -> ()

  "test.op"() { "test" = #hw.direction<input> } : () -> ()
  // CHECK-NEXT:  "test.op"() {test = #hw.direction<input>} : () -> ()

  %test = "test.op"() : () -> !hw.array<6xi7>
  // CHECK-NEXT: %{{.*}} = "test.op"() : () -> !hw.array<6xi7>


  %test_nested = "test.op"() : () -> !hw.array<6x!hw.array<9xi42>>
  // CHECK-NEXT: %{{.*}} = "test.op"() : () -> !hw.array<6x!hw.array<9xi42>>

  %const = "test.op"() : () -> i19
  %array = hw.array_create %const, %const : i19 
  %array1 = hw.array_create %const : i19 

  // CHECK: %{{.*}} = hw.array_create %const, %const : i19 

  %index = "test.op"() : () -> i1
  %element = hw.array_get %array[%index] : !hw.array<2xi19>, i1

  // CHECK: %{{.*}} = hw.array_get %{{.*}}[%{{.*}}] : !hw.array<2xi19>, i1
  %nested = "test.op"() : () -> !hw.array<2x!hw.array<4xi64>>
  %first_index = arith.constant 1 : i1
  %take_out = hw.array_get %nested[%first_index] : !hw.array<2x!hw.array<4xi64>>, i1
  // CHECK: %{{.*}} = hw.array_get %{{.*}}[%{{.*}}] : !hw.array<2x!hw.array<4xi64>>, i1

  %ic = hw.bitcast %test : (!hw.array<6xi7>) -> !hw.array<7xi6>
  // CHECK: %ic = hw.bitcast %test : (!hw.array<6xi7>) -> !hw.array<7xi6>
  
  %constant = hw.constant 32 : i32
  // CHECK: %constant = hw.constant 32 : i32
}) : () -> ()
