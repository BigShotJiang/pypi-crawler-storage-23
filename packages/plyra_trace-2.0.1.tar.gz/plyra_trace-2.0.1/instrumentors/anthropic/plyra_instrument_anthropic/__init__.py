"""plyra-instrument-anthropic: Anthropic SDK instrumentation for plyra-trace."""

from __future__ import annotations

from typing import Any

_instrumented = False


def instrument(
    tracer_provider: Any = None,
    capture_content: bool = True,
    capture_usage: bool = True,
) -> None:
    """
    Instrument the Anthropic Python SDK to emit plyra-trace spans.

    Works for:
    - anthropic.Anthropic().messages.create() (sync)
    - anthropic.AsyncAnthropic().messages.create() (async)
    - All Claude models: claude-opus-4, claude-sonnet-4, claude-haiku, etc.

    Usage:
        import plyra_trace
        from plyra_instrument_anthropic import instrument

        pt = plyra_trace.init(project="my-agent", endpoint="http://localhost:7700")
        instrument()
    """
    global _instrumented
    if _instrumented:
        return
    from plyra_instrument_anthropic._patch import _patch_anthropic

    _patch_anthropic(tracer_provider, capture_content, capture_usage)
    _instrumented = True


def uninstrument() -> None:
    """Remove Anthropic instrumentation patches."""
    global _instrumented
    if not _instrumented:
        return
    from plyra_instrument_anthropic._patch import _unpatch_anthropic

    _unpatch_anthropic()
    _instrumented = False


__all__ = ["instrument", "uninstrument"]
