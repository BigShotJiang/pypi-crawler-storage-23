"""Allow running as: python -m tilepack"""

from tilepack.cli import cli

cli()
