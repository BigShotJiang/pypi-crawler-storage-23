class UnspecifiedVarInDefaultNone(Exception):
    pass


class ParallelForExtraCode(Exception):
    pass


class ParallelForWrongLoopCount(Exception):
    pass


class ParallelForInvalidCollapseCount(Exception):
    pass


class NonconstantOpenmpSpecification(Exception):
    pass


class NonStringOpenmpSpecification(Exception):
    pass


class MultipleNumThreadsClauses(Exception):
    pass
