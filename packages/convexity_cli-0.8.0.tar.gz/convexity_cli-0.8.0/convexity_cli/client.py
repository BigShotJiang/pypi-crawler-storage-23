"""HTTP client for Convexity API.

Provides a wrapper around httpx with API key authentication
and CLI-specific error handling.
"""

from typing import Any

import httpx

from convexity_cli.config import get_config
from convexity_cli.exceptions import (
    APIError,
    AuthenticationError,
    ConflictError,
    NetworkError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class ConvexityClient:
    """HTTP client for Convexity API with API key authentication."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = None,
    ):
        """Initialize the client.

        Args:
            base_url: API base URL (defaults to config)
            api_key: API key for authentication (defaults to config)
            timeout: Request timeout in seconds (defaults to config)
        """
        config = get_config()

        self.base_url = (base_url or config.get_base_url()).rstrip("/")
        self.api_key = api_key or config.get_api_key()
        self.timeout = timeout or config.get_timeout()
        self._client: httpx.Client | None = None

    @property
    def client(self) -> httpx.Client:
        """Lazy initialization of HTTP client."""
        if self._client is None:
            if not self.api_key:
                raise AuthenticationError("No API key configured. Run 'convexity auth login' or set CONVEXITY_API_KEY.")

            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "ConvexityClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _handle_response(self, response: httpx.Response) -> Any:
        """Handle API response and raise appropriate exceptions.

        Args:
            response: HTTP response

        Returns:
            Parsed JSON response data

        Raises:
            Various CLI exceptions based on status code
        """
        if response.status_code >= 200 and response.status_code < 300:
            if response.status_code == 204:
                return None
            try:
                return response.json()
            except Exception:
                return response.text

        # Parse error response
        try:
            error_data = response.json()
            error_message = error_data.get("detail", str(error_data))
        except Exception:
            error_message = response.text or f"HTTP {response.status_code}"

        # Map status codes to exceptions
        status = response.status_code

        if status == 401:
            raise AuthenticationError(error_message)
        elif status == 403:
            raise PermissionError(error_message)
        elif status == 404:
            raise NotFoundError(message=error_message)
        elif status == 409:
            raise ConflictError(error_message)
        elif status == 422:
            errors = []
            if isinstance(error_data, dict) and "detail" in error_data:
                detail = error_data["detail"]
                if isinstance(detail, list):
                    errors = detail
            raise ValidationError(error_message, errors=errors)
        elif status == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                error_message,
                retry_after=int(retry_after) if retry_after else None,
            )
        elif status >= 500:
            raise ServerError(error_message, status_code=status)
        else:
            raise APIError(error_message, status_code=status)

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Any:
        """Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            path: API path (will be appended to base_url)
            params: Query parameters
            json_data: JSON body data

        Returns:
            Parsed response data
        """
        try:
            response = self.client.request(
                method=method,
                url=path,
                params=params,
                json=json_data,
            )
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise NetworkError(f"Failed to connect to {self.base_url}: {e}")
        except httpx.TimeoutException as e:
            raise NetworkError(f"Request timed out: {e}")
        except httpx.RequestError as e:
            raise NetworkError(f"Request failed: {e}")

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make a GET request."""
        return self._request("GET", path, params=params)

    def post(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make a POST request."""
        return self._request("POST", path, params=params, json_data=data)

    def patch(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make a PATCH request."""
        return self._request("PATCH", path, params=params, json_data=data)

    def delete(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Make a DELETE request."""
        return self._request("DELETE", path, params=params)

    # =========================================================================
    # Organization methods
    # =========================================================================

    def list_organizations(self) -> list[dict[str, Any]]:
        """List all organizations the user has access to."""
        response = self.get("/v1/organizations")
        return response.get("items", []) if isinstance(response, dict) else response
