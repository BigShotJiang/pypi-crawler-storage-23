"""Shared utilities for CLI commands.

Provides helper functions used across multiple command modules.
"""

from contextvars import ContextVar

from convexity_api_client import AuthenticatedClient

from convexity_cli.config import get_config
from convexity_cli.exceptions import AuthenticationError

# Context variables for global CLI overrides
_api_key_override: ContextVar[str | None] = ContextVar("api_key_override", default=None)
_base_url_override: ContextVar[str | None] = ContextVar("base_url_override", default=None)


def set_global_overrides(api_key: str | None = None, base_url: str | None = None) -> None:
    """Set global config overrides from CLI flags.

    Args:
        api_key: Override API key
        base_url: Override base URL
    """
    if api_key:
        _api_key_override.set(api_key)
    if base_url:
        _base_url_override.set(base_url)


def get_authenticated_client() -> AuthenticatedClient:
    """Create an authenticated client from config.

    Uses global overrides if set, otherwise falls back to config.

    Returns:
        Configured AuthenticatedClient instance

    Raises:
        AuthenticationError: If no API key is configured
    """
    config = get_config()

    # Use override if set, otherwise use config
    api_key = _api_key_override.get() or config.get_api_key()
    base_url = _base_url_override.get() or config.get_base_url()

    if not api_key:
        raise AuthenticationError("No API key configured. Run 'convexity-cli auth --key <your-api-key>' or set CONVEXITY_API_KEY.")

    return AuthenticatedClient(
        base_url=base_url,
        token=api_key,
        prefix="",  # No prefix for X-API-Key
        auth_header_name="X-API-Key",
        raise_on_unexpected_status=True,
    )
