import pandas as pd
import numpy as np
from YnAI.core import YnAICore
from YnAI.interpreter import SentinelInterpreter

def main():
    print("="*50)
    print(" STARTING SENTINEL PLATINUM ENGINE ")
    print("="*50)

    # 1. Inisialisasi Core
    YnAI = YnAICore(config_path="config.yaml")

    # 2. LOAD DATA (Ini adalah bagian yang menyebabkan error tadi jika hilang)
    try:
        # Mencoba membaca file market asli
        df = pd.read_csv("market.csv")
        print("[OK] Data Market berhasil dimuat.")
    except FileNotFoundError:
        print("[!] market.csv tidak ditemukan. Membuat data simulasi...")
        # Membuat data dummy agar sistem tetap bisa berjalan untuk testing
        dates = pd.date_range(start='2026-01-01', periods=100, freq='5min')
        df = pd.DataFrame({
            'Open': np.random.uniform(100, 105, 100),
            'High': np.random.uniform(105, 110, 100),
            'Low': np.random.uniform(90, 95, 100),
            'Close': np.random.uniform(95, 100, 100),
            'Volume': np.random.randint(1000, 5000, 100)
        }, index=dates)

    # 3. PROSES DATA (Sekarang 'df' sudah ada, tidak akan error lagi)
    X, y, df_enriched = YnAI.process_market_data(df)
    last_row = df_enriched.iloc[-1]

    # 4. INTERPRETER (Analisa Narasi Terpisah)
    print("\n" + "="*50)
    print(" SENTINEL INTELLIGENCE REPORT ")
    print("="*50)
    
    reasons = SentinelInterpreter.analyze_conditions(last_row, YnAI.config)
    for line in reasons:
        print(f" -> {line}")

    # 5. STATUS FINAL
    signal = YnAI.generate_action(last_row)
    print(f"\n STATUS FINAL : {signal}")
    print("="*50)

if __name__ == "__main__":
    main()