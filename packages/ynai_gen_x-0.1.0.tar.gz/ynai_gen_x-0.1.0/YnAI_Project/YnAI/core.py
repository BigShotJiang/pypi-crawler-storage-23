import yaml
import torch
import os
# --- PERBAIKAN IMPORT: Mengambil dari modul terpisah, bukan dari .utils ---
from .indicators_base import BaseIndicators
from .indicators_custom import CustomIndicators
from .utils import DataPreparer
from .trainer import YnAILSTM

class YnAICore:
    def __init__(self, config_path="config.yaml"):
        """
        Inisialisasi Inti YnAI: Mengambil parameter dari luar (config.yaml)
        agar core tetap bersih.
        """
        self.config = self._load_config(config_path)
        self.preparer = DataPreparer(window_size=self.config['model_settings']['window_size'])
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def _load_config(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Konfigurasi tidak ditemukan di {path}")
        with open(path, 'r') as f:
            return yaml.safe_load(f)

    def process_market_data(self, df):
        """
        Memanggil indikator Standard dan Custom secara modular.
        """
        st = self.config['strategy']['indicators']
        ct = self.config['strategy'].get('custom', {})
        
        # 1. Jalankan Indikator Standard (Base)
        df = BaseIndicators.add_ema(df, st['ema_fast'] + [st['ema_trend']])
        df = BaseIndicators.add_rsi(df, st['rsi_period'])
        df = BaseIndicators.add_macd(df, *st['macd_params'])
        df = BaseIndicators.add_atr(df, st['atr_period'])
        
        # 2. Jalankan Indikator Custom (Custom)
        df = CustomIndicators.add_stochastic(df, *ct.get('stoch_params', [5, 3]))
        df = CustomIndicators.add_bollinger(df, *ct.get('bb_params', [20, 2]))
        df = CustomIndicators.add_adx(df, ct.get('adx_period', 14))
        
        df = df.dropna()
        
        # 3. Fitur AI Otomatis (Mengambil kolom hasil kalkulasi)
        exclude = ['Open', 'High', 'Low', 'Volume']
        features = [c for c in df.columns if c not in exclude]
        
        X, y = self.preparer.create_multivariate_sequences(df, features)
        return X.to(self.device), y.to(self.device), df

    def generate_action(self, last_row):
        """
        Logika Sinyal SENTINEL PLATINUM.
        """
        # Filter ADX dari Config
        adx_min = self.config['strategy']['constraints']['adx_min']
        if last_row['ADX'] < adx_min:
            return "SKIP: LOW VOLATILITY (ADX < 20)"
        
        # Contoh Logika EMA Cross
        ema_fast = f"EMA{self.config['strategy']['indicators']['ema_fast'][0]}"
        ema_slow = f"EMA{self.config['strategy']['indicators']['ema_fast'][1]}"
        
        if last_row[ema_fast] > last_row[ema_slow] and last_row['Close'] > last_row['EMA50']:
            return "STRONG BUY SIGNAL"
        elif last_row[ema_fast] < last_row[ema_slow] and last_row['Close'] < last_row['EMA50']:
            return "STRONG SELL SIGNAL"
            
        return "NEUTRAL / WAITING"