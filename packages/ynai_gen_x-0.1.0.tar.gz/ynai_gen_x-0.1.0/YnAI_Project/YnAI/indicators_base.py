import pandas as pd

class BaseIndicators:
    """Mesin Indikator Standar - Rumus Baku Industri"""
    
    @staticmethod
    def add_ema(df, periods):
        for p in periods:
            df[f'EMA{p}'] = df['Close'].ewm(span=p, adjust=False).mean()
        return df

    @staticmethod
    def add_rsi(df, period=14):
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        df['RSI'] = 100 - (100 / (1 + (gain / (loss + 1e-9))))
        df['RSI_Delta'] = df['RSI'].diff() # Tambahan delta RSI sesuai permintaan
        return df

    @staticmethod
    def add_macd(df, fast=12, slow=26, signal=9):
        ema_f = df['Close'].ewm(span=fast, adjust=False).mean()
        ema_s = df['Close'].ewm(span=slow, adjust=False).mean()
        df['MACD'] = ema_f - ema_s
        df['MACD_Signal'] = df['MACD'].ewm(span=signal, adjust=False).mean()
        df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']
        return df

    @staticmethod
    def add_atr(df, period=14):
        high_low = df['High'] - df['Low']
        high_close = (df['High'] - df['Close'].shift()).abs()
        low_close = (df['Low'] - df['Close'].shift()).abs()
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        df['ATR'] = tr.rolling(window=period).mean()
        return df