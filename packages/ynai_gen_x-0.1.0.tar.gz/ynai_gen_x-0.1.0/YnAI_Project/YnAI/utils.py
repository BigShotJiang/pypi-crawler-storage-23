import pandas as pd
import numpy as np
import torch
import matplotlib.pyplot as plt

class DataPreparer:
    def __init__(self, window_size=14):
        self.window_size = window_size
        self.min_val = None
        self.max_val = None

    def create_multivariate_sequences(self, df, feature_cols):
        data = df[feature_cols].values
        self.min_val = data.min(axis=0)
        self.max_val = data.max(axis=0)
        scaled_data = (data - self.min_val) / (self.max_val - self.min_val + 1e-9)
        
        xs, ys = [], []
        for i in range(len(scaled_data) - self.window_size):
            xs.append(scaled_data[i : i + self.window_size])
            ys.append(scaled_data[i + self.window_size, 0])
        return torch.tensor(np.array(xs)).float(), torch.tensor(np.array(ys)).float()

    def denormalize(self, value):
        return value * (self.max_val[0] - self.min_val[0]) + self.min_val[0]
def plot_results(real_prices, predicted_prices):
    plt.figure(figsize=(12, 6))
    plt.plot(real_prices, label='Harga Asli', color='blue')
    plt.plot(predicted_prices, label='Prediksi YnAI', color='red', linestyle='--')
    plt.title('SENTINEL PLATINUM: Analisis Modular Clean')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()
import json

def save_checkpoint(model, preparer, filename="YnAI_checkpoint.pth"):
    checkpoint = {
        'model_state': model.state_dict(),
        'min_val': preparer.min_val,
        'max_val': preparer.max_val,
        'window_size': preparer.window_size
    }
    torch.save(checkpoint, filename)
    print(f"[SUCCESS] Checkpoint disimpan ke {filename}")

def load_checkpoint(model, preparer, filename="YnAI_checkpoint.pth"):
    checkpoint = torch.load(filename)
    model.load_state_dict(checkpoint['model_state'])
    preparer.min_val = checkpoint['min_val']
    preparer.max_val = checkpoint['max_val']
    preparer.window_size = checkpoint['window_size']
    print(f"[SUCCESS] Otak YnAI dimuat dari {filename}")

import pandas as pd
import numpy as np
import torch

class DataPreparer:
    def __init__(self, window_size=14):
        self.window_size = window_size
        self.min_val = None
        self.max_val = None

    def add_indicators(self, df):
        # EMA: 8, 21, 50
        df['EMA8'] = df['Close'].ewm(span=8, adjust=False).mean()
        df['EMA21'] = df['Close'].ewm(span=21, adjust=False).mean()
        df['EMA50'] = df['Close'].ewm(span=50, adjust=False).mean()
        
        # RSI: Periode 14
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        df['RSI'] = 100 - (100 / (1 + (gain / (loss + 1e-9))))
        
        # MACD: 8, 17, 9
        ema8 = df['Close'].ewm(span=8, adjust=False).mean()
        ema17 = df['Close'].ewm(span=17, adjust=False).mean()
        df['MACD'] = ema8 - ema17
        df['MACD_Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
        
        # ATR & Bollinger Bands
        df['ATR'] = (df['High'] - df['Low']).rolling(14).mean()
        df['MBB'] = df['Close'].rolling(20).mean()
        df['UBB'] = df['MBB'] + (df['Close'].rolling(20).std() * 2)
        df['LBB'] = df['MBB'] - (df['Close'].rolling(20).std() * 2)
        
        return df.dropna()

    def create_multivariate_sequences(self, df, feature_cols):
        data = df[feature_cols].values
        self.min_val = data.min(axis=0)
        self.max_val = data.max(axis=0)
        scaled_data = (data - self.min_val) / (self.max_val - self.min_val + 1e-9)
        
        xs, ys = [], []
        for i in range(len(scaled_data) - self.window_size):
            xs.append(scaled_data[i : i + self.window_size])
            ys.append(scaled_data[i + self.window_size, 0]) # Target: Close
            
        return torch.tensor(np.array(xs)).float(), torch.tensor(np.array(ys)).float()