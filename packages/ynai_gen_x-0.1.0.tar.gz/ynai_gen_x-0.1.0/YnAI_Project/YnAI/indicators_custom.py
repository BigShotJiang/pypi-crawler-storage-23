import pandas as pd
import numpy as np

class CustomIndicators:
    """Mesin Indikator Custom - Strategi Khusus Sentinel"""
    
    @staticmethod
    def add_stochastic(df, k=5, d=3):
        low_min = df['Low'].rolling(window=k).min()
        high_max = df['High'].rolling(window=k).max()
        df['Stoch_K'] = 100 * ((df['Close'] - low_min) / (high_max - low_min + 1e-9))
        df['Stoch_D'] = df['Stoch_K'].rolling(window=d).mean()
        return df

    @staticmethod
    def add_bollinger(df, period=20, dev=2):
        df['MBB'] = df['Close'].rolling(window=period).mean()
        std = df['Close'].rolling(window=period).std()
        df['UBB'] = df['MBB'] + (std * dev)
        df['LBB'] = df['MBB'] - (std * dev)
        df['BB_Width'] = (df['UBB'] - df['LBB']) / df['MBB']
        return df

    @staticmethod
    def add_adx(df, period=14):
        plus_dm = df['High'].diff().clip(lower=0)
        minus_dm = df['Low'].diff().clip(upper=0).abs()
        tr = (df['High'] - df['Low']).rolling(period).mean()
        plus_di = 100 * (plus_dm.rolling(period).mean() / tr)
        minus_di = 100 * (minus_dm.rolling(period).mean() / tr)
        dx = (abs(plus_di - minus_di) / (plus_di + minus_di + 1e-9)) * 100
        df['ADX'] = dx.rolling(period).mean()
        return df