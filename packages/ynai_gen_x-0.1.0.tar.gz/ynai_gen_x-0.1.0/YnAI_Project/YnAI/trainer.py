import torch
import torch.nn as nn

# --- ARSITEKTUR MODEL (Otak LSTM) ---
class YnAILSTM(nn.Module):
    def __init__(self, input_size=8, hidden_size=128, num_layers=3):
        super(YnAILSTM, self).__init__()
        # Simpan variabel ke self agar bisa diakses di fungsi forward
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM dengan Dropout untuk data market yang volatile
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        # Inisialisasi hidden & cell state menggunakan self.num_layers
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        
        out, _ = self.lstm(x, (h0, c0))
        # Ambil output dari candle terakhir
        out = self.fc(out[:, -1, :])
        return out

# --- ENGINE TRAINING (Trainer) ---
class YnAITrainer:
    def __init__(self, model, lr=0.001):
        self.model = model
        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    def train_step(self, inputs, labels):
        self.model.train()
        self.optimizer.zero_grad()
        outputs = self.model(inputs)
        
        # Samakan dimensi output dan label [batch, 1]
        loss = self.criterion(outputs, labels.view(-1, 1))
        
        loss.backward()
        self.optimizer.step()
        return loss.item()