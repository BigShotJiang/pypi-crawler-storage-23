class SentinelInterpreter:
    @staticmethod
    def analyze_conditions(last_row, config):
        """
        Menerjemahkan angka indikator ke dalam narasi analisa.
        """
        adx_val = last_row['ADX']
        adx_min = config['strategy']['constraints']['adx_min']
        rsi_val = last_row['RSI']
        price = last_row['Close']
        ema8 = last_row['EMA8']
        
        analysis = []
        
        # 1. Analisa Trend (ADX)
        if adx_val > adx_min:
            analysis.append(f"ADX ({adx_val:.2f}): Tren mikro KUAT (Trending). Syarat >{adx_min} terpenuhi.")
        else:
            analysis.append(f"ADX ({adx_val:.2f}): Tren mikro LEMAH (Sideways). Kurang dari batas {adx_min}.")

        # 2. Analisa Momentum (EMA)
        if price < ema8:
            analysis.append(f"EMA 8 ({ema8:.2f}) vs PRICE ({price:.2f}): Harga di bawah EMA 8 (Tekanan Jual).")
        else:
            analysis.append(f"EMA 8 ({ema8:.2f}) vs PRICE ({price:.2f}): Harga di atas EMA 8 (Tekanan Beli).")

        # 3. Analisa Ekstrem (RSI)
        if rsi_val > 70:
            analysis.append(f"RSI ({rsi_val:.2f}): Area Overbought (Jenuh Beli).")
        elif rsi_val < 30:
            analysis.append(f"RSI ({rsi_val:.2f}): Area Oversold (Jenuh Jual).")
        else:
            analysis.append(f"RSI ({rsi_val:.2f}): Area Netral (Konsolidasi).")

        return analysis