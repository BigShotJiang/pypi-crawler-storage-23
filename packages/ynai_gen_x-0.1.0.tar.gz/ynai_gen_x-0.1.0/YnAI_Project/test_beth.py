import YnAI

# Inisialisasi
core = YnAI.YnAICore()
print(core.system_check())

# Inisialisasi Trainer (default pakai GPT2 yang ringan)
bot = YnAI.YnAITrainer()
hasil = bot.quick_generate("Halo YnAI, apa tugasmu?")
print(f"Respon YnAI: {hasil}")