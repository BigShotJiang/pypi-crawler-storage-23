import os
import sys
import yaml

def check_structure():
    print("="*40)
    print(" SENTINEL PLATINUM - SYSTEM CHECK ")
    print("="*40)

    # 1. Cek File Konfigurasi
    if os.path.exists("config.yaml"):
        print("[OK] config.yaml ditemukan.")
        with open("config.yaml", 'r') as f:
            conf = yaml.safe_load(f)
            print(f"     -> Mode: {conf['strategy']['indicators']['ema_fast']}")
    else:
        print("[ERR] config.yaml TIDAK ADA!")

    # 2. Cek Folder YnAI & Init
    if os.path.exists("YnAI/__init__.py"):
        print("[OK] Package 'YnAI' terdeteksi.")
    else:
        print("[ERR] Folder 'YnAI' atau __init__.py tidak ada!")

    # 3. Cek Import Modular
    try:
        from YnAI.indicators_base import BaseIndicators
        print("[OK] indicators_base.py (Standard) Terkoneksi.")
    except ImportError as e:
        print(f"[ERR] Gagal Load indicators_base: {e}")

    try:
        from YnAI.indicators_custom import CustomIndicators
        print("[OK] indicators_custom.py (Custom) Terkoneksi.")
    except ImportError as e:
        print(f"[ERR] Gagal Load indicators_custom: {e}")

    try:
        from YnAI.core import YnAICore
        print("[OK] core.py (Clean Manager) Terkoneksi.")
    except ImportError as e:
        print(f"[ERR] Gagal Load core: {e}")

    print("="*40)
    print(" STATUS: SISTEM SIAP DIJALANKAN ")
    print("="*40)

if __name__ == "__main__":
    check_structure()