import MetaTrader5 as mt5
import torch
import torch.nn as nn
import numpy as np
import time
from datetime import datetime
import os

# Model sama seperti yang kamu train
class SimpleSentimentModel(nn.Module):
    def __init__(self, input_size=4, hidden_size=128):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 64)
        self.fc_out = nn.Linear(64, 3)
        self.dropout = nn.Dropout(0.3)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.relu(self.fc3(x))
        return self.fc_out(x)

# Load model
model = SimpleSentimentModel()
model.load_state_dict(torch.load("sentimen_local_model.pth", map_location=torch.device('cpu')))
model.eval()
print("Model loaded successfully")

# Fungsi ambil fitur dari MT5
def get_features(symbol="XAUUSD", timeframe=mt5.TIMEFRAME_M5):
    if not mt5.initialize():
        print("MT5 init failed")
        return None

    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, 2)
    if rates is None or len(rates) < 2:
        mt5.shutdown()
        return None

    close = rates[-1]['close']
    prev_close = rates[-2]['close']
    price_change = (close - prev_close) / prev_close if prev_close != 0 else 0

    rsi_handle = mt5.iRSI(symbol, timeframe, 14, mt5.PRICE_CLOSE)
    macd_handle = mt5.iMACD(symbol, timeframe, 12, 26, 9, mt5.PRICE_CLOSE)
    atr_handle = mt5.iATR(symbol, timeframe, 14)

    if rsi_handle is None or macd_handle is None or atr_handle is None:
        mt5.shutdown()
        return None

    rsi = mt5.copy_buffer(rsi_handle, 0, 0, 1)
    macd_main = mt5.copy_buffer(macd_handle, 0, 0, 1)
    macd_sig = mt5.copy_buffer(macd_handle, 1, 0, 1)
    atr = mt5.copy_buffer(atr_handle, 0, 0, 1)

    mt5.shutdown()

    if rsi is None or macd_main is None or macd_sig is None or atr is None:
        return None

    rsi_norm = rsi[0][0] / 100.0 if rsi[0] else 0.5
    macd_hist = macd_main[0][0] - macd_sig[0][0] if macd_main[0] and macd_sig[0] else 0
    macd_hist_norm = (macd_hist + 0.05) / 0.1
    atr_norm = atr[0][0] / (close * 0.01) if atr[0] and close != 0 else 0.001

    return np.array([[price_change, rsi_norm, macd_hist_norm, atr_norm]], dtype=np.float32)

# Loop prediksi & tulis ke file
def main_loop():
    print("Prediksi sentimen real-time dimulai. Tekan Ctrl+C untuk stop.")
    while True:
        try:
            features = get_features()
            if features is None:
                print("Gagal ambil data, coba lagi 60 detik...")
                time.sleep(60)
                continue

            input_tensor = torch.tensor(features, dtype=torch.float32)
            with torch.no_grad():
                output = model(input_tensor)
                pred = output.argmax(dim=1).item()
                prob = torch.softmax(output, dim=1)[0].numpy()

            labels = ["Bearish", "Neutral", "Bullish"]
            signal = labels[pred]
            max_prob = max(prob) * 100

            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            result = f"{timestamp} | {signal} | {max_prob:.1f}% | Bearish {prob[0]*100:.1f}% | Neutral {prob[1]*100:.1f}% | Bullish {prob[2]*100:.1f}%"

            print(result)
            with open("sentimen_signal.txt", "w") as f:
                f.write(result)

            time.sleep(60)  # update setiap 1 menit
        except KeyboardInterrupt:
            print("Stopped by user")
            break
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(60)

if __name__ == "__main__":
    main_loop()