# preprocess_sentimen.py
# Preprocessing data MT5 untuk model sentimen (lokal, tanpa Hugging Face)
# Input: market_data.csv dari MT5 ekspor
# Output: processed_market_data.csv (siap train)

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def preprocess_mt5_csv(csv_path="market_data.csv"):
    if not os.path.exists(csv_path):
        print(f"File {csv_path} tidak ditemukan!")
        print("Ekspor dulu dari MT5 menggunakan script ExportMarketData.mq5")
        return

    df = pd.read_csv(csv_path)

    # Konversi time & set index
    df['time'] = pd.to_datetime(df['time'])
    df.set_index('time', inplace=True)

    # Hitung price_change (wajib dulu!)
    df['price_change'] = df['close'].pct_change().fillna(0)

    # Isi NaN dengan forward/backward fill (lebih baik daripada drop)
    df = df.ffill().bfill()

    # Kalau masih ada NaN, isi dengan 0
    df = df.fillna(0)

    print(f"Total baris setelah isi NaN: {len(df)}")

    if len(df) < 100:
        print("Data masih terlalu sedikit! Ekspor lebih banyak bar dari MT5 (minimal 1000 bar di H1/D1).")
        return

    # Normalisasi fitur (0-1)
    scaler = MinMaxScaler()
    df['rsi_normalized'] = scaler.fit_transform(df[['rsi']])
    df['macd_hist_normalized'] = scaler.fit_transform(df[['macd_hist']])
    df['atr_normalized'] = scaler.fit_transform(df[['atr']])

    # Buat label berdasarkan price_change (threshold 0.1%)
    df['label'] = np.where(df['price_change'] > 0.001, 1,
                           np.where(df['price_change'] < -0.001, -1, 0))

    # Simpan hasil
    df.to_csv("processed_market_data.csv", index=True)
    print("Preprocessing selesai! File: processed_market_data.csv")
    print("Distribusi label:")
    print(df['label'].value_counts(normalize=True))

    return df

if __name__ == "__main__":
    preprocess_mt5_csv()