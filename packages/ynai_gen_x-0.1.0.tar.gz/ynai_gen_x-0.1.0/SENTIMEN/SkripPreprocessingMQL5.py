import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

def preprocess_and_export_meta(input_csv, output_csv):
    df = pd.read_csv(input_csv).dropna()

    # Fitur Dasar
    df['price_change'] = (df['close'] - df['open']) / df['open']
    df['rsi_normalized'] = df['rsi'] / 100.0

    # Fitur yang butuh Standardization
    features_to_scale = ['macd_hist', 'atr']
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df[features_to_scale])
    
    df['macd_hist_normalized'] = scaled_data[:, 0]
    df['atr_normalized'] = scaled_data[:, 1]

    # Simpan hasil olahan untuk Training
    df.to_csv(output_csv, index=False)

    # --- BAGIAN EKSPOR KE MQL5 ---
    with open("ModelParams.mqh", "w") as f:
        f.write("// File ini di-generate otomatis oleh Python\n")
        f.write(f"// Tanggal: {pd.Timestamp.now()}\n\n")
        
        for i, feature in enumerate(features_to_scale):
            f.write(f"const double {feature}_mean = {scaler.mean_[i]};\n")
            f.write(f"const double {feature}_std = {scaler.scale_[i]};\n")
            
    print("✅ Preprocessing selesai!")
    print("✅ File 'ModelParams.mqh' telah dibuat. Copy ke folder MQL5/Include/")

if __name__ == "__main__":
    preprocess_and_export_meta("raw_mt5_data.csv", "processed_market_data.csv")