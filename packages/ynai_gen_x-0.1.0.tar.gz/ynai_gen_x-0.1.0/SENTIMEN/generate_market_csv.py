# generate_market_csv.py
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import os

# ── Konfigurasi ──
NUM_SAMPLES = 1500          # jumlah baris (bisa dinaikkan jadi 5000–10000)
OUTPUT_FILE = "market.csv"

# Daftar simbol populer trading
symbols = ["XAUUSD", "BTCUSD", "ETHUSD", "EURUSD", "USDJPY", "NVDA", "TSLA", "IDX30", "USOIL", "NG"]

# Template teks bullish, bearish, neutral (realistis)
bullish_templates = [
    "{symbol} bullish setelah {event} positif",
    "Harga {symbol} breakout kuat, target {target}",
    "Investor institusi akumulasi {symbol}, sentimen positif",
    "{symbol} naik tajam karena {catalyst}",
    "Fundamental {symbol} sangat kuat, hold long",
]

bearish_templates = [
    "{symbol} bearish setelah {event} buruk",
    "Harga {symbol} breakdown support kunci",
    "Likuidasi besar-besaran di {symbol}",
    "{symbol} tertekan karena {catalyst} negatif",
    "Sentimen negatif mendominasi {symbol}",
]

neutral_templates = [
    "{symbol} masih sideways, tunggu konfirmasi",
    "Market {symbol} ranging, belum ada arah jelas",
    "Volatilitas {symbol} rendah hari ini",
    "Tidak ada katalis kuat untuk {symbol}",
    "{symbol} konsolidasi setelah rally kemarin",
]

events = [
    "laporan NFP", "keputusan Fed", "data CPI", "pernyataan Powell",
    "tweet Elon Musk", "earnings perusahaan", "geopolitik meningkat",
    "dolar menguat", "inflasi tinggi", "suku bunga naik",
]

catalysts = [
    "potongan suku bunga", "perang dagang mereda", "adopsi institusi",
    "likuidasi massal", "FUD regulasi", "pump whale", "dump besar",
]

# Fungsi generate satu baris
def generate_row():
    label = random.choices([0, 1, 2], weights=[0.35, 0.30, 0.35])[0]  # sedikit imbalance realistis
    symbol = random.choice(symbols)
    
    if label == 2:      # bullish
        template = random.choice(bullish_templates)
        event = random.choice(events) if "{event}" in template else ""
        catalyst = random.choice(catalysts) if "{catalyst}" in template else ""
        target = f"{random.uniform(0.5, 5):.2f}%"
        text = template.format(symbol=symbol, event=event, catalyst=catalyst, target=target)
        confidence = random.uniform(0.75, 0.98)
        
    elif label == 0:    # bearish
        template = random.choice(bearish_templates)
        event = random.choice(events) if "{event}" in template else ""
        catalyst = random.choice(catalysts) if "{catalyst}" in template else ""
        text = template.format(symbol=symbol, event=event, catalyst=catalyst)
        confidence = random.uniform(0.70, 0.95)
        
    else:               # neutral
        template = random.choice(neutral_templates)
        text = template.format(symbol=symbol)
        confidence = random.uniform(0.60, 0.85)
    
    source = random.choice(["Twitter", "Investing.com", "Kontan", "Bloomberg", "Stockbit", "CNBC Indonesia"])
    timestamp = (datetime.now() - timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d %H:%M:%S")
    
    return {
        "text": text,
        "label": label,
        "confidence": round(confidence, 2),
        "source": source,
        "symbol": symbol,
        "timestamp": timestamp
    }

# Generate dataset
data = [generate_row() for _ in range(NUM_SAMPLES)]
df = pd.DataFrame(data)

# Simpan ke CSV
df.to_csv(OUTPUT_FILE, index=False, encoding='utf-8')
print(f"Berhasil membuat {OUTPUT_FILE} dengan {len(df)} sampel.")
print(df['label'].value_counts(normalize=True))  # cek distribusi label