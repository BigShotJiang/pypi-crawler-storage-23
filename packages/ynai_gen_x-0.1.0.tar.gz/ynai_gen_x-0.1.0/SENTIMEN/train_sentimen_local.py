# train_sentimen_local_full.py
# ----------------------------------------------------------------------
# Model Sentimen Lokal - Training dari data MT5 (tanpa Hugging Face)
# Fitur input: price_change, rsi_normalized, macd_hist_normalized, atr_normalized
# Label: -1 (bearish), 0 (neutral), 1 (bullish) → diubah jadi 0,1,2 untuk CrossEntropy
# ----------------------------------------------------------------------

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import os
from datetime import datetime

# ================================================
# 1. Custom Dataset
# ================================================
class MarketSentimentDataset(Dataset):
    def __init__(self, df):
        features = ['price_change', 'rsi_normalized', 'macd_hist_normalized', 'atr_normalized']
        self.X = df[features].values.astype(np.float32)
        # Ubah label -1,0,1 menjadi 0,1,2
        self.y = (df['label'] + 1).values.astype(np.int64)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return torch.tensor(self.X[idx]), torch.tensor(self.y[idx])

# ================================================
# 2. Model Sederhana (MLP)
# ================================================
class SimpleSentimentModel(nn.Module):
    def __init__(self, input_size=4, hidden_size=128):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 64)
        self.fc_out = nn.Linear(64, 3)  # 3 kelas: bearish, neutral, bullish
        self.dropout = nn.Dropout(0.3)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.relu(self.fc3(x))
        return self.fc_out(x)

# ================================================
# 3. Fungsi Training + Validasi + Tes Prediksi
# ================================================
def train_and_test():
    # Path file hasil preprocessing
    csv_path = "processed_market_data.csv"

    if not os.path.exists(csv_path):
        print(f"File {csv_path} tidak ditemukan!")
        print("Pastikan sudah menjalankan preprocessing dan file ada di folder ini.")
        return

    df = pd.read_csv(csv_path, index_col="time", parse_dates=True)
    df = df.dropna()

    print("Distribusi label setelah preprocessing:")
    print(df['label'].value_counts(normalize=True))

    dataset = MarketSentimentDataset(df)

    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_ds, val_ds = torch.utils.data.random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_ds, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=64)

    # Inisialisasi model
    model = SimpleSentimentModel(input_size=4, hidden_size=128)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Training menggunakan device: {device}")
    model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=0.001, weight_decay=0.01)

    best_acc = 0.0
    best_epoch = 0

    for epoch in range(20):
        model.train()
        total_loss = 0.0
        for X, y in train_loader:
            X, y = X.to(device), y.to(device)
            optimizer.zero_grad()
            out = model(X)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch+1:2d}/20 | Train Loss: {avg_loss:.4f}", end=" | ")

        # Validasi
        model.eval()
        preds, trues = [], []
        with torch.no_grad():
            for X, y in val_loader:
                X = X.to(device)
                out = model(X)
                pred = out.argmax(dim=1).cpu().numpy()
                preds.extend(pred)
                trues.extend(y.cpu().numpy())

        acc = accuracy_score(trues, preds)
        print(f"Val Accuracy: {acc:.4f}")

        if acc > best_acc:
            best_acc = acc
            best_epoch = epoch + 1
            torch.save(model.state_dict(), "sentimen_local_model.pth")
            print(f"   → Model terbaik disimpan (epoch {best_epoch}, acc {best_acc:.4f})")

    print("\n" + "="*60)
    print(f"Training selesai! Akurasi terbaik: {best_acc:.4f} pada epoch {best_epoch}")
    print("Model disimpan: sentimen_local_model.pth")

    # ── Tes Prediksi Langsung ──
    print("\n=== Tes Prediksi Manual (menggunakan model terakhir) ===")
    model.eval()

    # Contoh input dummy (price_change, rsi_norm, macd_hist_norm, atr_norm)
    # Nilai ini bisa diganti dengan data real dari MT5
    test_samples = [
        [ 0.0018, 0.78, 0.12, 0.0015],   # RSI tinggi + MACD positif → bullish
        [-0.0023, 0.28, -0.09, 0.0030],   # RSI rendah + MACD negatif → bearish
        [ 0.0002, 0.52, 0.01, 0.0008]     # Hampir netral
    ]

    labels = ["Bearish", "Neutral", "Bullish"]

    for i, sample in enumerate(test_samples, 1):
        sample_tensor = torch.tensor([sample], dtype=torch.float32).to(device)
        with torch.no_grad():
            output = model(sample_tensor)
            pred = output.argmax(dim=1).item()
            prob = torch.softmax(output, dim=1)[0].cpu().numpy()

        print(f"Sampel {i}:")
        print(f"  Prediksi       : {labels[pred]}")
        print(f"  Probabilitas   : Bearish {prob[0]:5.1%} | Neutral {prob[1]:5.1%} | Bullish {prob[2]:5.1%}")
        print(f"  Input fitur    : {sample}")
        print("-"*60)

    # ── Export ke ONNX (untuk MQL5) ──
    print("\nMengekspor model ke ONNX...")
    dummy_input = torch.randn(1, 4, device=device)
    torch.onnx.export(
        model,
        dummy_input,
        "sentimen_local.onnx",
        export_params=True,
        opset_version=14,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}}
    )
    print("Model berhasil diekspor ke: sentimen_local.onnx")
    print("Sekarang bisa digunakan di MQL5 dengan OnnxCreate()")

if __name__ == "__main__":
    train_model()