# This file is part of astro_metadata_translator.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (http://www.lsst.org).
# See the LICENSE file at the top-level directory of this distribution
# for details of code ownership.
#
# Use of this source code is governed by a 3-clause BSD-style
# license that can be found in the LICENSE file.

"""Properties calculated by this package.

Defines all properties in one place so that both `ObservationInfo` and
`MetadataTranslator` can use them.  In particular, the translator
base class can use knowledge of these properties to predefine translation
stubs with documentation attached, and `ObservationInfo` can automatically
define the getter methods.
"""

from __future__ import annotations

__all__ = (
    "PROPERTIES",
    "PropertyDefinition",
)

from collections.abc import Callable
from typing import Any, Protocol, SupportsFloat

import astropy.coordinates
import astropy.time
import astropy.units
import numpy as np

# Helper functions to convert complex types to simple form suitable
# for JSON serialization
# All take the complex type and return simple python form using str, float,
# int, dict, or list.
# All assume the supplied parameter is not None.


class _ToValueProtocol(Protocol):
    """Protocol for Quantity-like class that has to_value method."""

    def to_value(self, unit: astropy.units.UnitBase | None = None) -> SupportsFloat | np.ndarray:
        """Return converted value that might be ndarray or a single number.

        Parameters
        ----------
        unit : `astropy.units.UnitBase` or `None`, optional
            Optional unit to use when converting the values to floats.
        """
        ...


def _quantity_to_float(q: _ToValueProtocol, unit: astropy.units.UnitBase | None = None) -> float:
    """Convert a quantity to a float, in a type safe manner, returning
    a single float.

    Parameters
    ----------
    q : `_ToValueProtocol`
        The Astropy object to extract the float value from. Must support a
        ``to_value()`` method.
    unit : `astropy.units.UnitBase` or `None`, optional
        Optional unit to use when converting the values to floats.

    Returns
    -------
    value : `float`
        Single float corresponding to the quantity-like input.
    """
    # Quantity.to_value is typed to return np.ndarray or a scalar-like value
    # that supports float conversion.
    # We only went a single float and it is an error to return multiples.
    values = q.to_value(unit=unit)
    if isinstance(values, np.ndarray):
        raise ValueError(
            f"Converting quantity to a float failed because unexpectedly got more than one float: {values}"
        )
    return float(values)


def earthlocation_to_simple(location: astropy.coordinates.EarthLocation) -> tuple[float, ...]:
    """Convert EarthLocation to tuple.

    Parameters
    ----------
    location : `astropy.coordinates.EarthLocation`
        The location to simplify.

    Returns
    -------
    geocentric : `tuple` of (`float`, `float`, `float`)
        The geocentric location as three floats in meters.
    """
    geocentric = location.to_geocentric()
    return tuple(_quantity_to_float(c, astropy.units.m) for c in geocentric)


def simple_to_earthlocation(simple: tuple[float, ...], **kwargs: Any) -> astropy.coordinates.EarthLocation:
    """Convert simple form back to EarthLocation.

    Parameters
    ----------
    simple : `tuple` [`float`, ...]
        The geocentric location as three floats in meters.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    loc : `astropy.coordinates.EarthLocation`
        The location on the Earth.
    """
    return astropy.coordinates.EarthLocation.from_geocentric(*simple, unit=astropy.units.m)


def datetime_to_simple(datetime: astropy.time.Time) -> tuple[float, float]:
    """Convert Time to tuple.

    Parameters
    ----------
    datetime : `astropy.time.Time`
        The time to simplify.

    Returns
    -------
    mjds : `tuple` of (`float`, `float`)
        The two MJDs in TAI.
    """
    tai = datetime.tai
    return (tai.jd1, tai.jd2)


def simple_to_datetime(simple: tuple[float, float], **kwargs: Any) -> astropy.time.Time:
    """Convert simple form back to `astropy.time.Time`.

    Parameters
    ----------
    simple : `tuple` [`float`, `float`]
        The time represented by two MJDs.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    t : `astropy.time.Time`
        An astropy time object.
    """
    return astropy.time.Time(simple[0], val2=simple[1], format="jd", scale="tai")


def exptime_to_simple(exptime: astropy.units.Quantity) -> float:
    """Convert exposure time Quantity to seconds.

    Parameters
    ----------
    exptime : `astropy.units.Quantity`
        The exposure time as a quantity.

    Returns
    -------
    e : `float`
        Exposure time in seconds.
    """
    return _quantity_to_float(exptime, astropy.units.s)


def simple_to_exptime(simple: float, **kwargs: Any) -> astropy.units.Quantity:
    """Convert simple form back to Quantity.

    Parameters
    ----------
    simple : `float`
        Exposure time in seconds.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    q : `astropy.units.Quantity`
        The exposure time as a quantity.
    """
    return simple * astropy.units.s


def angle_to_simple(angle: astropy.coordinates.Angle) -> float:
    """Convert Angle to degrees.

    Parameters
    ----------
    angle : `astropy.coordinates.Angle`
        The angle.

    Returns
    -------
    a : `float`
        The angle in degrees.
    """
    return _quantity_to_float(angle, astropy.units.deg)


def simple_to_angle(simple: float, **kwargs: Any) -> astropy.coordinates.Angle:
    """Convert degrees to Angle.

    Parameters
    ----------
    simple : `float`
        The angle in degrees.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    a : `astropy.coordinates.Angle`
        The angle as an object.
    """
    # Quantity of 45. deg is not the same as Angle.
    if isinstance(simple, astropy.units.Quantity):
        angle = simple
    else:
        angle = simple * astropy.units.deg
    return astropy.coordinates.Angle(angle)


def focusz_to_simple(focusz: astropy.units.Quantity) -> float:
    """Convert focusz to meters.

    Parameters
    ----------
    focusz : `astropy.units.Quantity`
        The z-focus as a quantity.

    Returns
    -------
    f : `float`
        The z-focus in meters.
    """
    return _quantity_to_float(focusz, astropy.units.m)


def simple_to_focusz(simple: float, **kwargs: Any) -> astropy.units.Quantity:
    """Convert simple form back to Quantity.

    Parameters
    ----------
    simple : `float`
        The z-focus in meters.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    q : `astropy.units.Quantity`
        The z-focus as a quantity.
    """
    return simple * astropy.units.m


def temperature_to_simple(temp: astropy.units.Quantity) -> float:
    """Convert temperature to kelvin.

    Parameters
    ----------
    temp : `astropy.units.Quantity`
        The temperature as a quantity.

    Returns
    -------
    t : `float`
        The temperature in kelvin.
    """
    q = temp.to(astropy.units.K, equivalencies=astropy.units.temperature())
    return _quantity_to_float(q)


def simple_to_temperature(simple: float, **kwargs: Any) -> astropy.units.Quantity:
    """Convert scalar kelvin value back to quantity.

    Parameters
    ----------
    simple : `float`
        Temperature as a float in units of kelvin.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    q : `astropy.units.Quantity`
        The temperature as a quantity.
    """
    return simple * astropy.units.K


def pressure_to_simple(press: astropy.units.Quantity) -> float:
    """Convert pressure Quantity to hPa.

    Parameters
    ----------
    press : `astropy.units.Quantity`
        The pressure as a quantity.

    Returns
    -------
    hpa : `float`
        The pressure in units of hPa.
    """
    return _quantity_to_float(press, astropy.units.hPa)


def simple_to_pressure(simple: float, **kwargs: Any) -> astropy.units.Quantity:
    """Convert the pressure scalar back to Quantity.

    Parameters
    ----------
    simple : `float`
        Pressure in units of hPa.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    q : `astropy.units.Quantity`
        The pressure as a quantity.
    """
    return simple * astropy.units.hPa


def skycoord_to_simple(skycoord: astropy.coordinates.SkyCoord) -> tuple[float, float]:
    """Convert SkyCoord to ICRS RA/Dec tuple.

    Parameters
    ----------
    skycoord : `astropy.coordinates.SkyCoord`
        Sky coordinates in astropy form.

    Returns
    -------
    simple : `tuple` [`float`, `float`]
        Sky coordinates as a tuple of two floats in units of degrees.
    """
    icrs = skycoord.icrs
    if not isinstance(icrs, astropy.coordinates.SkyCoord):
        raise ValueError(f"Could not extract ICRS coordinates from SkyCoord {skycoord}")
    ra = icrs.ra
    assert isinstance(ra, astropy.coordinates.Longitude)
    dec = icrs.dec
    assert isinstance(dec, astropy.coordinates.Latitude)
    return (_quantity_to_float(ra, astropy.units.deg), _quantity_to_float(dec, astropy.units.deg))


def simple_to_skycoord(simple: tuple[float, float], **kwargs: Any) -> astropy.coordinates.SkyCoord:
    """Convert ICRS tuple to SkyCoord.

    Parameters
    ----------
    simple : `tuple` [`float`, `float`]
        Sky coordinates in degrees.
    **kwargs : `typing.Any`
        Keyword arguments. Currently not used.

    Returns
    -------
    skycoord : `astropy.coordinates.SkyCoord`
        The sky coordinates in astropy form.
    """
    return astropy.coordinates.SkyCoord(*simple, unit=astropy.units.deg)


def altaz_to_simple(altaz: astropy.coordinates.AltAz) -> tuple[float, float]:
    """Convert AltAz to Alt/Az tuple.

    Do not include obstime or location in simplification. It is assumed
    that those will be present from other properties.

    Parameters
    ----------
    altaz : `astropy.coordinates.AltAz`
        The alt/az in astropy form.

    Returns
    -------
    simple : `tuple` [`float`, `float`]
        The Alt/Az as a tuple of two floats representing the position in
        units of degrees.
    """
    return (_quantity_to_float(altaz.az, astropy.units.deg), _quantity_to_float(altaz.alt, astropy.units.deg))


def simple_to_altaz(simple: tuple[float, float], **kwargs: Any) -> astropy.coordinates.AltAz:
    """Convert simple altaz tuple to AltAz.

    Parameters
    ----------
    simple : `tuple` [`float`, `float`]
        Altitude and elevation in degrees.
    **kwargs : `dict`
        Additional information. Must contain ``location`` and
        ``datetime_begin``.

    Returns
    -------
    altaz : `astropy.coordinates.AltAz`
        The altaz in astropy form.
    """
    # Sometimes we get given a SkyCoord that contains an AltAz frame that needs
    # to be extracted.
    if isinstance(simple, astropy.coordinates.SkyCoord):
        frame = simple.frame
        if isinstance(frame, astropy.coordinates.AltAz):
            return frame
        # If there is no AltAz frame, return what we have so that downstream
        # validation can fail.
        return simple

    location = kwargs.get("location")
    obstime = kwargs.get("datetime_begin")

    return astropy.coordinates.AltAz(
        simple[0] * astropy.units.deg, simple[1] * astropy.units.deg, obstime=obstime, location=location
    )


def timedelta_to_simple(delta: astropy.time.TimeDelta) -> int:
    """Convert a TimeDelta to integer seconds.

    This property does not need to support floating point seconds.

    Parameters
    ----------
    delta : `astropy.time.TimeDelta`
        The time offset.

    Returns
    -------
    sec : `int`
        Offset in integer seconds.
    """
    return round(_quantity_to_float(delta, astropy.units.s))


def simple_to_timedelta(simple: int, **kwargs: Any) -> astropy.time.TimeDelta:
    """Convert integer seconds to a `~astropy.time.TimeDelta`.

    Parameters
    ----------
    simple : `int`
        The offset in integer seconds.
    **kwargs : `dict`
        Additional information. Unused.

    Returns
    -------
    delta : `astropy.time.TimeDelta`
        The delta object.
    """
    return astropy.time.TimeDelta(simple, format="sec", scale="tai")


class PropertyDefinition:
    """Definition of an instrumental property.

    Supports both signatures:

    - ``(doc, py_type, to_simple=None, from_simple=None)``
    - ``(doc, legacy_str_type, py_type, to_simple=None, from_simple=None)``

    Modern preference is to not specify the string type since that can be
    derived directly from the python type.

    Parameters
    ----------
    doc : `str`
        Documentation string for the property.
    *args : `typing.Any`
        Remaining constructor arguments in one of the supported
        signatures.
    """

    __slots__ = ("doc", "py_type", "to_simple", "from_simple")

    doc: str
    py_type: type
    to_simple: Callable[[Any], Any] | None
    from_simple: Callable[[Any], Any] | None

    def __init__(self, doc: str, *args: Any) -> None:
        if not args:
            raise TypeError("PropertyDefinition requires at least a py_type argument")

        if isinstance(args[0], str):
            if len(args) < 2 or not isinstance(args[1], type):
                raise TypeError("Legacy PropertyDefinition signature requires (doc, str_type, py_type, ...)")
            py_type = args[1]
            rest = args[2:]
        else:
            if not isinstance(args[0], type):
                raise TypeError("PropertyDefinition py_type must be a type")
            py_type = args[0]
            rest = args[1:]

        if len(rest) > 2:
            raise TypeError("PropertyDefinition accepts at most two converter callables")

        to_simple: Callable[[Any], Any] | None = rest[0] if rest else None
        from_simple: Callable[[Any], Any] | None = rest[1] if len(rest) > 1 else None

        self.doc = doc
        self.py_type = py_type
        self.to_simple = to_simple
        self.from_simple = from_simple

    @property
    def str_type(self) -> str:
        """Python type of property as a string suitable for messages/docs."""
        if self.py_type.__module__ == "builtins":
            return self.py_type.__name__
        return f"{self.py_type.__module__}.{self.py_type.__qualname__}"

    def is_value_conformant(self, value: Any) -> bool:
        """Compare the supplied value against the expected type as defined
        for this property.

        Parameters
        ----------
        value : `object`
            Value of the property to validate. Can be `None`.

        Returns
        -------
        is_ok : `bool`
            `True` if the value is of an appropriate type.

        Notes
        -----
        Currently only the type of the property is validated. There is no
        attempt to check bounds or determine that a Quantity is compatible
        with the property.
        """
        if value is None:
            return True

        return isinstance(value, self.py_type)


# This dict defines all the core properties of an ObservationInfo.
# The PropertyDefinition is keyed by the property name.
# The doc string is used to define the Pydantic model.
# The py_type/doc are used to create the translator methods.
# The optional callables are used to convert types for serialization and
# validation.
PROPERTIES = {
    "telescope": PropertyDefinition("Full name of the telescope.", str),
    "instrument": PropertyDefinition("The instrument used to observe the exposure.", str),
    "location": PropertyDefinition(
        "Location of the observatory.",
        astropy.coordinates.EarthLocation,
        earthlocation_to_simple,
        simple_to_earthlocation,
    ),
    "exposure_id": PropertyDefinition(
        "Unique (with instrument) integer identifier for this observation.", int
    ),
    "visit_id": PropertyDefinition(
        """ID of the Visit this Exposure is associated with.

Science observations should essentially always be
associated with a visit, but calibration observations
may not be.""",
        int,
    ),
    "physical_filter": PropertyDefinition("The bandpass filter used for this observation.", str),
    "datetime_begin": PropertyDefinition(
        "Time of the start of the observation.",
        astropy.time.Time,
        datetime_to_simple,
        simple_to_datetime,
    ),
    "datetime_end": PropertyDefinition(
        "Time of the end of the observation.",
        astropy.time.Time,
        datetime_to_simple,
        simple_to_datetime,
    ),
    "exposure_time": PropertyDefinition(
        "Actual duration of the exposure (seconds).",
        astropy.units.Quantity,
        exptime_to_simple,
        simple_to_exptime,
    ),
    "exposure_time_requested": PropertyDefinition(
        "Requested duration of the exposure (seconds).",
        astropy.units.Quantity,
        exptime_to_simple,
        simple_to_exptime,
    ),
    "dark_time": PropertyDefinition(
        "Duration of the exposure with shutter closed (seconds).",
        astropy.units.Quantity,
        exptime_to_simple,
        simple_to_exptime,
    ),
    "boresight_airmass": PropertyDefinition("Airmass of the boresight of the telescope.", float),
    "boresight_rotation_angle": PropertyDefinition(
        "Angle of the instrument in boresight_rotation_coord frame.",
        astropy.coordinates.Angle,
        angle_to_simple,
        simple_to_angle,
    ),
    "boresight_rotation_coord": PropertyDefinition(
        "Coordinate frame of the instrument rotation angle (options: sky, unknown).",
        str,
    ),
    "detector_num": PropertyDefinition("Unique (for instrument) integer identifier for the sensor.", int),
    "detector_name": PropertyDefinition(
        "Name of the detector within the instrument (might not be unique if there are detector groups).",
        str,
    ),
    "detector_unique_name": PropertyDefinition(
        (
            "Unique name of the detector within the focal plane, generally combining detector_group with "
            "detector_name."
        ),
        str,
    ),
    "detector_serial": PropertyDefinition("Serial number/string associated with this detector.", str),
    "detector_group": PropertyDefinition(
        "Collection name of which this detector is a part. Can be None if there are no detector groupings.",
        str,
    ),
    "detector_exposure_id": PropertyDefinition(
        "Unique integer identifier for this detector in this exposure.",
        int,
    ),
    "focus_z": PropertyDefinition(
        "Defocal distance.",
        astropy.units.Quantity,
        focusz_to_simple,
        simple_to_focusz,
    ),
    "object": PropertyDefinition("Object of interest or field name.", str),
    "temperature": PropertyDefinition(
        "Temperature outside the dome.",
        astropy.units.Quantity,
        temperature_to_simple,
        simple_to_temperature,
    ),
    "pressure": PropertyDefinition(
        "Atmospheric pressure outside the dome.",
        astropy.units.Quantity,
        pressure_to_simple,
        simple_to_pressure,
    ),
    "relative_humidity": PropertyDefinition("Relative humidity outside the dome.", float),
    "tracking_radec": PropertyDefinition(
        "Requested RA/Dec to track.",
        astropy.coordinates.SkyCoord,
        skycoord_to_simple,
        simple_to_skycoord,
    ),
    "altaz_begin": PropertyDefinition(
        "Telescope boresight azimuth and elevation at start of observation.",
        astropy.coordinates.AltAz,
        altaz_to_simple,
        simple_to_altaz,
    ),
    "altaz_end": PropertyDefinition(
        "Telescope boresight azimuth and elevation at end of observation.",
        astropy.coordinates.AltAz,
        altaz_to_simple,
        simple_to_altaz,
    ),
    "science_program": PropertyDefinition("Observing program (survey or proposal) identifier.", str),
    "observation_type": PropertyDefinition(
        "Type of observation (currently: science, dark, flat, bias, focus).",
        str,
    ),
    "observation_id": PropertyDefinition(
        "Label uniquely identifying this observation (can be related to 'exposure_id').",
        str,
    ),
    "observation_reason": PropertyDefinition(
        "Reason this observation was taken, or its purpose ('science' and 'calibration' are common values)",
        str,
    ),
    "exposure_group": PropertyDefinition(
        "Label to use to associate this exposure with others (can be related to 'exposure_id').",
        str,
    ),
    "observing_day": PropertyDefinition(
        "Integer in YYYYMMDD format corresponding to the day of observation.", int
    ),
    "observing_day_offset": PropertyDefinition(
        (
            "Offset to subtract from an observation date when calculating the observing day. "
            "Conversely, the offset to add to an observing day when calculating the time span of a day."
        ),
        astropy.time.TimeDelta,
        timedelta_to_simple,
        simple_to_timedelta,
    ),
    "observation_counter": PropertyDefinition(
        (
            "Counter of this observation. Can be counter within observing_day or a global counter. "
            "Likely to be observatory specific."
        ),
        int,
    ),
    "has_simulated_content": PropertyDefinition(
        "Boolean indicating whether any part of this observation was simulated.", bool, None, None
    ),
    "group_counter_start": PropertyDefinition(
        "Observation counter for the start of the exposure group."
        "Depending on the instrument the relevant group may be "
        "visit_id or exposure_group.",
        int,
        None,
        None,
    ),
    "group_counter_end": PropertyDefinition(
        "Observation counter for the end of the exposure group. "
        "Depending on the instrument the relevant group may be "
        "visit_id or exposure_group.",
        int,
        None,
        None,
    ),
    "can_see_sky": PropertyDefinition(
        "True if the observation is looking at sky, False if it is definitely"
        " not looking at the sky. None indicates that it is not known whether"
        " sky could be seen.",
        bool,
    ),
}
