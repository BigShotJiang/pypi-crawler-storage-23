import asyncio
from langchain_ollama import ChatOllama
from langchain_openai import ChatOpenAI
import re
import logging

from lxf.ai.agents.guard_rail import RESPONSE_RULES, SECURITY_RULES 

SETLEVEL = logging.DEBUG
logger = logging.getLogger('AI Interviewer')
fh = logging.FileHandler('./logs/pylexfluent.log')
fh.setLevel(SETLEVEL)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.setLevel(SETLEVEL)
logger.addHandler(fh)

AI_TIMEOUT=180
AI_RETRIES=1


class Interviewer():
    """
    Docstring for Interviewer
    """
    def __init__(self,
                 model:str="gpt-oss", 
                 base_url:str="http://localhost/11434",
                 ctx:int=4096,
                 role:str="Tu es un assistant français",
                 openapi_compatibility:bool=False, api_key:str="123" ):
        """
        Docstring for __init__
        
        :param self: Description
        :param model: Model LLM 
        :type model: str
        :param base_url: URL du serveur OLLAMA
        :type base_url: str
        :param ctx: Taille du contexte (défaut 4096 o)
        :type ctx: int
        """
        self.system_prompt=f"""

        # ROLE
        {role}

        {SECURITY_RULES}    

        {RESPONSE_RULES}

        """
        if openapi_compatibility : 
            self.llm = ChatOpenAI(
                model=model,
                temperature=0,
                max_completion_tokens=ctx,
                base_url=base_url,
                api_key=api_key,
            )
        else :
            
            self.llm = ChatOllama(
                model=model,
                temperature=0,
                num_ctx=ctx,
                base_url=base_url,
                validate_model_on_init=True,                
                # other params...
            )
        
    def invoke(self,libelle:str,user_prompt:str, max_retries=AI_RETRIES, timeout=AI_TIMEOUT)->str :
        """
        """
        asyncio.run(self.invoke_async(libelle,user_prompt=user_prompt,max_retries=max_retries,timeout=timeout))

    async def invoke_async(self,libelle:str,user_prompt:str,max_retries=AI_RETRIES,timeout=AI_TIMEOUT)->tuple[int,str] :
        """
        """
        messages = [
            ("system",self.system_prompt),
            ("human",user_prompt)
        ]
        try:
                # On fixe la limite à timeout secondes (5 minutes par défaut)
                ai_response = await asyncio.wait_for(
                    self.llm.ainvoke(messages), 
                    timeout=timeout
                )
                if ai_response : 
                    return 0,ai_response.content
                logger.error(f"{libelle}: La question n'a reçu aucune réponse. ")
                return -1,"Aucune réponse"            
        except asyncio.TimeoutError:
                logger.warning(f"{libelle}: La requete a mis trop de temps, elle a ete annulee.")
                if max_retries>0 : 
                    max_retries-=1 
                    logger.warning(f"{libelle}: Une nouvelle tentative va etre effectuee...")
                    return await self.invoke_async(libelle,user_prompt=user_prompt, max_retries=max_retries,timeout=timeout)
                else :                
                    # Ici, vous pouvez logger l'erreur ou déclencher votre logique de retry
                    logger.error(f"{libelle}: Aucune tentative n'a reussie.")
                    return -10, "La requete a mis trop de temps. Aucune tentative n'a reussie."        
        except Exception as ex:
             logger.critical(f"Connexion impossible à l'agent IA. Raison :{ex}")
