import os
import logging
import random
from lxf.settings import get_logging_level

#logger
logger = logging.getLogger('PDF_UTILITies ')
fh = logging.FileHandler('./logs/pdf_utilities.log')
fh.setLevel(get_logging_level())
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.setLevel(get_logging_level())
logger.addHandler(fh)


import cv2
from pdf2image import convert_from_path, convert_from_bytes
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)
import img2pdf

import glob

def empty_folder(path:str) :
    files = glob.glob(path)
    for f in files:
        os.remove(f)

def remove_highligth(source:str, target:str)-> tuple[int,str] :
    """
    Docstring for remove highligh from images of PDF and return a PDF images with the b&w converted images 
    
    :param source: Description
    :type source: str
    :param target: Description
    :type target: str
    :return: Description
    :rtype: tuple[int, str]
    """
    if os.path.exists(source) is False :
        return -1 , f"{source} est introuvable"
    
    
    images = convert_from_path(source)
    if images == None : 
        return -2 , f"Aucune image extraite du fichier {source}"
    if os.path.exists("./data/temp") is False : 
        os.makedirs("./data/temp")        
    imgs=[]
    # on récupère un identifiant indépendant pour traiter la concurrence des appels 
    rd=random.randint(1,1000)    
    for i in range(len(images)):    
    ## Save image to file
            img_path=f"./data/temp/{rd}_page_{i}.jpeg"
            images[i].save(img_path,'JPEG')          
            image = cv2.imread(img_path)
            # Convert to Gray
            gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)            
            gray_path= f"./data/temp/{rd}_gray_page_{i}.png"
            cv2.imwrite(gray_path,gray)
            # display(gray_path)
            min=155
            max=255
            source=gray
            thresh, img_bw = cv2.threshold(source,min,max,cv2.THRESH_BINARY)
            black_white_path =f"./data/temp/{rd}_bw_page{i}.png"
            cv2.imwrite(black_white_path, img_bw)
            #display(black_white_path)
            imgs.append(black_white_path)            
            os.remove(img_path)
    logger.info(f"Fichier {source} - HighLight traite")    
    # Save all converted images in a pdf
    # opening from filename
    # specify paper size (A4)
    a4inpt = (img2pdf.mm_to_pt(210),img2pdf.mm_to_pt(297))
    layout_A4 = img2pdf.get_layout_fun(a4inpt)
    with open(target,"wb+") as f:
        f.write(img2pdf.convert(imgs,layout_fun=layout_A4))
    # remove all tempory file
    empty_folder(f"./data/temp/{rd}_*.png")
    if os.path.exists(target) is True :
        return 0, target
    return -3, f"Le fichier {target} n'a pu être créé"

def remove_header_footer(source:str,target:str)->tuple[int,str] :
    """
    Docstring for remove_header_footer
    
    :param source: Description
    :type source: str
    :param target: Description
    :type target: str
    :return: Description
    :rtype: tuple[int, str]
    """
    if os.path.exists(source) is False :
        return -1 , f"{source} est introuvable"
    
    images = convert_from_path(source)
    if images == None : 
        return -2 , f"Aucune image extraite du fichier {source}"
    if os.path.exists("./data/temp") is False : 
        os.makedirs("./data/temp")
        
    imgs=[]
    # on récupère un identifiant indépendant pour traiter la concurrence des appels 
    rd=random.randint(1,1000)      
    for i in range(len(images)): 
            img_path=f"./data/temp/{rd}_page_{i}.jpeg"
            images[i].save(img_path,'JPEG')          
            image = cv2.imread(img_path)        
            # Convert to Gray
            gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY) 
            # blur the image
            kernel_blur_size:any=(55,5)
            blur = cv2.GaussianBlur(gray,kernel_blur_size,0)
            # invert the image 
            thresh=cv2.threshold(blur,150,250,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
            # Dilate
            kernel_dilated_size:any=(55,10)
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT,kernel_dilated_size)
            dilate = cv2.dilate(thresh, kernel, iterations=1)
            # find header and footer
            cnts = cv2.findContours(dilate,cv2.RETR_LIST,cv2.CHAIN_APPROX_TC89_KCOS)
            cnts = cnts[0] if len(cnts)==2 else cnts[1]
            for i,cnt in enumerate(cnts):
                x,y,w,h =cv2.boundingRect(cnt)
                if (y<=200 or y>=2000 )and w > 300 :
                    logger.debug(i,x,y,w,h)
                    logger.info(f"Fichier : {source} - footer/Header trouve")
                    cv2.rectangle(image,(x,y),(x+w,y+h),(255,255,255),-1)
            final_image_path =f"./data/temp/{rd}_proceeded_page{i}.png"
            cv2.imwrite(final_image_path,image)
            imgs.append(final_image_path)
            os.remove(img_path)
    # Save all converted images in a pdf
    # opening from filename
    # specify paper size (A4)
    a4inpt = (img2pdf.mm_to_pt(210),img2pdf.mm_to_pt(297))
    layout_A4 = img2pdf.get_layout_fun(a4inpt)
    with open(target,"wb+") as f:
        f.write(img2pdf.convert(imgs,layout_fun=layout_A4))
    # remove all tempory file
    empty_folder(f"./data/temp/{rd}_*.png")
    if os.path.exists(target) is True :
        return 0, target
    return -3, f"Le fichier {target} n'a pu être créé"            
            
