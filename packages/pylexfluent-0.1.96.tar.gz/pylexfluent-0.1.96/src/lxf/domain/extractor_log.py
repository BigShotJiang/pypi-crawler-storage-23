
from pydantic import BaseModel, Field


LOG_SEVERITY_WARNING="WARNING"
LOG_SEVERITY_ERROR="ERROR"
LOG_SEVERITY_CRITICAL="CRITICAL"
    
class Log(BaseModel):
    """
    Docstring for Log
    """
    severity:str = Field(default=LOG_SEVERITY_ERROR)
    title:str=Field("Erreur")
    message:str=Field("Une erreur est apparue")
        