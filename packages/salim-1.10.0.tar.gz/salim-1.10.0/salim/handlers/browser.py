"""
Salim Browser Automation — remote-control your laptop's browser via Telegram.

Commands:
  /browse <url>                   — open URL, take full-page screenshot, send to Telegram
  /browse_click <selector>        — click an element (CSS selector or text)
  /browse_type <selector> <text>  — type text into an input field
  /browse_scroll <up|down|N>      — scroll the page
  /browse_back                    — navigate back
  /browse_close                   — close browser session
  /browse_js <javascript>         — run JavaScript in the browser page
  /browse_get <url>               — fetch page as raw text/HTML (no screenshot)

Uses Playwright (playwright-python) — fully open source, no API key needed.
Browser: Chromium (auto-downloaded by Playwright on first use, ~200MB).

Auto-installs:
  - playwright (pip)
  - chromium (playwright install chromium)

Why Playwright over Selenium:
  - Built-in async support
  - Automatically downloads browser binaries
  - Better headless support
  - Built-in screenshot API (no separate tool needed)
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.browser")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

# Per-chat browser session: chat_id → {browser, page, context}
_sessions: dict[int, dict] = {}

SCREENSHOT_QUALITY = 85
PAGE_TIMEOUT_MS    = 30_000   # 30s page load timeout
FULL_PAGE_MAX_KB   = 8_000    # if screenshot > 8MB, downscale


# ── Dependency management ─────────────────────────────────────────────────────

def _ensure_playwright() -> tuple[bool, str]:
    """
    Install playwright Python package + download Chromium browser.
    Returns (success, error_message).
    This is called once — cached browser binaries are reused.
    """
    # Check if playwright is importable
    try:
        from playwright.async_api import async_playwright  # noqa
        # Playwright is installed, check if Chromium is available
        chromium_ok = _check_chromium()
        if not chromium_ok:
            return _install_chromium()
        return True, ""
    except ImportError:
        pass

    # Install playwright package
    logger.info("Installing playwright...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "playwright", "--quiet"],
            capture_output=True, text=True, timeout=180
        )
        if result.returncode != 0:
            return False, f"pip install playwright failed: {result.stderr[:300]}"
    except Exception as e:
        return False, f"Failed to install playwright: {e}"

    # Now install Chromium
    return _install_chromium()


def _check_chromium() -> bool:
    """Check if Playwright's Chromium is already downloaded."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "--dry-run", "chromium"],
            capture_output=True, text=True, timeout=10
        )
        # If output says "already installed" or returns 0 with no download needed
        return "chromium" in result.stdout.lower() or result.returncode == 0
    except Exception:
        # Just try to install if unsure
        return False


def _install_chromium() -> tuple[bool, str]:
    """Download Playwright's Chromium binary (~200MB, cached after first run)."""
    logger.info("Installing Playwright Chromium (~200MB, one-time download)...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            capture_output=True, text=True, timeout=300  # 5 min for download
        )
        if result.returncode != 0:
            return False, f"playwright install chromium failed: {result.stderr[:300]}"
        return True, ""
    except subprocess.TimeoutExpired:
        return False, "Chromium download timed out (>5min). Check your connection and try again."
    except Exception as e:
        return False, str(e)


# ── Session management ────────────────────────────────────────────────────────

async def _get_or_create_session(chat_id: int) -> dict:
    """Get existing browser session or create a new one."""
    if chat_id in _sessions:
        sess = _sessions[chat_id]
        # Verify session is still alive
        try:
            _ = sess["page"].url  # will throw if page is closed
            return sess
        except Exception:
            # Session is dead, clean up
            await _close_session(chat_id)

    from playwright.async_api import async_playwright
    pw = await async_playwright().__aenter__()
    browser = await pw.chromium.launch(
        headless=True,
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--disable-extensions",
        ]
    )
    context = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        user_agent=(
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        )
    )
    page = await context.new_page()

    # Set timeouts
    page.set_default_navigation_timeout(PAGE_TIMEOUT_MS)
    page.set_default_timeout(15_000)

    sess = {"pw": pw, "browser": browser, "context": context, "page": page}
    _sessions[chat_id] = sess
    return sess


async def _close_session(chat_id: int):
    """Close and clean up a browser session."""
    sess = _sessions.pop(chat_id, None)
    if not sess:
        return
    try:
        await sess["browser"].close()
    except Exception:
        pass
    try:
        await sess["pw"].__aexit__(None, None, None)
    except Exception:
        pass


async def _screenshot_page(page) -> bytes:
    """Take a full-page screenshot, return JPEG bytes."""
    # Take screenshot as PNG first
    png_bytes = await page.screenshot(
        full_page=True,
        type="png",
    )

    # Convert PNG → JPEG (smaller) using PIL if available
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(png_bytes))
        # Cap height to avoid massive screenshots (infinite-scroll pages)
        max_height = 6000
        if img.height > max_height:
            ratio = max_height / img.height
            new_w = int(img.width * ratio)
            img = img.resize((new_w, max_height), Image.LANCZOS)

        out = io.BytesIO()
        img.convert("RGB").save(out, format="JPEG", quality=SCREENSHOT_QUALITY, optimize=True)
        return out.getvalue()
    except ImportError:
        # Return PNG as-is
        return png_bytes


def _normalize_url(url: str) -> str:
    """Ensure URL has a scheme."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


# ── Handler class ─────────────────────────────────────────────────────────────

class BrowserHandlers:
    """Mixin for Playwright-based browser automation commands."""

    async def _browser_ensure_ready(self, msg) -> bool:
        """Check deps and report error if not ready. Returns True if ready."""
        ok, err = await asyncio.get_event_loop().run_in_executor(
            None, _ensure_playwright
        )
        if not ok:
            await msg.reply_text(
                f"❌ <b>Browser setup failed</b>\n\n"
                f"<code>{esc(err)}</code>\n\n"
                f"Try manually: <code>pip install playwright && python -m playwright install chromium</code>",
                parse_mode=H
            )
            return False
        return True

    @require_auth
    async def cmd_browse(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse <url>  — Open URL, screenshot, send.
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "🌐 <b>Browser</b>\n\n"
                "Usage: <code>/browse &lt;url&gt;</code>\n\n"
                "Examples:\n"
                "<code>/browse google.com</code>\n"
                "<code>/browse https://github.com/trending</code>\n"
                "<code>/browse wikipedia.org/wiki/Python</code>\n\n"
                "Other commands:\n"
                "<code>/browse_click &lt;selector&gt;</code> — click element\n"
                "<code>/browse_type &lt;selector&gt; &lt;text&gt;</code> — type text\n"
                "<code>/browse_scroll down</code> — scroll\n"
                "<code>/browse_js &lt;javascript&gt;</code> — run JS\n"
                "<code>/browse_close</code> — close browser",
                parse_mode=H
            )
            return

        url = _normalize_url(" ".join(ctx.args))
        status = await msg.reply_text(
            f"🌐 <i>Opening {esc(url[:80])}...</i>", parse_mode=H
        )

        if not await self._browser_ensure_ready(msg):
            await status.delete()
            return

        chat_id = msg.chat_id
        try:
            sess = await _get_or_create_session(chat_id)
            page = sess["page"]

            await status.edit_text(
                f"🌐 <i>Loading {esc(url[:80])}...</i>", parse_mode=H
            )

            # Navigate with error handling
            try:
                response = await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=PAGE_TIMEOUT_MS
                )
                # Wait a bit for JS rendering
                await asyncio.sleep(1.5)
            except Exception as e:
                await status.edit_text(
                    f"❌ <b>Failed to load page</b>\n<code>{esc(str(e)[:300])}</code>",
                    parse_mode=H
                )
                return

            # Get page info
            title = await page.title()
            current_url = page.url
            http_status = response.status if response else "?"

            # Screenshot
            await status.edit_text("📸 <i>Taking screenshot...</i>", parse_mode=H)
            jpeg_bytes = await _screenshot_page(page)
            size_kb = len(jpeg_bytes) // 1024

            await status.delete()

            buf = io.BytesIO(jpeg_bytes)
            buf.name = "browser.jpg"

            await msg.reply_photo(
                photo=buf,
                caption=(
                    f"🌐 <b>{esc(title[:60])}</b>\n"
                    f"🔗 <code>{esc(current_url[:100])}</code>\n"
                    f"📊 HTTP {http_status} · 💾 {size_kb}KB\n"
                    f"🕐 {time.strftime('%H:%M:%S')}"
                ),
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("🔄 Refresh", callback_data=f"browse_refresh:{chat_id}"),
                        InlineKeyboardButton("⬅️ Back", callback_data=f"browse_back:{chat_id}"),
                        InlineKeyboardButton("❌ Close", callback_data=f"browse_close:{chat_id}"),
                    ]
                ])
            )

        except Exception as e:
            logger.error(f"browse error: {e}", exc_info=True)
            await status.edit_text(
                f"❌ Browser error: {esc(str(e)[:300])}", parse_mode=H
            )

    @require_auth
    async def cmd_browse_click(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse_click <selector>  — Click element by CSS selector or visible text.
        Examples:
          /browse_click button#submit
          /browse_click text=Sign In
          /browse_click .search-button
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/browse_click &lt;CSS selector or text=...&gt;</code>\n"
                "Examples:\n"
                "<code>/browse_click button</code>\n"
                "<code>/browse_click text=Login</code>\n"
                "<code>/browse_click #search-btn</code>",
                parse_mode=H
            )
            return

        if chat_id not in _sessions:
            await msg.reply_text(
                "❌ No active browser session.\nUse <code>/browse &lt;url&gt;</code> first.",
                parse_mode=H
            )
            return

        selector = " ".join(ctx.args)
        status = await msg.reply_text(
            f"🖱️ <i>Clicking: <code>{esc(selector[:80])}</code>...</i>", parse_mode=H
        )

        try:
            sess = _sessions[chat_id]
            page = sess["page"]

            # Try CSS selector first, then text matching
            try:
                await page.click(selector, timeout=5000)
            except Exception:
                # Try as visible text
                await page.get_by_text(selector).first.click(timeout=5000)

            await asyncio.sleep(1.0)  # Wait for page reaction

            # Screenshot result
            jpeg_bytes = await _screenshot_page(page)
            title = await page.title()
            current_url = page.url

            await status.delete()
            buf = io.BytesIO(jpeg_bytes)
            buf.name = "after_click.jpg"

            await msg.reply_photo(
                photo=buf,
                caption=(
                    f"🖱️ Clicked: <code>{esc(selector[:60])}</code>\n"
                    f"📄 {esc(title[:60])}\n"
                    f"🔗 <code>{esc(current_url[:80])}</code>"
                ),
                parse_mode=H
            )

        except Exception as e:
            await status.edit_text(
                f"❌ Click failed: <code>{esc(str(e)[:200])}</code>", parse_mode=H
            )

    @require_auth
    async def cmd_browse_type(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse_type <selector> <text>  — Type text into a field.
        Example: /browse_type input[name=q] hello world
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "Usage: <code>/browse_type &lt;selector&gt; &lt;text&gt;</code>\n"
                "Example: <code>/browse_type input[name=q] python tutorial</code>",
                parse_mode=H
            )
            return

        if chat_id not in _sessions:
            await msg.reply_text(
                "❌ No active browser session.\nUse <code>/browse &lt;url&gt;</code> first.",
                parse_mode=H
            )
            return

        selector = ctx.args[0]
        text = " ".join(ctx.args[1:])
        status = await msg.reply_text(
            f"⌨️ <i>Typing into <code>{esc(selector[:50])}</code>...</i>", parse_mode=H
        )

        try:
            sess = _sessions[chat_id]
            page = sess["page"]

            # Click the field first, clear it, then type
            await page.click(selector, timeout=5000)
            await page.fill(selector, text, timeout=5000)

            await asyncio.sleep(0.5)
            jpeg_bytes = await _screenshot_page(page)

            await status.delete()
            buf = io.BytesIO(jpeg_bytes)
            buf.name = "after_type.jpg"

            await msg.reply_photo(
                photo=buf,
                caption=f"⌨️ Typed into <code>{esc(selector[:50])}</code>: <i>{esc(text[:80])}</i>",
                parse_mode=H
            )

        except Exception as e:
            await status.edit_text(
                f"❌ Type failed: <code>{esc(str(e)[:200])}</code>", parse_mode=H
            )

    @require_auth
    async def cmd_browse_scroll(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse_scroll down       — scroll down one viewport
        /browse_scroll up         — scroll up
        /browse_scroll 500        — scroll by exact pixels
        /browse_scroll top        — scroll to top
        /browse_scroll bottom     — scroll to bottom
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id not in _sessions:
            await msg.reply_text(
                "❌ No browser session. Use <code>/browse &lt;url&gt;</code> first.",
                parse_mode=H
            )
            return

        direction = (ctx.args[0] if ctx.args else "down").lower()

        scroll_map = {
            "down":   "window.scrollBy(0, window.innerHeight)",
            "up":     "window.scrollBy(0, -window.innerHeight)",
            "top":    "window.scrollTo(0, 0)",
            "bottom": "window.scrollTo(0, document.body.scrollHeight)",
        }

        if direction in scroll_map:
            js = scroll_map[direction]
        else:
            try:
                pixels = int(direction)
                js = f"window.scrollBy(0, {pixels})"
                direction = f"{pixels}px"
            except ValueError:
                await msg.reply_text(
                    "Usage: <code>/browse_scroll [up|down|top|bottom|pixels]</code>",
                    parse_mode=H
                )
                return

        try:
            sess = _sessions[chat_id]
            page = sess["page"]
            await page.evaluate(js)
            await asyncio.sleep(0.5)

            jpeg_bytes = await _screenshot_page(page)
            buf = io.BytesIO(jpeg_bytes)
            buf.name = "after_scroll.jpg"
            await msg.reply_photo(
                photo=buf,
                caption=f"📜 Scrolled: {esc(direction)}"
            )

        except Exception as e:
            await msg.reply_text(
                f"❌ Scroll failed: {esc(str(e)[:200])}", parse_mode=H
            )

    @require_auth
    async def cmd_browse_js(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse_js <javascript>  — Execute JavaScript in the current page.
        Returns the JS return value as text.
        Example: /browse_js document.title
        Example: /browse_js document.querySelectorAll('a').length
        """
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/browse_js &lt;javascript&gt;</code>\n"
                "Examples:\n"
                "<code>/browse_js document.title</code>\n"
                "<code>/browse_js document.querySelectorAll('a').length</code>\n"
                "<code>/browse_js window.location.href</code>",
                parse_mode=H
            )
            return

        if chat_id not in _sessions:
            await msg.reply_text(
                "❌ No browser session. Use <code>/browse &lt;url&gt;</code> first.",
                parse_mode=H
            )
            return

        js_code = " ".join(ctx.args)

        try:
            sess = _sessions[chat_id]
            page = sess["page"]
            result = await page.evaluate(js_code)
            result_str = str(result)[:1000] if result is not None else "(null)"

            await msg.reply_text(
                f"🟨 <b>JS Result</b>\n"
                f"<code>{esc(js_code[:100])}</code>\n\n"
                f"<pre>{esc(result_str)}</pre>",
                parse_mode=H
            )
        except Exception as e:
            await msg.reply_text(
                f"❌ JS error: <code>{esc(str(e)[:300])}</code>", parse_mode=H
            )

    @require_auth
    async def cmd_browse_back(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/browse_back — Navigate back in browser history."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id not in _sessions:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        try:
            sess = _sessions[chat_id]
            page = sess["page"]
            await page.go_back(timeout=10000)
            await asyncio.sleep(1.0)

            jpeg_bytes = await _screenshot_page(page)
            title = await page.title()
            buf = io.BytesIO(jpeg_bytes)
            buf.name = "after_back.jpg"

            await msg.reply_photo(
                photo=buf,
                caption=f"⬅️ Back → <b>{esc(title[:60])}</b>",
                parse_mode=H
            )
        except Exception as e:
            await msg.reply_text(
                f"❌ Back failed: {esc(str(e)[:200])}", parse_mode=H
            )

    @require_auth
    async def cmd_browse_get(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse_get <url>  — Fetch page source/text without full rendering.
        Useful for APIs, plain text pages, fast content extraction.
        """
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/browse_get &lt;url&gt;</code>\n"
                "Returns the raw HTML/text of the page (no screenshot).",
                parse_mode=H
            )
            return

        url = _normalize_url(" ".join(ctx.args))
        status = await msg.reply_text(
            f"📥 <i>Fetching {esc(url[:60])}...</i>", parse_mode=H
        )

        if not await self._browser_ensure_ready(msg):
            await status.delete()
            return

        chat_id = msg.chat_id
        try:
            sess = await _get_or_create_session(chat_id)
            page = sess["page"]

            response = await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT_MS)
            content = await page.content()
            http_status = response.status if response else "?"

            # Try to extract readable text from HTML
            try:
                text_content = await page.evaluate(
                    "document.body ? document.body.innerText : document.documentElement.innerText"
                )
                # Clean up whitespace
                import re
                text_content = re.sub(r'\n{3,}', '\n\n', text_content.strip())
            except Exception:
                text_content = content

            preview = text_content[:3500]
            size = len(text_content)

            await status.edit_text(
                f"📥 <b>Page Content</b>\n"
                f"🔗 <code>{esc(url[:80])}</code>\n"
                f"📊 HTTP {http_status} · {size:,} chars\n\n"
                f"<pre>{esc(preview)}</pre>"
                + (f"\n\n<i>...{size - 3500:,} more chars (send as file?)</i>" if size > 3500 else ""),
                parse_mode=H,
            )

        except Exception as e:
            await status.edit_text(
                f"❌ Fetch failed: {esc(str(e)[:300])}", parse_mode=H
            )

    @require_auth
    async def cmd_browse_close(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/browse_close — Close the browser session for this chat."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if chat_id not in _sessions:
            await msg.reply_text("ℹ️ No active browser session.", parse_mode=H)
            return

        await _close_session(chat_id)
        await msg.reply_text("✅ <b>Browser session closed.</b>", parse_mode=H)

    async def handle_browse_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle browser inline button callbacks (Refresh, Back, Close)."""
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data.startswith("browse_refresh:"):
            chat_id = int(data.split(":", 1)[1])
            if chat_id in _sessions:
                page = _sessions[chat_id]["page"]
                try:
                    await page.reload(wait_until="domcontentloaded", timeout=PAGE_TIMEOUT_MS)
                    await asyncio.sleep(1.0)
                    jpeg_bytes = await _screenshot_page(page)
                    title = await page.title()
                    url = page.url
                    buf = io.BytesIO(jpeg_bytes)
                    buf.name = "refresh.jpg"
                    await query.message.reply_photo(
                        photo=buf,
                        caption=f"🔄 Refreshed: <b>{esc(title[:60])}</b>\n<code>{esc(url[:80])}</code>",
                        parse_mode=H
                    )
                except Exception as e:
                    await query.message.reply_text(f"❌ Refresh failed: {esc(str(e)[:200])}", parse_mode=H)

        elif data.startswith("browse_back:"):
            chat_id = int(data.split(":", 1)[1])
            ctx.args = []
            update.callback_query.message.chat_id = chat_id
            # Reuse cmd_browse_back logic
            if chat_id in _sessions:
                page = _sessions[chat_id]["page"]
                try:
                    await page.go_back(timeout=10000)
                    await asyncio.sleep(1.0)
                    jpeg_bytes = await _screenshot_page(page)
                    title = await page.title()
                    buf = io.BytesIO(jpeg_bytes)
                    buf.name = "back.jpg"
                    await query.message.reply_photo(
                        photo=buf,
                        caption=f"⬅️ Back → <b>{esc(title[:60])}</b>",
                        parse_mode=H
                    )
                except Exception as e:
                    await query.message.reply_text(f"❌ Back failed: {esc(str(e)[:200])}", parse_mode=H)

        elif data.startswith("browse_close:"):
            chat_id = int(data.split(":", 1)[1])
            await _close_session(chat_id)
            await query.edit_message_caption(
                caption="❌ <b>Browser session closed.</b>", parse_mode=H
            )
