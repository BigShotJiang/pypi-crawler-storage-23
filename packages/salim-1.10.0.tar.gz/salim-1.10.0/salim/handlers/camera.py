"""
Salim Camera & Recording Handler

/cam [delay]       — Capture a webcam photo and send to Telegram
/cam list          — List available webcam devices
/record <seconds>  — Record screen for N seconds, compress, send as video

Screen recording uses ffmpeg (already required for voice).
Webcam uses OpenCV (cv2) — already a transitive dep of many packages.

Auto-installs: opencv-python (if missing)
"""
from __future__ import annotations

import asyncio
import io
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows, run_shell_async

logger = logging.getLogger("salim.camera")

MAX_RECORD_SECONDS = 300   # 5 minutes hard cap
MAX_VIDEO_MB = 49          # Telegram bot limit is 50MB


def _ensure_cv2() -> bool:
    try:
        import cv2  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "opencv-python-headless", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install opencv: {e}")
        return False


def _ensure_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg"))


def _list_webcams() -> list[tuple[int, str]]:
    """Return [(index, name), ...] of available cameras."""
    import cv2
    cams = []
    for i in range(8):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            # Try to get device name
            name = f"Camera {i}"
            cams.append((i, name))
            cap.release()
    return cams


def _capture_frame(cam_index: int = 0) -> bytes:
    """Capture a single JPEG frame from the webcam. Returns JPEG bytes."""
    import cv2
    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera {cam_index}")

    # Let camera warm up (auto-exposure stabilize)
    for _ in range(5):
        cap.read()

    ret, frame = cap.read()
    cap.release()

    if not ret or frame is None:
        raise RuntimeError("Failed to capture frame from camera")

    # Flip horizontally (natural selfie view)
    frame = cv2.flip(frame, 1)

    # Add timestamp watermark
    h, w = frame.shape[:2]
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame, ts, (10, h - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.putText(frame, ts, (10, h - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2, cv2.LINE_AA)

    ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if not ret:
        raise RuntimeError("JPEG encoding failed")
    return buf.tobytes()


async def _record_screen_ffmpeg(seconds: int, output_path: str) -> tuple[bool, str]:
    """
    Record screen using ffmpeg. Cross-platform:
    - Linux: x11grab
    - macOS: avfoundation
    - Windows: gdigrab
    """
    if is_linux():
        display = os.environ.get("DISPLAY", ":0")
        # Get screen resolution
        try:
            xr = subprocess.check_output(
                ["xrandr"], stderr=subprocess.DEVNULL, text=True, timeout=5
            )
            import re
            m = re.search(r"(\d{3,4}x\d{3,4})\+0\+0", xr)
            size = m.group(1) if m else "1920x1080"
        except Exception:
            size = "1920x1080"

        cmd = [
            "ffmpeg", "-y",
            "-video_size", size,
            "-framerate", "15",
            "-f", "x11grab",
            "-i", display,
            "-t", str(seconds),
            "-vcodec", "libx264",
            "-preset", "ultrafast",
            "-crf", "28",           # quality: lower = better, 28 = good for screen
            "-pix_fmt", "yuv420p",
            output_path
        ]
    elif is_mac():
        cmd = [
            "ffmpeg", "-y",
            "-f", "avfoundation",
            "-framerate", "15",
            "-i", "1:none",        # screen index 1, no audio
            "-t", str(seconds),
            "-vcodec", "libx264",
            "-preset", "ultrafast",
            "-crf", "28",
            "-pix_fmt", "yuv420p",
            output_path
        ]
    else:  # Windows
        cmd = [
            "ffmpeg", "-y",
            "-f", "gdigrab",
            "-framerate", "15",
            "-i", "desktop",
            "-t", str(seconds),
            "-vcodec", "libx264",
            "-preset", "ultrafast",
            "-crf", "28",
            "-pix_fmt", "yuv420p",
            output_path
        ]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=seconds + 30
        )
        if proc.returncode == 0 and Path(output_path).exists():
            return True, ""
        return False, stderr.decode(errors="replace")[-500:]
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return False, "Recording timed out"
    except Exception as e:
        return False, str(e)


class CameraHandlers:

    @require_auth
    async def cmd_cam(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /cam            — Snapshot from default webcam
        /cam <N>        — Snapshot from camera index N
        /cam list       — List available cameras
        /cam <delay> <index>  — with delay
        """
        if not _ensure_cv2():
            await update.effective_message.reply_text(
                "❌ opencv-python not installed.\n"
                "Run: <code>pip install opencv-python-headless</code>",
                parse_mode="HTML"
            )
            return

        args = ctx.args or []

        # List cameras
        if args and args[0].lower() == "list":
            cams = await asyncio.get_event_loop().run_in_executor(None, _list_webcams)
            if not cams:
                await update.effective_message.reply_text("📷 No cameras detected.")
                return
            lines = [f"• Camera <code>{i}</code>: {name}" for i, name in cams]
            await update.effective_message.reply_text(
                "📷 <b>Available Cameras:</b>\n\n" + "\n".join(lines) +
                "\n\nUse <code>/cam &lt;index&gt;</code> to select.",
                parse_mode="HTML"
            )
            return

        # Parse delay and cam index
        delay = 0
        cam_index = 0
        for arg in args:
            try:
                val = int(arg)
                if val > 10:
                    delay = val
                else:
                    cam_index = val
            except ValueError:
                pass

        if delay:
            await update.effective_message.reply_text(f"📷 Taking webcam photo in {delay}s...")
            await asyncio.sleep(delay)

        status = await update.effective_message.reply_text(
            f"📷 <i>Capturing from camera {cam_index}...</i>", parse_mode="HTML"
        )

        try:
            jpeg_bytes = await asyncio.get_event_loop().run_in_executor(
                None, _capture_frame, cam_index
            )
        except Exception as e:
            await status.edit_text(f"❌ Camera error: {e}", parse_mode="HTML")
            return

        buf = io.BytesIO(jpeg_bytes)
        buf.name = f"cam_{cam_index}_{int(time.time())}.jpg"

        try:
            await status.delete()
        except Exception:
            pass

        await update.effective_message.reply_photo(
            photo=buf,
            caption=f"📷 Camera {cam_index} · {time.strftime('%Y-%m-%d %H:%M:%S')} · {len(jpeg_bytes)//1024}KB"
        )

    @require_auth
    async def cmd_record(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /record <seconds>   — Record screen, compress, send to Telegram
        /record 30          — 30-second recording
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "🎬 <b>Screen Recording</b>\n\n"
                "Usage: <code>/record &lt;seconds&gt;</code>\n"
                "Example: <code>/record 30</code>\n\n"
                f"Max: {MAX_RECORD_SECONDS}s · Output: compressed MP4",
                parse_mode="HTML"
            )
            return

        if not _ensure_ffmpeg():
            await update.effective_message.reply_text(
                "❌ ffmpeg not found.\n"
                "Install: <code>sudo apt install ffmpeg</code>",
                parse_mode="HTML"
            )
            return

        try:
            seconds = int(ctx.args[0])
        except ValueError:
            await update.effective_message.reply_text("❌ Duration must be a number (seconds).")
            return

        if seconds < 1:
            await update.effective_message.reply_text("❌ Minimum duration is 1 second.")
            return
        if seconds > MAX_RECORD_SECONDS:
            await update.effective_message.reply_text(
                f"❌ Maximum duration is {MAX_RECORD_SECONDS}s ({MAX_RECORD_SECONDS//60} minutes)."
            )
            return

        status = await update.effective_message.reply_text(
            f"🎬 <b>Recording screen for {seconds}s...</b>\n"
            f"<i>Will send video when complete.</i>",
            parse_mode="HTML"
        )

        with tempfile.TemporaryDirectory() as tmp:
            raw_path = os.path.join(tmp, "recording_raw.mp4")
            final_path = os.path.join(tmp, "recording.mp4")

            success, err = await _record_screen_ffmpeg(seconds, raw_path)

            if not success:
                await status.edit_text(
                    f"❌ Recording failed.\n<pre>{err[:400]}</pre>",
                    parse_mode="HTML"
                )
                return

            # Re-encode to ensure compatibility and smaller size
            compress_cmd = [
                "ffmpeg", "-y", "-i", raw_path,
                "-vcodec", "libx264",
                "-crf", "32",
                "-preset", "fast",
                "-movflags", "+faststart",   # streaming-friendly
                "-pix_fmt", "yuv420p",
                final_path
            ]
            proc = await asyncio.create_subprocess_exec(
                *compress_cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.wait()

            use_path = final_path if Path(final_path).exists() else raw_path
            size_bytes = Path(use_path).stat().st_size
            size_mb = size_bytes / (1024 * 1024)

            if size_mb > MAX_VIDEO_MB:
                await status.edit_text(
                    f"⚠️ Video is {size_mb:.1f}MB (Telegram limit: {MAX_VIDEO_MB}MB).\n"
                    "Try a shorter duration.",
                    parse_mode="HTML"
                )
                return

            await status.edit_text("📤 <i>Uploading video...</i>", parse_mode="HTML")

            with open(use_path, "rb") as f:
                video_bytes = f.read()

            buf = io.BytesIO(video_bytes)
            buf.name = f"screen_{int(time.time())}.mp4"

            try:
                await status.delete()
            except Exception:
                pass

            await update.effective_message.reply_video(
                video=buf,
                caption=(
                    f"🎬 Screen recording · {seconds}s\n"
                    f"📦 {size_mb:.1f}MB · {time.strftime('%H:%M:%S')}"
                ),
                supports_streaming=True,
            )
