"""Monkey-patch for the Langfuse SDK (v3 OTEL-based) to forward trace data."""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger("synkro.trace_tap")


class LangfuseTap:
    """Patches ``LangfuseSpanProcessor.on_end`` to copy span data to Synkro.

    Langfuse v3 uses OpenTelemetry spans internally. We intercept each span
    after it's processed by Langfuse, extract relevant fields, and enqueue
    a normalized event for the Synkro backend.
    """

    def __init__(self, worker: Any, project: str) -> None:
        self._worker = worker
        self._project = project
        self._original: Any = None
        self._installed = False

    def install(self) -> None:
        if self._installed:
            return
        try:
            self._try_span_processor() or self._try_flush()
        except ImportError:
            logger.debug("synkro.trace_tap: langfuse not installed, skipping")
        except Exception:
            logger.debug("synkro.trace_tap: failed to install Langfuse tap", exc_info=True)

    def _try_span_processor(self) -> bool:
        """Patch LangfuseSpanProcessor.on_end (Langfuse v3+)."""
        try:
            from langfuse._client.span_processor import LangfuseSpanProcessor

            self._original = LangfuseSpanProcessor.on_end
            tap = self

            def patched_on_end(processor_self: Any, span: Any) -> None:
                # Always call original first — zero impact on user's hot path
                tap._original(processor_self, span)
                try:
                    tap._process_span(span)
                except Exception:
                    logger.debug(
                        "synkro.trace_tap: error processing Langfuse span", exc_info=True
                    )

            LangfuseSpanProcessor.on_end = patched_on_end  # type: ignore[assignment]
            self._installed = True
            logger.debug("synkro.trace_tap: Langfuse tap installed (SpanProcessor.on_end)")
            return True
        except (ImportError, AttributeError):
            return False

    def _try_flush(self) -> bool:
        """Fallback: patch Langfuse.flush for older versions."""
        try:
            from langfuse import Langfuse

            self._original = Langfuse.flush
            tap = self

            def patched_flush(lf_self: Any, *args: Any, **kwargs: Any) -> Any:
                result = tap._original(lf_self, *args, **kwargs)
                return result

            Langfuse.flush = patched_flush  # type: ignore[assignment]
            self._installed = True
            self._patch_target = "flush"
            logger.debug("synkro.trace_tap: Langfuse tap installed (flush fallback)")
            return True
        except (ImportError, AttributeError):
            return False

    def _process_span(self, span: Any) -> None:
        from synkro.enterprise.trace_tap._state import _state

        if not _state.enabled:
            return

        event = self._normalize_otel_span(span)
        if event:
            self._worker.enqueue(event)

    def _normalize_otel_span(self, span: Any) -> dict[str, Any] | None:
        """Convert an OTEL ReadableSpan from Langfuse into a normalized trace event."""
        try:
            attrs = dict(span.attributes or {})
        except Exception:
            attrs = {}

        name = getattr(span, "name", "") or getattr(span, "_name", "")

        # Extract trace_id and span_id from context
        trace_id = ""
        span_id = ""
        ctx = getattr(span, "context", None) or getattr(span, "_context", None)
        if ctx:
            try:
                from opentelemetry import trace as otel_trace_api

                trace_id = otel_trace_api.format_trace_id(ctx.trace_id)
                span_id = otel_trace_api.format_span_id(ctx.span_id)
            except Exception:
                trace_id = str(getattr(ctx, "trace_id", ""))
                span_id = str(getattr(ctx, "span_id", ""))

        # Extract parent span id
        parent_run_id = None
        parent = getattr(span, "parent", None)
        if parent:
            try:
                from opentelemetry import trace as otel_trace_api

                parent_run_id = otel_trace_api.format_span_id(parent.span_id)
            except Exception:
                parent_run_id = str(getattr(parent, "span_id", ""))

        # Extract messages from attributes
        messages = self._extract_messages(attrs)

        # Extract model (Langfuse v3 uses langfuse.observation.model.name)
        model = (
            attrs.get("langfuse.observation.model.name")
            or attrs.get("gen_ai.response.model")
            or attrs.get("gen_ai.request.model")
            or attrs.get("llm.model")
            or ""
        )

        # Extract tokens
        # Langfuse v3 stores usage in langfuse.observation.usage_details as JSON
        prompt_tokens = None
        completion_tokens = None
        usage_json = attrs.get("langfuse.observation.usage_details")
        if usage_json and isinstance(usage_json, str):
            try:
                usage = json.loads(usage_json)
                prompt_tokens = usage.get("input") or usage.get("prompt_tokens")
                completion_tokens = usage.get("output") or usage.get("completion_tokens")
            except Exception:
                pass
        if prompt_tokens is None:
            prompt_tokens = attrs.get("gen_ai.usage.input_tokens") or attrs.get(
                "gen_ai.usage.prompt_tokens"
            )
        if completion_tokens is None:
            completion_tokens = attrs.get("gen_ai.usage.output_tokens") or attrs.get(
                "gen_ai.usage.completion_tokens"
            )

        # Extract latency
        latency_ms = None
        start_time = getattr(span, "start_time", None) or getattr(span, "_start_time", None)
        end_time = getattr(span, "end_time", None) or getattr(span, "_end_time", None)
        if start_time and end_time:
            try:
                latency_ms = int((end_time - start_time) / 1_000_000)  # ns → ms
            except Exception:
                pass

        # Determine status
        status = "success"
        span_status = getattr(span, "status", None) or getattr(span, "_status", None)
        if span_status:
            code = getattr(span_status, "status_code", None)
            if code and str(code.name) == "ERROR":
                status = "error"

        # Determine run_type from observation type or span kind/name
        obs_type = attrs.get("langfuse.observation.type", "")
        if obs_type == "generation":
            run_type = "llm"
        elif any(k in name.lower() for k in ["tool", "function"]):
            run_type = "tool"
        else:
            run_type = "chain"

        # Extract tool calls
        tool_calls = self._extract_tool_calls(attrs)

        # Extract tags from attributes
        tags = []
        raw_tags = attrs.get("langfuse.tags")
        if raw_tags:
            if isinstance(raw_tags, (list, tuple)):
                tags = list(raw_tags)
            elif isinstance(raw_tags, str):
                try:
                    tags = json.loads(raw_tags)
                except Exception:
                    tags = [raw_tags]

        return {
            "source": "langfuse",
            "project": self._project,
            "trace_id": trace_id,
            "external_id": span_id,
            "messages": messages,
            "model": str(model),
            "tool_calls": tool_calls,
            "metadata": {
                "run_type": run_type,
                "name": name,
                "latency_ms": latency_ms,
                "status": status,
                "tags": tags,
                "parent_run_id": parent_run_id,
                "prompt_tokens": int(prompt_tokens) if prompt_tokens else None,
                "completion_tokens": int(completion_tokens) if completion_tokens else None,
            },
        }

    def _extract_messages(self, attrs: dict[str, Any]) -> list[dict[str, str]]:
        """Extract messages from OTEL span attributes."""
        messages: list[dict[str, str]] = []

        # gen_ai.prompt.N.role / gen_ai.prompt.N.content (OpenTelemetry semantic conventions)
        i = 0
        while True:
            role = attrs.get(f"gen_ai.prompt.{i}.role")
            content = attrs.get(f"gen_ai.prompt.{i}.content")
            if role is None and content is None:
                break
            messages.append({"role": str(role or "user"), "content": str(content or "")})
            i += 1

        # gen_ai.completion.N.role / gen_ai.completion.N.content
        i = 0
        while True:
            role = attrs.get(f"gen_ai.completion.{i}.role")
            content = attrs.get(f"gen_ai.completion.{i}.content")
            if role is None and content is None:
                break
            messages.append({"role": str(role or "assistant"), "content": str(content or "")})
            i += 1

        # Fallback: try Langfuse observation or generic input/output attributes
        if not messages:
            input_val = (
                attrs.get("langfuse.observation.input")
                or attrs.get("langfuse.span.input")
                or attrs.get("input")
            )
            if input_val:
                if isinstance(input_val, str):
                    try:
                        parsed = json.loads(input_val)
                        if isinstance(parsed, list):
                            for m in parsed:
                                if isinstance(m, dict) and "role" in m:
                                    messages.append(
                                        {
                                            "role": m.get("role", "user"),
                                            "content": str(m.get("content", "")),
                                        }
                                    )
                        elif isinstance(parsed, dict) and "role" in parsed:
                            messages.append(
                                {
                                    "role": parsed.get("role", "user"),
                                    "content": str(parsed.get("content", "")),
                                }
                            )
                    except json.JSONDecodeError:
                        messages.append({"role": "user", "content": input_val})
                elif isinstance(input_val, dict) and "role" in input_val:
                    messages.append(
                        {
                            "role": input_val.get("role", "user"),
                            "content": str(input_val.get("content", "")),
                        }
                    )

            # Also extract output as assistant message
            output_val = attrs.get("langfuse.observation.output") or attrs.get("output")
            if output_val:
                if isinstance(output_val, str):
                    try:
                        parsed = json.loads(output_val)
                        if isinstance(parsed, dict) and "role" in parsed:
                            messages.append(
                                {
                                    "role": parsed.get("role", "assistant"),
                                    "content": str(parsed.get("content", "")),
                                }
                            )
                        elif isinstance(parsed, str):
                            messages.append({"role": "assistant", "content": parsed})
                    except json.JSONDecodeError:
                        messages.append({"role": "assistant", "content": output_val})
                elif isinstance(output_val, dict) and "content" in output_val:
                    messages.append(
                        {
                            "role": output_val.get("role", "assistant"),
                            "content": str(output_val.get("content", "")),
                        }
                    )

        return messages

    def _extract_tool_calls(self, attrs: dict[str, Any]) -> list[dict[str, Any]]:
        """Extract tool calls from OTEL span attributes."""
        tool_calls: list[dict[str, Any]] = []

        # Check gen_ai.completion.N.function_call or tool_calls
        i = 0
        while True:
            fn_name = attrs.get(f"gen_ai.completion.{i}.function_call.name")
            fn_args = attrs.get(f"gen_ai.completion.{i}.function_call.arguments")
            if fn_name is None:
                break
            args = fn_args
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except Exception:
                    args = {"raw": args}
            tool_calls.append(
                {
                    "name": str(fn_name),
                    "arguments": args or {},
                    "response": None,
                    "status": "success",
                }
            )
            i += 1

        return tool_calls

    def uninstall(self) -> None:
        if not self._installed or self._original is None:
            return
        try:
            if hasattr(self, "_patch_target") and self._patch_target == "flush":
                from langfuse import Langfuse

                Langfuse.flush = self._original  # type: ignore[assignment]
            else:
                from langfuse._client.span_processor import LangfuseSpanProcessor

                LangfuseSpanProcessor.on_end = self._original  # type: ignore[assignment]
            self._installed = False
            logger.debug("synkro.trace_tap: Langfuse tap uninstalled")
        except Exception:
            pass
