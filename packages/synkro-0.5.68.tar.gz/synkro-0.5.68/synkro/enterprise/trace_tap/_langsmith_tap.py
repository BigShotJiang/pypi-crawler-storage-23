"""Monkey-patch for the LangSmith SDK to forward trace data."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("synkro.trace_tap")


class LangSmithTap:
    """Patches ``langsmith.Client.batch_ingest_runs`` to copy data to Synkro."""

    def __init__(self, worker: Any, project: str) -> None:
        self._worker = worker
        self._project = project
        self._original: Any = None
        self._installed = False

    def install(self) -> None:
        if self._installed:
            return
        try:
            import langsmith

            self._original = langsmith.Client.batch_ingest_runs
            tap = self

            def patched_batch_ingest_runs(client_self: Any, *args: Any, **kwargs: Any) -> Any:
                result = tap._original(client_self, *args, **kwargs)
                try:
                    tap._process_runs(args, kwargs)
                except Exception:
                    logger.debug("synkro.trace_tap: error processing LangSmith runs", exc_info=True)
                return result

            langsmith.Client.batch_ingest_runs = patched_batch_ingest_runs  # type: ignore[assignment]
            self._installed = True
            logger.debug("synkro.trace_tap: LangSmith tap installed")
        except ImportError:
            logger.debug("synkro.trace_tap: langsmith not installed, skipping")
        except Exception:
            logger.debug("synkro.trace_tap: failed to install LangSmith tap", exc_info=True)

    def _process_runs(self, args: tuple, kwargs: dict) -> None:
        from synkro.enterprise.trace_tap._normalizer import normalize_langsmith_run
        from synkro.enterprise.trace_tap._state import _state

        if not _state.enabled:
            return

        # batch_ingest_runs(create=[], update=[])
        create = kwargs.get("create") or (args[0] if args else []) or []
        update = kwargs.get("update") or (args[1] if len(args) > 1 else []) or []

        for run in [*create, *update]:
            if not isinstance(run, dict):
                continue
            event = normalize_langsmith_run(run, self._project)
            if event:
                self._worker.enqueue(event)

    def uninstall(self) -> None:
        if not self._installed or self._original is None:
            return
        try:
            import langsmith

            langsmith.Client.batch_ingest_runs = self._original  # type: ignore[assignment]
            self._installed = False
            logger.debug("synkro.trace_tap: LangSmith tap uninstalled")
        except Exception:
            pass
