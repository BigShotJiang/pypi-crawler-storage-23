"""Tests for synkro.enterprise.trace_tap."""

from __future__ import annotations

import queue
import threading
import time
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from synkro.enterprise.trace_tap import _shutdown, disable, enable, init
from synkro.enterprise.trace_tap._normalizer import (
    _normalize_messages,
    normalize_langfuse_event,
    normalize_langsmith_run,
)
from synkro.enterprise.trace_tap._state import _TraceTapState, _state
from synkro.enterprise.trace_tap._worker import TraceWorker


# ── Helpers ──────────────────────────────────────────


def _reset_state():
    """Reset global state between tests."""
    _state.initialized = False
    _state.enabled = True
    _state.api_key = ""
    _state.project = ""
    _state.ingest_url = ""
    _state.worker = None
    _state.langsmith_tap = None
    _state.langfuse_tap = None


@pytest.fixture(autouse=True)
def clean_state():
    """Reset trace tap state before and after each test."""
    _reset_state()
    yield
    _reset_state()


# ── TestInit ──────────────────────────────────────────


_WORKER_PATH = "synkro.enterprise.trace_tap._worker.TraceWorker"
_LS_TAP_PATH = "synkro.enterprise.trace_tap._langsmith_tap.LangSmithTap"
_LF_TAP_PATH = "synkro.enterprise.trace_tap._langfuse_tap.LangfuseTap"


class TestInit:
    def test_worker_starts(self):
        with (
            patch(_WORKER_PATH) as MockWorker,
            patch(_LS_TAP_PATH) as MockLS,
            patch(_LF_TAP_PATH) as MockLF,
        ):
            MockWorker.return_value = MagicMock()
            MockLS.return_value = MagicMock()
            MockLF.return_value = MagicMock()

            init(api_key="sk-test", project="my-project")

            MockWorker.assert_called_once()
            assert _state.initialized is True
            assert _state.api_key == "sk-test"
            assert _state.project == "my-project"

    def test_patches_when_importable(self):
        with (
            patch(_WORKER_PATH) as MockWorker,
            patch(_LS_TAP_PATH) as MockLS,
            patch(_LF_TAP_PATH) as MockLF,
        ):
            mock_worker = MagicMock()
            MockWorker.return_value = mock_worker
            mock_ls = MagicMock()
            MockLS.return_value = mock_ls
            mock_lf = MagicMock()
            MockLF.return_value = mock_lf

            init(api_key="sk-test", project="test")

            mock_ls.install.assert_called_once()
            mock_lf.install.assert_called_once()

    def test_skips_when_not_installed(self):
        """LangSmithTap.install() gracefully handles ImportError."""
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        worker = MagicMock()
        tap = LangSmithTap(worker=worker, project="test")
        with patch.dict("sys.modules", {"langsmith": None}):
            tap.install()  # Should not raise
        assert not tap._installed

    def test_idempotent(self):
        with (
            patch(_WORKER_PATH) as MockWorker,
            patch(_LS_TAP_PATH) as MockLS,
            patch(_LF_TAP_PATH) as MockLF,
        ):
            MockWorker.return_value = MagicMock()
            MockLS.return_value = MagicMock()
            MockLF.return_value = MagicMock()

            init(api_key="sk-test", project="test")
            init(api_key="sk-test-2", project="test2")

            MockWorker.assert_called_once()
            assert _state.api_key == "sk-test"  # First call wins

    def test_succeeds_when_endpoint_unreachable(self):
        """init() should succeed even if the ingest endpoint is unreachable."""
        with (
            patch(_WORKER_PATH) as MockWorker,
            patch(_LS_TAP_PATH) as MockLS,
            patch(_LF_TAP_PATH) as MockLF,
        ):
            MockWorker.return_value = MagicMock()
            MockLS.return_value = MagicMock()
            MockLF.return_value = MagicMock()

            init(
                api_key="sk-test",
                project="test",
                ingest_url="http://localhost:99999/nope",
            )
            assert _state.initialized is True


# ── TestWorker ──────────────────────────────────────────


class TestWorker:
    def test_enqueue_and_flush(self):
        sent_batches = []

        with patch("synkro.enterprise.trace_tap._worker.TraceWorker._send") as mock_send:
            mock_send.side_effect = lambda batch: sent_batches.extend(batch)
            worker = TraceWorker(
                ingest_url="http://test",
                api_key="sk-test",
                batch_size=5,
                flush_interval=0.1,
            )
            for i in range(3):
                worker.enqueue({"id": i})

            time.sleep(0.5)  # Let the worker drain
            worker.flush()

            assert len(sent_batches) == 3

    def test_batching_by_count(self):
        batches_sent = []

        original_send = TraceWorker._send

        def capture_send(self, batch):
            batches_sent.append(list(batch))

        with patch.object(TraceWorker, "_send", capture_send):
            worker = TraceWorker(
                ingest_url="http://test",
                api_key="sk-test",
                batch_size=3,
                flush_interval=10.0,  # High interval so count triggers first
            )
            for i in range(6):
                worker.enqueue({"id": i})

            time.sleep(1.0)
            worker.flush()

            total = sum(len(b) for b in batches_sent)
            assert total == 6

    def test_queue_full_drops_silently(self):
        """When queue is full, events are dropped without raising."""
        worker = TraceWorker(
            ingest_url="http://test",
            api_key="sk-test",
            batch_size=100,
            flush_interval=100.0,
        )
        # Stop the worker thread so it doesn't drain
        worker._stop.set()
        worker._thread.join(timeout=2.0)

        # Fill the queue
        for i in range(10_000):
            worker.enqueue({"id": i})

        # This should not raise
        worker.enqueue({"id": "overflow"})
        assert worker._warned_full is True

    def test_send_failure_warns_once(self):
        with patch("synkro.enterprise.trace_tap._worker.TraceWorker._get_client") as mock_client:
            client = MagicMock()
            client.post.side_effect = Exception("connection refused")
            mock_client.return_value = client

            worker = TraceWorker(
                ingest_url="http://bad",
                api_key="sk-test",
                batch_size=1,
                flush_interval=0.1,
            )
            worker.enqueue({"id": 1})
            worker.enqueue({"id": 2})
            time.sleep(0.5)
            worker.flush()

            assert worker._warned_send is True

    def test_graceful_shutdown(self):
        with patch("synkro.enterprise.trace_tap._worker.TraceWorker._send"):
            worker = TraceWorker(
                ingest_url="http://test",
                api_key="sk-test",
                batch_size=50,
                flush_interval=0.1,
            )
            worker.enqueue({"id": 1})
            worker.flush()
            assert not worker._thread.is_alive()


# ── TestLangSmithTap ──────────────────────────────────


class TestLangSmithTap:
    def test_install_and_uninstall(self):
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        mock_module = MagicMock()
        original_fn = MagicMock()
        mock_module.Client.batch_ingest_runs = original_fn

        with patch.dict("sys.modules", {"langsmith": mock_module}):
            worker = MagicMock()
            tap = LangSmithTap(worker=worker, project="test")
            tap.install()
            assert tap._installed

            # Method was replaced
            assert mock_module.Client.batch_ingest_runs != original_fn

            tap.uninstall()
            assert mock_module.Client.batch_ingest_runs == original_fn
            assert not tap._installed

    def test_original_called_first(self):
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        mock_module = MagicMock()
        original_fn = MagicMock(return_value="ok")
        mock_module.Client.batch_ingest_runs = original_fn

        with patch.dict("sys.modules", {"langsmith": mock_module}):
            worker = MagicMock()
            tap = LangSmithTap(worker=worker, project="test")
            tap.install()

            # Call the patched method
            patched_fn = mock_module.Client.batch_ingest_runs
            client = MagicMock()
            patched_fn(client, create=[{"id": "1"}])
            # Original was called inside the patched function
            original_fn.assert_called_once()

    def test_llm_runs_extracted(self):
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        mock_module = MagicMock()
        original_fn = MagicMock(return_value=None)
        mock_module.Client.batch_ingest_runs = original_fn

        with patch.dict("sys.modules", {"langsmith": mock_module}):
            worker = MagicMock()
            tap = LangSmithTap(worker=worker, project="test")
            tap.install()

            _state.enabled = True

            run = {
                "id": "run-1",
                "run_type": "llm",
                "inputs": {"messages": [{"role": "user", "content": "hello"}]},
                "outputs": {"generations": [{"text": "hi"}]},
                "extra": {"invocation_params": {"model": "gpt-4o"}},
            }

            tap._process_runs((), {"create": [run]})
            worker.enqueue.assert_called_once()
            event = worker.enqueue.call_args[0][0]
            assert event["source"] == "langsmith"
            assert event["model"] == "gpt-4o"

    def test_retriever_embedding_skipped(self):
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        worker = MagicMock()
        tap = LangSmithTap(worker=worker, project="test")
        _state.enabled = True

        for run_type in ["retriever", "embedding"]:
            run = {"id": "1", "run_type": run_type, "inputs": {}, "outputs": {}}
            tap._process_runs((), {"create": [run]})

        worker.enqueue.assert_not_called()

    def test_errors_dont_propagate(self):
        """Errors in _process_runs are caught by the patched method."""
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        mock_module = MagicMock()
        original_fn = MagicMock(return_value=None)
        mock_module.Client.batch_ingest_runs = original_fn

        with patch.dict("sys.modules", {"langsmith": mock_module}):
            worker = MagicMock()
            worker.enqueue.side_effect = Exception("boom")
            tap = LangSmithTap(worker=worker, project="test")
            tap.install()
            _state.enabled = True

            # Call the patched method — errors should be swallowed
            patched_fn = mock_module.Client.batch_ingest_runs
            client = MagicMock()
            run = {"id": "1", "run_type": "llm", "inputs": {}, "outputs": {}}
            patched_fn(client, create=[run])  # Should not raise
            original_fn.assert_called_once()


# ── TestLangfuseTap ──────────────────────────────────


class TestLangfuseTap:
    def test_install_span_processor(self):
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap

        mock_sp_module = MagicMock()
        mock_sp_class = MagicMock()
        mock_sp_class.on_end = MagicMock()
        mock_sp_module.LangfuseSpanProcessor = mock_sp_class

        with patch.dict(
            "sys.modules",
            {
                "langfuse": MagicMock(),
                "langfuse._client": MagicMock(),
                "langfuse._client.span_processor": mock_sp_module,
            },
        ):
            worker = MagicMock()
            tap = LangfuseTap(worker=worker, project="test")
            tap.install()
            assert tap._installed

    def test_span_data_extracted(self):
        """Test that _normalize_otel_span extracts data correctly from a mock span."""
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap

        worker = MagicMock()
        tap = LangfuseTap(worker=worker, project="test")
        _state.enabled = True

        # Create a mock OTEL span
        span = MagicMock()
        span.name = "ChatOpenAI"
        span._name = "ChatOpenAI"
        span.attributes = {
            "gen_ai.prompt.0.role": "user",
            "gen_ai.prompt.0.content": "hello",
            "gen_ai.completion.0.role": "assistant",
            "gen_ai.completion.0.content": "hi there",
            "gen_ai.response.model": "gpt-4o",
            "gen_ai.usage.input_tokens": 10,
            "gen_ai.usage.output_tokens": 5,
        }
        span.start_time = 1000000000  # 1s in nanoseconds
        span._start_time = 1000000000
        span.end_time = 2234000000  # 2.234s in nanoseconds
        span._end_time = 2234000000
        span.context = None
        span._context = None
        span.parent = None
        span.status = MagicMock()
        span.status.status_code = MagicMock()
        span.status.status_code.name = "OK"
        span._status = span.status
        span.kind = "INTERNAL"

        event = tap._normalize_otel_span(span)
        assert event is not None
        assert event["source"] == "langfuse"
        assert event["model"] == "gpt-4o"
        assert len(event["messages"]) == 2
        assert event["messages"][0]["content"] == "hello"
        assert event["messages"][1]["content"] == "hi there"
        assert event["metadata"]["prompt_tokens"] == 10
        assert event["metadata"]["completion_tokens"] == 5
        assert event["metadata"]["latency_ms"] == 1234

    def test_process_span_enqueues(self):
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap

        worker = MagicMock()
        tap = LangfuseTap(worker=worker, project="test")
        _state.enabled = True

        span = MagicMock()
        span.name = "LLMCall"
        span._name = "LLMCall"
        span.attributes = {"gen_ai.request.model": "gpt-4o"}
        span.start_time = span._start_time = 0
        span.end_time = span._end_time = 1_000_000_000
        span.context = span._context = None
        span.parent = None
        span.status = span._status = MagicMock()
        span.status.status_code = MagicMock()
        span.status.status_code.name = "OK"
        span.kind = "CLIENT"

        tap._process_span(span)
        worker.enqueue.assert_called_once()

    def test_disabled_skips(self):
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap

        worker = MagicMock()
        tap = LangfuseTap(worker=worker, project="test")
        _state.enabled = False

        span = MagicMock()
        tap._process_span(span)
        worker.enqueue.assert_not_called()

    def test_errors_dont_propagate(self):
        """Errors in _process_span are caught by the patched on_end wrapper."""
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap

        mock_sp_module = MagicMock()
        original_on_end = MagicMock()
        mock_sp_module.LangfuseSpanProcessor = MagicMock()
        mock_sp_module.LangfuseSpanProcessor.on_end = original_on_end

        with patch.dict(
            "sys.modules",
            {
                "langfuse": MagicMock(),
                "langfuse._client": MagicMock(),
                "langfuse._client.span_processor": mock_sp_module,
            },
        ):
            worker = MagicMock()
            worker.enqueue.side_effect = Exception("boom")
            tap = LangfuseTap(worker=worker, project="test")
            tap.install()
            _state.enabled = True

            # Call the patched on_end — should not raise
            patched_fn = mock_sp_module.LangfuseSpanProcessor.on_end
            span = MagicMock()
            span.name = span._name = "test"
            span.attributes = {}
            span.start_time = span._start_time = 0
            span.end_time = span._end_time = 0
            span.context = span._context = None
            span.parent = None
            span.status = span._status = MagicMock()
            span.status.status_code = MagicMock()
            span.status.status_code.name = "OK"
            span.kind = "INTERNAL"

            patched_fn(MagicMock(), span)  # Should not raise
            original_on_end.assert_called_once()


# ── TestNormalizer ──────────────────────────────────


class TestNormalizer:
    def test_openai_format(self):
        msgs = _normalize_messages([
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
        ])
        assert len(msgs) == 2
        assert msgs[0] == {"role": "user", "content": "hello"}
        assert msgs[1] == {"role": "assistant", "content": "hi there"}

    def test_langchain_objects(self):
        human = SimpleNamespace(type="human", content="hello")
        ai = SimpleNamespace(type="ai", content="hi")
        msgs = _normalize_messages([human, ai])
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"
        assert msgs[1]["role"] == "assistant"

    def test_tuples(self):
        msgs = _normalize_messages([("user", "hello"), ("assistant", "hi")])
        assert len(msgs) == 2
        assert msgs[0] == {"role": "user", "content": "hello"}

    def test_strings(self):
        msgs = _normalize_messages("hello world")
        assert msgs == [{"role": "user", "content": "hello world"}]

    def test_none(self):
        msgs = _normalize_messages(None)
        assert msgs == []

    def test_nested_lists(self):
        msgs = _normalize_messages([[{"role": "user", "content": "hi"}]])
        assert len(msgs) == 1
        assert msgs[0]["content"] == "hi"

    def test_vision_content_parts(self):
        msg = {
            "role": "user",
            "content": [
                {"type": "text", "text": "What's in this image?"},
                {"type": "image_url", "image_url": {"url": "http://example.com/img.png"}},
            ],
        }
        msgs = _normalize_messages(msg)
        assert len(msgs) == 1
        assert "What's in this image?" in msgs[0]["content"]

    def test_model_extraction_langsmith(self):
        run = {
            "id": "1",
            "run_type": "llm",
            "inputs": {},
            "outputs": {},
            "extra": {"invocation_params": {"model": "gpt-4o"}},
        }
        event = normalize_langsmith_run(run, "test")
        assert event["model"] == "gpt-4o"

    def test_model_extraction_fallback(self):
        run = {
            "id": "1",
            "run_type": "llm",
            "inputs": {},
            "outputs": {},
            "extra": {"metadata": {"ls_model_name": "claude-3"}},
        }
        event = normalize_langsmith_run(run, "test")
        assert event["model"] == "claude-3"

    def test_token_extraction(self):
        run = {
            "id": "1",
            "run_type": "llm",
            "inputs": {},
            "outputs": {},
            "extra": {"token_usage": {"prompt_tokens": 100, "completion_tokens": 50}},
        }
        event = normalize_langsmith_run(run, "test")
        assert event["metadata"]["prompt_tokens"] == 100
        assert event["metadata"]["completion_tokens"] == 50

    def test_latency_from_times(self):
        run = {
            "id": "1",
            "run_type": "llm",
            "inputs": {},
            "outputs": {},
            "start_time": "2024-01-01T00:00:00Z",
            "end_time": "2024-01-01T00:00:01.234Z",
            "extra": {},
        }
        event = normalize_langsmith_run(run, "test")
        assert event["metadata"]["latency_ms"] == 1234

    def test_langfuse_tokens(self):
        event = normalize_langfuse_event(
            "generation-create",
            {
                "id": "1",
                "traceId": "t-1",
                "model": "gpt-4o",
                "usage": {"promptTokens": 100, "completionTokens": 50},
            },
            "test",
        )
        assert event["metadata"]["prompt_tokens"] == 100
        assert event["metadata"]["completion_tokens"] == 50

    def test_langfuse_tool_calls(self):
        event = normalize_langfuse_event(
            "generation-create",
            {
                "id": "1",
                "traceId": "t-1",
                "model": "gpt-4o",
                "output": {
                    "tool_calls": [
                        {"function": {"name": "search", "arguments": {"q": "test"}}}
                    ]
                },
            },
            "test",
        )
        assert len(event["tool_calls"]) == 1
        assert event["tool_calls"][0]["name"] == "search"


# ── TestDisableEnable ──────────────────────────────────


class TestDisableEnable:
    def test_suppresses_forwarding(self):
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        worker = MagicMock()
        tap = LangSmithTap(worker=worker, project="test")
        _state.enabled = True

        run = {"id": "1", "run_type": "llm", "inputs": {}, "outputs": {}}

        with disable():
            tap._process_runs((), {"create": [run]})

        worker.enqueue.assert_not_called()

    def test_restores_after_context_manager(self):
        _state.enabled = True
        with disable():
            assert _state.enabled is False
        assert _state.enabled is True

    def test_doesnt_affect_original_calls(self):
        """disable() only suppresses forwarding, not the original SDK calls."""
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap

        mock_module = MagicMock()
        original_fn = MagicMock(return_value=None)
        mock_module.Client.batch_ingest_runs = original_fn

        with patch.dict("sys.modules", {"langsmith": mock_module}):
            worker = MagicMock()
            tap = LangSmithTap(worker=worker, project="test")
            tap.install()

            patched_fn = mock_module.Client.batch_ingest_runs
            with disable():
                client = MagicMock()
                patched_fn(client, create=[])

            # Original was still called even though forwarding was disabled
            original_fn.assert_called_once()
            # But worker should NOT have received anything
            worker.enqueue.assert_not_called()

    def test_enable_reenables(self):
        _state.enabled = True
        _state.enabled = False
        enable()
        assert _state.enabled is True
