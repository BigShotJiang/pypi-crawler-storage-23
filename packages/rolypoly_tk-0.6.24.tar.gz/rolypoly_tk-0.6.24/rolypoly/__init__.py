"""rolypoly: RNA virus analysis toolkit"""

__version__ = "0.6.24"
__name__ = "rolypoly-tk"
