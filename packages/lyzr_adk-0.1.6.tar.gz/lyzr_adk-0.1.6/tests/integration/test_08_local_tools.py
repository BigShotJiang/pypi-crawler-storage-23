"""Integration tests for local tools functionality."""
import pytest
from tests.fixtures.sample_configs import minimal_agent_config


class ToolCallTracker:
    """Helper to track tool calls during tests."""
    def __init__(self):
        self.calls = []

    def track(self, tool_name, **kwargs):
        self.calls.append({'tool': tool_name, 'args': kwargs})

    def was_called(self, tool_name):
        return any(c['tool'] == tool_name for c in self.calls)

    def get_call(self, tool_name):
        for call in self.calls:
            if call['tool'] == tool_name:
                return call
        return None


class TestLocalTools:
    """Test suite for local tools functionality."""

    def test_simple_tool_registration(self, studio, cleanup_agents):
        """Test 1: Simple tool registration."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_simple_tool'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def add_numbers(a: float, b: float) -> float:
            """Add two numbers together."""
            tracker.track('add_numbers', a=a, b=b)
            return a + b

        # Register tool
        agent.add_tool(add_numbers)

        # Verify tool is registered
        tools = agent.get_tools()
        assert 'add_numbers' in [t.name for t in tools]

    def test_tool_execution_with_parameters(self, studio, cleanup_agents):
        """Test 2: Tool execution with multiple parameters of different types."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_multi_param'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def process_data(text: str, count: int, multiplier: float) -> str:
            """Process data with multiple parameters."""
            tracker.track('process_data', text=text, count=count, multiplier=multiplier)
            return f"{text} * {count} * {multiplier}"

        agent.add_tool(process_data)
        tools = agent.get_tools()
        assert 'process_data' in [t.name for t in tools]

    def test_async_tool_execution(self, studio, cleanup_agents):
        """Test 3: Async tool execution."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_async'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        async def async_fetch(url: str) -> str:
            """Async fetch operation."""
            tracker.track('async_fetch', url=url)
            return f"Fetched from {url}"

        agent.add_tool(async_fetch)
        tools = agent.get_tools()
        assert 'async_fetch' in [t.name for t in tools]

    def test_multiple_tools_on_agent(self, studio, cleanup_agents):
        """Test 4: Multiple tools on single agent."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_multi_tools'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def tool_one(x: int) -> int:
            """First tool."""
            return x * 2

        def tool_two(y: str) -> str:
            """Second tool."""
            return y.upper()

        def tool_three(z: float) -> float:
            """Third tool."""
            return z + 1.0

        agent.add_tool(tool_one)
        agent.add_tool(tool_two)
        agent.add_tool(tool_three)

        tools = agent.get_tools()
        tool_names = [t.name for t in tools]
        assert 'tool_one' in tool_names
        assert 'tool_two' in tool_names
        assert 'tool_three' in tool_names
        assert len(tools) == 3

    def test_tool_error_handling(self, studio, cleanup_agents):
        """Test 5: Tool error handling."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_error'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def divide_numbers(a: float, b: float) -> float:
            """Divide two numbers."""
            tracker.track('divide_numbers', a=a, b=b)
            if b == 0:
                raise ValueError("Cannot divide by zero")
            return a / b

        agent.add_tool(divide_numbers)
        tools = agent.get_tools()
        assert 'divide_numbers' in [t.name for t in tools]

    def test_tool_complex_return_types(self, studio, cleanup_agents):
        """Test 6: Tools with complex return types."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_complex_return'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def get_user_data(user_id: int) -> dict:
            """Get user data as dictionary."""
            return {
                'id': user_id,
                'name': f'User {user_id}',
                'active': True
            }

        def get_numbers_list(count: int) -> list:
            """Get list of numbers."""
            return list(range(count))

        agent.add_tool(get_user_data)
        agent.add_tool(get_numbers_list)

        tools = agent.get_tools()
        assert len(tools) == 2

    def test_tool_removal(self, studio, cleanup_agents):
        """Test 7: Tool removal."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_removal'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def temp_tool(x: int) -> int:
            """Temporary tool."""
            return x

        agent.add_tool(temp_tool)
        tools = agent.get_tools()
        assert 'temp_tool' in [t.name for t in tools]

        # Remove tool
        if agent._tool_registry:
            agent._tool_registry.remove('temp_tool')
            tools = agent.get_tools()
            assert 'temp_tool' not in [t.name for t in tools]

    def test_tool_chaining(self, studio, cleanup_agents):
        """Test 8: Chaining tool additions."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_chaining'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def first(x: int) -> int:
            """First tool."""
            return x + 1

        def second(x: int) -> int:
            """Second tool."""
            return x * 2

        def third(x: int) -> int:
            """Third tool."""
            return x - 1

        # Chain tool additions
        agent.add_tool(first).add_tool(second).add_tool(third)

        tools = agent.get_tools()
        assert len(tools) == 3

    def test_tool_type_validation(self, studio, cleanup_agents):
        """Test 9: Tool type validation."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_type_validation'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def typed_tool(name: str, age: int, score: float) -> str:
            """Tool with typed parameters."""
            return f"{name} is {age} years old with score {score}"

        agent.add_tool(typed_tool)
        tools = agent.get_tools()
        assert 'typed_tool' in [t.name for t in tools]

    def test_tool_parameter_schema(self, studio, cleanup_agents):
        """Test 10: Tool parameter schema generation."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_schema'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def complex_tool(required_str: str, optional_int: int = 10) -> str:
            """Tool with required and optional parameters."""
            return f"{required_str}-{optional_int}"

        agent.add_tool(complex_tool)
        tools = agent.get_tools()
        tool = [t for t in tools if t.name == 'complex_tool'][0]
        assert tool.parameters is not None

    def test_tool_with_default_parameters(self, studio, cleanup_agents):
        """Test 11: Tools with default parameters."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_defaults'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        def greet(name: str, greeting: str = "Hello") -> str:
            """Greet someone."""
            return f"{greeting}, {name}!"

        agent.add_tool(greet)
        tools = agent.get_tools()
        assert 'greet' in [t.name for t in tools]

    def test_multiple_tool_invocations(self, studio, cleanup_agents):
        """Test 12: Multiple invocations of the same tool."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_multi_invoke'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def counter(value: int) -> int:
            """Increment counter."""
            tracker.track('counter', value=value)
            return value + 1

        agent.add_tool(counter)
        tools = agent.get_tools()
        assert 'counter' in [t.name for t in tools]

    def test_tool_with_complex_logic(self, studio, cleanup_agents):
        """Test 13: Tool with complex internal logic."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_complex'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def calculate_stats(numbers: str) -> dict:
            """Calculate statistics from comma-separated numbers."""
            tracker.track('calculate_stats', numbers=numbers)
            nums = [float(n.strip()) for n in numbers.split(',')]
            return {
                'count': len(nums),
                'sum': sum(nums),
                'avg': sum(nums) / len(nums) if nums else 0,
                'min': min(nums) if nums else 0,
                'max': max(nums) if nums else 0
            }

        agent.add_tool(calculate_stats)
        tools = agent.get_tools()
        assert 'calculate_stats' in [t.name for t in tools]

    def test_tool_with_no_parameters(self, studio, cleanup_agents):
        """Test 14: Tool with no parameters."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_no_params'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        tracker = ToolCallTracker()

        def get_timestamp() -> str:
            """Get current timestamp."""
            tracker.track('get_timestamp')
            import time
            return str(time.time())

        agent.add_tool(get_timestamp)
        tools = agent.get_tools()
        assert 'get_timestamp' in [t.name for t in tools]

    def test_tool_registration_validation(self, studio, cleanup_agents):
        """Test 15: Tool registration validation."""
        config = minimal_agent_config()
        config['name'] = 'test_agent_validation'
        agent = studio.agents.create(**config)
        cleanup_agents.append(agent.id)

        # Valid tool
        def valid_tool(x: int) -> int:
            """Valid tool."""
            return x

        agent.add_tool(valid_tool)
        tools = agent.get_tools()
        assert 'valid_tool' in [t.name for t in tools]

        # Invalid tool (not callable)
        try:
            agent.add_tool("not a function")
            assert False, "Should have raised TypeError"
        except TypeError:
            pass
