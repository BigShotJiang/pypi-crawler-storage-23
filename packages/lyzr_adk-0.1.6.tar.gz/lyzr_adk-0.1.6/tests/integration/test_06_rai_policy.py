"""
Test 06: RAI Policy
Tests RAI guardrails CRUD operations and policy configurations.
"""

import pytest
from tests.fixtures.sample_configs import (
    rai_policy_pii_redact,
    rai_policy_content_blocking
)


@pytest.mark.rai
class TestRAIPolicy:
    """RAI policy tests."""

    def test_rai_policy_creation(self, studio, cleanup_policies):
        """Test creating a RAI policy."""
        config = rai_policy_pii_redact()
        policy = studio.rai.create_policy(**config)

        assert policy is not None
        assert policy.id is not None
        assert policy.name == config['name']

        cleanup_policies.append(policy.id)

    def test_rai_policy_read(self, studio, cleanup_policies):
        """Test retrieving a RAI policy."""
        config = rai_policy_pii_redact()
        created_policy = studio.rai.create_policy(**config)

        retrieved_policy = studio.rai.get_policy(created_policy.id)

        assert retrieved_policy is not None
        assert retrieved_policy.id == created_policy.id

        cleanup_policies.append(created_policy.id)

    def test_rai_policy_list(self, studio, cleanup_policies):
        """Test listing RAI policies."""
        config1 = rai_policy_pii_redact()
        config1['name'] = 'test_rai_1'
        policy1 = studio.rai.create_policy(**config1)
        cleanup_policies.append(policy1.id)

        config2 = rai_policy_content_blocking()
        config2['name'] = 'test_rai_2'
        policy2 = studio.rai.create_policy(**config2)
        cleanup_policies.append(policy2.id)

        policies = studio.rai.list_policies()

        policy_ids = [p.id for p in policies]
        assert policy1.id in policy_ids
        assert policy2.id in policy_ids

    def test_rai_policy_update(self, studio, cleanup_policies):
        """Test updating a RAI policy."""
        config = rai_policy_pii_redact()
        policy = studio.rai.create_policy(**config)

        new_description = "Updated policy"
        updated = studio.rai.update_policy(policy.id, description=new_description)

        assert updated.description == new_description

        cleanup_policies.append(policy.id)

    def test_rai_policy_delete(self, studio, cleanup_policies):
        """Test deleting a RAI policy."""
        config = rai_policy_pii_redact()
        policy = studio.rai.create_policy(**config)
        policy_id = policy.id

        studio.rai.delete_policy(policy_id)

        try:
            studio.rai.get_policy(policy_id)
            assert False, "Policy should be deleted"
        except Exception:
            pass

    def test_pii_detection_configuration(self, studio, cleanup_policies):
        """Test PII detection guardrail configuration."""
        from lyzr.rai import PIIType, PIIAction

        config = {
            'name': 'test_pii_config',
            'description': 'Test PII detection',
            'pii_detection': {
                PIIType.EMAIL: PIIAction.REDACT,
                PIIType.CREDIT_CARD: PIIAction.REDACT,
                PIIType.PHONE: PIIAction.REDACT,
                PIIType.SSN: PIIAction.REDACT
            }
        }

        policy = studio.rai.create_policy(**config)
        assert policy is not None

        cleanup_policies.append(policy.id)

    def test_toxicity_detection(self, studio, cleanup_policies):
        """Test toxicity detection guardrail."""
        config = rai_policy_content_blocking()
        policy = studio.rai.create_policy(**config)

        assert policy is not None

        cleanup_policies.append(policy.id)

    def test_multiple_guardrails(self, studio, cleanup_policies):
        """Test policy with multiple guardrails."""
        from lyzr.rai import PIIType, PIIAction

        config = {
            'name': 'test_multi_guardrails',
            'description': 'Test multiple guardrails',
            'pii_detection': {
                PIIType.EMAIL: PIIAction.REDACT
            },
            'toxicity_threshold': 0.5
        }

        policy = studio.rai.create_policy(**config)
        assert policy is not None

        cleanup_policies.append(policy.id)

    def test_prompt_injection_prevention(self, studio, cleanup_policies):
        """Test prompt injection prevention guardrail."""
        config = {
            'name': 'test_injection_protection',
            'description': 'Test prompt injection prevention',
            'prompt_injection': True
        }

        policy = studio.rai.create_policy(**config)
        assert policy is not None

        cleanup_policies.append(policy.id)

    def test_topic_filtering(self, studio, cleanup_policies):
        """Test topic filtering guardrail."""
        config = {
            'name': 'test_topic_filter',
            'description': 'Test topic filtering',
            'banned_topics': ['violence', 'hate'],
            'allowed_topics': {
                'enabled': True,
                'topics': ['science', 'technology']
            }
        }

        policy = studio.rai.create_policy(**config)
        assert policy is not None

        cleanup_policies.append(policy.id)
