"""
Test 07: Memory
Tests memory provider CRUD operations and memory management.
"""

import pytest
from tests.fixtures.sample_configs import memory_config_lyzr


@pytest.mark.memory
class TestMemory:
    """Memory provider tests."""

    def test_memory_providers_list(self, studio):
        """Test listing available memory providers."""
        providers = studio.memory.list_providers()

        assert providers is not None
        assert len(providers) > 0
        # Should include common providers (lyzr is built-in/default, so may not be listed)
        provider_ids = [p.get('provider_id') for p in providers]
        assert any(pid in ['aws-agentcore', 'mem0', 'supermemory'] for pid in provider_ids)

    def test_memory_creation_lyzr_provider(self, studio, cleanup_memories):
        """Test creating memory with Lyzr provider."""
        config = memory_config_lyzr()
        memory = studio.memory.create_credential(
            provider=config['provider'],
            name=config['name']
        )

        assert memory is not None
        assert memory.credential_id is not None
        assert memory.provider.value == 'lyzr'

        cleanup_memories.append(memory.credential_id)

    def test_memory_read(self, studio, cleanup_memories):
        """Test retrieving memory by ID."""
        config = memory_config_lyzr()
        created_memory = studio.memory.create_credential(
            provider=config['provider'],
            name=config['name']
        )

        retrieved_memory = studio.memory.get_memory(
            created_memory.credential_id,
            config['provider']
        )

        assert retrieved_memory is not None
        assert retrieved_memory.credential_id == created_memory.credential_id

        cleanup_memories.append(created_memory.credential_id)

    def test_memory_delete(self, studio, cleanup_memories):
        """Test deleting memory."""
        config = memory_config_lyzr()
        memory = studio.memory.create_credential(
            provider=config['provider'],
            name=config['name']
        )
        memory_id = memory.credential_id

        studio.memory.delete_credential(memory_id)

        try:
            studio.memory.get_memory(memory_id, config['provider'])
            assert False, "Memory should be deleted"
        except Exception:
            pass

    def test_memory_with_max_messages_config(self, studio, cleanup_memories):
        """Test memory with max_messages configuration."""
        config = {
            'name': 'test_memory_max_msgs',
            'provider': 'lyzr',
            'config': {'max_messages': 5}
        }

        memory = studio.memory.create_credential(
            provider=config['provider'],
            name=config['name']
        )
        assert memory is not None

        cleanup_memories.append(memory.credential_id)

    def test_memory_required_fields(self, studio):
        """Test that memory creation requires necessary fields."""
        # Missing name
        with pytest.raises(Exception):
            studio.memory.create_credential(provider='lyzr', name=None)

        # Missing provider
        with pytest.raises(Exception):
            studio.memory.create_credential(provider=None, name='test_memory')

    def test_memory_provider_validation(self, studio):
        """Test that invalid providers are rejected."""
        try:
            studio.memory.create_credential(
                provider='invalid_memory_provider',
                name='test_invalid_provider'
            )
            assert False, "Should fail with invalid provider"
        except Exception:
            pass

    @pytest.mark.skip(reason="Config preservation not supported in current SDK")
    def test_memory_config_preservation(self, studio, cleanup_memories):
        """Test that memory configuration is preserved."""
        config = {
            'name': 'test_memory_config_preserve',
            'provider': 'lyzr',
            'config': {'max_messages': 15}
        }

        memory = studio.memory.create_credential(
            provider=config['provider'],
            name=config['name']
        )
        retrieved = studio.memory.get_memory(memory.credential_id, config['provider'])

        # Config preservation not implemented yet
        # assert retrieved.config.get('max_messages') == 15

        cleanup_memories.append(memory.credential_id)
