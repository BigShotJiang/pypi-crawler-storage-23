"""
Test 04: Knowledge Base
Tests knowledge base CRUD operations, document management, and querying.
"""

import pytest
import os
from tests.fixtures.sample_configs import (
    knowledge_base_config_qdrant,
    knowledge_base_config_weaviate
)
from tests.fixtures.test_data import kb_training_text, kb_search_query


@pytest.mark.knowledge_base
class TestKnowledgeBase:
    """Knowledge base tests."""

    def test_knowledge_base_creation(self, studio, cleanup_knowledge_bases):
        """Test creating a knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        assert kb is not None
        assert kb.id is not None
        assert kb.name == config['name']

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_read(self, studio, cleanup_knowledge_bases):
        """Test retrieving a knowledge base by ID."""
        config = knowledge_base_config_qdrant()
        created_kb = studio.knowledge_bases.create(**config)
        kb_id = created_kb.id

        retrieved_kb = studio.knowledge_bases.get(kb_id)

        assert retrieved_kb is not None
        assert retrieved_kb.id == kb_id
        assert retrieved_kb.collection_name is not None

        cleanup_knowledge_bases.append(kb_id)

    def test_knowledge_base_list(self, studio, cleanup_knowledge_bases):
        """Test listing all knowledge bases."""
        config1 = knowledge_base_config_qdrant()
        config1['name'] = 'test_kb_list_1'
        kb1 = studio.knowledge_bases.create(**config1)
        cleanup_knowledge_bases.append(kb1.id)

        config2 = knowledge_base_config_qdrant()
        config2['name'] = 'test_kb_list_2'
        kb2 = studio.knowledge_bases.create(**config2)
        cleanup_knowledge_bases.append(kb2.id)

        kbs = studio.knowledge_bases.list()

        kb_ids = [kb.id for kb in kbs]
        assert kb1.id in kb_ids
        assert kb2.id in kb_ids

    def test_knowledge_base_update(self, studio, cleanup_knowledge_bases):
        """Test updating a knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)
        kb_id = kb.id

        new_description = "Updated description"
        updated_kb = studio.knowledge_bases.update(
            kb_id,
            description=new_description
        )

        assert updated_kb.description == new_description
        assert updated_kb.id == kb_id

        cleanup_knowledge_bases.append(kb_id)

    def test_knowledge_base_add_text_document(self, studio, cleanup_knowledge_bases):
        """Test adding a text document to knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        text = kb_training_text()
        kb.add_text(text, source="test")

        # Verify document was added
        kbs = studio.knowledge_bases.get(kb.id)
        assert kbs is not None

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_add_pdf_document(self, studio, cleanup_knowledge_bases, sample_pdf_path):
        """Test adding a PDF document to knowledge base."""
        if not os.path.exists(sample_pdf_path):
            pytest.skip("Sample PDF not found")

        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        kb.add_pdf(sample_pdf_path)

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_add_docx_document(self, studio, cleanup_knowledge_bases, sample_docx_path):
        """Test adding a DOCX document to knowledge base."""
        if not os.path.exists(sample_docx_path):
            pytest.skip("Sample DOCX not found")

        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        kb.add_docx(sample_docx_path)

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_add_txt_document(self, studio, cleanup_knowledge_bases, sample_txt_path):
        """Test adding a TXT document to knowledge base."""
        if not os.path.exists(sample_txt_path):
            pytest.skip("Sample TXT not found")

        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        kb.add_txt(sample_txt_path)

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_query_basic(self, studio, cleanup_knowledge_bases):
        """Test querying a knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        # Add training data
        text = kb_training_text()
        kb.add_text(text, source="test")

        # Query
        query = kb_search_query()
        results = kb.query(query)

        assert results is not None
        assert len(results) > 0

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_query_with_top_k(self, studio, cleanup_knowledge_bases):
        """Test querying with top_k parameter."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        text = kb_training_text()
        kb.add_text(text, source="test")

        query = kb_search_query()
        results = kb.query(query, top_k=3)

        assert results is not None
        assert len(results) <= 3

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_delete_document(self, studio, cleanup_knowledge_bases):
        """Test deleting a document from knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        text = kb_training_text()
        kb.add_text(text, source="test")

        # Get documents and delete the first one
        docs = kb.list_documents()
        if docs:
            kb.delete_documents([docs[0].id])

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_list_documents(self, studio, cleanup_knowledge_bases):
        """Test listing documents in knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        text = kb_training_text()
        kb.add_text(text, source="test")

        documents = kb.list_documents()

        assert documents is not None
        assert len(documents) > 0

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_reset(self, studio, cleanup_knowledge_bases):
        """Test resetting a knowledge base (clearing all documents)."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        # Add documents
        text = kb_training_text()
        kb.add_text(text, source="test")

        # Reset
        kb.reset()

        # Verify empty
        documents = kb.list_documents()
        assert len(documents) == 0

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_delete(self, studio, cleanup_knowledge_bases):
        """Test deleting a knowledge base."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)
        kb_id = kb.id

        studio.knowledge_bases.delete(kb_id)

        # Verify deletion
        try:
            retrieved = studio.knowledge_bases.get(kb_id)
            assert retrieved is None
        except Exception:
            pass

    def test_multiple_knowledge_bases(self, studio, cleanup_knowledge_bases):
        """Test managing multiple knowledge bases simultaneously."""
        config1 = knowledge_base_config_qdrant()
        config1['name'] = 'test_kb_multi_1'
        kb1 = studio.knowledge_bases.create(**config1)

        config2 = knowledge_base_config_weaviate() if False else knowledge_base_config_qdrant()
        config2['name'] = 'test_kb_multi_2'
        kb2 = studio.knowledge_bases.create(**config2)

        # Add different content to each
        text1 = "Content for KB1: Python programming"
        text2 = "Content for KB2: JavaScript development"

        kb1.add_text(text1, source="test")
        kb2.add_text(text2, source="test")

        # Query each
        results1 = kb1.query("Python")
        results2 = kb2.query("JavaScript")

        assert len(results1) > 0
        assert len(results2) > 0

        cleanup_knowledge_bases.extend([kb1.id, kb2.id])

    def test_knowledge_base_required_fields(self, studio):
        """Test that knowledge base creation requires necessary fields."""
        # Missing name
        with pytest.raises(Exception):
            studio.knowledge_bases.create(description="Test KB")

    def test_knowledge_base_empty_query_handling(self, studio, cleanup_knowledge_bases):
        """Test querying knowledge base with empty query."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        text = kb_training_text()
        kb.add_text(text, source="test")

        try:
            results = kb.query("")
            assert results is not None
        except Exception:
            pass

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_with_multiple_documents(self, studio, cleanup_knowledge_bases):
        """Test knowledge base with multiple documents."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        # Add multiple documents
        docs_to_add = [
            "Python is a high-level programming language",
            "JavaScript is used for web development",
            "Rust provides memory safety without garbage collection"
        ]

        for i, doc in enumerate(docs_to_add):
            kb.add_text(doc, source=f"test_{i}")

        # Verify all documents added
        documents = kb.list_documents()
        assert len(documents) >= len(docs_to_add)

        cleanup_knowledge_bases.append(kb.id)

    def test_knowledge_base_query_relevance(self, studio, cleanup_knowledge_bases):
        """Test that knowledge base returns relevant results."""
        config = knowledge_base_config_qdrant()
        kb = studio.knowledge_bases.create(**config)

        # Add specific content
        kb.add_text("The Eiffel Tower is located in Paris, France", source="test")
        kb.add_text("The Great Wall of China is one of the seven wonders", source="test")
        kb.add_text("The Statue of Liberty is in New York City", source="test")

        # Query for specific content
        results = kb.query("Paris")

        assert len(results) > 0

        cleanup_knowledge_bases.append(kb.id)
