"""
Test 10: Agent + Memory Integration
Tests agent execution with memory providers for persistent conversations.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    memory_config_lyzr,
    deterministic_agent_config
)


@pytest.mark.features
class TestAgentWithMemory:
    """Agent with memory provider integration tests."""

    def test_agent_with_memory_basic(self, studio, cleanup_agents, cleanup_memories):
        """Test basic agent execution with memory."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_with_memory'
        agent_config['memory'] = 10  # Lyzr memory: persist 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Hello")
        assert response is not None

    def test_memory_persistence_across_turns(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test that memory persists information across multiple turns."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_persistence'
        agent_config['memory'] = 10  # Lyzr memory: persist 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "memory_persistence_session"

        # Turn 1: Tell agent something
        response1 = agent.run("My name is Alice", session_id=session_id)
        assert response1 is not None

        # Turn 2: Ask if it remembers
        response2 = agent.run("What is my name?", session_id=session_id)
        assert response2 is not None

        # Turn 3: Continue conversation
        response3 = agent.run("Tell me a fact about my name", session_id=session_id)
        assert response3 is not None

    def test_agent_without_memory(self, studio, cleanup_agents):
        """Test agent execution without memory provider."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_memory'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Without memory, each turn should be independent
        response1 = agent.run("My name is Bob")
        response2 = agent.run("What is my name?")

        assert response1 is not None
        assert response2 is not None

    def test_memory_configuration_options(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test memory with different configuration options."""
        memory_config = memory_config_lyzr()
        memory_config['config'] = {'max_messages': 10}

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_config'
        agent_config['memory'] = 10  # Lyzr memory: max 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Test with memory config")
        assert response is not None

    def test_memory_update(self, studio, cleanup_agents, cleanup_memories):
        """Test updating agent's memory configuration."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_update'
        agent_config['memory'] = 5  # Start with 5 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Update to different memory size
        agent = agent.update(memory=15)

        response = agent.run("Test after memory update")
        assert response is not None

    def test_memory_removal(self, studio, cleanup_agents, cleanup_memories):
        """Test agent without memory (simulating removal)."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_removal'
        # Create agent without memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Test without memory")
        assert response is not None

    def test_memory_with_streaming(self, studio, cleanup_agents, cleanup_memories):
        """Test streaming with memory enabled."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_stream'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "memory_stream_session"
        agent.run("My favorite color is blue", session_id=session_id)

        chunks = list(agent.run("What is my favorite color?", stream=True, session_id=session_id))
        assert len(chunks) > 0

    def test_multiple_agents_separate_memory(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test that multiple agents maintain separate memories."""
        # Create two agents with memory
        agent1_config = minimal_agent_config()
        agent1_config['name'] = 'test_agent_memory_1'
        agent1_config['memory'] = 10  # Lyzr memory
        agent1 = studio.agents.create(**agent1_config)
        cleanup_agents.append(agent1.id)

        agent2_config = minimal_agent_config()
        agent2_config['name'] = 'test_agent_memory_2'
        agent2_config['memory'] = 10  # Lyzr memory
        agent2 = studio.agents.create(**agent2_config)
        cleanup_agents.append(agent2.id)

        session1 = "memory_session_1"
        session2 = "memory_session_2"

        # Agent 1 learns one thing
        agent1.run("I like Python", session_id=session1)

        # Agent 2 learns something else
        agent2.run("I like JavaScript", session_id=session2)

        # Query each agent
        response1 = agent1.run("What do I like?", session_id=session1)
        response2 = agent2.run("What do I like?", session_id=session2)

        assert response1 is not None
        assert response2 is not None

    def test_memory_with_long_conversation(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test memory handling with long conversation (20+ turns)."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_long'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "long_memory_session"

        # Have a long conversation
        prompts = [
            "Hello",
            "My name is Charlie",
            "I work in technology",
            "I enjoy programming",
            "What is my name?",
            "What do I do?",
            "Tell me about my interests",
            "Summarize what you know about me",
        ]

        for prompt in prompts:
            response = agent.run(prompt, session_id=session_id)
            assert response is not None

    def test_memory_max_messages_limit(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test that memory respects max_messages limit."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_limit'
        agent_config['memory'] = 5  # Lyzr memory: limit to 5 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "memory_limit_session"

        # Send more than max_messages
        for i in range(10):
            agent.run(f"Message {i}", session_id=session_id)

        # Agent should still work but only remember last 5
        response = agent.run("How many messages do you remember?", session_id=session_id)
        assert response is not None

    def test_memory_with_deterministic_agent(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test memory with deterministic agent (temperature=0)."""
        agent_config = deterministic_agent_config()
        agent_config['name'] = 'test_agent_memory_deterministic'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "deterministic_memory_session"

        # First run
        response1 = agent.run("What is 2 + 2?", session_id=session_id)

        # Second run - should be identical due to temperature=0
        response2 = agent.run("What is 2 + 2?", session_id=session_id)

        assert response1 is not None
        assert response2 is not None

    def test_memory_error_handling(self, studio, cleanup_agents, cleanup_memories):
        """Test error handling with memory."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_error'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Test with edge cases
        try:
            response = agent.run("")
            assert response is not None
        except Exception:
            pass

    def test_memory_context_isolation(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test that different sessions maintain isolated context."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_isolation'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Session 1
        agent.run("In session 1, my name is David", session_id="session_1")
        response1 = agent.run("What is my name?", session_id="session_1")

        # Session 2
        agent.run("In session 2, my name is Emily", session_id="session_2")
        response2 = agent.run("What is my name?", session_id="session_2")

        assert response1 is not None
        assert response2 is not None

    def test_memory_with_user_isolation(
        self, studio, cleanup_agents, cleanup_memories
    ):
        """Test memory isolation between different users."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_memory_users'
        agent_config['memory'] = 10  # Lyzr memory
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # User 1
        agent.run("My name is Frank", user_id="user_1")
        response1 = agent.run("What is my name?", user_id="user_1")

        # User 2
        agent.run("My name is Grace", user_id="user_2")
        response2 = agent.run("What is my name?", user_id="user_2")

        assert response1 is not None
        assert response2 is not None
