"""
Test 02: Agent Validation
Tests input validation and error handling for agent creation.
"""

import pytest
from tests.fixtures.test_data import invalid_agent_configs


@pytest.mark.agent
class TestAgentValidation:
    """Agent validation tests."""

    def test_agent_creation_without_name(self, studio):
        """Test that agent creation fails without name."""
        config = {
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_creation_without_provider(self, studio):
        """Test that agent creation fails without provider."""
        config = {
            'name': 'test_agent',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_creation_without_role(self, studio):
        """Test that agent creation fails without role."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_creation_without_goal(self, studio):
        """Test that agent creation fails without goal."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_creation_without_instructions(self, studio):
        """Test that agent creation fails without instructions."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_temperature_negative(self, studio):
        """Test that agent creation fails with negative temperature."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'temperature': -1.0
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_temperature_too_high(self, studio):
        """Test that agent creation fails with temperature > 2.0."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'temperature': 2.5
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_top_p_negative(self, studio):
        """Test that agent creation fails with negative top_p."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'top_p': -0.1
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_top_p_too_high(self, studio):
        """Test that agent creation fails with top_p > 1.0."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'top_p': 1.1
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_provider(self, studio):
        """Test that agent creation fails with invalid provider."""
        config = {
            'name': 'test_agent',
            'provider': 'invalid-provider-xyz',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_empty_name(self, studio):
        """Test that agent creation fails with empty name."""
        config = {
            'name': '',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_empty_provider(self, studio):
        """Test that agent creation fails with empty provider."""
        config = {
            'name': 'test_agent',
            'provider': '',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_empty_role(self, studio):
        """Test that agent creation fails with empty role."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': '',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_empty_goal(self, studio):
        """Test that agent creation fails with empty goal."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': '',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_empty_instructions(self, studio):
        """Test that agent creation fails with empty instructions."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': ''
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_whitespace_only_fields(self, studio):
        """Test that agent creation fails with whitespace-only fields."""
        config = {
            'name': '   ',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test'
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_max_tokens_negative(self, studio):
        """Test that agent creation fails with negative max_tokens."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'max_tokens': -100
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_invalid_max_tokens_zero(self, studio):
        """Test that agent creation fails with zero max_tokens."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'max_tokens': 0
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_agent_validation_error_is_descriptive(self, studio):
        """Test that validation errors contain descriptive messages."""
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'temperature': -1.0
        }

        with pytest.raises(Exception) as exc_info:
            studio.agents.create(**config)

        error_message = str(exc_info.value).lower()
        # Error should be descriptive
        assert 'temperature' in error_message or 'validation' in error_message or 'invalid' in error_message

    def test_multiple_validation_errors(self, studio):
        """Test agent creation with multiple validation errors."""
        # Both temperature and top_p are invalid
        config = {
            'name': 'test_agent',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'temperature': -1.0,
            'top_p': 1.5
        }

        with pytest.raises(Exception):
            studio.agents.create(**config)

    def test_no_agent_created_on_validation_failure(self, studio):
        """Test that no agent is created when validation fails."""
        config = {
            'name': 'test_agent_fail',
            'provider': 'gpt-4o',
            'role': 'Test',
            'goal': 'Test',
            'instructions': 'Test',
            'temperature': -1.0
        }

        try:
            studio.agents.create(**config)
        except Exception:
            pass

        # Verify the agent was not created by trying to list agents
        agents = studio.agents.list()
        agent_names = [a.name for a in agents]
        assert 'test_agent_fail' not in agent_names

    @pytest.mark.parametrize('invalid_config', invalid_agent_configs())
    def test_invalid_agent_configs(self, studio, invalid_config):
        """Test various invalid agent configurations."""
        with pytest.raises(Exception):
            studio.agents.create(**invalid_config)
