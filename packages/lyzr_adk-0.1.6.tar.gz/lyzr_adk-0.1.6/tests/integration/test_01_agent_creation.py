"""
Test 01: Agent Creation
Tests agent creation with various configurations, CRUD operations, and cloning.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    full_agent_config,
    claude_agent_config,
    gemini_agent_config,
    deterministic_agent_config,
    temperature_test_values,
    top_p_test_values,
    provider_configs,
)


@pytest.mark.agent
class TestAgentCreation:
    """Agent creation tests."""

    def test_minimal_agent_creation(self, studio, cleanup_agents):
        """Test creating agent with minimal configuration."""
        config = minimal_agent_config()
        agent = studio.agents.create(**config)

        assert agent is not None
        assert agent.id is not None
        assert agent.name == config["name"]
        # Provider returns "ProviderName/model" format (e.g., "OpenAI/gpt-4o")
        assert config["provider"] in agent.provider
        assert agent.role == config["role"]
        assert agent.goal == config["goal"]
        assert agent.instructions == config["instructions"]

        cleanup_agents.append(agent.id)

    def test_full_agent_creation(self, studio, cleanup_agents):
        """Test creating agent with full configuration."""
        config = full_agent_config()
        # Remove unsupported parameters
        config.pop("max_tokens", None)
        config.pop("top_k", None)
        config.pop("frequency_penalty", None)
        config.pop("presence_penalty", None)

        agent = studio.agents.create(**config)

        assert agent is not None
        assert agent.id is not None
        assert agent.name == config["name"]
        assert agent.temperature == config["temperature"]
        assert agent.top_p == config["top_p"]

        cleanup_agents.append(agent.id)

    def test_agent_with_different_providers(self, studio, cleanup_agents):
        """Test agent creation with different providers."""
        providers = ["gpt-4o", "claude-sonnet-4-5", "gemini-2.0-flash"]

        for provider in providers:
            config = {
                "name": f'test_agent_{provider.replace("-", "_")}',
                "provider": provider,
                "role": "Test Agent",
                "goal": "Test with different provider",
                "instructions": f"Test agent using {provider}",
            }

            agent = studio.agents.create(**config)
            # Provider returns "ProviderName/model" format
            assert provider in agent.provider
            cleanup_agents.append(agent.id)

    @pytest.mark.parametrize("temperature", temperature_test_values())
    def test_agent_temperature_range(self, studio, cleanup_agents, temperature):
        """Test agent creation with different temperature values."""
        config = minimal_agent_config()
        config["temperature"] = temperature
        config["name"] = f"test_agent_temp_{temperature}"

        agent = studio.agents.create(**config)
        assert agent.temperature == temperature
        cleanup_agents.append(agent.id)

    @pytest.mark.parametrize("top_p", top_p_test_values())
    def test_agent_top_p_range(self, studio, cleanup_agents, top_p):
        """Test agent creation with different top_p values."""
        config = minimal_agent_config()
        config["top_p"] = top_p
        config["name"] = f"test_agent_top_p_{top_p}"

        agent = studio.agents.create(**config)
        assert agent.top_p == top_p
        cleanup_agents.append(agent.id)

    def test_agent_read(self, studio, cleanup_agents):
        """Test reading agent by ID."""
        config = minimal_agent_config()
        created_agent = studio.agents.create(**config)
        agent_id = created_agent.id

        # Read the agent
        retrieved_agent = studio.agents.get(agent_id)

        assert retrieved_agent is not None
        assert retrieved_agent.id == agent_id
        assert retrieved_agent.name == config["name"]

        cleanup_agents.append(agent_id)

    def test_agent_list(self, studio, cleanup_agents):
        """Test listing all agents."""
        # Create multiple agents
        config1 = minimal_agent_config()
        config1["name"] = "test_list_agent_1"
        agent1 = studio.agents.create(**config1)
        cleanup_agents.append(agent1.id)

        config2 = minimal_agent_config()
        config2["name"] = "test_list_agent_2"
        agent2 = studio.agents.create(**config2)
        cleanup_agents.append(agent2.id)

        # List all agents
        agents = studio.agents.list()

        agent_ids = [a.id for a in agents]
        assert agent1.id in agent_ids
        assert agent2.id in agent_ids

    def test_agent_update(self, studio, cleanup_agents):
        """Test updating agent configuration."""
        config = minimal_agent_config()
        agent = studio.agents.create(**config)
        agent_id = agent.id

        # Update the agent
        new_role = "Updated Test Agent"
        updated_agent = studio.agents.update(agent_id, role=new_role)

        assert updated_agent.role == new_role
        assert updated_agent.id == agent_id
        assert updated_agent.name == config["name"]  # Unchanged fields

        cleanup_agents.append(agent_id)

    def test_agent_update_multiple_fields(self, studio, cleanup_agents):
        """Test updating multiple agent fields."""
        config = minimal_agent_config()
        agent = studio.agents.create(**config)
        agent_id = agent.id

        # Update multiple fields
        new_goal = "Updated goal"
        new_temperature = 0.8
        updated_agent = studio.agents.update(agent_id, goal=new_goal, temperature=new_temperature)

        assert updated_agent.goal == new_goal
        assert updated_agent.temperature == new_temperature
        assert updated_agent.role == config["role"]  # Unchanged

        cleanup_agents.append(agent_id)

    def test_agent_delete(self, studio, cleanup_agents):
        """Test deleting an agent."""
        config = minimal_agent_config()
        agent = studio.agents.create(**config)
        agent_id = agent.id

        # Delete the agent
        studio.agents.delete(agent_id)

        # Verify deletion by attempting to get the agent
        # It should raise an error or return None
        try:
            retrieved = studio.agents.get(agent_id)
            assert retrieved is None or "error" in str(retrieved).lower()
        except Exception:
            # Expected - agent not found
            pass

    def test_agent_clone(self, studio, cleanup_agents):
        """Test cloning an agent."""
        config = minimal_agent_config()
        original_agent = studio.agents.create(**config)
        original_id = original_agent.id

        # Clone the agent
        cloned_agent = studio.agents.clone(original_id)

        assert cloned_agent is not None
        assert cloned_agent.id != original_id  # Different IDs
        assert (
            original_agent.name in cloned_agent.name
        )  # if no name is passed, "og_name (Clone)" format is used
        assert cloned_agent.provider == original_agent.provider
        assert cloned_agent.role == original_agent.role
        assert cloned_agent.goal == original_agent.goal
        assert cloned_agent.instructions == original_agent.instructions

        cleanup_agents.append(original_id)
        cleanup_agents.append(cloned_agent.id)

    def test_agent_clone_with_name_change(self, studio, cleanup_agents):
        """Test cloning an agent with a new name."""
        config = minimal_agent_config()
        original_agent = studio.agents.create(**config)
        original_id = original_agent.id

        new_name = "cloned_agent_new_name"
        # Use new_name parameter (SDK expects new_name, not name)
        cloned_agent = studio.agents.clone(original_id, new_name=new_name)

        assert cloned_agent.name == new_name
        assert cloned_agent.id != original_id

        cleanup_agents.append(original_id)
        cleanup_agents.append(cloned_agent.id)

    def test_agent_creation_idempotency(self, studio, cleanup_agents):
        """Test that creating agents with same config creates different agents."""
        config = minimal_agent_config()

        agent1 = studio.agents.create(**config)
        # Change name to avoid duplicate name conflicts
        config["name"] = "test_agent_duplicate_1"
        agent2 = studio.agents.create(**config)

        assert agent1.id != agent2.id
        assert agent1.name != agent2.name or agent1.id != agent2.id

        cleanup_agents.extend([agent1.id, agent2.id])

    def test_agent_bulk_delete(self, studio, cleanup_agents):
        """Test bulk deleting agents."""
        # Create multiple agents
        agent_ids = []
        for i in range(3):
            config = minimal_agent_config()
            config["name"] = f"test_bulk_delete_{i}"
            agent = studio.agents.create(**config)
            agent_ids.append(agent.id)

        # Bulk delete
        studio.agents.bulk_delete(agent_ids)

        # Verify deletion
        for agent_id in agent_ids:
            try:
                retrieved = studio.agents.get(agent_id)
                assert retrieved is None or "error" in str(retrieved).lower()
            except Exception:
                pass

    def test_agent_name_uniqueness(self, studio, cleanup_agents):
        """Test that agent names should be unique or handle duplicates gracefully."""
        config = minimal_agent_config()
        agent1 = studio.agents.create(**config)
        cleanup_agents.append(agent1.id)

        # Try creating another agent with the same name
        try:
            agent2 = studio.agents.create(**config)
            # If it succeeds, they should have different IDs
            assert agent1.id != agent2.id
            cleanup_agents.append(agent2.id)
        except Exception as e:
            # Expected - duplicate name not allowed
            assert "duplicate" in str(e).lower() or "exists" in str(e).lower()

    def test_agent_required_fields(self, studio):
        """Test that creating agent without required fields fails."""
        invalid_configs = [
            # Missing name
            {"provider": "gpt-4o", "role": "Test", "goal": "Test", "instructions": "Test"},
            # Missing provider
            {"name": "test", "role": "Test", "goal": "Test", "instructions": "Test"},
            # Missing role
            {"name": "test", "provider": "gpt-4o", "goal": "Test", "instructions": "Test"},
            # Missing goal
            {"name": "test", "provider": "gpt-4o", "role": "Test", "instructions": "Test"},
            # Missing instructions
            {"name": "test", "provider": "gpt-4o", "role": "Test", "goal": "Test"},
        ]

        for invalid_config in invalid_configs:
            with pytest.raises(Exception):
                studio.agents.create(**invalid_config)
