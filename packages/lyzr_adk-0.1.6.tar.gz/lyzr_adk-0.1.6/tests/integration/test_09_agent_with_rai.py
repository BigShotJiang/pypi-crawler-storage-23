"""
Test 09: Agent + RAI Guardrails Integration
Tests agent execution with RAI guardrails enabled.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    rai_policy_pii_redact,
    rai_policy_content_blocking
)


@pytest.mark.features
class TestAgentWithRAI:
    """Agent with RAI guardrails integration tests."""

    def test_agent_with_pii_redaction(self, studio, cleanup_agents, cleanup_policies):
        """Test agent with PII redaction enabled."""
        # Create RAI policy with PII redaction
        policy_config = rai_policy_pii_redact()
        policy = studio.rai.create_policy(**policy_config)
        cleanup_policies.append(policy.id)

        # Create agent
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_pii_redact'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Apply RAI policy to agent
        agent.add_rai_policy(policy)

        # Execute agent with prompt containing PII
        prompt = "My email is john@example.com and my phone is 555-1234"
        response = agent.run(prompt)

        assert response is not None
        # Response should be sanitized (email/phone redacted or marked)

    def test_agent_with_content_blocking(self, studio, cleanup_agents, cleanup_policies):
        """Test agent with content blocking."""
        policy_config = rai_policy_content_blocking()
        policy = studio.rai.create_policy(**policy_config)
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_content_block'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        # Test with normal content
        prompt = "Tell me about artificial intelligence"
        response = agent.run(prompt)

        assert response is not None

    def test_agent_without_rai_policy(self, studio, cleanup_agents):
        """Test agent execution without RAI policy."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_rai'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompt = "Hello, how can I get help?"
        response = agent.run(prompt)

        assert response is not None

    def test_agent_rai_policy_update(self, studio, cleanup_agents, cleanup_policies):
        """Test updating agent's RAI policy."""
        # Create agent
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_update'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Create and apply first policy
        policy1 = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy1.id)
        agent.add_rai_policy(policy1)

        # Update to second policy
        policy2 = studio.rai.create_policy(**rai_policy_content_blocking())
        cleanup_policies.append(policy2.id)
        agent.add_rai_policy(policy2)

        # Verify update
        agent_details = studio.agents.get(agent.id)
        assert agent_details is not None

    def test_agent_rai_policy_removal(self, studio, cleanup_agents, cleanup_policies):
        """Test removing RAI policy from agent."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_removal'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent.add_rai_policy(policy)
        studio.agents.remove_rai_policy(agent.id)

        # Agent should still work without policy
        response = agent.run("Test prompt")
        assert response is not None

    def test_agent_with_rai_streaming(self, studio, cleanup_agents, cleanup_policies):
        """Test streaming execution with RAI policy."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_stream'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        prompt = "Write a story about a person named John"
        chunks = list(agent.run(prompt, stream=True))

        assert len(chunks) > 0

    def test_agent_with_rai_multi_turn(self, studio, cleanup_agents, cleanup_policies):
        """Test multi-turn conversation with RAI policy."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_multiturn'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        session_id = "rai_multiturn_session"

        # Turn 1
        response1 = agent.run("Hello", session_id=session_id)
        assert response1 is not None

        # Turn 2
        response2 = agent.run("My name is Alice", session_id=session_id)
        assert response2 is not None

        # Turn 3
        response3 = agent.run("What is my name?", session_id=session_id)
        assert response3 is not None

    def test_rai_policy_applied_correctly(self, studio, cleanup_agents, cleanup_policies):
        """Test that RAI policy is properly applied to agent."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_applied'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Set policy
        agent.add_rai_policy(policy)

        # Get agent details to verify policy is set
        agent_details = studio.agents.get(agent.id)
        assert agent_details is not None

    def test_multiple_agents_different_policies(
        self, studio, cleanup_agents, cleanup_policies
    ):
        """Test multiple agents with different RAI policies."""
        # Create two policies
        policy1 = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy1.id)

        policy2 = studio.rai.create_policy(**rai_policy_content_blocking())
        cleanup_policies.append(policy2.id)

        # Create two agents
        agent1_config = minimal_agent_config()
        agent1_config['name'] = 'test_agent_policy1'
        agent1 = studio.agents.create(**agent1_config)
        cleanup_agents.append(agent1.id)

        agent2_config = minimal_agent_config()
        agent2_config['name'] = 'test_agent_policy2'
        agent2 = studio.agents.create(**agent2_config)
        cleanup_agents.append(agent2.id)

        # Apply different policies
        agent1.add_rai_policy(policy1)
        agent2.add_rai_policy(policy2)

        # Both should work
        response1 = agent1.run("Test prompt 1")
        response2 = agent2.run("Test prompt 2")

        assert response1 is not None
        assert response2 is not None

    def test_rai_policy_with_pii_email(self, studio, cleanup_agents, cleanup_policies):
        """Test RAI policy detects and handles email addresses."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_pii_email'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        prompt = "Contact support at support@example.com for issues"
        response = agent.run(prompt)

        assert response is not None

    def test_rai_policy_with_credit_card(self, studio, cleanup_agents, cleanup_policies):
        """Test RAI policy detects credit card numbers."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_credit_card'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        prompt = "My card is 4532123456789012"
        response = agent.run(prompt)

        assert response is not None

    def test_agent_rai_error_handling(self, studio, cleanup_agents, cleanup_policies):
        """Test error handling with RAI policies."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_error'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        # Test with edge case prompts
        try:
            response = agent.run("")
            assert response is not None
        except Exception:
            pass

    def test_rai_policy_with_tokens(self, studio, cleanup_agents, cleanup_policies):
        """Test RAI policy doesn't interfere with token counting."""
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_rai_tokens'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_rai_policy(policy)

        prompt = "Count: one, two, three, four, five"
        response = agent.run(prompt)

        assert response is not None
