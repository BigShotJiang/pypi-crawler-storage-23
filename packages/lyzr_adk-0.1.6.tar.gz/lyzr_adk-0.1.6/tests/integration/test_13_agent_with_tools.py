"""
Test 13: Agent + Tools Integration
Tests agent execution with local tools registered and executing.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config


@pytest.mark.features
class TestAgentWithTools:
    """Agent with tools integration tests."""

    def test_agent_executes_registered_tool(self, studio, cleanup_agents):
        """Test agent calling a registered tool."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_execute_tool'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def add(a: float, b: float) -> float:
            return a + b

        agent.add_tool(add)

        prompt = "Add 5 and 3"
        response = agent.run(prompt)

        assert response is not None

    def test_agent_with_multiple_tools(self, studio, cleanup_agents):
        """Test agent with multiple tools."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_multi_tools'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def add(a: float, b: float) -> float:
            return a + b

        def multiply(a: float, b: float) -> float:
            return a * b

        def divide(a: float, b: float) -> float:
            if b == 0:
                return 0
            return a / b

        agent.add_tool(add)
        agent.add_tool(multiply)
        agent.add_tool(divide)

        prompt = "Calculate: 10 + 5, 8 * 3, 20 / 4"
        response = agent.run(prompt)

        assert response is not None

    def test_agent_tools_with_streaming(self, studio, cleanup_agents):
        """Test tool execution during streaming."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_stream'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def get_fact(topic: str) -> str:
            facts = {
                'python': 'Python was created in 1991',
                'javascript': 'JavaScript was created in 1995'
            }
            return facts.get(topic, 'Unknown topic')

        agent.add_tool(get_fact)

        chunks = list(agent.run("Tell me a fact about Python", stream=True))
        assert len(chunks) > 0

    def test_agent_tools_in_conversation(self, studio, cleanup_agents):
        """Test tools in multi-turn conversation."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_conv'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        memory = {}

        def remember(key: str, value: str) -> str:
            memory[key] = value
            return f"Remembered: {key} = {value}"

        def recall(key: str) -> str:
            return memory.get(key, "Not found")

        agent.add_tool(remember)
        agent.add_tool(recall)

        session_id = "tools_conversation"

        response1 = agent.run("Remember that my favorite color is blue", session_id=session_id)
        assert response1 is not None

        response2 = agent.run("What is my favorite color?", session_id=session_id)
        assert response2 is not None

    def test_agent_tools_error_handling(self, studio, cleanup_agents):
        """Test tool error handling in agent."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_error'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def risky_operation(value: float) -> float:
            if value < 0:
                raise ValueError("Negative value not allowed")
            return value * 2

        agent.add_tool(risky_operation)

        # Should handle error gracefully
        response = agent.run("Do risky operation with -5")
        assert response is not None

    def test_agent_tools_return_values(self, studio, cleanup_agents):
        """Test agent using tool return values."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_return'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def get_user_info(user_id: str) -> dict:
            return {
                'id': user_id,
                'name': 'John Doe',
                'email': 'john@example.com'
            }

        def get_orders(user_id: str) -> list:
            return ['Order1', 'Order2', 'Order3']

        agent.add_tool(get_user_info)
        agent.add_tool(get_orders)

        response = agent.run("Get info for user123")
        assert response is not None

    def test_agent_tools_chaining(self, studio, cleanup_agents):
        """Test chained tool calls."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_chain'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def step1(value: int) -> int:
            return value * 2

        def step2(value: int) -> int:
            return value + 10

        def step3(value: int) -> int:
            return value * 3

        agent.add_tool(step1)
        agent.add_tool(step2)
        agent.add_tool(step3)

        response = agent.run("Execute steps: 5 through step1, then step2, then step3")
        assert response is not None

    def test_agent_remove_tool(self, studio, cleanup_agents):
        """Test removing tool from agent."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_remove_tool'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def temporary_tool() -> str:
            return "This should be removed"

        agent.add_tool(temporary_tool)

        # Verify tool exists
        tools = agent.get_tools()
        assert 'temporary_tool' in [t.name for t in tools]

        # Remove tool
        agent.remove_tool('temporary_tool')

        # Verify removal
        tools = agent.get_tools()
        assert 'temporary_tool' not in [t.name for t in tools]

    def test_agent_tools_with_memory(self, studio, cleanup_agents, cleanup_memories):
        """Test tools with agent memory."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_memory'
        agent_config['memory'] = 10  # Lyzr memory: persist 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def track_count() -> int:
            return 42

        agent.add_tool(track_count)

        session_id = "tools_memory"

        response1 = agent.run("Call the tracking function", session_id=session_id)
        assert response1 is not None

        response2 = agent.run("Call the tracking function again", session_id=session_id)
        assert response2 is not None

    def test_agent_tools_with_kb(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test tools with knowledge base."""
        from tests.fixtures.sample_configs import knowledge_base_config_qdrant
        from tests.fixtures.test_data import kb_training_text

        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_tools_kb'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def search_tool(query: str) -> str:
            return f"Searching for: {query}"

        agent.add_tool(search_tool)

        response = agent.run("Use the KB and search tool to find information", knowledge_bases=[kb])
        assert response is not None

    def test_agent_tools_no_tools(self, studio, cleanup_agents):
        """Test agent without tools."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_tools'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Answer from knowledge")
        assert response is not None

    def test_agent_tools_empty_parameters(self, studio, cleanup_agents):
        """Test tool with no parameters."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_param_tool'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def get_timestamp() -> str:
            return "2024-01-01T00:00:00Z"

        agent.add_tool(get_timestamp)

        response = agent.run("Get the current timestamp")
        assert response is not None

    def test_agent_tools_type_handling(self, studio, cleanup_agents):
        """Test tools with different parameter types."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_type_tools'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        def process_data(
            name: str,
            count: int,
            score: float,
            active: bool
        ) -> str:
            return f"Processed: {name}, {count}, {score}, {active}"

        agent.add_tool(process_data)

        response = agent.run("Process data with string, int, float, and bool")
        assert response is not None
