"""
Test 23: Studio Envs
Initialize studio with multiple environments and test if all environments initialize properly
"""

import pytest
from lyzr.studio import Studio
from lyzr.urls import ServiceURLs
from tests.fixtures.sample_configs import (
    minimal_agent_config,
)


@pytest.mark.environments
class TestStudioEnvironments:
    """Environment Tests"""

    def test_prod_env(
        self,
    ):
        """Test prod env init"""
        studio = Studio(env="prod")
        assert studio.env_config.rag_api == "https://rag-prod.studio.lyzr.ai"
        assert studio.env_config.agent_api == "https://agent-prod.studio.lyzr.ai"
        assert studio.env_config.rai_api == "https://rai-prod.studio.lyzr.ai"

    def test_dev_env(
        self,
    ):
        """Test dev env init"""
        studio = Studio(env="dev")
        assert studio.env_config.rag_api == "https://rag-dev.test.studio.lyzr.ai"
        assert studio.env_config.agent_api == "https://agent-dev.test.studio.lyzr.ai"
        assert studio.env_config.rai_api == "https://srs-dev.test.studio.lyzr.ai"

    def test_custom_env(
        self,
    ):
        """Test custom env init"""
        service_urls = ServiceURLs(
            agent_api="http://localhost:8001",
            rag_api="http://localhost:8001",
            rai_api="http://localhost:8001",
        )

        studio = Studio(env=service_urls)
        assert studio.env_config.rag_api == "http://localhost:8001"
        assert studio.env_config.agent_api == "http://localhost:8001"
        assert studio.env_config.rai_api == "http://localhost:8001"
