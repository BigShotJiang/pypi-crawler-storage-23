"""Integration tests for skills module."""
import os
import pytest
import tempfile
from pathlib import Path

from lyzr.skills.models import Skill, SkillMetadata
from lyzr.skills.loader import parse_skill_file, discover_skills, load_skills
from lyzr.skills.tool import generate_skills_metadata_prompt, create_use_skill_tool


# ── Sample skill content ──────────────────────────────────────────────

VALID_SKILL_CONTENT = """\
---
name: research
description: Systematic research methodology
version: 1.0.0
tags: [research, analysis]
---

# Research Skill

When conducting research:
1. Understand the query
2. Gather information
3. Synthesize findings
"""

MINIMAL_SKILL_CONTENT = """\
---
name: helper
description: A simple helper skill
---

Do helpful things.
"""

NO_FRONTMATTER_CONTENT = """\
# Just markdown, no frontmatter
Some content here.
"""

INVALID_YAML_CONTENT = """\
---
name: broken
description: [invalid yaml
  this is not valid
---

Content here.
"""

MISSING_NAME_CONTENT = """\
---
description: Missing the name field
version: 1.0.0
---

Content here.
"""

MISSING_DESCRIPTION_CONTENT = """\
---
name: no-desc
version: 1.0.0
---

Content here.
"""


# ── Fixtures ──────────────────────────────────────────────────────────

@pytest.fixture
def skill_dir(tmp_path):
    """Create a temp directory with sample SKILL.md files."""
    # Skill in a subdirectory
    research_dir = tmp_path / "research"
    research_dir.mkdir()
    (research_dir / "SKILL.md").write_text(VALID_SKILL_CONTENT)

    # Another skill in a subdirectory
    helper_dir = tmp_path / "helper"
    helper_dir.mkdir()
    (helper_dir / "SKILL.md").write_text(MINIMAL_SKILL_CONTENT)

    return tmp_path


@pytest.fixture
def single_skill_file(tmp_path):
    """Create a single SKILL.md file."""
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text(VALID_SKILL_CONTENT)
    return skill_file


@pytest.fixture
def sample_skills():
    """Create Skill objects for tool tests."""
    return [
        Skill(
            metadata=SkillMetadata(
                name="research",
                description="Systematic research methodology",
                version="1.0.0",
                tags=["research", "analysis"],
            ),
            content="# Research\n\n1. Understand\n2. Gather\n3. Synthesize",
        ),
        Skill(
            metadata=SkillMetadata(
                name="git-helper",
                description="Git workflow assistant",
                version="2.0.0",
                tags=["git", "version-control"],
            ),
            content="# Git Helper\n\nUse conventional commits.",
        ),
    ]


# ── Models Tests ──────────────────────────────────────────────────────

class TestSkillModels:
    """Tests for Skill and SkillMetadata models."""

    def test_skill_metadata_creation(self):
        """Test 1: SkillMetadata with all fields."""
        meta = SkillMetadata(
            name="test-skill",
            description="A test skill",
            version="2.0.0",
            tags=["test", "example"],
        )
        assert meta.name == "test-skill"
        assert meta.description == "A test skill"
        assert meta.version == "2.0.0"
        assert meta.tags == ["test", "example"]

    def test_skill_metadata_defaults(self):
        """Test 2: SkillMetadata defaults for optional fields."""
        meta = SkillMetadata(name="minimal", description="Minimal skill")
        assert meta.version == "1.0.0"
        assert meta.tags == []

    def test_skill_creation(self):
        """Test 3: Full Skill creation with metadata and content."""
        meta = SkillMetadata(name="test", description="Test skill")
        skill = Skill(metadata=meta, content="# Instructions\nDo stuff.")
        assert skill.name == "test"
        assert skill.description == "Test skill"
        assert skill.version == "1.0.0"
        assert skill.tags == []
        assert skill.content == "# Instructions\nDo stuff."
        assert skill.path is None

    def test_skill_with_path(self, tmp_path):
        """Test 4: Skill with file path."""
        meta = SkillMetadata(name="test", description="Test skill")
        skill = Skill(metadata=meta, content="Content", path=tmp_path / "SKILL.md")
        assert skill.path == tmp_path / "SKILL.md"

    def test_skill_str_repr(self):
        """Test 5: Skill string representation."""
        meta = SkillMetadata(name="my-skill", description="desc", version="3.0.0")
        skill = Skill(metadata=meta, content="Content")
        assert str(skill) == "Skill(name='my-skill', version='3.0.0')"
        assert repr(skill) == "Skill(name='my-skill', version='3.0.0')"

    def test_skill_convenience_properties(self):
        """Test 6: Skill convenience properties delegate to metadata."""
        meta = SkillMetadata(
            name="prop-test",
            description="Property test",
            version="1.2.3",
            tags=["a", "b"],
        )
        skill = Skill(metadata=meta, content="Content")
        assert skill.name == meta.name
        assert skill.description == meta.description
        assert skill.version == meta.version
        assert skill.tags == meta.tags


# ── Parser Tests ──────────────────────────────────────────────────────

class TestParseSkillFile:
    """Tests for parse_skill_file."""

    def test_parse_valid_skill(self, single_skill_file):
        """Test 7: Parse a valid SKILL.md file."""
        skill = parse_skill_file(single_skill_file)
        assert skill.name == "research"
        assert skill.description == "Systematic research methodology"
        assert skill.version == "1.0.0"
        assert skill.tags == ["research", "analysis"]
        assert "# Research Skill" in skill.content
        assert "Synthesize findings" in skill.content
        assert skill.path == single_skill_file

    def test_parse_minimal_skill(self, tmp_path):
        """Test 8: Parse a skill with only required fields."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(MINIMAL_SKILL_CONTENT)
        skill = parse_skill_file(skill_file)
        assert skill.name == "helper"
        assert skill.description == "A simple helper skill"
        assert skill.version == "1.0.0"
        assert skill.tags == []
        assert "Do helpful things." in skill.content

    def test_parse_missing_file(self, tmp_path):
        """Test 9: FileNotFoundError for non-existent file."""
        with pytest.raises(FileNotFoundError, match="Skill file not found"):
            parse_skill_file(tmp_path / "does_not_exist.md")

    def test_parse_no_frontmatter(self, tmp_path):
        """Test 10: ValueError when frontmatter is missing."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(NO_FRONTMATTER_CONTENT)
        with pytest.raises(ValueError, match="Expected YAML frontmatter"):
            parse_skill_file(skill_file)

    def test_parse_invalid_yaml(self, tmp_path):
        """Test 11: ValueError for malformed YAML."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(INVALID_YAML_CONTENT)
        with pytest.raises(ValueError, match="Invalid YAML frontmatter"):
            parse_skill_file(skill_file)

    def test_parse_missing_name(self, tmp_path):
        """Test 12: ValueError when name field is missing."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(MISSING_NAME_CONTENT)
        with pytest.raises(ValueError, match="Missing required field 'name'"):
            parse_skill_file(skill_file)

    def test_parse_missing_description(self, tmp_path):
        """Test 13: ValueError when description field is missing."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(MISSING_DESCRIPTION_CONTENT)
        with pytest.raises(ValueError, match="Missing required field 'description'"):
            parse_skill_file(skill_file)

    def test_parse_non_dict_frontmatter(self, tmp_path):
        """Test 14: ValueError when frontmatter is not a dict."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text("---\n- just a list\n---\n\nContent\n")
        with pytest.raises(ValueError, match="must be a dictionary"):
            parse_skill_file(skill_file)


# ── Discovery Tests ───────────────────────────────────────────────────

class TestDiscoverSkills:
    """Tests for discover_skills."""

    def test_discover_in_subdirectories(self, skill_dir):
        """Test 15: Discover SKILL.md files in subdirectories."""
        found = discover_skills(search_paths=[skill_dir])
        names = [p.parent.name for p in found]
        assert "research" in names
        assert "helper" in names
        assert len(found) == 2

    def test_discover_direct_skill_file(self, tmp_path):
        """Test 16: Discover SKILL.md directly in search path."""
        (tmp_path / "SKILL.md").write_text(VALID_SKILL_CONTENT)
        found = discover_skills(search_paths=[tmp_path])
        assert len(found) >= 1
        assert any(p.name == "SKILL.md" for p in found)

    def test_discover_empty_directory(self, tmp_path):
        """Test 17: Empty result for directory with no skills."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        found = discover_skills(search_paths=[empty_dir])
        assert found == []

    def test_discover_nonexistent_directory(self, tmp_path):
        """Test 18: Nonexistent directory is silently skipped."""
        found = discover_skills(search_paths=[tmp_path / "no_such_dir"])
        assert found == []

    def test_discover_multiple_search_paths(self, tmp_path):
        """Test 19: Discover across multiple search paths."""
        dir_a = tmp_path / "a" / "skill-one"
        dir_b = tmp_path / "b" / "skill-two"
        dir_a.mkdir(parents=True)
        dir_b.mkdir(parents=True)
        (dir_a / "SKILL.md").write_text(VALID_SKILL_CONTENT)
        (dir_b / "SKILL.md").write_text(MINIMAL_SKILL_CONTENT)

        found = discover_skills(search_paths=[tmp_path / "a", tmp_path / "b"])
        assert len(found) == 2


# ── load_skills Tests ─────────────────────────────────────────────────

class TestLoadSkills:
    """Tests for load_skills."""

    def test_load_from_explicit_paths(self, single_skill_file):
        """Test 20: Load skills from explicit file paths."""
        skills = load_skills(paths=[single_skill_file])
        assert len(skills) == 1
        assert skills[0].name == "research"

    def test_load_from_string_paths(self, single_skill_file):
        """Test 21: Load skills from string paths."""
        skills = load_skills(paths=[str(single_skill_file)])
        assert len(skills) == 1
        assert skills[0].name == "research"

    def test_load_from_search_paths(self, skill_dir):
        """Test 22: Load all skills from search paths."""
        skills = load_skills(search_paths=[skill_dir])
        assert len(skills) == 2
        names = {s.name for s in skills}
        assert names == {"research", "helper"}

    def test_load_filter_by_name(self, skill_dir):
        """Test 23: Filter skills by name."""
        skills = load_skills(search_paths=[skill_dir], names=["research"])
        assert len(skills) == 1
        assert skills[0].name == "research"

    def test_load_filter_no_match(self, skill_dir):
        """Test 24: Filter by name with no matches returns empty."""
        skills = load_skills(search_paths=[skill_dir], names=["nonexistent"])
        assert skills == []

    def test_load_empty_search_paths(self, tmp_path):
        """Test 25: Empty result when no skills found."""
        empty = tmp_path / "empty"
        empty.mkdir()
        skills = load_skills(search_paths=[empty])
        assert skills == []

    def test_load_skips_invalid_files(self, tmp_path):
        """Test 26: Invalid skill files are skipped with warning."""
        bad_dir = tmp_path / "bad-skill"
        bad_dir.mkdir()
        (bad_dir / "SKILL.md").write_text(NO_FRONTMATTER_CONTENT)

        good_dir = tmp_path / "good-skill"
        good_dir.mkdir()
        (good_dir / "SKILL.md").write_text(VALID_SKILL_CONTENT)

        with pytest.warns(UserWarning, match="Failed to load skill"):
            skills = load_skills(search_paths=[tmp_path])

        assert len(skills) == 1
        assert skills[0].name == "research"

    def test_load_explicit_path_not_found(self, tmp_path):
        """Test 27: Explicit path that doesn't exist raises error."""
        with pytest.raises(FileNotFoundError):
            load_skills(paths=[tmp_path / "nope" / "SKILL.md"])


# ── Metadata Prompt Tests ─────────────────────────────────────────────

class TestGenerateSkillsMetadataPrompt:
    """Tests for generate_skills_metadata_prompt."""

    def test_prompt_with_skills(self, sample_skills):
        """Test 28: Generated prompt contains skill info."""
        prompt = generate_skills_metadata_prompt(sample_skills)
        assert "## Available Skills" in prompt
        assert "**research** (v1.0.0)" in prompt
        assert "Systematic research methodology" in prompt
        assert "Tags: research, analysis" in prompt
        assert "**git-helper** (v2.0.0)" in prompt
        assert "Git workflow assistant" in prompt
        assert "Tags: git, version-control" in prompt

    def test_prompt_empty_skills(self):
        """Test 29: Empty string for no skills."""
        assert generate_skills_metadata_prompt([]) == ""

    def test_prompt_skill_without_tags(self):
        """Test 30: Skill without tags omits tags line."""
        skills = [
            Skill(
                metadata=SkillMetadata(name="notags", description="No tags skill"),
                content="Content",
            )
        ]
        prompt = generate_skills_metadata_prompt(skills)
        assert "**notags**" in prompt
        assert "Tags:" not in prompt


# ── use_skill Tool Tests ──────────────────────────────────────────────

class TestCreateUseSkillTool:
    """Tests for create_use_skill_tool."""

    def test_tool_creation(self, sample_skills):
        """Test 31: Tool is created with correct properties."""
        tool = create_use_skill_tool(sample_skills)
        assert tool.name == "use_skill"
        assert "research" in tool.description
        assert "git-helper" in tool.description
        assert tool.parameters is not None
        assert tool.function is not None

    def test_tool_returns_skill_content(self, sample_skills):
        """Test 32: Tool returns correct skill content."""
        tool = create_use_skill_tool(sample_skills)
        result = tool.function(skill_name="research")
        assert "# Research" in result
        assert "Synthesize" in result

    def test_tool_returns_different_skill(self, sample_skills):
        """Test 33: Tool returns content for different skill."""
        tool = create_use_skill_tool(sample_skills)
        result = tool.function(skill_name="git-helper")
        assert "# Git Helper" in result
        assert "conventional commits" in result

    def test_tool_unknown_skill(self, sample_skills):
        """Test 34: Tool returns error for unknown skill name."""
        tool = create_use_skill_tool(sample_skills)
        result = tool.function(skill_name="nonexistent")
        assert "Error" in result
        assert "nonexistent" in result
        assert "research" in result
        assert "git-helper" in result

    def test_tool_parameter_schema(self, sample_skills):
        """Test 35: Tool parameter schema is correct."""
        tool = create_use_skill_tool(sample_skills)
        params = tool.parameters
        assert params["type"] == "object"
        assert "skill_name" in params["properties"]
        assert params["properties"]["skill_name"]["type"] == "string"
        assert params["required"] == ["skill_name"]
