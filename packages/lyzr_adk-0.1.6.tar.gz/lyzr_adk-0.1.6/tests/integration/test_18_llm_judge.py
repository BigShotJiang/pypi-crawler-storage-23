"""
Test 18: LLM Judge
Tests agent with LLM judge evaluation.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config


@pytest.mark.slow
class TestLLMJudge:
    """Agent LLM judge tests."""

    def test_agent_with_llm_judge(self, studio, cleanup_agents):
        """Test agent with LLM judge enabled."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_llm_judge'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Solve this problem", enable_llm_judge=True)
        assert response is not None

    def test_llm_judge_quality_assessment(self, studio, cleanup_agents):
        """Test LLM judge quality assessment."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_judge_quality'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Generate content and evaluate quality", enable_llm_judge=True)
        assert response is not None

    def test_llm_judge_output(self, studio, cleanup_agents):
        """Test LLM judge output format."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_judge_output'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Produce output to be judged", enable_llm_judge=True)
        assert response is not None
