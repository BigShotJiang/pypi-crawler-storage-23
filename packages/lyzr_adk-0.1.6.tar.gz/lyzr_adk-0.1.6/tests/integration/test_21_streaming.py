"""
Test 21: Streaming
Tests streaming response handling and chunk processing.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import streaming_test_prompt


@pytest.mark.slow
class TestStreaming:
    """Streaming functionality tests."""

    def test_basic_streaming(self, studio, cleanup_agents):
        """Test basic streaming."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_basic'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        chunks = []
        for chunk in agent.run(streaming_test_prompt(), stream=True):
            chunks.append(chunk)

        assert len(chunks) > 0

    def test_stream_chunk_collection(self, studio, cleanup_agents):
        """Test collecting all stream chunks."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_collect'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        chunks = list(agent.run(streaming_test_prompt(), stream=True))
        assert len(chunks) > 0
        assert chunks[-1].done == True

    def test_stream_done_flag(self, studio, cleanup_agents):
        """Test done flag on final chunk."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_done'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        chunks = list(agent.run(streaming_test_prompt(), stream=True))
        final_chunk = chunks[-1]
        assert final_chunk.done == True

    def test_text_reconstruction_from_stream(self, studio, cleanup_agents):
        """Test reconstructing text from stream chunks."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_reconstruct'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        full_text = ""
        for chunk in agent.run(streaming_test_prompt(), stream=True):
            if hasattr(chunk, 'content'):
                full_text += chunk.content

        assert len(full_text) > 0

    def test_stream_order_preservation(self, studio, cleanup_agents):
        """Test order preservation in streaming."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_order'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        chunks = list(agent.run("Write in order: 1, 2, 3, 4, 5", stream=True))
        assert len(chunks) > 0

    def test_stream_with_session(self, studio, cleanup_agents):
        """Test streaming with session management."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_stream_session'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "stream_session"
        chunks = list(agent.run(streaming_test_prompt(), stream=True, session_id=session_id))
        assert len(chunks) > 0
