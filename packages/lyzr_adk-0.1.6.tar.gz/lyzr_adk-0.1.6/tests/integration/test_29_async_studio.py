"""
Test 29: Async Studio
Tests Studio async context manager and convenience methods.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from lyzr.studio import Studio
from lyzr.http import AsyncHTTPClient
from lyzr.models import Agent


SAMPLE_AGENT_DATA = {
    "_id": "agent_test_123",
    "api_key": "sk-test",
    "name": "Test Agent",
    "agent_role": "Tester",
    "agent_goal": "Test things",
    "agent_instructions": "Test carefully",
    "provider_id": "OpenAI",
    "model": "gpt-4o",
    "temperature": 0.7,
    "top_p": 0.9,
    "tools": [],
    "features": [],
    "managed_agents": [],
    "tool_configs": [],
    "a2a_tools": [],
    "llm_credential_id": "lyzr_openai",
    "store_messages": True,
    "file_output": False,
}


class TestStudioAsyncInit:
    """Test Studio async initialization."""

    def test_ensure_async_clients_creates_clients(self):
        """Test that _ensure_async_clients creates async HTTP clients."""
        studio = Studio(api_key="sk-test")

        studio._ensure_async_clients()

        assert hasattr(studio, '_async_http')
        assert hasattr(studio, '_async_http_rag')
        assert hasattr(studio, '_async_http_rai')
        assert isinstance(studio._async_http, AsyncHTTPClient)
        assert isinstance(studio._async_http_rag, AsyncHTTPClient)
        assert isinstance(studio._async_http_rai, AsyncHTTPClient)
        assert studio._async_initialized is True

    def test_ensure_async_clients_idempotent(self):
        """Test that calling _ensure_async_clients twice is safe."""
        studio = Studio(api_key="sk-test")

        studio._ensure_async_clients()
        first_http = studio._async_http

        studio._ensure_async_clients()
        second_http = studio._async_http

        assert first_http is second_http  # Same instance

    def test_ensure_async_clients_injects_into_modules(self):
        """Test that async clients are injected into all modules."""
        studio = Studio(api_key="sk-test")

        studio._ensure_async_clients()

        assert studio.agents._async_http is studio._async_http
        assert studio.agents._inference._async_http is studio._async_http
        assert studio.contexts._async_http is studio._async_http
        assert studio.memory._async_http is studio._async_http
        assert studio.rai._async_http is studio._async_http_rai
        assert studio.knowledge_bases._async_http is studio._async_http_rag


class TestStudioAsyncContextManager:
    """Test Studio async context manager."""

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test async with Studio() as studio."""
        async with Studio(api_key="sk-test") as studio:
            assert studio._async_initialized is True
            assert isinstance(studio._async_http, AsyncHTTPClient)

        # After exit, async clients should be closed
        assert studio._async_initialized is False

    @pytest.mark.asyncio
    async def test_async_context_manager_returns_studio(self):
        """Test that async context manager returns Studio instance."""
        async with Studio(api_key="sk-test") as studio:
            assert isinstance(studio, Studio)


class TestStudioAsyncConvenienceMethods:
    """Test Studio async convenience methods."""

    @pytest.fixture
    def studio(self):
        """Create Studio and inject mock async HTTP."""
        s = Studio(api_key="sk-test")
        return s

    @pytest.mark.asyncio
    async def test_acreate_agent(self, studio):
        """Test studio.acreate_agent() initializes async and delegates."""
        mock_async = AsyncMock(spec=AsyncHTTPClient)
        mock_async.api_key = "sk-test"
        mock_async.base_url = "https://agent-prod.studio.lyzr.ai"
        mock_async.timeout = 300

        # Manually set to avoid real client creation
        studio._ensure_async_clients()

        # Replace with mock
        studio.agents._async_http = mock_async
        studio.agents._inference._async_http = mock_async

        # Setup mock responses
        mock_async.post.return_value = {"agent_id": "agent_new"}
        mock_async.get.return_value = {**SAMPLE_AGENT_DATA, "_id": "agent_new", "name": "New Bot"}

        agent = await studio.acreate_agent(
            name="New Bot",
            provider="openai/gpt-4o",
            role="Helper",
            goal="Help",
            instructions="Be helpful",
        )

        assert isinstance(agent, Agent)
        assert agent.name == "New Bot"

    @pytest.mark.asyncio
    async def test_aget_agent(self, studio):
        """Test studio.aget_agent() delegates correctly."""
        studio._ensure_async_clients()

        mock_async = AsyncMock(spec=AsyncHTTPClient)
        mock_async.api_key = "sk-test"
        mock_async.base_url = "https://agent-prod.studio.lyzr.ai"
        mock_async.timeout = 300

        studio.agents._async_http = mock_async
        studio.agents._inference._async_http = mock_async

        mock_async.get.return_value = SAMPLE_AGENT_DATA.copy()

        agent = await studio.aget_agent("agent_test_123")

        assert isinstance(agent, Agent)
        assert agent.id == "agent_test_123"

    @pytest.mark.asyncio
    async def test_alist_agents(self, studio):
        """Test studio.alist_agents() delegates correctly."""
        studio._ensure_async_clients()

        mock_async = AsyncMock(spec=AsyncHTTPClient)
        mock_async.api_key = "sk-test"
        mock_async.base_url = "https://agent-prod.studio.lyzr.ai"
        mock_async.timeout = 300

        studio.agents._async_http = mock_async
        studio.agents._inference._async_http = mock_async

        mock_async.get.return_value = [SAMPLE_AGENT_DATA.copy()]

        agents = await studio.alist_agents()

        assert len(agents) == 1

    @pytest.mark.asyncio
    async def test_adelete_agent(self, studio):
        """Test studio.adelete_agent() delegates correctly."""
        studio._ensure_async_clients()

        mock_async = AsyncMock(spec=AsyncHTTPClient)
        mock_async.api_key = "sk-test"
        mock_async.base_url = "https://agent-prod.studio.lyzr.ai"
        mock_async.timeout = 300

        studio.agents._async_http = mock_async

        mock_async.delete.return_value = True

        result = await studio.adelete_agent("agent_test_123")

        assert result is True


class TestStudioAsyncClose:
    """Test Studio async close."""

    @pytest.mark.asyncio
    async def test_aclose(self):
        """Test studio.aclose() closes all async clients."""
        studio = Studio(api_key="sk-test")
        studio._ensure_async_clients()

        # Replace with mocks to verify close is called
        mock_http = AsyncMock()
        mock_rag = AsyncMock()
        mock_rai = AsyncMock()

        studio._async_http = mock_http
        studio._async_http_rag = mock_rag
        studio._async_http_rai = mock_rai

        await studio.aclose()

        mock_http.close.assert_awaited_once()
        mock_rag.close.assert_awaited_once()
        mock_rai.close.assert_awaited_once()
        assert studio._async_initialized is False

    @pytest.mark.asyncio
    async def test_aclose_without_init(self):
        """Test aclose when async was never initialized."""
        studio = Studio(api_key="sk-test")

        # Should not raise
        await studio.aclose()
