"""
Test 16: Reflection
Tests agent with reflection capability.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import reflection_test_prompt


@pytest.mark.slow
class TestReflection:
    """Agent reflection tests."""

    def test_agent_with_reflection_enabled(self, studio, cleanup_agents):
        """Test agent with reflection enabled."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_reflection'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run(reflection_test_prompt(), enable_reflection=True)
        assert response is not None

    def test_agent_reflection_quality(self, studio, cleanup_agents):
        """Test reflection quality."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_reflection_quality'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Explain something and reflect on your explanation", enable_reflection=True)
        assert response is not None

    def test_reflection_toggle(self, studio, cleanup_agents):
        """Test toggling reflection on/off."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_reflection_toggle'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # With reflection
        response1 = agent.run("Answer with reflection", enable_reflection=True)
        # Without reflection
        response2 = agent.run("Answer without reflection", enable_reflection=False)

        assert response1 is not None
        assert response2 is not None
