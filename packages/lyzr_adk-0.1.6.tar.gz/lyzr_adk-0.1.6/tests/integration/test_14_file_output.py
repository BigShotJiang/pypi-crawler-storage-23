"""
Test 14: File Output
Tests agent generation of file artifacts.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import file_output_prompts


@pytest.mark.slow
class TestFileOutput:
    """File output generation tests."""

    def test_agent_generates_markdown_file(self, studio, cleanup_agents):
        """Test agent generating markdown file."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_markdown'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = file_output_prompts()
        response = agent.run(prompts['markdown'])
        assert response is not None

    def test_agent_generates_json_file(self, studio, cleanup_agents):
        """Test agent generating JSON file."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_json'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = file_output_prompts()
        response = agent.run(prompts['json'])
        assert response is not None

    def test_agent_generates_csv_file(self, studio, cleanup_agents):
        """Test agent generating CSV file."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_csv'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = file_output_prompts()
        response = agent.run(prompts['csv'])
        assert response is not None

    def test_agent_generates_text_file(self, studio, cleanup_agents):
        """Test agent generating text file."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_text'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = file_output_prompts()
        response = agent.run(prompts['text'])
        assert response is not None

    def test_file_output_artifact_retrieval(self, studio, cleanup_agents):
        """Test retrieving generated file artifact."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_file_artifact'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Generate a markdown file with 3 sections")
        assert response is not None
        # Check if response contains artifact info

    def test_multiple_file_formats(self, studio, cleanup_agents):
        """Test agent generating multiple file formats."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_multi_format'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = file_output_prompts()
        response1 = agent.run(prompts['markdown'])
        response2 = agent.run(prompts['json'])
        response3 = agent.run(prompts['csv'])

        assert response1 is not None
        assert response2 is not None
        assert response3 is not None
