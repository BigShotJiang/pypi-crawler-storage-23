"""
Test 19: Groundedness
Tests agent with groundedness verification against facts.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import (
    groundedness_facts,
    groundedness_test_prompt
)


@pytest.mark.slow
class TestGroundedness:
    """Agent groundedness tests."""

    def test_agent_with_groundedness_facts(self, studio, cleanup_agents):
        """Test agent with groundedness facts."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_groundedness'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        facts = groundedness_facts()
        response = agent.run(groundedness_test_prompt(), groundedness_facts=facts)
        assert response is not None

    def test_dynamic_fact_addition(self, studio, cleanup_agents):
        """Test adding facts dynamically."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_dynamic_facts'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Set initial facts
        facts1 = ["Fact 1", "Fact 2"]
        response1 = agent.run("Answer with facts", groundedness_facts=facts1)

        # Update facts
        facts2 = ["New Fact 1", "New Fact 2", "New Fact 3"]
        response2 = agent.run("Answer with updated facts", groundedness_facts=facts2)

        assert response1 is not None
        assert response2 is not None

    def test_groundedness_response_validation(self, studio, cleanup_agents):
        """Test validation of response against facts."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_groundedness_validate'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        facts = groundedness_facts()
        response = agent.run("Provide information grounded in facts", groundedness_facts=facts)
        assert response is not None

    def test_fact_based_response_generation(self, studio, cleanup_agents):
        """Test generating responses based on provided facts."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_fact_based'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        facts = ["Company X was founded in 2020", "It specializes in AI"]
        response = agent.run("Tell me about the company", groundedness_facts=facts)
        assert response is not None

    def test_without_groundedness_facts(self, studio, cleanup_agents):
        """Test agent without groundedness facts."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_groundedness'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Answer without groundedness facts")
        assert response is not None
