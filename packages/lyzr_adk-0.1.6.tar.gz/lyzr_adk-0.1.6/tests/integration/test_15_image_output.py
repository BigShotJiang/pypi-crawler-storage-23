"""
Test 15: Image Output
Tests agent generation of images.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import image_prompts


@pytest.mark.slow
class TestImageOutput:
    """Image output generation tests."""

    def test_agent_generates_image_dalle(self, studio, cleanup_agents):
        """Test agent generating image with DALL-E."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_image_dalle'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompt = image_prompts()[0]
        response = agent.run(f"Generate an image: {prompt}")
        assert response is not None

    def test_agent_generates_image_gemini(self, studio, cleanup_agents):
        """Test agent generating image with Gemini."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_image_gemini'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompt = image_prompts()[0]
        response = agent.run(f"Create image using Gemini: {prompt}")
        assert response is not None

    def test_multiple_image_generation(self, studio, cleanup_agents):
        """Test generating multiple images."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_multi_image'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = image_prompts()
        for prompt in prompts:
            response = agent.run(f"Generate: {prompt}")
            assert response is not None

    def test_image_artifact_retrieval(self, studio, cleanup_agents):
        """Test retrieving generated image artifact."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_image_artifact'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Generate a beautiful landscape image")
        assert response is not None
