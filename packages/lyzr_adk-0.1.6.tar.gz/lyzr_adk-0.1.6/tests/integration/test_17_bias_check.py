"""
Test 17: Bias Check
Tests agent with bias detection.
"""

import pytest
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import bias_check_prompt


@pytest.mark.slow
class TestBiasCheck:
    """Agent bias detection tests."""

    def test_agent_with_bias_check_enabled(self, studio, cleanup_agents):
        """Test agent with bias detection enabled."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_bias_check'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run(bias_check_prompt(), enable_bias_check=True)
        assert response is not None

    def test_bias_detection_output(self, studio, cleanup_agents):
        """Test bias detection output."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_bias_output'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Write about different careers", enable_bias_check=True)
        assert response is not None

    def test_bias_toggle(self, studio, cleanup_agents):
        """Test toggling bias check on/off."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_bias_toggle'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response1 = agent.run("Answer with bias check", enable_bias_check=True)
        response2 = agent.run("Answer without bias check", enable_bias_check=False)

        assert response1 is not None
        assert response2 is not None
