"""
Test 05: Context
Tests context CRUD operations and management.
"""

import pytest
from tests.fixtures.sample_configs import context_config


@pytest.mark.agent
class TestContext:
    """Context management tests."""

    def test_context_creation(self, studio, cleanup_contexts):
        """Test creating a context."""
        config = context_config()
        context = studio.contexts.create(**config)

        assert context is not None
        assert context.id is not None
        assert context.name == config['name']
        assert context.value == config['value']

        cleanup_contexts.append(context.id)

    def test_context_read(self, studio, cleanup_contexts):
        """Test retrieving a context by ID."""
        config = context_config()
        created_context = studio.contexts.create(**config)
        context_id = created_context.id

        retrieved_context = studio.contexts.get(context_id)

        assert retrieved_context is not None
        assert retrieved_context.id == context_id
        assert retrieved_context.name == config['name']

        cleanup_contexts.append(context_id)

    def test_context_list(self, studio, cleanup_contexts):
        """Test listing all contexts."""
        config1 = context_config()
        config1['name'] = 'test_context_1'
        context1 = studio.contexts.create(**config1)
        cleanup_contexts.append(context1.id)

        config2 = context_config()
        config2['name'] = 'test_context_2'
        context2 = studio.contexts.create(**config2)
        cleanup_contexts.append(context2.id)

        contexts = studio.contexts.list()

        context_ids = [c.id for c in contexts]
        assert context1.id in context_ids
        assert context2.id in context_ids

    def test_context_update(self, studio, cleanup_contexts):
        """Test updating a context value."""
        config = context_config()
        context = studio.contexts.create(**config)
        context_id = context.id

        new_value = "Updated context value"
        updated_context = studio.contexts.update(context_id, value=new_value)

        assert updated_context.value == new_value
        assert updated_context.id == context_id
        assert updated_context.name == config['name']

        cleanup_contexts.append(context_id)

    def test_context_delete(self, studio, cleanup_contexts):
        """Test deleting a context."""
        config = context_config()
        context = studio.contexts.create(**config)
        context_id = context.id

        studio.contexts.delete(context_id)

        try:
            retrieved = studio.contexts.get(context_id)
            assert retrieved is None
        except Exception:
            pass

    def test_context_pagination(self, studio, cleanup_contexts):
        """Test context listing with pagination."""
        # Create multiple contexts
        for i in range(5):
            config = context_config()
            config['name'] = f'test_pagination_context_{i}'
            context = studio.contexts.create(**config)
            cleanup_contexts.append(context.id)

        # List with skip and limit
        contexts = studio.contexts.list(skip=0, limit=2)

        assert len(contexts) <= 2

    def test_multiple_contexts(self, studio, cleanup_contexts):
        """Test managing multiple contexts."""
        contexts_created = []

        for i in range(3):
            config = context_config()
            config['name'] = f'test_multi_context_{i}'
            config['value'] = f'Context value {i}'
            context = studio.contexts.create(**config)
            contexts_created.append(context)
            cleanup_contexts.append(context.id)

        # Verify all created
        all_contexts = studio.contexts.list()
        all_ids = [c.id for c in all_contexts]

        for context in contexts_created:
            assert context.id in all_ids

    def test_context_required_fields(self, studio):
        """Test that context creation requires necessary fields."""
        # Missing name
        with pytest.raises(Exception):
            studio.contexts.create(value="test value")

        # Missing value
        with pytest.raises(Exception):
            studio.contexts.create(name="test_context")

    def test_context_empty_value(self, studio, cleanup_contexts):
        """Test creating context with empty value."""
        config = context_config()
        config['value'] = ""

        try:
            context = studio.contexts.create(**config)
            cleanup_contexts.append(context.id)
        except Exception:
            pass

    def test_context_name_uniqueness(self, studio, cleanup_contexts):
        """Test context name handling."""
        config = context_config()
        context1 = studio.contexts.create(**config)
        cleanup_contexts.append(context1.id)

        # Try creating another with same name
        try:
            context2 = studio.contexts.create(**config)
            assert context1.id != context2.id
            cleanup_contexts.append(context2.id)
        except Exception:
            pass

    def test_context_update_only_value(self, studio, cleanup_contexts):
        """Test that updating context only changes specified fields."""
        config = context_config()
        context = studio.contexts.create(**config)
        context_id = context.id

        new_value = "New value"
        updated_context = studio.contexts.update(context_id, value=new_value)

        # Name should remain the same
        assert updated_context.name == config['name']
        # Value should be updated
        assert updated_context.value == new_value

        cleanup_contexts.append(context_id)

    def test_context_special_characters(self, studio, cleanup_contexts):
        """Test context with special characters in value."""
        config = context_config()
        config['value'] = "Special chars: !@#$%^&*() <>&\""

        context = studio.contexts.create(**config)
        assert context.value == config['value']

        cleanup_contexts.append(context.id)

    def test_context_unicode_value(self, studio, cleanup_contexts):
        """Test context with unicode characters."""
        config = context_config()
        config['value'] = "Unicode: 你好世界 🌍"

        context = studio.contexts.create(**config)
        assert context.value == config['value']

        cleanup_contexts.append(context.id)

    def test_context_long_value(self, studio, cleanup_contexts):
        """Test context with very long value."""
        config = context_config()
        config['value'] = "x" * 10000

        context = studio.contexts.create(**config)
        assert len(context.value) == 10000

        cleanup_contexts.append(context.id)
