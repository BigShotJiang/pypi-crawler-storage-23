"""
Test 12: Agent + Context Integration
Tests agent execution with context information.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    context_config
)


@pytest.mark.features
class TestAgentWithContext:
    """Agent with context integration tests."""

    def test_agent_with_single_context(self, studio, cleanup_agents, cleanup_contexts):
        """Test agent with single context."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_with_context'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        response = agent.run("Hello")
        assert response is not None

    def test_agent_with_multiple_contexts(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test agent with multiple contexts."""
        context1_config = context_config()
        context1_config['name'] = 'context_1'
        context1 = studio.contexts.create(**context1_config)
        cleanup_contexts.append(context1.id)

        context2_config = context_config()
        context2_config['name'] = 'context_2'
        context2 = studio.contexts.create(**context2_config)
        cleanup_contexts.append(context2.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_multi_context'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context1)
        agent.add_context(context2)

        response = agent.run("Use context information")
        assert response is not None

    def test_agent_dynamic_context_update(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test updating context during execution."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_update'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        # Update context value
        new_value = "Updated context value"
        studio.contexts.update(context.id, value=new_value)

        response = agent.run("Use updated context")
        assert response is not None

    def test_agent_context_removal(self, studio, cleanup_agents, cleanup_contexts):
        """Test removing context from agent."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_removal'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)
        agent.remove_context(context)

        response = agent.run("Without context")
        assert response is not None

    def test_agent_context_with_streaming(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test streaming with context."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_stream'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        chunks = list(agent.run("Generate with context", stream=True))
        assert len(chunks) > 0

    def test_agent_context_in_conversation(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test context in multi-turn conversation."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_conversation'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        session_id = "context_conversation_session"

        response1 = agent.run("First turn", session_id=session_id)
        assert response1 is not None

        response2 = agent.run("Second turn with context", session_id=session_id)
        assert response2 is not None

    def test_multiple_agents_different_contexts(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test multiple agents with different contexts."""
        context1 = studio.contexts.create(**context_config())
        cleanup_contexts.append(context1.id)

        context2_config = context_config()
        context2_config['name'] = 'context_agent2'
        context2 = studio.contexts.create(**context2_config)
        cleanup_contexts.append(context2.id)

        agent1_config = minimal_agent_config()
        agent1_config['name'] = 'test_agent_context_1'
        agent1 = studio.agents.create(**agent1_config)
        cleanup_agents.append(agent1.id)

        agent2_config = minimal_agent_config()
        agent2_config['name'] = 'test_agent_context_2'
        agent2 = studio.agents.create(**agent2_config)
        cleanup_agents.append(agent2.id)

        agent1.add_context(context1)
        agent2.add_context(context2)

        response1 = agent1.run("Agent 1 with context")
        response2 = agent2.run("Agent 2 with different context")

        assert response1 is not None
        assert response2 is not None

    def test_agent_without_context(self, studio, cleanup_agents):
        """Test agent without context."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_context'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Without context")
        assert response is not None

    def test_context_with_special_values(self, studio, cleanup_agents, cleanup_contexts):
        """Test context with special character values."""
        context_cfg = context_config()
        context_cfg['value'] = "Special: !@#$%^&*() Unicode: 你好 😊"
        context = studio.contexts.create(**context_cfg)
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_special_context'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        response = agent.run("Use special context")
        assert response is not None

    def test_context_ordering(self, studio, cleanup_agents, cleanup_contexts):
        """Test ordering of multiple contexts."""
        contexts = []
        for i in range(3):
            ctx_config = context_config()
            ctx_config['name'] = f'context_order_{i}'
            ctx = studio.contexts.create(**ctx_config)
            contexts.append(ctx)
            cleanup_contexts.append(ctx.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_order'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        for ctx in contexts:
            agent.add_context(ctx)

        response = agent.run("Use ordered contexts")
        assert response is not None

    def test_context_update_during_session(
        self, studio, cleanup_agents, cleanup_contexts
    ):
        """Test updating context during agent session."""
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_context_session_update'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        agent.add_context(context)

        session_id = "context_update_session"

        # Turn 1
        response1 = agent.run("Turn 1", session_id=session_id)
        assert response1 is not None

        # Update context
        studio.contexts.update(context.id, value="Updated during session")

        # Turn 2 should see updated context
        response2 = agent.run("Turn 2", session_id=session_id)
        assert response2 is not None
