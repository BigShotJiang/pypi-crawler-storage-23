"""
Test 11: Agent + Knowledge Base Integration
Tests agent execution with knowledge base querying.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    knowledge_base_config_qdrant
)
from tests.fixtures.test_data import kb_training_text, kb_search_query


@pytest.mark.features
class TestAgentWithKnowledgeBase:
    """Agent with knowledge base integration tests."""

    def test_agent_queries_knowledge_base(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test agent querying a knowledge base."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)

        text = kb_training_text()
        kb.add_text(text, source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_with_kb'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompt = kb_search_query()
        response = agent.run(prompt, knowledge_bases=[kb])

        assert response is not None

    def test_agent_with_multiple_knowledge_bases(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test agent with access to multiple knowledge bases."""
        kb1_config = knowledge_base_config_qdrant()
        kb1_config['name'] = 'test_kb_1'
        kb1 = studio.knowledge_bases.create(**kb1_config)
        cleanup_knowledge_bases.append(kb1.id)
        kb1.add_text("Python is a programming language", source="test")

        kb2_config = knowledge_base_config_qdrant()
        kb2_config['name'] = 'test_kb_2'
        kb2 = studio.knowledge_bases.create(**kb2_config)
        cleanup_knowledge_bases.append(kb2.id)
        kb2.add_text("JavaScript is used for web development", source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_multi_kb'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Use KB1
        response = agent.run("Tell me about Python", knowledge_bases=[kb1])
        assert response is not None

    def test_agent_knowledge_base_update(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test updating agent's knowledge base."""
        kb1 = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb1.id)

        kb2_config = knowledge_base_config_qdrant()
        kb2_config['name'] = 'test_kb_update'
        kb2 = studio.knowledge_bases.create(**kb2_config)
        cleanup_knowledge_bases.append(kb2.id)

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_update'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Test with kb2 (simulating KB update by using different KB)
        response = agent.run("Test after KB update", knowledge_bases=[kb2])
        assert response is not None

    def test_agent_knowledge_base_removal(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test removing knowledge base from agent."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_removal'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Test without KB (simulating KB removal)
        response = agent.run("Test after KB removal")
        assert response is not None

    def test_agent_kb_streaming(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test streaming with knowledge base."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_stream'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        chunks = list(agent.run(kb_search_query(), stream=True, knowledge_bases=[kb]))
        assert len(chunks) > 0

    def test_agent_kb_with_retrieval_parameters(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test KB querying with custom retrieval parameters."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_params'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Use KB with custom retrieval params
        response = agent.run(
            kb_search_query(),
            knowledge_bases=[kb.with_config(top_k=3, retrieval_type='basic')]
        )
        assert response is not None

    def test_agent_kb_multi_turn(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test multi-turn conversation with knowledge base."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_multiturn'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "kb_multiturn_session"

        response1 = agent.run("What is Lyzr?", session_id=session_id, knowledge_bases=[kb])
        assert response1 is not None

        response2 = agent.run("What are its features?", session_id=session_id, knowledge_bases=[kb])
        assert response2 is not None

        response3 = agent.run("Tell me more about agents", session_id=session_id, knowledge_bases=[kb])
        assert response3 is not None

    def test_agent_without_knowledge_base(self, studio, cleanup_agents):
        """Test agent execution without knowledge base."""
        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_no_kb'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Answer from training data only")
        assert response is not None

    def test_agent_kb_with_multiple_documents(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test KB with multiple documents accessed by agent."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)

        docs = [
            "Python is a high-level programming language",
            "JavaScript is used for web development",
            "Rust provides memory safety without garbage collection",
            "Go is designed for concurrent programming"
        ]

        for doc in docs:
            kb.add_text(doc, source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_multi_docs'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("Compare Python and JavaScript", knowledge_bases=[kb])
        assert response is not None

    def test_agent_kb_context_preservation(
        self, studio, cleanup_agents, cleanup_knowledge_bases
    ):
        """Test that KB context is preserved across turns."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)

        text = "The capital of France is Paris. Paris is known for the Eiffel Tower."
        kb.add_text(text, source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_context'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        session_id = "kb_context_session"

        response1 = agent.run("What is the capital of France?", session_id=session_id, knowledge_bases=[kb])
        assert response1 is not None

        response2 = agent.run("What is it famous for?", session_id=session_id, knowledge_bases=[kb])
        assert response2 is not None

    def test_agent_kb_accuracy(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test that agent uses KB information accurately."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)

        specific_text = "Lyzr was founded in 2023 and specializes in agent orchestration"
        kb.add_text(specific_text, source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_accuracy'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run("When was Lyzr founded?", knowledge_bases=[kb])
        assert response is not None

    def test_agent_kb_error_handling(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test error handling with knowledge base."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_error'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        try:
            response = agent.run("", knowledge_bases=[kb])
            assert response is not None
        except Exception:
            pass

    def test_agent_kb_empty_query(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test KB handling of edge case queries."""
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        agent_config = minimal_agent_config()
        agent_config['name'] = 'test_agent_kb_empty'
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        try:
            response = agent.run("   ", knowledge_bases=[kb])
            assert response is not None
        except Exception:
            pass
