"""
Test 28: Async Module Methods
Tests async methods on Context, RAI, Memory, and KnowledgeBase modules.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from lyzr.http import HTTPClient, AsyncHTTPClient
from lyzr.context import ContextModule, Context, ContextList
from lyzr.rai import RAIModule, RAIPolicy, RAIPolicyList
from lyzr.memory.module import MemoryModule
from lyzr.memory.entity import Memory, MemoryList
from lyzr.memory.enums import MemoryProvider, MemoryStatus
from lyzr.knowledge_base.module import KnowledgeBaseModule
from lyzr.knowledge_base.entity import KnowledgeBase, KnowledgeBaseList
from lyzr.urls import ServiceURLs


@pytest.fixture
def mock_http():
    """Create mock sync HTTP client."""
    http = MagicMock(spec=HTTPClient)
    http.api_key = "sk-test"
    http.base_url = "https://agent-prod.studio.lyzr.ai"
    http.timeout = 30
    return http


@pytest.fixture
def mock_async_http():
    """Create mock async HTTP client."""
    async_http = AsyncMock(spec=AsyncHTTPClient)
    async_http.api_key = "sk-test"
    async_http.base_url = "https://agent-prod.studio.lyzr.ai"
    async_http.timeout = 30
    return async_http


# ============================================================================
# Context Module Tests
# ============================================================================

SAMPLE_CONTEXT_DATA = {
    "_id": "ctx_123",
    "name": "company",
    "value": "Lyzr Inc",
    "api_key": "sk-test",
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
}


class TestAsyncContextModule:
    """Async context module tests."""

    @pytest.fixture
    def ctx_module(self, mock_http, mock_async_http):
        module = ContextModule(mock_http)
        module._async_http = mock_async_http
        return module

    @pytest.mark.asyncio
    async def test_acreate(self, ctx_module, mock_async_http):
        """Test async create context."""
        mock_async_http.post.return_value = {"context_id": "ctx_123"}
        mock_async_http.get.return_value = SAMPLE_CONTEXT_DATA.copy()

        ctx = await ctx_module.acreate("company", "Lyzr Inc")

        assert isinstance(ctx, Context)
        assert ctx.name == "company"
        assert ctx.value == "Lyzr Inc"

    @pytest.mark.asyncio
    async def test_aget(self, ctx_module, mock_async_http):
        """Test async get context."""
        mock_async_http.get.return_value = SAMPLE_CONTEXT_DATA.copy()

        ctx = await ctx_module.aget("ctx_123")

        assert isinstance(ctx, Context)
        assert ctx.id == "ctx_123"

    @pytest.mark.asyncio
    async def test_alist(self, ctx_module, mock_async_http):
        """Test async list contexts."""
        mock_async_http.get.return_value = [SAMPLE_CONTEXT_DATA.copy()]

        ctx_list = await ctx_module.alist()

        assert isinstance(ctx_list, ContextList)
        assert len(ctx_list) == 1

    @pytest.mark.asyncio
    async def test_aupdate(self, ctx_module, mock_async_http):
        """Test async update context."""
        mock_async_http.put.return_value = {"message": "success"}
        mock_async_http.get.return_value = {**SAMPLE_CONTEXT_DATA, "value": "Updated"}

        ctx = await ctx_module.aupdate("ctx_123", value="Updated")

        assert isinstance(ctx, Context)

    @pytest.mark.asyncio
    async def test_adelete(self, ctx_module, mock_async_http):
        """Test async delete context."""
        mock_async_http.delete.return_value = True

        result = await ctx_module.adelete("ctx_123")

        assert result is True


# ============================================================================
# RAI Module Tests
# ============================================================================

SAMPLE_RAI_POLICY_DATA = {
    "_id": "rai_123",
    "name": "SafePolicy",
    "description": "Safety guardrails",
    "toxicity_check": {"enabled": True, "threshold": 0.4},
    "prompt_injection": {"enabled": False, "threshold": 0.3},
    "secrets_detection": {"enabled": False, "action": "mask"},
    "pii_detection": {"enabled": False, "types": {}, "custom_pii": []},
    "nsfw_check": {"enabled": False, "threshold": 0.8, "validation_method": "full"},
    "allowed_topics": {"enabled": False, "topics": []},
    "banned_topics": {"enabled": False, "topics": []},
    "keywords": {"enabled": False, "keywords": []},
}


class TestAsyncRAIModule:
    """Async RAI module tests."""

    @pytest.fixture
    def rai_module(self, mock_http, mock_async_http):
        env_config = ServiceURLs(
            agent_api="https://agent-prod.studio.lyzr.ai",
            rag_api="https://rag-prod.studio.lyzr.ai",
            rai_api="https://srs-prod.studio.lyzr.ai",
        )
        module = RAIModule(mock_http, env_config)
        module._async_http = mock_async_http
        return module

    @pytest.mark.asyncio
    async def test_acreate_policy(self, rai_module, mock_async_http):
        """Test async create RAI policy."""
        mock_async_http.post.return_value = SAMPLE_RAI_POLICY_DATA.copy()

        policy = await rai_module.acreate_policy(
            name="SafePolicy",
            description="Safety guardrails",
        )

        assert isinstance(policy, RAIPolicy)
        assert policy.name == "SafePolicy"

    @pytest.mark.asyncio
    async def test_aget_policy(self, rai_module, mock_async_http):
        """Test async get RAI policy."""
        mock_async_http.get.return_value = SAMPLE_RAI_POLICY_DATA.copy()

        policy = await rai_module.aget_policy("rai_123")

        assert isinstance(policy, RAIPolicy)
        assert policy.id == "rai_123"

    @pytest.mark.asyncio
    async def test_alist_policies(self, rai_module, mock_async_http):
        """Test async list RAI policies."""
        mock_async_http.get.return_value = [SAMPLE_RAI_POLICY_DATA.copy()]

        policy_list = await rai_module.alist_policies()

        assert isinstance(policy_list, RAIPolicyList)
        assert len(policy_list) == 1

    @pytest.mark.asyncio
    async def test_aupdate_policy(self, rai_module, mock_async_http):
        """Test async update RAI policy."""
        mock_async_http.put.return_value = {"message": "success"}
        mock_async_http.get.return_value = {**SAMPLE_RAI_POLICY_DATA, "description": "Updated"}

        policy = await rai_module.aupdate_policy("rai_123", description="Updated")

        assert isinstance(policy, RAIPolicy)

    @pytest.mark.asyncio
    async def test_adelete_policy(self, rai_module, mock_async_http):
        """Test async delete RAI policy."""
        mock_async_http.delete.return_value = True

        result = await rai_module.adelete_policy("rai_123")

        assert result is True


# ============================================================================
# Memory Module Tests
# ============================================================================


class TestAsyncMemoryModule:
    """Async memory module tests."""

    @pytest.fixture
    def mem_module(self, mock_http, mock_async_http):
        module = MemoryModule(mock_http)
        module._async_http = mock_async_http
        return module

    @pytest.mark.asyncio
    async def test_alist_providers(self, mem_module, mock_async_http):
        """Test async list memory providers."""
        mock_async_http.get.return_value = [
            {"provider_id": "mem0", "meta_data": {"provider_name": "Mem0"}},
        ]

        providers = await mem_module.alist_providers()

        assert isinstance(providers, list)
        assert len(providers) == 1

    @pytest.mark.asyncio
    async def test_aget_provider(self, mem_module, mock_async_http):
        """Test async get memory provider."""
        mock_async_http.get.return_value = {"provider_id": "mem0", "form": {}}

        provider = await mem_module.aget_provider("mem0")

        assert provider["provider_id"] == "mem0"

    @pytest.mark.asyncio
    async def test_acreate_credential(self, mem_module, mock_async_http):
        """Test async create memory credential."""
        mock_async_http.post.return_value = {
            "credential_id": "cred_123",
            "created_at": "2024-01-01",
        }

        memory = await mem_module.acreate_credential(
            provider="lyzr",
            name="Test Memory",
        )

        assert isinstance(memory, Memory)
        assert memory.credential_id == "cred_123"

    @pytest.mark.asyncio
    async def test_alist_memories(self, mem_module, mock_async_http):
        """Test async list memories."""
        mock_async_http.get.return_value = [
            {
                "_id": "cred_123",
                "provider_id": "lyzr",
                "name": "Test",
                "created_at": "2024-01-01",
            }
        ]

        mem_list = await mem_module.alist_memories()

        assert isinstance(mem_list, MemoryList)
        assert len(mem_list) == 1

    @pytest.mark.asyncio
    async def test_adelete_credential(self, mem_module, mock_async_http):
        """Test async delete memory credential."""
        mock_async_http.delete.return_value = True

        result = await mem_module.adelete_credential("cred_123")

        assert result is True


# ============================================================================
# KnowledgeBase Module Tests
# ============================================================================

SAMPLE_KB_DATA = {
    "_id": "kb_123",
    "name": "test_kb",
    "collection_name": "test_collection",
    "vector_db_credential_id": "cred_1",
    "vector_store_provider": "Qdrant",
    "embedding_model": "text-embedding-3-large",
    "embedding_credential_id": "cred_2",
    "llm_model": "gpt-4o",
    "llm_credential_id": "cred_3",
}


class TestAsyncKnowledgeBaseModule:
    """Async knowledge base module tests."""

    @pytest.fixture
    def kb_module(self, mock_http, mock_async_http):
        env_config = ServiceURLs(
            agent_api="https://agent-prod.studio.lyzr.ai",
            rag_api="https://rag-prod.studio.lyzr.ai",
            rai_api="https://srs-prod.studio.lyzr.ai",
        )
        module = KnowledgeBaseModule(mock_http, env_config)
        module._async_http = mock_async_http
        return module

    @pytest.mark.asyncio
    async def test_acreate(self, kb_module, mock_async_http):
        """Test async create knowledge base."""
        mock_async_http.post.return_value = SAMPLE_KB_DATA.copy()

        kb = await kb_module.acreate(name="test_kb")

        assert isinstance(kb, KnowledgeBase)
        assert kb.id == "kb_123"

    @pytest.mark.asyncio
    async def test_aget(self, kb_module, mock_async_http):
        """Test async get knowledge base."""
        mock_async_http.get.return_value = SAMPLE_KB_DATA.copy()

        kb = await kb_module.aget("kb_123")

        assert isinstance(kb, KnowledgeBase)
        assert kb.id == "kb_123"

    @pytest.mark.asyncio
    async def test_alist(self, kb_module, mock_async_http):
        """Test async list knowledge bases."""
        mock_async_http.get.return_value = {"configs": [SAMPLE_KB_DATA.copy()]}

        kb_list = await kb_module.alist()

        assert isinstance(kb_list, KnowledgeBaseList)
        assert len(kb_list) == 1

    @pytest.mark.asyncio
    async def test_aupdate(self, kb_module, mock_async_http):
        """Test async update knowledge base."""
        mock_async_http.put.return_value = {"success": True}
        mock_async_http.get.return_value = {**SAMPLE_KB_DATA, "description": "Updated"}

        kb = await kb_module.aupdate("kb_123", description="Updated")

        assert isinstance(kb, KnowledgeBase)

    @pytest.mark.asyncio
    async def test_adelete(self, kb_module, mock_async_http):
        """Test async delete knowledge base."""
        mock_async_http.delete.return_value = True

        result = await kb_module.adelete("kb_123")

        assert result is True

    @pytest.mark.asyncio
    async def test_abulk_delete(self, kb_module, mock_async_http):
        """Test async bulk delete knowledge bases."""
        mock_async_http.post.return_value = {"message": "deleted"}

        result = await kb_module.abulk_delete(["kb_1", "kb_2"])

        assert result is True

    @pytest.mark.asyncio
    async def test_aquery(self, kb_module, mock_async_http):
        """Test async query knowledge base."""
        mock_async_http.get.return_value = {
            "results": [
                {"text": "Business hours are 9-5", "score": 0.95, "source": "faq.txt"}
            ]
        }

        results = await kb_module._aquery("kb_123", "business hours")

        assert len(results) == 1
        assert results[0].text == "Business hours are 9-5"

    @pytest.mark.asyncio
    async def test_alist_documents(self, kb_module, mock_async_http):
        """Test async list documents."""
        mock_async_http.get.return_value = ["doc1.pdf", "doc2.txt"]

        docs = await kb_module._alist_documents("kb_123")

        assert len(docs) == 2

    @pytest.mark.asyncio
    async def test_areset(self, kb_module, mock_async_http):
        """Test async reset knowledge base."""
        mock_async_http.delete.return_value = True

        result = await kb_module._areset("kb_123")

        assert result is True
