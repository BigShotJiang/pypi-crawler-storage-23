"""
Test 20: Structured Outputs
Tests agent response parsing and validation with Pydantic models.
"""

import pytest
from pydantic import BaseModel
from tests.fixtures.sample_configs import minimal_agent_config
from tests.fixtures.test_data import structured_output_prompts


class UserInfo(BaseModel):
    name: str
    age: int
    email: str


class Address(BaseModel):
    street: str
    city: str
    country: str


class Person(BaseModel):
    name: str
    email: str
    address: Address


@pytest.mark.slow
class TestStructuredOutputs:
    """Structured output tests."""

    def test_simple_structured_output(self, studio, cleanup_agents):
        """Test simple structured output parsing."""
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_simple_struct"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = structured_output_prompts()
        response = agent.run(prompts["user_info"], response_model=UserInfo)
        assert response is not None

    def test_nested_structured_output(self, studio, cleanup_agents):
        """Test nested structured output parsing."""
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_nested_struct"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompt = "Create a person with address: Name: John, Email: john@example.com, Street: 123 Main, City: NYC, Country: USA"
        response = agent.run(prompt, response_model=Person)
        assert response is not None

    def test_list_structured_output(self, studio, cleanup_agents):
        """Test list structured output."""
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_list_struct"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        prompts = structured_output_prompts()
        response = agent.run(prompts["list_items"], response_model=list[UserInfo])
        assert response is not None

    def test_validation_with_pydantic(self, studio, cleanup_agents):
        """Test validation with Pydantic model."""
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_pydantic_validate"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        response = agent.run(
            "Extract: Name: Jane, Age: 25, Email: jane@example.com", response_model=UserInfo
        )
        assert response is not None

    def test_invalid_structured_output(self, studio, cleanup_agents):
        """Test handling of invalid structured output."""
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_invalid_struct"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        try:
            response = agent.run("Give invalid response", response_model=UserInfo)
            assert response is not None
        except Exception:
            # Expected - validation failure
            pass

    def test_structured_output_with_local_tools(self, studio, cleanup_agents):
        """Test structured output combined with local tool calling."""
        from pydantic import BaseModel, Field

        class CalculationResult(BaseModel):
            """Structured result from calculation."""

            operation: str = Field(
                description="The operation performed can be either add, divide, multiply or subtract"
            )
            input_a: float = Field(description="First input number")
            input_b: float = Field(description="Second input number")
            result: float = Field(description="Calculation result")

        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_struct_tools"
        agent_config["response_model"] = CalculationResult
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Add local tool
        def multiply(a: float, b: float) -> float:
            """Multiply two numbers."""
            return a * b

        agent.add_tool(multiply)

        # Run with structured response
        response = agent.run(
            "Use the multiply tool to calculate 7 times 8, then return the result as structured data",
        )

        # Should be a CalculationResult instance
        assert isinstance(response, CalculationResult)
        assert response.operation == "multiply"
        assert response.result == 56
