"""
Test 26: Async Agent Module
Tests async CRUD operations on AgentModule.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from lyzr.http import HTTPClient, AsyncHTTPClient
from lyzr.agents import AgentModule
from lyzr.models import Agent


# Sample agent data returned by API
SAMPLE_AGENT_DATA = {
    "_id": "agent_test_123",
    "api_key": "sk-test",
    "name": "Test Agent",
    "description": "A test agent",
    "agent_role": "Tester",
    "agent_goal": "Test things",
    "agent_instructions": "Test carefully",
    "provider_id": "OpenAI",
    "model": "gpt-4o",
    "temperature": 0.7,
    "top_p": 0.9,
    "tools": [],
    "features": [],
    "managed_agents": [],
    "tool_configs": [],
    "a2a_tools": [],
    "llm_credential_id": "lyzr_openai",
    "store_messages": True,
    "file_output": False,
}


@pytest.fixture
def mock_http():
    """Create a mock sync HTTP client."""
    http = MagicMock(spec=HTTPClient)
    http.api_key = "sk-test"
    http.base_url = "https://agent-prod.studio.lyzr.ai"
    http.timeout = 30
    http._get_headers.return_value = {"x-api-key": "sk-test"}
    http._build_url.side_effect = lambda path: f"https://agent-prod.studio.lyzr.ai/{path.lstrip('/')}"
    return http


@pytest.fixture
def mock_async_http():
    """Create a mock async HTTP client."""
    async_http = AsyncMock(spec=AsyncHTTPClient)
    async_http.api_key = "sk-test"
    async_http.base_url = "https://agent-prod.studio.lyzr.ai"
    async_http.timeout = 30
    async_http._get_headers.return_value = {"x-api-key": "sk-test"}
    async_http._build_url.side_effect = lambda path: f"https://agent-prod.studio.lyzr.ai/{path.lstrip('/')}"
    return async_http


@pytest.fixture
def agent_module(mock_http, mock_async_http):
    """Create AgentModule with mocked clients."""
    module = AgentModule(mock_http)
    module._async_http = mock_async_http
    module._inference._async_http = mock_async_http
    return module


class TestAsyncAgentModule:
    """Async agent CRUD tests."""

    @pytest.mark.asyncio
    async def test_aget(self, agent_module, mock_async_http):
        """Test async get agent."""
        mock_async_http.get.return_value = SAMPLE_AGENT_DATA.copy()

        agent = await agent_module.aget("agent_test_123")

        assert isinstance(agent, Agent)
        assert agent.id == "agent_test_123"
        assert agent.name == "Test Agent"
        mock_async_http.get.assert_awaited_once_with("/v3/agents/agent_test_123")

    @pytest.mark.asyncio
    async def test_acreate(self, agent_module, mock_async_http):
        """Test async create agent."""
        # First call: create returns agent_id
        mock_async_http.post.return_value = {"agent_id": "agent_new_123"}
        # Second call: get returns full agent data
        mock_async_http.get.return_value = {
            **SAMPLE_AGENT_DATA,
            "_id": "agent_new_123",
            "name": "New Agent",
        }

        agent = await agent_module.acreate(
            name="New Agent",
            provider="openai/gpt-4o",
            role="Helper",
            goal="Help users",
            instructions="Be helpful",
        )

        assert isinstance(agent, Agent)
        assert agent.id == "agent_new_123"
        assert agent.name == "New Agent"
        mock_async_http.post.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_alist(self, agent_module, mock_async_http):
        """Test async list agents."""
        mock_async_http.get.return_value = [SAMPLE_AGENT_DATA.copy()]

        agent_list = await agent_module.alist()

        assert len(agent_list) == 1
        assert agent_list[0].name == "Test Agent"

    @pytest.mark.asyncio
    async def test_alist_empty(self, agent_module, mock_async_http):
        """Test async list agents returns empty list."""
        mock_async_http.get.return_value = []

        agent_list = await agent_module.alist()

        assert len(agent_list) == 0

    @pytest.mark.asyncio
    async def test_aupdate(self, agent_module, mock_async_http):
        """Test async update agent."""
        # First call (aget for current): return original
        # Second call (aget after update): return updated
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            {**SAMPLE_AGENT_DATA, "temperature": 0.5},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        agent = await agent_module.aupdate("agent_test_123", temperature=0.5)

        assert isinstance(agent, Agent)
        mock_async_http.put.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_adelete(self, agent_module, mock_async_http):
        """Test async delete agent."""
        mock_async_http.delete.return_value = True

        result = await agent_module.adelete("agent_test_123")

        assert result is True
        mock_async_http.delete.assert_awaited_once_with("/v3/agents/agent_test_123")

    @pytest.mark.asyncio
    async def test_abulk_delete(self, agent_module, mock_async_http):
        """Test async bulk delete agents."""
        mock_async_http.post.return_value = {"message": "deleted"}

        result = await agent_module.abulk_delete(["id1", "id2"])

        assert result is True
        mock_async_http.post.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_abulk_delete_empty(self, agent_module):
        """Test async bulk delete with empty list raises error."""
        from lyzr.exceptions import ValidationError

        with pytest.raises(ValidationError):
            await agent_module.abulk_delete([])

    @pytest.mark.asyncio
    async def test_aclone(self, agent_module, mock_async_http):
        """Test async clone agent."""
        # aget original
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            # acreate -> aget new
            {**SAMPLE_AGENT_DATA, "_id": "agent_clone_123", "name": "Cloned Agent"},
        ]
        mock_async_http.post.return_value = {"agent_id": "agent_clone_123"}

        cloned = await agent_module.aclone("agent_test_123", "Cloned Agent")

        assert isinstance(cloned, Agent)
        assert cloned.name == "Cloned Agent"

    @pytest.mark.asyncio
    async def test_aremove_rai_policy(self, agent_module, mock_async_http):
        """Test async remove RAI policy."""
        agent_with_rai = {
            **SAMPLE_AGENT_DATA,
            "features": [
                {"type": "RAI", "config": {"policy_id": "p1"}, "priority": 0},
                {"type": "MEMORY", "config": {}, "priority": 0},
            ],
        }

        # aget with RAI, then aget current in aupdate, then aget after update
        mock_async_http.get.side_effect = [
            agent_with_rai,
            agent_with_rai,
            {**SAMPLE_AGENT_DATA, "features": [{"type": "MEMORY", "config": {}, "priority": 0}]},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        agent = await agent_module.aremove_rai_policy("agent_test_123")

        # Verify RAI was removed from features
        assert isinstance(agent, Agent)

    @pytest.mark.asyncio
    async def test_ensure_async_raises_without_client(self, mock_http):
        """Test that _ensure_async raises when no async client."""
        module = AgentModule(mock_http)
        # Don't set _async_http

        with pytest.raises(RuntimeError, match="Async not initialized"):
            await module.aget("agent_123")
