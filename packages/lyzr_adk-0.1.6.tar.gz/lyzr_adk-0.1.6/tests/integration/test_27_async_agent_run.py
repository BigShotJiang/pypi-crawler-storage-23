"""
Test 27: Async Agent Run
Tests agent.arun() and async streaming.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from lyzr.http import HTTPClient, AsyncHTTPClient
from lyzr.agents import AgentModule
from lyzr.inference import InferenceModule
from lyzr.responses import AgentResponse, AgentStream
from lyzr.models import Agent


SAMPLE_AGENT_DATA = {
    "_id": "agent_test_123",
    "api_key": "sk-test",
    "name": "Test Agent",
    "agent_role": "Tester",
    "agent_goal": "Test things",
    "agent_instructions": "Test carefully",
    "provider_id": "OpenAI",
    "model": "gpt-4o",
    "temperature": 0.7,
    "top_p": 0.9,
    "tools": [],
    "features": [],
    "managed_agents": [],
    "tool_configs": [],
    "a2a_tools": [],
    "llm_credential_id": "lyzr_openai",
    "store_messages": True,
    "file_output": False,
}


@pytest.fixture
def mock_http():
    """Create mock sync HTTP client."""
    http = MagicMock(spec=HTTPClient)
    http.api_key = "sk-test"
    http.base_url = "https://agent-prod.studio.lyzr.ai"
    http.timeout = 30
    http._get_headers.return_value = {"x-api-key": "sk-test"}
    http._build_url.side_effect = lambda path: f"https://agent-prod.studio.lyzr.ai/{path.lstrip('/')}"
    return http


@pytest.fixture
def mock_async_http():
    """Create mock async HTTP client."""
    async_http = AsyncMock(spec=AsyncHTTPClient)
    async_http.api_key = "sk-test"
    async_http.base_url = "https://agent-prod.studio.lyzr.ai"
    async_http.timeout = 30
    async_http._get_headers.return_value = {"x-api-key": "sk-test"}
    async_http._build_url.side_effect = lambda path: f"https://agent-prod.studio.lyzr.ai/{path.lstrip('/')}"
    return async_http


@pytest.fixture
def smart_agent(mock_http, mock_async_http):
    """Create a smart Agent with mocked clients."""
    agent_module = AgentModule(mock_http)
    agent_module._async_http = mock_async_http

    inference = InferenceModule(mock_http)
    inference._async_http = mock_async_http

    agent = Agent(**SAMPLE_AGENT_DATA)
    agent._http = mock_http
    agent._inference = inference
    agent._agent_module = agent_module
    return agent


class TestAsyncAgentRun:
    """Async agent.arun() tests."""

    @pytest.mark.asyncio
    async def test_arun_basic(self, smart_agent, mock_async_http):
        """Test basic async agent run."""
        mock_async_http.post.return_value = {
            "response": "Hello! I'm a test agent.",
            "message_id": "msg_123",
        }

        response = await smart_agent.arun("Hello")

        assert isinstance(response, AgentResponse)
        assert response.response == "Hello! I'm a test agent."
        mock_async_http.post.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_arun_with_session_id(self, smart_agent, mock_async_http):
        """Test async agent run with explicit session_id."""
        mock_async_http.post.return_value = {
            "response": "Response",
            "message_id": "msg_456",
        }

        response = await smart_agent.arun("Hello", session_id="my_session")

        assert isinstance(response, AgentResponse)
        # Verify session_id was passed in the request
        call_args = mock_async_http.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        assert payload["session_id"] == "my_session"

    @pytest.mark.asyncio
    async def test_arun_auto_generates_session_id(self, smart_agent, mock_async_http):
        """Test that arun auto-generates session_id."""
        mock_async_http.post.return_value = {
            "response": "Response",
            "message_id": "msg_789",
        }

        response = await smart_agent.arun("Hello")

        call_args = mock_async_http.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        assert payload["session_id"].startswith("session_")

    @pytest.mark.asyncio
    async def test_arun_with_structured_response(self, smart_agent, mock_async_http):
        """Test async agent run with response_model."""
        from pydantic import BaseModel

        class Result(BaseModel):
            answer: int

        smart_agent._response_model = Result

        mock_async_http.post.return_value = {
            "response": '{"answer": 42}',
            "message_id": "msg_structured",
        }

        response = await smart_agent.arun("What is the answer?")

        assert isinstance(response, Result)
        assert response.answer == 42

    @pytest.mark.asyncio
    async def test_arun_with_knowledge_bases(self, smart_agent, mock_async_http):
        """Test async agent run with knowledge bases."""
        mock_async_http.post.return_value = {
            "response": "Based on the docs...",
            "message_id": "msg_kb",
        }

        # Create a mock KB
        mock_kb = MagicMock()
        mock_kb.to_agentic_config.return_value = {
            "rag_id": "kb_123",
            "name": "test_kb",
            "description": "Test KB",
            "top_k": 10,
            "retrieval_type": "basic",
            "score_threshold": 0.0,
            "time_decay_factor": 0.4,
        }

        response = await smart_agent.arun("Search docs", knowledge_bases=[mock_kb])

        assert isinstance(response, AgentResponse)
        # Verify KB feature was added
        call_args = mock_async_http.post.call_args
        payload = call_args.kwargs.get("json") or call_args[1].get("json")
        features = payload.get("features", [])
        assert any(f.get("type") == "KNOWLEDGE_BASE" for f in features)


class TestAsyncAgentUpdate:
    """Async agent entity method tests."""

    @pytest.mark.asyncio
    async def test_aupdate(self, smart_agent, mock_async_http):
        """Test async agent update."""
        # aget current, put, aget updated
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            {**SAMPLE_AGENT_DATA, "temperature": 0.5},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        result = await smart_agent.aupdate(temperature=0.5)

        assert isinstance(result, Agent)

    @pytest.mark.asyncio
    async def test_adelete(self, smart_agent, mock_async_http):
        """Test async agent delete."""
        mock_async_http.delete.return_value = True

        result = await smart_agent.adelete()

        assert result is True

    @pytest.mark.asyncio
    async def test_aclone(self, smart_agent, mock_async_http):
        """Test async agent clone."""
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            {**SAMPLE_AGENT_DATA, "_id": "agent_cloned", "name": "Test Agent (Clone)"},
        ]
        mock_async_http.post.return_value = {"agent_id": "agent_cloned"}

        cloned = await smart_agent.aclone()

        assert isinstance(cloned, Agent)


class TestAsyncAgentFeatureToggles:
    """Async feature toggle tests."""

    @pytest.mark.asyncio
    async def test_aenable_file_output(self, smart_agent, mock_async_http):
        """Test async enable file output."""
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            {**SAMPLE_AGENT_DATA, "file_output": True},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        result = await smart_agent.aenable_file_output()

        assert isinstance(result, Agent)

    @pytest.mark.asyncio
    async def test_aadd_memory(self, smart_agent, mock_async_http):
        """Test async add memory."""
        mock_async_http.get.side_effect = [
            SAMPLE_AGENT_DATA.copy(),
            {**SAMPLE_AGENT_DATA, "features": [{"type": "MEMORY", "config": {"max_messages_context_count": 20}}]},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        result = await smart_agent.aadd_memory(max_messages=20)

        assert isinstance(result, Agent)

    @pytest.mark.asyncio
    async def test_aremove_memory(self, smart_agent, mock_async_http):
        """Test async remove memory."""
        agent_with_memory = {
            **SAMPLE_AGENT_DATA,
            "features": [{"type": "MEMORY", "config": {}}],
        }
        mock_async_http.get.side_effect = [
            agent_with_memory,
            {**SAMPLE_AGENT_DATA, "features": []},
        ]
        mock_async_http.put.return_value = {"message": "success"}

        result = await smart_agent.aremove_memory()

        assert isinstance(result, Agent)
