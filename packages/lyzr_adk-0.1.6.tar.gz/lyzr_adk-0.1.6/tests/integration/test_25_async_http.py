"""
Test 25: AsyncHTTPClient
Tests the async HTTP client with mocked responses.
"""

import pytest
import httpx
from unittest.mock import AsyncMock, patch, MagicMock
from lyzr.http import AsyncHTTPClient, _HTTPClientBase
from lyzr.exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    APIError,
    TimeoutError,
    ValidationError,
)


class TestHTTPClientBase:
    """Test _HTTPClientBase shared functionality."""

    def test_base_requires_api_key(self, monkeypatch):
        """Test that base raises error without API key."""
        monkeypatch.delenv("LYZR_API_KEY", raising=False)
        with pytest.raises(AuthenticationError):
            _HTTPClientBase(api_key=None)

    def test_base_builds_url(self):
        """Test URL building."""
        base = _HTTPClientBase(api_key="test-key", base_url="https://api.example.com")
        assert base._build_url("/v3/agents/") == "https://api.example.com/v3/agents/"
        assert base._build_url("v3/agents/") == "https://api.example.com/v3/agents/"

    def test_base_gets_headers(self):
        """Test header generation."""
        base = _HTTPClientBase(api_key="sk-test")
        headers = base._get_headers()
        assert headers["x-api-key"] == "sk-test"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"

    def test_base_handles_401(self):
        """Test 401 error handling."""
        base = _HTTPClientBase(api_key="sk-test")
        response = MagicMock()
        response.status_code = 401
        response.text = "Unauthorized"
        response.json.return_value = {"detail": "Invalid API key"}

        with pytest.raises(AuthenticationError):
            base._handle_error(response)

    def test_base_handles_404(self):
        """Test 404 error handling."""
        base = _HTTPClientBase(api_key="sk-test")
        response = MagicMock()
        response.status_code = 404
        response.text = "Not found"
        response.json.return_value = {"detail": "Resource not found"}

        with pytest.raises(NotFoundError):
            base._handle_error(response)

    def test_base_handles_422(self):
        """Test 422 error handling."""
        base = _HTTPClientBase(api_key="sk-test")
        response = MagicMock()
        response.status_code = 422
        response.text = "Validation error"
        response.json.return_value = {"detail": "Invalid params"}

        with pytest.raises(ValidationError):
            base._handle_error(response)

    def test_base_handles_429(self):
        """Test 429 error handling."""
        base = _HTTPClientBase(api_key="sk-test")
        response = MagicMock()
        response.status_code = 429
        response.text = "Rate limited"
        response.json.return_value = {"detail": "Too many requests"}

        with pytest.raises(RateLimitError):
            base._handle_error(response)

    def test_base_handles_500(self):
        """Test 500 error handling."""
        base = _HTTPClientBase(api_key="sk-test")
        response = MagicMock()
        response.status_code = 500
        response.text = "Internal server error"
        response.json.return_value = {"detail": "Server error"}

        with pytest.raises(APIError):
            base._handle_error(response)


class TestAsyncHTTPClient:
    """Test AsyncHTTPClient methods."""

    def test_init(self):
        """Test AsyncHTTPClient initialization."""
        client = AsyncHTTPClient(api_key="sk-test", base_url="https://api.example.com")
        assert client.api_key == "sk-test"
        assert client.base_url == "https://api.example.com"
        assert isinstance(client._client, httpx.AsyncClient)

    def test_init_requires_api_key(self, monkeypatch):
        """Test that init raises error without API key."""
        monkeypatch.delenv("LYZR_API_KEY", raising=False)
        with pytest.raises(AuthenticationError):
            AsyncHTTPClient(api_key=None)

    @pytest.mark.asyncio
    async def test_get(self):
        """Test async GET request."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "test"}

        with patch.object(client._client, "get", new_callable=AsyncMock, return_value=mock_response):
            result = await client.get("/v3/agents/")
            assert result == {"data": "test"}

        await client.close()

    @pytest.mark.asyncio
    async def test_post(self):
        """Test async POST request."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"agent_id": "agent_123"}

        with patch.object(client._client, "post", new_callable=AsyncMock, return_value=mock_response):
            result = await client.post("/v3/agents/", json={"name": "test"})
            assert result == {"agent_id": "agent_123"}

        await client.close()

    @pytest.mark.asyncio
    async def test_put(self):
        """Test async PUT request."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "updated"}

        with patch.object(client._client, "put", new_callable=AsyncMock, return_value=mock_response):
            result = await client.put("/v3/agents/123", json={"name": "updated"})
            assert result == {"message": "updated"}

        await client.close()

    @pytest.mark.asyncio
    async def test_delete(self):
        """Test async DELETE request."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch.object(client._client, "delete", new_callable=AsyncMock, return_value=mock_response):
            result = await client.delete("/v3/agents/123")
            assert result is True

        await client.close()

    @pytest.mark.asyncio
    async def test_delete_with_body(self):
        """Test async DELETE request with JSON body."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch.object(client._client, "request", new_callable=AsyncMock, return_value=mock_response):
            result = await client.delete("/v3/agents/123/docs/", json_body=["doc1"])
            assert result is True

        await client.close()

    @pytest.mark.asyncio
    async def test_get_error_handling(self):
        """Test that errors are properly raised for GET."""
        client = AsyncHTTPClient(api_key="sk-test")
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Not found"
        mock_response.json.return_value = {"detail": "Not found"}

        with patch.object(client._client, "get", new_callable=AsyncMock, return_value=mock_response):
            with pytest.raises(NotFoundError):
                await client.get("/v3/agents/nonexistent")

        await client.close()

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test async context manager."""
        async with AsyncHTTPClient(api_key="sk-test") as client:
            assert isinstance(client, AsyncHTTPClient)
            assert client.api_key == "sk-test"

    @pytest.mark.asyncio
    async def test_timeout_handling(self):
        """Test timeout error handling."""
        client = AsyncHTTPClient(api_key="sk-test", timeout=1)

        with patch.object(
            client._client, "get",
            new_callable=AsyncMock,
            side_effect=httpx.TimeoutException("timeout")
        ):
            with pytest.raises(TimeoutError):
                await client.get("/v3/agents/")

        await client.close()
