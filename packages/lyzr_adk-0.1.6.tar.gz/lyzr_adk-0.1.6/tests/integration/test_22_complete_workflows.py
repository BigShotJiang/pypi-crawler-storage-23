"""
Test 22: Complete Workflows
Tests end-to-end scenarios combining multiple features.
"""

import pytest
from tests.fixtures.sample_configs import (
    minimal_agent_config,
    knowledge_base_config_qdrant,
    memory_config_lyzr,
    context_config,
    rai_policy_pii_redact,
)
from tests.fixtures.test_data import kb_training_text, multi_agent_prompts


@pytest.mark.slow
class TestCompleteWorkflows:
    """End-to-end workflow tests."""

    def test_full_feature_agent(
        self,
        studio,
        cleanup_agents,
        cleanup_knowledge_bases,
        cleanup_memories,
        cleanup_contexts,
        cleanup_policies,
    ):
        """Test agent with all features enabled."""
        # Create knowledge base
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text(kb_training_text(), source="test")

        # Create context
        context = studio.contexts.create(**context_config())
        cleanup_contexts.append(context.id)

        # Create RAI policy
        policy = studio.rai.create_policy(**rai_policy_pii_redact())
        cleanup_policies.append(policy.id)

        # Create agent with all features
        agent_config = minimal_agent_config()
        agent_config["name"] = "test_agent_full_features"
        agent_config["memory"] = 10  # Lyzr memory: persist 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Configure all features
        agent.add_context(context)
        agent.add_rai_policy(policy)

        # Register tool
        def calculate(a: int, b: int) -> int:
            return a + b

        agent.add_tool(calculate)

        # Execute
        response = agent.run("Use all features to answer", knowledge_bases=[kb])
        assert response is not None

    def test_multi_agent_workflow(self, studio, cleanup_agents):
        """Test workflow with multiple agents."""
        prompts = multi_agent_prompts()

        # Create researcher agent
        researcher_config = minimal_agent_config()
        researcher_config["name"] = "researcher_agent"
        researcher = studio.agents.create(**researcher_config)
        cleanup_agents.append(researcher.id)

        # Create analyst agent
        analyst_config = minimal_agent_config()
        analyst_config["name"] = "analyst_agent"
        analyst = studio.agents.create(**analyst_config)
        cleanup_agents.append(analyst.id)

        # Create writer agent
        writer_config = minimal_agent_config()
        writer_config["name"] = "writer_agent"
        writer = studio.agents.create(**writer_config)
        cleanup_agents.append(writer.id)

        # Researcher -> Analyst -> Writer workflow
        research = researcher.run(prompts["research"])
        analysis = analyst.run(f"Analyze: {research}")
        article = writer.run(f"Write article based on: {analysis}")

        assert article is not None

    def test_e2e_user_journey(self, studio, cleanup_agents, cleanup_knowledge_bases):
        """Test end-to-end user journey."""
        # Step 1: Create knowledge base with documents
        kb_config = knowledge_base_config_qdrant()
        kb_config["name"] = "user_journey_kb"
        kb = studio.knowledge_bases.create(**kb_config)
        cleanup_knowledge_bases.append(kb.id)

        docs = [
            "Lyzr enables agent creation",
            "Agents can use knowledge bases",
            "Memory persists conversation context",
        ]
        for doc in docs:
            kb.add_text(doc, source="test")

        # Step 2: Create agent
        agent_config = minimal_agent_config()
        agent_config["name"] = "journey_agent"
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Step 3: Multi-turn conversation
        session = "user_journey"
        response1 = agent.run("What is Lyzr?", session_id=session, knowledge_bases=[kb])
        response2 = agent.run("How do agents use KB?", session_id=session, knowledge_bases=[kb])
        response3 = agent.run("Tell me more", session_id=session, knowledge_bases=[kb])

        # Step 4: Update agent
        studio.agents.update(agent.id, goal="Better goal")

        # Step 5: Verify updates
        updated = studio.agents.get(agent.id)
        assert updated.goal == "Better goal"
        assert response1 is not None
        assert response2 is not None
        assert response3 is not None

    def test_complex_feature_interaction(
        self, studio, cleanup_agents, cleanup_knowledge_bases, cleanup_memories
    ):
        """Test complex interaction of multiple features."""
        # Create KB with tools
        kb = studio.knowledge_bases.create(**knowledge_base_config_qdrant())
        cleanup_knowledge_bases.append(kb.id)
        kb.add_text("Technical Documentation", source="test")

        # Create agent
        agent_config = minimal_agent_config()
        agent_config["name"] = "complex_agent"
        agent_config["memory"] = 10  # Lyzr memory: persist 10 messages
        agent = studio.agents.create(**agent_config)
        cleanup_agents.append(agent.id)

        # Register tools
        def search(query: str) -> str:
            return f"Results for: {query}"

        def summarize(text: str) -> str:
            return f"Summary: {text[:50]}..."

        agent.add_tool(search)
        agent.add_tool(summarize)

        # Use all features
        session = "complex_session"
        response = agent.run(
            "Search KB, summarize results, remember for later",
            session_id=session,
            knowledge_bases=[kb],
        )

        assert response is not None
