import os
import pytest
from dotenv import load_dotenv
from lyzr import Studio


# Load environment variables
load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))


@pytest.fixture
def api_key():
    """Get API key from environment."""
    key = os.getenv('LYZR_API_KEY')
    if not key or key == 'your-dev-api-key':
        pytest.skip("LYZR_API_KEY not configured in .env file")
    return key


@pytest.fixture
def env():
    """Get environment setting."""
    return os.getenv('LYZR_ENV', 'dev')


@pytest.fixture
def studio(api_key, env):
    """Create a Studio instance for testing."""
    return Studio(api_key=api_key, env=env)


@pytest.fixture
def timeout():
    """Default timeout for API calls."""
    return 30


@pytest.fixture
def cleanup_agents(studio):
    """Fixture to cleanup created agents after tests."""
    agents_to_delete = []
    yield agents_to_delete

    # Cleanup
    for agent_id in agents_to_delete:
        try:
            studio.agents.delete(agent_id)
        except Exception:
            pass


@pytest.fixture
def cleanup_knowledge_bases(studio):
    """Fixture to cleanup created knowledge bases after tests."""
    kbs_to_delete = []
    yield kbs_to_delete

    # Cleanup
    for kb_id in kbs_to_delete:
        try:
            studio.knowledge_bases.delete(kb_id)
        except Exception:
            pass


@pytest.fixture
def cleanup_contexts(studio):
    """Fixture to cleanup created contexts after tests."""
    contexts_to_delete = []
    yield contexts_to_delete

    # Cleanup
    for context_id in contexts_to_delete:
        try:
            studio.contexts.delete(context_id)
        except Exception:
            pass


@pytest.fixture
def cleanup_policies(studio):
    """Fixture to cleanup created RAI policies after tests."""
    policies_to_delete = []
    yield policies_to_delete

    # Cleanup
    for policy_id in policies_to_delete:
        try:
            studio.rai.delete_policy(policy_id)
        except Exception:
            pass


@pytest.fixture
def cleanup_memories(studio):
    """Fixture to cleanup created memories after tests."""
    memories_to_delete = []
    yield memories_to_delete

    # Cleanup
    for memory_id in memories_to_delete:
        try:
            studio.memory.delete_credential(memory_id)
        except Exception:
            pass


@pytest.fixture
def sample_pdf_path():
    """Path to sample PDF file."""
    return os.path.join(
        os.path.dirname(__file__),
        'fixtures',
        'sample_files',
        'sample.pdf'
    )


@pytest.fixture
def sample_docx_path():
    """Path to sample DOCX file."""
    return os.path.join(
        os.path.dirname(__file__),
        'fixtures',
        'sample_files',
        'sample.docx'
    )


@pytest.fixture
def sample_txt_path():
    """Path to sample TXT file."""
    return os.path.join(
        os.path.dirname(__file__),
        'fixtures',
        'sample_files',
        'sample.txt'
    )
