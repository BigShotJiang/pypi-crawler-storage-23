"""Sample configurations for testing."""


def minimal_agent_config():
    """Minimal agent configuration."""
    return {
        'name': 'test_agent_minimal',
        'provider': 'gpt-4o',
        'role': 'Helpful Assistant',
        'goal': 'Provide clear and complete responses to user queries',
        'instructions': 'You are a helpful assistant. Always provide clear, complete responses. When asked to write something, generate meaningful content.'
    }


def full_agent_config():
    """Full agent configuration with all parameters."""
    return {
        'name': 'test_agent_full',
        'provider': 'gpt-4o',
        'role': 'Test Agent',
        'goal': 'Test all features',
        'instructions': 'You are a comprehensive test agent.',
        'temperature': 0.7,
        'top_p': 0.9,
        'max_tokens': 4096,
        'top_k': 40,
        'frequency_penalty': 0.0,
        'presence_penalty': 0.0,
    }


def claude_agent_config():
    """Agent configuration using Claude."""
    return {
        'name': 'test_agent_claude',
        'provider': 'claude-sonnet-4-5',
        'role': 'Claude Test Agent',
        'goal': 'Test with Anthropic Claude',
        'instructions': 'You are a helpful test agent powered by Claude.'
    }


def gemini_agent_config():
    """Agent configuration using Gemini."""
    return {
        'name': 'test_agent_gemini',
        'provider': 'gemini-2.0-flash',
        'role': 'Gemini Test Agent',
        'goal': 'Test with Google Gemini',
        'instructions': 'You are a helpful test agent powered by Gemini.'
    }


def deterministic_agent_config():
    """Agent with temperature=0 for deterministic responses."""
    return {
        'name': 'test_agent_deterministic',
        'provider': 'gpt-4o',
        'role': 'Deterministic Agent',
        'goal': 'Provide consistent answers',
        'instructions': 'You are a deterministic test agent.',
        'temperature': 0.0
    }


def knowledge_base_config_qdrant():
    """Knowledge base configuration with Qdrant."""
    return {
        'name': 'test_kb_qdrant',
        'vector_db': 'qdrant',
        'description': 'Test knowledge base with Qdrant'
    }


def knowledge_base_config_weaviate():
    """Knowledge base configuration with Weaviate."""
    return {
        'name': 'test_kb_weaviate',
        'vector_db': 'weaviate',
        'description': 'Test knowledge base with Weaviate'
    }


def rai_policy_pii_redact():
    """RAI policy with PII redaction."""
    from lyzr.rai import PIIType, PIIAction

    return {
        'name': 'test_policy_pii_redact',
        'description': 'Test RAI policy with PII redaction',
        'pii_detection': {
            PIIType.EMAIL: PIIAction.REDACT,
            PIIType.CREDIT_CARD: PIIAction.REDACT,
            PIIType.PHONE: PIIAction.REDACT,
            PIIType.SSN: PIIAction.REDACT
        }
    }


def rai_policy_content_blocking():
    """RAI policy with content blocking."""
    return {
        'name': 'test_policy_blocking',
        'description': 'Test RAI policy with content blocking',
        'toxicity_threshold': 0.5
    }


def memory_config_lyzr():
    """Memory configuration with Lyzr provider."""
    return {
        'name': 'test_memory_lyzr',
        'provider': 'lyzr',
        'config': {
            'max_messages': 10
        }
    }


def context_config():
    """Context configuration."""
    return {
        'name': 'test_context',
        'value': 'This is a test context value'
    }


def tool_config_simple():
    """Simple tool configuration."""
    return {
        'name': 'add_numbers',
        'description': 'Add two numbers',
        'parameters': {
            'type': 'object',
            'properties': {
                'a': {'type': 'number'},
                'b': {'type': 'number'}
            },
            'required': ['a', 'b']
        }
    }


def provider_configs():
    """List of available provider configurations."""
    return [
        {'name': 'gpt-4o', 'provider': 'gpt-4o'},
        {'name': 'claude-sonnet-4-5', 'provider': 'claude-sonnet-4-5'},
        {'name': 'gemini-2.0-flash', 'provider': 'gemini-2.0-flash'},
        {'name': 'groq-llama', 'provider': 'groq-llama'},
    ]


def temperature_test_values():
    """Temperature values to test."""
    return [0.0, 0.5, 1.0, 1.5, 2.0]


def top_p_test_values():
    """Top-p values to test."""
    return [0.0, 0.5, 0.9, 1.0]
