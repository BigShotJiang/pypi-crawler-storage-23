"""Test data and prompts for integration tests."""


def simple_math_prompt():
    """Simple math problem with deterministic answer."""
    return "What is 5 + 3? Answer with only the number."


def multi_turn_conversation():
    """Series of prompts for multi-turn conversation."""
    return [
        "What is the capital of France?",
        "What is its population?",
        "What is its most famous landmark?",
        "What year was it built?",
        "How tall is it?"
    ]


def kb_training_text():
    """Sample text for knowledge base training."""
    return """
    Lyzr is an AI agent orchestration platform that helps developers build and deploy intelligent agents.

    Key Features:
    - Agent Creation: Simple API to create AI agents with custom instructions
    - Knowledge Base: Upload documents and let agents query them
    - Memory: Persistent conversation memory for multi-turn interactions
    - Tools: Register Python functions as tools for agent execution
    - RAI: Responsible AI guardrails for safe agent behavior
    - Streaming: Real-time streaming responses
    - Structured Outputs: Type-safe response models

    Providers Supported:
    - OpenAI (GPT-4o, GPT-4 Turbo)
    - Anthropic (Claude Sonnet, Claude Opus)
    - Google (Gemini)
    - Groq (Llama)
    - Perplexity (Sonar)
    """


def kb_search_query():
    """Query for knowledge base search."""
    return "What are the key features of Lyzr?"


def invalid_agent_configs():
    """Invalid agent configurations for validation testing."""
    return [
        # Missing required fields
        {'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test', 'instructions': 'Test'},
        {'name': 'test', 'role': 'Test', 'goal': 'Test', 'instructions': 'Test'},
        {'name': 'test', 'provider': 'gpt-4o', 'goal': 'Test', 'instructions': 'Test'},
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'instructions': 'Test'},
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test'},

        # Invalid temperature
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test',
         'instructions': 'Test', 'temperature': -1},
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test',
         'instructions': 'Test', 'temperature': 2.5},

        # Invalid top_p
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test',
         'instructions': 'Test', 'top_p': -0.1},
        {'name': 'test', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test',
         'instructions': 'Test', 'top_p': 1.1},

        # Invalid provider
        {'name': 'test', 'provider': 'invalid-provider', 'role': 'Test', 'goal': 'Test',
         'instructions': 'Test'},

        # Empty strings
        {'name': '', 'provider': 'gpt-4o', 'role': 'Test', 'goal': 'Test', 'instructions': 'Test'},
        {'name': 'test', 'provider': '', 'role': 'Test', 'goal': 'Test', 'instructions': 'Test'},
    ]


def file_output_prompts():
    """Prompts for testing file output features."""
    return {
        'markdown': 'Create a markdown document about Python programming with sections for basics, functions, and classes.',
        'json': 'Generate a JSON document with information about 3 famous scientists including name, field, and achievements.',
        'csv': 'Create a CSV with 5 rows of sample user data including name, email, age, and country.',
        'text': 'Write a short poem about artificial intelligence.'
    }


def image_prompts():
    """Prompts for testing image generation."""
    return [
        "A serene mountain landscape with a lake at sunset",
        "A futuristic city with flying cars and neon lights",
        "A cozy library with warm lighting and books"
    ]


def tool_test_data():
    """Data for tool testing."""
    return {
        'simple_numbers': {'a': 5, 'b': 3},
        'negative_numbers': {'a': -10, 'b': 20},
        'decimals': {'a': 3.5, 'b': 2.7},
        'large_numbers': {'a': 1000000, 'b': 2000000}
    }


def structured_output_prompts():
    """Prompts for structured output testing."""
    return {
        'user_info': 'Extract the following from this text: name (string), age (integer), email (string). Text: "My name is John Smith, I am 30 years old, and my email is john@example.com"',
        'list_items': 'List 5 fruits in the format: name (string), color (string), price (float in dollars).',
    }


def reflection_test_prompt():
    """Prompt for testing reflection feature."""
    return "Explain quantum computing in simple terms, then reflect on whether your explanation was accurate and complete."


def bias_check_prompt():
    """Prompt for testing bias detection."""
    return "Write about the best career choices for different types of people."


def groundedness_facts():
    """Facts for groundedness testing."""
    return [
        "The Earth orbits the Sun, not the other way around",
        "Water boils at 100 degrees Celsius at sea level",
        "Python was created by Guido van Rossum in 1991"
    ]


def groundedness_test_prompt():
    """Prompt to test responses against facts."""
    return "What do you know about Python programming language and when was it created?"


def streaming_test_prompt():
    """Prompt for testing streaming functionality."""
    return "Write a short story (5 sentences) about a robot learning to paint."


def tool_chaining_data():
    """Data for testing tool chaining."""
    return [
        {'operation': 'add', 'values': [5, 3]},
        {'operation': 'multiply', 'values': [8, 2]},
        {'operation': 'subtract', 'values': [100, 25]}
    ]


def multi_agent_prompts():
    """Prompts for multi-agent workflow testing."""
    return {
        'research': "Research and provide key facts about renewable energy sources",
        'analysis': "Analyze the pros and cons of the provided information",
        'writing': "Write a comprehensive article about renewable energy based on the analysis"
    }


def edge_case_inputs():
    """Edge case inputs for testing."""
    return [
        "",  # Empty string
        " " * 100,  # Only whitespace
        "a" * 10000,  # Very long input
        "Special chars: !@#$%^&*()",
        "Unicode: 你好世界 🌍",
        "URL: https://example.com",
        "Code: print('hello')"
    ]
