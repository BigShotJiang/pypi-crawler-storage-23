"""
Studio - Main entry point for Lyzr Agent ADK
"""

from typing import Literal, Optional, Dict, List, Any, Type, Union
from pydantic import BaseModel
from lyzr.http import HTTPClient, AsyncHTTPClient
from lyzr.agents import AgentModule
from lyzr.knowledge_base import KnowledgeBaseModule
from lyzr.memory import MemoryModule
from lyzr.context import ContextModule
from lyzr.rai import RAIModule
from lyzr.urls import ServiceURLs


class Studio:
    """
    Main client for interacting with Lyzr Agent API

    Studio provides a clean interface to all Lyzr Agent API functionality.
    Each resource (agents, memory, artifacts, etc.) is accessible both as
    a module and through convenience methods.

    Example:
        >>> studio = Studio(api_key="sk-xxx")
        >>>
        >>> # Method 1: Direct convenience methods
        >>> agent = studio.create_agent(name="Bot", provider="openai/gpt-4o")
        >>>
        >>> # Method 2: Through module
        >>> agent = studio.agents.create(name="Bot", provider="openai/gpt-4o")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        env: Union[Literal["prod", "dev", "local"], ServiceURLs] = "prod",
        timeout: Optional[int] = None,
        log: str = "warning",
    ):
        """
        Initialize Studio client

        Args:
            api_key: Lyzr API key (reads from LYZR_API_KEY env var if not provided)
            env: Environment (prod, dev, local) - default: prod, or ServiceURLs(agent_api="", rag_api="", rai_api="")
            timeout: Request timeout in seconds (default: 30s for prod/dev, 300s for local)
            log: Log level (debug, info, warning, error, none) - default: warning

        Raises:
            AuthenticationError: If API key is not provided or invalid
            ValueError: If environment is unknown or not configured

        Example:
            >>> # Production (default)
            >>> studio = Studio(api_key="sk-xxx")
            >>>
            >>> # Development
            >>> studio = Studio(api_key="sk-xxx", env="dev")
            >>>
            >>> # Debug logging
            >>> studio = Studio(api_key="sk-xxx", log="debug")
            >>>
            >>> # Using environment variable
            >>> import os
            >>> os.environ["LYZR_API_KEY"] = "sk-xxx"
            >>> studio = Studio()
        """
        from lyzr.urls import get_urls
        from lyzr.logger import set_log_level, get_logger

        # Set log level
        set_log_level(log)
        logger = get_logger()
        logger.info(f"Initializing Studio (env={env})")

        # Get environment configuration
        if isinstance(env, ServiceURLs):
            self.env_config = env
            self.env = "custom"
        else:
            self.env_config = get_urls(env)
            self.env = env

        # Set default timeout based on environment
        if timeout is None:
            timeout = 300

        # Initialize HTTP client for Agent API
        self._http = HTTPClient(
            api_key=api_key, base_url=self.env_config.agent_api, timeout=timeout
        )

        # Register modules
        self._register_modules()

    def _register_modules(self):
        """Register all ADK modules and inject convenience methods"""

        # Register Agents module
        self.agents = AgentModule(self._http)

        # Inject convenience methods for agents
        # This allows both studio.create_agent() and studio.agents.create()
        self.create_agent = self.agents.create
        self.get_agent = self.agents.get
        self.list_agents = self.agents.list
        self.update_agent = self.agents.update
        self.delete_agent = self.agents.delete
        self.clone_agent = self.agents.clone
        self.bulk_delete_agents = self.agents.bulk_delete

        # Register KnowledgeBase module
        # Note: KnowledgeBaseModule creates its own HTTP client for RAG API
        self.knowledge_bases = KnowledgeBaseModule(self._http, self.env_config)

        # Inject convenience methods for knowledge bases
        self.create_knowledge_base = self.knowledge_bases.create
        self.get_knowledge_base = self.knowledge_bases.get
        self.list_knowledge_bases = self.knowledge_bases.list
        self.delete_knowledge_base = self.knowledge_bases.delete
        self.bulk_delete_knowledge_bases = self.knowledge_bases.bulk_delete

        # Register Context module
        self.contexts = ContextModule(self._http)
        self.create_context = self.contexts.create
        self.get_context = self.contexts.get
        self.list_contexts = self.contexts.list

        # Register RAI module
        self.rai = RAIModule(self._http, self.env_config)
        self.create_rai_policy = self.rai.create_policy
        self.get_rai_policy = self.rai.get_policy
        self.list_rai_policies = self.rai.list_policies

        # Register Memory module
        self.memory = MemoryModule(self._http)

        # Inject convenience methods for memory
        self.list_memory_providers = self.memory.list_providers
        self.create_memory_credential = self.memory.create_credential
        self.get_memory = self.memory.get_memory
        self.list_memories = self.memory.list_memories

        # Future modules will be registered here:
        # self.artifacts = ArtifactModule(self._http)
        # ...

    # ========================================================================
    # Async Support
    # ========================================================================

    def _ensure_async_clients(self):
        """Lazily create AsyncHTTPClient instances and inject into all modules"""
        if hasattr(self, '_async_initialized') and self._async_initialized:
            return

        # Create async HTTP client for Agent API
        self._async_http = AsyncHTTPClient(
            api_key=self._http.api_key,
            base_url=self.env_config.agent_api,
            timeout=self._http.timeout,
        )

        # Create async HTTP client for RAG API
        self._async_http_rag = AsyncHTTPClient(
            api_key=self._http.api_key,
            base_url=self.env_config.rag_api,
            timeout=300,
        )

        # Create async HTTP client for RAI API
        self._async_http_rai = AsyncHTTPClient(
            api_key=self._http.api_key,
            base_url=self.env_config.rai_api,
            timeout=30,
        )

        # Inject into modules
        self.agents._async_http = self._async_http
        self.agents._inference._async_http = self._async_http
        self.contexts._async_http = self._async_http
        self.memory._async_http = self._async_http
        self.rai._async_http = self._async_http_rai
        self.knowledge_bases._async_http = self._async_http_rag

        self._async_initialized = True

    # Async convenience methods

    async def acreate_agent(self, **kwargs):
        """Async create a new agent"""
        self._ensure_async_clients()
        return await self.agents.acreate(**kwargs)

    async def aget_agent(self, agent_id: str, **kwargs):
        """Async get an agent by ID"""
        self._ensure_async_clients()
        return await self.agents.aget(agent_id, **kwargs)

    async def alist_agents(self):
        """Async list all agents"""
        self._ensure_async_clients()
        return await self.agents.alist()

    async def aupdate_agent(self, agent_id: str, **kwargs):
        """Async update an agent"""
        self._ensure_async_clients()
        return await self.agents.aupdate(agent_id, **kwargs)

    async def adelete_agent(self, agent_id: str):
        """Async delete an agent"""
        self._ensure_async_clients()
        return await self.agents.adelete(agent_id)

    async def aclone_agent(self, agent_id: str, new_name: Optional[str] = None):
        """Async clone an agent"""
        self._ensure_async_clients()
        return await self.agents.aclone(agent_id, new_name)

    async def abulk_delete_agents(self, agent_ids: list):
        """Async bulk delete agents"""
        self._ensure_async_clients()
        return await self.agents.abulk_delete(agent_ids)

    async def acreate_knowledge_base(self, **kwargs):
        """Async create a knowledge base"""
        self._ensure_async_clients()
        return await self.knowledge_bases.acreate(**kwargs)

    async def aget_knowledge_base(self, kb_id: str):
        """Async get a knowledge base"""
        self._ensure_async_clients()
        return await self.knowledge_bases.aget(kb_id)

    async def alist_knowledge_bases(self, **kwargs):
        """Async list knowledge bases"""
        self._ensure_async_clients()
        return await self.knowledge_bases.alist(**kwargs)

    async def adelete_knowledge_base(self, kb_id: str):
        """Async delete a knowledge base"""
        self._ensure_async_clients()
        return await self.knowledge_bases.adelete(kb_id)

    async def acreate_context(self, name: str, value: str):
        """Async create a context"""
        self._ensure_async_clients()
        return await self.contexts.acreate(name, value)

    async def aget_context(self, context_id: str):
        """Async get a context"""
        self._ensure_async_clients()
        return await self.contexts.aget(context_id)

    async def alist_contexts(self, **kwargs):
        """Async list contexts"""
        self._ensure_async_clients()
        return await self.contexts.alist(**kwargs)

    async def acreate_rai_policy(self, **kwargs):
        """Async create a RAI policy"""
        self._ensure_async_clients()
        return await self.rai.acreate_policy(**kwargs)

    async def aget_rai_policy(self, policy_id: str):
        """Async get a RAI policy"""
        self._ensure_async_clients()
        return await self.rai.aget_policy(policy_id)

    async def alist_rai_policies(self):
        """Async list RAI policies"""
        self._ensure_async_clients()
        return await self.rai.alist_policies()

    async def alist_memory_providers(self):
        """Async list memory providers"""
        self._ensure_async_clients()
        return await self.memory.alist_providers()

    async def acreate_memory_credential(self, **kwargs):
        """Async create memory credential"""
        self._ensure_async_clients()
        return await self.memory.acreate_credential(**kwargs)

    async def aget_memory(self, credential_id: str, provider: str):
        """Async get memory"""
        self._ensure_async_clients()
        return await self.memory.aget_memory(credential_id, provider)

    async def alist_memories(self):
        """Async list memories"""
        self._ensure_async_clients()
        return await self.memory.alist_memories()

    # Lifecycle

    def close(self):
        """Close the HTTP client connection"""
        self._http.close()

    async def aclose(self):
        """Close all async HTTP client connections"""
        if hasattr(self, '_async_initialized') and self._async_initialized:
            await self._async_http.close()
            await self._async_http_rag.close()
            await self._async_http_rai.close()
            self._async_initialized = False

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()

    async def __aenter__(self):
        """Async context manager entry - initializes async clients"""
        self._ensure_async_clients()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - closes async clients"""
        await self.aclose()
        self.close()

    def __repr__(self) -> str:
        """String representation"""
        return f"Studio(base_url='{self._http.base_url}')"
