"""
Lyzr Agent ADK - Intuitive Python ADK for Lyzr Agent API
"""

from lyzr.__version__ import __version__
from lyzr.studio import Studio
from lyzr.models import Agent, AgentConfig, AgentList
from lyzr.responses import AgentResponse, AgentStream, TaskResponse, TaskStatus, Artifact
from lyzr.protocols import Runnable, Updatable, Deletable, Cloneable
from lyzr.inference import InferenceModule
from lyzr.knowledge_base import (
    KnowledgeBase,
    KnowledgeBaseModule,
    QueryResult,
    Document,
    KnowledgeBaseRuntimeConfig,
)
from lyzr.tools.local import Tool, ToolRegistry, LocalToolExecutor
from lyzr.image_models import ImageModelConfig, Gemini, DallE, ImageProvider
from lyzr.rai import RAIPolicy, RAIModule, RAIPolicyList, PIIType, PIIAction, SecretsAction, ValidationMethod
from lyzr.context import Context, ContextModule, ContextList
from lyzr.memory import (
    MemoryConfig,
    Memory,
    MemoryModule,
    MemoryProvider,
    MemoryStatus,
    MemoryResource,
    MemoryCredentialConfig,
    MemoryList
)
from lyzr.skills import (
    load_skills,
    Skill,
    SkillMetadata,
)
from lyzr.http import AsyncHTTPClient
from lyzr.exceptions import (
    LyzrError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
    APIError,
    RateLimitError,
    TimeoutError,
    InvalidResponseError,
    ToolNotFoundError,
)

__all__ = [
    # Main entry point
    "Studio",

    # Core models
    "Agent",
    "AgentConfig",
    "AgentList",

    # Knowledge Base
    "KnowledgeBase",
    "KnowledgeBaseModule",
    "QueryResult",
    "Document",
    "KnowledgeBaseRuntimeConfig",

    # Tools
    "Tool",
    "ToolRegistry",
    "LocalToolExecutor",

    # Image Models
    "ImageModelConfig",
    "Gemini",
    "DallE",
    "ImageProvider",

    # RAI (Responsible AI)
    "RAIPolicy",
    "RAIModule",
    "RAIPolicyList",
    "PIIType",
    "PIIAction",
    "SecretsAction",
    "ValidationMethod",

    # Context
    "Context",
    "ContextModule",
    "ContextList",

    # Memory
    "MemoryConfig",
    "Memory",
    "MemoryModule",
    "MemoryProvider",
    "MemoryStatus",
    "MemoryResource",
    "MemoryCredentialConfig",
    "MemoryList",

    # Skills
    "load_skills",
    "Skill",
    "SkillMetadata",

    # Response types
    "AgentResponse",
    "AgentStream",
    "TaskResponse",
    "TaskStatus",
    "Artifact",

    # Protocols
    "Runnable",
    "Updatable",
    "Deletable",
    "Cloneable",

    # Modules
    "InferenceModule",

    # Async
    "AsyncHTTPClient",

    # Exceptions
    "LyzrError",
    "AuthenticationError",
    "ValidationError",
    "NotFoundError",
    "APIError",
    "RateLimitError",
    "TimeoutError",
    "InvalidResponseError",
    "ToolNotFoundError",
]

# Rebuild models to resolve forward references after all imports are complete
# This is needed because AgentConfig references Context, KnowledgeBase, etc.
AgentConfig.model_rebuild()
Agent.model_rebuild()
AgentList.model_rebuild()
