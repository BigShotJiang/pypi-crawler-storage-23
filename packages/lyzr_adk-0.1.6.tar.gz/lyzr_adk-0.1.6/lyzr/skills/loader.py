"""
Skill loader for Lyzr ADK

Handles discovery, parsing, and loading of SKILL.md files.
"""

import os
import re
from pathlib import Path
from typing import List, Optional, Union

import yaml

from lyzr.skills.models import Skill, SkillMetadata


# Default search paths for skill discovery
DEFAULT_SEARCH_PATHS = [
    Path.home() / ".lyzr" / "skills",
    Path.home() / ".claude" / "skills",
    Path.cwd() / ".lyzr" / "skills",
    Path.cwd() / "skills",
]

# Regex pattern for YAML frontmatter
FRONTMATTER_PATTERN = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


def parse_skill_file(path: Path) -> Skill:
    """
    Parse a SKILL.md file into a Skill object

    Args:
        path: Path to the SKILL.md file

    Returns:
        Skill: Parsed skill with metadata and content

    Raises:
        ValueError: If file has invalid format or missing required fields
        FileNotFoundError: If file doesn't exist
    """
    if not path.exists():
        raise FileNotFoundError(f"Skill file not found: {path}")

    content = path.read_text(encoding="utf-8")

    # Extract YAML frontmatter
    match = FRONTMATTER_PATTERN.match(content)
    if not match:
        raise ValueError(
            f"Invalid skill file format: {path}. "
            "Expected YAML frontmatter between --- markers."
        )

    frontmatter_yaml = match.group(1)
    markdown_content = content[match.end() :].strip()

    # Parse YAML frontmatter
    try:
        frontmatter = yaml.safe_load(frontmatter_yaml)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML frontmatter in {path}: {e}")

    if not isinstance(frontmatter, dict):
        raise ValueError(f"YAML frontmatter must be a dictionary in {path}")

    # Validate required fields
    if "name" not in frontmatter:
        raise ValueError(f"Missing required field 'name' in {path}")
    if "description" not in frontmatter:
        raise ValueError(f"Missing required field 'description' in {path}")

    # Create metadata
    metadata = SkillMetadata(
        name=frontmatter["name"],
        description=frontmatter["description"],
        version=frontmatter.get("version", "1.0.0"),
        tags=frontmatter.get("tags", []),
    )

    return Skill(metadata=metadata, content=markdown_content, path=path)


def discover_skills(search_paths: Optional[List[Path]] = None) -> List[Path]:
    """
    Discover SKILL.md files in search paths

    Searches for files named SKILL.md in skill directories.
    A skill directory can contain a SKILL.md file directly or have
    subdirectories each containing a SKILL.md file.

    Args:
        search_paths: Paths to search (default: DEFAULT_SEARCH_PATHS)

    Returns:
        List of paths to discovered SKILL.md files
    """
    if search_paths is None:
        search_paths = DEFAULT_SEARCH_PATHS

    discovered = []

    for base_path in search_paths:
        if not base_path.exists():
            continue

        # Check for SKILL.md directly in the base path
        direct_skill = base_path / "SKILL.md"
        if direct_skill.exists():
            discovered.append(direct_skill)

        # Check subdirectories for SKILL.md files
        if base_path.is_dir():
            for item in base_path.iterdir():
                if item.is_dir():
                    skill_file = item / "SKILL.md"
                    if skill_file.exists():
                        discovered.append(skill_file)

    return discovered


def load_skills(
    paths: Optional[List[Union[str, Path]]] = None,
    names: Optional[List[str]] = None,
    search_paths: Optional[List[Union[str, Path]]] = None,
) -> List[Skill]:
    """
    Load skills from the filesystem

    This is the main entry point for loading skills. Skills can be loaded by:
    1. Providing explicit file paths
    2. Discovering skills from search paths and filtering by name
    3. Discovering all skills from search paths

    Args:
        paths: Explicit paths to SKILL.md files to load
        names: Skill names to filter (only load skills with these names)
        search_paths: Custom search paths (default: ~/.lyzr/skills, ~/.claude/skills,
                      ./.lyzr/skills, ./skills)

    Returns:
        List of loaded Skill objects

    Raises:
        ValueError: If a skill file has invalid format
        FileNotFoundError: If an explicit path doesn't exist

    Example:
        >>> # Load all skills from default paths
        >>> skills = load_skills()
        >>>
        >>> # Load specific skills by name
        >>> skills = load_skills(names=["research", "git-helper"])
        >>>
        >>> # Load from explicit paths
        >>> skills = load_skills(paths=["./my-skill/SKILL.md"])
        >>>
        >>> # Custom search paths
        >>> skills = load_skills(search_paths=["./custom/skills"])
    """
    loaded_skills = []

    # Convert string paths to Path objects
    if search_paths:
        search_paths = [Path(p) if isinstance(p, str) else p for p in search_paths]

    # Load from explicit paths if provided
    if paths:
        for path in paths:
            path = Path(path) if isinstance(path, str) else path
            skill = parse_skill_file(path)
            loaded_skills.append(skill)
    else:
        # Discover skills from search paths
        discovered_paths = discover_skills(search_paths)

        for skill_path in discovered_paths:
            try:
                skill = parse_skill_file(skill_path)
                loaded_skills.append(skill)
            except (ValueError, FileNotFoundError) as e:
                # Log warning but continue loading other skills
                import warnings

                warnings.warn(f"Failed to load skill from {skill_path}: {e}")

    # Filter by names if provided
    if names:
        names_set = set(names)
        loaded_skills = [s for s in loaded_skills if s.name in names_set]

    return loaded_skills
