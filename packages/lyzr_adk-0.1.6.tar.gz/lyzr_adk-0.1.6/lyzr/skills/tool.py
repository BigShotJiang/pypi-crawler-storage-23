"""
Skill tool factory for Lyzr ADK

Creates the use_skill tool that agents use to load full skill content.
"""

from typing import Dict, List, Any

from lyzr.skills.models import Skill
from lyzr.tools.local import Tool


def generate_skills_metadata_prompt(skills: List[Skill]) -> str:
    """
    Generate a prompt section describing available skills

    This is injected into the agent's system prompt so it knows what
    skills are available and can decide whether to use them.

    Args:
        skills: List of skills to describe

    Returns:
        Formatted string for system prompt injection

    Example output:
        ## Available Skills

        You have access to the following skills. Use the `use_skill` tool to load
        the full instructions for a skill when you need it.

        - **research** (v1.0.0): Systematic research methodology
          Tags: research, analysis

        - **git-helper** (v2.0.0): Git workflow assistant
          Tags: git, version-control
    """
    if not skills:
        return ""

    lines = [
        "## Available Skills",
        "",
        "You have access to the following skills. Use the `use_skill` tool to load",
        "the full instructions for a skill when you need it.",
        "",
    ]

    for skill in skills:
        # Skill name and description
        lines.append(f"- **{skill.name}** (v{skill.version}): {skill.description}")

        # Tags if present
        if skill.tags:
            tags_str = ", ".join(skill.tags)
            lines.append(f"  Tags: {tags_str}")

        lines.append("")

    return "\n".join(lines)


def create_use_skill_tool(skills: List[Skill]) -> Tool:
    """
    Create a use_skill tool for loading full skill content

    The tool is registered with the agent and called when the agent
    decides it needs the full instructions from a skill.

    Args:
        skills: List of available skills

    Returns:
        Tool: The use_skill tool configured with available skills

    Example:
        >>> skills = load_skills()
        >>> tool = create_use_skill_tool(skills)
        >>> agent.add_tool(tool)
        >>>
        >>> # Agent can now call:
        >>> # use_skill(skill_name="research")
        >>> # Returns full skill content
    """
    # Build a lookup dict for fast access
    skills_by_name: Dict[str, Skill] = {skill.name: skill for skill in skills}

    def use_skill(skill_name: str) -> str:
        """
        Load the full instructions for a skill

        Args:
            skill_name: Name of the skill to load

        Returns:
            Full skill content (markdown instructions)
        """
        skill = skills_by_name.get(skill_name)
        if not skill:
            available = list(skills_by_name.keys())
            return (
                f"Error: Skill '{skill_name}' not found. "
                f"Available skills: {available}"
            )

        # Return the full skill content
        return skill.content

    # Define the tool parameters
    parameters = {
        "type": "object",
        "properties": {
            "skill_name": {
                "type": "string",
                "description": "Name of the skill to load (e.g., 'research', 'git-helper')",
            }
        },
        "required": ["skill_name"],
    }

    # Build description with available skill names
    skill_names = [s.name for s in skills]
    description = (
        f"Load the full instructions for a skill. "
        f"Available skills: {skill_names}. "
        f"Call this when you need detailed guidance on how to perform a specific task."
    )

    return Tool(
        name="use_skill",
        description=description,
        parameters=parameters,
        function=use_skill,
    )
