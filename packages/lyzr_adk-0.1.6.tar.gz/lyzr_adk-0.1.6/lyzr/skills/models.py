"""
Skill data models for Lyzr ADK

Skills are local file-based instruction sets that agents can load on-demand.
"""

from typing import List, Optional
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict


class SkillMetadata(BaseModel):
    """
    Metadata for a skill (parsed from YAML frontmatter)

    This information is shown to the agent upfront so it can decide
    whether to load the full skill content.
    """

    name: str = Field(..., description="Unique skill identifier")
    description: str = Field(..., description="Brief description of what the skill does")
    version: str = Field(default="1.0.0", description="Skill version")
    tags: List[str] = Field(default_factory=list, description="Tags for categorization")


class Skill(BaseModel):
    """
    A complete skill with metadata and content

    Skills are loaded from SKILL.md files with YAML frontmatter.
    The full content is only provided to the agent when it calls use_skill().

    Example SKILL.md file:
        ---
        name: research
        description: Systematic research methodology
        version: 1.0.0
        tags: [research, analysis]
        ---

        # Research Skill

        When conducting research:
        1. Understand the query
        2. Gather information
        3. Synthesize findings
    """

    metadata: SkillMetadata = Field(..., description="Skill metadata from frontmatter")
    content: str = Field(..., description="Full markdown instructions")
    path: Optional[Path] = Field(default=None, description="Source file path")

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @property
    def name(self) -> str:
        """Convenience property to access skill name"""
        return self.metadata.name

    @property
    def description(self) -> str:
        """Convenience property to access skill description"""
        return self.metadata.description

    @property
    def version(self) -> str:
        """Convenience property to access skill version"""
        return self.metadata.version

    @property
    def tags(self) -> List[str]:
        """Convenience property to access skill tags"""
        return self.metadata.tags

    def __str__(self) -> str:
        return f"Skill(name='{self.name}', version='{self.version}')"

    def __repr__(self) -> str:
        return self.__str__()
