"""
Skills module for Lyzr ADK

Skills are local file-based instruction sets that agents can load on-demand.
They provide a progressive disclosure pattern where agents see metadata upfront
and can load full content via the use_skill tool when needed.

Example:
    >>> from lyzr import Studio, load_skills
    >>>
    >>> studio = Studio(api_key="...")
    >>>
    >>> # Load skills from default paths
    >>> skills = load_skills()
    >>>
    >>> # Or specific skills by name
    >>> skills = load_skills(names=["research", "git-helper"])
    >>>
    >>> # Create agent with skills
    >>> agent = studio.create_agent(
    ...     name="Assistant",
    ...     provider="openai/gpt-4o",
    ...     role="Helpful assistant",
    ...     goal="Help users",
    ...     instructions="Use your skills when appropriate.",
    ...     skills=skills,  # Auto-adds use_skill tool
    ... )
    >>>
    >>> response = agent.run("Research AI trends")
"""

from lyzr.skills.models import Skill, SkillMetadata
from lyzr.skills.loader import load_skills, parse_skill_file, discover_skills
from lyzr.skills.tool import create_use_skill_tool, generate_skills_metadata_prompt

__all__ = [
    # Main API
    "load_skills",
    "Skill",
    "SkillMetadata",
    # Advanced API
    "parse_skill_file",
    "discover_skills",
    "create_use_skill_tool",
    "generate_skills_metadata_prompt",
]
