"""
KnowledgeBaseModule for managing knowledge base operations
"""

from typing import Optional, List, Dict, Any, TYPE_CHECKING
from lyzr.base import BaseModule
from lyzr.exceptions import ValidationError
from lyzr.knowledge_base.models import QueryResult, Document
from lyzr.knowledge_base.config import KnowledgeBaseConfig
from lyzr.knowledge_base.entity import KnowledgeBase, KnowledgeBaseList

if TYPE_CHECKING:
    from lyzr.http import HTTPClient
    from lyzr.urls import ServiceURLs


class KnowledgeBaseModule(BaseModule):
    """
    Module for managing knowledge bases (RAG configurations)

    Can be used standalone or through Studio client.

    Example (Standalone):
        >>> from lyzr.http import HTTPClient
        >>> from lyzr.knowledge_base import KnowledgeBaseModule
        >>> http = HTTPClient(api_key="sk-xxx", base_url="https://rag-prod.studio.lyzr.ai")
        >>> kbs = KnowledgeBaseModule(http)
        >>> kb = kbs.create(name="support_kb")

    Example (Through Studio):
        >>> from lyzr import Studio
        >>> studio = Studio(api_key="sk-xxx")
        >>> kb = studio.create_knowledge_base(name="support_kb")
    """

    def __init__(self, http_client: 'HTTPClient', env_config: 'ServiceURLs'):
        """
        Initialize KnowledgeBaseModule

        Note: Creates a separate HTTP client for RAG API (different base URL)
        Uses longer timeout (300s) for document processing and website crawling.

        Args:
            http_client: Main HTTP client (for api_key)
            env_config: Environment URL configuration
        """
        from lyzr.http import HTTPClient

        # Create new HTTP client for RAG API with longer timeout
        # Document processing and website crawling can take several minutes
        self._http = HTTPClient(
            api_key=http_client.api_key,
            base_url=env_config.rag_api,  # Use environment-specific URL
            timeout=300  # 5 minutes for RAG operations
        )

    def _make_smart_kb(self, kb_data: Dict[str, Any], name: Optional[str] = None) -> KnowledgeBase:
        """
        Create smart KnowledgeBase with injected clients

        Args:
            kb_data: Raw KB data from API
            name: Optional name to inject (API doesn't return it)

        Returns:
            KnowledgeBase: Smart KB with methods
        """
        # Normalize id field (create returns "id", list/get returns "_id")
        if "id" in kb_data and "_id" not in kb_data:
            kb_data["_id"] = kb_data["id"]

        # Inject name if provided (API doesn't return it)
        if name and "name" not in kb_data:
            kb_data["name"] = name

        kb = KnowledgeBase(**kb_data)
        kb._http = self._http
        kb._kb_module = self
        return kb

    def create(
        self,
        name: str,
        vector_store: str = "qdrant",
        embedding_model: str = "text-embedding-3-large",
        llm_model: str = "gpt-4o",
        description: Optional[str] = None,
        **kwargs
    ) -> KnowledgeBase:
        """
        Create a new knowledge base

        Args:
            name: KB name (lowercase, numbers, underscores only)
            vector_store: Vector store type (qdrant, weaviate, pg_vector, milvus, neptune)
            embedding_model: Embedding model name (default: text-embedding-3-large)
            llm_model: LLM model name (default: gpt-4o)
            description: KB description
            **kwargs: Additional configuration

        Returns:
            KnowledgeBase: Created smart KB object

        Raises:
            ValidationError: If name format is invalid
            APIError: If API request fails

        Example:
            >>> kb = kbs.create(
            ...     name="customer_support",
            ...     description="Customer support docs",
            ...     vector_store="qdrant"
            ... )
        """
        # Build configuration
        config = KnowledgeBaseConfig(
            name=name,
            vector_store=vector_store,
            embedding_model=embedding_model,
            llm_model=llm_model,
            description=description,
            **kwargs
        )

        # Make API request
        response = self._http.post("/v3/rag/", json=config.to_api_dict())

        # API returns KB data but without the name field
        # Inject the name we used for creation
        return self._make_smart_kb(response, name=name)

    def get(self, kb_id: str) -> KnowledgeBase:
        """
        Get knowledge base by ID

        Args:
            kb_id: Knowledge base ID

        Returns:
            KnowledgeBase: Smart KB object

        Raises:
            NotFoundError: If KB doesn't exist
            APIError: If API request fails

        Example:
            >>> kb = kbs.get("kb_abc123")
            >>> print(kb.name)
        """
        response = self._http.get(f"/v3/rag/{kb_id}/")
        return self._make_smart_kb(response)

    def list(self, user_id: Optional[str] = None) -> KnowledgeBaseList:
        """
        List knowledge bases

        Args:
            user_id: Optional user ID to filter by (defaults to API key)

        Returns:
            KnowledgeBaseList: List of KBs (iterable)

        Example:
            >>> all_kbs = kbs.list()
            >>> for kb in all_kbs:
            ...     print(kb.name)
        """
        # Use api_key as user_id if not provided
        if not user_id:
            # Extract from HTTP client - use the api_key value
            user_id = self._http.api_key

        response = self._http.get(f"/v3/rag/user/{user_id}/")

        # Handle response format - API returns {"configs": [...]}
        if isinstance(response, dict) and "configs" in response:
            kb_data_list = response["configs"]
            kb_list = [self._make_smart_kb(kb_data) for kb_data in kb_data_list]
            return KnowledgeBaseList(
                knowledge_bases=kb_list,
                total=len(kb_list)
            )
        elif isinstance(response, list):
            kb_list = [self._make_smart_kb(kb_data) for kb_data in response]
            return KnowledgeBaseList(knowledge_bases=kb_list, total=len(kb_list))
        elif isinstance(response, dict):
            kb_data = response.get("knowledge_bases", response.get("data", []))
            kb_list = [self._make_smart_kb(kb) for kb in kb_data]
            return KnowledgeBaseList(
                knowledge_bases=kb_list,
                total=response.get("total", len(kb_list))
            )
        else:
            return KnowledgeBaseList(knowledge_bases=[])

    def update(self, kb_id: str, **kwargs) -> KnowledgeBase:
        """
        Update knowledge base configuration

        Args:
            kb_id: Knowledge base ID
            **kwargs: Fields to update

        Returns:
            KnowledgeBase: Updated KB object

        Example:
            >>> kb = kbs.update("kb_123", description="Updated desc")
        """
        if not kwargs:
            raise ValidationError("No fields provided for update")

        response = self._http.put(f"/v3/rag/{kb_id}/", json=kwargs)

        # API returns {"success": True}, not KB data
        # Fetch updated KB
        return self.get(kb_id)

    def delete(self, kb_id: str) -> bool:
        """
        Delete a knowledge base

        Args:
            kb_id: Knowledge base ID

        Returns:
            bool: True if successful

        Example:
            >>> success = kbs.delete("kb_123")
        """
        return self._http.delete(f"/v3/rag/{kb_id}/")

    def bulk_delete(self, kb_ids: List[str]) -> bool:
        """
        Delete multiple knowledge bases

        Args:
            kb_ids: List of KB IDs to delete

        Returns:
            bool: True if successful

        Example:
            >>> kbs.bulk_delete(["kb_1", "kb_2", "kb_3"])
        """
        if not kb_ids:
            raise ValidationError("kb_ids cannot be empty")

        response = self._http.post(
            "/v3/rag/bulk-delete/",
            json={"config_ids": kb_ids}
        )
        return True

    # Internal methods (used by KnowledgeBase methods)

    def _train_pdf(
        self,
        rag_id: str,
        file_path: str,
        data_parser: Optional[str] = None,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
        extra_info: Optional[str] = None,
    ) -> bool:
        """Internal: Add PDF to knowledge base"""
        data = {}
        if data_parser is not None:
            data["data_parser"] = str(data_parser)
        if chunk_size is not None:
            data["chunk_size"] = str(chunk_size)
        if chunk_overlap is not None:
            data["chunk_overlap"] = str(chunk_overlap)
        if extra_info is not None:
            data["extra_info"] = str(extra_info)

        return self._http.post_file(
            path="/v3/train/pdf/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )

    def _train_docx(
        self,
        rag_id: str,
        file_path: str,
        data_parser: Optional[str] = None,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
        extra_info: Optional[str] = None,
    ) -> bool:
        """Internal: Add DOCX to knowledge base"""
        data = {}
        if data_parser is not None:
            data["data_parser"] = str(data_parser)
        if chunk_size is not None:
            data["chunk_size"] = str(chunk_size)
        if chunk_overlap is not None:
            data["chunk_overlap"] = str(chunk_overlap)
        if extra_info is not None:
            data["extra_info"] = str(extra_info)

        self._http.post_file(
            path="/v3/train/docx/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )
        return True

    def _train_txt(
        self,
        rag_id: str,
        file_path: str,
        data_parser: Optional[str] = None,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
        extra_info: Optional[str] = None,
    ) -> bool:
        """Internal: Add TXT to knowledge base"""
        data = {}
        if data_parser is not None:
            data["data_parser"] = str(data_parser)
        if chunk_size is not None:
            data["chunk_size"] = str(chunk_size)
        if chunk_overlap is not None:
            data["chunk_overlap"] = str(chunk_overlap)
        if extra_info is not None:
            data["extra_info"] = str(extra_info)

        self._http.post_file(
            path="/v3/train/txt/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )
        return True

    def _train_website(
        self,
        rag_id: str,
        urls: List[str],
        source: str = "website",
        max_crawl_pages: Optional[int] = None,
        max_crawl_depth: Optional[int] = None,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
        dynamic_content_wait_secs: Optional[int] = None,
        actor: Optional[str] = None,
        crawler_type: Optional[str] = None,
    ) -> bool:
        """Internal: Add website to knowledge base"""
        payload = {
            "urls": urls,
            "source": source,
        }

        # Add optional parameters
        if max_crawl_pages is not None:
            payload["max_crawl_pages"] = max_crawl_pages
        if max_crawl_depth is not None:
            payload["max_crawl_depth"] = max_crawl_depth
        if chunk_size is not None:
            payload["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            payload["chunk_overlap"] = chunk_overlap
        if dynamic_content_wait_secs is not None:
            payload["dynamic_content_wait_secs"] = dynamic_content_wait_secs
        if actor is not None:
            payload["actor"] = actor
        if crawler_type is not None:
            payload["crawler_type"] = crawler_type

        self._http.post(
            path="/v3/train/website/",
            params={"rag_id": rag_id},
            json=payload,
        )
        return True

    def _train_text(
        self,
        rag_id: str,
        data: List[Dict[str, str]],
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> bool:
        """Internal: Add text to knowledge base"""
        payload = {
            "data": data,
        }

        # Add optional parameters
        if chunk_size is not None:
            payload["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            payload["chunk_overlap"] = chunk_overlap

        self._http.post(
            path="/v3/train/text/",
            params={"rag_id": rag_id},
            json=payload,
        )
        return True

    def _query(
        self,
        rag_id: str,
        query: str,
        top_k: Optional[int] = None,
        retrieval_type: Optional[str] = None,
        score_threshold: Optional[float] = None,
        lambda_param: Optional[float] = None,
        time_decay_factor: Optional[float] = None,
    ) -> List[QueryResult]:
        """Internal: Query knowledge base"""
        params = {
            "query": query,
        }

        # Add optional parameters
        if top_k is not None:
            params["top_k"] = top_k
        if retrieval_type is not None:
            params["retrieval_type"] = retrieval_type
        if score_threshold is not None:
            params["score_threshold"] = score_threshold
        if lambda_param is not None:
            params["lambda_param"] = lambda_param
        if time_decay_factor is not None:
            params["time_decay_factor"] = time_decay_factor

        response = self._http.get(f"/v3/rag/{rag_id}/retrieve/", params=params)

        # Parse results
        results = response.get("results", [])
        return [QueryResult(**result) for result in results]

    def _list_documents(self, rag_id: str) -> List[Document]:
        """Internal: List documents in KB"""
        response = self._http.get(f"/v3/rag/documents/{rag_id}/")

        # API returns a simple list of document names (strings)
        if isinstance(response, list):
            # Convert strings to Document objects
            return [
                Document(id=f"doc_{i}", source=doc_name, text=None)
                for i, doc_name in enumerate(response)
            ]
        else:
            # Fallback if format changes
            documents = response.get("documents", [])
            return [Document(**doc) if isinstance(doc, dict) else Document(id=f"doc_{i}", source=str(doc)) for i, doc in enumerate(documents)]

    def _delete_documents(self, rag_id: str, doc_ids: List[str]) -> bool:
        """Internal: Delete documents from KB"""
        self._http.delete(
            f"/v3/rag/{rag_id}/docs/",
            json_body=doc_ids
        )
        return True

    def _reset(self, rag_id: str) -> bool:
        """Internal: Clear all documents from KB"""
        self._http.delete(f"/v3/rag/{rag_id}/reset/")
        return True

    # ========================================================================
    # Async Methods
    # ========================================================================

    def _ensure_async(self):
        """Ensure async HTTP client is available (KB creates its own)"""
        if not self._async_http:
            raise RuntimeError(
                "Async not initialized. Use 'async with Studio(...) as studio:' "
                "to enable async support."
            )

    async def acreate(
        self,
        name: str,
        vector_store: str = "qdrant",
        embedding_model: str = "text-embedding-3-large",
        llm_model: str = "gpt-4o",
        description: Optional[str] = None,
        **kwargs
    ) -> KnowledgeBase:
        """Async create a new knowledge base"""
        self._ensure_async()

        config = KnowledgeBaseConfig(
            name=name,
            vector_store=vector_store,
            embedding_model=embedding_model,
            llm_model=llm_model,
            description=description,
            **kwargs
        )

        response = await self._async_http.post("/v3/rag/", json=config.to_api_dict())
        return self._make_smart_kb(response, name=name)

    async def aget(self, kb_id: str) -> KnowledgeBase:
        """Async get knowledge base by ID"""
        self._ensure_async()
        response = await self._async_http.get(f"/v3/rag/{kb_id}/")
        return self._make_smart_kb(response)

    async def alist(self, user_id: Optional[str] = None) -> KnowledgeBaseList:
        """Async list knowledge bases"""
        self._ensure_async()

        if not user_id:
            user_id = self._http.api_key

        response = await self._async_http.get(f"/v3/rag/user/{user_id}/")

        if isinstance(response, dict) and "configs" in response:
            kb_data_list = response["configs"]
            kb_list = [self._make_smart_kb(kb_data) for kb_data in kb_data_list]
            return KnowledgeBaseList(knowledge_bases=kb_list, total=len(kb_list))
        elif isinstance(response, list):
            kb_list = [self._make_smart_kb(kb_data) for kb_data in response]
            return KnowledgeBaseList(knowledge_bases=kb_list, total=len(kb_list))
        elif isinstance(response, dict):
            kb_data = response.get("knowledge_bases", response.get("data", []))
            kb_list = [self._make_smart_kb(kb) for kb in kb_data]
            return KnowledgeBaseList(knowledge_bases=kb_list, total=response.get("total", len(kb_list)))
        else:
            return KnowledgeBaseList(knowledge_bases=[])

    async def aupdate(self, kb_id: str, **kwargs) -> KnowledgeBase:
        """Async update knowledge base configuration"""
        self._ensure_async()
        if not kwargs:
            raise ValidationError("No fields provided for update")

        await self._async_http.put(f"/v3/rag/{kb_id}/", json=kwargs)
        return await self.aget(kb_id)

    async def adelete(self, kb_id: str) -> bool:
        """Async delete a knowledge base"""
        self._ensure_async()
        return await self._async_http.delete(f"/v3/rag/{kb_id}/")

    async def abulk_delete(self, kb_ids: List[str]) -> bool:
        """Async delete multiple knowledge bases"""
        self._ensure_async()
        if not kb_ids:
            raise ValidationError("kb_ids cannot be empty")

        await self._async_http.post("/v3/rag/bulk-delete/", json={"config_ids": kb_ids})
        return True

    async def _atrain_pdf(self, rag_id: str, file_path: str, **kwargs) -> bool:
        """Async internal: Add PDF to knowledge base"""
        self._ensure_async()
        data = {}
        for key in ("data_parser", "chunk_size", "chunk_overlap", "extra_info"):
            if kwargs.get(key) is not None:
                data[key] = str(kwargs[key])

        await self._async_http.post_file(
            path="/v3/train/pdf/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )
        return True

    async def _atrain_docx(self, rag_id: str, file_path: str, **kwargs) -> bool:
        """Async internal: Add DOCX to knowledge base"""
        self._ensure_async()
        data = {}
        for key in ("data_parser", "chunk_size", "chunk_overlap", "extra_info"):
            if kwargs.get(key) is not None:
                data[key] = str(kwargs[key])

        await self._async_http.post_file(
            path="/v3/train/docx/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )
        return True

    async def _atrain_txt(self, rag_id: str, file_path: str, **kwargs) -> bool:
        """Async internal: Add TXT to knowledge base"""
        self._ensure_async()
        data = {}
        for key in ("data_parser", "chunk_size", "chunk_overlap", "extra_info"):
            if kwargs.get(key) is not None:
                data[key] = str(kwargs[key])

        await self._async_http.post_file(
            path="/v3/train/txt/",
            file_path=file_path,
            file_field="file",
            params={"rag_id": rag_id},
            data=data,
        )
        return True

    async def _atrain_website(self, rag_id: str, urls: List[str], **kwargs) -> bool:
        """Async internal: Add website to knowledge base"""
        self._ensure_async()
        payload = {"urls": urls, "source": kwargs.get("source", "website")}

        for key in ("max_crawl_pages", "max_crawl_depth", "chunk_size", "chunk_overlap",
                     "dynamic_content_wait_secs", "actor", "crawler_type"):
            if kwargs.get(key) is not None:
                payload[key] = kwargs[key]

        await self._async_http.post(
            path="/v3/train/website/",
            params={"rag_id": rag_id},
            json=payload,
        )
        return True

    async def _atrain_text(self, rag_id: str, data: List[Dict[str, str]], **kwargs) -> bool:
        """Async internal: Add text to knowledge base"""
        self._ensure_async()
        payload = {"data": data}

        for key in ("chunk_size", "chunk_overlap"):
            if kwargs.get(key) is not None:
                payload[key] = kwargs[key]

        await self._async_http.post(
            path="/v3/train/text/",
            params={"rag_id": rag_id},
            json=payload,
        )
        return True

    async def _aquery(self, rag_id: str, query: str, **kwargs) -> List[QueryResult]:
        """Async internal: Query knowledge base"""
        self._ensure_async()
        params = {"query": query}

        for key in ("top_k", "retrieval_type", "score_threshold", "lambda_param", "time_decay_factor"):
            if kwargs.get(key) is not None:
                params[key] = kwargs[key]

        response = await self._async_http.get(f"/v3/rag/{rag_id}/retrieve/", params=params)
        results = response.get("results", [])
        return [QueryResult(**result) for result in results]

    async def _alist_documents(self, rag_id: str) -> List[Document]:
        """Async internal: List documents in KB"""
        self._ensure_async()
        response = await self._async_http.get(f"/v3/rag/documents/{rag_id}/")

        if isinstance(response, list):
            return [
                Document(id=f"doc_{i}", source=doc_name, text=None)
                for i, doc_name in enumerate(response)
            ]
        else:
            documents = response.get("documents", [])
            return [Document(**doc) if isinstance(doc, dict) else Document(id=f"doc_{i}", source=str(doc)) for i, doc in enumerate(documents)]

    async def _adelete_documents(self, rag_id: str, doc_ids: List[str]) -> bool:
        """Async internal: Delete documents from KB"""
        self._ensure_async()
        await self._async_http.delete(f"/v3/rag/{rag_id}/docs/", json_body=doc_ids)
        return True

    async def _areset(self, rag_id: str) -> bool:
        """Async internal: Clear all documents from KB"""
        self._ensure_async()
        await self._async_http.delete(f"/v3/rag/{rag_id}/reset/")
        return True
