"""
Base module class for all Lyzr Agent ADK modules
"""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from lyzr.http import HTTPClient, AsyncHTTPClient


class BaseModule:
    """Base class for all ADK modules"""

    def __init__(self, http_client: 'HTTPClient', async_http_client: Optional['AsyncHTTPClient'] = None):
        """
        Initialize module with HTTP client

        Args:
            http_client: Configured HTTP client instance
            async_http_client: Optional async HTTP client instance
        """
        self._http = http_client
        self._async_http: Optional['AsyncHTTPClient'] = async_http_client

    def _ensure_async(self):
        """Ensure async HTTP client is available"""
        if not self._async_http:
            raise RuntimeError(
                "Async not initialized. Use 'async with Studio(...) as studio:' "
                "to enable async support."
            )
