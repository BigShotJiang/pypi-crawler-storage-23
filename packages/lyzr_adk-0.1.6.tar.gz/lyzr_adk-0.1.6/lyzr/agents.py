"""
Agent module for managing agents
"""

from typing import Optional, List, Dict, Any, Type, Union, TYPE_CHECKING
from pydantic import BaseModel
from lyzr.base import BaseModule
from lyzr.models import Agent, AgentConfig, AgentList
from lyzr.exceptions import ValidationError
from lyzr.inference import InferenceModule

if TYPE_CHECKING:
    from lyzr.rai import RAIPolicy
    from lyzr.memory import MemoryConfig
    from lyzr.context import Context
    from lyzr.models.config import ImageModelConfig
    from lyzr.skills import Skill

# Sentinel value to detect "not provided" vs "explicitly None"
_NOT_PROVIDED = object()


class AgentModule(BaseModule):
    """
    Module for managing Lyzr agents

    Can be used standalone or through Studio client.

    Example (Standalone):
        >>> from lyzr.http import HTTPClient
        >>> from lyzr.agents import AgentModule
        >>> http = HTTPClient(api_key="sk-xxx")
        >>> agents = AgentModule(http)
        >>> agent = agents.create(name="Bot", provider="openai/gpt-4o")

    Example (Through Studio):
        >>> from lyzr import Studio
        >>> studio = Studio(api_key="sk-xxx")
        >>> agent = studio.create_agent(name="Bot", provider="openai/gpt-4o")
        >>> # OR
        >>> agent = studio.agents.create(name="Bot", provider="openai/gpt-4o")
    """

    def __init__(self, http_client):
        """Initialize AgentModule with HTTP client and inference module"""
        super().__init__(http_client)
        self._inference = InferenceModule(http_client)

    def _make_smart_agent(
        self, agent_data: Dict[str, Any], response_model: Optional[Type[BaseModel]] = None
    ) -> Agent:
        """
        Create a smart Agent with injected clients

        Args:
            agent_data: Raw agent data from API
            response_model: Optional Pydantic model for structured responses

        Returns:
            Agent: Smart agent with .run(), .update(), .delete(), .clone() methods
        """
        agent = Agent(**agent_data)
        # Inject clients
        agent._http = self._http
        agent._inference = self._inference
        agent._agent_module = self
        agent._response_model = response_model
        return agent

    def create(
        self,
        name: str,
        provider: str,
        role: str,
        goal: str,
        instructions: str,
        temperature: float = 0.7,
        top_p: float = 0.9,
        response_model: Optional[Type[BaseModel]] = None,
        description: Optional[str] = None,
        store_messages: bool = True,
        file_output: bool = False,
        image_output_config: Optional[Dict[str, Any]] = None,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: bool = False,
        bias_check: bool = False,
        llm_judge: bool = False,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = None,
        image_model: Optional["ImageModelConfig"] = None,
        features: Optional[List[Any]] = None,
        examples: Optional[str] = None,
        tools: Optional[List[str]] = None,
        managed_agents: Optional[List[Any]] = None,
        tool_usage_description: str = "{}",
        tool_configs: Optional[List[Any]] = None,
        llm_credential_id: str = "lyzr_openai",
        local_tools: Optional[List[Any]] = None,
        skills: Optional[List["Skill"]] = None,
    ) -> Agent:
        """
        Create a new agent

        Args:
            name: Agent name
            provider: Provider and model (e.g., 'openai/gpt-4o' or 'gpt-4o')
            role: Agent's role or persona
            goal: Agent's primary goal
            instructions: Detailed instructions for the agent
            temperature: Sampling temperature (0.0 to 2.0), default 0.7
            top_p: Nucleus sampling parameter (0.0 to 1.0), default 0.9
            response_model: Pydantic model for structured responses
            description: Agent description
            store_messages: Whether to store conversation messages, default True
            file_output: Whether agent can output files, default False
            image_output_config: Image output configuration
            memory: Memory configuration (int or MemoryConfig)
            contexts: Contexts to add to agent
            reflection: Enable self-reflection, default False
            bias_check: Enable bias detection, default False
            llm_judge: Enable LLM-as-judge, default False
            groundedness_facts: Facts for groundedness validation
            rai_policy: RAI policy for guardrails
            image_model: Image model configuration
            features: Enabled features list
            examples: Example interactions
            tools: List of tool IDs to enable
            managed_agents: Managed sub-agents list
            tool_usage_description: Tool usage description JSON string
            tool_configs: Tool configurations list
            llm_credential_id: LLM credential ID, default 'lyzr_openai'
            local_tools: Local tools to attach (functions or Tool objects)
            skills: Skills to add (auto-registers use_skill tool)

        Returns:
            Agent: Created smart agent object

        Raises:
            ValidationError: If parameters are invalid
            APIError: If API request fails

        Example:
            >>> # Text response
            >>> agent = agents.create(
            ...     name="Support Bot",
            ...     provider="openai/gpt-4o",
            ...     role="Customer support",
            ...     goal="Help customers",
            ...     instructions="Respond politely",
            ...     temperature=0.7
            ... )
            >>>
            >>> # Structured response
            >>> class Result(BaseModel):
            ...     answer: str
            >>>
            >>> agent = agents.create(
            ...     name="Structured Bot",
            ...     provider="openai/gpt-4o",
            ...     role="Data processor",
            ...     goal="Extract information",
            ...     instructions="Extract and format data",
            ...     response_model=Result
            ... )
        """
        # Build configuration using Pydantic model
        config = AgentConfig(
            name=name,
            provider=provider,
            temperature=temperature,
            top_p=top_p,
            description=description,
            role=role,
            goal=goal,
            instructions=instructions,
            examples=examples,
            tools=tools or [],
            tool_usage_description=tool_usage_description,
            tool_configs=tool_configs or [],
            llm_credential_id=llm_credential_id,
            features=features or [],
            managed_agents=managed_agents or [],
            store_messages=store_messages,
            file_output=file_output,
            image_output_config=image_output_config,
            response_model=response_model,
            contexts=contexts,
            reflection=reflection,
            bias_check=bias_check,
            llm_judge=llm_judge,
            groundedness_facts=groundedness_facts,
            rai_policy=rai_policy,
            image_model=image_model,
            memory=memory,
        )

        # Handle RAI policy if provided
        if rai_policy:
            from lyzr.rai import RAIPolicy

            if isinstance(rai_policy, RAIPolicy):
                # Get RAI endpoint
                rai_endpoint = f"{self._http.base_url.replace('agent-', 'srs-')}/v1/rai/inference"
                # Add RAI feature to config
                api_dict = config.to_api_dict()
                current_features = api_dict.get("features", [])
                api_dict["features"] = current_features + [
                    rai_policy.to_feature_format(rai_endpoint)
                ]

                # Make API request with RAI feature
                response = self._http.post("/v3/agents/", json=api_dict)
            else:
                # Make API request without RAI
                response = self._http.post("/v3/agents/", json=config.to_api_dict())
        else:
            # Make API request
            response = self._http.post("/v3/agents/", json=config.to_api_dict())

        # API returns {"agent_id": "..."}
        agent_id = response.get("agent_id")
        if not agent_id:
            raise ValidationError("API did not return agent_id")

        # Fetch full agent details and inject response_model
        agent = self.get(agent_id, response_model=response_model)

        # Attach local tools if provided
        if local_tools:
            self._attach_local_tools(agent, local_tools)

        # Attach skills if provided
        if skills:
            agent.add_skills(skills)

        return agent

    def get(self, agent_id: str, response_model: Optional[Type[BaseModel]] = None) -> Agent:
        """
        Get an existing agent by ID

        Args:
            agent_id: Agent ID
            response_model: Optional Pydantic model for structured responses

        Returns:
            Agent: Smart agent object

        Raises:
            NotFoundError: If agent doesn't exist
            APIError: If API request fails

        Example:
            >>> agent = agents.get("agent_abc123")
            >>> print(agent.name)
            >>> response = agent.run("Hello!")
            >>>
            >>> # Add tools after getting agent
            >>> agent.add_tool(lambda x: x * 2)
            >>> response = agent.run("Use the tool")
        """
        response = self._http.get(f"/v3/agents/{agent_id}")
        agent = self._make_smart_agent(response, response_model=response_model)

        return agent

    def list(self) -> AgentList:
        """
        List all agents

        Returns:
            AgentList: List of smart agents (iterable)

        Raises:
            APIError: If API request fails

        Example:
            >>> all_agents = agents.list()
            >>> for agent in all_agents:
            ...     print(agent.name)
            ...     # Each agent is smart and can run
            ...     response = agent.run("Hello")
        """
        response = self._http.get("/v3/agents/")

        # Handle different response formats
        if isinstance(response, list):
            agents = []
            for agent_data in response:
                try:
                    agent = self._make_smart_agent(agent_data)
                    agents.append(agent)
                except Exception as e:
                    # Skip agents that fail validation (might be corrupted/old)
                    print(f"Warning: Skipping agent {agent_data}: {str(e)}")
                    continue
            return AgentList(agents=agents, total=len(agents))
        elif isinstance(response, dict):
            agents_data = response.get("agents", response.get("data", []))
            agents = [self._make_smart_agent(agent_data) for agent_data in agents_data]
            return AgentList(agents=agents, total=response.get("total", len(agents)))
        else:
            return AgentList(agents=[])

    def _attach_local_tools(self, agent: Agent, tools: Optional[List[Any]]) -> Agent:
        """
        Attach local tools to an agent's registry

        Args:
            agent: Agent to attach tools to
            tools: List of tools (functions, Tool objects, or mix)

        Returns:
            Agent: Same agent with tools attached to _tool_registry
        """
        if not tools:
            return agent

        from lyzr.tools.local import Tool, ToolRegistry, LocalToolExecutor

        # Initialize tool registry if not present
        if not agent._tool_registry:
            agent._tool_registry = ToolRegistry()
            agent._tool_executor = LocalToolExecutor(agent._tool_registry)

        # Add each tool
        for tool in tools:
            if isinstance(tool, Tool):
                # Already a Tool object
                agent._tool_registry.add(tool)
            elif callable(tool):
                # Convert function to Tool using agent's method
                tool_obj = agent._function_to_tool(tool)
                agent._tool_registry.add(tool_obj)
            else:
                raise TypeError(f"Unknown tool type: {type(tool)}. Expected Tool or callable.")

        return agent

    def _merge_field(
        self, update_data: Dict[str, Any], key: str, new_value: Any, current_value: Any
    ) -> None:
        """
        Helper to merge a field: use new value if provided, else use current value

        Args:
            update_data: Dictionary to update
            key: Key to set in update_data
            new_value: New value (can be None to skip)
            current_value: Current/fallback value
        """
        if new_value is not None:
            update_data[key] = new_value
        elif current_value:
            update_data[key] = current_value

    def _get_current_features(self, update_data: Dict[str, Any], current_agent: Agent) -> List[Any]:
        """Get current features from update_data or current_agent"""
        return update_data.get("features") or current_agent.features or []

    def _update_srs_feature(
        self,
        update_data: Dict[str, Any],
        current_agent: Agent,
        reflection: Optional[bool] = None,
        bias_check: Optional[bool] = None,
    ) -> None:
        """
        Helper to update SRS (Self-Reflection System) feature

        Args:
            update_data: Dictionary to update
            current_agent: Current agent for fallback
            reflection: Enable reflection (None to keep current)
            bias_check: Enable bias check (None to keep current)
        """
        current_features = self._get_current_features(update_data, current_agent)

        # Get current SRS modules
        srs_modules = {}
        for f in current_features:
            if f.get("type") == "SRS":
                srs_modules = f.get("config", {}).get("modules", {}).copy()
                break

        # Update with new values if provided
        if reflection is not None:
            srs_modules["reflection"] = reflection
        if bias_check is not None:
            srs_modules["bias"] = bias_check

        # Remove old SRS feature
        features_without_srs = [f for f in current_features if f.get("type") != "SRS"]

        # Add updated SRS feature if any module is enabled
        if any(srs_modules.values()):
            srs_feature = {
                "type": "SRS",
                "config": {"max_tries": 1, "modules": srs_modules},
                "priority": 0,
            }
            update_data["features"] = features_without_srs + [srs_feature]
        else:
            # No modules enabled - remove SRS
            update_data["features"] = features_without_srs

    def _handle_advanced_updates(
        self,
        update_data: Dict[str, Any],
        current_agent: Agent,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: Optional[bool] = None,
        bias_check: Optional[bool] = None,
        llm_judge: Optional[bool] = None,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = None,
        image_model: Optional["ImageModelConfig"] = None,
    ) -> None:
        """
        Handle all advanced parameter updates (features, image model, etc.)

        Args:
            update_data: Dictionary to update
            current_agent: Current agent for fallback
            memory: Memory configuration
            contexts: Contexts to add
            reflection: Enable self-reflection
            bias_check: Enable bias detection
            llm_judge: Enable LLM-as-judge
            groundedness_facts: Facts for groundedness validation
            rai_policy: RAI policy for guardrails
            image_model: Image model configuration
        """
        # Handle memory
        if memory is not None:
            from lyzr.memory import MemoryConfig

            # Convert int shorthand to MemoryConfig
            memory_config = (
                MemoryConfig(max_messages_context_count=memory)
                if isinstance(memory, int)
                else memory
            )
            # Remove old memory feature and add new one
            current_features = self._get_current_features(update_data, current_agent)
            features_without_memory = [f for f in current_features if f.get("type") != "MEMORY"]
            update_data["features"] = features_without_memory + [memory_config.to_feature_format()]

        # Handle contexts
        if contexts is not None:
            current_features = self._get_current_features(update_data, current_agent)
            features_without_contexts = [f for f in current_features if f.get("type") != "CONTEXT"]

            if contexts:
                context_features = [ctx.to_feature_format() for ctx in contexts]
                update_data["features"] = features_without_contexts + context_features
            else:
                update_data["features"] = features_without_contexts

        # Handle SRS features (reflection + bias_check)
        if reflection is not None or bias_check is not None:
            self._update_srs_feature(update_data, current_agent, reflection, bias_check)

        # Handle llm_judge
        if llm_judge is not None:
            current_features = self._get_current_features(update_data, current_agent)
            features_without_judge = [
                f for f in current_features if f.get("type") != "UQLM_LLM_JUDGE"
            ]

            if llm_judge:
                update_data["features"] = features_without_judge + [
                    {"type": "UQLM_LLM_JUDGE", "config": {}, "priority": 0}
                ]
            else:
                update_data["features"] = features_without_judge

        # Handle groundedness_facts
        if groundedness_facts is not None:
            current_features = self._get_current_features(update_data, current_agent)
            features_without_groundedness = [
                f for f in current_features if f.get("type") != "GROUNDEDNESS"
            ]

            if groundedness_facts:
                update_data["features"] = features_without_groundedness + [
                    {"type": "GROUNDEDNESS", "config": {"facts": groundedness_facts}, "priority": 0}
                ]
            else:
                update_data["features"] = features_without_groundedness

        # Handle rai_policy
        if rai_policy is not None:
            from lyzr.rai import RAIPolicy

            current_features = self._get_current_features(update_data, current_agent)
            features_without_rai = [f for f in current_features if f.get("type") != "RAI"]

            if rai_policy and isinstance(rai_policy, RAIPolicy):
                # Get RAI endpoint
                rai_endpoint = f"{self._http.base_url.replace('agent-', 'srs-')}/v1/rai/inference"
                update_data["features"] = features_without_rai + [
                    rai_policy.to_feature_format(rai_endpoint)
                ]
            else:
                update_data["features"] = features_without_rai

        # Handle image_model
        if image_model is not None:
            if image_model:
                update_data["image_output_config"] = {
                    "model": image_model.model,
                    "credential_id": image_model.credential_id,
                }
            else:
                update_data["image_output_config"] = None

    def update(
        self,
        agent_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        role: Optional[str] = None,
        goal: Optional[str] = None,
        instructions: Optional[str] = None,
        response_model: Optional[Type[BaseModel]] = None,
        store_messages: Optional[bool] = None,
        file_output: Optional[bool] = None,
        image_output_config: Optional[Dict[str, Any]] = None,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: Optional[bool] = None,
        bias_check: Optional[bool] = None,
        llm_judge: Optional[bool] = None,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = _NOT_PROVIDED,
        image_model: Optional["ImageModelConfig"] = None,
        features: Optional[List[Any]] = None,
        examples: Optional[str] = None,
        tools: Optional[List[str]] = None,
        managed_agents: Optional[List[Any]] = None,
        tool_usage_description: Optional[str] = None,
        tool_configs: Optional[List[Any]] = None,
        llm_credential_id: Optional[str] = None,
        local_tools: Optional[List[Any]] = None,
    ) -> Agent:
        """
        Update an existing agent

        Args:
            agent_id: Agent ID
            name: New agent name
            description: New description
            temperature: New temperature (0.0 to 2.0)
            top_p: New top_p value (0.0 to 1.0)
            role: New agent role or persona
            goal: New agent goal
            instructions: New instructions for the agent
            response_model: Pydantic model for structured responses
            store_messages: Whether to store conversation messages
            file_output: Whether agent can output files
            image_output_config: Image output configuration
            memory: Memory configuration (int or MemoryConfig)
            contexts: Contexts to add to agent
            reflection: Enable self-reflection
            bias_check: Enable bias detection
            llm_judge: Enable LLM-as-judge
            groundedness_facts: Facts for groundedness validation
            rai_policy: RAI policy for guardrails
            image_model: Image model configuration
            features: Enabled features list
            examples: Example interactions
            tools: List of tool IDs to enable
            managed_agents: Managed sub-agents list
            tool_usage_description: Tool usage description JSON string
            tool_configs: Tool configurations list
            llm_credential_id: LLM credential ID
            local_tools: Local tools to attach (functions or Tool objects)

        Returns:
            Agent: Updated agent object

        Raises:
            NotFoundError: If agent doesn't exist
            ValidationError: If parameters are invalid
            APIError: If API request fails

        Example:
            >>> agent = agents.update(
            ...     "agent_abc123",
            ...     temperature=0.5,
            ...     description="Updated description"
            ... )
        """
        # Get current agent to merge with updates
        current_agent = self.get(agent_id)

        # Build update data with required fields and current values as base
        update_data = {
            "name": name if name is not None else current_agent.name,
            "provider_id": current_agent.provider_id,
            "model": current_agent.model,
            "temperature": temperature if temperature is not None else current_agent.temperature,
            "top_p": top_p if top_p is not None else current_agent.top_p,
        }

        # Merge optional fields
        self._merge_field(update_data, "description", description, current_agent.description)
        self._merge_field(update_data, "agent_role", role, current_agent.agent_role)
        self._merge_field(update_data, "agent_goal", goal, current_agent.agent_goal)
        self._merge_field(
            update_data, "agent_instructions", instructions, current_agent.agent_instructions
        )
        self._merge_field(update_data, "examples", examples, current_agent.examples)
        self._merge_field(update_data, "tools", tools, current_agent.tools)
        self._merge_field(
            update_data,
            "tool_usage_description",
            tool_usage_description,
            current_agent.tool_usage_description,
        )
        self._merge_field(update_data, "tool_configs", tool_configs, current_agent.tool_configs)
        self._merge_field(
            update_data, "managed_agents", managed_agents, current_agent.managed_agents
        )
        self._merge_field(update_data, "features", features, current_agent.features)
        self._merge_field(
            update_data, "llm_credential_id", llm_credential_id, current_agent.llm_credential_id
        )
        self._merge_field(
            update_data, "store_messages", store_messages, current_agent.store_messages
        )
        self._merge_field(update_data, "file_output", file_output, current_agent.file_output)
        self._merge_field(
            update_data,
            "image_output_config",
            image_output_config,
            current_agent.image_output_config,
        )

        # Validate temperature and top_p ranges
        if not 0.0 <= update_data["temperature"] <= 2.0:
            raise ValidationError("Temperature must be between 0.0 and 2.0")
        if not 0.0 <= update_data["top_p"] <= 1.0:
            raise ValidationError("top_p must be between 0.0 and 1.0")

        # Handle advanced feature parameters
        # !!!!MODIFIES update_data inplace
        self._handle_advanced_updates(
            update_data=update_data,
            current_agent=current_agent,
            memory=memory,
            contexts=contexts,
            reflection=reflection,
            bias_check=bias_check,
            llm_judge=llm_judge,
            groundedness_facts=groundedness_facts,
            rai_policy=rai_policy,
            image_model=image_model,
        )

        response = self._http.put(f"/v3/agents/{agent_id}", json=update_data)

        # API returns success message, not agent data
        # Fetch updated agent
        updated_agent = self.get(agent_id)

        # If response_model was provided, inject it into the agent for client-side parsing
        if response_model is not None:
            updated_agent._response_model = response_model

        # Attach local tools if provided
        if local_tools:
            self._attach_local_tools(updated_agent, local_tools)

        return updated_agent

    def delete(self, agent_id: str) -> bool:
        """
        Delete an agent

        Args:
            agent_id: Agent ID

        Returns:
            bool: True if deleted successfully

        Raises:
            NotFoundError: If agent doesn't exist
            APIError: If API request fails

        Example:
            >>> success = agents.delete("agent_abc123")
            >>> print(success)
            True
        """
        return self._http.delete(f"/v3/agents/{agent_id}")

    def clone(self, agent_id: str, new_name: Optional[str] = None) -> Agent:
        """
        Clone an existing agent

        Args:
            agent_id: Agent ID to clone
            new_name: Name for the cloned agent

        Returns:
            Agent: Cloned agent object

        Raises:
            NotFoundError: If agent doesn't exist
            APIError: If API request fails

        Example:
            >>> cloned = agents.clone("agent_abc123", "Cloned Agent")
        """
        # Get the existing agent
        original = self.get(agent_id)

        # Build provider string from provider_id and model
        # create() expects "provider/model" format
        provider_string = f"{original.provider_id}/{original.model}"

        # Prepare data for creating new agent with same config
        clone_kwargs = {
            "name": new_name or f"{original.name} (Clone)",
            "provider": provider_string,
            "temperature": original.temperature,
            "top_p": original.top_p,
        }

        # Add optional string fields if they exist
        # Note: create() expects role/goal/instructions, not agent_role/agent_goal/agent_instructions
        if original.description:
            clone_kwargs["description"] = original.description
        if original.agent_role:
            clone_kwargs["role"] = original.agent_role
        if original.agent_goal:
            clone_kwargs["goal"] = original.agent_goal
        if original.agent_instructions:
            clone_kwargs["instructions"] = original.agent_instructions
        if original.agent_context:
            clone_kwargs["agent_context"] = original.agent_context
        if original.agent_output:
            clone_kwargs["agent_output"] = original.agent_output

        # Add tools list if it exists
        if original.tools:
            clone_kwargs["tools"] = original.tools

        # Add optional config fields if they exist
        if original.features:
            clone_kwargs["features"] = original.features
        if original.tool_configs:
            clone_kwargs["tool_configs"] = original.tool_configs
        if original.file_output:
            clone_kwargs["file_output"] = original.file_output
        if original.image_output_config:
            clone_kwargs["image_output_config"] = original.image_output_config
        if original.voice_config:
            clone_kwargs["voice_config"] = original.voice_config
        if original._response_model:
            clone_kwargs["response_model"] = original._response_model
        if original.store_messages is not None:
            clone_kwargs["store_messages"] = original.store_messages
        if original.examples:
            clone_kwargs["examples"] = original.examples
        if original.additional_model_params:
            clone_kwargs["additional_model_params"] = original.additional_model_params

        # Create the new agent using the create method
        return self.create(**clone_kwargs)

    def bulk_delete(self, agent_ids: List[str]) -> bool:
        """
        Delete multiple agents at once

        Args:
            agent_ids: List of agent IDs to delete

        Returns:
            bool: True if successful

        Raises:
            ValidationError: If agent_ids is empty
            APIError: If API request fails

        Example:
            >>> success = agents.bulk_delete(["id1", "id2", "id3"])
        """
        if not agent_ids:
            raise ValidationError("agent_ids cannot be empty")

        response = self._http.post("/v3/agents/bulk-delete", json={"agent_ids": agent_ids})
        return True

    def remove_rai_policy(self, agent_id: str) -> Agent:
        """
        Remove RAI policy from an agent

        Args:
            agent_id: Agent ID

        Returns:
            Agent: Updated agent without RAI policy

        Example:
            >>> agent = agents.remove_rai_policy("agent_abc123")
        """
        # Fetch agent and manually remove RAI feature
        agent = self.get(agent_id)
        current_features = agent.features or []
        new_features = [f for f in current_features if f.get("type") != "RAI"]
        return self.update(agent_id, features=new_features)

    # ========================================================================
    # Async Methods
    # ========================================================================

    def _build_create_payload(
        self,
        name: str,
        provider: str,
        role: str,
        goal: str,
        instructions: str,
        temperature: float = 0.7,
        top_p: float = 0.9,
        response_model: Optional[Type[BaseModel]] = None,
        description: Optional[str] = None,
        store_messages: bool = True,
        file_output: bool = False,
        image_output_config: Optional[Dict[str, Any]] = None,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: bool = False,
        bias_check: bool = False,
        llm_judge: bool = False,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = None,
        image_model: Optional["ImageModelConfig"] = None,
        features: Optional[List[Any]] = None,
        examples: Optional[str] = None,
        tools: Optional[List[str]] = None,
        managed_agents: Optional[List[Any]] = None,
        tool_usage_description: str = "{}",
        tool_configs: Optional[List[Any]] = None,
        llm_credential_id: str = "lyzr_openai",
    ) -> Dict[str, Any]:
        """Build the API payload for agent creation"""
        config = AgentConfig(
            name=name,
            provider=provider,
            temperature=temperature,
            top_p=top_p,
            description=description,
            role=role,
            goal=goal,
            instructions=instructions,
            examples=examples,
            tools=tools or [],
            tool_usage_description=tool_usage_description,
            tool_configs=tool_configs or [],
            llm_credential_id=llm_credential_id,
            features=features or [],
            managed_agents=managed_agents or [],
            store_messages=store_messages,
            file_output=file_output,
            image_output_config=image_output_config,
            response_model=response_model,
            contexts=contexts,
            reflection=reflection,
            bias_check=bias_check,
            llm_judge=llm_judge,
            groundedness_facts=groundedness_facts,
            rai_policy=rai_policy,
            image_model=image_model,
            memory=memory,
        )

        api_dict = config.to_api_dict()

        if rai_policy:
            from lyzr.rai import RAIPolicy as RAIPolicyClass
            if isinstance(rai_policy, RAIPolicyClass):
                rai_endpoint = f"{self._http.base_url.replace('agent-', 'srs-')}/v1/rai/inference"
                current_features = api_dict.get("features", [])
                api_dict["features"] = current_features + [
                    rai_policy.to_feature_format(rai_endpoint)
                ]

        return api_dict

    async def acreate(
        self,
        name: str,
        provider: str,
        role: str,
        goal: str,
        instructions: str,
        temperature: float = 0.7,
        top_p: float = 0.9,
        response_model: Optional[Type[BaseModel]] = None,
        description: Optional[str] = None,
        store_messages: bool = True,
        file_output: bool = False,
        image_output_config: Optional[Dict[str, Any]] = None,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: bool = False,
        bias_check: bool = False,
        llm_judge: bool = False,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = None,
        image_model: Optional["ImageModelConfig"] = None,
        features: Optional[List[Any]] = None,
        examples: Optional[str] = None,
        tools: Optional[List[str]] = None,
        managed_agents: Optional[List[Any]] = None,
        tool_usage_description: str = "{}",
        tool_configs: Optional[List[Any]] = None,
        llm_credential_id: str = "lyzr_openai",
        local_tools: Optional[List[Any]] = None,
        skills: Optional[List["Skill"]] = None,
    ) -> Agent:
        """Async create a new agent"""
        self._ensure_async()

        api_dict = self._build_create_payload(
            name=name, provider=provider, role=role, goal=goal,
            instructions=instructions, temperature=temperature, top_p=top_p,
            response_model=response_model, description=description,
            store_messages=store_messages, file_output=file_output,
            image_output_config=image_output_config, memory=memory,
            contexts=contexts, reflection=reflection, bias_check=bias_check,
            llm_judge=llm_judge, groundedness_facts=groundedness_facts,
            rai_policy=rai_policy, image_model=image_model, features=features,
            examples=examples, tools=tools, managed_agents=managed_agents,
            tool_usage_description=tool_usage_description,
            tool_configs=tool_configs, llm_credential_id=llm_credential_id,
        )

        response = await self._async_http.post("/v3/agents/", json=api_dict)

        agent_id = response.get("agent_id")
        if not agent_id:
            raise ValidationError("API did not return agent_id")

        agent = await self.aget(agent_id, response_model=response_model)

        if local_tools:
            self._attach_local_tools(agent, local_tools)

        if skills:
            agent.add_skills(skills)

        return agent

    async def aget(self, agent_id: str, response_model: Optional[Type[BaseModel]] = None) -> Agent:
        """Async get an existing agent by ID"""
        self._ensure_async()
        response = await self._async_http.get(f"/v3/agents/{agent_id}")
        agent = self._make_smart_agent(response, response_model=response_model)
        return agent

    async def alist(self) -> AgentList:
        """Async list all agents"""
        self._ensure_async()
        response = await self._async_http.get("/v3/agents/")

        if isinstance(response, list):
            agents = []
            for agent_data in response:
                try:
                    agent = self._make_smart_agent(agent_data)
                    agents.append(agent)
                except Exception:
                    continue
            return AgentList(agents=agents, total=len(agents))
        elif isinstance(response, dict):
            agents_data = response.get("agents", response.get("data", []))
            agents = [self._make_smart_agent(agent_data) for agent_data in agents_data]
            return AgentList(agents=agents, total=response.get("total", len(agents)))
        else:
            return AgentList(agents=[])

    async def aupdate(
        self,
        agent_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        role: Optional[str] = None,
        goal: Optional[str] = None,
        instructions: Optional[str] = None,
        response_model: Optional[Type[BaseModel]] = None,
        store_messages: Optional[bool] = None,
        file_output: Optional[bool] = None,
        image_output_config: Optional[Dict[str, Any]] = None,
        memory: Optional[Union[int, "MemoryConfig"]] = None,
        contexts: Optional[List["Context"]] = None,
        reflection: Optional[bool] = None,
        bias_check: Optional[bool] = None,
        llm_judge: Optional[bool] = None,
        groundedness_facts: Optional[List[str]] = None,
        rai_policy: Optional["RAIPolicy"] = _NOT_PROVIDED,
        image_model: Optional["ImageModelConfig"] = None,
        features: Optional[List[Any]] = None,
        examples: Optional[str] = None,
        tools: Optional[List[str]] = None,
        managed_agents: Optional[List[Any]] = None,
        tool_usage_description: Optional[str] = None,
        tool_configs: Optional[List[Any]] = None,
        llm_credential_id: Optional[str] = None,
        local_tools: Optional[List[Any]] = None,
    ) -> Agent:
        """Async update an existing agent"""
        self._ensure_async()

        current_agent = await self.aget(agent_id)

        update_data = {
            "name": name if name is not None else current_agent.name,
            "provider_id": current_agent.provider_id,
            "model": current_agent.model,
            "temperature": temperature if temperature is not None else current_agent.temperature,
            "top_p": top_p if top_p is not None else current_agent.top_p,
        }

        self._merge_field(update_data, "description", description, current_agent.description)
        self._merge_field(update_data, "agent_role", role, current_agent.agent_role)
        self._merge_field(update_data, "agent_goal", goal, current_agent.agent_goal)
        self._merge_field(update_data, "agent_instructions", instructions, current_agent.agent_instructions)
        self._merge_field(update_data, "examples", examples, current_agent.examples)
        self._merge_field(update_data, "tools", tools, current_agent.tools)
        self._merge_field(update_data, "tool_usage_description", tool_usage_description, current_agent.tool_usage_description)
        self._merge_field(update_data, "tool_configs", tool_configs, current_agent.tool_configs)
        self._merge_field(update_data, "managed_agents", managed_agents, current_agent.managed_agents)
        self._merge_field(update_data, "features", features, current_agent.features)
        self._merge_field(update_data, "llm_credential_id", llm_credential_id, current_agent.llm_credential_id)
        self._merge_field(update_data, "store_messages", store_messages, current_agent.store_messages)
        self._merge_field(update_data, "file_output", file_output, current_agent.file_output)
        self._merge_field(update_data, "image_output_config", image_output_config, current_agent.image_output_config)

        if not 0.0 <= update_data["temperature"] <= 2.0:
            raise ValidationError("Temperature must be between 0.0 and 2.0")
        if not 0.0 <= update_data["top_p"] <= 1.0:
            raise ValidationError("top_p must be between 0.0 and 1.0")

        self._handle_advanced_updates(
            update_data=update_data,
            current_agent=current_agent,
            memory=memory,
            contexts=contexts,
            reflection=reflection,
            bias_check=bias_check,
            llm_judge=llm_judge,
            groundedness_facts=groundedness_facts,
            rai_policy=rai_policy,
            image_model=image_model,
        )

        await self._async_http.put(f"/v3/agents/{agent_id}", json=update_data)

        updated_agent = await self.aget(agent_id)

        if response_model is not None:
            updated_agent._response_model = response_model

        if local_tools:
            self._attach_local_tools(updated_agent, local_tools)

        return updated_agent

    async def adelete(self, agent_id: str) -> bool:
        """Async delete an agent"""
        self._ensure_async()
        return await self._async_http.delete(f"/v3/agents/{agent_id}")

    async def aclone(self, agent_id: str, new_name: Optional[str] = None) -> Agent:
        """Async clone an existing agent"""
        self._ensure_async()

        original = await self.aget(agent_id)

        provider_string = f"{original.provider_id}/{original.model}"

        clone_kwargs = {
            "name": new_name or f"{original.name} (Clone)",
            "provider": provider_string,
            "temperature": original.temperature,
            "top_p": original.top_p,
        }

        if original.description:
            clone_kwargs["description"] = original.description
        if original.agent_role:
            clone_kwargs["role"] = original.agent_role
        if original.agent_goal:
            clone_kwargs["goal"] = original.agent_goal
        if original.agent_instructions:
            clone_kwargs["instructions"] = original.agent_instructions
        if original.tools:
            clone_kwargs["tools"] = original.tools
        if original.features:
            clone_kwargs["features"] = original.features
        if original.tool_configs:
            clone_kwargs["tool_configs"] = original.tool_configs
        if original.file_output:
            clone_kwargs["file_output"] = original.file_output
        if original.image_output_config:
            clone_kwargs["image_output_config"] = original.image_output_config
        if original._response_model:
            clone_kwargs["response_model"] = original._response_model
        if original.store_messages is not None:
            clone_kwargs["store_messages"] = original.store_messages
        if original.examples:
            clone_kwargs["examples"] = original.examples

        return await self.acreate(**clone_kwargs)

    async def abulk_delete(self, agent_ids: List[str]) -> bool:
        """Async delete multiple agents at once"""
        self._ensure_async()

        if not agent_ids:
            raise ValidationError("agent_ids cannot be empty")

        await self._async_http.post("/v3/agents/bulk-delete", json={"agent_ids": agent_ids})
        return True

    async def aremove_rai_policy(self, agent_id: str) -> Agent:
        """Async remove RAI policy from an agent"""
        self._ensure_async()
        agent = await self.aget(agent_id)
        current_features = agent.features or []
        new_features = [f for f in current_features if f.get("type") != "RAI"]
        return await self.aupdate(agent_id, features=new_features)
