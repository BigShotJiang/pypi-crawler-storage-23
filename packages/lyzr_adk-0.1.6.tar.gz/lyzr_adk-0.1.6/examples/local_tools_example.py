from lyzr import AgentResponse, AgentStream, Studio
from datetime import datetime


def get_current_time():
    return {"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def main():
    studio = Studio(api_key="sk-default-Y8C0fC0PU0FGrIPBQIZbsHjjmgfXFUMn", env="local", log="debug")

    # Create agent
    agent = studio.create_agent(
        name="Assistant",
        provider="openai/gpt-4o-mini",
        role="You are a helpful assistant",
        goal="Help users with their questions",
        instructions="Be concise and friendly",
        memory=30,
    )

    agent.add_tool(get_current_time)

    # Run agent (use unique session_id to avoid stale history)
    import uuid

    response = agent.run("What is the current time?", session_id=f"session_{uuid.uuid4().hex[:16]}")
    if isinstance(response, AgentResponse):
        print("Response:", response)
        print(response.response)

    # Streaming
    # for chunk in agent.run("write a 1000 word essay on the topic of the universe", stream=True):
    #     if isinstance(chunk, AgentStream):
    #         print(chunk.content, end="", flush=True)
    # print()

    # Update
    # agent = agent.update(temperature=0.3)

    # Cleanup
    agent.delete()


if __name__ == "__main__":
    main()
