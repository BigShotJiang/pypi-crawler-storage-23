"""
Set your API key:
  export LYZR_API_KEY="your-api-key"
Or pass directly:
  Studio(api_key="your-api-key")

Get your API key: https://studio.lyzr.ai

Skills - Local File-Based Instructions

Demonstrates: Loading skills from SKILL.md files, progressive disclosure,
auto-injected use_skill tool
"""

from pathlib import Path
from dotenv import load_dotenv

load_dotenv()  # Load from .env file if present

from lyzr import Studio, load_skills, Skill, SkillMetadata


# =============================================================================
# PART 1: Understanding Skills
# =============================================================================
#
# Skills are local markdown files with YAML frontmatter that provide
# structured instructions to agents. They enable:
#
# 1. Progressive Disclosure - Agent sees metadata upfront, loads full
#    content on-demand via use_skill tool
# 2. Reusable Instructions - Same skills work across multiple agents
# 3. Version Control - Skills are files, can be versioned with git
#
# Skill file format (SKILL.md):
#
#   ---
#   name: research
#   description: Systematic research methodology
#   version: 1.0.0
#   tags: [research, analysis]
#   ---
#
#   # Research Skill
#
#   When conducting research:
#   1. Understand the query
#   2. Gather information
#   ...


# =============================================================================
# PART 2: Create Sample Skills (normally you'd have these in files)
# =============================================================================


def setup_sample_skills():
    """Create sample skill files for demonstration"""
    skills_dir = Path("./demo_skills")
    skills_dir.mkdir(exist_ok=True)

    # Skill 1: Research methodology
    research_dir = skills_dir / "research"
    research_dir.mkdir(exist_ok=True)
    (research_dir / "SKILL.md").write_text(
        """---
name: research
description: Systematic research and analysis methodology
version: 1.0.0
tags: [research, analysis, methodology]
---

# Research Skill

## Overview
Use this skill when you need to conduct thorough research on any topic.

## Methodology

### 1. Query Understanding
- Identify the core question or topic
- Note any constraints (time period, scope, depth)
- Clarify ambiguous terms

### 2. Information Gathering
- Start with broad overview sources
- Identify authoritative sources
- Cross-reference multiple sources
- Note conflicting information

### 3. Analysis
- Synthesize findings into coherent narrative
- Identify patterns and trends
- Note gaps in available information
- Consider multiple perspectives

### 4. Presentation
- Lead with key findings
- Support with evidence
- Acknowledge limitations
- Suggest further research if needed

## Best Practices
- Always cite sources when possible
- Distinguish facts from opinions
- Update findings if new information emerges
"""
    )

    # Skill 2: Code review
    review_dir = skills_dir / "code-review"
    review_dir.mkdir(exist_ok=True)
    (review_dir / "SKILL.md").write_text(
        """---
name: code-review
description: Thorough code review checklist and methodology
version: 2.0.0
tags: [code, review, quality]
---

# Code Review Skill

## Overview
Use this skill when reviewing code for quality, security, and maintainability.

## Review Checklist

### 1. Correctness
- [ ] Does the code do what it's supposed to do?
- [ ] Are edge cases handled?
- [ ] Are error conditions handled appropriately?

### 2. Security
- [ ] Input validation present?
- [ ] No SQL injection vulnerabilities?
- [ ] No XSS vulnerabilities?
- [ ] Sensitive data properly handled?

### 3. Performance
- [ ] No obvious performance issues?
- [ ] Appropriate data structures used?
- [ ] No unnecessary loops or iterations?

### 4. Maintainability
- [ ] Code is readable and well-organized?
- [ ] Functions are single-purpose?
- [ ] Variable names are descriptive?
- [ ] Comments explain "why" not "what"?

### 5. Testing
- [ ] Tests cover main functionality?
- [ ] Edge cases tested?
- [ ] Tests are readable and maintainable?

## Feedback Guidelines
- Be constructive and specific
- Explain the "why" behind suggestions
- Offer alternatives when critiquing
- Acknowledge good patterns
"""
    )

    # Skill 3: Writing assistant
    writing_dir = skills_dir / "writing"
    writing_dir.mkdir(exist_ok=True)
    (writing_dir / "SKILL.md").write_text(
        """---
name: writing
description: Professional writing and editing guidelines
version: 1.0.0
tags: [writing, editing, communication]
---

# Writing Skill

## Overview
Use this skill when creating or editing written content.

## Writing Principles

### Clarity
- Use simple, direct language
- One idea per sentence
- Short paragraphs (3-5 sentences)
- Active voice preferred

### Structure
- Lead with the most important information
- Use headings and lists for scannability
- Logical flow between sections
- Strong opening and closing

### Tone
- Match tone to audience and purpose
- Professional but approachable
- Confident without being arrogant
- Empathetic when appropriate

## Editing Checklist
1. Remove unnecessary words
2. Replace jargon with plain language
3. Check for consistent terminology
4. Verify facts and figures
5. Proofread for grammar and spelling
"""
    )

    return skills_dir


# =============================================================================
# PART 3: Load and Use Skills
# =============================================================================

# Setup sample skills
skills_dir = setup_sample_skills()
print(f"Created sample skills in: {skills_dir.absolute()}")
print()

# Load all skills from the directory
skills = load_skills(search_paths=[skills_dir])
print(f"Loaded {len(skills)} skills:")
for skill in skills:
    print(f"  - {skill.name} (v{skill.version}): {skill.description}")
    if skill.tags:
        print(f"    Tags: {', '.join(skill.tags)}")
print()

# You can also load specific skills by name
research_only = load_skills(search_paths=[skills_dir], names=["research"])
print(f"Loaded specific skill: {research_only[0].name}")
print()


# =============================================================================
# PART 4: Use Skills with an Agent
# =============================================================================

studio = Studio(env="dev")  # Uses LYZR_API_KEY env var

# Create agent with skills
agent = studio.create_agent(
    name="Skilled Assistant",
    provider="openai/gpt-4o-mini",
    role="Versatile assistant with specialized skills",
    goal="Help users by leveraging specialized skills when appropriate",
    instructions="""You are a helpful assistant with access to specialized skills.

When a task matches one of your available skills, use the use_skill tool to
load the full instructions for that skill, then follow those instructions.

Available skills are listed in your context. Only load a skill when you
actually need its detailed instructions.""",
    skills=skills,  # This auto-registers the use_skill tool
)

print("Agent created with skills:")
print(f"  Has skills: {agent.has_skills()}")
print(f"  Skills: {agent.list_skills()}")

# Example 1: Task that should trigger research skill
response = agent.run(
    "I need to understand the current state of quantum computing. "
    "Please research this topic and give me a structured overview."
)
print(f"Response:\n{response.response}\n")

# Example 2: Task that should trigger code review skill
response = agent.run(
    """Please review this Python function:

def get_user(id):
    query = "SELECT * FROM users WHERE id = " + id
    return db.execute(query)

What issues do you see?"""
)
print(f"Response:\n{response.response}\n")

# Example 3: Task that should trigger writing skill
print("=" * 70)
print("Example 3: Writing Task")
print("=" * 70)
response = agent.run(
    "Help me improve this paragraph: 'The product that we are building "
    "is going to be very useful for the users who will use it because "
    "it has many features that are helpful and good.'"
)
print(f"Response:\n{response.response}\n")

# Cleanup
agent.delete()

# Optional: Remove demo skills directory
import shutil

shutil.rmtree(skills_dir)
print(f"Cleaned up demo skills directory")
