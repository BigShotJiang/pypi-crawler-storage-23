"""
Context variables for request-scoped attributes (client_type, screen_name).
Used by middleware and log processors to correlate attributes with spans.
"""
import contextvars

client_type_context: contextvars.ContextVar[str] = contextvars.ContextVar(
    "client_type", default=""
)
screen_name_context: contextvars.ContextVar[str] = contextvars.ContextVar(
    "screen_name", default=""
)
