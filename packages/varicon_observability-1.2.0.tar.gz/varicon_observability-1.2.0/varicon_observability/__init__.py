from .setup import setup_observability
from .config import ObservabilityConfig
from .integrations import setup_django, setup_fastapi, setup_celery
from .metrics import (
    get_meter,
    get_request_counter,
    get_request_duration_histogram,
    get_active_connections_counter,
)
from .system_metrics import (
    SystemMetricsCollector,
    start_system_metrics,
    get_system_metrics_collector,
)
from .db_metrics import (
    DatabaseMetricsCollector,
    start_db_metrics,
    get_db_metrics_collector,
)
from .trace_filter import TraceContextFilter
from .asgi import instrument_asgi

__version__ = "1.2.0"
__all__ = [
    "setup_observability",
    "ObservabilityConfig",
    "setup_django",
    "setup_fastapi",
    "setup_celery",
    "get_meter",
    "get_request_counter",
    "get_request_duration_histogram",
    "get_active_connections_counter",
    "SystemMetricsCollector",
    "start_system_metrics",
    "get_system_metrics_collector",
    "DatabaseMetricsCollector",
    "start_db_metrics",
    "get_db_metrics_collector",
    "TraceContextFilter",
    "instrument_asgi",
]
