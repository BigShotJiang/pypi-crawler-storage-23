"""Default package."""

from typing import Final

__version__: Final[str] = "5.1.4"
