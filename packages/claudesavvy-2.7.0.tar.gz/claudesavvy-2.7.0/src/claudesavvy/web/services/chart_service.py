"""Chart service for Claude Monitor."""
