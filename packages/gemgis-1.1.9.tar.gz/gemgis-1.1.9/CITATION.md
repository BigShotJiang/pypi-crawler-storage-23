If you use GemGIS for any published work, please cite it using the reference
below:

@article{Jüstel2022,
    doi = {10.21105/joss.03709},
    url = {https://doi.org/10.21105/joss.03709},
    year = {2022}, publisher = {The Open Journal},
    volume = {7},
    number = {73},
    pages = {3709},
    author = {Alexander Jüstel and Arthur Endlein Correira and Marius Pischke and Miguel de la Varga and Florian Wellmann},
    title = {GemGIS - Spatial Data Processing for Geomodeling},
    journal = {Journal of Open Source Software}
    }