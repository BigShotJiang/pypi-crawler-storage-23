# Design: x402 Paywall for InferShrink

## Architecture

```
Agent (with USDC wallet)
  |
  |-- POST /optimize { prompt, provider }
  |
  v
InferShrink x402 Server (Express + @x402/express)
  |
  |-- 402 Payment Required (if no payment)
  |-- Verify+Settle via Facilitator (if payment present)
  |-- classify(prompt) → complexity
  |-- route(prompt, provider, complexity) → model
  |
  v
Response: { complexity, recommended_model, estimated_savings_pct }
```

## Project Structure

```
infershrink-x402/
├── src/
│   ├── server.ts          # Express server with x402 middleware
│   ├── config.ts          # Network, pricing, facilitator config
│   ├── handlers.ts        # /classify, /optimize, /status handlers
│   └── infershrink.ts     # Thin wrapper around infershrink Python SDK
├── client/
│   ├── agent-demo.ts      # Full agent simulation script
│   └── pay.ts             # Minimal payment client
├── test/
│   ├── server.test.ts     # Unit tests (mocked facilitator)
│   ├── handlers.test.ts   # Handler logic tests
│   └── e2e.test.ts        # E2e test (requires funded wallet)
├── package.json
├── tsconfig.json
└── README.md
```

## Server Design

### Express App with @x402/express Middleware

```typescript
import { paymentMiddleware } from "@x402/express";
import { x402ResourceServer } from "@x402/core/server";
import { registerExactEvmScheme } from "@x402/evm/exact/server";

const resourceServer = new x402ResourceServer();
registerExactEvmScheme(resourceServer);

const routes = {
  "POST /classify": {
    accepts: [{ scheme: "exact", network, payTo, price: "$0.0001" }],
    description: "Classify prompt complexity",
  },
  "POST /optimize": {
    accepts: [{ scheme: "exact", network, payTo, price: "$0.001" }],
    description: "Optimize LLM routing for prompt",
  },
};
```

### InferShrink Integration

The server calls InferShrink's Python SDK via subprocess:

```typescript
// Option A: subprocess
const result = execSync(`python3 -c "
from infershrink import classify, route
import json
c = classify('${escaped_prompt}')
r = route('${escaped_prompt}', provider='${provider}', complexity=c.complexity)
print(json.dumps({'complexity': c.complexity, 'model': r.model, 'savings': r.savings_pct}))
"`);

// Option B: HTTP bridge (if Python server running)
// Option C: Pure TS reimplementation of classify logic (future)
```

Option A (subprocess) for v1 — simple, correct, no additional infrastructure.

### Configuration

```typescript
interface Config {
  network: string;           // "eip155:84532" or "eip155:8453"
  sellerWallet: string;
  facilitatorUrl?: string;   // Auto-detected from network
  cdpKeyId?: string;
  cdpPrivateKey?: string;
  port: number;              // Default 8402
}
```

Environment variables:
- `SELLER_WALLET` (required)
- `X402_NETWORK` (default: "eip155:84532")
- `CDP_KEY_ID` + `CDP_PRIVATE_KEY` (for mainnet)
- `PORT` (default: 8402)

## Client Design

### Agent Demo Script

```typescript
import { x402Client, wrapFetchWithPayment } from "@x402/fetch";
import { registerExactEvmScheme } from "@x402/evm/exact/client";

// Agent discovers service
const status = await fetch(SERVER_URL + "/status").then(r => r.json());
console.log("Available:", status.supported_providers);

// Agent pays and gets optimization
const fetchPaid = wrapFetchWithPayment(fetch, client);
const result = await fetchPaid(SERVER_URL + "/optimize", {
  method: "POST",
  body: JSON.stringify({ prompt: "Explain quantum computing", provider: "google" }),
});
// Returns: { complexity: "simple", recommended_model: "gemini-2.0-flash", savings: 85 }
```

## Testing Strategy

### Unit Tests (mocked facilitator)
- Server returns 402 for unauthenticated requests
- Server returns correct PAYMENT-REQUIRED header format
- /status returns pricing and version
- Handlers return correct optimization results

### Integration Tests (mocked x402 flow)  
- Full request → 402 → payment → response cycle
- Error handling (invalid prompt, unknown provider)

### E2e Test (live, requires funded wallet)
- `EVM_PRIVATE_KEY=0x... npx tsx client/agent-demo.ts`
- Connects to live server, pays real USDC, gets real result
