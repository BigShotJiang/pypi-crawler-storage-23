"""Tests for streaming support."""

from infershrink import optimize
from infershrink.router import _detect_provider


class MockStreamChunk:
    """Mock OpenAI streaming chunk."""

    def __init__(self, content, model="gpt-4o-mini"):
        self.choices = [
            type(
                "Choice",
                (),
                {
                    "delta": type("Delta", (), {"content": content})(),
                    "finish_reason": None,
                },
            )()
        ]
        self.model = model


class MockStream:
    """Mock streaming response (iterable)."""

    def __init__(self, chunks, model="gpt-4o-mini"):
        self._chunks = [MockStreamChunk(c, model) for c in chunks]
        self._model = model

    def __iter__(self):
        return iter(self._chunks)


class MockStreamCompletions:
    def __init__(self):
        self._last_kwargs = {}

    def create(self, **kwargs):
        self._last_kwargs = kwargs
        model = kwargs.get("model", "gpt-4o")
        if kwargs.get("stream"):
            return MockStream(["Hello", " world", "!"], model=model)
        return {"choices": [{"message": {"content": "Hello world!"}}]}


class MockStreamChat:
    def __init__(self):
        self.completions = MockStreamCompletions()


class MockStreamClient:
    def __init__(self):
        self.chat = MockStreamChat()


class TestOpenAIStreaming:
    def test_stream_true_passes_through(self):
        """stream=True should still classify/route but return the stream."""
        mock = MockStreamClient()
        client = optimize(mock)

        result = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        )

        # Should be iterable (stream)
        chunks = list(result)
        assert len(chunks) == 3
        assert chunks[0].choices[0].delta.content == "Hello"

    def test_stream_model_is_routed(self):
        """Even with streaming, the model should be routed."""
        mock = MockStreamClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        )

        # Should have been routed to gpt-4o-mini
        actual_model = mock.chat.completions._last_kwargs["model"]
        assert actual_model == "gpt-4o-mini"

    def test_stream_tracking_works(self):
        """Tracking should work with streaming (based on input tokens)."""
        mock = MockStreamClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1
        assert stats.requests_downgraded == 1

    def test_stream_false_returns_normal(self):
        """stream=False should return a normal response."""
        mock = MockStreamClient()
        client = optimize(mock)

        result = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            stream=False,
        )

        assert isinstance(result, dict)

    def test_stream_complex_not_downgraded(self):
        """Complex tasks should not be downgraded even with streaming."""
        mock = MockStreamClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Design a distributed consensus algorithm"}],
            stream=True,
        )

        actual_model = mock.chat.completions._last_kwargs["model"]
        assert _detect_provider(actual_model) == "openai"
