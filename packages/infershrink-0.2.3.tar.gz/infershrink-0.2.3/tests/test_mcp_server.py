"""Tests for InferShrink MCP Server.

Tests the tool handlers directly (no transport needed).
Requires: pip install infershrink[mcp]
"""

from __future__ import annotations

import pytest

mcp = pytest.importorskip("mcp", reason="MCP SDK not installed (pip install infershrink[mcp])")


class TestMCPServerBuild:
    """Test that the server builds and exposes the right tools."""

    def test_server_builds(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        assert server is not None
        assert server.name == "InferShrink"

    def test_server_has_three_tools(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        # FastMCP stores tools internally — access via _tool_manager or list
        tools = server._tool_manager._tools
        assert len(tools) == 3
        tool_names = set(tools.keys())
        assert tool_names == {
            "infershrink_classify",
            "infershrink_optimize",
            "infershrink_status",
        }


class TestClassifyTool:
    """Test infershrink_classify tool handler."""

    def _get_classify(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        return server._tool_manager._tools["infershrink_classify"].fn

    def test_simple_prompt(self):
        fn = self._get_classify()
        result = fn(prompt="Hello, how are you?", provider="openai")
        assert result["complexity"] == "simple"
        assert result["provider"] == "openai"
        assert "tokens" in result
        assert "recommended_model" in result

    def test_complex_prompt(self):
        fn = self._get_classify()
        result = fn(
            prompt="Write a comprehensive step-by-step guide to implementing "
            "a distributed consensus algorithm with formal proofs",
            provider="openai",
        )
        assert result["complexity"] == "complex"

    def test_provider_anthropic(self):
        fn = self._get_classify()
        result = fn(prompt="Hi", provider="anthropic")
        assert result["provider"] == "anthropic"
        # Should recommend a claude model or indicate no match
        rec = result["recommended_model"]
        assert "claude" in rec.lower() or "no anthropic" in rec.lower()

    def test_provider_google(self):
        fn = self._get_classify()
        result = fn(prompt="Hi", provider="google")
        assert result["provider"] == "google"
        rec = result["recommended_model"]
        assert "gemini" in rec.lower() or "no google" in rec.lower()

    def test_returns_reason(self):
        fn = self._get_classify()
        result = fn(prompt="Hello", provider="openai")
        assert "reason" in result
        assert isinstance(result["reason"], str)

    def test_returns_recommended_tier(self):
        fn = self._get_classify()
        result = fn(prompt="Hello", provider="openai")
        assert result["recommended_tier"] in ("tier1", "tier2", "tier3")


class TestOptimizeTool:
    """Test infershrink_optimize tool handler."""

    def _get_optimize(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        return server._tool_manager._tools["infershrink_optimize"].fn

    def test_simple_messages_optimized(self):
        fn = self._get_optimize()
        result = fn(
            messages=[{"role": "user", "content": "Hello"}],
            provider="openai",
            current_model="gpt-4o",
        )
        assert result["complexity"] == "simple"
        assert result["original_model"] == "gpt-4o"
        # May or may not downgrade depending on env (auto_discover reshuffles tiers)
        assert isinstance(result["downgraded"], bool)
        assert (
            "gpt" in result["recommended_model"].lower()
            or "o" in result["recommended_model"].lower()
        )

    def test_complex_messages_not_downgraded(self):
        fn = self._get_optimize()
        result = fn(
            messages=[
                {"role": "user", "content": "Write a comprehensive step-by-step algorithm analysis"}
            ],
            provider="openai",
            current_model="gpt-4o-mini",
        )
        # Complex on mini → should NOT downgrade further
        assert result["complexity"] == "complex"

    def test_default_model_when_empty(self):
        fn = self._get_optimize()
        result = fn(
            messages=[{"role": "user", "content": "Hello"}],
            provider="anthropic",
            current_model="",
        )
        assert result["original_model"] == "claude-sonnet-4-20250514"
        assert result["provider"] == "anthropic"

    def test_returns_savings_estimate(self):
        fn = self._get_optimize()
        result = fn(
            messages=[{"role": "user", "content": "Hello"}],
            provider="openai",
            current_model="gpt-4o",
        )
        assert "estimated_savings_pct" in result
        assert isinstance(result["estimated_savings_pct"], (int, float))

    def test_same_provider_constraint(self):
        fn = self._get_optimize()
        result = fn(
            messages=[{"role": "user", "content": "Hello"}],
            provider="openai",
            current_model="gpt-4o",
        )
        # Recommended model should still be OpenAI
        rec = result["recommended_model"]
        assert rec.startswith("gpt-") or rec.startswith("o")


class TestStatusTool:
    """Test infershrink_status tool handler."""

    def _get_status(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        return server._tool_manager._tools["infershrink_status"].fn

    def test_returns_version(self):
        fn = self._get_status()
        result = fn()
        assert "version" in result
        assert result["version"] == "0.2.2"

    def test_returns_features(self):
        fn = self._get_status()
        result = fn()
        assert "features" in result
        assert "routing" in result["features"]

    def test_returns_providers(self):
        fn = self._get_status()
        result = fn()
        assert set(result["providers"]) == {"openai", "anthropic", "google"}

    def test_returns_request_count(self):
        fn = self._get_status()
        result = fn()
        assert "total_requests" in result
        assert isinstance(result["total_requests"], int)


class TestToolNaming:
    """Verify tool names follow MCP best practices."""

    def test_names_follow_service_action_pattern(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        tools = server._tool_manager._tools
        for name in tools:
            assert name.startswith("infershrink_"), (
                f"Tool {name} must be prefixed with infershrink_"
            )

    def test_names_are_valid_mcp_characters(self):
        import re

        from infershrink.mcp_server import _build_server

        server = _build_server()
        tools = server._tool_manager._tools
        valid_pattern = re.compile(r"^[A-Za-z0-9_\-.]+$")
        for name in tools:
            assert valid_pattern.match(name), f"Tool name '{name}' has invalid MCP characters"


class TestCLIEntryPoint:
    """Test CLI argument parsing."""

    def test_main_import(self):
        from infershrink.mcp_server import main

        assert callable(main)
