"""Integration tests for retrieval features (FAISS + TokenShrink).

Requires: pip install infershrink[retrieval]
Skipped automatically if faiss is not installed.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

faiss = pytest.importorskip("faiss", reason="Requires: pip install infershrink[retrieval]")
pytest.importorskip("sentence_transformers", reason="Requires: pip install infershrink[retrieval]")

from infershrink.retrieval import (  # noqa: E402
    ChunkScore,
    ShrinkResult,
    TokenShrink,
    _adaptive_ratio,
    _compute_importance,
    _information_density,
    is_retrieval_available,
)


@pytest.fixture
def sample_docs(tmp_path: Path) -> Path:
    """Create a temp directory with sample text files for indexing."""
    (tmp_path / "api.md").write_text(
        "# API Reference\n\n"
        "The rate limit is 100 requests per minute per API key. "
        "Exceeding this limit returns HTTP 429. "
        "You can request a rate limit increase by contacting support. "
        "Each API key is scoped to a single project. "
        "Authentication uses Bearer tokens in the Authorization header. "
        "All responses are JSON with a top-level 'data' key. " * 10
    )
    (tmp_path / "guide.md").write_text(
        "# Getting Started\n\n"
        "Install the SDK with pip install example-sdk. "
        "Import the client and authenticate with your API key. "
        "The client supports both sync and async modes. "
        "Use the classify method to categorize inputs. "
        "Results include a confidence score between 0 and 1. " * 10
    )
    (tmp_path / "faq.md").write_text(
        "# FAQ\n\n"
        "Q: What models are supported?\n"
        "A: GPT-4o, GPT-4o Mini, Gemini Flash, Gemini Pro, Claude Sonnet. "
        "Q: How much does it cost?\n"
        "A: Free tier includes 1000 requests per day. Pro is $19/month. "
        "Q: Is my data stored?\n"
        "A: No data is stored. All processing happens in memory. " * 10
    )
    return tmp_path


@pytest.fixture
def ts(sample_docs: Path, tmp_path: Path) -> TokenShrink:
    """Create a TokenShrink instance with indexed sample docs."""
    index_dir = tmp_path / ".index"
    ts = TokenShrink(
        index_dir=str(index_dir),
        compression=False,  # Don't require LLMLingua for these tests
    )
    ts.index(str(sample_docs))
    return ts


class TestIsRetrievalAvailable:
    def test_returns_true_when_installed(self):
        assert is_retrieval_available() is True


class TestTokenShrinkIndex:
    def test_indexes_directory(self, sample_docs: Path, tmp_path: Path):
        ts = TokenShrink(index_dir=str(tmp_path / ".idx"), compression=False)
        stats = ts.index(str(sample_docs))
        assert stats["files_indexed"] >= 3
        assert stats["chunks_added"] > 0
        assert stats["total_chunks"] > 0

    def test_skips_unchanged_files(self, sample_docs: Path):
        # Use a separate temp dir for index to avoid index files being scanned
        with tempfile.TemporaryDirectory() as idx_dir:
            ts = TokenShrink(index_dir=idx_dir, compression=False)
            stats1 = ts.index(str(sample_docs))
            assert stats1["files_indexed"] >= 3
            # Same instance, same files — should skip
            stats2 = ts.index(str(sample_docs))
            assert stats2["files_indexed"] == 0
            assert stats2["total_chunks"] == stats1["total_chunks"]

    def test_force_reindex(self, ts: TokenShrink, sample_docs: Path):
        stats = ts.index(str(sample_docs), force=True)
        assert stats["files_indexed"] >= 3


class TestTokenShrinkQuery:
    def test_returns_relevant_chunks(self, ts: TokenShrink):
        result = ts.query("What is the rate limit?")
        assert isinstance(result, ShrinkResult)
        assert len(result.context) > 0
        assert "rate limit" in result.context.lower() or "100 requests" in result.context.lower()

    def test_returns_sources(self, ts: TokenShrink):
        result = ts.query("What is the rate limit?")
        assert len(result.sources) > 0
        assert any("api.md" in s for s in result.sources)

    def test_empty_index_returns_empty(self, tmp_path: Path):
        ts = TokenShrink(index_dir=str(tmp_path / ".empty"), compression=False)
        result = ts.query("anything")
        assert result.context == ""
        assert result.original_tokens == 0
        assert result.ratio == 1.0

    def test_min_score_filters(self, ts: TokenShrink):
        # Very high min_score should return fewer/no results
        result_low = ts.query("rate limit", min_score=0.1)
        result_high = ts.query("rate limit", min_score=0.99)
        assert len(result_low.context) >= len(result_high.context)


class TestChunkScores:
    def test_chunk_scores_populated(self, ts: TokenShrink):
        result = ts.query("What models are supported?")
        assert len(result.chunk_scores) > 0
        for cs in result.chunk_scores:
            assert isinstance(cs, ChunkScore)
            assert cs.similarity > 0
            assert 0 <= cs.density <= 1
            assert cs.importance > 0
            assert 0 < cs.compression_ratio <= 1

    def test_importance_scoring(self, ts: TokenShrink):
        result = ts.query("rate limit API")
        scores = [cs for cs in result.chunk_scores if not cs.deduplicated]
        if len(scores) >= 2:
            # Higher similarity should generally mean higher importance
            sorted_by_sim = sorted(scores, key=lambda s: s.similarity, reverse=True)
            assert sorted_by_sim[0].importance >= sorted_by_sim[-1].importance


class TestDeduplication:
    def test_dedup_removes_redundant(self, tmp_path: Path):
        # Create docs with duplicate content
        docs = tmp_path / "docs"
        docs.mkdir()
        content = "The quick brown fox jumps over the lazy dog. " * 50
        (docs / "file1.md").write_text(content)
        (docs / "file2.md").write_text(content)  # Exact duplicate
        (docs / "file3.md").write_text(
            "Something completely different about quantum physics. " * 50
        )

        ts = TokenShrink(index_dir=str(tmp_path / ".idx"), compression=False, dedup=True)
        ts.index(str(docs))

        result = ts.query("quick brown fox", k=10)
        # Should have removed some duplicates
        assert result.dedup_removed >= 0  # At least detects the scenario

    def test_dedup_disabled(self, tmp_path: Path):
        docs = tmp_path / "docs"
        docs.mkdir()
        content = "Repeated content about machine learning. " * 50
        (docs / "a.md").write_text(content)
        (docs / "b.md").write_text(content)

        ts = TokenShrink(index_dir=str(tmp_path / ".idx"), compression=False, dedup=False)
        ts.index(str(docs))

        result = ts.query("machine learning", k=10, dedup=False)
        assert result.dedup_removed == 0


class TestShrinkResult:
    def test_savings_property(self):
        r = ShrinkResult(
            context="compressed",
            sources=["a.md"],
            original_tokens=1000,
            compressed_tokens=300,
            ratio=0.3,
        )
        assert "70%" in r.savings
        assert r.savings_pct == pytest.approx(70.0)

    def test_savings_with_dedup(self):
        r = ShrinkResult(
            context="compressed",
            sources=["a.md"],
            original_tokens=1000,
            compressed_tokens=300,
            ratio=0.3,
            dedup_removed=3,
        )
        assert "3 redundant" in r.savings


class TestUtilityFunctions:
    def test_information_density_empty(self):
        assert _information_density("") == 0.0

    def test_information_density_repetitive(self):
        # Very repetitive text should have low density
        low = _information_density("aaaaaaaaaaaaaaaaaaa")
        high = _information_density("The quick brown fox jumps over the lazy dog 123!")
        assert low < high

    def test_compute_importance(self):
        score = _compute_importance(0.8, 0.6)
        assert 0 < score < 1

    def test_adaptive_ratio_high_importance(self):
        high = _adaptive_ratio(0.9)
        low = _adaptive_ratio(0.1)
        assert high > low  # High importance → keep more


class TestTokenShrinkStats:
    def test_stats(self, ts: TokenShrink):
        stats = ts.stats()
        assert stats["total_chunks"] > 0
        assert stats["total_files"] >= 3
        assert stats["compression_available"] in (True, False)

    def test_clear(self, ts: TokenShrink):
        ts.clear()
        stats = ts.stats()
        assert stats["total_chunks"] == 0
        assert stats["total_files"] == 0


class TestTokenShrinkSearch:
    def test_search_returns_raw_chunks(self, ts: TokenShrink):
        results = ts.search("rate limit")
        assert len(results) > 0
        assert "text" in results[0]
        assert "score" in results[0]
        assert "source" in results[0]
