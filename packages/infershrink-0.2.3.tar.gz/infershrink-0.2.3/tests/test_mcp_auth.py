"""Tests for MCP auth middleware."""

from __future__ import annotations


class TestBearerAuth:
    def test_valid_api_key(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_API_KEY", "test-key-123")
        from infershrink.mcp_auth import authenticate_bearer

        result = authenticate_bearer("test-key-123")
        assert result.authenticated is True
        assert result.tier == "pro"
        assert result.method == "bearer"

    def test_invalid_api_key(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_API_KEY", "test-key-123")
        from infershrink.mcp_auth import authenticate_bearer

        result = authenticate_bearer("wrong-key")
        assert result.authenticated is False

    def test_admin_key(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_ADMIN_KEY", "admin-secret")
        from infershrink.mcp_auth import authenticate_bearer

        result = authenticate_bearer("admin-secret")
        assert result.authenticated is True
        assert result.tier == "admin"

    def test_empty_token(self):
        from infershrink.mcp_auth import authenticate_bearer

        result = authenticate_bearer("")
        assert result.authenticated is False

    def test_no_env_key_set(self, monkeypatch):
        monkeypatch.delenv("INFERSHRINK_API_KEY", raising=False)
        monkeypatch.delenv("INFERSHRINK_ADMIN_KEY", raising=False)
        from infershrink.mcp_auth import authenticate_bearer

        result = authenticate_bearer("any-token")
        assert result.authenticated is False


class TestX402Auth:
    def test_valid_proof_with_wallet(self, monkeypatch):
        monkeypatch.setenv("SELLER_WALLET", "0x1234567890abcdef")
        from infershrink.mcp_auth import authenticate_x402

        result = authenticate_x402("proof-data")
        assert result.authenticated is True
        assert result.tier == "pro"
        assert result.method == "x402"

    def test_no_wallet_configured(self, monkeypatch):
        monkeypatch.delenv("SELLER_WALLET", raising=False)
        from infershrink.mcp_auth import authenticate_x402

        result = authenticate_x402("proof-data")
        assert result.authenticated is False
        assert "SELLER_WALLET" in result.error

    def test_empty_proof(self):
        from infershrink.mcp_auth import authenticate_x402

        result = authenticate_x402("")
        assert result.authenticated is False


class TestAuthenticate:
    def test_bearer_takes_priority(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_API_KEY", "key-123")
        monkeypatch.setenv("SELLER_WALLET", "0xabc")
        from infershrink.mcp_auth import authenticate

        result = authenticate(bearer_token="key-123", x402_proof="proof")
        assert result.method == "bearer"

    def test_falls_back_to_x402(self, monkeypatch):
        monkeypatch.delenv("INFERSHRINK_API_KEY", raising=False)
        monkeypatch.setenv("SELLER_WALLET", "0xabc")
        from infershrink.mcp_auth import authenticate

        result = authenticate(bearer_token="wrong", x402_proof="proof")
        assert result.method == "x402"

    def test_unauthenticated_gets_free_tier(self, monkeypatch):
        monkeypatch.delenv("INFERSHRINK_API_KEY", raising=False)
        from infershrink.mcp_auth import authenticate

        result = authenticate()
        assert result.authenticated is True
        assert result.tier == "free"
        assert result.method == "none"


class TestPaymentHeader:
    def test_402_header_is_valid_base64_json(self, monkeypatch):
        monkeypatch.setenv("SELLER_WALLET", "0xabc123")
        import base64
        import json

        from infershrink.mcp_auth import build_402_header

        header = build_402_header()
        decoded = json.loads(base64.b64decode(header))
        assert decoded["x402Version"] == 1
        assert len(decoded["accepts"]) == 1
        assert decoded["accepts"][0]["network"] == "base-mainnet"
        assert decoded["accepts"][0]["payTo"] == "0xabc123"
