"""InferShrink MCP Server — expose cost optimization tools to AI agents.

Requires: pip install infershrink[mcp]

Usage:
    infershrink-mcp              # Streamable HTTP on port 8402
    infershrink-mcp --stdio      # stdio transport (Claude Desktop, local dev)
    infershrink-mcp --port 9000  # Custom port

Three tools exposed (curate ruthlessly — no more):
    - infershrink_classify: Classify prompt complexity
    - infershrink_optimize: Classify + route to cheapest model
    - infershrink_status: Server status and feature availability
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import threading
from typing import Any

logger = logging.getLogger(__name__)


def _require_mcp():
    """Lazy check for MCP SDK availability."""
    try:
        import mcp  # noqa: F401
    except ImportError:
        print(
            "Error: MCP SDK not installed. Install with: pip install infershrink[mcp]",
            file=sys.stderr,
        )
        sys.exit(1)


def _build_server():
    """Build and return the FastMCP server instance."""
    from mcp.server.fastmcp import FastMCP

    from . import __version__, classify, route
    from .config import build_config
    from .retrieval import is_retrieval_available

    mcp_server = FastMCP(
        "InferShrink",
        json_response=True,
    )

    # Shared config — built once at startup
    _config = build_config(auto_discover=True)

    # Track requests for status tool (thread-safe)
    import itertools

    _request_counter = itertools.count(1)  # Start at 1
    _request_total = [0]  # mutable container for thread-safe reads

    # Telemetry — best-effort, never blocks
    _telemetry_enabled = os.environ.get("INFERSHRINK_TELEMETRY", "true").lower() != "false"

    def _send_telemetry(tool: str, data: dict) -> None:  # type: ignore[misc]
        """Fire-and-forget telemetry event."""
        if not _telemetry_enabled:
            return
        try:
            from .edge_sync import EdgeSync

            endpoint = os.environ.get("INFERSHRINK_EDGE_ENDPOINT", "")
            token = os.environ.get("INFERSHRINK_EDGE_TOKEN", "")
            if not endpoint or not token:
                return
            sync = EdgeSync(endpoint=endpoint, token=token)
            event = {"source": "mcp", "tool": tool, **data}
            sync.push(event)
            sync.flush()
        except Exception as e:
            logger.debug("Telemetry send failed (non-blocking): %s", e)

    def _check_compression_available() -> bool:
        try:
            from .compressor import compress  # noqa: F401

            return bool(_config.get("compression", {}).get("enabled", False))
        except ImportError:
            return False

    _VALID_PROVIDERS = {"openai", "anthropic", "google"}

    @mcp_server.tool(
        name="infershrink_classify",
        description=(
            "Classify a prompt's complexity level for cost-optimal model routing. "
            "Use when you want to know if a prompt is simple enough for a cheaper model. "
            "Returns complexity (simple/moderate/complex/security_critical), token count, "
            "and recommended model tier. "
            "Provider must be one of: openai, anthropic, google."
        ),
    )
    def infershrink_classify(prompt: str, provider: str = "openai") -> dict[str, Any]:
        """Classify prompt complexity for model routing.

        Args:
            prompt: The prompt text to classify.
            provider: LLM provider (openai, anthropic, google). Routing stays within this provider.
        """
        provider_lower = provider.lower()
        if provider_lower not in _VALID_PROVIDERS:
            return {"error": f"Invalid provider '{provider}'. Use: {sorted(_VALID_PROVIDERS)}"}

        try:
            result = classify(prompt)  # type: ignore[arg-type]  # classify accepts str
        except Exception as e:
            return {"error": f"Classification failed: {e}"}

        _request_total[0] = next(_request_counter)

        # Map complexity to recommended model
        from .config import COMPLEXITY_TO_TIER

        tier_name = COMPLEXITY_TO_TIER.get(result.complexity.value, "tier3")
        tier = _config.get("tiers", {}).get(tier_name, {})

        # Find a model for the requested provider
        _provider_prefixes = {
            "openai": ["gpt-", "o1", "o3", "o4"],
            "anthropic": ["claude-"],
            "google": ["gemini-"],
        }
        prefixes = _provider_prefixes.get(provider_lower, [])
        recommended = None
        for model in tier.get("models", []):
            if any(model.lower().startswith(p) for p in prefixes):
                recommended = model
                break

        response = {
            "complexity": result.complexity.value.lower(),
            "tokens": result.estimated_tokens,
            "reason": result.reason,
            "recommended_model": recommended or f"(no {provider} model in {tier_name})",
            "recommended_tier": tier_name,
            "provider": provider_lower,
        }

        threading.Thread(
            target=_send_telemetry,
            args=("classify", {"complexity": response["complexity"], "provider": provider_lower}),
            daemon=True,
        ).start()

        return response

    @mcp_server.tool(
        name="infershrink_optimize",
        description=(
            "Optimize an LLM request for cost. Classifies complexity and recommends "
            "the cheapest model that can handle it. Same-provider routing — never "
            "switches providers. "
            "Use when you're about to make an LLM API call and want to minimize cost. "
            'Pass messages in OpenAI format: [{"role": "user", "content": "..."}]. '
            "Provider must be one of: openai, anthropic, google."
        ),
    )
    def infershrink_optimize(
        messages: list[dict[str, Any]],
        provider: str = "openai",
        current_model: str = "",
    ) -> dict[str, Any]:
        """Optimize an LLM request for cost.

        Args:
            messages: OpenAI-format messages array.
            provider: LLM provider (openai, anthropic, google).
            current_model: Model you'd normally use. Empty = use provider's tier3 default.
        """
        provider_lower = provider.lower()
        if provider_lower not in _VALID_PROVIDERS:
            return {"error": f"Invalid provider '{provider}'. Use: {sorted(_VALID_PROVIDERS)}"}

        try:
            classification = classify(messages)
        except Exception as e:
            return {"error": f"Classification failed: {e}"}

        _request_total[0] = next(_request_counter)

        # Determine current model if not provided
        if not current_model:
            _provider_defaults = {
                "openai": "gpt-4o",
                "anthropic": "claude-sonnet-4-20250514",
                "google": "gemini-2.5-pro",
            }
            current_model = _provider_defaults.get(provider.lower(), "gpt-4o")

        # Route
        routing = route(current_model, classification.complexity, _config)

        # Calculate estimated savings
        tiers = _config.get("tiers", {})
        original_tier = None
        routed_tier = None
        for _tier_name, tier_cfg in tiers.items():
            if routing.original_model in tier_cfg.get("models", []):
                original_tier = tier_cfg
            if routing.routed_model in tier_cfg.get("models", []):
                routed_tier = tier_cfg

        savings_pct = 0.0
        if original_tier and routed_tier:
            orig_cost = original_tier.get("cost_per_1k_input", 0)
            routed_cost = routed_tier.get("cost_per_1k_input", 0)
            if orig_cost > 0:
                savings_pct = round((1 - routed_cost / orig_cost) * 100, 1)

        response = {
            "recommended_model": routing.routed_model,
            "original_model": routing.original_model,
            "complexity": classification.complexity.value.lower(),
            "reason": classification.reason,
            "downgraded": routing.was_downgraded,
            "estimated_savings_pct": savings_pct,
            "original_tokens": classification.estimated_tokens,
            "provider": provider.lower(),
        }

        threading.Thread(
            target=_send_telemetry,
            args=(
                "optimize",
                {
                    "complexity": response["complexity"],
                    "provider": provider.lower(),
                    "downgraded": routing.was_downgraded,
                    "savings_pct": savings_pct,
                },
            ),
            daemon=True,
        ).start()

        return response

    @mcp_server.tool(
        name="infershrink_status",
        description=(
            "Check InferShrink server status and available features. "
            "Use to verify the server is running and see what optimization "
            "features are available (routing, compression, retrieval). "
            "No arguments required."
        ),
    )
    def infershrink_status() -> dict[str, Any]:
        """Check server status and feature availability."""
        features = ["routing"]  # Always available
        if _check_compression_available():
            features.append("compression")
        if is_retrieval_available():
            features.append("retrieval")

        return {
            "version": __version__,
            "features": features,
            "tier": "free",  # TODO: wire to license validation
            "total_requests": _request_total[0],
            "providers": ["openai", "anthropic", "google"],
        }

    return mcp_server


def main():
    """Entry point for infershrink-mcp CLI."""
    _require_mcp()

    parser = argparse.ArgumentParser(description="InferShrink MCP Server")
    parser.add_argument(
        "--stdio",
        action="store_true",
        help="Use stdio transport (for Claude Desktop, local dev)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for Streamable HTTP transport (default: 127.0.0.1, use 0.0.0.0 for public)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8402,
        help="Port for Streamable HTTP transport (default: 8402)",
    )
    args = parser.parse_args()

    server = _build_server()

    if args.stdio:
        server.run(transport="stdio")
    else:
        server.run(
            transport="streamable-http",
            host=args.host,
            port=args.port,
        )


if __name__ == "__main__":
    main()
