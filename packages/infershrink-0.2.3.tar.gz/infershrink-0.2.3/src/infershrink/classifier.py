"""Rule-based task complexity classifier (v1).

Analyzes a messages array and returns a complexity level used for
model routing and compression decisions.

NOTE: This classifier is for COST OPTIMIZATION routing, not security.
It determines whether a prompt is simple/moderate/complex to route
to the cheapest capable model. Security scanning is a separate concern
(see Agent Guard).
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

from .types import ClassificationResult, Complexity

# ---------------------------------------------------------------------------
# Keyword / pattern sets
# ---------------------------------------------------------------------------

# Credential-related keywords — route to strongest model (don't compress
# or send to cheap models when handling sensitive data)
_SECURITY_KEYWORDS: set[str] = {
    "password",
    "passwd",
    "secret",
    "api_key",
    "apikey",
    "api-key",
    "api key",
    "auth_token",
    "auth token",
    "access_token",
    "access token",
    "refresh_token",
    "refresh token",
    "bearer token",
    "credential",
    "private_key",
    "private-key",
    "private key",
    "ssh-key",
    "ssh key",
    "credit card",
    "credit_card",
    "ssn",
    "social security",
    "bank account",
    "routing number",
    "financial",
    "hipaa",
    "pci",
    "encrypt",
    "decrypt",
    "certificate",
    "oauth",
    "jwt",
}

_COMPLEX_KEYWORDS: set[str] = {
    "step by step",
    "step-by-step",
    "chain of thought",
    "chain-of-thought",
    "multi-step",
    "multistep",
    "analyze",
    "compare and contrast",
    "write a story",
    "write a poem",
    "creative writing",
    "novel",
    "debug this",
    "refactor",
    "architecture",
    "design pattern",
    "mathematical proof",
    "theorem",
    "derive",
    "implement",
    "write a function",
    "write a class",
    "write a script",
    "unit test",
    "error handling",
    "type hints",
    "comprehensive",
    "explain in detail",
    "explain how",
    "explain why",
    "recursive",
    "algorithm",
    "data structure",
    "optimization",
    "review this code",
    "code review",
    "fix this bug",
    "build a",
    "create a",
    "design a",
    "develop a",
    "with tests",
    "with examples",
    "with documentation",
    "pros and cons",
    "trade-offs",
    "tradeoffs",
    "summarize this article",
    "summarize this paper",
    "translate this",
    "rewrite this",
    # Academic/theoretical
    "derivation",
    "prove",
    "proof",
    "formalize",
    "formal specification",
    "mathematical",
    "computational complexity",
    "time complexity",
    "space complexity",
    "big-o",
    "asymptotic",
    # Multi-part requests
    "including",
    "furthermore",
    "additionally",
    "as well as",
    # Deep explanation
    "foundations",
    "fundamentals",
    "from first principles",
    "in depth",
    "in-depth",
    "thorough",
    "detailed analysis",
    "benchmark",
}

_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```")
_INLINE_CODE_RE = re.compile(r"`[^`]+`")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token for English)."""
    return max(1, len(text) // 4)


def _flatten_text(messages: List[Dict[str, Any]]) -> str:
    """Concatenate all message content into a single string."""
    parts: list[str] = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            # Multi-part content (text blocks, images, etc.)
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    parts.append(part.get("text", ""))
                elif isinstance(part, str):
                    parts.append(part)
    return "\n".join(parts)


def _has_tool_calls(messages: List[Dict[str, Any]]) -> bool:
    """Check if any message contains tool_calls or function_call."""
    for msg in messages:
        if msg.get("tool_calls") or msg.get("function_call"):
            return True
        if msg.get("role") == "tool" or msg.get("role") == "function":
            return True
    return False


def _count_code_blocks(text: str) -> int:
    return len(_CODE_BLOCK_RE.findall(text))


def _count_inline_code(text: str) -> int:
    return len(_INLINE_CODE_RE.findall(text))


def _contains_any(text: str, keywords: set[str]) -> list[str]:
    """Return list of matched keywords found in text (case-insensitive)."""
    text_lower = text.lower()
    return [kw for kw in keywords if kw in text_lower]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def classify(messages: List[Dict[str, Any]]) -> ClassificationResult:
    """Classify the complexity of a messages array.

    Parameters
    ----------
    messages:
        The messages list in OpenAI chat format
        (``[{"role": "user", "content": "..."}]``).

    Returns
    -------
    ClassificationResult
        Contains the complexity level, reason, token estimate, and signals.
    """
    # Accept bare string or string list for convenience
    if isinstance(messages, str):
        messages = [{"role": "user", "content": messages}]
    elif isinstance(messages, list) and messages and isinstance(messages[0], str):
        messages = [{"role": "user", "content": m} for m in messages]

    full_text = _flatten_text(messages)
    est_tokens = _estimate_tokens(full_text)

    code_blocks = _count_code_blocks(full_text)
    inline_code = _count_inline_code(full_text)
    has_tools = _has_tool_calls(messages)
    security_hits = _contains_any(full_text, _SECURITY_KEYWORDS)
    complex_hits = _contains_any(full_text, _COMPLEX_KEYWORDS)

    # Count messages by role
    system_msgs = [m for m in messages if m.get("role") == "system"]
    system_length = sum(
        _estimate_tokens(m.get("content", "") if isinstance(m.get("content", ""), str) else "")
        for m in system_msgs
    )

    # Multi-clause detection: count question marks and instruction verbs
    question_count = full_text.count("?")
    # Count comma-separated instructions (e.g., "include X, handle Y, add Z")
    clause_indicators = sum(
        1
        for word in [
            "include",
            "handle",
            "add",
            "ensure",
            "provide",
            "show",
            "list",
            "describe",
            "cover",
        ]
        if word in full_text.lower()
    )

    signals: Dict[str, Any] = {
        "estimated_tokens": est_tokens,
        "code_blocks": code_blocks,
        "inline_code": inline_code,
        "has_tool_calls": has_tools,
        "security_keywords": security_hits,
        "complex_keywords": complex_hits,
        "system_prompt_tokens": system_length,
        "message_count": len(messages),
        "question_count": question_count,
        "clause_indicators": clause_indicators,
    }

    # --- Decision tree ---

    # 1. Security-critical: prompts containing credentials/sensitive data
    #    Route to strongest model, never compress
    if security_hits:
        return ClassificationResult(
            complexity=Complexity.SECURITY_CRITICAL,
            reason=f"Security-sensitive content detected: {', '.join(security_hits[:5])}",
            estimated_tokens=est_tokens,
            signals=signals,
        )

    # Check for explicit security marker in metadata
    for msg in messages:
        meta = msg.get("metadata", {}) or {}
        if isinstance(meta, dict) and meta.get("security_critical"):
            return ClassificationResult(
                complexity=Complexity.SECURITY_CRITICAL,
                reason="Explicitly marked as security-critical via metadata",
                estimated_tokens=est_tokens,
                signals=signals,
            )

    # 2. Complex
    multi_clause = clause_indicators >= 3 or (question_count >= 3 and est_tokens > 30)
    if (
        est_tokens > 2000
        or code_blocks >= 3
        or has_tools
        or complex_hits
        or system_length > 500
        or multi_clause
    ):
        reason_parts: list[str] = []
        if est_tokens > 2000:
            reason_parts.append(f"long prompt ({est_tokens} tokens)")
        if code_blocks >= 3:
            reason_parts.append(f"{code_blocks} code blocks")
        if has_tools:
            reason_parts.append("tool calls present")
        if complex_hits:
            reason_parts.append(f"complex keywords: {', '.join(complex_hits[:3])}")
        if system_length > 500:
            reason_parts.append(f"complex system prompt ({system_length} tokens)")
        if multi_clause:
            reason_parts.append(
                f"multi-part request ({clause_indicators} instructions, {question_count} questions)"
            )

        return ClassificationResult(
            complexity=Complexity.COMPLEX,
            reason="; ".join(reason_parts),
            estimated_tokens=est_tokens,
            signals=signals,
        )

    # 3. Moderate
    if est_tokens > 500 or code_blocks >= 1 or inline_code >= 3 or len(messages) > 4:
        reason_parts = []
        if est_tokens > 500:
            reason_parts.append(f"medium prompt ({est_tokens} tokens)")
        if code_blocks >= 1:
            reason_parts.append(f"{code_blocks} code block(s)")
        if inline_code >= 3:
            reason_parts.append(f"{inline_code} inline code spans")
        if len(messages) > 4:
            reason_parts.append(f"multi-turn ({len(messages)} messages)")

        return ClassificationResult(
            complexity=Complexity.MODERATE,
            reason="; ".join(reason_parts) or "moderate complexity signals",
            estimated_tokens=est_tokens,
            signals=signals,
        )

    # 4. Simple (default)
    return ClassificationResult(
        complexity=Complexity.SIMPLE,
        reason=f"Short, simple prompt ({est_tokens} tokens, no code, no tools)",
        estimated_tokens=est_tokens,
        signals=signals,
    )
