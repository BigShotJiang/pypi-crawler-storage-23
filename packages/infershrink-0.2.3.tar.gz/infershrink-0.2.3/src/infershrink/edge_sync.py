"""Edge CRDT telemetry sync for InferShrink.

Best-effort sync of usage telemetry to the Edge CRDT Runtime.
Local stats.jsonl remains authoritative. Edge failure never affects core functionality.
"""

from __future__ import annotations

import atexit
import hashlib
import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)

# Telemetry event required fields for validation
_REQUIRED_FIELDS = frozenset(
    {
        "ts",
        "complexity",
        "original_model",
        "routed_model",
        "was_downgraded",
        "provider",
        "input_tokens",
        "output_tokens",
        "original_cost_usd",
        "actual_cost_usd",
        "savings_usd",
        "latency_ms",
    }
)

# All allowed fields (required + optional)
_ALLOWED_FIELDS = _REQUIRED_FIELDS | frozenset({"null_recovery", "error"})


def _validate_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """Strip unknown fields and enforce only allowed fields."""
    return {k: v for k, v in event.items() if k in _ALLOWED_FIELDS}


def _compute_instance_id(license_key: Optional[str] = None) -> str:
    """SHA-256 of license key truncated to 16 chars, or 'dev'."""
    key = license_key or os.environ.get("INFERSHRINK_LICENSE_KEY", "")
    if not key:
        return "dev"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


class EdgeSync:
    """Batches telemetry events and syncs to Edge CRDT Runtime via /ingest."""

    def __init__(
        self,
        endpoint: str,
        token: str,
        instance_id: Optional[str] = None,
        batch_size: int = 50,
        flush_interval_s: int = 300,
        max_queue: int = 500,
        sdk_version: str = "unknown",
    ) -> None:
        self._endpoint = endpoint.rstrip("/")
        self._token = token
        self._instance_id = instance_id or _compute_instance_id()
        self._batch_size = max(1, min(100, batch_size))
        self._flush_interval_s = flush_interval_s
        self._max_queue = max_queue
        self._sdk_version = sdk_version

        self._queue: List[Dict[str, Any]] = []
        self._lock = threading.Lock()
        self._consecutive_failures = 0
        self._disabled = False
        self._disabled_until: Optional[float] = None
        self._overflow_warned = False

        # Start periodic flush timer
        self._timer: Optional[threading.Timer] = None
        self._closed = False
        self._start_timer()

        # Register shutdown handler
        atexit.register(self.close)

    def _start_timer(self) -> None:
        """Start the periodic flush timer."""
        if self._closed:
            return
        self._timer = threading.Timer(self._flush_interval_s, self._timer_flush)
        self._timer.daemon = True
        self._timer.start()

    def _timer_flush(self) -> None:
        """Called by the periodic timer."""
        if not self._closed:
            self.flush()
            self._start_timer()

    def _is_disabled(self) -> bool:
        """Check if sync is disabled (permanent or temporary)."""
        if self._disabled:
            return True
        if self._disabled_until is not None:
            if time.time() < self._disabled_until:
                return True
            # Re-enable after the disable period
            self._disabled_until = None
            self._consecutive_failures = 0
        return False

    def push(self, event: Dict[str, Any]) -> None:
        """Queue a telemetry event. Non-blocking. Thread-safe.

        If queue exceeds max_queue, drops oldest events.
        """
        if self._is_disabled():
            return

        cleaned = _validate_event(event)

        with self._lock:
            self._queue.append(cleaned)
            if len(self._queue) > self._max_queue:
                dropped = len(self._queue) - self._max_queue
                self._queue = self._queue[dropped:]
                if not self._overflow_warned:
                    logger.warning(
                        "Edge telemetry queue overflow: dropped %d oldest events", dropped
                    )
                    self._overflow_warned = True

            should_flush = len(self._queue) >= self._batch_size

        if should_flush:
            self.flush()

    def flush(self) -> bool:
        """POST queued events to edge /ingest. Returns True on success."""
        if self._is_disabled():
            return False

        with self._lock:
            if not self._queue:
                return True
            batch = list(self._queue)
            self._queue.clear()

        # Compute today's date for doc ID
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        doc_id = f"telemetry:{self._instance_id}:{today}"
        url = f"{self._endpoint}/doc/{doc_id}/ingest"

        payload = json.dumps(
            {
                "events": batch,
                "meta": {
                    "instance_id": self._instance_id,
                    "sdk_version": self._sdk_version,
                },
            }
        ).encode("utf-8")

        req = Request(  # noqa: S310 — URL from config, not user input
            url,
            data=payload,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urlopen(req, timeout=10) as resp:  # noqa: S310 — URL is from config, not user input
                if resp.status == 200:
                    self._consecutive_failures = 0
                    return True
                else:
                    return self._handle_failure(batch)
        except HTTPError as e:
            if e.code == 429:
                # Rate limited — disable until next midnight UTC
                now = datetime.now(timezone.utc)
                tomorrow = now.replace(hour=0, minute=0, second=0, microsecond=0) + __import__(
                    "datetime"
                ).timedelta(days=1)
                self._disabled_until = tomorrow.timestamp()
                logger.warning(
                    "Edge telemetry rate limited (429). Disabled until %s UTC.",
                    tomorrow.date(),
                )
                # Don't re-queue — events are lost (local stats.jsonl has them)
                return False
            return self._handle_failure(batch)
        except (URLError, OSError, TimeoutError):
            return self._handle_failure(batch)

    def _handle_failure(self, batch: List[Dict[str, Any]]) -> bool:
        """Handle a flush failure: re-queue events, track consecutive failures."""
        self._consecutive_failures += 1

        # Re-queue events (may drop oldest if over max_queue)
        with self._lock:
            self._queue = batch + self._queue
            if len(self._queue) > self._max_queue:
                self._queue = self._queue[-self._max_queue :]

        if self._consecutive_failures >= 3:
            self._disabled = True
            logger.warning(
                "Edge telemetry disabled after %d consecutive failures.",
                self._consecutive_failures,
            )

        return False

    def close(self) -> None:
        """Final flush attempt. Cancel timer."""
        if self._closed:
            return
        self._closed = True

        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

        # Best-effort final flush
        if not self._is_disabled():
            self.flush()
