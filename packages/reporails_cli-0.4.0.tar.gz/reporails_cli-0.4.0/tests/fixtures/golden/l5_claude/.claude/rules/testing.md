# Testing Rules

- MUST write tests for new features
- MUST maintain test coverage above 80%
- NEVER skip failing tests
- NEVER mock the unit under test
