"""Interface adapters for reporails (CLI, MCP)."""
