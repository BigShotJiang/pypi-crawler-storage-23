"""CLI interface for reporails."""

from __future__ import annotations

from reporails_cli.interfaces.cli.helpers import app

__all__ = ["app"]
