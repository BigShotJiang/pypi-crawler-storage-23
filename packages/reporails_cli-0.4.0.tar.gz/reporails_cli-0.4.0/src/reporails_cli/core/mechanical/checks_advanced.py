# pylint: disable=too-many-lines
"""Advanced mechanical checks — content reading, import following, aggregation.

These checks are more complex than the simple structural checks in checks.py.
They are imported and registered in MECHANICAL_CHECKS by checks.py.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from reporails_cli.core.mechanical.checks import (
    CheckResult,
    _expand_file_pattern,
    _get_target_patterns,
    _resolve_glob_targets,
    _resolve_path,
    _safe_float,
)


def path_resolves(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that target paths exist."""
    for pattern in _get_target_patterns(args, vars):
        if _resolve_glob_targets(pattern, root):
            return CheckResult(passed=True, message="Target paths exist")
    return CheckResult(passed=False, message="No matching paths found")


def extract_imports(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check for @import references in instruction files."""
    imports_found: list[str] = []
    for pattern in _get_target_patterns(args, vars):
        for match in _resolve_glob_targets(pattern, root):
            if not match.is_file():
                continue
            try:
                content = match.read_text(encoding="utf-8")
                imports_found.extend(re.findall(r"@[\w./-]+", content))
            except OSError:
                continue
    if imports_found:
        return CheckResult(
            passed=True,
            message=f"Found {len(imports_found)} import(s)",
            annotations={"discovered_imports": imports_found},
        )
    return CheckResult(passed=False, message="No imports found")


def aggregate_byte_size(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check total byte size of all matching files."""
    max_bytes = _safe_float(args.get("max"), float("inf"))
    raw_pattern = str(args.get("pattern", "**/*"))
    all_files: set[Path] = set()
    for pattern in _expand_file_pattern(raw_pattern, vars):
        all_files.update(m for m in _resolve_glob_targets(pattern, root) if m.is_file())
    total = sum(f.stat().st_size for f in all_files)
    if total <= max_bytes:
        return CheckResult(passed=True, message=f"Total {total}B within limit")
    return CheckResult(passed=False, message=f"Total {total}B exceeds max {max_bytes}")


def import_depth(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that @import chains do not exceed max depth."""
    max_depth = int(args.get("max", 5))

    def follow(filepath: Path, visited: set[Path], depth: int) -> int:
        if filepath in visited or not filepath.is_file():
            return depth
        visited.add(filepath)
        try:
            content = filepath.read_text(encoding="utf-8")
        except OSError:
            return depth
        refs = re.findall(r"@([\w./-]+)", content)
        max_d = depth
        for ref in refs:
            target = filepath.parent / ref
            if target.is_file():
                max_d = max(max_d, follow(target, visited, depth + 1))
        return max_d

    for pattern in _get_target_patterns(args, vars):
        for match in _resolve_glob_targets(pattern, root):
            if not match.is_file():
                continue
            deepest = follow(match, set(), 0)
            if deepest > max_depth:
                return CheckResult(
                    passed=False,
                    message=f"{match.name}: depth {deepest} exceeds max {max_depth}",
                )
    return CheckResult(passed=True, message=f"Import depth within limit ({max_depth})")


def directory_file_types(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that all files in a directory match allowed extensions."""
    path = _resolve_path(str(args.get("path", "")), vars)
    extensions: list[str] = list(args.get("extensions", []))
    target = root / path
    if not target.is_dir():
        return CheckResult(passed=True, message=f"Directory not found: {path} (OK)")
    bad = [f.name for f in target.iterdir() if f.is_file() and f.suffix not in extensions]
    if bad:
        return CheckResult(passed=False, message=f"Non-{extensions} files: {', '.join(bad[:5])}")
    return CheckResult(passed=True, message=f"All files in {path} match {extensions}")


def frontmatter_valid_glob(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that YAML frontmatter path entries use valid glob syntax."""
    path = _resolve_path(str(args.get("path", "")), vars)
    target = root / path
    if not target.is_dir():
        return CheckResult(passed=True, message=f"Directory not found: {path} (OK)")
    for f in target.iterdir():
        if not f.is_file() or f.suffix != ".md":
            continue
        try:
            content = f.read_text(encoding="utf-8")
            if not content.startswith("---"):
                continue
            end = content.find("---", 3)
            if end < 0:
                continue
            fm = yaml.safe_load(content[3:end])
            if not isinstance(fm, dict):
                continue
            paths = fm.get("globs") or fm.get("paths") or []
            if isinstance(paths, str):
                paths = [paths]
            for p in paths:
                if not isinstance(p, str):
                    return CheckResult(passed=False, message=f"{f.name}: non-string path: {p}")
                if p.count("[") != p.count("]"):
                    return CheckResult(passed=False, message=f"{f.name}: unbalanced brackets: {p}")
        except (OSError, yaml.YAMLError):
            continue
    return CheckResult(passed=True, message="All frontmatter path entries valid")


def count_at_most(
    _root: Path,
    args: dict[str, Any],
    _vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that a metadata list has at most N entries.

    Reads a named metadata key from args (injected by pipeline from annotations).
    Args: threshold (int, default 0), plus the metadata key name -> list.
    """
    threshold = int(args.get("threshold", 0))
    # Find the metadata list — it's injected as args[key] by the pipeline
    items: list[str] = []
    for value in args.values():
        if isinstance(value, list):
            items = value
            break
    if len(items) <= threshold:
        return CheckResult(passed=True, message=f"Count {len(items)} within limit ({threshold})")
    return CheckResult(passed=False, message=f"Count {len(items)} exceeds max {threshold}")


def count_at_least(
    _root: Path,
    args: dict[str, Any],
    _vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that a metadata list has at least N entries.

    Reads a named metadata key from args (injected by pipeline from annotations).
    Args: threshold (int, default 1), plus the metadata key name -> list.
    """
    threshold = int(args.get("threshold", 1))
    items: list[str] = []
    for value in args.values():
        if isinstance(value, list):
            items = value
            break
    if len(items) >= threshold:
        return CheckResult(passed=True, message=f"Count {len(items)} meets minimum ({threshold})")
    return CheckResult(passed=False, message=f"Count {len(items)} below minimum {threshold}")


def check_import_targets_exist(
    root: Path,
    args: dict[str, Any],
    _vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that all @import paths from metadata resolve to existing files.

    Reads import paths from args (injected by pipeline from D check annotations).
    Each path is resolved relative to the target instruction file's directory.
    """
    import_paths: list[str] = []
    for value in args.values():
        if isinstance(value, list):
            import_paths = value
            break
    if not import_paths:
        return CheckResult(passed=True, message="No import paths to check")
    missing: list[str] = []
    for ref in import_paths:
        # Strip leading @ if present
        clean = ref.lstrip("@")
        if not (root / clean).exists():
            missing.append(clean)
    if missing:
        return CheckResult(
            passed=False,
            message=f"Unresolved imports: {', '.join(missing[:5])}",
        )
    return CheckResult(passed=True, message=f"All {len(import_paths)} import(s) resolve")


def filename_matches_pattern(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that target filenames match a regex pattern.

    Args: pattern (regex string), path (optional glob for file targets).
    """
    pattern = str(args.get("pattern", ""))
    if not pattern:
        return CheckResult(passed=False, message="filename_matches_pattern: no pattern specified")
    try:
        compiled = re.compile(pattern)
    except re.error as e:
        return CheckResult(passed=False, message=f"filename_matches_pattern: invalid regex: {e}")
    for fp in _get_target_patterns(args, vars):
        for match in _resolve_glob_targets(fp, root):
            if not match.is_file():
                continue
            if not compiled.search(match.name):
                return CheckResult(
                    passed=False,
                    message=f"{match.name}: does not match pattern {pattern}",
                )
    return CheckResult(passed=True, message="All filenames match pattern")


def _scope_dir_from_glob(glob_pattern: str) -> str:
    """Extract the non-glob directory prefix from a glob pattern.

    >>> _scope_dir_from_glob(".claude/skills/**/*.md")
    '.claude/skills'
    >>> _scope_dir_from_glob("**/CLAUDE.md")
    ''
    """
    parts = glob_pattern.replace("\\", "/").split("/")
    dirs: list[str] = []
    for part in parts:
        if any(c in part for c in "*?[{"):
            break
        dirs.append(part)
    return "/".join(dirs)


def file_absent(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that NO file matching the pattern exists.

    When ``_targets`` is injected (from rule.targets), scopes the search
    to the target directory instead of the project root.
    """
    pattern = str(args.get("pattern", ""))
    if not pattern:
        return CheckResult(passed=False, message="file_absent: no pattern specified")
    resolved = _resolve_path(pattern, vars)

    # Determine search scope: rule targets directory or project root
    targets = str(args.get("_targets", ""))
    scope_dir = _scope_dir_from_glob(_resolve_path(targets, vars)) if targets else ""
    if scope_dir:
        search_pattern = f"{scope_dir}/**/{resolved}"
        direct_path = root / scope_dir / resolved
    else:
        search_pattern = resolved
        direct_path = root / resolved

    matches = _resolve_glob_targets(search_pattern, root)
    if matches:
        name = str(matches[0].relative_to(root)) if matches[0].is_relative_to(root) else matches[0].name
        return CheckResult(passed=False, message=f"Forbidden file exists: {name}")
    if direct_path.exists():
        rel = f"{scope_dir}/{resolved}" if scope_dir else resolved
        return CheckResult(passed=False, message=f"Forbidden file exists: {rel}")
    return CheckResult(passed=True, message="Forbidden file not found")


def content_absent(
    root: Path,
    args: dict[str, Any],
    vars: dict[str, str | list[str]],
) -> CheckResult:
    """Check that a regex pattern does NOT appear in matching files."""
    pattern = str(args.get("pattern", ""))
    if not pattern:
        return CheckResult(passed=False, message="content_absent: no pattern specified")
    try:
        compiled = re.compile(pattern)
    except re.error as e:
        return CheckResult(passed=False, message=f"content_absent: invalid regex: {e}")
    for fp in _get_target_patterns(args, vars):
        for match in _resolve_glob_targets(fp, root):
            if not match.is_file():
                continue
            try:
                content = match.read_text(encoding="utf-8")
                if compiled.search(content):
                    return CheckResult(
                        passed=False,
                        message=f"{match.name}: forbidden pattern found",
                    )
            except OSError:
                continue
    return CheckResult(passed=True, message="Forbidden pattern not found")
