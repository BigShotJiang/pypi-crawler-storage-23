"""Reporails - Validate and score CLAUDE.md files."""

from __future__ import annotations

from importlib.metadata import version

__version__ = version("reporails-cli")
