# CHANGELOG

<!-- version list -->

## v1.1.2 (2026-03-01)

### Bug Fixes

- **types**: Make VatCode.code field optional
  ([`f26939c`](https://github.com/bandbyte/moco-py/commit/f26939ca0adc9830b87e4adb76ec861211d1a2bd))


## v1.1.1 (2026-03-01)

### Bug Fixes

- **types**: Make fields optional that API may omit
  ([`51b1483`](https://github.com/bandbyte/moco-py/commit/51b1483218f62a705351d0756258a4dc98acf7fe))


## v1.1.0 (2026-03-01)

### Chores

- **release**: Set version to 1.0.0
  ([`77c3cfd`](https://github.com/bandbyte/moco-py/commit/77c3cfdcc18d10c2088ecd719967534480b79ae8))

### Features

- **client**: Register new resources on Moco and AsyncMoco
  ([`968cb77`](https://github.com/bandbyte/moco-py/commit/968cb77dd24a855ad9e473a7b6dbfe132a5e15b8))

- **offers**: Add offer customer approval resource
  ([`3271f10`](https://github.com/bandbyte/moco-py/commit/3271f103867f44b75dc93a938f45ffc736ee83ac))

- **purchases**: Add purchase bookkeeping exports resource
  ([`c33dee9`](https://github.com/bandbyte/moco-py/commit/c33dee9374133eebd0b4236312127e973d48d21f))

- **purchases**: Add purchase budgets resource
  ([`427e83d`](https://github.com/bandbyte/moco-py/commit/427e83dccd9104303893c7d9d51c16c5ebb76236))


## v1.0.0 (2026-03-01)

- Initial Release
