"""Prometheus metrics exporter for etcd3 client.

This module provides Prometheus-compatible metrics export for the etcd3 client,
supporting various metric types including counters, gauges, and histograms.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional
import logging

if TYPE_CHECKING:
    from prometheus_client import CollectorRegistry

try:
    from prometheus_client import (
        Counter,
        Gauge,
        Histogram,
        CollectorRegistry,
        generate_latest,
    )

    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False


logger = logging.getLogger("etcd3.exporters")


class EtcdPrometheusExporter:
    """Prometheus metrics exporter for etcd3 client.

    Provides Prometheus-compatible metrics with labels for operation,
    endpoint, and status dimensions.

    Example:
        >>> exporter = EtcdPrometheusExporter()
        >>> exporter.record_request("kv.get", endpoint="localhost:2379", duration=0.001)
        >>> print(exporter.metrics())  # Get Prometheus format output
    """

    def __init__(self, registry: Optional[CollectorRegistry] = None):
        """Initialize Prometheus exporter.

        Args:
            registry: Optional Prometheus registry. Uses default if None.
        """
        if not PROMETHEUS_AVAILABLE:
            raise ImportError(
                "prometheus_client is required for metrics export. "
                "Install with: pip install prometheus-client"
            )

        self._registry = registry or CollectorRegistry()

        # Request metrics
        self._request_counter = Counter(
            "etcd3_requests_total",
            "Total number of requests",
            ["operation", "endpoint", "status"],
            registry=self._registry,
        )

        self._request_duration = Histogram(
            "etcd3_request_duration_seconds",
            "Request duration in seconds",
            ["operation", "endpoint"],
            buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0],
            registry=self._registry,
        )

        # Error metrics
        self._error_counter = Counter(
            "etcd3_errors_total",
            "Total number of errors",
            ["operation", "endpoint", "error_type"],
            registry=self._registry,
        )

        # Retry metrics
        self._retry_counter = Counter(
            "etcd3_retries_total",
            "Total number of retries",
            ["operation", "endpoint"],
            registry=self._registry,
        )

        # Connection metrics
        self._connection_gauge = Gauge(
            "etcd3_connections",
            "Number of active connections",
            ["endpoint", "state"],
            registry=self._registry,
        )

    def record_request(
        self,
        operation: str,
        endpoint: str,
        duration: float,
        status: str = "success",
    ):
        """Record a request metric.

        Args:
            operation: Operation name (e.g., "kv.get", "lease.grant")
            endpoint: Endpoint address
            duration: Request duration in seconds
            status: Request status ("success" or "error")
        """
        status_label = "success" if status in ("success", "ok", 200, 0) else "error"

        self._request_counter.labels(
            operation=operation,
            endpoint=endpoint,
            status=status_label,
        ).inc()

        self._request_duration.labels(
            operation=operation,
            endpoint=endpoint,
        ).observe(duration)

    def record_error(
        self,
        operation: str,
        endpoint: str,
        error_type: str,
    ):
        """Record an error metric.

        Args:
            operation: Operation name
            endpoint: Endpoint address
            error_type: Error type/class name
        """
        self._error_counter.labels(
            operation=operation,
            endpoint=endpoint,
            error_type=error_type,
        ).inc()

    def record_retry(
        self,
        operation: str,
        endpoint: str,
    ):
        """Record a retry metric.

        Args:
            operation: Operation name
            endpoint: Endpoint address
        """
        self._retry_counter.labels(
            operation=operation,
            endpoint=endpoint,
        ).inc()

    def set_connection_state(
        self,
        endpoint: str,
        state: str,
    ):
        """Set connection state gauge.

        Args:
            endpoint: Endpoint address
            state: Connection state ("active", "idle", "failed")
        """
        self._connection_gauge.labels(
            endpoint=endpoint,
            state=state,
        ).set(1)

    def unset_connection(self, endpoint: str):
        """Unset connection for an endpoint.

        Args:
            endpoint: Endpoint address
        """
        for state in ("active", "idle", "failed"):
            try:
                self._connection_gauge.labels(
                    endpoint=endpoint,
                    state=state,
                ).dec(1)
            except ValueError:
                pass  # Value already 0

    def record_endpoint_failure(self, endpoint: str):
        """Record an endpoint failure."""
        self.set_connection_state(endpoint, "failed")

    def record_endpoint_usage(self, endpoint: str):
        """Record an endpoint usage."""
        self.record_request("endpoint.usage", endpoint, 0, "success")

    def record_endpoint_recovery(self, endpoint: str):
        """Record an endpoint recovery."""
        self.set_connection_state(endpoint, "active")

    def metrics(self) -> bytes:
        """Get metrics in Prometheus format.

        Returns:
            Prometheus metrics text format
        """
        return generate_latest(self._registry)

    def reset(self):
        """Reset all metrics."""
        logger.warning("Reset not fully supported in Prometheus exporter")


# Global exporter instance
_exporter: Optional[EtcdPrometheusExporter] = None


def get_exporter() -> Optional[EtcdPrometheusExporter]:
    """Get the global Prometheus exporter instance.

    Returns:
        Global EtcdPrometheusExporter instance or None if not available
    """
    global _exporter
    if _exporter is None and PROMETHEUS_AVAILABLE:
        try:
            _exporter = EtcdPrometheusExporter()
        except Exception as e:
            logger.warning(f"Failed to create Prometheus exporter: {e}")
            return None
    return _exporter


def init_exporter(
    registry: Optional[CollectorRegistry] = None,
) -> EtcdPrometheusExporter:
    """Initialize the global Prometheus exporter.

    Args:
        registry: Optional Prometheus registry

    Returns:
        Initialized EtcdPrometheusExporter instance
    """
    global _exporter
    _exporter = EtcdPrometheusExporter(registry)
    return _exporter


def is_prometheus_available() -> bool:
    """Check if Prometheus client is available.

    Returns:
        True if prometheus_client is installed
    """
    return PROMETHEUS_AVAILABLE


class _NoOpMetrics:
    """No-op metrics collector when Prometheus is not available."""

    def record_request(
        self, operation: str, endpoint: str, duration: float, status: str = "success"
    ):
        pass

    def record_error(self, operation: str, endpoint: str, error_type: str):
        pass

    def record_retry(self, operation: str, endpoint: str):
        pass

    def record_endpoint_failure(self, endpoint: str):
        pass

    def record_endpoint_usage(self, endpoint: str):
        pass

    def record_endpoint_recovery(self, endpoint: str):
        pass

    def set_connection_state(self, endpoint: str, state: str):
        pass

    def unset_connection(self, endpoint: str):
        pass

    def metrics(self) -> bytes:
        return b""


def get_metrics_interface():
    """Get the metrics interface.

    Returns:
        EtcdPrometheusExporter if available, otherwise NoOpMetrics
    """
    if PROMETHEUS_AVAILABLE:
        exporter = get_exporter()
        if exporter is not None:
            return exporter
    return _NoOpMetrics()


def monitor_request(operation: str, is_async: bool = False):
    """Decorator factory to monitor request latency and errors.

    Args:
        operation: Name of the operation
        is_async: Whether the decorated function is async

    Returns:
        Decorator function
    """
    import time

    def decorator(func):
        if is_async:

            async def async_wrapper(*args, **kwargs):
                start_time = time.time()
                try:
                    result = await func(*args, **kwargs)
                    latency = time.time() - start_time
                    get_metrics_interface().record_request(
                        operation, "unknown", latency, "success"
                    )
                    return result
                except Exception as e:
                    latency = time.time() - start_time
                    get_metrics_interface().record_request(
                        operation, "unknown", latency, "error"
                    )
                    get_metrics_interface().record_error(
                        operation, "unknown", type(e).__name__
                    )
                    raise

            return async_wrapper

        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                latency = time.time() - start_time
                get_metrics_interface().record_request(
                    operation, "unknown", latency, "success"
                )
                return result
            except Exception as e:
                latency = time.time() - start_time
                get_metrics_interface().record_request(
                    operation, "unknown", latency, "error"
                )
                get_metrics_interface().record_error(
                    operation, "unknown", type(e).__name__
                )
                raise

        return sync_wrapper

    return decorator
