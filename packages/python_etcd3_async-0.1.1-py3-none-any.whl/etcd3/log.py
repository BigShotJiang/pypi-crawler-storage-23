"""Logging utilities for etcd3 client.

This module provides logging functionality for etcd3 operations,
including decorators for logging key operations and trace context integration.
"""

import functools
import logging
import os
from contextvars import ContextVar
from typing import Optional

from etcd3.trace import get_current_span, is_tracing_available

ENV_PREFIX = "ETCD_OBS_"
ENV_LOG_LEVEL = f"{ENV_PREFIX}LOG_LEVEL"

_log_operation: ContextVar[Optional[str]] = ContextVar("log_operation", default=None)

_log = logging.getLogger("etcd3")
_log.addHandler(logging.NullHandler())

_env_level = os.environ.get(ENV_LOG_LEVEL)
if _env_level:
    try:
        _log.setLevel(getattr(logging, _env_level.upper(), logging.DEBUG))
    except (AttributeError, ValueError):
        pass


def log_operation(operation_name: str):
    """Decorator to log operation start and completion for sync functions.

    Args:
        operation_name: Name of the operation for logging

    Returns:
        Decorator function
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _log_operation.set(operation_name)
            if _log.isEnabledFor(logging.DEBUG):
                _log.debug("[etcd3] Starting operation: %s", operation_name)
            try:
                result = func(*args, **kwargs)
                if _log.isEnabledFor(logging.DEBUG):
                    _log.debug("[etcd3] Completed operation: %s", operation_name)
                return result
            except Exception as e:
                _log.error("[etcd3] Operation failed: %s, error: %s", operation_name, e)
                raise

        return wrapper

    return decorator


def log_operation_async(operation_name: str):
    """Decorator to log operation start and completion for async functions.

    Args:
        operation_name: Name of the operation for logging

    Returns:
        Decorator function
    """

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            _log_operation.set(operation_name)
            if _log.isEnabledFor(logging.DEBUG):
                _log.debug("[etcd3] Starting operation: %s", operation_name)
            try:
                result = await func(*args, **kwargs)
                if _log.isEnabledFor(logging.DEBUG):
                    _log.debug("[etcd3] Completed operation: %s", operation_name)
                return result
            except Exception as e:
                _log.error("[etcd3] Operation failed: %s, error: %s", operation_name, e)
                raise

        return wrapper

    return decorator


def get_logger(operation: Optional[str] = None) -> logging.Logger:
    """Get the etcd3 logger instance, optionally with operation context.

    Args:
        operation: Optional operation name to set in context

    Returns:
        Logger instance
    """
    if operation:
        _log_operation.set(operation)
    return _log


def set_log_level(level: str):
    """Set the log level for etcd3 logger.

    This can also be configured via the ETCD3_LOG_LEVEL environment variable.

    Args:
        level: Log level as string ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')
    """
    _log.setLevel(getattr(logging, level.upper(), logging.DEBUG))


def get_trace_context() -> tuple[Optional[str], Optional[str]]:
    """Get trace context (trace_id, span_id) from current span.

    Returns:
        Tuple of (trace_id, span_id), or (None, None) if not available
    """
    if not is_tracing_available():
        return None, None

    span = get_current_span()
    if span is None:
        return None, None

    trace_id = span.get_span_context().trace_id
    span_id = span.get_span_context().span_id

    trace_id_hex = format(trace_id, "032x") if trace_id else None
    span_id_hex = format(span_id, "016x") if span_id else None

    return trace_id_hex, span_id_hex


class TraceContextLogRecord(logging.LogRecord):
    """LogRecord subclass that includes trace context."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        trace_id, span_id = get_trace_context()
        self.trace_id = trace_id
        self.span_id = span_id
        self.operation = _log_operation.get()
