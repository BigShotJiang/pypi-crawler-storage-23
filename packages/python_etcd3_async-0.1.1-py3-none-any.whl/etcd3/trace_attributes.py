"""etcd semantic attributes for OpenTelemetry tracing.

This module defines standardized attributes for etcd operations in OpenTelemetry
traces, following the OpenTelemetry semantic conventions:
https://opentelemetry.io/docs/reference/specification/trace/semantic_conventions/
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional


class EtcdOperationType(Enum):
    """etcd operation types for tracing."""

    # KV operations
    KV_GET = "kv.get"
    KV_PUT = "kv.put"
    KV_DELETE = "kv.delete"
    KV_RANGE = "kv.range"
    KV_TXN = "kv.transaction"

    # Lease operations
    LEASE_GRANT = "lease.grant"
    LEASE_REVOKE = "lease.revoke"
    LEASE_KEEPALIVE = "lease.keepalive"
    LEASE_TTL = "lease.ttl"

    # Lock operations
    LOCK_ACQUIRE = "lock.acquire"
    LOCK_RELEASE = "lock.release"
    LOCK_REFRESH = "lock.refresh"

    # Watch operations
    WATCH_CREATE = "watch.create"
    WATCH_CANCEL = "watch.cancel"

    # Cluster operations
    CLUSTER_MEMBER_ADD = "cluster.member.add"
    CLUSTER_MEMBER_REMOVE = "cluster.member.remove"
    CLUSTER_MEMBER_UPDATE = "cluster.member.update"
    CLUSTER_MEMBER_LIST = "cluster.member.list"

    # Maintenance operations
    MAINTENANCE_STATUS = "maintenance.status"
    MAINTENANCE_COMPACT = "maintenance.compact"
    MAINTENANCE_DEFRAG = "maintenance.defragment"


@dataclass(frozen=True)
class TraceAttributes:
    """Standard attribute names for etcd OpenTelemetry traces.

    These attributes follow OpenTelemetry semantic conventions where applicable
    and define etcd-specific attributes for comprehensive observability.
    """

    # === OpenTelemetry Standard Database Attributes ===
    DB_SYSTEM = "db.system"
    """Database system: always 'etcd' for this client."""

    DB_OPERATION = "db.operation"
    """Database operation name (e.g., 'kv.get', 'lease.grant')."""

    DB_STATEMENT = "db.statement"
    """Database statement (for complex queries, optional)."""

    # === etcd Key-Value Attributes ===
    ETCD_KEY = "etcd.key"
    """The key being operated on."""

    ETCD_RANGE_END = "etcd.range_end"
    """End of the key range for range operations."""

    ETCD_LIMIT = "etcd.limit"
    """Maximum number of keys to return."""

    ETCD_REVISION = "etcd.revision"
    """Current revision of the operation result."""

    ETCD_PREV_REVISION = "etcd.prev_revision"
    """Previous revision (for compare operations)."""

    ETCD_COUNT = "etcd.count"
    """Number of keys returned or affected."""

    ETCD_DELETED = "etcd.deleted"
    """Number of keys deleted."""

    # === etcd Cluster Attributes ===
    ETCD_ENDPOINT = "etcd.endpoint"
    """The etcd endpoint being accessed."""

    ETCD_CLUSTER_ID = "etcd.cluster_id"
    """Cluster ID from response header."""

    ETCD_MEMBER_ID = "etcd.member_id"
    """Member ID from response header."""

    ETCD_RAFT_TERM = "etcd.raft_term"
    """Raft term from response header."""

    # === etcd Lease Attributes ===
    ETCD_LEASE_ID = "etcd.lease.id"
    """Lease ID."""

    ETCD_LEASE_TTL = "etcd.lease.ttl"
    """Lease TTL in seconds."""

    ETCD_LEASE_REMAINING_TTL = "etcd.lease.remaining_ttl"
    """Remaining TTL for the lease."""

    # === etcd Lock Attributes ===
    ETCD_LOCK_NAME = "etcd.lock.name"
    """Lock name (key path)."""

    ETCD_LOCK_UUID = "etcd.lock.uuid"
    """Lock UUID (first 8 bytes)."""

    ETCD_LOCK_ACQUIRED = "etcd.lock.acquired"
    """Whether the lock was successfully acquired."""

    # === etcd Transaction Attributes ===
    ETCD_TXN_COMPARE_COUNT = "etcd.txn.compare_count"
    """Number of compare conditions."""

    ETCD_TXN_SUCCESS_COUNT = "etcd.txn.success_count"
    """Number of success operations."""

    ETCD_TXN_FAILURE_COUNT = "etcd.txn.failure_count"
    """Number of failure operations."""

    ETCD_TXN_SUCCEEDED = "etcd.txn.succeeded"
    """Whether the transaction succeeded."""

    # === etcd Batch Attributes ===
    ETCD_BATCH_SIZE = "etcd.batch.size"
    """Number of operations in the batch."""

    ETCD_BATCH_ATOMIC = "etcd.batch.atomic"
    """Whether the batch is atomic."""

    # === etcd Error Attributes ===
    ETCD_ERROR_CODE = "etcd.error_code"
    """Error code if operation failed."""

    ETCD_ERROR_MESSAGE = "etcd.error_message"
    """Error message if operation failed."""

    # === Retry Attributes ===
    ETCD_RETRY_COUNT = "etcd.retry.count"
    """Number of retries for this operation."""

    ETCD_RETRY_ENDPOINT = "etcd.retry.endpoint"
    """Endpoint used after retry."""


def _safe_decode(value: Optional[bytes], max_length: int = 256) -> Optional[str]:
    """Safely decode bytes to string for attribute values.

    Args:
        value: Bytes value to decode
        max_length: Maximum length for the decoded string

    Returns:
        Decoded string or None if input is None
    """
    if value is None:
        return None

    try:
        decoded = value.decode("utf-8", errors="replace")
        if len(decoded) > max_length:
            decoded = decoded[:max_length] + "..."
        return decoded
    except Exception:
        return repr(value)


def build_kv_attributes(
    operation: str,
    key: Optional[bytes] = None,
    range_end: Optional[bytes] = None,
    limit: Optional[int] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Build trace attributes for KV operations.

    Args:
        operation: Operation type (e.g., 'kv.get', 'kv.put')
        key: The key being operated on
        range_end: End of key range for range operations
        limit: Maximum number of keys to return
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.DB_SYSTEM: "etcd",
        TraceAttributes.DB_OPERATION: operation,
    }

    if key is not None:
        attrs[TraceAttributes.ETCD_KEY] = _safe_decode(key)

    if range_end is not None:
        attrs[TraceAttributes.ETCD_RANGE_END] = _safe_decode(range_end)

    if limit is not None:
        attrs[TraceAttributes.ETCD_LIMIT] = limit

    attrs.update(kwargs)
    return attrs


def build_response_attributes(
    header=None, count: Optional[int] = None, deleted: Optional[int] = None, **kwargs
) -> Dict[str, Any]:
    """Build trace attributes from etcd response.

    Args:
        header: Response header from etcd
        count: Number of keys returned/affected
        deleted: Number of keys deleted
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {}

    if header:
        attrs[TraceAttributes.ETCD_REVISION] = header.revision
        attrs[TraceAttributes.ETCD_CLUSTER_ID] = header.cluster_id
        attrs[TraceAttributes.ETCD_MEMBER_ID] = header.member_id
        attrs[TraceAttributes.ETCD_RAFT_TERM] = header.raft_term

    if count is not None:
        attrs[TraceAttributes.ETCD_COUNT] = count

    if deleted is not None:
        attrs[TraceAttributes.ETCD_DELETED] = deleted

    attrs.update(kwargs)
    return attrs


def build_lease_attributes(
    lease_id: Optional[int] = None,
    ttl: Optional[int] = None,
    remaining_ttl: Optional[int] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Build trace attributes for lease operations.

    Args:
        lease_id: Lease ID
        ttl: Lease TTL in seconds
        remaining_ttl: Remaining TTL
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.DB_SYSTEM: "etcd",
    }

    if lease_id is not None:
        attrs[TraceAttributes.ETCD_LEASE_ID] = lease_id

    if ttl is not None:
        attrs[TraceAttributes.ETCD_LEASE_TTL] = ttl

    if remaining_ttl is not None:
        attrs[TraceAttributes.ETCD_LEASE_REMAINING_TTL] = remaining_ttl

    attrs.update(kwargs)
    return attrs


def build_lock_attributes(
    name: Optional[str] = None,
    uuid: Optional[bytes] = None,
    acquired: Optional[bool] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Build trace attributes for lock operations.

    Args:
        name: Lock name (key path)
        uuid: Lock UUID (will use first 8 bytes)
        acquired: Whether the lock was acquired
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.DB_SYSTEM: "etcd",
    }

    if name is not None:
        attrs[TraceAttributes.ETCD_LOCK_NAME] = name

    if uuid is not None:
        # Use first 8 bytes of UUID for readability
        uuid_str = uuid[:8].hex() if isinstance(uuid, bytes) else str(uuid)[:16]
        attrs[TraceAttributes.ETCD_LOCK_UUID] = uuid_str

    if acquired is not None:
        attrs[TraceAttributes.ETCD_LOCK_ACQUIRED] = acquired

    attrs.update(kwargs)
    return attrs


def build_txn_attributes(
    compare_count: Optional[int] = None,
    success_count: Optional[int] = None,
    failure_count: Optional[int] = None,
    succeeded: Optional[bool] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Build trace attributes for transaction operations.

    Args:
        compare_count: Number of compare conditions
        success_count: Number of success operations
        failure_count: Number of failure operations
        succeeded: Whether the transaction succeeded
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.DB_SYSTEM: "etcd",
    }

    if compare_count is not None:
        attrs[TraceAttributes.ETCD_TXN_COMPARE_COUNT] = compare_count

    if success_count is not None:
        attrs[TraceAttributes.ETCD_TXN_SUCCESS_COUNT] = success_count

    if failure_count is not None:
        attrs[TraceAttributes.ETCD_TXN_FAILURE_COUNT] = failure_count

    if succeeded is not None:
        attrs[TraceAttributes.ETCD_TXN_SUCCEEDED] = succeeded

    attrs.update(kwargs)
    return attrs


def build_batch_attributes(size: int, atomic: bool = False, **kwargs) -> Dict[str, Any]:
    """Build trace attributes for batch operations.

    Args:
        size: Number of operations in the batch
        atomic: Whether the batch is atomic
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.DB_SYSTEM: "etcd",
        TraceAttributes.ETCD_BATCH_SIZE: size,
        TraceAttributes.ETCD_BATCH_ATOMIC: atomic,
    }

    attrs.update(kwargs)
    return attrs


def build_endpoint_attributes(endpoint: str, **kwargs) -> Dict[str, Any]:
    """Build trace attributes for endpoint-related operations.

    Args:
        endpoint: The etcd endpoint
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {
        TraceAttributes.ETCD_ENDPOINT: endpoint,
    }

    attrs.update(kwargs)
    return attrs


def build_error_attributes(
    error_code: Optional[str] = None, error_message: Optional[str] = None, **kwargs
) -> Dict[str, Any]:
    """Build trace attributes for error cases.

    Args:
        error_code: Error code
        error_message: Error message
        **kwargs: Additional attributes

    Returns:
        Dictionary of trace attributes
    """
    attrs = {}

    if error_code is not None:
        attrs[TraceAttributes.ETCD_ERROR_CODE] = error_code

    if error_message is not None:
        # Truncate long error messages
        if len(error_message) > 256:
            error_message = error_message[:256] + "..."
        attrs[TraceAttributes.ETCD_ERROR_MESSAGE] = error_message

    attrs.update(kwargs)
    return attrs
