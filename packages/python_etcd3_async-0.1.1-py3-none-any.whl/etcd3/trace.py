"""OpenTelemetry tracing utilities for etcd3 client.

This module provides OpenTelemetry tracing support for etcd3 operations.
It automatically gets the tracer from the global tracer provider.
"""

import os
from contextlib import contextmanager
from typing import Optional, Dict, Any

OTEL_AVAILABLE = False
try:
    from opentelemetry import trace
    from opentelemetry.trace import SpanKind, Status, StatusCode
    from opentelemetry.trace.propagation.tracecontext import (
        TraceContextTextMapPropagator,
    )

    OTEL_AVAILABLE = True
except ImportError:
    pass

_tracer = None
_propagator = None
_tracing_initialized = False

ENV_PREFIX = "ETCD_OBS_"


def init_tracing(
    service_name: str = "etcd3-client",
    endpoint: Optional[str] = None,
    insecure: bool = True,
    sample_rate: float = 1.0,
):
    """Initialize tracing with optional OTLP exporter.

    Args:
        service_name: Name of the service for tracing
        endpoint: OTLP exporter endpoint (e.g., "localhost:4317")
        insecure: Whether to use insecure connection for OTLP
        sample_rate: Trace sampling rate (0.0-1.0)

    Returns:
        True if tracing was initialized successfully, False otherwise
    """
    global _tracer, _propagator, _tracing_initialized

    if not OTEL_AVAILABLE:
        return False

    try:
        # Check if user already set a global provider
        try:
            provider = trace.get_tracer_provider()
            # If user configured their own provider, use it
            if provider and hasattr(provider, "get_tracer"):
                _tracer = provider.get_tracer(service_name)
                _tracing_initialized = True
                return True
        except Exception:
            pass

        # Try to auto-configure OTLP exporter if endpoint is provided
        if endpoint is None:
            endpoint = os.environ.get(f"{ENV_PREFIX}OTLP_ENDPOINT")

        if endpoint:
            try:
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                    OTLPSpanExporter,
                )
                from opentelemetry.sdk.trace import TracerProvider
                from opentelemetry.sdk.trace.export import BatchSpanProcessor

                exporter = OTLPSpanExporter(
                    endpoint=endpoint,
                    insecure=insecure,
                )
                provider = TracerProvider()

                # Apply sampling if rate < 1.0
                if sample_rate < 1.0:
                    from opentelemetry.sdk.trace.sampling import TraceIdRatioBased

                    sampler = TraceIdRatioBased(sample_rate)
                    provider = TracerProvider(sampler=sampler)

                provider.add_span_processor(BatchSpanProcessor(exporter))
                trace.set_tracer_provider(provider)
            except ImportError:
                pass  # OTLP exporter not installed
        elif sample_rate < 1.0:
            # Configure sampler even without OTLP endpoint
            try:
                from opentelemetry.sdk.trace import TracerProvider
                from opentelemetry.sdk.trace.sampling import TraceIdRatioBased

                sampler = TraceIdRatioBased(sample_rate)
                provider = TracerProvider(sampler=sampler)
                trace.set_tracer_provider(provider)
            except ImportError:
                pass

        # Get tracer from provider
        provider = trace.get_tracer_provider()
        _tracer = provider.get_tracer(service_name)
        _propagator = TraceContextTextMapPropagator()
        _tracing_initialized = True
        return True
    except Exception:  # pylint: disable=broad-except
        _tracer = None
        _propagator = None
        _tracing_initialized = False
        return False


def get_tracer():
    """Get the tracer instance.

    Returns:
        Tracer instance or None if not available
    """
    global _tracer, _tracing_initialized
    if _tracer is None and OTEL_AVAILABLE and not _tracing_initialized:
        init_tracing()
    return _tracer


def is_tracing_available() -> bool:
    """Check if OpenTelemetry tracing is available.

    Returns:
        True if OpenTelemetry is installed and initialized, False otherwise
    """
    return OTEL_AVAILABLE and get_tracer() is not None


@contextmanager
def create_span(
    operation_name: str, attributes: Optional[Dict[str, Any]] = None, kind=None
):
    """Create a span context manager for tracing an operation.

    Args:
        operation_name: Name of the operation/span
        attributes: Optional attributes to add to the span
        kind: Optional span kind (default: CLIENT)

    Yields:
        Span object if tracing is available, None otherwise
    """
    tracer = get_tracer()
    if tracer is None:
        yield None
        return

    if kind is None:
        kind = SpanKind.CLIENT

    with tracer.start_as_current_span(operation_name, kind=kind) as span:
        if attributes:
            for key, value in attributes.items():
                if value is not None:
                    span.set_attribute(key, value)
        try:
            yield span
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise


def inject_context(carrier: dict):
    """Inject trace context into a carrier dictionary.

    Args:
        carrier: Dictionary to inject context into
    """
    if _propagator:
        _propagator.inject(carrier)


def extract_context(carrier: dict):
    """Extract trace context from a carrier dictionary.

    Args:
        carrier: Dictionary containing trace context

    Returns:
        Extracted context or None
    """
    if _propagator:
        return _propagator.extract(carrier)
    return None


def get_current_span():
    """Get the current active span.

    Returns:
        Current span or None
    """
    if not is_tracing_available():
        return None
    return trace.get_current_span()


def add_span_attribute(key: str, value: Any):
    """Add an attribute to the current span.

    Args:
        key: Attribute key
        value: Attribute value
    """
    span = get_current_span()
    if span:
        span.set_attribute(key, value)


def add_span_event(name: str, attributes: Optional[Dict[str, Any]] = None):
    """Add an event to the current span.

    Args:
        name: Event name
        attributes: Optional event attributes
    """
    span = get_current_span()
    if span:
        span.add_event(name, attributes=attributes or {})
