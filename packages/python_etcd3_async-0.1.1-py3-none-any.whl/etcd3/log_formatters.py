"""Logging formatters for etcd3 client.

This module provides structured logging formatters including JSON and colored
console output, with support for trace context integration.
"""

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any, Dict, Optional


class JSONFormatter(logging.Formatter):
    """JSON structured log formatter.

    Outputs logs as JSON objects with standardized fields for easy ingestion
    into log aggregation systems like ELK, Loki, or cloud logging services.

    Example output:
        {
            "timestamp": "2024-01-15T08:30:00.123456+00:00",
            "level": "INFO",
            "logger": "etcd3",
            "message": "Completed operation: kv.put",
            "operation": "kv.put",
            "trace_id": "abcd1234...",
            "span_id": "efgh5678...",
            "source": {
                "file": "etcd3/async_client_extensions.py",
                "line": 177,
                "function": "put"
            }
        }
    """

    def __init__(self, indent: Optional[int] = None):
        """Initialize JSON formatter.

        :param indent: Indentation for pretty-printing (None for compact)
        """
        super().__init__()
        self.indent = indent

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON.

        :param record: Log record to format
        :returns: JSON string
        """
        # Build base log data
        log_data: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add extra fields if present
        if hasattr(record, "operation") and record.operation:
            log_data["operation"] = record.operation

        if hasattr(record, "trace_id") and record.trace_id:
            log_data["trace_id"] = record.trace_id

        if hasattr(record, "span_id") and record.span_id:
            log_data["span_id"] = record.span_id

        if hasattr(record, "attributes") and record.attributes:
            log_data["attributes"] = record.attributes

        # Add exception info if present
        if record.exc_info:
            log_data["error"] = self.formatException(record.exc_info)

        # Add source location
        log_data["source"] = {
            "file": record.pathname,
            "line": record.lineno,
            "function": record.funcName,
        }

        return json.dumps(log_data, indent=self.indent, default=str)


class ColoredTextFormatter(logging.Formatter):
    """Colored text formatter for console output.

    Adds ANSI color codes to log output for better readability in terminals.
    Automatically detects if the output is a TTY and disables colors if not.
    """

    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[36m",  # Cyan
        "INFO": "\033[32m",  # Green
        "WARNING": "\033[33m",  # Yellow
        "ERROR": "\033[31m",  # Red
        "CRITICAL": "\033[35m",  # Magenta
        "RESET": "\033[0m",
        "BOLD": "\033[1m",
        "DIM": "\033[2m",
    }

    def __init__(self, include_trace: bool = True, fmt: Optional[str] = None):
        """Initialize colored formatter.

        :param include_trace: Whether to include trace context in output
        :param fmt: Optional format string override
        """
        super().__init__()
        self.include_trace = include_trace
        self.supports_color = sys.stderr.isatty()
        self.fmt = (
            fmt
            or "%(asctime)s %(levelcolor)s[%(levelname)s]%(reset)s %(name)s: %(message)s"
        )

    def _colorize(self, text: str, color: str) -> str:
        """Wrap text in color codes if supported.

        :param text: Text to colorize
        :param color: Color name
        :returns: Colorized or plain text
        """
        if not self.supports_color:
            return text
        reset = self.COLORS["RESET"]
        color_code = self.COLORS.get(color, "")
        return f"{color_code}{text}{reset}"

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with colors.

        :param record: Log record to format
        :returns: Formatted string
        """
        # Format timestamp
        record.asctime = self.formatTime(record)

        # Build main message
        parts = [
            record.asctime,
            self._colorize(f"[{record.levelname}]", record.levelname),
            record.name,
            ":",
            record.getMessage(),
        ]

        # Add trace context if enabled and available
        if self.include_trace:
            trace_parts = []
            if hasattr(record, "operation") and record.operation:
                trace_parts.append(f"op={record.operation}")
            if hasattr(record, "trace_id") and record.trace_id:
                short_trace = record.trace_id[:16]
                trace_parts.append(f"trace={short_trace}...")
            if hasattr(record, "span_id") and record.span_id:
                trace_parts.append(f"span={record.span_id[:8]}")

            if trace_parts:
                parts.append(self._colorize(f"({', '.join(trace_parts)})", "DIM"))

        # Add exception
        result = " ".join(parts)
        if record.exc_info:
            result += "\n" + self.formatException(record.exc_info)

        return result


class SimpleFormatter(logging.Formatter):
    """Simple text formatter with optional components.

    A more flexible version of the standard Formatter that allows
    enabling/disabling specific fields.
    """

    def __init__(
        self,
        fmt: Optional[str] = None,
        datefmt: Optional[str] = None,
        include_source: bool = False,
    ):
        """Initialize simple formatter.

        :param fmt: Format string
        :param datefmt: Date format string
        :param include_source: Whether to include source file/line
        """
        if fmt is None:
            parts = ["%(asctime)s", "[%(levelname)s]", "%(name)s:", "%(message)s"]
            if include_source:
                parts.append("(%(pathname)s:%(lineno)d)")
            fmt = " ".join(parts)

        super().__init__(fmt=fmt, datefmt=datefmt)


def configure_formatter(format_type: str = "text", **kwargs) -> logging.Formatter:
    """Create a configured formatter.

    Factory function to create formatters based on type.

    :param format_type: Type of formatter ("text", "json", "colored")
    :param kwargs: Additional arguments for specific formatter types
    :returns: Configured Formatter instance

    :raises ValueError: If format_type is not recognized

    Example:
        >>> formatter = configure_formatter("json", indent=2)
        >>> handler = logging.StreamHandler()
        >>> handler.setFormatter(formatter)
    """
    format_type = format_type.lower()

    if format_type == "json":
        return JSONFormatter(**kwargs)
    elif format_type == "colored":
        return ColoredTextFormatter(**kwargs)
    elif format_type == "text":
        return SimpleFormatter(**kwargs)
    else:
        raise ValueError(
            f"Unknown format_type: {format_type}. "
            "Choose from: 'text', 'json', 'colored'"
        )
