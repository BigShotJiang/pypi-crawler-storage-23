class Lease(object):
    """
    A lease.

    :ivar id: ID of the lease
    :ivar ttl: time to live for this lease
    """

    def __init__(self, lease_id, ttl, etcd_client=None):
        if ttl <= 0:
            raise ValueError("ttl must be a positive integer")
        self.id = lease_id
        self.ttl = ttl

        self.etcd_client = etcd_client

    def _get_lease_info(self):
        return self.etcd_client.get_lease_info(self.id)

    def revoke(self):
        """Revoke this lease."""
        self.etcd_client.revoke_lease(self.id)

    def refresh(self):
        """Refresh the time to live for this lease.

        Returns a generator that yields keep-alive responses.
        The caller should iterate over this generator to keep the lease alive.

        Example:
            for response in lease.refresh():
                # Lease is kept alive while iterating
                pass
        """
        return self.etcd_client.refresh_lease(self.id)

    @property
    def remaining_ttl(self):
        return self._get_lease_info().TTL

    @property
    def granted_ttl(self):
        return self._get_lease_info().grantedTTL

    @property
    def keys(self):
        return self._get_lease_info().keys


class AsyncLease(object):
    """
    An asynchronous lease.

    :ivar id: ID of the lease
    :ivar ttl: time to live for this lease
    """

    def __init__(self, lease_id, ttl, etcd_client=None):
        if ttl <= 0:
            raise ValueError("ttl must be a positive integer")
        self.id = lease_id
        self.ttl = ttl

        self.etcd_client = etcd_client

    async def _get_lease_info(self):
        """Get lease information from etcd."""
        return await self.etcd_client.get_lease_info(self.id)

    async def revoke(self):
        """Revoke this lease."""
        await self.etcd_client.revoke_lease(self.id)

    def refresh(self):
        """Refresh the time to live for this lease.

        Returns an async generator that yields keep-alive responses.
        """
        return self.etcd_client.refresh_lease(self.id)

    async def get_remaining_ttl(self):
        """Get the remaining time to live for this lease.

        :returns: remaining TTL in seconds
        :rtype: int
        """
        info = await self._get_lease_info()
        return info.TTL

    async def get_granted_ttl(self):
        """Get the granted time to live for this lease.

        :returns: granted TTL in seconds
        :rtype: int
        """
        info = await self._get_lease_info()
        return info.grantedTTL

    async def get_keys(self):
        """Get the keys attached to this lease.

        :returns: list of keys attached to this lease
        :rtype: list
        """
        info = await self._get_lease_info()
        return list(info.keys)
