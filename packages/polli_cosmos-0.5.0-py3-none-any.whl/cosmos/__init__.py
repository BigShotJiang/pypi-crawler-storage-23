"""Cosmos: ingest + crop toolkit.

Public SDK lives under `cosmos.sdk`.
"""

__all__ = [
    "sdk",
]
