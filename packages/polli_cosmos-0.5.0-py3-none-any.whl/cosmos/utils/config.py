from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AppConfig:
    """Placeholder for future config loader/saver."""

    version: int = 1
