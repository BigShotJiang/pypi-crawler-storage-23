"""
Framework integrations for Risicare SDK.

Provides automatic instrumentation for popular AI/agent frameworks:
- LangChain (callback handler + auto-injection)
- LangGraph (graph execution tracing)
- CrewAI (crew/agent/task tracing)
- AutoGen (agent conversation tracing, v0.2.x + v0.4+)
- OpenAI Agents SDK (runner/handoff tracing)
- Instructor (structured extraction tracing)
- LiteLLM (unified LLM proxy callback)
- DSPy (module/LM/tool callback)
- Pydantic AI (agent run tracing)
- LlamaIndex (span handler for queries, retrieval, LLM calls)
- OpenTelemetry SDK bridge (opt-in via otel_bridge=True)

All integrations are lazy-loaded and have zero hard dependencies on
the frameworks they instrument. If a framework is not installed,
the integration silently skips initialization.

Usage:
    # Automatic via import hooks (zero config):
    import risicare
    risicare.init(api_key="rsk-...")
    import langchain  # Automatically instrumented

    # Explicit:
    from risicare.integrations.langchain import instrument_langchain
    import langchain
    instrument_langchain(langchain)

    # Manual callback (LangChain only):
    from risicare.integrations.langchain import RisicareCallbackHandler
    chain.invoke(input, config={"callbacks": [RisicareCallbackHandler()]})

    # OpenTelemetry bridge:
    from risicare.integrations.otel import RisicareSpanExporter, RisicareSpanProcessor
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from risicare.integrations.langchain._callback import RisicareCallbackHandler
    from risicare.integrations.otel._bridge import (
        RisicareSpanExporter,
        RisicareSpanProcessor,
    )

__all__ = [
    "RisicareCallbackHandler",
    "RisicareSpanExporter",
    "RisicareSpanProcessor",
]


def __getattr__(name: str) -> Any:
    """Lazy re-export bridge classes to avoid import-time dependencies."""
    if name == "RisicareSpanExporter":
        from risicare.integrations.otel._bridge import RisicareSpanExporter
        return RisicareSpanExporter
    if name == "RisicareSpanProcessor":
        from risicare.integrations.otel._bridge import RisicareSpanProcessor
        return RisicareSpanProcessor
    if name == "RisicareCallbackHandler":
        from risicare.integrations.langchain._callback import RisicareCallbackHandler
        return RisicareCallbackHandler
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
