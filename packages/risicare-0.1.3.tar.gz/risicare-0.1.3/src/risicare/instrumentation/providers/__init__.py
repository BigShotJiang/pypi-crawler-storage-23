"""
LLM Provider instrumentation modules.

Each module provides automatic instrumentation for a specific LLM provider SDK:
- OpenAI (+ DeepSeek/vLLM/xAI/Fireworks/Baseten/Novita/BytePlus via base_url detection)
- Anthropic
- Cohere
- Google (Generative AI)
- Mistral
- Groq
- Together AI
- Ollama
- Amazon Bedrock (via botocore)
- Google Vertex AI
- Cerebras
- Hugging Face (InferenceClient)
"""

from risicare.instrumentation.providers.openai import instrument_openai
from risicare.instrumentation.providers.anthropic import instrument_anthropic
from risicare.instrumentation.providers.cohere import instrument_cohere
from risicare.instrumentation.providers.google import instrument_google
from risicare.instrumentation.providers.mistral import instrument_mistral
from risicare.instrumentation.providers.groq import instrument_groq
from risicare.instrumentation.providers.together import instrument_together
from risicare.instrumentation.providers.ollama import instrument_ollama
from risicare.instrumentation.providers.bedrock import instrument_bedrock
from risicare.instrumentation.providers.vertex_ai import instrument_vertex_ai
from risicare.instrumentation.providers.cerebras import instrument_cerebras
from risicare.instrumentation.providers.huggingface import instrument_huggingface

__all__ = [
    "instrument_openai",
    "instrument_anthropic",
    "instrument_cohere",
    "instrument_google",
    "instrument_mistral",
    "instrument_groq",
    "instrument_together",
    "instrument_ollama",
    "instrument_bedrock",
    "instrument_vertex_ai",
    "instrument_cerebras",
    "instrument_huggingface",
]
