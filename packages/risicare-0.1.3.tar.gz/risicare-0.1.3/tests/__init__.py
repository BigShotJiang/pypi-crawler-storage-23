"""Test package for risicare-sdk."""
