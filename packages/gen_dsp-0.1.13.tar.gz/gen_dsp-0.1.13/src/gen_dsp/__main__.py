"""
Entry point for running gen_dsp as a module: python -m gen_dsp
"""

from gen_dsp.cli import main

if __name__ == "__main__":
    main()
