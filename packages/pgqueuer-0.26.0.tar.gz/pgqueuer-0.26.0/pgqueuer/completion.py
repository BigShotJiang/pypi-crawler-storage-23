"""Backward-compatibility shim. Canonical: pgqueuer.core.completion"""

from pgqueuer.core.completion import CompletionWatcher

__all__ = [
    "CompletionWatcher",
]
