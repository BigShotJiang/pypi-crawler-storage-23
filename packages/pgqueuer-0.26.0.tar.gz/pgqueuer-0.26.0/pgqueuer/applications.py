"""Backward-compatibility shim. Canonical: pgqueuer.core.applications"""

from pgqueuer.core.applications import PgQueuer

__all__ = ["PgQueuer"]
