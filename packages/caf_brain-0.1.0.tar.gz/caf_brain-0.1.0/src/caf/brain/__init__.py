"""Common Analytical Framework package of Machine and Deep Learning tools."""

from ._version import __version__
