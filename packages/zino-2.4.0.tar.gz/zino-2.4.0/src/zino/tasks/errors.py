class DeviceUnreachableError(Exception):
    pass
