"""CLI package for the Gale-Shapley algorithm."""

from rich.console import Console

console = Console()
