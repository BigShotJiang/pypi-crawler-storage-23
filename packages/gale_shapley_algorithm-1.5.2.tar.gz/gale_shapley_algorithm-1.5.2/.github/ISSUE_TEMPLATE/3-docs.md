---
name: Documentation
about: Report a documentation issue or suggest an improvement
title: "docs: "
labels: documentation
assignees: oedokumaci
---

## Description

<!-- Describe the documentation issue or improvement. -->

## Location

<!-- Link to the relevant documentation page or section. -->

## Suggested change

<!-- What should the documentation say instead? -->
