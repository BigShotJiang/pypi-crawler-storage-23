import os
from setuptools import setup, find_packages

# Read the contents of your README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='coreimr',
    version='1.0.1', # Updated version to allow new publish
    description='Zero-dependency HTML to Image converter',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='CoreImR',
    packages=find_packages(),
    python_requires='>=3.6',
)
