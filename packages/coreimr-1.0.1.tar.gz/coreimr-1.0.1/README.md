# CoreImR

Advanced, Zero-dependency HTML, CSS, and JS to Image converter for Python.

It simply opens a temporary HTML file in a headless browser (Chrome or Edge) that is already installed on the system and takes a screenshot. 100% zero-dependency, lightweight, fast, and feature-rich!

## Features
- **Zero Dependencies**
- Configurable **Dimensions** (Width/Height)
- Support for **Transparent Backgrounds**
- **Delay / Virtual Time Budget** (wait for animations/JS to load before capture)

## Installation

```bash
pip install coreimr
```

## Usage

### Simple Example

```python
from coreimr import render

render('<h1>Hello!</h1>', 'output.png')
```

### Advanced Example

```python
from coreimr import CoreImR

html = """
<!DOCTYPE html>
<html>
<body style="background: rgba(0, 0, 255, 0.5); width: 100vw; height: 100vh; display: flex; align-items: center; justify-content: center;">
    <h1 style="color: white; font-family: sans-serif;">Advanced CoreImR!</h1>
</body>
</html>
"""

imr = CoreImR(width=1920, height=1080, transparent=True, delay=500)
imr.render(html, 'output_advanced.png')
```