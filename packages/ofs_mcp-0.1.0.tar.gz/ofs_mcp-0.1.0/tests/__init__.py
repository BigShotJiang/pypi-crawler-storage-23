"""Tests for ofs-mcp."""
