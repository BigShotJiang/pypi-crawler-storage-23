"""OFS MCP tool modules."""
