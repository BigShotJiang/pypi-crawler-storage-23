"""OFS MCP — NOAA Operational Forecast System MCP server."""
