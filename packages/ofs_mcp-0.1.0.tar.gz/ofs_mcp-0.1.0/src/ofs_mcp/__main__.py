"""Allow running the server with `python -m ofs_mcp`."""

from .server import main

main()
