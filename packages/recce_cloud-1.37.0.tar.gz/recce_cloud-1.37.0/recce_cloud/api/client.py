"""
Recce Cloud API clients for lightweight operations.

Provides clients for session management, organization/project listing, and report generation.
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional

import requests

from recce_cloud.api.exceptions import RecceCloudException

logger = logging.getLogger("recce")

RECCE_CLOUD_API_HOST = os.environ.get("RECCE_CLOUD_API_HOST", "https://cloud.datarecce.io")

DOCKER_INTERNAL_URL_PREFIX = "http://host.docker.internal"
LOCALHOST_URL_PREFIX = "http://localhost"


class RecceCloudClient:
    """
    Lightweight Recce Cloud API client.

    Supports authentication with Recce Cloud API token (starts with "rct-").
    """

    def __init__(self, token: str):
        if token is None:
            raise ValueError("Token cannot be None.")
        self.token = token
        self.base_url_v2 = f"{RECCE_CLOUD_API_HOST}/api/v2"

    def _request(self, method: str, url: str, headers: dict = None, **kwargs):
        """Make authenticated HTTP request to Recce Cloud API."""
        headers = {
            **(headers or {}),
            "Authorization": f"Bearer {self.token}",
        }
        return requests.request(method, url, headers=headers, **kwargs)

    def _safe_get_error_detail(self, response, default: str) -> str:
        """Safely extract error detail from response JSON.

        Some error responses may not have a valid JSON body (e.g., HTML error pages
        from proxies), so we need to handle JSONDecodeError gracefully.

        Args:
            response: The HTTP response object.
            default: Default message to return if JSON parsing fails.

        Returns:
            The error detail string from the response, or the default message.
        """
        try:
            return response.json().get("detail", default)
        except (json.JSONDecodeError, ValueError):
            return default

    def _replace_localhost_with_docker_internal(self, url: str) -> str:
        """Convert localhost URLs to docker internal URLs if running in Docker."""
        if url is None:
            return None
        if (
            os.environ.get("RECCE_SHARE_INSTANCE_ENV") == "docker"
            or os.environ.get("RECCE_TASK_INSTANCE_ENV") == "docker"
            or os.environ.get("RECCE_INSTANCE_ENV") == "docker"
        ):
            # For local development, convert the presigned URL from localhost to host.docker.internal
            if url.startswith(LOCALHOST_URL_PREFIX):
                return url.replace(LOCALHOST_URL_PREFIX, DOCKER_INTERNAL_URL_PREFIX)
        return url

    def get_session(self, session_id: str) -> dict:
        """
        Get session information from Recce Cloud.

        Args:
            session_id: The session ID to retrieve

        Returns:
            dict containing session information with keys:
                - org_id: Organization ID
                - project_id: Project ID
                - ... other session fields

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/sessions/{session_id}"
        response = self._request("GET", api_url)
        if response.status_code == 403:
            return {"status": "error", "message": self._safe_get_error_detail(response, "Permission denied")}
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )
        data = response.json()
        if data["success"] is not True:
            raise RecceCloudException(
                reason=data.get("message", "Unknown error"),
                status_code=response.status_code,
            )
        return data["session"]

    def get_upload_urls_by_session_id(self, org_id: str, project_id: str, session_id: str) -> dict:
        """
        Get presigned S3 upload URLs for a session.

        Args:
            org_id: Organization ID
            project_id: Project ID
            session_id: Session ID

        Returns:
            dict with keys:
                - manifest_url: Presigned URL for uploading manifest.json
                - catalog_url: Presigned URL for uploading catalog.json

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/upload-url"
        response = self._request("GET", api_url)
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )
        data = response.json()
        if data["presigned_urls"] is None:
            raise RecceCloudException(
                reason="No presigned URLs returned from the server.",
                status_code=404,
            )

        presigned_urls = data["presigned_urls"]
        for key, url in presigned_urls.items():
            presigned_urls[key] = self._replace_localhost_with_docker_internal(url)
        return presigned_urls

    def get_download_urls_by_session_id(self, org_id: str, project_id: str, session_id: str) -> dict:
        """
        Get presigned S3 download URLs for a session.

        Args:
            org_id: Organization ID
            project_id: Project ID
            session_id: Session ID

        Returns:
            dict with keys:
                - manifest_url: Presigned URL for downloading manifest.json
                - catalog_url: Presigned URL for downloading catalog.json

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/download-url"
        response = self._request("GET", api_url)
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )
        data = response.json()
        if data["presigned_urls"] is None:
            raise RecceCloudException(
                reason="No presigned URLs returned from the server.",
                status_code=404,
            )

        presigned_urls = data["presigned_urls"]
        for key, url in presigned_urls.items():
            presigned_urls[key] = self._replace_localhost_with_docker_internal(url)
        return presigned_urls

    def update_session(self, org_id: str, project_id: str, session_id: str, adapter_type: str) -> dict:
        """
        Update session metadata with adapter type.

        Args:
            org_id: Organization ID
            project_id: Project ID
            session_id: Session ID
            adapter_type: dbt adapter type (e.g., "postgres", "snowflake", "bigquery")

        Returns:
            dict containing updated session information

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}"
        data = {"adapter_type": adapter_type}
        response = self._request("PATCH", api_url, json=data)
        if response.status_code == 403:
            return {"status": "error", "message": self._safe_get_error_detail(response, "Permission denied")}
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )
        return response.json()

    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session by ID.

        This uses the user interactive endpoint DELETE /sessions/{session_id}.
        If the session is a base session, it will be automatically unbound first.

        Args:
            session_id: Session ID to delete

        Returns:
            True if deletion was successful

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/sessions/{session_id}"
        response = self._request("DELETE", api_url)
        if response.status_code == 204:
            return True
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code == 404:
            raise RecceCloudException(
                reason="Session not found",
                status_code=response.status_code,
            )
        raise RecceCloudException(
            reason=response.text,
            status_code=response.status_code,
        )

    def upload_completed(self, session_id: str) -> dict:
        """
        Notify Recce Cloud that upload is complete for a session.

        This triggers post-upload processing such as AI summary generation.

        Args:
            session_id: Session ID to notify completion for

        Returns:
            dict containing acknowledgement or empty dict

        Raises:
            RecceCloudException: If the request fails
        """
        api_url = f"{self.base_url_v2}/sessions/{session_id}/upload-completed"
        response = self._request("POST", api_url)
        if response.status_code in [200, 204]:
            if response.status_code == 204 or not response.content:
                return {}
            return response.json()
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code == 404:
            raise RecceCloudException(
                reason="Session not found",
                status_code=response.status_code,
            )
        raise RecceCloudException(
            reason=response.text,
            status_code=response.status_code,
        )

    def list_organizations(self) -> List[Dict[str, Any]]:
        """
        List all organizations the user has access to.

        Returns:
            List of organization dictionaries with id, name, slug fields.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations"
        response = self._request("GET", api_url)

        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        data = response.json()
        return data.get("organizations", [])

    def list_projects(self, org_id: str) -> List[Dict[str, Any]]:
        """
        List all projects in an organization.

        Args:
            org_id: Organization ID or slug.

        Returns:
            List of project dictionaries with id, name, slug fields.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects"
        response = self._request("GET", api_url)

        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        data = response.json()
        return data.get("projects", [])

    def get_organization(self, org_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific organization by ID or slug.

        Args:
            org_id: Organization ID or slug.

        Returns:
            Organization dictionary, or None if not found.

        Raises:
            RecceCloudException: If the API call fails.
        """
        orgs = self.list_organizations()
        for org in orgs:
            # Compare as strings to handle both int and str IDs
            if str(org.get("id")) == str(org_id) or org.get("slug") == org_id or org.get("name") == org_id:
                return org
        return None

    def get_project(self, org_id: str, project_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific project by ID or slug.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.

        Returns:
            Project dictionary, or None if not found.

        Raises:
            RecceCloudException: If the API call fails.
        """
        projects = self.list_projects(org_id)
        for project in projects:
            # Compare as strings to handle both int and str IDs
            if (
                str(project.get("id")) == str(project_id)
                or project.get("slug") == project_id
                or project.get("name") == project_id
            ):
                return project
        return None

    def list_sessions(
        self,
        org_id: str,
        project_id: str,
        session_name: Optional[str] = None,
        session_type: Optional[str] = None,
        branch: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        List sessions in a project with optional filtering.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_name: Filter by session name (exact match).
            session_type: Filter by session type (e.g., "pr", "prod", "manual").
            branch: Filter by branch name (exact match).
            limit: Maximum number of results to return (1-1000).
            offset: Number of results to skip for pagination.

        Returns:
            List of session dictionaries.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions"
        params = {}
        if session_name:
            params["name"] = session_name
        if session_type:
            params["type"] = session_type
        if branch:
            params["branch"] = branch
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        response = self._request("GET", api_url, params=params if params else None)

        if response.status_code == 404:
            raise RecceCloudException(
                reason="Organization or project not found",
                status_code=response.status_code,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        data = response.json()
        return data.get("sessions", [])

    def get_session_by_name(
        self,
        org_id: str,
        project_id: str,
        session_name: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get a session by its name.

        Uses the list sessions endpoint with filtering to find a session
        by name, which is unique within a project.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_name: The session name to look up.

        Returns:
            Session dictionary if found, None otherwise.

        Raises:
            RecceCloudException: If the API call fails.
        """
        sessions = self.list_sessions(
            org_id=org_id,
            project_id=project_id,
            session_name=session_name,
            limit=1,
        )
        if sessions:
            return sessions[0]
        return None

    def create_session(
        self,
        org_id: str,
        project_id: str,
        session_name: str,
        adapter_type: Optional[str] = None,
        session_type: str = "manual",
    ) -> Dict[str, Any]:
        """
        Create a new session with the given name.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_name: The name for the new session.
            adapter_type: dbt adapter type (e.g., "postgres", "snowflake").
            session_type: Session type (default: "manual").

        Returns:
            Created session dictionary with id, name, and other fields.

        Raises:
            RecceCloudException: If the API call fails or session creation fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions"
        data = {
            "name": session_name,
            "type": session_type,
        }
        if adapter_type:
            data["adapter_type"] = adapter_type

        response = self._request("POST", api_url, json=data)

        if response.status_code == 404:
            raise RecceCloudException(
                reason="Organization or project not found",
                status_code=response.status_code,
            )
        if response.status_code == 409:
            raise RecceCloudException(
                reason=f"Session with name '{session_name}' already exists",
                status_code=response.status_code,
            )
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code not in [200, 201]:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        result = response.json()
        # Handle both direct session response and wrapped response
        if "session" in result:
            return result["session"]
        return result

    def check_prerequisites(
        self,
        org_id: str,
        project_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """
        Check prerequisites for data review generation.

        This calls the backend API to verify:
        1. Session exists and belongs to the project
        2. Session has artifacts uploaded (adapter_type is set)
        3. Base session exists for the project
        4. Base session has artifacts uploaded

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_id: Session ID to check.

        Returns:
            dict with:
                - success: bool
                - session_id: str
                - session_name: str
                - adapter_type: str or None
                - has_base_session: bool
                - base_session_has_artifacts: bool
                - is_ready: bool
                - reason: str or None (explains why not ready)

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = (
            f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/check-prerequisites"
        )
        response = self._request("GET", api_url)

        if response.status_code == 404:
            error_detail = "Session or project not found"
            try:
                error_detail = response.json().get("detail", error_detail)
            except Exception:
                pass
            raise RecceCloudException(
                reason=error_detail,
                status_code=response.status_code,
            )
        if response.status_code == 400:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Bad request"),
                status_code=response.status_code,
            )
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        return response.json()

    def generate_data_review(
        self,
        org_id: str,
        project_id: str,
        session_id: str,
        regenerate: bool = False,
    ) -> Dict[str, Any]:
        """
        Trigger data review generation for a session.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_id: Session ID to generate review for.
            regenerate: If True, regenerate even if a review already exists.

        Returns:
            dict with task_id if a new task was created, or empty if review already exists.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/recce_summary"
        data = {"regenerate": regenerate}

        response = self._request("POST", api_url, json=data)

        if response.status_code == 404:
            raise RecceCloudException(
                reason="Session not found",
                status_code=response.status_code,
            )
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code == 400:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Bad request"),
                status_code=response.status_code,
            )
        if response.status_code not in [200, 201, 202]:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        return response.json()

    def get_data_review(
        self,
        org_id: str,
        project_id: str,
        session_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get the existing data review for a session.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_id: Session ID to get review for.

        Returns:
            dict with session_id, session_name, summary (content), trace_id if found.
            None if no review exists.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/recce_summary"
        response = self._request("GET", api_url)

        if response.status_code == 404:
            # No review exists for this session
            return None
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        return response.json()

    def get_running_task(
        self,
        org_id: str,
        project_id: str,
        session_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get the currently running task for a session.

        Args:
            org_id: Organization ID or slug.
            project_id: Project ID or slug.
            session_id: Session ID to check.

        Returns:
            dict with task_id and status if a task is running, None otherwise.

        Raises:
            RecceCloudException: If the API call fails.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/projects/{project_id}/sessions/{session_id}/running_task"
        response = self._request("GET", api_url)

        if response.status_code == 404:
            return None
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        data = response.json()
        # Return None if no task is running
        if data.get("task_id") is None:
            return None
        return data

    def get_task_status(self, org_id: str, task_id: str) -> Dict[str, Any]:
        """
        Get the status of a task by ID.

        Args:
            org_id: Organization ID or slug.
            task_id: Task ID to check.

        Returns:
            dict with id, command, status, created_at, started_at, finished_at, metadata.

        Raises:
            RecceCloudException: If the API call fails or task not found.
        """
        api_url = f"{self.base_url_v2}/organizations/{org_id}/tasks/{task_id}/status"
        response = self._request("GET", api_url)

        if response.status_code == 404:
            raise RecceCloudException(
                reason="Task not found",
                status_code=response.status_code,
            )
        if response.status_code == 403:
            raise RecceCloudException(
                reason=self._safe_get_error_detail(response, "Permission denied"),
                status_code=response.status_code,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        return response.json()


class ReportClient:
    """Client for fetching reports from Recce Cloud API."""

    def __init__(self, token: str):
        if token is None:
            raise ValueError("Token cannot be None.")
        self.token = token
        self.base_url_v2 = f"{RECCE_CLOUD_API_HOST}/api/v2"

    def _request(self, method: str, url: str, headers: dict = None, **kwargs):
        """
        Make authenticated HTTP request to Recce Cloud API.

        Raises:
            RecceCloudException: If network error occurs
        """
        headers = {
            **(headers or {}),
            "Authorization": f"Bearer {self.token}",
        }
        try:
            return requests.request(method, url, headers=headers, timeout=60, **kwargs)
        except requests.exceptions.Timeout as e:
            logger.error(f"Request timeout: {e}")
            raise RecceCloudException(
                reason="Request timed out. Please try again.",
                status_code=0,
            )
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e}")
            raise RecceCloudException(
                reason="Failed to connect to Recce Cloud API. Please check your network connection.",
                status_code=0,
            )
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            raise RecceCloudException(
                reason=f"Network error: {str(e)}",
                status_code=0,
            )

    def get_pr_metrics(
        self,
        repo: str,
        since: str = "30d",
        until: Optional[str] = None,
        base_branch: str = "main",
        merged_only: bool = True,
    ):
        """
        Fetch PR metrics report from Recce Cloud API.

        Args:
            repo: Repository full name (owner/repo)
            since: Start date (ISO format or relative like 30d)
            until: End date (ISO format or relative). Defaults to today.
            base_branch: Target branch filter
            merged_only: Only include merged PRs

        Returns:
            PRMetricsReport containing all metrics

        Raises:
            RecceCloudException: If the request fails
        """
        # Import here to avoid circular import
        from recce_cloud.report import PRMetrics, PRMetricsReport, SummaryStatistics

        api_url = f"{self.base_url_v2}/reports/pr-metrics"

        params = {
            "repo": repo,
            "since": since,
            "base_branch": base_branch,
            "merged_only": str(merged_only).lower(),
        }
        if until:
            params["until"] = until

        response = self._request("GET", api_url, params=params)

        if response.status_code == 401:
            raise RecceCloudException(
                reason="Invalid or missing API token",
                status_code=401,
            )
        if response.status_code == 404:
            raise RecceCloudException(
                reason=f"Repository not found: {repo}",
                status_code=404,
            )
        if response.status_code == 400:
            try:
                error_detail = response.json().get("detail", "Bad request")
            except json.JSONDecodeError:
                error_detail = "Bad request"
            raise RecceCloudException(
                reason=error_detail,
                status_code=400,
            )
        if response.status_code == 502:
            try:
                error_detail = response.json().get("detail", "Upstream API error")
            except json.JSONDecodeError:
                error_detail = "Upstream API error"
            raise RecceCloudException(
                reason=error_detail,
                status_code=502,
            )
        if response.status_code != 200:
            raise RecceCloudException(
                reason=response.text,
                status_code=response.status_code,
            )

        try:
            data = response.json()
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse API response: {e}")
            raise RecceCloudException(
                reason="Invalid response from API",
                status_code=response.status_code,
            )

        # Parse pull requests
        pull_requests = []
        for pr in data.get("pull_requests", []):
            pull_requests.append(
                PRMetrics(
                    pr_number=pr.get("pr_number", 0),
                    pr_title=pr.get("pr_title", ""),
                    pr_state=pr.get("pr_state", "unknown"),
                    pr_url=pr.get("pr_url", ""),
                    pr_author=pr.get("pr_author"),
                    pr_created_at=pr.get("pr_created_at"),
                    pr_merged_at=pr.get("pr_merged_at"),
                    time_to_merge=pr.get("time_to_merge"),
                    commits_before_pr_open=pr.get("commits_before_pr_open", 0),
                    commits_after_pr_open=pr.get("commits_after_pr_open", 0),
                    commits_after_summary=pr.get("commits_after_summary"),
                    commits_fetch_failed=pr.get("commits_fetch_failed", False),
                    has_recce_session=pr.get("has_recce_session", False),
                    recce_session_url=pr.get("recce_session_url"),
                    recce_checks_count=pr.get("recce_checks_count"),
                    recce_check_types=pr.get("recce_check_types"),
                    recce_summary_generated=pr.get("recce_summary_generated"),
                    recce_summary_at=pr.get("recce_summary_at"),
                )
            )

        # Parse summary statistics
        summary_data = data.get("summary", {})
        summary = SummaryStatistics(
            total_prs=summary_data.get("total_prs", len(pull_requests)),
            prs_merged=summary_data.get("prs_merged", 0),
            prs_open=summary_data.get("prs_open", 0),
            prs_with_recce_session=summary_data.get("prs_with_recce_session", 0),
            prs_with_recce_summary=summary_data.get("prs_with_recce_summary", 0),
            recce_adoption_rate=summary_data.get("recce_adoption_rate", 0.0),
            summary_generation_rate=summary_data.get("summary_generation_rate", 0.0),
            total_commits_before_pr_open=summary_data.get("total_commits_before_pr_open", 0),
            total_commits_after_pr_open=summary_data.get("total_commits_after_pr_open", 0),
            total_commits_after_summary=summary_data.get("total_commits_after_summary", 0),
            avg_commits_before_pr_open=summary_data.get("avg_commits_before_pr_open", 0.0),
            avg_commits_after_pr_open=summary_data.get("avg_commits_after_pr_open", 0.0),
            avg_commits_after_summary=summary_data.get("avg_commits_after_summary"),
            avg_time_to_merge=summary_data.get("avg_time_to_merge"),
        )

        date_range = data.get("date_range", {})
        return PRMetricsReport(
            success=data.get("success", True),
            repo=data.get("repo", repo),
            date_range_since=date_range.get("since", ""),
            date_range_until=date_range.get("until", ""),
            summary=summary,
            pull_requests=pull_requests,
        )
