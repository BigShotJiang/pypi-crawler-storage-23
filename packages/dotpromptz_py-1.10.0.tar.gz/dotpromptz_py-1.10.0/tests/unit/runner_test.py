"""Unit tests for the dotpromptz runner module."""

import asyncio
import json
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from dotpromptz.adapters._base import Adapter, GenerateResponse, ImageResult, ToolCallResult
from dotpromptz.runner import (
    BatchAbortError,
    BatchResult,
    _classify_error,
    _compute_delay,
    _execute_with_retry,
    _extract_status_code,
    aggregate_batch_results,
    extract_response_content,
    part_to_dict,
    resolve_adapter,
    run_batch,
    run_single,
    serialize_result,
    write_output,
)
from dotpromptz.typing import ErrorAction, ErrorHandlerRule, RetryConfig, RuntimeConfig

SIMPLE_PROMPT = """\
---
config:
  model: gpt-4o
input:
  schema:
    topic: string
---
Tell me about {{topic}}.
"""


def _make_adapter(*, text: str = 'response', side_effect: Exception | None = None) -> Adapter:
    """Create a mock adapter with a configurable generate response."""
    adapter = MagicMock(spec=Adapter)
    if side_effect:
        adapter.generate = AsyncMock(side_effect=side_effect)
    else:
        adapter.generate = AsyncMock(
            return_value=GenerateResponse(text=text),
        )
    return adapter


class TestRunSingle:
    @pytest.mark.asyncio
    async def test_basic_execution(self) -> None:
        adapter = _make_adapter(text='Hello AI')
        response = await run_single(SIMPLE_PROMPT, {'topic': 'AI'}, adapter)
        assert response.text == 'Hello AI'
        adapter.generate.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_propagates_adapter_error(self) -> None:
        adapter = _make_adapter(side_effect=RuntimeError('API timeout'))
        with pytest.raises(RuntimeError, match='API timeout'):
            await run_single(SIMPLE_PROMPT, {'topic': 'AI'}, adapter)

    @pytest.mark.asyncio
    async def test_reuses_provided_dp(self) -> None:
        from dotpromptz import Dotprompt

        dp = Dotprompt()
        adapter = _make_adapter(text='reuse test')
        response = await run_single(SIMPLE_PROMPT, {'topic': 'AI'}, adapter, dp=dp)
        assert response.text == 'reuse test'


class TestRunBatch:
    @pytest.mark.asyncio
    async def test_basic_batch(self) -> None:
        adapter = _make_adapter(text='result')
        inputs = [{'topic': 'AI'}, {'topic': 'ML'}, {'topic': 'DL'}]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter)

        assert len(results) == 3
        assert all(r.status == 'success' for r in results)
        assert all(r.response is not None for r in results)
        assert all(r.error is None for r in results)
        # Verify sorted by index
        assert [r.index for r in results] == [0, 1, 2]

    @pytest.mark.asyncio
    async def test_batch_preserves_input(self) -> None:
        adapter = _make_adapter(text='ok')
        inputs = [{'topic': 'AI'}, {'topic': 'ML'}]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter)

        assert results[0].input == {'topic': 'AI'}
        assert results[1].input == {'topic': 'ML'}

    @pytest.mark.asyncio
    async def test_batch_handles_partial_failures(self) -> None:
        """When some items fail, they get status='error' while others succeed."""
        call_count = 0

        async def _generate_with_failure(rendered: Any, **kwargs: Any) -> GenerateResponse:
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise RuntimeError('Item 2 failed')
            return GenerateResponse(text=f'result_{call_count}')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_generate_with_failure)

        inputs = [{'topic': 'AI'}, {'topic': 'ML'}, {'topic': 'DL'}]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter)

        assert len(results) == 3
        # One should have failed
        errors = [r for r in results if r.status == 'error']
        successes = [r for r in results if r.status == 'success']
        assert len(errors) == 1
        assert len(successes) == 2
        assert errors[0].error == 'Item 2 failed'
        assert errors[0].response is None

    @pytest.mark.asyncio
    async def test_batch_all_failures(self) -> None:
        adapter = _make_adapter(side_effect=RuntimeError('all fail'))
        inputs = [{'topic': 'AI'}, {'topic': 'ML'}]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter)

        assert len(results) == 2
        assert all(r.status == 'error' for r in results)
        assert all('all fail' in r.error for r in results)

    @pytest.mark.asyncio
    async def test_batch_respects_max_workers(self) -> None:
        """Verify concurrency is limited by max_workers."""
        concurrent_count = 0
        max_concurrent = 0

        async def _counting_generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            nonlocal concurrent_count, max_concurrent
            concurrent_count += 1
            max_concurrent = max(max_concurrent, concurrent_count)
            await asyncio.sleep(0.01)  # Small delay to allow overlap
            concurrent_count -= 1
            return GenerateResponse(text='ok')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_counting_generate)

        inputs = [{'topic': f't{i}'} for i in range(10)]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter, max_workers=2)

        assert len(results) == 10
        assert all(r.status == 'success' for r in results)
        assert max_concurrent <= 2

    @pytest.mark.asyncio
    async def test_batch_on_item_complete_callback(self) -> None:
        adapter = _make_adapter(text='done')
        completed: list[BatchResult] = []

        def _on_complete(result: BatchResult) -> None:
            completed.append(result)

        inputs = [{'topic': 'AI'}, {'topic': 'ML'}]
        results = await run_batch(
            SIMPLE_PROMPT,
            inputs,
            adapter,
            on_item_complete=_on_complete,
        )

        assert len(completed) == 2
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_batch_empty_input_list(self) -> None:
        adapter = _make_adapter(text='unused')
        results = await run_batch(SIMPLE_PROMPT, [], adapter)
        assert results == []
        adapter.generate.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_batch_reuses_provided_dp(self) -> None:
        from dotpromptz import Dotprompt

        dp = Dotprompt()
        adapter = _make_adapter(text='reused')
        inputs = [{'topic': 'AI'}]
        results = await run_batch(SIMPLE_PROMPT, inputs, adapter, dp=dp)

        assert len(results) == 1
        assert results[0].status == 'success'


class TestBatchResult:
    def test_dataclass_defaults(self) -> None:
        r = BatchResult(index=0, input={'a': 1}, status='success')
        assert r.response is None
        assert r.error is None

    def test_success_result(self) -> None:
        resp = GenerateResponse(text='hello')
        r = BatchResult(index=1, input={'x': 'y'}, status='success', response=resp)
        assert r.status == 'success'
        assert r.response.text == 'hello'
        assert r.error is None

    def test_error_result(self) -> None:
        r = BatchResult(index=2, input={'x': 'y'}, status='error', error='boom')
        assert r.status == 'error'
        assert r.response is None
        assert r.error == 'boom'


class TestResolveAdapter:
    def test_adapter_config_object(self) -> None:
        from unittest.mock import patch

        from dotpromptz.credentials import Credential, CredentialPool
        from dotpromptz.typing import AdapterConfig

        cred = Credential(name='test', adapter='openai', api_key='sk-test')
        pool = CredentialPool([cred])
        mock_rendered = MagicMock()
        mock_rendered.adapter = AdapterConfig(name='openai')
        mock_rendered.config = {}

        with patch('dotpromptz.runner.get_adapter') as mock_get_adapter:
            resolve_adapter(mock_rendered, pool=pool)
            mock_get_adapter.assert_called_once_with('openai', credential=cred)

    def test_adapter_config_with_group(self) -> None:
        from unittest.mock import patch

        from dotpromptz.credentials import Credential, CredentialPool
        from dotpromptz.typing import AdapterConfig

        cred_east = Credential(name='east', adapter='openai', api_key='sk-east')
        cred_west = Credential(name='west', adapter='openai', api_key='sk-west')
        pool = CredentialPool([cred_east, cred_west])
        mock_rendered = MagicMock()
        mock_rendered.adapter = AdapterConfig(name='openai', group='east')
        mock_rendered.config = {}

        with patch('dotpromptz.runner.get_adapter') as mock_get_adapter:
            resolve_adapter(mock_rendered, pool=pool)
            mock_get_adapter.assert_called_once_with('openai', credential=cred_east)

    def test_string_adapter(self) -> None:
        from unittest.mock import patch

        from dotpromptz.credentials import Credential, CredentialPool

        cred = Credential(name='main', adapter='anthropic', api_key='sk-test')
        pool = CredentialPool([cred])
        mock_rendered = MagicMock()
        mock_rendered.adapter = 'anthropic'
        mock_rendered.config = {}

        with patch('dotpromptz.runner.get_adapter') as mock_get_adapter:
            resolve_adapter(mock_rendered, pool=pool)
            mock_get_adapter.assert_called_once_with('anthropic', credential=cred)

    def test_none_adapter_raises_value_error(self) -> None:
        mock_rendered = MagicMock()
        mock_rendered.adapter = None

        with pytest.raises(ValueError, match='No adapter specified'):
            resolve_adapter(mock_rendered)

    def test_empty_string_adapter_raises_value_error(self) -> None:
        mock_rendered = MagicMock()
        mock_rendered.adapter = ''

        with pytest.raises(ValueError, match='No adapter specified'):
            resolve_adapter(mock_rendered)


class TestSerializeResult:
    def test_json_dict(self) -> None:
        import json

        result = serialize_result({'key': 'value'}, 'json')
        assert json.loads(result) == {'key': 'value'}

    def test_json_string_pretty_prints(self) -> None:
        import json

        result = serialize_result('{"a": 1}', 'json')
        parsed = json.loads(result)
        assert parsed == {'a': 1}
        # Pretty-printed means it has newlines
        assert '\n' in result

    def test_json_non_json_string(self) -> None:
        import json

        result = serialize_result('plain text', 'json')
        assert json.loads(result) == 'plain text'

    def test_txt_format(self) -> None:
        result = serialize_result({'key': 'value'}, 'txt')
        assert result == str({'key': 'value'})

    def test_txt_string(self) -> None:
        result = serialize_result('hello', 'txt')
        assert result == 'hello'

    def test_yaml_format(self) -> None:
        result = serialize_result({'name': 'Alice', 'age': 30}, 'yaml')
        assert 'name: Alice' in result
        assert 'age: 30' in result

    def test_yaml_from_json_string(self) -> None:
        result = serialize_result('{"x": 1}', 'yaml')
        assert 'x: 1' in result

    def test_yaml_missing_raises(self) -> None:
        # yaml is installed in this env; verify the error message format
        # by confirming the RuntimeError path exists in serialize_result.
        pass  # yaml is installed — cannot realistically unload C extension


class TestPartToDict:
    def test_text_part(self) -> None:
        from dotpromptz.typing import TextPart

        result = part_to_dict(TextPart(text='hello'))
        assert result == {'text': 'hello'}

    def test_media_part(self) -> None:
        from dotpromptz.typing import MediaContent, MediaPart

        part = MediaPart(media=MediaContent(url='https://example.com/img.png', content_type='image/png'))
        result = part_to_dict(part)
        assert 'media' in result
        assert result['media']['url'] == 'https://example.com/img.png'

    def test_data_part(self) -> None:
        from dotpromptz.typing import DataPart

        result = part_to_dict(DataPart(data={'key': 'value'}))
        assert result == {'data': {'key': 'value'}}

    def test_tool_request_part(self) -> None:
        from dotpromptz.typing import ToolRequestContent, ToolRequestPart

        part = ToolRequestPart(tool_request=ToolRequestContent(name='search', input={'q': 'test'}))
        result = part_to_dict(part)
        assert 'tool_request' in result
        assert result['tool_request']['name'] == 'search'

    def test_tool_response_part(self) -> None:
        from dotpromptz.typing import ToolResponseContent, ToolResponsePart

        part = ToolResponsePart(tool_response=ToolResponseContent(name='search', output={'result': 1}))
        result = part_to_dict(part)
        assert 'tool_response' in result
        assert result['tool_response']['name'] == 'search'

    def test_unknown_part_type(self) -> None:
        class FakePart:
            pass

        result = part_to_dict(FakePart())
        assert result == {'type': 'FakePart'}


class TestWriteOutput:
    def test_writes_text_file(self, tmp_path: Path) -> None:
        from dotpromptz.typing import PromptOutputConfig

        cfg = PromptOutputConfig(format='json', file_name='output')
        result = write_output('{"a": 1}', cfg, tmp_path, 'result')
        assert result == tmp_path / 'result.json'
        assert result.read_text(encoding='utf-8') == '{"a": 1}'

    def test_writes_bytes_file(self, tmp_path: Path) -> None:
        from dotpromptz.typing import PromptOutputConfig

        cfg = PromptOutputConfig(format='image', file_name='output')
        data = b'\x89PNG\r\n'
        result = write_output(data, cfg, tmp_path, 'pic')
        assert result == tmp_path / 'pic.png'
        assert result.read_bytes() == data

    def test_creates_nested_directories(self, tmp_path: Path) -> None:
        from dotpromptz.typing import PromptOutputConfig

        cfg = PromptOutputConfig(format='txt', file_name='output')
        nested = tmp_path / 'a' / 'b' / 'c'
        result = write_output('hello', cfg, nested, 'out')
        assert result == nested / 'out.txt'
        assert result.read_text(encoding='utf-8') == 'hello'

    def test_yaml_extension(self, tmp_path: Path) -> None:
        from dotpromptz.typing import PromptOutputConfig

        cfg = PromptOutputConfig(format='yaml', file_name='output')
        result = write_output('name: Alice', cfg, tmp_path, 'data')
        assert result.suffix == '.yaml'

    def test_overwrites_existing_file(self, tmp_path: Path) -> None:
        from dotpromptz.typing import PromptOutputConfig

        cfg = PromptOutputConfig(format='txt', file_name='output')
        filepath = tmp_path / 'out.txt'
        filepath.write_text('old', encoding='utf-8')
        write_output('new', cfg, tmp_path, 'out')
        assert filepath.read_text(encoding='utf-8') == 'new'


class TestExtractResponseContent:
    def test_text_json(self) -> None:
        response = GenerateResponse(text='{"key": "value"}')
        result = extract_response_content(response, 'json')
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert parsed == {'key': 'value'}

    def test_text_yaml(self) -> None:
        response = GenerateResponse(text='{"x": 1}')
        result = extract_response_content(response, 'yaml')
        assert isinstance(result, str)
        assert 'x: 1' in result

    def test_text_txt(self) -> None:
        response = GenerateResponse(text='plain output')
        result = extract_response_content(response, 'txt')
        assert result == 'plain output'

    def test_image_returns_bytes(self) -> None:
        img_data = b'\x89PNG_DATA'
        response = GenerateResponse(image=ImageResult(data=img_data, mime_type='image/png'))
        result = extract_response_content(response, 'image')
        assert isinstance(result, bytes)
        assert result == img_data

    def test_image_no_data_raises(self) -> None:
        response = GenerateResponse(text='no image here')
        with pytest.raises(ValueError, match='Expected image output'):
            extract_response_content(response, 'image')

    def test_tool_calls_json(self) -> None:
        tc = ToolCallResult(id='tc1', name='search', arguments={'q': 'test'})
        response = GenerateResponse(tool_calls=[tc])
        result = extract_response_content(response, 'json')
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        assert parsed[0]['name'] == 'search'

    def test_empty_response(self) -> None:
        response = GenerateResponse()
        result = extract_response_content(response, 'json')
        assert result == ''

    def test_text_takes_priority_over_tool_calls(self) -> None:
        tc = ToolCallResult(id='tc1', name='search', arguments={'q': 'test'})
        response = GenerateResponse(text='priority text', tool_calls=[tc])
        result = extract_response_content(response, 'txt')
        assert result == 'priority text'


class TestAggregateBatchResults:
    def test_basic_aggregation(self) -> None:
        results = [
            BatchResult(index=0, input={'a': '1'}, status='success', response=GenerateResponse(text='{"v": 1}')),
            BatchResult(index=1, input={'a': '2'}, status='success', response=GenerateResponse(text='{"v": 2}')),
        ]
        agg = aggregate_batch_results(results, 'json', 'out')
        assert 'out_0' in agg
        assert 'out_1' in agg
        assert agg['out_0'] == {'v': 1}
        assert agg['out_1'] == {'v': 2}

    def test_error_results(self) -> None:
        results = [
            BatchResult(index=0, input={}, status='error', error='boom'),
        ]
        agg = aggregate_batch_results(results, 'json', 'result')
        assert agg['result_0'] == {'error': 'boom'}

    def test_tool_calls(self) -> None:
        tc = ToolCallResult(id='tc1', name='fn', arguments={'x': 1})
        results = [
            BatchResult(index=0, input={}, status='success', response=GenerateResponse(tool_calls=[tc])),
        ]
        agg = aggregate_batch_results(results, 'json', 'out')
        assert isinstance(agg['out_0'], list)
        assert agg['out_0'][0]['name'] == 'fn'

    def test_empty_response_is_none(self) -> None:
        results = [
            BatchResult(index=0, input={}, status='success', response=GenerateResponse()),
        ]
        agg = aggregate_batch_results(results, 'json', 'out')
        assert agg['out_0'] is None

    def test_txt_format_json_parse(self) -> None:
        results = [
            BatchResult(index=0, input={}, status='success', response=GenerateResponse(text='{"v": 1}')),
        ]
        agg = aggregate_batch_results(results, 'txt', 'out')
        # txt format now parses JSON — same as json/yaml formats
        assert agg['out_0'] == {'v': 1}

    def test_unparseable_json_keeps_string(self) -> None:
        results = [
            BatchResult(index=0, input={}, status='success', response=GenerateResponse(text='not json')),
        ]
        agg = aggregate_batch_results(results, 'json', 'out')
        assert agg['out_0'] == 'not json'

    def test_empty_results_list(self) -> None:
        agg = aggregate_batch_results([], 'json', 'out')
        assert agg == {}

    def test_yaml_format_parses_json(self) -> None:
        results = [
            BatchResult(index=0, input={}, status='success', response=GenerateResponse(text='{"k": "v"}')),
        ]
        agg = aggregate_batch_results(results, 'yaml', 'out')
        assert agg['out_0'] == {'k': 'v'}


# ── Retry / Timeout / Error-handling tests ──────────────────────────────────


def _default_retry_cfg(**overrides: Any) -> RetryConfig:
    """Create a RetryConfig with sensible test defaults (jitter disabled)."""
    defaults: dict[str, Any] = {
        'max_retries': 3,
        'backoff_strategy': 'exponential',
        'backoff_base': 1.0,
        'backoff_max': 60.0,
        'jitter': False,
    }
    defaults.update(overrides)
    return RetryConfig(**defaults)


class TestComputeDelay:
    """Tests for ``_compute_delay``."""

    def test_exponential_default(self) -> None:
        cfg = _default_retry_cfg()
        assert _compute_delay(0, cfg) == 1.0  # 1 * 2^0
        assert _compute_delay(1, cfg) == 2.0  # 1 * 2^1
        assert _compute_delay(2, cfg) == 4.0  # 1 * 2^2
        assert _compute_delay(3, cfg) == 8.0  # 1 * 2^3

    def test_exponential_custom_base(self) -> None:
        cfg = _default_retry_cfg(backoff_base=2.0)
        assert _compute_delay(0, cfg) == 2.0  # 2 * 2^0
        assert _compute_delay(1, cfg) == 4.0  # 2 * 2^1
        assert _compute_delay(2, cfg) == 8.0  # 2 * 2^2

    def test_fixed_strategy(self) -> None:
        cfg = _default_retry_cfg(backoff_strategy='fixed', backoff_base=5.0)
        assert _compute_delay(0, cfg) == 5.0
        assert _compute_delay(1, cfg) == 5.0
        assert _compute_delay(5, cfg) == 5.0

    def test_linear_strategy(self) -> None:
        cfg = _default_retry_cfg(backoff_strategy='linear', backoff_base=2.0)
        assert _compute_delay(0, cfg) == 2.0  # 2 * (0+1)
        assert _compute_delay(1, cfg) == 4.0  # 2 * (1+1)
        assert _compute_delay(2, cfg) == 6.0  # 2 * (2+1)

    def test_backoff_max_caps_delay(self) -> None:
        cfg = _default_retry_cfg(backoff_max=3.0)
        # attempt 2: 1*2^2 = 4 -> capped to 3
        assert _compute_delay(2, cfg) == 3.0
        assert _compute_delay(10, cfg) == 3.0

    def test_jitter_reduces_delay(self) -> None:
        cfg = _default_retry_cfg(jitter=True, backoff_base=10.0)
        # With jitter, delay is multiplied by uniform(0.5, 1.0)
        # So result must be in [5.0, 10.0]
        for _ in range(50):
            d = _compute_delay(0, cfg)
            assert 5.0 <= d <= 10.0

    def test_backoff_base_override(self) -> None:
        cfg = _default_retry_cfg(backoff_base=1.0)
        # Override replaces cfg.backoff_base
        assert _compute_delay(0, cfg, backoff_base_override=5.0) == 5.0  # 5 * 2^0
        assert _compute_delay(1, cfg, backoff_base_override=5.0) == 10.0  # 5 * 2^1

    def test_override_none_uses_config_base(self) -> None:
        cfg = _default_retry_cfg(backoff_base=3.0)
        assert _compute_delay(0, cfg, backoff_base_override=None) == 3.0


class TestExtractStatusCode:
    """Tests for ``_extract_status_code``."""

    def test_status_code_attribute(self) -> None:
        """OpenAI / Anthropic style: exc.status_code."""
        exc = Exception('rate limited')
        exc.status_code = 429  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 429

    def test_code_attribute(self) -> None:
        """Google GenAI style: exc.code."""
        exc = Exception('quota exceeded')
        exc.code = 429  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 429

    def test_response_status_code(self) -> None:
        """Fallback: exc.response.status_code."""
        resp = MagicMock()
        resp.status_code = 503
        resp.status = None
        exc = Exception('service unavailable')
        exc.response = resp  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 503

    def test_response_status_attribute(self) -> None:
        """Fallback: exc.response.status (httpx style)."""
        resp = MagicMock(spec=[])
        resp.status = 502
        exc = Exception('bad gateway')
        exc.response = resp  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 502

    def test_http_response_fallback(self) -> None:
        """Fallback: exc.http_response.status_code."""
        resp = MagicMock()
        resp.status_code = 500
        exc = Exception('internal')
        exc.http_response = resp  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 500

    def test_grpc_status_code_int(self) -> None:
        """gRPC: exc.grpc_status_code as plain int."""
        exc = Exception('unavailable')
        exc.grpc_status_code = 14  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 503  # UNAVAILABLE -> 503

    def test_grpc_status_code_enum(self) -> None:
        """gRPC: exc.grpc_status_code as enum with .value."""
        grpc_code = MagicMock()
        grpc_code.value = (8,)  # RESOURCE_EXHAUSTED
        exc = Exception('resource exhausted')
        exc.grpc_status_code = grpc_code  # type: ignore[attr-defined]
        assert _extract_status_code(exc) == 429

    def test_cause_unwrapping(self) -> None:
        """Extracts status from __cause__."""
        inner = Exception('inner')
        inner.status_code = 429  # type: ignore[attr-defined]
        outer = Exception('outer')
        outer.__cause__ = inner
        assert _extract_status_code(outer) == 429

    def test_context_unwrapping(self) -> None:
        """Extracts status from __context__."""
        inner = Exception('inner')
        inner.status_code = 500  # type: ignore[attr-defined]
        outer = Exception('outer')
        outer.__context__ = inner
        assert _extract_status_code(outer) == 500

    def test_no_status_code_returns_none(self) -> None:
        assert _extract_status_code(Exception('plain error')) is None

    def test_non_int_status_code_ignored(self) -> None:
        exc = Exception('bad')
        exc.status_code = 'not_an_int'  # type: ignore[attr-defined]
        assert _extract_status_code(exc) is None


class TestClassifyError:
    """Tests for ``_classify_error``."""

    def test_handler_status_code_match(self) -> None:
        cfg = _default_retry_cfg()
        handlers = [ErrorHandlerRule(status_codes=[429], action=ErrorAction.RETRY, backoff_base=5.0)]
        exc = Exception('rate limited')
        exc.status_code = 429  # type: ignore[attr-defined]
        action, max_retries, override = _classify_error(exc, cfg, handlers)
        assert action == ErrorAction.RETRY
        assert max_retries == 3  # from cfg
        assert override == 5.0

    def test_handler_pattern_match(self) -> None:
        cfg = _default_retry_cfg()
        handlers = [ErrorHandlerRule(pattern='context.*length', action=ErrorAction.SKIP)]
        exc = Exception('context window length exceeded')
        action, max_retries, override = _classify_error(exc, cfg, handlers)
        assert action == ErrorAction.SKIP
        assert override is None

    def test_handler_status_code_takes_priority_over_pattern(self) -> None:
        cfg = _default_retry_cfg()
        handlers = [
            ErrorHandlerRule(status_codes=[429], action=ErrorAction.RETRY),
            ErrorHandlerRule(pattern='rate', action=ErrorAction.ABORT),
        ]
        exc = Exception('rate limited')
        exc.status_code = 429  # type: ignore[attr-defined]
        action, _, _ = _classify_error(exc, cfg, handlers)
        # First rule matches on status_code, so RETRY
        assert action == ErrorAction.RETRY

    def test_handler_with_max_retries_override(self) -> None:
        cfg = _default_retry_cfg(max_retries=5)
        handlers = [ErrorHandlerRule(status_codes=[503], action=ErrorAction.RETRY, max_retries=1)]
        exc = Exception('unavailable')
        exc.status_code = 503  # type: ignore[attr-defined]
        _, max_retries, _ = _classify_error(exc, cfg, handlers)
        assert max_retries == 1  # rule overrides global

    def test_first_matching_handler_wins(self) -> None:
        cfg = _default_retry_cfg()
        handlers = [
            ErrorHandlerRule(status_codes=[503], action=ErrorAction.ABORT),
            ErrorHandlerRule(status_codes=[503], action=ErrorAction.RETRY),
        ]
        exc = Exception('unavailable')
        exc.status_code = 503  # type: ignore[attr-defined]
        action, _, _ = _classify_error(exc, cfg, handlers)
        assert action == ErrorAction.ABORT

    def test_default_retryable_status_code(self) -> None:
        cfg = _default_retry_cfg()
        exc = Exception('rate limited')
        exc.status_code = 429  # type: ignore[attr-defined]
        action, max_retries, override = _classify_error(exc, cfg, None)
        assert action == ErrorAction.RETRY
        assert max_retries == 3
        assert override is None

    def test_non_retryable_status_code_skips(self) -> None:
        cfg = _default_retry_cfg()
        exc = Exception('bad request')
        exc.status_code = 400  # type: ignore[attr-defined]
        action, max_retries, _ = _classify_error(exc, cfg, None)
        assert action == ErrorAction.SKIP
        assert max_retries == 0

    def test_no_status_code_defaults_to_retry(self) -> None:
        cfg = _default_retry_cfg()
        exc = Exception('connection reset')
        action, max_retries, override = _classify_error(exc, cfg, None)
        assert action == ErrorAction.RETRY
        assert max_retries == 3
        assert override is None

    def test_abort_action(self) -> None:
        cfg = _default_retry_cfg()
        handlers = [ErrorHandlerRule(status_codes=[401], action=ErrorAction.ABORT)]
        exc = Exception('unauthorized')
        exc.status_code = 401  # type: ignore[attr-defined]
        action, _, _ = _classify_error(exc, cfg, handlers)
        assert action == ErrorAction.ABORT


class TestExecuteWithRetry:
    """Tests for ``_execute_with_retry``."""

    @pytest.mark.asyncio
    async def test_success_no_retry(self) -> None:
        """Succeeds on first attempt, no retry needed."""

        async def _ok() -> str:
            return 'ok'

        result, attempts = await _execute_with_retry(
            _ok,
            retry_cfg=None,
            error_handlers=None,
            timeout=None,
        )
        assert result == 'ok'
        assert attempts == 1

    @pytest.mark.asyncio
    async def test_success_after_retries(self) -> None:
        """Fails twice, succeeds on third attempt."""
        call_count = 0

        async def _factory() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                exc = Exception(f'fail {call_count}')
                exc.status_code = 500  # type: ignore[attr-defined]
                raise exc
            return 'ok'

        cfg = _default_retry_cfg(max_retries=3, backoff_base=0.001)
        result, attempts = await _execute_with_retry(
            _factory,
            retry_cfg=cfg,
            error_handlers=None,
            timeout=None,
        )
        assert result == 'ok'
        assert attempts == 3

    @pytest.mark.asyncio
    async def test_exhausts_retries_then_raises(self) -> None:
        """All retries exhausted -> raises last exception."""

        async def _always_fail() -> str:
            exc = Exception('persistent')
            exc.status_code = 500  # type: ignore[attr-defined]
            raise exc

        cfg = _default_retry_cfg(max_retries=2, backoff_base=0.001)
        with pytest.raises(Exception, match='persistent'):
            await _execute_with_retry(
                _always_fail,
                retry_cfg=cfg,
                error_handlers=None,
                timeout=None,
            )

    @pytest.mark.asyncio
    async def test_skip_action_raises_immediately(self) -> None:
        """SKIP action re-raises without retrying."""
        call_count = 0

        async def _factory() -> str:
            nonlocal call_count
            call_count += 1
            exc = Exception('bad request')
            exc.status_code = 400  # type: ignore[attr-defined]
            raise exc

        cfg = _default_retry_cfg(max_retries=3, backoff_base=0.001)
        handlers = [ErrorHandlerRule(status_codes=[400], action=ErrorAction.SKIP)]
        with pytest.raises(Exception, match='bad request'):
            await _execute_with_retry(
                _factory,
                retry_cfg=cfg,
                error_handlers=handlers,
                timeout=None,
            )
        assert call_count == 1  # no retries attempted

    @pytest.mark.asyncio
    async def test_abort_action_raises_immediately(self) -> None:
        """ABORT action re-raises without retrying."""
        call_count = 0

        async def _factory() -> str:
            nonlocal call_count
            call_count += 1
            exc = Exception('unauthorized')
            exc.status_code = 401  # type: ignore[attr-defined]
            raise exc

        cfg = _default_retry_cfg(max_retries=3, backoff_base=0.001)
        handlers = [ErrorHandlerRule(status_codes=[401], action=ErrorAction.ABORT)]
        with pytest.raises(Exception, match='unauthorized'):
            await _execute_with_retry(
                _factory,
                retry_cfg=cfg,
                error_handlers=handlers,
                timeout=None,
            )
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_timeout_triggers_retry(self) -> None:
        """Timeout causes retry on transient coroutine."""
        call_count = 0

        async def _factory() -> str:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                await asyncio.sleep(10)  # will be killed by timeout
            return 'ok'

        cfg = _default_retry_cfg(max_retries=2, backoff_base=0.001)
        result, attempts = await _execute_with_retry(
            _factory,
            retry_cfg=cfg,
            error_handlers=None,
            timeout=0.05,
        )
        assert result == 'ok'
        assert attempts == 2

    @pytest.mark.asyncio
    async def test_timeout_all_attempts_raises(self) -> None:
        """All attempts time out -> raises TimeoutError."""

        async def _slow() -> str:
            await asyncio.sleep(10)
            return 'never'

        cfg = _default_retry_cfg(max_retries=1, backoff_base=0.001)
        with pytest.raises(asyncio.TimeoutError):
            await _execute_with_retry(
                _slow,
                retry_cfg=cfg,
                error_handlers=None,
                timeout=0.01,
            )

    @pytest.mark.asyncio
    async def test_no_retry_cfg_raises_on_error(self) -> None:
        """When retry_cfg is None, errors raise immediately."""

        async def _fail() -> str:
            raise RuntimeError('no retry')

        with pytest.raises(RuntimeError, match='no retry'):
            await _execute_with_retry(
                _fail,
                retry_cfg=None,
                error_handlers=None,
                timeout=None,
            )

    @pytest.mark.asyncio
    async def test_rule_max_retries_limits_attempts(self) -> None:
        """Per-rule max_retries can be lower than global, limiting retries."""
        call_count = 0

        async def _factory() -> str:
            nonlocal call_count
            call_count += 1
            exc = Exception('overloaded')
            exc.status_code = 429  # type: ignore[attr-defined]
            raise exc

        cfg = _default_retry_cfg(max_retries=5, backoff_base=0.001)
        handlers = [ErrorHandlerRule(status_codes=[429], action=ErrorAction.RETRY, max_retries=1)]
        with pytest.raises(Exception, match='overloaded'):
            await _execute_with_retry(
                _factory,
                retry_cfg=cfg,
                error_handlers=handlers,
                timeout=None,
            )
        # max_retries=1 from rule, effective_max = min(1, 5) = 1
        # attempt 0 fails, attempt 1 (>= effective_max=1) raises
        assert call_count == 2


class TestRunBatchWithRetry:
    """Integration tests for ``run_batch`` with retry/timeout/abort."""

    @pytest.mark.asyncio
    async def test_batch_retries_transient_errors(self) -> None:
        """Items with transient errors are retried and eventually succeed."""
        call_counts: dict[int, int] = {}

        async def _generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            # Use the rendered text to identify which input we're processing
            idx = id(rendered)
            call_counts[idx] = call_counts.get(idx, 0) + 1
            if call_counts[idx] == 1:
                exc = Exception('transient')
                exc.status_code = 500  # type: ignore[attr-defined]
                raise exc
            return GenerateResponse(text='ok')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_generate)

        runtime = RuntimeConfig(
            retry=RetryConfig(max_retries=2, backoff_base=0.001, jitter=False),
        )
        inputs = [{'topic': 'AI'}, {'topic': 'ML'}]
        results = await run_batch(
            SIMPLE_PROMPT,
            inputs,
            adapter,
            runtime=runtime,
        )

        assert len(results) == 2
        assert all(r.status == 'success' for r in results)
        assert all(r.attempts >= 1 for r in results)

    @pytest.mark.asyncio
    async def test_batch_skip_non_retryable(self) -> None:
        """Non-retryable errors skip (status=error) without retrying."""

        async def _generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            exc = Exception('bad request')
            exc.status_code = 400  # type: ignore[attr-defined]
            raise exc

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_generate)

        runtime = RuntimeConfig(
            retry=RetryConfig(max_retries=3, backoff_base=0.001, jitter=False),
        )
        results = await run_batch(
            SIMPLE_PROMPT,
            [{'topic': 'AI'}],
            adapter,
            runtime=runtime,
        )

        assert len(results) == 1
        assert results[0].status == 'error'
        assert 'bad request' in results[0].error

    @pytest.mark.asyncio
    async def test_batch_abort_raises_batch_abort_error(self) -> None:
        """An ABORT handler triggers BatchAbortError."""

        async def _generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            exc = Exception('unauthorized')
            exc.status_code = 401  # type: ignore[attr-defined]
            raise exc

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_generate)

        runtime = RuntimeConfig(
            retry=RetryConfig(max_retries=1, backoff_base=0.001, jitter=False),
            error_handlers=[ErrorHandlerRule(status_codes=[401], action=ErrorAction.ABORT)],
        )
        with pytest.raises(BatchAbortError) as exc_info:
            await run_batch(
                SIMPLE_PROMPT,
                [{'topic': 'AI'}, {'topic': 'ML'}],
                adapter,
                runtime=runtime,
            )
        assert exc_info.value.original is not None
        assert 'unauthorized' in str(exc_info.value.original)

    @pytest.mark.asyncio
    async def test_batch_abort_error_attributes(self) -> None:
        """BatchAbortError carries index and original exception."""
        original = RuntimeError('auth failed')
        err = BatchAbortError(index=3, original=original)
        assert err.index == 3
        assert err.original is original
        assert '3' in str(err)
        assert 'auth failed' in str(err)

    @pytest.mark.asyncio
    async def test_batch_timeout(self) -> None:
        """Per-request timeout triggers retry and eventually an error."""

        async def _slow_generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            await asyncio.sleep(10)
            return GenerateResponse(text='never')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_slow_generate)

        runtime = RuntimeConfig(
            timeout=0.01,
            retry=RetryConfig(max_retries=1, backoff_base=0.001, jitter=False),
        )
        results = await run_batch(
            SIMPLE_PROMPT,
            [{'topic': 'AI'}],
            adapter,
            runtime=runtime,
        )

        assert len(results) == 1
        assert results[0].status == 'error'

    @pytest.mark.asyncio
    async def test_batch_no_runtime_backward_compat(self) -> None:
        """Without runtime arg, batch works exactly as before (no retry)."""
        adapter = _make_adapter(text='hello')
        results = await run_batch(
            SIMPLE_PROMPT,
            [{'topic': 'AI'}],
            adapter,
        )
        assert len(results) == 1
        assert results[0].status == 'success'
        assert results[0].attempts == 1
        assert results[0].elapsed >= 0.0

    @pytest.mark.asyncio
    async def test_batch_elapsed_tracked(self) -> None:
        """BatchResult.elapsed is populated on success."""

        async def _slow_generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            await asyncio.sleep(0.02)
            return GenerateResponse(text='done')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_slow_generate)

        results = await run_batch(
            SIMPLE_PROMPT,
            [{'topic': 'AI'}],
            adapter,
        )
        assert results[0].elapsed >= 0.02

    @pytest.mark.asyncio
    async def test_batch_on_item_complete_with_retry(self) -> None:
        """Callback fires after retry resolution (success or final error)."""
        call_count = 0

        async def _generate(rendered: Any, **kwargs: Any) -> GenerateResponse:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                exc = Exception('transient')
                exc.status_code = 500  # type: ignore[attr-defined]
                raise exc
            return GenerateResponse(text='recovered')

        adapter = MagicMock(spec=Adapter)
        adapter.generate = AsyncMock(side_effect=_generate)

        completed: list[BatchResult] = []
        runtime = RuntimeConfig(
            retry=RetryConfig(max_retries=2, backoff_base=0.001, jitter=False),
        )
        await run_batch(
            SIMPLE_PROMPT,
            [{'topic': 'AI'}],
            adapter,
            on_item_complete=lambda r: completed.append(r),
            runtime=runtime,
        )

        assert len(completed) == 1
        assert completed[0].status == 'success'
