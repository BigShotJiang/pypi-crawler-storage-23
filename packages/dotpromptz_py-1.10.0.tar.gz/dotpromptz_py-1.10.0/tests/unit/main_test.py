"""Tests for __main__.py module entry point."""

import subprocess
import sys


class TestMainModule:
    """Test that python -m dotpromptz works."""

    def test_main_help(self) -> None:
        """Running ``python -m dotpromptz --help`` should succeed."""
        result = subprocess.run(
            [sys.executable, '-m', 'dotpromptz', '--help'],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0
        # Top-level help shows subcommands and .prompt mention
        assert 'run' in result.stdout
        assert 'build' in result.stdout
        assert '.prompt' in result.stdout

    def test_main_version(self) -> None:
        """Running ``python -m dotpromptz --version`` should succeed."""
        result = subprocess.run(
            [sys.executable, '-m', 'dotpromptz', '--version'],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0

    def test_main_module_invokes_cli(self) -> None:
        """The __main__.py module should call cli() when run."""
        import runpy
        from unittest.mock import patch

        with patch('dotpromptz.cli.cli') as mock_cli:
            mock_cli.side_effect = SystemExit(0)
            try:
                runpy.run_module('dotpromptz', run_name='__main__')
            except SystemExit:
                pass
            mock_cli.assert_called_once()
