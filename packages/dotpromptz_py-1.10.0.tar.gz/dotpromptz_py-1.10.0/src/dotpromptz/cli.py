"""Command-line interface for dotpromptz.

Usage::

    prompt run my_prompt.prompt
    prompt build my_prompt.prompt
"""

import argparse
import asyncio
import json
import signal
import sys
from datetime import datetime
from importlib.metadata import version
from pathlib import Path
from typing import Any

import structlog

from dotpromptz import Dotprompt
from dotpromptz.inputs import resolve_input
from dotpromptz.logging import configure_logging, generate_build_output_filename
from dotpromptz.parse import parse_document
from dotpromptz.runner import (
    BatchAbortError,
    aggregate_batch_results as _runner_aggregate_batch_results,
    extract_response_content as _runner_extract_response_content,
    part_to_dict as _runner_part_to_dict,
    resolve_adapter as _runner_resolve_adapter,
    run_batch,
    serialize_result as _runner_serialize_result,
    write_output as _runner_write_output,
)
from dotpromptz.typing import DataArgument, PromptOutputConfig
from dotpromptz.version import PromptVersionError, adapt_prompt, check_for_update

logger = structlog.get_logger(__name__)


def _resolve_adapter(rendered: Any) -> Any:
    """CLI wrapper around :func:`runner.resolve_adapter`.

    Calls ``sys.exit(2)`` on failure instead of raising ``ValueError``.
    """
    try:
        return _runner_resolve_adapter(rendered)
    except ValueError as exc:
        logger.error(str(exc))
        sys.exit(2)


def _part_to_dict(part: Any) -> dict[str, Any]:
    """CLI wrapper — delegates to :func:`runner.part_to_dict`."""
    return _runner_part_to_dict(part)


def _write_output(
    content: str | bytes,
    output_config: PromptOutputConfig,
    output_dir: Path,
    file_name: str,
) -> Path:
    """CLI wrapper — delegates to :func:`runner.write_output`."""
    return _runner_write_output(content, output_config, output_dir, file_name)


def _serialize_result(data: Any, fmt: str) -> str:
    """CLI wrapper — delegates to :func:`runner.serialize_result`."""
    return _runner_serialize_result(data, fmt)


def _validate_prompt_file(prompt_file: str) -> Path:
    """Validate that the prompt file exists and return its Path.

    Args:
        prompt_file: Path string to the .prompt file.

    Returns:
        Resolved Path object.
    """
    path = Path(prompt_file)
    if not path.is_file():
        logger.error('Path does not exist.', path=prompt_file)
        sys.exit(2)
    return path


def _get_version() -> str:
    """Return the installed package version."""
    try:
        return version('dotpromptz-py')
    except Exception:
        return 'unknown'


def cli(args: list[str] | None = None) -> None:
    """Main CLI entry point with subcommands.

    Subcommands:
        run   — Render and execute a .prompt file (call LLM).
        build — Render a .prompt file without executing (no LLM call).

    Args:
        args: Command-line arguments (defaults to sys.argv[1:]).

    Examples::

      prompt run explain.prompt
      prompt build explain.prompt
    """
    parser = argparse.ArgumentParser(
        prog='prompt',
        description='Dotpromptz CLI — build and run .prompt files.',
    )
    parser.add_argument('--version', action='version', version=f'%(prog)s {_get_version()}')
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
        help='Set logging level (default: INFO).',
    )
    subparsers = parser.add_subparsers(dest='command', help='Available commands.')

    # --- prompt run ---
    run_parser = subparsers.add_parser(
        'run',
        help='Render and execute a .prompt file (calls LLM).',
        description='Render a .prompt file with input from frontmatter, then call the configured LLM and write output.',
    )
    run_parser.add_argument(
        'prompt_file',
        metavar='PROMPT_FILE',
        help='Path to a .prompt file.',
    )

    # --- prompt build ---
    build_parser = subparsers.add_parser(
        'build',
        help='Render a .prompt file without executing (no LLM call).',
        description=(
            'Parse and render a .prompt file, resolve input and config, '
            'then print the rendered prompt to stdout. '
            'Useful for inspecting the final prompt before sending it to an LLM.'
        ),
    )
    build_parser.add_argument(
        'prompt_file',
        metavar='PROMPT_FILE',
        help='Path to a .prompt file.',
    )

    parsed = parser.parse_args(args)

    # Configure logging AFTER parsing args so --log-level is available.
    log_dir = configure_logging(level=parsed.log_level)

    # Best-effort update check (never blocks or fails the CLI).
    check_for_update()

    if parsed.command is None:
        parser.print_help()
        sys.exit(2)

    if parsed.command == 'run':
        _validate_prompt_file(parsed.prompt_file)
        asyncio.run(_run_cli_async(prompt_file=parsed.prompt_file))
    elif parsed.command == 'build':
        _validate_prompt_file(parsed.prompt_file)
        _build_cli(prompt_file=parsed.prompt_file, log_dir=log_dir)


def _build_cli(*, prompt_file: str, log_dir: Path) -> None:
    """Parse, validate, and render a .prompt file without calling an LLM.

    Writes the rendered prompt (messages, config, metadata) to a JSON file
    under the log directory and logs the file path at INFO level.

    Args:
        prompt_file: Path to the .prompt file.
        log_dir: Directory where the build output JSON is written.
    """
    # 1. Read and parse.
    prompt_path = Path(prompt_file)
    source = prompt_path.read_text(encoding='utf-8')
    parsed = parse_document(source)

    # 2. Version compatibility check.
    try:
        adapt_prompt(parsed)
    except PromptVersionError as exc:
        logger.error(str(exc))
        sys.exit(2)

    # 3. Resolve input data from frontmatter.
    try:
        input_cfg = parsed.input
        defaults = input_cfg.defaults if input_cfg else None
        records = resolve_input(
            input_cfg.data if input_cfg else None,
            prompt_path,
            defaults=defaults,
        )
    except ValueError as exc:
        logger.error('Input resolution failed.', error=str(exc))
        sys.exit(1)
    # 4. Determine input data for rendering.
    if not records and defaults:
        input_data = defaults
    elif not records:
        input_data = {}
    elif len(records) > 1:
        # For batch, render the first item as a representative sample.
        input_data = records[0]
        logger.info('Batch mode detected. Rendering first item as sample.', total_items=len(records))
    else:
        input_data = records[0]
    # 5. Render (no LLM call).
    dp = Dotprompt()
    rendered = dp.render(source, data=DataArgument(input=input_data), variables=input_data)

    # 6. Build output dict.
    output: dict[str, Any] = {}

    # Config
    if rendered.config:
        output['config'] = rendered.config

    # Model
    if rendered.model:
        output['model'] = rendered.model

    # Messages
    output['messages'] = []
    for msg in rendered.messages:
        msg_dict: dict[str, Any] = {'role': msg.role}
        if msg.content:
            parts = []
            for part in msg.content:
                parts.append(_part_to_dict(part))
            msg_dict['content'] = parts
        output['messages'].append(msg_dict)

    # Output config
    if rendered.output:
        output['output'] = rendered.output.model_dump(exclude_none=True)

    # Tools
    if rendered.tools:
        output['tools'] = [t.model_dump(exclude_none=True) for t in rendered.tools]

    # Input/output schemas
    if rendered.input:
        output['input'] = rendered.input.model_dump(exclude_none=True)

    # 7. Write build output to file (no stdout print).
    output_filename = generate_build_output_filename(prompt_path.stem)
    output_file = log_dir / output_filename
    output_file.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding='utf-8')
    logger.info('Build output saved.', path=str(output_file))


async def _run_cli_async(*, prompt_file: str) -> None:
    """Async implementation of the run command.

    Always runs through ``_run_batch`` — single-item input is treated
    as a batch of one.
    """
    # 1. Read the prompt source and parse.
    prompt_path = Path(prompt_file)
    source = prompt_path.read_text(encoding='utf-8')
    parsed = parse_document(source)

    # 2. Version compatibility check (fail early before input resolution).
    try:
        adapt_prompt(parsed)
    except PromptVersionError as exc:
        logger.error(str(exc))
        sys.exit(2)

    # 3. Resolve input data from frontmatter.
    try:
        input_cfg = parsed.input
        defaults = input_cfg.defaults if input_cfg else None
        records = resolve_input(
            input_cfg.data if input_cfg else None,
            prompt_path,
            defaults=defaults,
        )
    except ValueError as exc:
        logger.error('Input resolution failed.', error=str(exc))
        sys.exit(1)

    # 4. Build input list (always a list).
    if not records and defaults:
        input_list = [defaults]
    elif not records:
        input_list = [{}]
    else:
        input_list = records

    # 5. Execute as batch (single item = batch of 1).
    await _run_batch(source, input_list, prompt_path)


async def _run_batch(
    source: str,
    input_list: list[dict],
    prompt_path: Path,
) -> None:
    """Execute batch prompt rendering and generation with concurrency control.

    Delegates core batch execution to ``runner.run_batch`` and handles
    file I/O, aggregation, SIGINT handling, and exit codes.

    All results are written to files. When ``aggregate`` is enabled,
    results are merged into a single file after all items complete.
    For ``txt`` format aggregation, the output is serialized as JSON.
    Stdout is silent.

    Args:
        source: The .prompt file content.
        input_list: List of input variable dicts.
        prompt_path: Path to the .prompt file (for output dir template resolution).
    """
    # 1. Parse the prompt once to get runtime and output config.
    parsed_prompt = parse_document(source)
    runtime_config = parsed_prompt.runtime  # RuntimeConfig | None
    output_config: PromptOutputConfig | None = parsed_prompt.output

    if output_config is None:
        logger.error('No output configuration found in .prompt frontmatter. output.format is required.')
        sys.exit(2)

    if not output_config.file_name:
        logger.error('output.file_name is required in .prompt frontmatter.')
        sys.exit(2)

    # 2. Get batch settings.
    max_workers = runtime_config.max_workers if runtime_config else 5
    output_dir = _resolve_output_dir(output_config.output_dir, prompt_path)
    file_name_tpl = output_config.file_name
    fmt = output_config.format
    aggregate = output_config.aggregate

    # 3. Render first item to resolve adapter.
    dp = Dotprompt()
    first_rendered = dp.render(source, data=DataArgument(input=input_list[0]), variables=input_list[0])
    adapter = _resolve_adapter(first_rendered)

    # 4. Create output directory.
    output_dir.mkdir(parents=True, exist_ok=True)

    # 5. Set up SIGINT (Ctrl+C) handler for graceful abort.
    abort_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    sigint_count = 0

    def _sigint_handler() -> None:
        nonlocal sigint_count
        sigint_count += 1
        if sigint_count == 1:
            logger.warning(
                'Interrupt received. Aborting after in-flight tasks finish... (press Ctrl+C again to force exit)',
            )
            abort_event.set()
        else:
            logger.warning('Force exit.')
            sys.exit(130)

    try:
        loop.add_signal_handler(signal.SIGINT, _sigint_handler)
    except NotImplementedError:
        # Windows does not support add_signal_handler; fall back to no-op.
        pass

    # 6. Run batch using runner.
    try:
        batch_results = await run_batch(
            source,
            input_list,
            adapter,
            max_workers=max_workers,
            dp=dp,
            runtime=runtime_config,
        )
    except BatchAbortError as exc:
        logger.error('Batch aborted.', index=exc.index, error=str(exc.original))
        sys.exit(1)

    # 7. Write output files.
    is_single = len(batch_results) == 1

    if aggregate and fmt != 'image':
        # Aggregate: collect all text results into a single dict keyed by file stem.
        aggregated = _runner_aggregate_batch_results(batch_results, fmt, file_name_tpl)
        # For txt aggregate, serialize as JSON.
        agg_fmt = 'json' if fmt == 'txt' else fmt
        content = _serialize_result(aggregated, agg_fmt)
        # Write with the appropriate extension.
        agg_output_config = (
            output_config
            if fmt != 'txt'
            else PromptOutputConfig(
                format='json',
                file_name=file_name_tpl,
                aggregate=True,
            )
        )
        path = _write_output(content, agg_output_config, output_dir, file_name_tpl)
        logger.info('Aggregated output saved.', path=str(path))
    else:
        # Individual files per result.
        for result in batch_results:
            idx = result.index
            # Single-item batch: use plain file_name without _0 suffix.
            stem = file_name_tpl if is_single else f'{file_name_tpl}_{idx}'
            if result.status == 'error':
                if fmt == 'image':
                    logger.warning('Item failed.', index=idx, error=result.error)
                else:
                    err_content = _serialize_result({'error': result.error}, fmt)
                    path = _write_output(err_content, output_config, output_dir, stem)
                    logger.info('Output saved.', path=str(path))
                continue
            try:
                item_content = _runner_extract_response_content(result.response, fmt)
            except (ValueError, AttributeError):
                if fmt == 'image':
                    logger.warning('Expected image but got no image data.', index=idx)
                else:
                    item_content = _serialize_result('', fmt)
                    path = _write_output(item_content, output_config, output_dir, stem)
                    logger.info('Output saved.', path=str(path))
                continue
            path = _write_output(item_content, output_config, output_dir, stem)
            if fmt == 'image':
                logger.info('Image saved.', path=str(path))
            else:
                logger.info('Output saved.', path=str(path))

    # 8. Exit with error code if ALL items failed.
    failed = sum(1 for r in batch_results if r.status == 'error')
    if failed == len(batch_results):
        sys.exit(1)


def _resolve_output_dir(output_dir_tpl: str | None, prompt_path: Path) -> Path:
    """Resolve output directory from template or default.

    Template variables:
        ``{{@name}}`` — the ``.prompt`` file stem (without extension).
        ``{{@time}}`` — current timestamp as ``YYYYMMDD_HHMMSS``.

    When *output_dir_tpl* is ``None``, defaults to
    ``output/{{@name}}_{{@time}}``.

    Args:
        output_dir_tpl: Output directory template string, or ``None``.
        prompt_path: Path to the .prompt file.

    Returns:
        Resolved ``Path`` object.
    """
    if output_dir_tpl is None:
        output_dir_tpl = 'output/{{@name}}_{{@time}}'

    name = prompt_path.stem
    time_str = datetime.now().strftime('%Y%m%d_%H%M%S')
    resolved = output_dir_tpl.replace('{{@name}}', name).replace('{{@time}}', time_str)
    return Path(resolved)
