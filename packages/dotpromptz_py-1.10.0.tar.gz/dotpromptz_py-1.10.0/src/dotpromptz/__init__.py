"""Dotpromptz: Executable prompt templates for Python.

Dotpromptz is the Python implementation of the Dotprompt file format—an executable
prompt template format for Generative AI. It provides a structured way to define,
manage, and render prompts with metadata, schemas, tools, and templating.

## What is Dotprompt?

Dotprompt files (`.prompt`) combine YAML frontmatter metadata with Handlebars
templates to create self-contained, executable prompt definitions:

```
+---------------------------+
|     YAML Frontmatter      |  <- Model config, schemas, tools
|---------------------------|
|                           |
|   Handlebars Template     |  <- Dynamic prompt with variables
|                           |
+---------------------------+
```

## Key Concepts

| Concept          | Description                                                      |
|------------------|------------------------------------------------------------------|
| **Frontmatter**  | YAML metadata block at the top of `.prompt` files (model,        |
|                  | schemas, tools, config)                                          |
| **Template**     | Handlebars template body with variables, helpers, and partials   |
| **Picoschema**   | Compact schema format that compiles to JSON Schema               |
| **Partials**     | Reusable template fragments (prefixed with `_` in filenames)     |
| **Helpers**      | Custom Handlebars functions (`{{role}}`, `{{media}}`, etc.)      |
| **Resolvers**    | Functions to dynamically resolve tools, schemas, and partials    |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Dotprompt                               │
│  (Main entry point - compiles and renders prompt templates)     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │    parse     │  │  picoschema  │  │      resolvers       │  │
│  │  (YAML +     │  │  (Schema     │  │  (Tools, schemas,    │  │
│  │   template)  │  │   compiler)  │  │   partials lookup)   │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────┐  ┌──────────────────────────┐  │
│  │         helpers          │  │        handlebarrz       │  │
│  │  (Built-in Handlebars    │  │  (Handlebars engine via  │  │
│  │      functions)          │  │        Rust FFI)         │  │
│  └──────────────────────────┘  └──────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Quick Start

```python
from dotpromptz import Dotprompt

# Create a Dotprompt instance
dp = Dotprompt()

# Parse and render a prompt
source = '''
---
model: gemini-pro
input:
  schema:
    name: string
---
Hello, {{name}}! How can I help you today?
'''

rendered = dp.render(source, data=DataArgument(input={'name': 'Alice'}))

# Access rendered messages
for message in rendered.messages:
    print(f'{message.role}: {message.content}')
```

## Example `.prompt` File

```handlebars
---
model: googleai/gemini-2.5-pro
input:
  schema:
    topic: string, The topic to explain
    level: string, Expertise level (beginner, intermediate, advanced)
output:
  format: json
  schema:
    explanation: string, Clear explanation of the topic
    examples(array): string, Illustrative examples
---

{{role "system"}}
You are an expert educator who adapts explanations to the learner's level.

{{role "user"}}
Please explain {{topic}} for someone at the {{level}} level.
Provide clear examples to illustrate key points.
```

## Module Structure

| Module          | Purpose                                              |
|-----------------|------------------------------------------------------|
| `dotprompt`     | Main `Dotprompt` class for compiling/rendering       |
| `parse`         | YAML frontmatter extraction and message parsing      |
| `picoschema`    | Picoschema to JSON Schema compilation                |
| `helpers`       | Built-in Handlebars helpers (`role`, `media`, etc.)  |
| `resolvers`     | Resolution of tools, schemas, partials, and errors   |
| `typing`        | Pydantic models and type definitions                 |

## See Also

- Dotprompt specification: https://github.com/google/dotprompt
- Handlebars templating: https://handlebarsjs.com
- JSON Schema: https://json-schema.org
"""

from .credentials import Credential, CredentialPool, load_credentials
from .dotprompt import Dotprompt, TemplateMissingVariableError
from .inputs import infer_schema, resolve_input
from .logging import configure_logging
from .runner import (
    BatchResult,
    aggregate_batch_results,
    extract_response_content,
    part_to_dict,
    resolve_adapter,
    run_batch,
    run_single,
    serialize_result,
    write_output,
)
from .typing import DataArgument
from .version import CURRENT_MAJOR, PromptVersionError

__all__ = [
    'BatchResult',
    'CURRENT_MAJOR',
    'configure_logging',
    'Credential',
    'CredentialPool',
    'DataArgument',
    'Dotprompt',
    'PromptVersionError',
    'TemplateMissingVariableError',
    'aggregate_batch_results',
    'extract_response_content',
    'infer_schema',
    'load_credentials',
    'part_to_dict',
    'resolve_adapter',
    'resolve_input',
    'run_batch',
    'run_single',
    'serialize_result',
    'write_output',
]
