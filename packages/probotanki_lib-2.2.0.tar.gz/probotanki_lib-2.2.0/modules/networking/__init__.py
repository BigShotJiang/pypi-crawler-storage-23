from .tankisocket import TankiSocket
from .asynctankisocket import AsyncTankiSocket