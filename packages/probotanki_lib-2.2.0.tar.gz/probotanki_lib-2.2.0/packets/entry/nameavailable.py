from ...packets import AbstractPacket


class Name_Available(AbstractPacket):
    id = -706679202
    description = "Said name is available for registration"