from ...packets import AbstractPacket


class Login_Failed(AbstractPacket):
    id = 103812952
    description = 'Login failed'
