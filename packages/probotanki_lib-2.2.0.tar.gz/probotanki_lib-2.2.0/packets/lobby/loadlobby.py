from ...packets import AbstractPacket


class Load_Lobby(AbstractPacket):
    id = 1452181070
    description = "Load battle info"
