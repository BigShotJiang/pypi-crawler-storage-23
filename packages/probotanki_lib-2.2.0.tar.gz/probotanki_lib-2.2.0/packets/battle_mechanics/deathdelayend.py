from ...packets import AbstractPacket


class Death_Delay_End(AbstractPacket):
    id = 268832557
    description = "Respawn delay ends and player can start respawning"
