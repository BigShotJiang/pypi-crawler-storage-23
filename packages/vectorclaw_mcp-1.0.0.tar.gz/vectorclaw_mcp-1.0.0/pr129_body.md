## Summary
- add full hardware smoke report for 2026-02-28
- update smoke log with final one-by-one rerun outcomes
- update API/semantics docs from empirical findings
- add roadmap follow-ups (async control path, pose metadata, perception hardening)
- add explicit MVP vision-loop requirement note (camera capture requires VLM/image-analysis model for look→reason→act)

## Key artifacts
- docs/research/HARDWARE_SMOKE_REPORT_2026-02-28.md
- docs/HARDWARE_SMOKE_LOG.md
- docs/HARDWARE_SMOKE_EMPIRICAL_TEST.md
- docs/research/SDK_SEMANTICS_RESEARCH.md
- docs/API_REFERENCE.md
- ROADMAP.md

## Notes
- This PR is documentation-only (no runtime code changes).
- Local debug artifacts/scripts were intentionally excluded from commit.
