"""Allow running the server with ``python -m vectorclaw_mcp``."""

from .server import main

main()
