"""VectorClaw MCP — Anki Vector robot bridge for AI assistants."""

__version__ = "0.1.0"
