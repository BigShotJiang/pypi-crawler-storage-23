# SDK Patch Notes

Status: **No custom SDK patch set is currently required**.

VectorClaw is validated against upstream Wire-Pod SDK (`wirepod_vector_sdk` / `anki_vector` namespace) without a maintained fork for baseline operation.

## Baseline
- Upstream source: `kercre123/wirepod-vector-python-sdk`
- Tested baseline: `wirepod_vector_sdk 0.8.1`

## Why this file exists
This file tracks SDK deltas **if** we ever need temporary compatibility patches in the future.

## If patching becomes necessary later
Document each patch with:
1. Exact file + code delta
2. Reason/impact
3. Upstream PR link (if opened)
4. Removal trigger

Until then, this file intentionally stays minimal.
