from .extension import KatexRsExtension

def makeExtension(**kwargs):
    return KatexRsExtension(**kwargs)
