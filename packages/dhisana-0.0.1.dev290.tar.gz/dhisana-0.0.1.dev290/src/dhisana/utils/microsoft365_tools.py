import asyncio
import logging
from datetime import datetime, timedelta, timezone
import json
import re
from typing import Any, Dict, List, Optional

import httpx

from dhisana.schemas.common import (
    SendEmailContext,
    QueryEmailContext,
    ReplyEmailContext,
)
from dhisana.schemas.sales import MessageItem
from dhisana.utils.email_body_utils import body_variants


def _normalize_recipient(recipient: Any) -> Optional[Dict[str, str]]:
    if recipient is None:
        return None
    if isinstance(recipient, dict):
        email = recipient.get("email") or recipient.get("address")
        name = recipient.get("name")
    else:
        email = getattr(recipient, "email", None) or getattr(recipient, "address", None)
        name = getattr(recipient, "name", None)
        if isinstance(recipient, str):
            email = recipient
            name = None
    if not email:
        return None
    return {"email": email, "name": name}


def _normalize_recipients(recipients: Optional[List[Any]]) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    for recipient in recipients or []:
        item = _normalize_recipient(recipient)
        if item:
            normalized.append(item)
    return normalized


def _dedupe_recipients(
    recipients: List[Dict[str, str]],
    exclude_emails: Optional[List[str]] = None,
) -> List[Dict[str, str]]:
    excluded = {email.lower() for email in (exclude_emails or []) if email}
    seen: set[str] = set()
    result: List[Dict[str, str]] = []
    for recipient in recipients:
        email = (recipient.get("email") or "").strip()
        if not email:
            continue
        email_lc = email.lower()
        if email_lc in seen or email_lc in excluded:
            continue
        seen.add(email_lc)
        result.append({"email": email, "name": recipient.get("name")})
    return result


def _recipients_to_m365(recipients: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    for recipient in recipients:
        email = recipient.get("email")
        if not email:
            continue
        payload = {"emailAddress": {"address": email}}
        name = recipient.get("name")
        if name:
            payload["emailAddress"]["name"] = name
        result.append(payload)
    return result

def get_microsoft365_access_token(tool_config: Optional[List[Dict]] = None) -> str:
    """
    Retrieve a Microsoft Graph OAuth2 access token from tool_config or env.

    Expected tool_config shape (similar to HubSpot):
        {
          "name": "microsoft365",
          "configuration": [
            {"name": "oauth_tokens", "value": {"access_token": "..."} }
            # or {"name": "access_token", "value": "..."}
          ]
        }

    This helper no longer reads environment variables; the token must be supplied
    via the microsoft365 integration's configuration.
    """
    access_token: Optional[str] = None

    if tool_config:
        ms_cfg = next((c for c in tool_config if c.get("name") == "microsoft365"), None)
        if ms_cfg:
            cfg_map = {f["name"]: f.get("value") for f in ms_cfg.get("configuration", []) if f}
            raw_oauth = cfg_map.get("oauth_tokens")
            # If oauth_tokens is a JSON string, parse; if dict, read directly
            if isinstance(raw_oauth, str):
                try:
                    raw_oauth = json.loads(raw_oauth)
                except Exception:
                    raw_oauth = None
            if isinstance(raw_oauth, dict):
                access_token = raw_oauth.get("access_token") or raw_oauth.get("token")
            if not access_token:
                access_token = cfg_map.get("access_token") or cfg_map.get("apiKey")

    if not access_token:
        raise ValueError(
            "Microsoft 365 integration is not configured. Please connect Microsoft 365 in Integrations and provide an OAuth access token."
        )
    return access_token


def _get_m365_auth_mode(tool_config: Optional[List[Dict]] = None) -> str:
    """
    Determine auth mode: 'delegated' (default) or 'application'.
    Looks for configuration fields in the microsoft365 integration:
      - auth_mode: 'delegated' | 'application'
      - use_application_permissions: true/false (string or bool)
    """
    mode = "delegated"
    if tool_config:
        ms_cfg = next((c for c in tool_config if c.get("name") == "microsoft365"), None)
        if ms_cfg:
            cfg_map = {f["name"]: f.get("value") for f in ms_cfg.get("configuration", []) if f}
            raw_mode = (
                cfg_map.get("auth_mode")
                or cfg_map.get("authMode")
                or cfg_map.get("mode")
            )
            if isinstance(raw_mode, str) and raw_mode:
                val = raw_mode.strip().lower()
                if val in ("application", "app", "service", "service_account"):
                    return "application"
                if val in ("delegated", "user"):
                    return "delegated"
            uap = cfg_map.get("use_application_permissions") or cfg_map.get("applicationPermissions")
            if isinstance(uap, str):
                if uap.strip().lower() in ("true", "1", "yes", "y"):  # truthy
                    return "application"
            elif isinstance(uap, bool) and uap:
                return "application"
    return mode


def _base_resource(sender_email: Optional[str], tool_config: Optional[List[Dict]], auth_mode: Optional[str] = None) -> str:
    mode = (auth_mode or _get_m365_auth_mode(tool_config)).lower()
    if mode == "application":
        if not sender_email:
            raise ValueError("sender_email is required when using application permissions.")
        return f"/users/{sender_email}"
    # Delegated (per-user) uses /me
    return "/me"


def _token_has_mail_read_scope(token: str) -> bool:
    """
    Best-effort check if the OAuth token includes Mail.Read or Mail.ReadWrite.
    Works for both delegated ("scp") and app-only ("roles"). No signature verification.
    """
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return False
        import base64

        def _b64url_decode(segment: str) -> bytes:
            pad = "=" * (-len(segment) % 4)
            return base64.urlsafe_b64decode(segment + pad)

        payload_bytes = _b64url_decode(parts[1])
        payload = json.loads(payload_bytes.decode("utf-8"))

        scopes = set()
        scp = payload.get("scp")
        if isinstance(scp, str):
            scopes.update(s.strip() for s in scp.split(" ") if s.strip())

        roles = payload.get("roles")
        if isinstance(roles, list):
            scopes.update(r for r in roles if isinstance(r, str))

        return any(s in scopes for s in ("Mail.ReadWrite", "Mail.Read"))
    except Exception:
        return False


async def send_email_using_microsoft_graph_async(
    send_email_context: SendEmailContext,
    tool_config: Optional[List[Dict]] = None,
    auth_mode: Optional[str] = None,
) -> str:
    """
    Send an email via Microsoft Graph API using an OAuth2 access token.

    Uses the /sendMail endpoint which only requires Mail.Send permission.
    Returns a best-effort string identifier (not a Graph message ID) since
    /sendMail responds 202 with no body. If higher privileges are present
    (Mail.Read*), callers should locate the actual message ID from Sent Items
    separately if they need it.
    """
    token = get_microsoft365_access_token(tool_config)
    sender_email = send_email_context.sender_email

    base_url = "https://graph.microsoft.com/v1.0"
    base_res = _base_resource(sender_email, tool_config, auth_mode)

    plain_body, html_body, resolved_fmt = body_variants(
        send_email_context.body,
        getattr(send_email_context, "body_format", None),
    )
    content_type = "Text" if resolved_fmt == "text" else "HTML"
    content_body = plain_body if resolved_fmt == "text" else html_body

    message_payload: Dict[str, Any] = {
        "subject": send_email_context.subject,
        "body": {
            "contentType": content_type,
            "content": content_body,
        },
        "toRecipients": [
            {"emailAddress": {"address": send_email_context.recipient}}
        ],
    }

    extra_headers = getattr(send_email_context, "headers", None) or {}
    if extra_headers:
        message_payload["internetMessageHeaders"] = [
            {"name": header, "value": str(value)}
            for header, value in extra_headers.items()
            if header and value is not None
        ]

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        send_url = f"{base_url}{base_res}/sendMail"
        send_body = {
            "message": message_payload,
            "saveToSentItems": True,
        }
        send_resp = await client.post(send_url, headers=headers, json=send_body)
        send_resp.raise_for_status()  # expect 202 Accepted

    # Attempt to fetch the just-sent message from Sent Items regardless of scopes.
    # If the token lacks read scopes, a 401/403 is expected; log and continue.
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            since = _normalize_graph_datetime(
                (datetime.now(timezone.utc) - timedelta(minutes=15)).isoformat()
            )
            params = {
                "$select": "id,subject,toRecipients,ccRecipients,sentDateTime,createdDateTime",
                "$orderby": "sentDateTime desc",
                "$top": "25",
                "$filter": f"sentDateTime ge {since}",
            }
            list_url = f"{base_url}{base_res}/mailFolders/SentItems/messages"
            resp = await client.get(list_url, headers=headers, params=params)
            resp.raise_for_status()
            data = resp.json() or {}
            target_subject = (send_email_context.subject or "").strip()
            target_to = (send_email_context.recipient or "").strip().lower()
            for m in data.get("value", []):
                subj = (m.get("subject") or "").strip()
                if subj != target_subject:
                    continue
                # Gather recipient addresses
                recips: List[str] = []
                for r in m.get("toRecipients", []) or []:
                    addr = ((r.get("emailAddress") or {}).get("address") or "").strip().lower()
                    if addr:
                        recips.append(addr)
                if target_to and target_to in recips:
                    msg_id = m.get("id")
                    if msg_id:
                        return msg_id
    except httpx.HTTPStatusError as exc:
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if status in (401, 403):
            logging.warning(
                "Microsoft Graph: insufficient read scope (status %s) while fetching sent message id; skipping.",
                status,
            )
        else:
            logging.exception(
                "Microsoft Graph: unable to retrieve sent message id; continuing without it"
            )
    except Exception:
        logging.exception(
            "Microsoft Graph: unable to retrieve sent message id; continuing without it"
        )

    # Fall back: we cannot reliably return the Graph message ID without a lookup
    # or if we didn't find it. Return a best‑effort opaque token for correlation.
    return f"sent:{send_email_context.sender_email}:{send_email_context.recipient}:{send_email_context.subject}"


def _normalize_graph_datetime(value: str) -> str:
    """Normalize an ISO-8601 datetime string to the format Microsoft Graph
    OData $filter expects: no microseconds, UTC indicated by 'Z' suffix
    (e.g. '2026-02-27T00:36:36Z').

    Naive datetimes (no timezone info) are assumed to be UTC.
    """
    try:
        dt = datetime.fromisoformat(value)
        # Convert to UTC if timezone-aware
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc)
        # Format without microseconds, with Z suffix
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    except (ValueError, TypeError):
        # Fallback: strip microseconds and any UTC offset via regex
        cleaned = re.sub(r"\.\d+", "", value)
        cleaned = re.sub(r"[+-]\d{2}:?\d{2}$", "", cleaned)
        if not cleaned.endswith("Z"):
            cleaned += "Z"
        return cleaned


def _join_people(emails: List[Dict[str, Any]]) -> tuple[str, str]:
    names: List[str] = []
    addrs: List[str] = []
    for entry in emails or []:
        addr = entry.get("emailAddress", {})
        names.append(addr.get("name") or "")
        addrs.append(addr.get("address") or "")
    return ", ".join([n for n in names if n]), ", ".join([a for a in addrs if a])


async def list_emails_in_time_range_m365_async(
    context: QueryEmailContext,
    tool_config: Optional[List[Dict]] = None,
    auth_mode: Optional[str] = None,
) -> List[MessageItem]:
    """
    List messages in a time range using Microsoft Graph.

    Interprets labels as Outlook categories when provided.
    """
    if context.labels is None:
        context.labels = []

    token = get_microsoft365_access_token(tool_config)
    base_url = "https://graph.microsoft.com/v1.0"
    base_res = _base_resource(context.sender_email, tool_config, auth_mode)
    headers = {"Authorization": f"Bearer {token}"}

    # Build $filter – normalise datetimes to Graph-compatible format
    start_iso = _normalize_graph_datetime(context.start_time)
    end_iso = _normalize_graph_datetime(context.end_time)
    filters: List[str] = [
        f"receivedDateTime ge {start_iso}",
        f"receivedDateTime le {end_iso}",
    ]
    if context.unread_only:
        filters.append("isRead eq false")
    if context.labels:
        cats = [f"categories/any(c:c eq '{lbl}')" for lbl in context.labels]
        filters.append("( " + " or ".join(cats) + " )")
    filter_q = " and ".join(filters)

    # Select minimal fields and sort newest first
    select = (
        "id,conversationId,subject,from,toRecipients,ccRecipients,receivedDateTime,"
        "bodyPreview,internetMessageId,categories"
    )
    top = 50
    url = (
        f"{base_url}{base_res}/messages"
        f"?$select={select}&$orderby=receivedDateTime desc&$top={top}&$filter={httpx.QueryParams({'f': filter_q})['f']}"
    )

    items: List[MessageItem] = []
    async with httpx.AsyncClient(timeout=30) as client:
        next_url = url
        fetched = 0
        max_fetch = 200
        while next_url and fetched < max_fetch:
            resp = await client.get(next_url, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            for m in data.get("value", []):
                s_name = (m.get("from", {}).get("emailAddress", {}) or {}).get("name") or ""
                s_email = (m.get("from", {}).get("emailAddress", {}) or {}).get("address") or ""
                to_names, to_emails = _join_people(m.get("toRecipients", []))
                cc_names, cc_emails = _join_people(m.get("ccRecipients", []))
                receiver_name = ", ".join([v for v in [to_names, cc_names] if v])
                receiver_email = ", ".join([v for v in [to_emails, cc_emails] if v])

                items.append(
                    MessageItem(
                        message_id=m.get("id", ""),
                        thread_id=m.get("conversationId", ""),
                        sender_name=s_name,
                        sender_email=s_email,
                        receiver_name=receiver_name,
                        receiver_email=receiver_email,
                        iso_datetime=m.get("receivedDateTime", ""),
                        subject=m.get("subject", ""),
                        body=m.get("bodyPreview", ""),
                    )
                )
                fetched += 1
            next_url = data.get("@odata.nextLink")
            if next_url and fetched >= max_fetch:
                break

    return items


async def reply_to_email_m365_async(
    reply_email_context: ReplyEmailContext,
    tool_config: Optional[List[Dict]] = None,
    auth_mode: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Reply-all to a message using Microsoft Graph. Returns basic metadata similar to GW helper.
    """
    if reply_email_context.add_labels is None:
        reply_email_context.add_labels = []

    token = get_microsoft365_access_token(tool_config)
    base_url = "https://graph.microsoft.com/v1.0"
    base_res = _base_resource(reply_email_context.sender_email, tool_config, auth_mode)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    reply_type = (reply_email_context.reply_type or "reply").lower()
    if reply_type not in {"reply", "reply_all", "forward"}:
        reply_type = "reply"

    explicit_to = _normalize_recipients(reply_email_context.to_recipients)
    explicit_cc = _normalize_recipients(reply_email_context.cc_recipients)
    explicit_bcc = _normalize_recipients(reply_email_context.bcc_recipients)

    # 1) Fetch original message for context (subject, recipients, thread)
    async with httpx.AsyncClient(timeout=30) as client:
        get_url = f"{base_url}{base_res}/messages/{reply_email_context.message_id}"
        get_resp = await client.get(get_url, headers=headers)
        get_resp.raise_for_status()
        orig = get_resp.json()

        orig_subject = orig.get("subject", "")
        thread_id = orig.get("conversationId", "")
        cc_list = orig.get("ccRecipients", [])
        to_list = orig.get("toRecipients", [])
        from_addr = (orig.get("from", {}) or {}).get("emailAddress", {}) or {}
        from_email = from_addr.get("address", "")
        from_name = from_addr.get("name")

        sender_email_lc = (reply_email_context.sender_email or "").lower()

        def _is_self(addr: str) -> bool:
            return bool(sender_email_lc) and sender_email_lc in addr.lower()

        def _address_dicts(recipients: List[Dict[str, Any]]) -> List[Dict[str, str]]:
            result: List[Dict[str, str]] = []
            for recipient in recipients or []:
                email_address = recipient.get("emailAddress", {}) if recipient else {}
                address = email_address.get("address")
                if not address:
                    continue
                result.append({"email": address, "name": email_address.get("name")})
            return result

        to_recipients: List[Dict[str, str]] = []
        cc_recipients: List[Dict[str, str]] = []
        bcc_recipients: List[Dict[str, str]] = []

        if reply_type == "forward":
            if not explicit_to:
                raise ValueError("Forward requires explicit to_recipients.")
            to_recipients = _dedupe_recipients(explicit_to)
            cc_recipients = _dedupe_recipients(explicit_cc)
            bcc_recipients = _dedupe_recipients(explicit_bcc)

            if reply_email_context.subject:
                subject = reply_email_context.subject
            elif orig_subject and not orig_subject.lower().startswith("fwd:"):
                subject = f"Fwd: {orig_subject}"
            else:
                subject = orig_subject or "Fwd:"
        else:
            subject = orig_subject if orig_subject.startswith("Re:") else f"Re: {orig_subject}"

            if reply_type == "reply_all":
                base_to = _dedupe_recipients(
                    [{"email": from_email, "name": from_name}] if from_email and not _is_self(from_email) else [],
                    exclude_emails=[reply_email_context.sender_email],
                )
                if not base_to:
                    base_to = _dedupe_recipients(
                        _address_dicts(to_list),
                        exclude_emails=[reply_email_context.sender_email],
                    )
                if not base_to and reply_email_context.fallback_recipient and not _is_self(reply_email_context.fallback_recipient):
                    base_to = _dedupe_recipients([{"email": reply_email_context.fallback_recipient}])
                if not base_to:
                    raise ValueError(
                        "No valid recipient found in the original message; refusing to reply to sender."
                    )
                base_to_emails = [recipient.get("email") for recipient in base_to if recipient.get("email")]
                base_cc_candidates = _address_dicts(to_list) + _address_dicts(cc_list)
                base_cc = _dedupe_recipients(
                    base_cc_candidates,
                    exclude_emails=[reply_email_context.sender_email] + base_to_emails,
                )
            else:
                base_to = _dedupe_recipients(
                    [{"email": from_email, "name": from_name}] if from_email and not _is_self(from_email) else [],
                    exclude_emails=[reply_email_context.sender_email],
                )
                if not base_to:
                    base_to = _dedupe_recipients(
                        _address_dicts(to_list),
                        exclude_emails=[reply_email_context.sender_email],
                    )
                base_cc = _dedupe_recipients(
                    _address_dicts(cc_list),
                    exclude_emails=[reply_email_context.sender_email],
                )
                if not base_to and reply_email_context.fallback_recipient and not _is_self(reply_email_context.fallback_recipient):
                    base_to = _dedupe_recipients([{"email": reply_email_context.fallback_recipient}])
                    base_cc = []
                if not base_to:
                    raise ValueError(
                        "No valid recipient found in the original message; refusing to reply to sender."
                    )

            to_recipients = base_to
            if explicit_to:
                to_recipients = _dedupe_recipients(explicit_to)

            cc_recipients = base_cc
            if explicit_cc:
                cc_recipients = _dedupe_recipients(
                    base_cc + explicit_cc,
                    exclude_emails=[recipient.get("email") for recipient in to_recipients if recipient.get("email")],
                )

            bcc_recipients = _dedupe_recipients(explicit_bcc)

        to_addresses = ", ".join([recipient.get("email") for recipient in to_recipients if recipient.get("email")])
        cc_addresses = ", ".join([recipient.get("email") for recipient in cc_recipients if recipient.get("email")])

        if not to_addresses:
            raise ValueError(
                "No valid recipient found in the original message; refusing to reply to sender."
            )

        # 2) Create draft with comment
        if reply_type == "forward":
            create_reply_url = (
                f"{base_url}{base_res}/messages/{reply_email_context.message_id}/createForward"
            )
        elif reply_type == "reply":
            create_reply_url = (
                f"{base_url}{base_res}/messages/{reply_email_context.message_id}/createReply"
            )
        else:
            create_reply_url = (
                f"{base_url}{base_res}/messages/{reply_email_context.message_id}/createReplyAll"
            )
        create_payload = {"comment": reply_email_context.reply_body}
        create_resp = await client.post(create_reply_url, headers=headers, json=create_payload)
        create_resp.raise_for_status()
        reply_msg = create_resp.json()
        reply_id = reply_msg.get("id")

        # 3) Optionally update recipients/subject and add categories (labels) to the draft
        patch_payload: Dict[str, Any] = {}
        if to_recipients:
            patch_payload["toRecipients"] = _recipients_to_m365(to_recipients)
        if cc_recipients:
            patch_payload["ccRecipients"] = _recipients_to_m365(cc_recipients)
        if bcc_recipients:
            patch_payload["bccRecipients"] = _recipients_to_m365(bcc_recipients)
        if reply_type == "forward":
            patch_payload["subject"] = subject
        if reply_email_context.add_labels:
            categories = list(set((reply_msg.get("categories") or []) + reply_email_context.add_labels))
            patch_payload["categories"] = categories
        if patch_payload:
            patch_url = f"{base_url}{base_res}/messages/{reply_id}"
            await client.patch(patch_url, headers=headers, json=patch_payload)

        # 4) Send the reply
        send_url = f"{base_url}{base_res}/messages/{reply_id}/send"
        send_resp = await client.post(send_url, headers=headers)
        send_resp.raise_for_status()

        # 5) Optionally mark original as read
        if str(reply_email_context.mark_as_read).lower() == "true":
            mark_url = f"{base_url}{base_res}/messages/{reply_email_context.message_id}"
            await client.patch(mark_url, headers=headers, json={"isRead": True})

    # Attempt to fetch the sent message to get final details (best effort)
    email_labels: List[str] = reply_email_context.add_labels or []
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            fetch_url = f"{base_url}{base_res}/messages/{reply_id}?$select=id,categories"
            fetch_resp = await client.get(fetch_url, headers=headers)
            if fetch_resp.status_code == 200:
                sent_obj = fetch_resp.json()
                email_labels = sent_obj.get("categories", email_labels)
    except Exception:
        pass

    sent_message_details = {
        "mailbox_email_id": reply_id,
        "message_id": thread_id,
        "thread_id": thread_id,
        "email_subject": subject,
        "email_sender": reply_email_context.sender_email,
        "email_recipients": [to_addresses] + ([cc_addresses] if cc_addresses else []),
        "to_recipients": to_recipients,
        "cc_recipients": cc_recipients,
        "read_email_status": "READ" if str(reply_email_context.mark_as_read).lower() == "true" else "UNREAD",
        "email_labels": email_labels,
    }

    return sent_message_details
