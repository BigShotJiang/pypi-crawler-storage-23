"""External IO adapters."""
