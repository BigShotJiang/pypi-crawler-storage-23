"""Version constants for agent-estimate."""

__version__ = "0.3.0"
