"""ECR image management utilities."""

from __future__ import annotations

import asyncio
import logging
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# ECR constants
ECR_REGISTRY = "383806609161.dkr.ecr.us-west-1.amazonaws.com"
ECR_REGION = "us-west-1"


@dataclass
class ECRImage:
    """Parsed ECR image URL."""

    registry: str
    repository: str
    tag: str
    region: str

    @classmethod
    def from_url(cls, url: str) -> ECRImage:
        """Parse an ECR image URL."""
        match = re.match(r"^([^/]+)/(.+):(.+)$", url)
        if not match:
            raise ValueError(f"Invalid ECR URL format: {url}")

        registry = match.group(1)
        repository = match.group(2)
        tag = match.group(3)

        region_match = re.search(r"\.ecr\.([^.]+)\.", registry)
        if not region_match:
            raise ValueError(f"Could not extract region from ECR URL: {url}")

        return cls(registry=registry, repository=repository, tag=tag, region=region_match.group(1))

    @property
    def full_url(self) -> str:
        return f"{self.registry}/{self.repository}:{self.tag}"

    @property
    def short_name(self) -> str:
        repo_name = self.repository.split("/")[-1]
        return f"{repo_name}:{self.tag}"


def ecr_login() -> bool:
    """Login to ECR. Returns True on success."""
    login_cmd = subprocess.run(
        ["aws", "ecr", "get-login-password", "--region", ECR_REGION],
        capture_output=True,
        text=True,
    )
    if login_cmd.returncode != 0:
        logger.error(f"ECR login failed: {login_cmd.stderr}")
        return False

    docker_login = subprocess.run(
        ["docker", "login", "--username", "AWS", "--password-stdin", ECR_REGISTRY],
        input=login_cmd.stdout,
        capture_output=True,
        text=True,
    )
    if docker_login.returncode != 0:
        logger.error(f"Docker login failed: {docker_login.stderr}")
        return False

    return True


def ensure_repository(repository: str) -> bool:
    """Ensure ECR repository exists, create if not."""
    result = subprocess.run(
        [
            "aws",
            "ecr",
            "describe-repositories",
            "--repository-names",
            repository,
            "--region",
            ECR_REGION,
            "--output",
            "json",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return True

    logger.info(f"Creating ECR repository: {repository}")
    result = subprocess.run(
        [
            "aws",
            "ecr",
            "create-repository",
            "--repository-name",
            repository,
            "--region",
            ECR_REGION,
            "--output",
            "json",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        # If another process created the repository first, treat it as success.
        if "RepositoryAlreadyExistsException" in (result.stderr or ""):
            return True
        logger.error(f"Failed to create repository: {result.stderr}")
        return False

    return True


def build_and_push(
    local_image: str,
    ecr_image: str,
    build_path: str,
    repository: str,
    no_cache: bool = False,
) -> bool:
    """Build Docker image and push to ECR."""
    # Build
    build_cmd = ["docker", "build", "-t", local_image]
    if no_cache:
        build_cmd.append("--no-cache")
    build_cmd.append(".")
    result = subprocess.run(build_cmd, cwd=build_path)
    if result.returncode != 0:
        return False

    # Tag
    result = subprocess.run(["docker", "tag", local_image, ecr_image])
    if result.returncode != 0:
        return False

    # Ensure repo exists
    if not ensure_repository(repository):
        return False

    # Login
    if not ecr_login():
        return False

    # Push
    result = subprocess.run(["docker", "push", ecr_image])
    return result.returncode == 0


def get_image_digest(repository: str, tag: str) -> str | None:
    """Get the digest of an image tag in ECR. Returns None if not found."""
    import json

    result = subprocess.run(
        [
            "aws",
            "ecr",
            "describe-images",
            "--repository-name",
            repository,
            "--image-ids",
            f"imageTag={tag}",
            "--region",
            ECR_REGION,
            "--output",
            "json",
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None

    try:
        data = json.loads(result.stdout)
        images = data.get("imageDetails", [])
        if images:
            return images[0].get("imageDigest")
    except Exception:
        pass
    return None


@dataclass
class DockerPublishResult:
    """Result of a Docker publish operation."""

    success: bool
    ecr_image: str
    latest_image: str
    error: str | None = None


def publish_docker_image(
    name: str,
    version: str,
    build_path: str,
    repo_prefix: str,
    target: str | None = None,
    build_args: dict[str, str] | None = None,
    disable_provenance: bool = True,
) -> DockerPublishResult:
    """Build and publish a Docker image to ECR.

    Args:
        name: Short name for the image (e.g., 'my-agent')
        version: Version tag (e.g., '1.0.0')
        build_path: Path to directory containing Dockerfile
        repo_prefix: ECR repository prefix (e.g., 'vm/rootfs/plato-agents')
        target: Optional Docker build target (e.g., 'prod')
        build_args: Optional build arguments
        disable_provenance: Disable BuildKit provenance attestations by default
            so unchanged image content yields stable digests.

    Returns:
        DockerPublishResult with success status and image URIs
    """
    repository = f"{repo_prefix}/{name}"
    local_tag = f"{name}:{version}"
    ecr_image = f"{ECR_REGISTRY}/{repository}:{version}"
    latest_image = f"{ECR_REGISTRY}/{repository}:latest"

    # Build Docker image
    docker_cmd = ["docker", "build"]
    if disable_provenance:
        docker_cmd.append("--provenance=false")
    docker_cmd.extend(["-t", local_tag])

    # Add --target if specified, or auto-detect from Dockerfile
    dockerfile_path = Path(build_path) / "Dockerfile"
    if target:
        docker_cmd.extend(["--target", target])
    elif dockerfile_path.exists():
        dockerfile_content = dockerfile_path.read_text()
        if "FROM" in dockerfile_content and "AS prod" in dockerfile_content:
            docker_cmd.extend(["--target", "prod"])

    # Add build args
    if build_args:
        for key, value in build_args.items():
            docker_cmd.extend(["--build-arg", f"{key}={value}"])

    docker_cmd.append(build_path)

    result = subprocess.run(docker_cmd)
    if result.returncode != 0:
        return DockerPublishResult(
            success=False, ecr_image=ecr_image, latest_image=latest_image, error="Docker build failed"
        )

    # Tag for ECR
    subprocess.run(["docker", "tag", local_tag, ecr_image])

    # Ensure repo exists
    if not ensure_repository(repository):
        return DockerPublishResult(
            success=False, ecr_image=ecr_image, latest_image=latest_image, error="Failed to create ECR repository"
        )

    # Login to ECR
    if not ecr_login():
        return DockerPublishResult(
            success=False, ecr_image=ecr_image, latest_image=latest_image, error="ECR login failed"
        )

    # Push versioned tag
    result = subprocess.run(["docker", "push", ecr_image])
    if result.returncode != 0:
        return DockerPublishResult(success=False, ecr_image=ecr_image, latest_image=latest_image, error="Push failed")

    # Also push :latest
    subprocess.run(["docker", "tag", local_tag, latest_image])
    subprocess.run(["docker", "push", latest_image])

    return DockerPublishResult(success=True, ecr_image=ecr_image, latest_image=latest_image)


# Async versions for chronos dev
async def check_image_exists_async(image: ECRImage) -> bool:
    """Check if an image exists in ECR (async)."""
    cmd = [
        "aws",
        "ecr",
        "describe-images",
        "--repository-name",
        image.repository,
        "--image-ids",
        f"imageTag={image.tag}",
        "--region",
        image.region,
        "--output",
        "json",
    ]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()

        if proc.returncode == 0:
            return True

        stderr_str = stderr.decode()
        if "ImageNotFoundException" in stderr_str or "RepositoryNotFoundException" in stderr_str:
            return False

        logger.warning(f"ECR check failed: {stderr_str}")
        return False

    except FileNotFoundError:
        logger.warning("AWS CLI not found")
        return False


async def ensure_image_exists_async(image_url: str) -> bool:
    """Ensure an image exists in ECR (async)."""
    try:
        image = ECRImage.from_url(image_url)
    except ValueError as e:
        logger.error(f"Invalid ECR URL: {e}")
        raise

    logger.info(f"Checking if image exists: {image.short_name}")
    if await check_image_exists_async(image):
        logger.info(f"Image found: {image.short_name}")
        return True

    raise RuntimeError(
        f"Image not found in ECR: {image.full_url}\n\n"
        f"Push the image first with: plato world publish <path> or plato agent publish <path>"
    )
