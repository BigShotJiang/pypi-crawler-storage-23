import sys
import far_science

sys.exit(far_science.main())
