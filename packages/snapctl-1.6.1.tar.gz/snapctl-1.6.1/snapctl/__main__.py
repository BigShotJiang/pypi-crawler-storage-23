"""
This file is used to run the snapctl command line interface.
"""
from .main import app
app(prog_name="snapctl")
